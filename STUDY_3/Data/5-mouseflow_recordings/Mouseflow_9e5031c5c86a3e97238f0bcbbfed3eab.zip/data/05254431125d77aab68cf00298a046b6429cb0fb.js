var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05254431125d77aab68cf00298a046b6429cb0fb"] = {
  "startTime": "2018-05-25T17:17:44.5327569Z",
  "websitePageUrl": "/16",
  "visitTime": 145918,
  "engagementTime": 86693,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "9e5031c5c86a3e97238f0bcbbfed3eab",
    "created": "2018-05-25T17:17:44.5327569+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=3A2HT",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6a589428a7ca9609690c4fdf16db8c2a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/9e5031c5c86a3e97238f0bcbbfed3eab/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 302,
      "e": 302,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 473,
      "y": 753
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 42480,
      "y": 40938,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 478,
      "y": 739
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 478,
      "y": 731
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 491,
      "y": 697
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 44278,
      "y": 38168,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 495,
      "y": 692
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 44616,
      "y": 37836,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 493,
      "y": 690
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 477,
      "y": 651
    },
    {
      "t": 1969,
      "e": 1969,
      "ty": 6,
      "x": 474,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 474,
      "y": 586
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 42368,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 489,
      "y": 543
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 492,
      "y": 536
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 44391,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4796,
      "e": 4796,
      "ty": 3,
      "x": 492,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4799,
      "e": 4799,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4915,
      "e": 4915,
      "ty": 4,
      "x": 44391,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4915,
      "e": 4915,
      "ty": 5,
      "x": 492,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 493,
      "y": 535
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 592,
      "y": 559
    },
    {
      "t": 5222,
      "e": 5222,
      "ty": 7,
      "x": 749,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 3242,
      "y": 36670,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 982,
      "y": 744
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1045,
      "y": 820
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1094,
      "y": 886
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 21705,
      "y": 53573,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1128,
      "y": 950
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1174,
      "y": 985
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 29386,
      "y": 60736,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1270,
      "y": 969
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1323,
      "y": 962
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1329,
      "y": 962
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 38265,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 1323,
      "y": 960
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1309,
      "y": 949
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 35516,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1274,
      "y": 937
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1238,
      "y": 932
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1203,
      "y": 927
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 29386,
      "y": 56510,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1149,
      "y": 919
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1148,
      "y": 918
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 25510,
      "y": 56009,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 1150,
      "y": 932
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1150,
      "y": 938
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1150,
      "y": 943
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 25651,
      "y": 57656,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1149,
      "y": 961
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1149,
      "y": 963
    },
    {
      "t": 7752,
      "e": 7752,
      "ty": 41,
      "x": 21504,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1147,
      "y": 894
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1158,
      "y": 804
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 26215,
      "y": 47700,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8100,
      "e": 8100,
      "ty": 2,
      "x": 1164,
      "y": 760
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 1158,
      "y": 782
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 24594,
      "y": 50565,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1125,
      "y": 884
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1125,
      "y": 888
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 1118,
      "y": 888
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 23396,
      "y": 53717,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 667,
      "y": 777
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 596,
      "y": 694
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 53721,
      "y": 36728,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8800,
      "e": 8800,
      "ty": 2,
      "x": 565,
      "y": 665
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 2,
      "x": 556,
      "y": 664
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 51585,
      "y": 36340,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12753,
      "e": 12753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 12895,
      "e": 12895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12896,
      "e": 12896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12935,
      "e": 12935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 12976,
      "e": 12976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 13136,
      "e": 13136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13136,
      "e": 13136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13199,
      "e": 13199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 13295,
      "e": 13295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13295,
      "e": 13295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13336,
      "e": 13336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 13456,
      "e": 13456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13459,
      "e": 13459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13519,
      "e": 13519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 13583,
      "e": 13583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 13704,
      "e": 13704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13705,
      "e": 13705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13714,
      "e": 13714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13799,
      "e": 13799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13863,
      "e": 13863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13864,
      "e": 13864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14002,
      "e": 14002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look A"
    },
    {
      "t": 14031,
      "e": 14031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 14103,
      "e": 14103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14104,
      "e": 14104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14304,
      "e": 14304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 15032,
      "e": 15032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15152,
      "e": 15152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look A"
    },
    {
      "t": 15239,
      "e": 15239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15335,
      "e": 15335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look "
    },
    {
      "t": 15848,
      "e": 15848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15849,
      "e": 15849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15975,
      "e": 15975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 16128,
      "e": 16128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16128,
      "e": 16128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16304,
      "e": 16304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 16312,
      "e": 16312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16313,
      "e": 16313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16375,
      "e": 16375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17016,
      "e": 17016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17120,
      "e": 17120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look AT"
    },
    {
      "t": 17216,
      "e": 17216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17279,
      "e": 17279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look A"
    },
    {
      "t": 17351,
      "e": 17351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17456,
      "e": 17456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look "
    },
    {
      "t": 17520,
      "e": 17520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 17608,
      "e": 17608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17744,
      "e": 17744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17745,
      "e": 17745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17879,
      "e": 17879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17976,
      "e": 17976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17976,
      "e": 17976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18112,
      "e": 18112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18113,
      "e": 18113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18159,
      "e": 18159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 18408,
      "e": 18408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18840,
      "e": 18840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18841,
      "e": 18841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18927,
      "e": 18927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 19144,
      "e": 19144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 19145,
      "e": 19145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19269,
      "e": 19269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 19708,
      "e": 19708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19709,
      "e": 19709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19797,
      "e": 19797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19933,
      "e": 19933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19933,
      "e": 19933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19995,
      "e": 19995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19997,
      "e": 19997,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20116,
      "e": 20116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20116,
      "e": 20116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20164,
      "e": 20164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20164,
      "e": 20164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20188,
      "e": 20188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 20292,
      "e": 20292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20292,
      "e": 20292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20308,
      "e": 20308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20308,
      "e": 20308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20316,
      "e": 20316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 20372,
      "e": 20372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20485,
      "e": 20485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20492,
      "e": 20492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20492,
      "e": 20492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20564,
      "e": 20564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20853,
      "e": 20853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 20853,
      "e": 20853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20979,
      "e": 20979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20980,
      "e": 20980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21028,
      "e": 21028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 21067,
      "e": 21067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21075,
      "e": 21075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21075,
      "e": 21075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21198,
      "e": 21198,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and wha"
    },
    {
      "t": 21212,
      "e": 21212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21213,
      "e": 21213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21236,
      "e": 21236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 21276,
      "e": 21276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21399,
      "e": 21399,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what"
    },
    {
      "t": 21428,
      "e": 21428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21429,
      "e": 21429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21484,
      "e": 21484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21599,
      "e": 21599,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what "
    },
    {
      "t": 21628,
      "e": 21628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21629,
      "e": 21629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21725,
      "e": 21725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21726,
      "e": 21726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21732,
      "e": 21732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 21844,
      "e": 21844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21844,
      "e": 21844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21844,
      "e": 21844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21923,
      "e": 21923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21996,
      "e": 21996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21997,
      "e": 21997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22067,
      "e": 22067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 22068,
      "e": 22068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22132,
      "e": 22132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ab"
    },
    {
      "t": 22180,
      "e": 22180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22252,
      "e": 22252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22254,
      "e": 22254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22372,
      "e": 22372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22797,
      "e": 22797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 22798,
      "e": 22798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22923,
      "e": 22923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 23020,
      "e": 23020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23020,
      "e": 23020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23140,
      "e": 23140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23140,
      "e": 23140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23171,
      "e": 23171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 23212,
      "e": 23212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23460,
      "e": 23460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23461,
      "e": 23461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23599,
      "e": 23599,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above a"
    },
    {
      "t": 23628,
      "e": 23628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23660,
      "e": 23660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23660,
      "e": 23660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23795,
      "e": 23795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23795,
      "e": 23795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23835,
      "e": 23835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 23884,
      "e": 23884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23884,
      "e": 23884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23932,
      "e": 23932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23940,
      "e": 23940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24036,
      "e": 24036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24036,
      "e": 24036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24100,
      "e": 24100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24101,
      "e": 24101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24189,
      "e": 24189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 24196,
      "e": 24196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24199,
      "e": 24199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24199,
      "e": 24199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24316,
      "e": 24316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24316,
      "e": 24316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24340,
      "e": 24340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 24436,
      "e": 24436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24772,
      "e": 24772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24774,
      "e": 24774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24892,
      "e": 24892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24964,
      "e": 24964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 24965,
      "e": 24965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25091,
      "e": 25091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 25140,
      "e": 25140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25141,
      "e": 25141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25308,
      "e": 25308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25308,
      "e": 25308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25348,
      "e": 25348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 25348,
      "e": 25348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25348,
      "e": 25348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25412,
      "e": 25412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25509,
      "e": 25509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25597,
      "e": 25597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25598,
      "e": 25598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25724,
      "e": 25724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25724,
      "e": 25724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25796,
      "e": 25796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 25804,
      "e": 25804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26980,
      "e": 26980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26982,
      "e": 26982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27076,
      "e": 27076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27213,
      "e": 27213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27213,
      "e": 27213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27364,
      "e": 27364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27436,
      "e": 27436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27438,
      "e": 27438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27600,
      "e": 27600,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events sta"
    },
    {
      "t": 27628,
      "e": 27628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27647,
      "e": 27630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27648,
      "e": 27631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27799,
      "e": 27782,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events star"
    },
    {
      "t": 27820,
      "e": 27803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 28204,
      "e": 28187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28206,
      "e": 28189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28380,
      "e": 28363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28421,
      "e": 28404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28422,
      "e": 28405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28492,
      "e": 28475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28599,
      "e": 28582,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start "
    },
    {
      "t": 28733,
      "e": 28716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28733,
      "e": 28716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28860,
      "e": 28843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28956,
      "e": 28939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28956,
      "e": 28939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29125,
      "e": 29108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29126,
      "e": 29109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29147,
      "e": 29130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 29203,
      "e": 29186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29469,
      "e": 29452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 29469,
      "e": 29452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29599,
      "e": 29582,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 1"
    },
    {
      "t": 29603,
      "e": 29586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 29708,
      "e": 29691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 29709,
      "e": 29692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29876,
      "e": 29859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 30116,
      "e": 30099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30116,
      "e": 30099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30219,
      "e": 30202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30381,
      "e": 30364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30382,
      "e": 30365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30459,
      "e": 30442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 30805,
      "e": 30788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 30805,
      "e": 30788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30916,
      "e": 30899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 32097,
      "e": 32080,
      "ty": 2,
      "x": 364,
      "y": 608
    },
    {
      "t": 32107,
      "e": 32090,
      "ty": 6,
      "x": 237,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32197,
      "e": 32180,
      "ty": 2,
      "x": 113,
      "y": 537
    },
    {
      "t": 32240,
      "e": 32223,
      "ty": 7,
      "x": 132,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32247,
      "e": 32230,
      "ty": 41,
      "x": 3923,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 32297,
      "e": 32280,
      "ty": 2,
      "x": 205,
      "y": 485
    },
    {
      "t": 32397,
      "e": 32380,
      "ty": 2,
      "x": 553,
      "y": 463
    },
    {
      "t": 32498,
      "e": 32481,
      "ty": 2,
      "x": 587,
      "y": 520
    },
    {
      "t": 32498,
      "e": 32481,
      "ty": 41,
      "x": 55070,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 32507,
      "e": 32490,
      "ty": 6,
      "x": 589,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32598,
      "e": 32581,
      "ty": 2,
      "x": 591,
      "y": 529
    },
    {
      "t": 32747,
      "e": 32730,
      "ty": 41,
      "x": 55519,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33024,
      "e": 33007,
      "ty": 3,
      "x": 591,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33128,
      "e": 33111,
      "ty": 4,
      "x": 55519,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33128,
      "e": 33111,
      "ty": 5,
      "x": 591,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33869,
      "e": 33852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33932,
      "e": 33915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12o\n"
    },
    {
      "t": 34012,
      "e": 33995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34051,
      "e": 34034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12\n"
    },
    {
      "t": 34200,
      "e": 34183,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12\n"
    },
    {
      "t": 34260,
      "e": 34243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34261,
      "e": 34244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34324,
      "e": 34307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12p\n"
    },
    {
      "t": 34492,
      "e": 34475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34493,
      "e": 34476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34564,
      "e": 34547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12pm\n"
    },
    {
      "t": 35493,
      "e": 35476,
      "ty": 7,
      "x": 582,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35497,
      "e": 35480,
      "ty": 2,
      "x": 582,
      "y": 606
    },
    {
      "t": 35497,
      "e": 35480,
      "ty": 41,
      "x": 54508,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 35597,
      "e": 35580,
      "ty": 2,
      "x": 500,
      "y": 770
    },
    {
      "t": 35697,
      "e": 35680,
      "ty": 2,
      "x": 468,
      "y": 761
    },
    {
      "t": 35748,
      "e": 35731,
      "ty": 41,
      "x": 33425,
      "y": 57189,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 35797,
      "e": 35780,
      "ty": 2,
      "x": 383,
      "y": 692
    },
    {
      "t": 35812,
      "e": 35781,
      "ty": 6,
      "x": 383,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 35860,
      "e": 35829,
      "ty": 7,
      "x": 383,
      "y": 652,
      "ta": "#strategyButton"
    },
    {
      "t": 35898,
      "e": 35867,
      "ty": 2,
      "x": 383,
      "y": 651
    },
    {
      "t": 35998,
      "e": 35967,
      "ty": 41,
      "x": 30149,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 36197,
      "e": 36166,
      "ty": 2,
      "x": 384,
      "y": 650
    },
    {
      "t": 36248,
      "e": 36217,
      "ty": 41,
      "x": 31085,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 36297,
      "e": 36266,
      "ty": 2,
      "x": 387,
      "y": 652
    },
    {
      "t": 36313,
      "e": 36282,
      "ty": 6,
      "x": 389,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 36397,
      "e": 36366,
      "ty": 2,
      "x": 394,
      "y": 665
    },
    {
      "t": 36498,
      "e": 36467,
      "ty": 41,
      "x": 30258,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 36593,
      "e": 36562,
      "ty": 3,
      "x": 394,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 36594,
      "e": 36563,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at 12pm and what is above are the events start at 12pm\n"
    },
    {
      "t": 36595,
      "e": 36564,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36596,
      "e": 36565,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 36720,
      "e": 36689,
      "ty": 4,
      "x": 30258,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 36732,
      "e": 36701,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 36734,
      "e": 36703,
      "ty": 5,
      "x": 394,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 36741,
      "e": 36710,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 37298,
      "e": 37267,
      "ty": 2,
      "x": 395,
      "y": 654
    },
    {
      "t": 37497,
      "e": 37466,
      "ty": 41,
      "x": 13327,
      "y": 35786,
      "ta": "html > body"
    },
    {
      "t": 37741,
      "e": 37710,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 38197,
      "e": 38166,
      "ty": 2,
      "x": 415,
      "y": 654
    },
    {
      "t": 38255,
      "e": 38224,
      "ty": 41,
      "x": 17873,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 38297,
      "e": 38266,
      "ty": 2,
      "x": 613,
      "y": 645
    },
    {
      "t": 38397,
      "e": 38366,
      "ty": 2,
      "x": 706,
      "y": 641
    },
    {
      "t": 38498,
      "e": 38467,
      "ty": 2,
      "x": 744,
      "y": 629
    },
    {
      "t": 38498,
      "e": 38467,
      "ty": 41,
      "x": 25346,
      "y": 34401,
      "ta": "html > body"
    },
    {
      "t": 38597,
      "e": 38566,
      "ty": 2,
      "x": 841,
      "y": 599
    },
    {
      "t": 38697,
      "e": 38666,
      "ty": 2,
      "x": 875,
      "y": 590
    },
    {
      "t": 38748,
      "e": 38717,
      "ty": 41,
      "x": 15356,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 38798,
      "e": 38767,
      "ty": 2,
      "x": 887,
      "y": 582
    },
    {
      "t": 38897,
      "e": 38866,
      "ty": 2,
      "x": 891,
      "y": 576
    },
    {
      "t": 38912,
      "e": 38881,
      "ty": 6,
      "x": 894,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38998,
      "e": 38967,
      "ty": 2,
      "x": 898,
      "y": 566
    },
    {
      "t": 38998,
      "e": 38967,
      "ty": 41,
      "x": 19465,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39040,
      "e": 39009,
      "ty": 3,
      "x": 898,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39040,
      "e": 39009,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39152,
      "e": 39121,
      "ty": 4,
      "x": 19465,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39152,
      "e": 39121,
      "ty": 5,
      "x": 898,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40107,
      "e": 40076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 40108,
      "e": 40077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40204,
      "e": 40173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 40205,
      "e": 40174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40251,
      "e": 40220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 40268,
      "e": 40237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 40399,
      "e": 40368,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 40997,
      "e": 40966,
      "ty": 2,
      "x": 905,
      "y": 567
    },
    {
      "t": 40999,
      "e": 40968,
      "ty": 41,
      "x": 20979,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41031,
      "e": 41000,
      "ty": 7,
      "x": 908,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41098,
      "e": 41067,
      "ty": 2,
      "x": 904,
      "y": 589
    },
    {
      "t": 41197,
      "e": 41166,
      "ty": 2,
      "x": 922,
      "y": 607
    },
    {
      "t": 41247,
      "e": 41216,
      "ty": 41,
      "x": 27684,
      "y": 42129,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 41297,
      "e": 41266,
      "ty": 2,
      "x": 945,
      "y": 633
    },
    {
      "t": 41381,
      "e": 41350,
      "ty": 6,
      "x": 947,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41397,
      "e": 41366,
      "ty": 2,
      "x": 947,
      "y": 651
    },
    {
      "t": 41498,
      "e": 41467,
      "ty": 2,
      "x": 948,
      "y": 662
    },
    {
      "t": 41498,
      "e": 41467,
      "ty": 41,
      "x": 30280,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41817,
      "e": 41786,
      "ty": 3,
      "x": 948,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41818,
      "e": 41787,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 41818,
      "e": 41787,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41819,
      "e": 41788,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41960,
      "e": 41929,
      "ty": 4,
      "x": 30280,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41960,
      "e": 41929,
      "ty": 5,
      "x": 948,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42925,
      "e": 42894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 43043,
      "e": 43012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 43044,
      "e": 43013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43059,
      "e": 43028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 43131,
      "e": 43100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 43164,
      "e": 43133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 43340,
      "e": 43309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 43381,
      "e": 43350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 43381,
      "e": 43350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43476,
      "e": 43445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 43645,
      "e": 43614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43645,
      "e": 43614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43707,
      "e": 43676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 43828,
      "e": 43797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 43828,
      "e": 43797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43899,
      "e": 43868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 43908,
      "e": 43877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 43909,
      "e": 43878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44148,
      "e": 44117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 45698,
      "e": 45667,
      "ty": 2,
      "x": 948,
      "y": 654
    },
    {
      "t": 45748,
      "e": 45717,
      "ty": 41,
      "x": 30280,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45798,
      "e": 45767,
      "ty": 2,
      "x": 944,
      "y": 651
    },
    {
      "t": 45898,
      "e": 45867,
      "ty": 2,
      "x": 940,
      "y": 650
    },
    {
      "t": 45998,
      "e": 45967,
      "ty": 41,
      "x": 28549,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46152,
      "e": 46121,
      "ty": 7,
      "x": 944,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46167,
      "e": 46136,
      "ty": 6,
      "x": 946,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46198,
      "e": 46167,
      "ty": 2,
      "x": 947,
      "y": 688
    },
    {
      "t": 46248,
      "e": 46217,
      "ty": 41,
      "x": 27871,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46285,
      "e": 46254,
      "ty": 7,
      "x": 951,
      "y": 713,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46298,
      "e": 46267,
      "ty": 2,
      "x": 951,
      "y": 713
    },
    {
      "t": 46398,
      "e": 46367,
      "ty": 2,
      "x": 951,
      "y": 718
    },
    {
      "t": 46498,
      "e": 46467,
      "ty": 2,
      "x": 954,
      "y": 721
    },
    {
      "t": 46498,
      "e": 46467,
      "ty": 41,
      "x": 32578,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 46598,
      "e": 46567,
      "ty": 2,
      "x": 955,
      "y": 718
    },
    {
      "t": 46636,
      "e": 46605,
      "ty": 6,
      "x": 958,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46698,
      "e": 46667,
      "ty": 2,
      "x": 959,
      "y": 701
    },
    {
      "t": 46748,
      "e": 46717,
      "ty": 41,
      "x": 32509,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46798,
      "e": 46767,
      "ty": 2,
      "x": 959,
      "y": 700
    },
    {
      "t": 46898,
      "e": 46867,
      "ty": 2,
      "x": 959,
      "y": 699
    },
    {
      "t": 46998,
      "e": 46967,
      "ty": 41,
      "x": 32509,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47400,
      "e": 47369,
      "ty": 3,
      "x": 959,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47401,
      "e": 47370,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 47402,
      "e": 47371,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47402,
      "e": 47371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47520,
      "e": 47489,
      "ty": 4,
      "x": 32509,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47527,
      "e": 47496,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47528,
      "e": 47497,
      "ty": 5,
      "x": 959,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47529,
      "e": 47498,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 47598,
      "e": 47567,
      "ty": 2,
      "x": 959,
      "y": 698
    },
    {
      "t": 47748,
      "e": 47717,
      "ty": 41,
      "x": 32715,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 47797,
      "e": 47766,
      "ty": 2,
      "x": 958,
      "y": 698
    },
    {
      "t": 47897,
      "e": 47866,
      "ty": 2,
      "x": 956,
      "y": 698
    },
    {
      "t": 47997,
      "e": 47966,
      "ty": 2,
      "x": 954,
      "y": 698
    },
    {
      "t": 47997,
      "e": 47966,
      "ty": 41,
      "x": 32578,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 48097,
      "e": 48066,
      "ty": 2,
      "x": 953,
      "y": 698
    },
    {
      "t": 48248,
      "e": 48217,
      "ty": 41,
      "x": 32543,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 48397,
      "e": 48366,
      "ty": 2,
      "x": 952,
      "y": 698
    },
    {
      "t": 48497,
      "e": 48466,
      "ty": 41,
      "x": 32509,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 48549,
      "e": 48518,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 48597,
      "e": 48566,
      "ty": 2,
      "x": 951,
      "y": 697
    },
    {
      "t": 48747,
      "e": 48716,
      "ty": 41,
      "x": 32651,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 49197,
      "e": 49166,
      "ty": 2,
      "x": 937,
      "y": 548
    },
    {
      "t": 49247,
      "e": 49216,
      "ty": 41,
      "x": 23395,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 49297,
      "e": 49266,
      "ty": 2,
      "x": 901,
      "y": 433
    },
    {
      "t": 49397,
      "e": 49366,
      "ty": 2,
      "x": 866,
      "y": 344
    },
    {
      "t": 49497,
      "e": 49466,
      "ty": 2,
      "x": 847,
      "y": 305
    },
    {
      "t": 49497,
      "e": 49466,
      "ty": 41,
      "x": 6070,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 49504,
      "e": 49473,
      "ty": 6,
      "x": 838,
      "y": 294,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 49520,
      "e": 49489,
      "ty": 7,
      "x": 827,
      "y": 285,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 49597,
      "e": 49566,
      "ty": 2,
      "x": 821,
      "y": 280
    },
    {
      "t": 49747,
      "e": 49716,
      "ty": 41,
      "x": 0,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 49797,
      "e": 49766,
      "ty": 2,
      "x": 821,
      "y": 276
    },
    {
      "t": 49897,
      "e": 49866,
      "ty": 2,
      "x": 823,
      "y": 271
    },
    {
      "t": 49998,
      "e": 49967,
      "ty": 41,
      "x": 1201,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 50397,
      "e": 50366,
      "ty": 2,
      "x": 829,
      "y": 280
    },
    {
      "t": 50498,
      "e": 50467,
      "ty": 2,
      "x": 830,
      "y": 285
    },
    {
      "t": 50498,
      "e": 50467,
      "ty": 41,
      "x": 2688,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50567,
      "e": 50536,
      "ty": 6,
      "x": 830,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50597,
      "e": 50566,
      "ty": 2,
      "x": 830,
      "y": 288
    },
    {
      "t": 50747,
      "e": 50716,
      "ty": 41,
      "x": 18037,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50897,
      "e": 50866,
      "ty": 2,
      "x": 830,
      "y": 290
    },
    {
      "t": 50997,
      "e": 50966,
      "ty": 41,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 51097,
      "e": 51066,
      "ty": 2,
      "x": 829,
      "y": 291
    },
    {
      "t": 51247,
      "e": 51216,
      "ty": 41,
      "x": 12996,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52632,
      "e": 52601,
      "ty": 3,
      "x": 829,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52632,
      "e": 52601,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52743,
      "e": 52712,
      "ty": 4,
      "x": 12996,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52744,
      "e": 52713,
      "ty": 5,
      "x": 829,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52744,
      "e": 52713,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 53097,
      "e": 53066,
      "ty": 2,
      "x": 829,
      "y": 294
    },
    {
      "t": 53124,
      "e": 53093,
      "ty": 7,
      "x": 834,
      "y": 309,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 53197,
      "e": 53166,
      "ty": 2,
      "x": 861,
      "y": 359
    },
    {
      "t": 53247,
      "e": 53216,
      "ty": 41,
      "x": 9867,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 53297,
      "e": 53266,
      "ty": 2,
      "x": 863,
      "y": 362
    },
    {
      "t": 53397,
      "e": 53366,
      "ty": 2,
      "x": 863,
      "y": 365
    },
    {
      "t": 53497,
      "e": 53466,
      "ty": 41,
      "x": 9867,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 53697,
      "e": 53666,
      "ty": 2,
      "x": 864,
      "y": 368
    },
    {
      "t": 53747,
      "e": 53716,
      "ty": 41,
      "x": 10104,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 53897,
      "e": 53866,
      "ty": 2,
      "x": 872,
      "y": 375
    },
    {
      "t": 53997,
      "e": 53966,
      "ty": 2,
      "x": 881,
      "y": 381
    },
    {
      "t": 53997,
      "e": 53966,
      "ty": 41,
      "x": 14139,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 54097,
      "e": 54066,
      "ty": 2,
      "x": 885,
      "y": 386
    },
    {
      "t": 54197,
      "e": 54166,
      "ty": 2,
      "x": 888,
      "y": 390
    },
    {
      "t": 54247,
      "e": 54216,
      "ty": 41,
      "x": 15800,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 54397,
      "e": 54366,
      "ty": 2,
      "x": 889,
      "y": 392
    },
    {
      "t": 54498,
      "e": 54467,
      "ty": 2,
      "x": 889,
      "y": 393
    },
    {
      "t": 54498,
      "e": 54467,
      "ty": 41,
      "x": 16037,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 54597,
      "e": 54566,
      "ty": 2,
      "x": 890,
      "y": 393
    },
    {
      "t": 54697,
      "e": 54666,
      "ty": 2,
      "x": 891,
      "y": 394
    },
    {
      "t": 54748,
      "e": 54717,
      "ty": 41,
      "x": 16512,
      "y": 10561,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 54897,
      "e": 54866,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 54997,
      "e": 54966,
      "ty": 2,
      "x": 891,
      "y": 412
    },
    {
      "t": 54997,
      "e": 54966,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 54997,
      "e": 54966,
      "ty": 41,
      "x": 16512,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 55897,
      "e": 55866,
      "ty": 2,
      "x": 891,
      "y": 415
    },
    {
      "t": 55997,
      "e": 55966,
      "ty": 41,
      "x": 16512,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 56097,
      "e": 56066,
      "ty": 2,
      "x": 888,
      "y": 416
    },
    {
      "t": 56197,
      "e": 56166,
      "ty": 2,
      "x": 887,
      "y": 416
    },
    {
      "t": 56248,
      "e": 56217,
      "ty": 41,
      "x": 14614,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 56297,
      "e": 56266,
      "ty": 2,
      "x": 873,
      "y": 418
    },
    {
      "t": 56397,
      "e": 56366,
      "ty": 2,
      "x": 862,
      "y": 421
    },
    {
      "t": 56497,
      "e": 56466,
      "ty": 2,
      "x": 861,
      "y": 421
    },
    {
      "t": 56499,
      "e": 56468,
      "ty": 41,
      "x": 46329,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 56697,
      "e": 56666,
      "ty": 2,
      "x": 860,
      "y": 421
    },
    {
      "t": 56747,
      "e": 56716,
      "ty": 41,
      "x": 40476,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 56794,
      "e": 56763,
      "ty": 6,
      "x": 828,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56797,
      "e": 56766,
      "ty": 2,
      "x": 828,
      "y": 415
    },
    {
      "t": 56810,
      "e": 56779,
      "ty": 7,
      "x": 814,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56897,
      "e": 56866,
      "ty": 2,
      "x": 793,
      "y": 409
    },
    {
      "t": 56998,
      "e": 56967,
      "ty": 41,
      "x": 27033,
      "y": 22214,
      "ta": "html > body"
    },
    {
      "t": 57097,
      "e": 57066,
      "ty": 2,
      "x": 807,
      "y": 409
    },
    {
      "t": 57197,
      "e": 57166,
      "ty": 2,
      "x": 814,
      "y": 411
    },
    {
      "t": 57247,
      "e": 57216,
      "ty": 41,
      "x": 27894,
      "y": 22325,
      "ta": "html > body"
    },
    {
      "t": 57297,
      "e": 57266,
      "ty": 2,
      "x": 819,
      "y": 412
    },
    {
      "t": 57397,
      "e": 57366,
      "ty": 2,
      "x": 822,
      "y": 414
    },
    {
      "t": 57498,
      "e": 57467,
      "ty": 2,
      "x": 825,
      "y": 416
    },
    {
      "t": 57498,
      "e": 57467,
      "ty": 41,
      "x": 4188,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 57520,
      "e": 57489,
      "ty": 6,
      "x": 826,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57597,
      "e": 57566,
      "ty": 2,
      "x": 830,
      "y": 419
    },
    {
      "t": 57748,
      "e": 57717,
      "ty": 41,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57776,
      "e": 57745,
      "ty": 3,
      "x": 830,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57779,
      "e": 57748,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 57780,
      "e": 57749,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57898,
      "e": 57867,
      "ty": 2,
      "x": 831,
      "y": 419
    },
    {
      "t": 57911,
      "e": 57880,
      "ty": 4,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57911,
      "e": 57880,
      "ty": 5,
      "x": 831,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57912,
      "e": 57881,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 57998,
      "e": 57967,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58128,
      "e": 58097,
      "ty": 7,
      "x": 832,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58198,
      "e": 58167,
      "ty": 2,
      "x": 835,
      "y": 430
    },
    {
      "t": 58247,
      "e": 58216,
      "ty": 41,
      "x": 13241,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58298,
      "e": 58267,
      "ty": 2,
      "x": 844,
      "y": 440
    },
    {
      "t": 58497,
      "e": 58466,
      "ty": 41,
      "x": 18034,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58697,
      "e": 58666,
      "ty": 2,
      "x": 844,
      "y": 443
    },
    {
      "t": 58748,
      "e": 58717,
      "ty": 41,
      "x": 18034,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 58797,
      "e": 58766,
      "ty": 2,
      "x": 848,
      "y": 464
    },
    {
      "t": 58862,
      "e": 58831,
      "ty": 6,
      "x": 831,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58878,
      "e": 58847,
      "ty": 7,
      "x": 796,
      "y": 517,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58898,
      "e": 58867,
      "ty": 2,
      "x": 771,
      "y": 523
    },
    {
      "t": 58998,
      "e": 58967,
      "ty": 2,
      "x": 761,
      "y": 559
    },
    {
      "t": 58998,
      "e": 58967,
      "ty": 41,
      "x": 25931,
      "y": 30523,
      "ta": "html > body"
    },
    {
      "t": 59098,
      "e": 59067,
      "ty": 2,
      "x": 855,
      "y": 633
    },
    {
      "t": 59197,
      "e": 59166,
      "ty": 2,
      "x": 923,
      "y": 692
    },
    {
      "t": 59247,
      "e": 59216,
      "ty": 41,
      "x": 35290,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59297,
      "e": 59266,
      "ty": 2,
      "x": 890,
      "y": 796
    },
    {
      "t": 59397,
      "e": 59366,
      "ty": 2,
      "x": 877,
      "y": 808
    },
    {
      "t": 59497,
      "e": 59466,
      "ty": 2,
      "x": 845,
      "y": 815
    },
    {
      "t": 59498,
      "e": 59467,
      "ty": 41,
      "x": 13916,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 59596,
      "e": 59565,
      "ty": 6,
      "x": 838,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 59597,
      "e": 59566,
      "ty": 2,
      "x": 838,
      "y": 815
    },
    {
      "t": 59661,
      "e": 59630,
      "ty": 7,
      "x": 825,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 59697,
      "e": 59666,
      "ty": 2,
      "x": 821,
      "y": 815
    },
    {
      "t": 59748,
      "e": 59717,
      "ty": 41,
      "x": 27928,
      "y": 44705,
      "ta": "html > body"
    },
    {
      "t": 59797,
      "e": 59766,
      "ty": 2,
      "x": 819,
      "y": 815
    },
    {
      "t": 59897,
      "e": 59866,
      "ty": 2,
      "x": 818,
      "y": 815
    },
    {
      "t": 59997,
      "e": 59966,
      "ty": 2,
      "x": 816,
      "y": 814
    },
    {
      "t": 59997,
      "e": 59966,
      "ty": 41,
      "x": 27825,
      "y": 44650,
      "ta": "html > body"
    },
    {
      "t": 60298,
      "e": 60267,
      "ty": 2,
      "x": 822,
      "y": 816
    },
    {
      "t": 60330,
      "e": 60299,
      "ty": 6,
      "x": 826,
      "y": 819,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60364,
      "e": 60333,
      "ty": 7,
      "x": 827,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 60398,
      "e": 60367,
      "ty": 2,
      "x": 827,
      "y": 823
    },
    {
      "t": 60498,
      "e": 60467,
      "ty": 41,
      "x": 3292,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 61098,
      "e": 61067,
      "ty": 2,
      "x": 826,
      "y": 824
    },
    {
      "t": 61247,
      "e": 61216,
      "ty": 41,
      "x": 2111,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 61299,
      "e": 61268,
      "ty": 2,
      "x": 901,
      "y": 670
    },
    {
      "t": 61397,
      "e": 61366,
      "ty": 2,
      "x": 922,
      "y": 623
    },
    {
      "t": 61498,
      "e": 61467,
      "ty": 2,
      "x": 920,
      "y": 623
    },
    {
      "t": 61500,
      "e": 61469,
      "ty": 41,
      "x": 23395,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 61598,
      "e": 61567,
      "ty": 2,
      "x": 893,
      "y": 666
    },
    {
      "t": 61697,
      "e": 61666,
      "ty": 2,
      "x": 892,
      "y": 674
    },
    {
      "t": 61748,
      "e": 61717,
      "ty": 41,
      "x": 18950,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 61798,
      "e": 61767,
      "ty": 2,
      "x": 891,
      "y": 676
    },
    {
      "t": 61898,
      "e": 61867,
      "ty": 2,
      "x": 873,
      "y": 687
    },
    {
      "t": 61998,
      "e": 61967,
      "ty": 2,
      "x": 844,
      "y": 697
    },
    {
      "t": 61998,
      "e": 61967,
      "ty": 41,
      "x": 5689,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62048,
      "e": 62017,
      "ty": 6,
      "x": 839,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62097,
      "e": 62066,
      "ty": 2,
      "x": 838,
      "y": 701
    },
    {
      "t": 62198,
      "e": 62167,
      "ty": 2,
      "x": 836,
      "y": 702
    },
    {
      "t": 62248,
      "e": 62217,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62398,
      "e": 62367,
      "ty": 2,
      "x": 834,
      "y": 701
    },
    {
      "t": 62498,
      "e": 62467,
      "ty": 41,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63376,
      "e": 63345,
      "ty": 3,
      "x": 834,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63377,
      "e": 63346,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 63378,
      "e": 63347,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63511,
      "e": 63480,
      "ty": 4,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63512,
      "e": 63481,
      "ty": 5,
      "x": 834,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63512,
      "e": 63481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 63597,
      "e": 63566,
      "ty": 2,
      "x": 834,
      "y": 700
    },
    {
      "t": 63698,
      "e": 63667,
      "ty": 2,
      "x": 837,
      "y": 700
    },
    {
      "t": 63700,
      "e": 63669,
      "ty": 7,
      "x": 849,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63747,
      "e": 63716,
      "ty": 41,
      "x": 18173,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 63798,
      "e": 63767,
      "ty": 2,
      "x": 956,
      "y": 728
    },
    {
      "t": 63897,
      "e": 63866,
      "ty": 2,
      "x": 992,
      "y": 733
    },
    {
      "t": 63997,
      "e": 63966,
      "ty": 41,
      "x": 42812,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64748,
      "e": 64717,
      "ty": 41,
      "x": 43063,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64798,
      "e": 64767,
      "ty": 2,
      "x": 993,
      "y": 733
    },
    {
      "t": 65398,
      "e": 65367,
      "ty": 2,
      "x": 995,
      "y": 738
    },
    {
      "t": 65498,
      "e": 65467,
      "ty": 2,
      "x": 1008,
      "y": 769
    },
    {
      "t": 65498,
      "e": 65467,
      "ty": 41,
      "x": 44279,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 65598,
      "e": 65567,
      "ty": 2,
      "x": 1009,
      "y": 769
    },
    {
      "t": 65748,
      "e": 65717,
      "ty": 41,
      "x": 44516,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 65797,
      "e": 65766,
      "ty": 2,
      "x": 1009,
      "y": 771
    },
    {
      "t": 65998,
      "e": 65967,
      "ty": 41,
      "x": 44516,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 68397,
      "e": 68366,
      "ty": 2,
      "x": 1000,
      "y": 770
    },
    {
      "t": 68497,
      "e": 68466,
      "ty": 2,
      "x": 987,
      "y": 767
    },
    {
      "t": 68498,
      "e": 68467,
      "ty": 41,
      "x": 39295,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 68598,
      "e": 68567,
      "ty": 2,
      "x": 972,
      "y": 762
    },
    {
      "t": 68697,
      "e": 68666,
      "ty": 2,
      "x": 971,
      "y": 761
    },
    {
      "t": 68748,
      "e": 68717,
      "ty": 41,
      "x": 62412,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 69198,
      "e": 69167,
      "ty": 2,
      "x": 970,
      "y": 761
    },
    {
      "t": 69248,
      "e": 69217,
      "ty": 41,
      "x": 58239,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 69298,
      "e": 69267,
      "ty": 2,
      "x": 913,
      "y": 785
    },
    {
      "t": 69398,
      "e": 69367,
      "ty": 2,
      "x": 931,
      "y": 907
    },
    {
      "t": 69497,
      "e": 69466,
      "ty": 2,
      "x": 924,
      "y": 927
    },
    {
      "t": 69498,
      "e": 69467,
      "ty": 41,
      "x": 24344,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 69598,
      "e": 69567,
      "ty": 2,
      "x": 896,
      "y": 942
    },
    {
      "t": 69698,
      "e": 69667,
      "ty": 2,
      "x": 849,
      "y": 943
    },
    {
      "t": 69748,
      "e": 69717,
      "ty": 41,
      "x": 27937,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 69797,
      "e": 69766,
      "ty": 2,
      "x": 847,
      "y": 939
    },
    {
      "t": 69898,
      "e": 69867,
      "ty": 2,
      "x": 843,
      "y": 935
    },
    {
      "t": 69998,
      "e": 69967,
      "ty": 2,
      "x": 842,
      "y": 935
    },
    {
      "t": 69999,
      "e": 69968,
      "ty": 41,
      "x": 22476,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 69999,
      "e": 69968,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70098,
      "e": 70067,
      "ty": 2,
      "x": 841,
      "y": 935
    },
    {
      "t": 70247,
      "e": 70216,
      "ty": 41,
      "x": 20291,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 70264,
      "e": 70233,
      "ty": 6,
      "x": 839,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70298,
      "e": 70267,
      "ty": 2,
      "x": 838,
      "y": 933
    },
    {
      "t": 70397,
      "e": 70366,
      "ty": 2,
      "x": 835,
      "y": 931
    },
    {
      "t": 70497,
      "e": 70466,
      "ty": 2,
      "x": 833,
      "y": 930
    },
    {
      "t": 70497,
      "e": 70466,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70552,
      "e": 70521,
      "ty": 3,
      "x": 833,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70553,
      "e": 70522,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70554,
      "e": 70523,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70703,
      "e": 70672,
      "ty": 4,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70704,
      "e": 70673,
      "ty": 5,
      "x": 833,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70704,
      "e": 70673,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 70747,
      "e": 70716,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70797,
      "e": 70766,
      "ty": 2,
      "x": 833,
      "y": 929
    },
    {
      "t": 70997,
      "e": 70966,
      "ty": 2,
      "x": 835,
      "y": 929
    },
    {
      "t": 70997,
      "e": 70966,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 71055,
      "e": 71024,
      "ty": 7,
      "x": 840,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 71096,
      "e": 71065,
      "ty": 2,
      "x": 846,
      "y": 944
    },
    {
      "t": 71197,
      "e": 71166,
      "ty": 2,
      "x": 866,
      "y": 975
    },
    {
      "t": 71248,
      "e": 71217,
      "ty": 41,
      "x": 55173,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 71297,
      "e": 71266,
      "ty": 2,
      "x": 882,
      "y": 999
    },
    {
      "t": 71322,
      "e": 71291,
      "ty": 6,
      "x": 885,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 71397,
      "e": 71366,
      "ty": 2,
      "x": 888,
      "y": 1010
    },
    {
      "t": 71497,
      "e": 71466,
      "ty": 2,
      "x": 890,
      "y": 1014
    },
    {
      "t": 71497,
      "e": 71466,
      "ty": 41,
      "x": 31221,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 71697,
      "e": 71666,
      "ty": 2,
      "x": 891,
      "y": 1015
    },
    {
      "t": 71747,
      "e": 71716,
      "ty": 41,
      "x": 31736,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72441,
      "e": 72410,
      "ty": 3,
      "x": 891,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72442,
      "e": 72411,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 72442,
      "e": 72411,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72568,
      "e": 72537,
      "ty": 4,
      "x": 31736,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72568,
      "e": 72537,
      "ty": 5,
      "x": 891,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72571,
      "e": 72540,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72571,
      "e": 72540,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 72572,
      "e": 72541,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 72997,
      "e": 72966,
      "ty": 2,
      "x": 891,
      "y": 1013
    },
    {
      "t": 72998,
      "e": 72967,
      "ty": 41,
      "x": 30408,
      "y": 55674,
      "ta": "html > body"
    },
    {
      "t": 73097,
      "e": 73066,
      "ty": 2,
      "x": 891,
      "y": 999
    },
    {
      "t": 73247,
      "e": 73216,
      "ty": 41,
      "x": 30408,
      "y": 54898,
      "ta": "html > body"
    },
    {
      "t": 73907,
      "e": 73876,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 73913,
      "e": 73882,
      "ty": 2,
      "x": 891,
      "y": 996
    },
    {
      "t": 73997,
      "e": 73966,
      "ty": 41,
      "x": 29397,
      "y": 60224,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74497,
      "e": 74466,
      "ty": 2,
      "x": 890,
      "y": 994
    },
    {
      "t": 74497,
      "e": 74466,
      "ty": 41,
      "x": 29348,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74597,
      "e": 74566,
      "ty": 2,
      "x": 886,
      "y": 977
    },
    {
      "t": 74697,
      "e": 74666,
      "ty": 2,
      "x": 866,
      "y": 912
    },
    {
      "t": 74748,
      "e": 74717,
      "ty": 41,
      "x": 28019,
      "y": 24612,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 74797,
      "e": 74766,
      "ty": 2,
      "x": 860,
      "y": 873
    },
    {
      "t": 74897,
      "e": 74866,
      "ty": 2,
      "x": 860,
      "y": 872
    },
    {
      "t": 74998,
      "e": 74967,
      "ty": 41,
      "x": 27872,
      "y": 62236,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 75748,
      "e": 75717,
      "ty": 41,
      "x": 26839,
      "y": 60847,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 75797,
      "e": 75766,
      "ty": 2,
      "x": 733,
      "y": 830
    },
    {
      "t": 75897,
      "e": 75866,
      "ty": 2,
      "x": 549,
      "y": 662
    },
    {
      "t": 75997,
      "e": 75966,
      "ty": 2,
      "x": 458,
      "y": 545
    },
    {
      "t": 75998,
      "e": 75967,
      "ty": 41,
      "x": 8095,
      "y": 24386,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76097,
      "e": 76066,
      "ty": 2,
      "x": 482,
      "y": 474
    },
    {
      "t": 76197,
      "e": 76166,
      "ty": 2,
      "x": 508,
      "y": 456
    },
    {
      "t": 76248,
      "e": 76217,
      "ty": 41,
      "x": 11883,
      "y": 47993,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 76297,
      "e": 76266,
      "ty": 2,
      "x": 539,
      "y": 438
    },
    {
      "t": 76398,
      "e": 76367,
      "ty": 2,
      "x": 562,
      "y": 431
    },
    {
      "t": 76498,
      "e": 76467,
      "ty": 2,
      "x": 568,
      "y": 431
    },
    {
      "t": 76498,
      "e": 76467,
      "ty": 41,
      "x": 13506,
      "y": 39411,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 79995,
      "e": 79964,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140692,
      "e": 81467,
      "ty": 2,
      "x": 516,
      "y": 904
    },
    {
      "t": 140743,
      "e": 81518,
      "ty": 41,
      "x": 16598,
      "y": 61989,
      "ta": "> div.masterdiv"
    },
    {
      "t": 140793,
      "e": 81568,
      "ty": 2,
      "x": 483,
      "y": 1174
    },
    {
      "t": 140892,
      "e": 81667,
      "ty": 2,
      "x": 482,
      "y": 1174
    },
    {
      "t": 140992,
      "e": 81767,
      "ty": 41,
      "x": 16323,
      "y": 64593,
      "ta": "> div.masterdiv"
    },
    {
      "t": 141093,
      "e": 81868,
      "ty": 2,
      "x": 792,
      "y": 1105
    },
    {
      "t": 141192,
      "e": 81967,
      "ty": 2,
      "x": 870,
      "y": 1098
    },
    {
      "t": 141243,
      "e": 82018,
      "ty": 41,
      "x": 29685,
      "y": 60383,
      "ta": "> div.masterdiv"
    },
    {
      "t": 141392,
      "e": 82167,
      "ty": 2,
      "x": 862,
      "y": 1098
    },
    {
      "t": 141492,
      "e": 82267,
      "ty": 2,
      "x": 889,
      "y": 1062
    },
    {
      "t": 141493,
      "e": 82268,
      "ty": 41,
      "x": 29299,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141593,
      "e": 82368,
      "ty": 2,
      "x": 925,
      "y": 1033
    },
    {
      "t": 141692,
      "e": 82467,
      "ty": 2,
      "x": 925,
      "y": 1032
    },
    {
      "t": 141743,
      "e": 82518,
      "ty": 41,
      "x": 31070,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141793,
      "e": 82568,
      "ty": 2,
      "x": 925,
      "y": 1044
    },
    {
      "t": 141854,
      "e": 82629,
      "ty": 6,
      "x": 938,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 141893,
      "e": 82668,
      "ty": 2,
      "x": 939,
      "y": 1077
    },
    {
      "t": 141993,
      "e": 82768,
      "ty": 2,
      "x": 943,
      "y": 1086
    },
    {
      "t": 141993,
      "e": 82768,
      "ty": 41,
      "x": 18295,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 142092,
      "e": 82867,
      "ty": 2,
      "x": 945,
      "y": 1094
    },
    {
      "t": 142242,
      "e": 83017,
      "ty": 41,
      "x": 19387,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 142564,
      "e": 83339,
      "ty": 3,
      "x": 945,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 142565,
      "e": 83340,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 142698,
      "e": 83473,
      "ty": 4,
      "x": 19387,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 142698,
      "e": 83473,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 142699,
      "e": 83474,
      "ty": 5,
      "x": 945,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 142700,
      "e": 83475,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 143748,
      "e": 84523,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 145392,
      "e": 86167,
      "ty": 2,
      "x": 945,
      "y": 1095
    },
    {
      "t": 145492,
      "e": 86267,
      "ty": 2,
      "x": 945,
      "y": 1096
    },
    {
      "t": 145493,
      "e": 86268,
      "ty": 41,
      "x": 32011,
      "y": 32851,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 145693,
      "e": 86468,
      "ty": 2,
      "x": 942,
      "y": 1095
    },
    {
      "t": 145743,
      "e": 86518,
      "ty": 41,
      "x": 31855,
      "y": 32851,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 145793,
      "e": 86568,
      "ty": 2,
      "x": 942,
      "y": 1094
    },
    {
      "t": 145918,
      "e": 86693,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 93470, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 93476, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4894, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 99725, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11144, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MIKE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 111877, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9835, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 122800, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15153, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 138956, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17484, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 157811, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-11 AM-C -C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1070,y:868,t:1527268106012};\\\", \\\"{x:1073,y:863,t:1527268106021};\\\", \\\"{x:1116,y:838,t:1527268106037};\\\", \\\"{x:1182,y:796,t:1527268106054};\\\", \\\"{x:1196,y:749,t:1527268106071};\\\", \\\"{x:1195,y:702,t:1527268106088};\\\", \\\"{x:1120,y:553,t:1527268106104};\\\", \\\"{x:1029,y:441,t:1527268106121};\\\", \\\"{x:921,y:344,t:1527268106137};\\\", \\\"{x:826,y:269,t:1527268106154};\\\", \\\"{x:745,y:210,t:1527268106171};\\\", \\\"{x:665,y:163,t:1527268106188};\\\", \\\"{x:567,y:127,t:1527268106204};\\\", \\\"{x:474,y:106,t:1527268106221};\\\", \\\"{x:401,y:93,t:1527268106238};\\\", \\\"{x:348,y:85,t:1527268106254};\\\", \\\"{x:300,y:78,t:1527268106271};\\\", \\\"{x:230,y:74,t:1527268106288};\\\", \\\"{x:202,y:72,t:1527268106304};\\\", \\\"{x:181,y:69,t:1527268106321};\\\", \\\"{x:171,y:67,t:1527268106338};\\\", \\\"{x:168,y:67,t:1527268106354};\\\", \\\"{x:168,y:66,t:1527268106497};\\\", \\\"{x:172,y:64,t:1527268106504};\\\", \\\"{x:242,y:49,t:1527268106522};\\\", \\\"{x:360,y:37,t:1527268106539};\\\", \\\"{x:466,y:35,t:1527268106555};\\\", \\\"{x:524,y:46,t:1527268106572};\\\", \\\"{x:537,y:61,t:1527268106588};\\\", \\\"{x:547,y:79,t:1527268106604};\\\", \\\"{x:554,y:91,t:1527268106621};\\\", \\\"{x:558,y:98,t:1527268106638};\\\", \\\"{x:560,y:104,t:1527268106655};\\\", \\\"{x:560,y:106,t:1527268106671};\\\", \\\"{x:560,y:115,t:1527268106687};\\\", \\\"{x:564,y:130,t:1527268106704};\\\", \\\"{x:568,y:147,t:1527268106721};\\\", \\\"{x:574,y:163,t:1527268106738};\\\", \\\"{x:578,y:178,t:1527268106756};\\\", \\\"{x:582,y:206,t:1527268106772};\\\", \\\"{x:592,y:245,t:1527268106788};\\\", \\\"{x:607,y:303,t:1527268106805};\\\", \\\"{x:623,y:361,t:1527268106821};\\\", \\\"{x:647,y:421,t:1527268106838};\\\", \\\"{x:661,y:454,t:1527268106855};\\\", \\\"{x:670,y:477,t:1527268106872};\\\", \\\"{x:673,y:489,t:1527268106888};\\\", \\\"{x:676,y:492,t:1527268106906};\\\", \\\"{x:674,y:492,t:1527268107137};\\\", \\\"{x:671,y:492,t:1527268107144};\\\", \\\"{x:668,y:492,t:1527268107155};\\\", \\\"{x:661,y:492,t:1527268107172};\\\", \\\"{x:654,y:492,t:1527268107189};\\\", \\\"{x:649,y:492,t:1527268107205};\\\", \\\"{x:647,y:492,t:1527268107223};\\\", \\\"{x:646,y:493,t:1527268107238};\\\", \\\"{x:645,y:493,t:1527268107255};\\\", \\\"{x:642,y:495,t:1527268107271};\\\", \\\"{x:639,y:495,t:1527268107288};\\\", \\\"{x:637,y:496,t:1527268107305};\\\", \\\"{x:636,y:496,t:1527268107322};\\\", \\\"{x:635,y:496,t:1527268107344};\\\", \\\"{x:634,y:496,t:1527268107553};\\\", \\\"{x:632,y:497,t:1527268107561};\\\", \\\"{x:632,y:498,t:1527268107585};\\\", \\\"{x:633,y:498,t:1527268107657};\\\", \\\"{x:637,y:498,t:1527268107673};\\\", \\\"{x:649,y:498,t:1527268107690};\\\", \\\"{x:664,y:498,t:1527268107706};\\\", \\\"{x:686,y:496,t:1527268107722};\\\", \\\"{x:710,y:496,t:1527268107740};\\\", \\\"{x:737,y:496,t:1527268107756};\\\", \\\"{x:759,y:497,t:1527268107773};\\\", \\\"{x:774,y:499,t:1527268107790};\\\", \\\"{x:780,y:502,t:1527268107806};\\\", \\\"{x:783,y:503,t:1527268107823};\\\", \\\"{x:785,y:503,t:1527268107874};\\\", \\\"{x:790,y:503,t:1527268107889};\\\", \\\"{x:798,y:503,t:1527268107906};\\\", \\\"{x:812,y:503,t:1527268107923};\\\", \\\"{x:830,y:503,t:1527268107940};\\\", \\\"{x:852,y:506,t:1527268107957};\\\", \\\"{x:874,y:509,t:1527268107972};\\\", \\\"{x:895,y:512,t:1527268107989};\\\", \\\"{x:917,y:517,t:1527268108006};\\\", \\\"{x:932,y:520,t:1527268108022};\\\", \\\"{x:946,y:525,t:1527268108040};\\\", \\\"{x:959,y:532,t:1527268108055};\\\", \\\"{x:968,y:540,t:1527268108072};\\\", \\\"{x:974,y:545,t:1527268108089};\\\", \\\"{x:983,y:553,t:1527268108106};\\\", \\\"{x:993,y:560,t:1527268108122};\\\", \\\"{x:1004,y:566,t:1527268108139};\\\", \\\"{x:1014,y:572,t:1527268108157};\\\", \\\"{x:1025,y:577,t:1527268108172};\\\", \\\"{x:1041,y:583,t:1527268108189};\\\", \\\"{x:1061,y:594,t:1527268108206};\\\", \\\"{x:1077,y:604,t:1527268108223};\\\", \\\"{x:1089,y:610,t:1527268108239};\\\", \\\"{x:1102,y:617,t:1527268108255};\\\", \\\"{x:1109,y:623,t:1527268108273};\\\", \\\"{x:1120,y:630,t:1527268108290};\\\", \\\"{x:1132,y:640,t:1527268108307};\\\", \\\"{x:1147,y:654,t:1527268108323};\\\", \\\"{x:1163,y:666,t:1527268108339};\\\", \\\"{x:1181,y:681,t:1527268108357};\\\", \\\"{x:1198,y:693,t:1527268108373};\\\", \\\"{x:1215,y:705,t:1527268108389};\\\", \\\"{x:1230,y:720,t:1527268108407};\\\", \\\"{x:1246,y:737,t:1527268108424};\\\", \\\"{x:1259,y:747,t:1527268108440};\\\", \\\"{x:1263,y:751,t:1527268108457};\\\", \\\"{x:1264,y:751,t:1527268108474};\\\", \\\"{x:1265,y:753,t:1527268108490};\\\", \\\"{x:1267,y:754,t:1527268108507};\\\", \\\"{x:1268,y:760,t:1527268108523};\\\", \\\"{x:1270,y:764,t:1527268108540};\\\", \\\"{x:1274,y:772,t:1527268108557};\\\", \\\"{x:1276,y:777,t:1527268108574};\\\", \\\"{x:1277,y:780,t:1527268108590};\\\", \\\"{x:1279,y:784,t:1527268108607};\\\", \\\"{x:1281,y:787,t:1527268108625};\\\", \\\"{x:1284,y:790,t:1527268108640};\\\", \\\"{x:1290,y:796,t:1527268108657};\\\", \\\"{x:1294,y:801,t:1527268108674};\\\", \\\"{x:1300,y:808,t:1527268108690};\\\", \\\"{x:1308,y:818,t:1527268108707};\\\", \\\"{x:1320,y:825,t:1527268108724};\\\", \\\"{x:1335,y:833,t:1527268108740};\\\", \\\"{x:1347,y:838,t:1527268108757};\\\", \\\"{x:1358,y:842,t:1527268108774};\\\", \\\"{x:1362,y:843,t:1527268108791};\\\", \\\"{x:1363,y:843,t:1527268108807};\\\", \\\"{x:1364,y:843,t:1527268108824};\\\", \\\"{x:1363,y:843,t:1527268108961};\\\", \\\"{x:1361,y:843,t:1527268108974};\\\", \\\"{x:1355,y:844,t:1527268108992};\\\", \\\"{x:1347,y:846,t:1527268109008};\\\", \\\"{x:1343,y:848,t:1527268109025};\\\", \\\"{x:1338,y:851,t:1527268109041};\\\", \\\"{x:1336,y:854,t:1527268109065};\\\", \\\"{x:1336,y:855,t:1527268109081};\\\", \\\"{x:1335,y:856,t:1527268109091};\\\", \\\"{x:1334,y:858,t:1527268109107};\\\", \\\"{x:1333,y:860,t:1527268109124};\\\", \\\"{x:1332,y:860,t:1527268109141};\\\", \\\"{x:1332,y:861,t:1527268109157};\\\", \\\"{x:1331,y:862,t:1527268109174};\\\", \\\"{x:1329,y:863,t:1527268109193};\\\", \\\"{x:1324,y:863,t:1527268109209};\\\", \\\"{x:1312,y:863,t:1527268109224};\\\", \\\"{x:1293,y:863,t:1527268109241};\\\", \\\"{x:1268,y:859,t:1527268109258};\\\", \\\"{x:1241,y:856,t:1527268109273};\\\", \\\"{x:1202,y:850,t:1527268109291};\\\", \\\"{x:1152,y:842,t:1527268109307};\\\", \\\"{x:1093,y:825,t:1527268109324};\\\", \\\"{x:1024,y:808,t:1527268109341};\\\", \\\"{x:977,y:794,t:1527268109358};\\\", \\\"{x:939,y:781,t:1527268109374};\\\", \\\"{x:914,y:775,t:1527268109390};\\\", \\\"{x:887,y:764,t:1527268109407};\\\", \\\"{x:870,y:756,t:1527268109423};\\\", \\\"{x:848,y:745,t:1527268109440};\\\", \\\"{x:832,y:736,t:1527268109457};\\\", \\\"{x:817,y:728,t:1527268109474};\\\", \\\"{x:802,y:719,t:1527268109491};\\\", \\\"{x:788,y:709,t:1527268109507};\\\", \\\"{x:777,y:700,t:1527268109523};\\\", \\\"{x:769,y:691,t:1527268109540};\\\", \\\"{x:764,y:683,t:1527268109557};\\\", \\\"{x:762,y:678,t:1527268109574};\\\", \\\"{x:761,y:675,t:1527268109590};\\\", \\\"{x:760,y:674,t:1527268109608};\\\", \\\"{x:758,y:671,t:1527268109624};\\\", \\\"{x:758,y:670,t:1527268109641};\\\", \\\"{x:757,y:670,t:1527268109657};\\\", \\\"{x:755,y:668,t:1527268109674};\\\", \\\"{x:757,y:667,t:1527268109721};\\\", \\\"{x:764,y:667,t:1527268109728};\\\", \\\"{x:775,y:667,t:1527268109741};\\\", \\\"{x:803,y:671,t:1527268109758};\\\", \\\"{x:863,y:695,t:1527268109775};\\\", \\\"{x:966,y:745,t:1527268109790};\\\", \\\"{x:1089,y:816,t:1527268109808};\\\", \\\"{x:1250,y:904,t:1527268109825};\\\", \\\"{x:1303,y:940,t:1527268109841};\\\", \\\"{x:1342,y:965,t:1527268109858};\\\", \\\"{x:1365,y:982,t:1527268109875};\\\", \\\"{x:1376,y:990,t:1527268109892};\\\", \\\"{x:1379,y:993,t:1527268109908};\\\", \\\"{x:1378,y:993,t:1527268110065};\\\", \\\"{x:1377,y:992,t:1527268110075};\\\", \\\"{x:1372,y:989,t:1527268110093};\\\", \\\"{x:1357,y:984,t:1527268110108};\\\", \\\"{x:1334,y:975,t:1527268110126};\\\", \\\"{x:1312,y:969,t:1527268110143};\\\", \\\"{x:1293,y:965,t:1527268110158};\\\", \\\"{x:1281,y:964,t:1527268110174};\\\", \\\"{x:1278,y:963,t:1527268110191};\\\", \\\"{x:1277,y:963,t:1527268110207};\\\", \\\"{x:1277,y:964,t:1527268110392};\\\", \\\"{x:1277,y:966,t:1527268110409};\\\", \\\"{x:1278,y:968,t:1527268110425};\\\", \\\"{x:1278,y:969,t:1527268110489};\\\", \\\"{x:1278,y:968,t:1527268110714};\\\", \\\"{x:1278,y:967,t:1527268110785};\\\", \\\"{x:1278,y:966,t:1527268110800};\\\", \\\"{x:1278,y:965,t:1527268110812};\\\", \\\"{x:1279,y:964,t:1527268110825};\\\", \\\"{x:1279,y:963,t:1527268110841};\\\", \\\"{x:1279,y:962,t:1527268110872};\\\", \\\"{x:1279,y:961,t:1527268110888};\\\", \\\"{x:1279,y:960,t:1527268110920};\\\", \\\"{x:1280,y:959,t:1527268110936};\\\", \\\"{x:1280,y:958,t:1527268110976};\\\", \\\"{x:1280,y:957,t:1527268111009};\\\", \\\"{x:1280,y:955,t:1527268111026};\\\", \\\"{x:1280,y:952,t:1527268111042};\\\", \\\"{x:1280,y:948,t:1527268111059};\\\", \\\"{x:1280,y:941,t:1527268111076};\\\", \\\"{x:1280,y:932,t:1527268111092};\\\", \\\"{x:1280,y:923,t:1527268111109};\\\", \\\"{x:1280,y:918,t:1527268111126};\\\", \\\"{x:1280,y:912,t:1527268111142};\\\", \\\"{x:1280,y:906,t:1527268111159};\\\", \\\"{x:1279,y:900,t:1527268111176};\\\", \\\"{x:1279,y:899,t:1527268111192};\\\", \\\"{x:1278,y:896,t:1527268111210};\\\", \\\"{x:1277,y:894,t:1527268111226};\\\", \\\"{x:1276,y:890,t:1527268111242};\\\", \\\"{x:1275,y:886,t:1527268111259};\\\", \\\"{x:1274,y:882,t:1527268111275};\\\", \\\"{x:1274,y:879,t:1527268111291};\\\", \\\"{x:1273,y:876,t:1527268111309};\\\", \\\"{x:1273,y:874,t:1527268111326};\\\", \\\"{x:1273,y:873,t:1527268111342};\\\", \\\"{x:1273,y:870,t:1527268111358};\\\", \\\"{x:1273,y:867,t:1527268111376};\\\", \\\"{x:1273,y:863,t:1527268111392};\\\", \\\"{x:1273,y:861,t:1527268111408};\\\", \\\"{x:1273,y:860,t:1527268111425};\\\", \\\"{x:1273,y:858,t:1527268111442};\\\", \\\"{x:1272,y:856,t:1527268111458};\\\", \\\"{x:1272,y:855,t:1527268111476};\\\", \\\"{x:1272,y:852,t:1527268111493};\\\", \\\"{x:1272,y:850,t:1527268111508};\\\", \\\"{x:1272,y:848,t:1527268111525};\\\", \\\"{x:1272,y:845,t:1527268111542};\\\", \\\"{x:1272,y:844,t:1527268111559};\\\", \\\"{x:1272,y:839,t:1527268111575};\\\", \\\"{x:1272,y:838,t:1527268111592};\\\", \\\"{x:1272,y:835,t:1527268111609};\\\", \\\"{x:1272,y:834,t:1527268111640};\\\", \\\"{x:1271,y:834,t:1527268112088};\\\", \\\"{x:1269,y:834,t:1527268112095};\\\", \\\"{x:1267,y:834,t:1527268112109};\\\", \\\"{x:1261,y:834,t:1527268112125};\\\", \\\"{x:1255,y:834,t:1527268112143};\\\", \\\"{x:1237,y:834,t:1527268112159};\\\", \\\"{x:1211,y:834,t:1527268112176};\\\", \\\"{x:1159,y:834,t:1527268112193};\\\", \\\"{x:1048,y:834,t:1527268112209};\\\", \\\"{x:904,y:812,t:1527268112226};\\\", \\\"{x:761,y:793,t:1527268112242};\\\", \\\"{x:635,y:770,t:1527268112259};\\\", \\\"{x:528,y:744,t:1527268112276};\\\", \\\"{x:425,y:711,t:1527268112292};\\\", \\\"{x:339,y:674,t:1527268112309};\\\", \\\"{x:273,y:646,t:1527268112326};\\\", \\\"{x:226,y:625,t:1527268112344};\\\", \\\"{x:181,y:610,t:1527268112360};\\\", \\\"{x:166,y:606,t:1527268112377};\\\", \\\"{x:157,y:601,t:1527268112393};\\\", \\\"{x:148,y:598,t:1527268112410};\\\", \\\"{x:141,y:596,t:1527268112426};\\\", \\\"{x:131,y:592,t:1527268112443};\\\", \\\"{x:123,y:589,t:1527268112460};\\\", \\\"{x:115,y:584,t:1527268112476};\\\", \\\"{x:112,y:580,t:1527268112492};\\\", \\\"{x:108,y:573,t:1527268112510};\\\", \\\"{x:107,y:565,t:1527268112526};\\\", \\\"{x:107,y:558,t:1527268112544};\\\", \\\"{x:107,y:556,t:1527268112559};\\\", \\\"{x:107,y:555,t:1527268112576};\\\", \\\"{x:107,y:554,t:1527268112594};\\\", \\\"{x:108,y:553,t:1527268112609};\\\", \\\"{x:113,y:553,t:1527268112626};\\\", \\\"{x:132,y:553,t:1527268112644};\\\", \\\"{x:165,y:556,t:1527268112660};\\\", \\\"{x:217,y:562,t:1527268112677};\\\", \\\"{x:263,y:570,t:1527268112693};\\\", \\\"{x:297,y:575,t:1527268112710};\\\", \\\"{x:317,y:576,t:1527268112726};\\\", \\\"{x:334,y:575,t:1527268112744};\\\", \\\"{x:337,y:573,t:1527268112760};\\\", \\\"{x:338,y:572,t:1527268112776};\\\", \\\"{x:338,y:571,t:1527268112799};\\\", \\\"{x:339,y:571,t:1527268112810};\\\", \\\"{x:340,y:569,t:1527268112826};\\\", \\\"{x:341,y:568,t:1527268112844};\\\", \\\"{x:343,y:567,t:1527268112860};\\\", \\\"{x:344,y:565,t:1527268112877};\\\", \\\"{x:346,y:562,t:1527268112894};\\\", \\\"{x:350,y:560,t:1527268112909};\\\", \\\"{x:354,y:559,t:1527268112927};\\\", \\\"{x:357,y:556,t:1527268112944};\\\", \\\"{x:360,y:553,t:1527268112959};\\\", \\\"{x:361,y:552,t:1527268112976};\\\", \\\"{x:363,y:550,t:1527268112994};\\\", \\\"{x:367,y:545,t:1527268113009};\\\", \\\"{x:369,y:540,t:1527268113028};\\\", \\\"{x:372,y:537,t:1527268113043};\\\", \\\"{x:373,y:534,t:1527268113060};\\\", \\\"{x:375,y:532,t:1527268113076};\\\", \\\"{x:377,y:529,t:1527268113093};\\\", \\\"{x:379,y:527,t:1527268113111};\\\", \\\"{x:380,y:525,t:1527268113127};\\\", \\\"{x:382,y:525,t:1527268113144};\\\", \\\"{x:383,y:525,t:1527268113208};\\\", \\\"{x:384,y:525,t:1527268113215};\\\", \\\"{x:385,y:524,t:1527268113272};\\\", \\\"{x:387,y:525,t:1527268116504};\\\", \\\"{x:388,y:526,t:1527268116513};\\\", \\\"{x:390,y:526,t:1527268116529};\\\", \\\"{x:394,y:526,t:1527268116545};\\\", \\\"{x:397,y:527,t:1527268116563};\\\", \\\"{x:401,y:527,t:1527268116580};\\\", \\\"{x:405,y:527,t:1527268116596};\\\", \\\"{x:409,y:527,t:1527268116612};\\\", \\\"{x:415,y:527,t:1527268116629};\\\", \\\"{x:419,y:527,t:1527268116647};\\\", \\\"{x:423,y:527,t:1527268116663};\\\", \\\"{x:426,y:527,t:1527268116680};\\\", \\\"{x:428,y:528,t:1527268116696};\\\", \\\"{x:433,y:529,t:1527268116712};\\\", \\\"{x:438,y:530,t:1527268116729};\\\", \\\"{x:447,y:531,t:1527268116745};\\\", \\\"{x:453,y:532,t:1527268116762};\\\", \\\"{x:461,y:533,t:1527268116780};\\\", \\\"{x:469,y:534,t:1527268116795};\\\", \\\"{x:474,y:534,t:1527268116812};\\\", \\\"{x:478,y:535,t:1527268116830};\\\", \\\"{x:482,y:536,t:1527268116846};\\\", \\\"{x:484,y:536,t:1527268116863};\\\", \\\"{x:486,y:537,t:1527268116880};\\\", \\\"{x:488,y:537,t:1527268116896};\\\", \\\"{x:489,y:538,t:1527268116912};\\\", \\\"{x:491,y:538,t:1527268116929};\\\", \\\"{x:494,y:539,t:1527268116945};\\\", \\\"{x:496,y:540,t:1527268116963};\\\", \\\"{x:497,y:540,t:1527268116980};\\\", \\\"{x:500,y:540,t:1527268116995};\\\", \\\"{x:504,y:540,t:1527268117012};\\\", \\\"{x:505,y:540,t:1527268117029};\\\", \\\"{x:509,y:540,t:1527268117046};\\\", \\\"{x:514,y:535,t:1527268117064};\\\", \\\"{x:522,y:530,t:1527268117080};\\\", \\\"{x:528,y:528,t:1527268117097};\\\", \\\"{x:539,y:527,t:1527268117113};\\\", \\\"{x:560,y:523,t:1527268117130};\\\", \\\"{x:586,y:523,t:1527268117146};\\\", \\\"{x:622,y:523,t:1527268117164};\\\", \\\"{x:667,y:523,t:1527268117180};\\\", \\\"{x:720,y:523,t:1527268117197};\\\", \\\"{x:777,y:526,t:1527268117214};\\\", \\\"{x:828,y:533,t:1527268117229};\\\", \\\"{x:881,y:541,t:1527268117247};\\\", \\\"{x:946,y:554,t:1527268117264};\\\", \\\"{x:990,y:566,t:1527268117280};\\\", \\\"{x:1030,y:580,t:1527268117296};\\\", \\\"{x:1065,y:598,t:1527268117313};\\\", \\\"{x:1091,y:615,t:1527268117329};\\\", \\\"{x:1109,y:629,t:1527268117347};\\\", \\\"{x:1124,y:646,t:1527268117363};\\\", \\\"{x:1130,y:659,t:1527268117379};\\\", \\\"{x:1135,y:671,t:1527268117397};\\\", \\\"{x:1139,y:684,t:1527268117414};\\\", \\\"{x:1143,y:698,t:1527268117430};\\\", \\\"{x:1146,y:714,t:1527268117447};\\\", \\\"{x:1157,y:740,t:1527268117464};\\\", \\\"{x:1167,y:761,t:1527268117479};\\\", \\\"{x:1179,y:784,t:1527268117497};\\\", \\\"{x:1194,y:806,t:1527268117514};\\\", \\\"{x:1207,y:821,t:1527268117530};\\\", \\\"{x:1216,y:831,t:1527268117547};\\\", \\\"{x:1220,y:834,t:1527268117564};\\\", \\\"{x:1221,y:835,t:1527268117580};\\\", \\\"{x:1222,y:836,t:1527268117608};\\\", \\\"{x:1222,y:837,t:1527268117616};\\\", \\\"{x:1222,y:838,t:1527268117630};\\\", \\\"{x:1225,y:843,t:1527268117647};\\\", \\\"{x:1228,y:850,t:1527268117663};\\\", \\\"{x:1235,y:859,t:1527268117680};\\\", \\\"{x:1239,y:863,t:1527268117696};\\\", \\\"{x:1243,y:866,t:1527268117713};\\\", \\\"{x:1248,y:868,t:1527268117730};\\\", \\\"{x:1252,y:871,t:1527268117746};\\\", \\\"{x:1253,y:871,t:1527268117776};\\\", \\\"{x:1254,y:872,t:1527268117815};\\\", \\\"{x:1255,y:873,t:1527268117830};\\\", \\\"{x:1257,y:877,t:1527268117847};\\\", \\\"{x:1261,y:881,t:1527268117862};\\\", \\\"{x:1270,y:900,t:1527268117880};\\\", \\\"{x:1276,y:909,t:1527268117897};\\\", \\\"{x:1279,y:917,t:1527268117912};\\\", \\\"{x:1280,y:921,t:1527268117930};\\\", \\\"{x:1281,y:923,t:1527268117947};\\\", \\\"{x:1282,y:925,t:1527268117963};\\\", \\\"{x:1282,y:926,t:1527268117980};\\\", \\\"{x:1283,y:926,t:1527268117996};\\\", \\\"{x:1283,y:928,t:1527268118013};\\\", \\\"{x:1284,y:931,t:1527268118030};\\\", \\\"{x:1286,y:932,t:1527268118047};\\\", \\\"{x:1286,y:933,t:1527268118063};\\\", \\\"{x:1286,y:934,t:1527268118079};\\\", \\\"{x:1286,y:935,t:1527268118120};\\\", \\\"{x:1286,y:936,t:1527268118130};\\\", \\\"{x:1286,y:937,t:1527268118146};\\\", \\\"{x:1286,y:940,t:1527268118163};\\\", \\\"{x:1286,y:941,t:1527268118180};\\\", \\\"{x:1286,y:940,t:1527268118279};\\\", \\\"{x:1286,y:928,t:1527268118296};\\\", \\\"{x:1286,y:914,t:1527268118313};\\\", \\\"{x:1286,y:905,t:1527268118330};\\\", \\\"{x:1286,y:893,t:1527268118346};\\\", \\\"{x:1286,y:887,t:1527268118363};\\\", \\\"{x:1286,y:883,t:1527268118380};\\\", \\\"{x:1286,y:877,t:1527268118396};\\\", \\\"{x:1286,y:872,t:1527268118412};\\\", \\\"{x:1286,y:869,t:1527268118430};\\\", \\\"{x:1285,y:865,t:1527268118445};\\\", \\\"{x:1283,y:861,t:1527268118463};\\\", \\\"{x:1281,y:853,t:1527268118479};\\\", \\\"{x:1281,y:849,t:1527268118495};\\\", \\\"{x:1280,y:845,t:1527268118513};\\\", \\\"{x:1280,y:842,t:1527268118530};\\\", \\\"{x:1279,y:840,t:1527268118545};\\\", \\\"{x:1279,y:839,t:1527268118563};\\\", \\\"{x:1279,y:837,t:1527268118591};\\\", \\\"{x:1278,y:836,t:1527268118616};\\\", \\\"{x:1278,y:834,t:1527268118640};\\\", \\\"{x:1278,y:832,t:1527268118671};\\\", \\\"{x:1278,y:831,t:1527268118695};\\\", \\\"{x:1278,y:830,t:1527268118720};\\\", \\\"{x:1278,y:829,t:1527268118729};\\\", \\\"{x:1278,y:828,t:1527268118746};\\\", \\\"{x:1278,y:827,t:1527268118952};\\\", \\\"{x:1278,y:826,t:1527268118984};\\\", \\\"{x:1278,y:825,t:1527268119063};\\\", \\\"{x:1278,y:824,t:1527268119336};\\\", \\\"{x:1278,y:823,t:1527268119346};\\\", \\\"{x:1278,y:822,t:1527268119361};\\\", \\\"{x:1278,y:820,t:1527268119378};\\\", \\\"{x:1278,y:819,t:1527268119396};\\\", \\\"{x:1278,y:818,t:1527268119416};\\\", \\\"{x:1278,y:817,t:1527268119432};\\\", \\\"{x:1278,y:816,t:1527268119445};\\\", \\\"{x:1278,y:815,t:1527268119471};\\\", \\\"{x:1278,y:814,t:1527268119616};\\\", \\\"{x:1278,y:813,t:1527268119628};\\\", \\\"{x:1278,y:809,t:1527268119645};\\\", \\\"{x:1278,y:804,t:1527268119662};\\\", \\\"{x:1278,y:797,t:1527268119679};\\\", \\\"{x:1278,y:789,t:1527268119695};\\\", \\\"{x:1278,y:781,t:1527268119712};\\\", \\\"{x:1278,y:777,t:1527268119728};\\\", \\\"{x:1278,y:775,t:1527268119745};\\\", \\\"{x:1278,y:774,t:1527268119762};\\\", \\\"{x:1278,y:772,t:1527268119779};\\\", \\\"{x:1278,y:771,t:1527268119795};\\\", \\\"{x:1277,y:769,t:1527268119839};\\\", \\\"{x:1277,y:768,t:1527268119864};\\\", \\\"{x:1277,y:766,t:1527268119879};\\\", \\\"{x:1277,y:765,t:1527268119895};\\\", \\\"{x:1277,y:762,t:1527268119911};\\\", \\\"{x:1277,y:759,t:1527268119929};\\\", \\\"{x:1277,y:755,t:1527268119945};\\\", \\\"{x:1276,y:749,t:1527268119962};\\\", \\\"{x:1275,y:739,t:1527268119979};\\\", \\\"{x:1274,y:727,t:1527268119995};\\\", \\\"{x:1273,y:717,t:1527268120011};\\\", \\\"{x:1271,y:708,t:1527268120028};\\\", \\\"{x:1269,y:698,t:1527268120045};\\\", \\\"{x:1269,y:693,t:1527268120061};\\\", \\\"{x:1268,y:689,t:1527268120079};\\\", \\\"{x:1267,y:683,t:1527268120095};\\\", \\\"{x:1267,y:678,t:1527268120112};\\\", \\\"{x:1267,y:675,t:1527268120128};\\\", \\\"{x:1266,y:671,t:1527268120145};\\\", \\\"{x:1266,y:669,t:1527268120162};\\\", \\\"{x:1265,y:667,t:1527268120177};\\\", \\\"{x:1265,y:666,t:1527268120194};\\\", \\\"{x:1265,y:665,t:1527268120255};\\\", \\\"{x:1264,y:665,t:1527268120343};\\\", \\\"{x:1261,y:666,t:1527268120352};\\\", \\\"{x:1258,y:669,t:1527268120362};\\\", \\\"{x:1250,y:675,t:1527268120378};\\\", \\\"{x:1234,y:685,t:1527268120395};\\\", \\\"{x:1212,y:698,t:1527268120412};\\\", \\\"{x:1183,y:715,t:1527268120428};\\\", \\\"{x:1152,y:729,t:1527268120444};\\\", \\\"{x:1116,y:744,t:1527268120462};\\\", \\\"{x:1080,y:759,t:1527268120478};\\\", \\\"{x:1044,y:769,t:1527268120494};\\\", \\\"{x:1020,y:774,t:1527268120510};\\\", \\\"{x:988,y:780,t:1527268120527};\\\", \\\"{x:971,y:780,t:1527268120545};\\\", \\\"{x:950,y:780,t:1527268120562};\\\", \\\"{x:930,y:780,t:1527268120578};\\\", \\\"{x:901,y:780,t:1527268120594};\\\", \\\"{x:881,y:780,t:1527268120610};\\\", \\\"{x:860,y:776,t:1527268120627};\\\", \\\"{x:843,y:770,t:1527268120645};\\\", \\\"{x:829,y:763,t:1527268120661};\\\", \\\"{x:818,y:755,t:1527268120677};\\\", \\\"{x:811,y:748,t:1527268120695};\\\", \\\"{x:801,y:741,t:1527268120711};\\\", \\\"{x:785,y:733,t:1527268120728};\\\", \\\"{x:768,y:729,t:1527268120745};\\\", \\\"{x:746,y:728,t:1527268120760};\\\", \\\"{x:720,y:728,t:1527268120778};\\\", \\\"{x:694,y:728,t:1527268120795};\\\", \\\"{x:670,y:728,t:1527268120811};\\\", \\\"{x:652,y:728,t:1527268120827};\\\", \\\"{x:640,y:728,t:1527268120844};\\\", \\\"{x:630,y:728,t:1527268120861};\\\", \\\"{x:623,y:728,t:1527268120878};\\\", \\\"{x:614,y:728,t:1527268120895};\\\", \\\"{x:605,y:728,t:1527268120910};\\\", \\\"{x:591,y:728,t:1527268120928};\\\", \\\"{x:582,y:728,t:1527268120945};\\\", \\\"{x:578,y:727,t:1527268120961};\\\", \\\"{x:573,y:726,t:1527268120978};\\\", \\\"{x:569,y:726,t:1527268120995};\\\", \\\"{x:563,y:725,t:1527268121011};\\\", \\\"{x:558,y:724,t:1527268121028};\\\", \\\"{x:556,y:724,t:1527268121044};\\\", \\\"{x:555,y:724,t:1527268121087};\\\", \\\"{x:553,y:724,t:1527268121168};\\\", \\\"{x:552,y:724,t:1527268121192};\\\", \\\"{x:550,y:724,t:1527268121207};\\\", \\\"{x:549,y:724,t:1527268121215};\\\", \\\"{x:546,y:724,t:1527268121227};\\\", \\\"{x:542,y:724,t:1527268121244};\\\", \\\"{x:539,y:724,t:1527268121261};\\\", \\\"{x:538,y:724,t:1527268121277};\\\", \\\"{x:538,y:723,t:1527268121408};\\\" ] }, { \\\"rt\\\": 18514, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 177570, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:724,t:1527268123880};\\\", \\\"{x:538,y:725,t:1527268123903};\\\", \\\"{x:538,y:722,t:1527268124096};\\\", \\\"{x:538,y:719,t:1527268124104};\\\", \\\"{x:541,y:715,t:1527268124119};\\\", \\\"{x:548,y:703,t:1527268124136};\\\", \\\"{x:553,y:690,t:1527268124153};\\\", \\\"{x:558,y:674,t:1527268124169};\\\", \\\"{x:564,y:656,t:1527268124187};\\\", \\\"{x:569,y:636,t:1527268124204};\\\", \\\"{x:575,y:620,t:1527268124219};\\\", \\\"{x:576,y:610,t:1527268124237};\\\", \\\"{x:580,y:597,t:1527268124251};\\\", \\\"{x:583,y:590,t:1527268124269};\\\", \\\"{x:584,y:588,t:1527268124286};\\\", \\\"{x:584,y:585,t:1527268124302};\\\", \\\"{x:585,y:585,t:1527268124319};\\\", \\\"{x:586,y:583,t:1527268124335};\\\", \\\"{x:587,y:582,t:1527268124352};\\\", \\\"{x:587,y:579,t:1527268124370};\\\", \\\"{x:590,y:574,t:1527268124386};\\\", \\\"{x:591,y:567,t:1527268124403};\\\", \\\"{x:595,y:560,t:1527268124419};\\\", \\\"{x:600,y:553,t:1527268124436};\\\", \\\"{x:607,y:542,t:1527268124453};\\\", \\\"{x:613,y:535,t:1527268124470};\\\", \\\"{x:617,y:529,t:1527268124486};\\\", \\\"{x:626,y:522,t:1527268124504};\\\", \\\"{x:632,y:514,t:1527268124519};\\\", \\\"{x:643,y:508,t:1527268124536};\\\", \\\"{x:645,y:507,t:1527268124553};\\\", \\\"{x:647,y:506,t:1527268124569};\\\", \\\"{x:645,y:506,t:1527268124809};\\\", \\\"{x:636,y:506,t:1527268124820};\\\", \\\"{x:605,y:511,t:1527268124839};\\\", \\\"{x:571,y:516,t:1527268124853};\\\", \\\"{x:532,y:516,t:1527268124869};\\\", \\\"{x:503,y:516,t:1527268124886};\\\", \\\"{x:481,y:516,t:1527268124903};\\\", \\\"{x:463,y:513,t:1527268124919};\\\", \\\"{x:455,y:509,t:1527268124935};\\\", \\\"{x:449,y:506,t:1527268124953};\\\", \\\"{x:445,y:505,t:1527268124970};\\\", \\\"{x:442,y:505,t:1527268124987};\\\", \\\"{x:439,y:505,t:1527268125002};\\\", \\\"{x:437,y:505,t:1527268125020};\\\", \\\"{x:435,y:505,t:1527268125036};\\\", \\\"{x:431,y:503,t:1527268125053};\\\", \\\"{x:429,y:502,t:1527268125070};\\\", \\\"{x:427,y:502,t:1527268125086};\\\", \\\"{x:426,y:501,t:1527268125103};\\\", \\\"{x:425,y:499,t:1527268125120};\\\", \\\"{x:425,y:494,t:1527268125136};\\\", \\\"{x:425,y:490,t:1527268125153};\\\", \\\"{x:425,y:485,t:1527268125170};\\\", \\\"{x:425,y:481,t:1527268125187};\\\", \\\"{x:426,y:478,t:1527268125203};\\\", \\\"{x:428,y:474,t:1527268125221};\\\", \\\"{x:429,y:473,t:1527268125236};\\\", \\\"{x:431,y:472,t:1527268125253};\\\", \\\"{x:434,y:472,t:1527268125270};\\\", \\\"{x:439,y:472,t:1527268125288};\\\", \\\"{x:445,y:472,t:1527268125303};\\\", \\\"{x:456,y:475,t:1527268125320};\\\", \\\"{x:460,y:476,t:1527268125337};\\\", \\\"{x:464,y:476,t:1527268125353};\\\", \\\"{x:467,y:476,t:1527268125370};\\\", \\\"{x:469,y:476,t:1527268125387};\\\", \\\"{x:470,y:476,t:1527268125404};\\\", \\\"{x:472,y:476,t:1527268125424};\\\", \\\"{x:473,y:476,t:1527268125448};\\\", \\\"{x:474,y:476,t:1527268125472};\\\", \\\"{x:476,y:476,t:1527268125487};\\\", \\\"{x:481,y:476,t:1527268125503};\\\", \\\"{x:500,y:482,t:1527268125520};\\\", \\\"{x:513,y:488,t:1527268125537};\\\", \\\"{x:525,y:492,t:1527268125554};\\\", \\\"{x:533,y:494,t:1527268125570};\\\", \\\"{x:537,y:495,t:1527268125587};\\\", \\\"{x:538,y:495,t:1527268125616};\\\", \\\"{x:539,y:495,t:1527268125640};\\\", \\\"{x:540,y:495,t:1527268125655};\\\", \\\"{x:541,y:494,t:1527268125670};\\\", \\\"{x:544,y:494,t:1527268125688};\\\", \\\"{x:556,y:490,t:1527268125704};\\\", \\\"{x:576,y:489,t:1527268125720};\\\", \\\"{x:606,y:486,t:1527268125738};\\\", \\\"{x:648,y:486,t:1527268125754};\\\", \\\"{x:701,y:486,t:1527268125771};\\\", \\\"{x:751,y:486,t:1527268125788};\\\", \\\"{x:783,y:486,t:1527268125805};\\\", \\\"{x:811,y:485,t:1527268125820};\\\", \\\"{x:831,y:481,t:1527268125837};\\\", \\\"{x:848,y:479,t:1527268125854};\\\", \\\"{x:860,y:476,t:1527268125871};\\\", \\\"{x:867,y:475,t:1527268125888};\\\", \\\"{x:880,y:474,t:1527268125904};\\\", \\\"{x:891,y:472,t:1527268125922};\\\", \\\"{x:907,y:472,t:1527268125937};\\\", \\\"{x:930,y:472,t:1527268125954};\\\", \\\"{x:971,y:479,t:1527268125971};\\\", \\\"{x:1036,y:500,t:1527268125987};\\\", \\\"{x:1125,y:527,t:1527268126004};\\\", \\\"{x:1236,y:564,t:1527268126022};\\\", \\\"{x:1339,y:597,t:1527268126037};\\\", \\\"{x:1434,y:624,t:1527268126055};\\\", \\\"{x:1495,y:643,t:1527268126071};\\\", \\\"{x:1549,y:657,t:1527268126088};\\\", \\\"{x:1562,y:661,t:1527268126104};\\\", \\\"{x:1567,y:664,t:1527268126121};\\\", \\\"{x:1568,y:665,t:1527268126177};\\\", \\\"{x:1569,y:667,t:1527268126200};\\\", \\\"{x:1571,y:669,t:1527268126208};\\\", \\\"{x:1571,y:670,t:1527268126222};\\\", \\\"{x:1573,y:677,t:1527268126239};\\\", \\\"{x:1575,y:686,t:1527268126255};\\\", \\\"{x:1575,y:698,t:1527268126272};\\\", \\\"{x:1575,y:709,t:1527268126289};\\\", \\\"{x:1575,y:715,t:1527268126305};\\\", \\\"{x:1574,y:718,t:1527268126322};\\\", \\\"{x:1572,y:720,t:1527268126339};\\\", \\\"{x:1572,y:721,t:1527268126384};\\\", \\\"{x:1571,y:721,t:1527268126400};\\\", \\\"{x:1570,y:721,t:1527268126449};\\\", \\\"{x:1568,y:721,t:1527268126457};\\\", \\\"{x:1564,y:721,t:1527268126472};\\\", \\\"{x:1559,y:721,t:1527268126488};\\\", \\\"{x:1532,y:716,t:1527268126504};\\\", \\\"{x:1510,y:711,t:1527268126521};\\\", \\\"{x:1488,y:700,t:1527268126539};\\\", \\\"{x:1469,y:688,t:1527268126555};\\\", \\\"{x:1454,y:670,t:1527268126571};\\\", \\\"{x:1444,y:650,t:1527268126589};\\\", \\\"{x:1436,y:626,t:1527268126606};\\\", \\\"{x:1430,y:604,t:1527268126622};\\\", \\\"{x:1426,y:583,t:1527268126639};\\\", \\\"{x:1421,y:564,t:1527268126656};\\\", \\\"{x:1418,y:555,t:1527268126672};\\\", \\\"{x:1414,y:545,t:1527268126689};\\\", \\\"{x:1412,y:542,t:1527268126706};\\\", \\\"{x:1410,y:539,t:1527268126721};\\\", \\\"{x:1409,y:537,t:1527268126738};\\\", \\\"{x:1409,y:536,t:1527268126816};\\\", \\\"{x:1410,y:535,t:1527268126823};\\\", \\\"{x:1411,y:533,t:1527268126838};\\\", \\\"{x:1416,y:530,t:1527268126855};\\\", \\\"{x:1418,y:529,t:1527268126871};\\\", \\\"{x:1420,y:529,t:1527268126889};\\\", \\\"{x:1421,y:527,t:1527268126905};\\\", \\\"{x:1421,y:530,t:1527268127025};\\\", \\\"{x:1421,y:533,t:1527268127039};\\\", \\\"{x:1421,y:544,t:1527268127056};\\\", \\\"{x:1421,y:552,t:1527268127071};\\\", \\\"{x:1421,y:560,t:1527268127088};\\\", \\\"{x:1421,y:572,t:1527268127106};\\\", \\\"{x:1421,y:578,t:1527268127122};\\\", \\\"{x:1421,y:584,t:1527268127138};\\\", \\\"{x:1421,y:587,t:1527268127155};\\\", \\\"{x:1421,y:590,t:1527268127172};\\\", \\\"{x:1421,y:592,t:1527268127188};\\\", \\\"{x:1421,y:595,t:1527268127205};\\\", \\\"{x:1420,y:600,t:1527268127222};\\\", \\\"{x:1418,y:605,t:1527268127239};\\\", \\\"{x:1414,y:613,t:1527268127256};\\\", \\\"{x:1409,y:619,t:1527268127272};\\\", \\\"{x:1402,y:624,t:1527268127289};\\\", \\\"{x:1393,y:628,t:1527268127305};\\\", \\\"{x:1384,y:630,t:1527268127322};\\\", \\\"{x:1377,y:631,t:1527268127340};\\\", \\\"{x:1374,y:631,t:1527268127356};\\\", \\\"{x:1373,y:631,t:1527268127372};\\\", \\\"{x:1371,y:631,t:1527268127392};\\\", \\\"{x:1370,y:631,t:1527268127433};\\\", \\\"{x:1369,y:631,t:1527268127448};\\\", \\\"{x:1367,y:631,t:1527268127457};\\\", \\\"{x:1361,y:631,t:1527268127472};\\\", \\\"{x:1356,y:631,t:1527268127490};\\\", \\\"{x:1353,y:631,t:1527268127505};\\\", \\\"{x:1351,y:631,t:1527268127522};\\\", \\\"{x:1349,y:634,t:1527268127539};\\\", \\\"{x:1348,y:636,t:1527268127556};\\\", \\\"{x:1348,y:638,t:1527268127573};\\\", \\\"{x:1348,y:639,t:1527268127590};\\\", \\\"{x:1348,y:640,t:1527268127608};\\\", \\\"{x:1348,y:641,t:1527268127624};\\\", \\\"{x:1348,y:643,t:1527268127641};\\\", \\\"{x:1349,y:644,t:1527268127656};\\\", \\\"{x:1350,y:647,t:1527268127672};\\\", \\\"{x:1350,y:650,t:1527268127690};\\\", \\\"{x:1350,y:654,t:1527268127708};\\\", \\\"{x:1350,y:659,t:1527268127723};\\\", \\\"{x:1348,y:664,t:1527268127740};\\\", \\\"{x:1344,y:675,t:1527268127757};\\\", \\\"{x:1342,y:684,t:1527268127773};\\\", \\\"{x:1339,y:693,t:1527268127791};\\\", \\\"{x:1337,y:699,t:1527268127806};\\\", \\\"{x:1336,y:706,t:1527268127822};\\\", \\\"{x:1336,y:711,t:1527268127839};\\\", \\\"{x:1336,y:714,t:1527268127857};\\\", \\\"{x:1336,y:717,t:1527268127873};\\\", \\\"{x:1336,y:719,t:1527268127890};\\\", \\\"{x:1336,y:721,t:1527268127908};\\\", \\\"{x:1336,y:724,t:1527268127922};\\\", \\\"{x:1336,y:728,t:1527268127940};\\\", \\\"{x:1336,y:733,t:1527268127956};\\\", \\\"{x:1336,y:743,t:1527268127973};\\\", \\\"{x:1336,y:751,t:1527268127989};\\\", \\\"{x:1336,y:760,t:1527268128006};\\\", \\\"{x:1336,y:767,t:1527268128022};\\\", \\\"{x:1336,y:771,t:1527268128039};\\\", \\\"{x:1336,y:774,t:1527268128056};\\\", \\\"{x:1336,y:775,t:1527268128073};\\\", \\\"{x:1336,y:777,t:1527268128090};\\\", \\\"{x:1336,y:778,t:1527268128106};\\\", \\\"{x:1336,y:779,t:1527268128128};\\\", \\\"{x:1336,y:780,t:1527268128160};\\\", \\\"{x:1338,y:780,t:1527268128184};\\\", \\\"{x:1341,y:780,t:1527268128192};\\\", \\\"{x:1347,y:778,t:1527268128206};\\\", \\\"{x:1364,y:775,t:1527268128224};\\\", \\\"{x:1397,y:769,t:1527268128240};\\\", \\\"{x:1422,y:762,t:1527268128257};\\\", \\\"{x:1440,y:757,t:1527268128274};\\\", \\\"{x:1451,y:752,t:1527268128290};\\\", \\\"{x:1457,y:748,t:1527268128308};\\\", \\\"{x:1459,y:747,t:1527268128324};\\\", \\\"{x:1462,y:742,t:1527268128339};\\\", \\\"{x:1466,y:736,t:1527268128357};\\\", \\\"{x:1472,y:728,t:1527268128374};\\\", \\\"{x:1480,y:717,t:1527268128390};\\\", \\\"{x:1488,y:708,t:1527268128406};\\\", \\\"{x:1495,y:699,t:1527268128423};\\\", \\\"{x:1499,y:692,t:1527268128440};\\\", \\\"{x:1505,y:680,t:1527268128457};\\\", \\\"{x:1509,y:672,t:1527268128473};\\\", \\\"{x:1512,y:665,t:1527268128491};\\\", \\\"{x:1515,y:662,t:1527268128508};\\\", \\\"{x:1516,y:659,t:1527268128524};\\\", \\\"{x:1518,y:657,t:1527268128541};\\\", \\\"{x:1518,y:655,t:1527268128556};\\\", \\\"{x:1520,y:653,t:1527268128574};\\\", \\\"{x:1522,y:650,t:1527268128590};\\\", \\\"{x:1523,y:648,t:1527268128606};\\\", \\\"{x:1526,y:646,t:1527268128624};\\\", \\\"{x:1527,y:644,t:1527268128640};\\\", \\\"{x:1529,y:643,t:1527268128657};\\\", \\\"{x:1532,y:642,t:1527268128673};\\\", \\\"{x:1535,y:642,t:1527268128690};\\\", \\\"{x:1536,y:641,t:1527268128706};\\\", \\\"{x:1540,y:640,t:1527268128723};\\\", \\\"{x:1544,y:640,t:1527268128740};\\\", \\\"{x:1550,y:640,t:1527268128757};\\\", \\\"{x:1554,y:640,t:1527268128773};\\\", \\\"{x:1558,y:640,t:1527268128790};\\\", \\\"{x:1559,y:640,t:1527268128808};\\\", \\\"{x:1561,y:640,t:1527268128823};\\\", \\\"{x:1564,y:640,t:1527268128840};\\\", \\\"{x:1566,y:640,t:1527268128857};\\\", \\\"{x:1569,y:640,t:1527268128874};\\\", \\\"{x:1571,y:641,t:1527268128891};\\\", \\\"{x:1574,y:641,t:1527268128907};\\\", \\\"{x:1575,y:642,t:1527268128923};\\\", \\\"{x:1576,y:642,t:1527268128940};\\\", \\\"{x:1577,y:642,t:1527268128958};\\\", \\\"{x:1578,y:643,t:1527268128974};\\\", \\\"{x:1579,y:643,t:1527268128991};\\\", \\\"{x:1581,y:644,t:1527268129008};\\\", \\\"{x:1582,y:644,t:1527268129024};\\\", \\\"{x:1584,y:644,t:1527268129040};\\\", \\\"{x:1586,y:645,t:1527268129058};\\\", \\\"{x:1588,y:646,t:1527268129073};\\\", \\\"{x:1593,y:649,t:1527268129091};\\\", \\\"{x:1595,y:651,t:1527268129108};\\\", \\\"{x:1597,y:652,t:1527268129124};\\\", \\\"{x:1601,y:655,t:1527268129141};\\\", \\\"{x:1604,y:658,t:1527268129157};\\\", \\\"{x:1608,y:661,t:1527268129175};\\\", \\\"{x:1609,y:662,t:1527268129190};\\\", \\\"{x:1611,y:665,t:1527268129208};\\\", \\\"{x:1615,y:670,t:1527268129224};\\\", \\\"{x:1620,y:673,t:1527268129241};\\\", \\\"{x:1623,y:675,t:1527268129258};\\\", \\\"{x:1626,y:678,t:1527268129275};\\\", \\\"{x:1628,y:680,t:1527268129290};\\\", \\\"{x:1629,y:683,t:1527268129308};\\\", \\\"{x:1631,y:686,t:1527268129325};\\\", \\\"{x:1634,y:689,t:1527268129341};\\\", \\\"{x:1637,y:693,t:1527268129358};\\\", \\\"{x:1638,y:695,t:1527268129374};\\\", \\\"{x:1640,y:697,t:1527268129390};\\\", \\\"{x:1641,y:701,t:1527268129408};\\\", \\\"{x:1644,y:706,t:1527268129424};\\\", \\\"{x:1644,y:707,t:1527268129441};\\\", \\\"{x:1645,y:709,t:1527268129458};\\\", \\\"{x:1646,y:710,t:1527268129475};\\\", \\\"{x:1647,y:712,t:1527268129492};\\\", \\\"{x:1647,y:713,t:1527268129509};\\\", \\\"{x:1647,y:715,t:1527268129525};\\\", \\\"{x:1649,y:717,t:1527268129542};\\\", \\\"{x:1649,y:719,t:1527268129557};\\\", \\\"{x:1649,y:721,t:1527268129576};\\\", \\\"{x:1649,y:722,t:1527268129592};\\\", \\\"{x:1650,y:723,t:1527268129608};\\\", \\\"{x:1649,y:723,t:1527268129897};\\\", \\\"{x:1648,y:723,t:1527268129920};\\\", \\\"{x:1647,y:723,t:1527268129929};\\\", \\\"{x:1646,y:723,t:1527268129941};\\\", \\\"{x:1643,y:723,t:1527268129959};\\\", \\\"{x:1639,y:725,t:1527268129975};\\\", \\\"{x:1632,y:726,t:1527268129992};\\\", \\\"{x:1623,y:726,t:1527268130008};\\\", \\\"{x:1617,y:726,t:1527268130025};\\\", \\\"{x:1611,y:726,t:1527268130041};\\\", \\\"{x:1603,y:726,t:1527268130059};\\\", \\\"{x:1599,y:724,t:1527268130075};\\\", \\\"{x:1590,y:717,t:1527268130092};\\\", \\\"{x:1581,y:710,t:1527268130109};\\\", \\\"{x:1576,y:703,t:1527268130125};\\\", \\\"{x:1571,y:694,t:1527268130142};\\\", \\\"{x:1567,y:686,t:1527268130159};\\\", \\\"{x:1562,y:674,t:1527268130174};\\\", \\\"{x:1553,y:654,t:1527268130192};\\\", \\\"{x:1549,y:643,t:1527268130209};\\\", \\\"{x:1543,y:631,t:1527268130225};\\\", \\\"{x:1537,y:619,t:1527268130241};\\\", \\\"{x:1533,y:610,t:1527268130259};\\\", \\\"{x:1527,y:600,t:1527268130275};\\\", \\\"{x:1524,y:595,t:1527268130292};\\\", \\\"{x:1520,y:589,t:1527268130308};\\\", \\\"{x:1518,y:585,t:1527268130325};\\\", \\\"{x:1515,y:580,t:1527268130341};\\\", \\\"{x:1513,y:576,t:1527268130359};\\\", \\\"{x:1511,y:573,t:1527268130376};\\\", \\\"{x:1511,y:571,t:1527268130400};\\\", \\\"{x:1511,y:570,t:1527268130537};\\\", \\\"{x:1513,y:570,t:1527268130544};\\\", \\\"{x:1516,y:571,t:1527268130558};\\\", \\\"{x:1524,y:575,t:1527268130576};\\\", \\\"{x:1527,y:576,t:1527268130592};\\\", \\\"{x:1531,y:579,t:1527268130609};\\\", \\\"{x:1532,y:580,t:1527268130626};\\\", \\\"{x:1534,y:581,t:1527268130642};\\\", \\\"{x:1536,y:578,t:1527268130832};\\\", \\\"{x:1537,y:573,t:1527268130843};\\\", \\\"{x:1541,y:560,t:1527268130858};\\\", \\\"{x:1547,y:541,t:1527268130876};\\\", \\\"{x:1553,y:523,t:1527268130893};\\\", \\\"{x:1558,y:509,t:1527268130909};\\\", \\\"{x:1563,y:498,t:1527268130926};\\\", \\\"{x:1565,y:492,t:1527268130943};\\\", \\\"{x:1569,y:487,t:1527268130960};\\\", \\\"{x:1570,y:486,t:1527268130976};\\\", \\\"{x:1572,y:483,t:1527268130992};\\\", \\\"{x:1572,y:482,t:1527268131010};\\\", \\\"{x:1574,y:480,t:1527268131026};\\\", \\\"{x:1578,y:477,t:1527268131043};\\\", \\\"{x:1580,y:476,t:1527268131060};\\\", \\\"{x:1584,y:474,t:1527268131076};\\\", \\\"{x:1586,y:473,t:1527268131093};\\\", \\\"{x:1587,y:472,t:1527268131110};\\\", \\\"{x:1588,y:471,t:1527268131125};\\\", \\\"{x:1589,y:470,t:1527268131142};\\\", \\\"{x:1590,y:468,t:1527268131159};\\\", \\\"{x:1591,y:467,t:1527268131175};\\\", \\\"{x:1592,y:467,t:1527268131263};\\\", \\\"{x:1594,y:466,t:1527268131304};\\\", \\\"{x:1595,y:465,t:1527268131328};\\\", \\\"{x:1596,y:464,t:1527268131342};\\\", \\\"{x:1599,y:460,t:1527268131359};\\\", \\\"{x:1602,y:456,t:1527268131375};\\\", \\\"{x:1606,y:452,t:1527268131393};\\\", \\\"{x:1610,y:449,t:1527268131409};\\\", \\\"{x:1611,y:447,t:1527268131426};\\\", \\\"{x:1614,y:445,t:1527268131443};\\\", \\\"{x:1614,y:444,t:1527268131460};\\\", \\\"{x:1615,y:444,t:1527268131477};\\\", \\\"{x:1616,y:443,t:1527268131493};\\\", \\\"{x:1616,y:442,t:1527268131521};\\\", \\\"{x:1616,y:441,t:1527268131601};\\\", \\\"{x:1616,y:442,t:1527268131832};\\\", \\\"{x:1616,y:443,t:1527268131864};\\\", \\\"{x:1616,y:444,t:1527268131888};\\\", \\\"{x:1616,y:446,t:1527268131896};\\\", \\\"{x:1616,y:447,t:1527268131910};\\\", \\\"{x:1616,y:448,t:1527268131927};\\\", \\\"{x:1616,y:450,t:1527268131944};\\\", \\\"{x:1615,y:452,t:1527268132159};\\\", \\\"{x:1615,y:453,t:1527268132176};\\\", \\\"{x:1615,y:455,t:1527268132199};\\\", \\\"{x:1615,y:456,t:1527268132273};\\\", \\\"{x:1615,y:458,t:1527268132320};\\\", \\\"{x:1616,y:459,t:1527268132336};\\\", \\\"{x:1616,y:461,t:1527268132344};\\\", \\\"{x:1616,y:465,t:1527268132360};\\\", \\\"{x:1617,y:472,t:1527268132378};\\\", \\\"{x:1618,y:479,t:1527268132394};\\\", \\\"{x:1620,y:487,t:1527268132411};\\\", \\\"{x:1621,y:494,t:1527268132428};\\\", \\\"{x:1621,y:499,t:1527268132444};\\\", \\\"{x:1624,y:505,t:1527268132461};\\\", \\\"{x:1624,y:507,t:1527268132478};\\\", \\\"{x:1626,y:510,t:1527268132494};\\\", \\\"{x:1628,y:514,t:1527268132511};\\\", \\\"{x:1629,y:517,t:1527268132528};\\\", \\\"{x:1629,y:520,t:1527268132544};\\\", \\\"{x:1629,y:522,t:1527268132560};\\\", \\\"{x:1631,y:524,t:1527268132578};\\\", \\\"{x:1632,y:527,t:1527268132594};\\\", \\\"{x:1632,y:529,t:1527268132610};\\\", \\\"{x:1632,y:532,t:1527268132628};\\\", \\\"{x:1633,y:537,t:1527268132644};\\\", \\\"{x:1635,y:545,t:1527268132660};\\\", \\\"{x:1636,y:552,t:1527268132677};\\\", \\\"{x:1636,y:559,t:1527268132693};\\\", \\\"{x:1636,y:562,t:1527268132710};\\\", \\\"{x:1636,y:567,t:1527268132728};\\\", \\\"{x:1637,y:568,t:1527268132752};\\\", \\\"{x:1638,y:569,t:1527268132793};\\\", \\\"{x:1639,y:569,t:1527268132816};\\\", \\\"{x:1639,y:571,t:1527268132828};\\\", \\\"{x:1639,y:572,t:1527268132844};\\\", \\\"{x:1639,y:575,t:1527268132861};\\\", \\\"{x:1639,y:580,t:1527268132878};\\\", \\\"{x:1639,y:586,t:1527268132895};\\\", \\\"{x:1638,y:591,t:1527268132911};\\\", \\\"{x:1635,y:597,t:1527268132928};\\\", \\\"{x:1635,y:599,t:1527268132945};\\\", \\\"{x:1635,y:600,t:1527268132960};\\\", \\\"{x:1635,y:601,t:1527268133049};\\\", \\\"{x:1635,y:602,t:1527268133064};\\\", \\\"{x:1635,y:604,t:1527268133081};\\\", \\\"{x:1634,y:606,t:1527268133105};\\\", \\\"{x:1633,y:607,t:1527268133111};\\\", \\\"{x:1631,y:610,t:1527268133127};\\\", \\\"{x:1628,y:613,t:1527268133144};\\\", \\\"{x:1626,y:614,t:1527268133161};\\\", \\\"{x:1625,y:615,t:1527268133177};\\\", \\\"{x:1624,y:615,t:1527268133231};\\\", \\\"{x:1623,y:615,t:1527268133247};\\\", \\\"{x:1622,y:615,t:1527268133263};\\\", \\\"{x:1621,y:615,t:1527268133312};\\\", \\\"{x:1621,y:614,t:1527268133368};\\\", \\\"{x:1620,y:614,t:1527268133433};\\\", \\\"{x:1619,y:614,t:1527268133489};\\\", \\\"{x:1619,y:613,t:1527268133497};\\\", \\\"{x:1618,y:611,t:1527268133512};\\\", \\\"{x:1617,y:607,t:1527268133528};\\\", \\\"{x:1615,y:604,t:1527268133544};\\\", \\\"{x:1612,y:600,t:1527268133562};\\\", \\\"{x:1611,y:598,t:1527268133578};\\\", \\\"{x:1611,y:597,t:1527268133656};\\\", \\\"{x:1611,y:596,t:1527268133672};\\\", \\\"{x:1611,y:594,t:1527268133680};\\\", \\\"{x:1611,y:591,t:1527268133696};\\\", \\\"{x:1611,y:587,t:1527268133712};\\\", \\\"{x:1611,y:583,t:1527268133729};\\\", \\\"{x:1611,y:580,t:1527268133745};\\\", \\\"{x:1611,y:577,t:1527268133762};\\\", \\\"{x:1612,y:576,t:1527268133779};\\\", \\\"{x:1612,y:575,t:1527268133795};\\\", \\\"{x:1612,y:574,t:1527268133812};\\\", \\\"{x:1611,y:573,t:1527268134049};\\\", \\\"{x:1608,y:572,t:1527268134062};\\\", \\\"{x:1592,y:572,t:1527268134079};\\\", \\\"{x:1492,y:572,t:1527268134096};\\\", \\\"{x:1373,y:572,t:1527268134112};\\\", \\\"{x:1217,y:580,t:1527268134129};\\\", \\\"{x:1043,y:607,t:1527268134146};\\\", \\\"{x:908,y:622,t:1527268134163};\\\", \\\"{x:825,y:622,t:1527268134178};\\\", \\\"{x:788,y:622,t:1527268134196};\\\", \\\"{x:772,y:620,t:1527268134213};\\\", \\\"{x:771,y:619,t:1527268134228};\\\", \\\"{x:770,y:619,t:1527268134246};\\\", \\\"{x:769,y:618,t:1527268134262};\\\", \\\"{x:768,y:617,t:1527268134279};\\\", \\\"{x:760,y:614,t:1527268134296};\\\", \\\"{x:750,y:612,t:1527268134313};\\\", \\\"{x:740,y:611,t:1527268134328};\\\", \\\"{x:728,y:611,t:1527268134345};\\\", \\\"{x:712,y:611,t:1527268134360};\\\", \\\"{x:697,y:611,t:1527268134376};\\\", \\\"{x:685,y:611,t:1527268134393};\\\", \\\"{x:668,y:611,t:1527268134410};\\\", \\\"{x:649,y:611,t:1527268134426};\\\", \\\"{x:625,y:611,t:1527268134444};\\\", \\\"{x:602,y:609,t:1527268134460};\\\", \\\"{x:576,y:606,t:1527268134477};\\\", \\\"{x:551,y:606,t:1527268134493};\\\", \\\"{x:537,y:605,t:1527268134511};\\\", \\\"{x:538,y:605,t:1527268134592};\\\", \\\"{x:543,y:605,t:1527268134600};\\\", \\\"{x:552,y:610,t:1527268134611};\\\", \\\"{x:569,y:615,t:1527268134628};\\\", \\\"{x:592,y:622,t:1527268134644};\\\", \\\"{x:619,y:625,t:1527268134662};\\\", \\\"{x:642,y:625,t:1527268134678};\\\", \\\"{x:657,y:625,t:1527268134695};\\\", \\\"{x:664,y:624,t:1527268134710};\\\", \\\"{x:666,y:622,t:1527268134727};\\\", \\\"{x:668,y:621,t:1527268134744};\\\", \\\"{x:670,y:620,t:1527268134760};\\\", \\\"{x:679,y:617,t:1527268134777};\\\", \\\"{x:694,y:612,t:1527268134795};\\\", \\\"{x:717,y:606,t:1527268134812};\\\", \\\"{x:745,y:599,t:1527268134828};\\\", \\\"{x:776,y:590,t:1527268134844};\\\", \\\"{x:803,y:587,t:1527268134861};\\\", \\\"{x:825,y:583,t:1527268134877};\\\", \\\"{x:839,y:581,t:1527268134895};\\\", \\\"{x:848,y:581,t:1527268134911};\\\", \\\"{x:850,y:580,t:1527268134927};\\\", \\\"{x:845,y:580,t:1527268134984};\\\", \\\"{x:840,y:580,t:1527268134994};\\\", \\\"{x:823,y:580,t:1527268135011};\\\", \\\"{x:793,y:580,t:1527268135027};\\\", \\\"{x:762,y:580,t:1527268135044};\\\", \\\"{x:737,y:580,t:1527268135061};\\\", \\\"{x:717,y:579,t:1527268135078};\\\", \\\"{x:699,y:579,t:1527268135094};\\\", \\\"{x:670,y:581,t:1527268135111};\\\", \\\"{x:650,y:584,t:1527268135128};\\\", \\\"{x:631,y:586,t:1527268135145};\\\", \\\"{x:613,y:591,t:1527268135162};\\\", \\\"{x:591,y:593,t:1527268135178};\\\", \\\"{x:569,y:596,t:1527268135194};\\\", \\\"{x:548,y:598,t:1527268135211};\\\", \\\"{x:522,y:603,t:1527268135227};\\\", \\\"{x:494,y:607,t:1527268135245};\\\", \\\"{x:460,y:613,t:1527268135262};\\\", \\\"{x:428,y:613,t:1527268135279};\\\", \\\"{x:383,y:614,t:1527268135295};\\\", \\\"{x:345,y:614,t:1527268135312};\\\", \\\"{x:335,y:614,t:1527268135327};\\\", \\\"{x:332,y:614,t:1527268135345};\\\", \\\"{x:332,y:615,t:1527268135384};\\\", \\\"{x:331,y:615,t:1527268135424};\\\", \\\"{x:329,y:615,t:1527268135432};\\\", \\\"{x:327,y:615,t:1527268135445};\\\", \\\"{x:315,y:616,t:1527268135461};\\\", \\\"{x:299,y:616,t:1527268135478};\\\", \\\"{x:278,y:616,t:1527268135494};\\\", \\\"{x:250,y:616,t:1527268135512};\\\", \\\"{x:228,y:616,t:1527268135528};\\\", \\\"{x:210,y:619,t:1527268135544};\\\", \\\"{x:190,y:621,t:1527268135563};\\\", \\\"{x:172,y:624,t:1527268135579};\\\", \\\"{x:163,y:625,t:1527268135594};\\\", \\\"{x:158,y:626,t:1527268135612};\\\", \\\"{x:151,y:626,t:1527268135628};\\\", \\\"{x:147,y:627,t:1527268135645};\\\", \\\"{x:143,y:628,t:1527268135661};\\\", \\\"{x:141,y:629,t:1527268135678};\\\", \\\"{x:140,y:629,t:1527268135808};\\\", \\\"{x:140,y:630,t:1527268135840};\\\", \\\"{x:141,y:630,t:1527268135848};\\\", \\\"{x:141,y:631,t:1527268135864};\\\", \\\"{x:142,y:632,t:1527268135879};\\\", \\\"{x:143,y:632,t:1527268135985};\\\", \\\"{x:145,y:632,t:1527268136007};\\\", \\\"{x:145,y:633,t:1527268136016};\\\", \\\"{x:146,y:633,t:1527268136032};\\\", \\\"{x:146,y:634,t:1527268136063};\\\", \\\"{x:147,y:635,t:1527268136088};\\\", \\\"{x:148,y:635,t:1527268136103};\\\", \\\"{x:149,y:635,t:1527268136136};\\\", \\\"{x:149,y:636,t:1527268136151};\\\", \\\"{x:150,y:636,t:1527268136167};\\\", \\\"{x:151,y:636,t:1527268137777};\\\", \\\"{x:152,y:637,t:1527268139088};\\\", \\\"{x:155,y:639,t:1527268139256};\\\", \\\"{x:160,y:643,t:1527268139264};\\\", \\\"{x:172,y:650,t:1527268139282};\\\", \\\"{x:183,y:656,t:1527268139298};\\\", \\\"{x:194,y:662,t:1527268139314};\\\", \\\"{x:200,y:666,t:1527268139332};\\\", \\\"{x:203,y:668,t:1527268139347};\\\", \\\"{x:203,y:669,t:1527268139364};\\\", \\\"{x:205,y:669,t:1527268139536};\\\", \\\"{x:205,y:671,t:1527268139585};\\\", \\\"{x:205,y:672,t:1527268139608};\\\", \\\"{x:206,y:673,t:1527268139697};\\\", \\\"{x:208,y:673,t:1527268139833};\\\", \\\"{x:211,y:675,t:1527268139849};\\\", \\\"{x:212,y:676,t:1527268139866};\\\", \\\"{x:215,y:677,t:1527268139883};\\\", \\\"{x:216,y:678,t:1527268139899};\\\", \\\"{x:217,y:678,t:1527268139920};\\\", \\\"{x:218,y:678,t:1527268139933};\\\", \\\"{x:219,y:678,t:1527268139952};\\\", \\\"{x:220,y:678,t:1527268140016};\\\", \\\"{x:222,y:678,t:1527268140032};\\\", \\\"{x:224,y:678,t:1527268140049};\\\", \\\"{x:227,y:678,t:1527268140066};\\\", \\\"{x:227,y:679,t:1527268140083};\\\", \\\"{x:228,y:679,t:1527268140099};\\\", \\\"{x:228,y:680,t:1527268140116};\\\", \\\"{x:230,y:680,t:1527268140360};\\\", \\\"{x:233,y:680,t:1527268140577};\\\", \\\"{x:238,y:681,t:1527268140584};\\\", \\\"{x:250,y:683,t:1527268140600};\\\", \\\"{x:264,y:683,t:1527268140617};\\\", \\\"{x:275,y:684,t:1527268140634};\\\", \\\"{x:287,y:684,t:1527268140650};\\\", \\\"{x:301,y:684,t:1527268140667};\\\", \\\"{x:311,y:684,t:1527268140684};\\\", \\\"{x:321,y:684,t:1527268140700};\\\", \\\"{x:332,y:684,t:1527268140717};\\\", \\\"{x:342,y:684,t:1527268140734};\\\", \\\"{x:351,y:684,t:1527268140750};\\\", \\\"{x:362,y:684,t:1527268140767};\\\", \\\"{x:373,y:686,t:1527268140784};\\\", \\\"{x:383,y:689,t:1527268140800};\\\", \\\"{x:394,y:693,t:1527268140817};\\\", \\\"{x:401,y:693,t:1527268140834};\\\", \\\"{x:409,y:697,t:1527268140850};\\\", \\\"{x:414,y:697,t:1527268140867};\\\", \\\"{x:419,y:697,t:1527268140884};\\\", \\\"{x:423,y:698,t:1527268140901};\\\", \\\"{x:431,y:701,t:1527268140916};\\\", \\\"{x:444,y:705,t:1527268140934};\\\", \\\"{x:464,y:712,t:1527268140951};\\\", \\\"{x:482,y:723,t:1527268140967};\\\", \\\"{x:506,y:734,t:1527268140983};\\\", \\\"{x:512,y:736,t:1527268140999};\\\", \\\"{x:517,y:739,t:1527268141015};\\\", \\\"{x:517,y:740,t:1527268141071};\\\", \\\"{x:517,y:741,t:1527268141103};\\\", \\\"{x:517,y:740,t:1527268141217};\\\", \\\"{x:517,y:739,t:1527268141240};\\\", \\\"{x:517,y:738,t:1527268141250};\\\", \\\"{x:517,y:737,t:1527268141267};\\\", \\\"{x:517,y:736,t:1527268141337};\\\", \\\"{x:516,y:736,t:1527268141385};\\\", \\\"{x:515,y:733,t:1527268141401};\\\", \\\"{x:515,y:732,t:1527268141416};\\\", \\\"{x:513,y:729,t:1527268141433};\\\", \\\"{x:513,y:728,t:1527268141450};\\\", \\\"{x:513,y:727,t:1527268141467};\\\", \\\"{x:513,y:726,t:1527268141484};\\\", \\\"{x:512,y:725,t:1527268141500};\\\", \\\"{x:512,y:724,t:1527268141919};\\\", \\\"{x:512,y:723,t:1527268141943};\\\" ] }, { \\\"rt\\\": 16247, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 195058, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:722,t:1527268143698};\\\", \\\"{x:513,y:720,t:1527268143707};\\\", \\\"{x:513,y:717,t:1527268143721};\\\", \\\"{x:515,y:706,t:1527268143739};\\\", \\\"{x:519,y:690,t:1527268143756};\\\", \\\"{x:525,y:674,t:1527268143771};\\\", \\\"{x:525,y:660,t:1527268143787};\\\", \\\"{x:528,y:639,t:1527268143805};\\\", \\\"{x:528,y:622,t:1527268143821};\\\", \\\"{x:528,y:605,t:1527268143838};\\\", \\\"{x:527,y:591,t:1527268143854};\\\", \\\"{x:523,y:576,t:1527268143871};\\\", \\\"{x:523,y:556,t:1527268143888};\\\", \\\"{x:522,y:544,t:1527268143904};\\\", \\\"{x:521,y:530,t:1527268143921};\\\", \\\"{x:521,y:523,t:1527268143938};\\\", \\\"{x:521,y:514,t:1527268143954};\\\", \\\"{x:521,y:512,t:1527268143971};\\\", \\\"{x:521,y:511,t:1527268143987};\\\", \\\"{x:521,y:510,t:1527268144083};\\\", \\\"{x:521,y:509,t:1527268144091};\\\", \\\"{x:521,y:508,t:1527268144107};\\\", \\\"{x:522,y:507,t:1527268144122};\\\", \\\"{x:527,y:503,t:1527268144138};\\\", \\\"{x:537,y:498,t:1527268144154};\\\", \\\"{x:543,y:495,t:1527268144171};\\\", \\\"{x:554,y:492,t:1527268144188};\\\", \\\"{x:563,y:490,t:1527268144204};\\\", \\\"{x:577,y:488,t:1527268144221};\\\", \\\"{x:591,y:487,t:1527268144238};\\\", \\\"{x:604,y:487,t:1527268144253};\\\", \\\"{x:614,y:487,t:1527268144271};\\\", \\\"{x:621,y:487,t:1527268144287};\\\", \\\"{x:625,y:487,t:1527268144303};\\\", \\\"{x:626,y:487,t:1527268144371};\\\", \\\"{x:627,y:487,t:1527268144467};\\\", \\\"{x:627,y:488,t:1527268144507};\\\", \\\"{x:627,y:490,t:1527268144521};\\\", \\\"{x:628,y:493,t:1527268144537};\\\", \\\"{x:628,y:494,t:1527268144554};\\\", \\\"{x:628,y:495,t:1527268144691};\\\", \\\"{x:627,y:496,t:1527268144763};\\\", \\\"{x:623,y:497,t:1527268144770};\\\", \\\"{x:612,y:501,t:1527268144786};\\\", \\\"{x:593,y:502,t:1527268144804};\\\", \\\"{x:567,y:502,t:1527268144820};\\\", \\\"{x:538,y:502,t:1527268144837};\\\", \\\"{x:511,y:502,t:1527268144854};\\\", \\\"{x:495,y:502,t:1527268144870};\\\", \\\"{x:486,y:502,t:1527268144887};\\\", \\\"{x:483,y:502,t:1527268144904};\\\", \\\"{x:482,y:502,t:1527268145027};\\\", \\\"{x:481,y:502,t:1527268145050};\\\", \\\"{x:480,y:501,t:1527268145067};\\\", \\\"{x:479,y:501,t:1527268145091};\\\", \\\"{x:479,y:500,t:1527268145123};\\\", \\\"{x:479,y:498,t:1527268145139};\\\", \\\"{x:479,y:497,t:1527268145153};\\\", \\\"{x:482,y:493,t:1527268145170};\\\", \\\"{x:491,y:490,t:1527268145187};\\\", \\\"{x:496,y:488,t:1527268145203};\\\", \\\"{x:503,y:486,t:1527268145220};\\\", \\\"{x:514,y:485,t:1527268145237};\\\", \\\"{x:530,y:485,t:1527268145253};\\\", \\\"{x:551,y:485,t:1527268145270};\\\", \\\"{x:577,y:485,t:1527268145287};\\\", \\\"{x:600,y:485,t:1527268145303};\\\", \\\"{x:622,y:485,t:1527268145320};\\\", \\\"{x:638,y:485,t:1527268145337};\\\", \\\"{x:650,y:482,t:1527268145354};\\\", \\\"{x:662,y:481,t:1527268145370};\\\", \\\"{x:668,y:479,t:1527268145387};\\\", \\\"{x:669,y:478,t:1527268145403};\\\", \\\"{x:675,y:478,t:1527268145420};\\\", \\\"{x:682,y:476,t:1527268145437};\\\", \\\"{x:696,y:474,t:1527268145453};\\\", \\\"{x:718,y:472,t:1527268145470};\\\", \\\"{x:752,y:469,t:1527268145486};\\\", \\\"{x:817,y:466,t:1527268145503};\\\", \\\"{x:895,y:459,t:1527268145520};\\\", \\\"{x:976,y:446,t:1527268145536};\\\", \\\"{x:1070,y:432,t:1527268145554};\\\", \\\"{x:1166,y:419,t:1527268145571};\\\", \\\"{x:1193,y:414,t:1527268145586};\\\", \\\"{x:1245,y:401,t:1527268145603};\\\", \\\"{x:1269,y:394,t:1527268145620};\\\", \\\"{x:1288,y:389,t:1527268145636};\\\", \\\"{x:1306,y:384,t:1527268145653};\\\", \\\"{x:1323,y:379,t:1527268145670};\\\", \\\"{x:1339,y:375,t:1527268145686};\\\", \\\"{x:1352,y:371,t:1527268145703};\\\", \\\"{x:1366,y:368,t:1527268145720};\\\", \\\"{x:1385,y:363,t:1527268145737};\\\", \\\"{x:1401,y:362,t:1527268145754};\\\", \\\"{x:1416,y:359,t:1527268145770};\\\", \\\"{x:1433,y:357,t:1527268145786};\\\", \\\"{x:1464,y:357,t:1527268145803};\\\", \\\"{x:1486,y:356,t:1527268145819};\\\", \\\"{x:1510,y:351,t:1527268145836};\\\", \\\"{x:1537,y:347,t:1527268145853};\\\", \\\"{x:1559,y:341,t:1527268145869};\\\", \\\"{x:1576,y:337,t:1527268145887};\\\", \\\"{x:1587,y:334,t:1527268145903};\\\", \\\"{x:1594,y:332,t:1527268145919};\\\", \\\"{x:1595,y:332,t:1527268145937};\\\", \\\"{x:1596,y:332,t:1527268146035};\\\", \\\"{x:1596,y:336,t:1527268146053};\\\", \\\"{x:1597,y:344,t:1527268146070};\\\", \\\"{x:1598,y:348,t:1527268146086};\\\", \\\"{x:1598,y:353,t:1527268146102};\\\", \\\"{x:1598,y:359,t:1527268146120};\\\", \\\"{x:1598,y:365,t:1527268146136};\\\", \\\"{x:1598,y:376,t:1527268146152};\\\", \\\"{x:1598,y:389,t:1527268146170};\\\", \\\"{x:1598,y:403,t:1527268146186};\\\", \\\"{x:1598,y:411,t:1527268146202};\\\", \\\"{x:1598,y:428,t:1527268146219};\\\", \\\"{x:1598,y:439,t:1527268146236};\\\", \\\"{x:1598,y:449,t:1527268146252};\\\", \\\"{x:1598,y:459,t:1527268146269};\\\", \\\"{x:1597,y:469,t:1527268146286};\\\", \\\"{x:1593,y:483,t:1527268146302};\\\", \\\"{x:1587,y:498,t:1527268146319};\\\", \\\"{x:1582,y:507,t:1527268146336};\\\", \\\"{x:1578,y:513,t:1527268146353};\\\", \\\"{x:1577,y:516,t:1527268146369};\\\", \\\"{x:1574,y:518,t:1527268146387};\\\", \\\"{x:1571,y:521,t:1527268146403};\\\", \\\"{x:1565,y:525,t:1527268146419};\\\", \\\"{x:1553,y:532,t:1527268146435};\\\", \\\"{x:1530,y:544,t:1527268146453};\\\", \\\"{x:1508,y:553,t:1527268146469};\\\", \\\"{x:1490,y:563,t:1527268146486};\\\", \\\"{x:1474,y:571,t:1527268146503};\\\", \\\"{x:1459,y:582,t:1527268146519};\\\", \\\"{x:1450,y:589,t:1527268146536};\\\", \\\"{x:1443,y:596,t:1527268146552};\\\", \\\"{x:1436,y:601,t:1527268146569};\\\", \\\"{x:1430,y:607,t:1527268146585};\\\", \\\"{x:1425,y:618,t:1527268146603};\\\", \\\"{x:1422,y:627,t:1527268146619};\\\", \\\"{x:1422,y:636,t:1527268146635};\\\", \\\"{x:1421,y:645,t:1527268146652};\\\", \\\"{x:1418,y:653,t:1527268146669};\\\", \\\"{x:1417,y:657,t:1527268146685};\\\", \\\"{x:1412,y:664,t:1527268146702};\\\", \\\"{x:1408,y:669,t:1527268146718};\\\", \\\"{x:1404,y:673,t:1527268146735};\\\", \\\"{x:1400,y:675,t:1527268146753};\\\", \\\"{x:1397,y:678,t:1527268146768};\\\", \\\"{x:1394,y:681,t:1527268146785};\\\", \\\"{x:1389,y:685,t:1527268146803};\\\", \\\"{x:1386,y:688,t:1527268146818};\\\", \\\"{x:1381,y:693,t:1527268146835};\\\", \\\"{x:1380,y:694,t:1527268146852};\\\", \\\"{x:1379,y:695,t:1527268146868};\\\", \\\"{x:1378,y:698,t:1527268146885};\\\", \\\"{x:1378,y:699,t:1527268146939};\\\", \\\"{x:1378,y:701,t:1527268146955};\\\", \\\"{x:1376,y:702,t:1527268146968};\\\", \\\"{x:1373,y:705,t:1527268146985};\\\", \\\"{x:1369,y:708,t:1527268147002};\\\", \\\"{x:1362,y:712,t:1527268147018};\\\", \\\"{x:1348,y:719,t:1527268147035};\\\", \\\"{x:1339,y:723,t:1527268147052};\\\", \\\"{x:1328,y:728,t:1527268147068};\\\", \\\"{x:1315,y:736,t:1527268147085};\\\", \\\"{x:1300,y:747,t:1527268147100};\\\", \\\"{x:1290,y:754,t:1527268147118};\\\", \\\"{x:1282,y:760,t:1527268147135};\\\", \\\"{x:1278,y:763,t:1527268147151};\\\", \\\"{x:1274,y:767,t:1527268147168};\\\", \\\"{x:1273,y:773,t:1527268147184};\\\", \\\"{x:1268,y:782,t:1527268147200};\\\", \\\"{x:1264,y:791,t:1527268147217};\\\", \\\"{x:1261,y:799,t:1527268147234};\\\", \\\"{x:1256,y:804,t:1527268147251};\\\", \\\"{x:1252,y:810,t:1527268147268};\\\", \\\"{x:1248,y:816,t:1527268147285};\\\", \\\"{x:1246,y:818,t:1527268147301};\\\", \\\"{x:1246,y:819,t:1527268147318};\\\", \\\"{x:1245,y:821,t:1527268147335};\\\", \\\"{x:1244,y:821,t:1527268147351};\\\", \\\"{x:1243,y:823,t:1527268147368};\\\", \\\"{x:1242,y:825,t:1527268147395};\\\", \\\"{x:1240,y:825,t:1527268147436};\\\", \\\"{x:1238,y:825,t:1527268147459};\\\", \\\"{x:1237,y:825,t:1527268147475};\\\", \\\"{x:1236,y:826,t:1527268147491};\\\", \\\"{x:1235,y:827,t:1527268147515};\\\", \\\"{x:1234,y:827,t:1527268147531};\\\", \\\"{x:1234,y:828,t:1527268147547};\\\", \\\"{x:1234,y:830,t:1527268147564};\\\", \\\"{x:1234,y:832,t:1527268147571};\\\", \\\"{x:1234,y:833,t:1527268147587};\\\", \\\"{x:1233,y:835,t:1527268147602};\\\", \\\"{x:1232,y:836,t:1527268147619};\\\", \\\"{x:1231,y:836,t:1527268147723};\\\", \\\"{x:1230,y:836,t:1527268147746};\\\", \\\"{x:1229,y:836,t:1527268147780};\\\", \\\"{x:1228,y:836,t:1527268147795};\\\", \\\"{x:1227,y:836,t:1527268147803};\\\", \\\"{x:1226,y:836,t:1527268147827};\\\", \\\"{x:1224,y:836,t:1527268147842};\\\", \\\"{x:1223,y:836,t:1527268147867};\\\", \\\"{x:1221,y:836,t:1527268147885};\\\", \\\"{x:1220,y:836,t:1527268147923};\\\", \\\"{x:1219,y:835,t:1527268147955};\\\", \\\"{x:1218,y:835,t:1527268148027};\\\", \\\"{x:1217,y:834,t:1527268148318};\\\", \\\"{x:1217,y:833,t:1527268148643};\\\", \\\"{x:1217,y:832,t:1527268149555};\\\", \\\"{x:1217,y:830,t:1527268150411};\\\", \\\"{x:1218,y:829,t:1527268150426};\\\", \\\"{x:1219,y:828,t:1527268150443};\\\", \\\"{x:1221,y:828,t:1527268150452};\\\", \\\"{x:1222,y:828,t:1527268150466};\\\", \\\"{x:1225,y:828,t:1527268150482};\\\", \\\"{x:1231,y:827,t:1527268150499};\\\", \\\"{x:1235,y:827,t:1527268150515};\\\", \\\"{x:1243,y:824,t:1527268150532};\\\", \\\"{x:1253,y:823,t:1527268150548};\\\", \\\"{x:1264,y:823,t:1527268150564};\\\", \\\"{x:1277,y:820,t:1527268150582};\\\", \\\"{x:1289,y:819,t:1527268150599};\\\", \\\"{x:1299,y:818,t:1527268150614};\\\", \\\"{x:1309,y:815,t:1527268150631};\\\", \\\"{x:1320,y:814,t:1527268150649};\\\", \\\"{x:1330,y:813,t:1527268150665};\\\", \\\"{x:1343,y:811,t:1527268150680};\\\", \\\"{x:1362,y:810,t:1527268150697};\\\", \\\"{x:1372,y:810,t:1527268150714};\\\", \\\"{x:1377,y:810,t:1527268150730};\\\", \\\"{x:1380,y:810,t:1527268150747};\\\", \\\"{x:1381,y:810,t:1527268150763};\\\", \\\"{x:1382,y:810,t:1527268150781};\\\", \\\"{x:1383,y:810,t:1527268150834};\\\", \\\"{x:1384,y:810,t:1527268150883};\\\", \\\"{x:1384,y:811,t:1527268150907};\\\", \\\"{x:1385,y:811,t:1527268150923};\\\", \\\"{x:1385,y:812,t:1527268150931};\\\", \\\"{x:1385,y:813,t:1527268150948};\\\", \\\"{x:1385,y:814,t:1527268150965};\\\", \\\"{x:1384,y:815,t:1527268150982};\\\", \\\"{x:1382,y:817,t:1527268150998};\\\", \\\"{x:1381,y:818,t:1527268151014};\\\", \\\"{x:1380,y:819,t:1527268151032};\\\", \\\"{x:1378,y:820,t:1527268151047};\\\", \\\"{x:1376,y:821,t:1527268151064};\\\", \\\"{x:1375,y:821,t:1527268151082};\\\", \\\"{x:1374,y:822,t:1527268151097};\\\", \\\"{x:1369,y:824,t:1527268151115};\\\", \\\"{x:1367,y:824,t:1527268151131};\\\", \\\"{x:1365,y:825,t:1527268151147};\\\", \\\"{x:1364,y:825,t:1527268151164};\\\", \\\"{x:1363,y:826,t:1527268151180};\\\", \\\"{x:1362,y:826,t:1527268151197};\\\", \\\"{x:1359,y:827,t:1527268151214};\\\", \\\"{x:1357,y:827,t:1527268151230};\\\", \\\"{x:1355,y:829,t:1527268151247};\\\", \\\"{x:1354,y:829,t:1527268151265};\\\", \\\"{x:1351,y:829,t:1527268151281};\\\", \\\"{x:1350,y:829,t:1527268151297};\\\", \\\"{x:1349,y:829,t:1527268151339};\\\", \\\"{x:1348,y:829,t:1527268151379};\\\", \\\"{x:1347,y:830,t:1527268151395};\\\", \\\"{x:1346,y:830,t:1527268152460};\\\", \\\"{x:1346,y:829,t:1527268153051};\\\", \\\"{x:1346,y:827,t:1527268153195};\\\", \\\"{x:1346,y:826,t:1527268153227};\\\", \\\"{x:1347,y:824,t:1527268153324};\\\", \\\"{x:1347,y:822,t:1527268153371};\\\", \\\"{x:1348,y:820,t:1527268153387};\\\", \\\"{x:1348,y:819,t:1527268153491};\\\", \\\"{x:1348,y:818,t:1527268153507};\\\", \\\"{x:1348,y:817,t:1527268153514};\\\", \\\"{x:1349,y:817,t:1527268153528};\\\", \\\"{x:1349,y:816,t:1527268153545};\\\", \\\"{x:1349,y:815,t:1527268153562};\\\", \\\"{x:1349,y:814,t:1527268153579};\\\", \\\"{x:1350,y:813,t:1527268153595};\\\", \\\"{x:1350,y:812,t:1527268153619};\\\", \\\"{x:1351,y:811,t:1527268153629};\\\", \\\"{x:1351,y:809,t:1527268153646};\\\", \\\"{x:1351,y:807,t:1527268153662};\\\", \\\"{x:1351,y:804,t:1527268153678};\\\", \\\"{x:1351,y:801,t:1527268153696};\\\", \\\"{x:1351,y:798,t:1527268153712};\\\", \\\"{x:1351,y:794,t:1527268153729};\\\", \\\"{x:1351,y:792,t:1527268153744};\\\", \\\"{x:1351,y:790,t:1527268153762};\\\", \\\"{x:1351,y:787,t:1527268153778};\\\", \\\"{x:1351,y:785,t:1527268153795};\\\", \\\"{x:1351,y:783,t:1527268153811};\\\", \\\"{x:1351,y:782,t:1527268153829};\\\", \\\"{x:1351,y:781,t:1527268153844};\\\", \\\"{x:1351,y:779,t:1527268153861};\\\", \\\"{x:1351,y:778,t:1527268153878};\\\", \\\"{x:1351,y:777,t:1527268153894};\\\", \\\"{x:1351,y:775,t:1527268153911};\\\", \\\"{x:1351,y:774,t:1527268153928};\\\", \\\"{x:1351,y:772,t:1527268153944};\\\", \\\"{x:1351,y:771,t:1527268153961};\\\", \\\"{x:1351,y:769,t:1527268153979};\\\", \\\"{x:1351,y:766,t:1527268153994};\\\", \\\"{x:1351,y:764,t:1527268154011};\\\", \\\"{x:1351,y:763,t:1527268154028};\\\", \\\"{x:1351,y:761,t:1527268154045};\\\", \\\"{x:1351,y:758,t:1527268154061};\\\", \\\"{x:1351,y:757,t:1527268154077};\\\", \\\"{x:1351,y:755,t:1527268154094};\\\", \\\"{x:1351,y:754,t:1527268154123};\\\", \\\"{x:1351,y:753,t:1527268154146};\\\", \\\"{x:1351,y:752,t:1527268154179};\\\", \\\"{x:1351,y:751,t:1527268154227};\\\", \\\"{x:1351,y:749,t:1527268154245};\\\", \\\"{x:1351,y:748,t:1527268154261};\\\", \\\"{x:1351,y:746,t:1527268154277};\\\", \\\"{x:1351,y:745,t:1527268154298};\\\", \\\"{x:1351,y:744,t:1527268154311};\\\", \\\"{x:1350,y:743,t:1527268154327};\\\", \\\"{x:1350,y:742,t:1527268154346};\\\", \\\"{x:1350,y:741,t:1527268154363};\\\", \\\"{x:1350,y:740,t:1527268154379};\\\", \\\"{x:1349,y:739,t:1527268154403};\\\", \\\"{x:1349,y:738,t:1527268154419};\\\", \\\"{x:1349,y:737,t:1527268154443};\\\", \\\"{x:1349,y:736,t:1527268154475};\\\", \\\"{x:1349,y:735,t:1527268154587};\\\", \\\"{x:1349,y:734,t:1527268154667};\\\", \\\"{x:1347,y:733,t:1527268154677};\\\", \\\"{x:1346,y:732,t:1527268154698};\\\", \\\"{x:1346,y:731,t:1527268154714};\\\", \\\"{x:1346,y:730,t:1527268154727};\\\", \\\"{x:1345,y:728,t:1527268154770};\\\", \\\"{x:1345,y:727,t:1527268154842};\\\", \\\"{x:1344,y:726,t:1527268154931};\\\", \\\"{x:1344,y:725,t:1527268154947};\\\", \\\"{x:1344,y:724,t:1527268154961};\\\", \\\"{x:1343,y:722,t:1527268154978};\\\", \\\"{x:1343,y:720,t:1527268154994};\\\", \\\"{x:1343,y:715,t:1527268155011};\\\", \\\"{x:1343,y:705,t:1527268155027};\\\", \\\"{x:1343,y:701,t:1527268155044};\\\", \\\"{x:1343,y:694,t:1527268155061};\\\", \\\"{x:1343,y:685,t:1527268155076};\\\", \\\"{x:1343,y:679,t:1527268155093};\\\", \\\"{x:1343,y:673,t:1527268155111};\\\", \\\"{x:1343,y:668,t:1527268155127};\\\", \\\"{x:1343,y:663,t:1527268155144};\\\", \\\"{x:1343,y:660,t:1527268155160};\\\", \\\"{x:1343,y:655,t:1527268155177};\\\", \\\"{x:1343,y:648,t:1527268155194};\\\", \\\"{x:1343,y:639,t:1527268155210};\\\", \\\"{x:1343,y:633,t:1527268155226};\\\", \\\"{x:1343,y:628,t:1527268155243};\\\", \\\"{x:1343,y:625,t:1527268155261};\\\", \\\"{x:1342,y:623,t:1527268155277};\\\", \\\"{x:1342,y:622,t:1527268155293};\\\", \\\"{x:1342,y:621,t:1527268155309};\\\", \\\"{x:1341,y:619,t:1527268155326};\\\", \\\"{x:1341,y:618,t:1527268155344};\\\", \\\"{x:1341,y:617,t:1527268155360};\\\", \\\"{x:1341,y:616,t:1527268155377};\\\", \\\"{x:1340,y:614,t:1527268155394};\\\", \\\"{x:1340,y:613,t:1527268155410};\\\", \\\"{x:1340,y:611,t:1527268155426};\\\", \\\"{x:1339,y:608,t:1527268155443};\\\", \\\"{x:1339,y:603,t:1527268155460};\\\", \\\"{x:1339,y:596,t:1527268155476};\\\", \\\"{x:1339,y:587,t:1527268155493};\\\", \\\"{x:1339,y:581,t:1527268155509};\\\", \\\"{x:1337,y:574,t:1527268155527};\\\", \\\"{x:1337,y:569,t:1527268155544};\\\", \\\"{x:1337,y:565,t:1527268155560};\\\", \\\"{x:1337,y:559,t:1527268155577};\\\", \\\"{x:1337,y:555,t:1527268155594};\\\", \\\"{x:1337,y:551,t:1527268155610};\\\", \\\"{x:1337,y:547,t:1527268155626};\\\", \\\"{x:1336,y:545,t:1527268155642};\\\", \\\"{x:1336,y:544,t:1527268155660};\\\", \\\"{x:1336,y:543,t:1527268155677};\\\", \\\"{x:1336,y:542,t:1527268155692};\\\", \\\"{x:1335,y:542,t:1527268155850};\\\", \\\"{x:1333,y:543,t:1527268155860};\\\", \\\"{x:1330,y:550,t:1527268155877};\\\", \\\"{x:1322,y:563,t:1527268155893};\\\", \\\"{x:1311,y:578,t:1527268155910};\\\", \\\"{x:1295,y:596,t:1527268155926};\\\", \\\"{x:1275,y:615,t:1527268155942};\\\", \\\"{x:1228,y:646,t:1527268155959};\\\", \\\"{x:1162,y:673,t:1527268155976};\\\", \\\"{x:1088,y:691,t:1527268155992};\\\", \\\"{x:1006,y:697,t:1527268156009};\\\", \\\"{x:928,y:697,t:1527268156026};\\\", \\\"{x:839,y:697,t:1527268156042};\\\", \\\"{x:784,y:693,t:1527268156059};\\\", \\\"{x:737,y:689,t:1527268156075};\\\", \\\"{x:704,y:685,t:1527268156092};\\\", \\\"{x:674,y:685,t:1527268156109};\\\", \\\"{x:645,y:685,t:1527268156125};\\\", \\\"{x:626,y:684,t:1527268156142};\\\", \\\"{x:610,y:684,t:1527268156159};\\\", \\\"{x:600,y:684,t:1527268156175};\\\", \\\"{x:594,y:684,t:1527268156192};\\\", \\\"{x:593,y:685,t:1527268156209};\\\", \\\"{x:591,y:686,t:1527268156226};\\\", \\\"{x:590,y:686,t:1527268156251};\\\", \\\"{x:589,y:686,t:1527268156339};\\\", \\\"{x:587,y:684,t:1527268156354};\\\", \\\"{x:578,y:682,t:1527268156363};\\\", \\\"{x:569,y:678,t:1527268156376};\\\", \\\"{x:550,y:673,t:1527268156392};\\\", \\\"{x:526,y:670,t:1527268156408};\\\", \\\"{x:499,y:667,t:1527268156426};\\\", \\\"{x:465,y:662,t:1527268156442};\\\", \\\"{x:456,y:661,t:1527268156458};\\\", \\\"{x:454,y:659,t:1527268156476};\\\", \\\"{x:454,y:658,t:1527268156514};\\\", \\\"{x:454,y:657,t:1527268156526};\\\", \\\"{x:454,y:655,t:1527268156541};\\\", \\\"{x:455,y:651,t:1527268156558};\\\", \\\"{x:460,y:646,t:1527268156576};\\\", \\\"{x:477,y:641,t:1527268156591};\\\", \\\"{x:506,y:636,t:1527268156608};\\\", \\\"{x:567,y:630,t:1527268156631};\\\", \\\"{x:621,y:628,t:1527268156649};\\\", \\\"{x:685,y:628,t:1527268156664};\\\", \\\"{x:730,y:628,t:1527268156681};\\\", \\\"{x:788,y:626,t:1527268156698};\\\", \\\"{x:814,y:623,t:1527268156715};\\\", \\\"{x:833,y:619,t:1527268156731};\\\", \\\"{x:844,y:617,t:1527268156748};\\\", \\\"{x:846,y:616,t:1527268156764};\\\", \\\"{x:846,y:615,t:1527268156781};\\\", \\\"{x:845,y:615,t:1527268156851};\\\", \\\"{x:840,y:615,t:1527268156866};\\\", \\\"{x:817,y:616,t:1527268156881};\\\", \\\"{x:733,y:626,t:1527268156898};\\\", \\\"{x:645,y:634,t:1527268156916};\\\", \\\"{x:551,y:636,t:1527268156931};\\\", \\\"{x:472,y:638,t:1527268156947};\\\", \\\"{x:422,y:638,t:1527268156964};\\\", \\\"{x:394,y:638,t:1527268156981};\\\", \\\"{x:385,y:638,t:1527268156998};\\\", \\\"{x:383,y:639,t:1527268157163};\\\", \\\"{x:382,y:639,t:1527268157194};\\\", \\\"{x:381,y:640,t:1527268157202};\\\", \\\"{x:379,y:640,t:1527268157215};\\\", \\\"{x:365,y:641,t:1527268157232};\\\", \\\"{x:346,y:643,t:1527268157249};\\\", \\\"{x:322,y:646,t:1527268157265};\\\", \\\"{x:292,y:647,t:1527268157282};\\\", \\\"{x:279,y:647,t:1527268157298};\\\", \\\"{x:273,y:647,t:1527268157315};\\\", \\\"{x:270,y:647,t:1527268157333};\\\", \\\"{x:267,y:647,t:1527268157349};\\\", \\\"{x:261,y:647,t:1527268157365};\\\", \\\"{x:254,y:644,t:1527268157382};\\\", \\\"{x:243,y:640,t:1527268157398};\\\", \\\"{x:231,y:635,t:1527268157415};\\\", \\\"{x:220,y:630,t:1527268157432};\\\", \\\"{x:212,y:628,t:1527268157448};\\\", \\\"{x:209,y:626,t:1527268157466};\\\", \\\"{x:207,y:625,t:1527268157482};\\\", \\\"{x:205,y:625,t:1527268157522};\\\", \\\"{x:204,y:625,t:1527268157532};\\\", \\\"{x:198,y:623,t:1527268157548};\\\", \\\"{x:193,y:622,t:1527268157565};\\\", \\\"{x:187,y:622,t:1527268157583};\\\", \\\"{x:184,y:620,t:1527268157598};\\\", \\\"{x:183,y:618,t:1527268157616};\\\", \\\"{x:180,y:615,t:1527268157632};\\\", \\\"{x:178,y:612,t:1527268157650};\\\", \\\"{x:174,y:607,t:1527268157665};\\\", \\\"{x:166,y:600,t:1527268157682};\\\", \\\"{x:165,y:598,t:1527268157699};\\\", \\\"{x:164,y:595,t:1527268157715};\\\", \\\"{x:164,y:594,t:1527268157732};\\\", \\\"{x:163,y:594,t:1527268157749};\\\", \\\"{x:163,y:593,t:1527268157802};\\\", \\\"{x:163,y:592,t:1527268157834};\\\", \\\"{x:163,y:591,t:1527268157849};\\\", \\\"{x:162,y:591,t:1527268157865};\\\", \\\"{x:161,y:590,t:1527268157883};\\\", \\\"{x:161,y:588,t:1527268157899};\\\", \\\"{x:160,y:586,t:1527268157916};\\\", \\\"{x:160,y:585,t:1527268157933};\\\", \\\"{x:160,y:583,t:1527268157950};\\\", \\\"{x:159,y:581,t:1527268157965};\\\", \\\"{x:159,y:579,t:1527268157986};\\\", \\\"{x:159,y:578,t:1527268158002};\\\", \\\"{x:159,y:576,t:1527268158018};\\\", \\\"{x:159,y:574,t:1527268158033};\\\", \\\"{x:158,y:571,t:1527268158049};\\\", \\\"{x:158,y:568,t:1527268158066};\\\", \\\"{x:157,y:564,t:1527268158082};\\\", \\\"{x:157,y:562,t:1527268158099};\\\", \\\"{x:157,y:560,t:1527268158123};\\\", \\\"{x:157,y:559,t:1527268158154};\\\", \\\"{x:158,y:558,t:1527268158562};\\\", \\\"{x:162,y:560,t:1527268158570};\\\", \\\"{x:173,y:565,t:1527268158583};\\\", \\\"{x:203,y:578,t:1527268158599};\\\", \\\"{x:235,y:589,t:1527268158617};\\\", \\\"{x:288,y:603,t:1527268158634};\\\", \\\"{x:341,y:617,t:1527268158649};\\\", \\\"{x:414,y:639,t:1527268158666};\\\", \\\"{x:451,y:652,t:1527268158684};\\\", \\\"{x:474,y:657,t:1527268158699};\\\", \\\"{x:492,y:663,t:1527268158716};\\\", \\\"{x:498,y:663,t:1527268158733};\\\", \\\"{x:499,y:664,t:1527268158751};\\\", \\\"{x:501,y:664,t:1527268158843};\\\", \\\"{x:502,y:665,t:1527268158876};\\\", \\\"{x:502,y:667,t:1527268158883};\\\", \\\"{x:505,y:671,t:1527268158901};\\\", \\\"{x:505,y:675,t:1527268158917};\\\", \\\"{x:505,y:680,t:1527268158934};\\\", \\\"{x:505,y:685,t:1527268158950};\\\", \\\"{x:505,y:692,t:1527268158967};\\\", \\\"{x:506,y:697,t:1527268158984};\\\", \\\"{x:507,y:700,t:1527268159001};\\\", \\\"{x:508,y:701,t:1527268159116};\\\", \\\"{x:508,y:702,t:1527268159134};\\\", \\\"{x:509,y:703,t:1527268159150};\\\", \\\"{x:509,y:705,t:1527268159170};\\\", \\\"{x:509,y:706,t:1527268159683};\\\" ] }, { \\\"rt\\\": 53717, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 250102, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -U -U -U -A -F -Z -Z -Z -A -A -A -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:702,t:1527268161114};\\\", \\\"{x:510,y:696,t:1527268161122};\\\", \\\"{x:513,y:689,t:1527268161135};\\\", \\\"{x:519,y:672,t:1527268161151};\\\", \\\"{x:525,y:655,t:1527268161168};\\\", \\\"{x:530,y:639,t:1527268161186};\\\", \\\"{x:536,y:621,t:1527268161201};\\\", \\\"{x:549,y:583,t:1527268161218};\\\", \\\"{x:558,y:560,t:1527268161237};\\\", \\\"{x:565,y:544,t:1527268161251};\\\", \\\"{x:569,y:533,t:1527268161269};\\\", \\\"{x:570,y:523,t:1527268161285};\\\", \\\"{x:572,y:520,t:1527268161301};\\\", \\\"{x:573,y:517,t:1527268161318};\\\", \\\"{x:573,y:516,t:1527268161336};\\\", \\\"{x:573,y:515,t:1527268161362};\\\", \\\"{x:573,y:514,t:1527268161402};\\\", \\\"{x:573,y:513,t:1527268161418};\\\", \\\"{x:573,y:512,t:1527268161450};\\\", \\\"{x:572,y:511,t:1527268161547};\\\", \\\"{x:567,y:511,t:1527268161554};\\\", \\\"{x:563,y:511,t:1527268161569};\\\", \\\"{x:550,y:511,t:1527268161585};\\\", \\\"{x:546,y:511,t:1527268161602};\\\", \\\"{x:542,y:510,t:1527268161618};\\\", \\\"{x:540,y:510,t:1527268161635};\\\", \\\"{x:539,y:508,t:1527268161652};\\\", \\\"{x:538,y:508,t:1527268161668};\\\", \\\"{x:537,y:507,t:1527268161686};\\\", \\\"{x:536,y:507,t:1527268161701};\\\", \\\"{x:535,y:506,t:1527268161719};\\\", \\\"{x:535,y:505,t:1527268161736};\\\", \\\"{x:534,y:505,t:1527268161753};\\\", \\\"{x:533,y:504,t:1527268161770};\\\", \\\"{x:533,y:503,t:1527268161810};\\\", \\\"{x:532,y:503,t:1527268161819};\\\", \\\"{x:531,y:501,t:1527268161835};\\\", \\\"{x:530,y:499,t:1527268161853};\\\", \\\"{x:530,y:495,t:1527268161868};\\\", \\\"{x:530,y:491,t:1527268161886};\\\", \\\"{x:530,y:486,t:1527268161903};\\\", \\\"{x:530,y:482,t:1527268161919};\\\", \\\"{x:530,y:481,t:1527268161936};\\\", \\\"{x:530,y:479,t:1527268161953};\\\", \\\"{x:530,y:478,t:1527268161970};\\\", \\\"{x:530,y:477,t:1527268161986};\\\", \\\"{x:530,y:475,t:1527268162003};\\\", \\\"{x:530,y:474,t:1527268162187};\\\", \\\"{x:531,y:472,t:1527268162203};\\\", \\\"{x:533,y:472,t:1527268162220};\\\", \\\"{x:536,y:471,t:1527268162236};\\\", \\\"{x:541,y:470,t:1527268162253};\\\", \\\"{x:544,y:469,t:1527268162270};\\\", \\\"{x:550,y:469,t:1527268162286};\\\", \\\"{x:557,y:469,t:1527268162303};\\\", \\\"{x:568,y:469,t:1527268162320};\\\", \\\"{x:579,y:471,t:1527268162336};\\\", \\\"{x:595,y:473,t:1527268162352};\\\", \\\"{x:607,y:473,t:1527268162370};\\\", \\\"{x:618,y:473,t:1527268162386};\\\", \\\"{x:639,y:473,t:1527268162402};\\\", \\\"{x:654,y:473,t:1527268162420};\\\", \\\"{x:677,y:473,t:1527268162436};\\\", \\\"{x:707,y:472,t:1527268162453};\\\", \\\"{x:742,y:468,t:1527268162470};\\\", \\\"{x:778,y:468,t:1527268162486};\\\", \\\"{x:815,y:468,t:1527268162502};\\\", \\\"{x:851,y:468,t:1527268162520};\\\", \\\"{x:883,y:468,t:1527268162537};\\\", \\\"{x:912,y:470,t:1527268162552};\\\", \\\"{x:962,y:483,t:1527268162570};\\\", \\\"{x:991,y:493,t:1527268162586};\\\", \\\"{x:1016,y:498,t:1527268162603};\\\", \\\"{x:1039,y:501,t:1527268162619};\\\", \\\"{x:1063,y:505,t:1527268162637};\\\", \\\"{x:1082,y:508,t:1527268162652};\\\", \\\"{x:1104,y:508,t:1527268162669};\\\", \\\"{x:1123,y:511,t:1527268162686};\\\", \\\"{x:1140,y:514,t:1527268162702};\\\", \\\"{x:1148,y:516,t:1527268162719};\\\", \\\"{x:1158,y:519,t:1527268162736};\\\", \\\"{x:1165,y:523,t:1527268162753};\\\", \\\"{x:1178,y:531,t:1527268162769};\\\", \\\"{x:1199,y:545,t:1527268162785};\\\", \\\"{x:1218,y:559,t:1527268162802};\\\", \\\"{x:1238,y:571,t:1527268162819};\\\", \\\"{x:1260,y:584,t:1527268162836};\\\", \\\"{x:1279,y:595,t:1527268162853};\\\", \\\"{x:1295,y:602,t:1527268162870};\\\", \\\"{x:1311,y:610,t:1527268162887};\\\", \\\"{x:1321,y:613,t:1527268162902};\\\", \\\"{x:1329,y:615,t:1527268162920};\\\", \\\"{x:1336,y:617,t:1527268162937};\\\", \\\"{x:1342,y:619,t:1527268162954};\\\", \\\"{x:1343,y:619,t:1527268162970};\\\", \\\"{x:1345,y:621,t:1527268162987};\\\", \\\"{x:1350,y:624,t:1527268163004};\\\", \\\"{x:1357,y:630,t:1527268163020};\\\", \\\"{x:1370,y:641,t:1527268163037};\\\", \\\"{x:1388,y:656,t:1527268163054};\\\", \\\"{x:1406,y:672,t:1527268163070};\\\", \\\"{x:1422,y:685,t:1527268163086};\\\", \\\"{x:1433,y:696,t:1527268163103};\\\", \\\"{x:1438,y:702,t:1527268163119};\\\", \\\"{x:1442,y:706,t:1527268163136};\\\", \\\"{x:1442,y:708,t:1527268163154};\\\", \\\"{x:1443,y:709,t:1527268163170};\\\", \\\"{x:1444,y:709,t:1527268163210};\\\", \\\"{x:1444,y:711,t:1527268163226};\\\", \\\"{x:1444,y:713,t:1527268163237};\\\", \\\"{x:1440,y:717,t:1527268163253};\\\", \\\"{x:1429,y:724,t:1527268163270};\\\", \\\"{x:1422,y:732,t:1527268163287};\\\", \\\"{x:1410,y:751,t:1527268163303};\\\", \\\"{x:1399,y:774,t:1527268163320};\\\", \\\"{x:1394,y:786,t:1527268163337};\\\", \\\"{x:1394,y:792,t:1527268163354};\\\", \\\"{x:1392,y:799,t:1527268163370};\\\", \\\"{x:1392,y:802,t:1527268163387};\\\", \\\"{x:1392,y:803,t:1527268163434};\\\", \\\"{x:1392,y:804,t:1527268163483};\\\", \\\"{x:1393,y:805,t:1527268163499};\\\", \\\"{x:1394,y:807,t:1527268163507};\\\", \\\"{x:1394,y:809,t:1527268163521};\\\", \\\"{x:1399,y:814,t:1527268163537};\\\", \\\"{x:1406,y:829,t:1527268163554};\\\", \\\"{x:1408,y:835,t:1527268163571};\\\", \\\"{x:1411,y:842,t:1527268163587};\\\", \\\"{x:1413,y:848,t:1527268163604};\\\", \\\"{x:1414,y:851,t:1527268163622};\\\", \\\"{x:1415,y:852,t:1527268163637};\\\", \\\"{x:1415,y:854,t:1527268163666};\\\", \\\"{x:1416,y:854,t:1527268163690};\\\", \\\"{x:1417,y:855,t:1527268163704};\\\", \\\"{x:1418,y:856,t:1527268163730};\\\", \\\"{x:1418,y:857,t:1527268163746};\\\", \\\"{x:1418,y:858,t:1527268163755};\\\", \\\"{x:1419,y:861,t:1527268163771};\\\", \\\"{x:1419,y:864,t:1527268163787};\\\", \\\"{x:1419,y:870,t:1527268163803};\\\", \\\"{x:1419,y:876,t:1527268163821};\\\", \\\"{x:1419,y:881,t:1527268163838};\\\", \\\"{x:1419,y:885,t:1527268163853};\\\", \\\"{x:1419,y:886,t:1527268163870};\\\", \\\"{x:1420,y:887,t:1527268163979};\\\", \\\"{x:1421,y:887,t:1527268164028};\\\", \\\"{x:1423,y:888,t:1527268164038};\\\", \\\"{x:1429,y:890,t:1527268164055};\\\", \\\"{x:1436,y:893,t:1527268164071};\\\", \\\"{x:1447,y:897,t:1527268164088};\\\", \\\"{x:1460,y:900,t:1527268164105};\\\", \\\"{x:1467,y:902,t:1527268164121};\\\", \\\"{x:1474,y:902,t:1527268164139};\\\", \\\"{x:1476,y:902,t:1527268164154};\\\", \\\"{x:1479,y:902,t:1527268164171};\\\", \\\"{x:1482,y:901,t:1527268164188};\\\", \\\"{x:1486,y:900,t:1527268164205};\\\", \\\"{x:1490,y:899,t:1527268164221};\\\", \\\"{x:1493,y:898,t:1527268164238};\\\", \\\"{x:1494,y:897,t:1527268164255};\\\", \\\"{x:1496,y:897,t:1527268164274};\\\", \\\"{x:1497,y:897,t:1527268164323};\\\", \\\"{x:1499,y:897,t:1527268164338};\\\", \\\"{x:1501,y:897,t:1527268164353};\\\", \\\"{x:1502,y:897,t:1527268164506};\\\", \\\"{x:1503,y:897,t:1527268164521};\\\", \\\"{x:1503,y:898,t:1527268164538};\\\", \\\"{x:1505,y:900,t:1527268164554};\\\", \\\"{x:1506,y:902,t:1527268164571};\\\", \\\"{x:1508,y:906,t:1527268164588};\\\", \\\"{x:1510,y:910,t:1527268164605};\\\", \\\"{x:1510,y:912,t:1527268164621};\\\", \\\"{x:1511,y:912,t:1527268164683};\\\", \\\"{x:1512,y:912,t:1527268164691};\\\", \\\"{x:1512,y:911,t:1527268164739};\\\", \\\"{x:1510,y:911,t:1527268164755};\\\", \\\"{x:1505,y:910,t:1527268164772};\\\", \\\"{x:1501,y:909,t:1527268164788};\\\", \\\"{x:1496,y:909,t:1527268164805};\\\", \\\"{x:1490,y:909,t:1527268164822};\\\", \\\"{x:1484,y:909,t:1527268164838};\\\", \\\"{x:1478,y:909,t:1527268164855};\\\", \\\"{x:1471,y:909,t:1527268164872};\\\", \\\"{x:1463,y:909,t:1527268164888};\\\", \\\"{x:1459,y:909,t:1527268164905};\\\", \\\"{x:1453,y:908,t:1527268164923};\\\", \\\"{x:1451,y:907,t:1527268164939};\\\", \\\"{x:1448,y:905,t:1527268164955};\\\", \\\"{x:1446,y:903,t:1527268164972};\\\", \\\"{x:1445,y:903,t:1527268164988};\\\", \\\"{x:1445,y:902,t:1527268165010};\\\", \\\"{x:1444,y:902,t:1527268165091};\\\", \\\"{x:1443,y:901,t:1527268165147};\\\", \\\"{x:1443,y:900,t:1527268165171};\\\", \\\"{x:1443,y:898,t:1527268165187};\\\", \\\"{x:1443,y:896,t:1527268165195};\\\", \\\"{x:1446,y:894,t:1527268165205};\\\", \\\"{x:1449,y:891,t:1527268165222};\\\", \\\"{x:1454,y:889,t:1527268165239};\\\", \\\"{x:1460,y:885,t:1527268165255};\\\", \\\"{x:1464,y:883,t:1527268165273};\\\", \\\"{x:1465,y:882,t:1527268165290};\\\", \\\"{x:1467,y:882,t:1527268165305};\\\", \\\"{x:1468,y:882,t:1527268165322};\\\", \\\"{x:1472,y:882,t:1527268165338};\\\", \\\"{x:1476,y:883,t:1527268165355};\\\", \\\"{x:1487,y:885,t:1527268165372};\\\", \\\"{x:1497,y:885,t:1527268165389};\\\", \\\"{x:1508,y:885,t:1527268165405};\\\", \\\"{x:1525,y:885,t:1527268165422};\\\", \\\"{x:1545,y:880,t:1527268165439};\\\", \\\"{x:1565,y:876,t:1527268165455};\\\", \\\"{x:1584,y:871,t:1527268165472};\\\", \\\"{x:1601,y:869,t:1527268165489};\\\", \\\"{x:1611,y:869,t:1527268165506};\\\", \\\"{x:1615,y:869,t:1527268165522};\\\", \\\"{x:1618,y:869,t:1527268165539};\\\", \\\"{x:1619,y:869,t:1527268165556};\\\", \\\"{x:1620,y:871,t:1527268165572};\\\", \\\"{x:1622,y:876,t:1527268165589};\\\", \\\"{x:1624,y:880,t:1527268165606};\\\", \\\"{x:1625,y:885,t:1527268165622};\\\", \\\"{x:1626,y:887,t:1527268165639};\\\", \\\"{x:1626,y:888,t:1527268165691};\\\", \\\"{x:1627,y:888,t:1527268165706};\\\", \\\"{x:1628,y:889,t:1527268165787};\\\", \\\"{x:1628,y:891,t:1527268165803};\\\", \\\"{x:1628,y:895,t:1527268165819};\\\", \\\"{x:1628,y:897,t:1527268165827};\\\", \\\"{x:1628,y:900,t:1527268165839};\\\", \\\"{x:1627,y:906,t:1527268165856};\\\", \\\"{x:1624,y:914,t:1527268165872};\\\", \\\"{x:1623,y:919,t:1527268165890};\\\", \\\"{x:1623,y:921,t:1527268165906};\\\", \\\"{x:1624,y:921,t:1527268165987};\\\", \\\"{x:1624,y:920,t:1527268165995};\\\", \\\"{x:1624,y:918,t:1527268166006};\\\", \\\"{x:1624,y:915,t:1527268166022};\\\", \\\"{x:1623,y:910,t:1527268166039};\\\", \\\"{x:1623,y:904,t:1527268166056};\\\", \\\"{x:1622,y:897,t:1527268166073};\\\", \\\"{x:1621,y:892,t:1527268166089};\\\", \\\"{x:1620,y:881,t:1527268166106};\\\", \\\"{x:1620,y:872,t:1527268166123};\\\", \\\"{x:1620,y:856,t:1527268166139};\\\", \\\"{x:1620,y:839,t:1527268166156};\\\", \\\"{x:1620,y:823,t:1527268166173};\\\", \\\"{x:1620,y:809,t:1527268166190};\\\", \\\"{x:1620,y:799,t:1527268166206};\\\", \\\"{x:1620,y:791,t:1527268166223};\\\", \\\"{x:1620,y:779,t:1527268166240};\\\", \\\"{x:1619,y:769,t:1527268166257};\\\", \\\"{x:1618,y:761,t:1527268166273};\\\", \\\"{x:1616,y:751,t:1527268166289};\\\", \\\"{x:1614,y:738,t:1527268166306};\\\", \\\"{x:1611,y:732,t:1527268166322};\\\", \\\"{x:1609,y:727,t:1527268166340};\\\", \\\"{x:1607,y:720,t:1527268166356};\\\", \\\"{x:1606,y:714,t:1527268166373};\\\", \\\"{x:1603,y:709,t:1527268166390};\\\", \\\"{x:1602,y:705,t:1527268166406};\\\", \\\"{x:1602,y:702,t:1527268166423};\\\", \\\"{x:1602,y:699,t:1527268166440};\\\", \\\"{x:1602,y:696,t:1527268166456};\\\", \\\"{x:1600,y:692,t:1527268166474};\\\", \\\"{x:1600,y:691,t:1527268166490};\\\", \\\"{x:1600,y:688,t:1527268166507};\\\", \\\"{x:1600,y:686,t:1527268166522};\\\", \\\"{x:1600,y:685,t:1527268166546};\\\", \\\"{x:1600,y:684,t:1527268166556};\\\", \\\"{x:1600,y:683,t:1527268166573};\\\", \\\"{x:1600,y:685,t:1527268166730};\\\", \\\"{x:1600,y:690,t:1527268166740};\\\", \\\"{x:1602,y:699,t:1527268166755};\\\", \\\"{x:1604,y:703,t:1527268166773};\\\", \\\"{x:1604,y:705,t:1527268166789};\\\", \\\"{x:1604,y:701,t:1527268166908};\\\", \\\"{x:1604,y:687,t:1527268166923};\\\", \\\"{x:1604,y:673,t:1527268166941};\\\", \\\"{x:1604,y:658,t:1527268166957};\\\", \\\"{x:1604,y:647,t:1527268166974};\\\", \\\"{x:1603,y:638,t:1527268166990};\\\", \\\"{x:1602,y:631,t:1527268167007};\\\", \\\"{x:1602,y:625,t:1527268167023};\\\", \\\"{x:1602,y:619,t:1527268167041};\\\", \\\"{x:1602,y:612,t:1527268167057};\\\", \\\"{x:1602,y:605,t:1527268167074};\\\", \\\"{x:1602,y:597,t:1527268167089};\\\", \\\"{x:1602,y:592,t:1527268167107};\\\", \\\"{x:1602,y:590,t:1527268167122};\\\", \\\"{x:1602,y:588,t:1527268167140};\\\", \\\"{x:1602,y:587,t:1527268167157};\\\", \\\"{x:1602,y:586,t:1527268167178};\\\", \\\"{x:1602,y:585,t:1527268167194};\\\", \\\"{x:1602,y:584,t:1527268167206};\\\", \\\"{x:1602,y:583,t:1527268167223};\\\", \\\"{x:1602,y:581,t:1527268167240};\\\", \\\"{x:1602,y:580,t:1527268167259};\\\", \\\"{x:1602,y:579,t:1527268167274};\\\", \\\"{x:1602,y:578,t:1527268167315};\\\", \\\"{x:1602,y:577,t:1527268167418};\\\", \\\"{x:1602,y:578,t:1527268167674};\\\", \\\"{x:1602,y:583,t:1527268167690};\\\", \\\"{x:1602,y:587,t:1527268167707};\\\", \\\"{x:1602,y:590,t:1527268167725};\\\", \\\"{x:1602,y:594,t:1527268167741};\\\", \\\"{x:1603,y:597,t:1527268167757};\\\", \\\"{x:1603,y:602,t:1527268167774};\\\", \\\"{x:1603,y:605,t:1527268167791};\\\", \\\"{x:1603,y:609,t:1527268167807};\\\", \\\"{x:1604,y:612,t:1527268167824};\\\", \\\"{x:1604,y:615,t:1527268167841};\\\", \\\"{x:1604,y:617,t:1527268167857};\\\", \\\"{x:1604,y:621,t:1527268167874};\\\", \\\"{x:1607,y:625,t:1527268167890};\\\", \\\"{x:1607,y:627,t:1527268167908};\\\", \\\"{x:1607,y:630,t:1527268167924};\\\", \\\"{x:1608,y:636,t:1527268167941};\\\", \\\"{x:1608,y:640,t:1527268167957};\\\", \\\"{x:1609,y:646,t:1527268167974};\\\", \\\"{x:1609,y:652,t:1527268167991};\\\", \\\"{x:1611,y:656,t:1527268168007};\\\", \\\"{x:1611,y:659,t:1527268168024};\\\", \\\"{x:1611,y:663,t:1527268168041};\\\", \\\"{x:1613,y:671,t:1527268168057};\\\", \\\"{x:1615,y:683,t:1527268168074};\\\", \\\"{x:1616,y:694,t:1527268168090};\\\", \\\"{x:1618,y:703,t:1527268168108};\\\", \\\"{x:1618,y:710,t:1527268168125};\\\", \\\"{x:1620,y:718,t:1527268168141};\\\", \\\"{x:1620,y:723,t:1527268168157};\\\", \\\"{x:1621,y:727,t:1527268168174};\\\", \\\"{x:1621,y:731,t:1527268168191};\\\", \\\"{x:1622,y:734,t:1527268168208};\\\", \\\"{x:1622,y:736,t:1527268168223};\\\", \\\"{x:1623,y:740,t:1527268168241};\\\", \\\"{x:1623,y:747,t:1527268168258};\\\", \\\"{x:1623,y:752,t:1527268168274};\\\", \\\"{x:1623,y:756,t:1527268168291};\\\", \\\"{x:1624,y:761,t:1527268168307};\\\", \\\"{x:1624,y:763,t:1527268168324};\\\", \\\"{x:1624,y:767,t:1527268168341};\\\", \\\"{x:1624,y:773,t:1527268168358};\\\", \\\"{x:1624,y:777,t:1527268168374};\\\", \\\"{x:1624,y:782,t:1527268168391};\\\", \\\"{x:1623,y:788,t:1527268168407};\\\", \\\"{x:1623,y:792,t:1527268168424};\\\", \\\"{x:1622,y:796,t:1527268168441};\\\", \\\"{x:1620,y:804,t:1527268168458};\\\", \\\"{x:1620,y:810,t:1527268168474};\\\", \\\"{x:1620,y:816,t:1527268168490};\\\", \\\"{x:1620,y:822,t:1527268168508};\\\", \\\"{x:1620,y:827,t:1527268168524};\\\", \\\"{x:1620,y:833,t:1527268168541};\\\", \\\"{x:1620,y:838,t:1527268168558};\\\", \\\"{x:1620,y:845,t:1527268168574};\\\", \\\"{x:1620,y:855,t:1527268168591};\\\", \\\"{x:1620,y:862,t:1527268168608};\\\", \\\"{x:1620,y:867,t:1527268168625};\\\", \\\"{x:1620,y:873,t:1527268168640};\\\", \\\"{x:1620,y:881,t:1527268168658};\\\", \\\"{x:1620,y:889,t:1527268168674};\\\", \\\"{x:1620,y:894,t:1527268168691};\\\", \\\"{x:1620,y:900,t:1527268168708};\\\", \\\"{x:1620,y:904,t:1527268168726};\\\", \\\"{x:1620,y:906,t:1527268168741};\\\", \\\"{x:1620,y:909,t:1527268168758};\\\", \\\"{x:1620,y:913,t:1527268168775};\\\", \\\"{x:1620,y:915,t:1527268168791};\\\", \\\"{x:1619,y:920,t:1527268168808};\\\", \\\"{x:1618,y:922,t:1527268168825};\\\", \\\"{x:1618,y:925,t:1527268168841};\\\", \\\"{x:1617,y:929,t:1527268168858};\\\", \\\"{x:1617,y:931,t:1527268168875};\\\", \\\"{x:1617,y:932,t:1527268168891};\\\", \\\"{x:1617,y:934,t:1527268168908};\\\", \\\"{x:1617,y:935,t:1527268168926};\\\", \\\"{x:1617,y:936,t:1527268168941};\\\", \\\"{x:1617,y:937,t:1527268168958};\\\", \\\"{x:1617,y:938,t:1527268168979};\\\", \\\"{x:1616,y:939,t:1527268168991};\\\", \\\"{x:1616,y:940,t:1527268169008};\\\", \\\"{x:1616,y:942,t:1527268169025};\\\", \\\"{x:1616,y:943,t:1527268169042};\\\", \\\"{x:1616,y:944,t:1527268169090};\\\", \\\"{x:1616,y:945,t:1527268169115};\\\", \\\"{x:1616,y:946,t:1527268169130};\\\", \\\"{x:1615,y:946,t:1527268169142};\\\", \\\"{x:1615,y:947,t:1527268169203};\\\", \\\"{x:1615,y:948,t:1527268169227};\\\", \\\"{x:1615,y:949,t:1527268169243};\\\", \\\"{x:1615,y:950,t:1527268169291};\\\", \\\"{x:1615,y:951,t:1527268169299};\\\", \\\"{x:1615,y:952,t:1527268169308};\\\", \\\"{x:1615,y:953,t:1527268169338};\\\", \\\"{x:1615,y:954,t:1527268169354};\\\", \\\"{x:1615,y:955,t:1527268169379};\\\", \\\"{x:1615,y:956,t:1527268169451};\\\", \\\"{x:1615,y:957,t:1527268169554};\\\", \\\"{x:1615,y:958,t:1527268170099};\\\", \\\"{x:1615,y:959,t:1527268170130};\\\", \\\"{x:1614,y:959,t:1527268170178};\\\", \\\"{x:1613,y:959,t:1527268170191};\\\", \\\"{x:1612,y:959,t:1527268170209};\\\", \\\"{x:1595,y:959,t:1527268170226};\\\", \\\"{x:1576,y:959,t:1527268170242};\\\", \\\"{x:1560,y:959,t:1527268170258};\\\", \\\"{x:1550,y:959,t:1527268170275};\\\", \\\"{x:1543,y:959,t:1527268170291};\\\", \\\"{x:1542,y:959,t:1527268170308};\\\", \\\"{x:1540,y:960,t:1527268170326};\\\", \\\"{x:1540,y:961,t:1527268170343};\\\", \\\"{x:1539,y:962,t:1527268170359};\\\", \\\"{x:1536,y:962,t:1527268170375};\\\", \\\"{x:1531,y:962,t:1527268170393};\\\", \\\"{x:1526,y:962,t:1527268170408};\\\", \\\"{x:1520,y:962,t:1527268170426};\\\", \\\"{x:1516,y:962,t:1527268170443};\\\", \\\"{x:1512,y:962,t:1527268170458};\\\", \\\"{x:1507,y:961,t:1527268170475};\\\", \\\"{x:1504,y:961,t:1527268170493};\\\", \\\"{x:1501,y:961,t:1527268170509};\\\", \\\"{x:1499,y:961,t:1527268170525};\\\", \\\"{x:1498,y:961,t:1527268170542};\\\", \\\"{x:1497,y:961,t:1527268170558};\\\", \\\"{x:1494,y:961,t:1527268170576};\\\", \\\"{x:1492,y:961,t:1527268170593};\\\", \\\"{x:1491,y:961,t:1527268170609};\\\", \\\"{x:1489,y:961,t:1527268170625};\\\", \\\"{x:1488,y:961,t:1527268170643};\\\", \\\"{x:1487,y:960,t:1527268170698};\\\", \\\"{x:1487,y:959,t:1527268170867};\\\", \\\"{x:1487,y:958,t:1527268170891};\\\", \\\"{x:1487,y:957,t:1527268170899};\\\", \\\"{x:1487,y:956,t:1527268170910};\\\", \\\"{x:1486,y:952,t:1527268170927};\\\", \\\"{x:1486,y:947,t:1527268170944};\\\", \\\"{x:1484,y:938,t:1527268170960};\\\", \\\"{x:1483,y:930,t:1527268170976};\\\", \\\"{x:1480,y:922,t:1527268170993};\\\", \\\"{x:1478,y:908,t:1527268171010};\\\", \\\"{x:1478,y:903,t:1527268171026};\\\", \\\"{x:1478,y:898,t:1527268171044};\\\", \\\"{x:1478,y:896,t:1527268171061};\\\", \\\"{x:1478,y:893,t:1527268171077};\\\", \\\"{x:1477,y:889,t:1527268171093};\\\", \\\"{x:1477,y:886,t:1527268171110};\\\", \\\"{x:1477,y:880,t:1527268171126};\\\", \\\"{x:1477,y:871,t:1527268171143};\\\", \\\"{x:1477,y:863,t:1527268171160};\\\", \\\"{x:1477,y:858,t:1527268171176};\\\", \\\"{x:1477,y:854,t:1527268171193};\\\", \\\"{x:1477,y:849,t:1527268171210};\\\", \\\"{x:1477,y:848,t:1527268171226};\\\", \\\"{x:1477,y:846,t:1527268171243};\\\", \\\"{x:1477,y:844,t:1527268171260};\\\", \\\"{x:1477,y:843,t:1527268171278};\\\", \\\"{x:1477,y:841,t:1527268171293};\\\", \\\"{x:1476,y:839,t:1527268171310};\\\", \\\"{x:1475,y:839,t:1527268171327};\\\", \\\"{x:1475,y:836,t:1527268171343};\\\", \\\"{x:1475,y:834,t:1527268171360};\\\", \\\"{x:1475,y:829,t:1527268171378};\\\", \\\"{x:1476,y:822,t:1527268171394};\\\", \\\"{x:1478,y:812,t:1527268171411};\\\", \\\"{x:1478,y:809,t:1527268171428};\\\", \\\"{x:1478,y:806,t:1527268171444};\\\", \\\"{x:1478,y:805,t:1527268171461};\\\", \\\"{x:1479,y:804,t:1527268171659};\\\", \\\"{x:1480,y:804,t:1527268171691};\\\", \\\"{x:1481,y:804,t:1527268171731};\\\", \\\"{x:1481,y:805,t:1527268171745};\\\", \\\"{x:1484,y:809,t:1527268171760};\\\", \\\"{x:1484,y:814,t:1527268171778};\\\", \\\"{x:1487,y:827,t:1527268171795};\\\", \\\"{x:1488,y:836,t:1527268171810};\\\", \\\"{x:1488,y:839,t:1527268171827};\\\", \\\"{x:1488,y:841,t:1527268171845};\\\", \\\"{x:1488,y:843,t:1527268172028};\\\", \\\"{x:1488,y:845,t:1527268172045};\\\", \\\"{x:1488,y:847,t:1527268172060};\\\", \\\"{x:1488,y:848,t:1527268172078};\\\", \\\"{x:1488,y:849,t:1527268172274};\\\", \\\"{x:1487,y:850,t:1527268172290};\\\", \\\"{x:1487,y:851,t:1527268172322};\\\", \\\"{x:1485,y:850,t:1527268172427};\\\", \\\"{x:1485,y:849,t:1527268172835};\\\", \\\"{x:1485,y:848,t:1527268172845};\\\", \\\"{x:1485,y:847,t:1527268172861};\\\", \\\"{x:1485,y:845,t:1527268172878};\\\", \\\"{x:1485,y:842,t:1527268172894};\\\", \\\"{x:1485,y:841,t:1527268172911};\\\", \\\"{x:1485,y:839,t:1527268172928};\\\", \\\"{x:1485,y:838,t:1527268172945};\\\", \\\"{x:1485,y:836,t:1527268172962};\\\", \\\"{x:1485,y:834,t:1527268173092};\\\", \\\"{x:1485,y:833,t:1527268173111};\\\", \\\"{x:1485,y:831,t:1527268173127};\\\", \\\"{x:1485,y:830,t:1527268173144};\\\", \\\"{x:1485,y:829,t:1527268173161};\\\", \\\"{x:1485,y:828,t:1527268173178};\\\", \\\"{x:1485,y:827,t:1527268173194};\\\", \\\"{x:1485,y:828,t:1527268173539};\\\", \\\"{x:1485,y:829,t:1527268173554};\\\", \\\"{x:1486,y:829,t:1527268173627};\\\", \\\"{x:1487,y:829,t:1527268173677};\\\", \\\"{x:1489,y:830,t:1527268173699};\\\", \\\"{x:1490,y:830,t:1527268173712};\\\", \\\"{x:1495,y:832,t:1527268173729};\\\", \\\"{x:1510,y:835,t:1527268173745};\\\", \\\"{x:1542,y:845,t:1527268173762};\\\", \\\"{x:1564,y:850,t:1527268173778};\\\", \\\"{x:1577,y:851,t:1527268173795};\\\", \\\"{x:1589,y:851,t:1527268173811};\\\", \\\"{x:1593,y:851,t:1527268173828};\\\", \\\"{x:1596,y:850,t:1527268173844};\\\", \\\"{x:1598,y:848,t:1527268173862};\\\", \\\"{x:1598,y:846,t:1527268173878};\\\", \\\"{x:1598,y:845,t:1527268173895};\\\", \\\"{x:1599,y:844,t:1527268173912};\\\", \\\"{x:1599,y:842,t:1527268173930};\\\", \\\"{x:1600,y:842,t:1527268173945};\\\", \\\"{x:1601,y:840,t:1527268173962};\\\", \\\"{x:1603,y:840,t:1527268174035};\\\", \\\"{x:1604,y:840,t:1527268174139};\\\", \\\"{x:1604,y:839,t:1527268174171};\\\", \\\"{x:1604,y:840,t:1527268174283};\\\", \\\"{x:1602,y:841,t:1527268174296};\\\", \\\"{x:1595,y:841,t:1527268174312};\\\", \\\"{x:1588,y:841,t:1527268174329};\\\", \\\"{x:1579,y:841,t:1527268174346};\\\", \\\"{x:1572,y:841,t:1527268174363};\\\", \\\"{x:1565,y:841,t:1527268174379};\\\", \\\"{x:1554,y:841,t:1527268174396};\\\", \\\"{x:1537,y:841,t:1527268174413};\\\", \\\"{x:1518,y:841,t:1527268174430};\\\", \\\"{x:1502,y:841,t:1527268174447};\\\", \\\"{x:1487,y:841,t:1527268174463};\\\", \\\"{x:1475,y:841,t:1527268174479};\\\", \\\"{x:1469,y:842,t:1527268174497};\\\", \\\"{x:1464,y:844,t:1527268174513};\\\", \\\"{x:1462,y:845,t:1527268174529};\\\", \\\"{x:1459,y:846,t:1527268174546};\\\", \\\"{x:1458,y:846,t:1527268174611};\\\", \\\"{x:1458,y:847,t:1527268174803};\\\", \\\"{x:1458,y:848,t:1527268174955};\\\", \\\"{x:1458,y:850,t:1527268175003};\\\", \\\"{x:1458,y:851,t:1527268175013};\\\", \\\"{x:1458,y:854,t:1527268175030};\\\", \\\"{x:1458,y:856,t:1527268175047};\\\", \\\"{x:1458,y:858,t:1527268175063};\\\", \\\"{x:1458,y:859,t:1527268175079};\\\", \\\"{x:1458,y:861,t:1527268175096};\\\", \\\"{x:1460,y:861,t:1527268175154};\\\", \\\"{x:1460,y:863,t:1527268175194};\\\", \\\"{x:1460,y:864,t:1527268175210};\\\", \\\"{x:1462,y:868,t:1527268175218};\\\", \\\"{x:1462,y:870,t:1527268175234};\\\", \\\"{x:1462,y:871,t:1527268175246};\\\", \\\"{x:1463,y:877,t:1527268175263};\\\", \\\"{x:1463,y:882,t:1527268175280};\\\", \\\"{x:1464,y:886,t:1527268175296};\\\", \\\"{x:1464,y:890,t:1527268175313};\\\", \\\"{x:1465,y:892,t:1527268175330};\\\", \\\"{x:1465,y:893,t:1527268175346};\\\", \\\"{x:1466,y:893,t:1527268175427};\\\", \\\"{x:1467,y:894,t:1527268175451};\\\", \\\"{x:1467,y:895,t:1527268175482};\\\", \\\"{x:1467,y:896,t:1527268175499};\\\", \\\"{x:1467,y:898,t:1527268175514};\\\", \\\"{x:1467,y:903,t:1527268175531};\\\", \\\"{x:1469,y:905,t:1527268175547};\\\", \\\"{x:1469,y:906,t:1527268175564};\\\", \\\"{x:1470,y:906,t:1527268175667};\\\", \\\"{x:1470,y:905,t:1527268175698};\\\", \\\"{x:1471,y:904,t:1527268175713};\\\", \\\"{x:1472,y:903,t:1527268175731};\\\", \\\"{x:1472,y:902,t:1527268175763};\\\", \\\"{x:1472,y:901,t:1527268175780};\\\", \\\"{x:1472,y:900,t:1527268175798};\\\", \\\"{x:1472,y:898,t:1527268175814};\\\", \\\"{x:1472,y:894,t:1527268175831};\\\", \\\"{x:1472,y:890,t:1527268175847};\\\", \\\"{x:1472,y:884,t:1527268175863};\\\", \\\"{x:1472,y:879,t:1527268175880};\\\", \\\"{x:1474,y:874,t:1527268175898};\\\", \\\"{x:1477,y:866,t:1527268175913};\\\", \\\"{x:1480,y:859,t:1527268175930};\\\", \\\"{x:1481,y:854,t:1527268175947};\\\", \\\"{x:1481,y:849,t:1527268175964};\\\", \\\"{x:1484,y:842,t:1527268175981};\\\", \\\"{x:1485,y:838,t:1527268175998};\\\", \\\"{x:1485,y:836,t:1527268176014};\\\", \\\"{x:1485,y:835,t:1527268176034};\\\", \\\"{x:1485,y:834,t:1527268176083};\\\", \\\"{x:1485,y:833,t:1527268176098};\\\", \\\"{x:1485,y:832,t:1527268176115};\\\", \\\"{x:1485,y:831,t:1527268176131};\\\", \\\"{x:1485,y:830,t:1527268176148};\\\", \\\"{x:1485,y:829,t:1527268176170};\\\", \\\"{x:1485,y:828,t:1527268176379};\\\", \\\"{x:1486,y:828,t:1527268176403};\\\", \\\"{x:1486,y:827,t:1527268176414};\\\", \\\"{x:1486,y:826,t:1527268176435};\\\", \\\"{x:1487,y:826,t:1527268176451};\\\", \\\"{x:1488,y:826,t:1527268176473};\\\", \\\"{x:1490,y:826,t:1527268176482};\\\", \\\"{x:1493,y:826,t:1527268176497};\\\", \\\"{x:1513,y:826,t:1527268176513};\\\", \\\"{x:1531,y:828,t:1527268176531};\\\", \\\"{x:1552,y:832,t:1527268176547};\\\", \\\"{x:1568,y:834,t:1527268176564};\\\", \\\"{x:1578,y:834,t:1527268176581};\\\", \\\"{x:1583,y:834,t:1527268176597};\\\", \\\"{x:1584,y:834,t:1527268176614};\\\", \\\"{x:1586,y:834,t:1527268176631};\\\", \\\"{x:1587,y:834,t:1527268176650};\\\", \\\"{x:1588,y:833,t:1527268176674};\\\", \\\"{x:1590,y:833,t:1527268176842};\\\", \\\"{x:1591,y:832,t:1527268176858};\\\", \\\"{x:1593,y:832,t:1527268176882};\\\", \\\"{x:1595,y:831,t:1527268176898};\\\", \\\"{x:1595,y:830,t:1527268176915};\\\", \\\"{x:1596,y:830,t:1527268177002};\\\", \\\"{x:1597,y:830,t:1527268177015};\\\", \\\"{x:1598,y:830,t:1527268177091};\\\", \\\"{x:1599,y:830,t:1527268177154};\\\", \\\"{x:1600,y:830,t:1527268177331};\\\", \\\"{x:1601,y:830,t:1527268177467};\\\", \\\"{x:1602,y:830,t:1527268177659};\\\", \\\"{x:1603,y:830,t:1527268177690};\\\", \\\"{x:1604,y:830,t:1527268177747};\\\", \\\"{x:1605,y:830,t:1527268177771};\\\", \\\"{x:1606,y:830,t:1527268177803};\\\", \\\"{x:1607,y:830,t:1527268177842};\\\", \\\"{x:1606,y:830,t:1527268178059};\\\", \\\"{x:1596,y:830,t:1527268178067};\\\", \\\"{x:1576,y:830,t:1527268178082};\\\", \\\"{x:1547,y:830,t:1527268178099};\\\", \\\"{x:1523,y:829,t:1527268178116};\\\", \\\"{x:1505,y:827,t:1527268178133};\\\", \\\"{x:1499,y:825,t:1527268178149};\\\", \\\"{x:1497,y:825,t:1527268178166};\\\", \\\"{x:1496,y:825,t:1527268178443};\\\", \\\"{x:1494,y:825,t:1527268178450};\\\", \\\"{x:1492,y:825,t:1527268178466};\\\", \\\"{x:1484,y:825,t:1527268178483};\\\", \\\"{x:1477,y:825,t:1527268178501};\\\", \\\"{x:1468,y:825,t:1527268178515};\\\", \\\"{x:1459,y:825,t:1527268178532};\\\", \\\"{x:1445,y:825,t:1527268178549};\\\", \\\"{x:1428,y:825,t:1527268178566};\\\", \\\"{x:1398,y:822,t:1527268178582};\\\", \\\"{x:1348,y:815,t:1527268178600};\\\", \\\"{x:1262,y:802,t:1527268178615};\\\", \\\"{x:1153,y:786,t:1527268178632};\\\", \\\"{x:1028,y:767,t:1527268178649};\\\", \\\"{x:890,y:746,t:1527268178665};\\\", \\\"{x:702,y:717,t:1527268178682};\\\", \\\"{x:591,y:699,t:1527268178699};\\\", \\\"{x:511,y:678,t:1527268178716};\\\", \\\"{x:477,y:671,t:1527268178732};\\\", \\\"{x:464,y:666,t:1527268178750};\\\", \\\"{x:458,y:662,t:1527268178767};\\\", \\\"{x:455,y:654,t:1527268178782};\\\", \\\"{x:453,y:649,t:1527268178801};\\\", \\\"{x:451,y:643,t:1527268178816};\\\", \\\"{x:448,y:638,t:1527268178832};\\\", \\\"{x:444,y:633,t:1527268178849};\\\", \\\"{x:441,y:626,t:1527268178865};\\\", \\\"{x:438,y:618,t:1527268178884};\\\", \\\"{x:435,y:610,t:1527268178900};\\\", \\\"{x:432,y:602,t:1527268178915};\\\", \\\"{x:430,y:597,t:1527268178932};\\\", \\\"{x:429,y:594,t:1527268178949};\\\", \\\"{x:428,y:593,t:1527268178966};\\\", \\\"{x:428,y:592,t:1527268178994};\\\", \\\"{x:427,y:592,t:1527268179042};\\\", \\\"{x:427,y:590,t:1527268179050};\\\", \\\"{x:435,y:589,t:1527268179066};\\\", \\\"{x:449,y:586,t:1527268179083};\\\", \\\"{x:474,y:585,t:1527268179099};\\\", \\\"{x:507,y:580,t:1527268179117};\\\", \\\"{x:538,y:578,t:1527268179133};\\\", \\\"{x:568,y:578,t:1527268179149};\\\", \\\"{x:591,y:578,t:1527268179166};\\\", \\\"{x:607,y:578,t:1527268179183};\\\", \\\"{x:613,y:578,t:1527268179199};\\\", \\\"{x:616,y:578,t:1527268179216};\\\", \\\"{x:617,y:578,t:1527268179242};\\\", \\\"{x:618,y:579,t:1527268179258};\\\", \\\"{x:619,y:581,t:1527268179267};\\\", \\\"{x:622,y:587,t:1527268179285};\\\", \\\"{x:624,y:594,t:1527268179300};\\\", \\\"{x:629,y:604,t:1527268179316};\\\", \\\"{x:632,y:611,t:1527268179333};\\\", \\\"{x:634,y:615,t:1527268179349};\\\", \\\"{x:634,y:616,t:1527268179490};\\\", \\\"{x:634,y:615,t:1527268179595};\\\", \\\"{x:632,y:613,t:1527268179603};\\\", \\\"{x:628,y:610,t:1527268179618};\\\", \\\"{x:624,y:603,t:1527268179633};\\\", \\\"{x:617,y:595,t:1527268179649};\\\", \\\"{x:617,y:594,t:1527268179673};\\\", \\\"{x:621,y:594,t:1527268180146};\\\", \\\"{x:629,y:594,t:1527268180154};\\\", \\\"{x:637,y:599,t:1527268180168};\\\", \\\"{x:660,y:603,t:1527268180183};\\\", \\\"{x:685,y:609,t:1527268180200};\\\", \\\"{x:709,y:615,t:1527268180218};\\\", \\\"{x:752,y:628,t:1527268180234};\\\", \\\"{x:797,y:641,t:1527268180250};\\\", \\\"{x:845,y:657,t:1527268180268};\\\", \\\"{x:902,y:677,t:1527268180284};\\\", \\\"{x:959,y:699,t:1527268180300};\\\", \\\"{x:1019,y:721,t:1527268180318};\\\", \\\"{x:1071,y:744,t:1527268180333};\\\", \\\"{x:1118,y:763,t:1527268180350};\\\", \\\"{x:1159,y:780,t:1527268180368};\\\", \\\"{x:1185,y:790,t:1527268180383};\\\", \\\"{x:1208,y:797,t:1527268180400};\\\", \\\"{x:1239,y:807,t:1527268180417};\\\", \\\"{x:1255,y:813,t:1527268180433};\\\", \\\"{x:1266,y:819,t:1527268180450};\\\", \\\"{x:1282,y:828,t:1527268180468};\\\", \\\"{x:1296,y:835,t:1527268180485};\\\", \\\"{x:1309,y:843,t:1527268180500};\\\", \\\"{x:1318,y:849,t:1527268180518};\\\", \\\"{x:1329,y:855,t:1527268180534};\\\", \\\"{x:1337,y:859,t:1527268180551};\\\", \\\"{x:1342,y:863,t:1527268180567};\\\", \\\"{x:1345,y:864,t:1527268180584};\\\", \\\"{x:1348,y:866,t:1527268180600};\\\", \\\"{x:1353,y:867,t:1527268180617};\\\", \\\"{x:1355,y:867,t:1527268180634};\\\", \\\"{x:1373,y:868,t:1527268180651};\\\", \\\"{x:1394,y:868,t:1527268180667};\\\", \\\"{x:1416,y:868,t:1527268180684};\\\", \\\"{x:1432,y:868,t:1527268180700};\\\", \\\"{x:1450,y:868,t:1527268180718};\\\", \\\"{x:1457,y:868,t:1527268180734};\\\", \\\"{x:1460,y:868,t:1527268180751};\\\", \\\"{x:1461,y:868,t:1527268180768};\\\", \\\"{x:1462,y:868,t:1527268180785};\\\", \\\"{x:1463,y:866,t:1527268180907};\\\", \\\"{x:1463,y:865,t:1527268180917};\\\", \\\"{x:1460,y:858,t:1527268180934};\\\", \\\"{x:1456,y:856,t:1527268180950};\\\", \\\"{x:1454,y:855,t:1527268180967};\\\", \\\"{x:1454,y:854,t:1527268180985};\\\", \\\"{x:1453,y:854,t:1527268181000};\\\", \\\"{x:1453,y:853,t:1527268181017};\\\", \\\"{x:1453,y:852,t:1527268181034};\\\", \\\"{x:1452,y:852,t:1527268181050};\\\", \\\"{x:1451,y:851,t:1527268181082};\\\", \\\"{x:1451,y:850,t:1527268181090};\\\", \\\"{x:1450,y:849,t:1527268181101};\\\", \\\"{x:1448,y:847,t:1527268181117};\\\", \\\"{x:1443,y:841,t:1527268181134};\\\", \\\"{x:1436,y:832,t:1527268181151};\\\", \\\"{x:1427,y:821,t:1527268181167};\\\", \\\"{x:1416,y:811,t:1527268181184};\\\", \\\"{x:1407,y:805,t:1527268181201};\\\", \\\"{x:1403,y:802,t:1527268181218};\\\", \\\"{x:1398,y:799,t:1527268181235};\\\", \\\"{x:1397,y:798,t:1527268181251};\\\", \\\"{x:1396,y:798,t:1527268181268};\\\", \\\"{x:1396,y:797,t:1527268181284};\\\", \\\"{x:1395,y:796,t:1527268181302};\\\", \\\"{x:1394,y:796,t:1527268181318};\\\", \\\"{x:1394,y:795,t:1527268181346};\\\", \\\"{x:1393,y:795,t:1527268181370};\\\", \\\"{x:1393,y:793,t:1527268181402};\\\", \\\"{x:1392,y:792,t:1527268181418};\\\", \\\"{x:1390,y:789,t:1527268181434};\\\", \\\"{x:1389,y:788,t:1527268181452};\\\", \\\"{x:1389,y:787,t:1527268181473};\\\", \\\"{x:1389,y:786,t:1527268181490};\\\", \\\"{x:1388,y:785,t:1527268181594};\\\", \\\"{x:1388,y:784,t:1527268181642};\\\", \\\"{x:1388,y:783,t:1527268181657};\\\", \\\"{x:1388,y:782,t:1527268181667};\\\", \\\"{x:1386,y:780,t:1527268181684};\\\", \\\"{x:1386,y:779,t:1527268181702};\\\", \\\"{x:1385,y:778,t:1527268181719};\\\", \\\"{x:1385,y:776,t:1527268181735};\\\", \\\"{x:1384,y:776,t:1527268182115};\\\", \\\"{x:1383,y:777,t:1527268182130};\\\", \\\"{x:1383,y:778,t:1527268182683};\\\", \\\"{x:1383,y:777,t:1527268182714};\\\", \\\"{x:1383,y:776,t:1527268182722};\\\", \\\"{x:1382,y:774,t:1527268182738};\\\", \\\"{x:1382,y:773,t:1527268182752};\\\", \\\"{x:1382,y:771,t:1527268182769};\\\", \\\"{x:1382,y:768,t:1527268182787};\\\", \\\"{x:1382,y:767,t:1527268182802};\\\", \\\"{x:1381,y:766,t:1527268182819};\\\", \\\"{x:1381,y:765,t:1527268182946};\\\", \\\"{x:1381,y:764,t:1527268182987};\\\", \\\"{x:1381,y:765,t:1527268183403};\\\", \\\"{x:1381,y:766,t:1527268183419};\\\", \\\"{x:1380,y:767,t:1527268183436};\\\", \\\"{x:1380,y:768,t:1527268183610};\\\", \\\"{x:1380,y:769,t:1527268183636};\\\", \\\"{x:1380,y:770,t:1527268183653};\\\", \\\"{x:1380,y:772,t:1527268183669};\\\", \\\"{x:1380,y:773,t:1527268183686};\\\", \\\"{x:1380,y:774,t:1527268183703};\\\", \\\"{x:1379,y:774,t:1527268183755};\\\", \\\"{x:1379,y:775,t:1527268183900};\\\", \\\"{x:1379,y:776,t:1527268183939};\\\", \\\"{x:1379,y:777,t:1527268183954};\\\", \\\"{x:1378,y:777,t:1527268187651};\\\", \\\"{x:1377,y:777,t:1527268187691};\\\", \\\"{x:1376,y:777,t:1527268187723};\\\", \\\"{x:1375,y:777,t:1527268187745};\\\", \\\"{x:1375,y:776,t:1527268187794};\\\", \\\"{x:1375,y:775,t:1527268187810};\\\", \\\"{x:1375,y:774,t:1527268187821};\\\", \\\"{x:1375,y:773,t:1527268187837};\\\", \\\"{x:1375,y:772,t:1527268187858};\\\", \\\"{x:1375,y:771,t:1527268188035};\\\", \\\"{x:1375,y:770,t:1527268188115};\\\", \\\"{x:1374,y:774,t:1527268190115};\\\", \\\"{x:1372,y:782,t:1527268190123};\\\", \\\"{x:1367,y:796,t:1527268190138};\\\", \\\"{x:1364,y:809,t:1527268190155};\\\", \\\"{x:1363,y:816,t:1527268190173};\\\", \\\"{x:1363,y:820,t:1527268190189};\\\", \\\"{x:1361,y:823,t:1527268190206};\\\", \\\"{x:1361,y:825,t:1527268190222};\\\", \\\"{x:1361,y:828,t:1527268190239};\\\", \\\"{x:1361,y:830,t:1527268190256};\\\", \\\"{x:1361,y:832,t:1527268190273};\\\", \\\"{x:1361,y:835,t:1527268190289};\\\", \\\"{x:1361,y:838,t:1527268190305};\\\", \\\"{x:1362,y:841,t:1527268190323};\\\", \\\"{x:1362,y:845,t:1527268190340};\\\", \\\"{x:1362,y:851,t:1527268190356};\\\", \\\"{x:1362,y:857,t:1527268190372};\\\", \\\"{x:1362,y:864,t:1527268190390};\\\", \\\"{x:1362,y:866,t:1527268190406};\\\", \\\"{x:1362,y:867,t:1527268190514};\\\", \\\"{x:1362,y:869,t:1527268190563};\\\", \\\"{x:1362,y:870,t:1527268190573};\\\", \\\"{x:1362,y:874,t:1527268190590};\\\", \\\"{x:1360,y:877,t:1527268190605};\\\", \\\"{x:1358,y:883,t:1527268190622};\\\", \\\"{x:1356,y:887,t:1527268190640};\\\", \\\"{x:1354,y:890,t:1527268190656};\\\", \\\"{x:1352,y:891,t:1527268190672};\\\", \\\"{x:1350,y:891,t:1527268190706};\\\", \\\"{x:1340,y:894,t:1527268190723};\\\", \\\"{x:1336,y:896,t:1527268190740};\\\", \\\"{x:1334,y:897,t:1527268190762};\\\", \\\"{x:1332,y:899,t:1527268190778};\\\", \\\"{x:1331,y:900,t:1527268190795};\\\", \\\"{x:1329,y:903,t:1527268190810};\\\", \\\"{x:1328,y:903,t:1527268190826};\\\", \\\"{x:1328,y:904,t:1527268190843};\\\", \\\"{x:1327,y:906,t:1527268190857};\\\", \\\"{x:1326,y:909,t:1527268190873};\\\", \\\"{x:1325,y:913,t:1527268190890};\\\", \\\"{x:1326,y:912,t:1527268191323};\\\", \\\"{x:1327,y:912,t:1527268191353};\\\", \\\"{x:1328,y:912,t:1527268191370};\\\", \\\"{x:1329,y:912,t:1527268191385};\\\", \\\"{x:1330,y:912,t:1527268191401};\\\", \\\"{x:1331,y:912,t:1527268191410};\\\", \\\"{x:1333,y:911,t:1527268191441};\\\", \\\"{x:1334,y:910,t:1527268191456};\\\", \\\"{x:1336,y:909,t:1527268191474};\\\", \\\"{x:1337,y:907,t:1527268191489};\\\", \\\"{x:1338,y:907,t:1527268191507};\\\", \\\"{x:1338,y:906,t:1527268191524};\\\", \\\"{x:1339,y:906,t:1527268191540};\\\", \\\"{x:1340,y:906,t:1527268191682};\\\", \\\"{x:1341,y:905,t:1527268191707};\\\", \\\"{x:1342,y:903,t:1527268191724};\\\", \\\"{x:1342,y:901,t:1527268191739};\\\", \\\"{x:1343,y:898,t:1527268191757};\\\", \\\"{x:1343,y:897,t:1527268191773};\\\", \\\"{x:1343,y:895,t:1527268191790};\\\", \\\"{x:1343,y:894,t:1527268192179};\\\", \\\"{x:1343,y:891,t:1527268192192};\\\", \\\"{x:1332,y:886,t:1527268192208};\\\", \\\"{x:1324,y:882,t:1527268192224};\\\", \\\"{x:1321,y:880,t:1527268192241};\\\", \\\"{x:1320,y:878,t:1527268192257};\\\", \\\"{x:1319,y:878,t:1527268192275};\\\", \\\"{x:1319,y:877,t:1527268192299};\\\", \\\"{x:1318,y:877,t:1527268192443};\\\", \\\"{x:1316,y:877,t:1527268192458};\\\", \\\"{x:1304,y:869,t:1527268192474};\\\", \\\"{x:1292,y:862,t:1527268192491};\\\", \\\"{x:1277,y:854,t:1527268192507};\\\", \\\"{x:1261,y:846,t:1527268192524};\\\", \\\"{x:1249,y:839,t:1527268192541};\\\", \\\"{x:1242,y:835,t:1527268192557};\\\", \\\"{x:1239,y:833,t:1527268192574};\\\", \\\"{x:1238,y:833,t:1527268192715};\\\", \\\"{x:1238,y:831,t:1527268192730};\\\", \\\"{x:1238,y:830,t:1527268192747};\\\", \\\"{x:1240,y:830,t:1527268192758};\\\", \\\"{x:1246,y:827,t:1527268192774};\\\", \\\"{x:1253,y:826,t:1527268192791};\\\", \\\"{x:1259,y:826,t:1527268192808};\\\", \\\"{x:1265,y:826,t:1527268192825};\\\", \\\"{x:1271,y:826,t:1527268192842};\\\", \\\"{x:1276,y:826,t:1527268192858};\\\", \\\"{x:1280,y:827,t:1527268192875};\\\", \\\"{x:1284,y:829,t:1527268192891};\\\", \\\"{x:1288,y:831,t:1527268192910};\\\", \\\"{x:1289,y:832,t:1527268192924};\\\", \\\"{x:1289,y:833,t:1527268193947};\\\", \\\"{x:1289,y:834,t:1527268194899};\\\", \\\"{x:1288,y:834,t:1527268194938};\\\", \\\"{x:1287,y:834,t:1527268194986};\\\", \\\"{x:1286,y:834,t:1527268195018};\\\", \\\"{x:1285,y:834,t:1527268195050};\\\", \\\"{x:1284,y:834,t:1527268195075};\\\", \\\"{x:1283,y:835,t:1527268195155};\\\", \\\"{x:1282,y:835,t:1527268195570};\\\", \\\"{x:1281,y:835,t:1527268195738};\\\", \\\"{x:1281,y:834,t:1527268195771};\\\", \\\"{x:1281,y:832,t:1527268195802};\\\", \\\"{x:1281,y:831,t:1527268195810};\\\", \\\"{x:1281,y:830,t:1527268195826};\\\", \\\"{x:1281,y:829,t:1527268195843};\\\", \\\"{x:1282,y:828,t:1527268195859};\\\", \\\"{x:1283,y:828,t:1527268195876};\\\", \\\"{x:1284,y:827,t:1527268195898};\\\", \\\"{x:1285,y:825,t:1527268195939};\\\", \\\"{x:1287,y:824,t:1527268195947};\\\", \\\"{x:1288,y:822,t:1527268195959};\\\", \\\"{x:1292,y:818,t:1527268195977};\\\", \\\"{x:1295,y:814,t:1527268195994};\\\", \\\"{x:1296,y:811,t:1527268196009};\\\", \\\"{x:1299,y:807,t:1527268196025};\\\", \\\"{x:1301,y:803,t:1527268196043};\\\", \\\"{x:1303,y:800,t:1527268196059};\\\", \\\"{x:1306,y:793,t:1527268196076};\\\", \\\"{x:1309,y:789,t:1527268196093};\\\", \\\"{x:1313,y:783,t:1527268196109};\\\", \\\"{x:1314,y:779,t:1527268196126};\\\", \\\"{x:1316,y:775,t:1527268196143};\\\", \\\"{x:1317,y:773,t:1527268196159};\\\", \\\"{x:1318,y:768,t:1527268196176};\\\", \\\"{x:1321,y:764,t:1527268196193};\\\", \\\"{x:1321,y:761,t:1527268196210};\\\", \\\"{x:1322,y:754,t:1527268196226};\\\", \\\"{x:1324,y:751,t:1527268196243};\\\", \\\"{x:1324,y:748,t:1527268196260};\\\", \\\"{x:1324,y:746,t:1527268196276};\\\", \\\"{x:1324,y:742,t:1527268196293};\\\", \\\"{x:1324,y:740,t:1527268196310};\\\", \\\"{x:1324,y:737,t:1527268196326};\\\", \\\"{x:1324,y:734,t:1527268196343};\\\", \\\"{x:1324,y:732,t:1527268196359};\\\", \\\"{x:1324,y:729,t:1527268196376};\\\", \\\"{x:1322,y:726,t:1527268196394};\\\", \\\"{x:1321,y:722,t:1527268196410};\\\", \\\"{x:1319,y:716,t:1527268196426};\\\", \\\"{x:1319,y:713,t:1527268196444};\\\", \\\"{x:1317,y:710,t:1527268196459};\\\", \\\"{x:1317,y:708,t:1527268196476};\\\", \\\"{x:1317,y:707,t:1527268196493};\\\", \\\"{x:1316,y:704,t:1527268196509};\\\", \\\"{x:1316,y:703,t:1527268196526};\\\", \\\"{x:1315,y:701,t:1527268196542};\\\", \\\"{x:1315,y:700,t:1527268196559};\\\", \\\"{x:1314,y:697,t:1527268196576};\\\", \\\"{x:1314,y:696,t:1527268196617};\\\", \\\"{x:1314,y:694,t:1527268196626};\\\", \\\"{x:1313,y:693,t:1527268196643};\\\", \\\"{x:1313,y:687,t:1527268196660};\\\", \\\"{x:1313,y:683,t:1527268196676};\\\", \\\"{x:1313,y:679,t:1527268196693};\\\", \\\"{x:1312,y:677,t:1527268196710};\\\", \\\"{x:1312,y:674,t:1527268196726};\\\", \\\"{x:1312,y:673,t:1527268196745};\\\", \\\"{x:1312,y:672,t:1527268196786};\\\", \\\"{x:1312,y:671,t:1527268196793};\\\", \\\"{x:1312,y:670,t:1527268196923};\\\", \\\"{x:1312,y:669,t:1527268196931};\\\", \\\"{x:1312,y:667,t:1527268196943};\\\", \\\"{x:1312,y:666,t:1527268196960};\\\", \\\"{x:1312,y:664,t:1527268196976};\\\", \\\"{x:1312,y:663,t:1527268196993};\\\", \\\"{x:1312,y:662,t:1527268197009};\\\", \\\"{x:1312,y:661,t:1527268197033};\\\", \\\"{x:1312,y:660,t:1527268197057};\\\", \\\"{x:1312,y:659,t:1527268197081};\\\", \\\"{x:1312,y:658,t:1527268197177};\\\", \\\"{x:1312,y:657,t:1527268197201};\\\", \\\"{x:1312,y:655,t:1527268197209};\\\", \\\"{x:1313,y:653,t:1527268197227};\\\", \\\"{x:1313,y:652,t:1527268197243};\\\", \\\"{x:1313,y:651,t:1527268197265};\\\", \\\"{x:1313,y:650,t:1527268197281};\\\", \\\"{x:1313,y:649,t:1527268197305};\\\", \\\"{x:1313,y:648,t:1527268197433};\\\", \\\"{x:1313,y:647,t:1527268197442};\\\", \\\"{x:1313,y:646,t:1527268197460};\\\", \\\"{x:1313,y:643,t:1527268197477};\\\", \\\"{x:1313,y:642,t:1527268197493};\\\", \\\"{x:1313,y:641,t:1527268197510};\\\", \\\"{x:1313,y:640,t:1527268197527};\\\", \\\"{x:1314,y:639,t:1527268197786};\\\", \\\"{x:1315,y:639,t:1527268198667};\\\", \\\"{x:1316,y:640,t:1527268203735};\\\", \\\"{x:1316,y:642,t:1527268204062};\\\", \\\"{x:1316,y:643,t:1527268205806};\\\", \\\"{x:1316,y:645,t:1527268205818};\\\", \\\"{x:1316,y:649,t:1527268205836};\\\", \\\"{x:1316,y:654,t:1527268205852};\\\", \\\"{x:1316,y:658,t:1527268205868};\\\", \\\"{x:1316,y:663,t:1527268205886};\\\", \\\"{x:1316,y:666,t:1527268205902};\\\", \\\"{x:1317,y:670,t:1527268205918};\\\", \\\"{x:1317,y:673,t:1527268205935};\\\", \\\"{x:1317,y:675,t:1527268205953};\\\", \\\"{x:1317,y:677,t:1527268205968};\\\", \\\"{x:1317,y:681,t:1527268205985};\\\", \\\"{x:1316,y:686,t:1527268206003};\\\", \\\"{x:1316,y:690,t:1527268206019};\\\", \\\"{x:1316,y:693,t:1527268206036};\\\", \\\"{x:1315,y:697,t:1527268206052};\\\", \\\"{x:1315,y:702,t:1527268206068};\\\", \\\"{x:1314,y:708,t:1527268206085};\\\", \\\"{x:1314,y:711,t:1527268206102};\\\", \\\"{x:1314,y:714,t:1527268206118};\\\", \\\"{x:1314,y:716,t:1527268206135};\\\", \\\"{x:1314,y:718,t:1527268206152};\\\", \\\"{x:1314,y:722,t:1527268206168};\\\", \\\"{x:1314,y:727,t:1527268206185};\\\", \\\"{x:1313,y:733,t:1527268206203};\\\", \\\"{x:1313,y:735,t:1527268206219};\\\", \\\"{x:1312,y:738,t:1527268206236};\\\", \\\"{x:1312,y:741,t:1527268206252};\\\", \\\"{x:1312,y:742,t:1527268206269};\\\", \\\"{x:1312,y:744,t:1527268206285};\\\", \\\"{x:1312,y:746,t:1527268206302};\\\", \\\"{x:1312,y:748,t:1527268206319};\\\", \\\"{x:1312,y:750,t:1527268206336};\\\", \\\"{x:1312,y:752,t:1527268206353};\\\", \\\"{x:1312,y:755,t:1527268206369};\\\", \\\"{x:1312,y:758,t:1527268206385};\\\", \\\"{x:1312,y:761,t:1527268206402};\\\", \\\"{x:1312,y:764,t:1527268206419};\\\", \\\"{x:1312,y:766,t:1527268206436};\\\", \\\"{x:1312,y:768,t:1527268206453};\\\", \\\"{x:1312,y:771,t:1527268206470};\\\", \\\"{x:1312,y:773,t:1527268206485};\\\", \\\"{x:1312,y:774,t:1527268206502};\\\", \\\"{x:1312,y:776,t:1527268206519};\\\", \\\"{x:1312,y:777,t:1527268206541};\\\", \\\"{x:1312,y:778,t:1527268206552};\\\", \\\"{x:1312,y:779,t:1527268206569};\\\", \\\"{x:1312,y:782,t:1527268206585};\\\", \\\"{x:1312,y:784,t:1527268206602};\\\", \\\"{x:1312,y:787,t:1527268206619};\\\", \\\"{x:1312,y:789,t:1527268206635};\\\", \\\"{x:1312,y:792,t:1527268206653};\\\", \\\"{x:1312,y:793,t:1527268206669};\\\", \\\"{x:1312,y:795,t:1527268206685};\\\", \\\"{x:1313,y:797,t:1527268206702};\\\", \\\"{x:1313,y:798,t:1527268206719};\\\", \\\"{x:1313,y:802,t:1527268206735};\\\", \\\"{x:1315,y:806,t:1527268206752};\\\", \\\"{x:1316,y:811,t:1527268206769};\\\", \\\"{x:1316,y:817,t:1527268206785};\\\", \\\"{x:1317,y:821,t:1527268206802};\\\", \\\"{x:1317,y:826,t:1527268206819};\\\", \\\"{x:1317,y:832,t:1527268206835};\\\", \\\"{x:1317,y:837,t:1527268206852};\\\", \\\"{x:1317,y:842,t:1527268206869};\\\", \\\"{x:1317,y:844,t:1527268206885};\\\", \\\"{x:1317,y:845,t:1527268206903};\\\", \\\"{x:1317,y:847,t:1527268206919};\\\", \\\"{x:1317,y:848,t:1527268206958};\\\", \\\"{x:1317,y:849,t:1527268206969};\\\", \\\"{x:1317,y:850,t:1527268206987};\\\", \\\"{x:1317,y:852,t:1527268207002};\\\", \\\"{x:1317,y:855,t:1527268207019};\\\", \\\"{x:1317,y:859,t:1527268207035};\\\", \\\"{x:1317,y:864,t:1527268207053};\\\", \\\"{x:1317,y:875,t:1527268207069};\\\", \\\"{x:1317,y:882,t:1527268207085};\\\", \\\"{x:1317,y:890,t:1527268207102};\\\", \\\"{x:1317,y:896,t:1527268207120};\\\", \\\"{x:1317,y:899,t:1527268207139};\\\", \\\"{x:1319,y:902,t:1527268207152};\\\", \\\"{x:1319,y:903,t:1527268207169};\\\", \\\"{x:1320,y:904,t:1527268207185};\\\", \\\"{x:1321,y:905,t:1527268207201};\\\", \\\"{x:1321,y:906,t:1527268207229};\\\", \\\"{x:1322,y:907,t:1527268207285};\\\", \\\"{x:1322,y:903,t:1527268207414};\\\", \\\"{x:1321,y:898,t:1527268207422};\\\", \\\"{x:1321,y:892,t:1527268207436};\\\", \\\"{x:1321,y:877,t:1527268207453};\\\", \\\"{x:1315,y:844,t:1527268207469};\\\", \\\"{x:1312,y:820,t:1527268207486};\\\", \\\"{x:1310,y:798,t:1527268207503};\\\", \\\"{x:1307,y:783,t:1527268207519};\\\", \\\"{x:1305,y:766,t:1527268207537};\\\", \\\"{x:1301,y:748,t:1527268207553};\\\", \\\"{x:1300,y:731,t:1527268207569};\\\", \\\"{x:1300,y:718,t:1527268207586};\\\", \\\"{x:1300,y:700,t:1527268207602};\\\", \\\"{x:1300,y:685,t:1527268207619};\\\", \\\"{x:1300,y:668,t:1527268207637};\\\", \\\"{x:1300,y:650,t:1527268207653};\\\", \\\"{x:1300,y:641,t:1527268207669};\\\", \\\"{x:1300,y:632,t:1527268207686};\\\", \\\"{x:1300,y:624,t:1527268207704};\\\", \\\"{x:1300,y:618,t:1527268207720};\\\", \\\"{x:1300,y:612,t:1527268207736};\\\", \\\"{x:1300,y:606,t:1527268207754};\\\", \\\"{x:1300,y:602,t:1527268207769};\\\", \\\"{x:1300,y:599,t:1527268207787};\\\", \\\"{x:1300,y:598,t:1527268207803};\\\", \\\"{x:1300,y:597,t:1527268207819};\\\", \\\"{x:1300,y:598,t:1527268207957};\\\", \\\"{x:1300,y:600,t:1527268207970};\\\", \\\"{x:1300,y:610,t:1527268207986};\\\", \\\"{x:1301,y:628,t:1527268208003};\\\", \\\"{x:1306,y:650,t:1527268208020};\\\", \\\"{x:1308,y:673,t:1527268208036};\\\", \\\"{x:1309,y:711,t:1527268208053};\\\", \\\"{x:1313,y:736,t:1527268208070};\\\", \\\"{x:1314,y:758,t:1527268208086};\\\", \\\"{x:1314,y:772,t:1527268208103};\\\", \\\"{x:1315,y:779,t:1527268208120};\\\", \\\"{x:1316,y:785,t:1527268208136};\\\", \\\"{x:1318,y:791,t:1527268208153};\\\", \\\"{x:1320,y:799,t:1527268208169};\\\", \\\"{x:1322,y:809,t:1527268208186};\\\", \\\"{x:1325,y:819,t:1527268208203};\\\", \\\"{x:1326,y:829,t:1527268208220};\\\", \\\"{x:1327,y:838,t:1527268208236};\\\", \\\"{x:1329,y:851,t:1527268208254};\\\", \\\"{x:1330,y:862,t:1527268208269};\\\", \\\"{x:1330,y:870,t:1527268208287};\\\", \\\"{x:1330,y:879,t:1527268208303};\\\", \\\"{x:1330,y:889,t:1527268208320};\\\", \\\"{x:1330,y:895,t:1527268208336};\\\", \\\"{x:1330,y:899,t:1527268208353};\\\", \\\"{x:1330,y:900,t:1527268208370};\\\", \\\"{x:1331,y:901,t:1527268208412};\\\", \\\"{x:1331,y:902,t:1527268208485};\\\", \\\"{x:1331,y:903,t:1527268208493};\\\", \\\"{x:1331,y:904,t:1527268208503};\\\", \\\"{x:1331,y:906,t:1527268208520};\\\", \\\"{x:1331,y:911,t:1527268208536};\\\", \\\"{x:1330,y:919,t:1527268208553};\\\", \\\"{x:1329,y:925,t:1527268208570};\\\", \\\"{x:1328,y:928,t:1527268208586};\\\", \\\"{x:1328,y:929,t:1527268208603};\\\", \\\"{x:1327,y:931,t:1527268208774};\\\", \\\"{x:1326,y:932,t:1527268208786};\\\", \\\"{x:1323,y:938,t:1527268208803};\\\", \\\"{x:1322,y:939,t:1527268208820};\\\", \\\"{x:1322,y:940,t:1527268208837};\\\", \\\"{x:1321,y:941,t:1527268208878};\\\", \\\"{x:1321,y:940,t:1527268208886};\\\", \\\"{x:1321,y:934,t:1527268208903};\\\", \\\"{x:1321,y:922,t:1527268208920};\\\", \\\"{x:1321,y:899,t:1527268208937};\\\", \\\"{x:1321,y:868,t:1527268208954};\\\", \\\"{x:1321,y:838,t:1527268208971};\\\", \\\"{x:1321,y:809,t:1527268208988};\\\", \\\"{x:1321,y:782,t:1527268209003};\\\", \\\"{x:1321,y:758,t:1527268209020};\\\", \\\"{x:1321,y:725,t:1527268209038};\\\", \\\"{x:1321,y:710,t:1527268209053};\\\", \\\"{x:1321,y:699,t:1527268209070};\\\", \\\"{x:1319,y:692,t:1527268209088};\\\", \\\"{x:1318,y:684,t:1527268209104};\\\", \\\"{x:1318,y:673,t:1527268209120};\\\", \\\"{x:1318,y:662,t:1527268209138};\\\", \\\"{x:1318,y:652,t:1527268209154};\\\", \\\"{x:1318,y:646,t:1527268209170};\\\", \\\"{x:1318,y:641,t:1527268209188};\\\", \\\"{x:1318,y:638,t:1527268209204};\\\", \\\"{x:1318,y:637,t:1527268209221};\\\", \\\"{x:1318,y:638,t:1527268209309};\\\", \\\"{x:1317,y:644,t:1527268209321};\\\", \\\"{x:1317,y:652,t:1527268209337};\\\", \\\"{x:1314,y:668,t:1527268209352};\\\", \\\"{x:1313,y:690,t:1527268209370};\\\", \\\"{x:1312,y:713,t:1527268209387};\\\", \\\"{x:1312,y:740,t:1527268209403};\\\", \\\"{x:1312,y:767,t:1527268209420};\\\", \\\"{x:1312,y:798,t:1527268209436};\\\", \\\"{x:1312,y:813,t:1527268209454};\\\", \\\"{x:1312,y:824,t:1527268209470};\\\", \\\"{x:1312,y:837,t:1527268209486};\\\", \\\"{x:1312,y:852,t:1527268209503};\\\", \\\"{x:1312,y:870,t:1527268209520};\\\", \\\"{x:1312,y:890,t:1527268209537};\\\", \\\"{x:1312,y:904,t:1527268209554};\\\", \\\"{x:1312,y:911,t:1527268209570};\\\", \\\"{x:1312,y:915,t:1527268209587};\\\", \\\"{x:1312,y:917,t:1527268209604};\\\", \\\"{x:1312,y:918,t:1527268209637};\\\", \\\"{x:1312,y:919,t:1527268209718};\\\", \\\"{x:1312,y:921,t:1527268209749};\\\", \\\"{x:1312,y:922,t:1527268209765};\\\", \\\"{x:1312,y:924,t:1527268209773};\\\", \\\"{x:1312,y:925,t:1527268209787};\\\", \\\"{x:1312,y:932,t:1527268209805};\\\", \\\"{x:1312,y:937,t:1527268209820};\\\", \\\"{x:1312,y:944,t:1527268209837};\\\", \\\"{x:1312,y:946,t:1527268209854};\\\", \\\"{x:1313,y:947,t:1527268209886};\\\", \\\"{x:1314,y:947,t:1527268209950};\\\", \\\"{x:1314,y:948,t:1527268209990};\\\", \\\"{x:1314,y:949,t:1527268210006};\\\", \\\"{x:1314,y:950,t:1527268210021};\\\", \\\"{x:1314,y:954,t:1527268210037};\\\", \\\"{x:1316,y:958,t:1527268210054};\\\", \\\"{x:1316,y:961,t:1527268210070};\\\", \\\"{x:1316,y:962,t:1527268210087};\\\", \\\"{x:1316,y:963,t:1527268210105};\\\", \\\"{x:1317,y:963,t:1527268210125};\\\", \\\"{x:1320,y:963,t:1527268210333};\\\", \\\"{x:1325,y:963,t:1527268210340};\\\", \\\"{x:1332,y:963,t:1527268210354};\\\", \\\"{x:1352,y:962,t:1527268210371};\\\", \\\"{x:1379,y:961,t:1527268210387};\\\", \\\"{x:1414,y:957,t:1527268210403};\\\", \\\"{x:1469,y:949,t:1527268210420};\\\", \\\"{x:1495,y:948,t:1527268210437};\\\", \\\"{x:1519,y:944,t:1527268210454};\\\", \\\"{x:1535,y:944,t:1527268210471};\\\", \\\"{x:1546,y:944,t:1527268210487};\\\", \\\"{x:1555,y:944,t:1527268210504};\\\", \\\"{x:1567,y:947,t:1527268210521};\\\", \\\"{x:1574,y:949,t:1527268210537};\\\", \\\"{x:1582,y:952,t:1527268210554};\\\", \\\"{x:1588,y:954,t:1527268210571};\\\", \\\"{x:1591,y:954,t:1527268210587};\\\", \\\"{x:1594,y:954,t:1527268210604};\\\", \\\"{x:1598,y:954,t:1527268210621};\\\", \\\"{x:1601,y:954,t:1527268210636};\\\", \\\"{x:1606,y:953,t:1527268210654};\\\", \\\"{x:1613,y:952,t:1527268210671};\\\", \\\"{x:1620,y:951,t:1527268210687};\\\", \\\"{x:1624,y:951,t:1527268210704};\\\", \\\"{x:1627,y:951,t:1527268210721};\\\", \\\"{x:1627,y:953,t:1527268211014};\\\", \\\"{x:1627,y:955,t:1527268211030};\\\", \\\"{x:1626,y:956,t:1527268211038};\\\", \\\"{x:1624,y:958,t:1527268211055};\\\", \\\"{x:1623,y:960,t:1527268211072};\\\", \\\"{x:1622,y:960,t:1527268211093};\\\", \\\"{x:1621,y:960,t:1527268211118};\\\", \\\"{x:1619,y:960,t:1527268211126};\\\", \\\"{x:1618,y:960,t:1527268211138};\\\", \\\"{x:1607,y:960,t:1527268211154};\\\", \\\"{x:1584,y:960,t:1527268211171};\\\", \\\"{x:1555,y:960,t:1527268211188};\\\", \\\"{x:1525,y:960,t:1527268211205};\\\", \\\"{x:1483,y:954,t:1527268211221};\\\", \\\"{x:1460,y:945,t:1527268211238};\\\", \\\"{x:1444,y:936,t:1527268211254};\\\", \\\"{x:1428,y:924,t:1527268211271};\\\", \\\"{x:1415,y:914,t:1527268211288};\\\", \\\"{x:1401,y:902,t:1527268211305};\\\", \\\"{x:1376,y:884,t:1527268211322};\\\", \\\"{x:1344,y:859,t:1527268211338};\\\", \\\"{x:1305,y:833,t:1527268211354};\\\", \\\"{x:1282,y:815,t:1527268211371};\\\", \\\"{x:1268,y:800,t:1527268211389};\\\", \\\"{x:1254,y:778,t:1527268211405};\\\", \\\"{x:1248,y:752,t:1527268211422};\\\", \\\"{x:1247,y:731,t:1527268211439};\\\", \\\"{x:1247,y:708,t:1527268211454};\\\", \\\"{x:1247,y:687,t:1527268211472};\\\", \\\"{x:1249,y:660,t:1527268211489};\\\", \\\"{x:1250,y:630,t:1527268211505};\\\", \\\"{x:1250,y:612,t:1527268211522};\\\", \\\"{x:1250,y:601,t:1527268211538};\\\", \\\"{x:1250,y:592,t:1527268211555};\\\", \\\"{x:1250,y:580,t:1527268211571};\\\", \\\"{x:1250,y:573,t:1527268211588};\\\", \\\"{x:1254,y:561,t:1527268211605};\\\", \\\"{x:1254,y:557,t:1527268211621};\\\", \\\"{x:1254,y:552,t:1527268211638};\\\", \\\"{x:1255,y:550,t:1527268211655};\\\", \\\"{x:1255,y:549,t:1527268211672};\\\", \\\"{x:1255,y:548,t:1527268211694};\\\", \\\"{x:1255,y:547,t:1527268211706};\\\", \\\"{x:1256,y:546,t:1527268211721};\\\", \\\"{x:1257,y:545,t:1527268211738};\\\", \\\"{x:1260,y:543,t:1527268211756};\\\", \\\"{x:1262,y:543,t:1527268211771};\\\", \\\"{x:1267,y:542,t:1527268211788};\\\", \\\"{x:1275,y:542,t:1527268211805};\\\", \\\"{x:1278,y:542,t:1527268211822};\\\", \\\"{x:1282,y:541,t:1527268211838};\\\", \\\"{x:1283,y:540,t:1527268211855};\\\", \\\"{x:1285,y:539,t:1527268211872};\\\", \\\"{x:1287,y:537,t:1527268211889};\\\", \\\"{x:1287,y:535,t:1527268211905};\\\", \\\"{x:1289,y:534,t:1527268211921};\\\", \\\"{x:1289,y:533,t:1527268211941};\\\", \\\"{x:1290,y:532,t:1527268211955};\\\", \\\"{x:1290,y:531,t:1527268211972};\\\", \\\"{x:1291,y:530,t:1527268211989};\\\", \\\"{x:1292,y:529,t:1527268212079};\\\", \\\"{x:1293,y:527,t:1527268212118};\\\", \\\"{x:1295,y:524,t:1527268212134};\\\", \\\"{x:1296,y:523,t:1527268212141};\\\", \\\"{x:1297,y:522,t:1527268212155};\\\", \\\"{x:1298,y:519,t:1527268212173};\\\", \\\"{x:1299,y:518,t:1527268212188};\\\", \\\"{x:1301,y:515,t:1527268212205};\\\", \\\"{x:1303,y:513,t:1527268212223};\\\", \\\"{x:1305,y:513,t:1527268212239};\\\", \\\"{x:1307,y:511,t:1527268212256};\\\", \\\"{x:1309,y:511,t:1527268212273};\\\", \\\"{x:1312,y:511,t:1527268212289};\\\", \\\"{x:1318,y:511,t:1527268212306};\\\", \\\"{x:1326,y:512,t:1527268212323};\\\", \\\"{x:1332,y:512,t:1527268212339};\\\", \\\"{x:1341,y:512,t:1527268212356};\\\", \\\"{x:1347,y:511,t:1527268212373};\\\", \\\"{x:1352,y:509,t:1527268212388};\\\", \\\"{x:1359,y:504,t:1527268212406};\\\", \\\"{x:1361,y:502,t:1527268212422};\\\", \\\"{x:1363,y:501,t:1527268212439};\\\", \\\"{x:1365,y:499,t:1527268212456};\\\", \\\"{x:1367,y:498,t:1527268212473};\\\", \\\"{x:1370,y:496,t:1527268212489};\\\", \\\"{x:1372,y:495,t:1527268212505};\\\", \\\"{x:1376,y:495,t:1527268212523};\\\", \\\"{x:1382,y:495,t:1527268212538};\\\", \\\"{x:1392,y:495,t:1527268212555};\\\", \\\"{x:1403,y:496,t:1527268212573};\\\", \\\"{x:1416,y:498,t:1527268212588};\\\", \\\"{x:1434,y:499,t:1527268212604};\\\", \\\"{x:1440,y:499,t:1527268212622};\\\", \\\"{x:1443,y:499,t:1527268212638};\\\", \\\"{x:1444,y:500,t:1527268212748};\\\", \\\"{x:1444,y:502,t:1527268212757};\\\", \\\"{x:1443,y:508,t:1527268212772};\\\", \\\"{x:1413,y:547,t:1527268212789};\\\", \\\"{x:1365,y:583,t:1527268212805};\\\", \\\"{x:1288,y:613,t:1527268212822};\\\", \\\"{x:1184,y:633,t:1527268212839};\\\", \\\"{x:1076,y:635,t:1527268212855};\\\", \\\"{x:981,y:635,t:1527268212872};\\\", \\\"{x:910,y:631,t:1527268212889};\\\", \\\"{x:854,y:623,t:1527268212905};\\\", \\\"{x:831,y:620,t:1527268212922};\\\", \\\"{x:818,y:618,t:1527268212939};\\\", \\\"{x:813,y:618,t:1527268212956};\\\", \\\"{x:811,y:618,t:1527268212972};\\\", \\\"{x:808,y:618,t:1527268212989};\\\", \\\"{x:802,y:618,t:1527268213005};\\\", \\\"{x:798,y:621,t:1527268213023};\\\", \\\"{x:787,y:629,t:1527268213039};\\\", \\\"{x:772,y:640,t:1527268213055};\\\", \\\"{x:753,y:650,t:1527268213072};\\\", \\\"{x:741,y:655,t:1527268213089};\\\", \\\"{x:724,y:657,t:1527268213105};\\\", \\\"{x:702,y:658,t:1527268213122};\\\", \\\"{x:679,y:658,t:1527268213140};\\\", \\\"{x:659,y:659,t:1527268213155};\\\", \\\"{x:637,y:663,t:1527268213172};\\\", \\\"{x:610,y:668,t:1527268213189};\\\", \\\"{x:597,y:670,t:1527268213205};\\\", \\\"{x:590,y:674,t:1527268213222};\\\", \\\"{x:587,y:677,t:1527268213240};\\\", \\\"{x:585,y:679,t:1527268213255};\\\", \\\"{x:582,y:683,t:1527268213273};\\\", \\\"{x:575,y:693,t:1527268213289};\\\", \\\"{x:565,y:702,t:1527268213305};\\\", \\\"{x:552,y:711,t:1527268213323};\\\", \\\"{x:543,y:717,t:1527268213339};\\\", \\\"{x:538,y:720,t:1527268213355};\\\", \\\"{x:537,y:721,t:1527268213558};\\\" ] }, { \\\"rt\\\": 99942, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 351312, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -O -C -A -O -I -11 AM-06 PM-06 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:720,t:1527268216421};\\\", \\\"{x:531,y:697,t:1527268216438};\\\", \\\"{x:522,y:683,t:1527268216449};\\\", \\\"{x:511,y:661,t:1527268216466};\\\", \\\"{x:495,y:640,t:1527268216483};\\\", \\\"{x:477,y:616,t:1527268216500};\\\", \\\"{x:450,y:585,t:1527268216517};\\\", \\\"{x:442,y:573,t:1527268216533};\\\", \\\"{x:434,y:561,t:1527268216550};\\\", \\\"{x:425,y:543,t:1527268216567};\\\", \\\"{x:422,y:529,t:1527268216583};\\\", \\\"{x:419,y:514,t:1527268216600};\\\", \\\"{x:419,y:500,t:1527268216616};\\\", \\\"{x:419,y:487,t:1527268216633};\\\", \\\"{x:419,y:474,t:1527268216650};\\\", \\\"{x:419,y:465,t:1527268216666};\\\", \\\"{x:419,y:461,t:1527268216683};\\\", \\\"{x:419,y:458,t:1527268216700};\\\", \\\"{x:419,y:457,t:1527268216716};\\\", \\\"{x:419,y:456,t:1527268216781};\\\", \\\"{x:421,y:456,t:1527268216829};\\\", \\\"{x:422,y:456,t:1527268216845};\\\", \\\"{x:424,y:456,t:1527268216862};\\\", \\\"{x:425,y:456,t:1527268216869};\\\", \\\"{x:428,y:456,t:1527268216884};\\\", \\\"{x:431,y:456,t:1527268216901};\\\", \\\"{x:436,y:456,t:1527268216916};\\\", \\\"{x:444,y:456,t:1527268216933};\\\", \\\"{x:450,y:456,t:1527268216950};\\\", \\\"{x:454,y:456,t:1527268216967};\\\", \\\"{x:458,y:456,t:1527268216983};\\\", \\\"{x:463,y:457,t:1527268217000};\\\", \\\"{x:469,y:459,t:1527268217016};\\\", \\\"{x:473,y:460,t:1527268217033};\\\", \\\"{x:478,y:462,t:1527268217050};\\\", \\\"{x:482,y:464,t:1527268217066};\\\", \\\"{x:485,y:466,t:1527268217084};\\\", \\\"{x:488,y:468,t:1527268217101};\\\", \\\"{x:490,y:468,t:1527268217317};\\\", \\\"{x:509,y:474,t:1527268217333};\\\", \\\"{x:535,y:477,t:1527268217350};\\\", \\\"{x:577,y:479,t:1527268217366};\\\", \\\"{x:614,y:479,t:1527268217384};\\\", \\\"{x:640,y:479,t:1527268217400};\\\", \\\"{x:658,y:477,t:1527268217417};\\\", \\\"{x:664,y:475,t:1527268217433};\\\", \\\"{x:668,y:473,t:1527268217451};\\\", \\\"{x:669,y:473,t:1527268217494};\\\", \\\"{x:670,y:473,t:1527268217574};\\\", \\\"{x:670,y:474,t:1527268217981};\\\", \\\"{x:670,y:475,t:1527268218005};\\\", \\\"{x:669,y:475,t:1527268218017};\\\", \\\"{x:668,y:477,t:1527268218037};\\\", \\\"{x:667,y:477,t:1527268218054};\\\", \\\"{x:665,y:479,t:1527268218066};\\\", \\\"{x:660,y:484,t:1527268218083};\\\", \\\"{x:648,y:491,t:1527268218102};\\\", \\\"{x:646,y:492,t:1527268218117};\\\", \\\"{x:634,y:494,t:1527268218133};\\\", \\\"{x:626,y:494,t:1527268218149};\\\", \\\"{x:617,y:494,t:1527268218167};\\\", \\\"{x:609,y:494,t:1527268218184};\\\", \\\"{x:603,y:494,t:1527268218201};\\\", \\\"{x:586,y:494,t:1527268218217};\\\", \\\"{x:562,y:494,t:1527268218234};\\\", \\\"{x:537,y:494,t:1527268218251};\\\", \\\"{x:514,y:494,t:1527268218267};\\\", \\\"{x:489,y:494,t:1527268218284};\\\", \\\"{x:459,y:494,t:1527268218301};\\\", \\\"{x:453,y:494,t:1527268218317};\\\", \\\"{x:437,y:498,t:1527268218333};\\\", \\\"{x:433,y:500,t:1527268218351};\\\", \\\"{x:432,y:501,t:1527268218367};\\\", \\\"{x:431,y:501,t:1527268218383};\\\", \\\"{x:430,y:501,t:1527268218400};\\\", \\\"{x:431,y:501,t:1527268218925};\\\", \\\"{x:432,y:501,t:1527268218965};\\\", \\\"{x:433,y:501,t:1527268218989};\\\", \\\"{x:434,y:501,t:1527268219004};\\\", \\\"{x:436,y:501,t:1527268219029};\\\", \\\"{x:439,y:502,t:1527268219045};\\\", \\\"{x:443,y:504,t:1527268219054};\\\", \\\"{x:444,y:504,t:1527268219066};\\\", \\\"{x:451,y:506,t:1527268219084};\\\", \\\"{x:458,y:508,t:1527268219101};\\\", \\\"{x:474,y:513,t:1527268219117};\\\", \\\"{x:483,y:514,t:1527268219133};\\\", \\\"{x:491,y:517,t:1527268219150};\\\", \\\"{x:494,y:517,t:1527268219166};\\\", \\\"{x:495,y:517,t:1527268219541};\\\", \\\"{x:496,y:516,t:1527268219580};\\\", \\\"{x:497,y:516,t:1527268219588};\\\", \\\"{x:498,y:515,t:1527268219599};\\\", \\\"{x:498,y:514,t:1527268219616};\\\", \\\"{x:501,y:514,t:1527268219633};\\\", \\\"{x:502,y:513,t:1527268219650};\\\", \\\"{x:504,y:511,t:1527268219666};\\\", \\\"{x:509,y:508,t:1527268219683};\\\", \\\"{x:514,y:506,t:1527268219700};\\\", \\\"{x:517,y:504,t:1527268219716};\\\", \\\"{x:518,y:503,t:1527268219733};\\\", \\\"{x:520,y:502,t:1527268219756};\\\", \\\"{x:520,y:501,t:1527268219956};\\\", \\\"{x:521,y:500,t:1527268219988};\\\", \\\"{x:522,y:500,t:1527268220012};\\\", \\\"{x:522,y:499,t:1527268220028};\\\", \\\"{x:523,y:498,t:1527268220061};\\\", \\\"{x:523,y:497,t:1527268220158};\\\", \\\"{x:525,y:497,t:1527268220174};\\\", \\\"{x:528,y:496,t:1527268220183};\\\", \\\"{x:531,y:494,t:1527268220200};\\\", \\\"{x:537,y:492,t:1527268220216};\\\", \\\"{x:541,y:490,t:1527268220233};\\\", \\\"{x:544,y:489,t:1527268220250};\\\", \\\"{x:547,y:489,t:1527268220267};\\\", \\\"{x:551,y:487,t:1527268220283};\\\", \\\"{x:554,y:486,t:1527268220300};\\\", \\\"{x:555,y:486,t:1527268220316};\\\", \\\"{x:556,y:486,t:1527268220334};\\\", \\\"{x:558,y:486,t:1527268220351};\\\", \\\"{x:560,y:486,t:1527268220367};\\\", \\\"{x:563,y:486,t:1527268220383};\\\", \\\"{x:563,y:487,t:1527268220400};\\\", \\\"{x:564,y:487,t:1527268220417};\\\", \\\"{x:566,y:487,t:1527268220653};\\\", \\\"{x:567,y:487,t:1527268220686};\\\", \\\"{x:568,y:487,t:1527268220821};\\\", \\\"{x:569,y:486,t:1527268220834};\\\", \\\"{x:570,y:486,t:1527268220850};\\\", \\\"{x:574,y:486,t:1527268220867};\\\", \\\"{x:579,y:486,t:1527268220884};\\\", \\\"{x:587,y:486,t:1527268220901};\\\", \\\"{x:590,y:486,t:1527268220917};\\\", \\\"{x:594,y:486,t:1527268220934};\\\", \\\"{x:595,y:486,t:1527268220950};\\\", \\\"{x:596,y:486,t:1527268220966};\\\", \\\"{x:598,y:486,t:1527268220989};\\\", \\\"{x:600,y:486,t:1527268221029};\\\", \\\"{x:601,y:485,t:1527268221045};\\\", \\\"{x:603,y:485,t:1527268221062};\\\", \\\"{x:604,y:484,t:1527268221069};\\\", \\\"{x:605,y:484,t:1527268221084};\\\", \\\"{x:609,y:484,t:1527268221102};\\\", \\\"{x:613,y:484,t:1527268221116};\\\", \\\"{x:618,y:484,t:1527268221133};\\\", \\\"{x:625,y:484,t:1527268221150};\\\", \\\"{x:633,y:484,t:1527268221166};\\\", \\\"{x:638,y:485,t:1527268221183};\\\", \\\"{x:641,y:485,t:1527268221200};\\\", \\\"{x:641,y:486,t:1527268222141};\\\", \\\"{x:640,y:487,t:1527268222150};\\\", \\\"{x:630,y:490,t:1527268222166};\\\", \\\"{x:615,y:494,t:1527268222183};\\\", \\\"{x:597,y:495,t:1527268222200};\\\", \\\"{x:588,y:497,t:1527268222216};\\\", \\\"{x:581,y:497,t:1527268222234};\\\", \\\"{x:580,y:497,t:1527268222250};\\\", \\\"{x:579,y:497,t:1527268222266};\\\", \\\"{x:579,y:496,t:1527268222853};\\\", \\\"{x:579,y:495,t:1527268222867};\\\", \\\"{x:579,y:494,t:1527268222884};\\\", \\\"{x:580,y:493,t:1527268222900};\\\", \\\"{x:581,y:492,t:1527268222917};\\\", \\\"{x:583,y:492,t:1527268222934};\\\", \\\"{x:583,y:491,t:1527268222951};\\\", \\\"{x:585,y:490,t:1527268222966};\\\", \\\"{x:586,y:490,t:1527268222983};\\\", \\\"{x:589,y:489,t:1527268223001};\\\", \\\"{x:590,y:488,t:1527268223017};\\\", \\\"{x:593,y:487,t:1527268223034};\\\", \\\"{x:595,y:484,t:1527268223051};\\\", \\\"{x:599,y:483,t:1527268223067};\\\", \\\"{x:602,y:481,t:1527268223084};\\\", \\\"{x:603,y:480,t:1527268223100};\\\", \\\"{x:604,y:480,t:1527268223117};\\\", \\\"{x:605,y:480,t:1527268223174};\\\", \\\"{x:606,y:480,t:1527268223213};\\\", \\\"{x:607,y:480,t:1527268223293};\\\", \\\"{x:607,y:479,t:1527268223309};\\\", \\\"{x:608,y:479,t:1527268223367};\\\", \\\"{x:609,y:479,t:1527268223973};\\\", \\\"{x:611,y:479,t:1527268223997};\\\", \\\"{x:613,y:480,t:1527268224030};\\\", \\\"{x:613,y:481,t:1527268224158};\\\", \\\"{x:614,y:481,t:1527268224254};\\\", \\\"{x:615,y:482,t:1527268224334};\\\", \\\"{x:617,y:482,t:1527268224501};\\\", \\\"{x:617,y:483,t:1527268224549};\\\", \\\"{x:618,y:483,t:1527268224885};\\\", \\\"{x:618,y:484,t:1527268225468};\\\", \\\"{x:618,y:485,t:1527268225516};\\\", \\\"{x:618,y:486,t:1527268225540};\\\", \\\"{x:618,y:487,t:1527268225581};\\\", \\\"{x:618,y:488,t:1527268225614};\\\", \\\"{x:618,y:489,t:1527268225654};\\\", \\\"{x:619,y:490,t:1527268225684};\\\", \\\"{x:619,y:492,t:1527268225710};\\\", \\\"{x:620,y:493,t:1527268225717};\\\", \\\"{x:621,y:494,t:1527268225734};\\\", \\\"{x:621,y:495,t:1527268225751};\\\", \\\"{x:622,y:496,t:1527268225767};\\\", \\\"{x:624,y:497,t:1527268225784};\\\", \\\"{x:627,y:499,t:1527268225821};\\\", \\\"{x:629,y:499,t:1527268225837};\\\", \\\"{x:631,y:500,t:1527268225851};\\\", \\\"{x:636,y:502,t:1527268225867};\\\", \\\"{x:644,y:504,t:1527268225885};\\\", \\\"{x:664,y:507,t:1527268225901};\\\", \\\"{x:678,y:509,t:1527268225917};\\\", \\\"{x:690,y:510,t:1527268225933};\\\", \\\"{x:702,y:512,t:1527268225951};\\\", \\\"{x:708,y:514,t:1527268225967};\\\", \\\"{x:715,y:515,t:1527268225984};\\\", \\\"{x:722,y:519,t:1527268226001};\\\", \\\"{x:731,y:522,t:1527268226019};\\\", \\\"{x:741,y:527,t:1527268226033};\\\", \\\"{x:757,y:531,t:1527268226051};\\\", \\\"{x:789,y:539,t:1527268226072};\\\", \\\"{x:814,y:545,t:1527268226088};\\\", \\\"{x:848,y:551,t:1527268226105};\\\", \\\"{x:885,y:563,t:1527268226122};\\\", \\\"{x:941,y:584,t:1527268226141};\\\", \\\"{x:993,y:607,t:1527268226158};\\\", \\\"{x:1046,y:630,t:1527268226174};\\\", \\\"{x:1082,y:645,t:1527268226190};\\\", \\\"{x:1120,y:659,t:1527268226207};\\\", \\\"{x:1148,y:668,t:1527268226225};\\\", \\\"{x:1173,y:676,t:1527268226241};\\\", \\\"{x:1194,y:680,t:1527268226258};\\\", \\\"{x:1209,y:682,t:1527268226275};\\\", \\\"{x:1221,y:684,t:1527268226292};\\\", \\\"{x:1228,y:686,t:1527268226308};\\\", \\\"{x:1243,y:691,t:1527268226324};\\\", \\\"{x:1267,y:700,t:1527268226342};\\\", \\\"{x:1306,y:711,t:1527268226359};\\\", \\\"{x:1344,y:721,t:1527268226375};\\\", \\\"{x:1378,y:730,t:1527268226392};\\\", \\\"{x:1397,y:732,t:1527268226409};\\\", \\\"{x:1410,y:736,t:1527268226426};\\\", \\\"{x:1413,y:737,t:1527268226442};\\\", \\\"{x:1415,y:738,t:1527268226459};\\\", \\\"{x:1417,y:739,t:1527268226476};\\\", \\\"{x:1417,y:740,t:1527268226492};\\\", \\\"{x:1418,y:740,t:1527268226509};\\\", \\\"{x:1419,y:740,t:1527268226566};\\\", \\\"{x:1420,y:739,t:1527268226576};\\\", \\\"{x:1420,y:735,t:1527268226592};\\\", \\\"{x:1420,y:730,t:1527268226610};\\\", \\\"{x:1420,y:726,t:1527268226625};\\\", \\\"{x:1420,y:721,t:1527268226642};\\\", \\\"{x:1418,y:715,t:1527268226659};\\\", \\\"{x:1414,y:707,t:1527268226676};\\\", \\\"{x:1412,y:702,t:1527268226693};\\\", \\\"{x:1410,y:698,t:1527268226710};\\\", \\\"{x:1408,y:694,t:1527268226726};\\\", \\\"{x:1406,y:690,t:1527268226743};\\\", \\\"{x:1404,y:686,t:1527268226760};\\\", \\\"{x:1402,y:680,t:1527268226777};\\\", \\\"{x:1399,y:674,t:1527268226794};\\\", \\\"{x:1398,y:667,t:1527268226809};\\\", \\\"{x:1393,y:658,t:1527268226827};\\\", \\\"{x:1391,y:653,t:1527268226844};\\\", \\\"{x:1388,y:646,t:1527268226861};\\\", \\\"{x:1385,y:641,t:1527268226877};\\\", \\\"{x:1383,y:638,t:1527268226893};\\\", \\\"{x:1382,y:634,t:1527268226911};\\\", \\\"{x:1378,y:629,t:1527268226928};\\\", \\\"{x:1375,y:623,t:1527268226944};\\\", \\\"{x:1370,y:615,t:1527268226961};\\\", \\\"{x:1366,y:608,t:1527268226978};\\\", \\\"{x:1361,y:601,t:1527268226993};\\\", \\\"{x:1357,y:596,t:1527268227010};\\\", \\\"{x:1353,y:590,t:1527268227027};\\\", \\\"{x:1348,y:586,t:1527268227044};\\\", \\\"{x:1346,y:584,t:1527268227061};\\\", \\\"{x:1344,y:582,t:1527268227078};\\\", \\\"{x:1343,y:581,t:1527268227095};\\\", \\\"{x:1341,y:579,t:1527268227112};\\\", \\\"{x:1341,y:577,t:1527268227128};\\\", \\\"{x:1339,y:576,t:1527268227145};\\\", \\\"{x:1337,y:572,t:1527268227162};\\\", \\\"{x:1336,y:568,t:1527268227178};\\\", \\\"{x:1332,y:562,t:1527268227195};\\\", \\\"{x:1328,y:556,t:1527268227211};\\\", \\\"{x:1324,y:549,t:1527268227229};\\\", \\\"{x:1320,y:542,t:1527268227246};\\\", \\\"{x:1317,y:537,t:1527268227262};\\\", \\\"{x:1313,y:526,t:1527268227279};\\\", \\\"{x:1312,y:521,t:1527268227296};\\\", \\\"{x:1311,y:516,t:1527268227311};\\\", \\\"{x:1310,y:514,t:1527268227329};\\\", \\\"{x:1309,y:512,t:1527268227346};\\\", \\\"{x:1309,y:511,t:1527268227363};\\\", \\\"{x:1309,y:510,t:1527268227379};\\\", \\\"{x:1309,y:509,t:1527268227396};\\\", \\\"{x:1309,y:507,t:1527268227413};\\\", \\\"{x:1308,y:504,t:1527268227430};\\\", \\\"{x:1308,y:502,t:1527268227446};\\\", \\\"{x:1308,y:500,t:1527268227463};\\\", \\\"{x:1308,y:499,t:1527268227481};\\\", \\\"{x:1308,y:498,t:1527268227497};\\\", \\\"{x:1308,y:499,t:1527268228301};\\\", \\\"{x:1308,y:500,t:1527268228326};\\\", \\\"{x:1308,y:501,t:1527268228542};\\\", \\\"{x:1308,y:502,t:1527268229038};\\\", \\\"{x:1308,y:503,t:1527268229758};\\\", \\\"{x:1308,y:504,t:1527268230430};\\\", \\\"{x:1307,y:506,t:1527268230442};\\\", \\\"{x:1306,y:506,t:1527268230459};\\\", \\\"{x:1306,y:507,t:1527268234901};\\\", \\\"{x:1306,y:508,t:1527268235246};\\\", \\\"{x:1306,y:509,t:1527268237861};\\\", \\\"{x:1306,y:510,t:1527268238126};\\\", \\\"{x:1306,y:511,t:1527268238333};\\\", \\\"{x:1306,y:512,t:1527268238341};\\\", \\\"{x:1306,y:514,t:1527268238357};\\\", \\\"{x:1306,y:515,t:1527268238382};\\\", \\\"{x:1306,y:517,t:1527268238582};\\\", \\\"{x:1306,y:518,t:1527268238592};\\\", \\\"{x:1307,y:520,t:1527268238608};\\\", \\\"{x:1307,y:522,t:1527268238624};\\\", \\\"{x:1307,y:524,t:1527268238641};\\\", \\\"{x:1307,y:525,t:1527268238659};\\\", \\\"{x:1308,y:527,t:1527268238694};\\\", \\\"{x:1309,y:529,t:1527268238709};\\\", \\\"{x:1309,y:531,t:1527268238725};\\\", \\\"{x:1310,y:536,t:1527268238742};\\\", \\\"{x:1310,y:541,t:1527268238759};\\\", \\\"{x:1311,y:546,t:1527268238775};\\\", \\\"{x:1312,y:554,t:1527268238792};\\\", \\\"{x:1312,y:561,t:1527268238809};\\\", \\\"{x:1312,y:569,t:1527268238826};\\\", \\\"{x:1313,y:579,t:1527268238843};\\\", \\\"{x:1314,y:591,t:1527268238859};\\\", \\\"{x:1315,y:598,t:1527268238876};\\\", \\\"{x:1318,y:603,t:1527268238894};\\\", \\\"{x:1318,y:604,t:1527268238910};\\\", \\\"{x:1319,y:605,t:1527268238925};\\\", \\\"{x:1320,y:608,t:1527268238942};\\\", \\\"{x:1321,y:610,t:1527268238960};\\\", \\\"{x:1321,y:614,t:1527268238976};\\\", \\\"{x:1322,y:618,t:1527268238993};\\\", \\\"{x:1322,y:623,t:1527268239009};\\\", \\\"{x:1322,y:630,t:1527268239027};\\\", \\\"{x:1324,y:639,t:1527268239043};\\\", \\\"{x:1326,y:648,t:1527268239060};\\\", \\\"{x:1327,y:662,t:1527268239077};\\\", \\\"{x:1329,y:671,t:1527268239093};\\\", \\\"{x:1329,y:677,t:1527268239110};\\\", \\\"{x:1329,y:679,t:1527268239126};\\\", \\\"{x:1329,y:681,t:1527268239144};\\\", \\\"{x:1329,y:682,t:1527268239206};\\\", \\\"{x:1329,y:684,t:1527268239213};\\\", \\\"{x:1329,y:685,t:1527268239227};\\\", \\\"{x:1329,y:689,t:1527268239244};\\\", \\\"{x:1329,y:696,t:1527268239262};\\\", \\\"{x:1329,y:703,t:1527268239277};\\\", \\\"{x:1329,y:711,t:1527268239294};\\\", \\\"{x:1329,y:718,t:1527268239311};\\\", \\\"{x:1329,y:724,t:1527268239328};\\\", \\\"{x:1329,y:733,t:1527268239345};\\\", \\\"{x:1328,y:739,t:1527268239361};\\\", \\\"{x:1327,y:742,t:1527268239378};\\\", \\\"{x:1327,y:744,t:1527268239395};\\\", \\\"{x:1326,y:745,t:1527268239412};\\\", \\\"{x:1326,y:746,t:1527268239486};\\\", \\\"{x:1326,y:747,t:1527268239501};\\\", \\\"{x:1326,y:748,t:1527268239517};\\\", \\\"{x:1326,y:749,t:1527268239533};\\\", \\\"{x:1326,y:751,t:1527268239544};\\\", \\\"{x:1326,y:755,t:1527268239562};\\\", \\\"{x:1326,y:760,t:1527268239579};\\\", \\\"{x:1326,y:764,t:1527268239595};\\\", \\\"{x:1326,y:769,t:1527268239612};\\\", \\\"{x:1326,y:773,t:1527268239629};\\\", \\\"{x:1326,y:774,t:1527268239645};\\\", \\\"{x:1326,y:776,t:1527268239662};\\\", \\\"{x:1326,y:777,t:1527268239685};\\\", \\\"{x:1326,y:779,t:1527268239696};\\\", \\\"{x:1326,y:783,t:1527268239713};\\\", \\\"{x:1326,y:791,t:1527268239730};\\\", \\\"{x:1326,y:800,t:1527268239746};\\\", \\\"{x:1326,y:807,t:1527268239763};\\\", \\\"{x:1326,y:812,t:1527268239780};\\\", \\\"{x:1326,y:819,t:1527268239795};\\\", \\\"{x:1326,y:828,t:1527268239813};\\\", \\\"{x:1326,y:836,t:1527268239829};\\\", \\\"{x:1326,y:842,t:1527268239846};\\\", \\\"{x:1326,y:844,t:1527268239863};\\\", \\\"{x:1326,y:846,t:1527268239879};\\\", \\\"{x:1326,y:847,t:1527268240022};\\\", \\\"{x:1326,y:848,t:1527268240037};\\\", \\\"{x:1326,y:849,t:1527268240047};\\\", \\\"{x:1326,y:852,t:1527268240064};\\\", \\\"{x:1326,y:856,t:1527268240081};\\\", \\\"{x:1325,y:859,t:1527268240098};\\\", \\\"{x:1325,y:860,t:1527268240114};\\\", \\\"{x:1325,y:862,t:1527268240131};\\\", \\\"{x:1325,y:863,t:1527268240373};\\\", \\\"{x:1324,y:862,t:1527268240381};\\\", \\\"{x:1324,y:845,t:1527268240399};\\\", \\\"{x:1324,y:819,t:1527268240416};\\\", \\\"{x:1328,y:784,t:1527268240432};\\\", \\\"{x:1328,y:756,t:1527268240449};\\\", \\\"{x:1328,y:734,t:1527268240465};\\\", \\\"{x:1328,y:716,t:1527268240482};\\\", \\\"{x:1328,y:690,t:1527268240499};\\\", \\\"{x:1328,y:663,t:1527268240515};\\\", \\\"{x:1328,y:628,t:1527268240534};\\\", \\\"{x:1328,y:611,t:1527268240549};\\\", \\\"{x:1328,y:600,t:1527268240565};\\\", \\\"{x:1328,y:595,t:1527268240582};\\\", \\\"{x:1328,y:591,t:1527268240600};\\\", \\\"{x:1328,y:583,t:1527268240616};\\\", \\\"{x:1328,y:579,t:1527268240633};\\\", \\\"{x:1327,y:570,t:1527268240650};\\\", \\\"{x:1324,y:559,t:1527268240667};\\\", \\\"{x:1321,y:547,t:1527268240682};\\\", \\\"{x:1317,y:537,t:1527268240700};\\\", \\\"{x:1312,y:524,t:1527268240717};\\\", \\\"{x:1309,y:520,t:1527268240734};\\\", \\\"{x:1308,y:517,t:1527268240750};\\\", \\\"{x:1306,y:514,t:1527268240767};\\\", \\\"{x:1306,y:512,t:1527268240784};\\\", \\\"{x:1305,y:512,t:1527268242126};\\\", \\\"{x:1305,y:513,t:1527268242308};\\\", \\\"{x:1305,y:516,t:1527268242322};\\\", \\\"{x:1305,y:522,t:1527268242340};\\\", \\\"{x:1305,y:528,t:1527268242356};\\\", \\\"{x:1305,y:531,t:1527268242373};\\\", \\\"{x:1305,y:532,t:1527268242397};\\\", \\\"{x:1305,y:533,t:1527268242429};\\\", \\\"{x:1305,y:535,t:1527268242453};\\\", \\\"{x:1305,y:538,t:1527268242469};\\\", \\\"{x:1305,y:541,t:1527268242477};\\\", \\\"{x:1305,y:546,t:1527268242490};\\\", \\\"{x:1305,y:556,t:1527268242507};\\\", \\\"{x:1307,y:568,t:1527268242524};\\\", \\\"{x:1307,y:587,t:1527268242541};\\\", \\\"{x:1307,y:599,t:1527268242557};\\\", \\\"{x:1308,y:615,t:1527268242573};\\\", \\\"{x:1308,y:632,t:1527268242590};\\\", \\\"{x:1309,y:648,t:1527268242607};\\\", \\\"{x:1309,y:657,t:1527268242624};\\\", \\\"{x:1309,y:666,t:1527268242640};\\\", \\\"{x:1308,y:670,t:1527268242657};\\\", \\\"{x:1306,y:673,t:1527268242675};\\\", \\\"{x:1304,y:676,t:1527268242691};\\\", \\\"{x:1302,y:681,t:1527268242708};\\\", \\\"{x:1299,y:695,t:1527268242725};\\\", \\\"{x:1298,y:705,t:1527268242741};\\\", \\\"{x:1297,y:714,t:1527268242758};\\\", \\\"{x:1296,y:723,t:1527268242774};\\\", \\\"{x:1296,y:730,t:1527268242792};\\\", \\\"{x:1296,y:744,t:1527268242807};\\\", \\\"{x:1296,y:762,t:1527268242824};\\\", \\\"{x:1296,y:777,t:1527268242841};\\\", \\\"{x:1298,y:791,t:1527268242858};\\\", \\\"{x:1305,y:803,t:1527268242875};\\\", \\\"{x:1311,y:810,t:1527268242891};\\\", \\\"{x:1320,y:816,t:1527268242909};\\\", \\\"{x:1325,y:819,t:1527268242925};\\\", \\\"{x:1327,y:819,t:1527268242942};\\\", \\\"{x:1329,y:820,t:1527268242959};\\\", \\\"{x:1330,y:821,t:1527268243021};\\\", \\\"{x:1331,y:822,t:1527268243085};\\\", \\\"{x:1331,y:824,t:1527268243101};\\\", \\\"{x:1331,y:826,t:1527268243109};\\\", \\\"{x:1331,y:828,t:1527268243126};\\\", \\\"{x:1331,y:829,t:1527268243142};\\\", \\\"{x:1331,y:824,t:1527268243454};\\\", \\\"{x:1331,y:820,t:1527268243461};\\\", \\\"{x:1331,y:806,t:1527268243478};\\\", \\\"{x:1331,y:788,t:1527268243494};\\\", \\\"{x:1331,y:769,t:1527268243511};\\\", \\\"{x:1333,y:750,t:1527268243528};\\\", \\\"{x:1333,y:731,t:1527268243545};\\\", \\\"{x:1333,y:715,t:1527268243561};\\\", \\\"{x:1333,y:702,t:1527268243578};\\\", \\\"{x:1333,y:689,t:1527268243595};\\\", \\\"{x:1332,y:678,t:1527268243612};\\\", \\\"{x:1330,y:667,t:1527268243628};\\\", \\\"{x:1327,y:659,t:1527268243645};\\\", \\\"{x:1325,y:650,t:1527268243663};\\\", \\\"{x:1325,y:646,t:1527268243680};\\\", \\\"{x:1323,y:639,t:1527268243695};\\\", \\\"{x:1321,y:635,t:1527268243712};\\\", \\\"{x:1319,y:629,t:1527268243732};\\\", \\\"{x:1317,y:625,t:1527268243745};\\\", \\\"{x:1315,y:620,t:1527268243762};\\\", \\\"{x:1313,y:617,t:1527268243778};\\\", \\\"{x:1312,y:616,t:1527268243795};\\\", \\\"{x:1312,y:619,t:1527268244078};\\\", \\\"{x:1312,y:622,t:1527268244084};\\\", \\\"{x:1312,y:626,t:1527268244097};\\\", \\\"{x:1312,y:637,t:1527268244115};\\\", \\\"{x:1312,y:646,t:1527268244130};\\\", \\\"{x:1312,y:654,t:1527268244147};\\\", \\\"{x:1312,y:663,t:1527268244165};\\\", \\\"{x:1312,y:665,t:1527268244181};\\\", \\\"{x:1312,y:666,t:1527268244237};\\\", \\\"{x:1312,y:667,t:1527268244342};\\\", \\\"{x:1312,y:668,t:1527268244357};\\\", \\\"{x:1312,y:669,t:1527268244367};\\\", \\\"{x:1312,y:671,t:1527268244380};\\\", \\\"{x:1312,y:675,t:1527268244397};\\\", \\\"{x:1312,y:678,t:1527268244415};\\\", \\\"{x:1312,y:680,t:1527268244432};\\\", \\\"{x:1312,y:681,t:1527268244452};\\\", \\\"{x:1312,y:682,t:1527268244645};\\\", \\\"{x:1312,y:683,t:1527268244662};\\\", \\\"{x:1312,y:684,t:1527268244669};\\\", \\\"{x:1312,y:685,t:1527268244683};\\\", \\\"{x:1312,y:686,t:1527268244886};\\\", \\\"{x:1312,y:687,t:1527268244900};\\\", \\\"{x:1312,y:690,t:1527268244917};\\\", \\\"{x:1312,y:691,t:1527268245374};\\\", \\\"{x:1312,y:692,t:1527268245397};\\\", \\\"{x:1312,y:694,t:1527268245412};\\\", \\\"{x:1312,y:695,t:1527268245893};\\\", \\\"{x:1312,y:697,t:1527268246189};\\\", \\\"{x:1311,y:698,t:1527268248301};\\\", \\\"{x:1310,y:696,t:1527268254438};\\\", \\\"{x:1309,y:695,t:1527268254485};\\\", \\\"{x:1308,y:694,t:1527268254501};\\\", \\\"{x:1308,y:693,t:1527268254509};\\\", \\\"{x:1307,y:691,t:1527268254533};\\\", \\\"{x:1307,y:690,t:1527268254581};\\\", \\\"{x:1307,y:689,t:1527268254597};\\\", \\\"{x:1306,y:688,t:1527268254605};\\\", \\\"{x:1305,y:687,t:1527268254622};\\\", \\\"{x:1303,y:682,t:1527268254640};\\\", \\\"{x:1302,y:675,t:1527268254657};\\\", \\\"{x:1300,y:662,t:1527268254672};\\\", \\\"{x:1298,y:647,t:1527268254690};\\\", \\\"{x:1297,y:631,t:1527268254707};\\\", \\\"{x:1297,y:614,t:1527268254723};\\\", \\\"{x:1296,y:602,t:1527268254740};\\\", \\\"{x:1294,y:591,t:1527268254756};\\\", \\\"{x:1294,y:585,t:1527268254772};\\\", \\\"{x:1294,y:580,t:1527268254790};\\\", \\\"{x:1294,y:576,t:1527268254806};\\\", \\\"{x:1293,y:573,t:1527268254823};\\\", \\\"{x:1292,y:570,t:1527268254840};\\\", \\\"{x:1292,y:566,t:1527268254856};\\\", \\\"{x:1291,y:564,t:1527268254873};\\\", \\\"{x:1291,y:560,t:1527268254890};\\\", \\\"{x:1290,y:553,t:1527268254908};\\\", \\\"{x:1289,y:546,t:1527268254924};\\\", \\\"{x:1289,y:534,t:1527268254941};\\\", \\\"{x:1289,y:529,t:1527268254957};\\\", \\\"{x:1289,y:524,t:1527268254974};\\\", \\\"{x:1289,y:519,t:1527268254990};\\\", \\\"{x:1289,y:518,t:1527268255008};\\\", \\\"{x:1290,y:515,t:1527268255024};\\\", \\\"{x:1291,y:514,t:1527268255181};\\\", \\\"{x:1291,y:513,t:1527268255213};\\\", \\\"{x:1291,y:512,t:1527268255229};\\\", \\\"{x:1292,y:511,t:1527268255253};\\\", \\\"{x:1292,y:510,t:1527268255269};\\\", \\\"{x:1293,y:509,t:1527268255276};\\\", \\\"{x:1294,y:508,t:1527268255446};\\\", \\\"{x:1295,y:506,t:1527268255493};\\\", \\\"{x:1297,y:505,t:1527268255524};\\\", \\\"{x:1297,y:506,t:1527268255628};\\\", \\\"{x:1297,y:507,t:1527268255669};\\\", \\\"{x:1297,y:508,t:1527268255718};\\\", \\\"{x:1297,y:509,t:1527268255732};\\\", \\\"{x:1297,y:511,t:1527268255744};\\\", \\\"{x:1298,y:516,t:1527268255760};\\\", \\\"{x:1299,y:527,t:1527268255777};\\\", \\\"{x:1302,y:543,t:1527268255794};\\\", \\\"{x:1302,y:559,t:1527268255810};\\\", \\\"{x:1302,y:580,t:1527268255827};\\\", \\\"{x:1303,y:615,t:1527268255845};\\\", \\\"{x:1303,y:635,t:1527268255861};\\\", \\\"{x:1303,y:651,t:1527268255878};\\\", \\\"{x:1303,y:658,t:1527268255894};\\\", \\\"{x:1303,y:662,t:1527268255911};\\\", \\\"{x:1303,y:665,t:1527268255928};\\\", \\\"{x:1303,y:666,t:1527268255944};\\\", \\\"{x:1303,y:668,t:1527268255961};\\\", \\\"{x:1303,y:671,t:1527268255977};\\\", \\\"{x:1303,y:675,t:1527268255995};\\\", \\\"{x:1303,y:681,t:1527268256011};\\\", \\\"{x:1302,y:691,t:1527268256028};\\\", \\\"{x:1302,y:701,t:1527268256044};\\\", \\\"{x:1302,y:718,t:1527268256061};\\\", \\\"{x:1302,y:738,t:1527268256078};\\\", \\\"{x:1302,y:760,t:1527268256095};\\\", \\\"{x:1302,y:780,t:1527268256111};\\\", \\\"{x:1302,y:790,t:1527268256128};\\\", \\\"{x:1302,y:795,t:1527268256145};\\\", \\\"{x:1302,y:796,t:1527268256162};\\\", \\\"{x:1302,y:797,t:1527268256178};\\\", \\\"{x:1302,y:798,t:1527268256195};\\\", \\\"{x:1304,y:802,t:1527268256213};\\\", \\\"{x:1304,y:804,t:1527268256228};\\\", \\\"{x:1305,y:807,t:1527268256245};\\\", \\\"{x:1306,y:813,t:1527268256262};\\\", \\\"{x:1306,y:818,t:1527268256279};\\\", \\\"{x:1306,y:826,t:1527268256295};\\\", \\\"{x:1306,y:839,t:1527268256313};\\\", \\\"{x:1306,y:852,t:1527268256329};\\\", \\\"{x:1306,y:866,t:1527268256347};\\\", \\\"{x:1306,y:879,t:1527268256363};\\\", \\\"{x:1306,y:883,t:1527268256379};\\\", \\\"{x:1306,y:884,t:1527268256582};\\\", \\\"{x:1306,y:881,t:1527268256694};\\\", \\\"{x:1307,y:875,t:1527268256701};\\\", \\\"{x:1309,y:865,t:1527268256714};\\\", \\\"{x:1313,y:842,t:1527268256731};\\\", \\\"{x:1315,y:817,t:1527268256747};\\\", \\\"{x:1316,y:781,t:1527268256767};\\\", \\\"{x:1316,y:764,t:1527268256781};\\\", \\\"{x:1316,y:752,t:1527268256797};\\\", \\\"{x:1316,y:746,t:1527268256815};\\\", \\\"{x:1316,y:740,t:1527268256832};\\\", \\\"{x:1316,y:734,t:1527268256848};\\\", \\\"{x:1317,y:723,t:1527268256865};\\\", \\\"{x:1317,y:715,t:1527268256881};\\\", \\\"{x:1317,y:710,t:1527268256899};\\\", \\\"{x:1318,y:708,t:1527268256915};\\\", \\\"{x:1318,y:706,t:1527268256932};\\\", \\\"{x:1319,y:706,t:1527268257021};\\\", \\\"{x:1320,y:708,t:1527268257033};\\\", \\\"{x:1320,y:721,t:1527268257048};\\\", \\\"{x:1324,y:743,t:1527268257066};\\\", \\\"{x:1325,y:766,t:1527268257083};\\\", \\\"{x:1326,y:790,t:1527268257099};\\\", \\\"{x:1326,y:803,t:1527268257116};\\\", \\\"{x:1326,y:809,t:1527268257132};\\\", \\\"{x:1327,y:810,t:1527268257149};\\\", \\\"{x:1327,y:811,t:1527268257173};\\\", \\\"{x:1329,y:812,t:1527268257188};\\\", \\\"{x:1329,y:813,t:1527268257212};\\\", \\\"{x:1329,y:815,t:1527268257228};\\\", \\\"{x:1329,y:816,t:1527268257236};\\\", \\\"{x:1330,y:817,t:1527268257249};\\\", \\\"{x:1330,y:823,t:1527268257266};\\\", \\\"{x:1331,y:831,t:1527268257283};\\\", \\\"{x:1331,y:839,t:1527268257300};\\\", \\\"{x:1331,y:853,t:1527268257316};\\\", \\\"{x:1331,y:862,t:1527268257333};\\\", \\\"{x:1331,y:866,t:1527268257351};\\\", \\\"{x:1331,y:867,t:1527268257366};\\\", \\\"{x:1330,y:867,t:1527268257708};\\\", \\\"{x:1329,y:866,t:1527268257718};\\\", \\\"{x:1328,y:866,t:1527268257735};\\\", \\\"{x:1325,y:865,t:1527268257752};\\\", \\\"{x:1323,y:864,t:1527268257768};\\\", \\\"{x:1322,y:864,t:1527268257797};\\\", \\\"{x:1320,y:864,t:1527268257813};\\\", \\\"{x:1318,y:865,t:1527268257821};\\\", \\\"{x:1317,y:866,t:1527268257835};\\\", \\\"{x:1315,y:867,t:1527268257853};\\\", \\\"{x:1314,y:870,t:1527268258549};\\\", \\\"{x:1313,y:870,t:1527268258557};\\\", \\\"{x:1313,y:872,t:1527268258572};\\\", \\\"{x:1311,y:880,t:1527268258589};\\\", \\\"{x:1310,y:882,t:1527268258605};\\\", \\\"{x:1310,y:883,t:1527268258622};\\\", \\\"{x:1310,y:885,t:1527268258677};\\\", \\\"{x:1310,y:886,t:1527268258733};\\\", \\\"{x:1311,y:888,t:1527268258774};\\\", \\\"{x:1311,y:890,t:1527268258790};\\\", \\\"{x:1312,y:893,t:1527268258806};\\\", \\\"{x:1312,y:897,t:1527268258822};\\\", \\\"{x:1312,y:900,t:1527268258840};\\\", \\\"{x:1312,y:904,t:1527268258857};\\\", \\\"{x:1313,y:905,t:1527268258877};\\\", \\\"{x:1314,y:906,t:1527268258917};\\\", \\\"{x:1315,y:906,t:1527268258949};\\\", \\\"{x:1315,y:907,t:1527268258997};\\\", \\\"{x:1315,y:909,t:1527268259029};\\\", \\\"{x:1315,y:910,t:1527268259041};\\\", \\\"{x:1315,y:914,t:1527268259057};\\\", \\\"{x:1315,y:920,t:1527268259074};\\\", \\\"{x:1315,y:925,t:1527268259091};\\\", \\\"{x:1315,y:928,t:1527268259108};\\\", \\\"{x:1315,y:929,t:1527268259123};\\\", \\\"{x:1315,y:930,t:1527268259213};\\\", \\\"{x:1315,y:931,t:1527268259301};\\\", \\\"{x:1315,y:932,t:1527268259317};\\\", \\\"{x:1315,y:933,t:1527268259325};\\\", \\\"{x:1315,y:936,t:1527268259342};\\\", \\\"{x:1315,y:937,t:1527268259359};\\\", \\\"{x:1315,y:938,t:1527268259573};\\\", \\\"{x:1312,y:938,t:1527268259637};\\\", \\\"{x:1309,y:936,t:1527268259644};\\\", \\\"{x:1307,y:936,t:1527268259660};\\\", \\\"{x:1294,y:929,t:1527268259677};\\\", \\\"{x:1278,y:923,t:1527268259692};\\\", \\\"{x:1262,y:915,t:1527268259709};\\\", \\\"{x:1251,y:911,t:1527268259727};\\\", \\\"{x:1242,y:907,t:1527268259743};\\\", \\\"{x:1239,y:905,t:1527268259759};\\\", \\\"{x:1237,y:905,t:1527268259776};\\\", \\\"{x:1236,y:904,t:1527268259845};\\\", \\\"{x:1234,y:902,t:1527268259860};\\\", \\\"{x:1231,y:899,t:1527268259876};\\\", \\\"{x:1228,y:895,t:1527268259893};\\\", \\\"{x:1224,y:887,t:1527268259910};\\\", \\\"{x:1222,y:881,t:1527268259927};\\\", \\\"{x:1220,y:875,t:1527268259943};\\\", \\\"{x:1219,y:869,t:1527268259960};\\\", \\\"{x:1218,y:865,t:1527268259978};\\\", \\\"{x:1217,y:861,t:1527268259994};\\\", \\\"{x:1217,y:860,t:1527268260011};\\\", \\\"{x:1216,y:859,t:1527268260028};\\\", \\\"{x:1216,y:858,t:1527268260142};\\\", \\\"{x:1216,y:856,t:1527268260157};\\\", \\\"{x:1216,y:855,t:1527268260166};\\\", \\\"{x:1216,y:854,t:1527268260179};\\\", \\\"{x:1214,y:850,t:1527268260194};\\\", \\\"{x:1214,y:847,t:1527268260211};\\\", \\\"{x:1214,y:845,t:1527268260228};\\\", \\\"{x:1214,y:844,t:1527268260245};\\\", \\\"{x:1214,y:843,t:1527268260405};\\\", \\\"{x:1214,y:842,t:1527268260412};\\\", \\\"{x:1214,y:841,t:1527268260429};\\\", \\\"{x:1214,y:839,t:1527268260445};\\\", \\\"{x:1214,y:838,t:1527268260462};\\\", \\\"{x:1214,y:836,t:1527268260480};\\\", \\\"{x:1214,y:835,t:1527268260496};\\\", \\\"{x:1214,y:836,t:1527268260805};\\\", \\\"{x:1214,y:838,t:1527268260814};\\\", \\\"{x:1213,y:842,t:1527268260831};\\\", \\\"{x:1212,y:848,t:1527268260847};\\\", \\\"{x:1212,y:852,t:1527268260865};\\\", \\\"{x:1211,y:857,t:1527268260881};\\\", \\\"{x:1211,y:860,t:1527268260898};\\\", \\\"{x:1210,y:863,t:1527268260915};\\\", \\\"{x:1210,y:864,t:1527268260932};\\\", \\\"{x:1210,y:867,t:1527268260947};\\\", \\\"{x:1210,y:870,t:1527268260966};\\\", \\\"{x:1210,y:874,t:1527268260981};\\\", \\\"{x:1210,y:877,t:1527268260998};\\\", \\\"{x:1209,y:882,t:1527268261015};\\\", \\\"{x:1208,y:887,t:1527268261032};\\\", \\\"{x:1208,y:889,t:1527268261049};\\\", \\\"{x:1208,y:892,t:1527268261064};\\\", \\\"{x:1208,y:896,t:1527268261081};\\\", \\\"{x:1208,y:901,t:1527268261099};\\\", \\\"{x:1208,y:905,t:1527268261116};\\\", \\\"{x:1208,y:908,t:1527268261132};\\\", \\\"{x:1208,y:909,t:1527268261149};\\\", \\\"{x:1208,y:910,t:1527268261166};\\\", \\\"{x:1208,y:911,t:1527268261213};\\\", \\\"{x:1208,y:912,t:1527268261228};\\\", \\\"{x:1208,y:913,t:1527268261245};\\\", \\\"{x:1208,y:915,t:1527268261253};\\\", \\\"{x:1209,y:917,t:1527268261269};\\\", \\\"{x:1209,y:919,t:1527268261283};\\\", \\\"{x:1210,y:921,t:1527268261300};\\\", \\\"{x:1210,y:923,t:1527268261316};\\\", \\\"{x:1210,y:927,t:1527268261332};\\\", \\\"{x:1211,y:931,t:1527268261350};\\\", \\\"{x:1211,y:933,t:1527268261367};\\\", \\\"{x:1211,y:935,t:1527268261383};\\\", \\\"{x:1211,y:938,t:1527268261400};\\\", \\\"{x:1211,y:939,t:1527268261420};\\\", \\\"{x:1211,y:940,t:1527268261478};\\\", \\\"{x:1211,y:941,t:1527268261581};\\\", \\\"{x:1211,y:942,t:1527268261605};\\\", \\\"{x:1211,y:943,t:1527268261618};\\\", \\\"{x:1211,y:944,t:1527268261634};\\\", \\\"{x:1211,y:945,t:1527268261651};\\\", \\\"{x:1211,y:946,t:1527268261741};\\\", \\\"{x:1212,y:946,t:1527268261821};\\\", \\\"{x:1213,y:945,t:1527268261942};\\\", \\\"{x:1213,y:943,t:1527268261952};\\\", \\\"{x:1213,y:932,t:1527268261969};\\\", \\\"{x:1213,y:921,t:1527268261985};\\\", \\\"{x:1213,y:899,t:1527268262002};\\\", \\\"{x:1213,y:878,t:1527268262019};\\\", \\\"{x:1213,y:858,t:1527268262036};\\\", \\\"{x:1211,y:836,t:1527268262053};\\\", \\\"{x:1208,y:827,t:1527268262069};\\\", \\\"{x:1208,y:820,t:1527268262086};\\\", \\\"{x:1208,y:814,t:1527268262103};\\\", \\\"{x:1208,y:811,t:1527268262119};\\\", \\\"{x:1208,y:810,t:1527268262136};\\\", \\\"{x:1207,y:808,t:1527268262153};\\\", \\\"{x:1207,y:806,t:1527268262196};\\\", \\\"{x:1207,y:805,t:1527268262236};\\\", \\\"{x:1209,y:805,t:1527268262389};\\\", \\\"{x:1211,y:808,t:1527268262404};\\\", \\\"{x:1224,y:820,t:1527268262420};\\\", \\\"{x:1235,y:827,t:1527268262436};\\\", \\\"{x:1242,y:830,t:1527268262454};\\\", \\\"{x:1245,y:831,t:1527268262471};\\\", \\\"{x:1247,y:831,t:1527268262487};\\\", \\\"{x:1248,y:831,t:1527268262541};\\\", \\\"{x:1250,y:831,t:1527268262557};\\\", \\\"{x:1252,y:831,t:1527268262571};\\\", \\\"{x:1259,y:831,t:1527268262588};\\\", \\\"{x:1279,y:835,t:1527268262605};\\\", \\\"{x:1298,y:838,t:1527268262622};\\\", \\\"{x:1314,y:840,t:1527268262638};\\\", \\\"{x:1324,y:841,t:1527268262655};\\\", \\\"{x:1333,y:843,t:1527268262671};\\\", \\\"{x:1336,y:843,t:1527268262689};\\\", \\\"{x:1337,y:843,t:1527268262704};\\\", \\\"{x:1338,y:842,t:1527268262741};\\\", \\\"{x:1339,y:842,t:1527268262773};\\\", \\\"{x:1339,y:841,t:1527268262789};\\\", \\\"{x:1340,y:841,t:1527268262805};\\\", \\\"{x:1340,y:840,t:1527268262877};\\\", \\\"{x:1340,y:837,t:1527268263013};\\\", \\\"{x:1340,y:836,t:1527268263045};\\\", \\\"{x:1340,y:835,t:1527268263077};\\\", \\\"{x:1342,y:835,t:1527268264608};\\\", \\\"{x:1341,y:835,t:1527268264897};\\\", \\\"{x:1339,y:835,t:1527268264904};\\\", \\\"{x:1337,y:835,t:1527268264917};\\\", \\\"{x:1333,y:835,t:1527268264935};\\\", \\\"{x:1330,y:835,t:1527268264951};\\\", \\\"{x:1329,y:835,t:1527268264967};\\\", \\\"{x:1327,y:835,t:1527268265016};\\\", \\\"{x:1326,y:835,t:1527268265056};\\\", \\\"{x:1324,y:835,t:1527268265113};\\\", \\\"{x:1323,y:835,t:1527268265153};\\\", \\\"{x:1321,y:834,t:1527268265169};\\\", \\\"{x:1320,y:834,t:1527268265185};\\\", \\\"{x:1318,y:834,t:1527268265202};\\\", \\\"{x:1315,y:834,t:1527268265218};\\\", \\\"{x:1310,y:834,t:1527268265235};\\\", \\\"{x:1307,y:833,t:1527268265252};\\\", \\\"{x:1304,y:831,t:1527268265268};\\\", \\\"{x:1302,y:829,t:1527268265285};\\\", \\\"{x:1298,y:822,t:1527268265302};\\\", \\\"{x:1295,y:811,t:1527268265320};\\\", \\\"{x:1294,y:798,t:1527268265335};\\\", \\\"{x:1294,y:772,t:1527268265352};\\\", \\\"{x:1293,y:751,t:1527268265371};\\\", \\\"{x:1293,y:733,t:1527268265385};\\\", \\\"{x:1295,y:710,t:1527268265402};\\\", \\\"{x:1303,y:672,t:1527268265419};\\\", \\\"{x:1308,y:645,t:1527268265436};\\\", \\\"{x:1312,y:621,t:1527268265453};\\\", \\\"{x:1315,y:603,t:1527268265469};\\\", \\\"{x:1316,y:591,t:1527268265486};\\\", \\\"{x:1318,y:579,t:1527268265503};\\\", \\\"{x:1318,y:572,t:1527268265519};\\\", \\\"{x:1320,y:561,t:1527268265536};\\\", \\\"{x:1322,y:556,t:1527268265553};\\\", \\\"{x:1322,y:554,t:1527268265570};\\\", \\\"{x:1322,y:553,t:1527268265585};\\\", \\\"{x:1322,y:551,t:1527268265603};\\\", \\\"{x:1322,y:549,t:1527268265620};\\\", \\\"{x:1322,y:548,t:1527268265637};\\\", \\\"{x:1322,y:546,t:1527268265663};\\\", \\\"{x:1322,y:545,t:1527268265695};\\\", \\\"{x:1321,y:545,t:1527268265713};\\\", \\\"{x:1320,y:545,t:1527268265745};\\\", \\\"{x:1319,y:544,t:1527268266201};\\\", \\\"{x:1319,y:543,t:1527268266216};\\\", \\\"{x:1319,y:542,t:1527268266240};\\\", \\\"{x:1319,y:540,t:1527268266281};\\\", \\\"{x:1319,y:539,t:1527268266296};\\\", \\\"{x:1318,y:538,t:1527268266306};\\\", \\\"{x:1318,y:536,t:1527268266323};\\\", \\\"{x:1318,y:533,t:1527268266339};\\\", \\\"{x:1317,y:531,t:1527268266356};\\\", \\\"{x:1317,y:528,t:1527268266373};\\\", \\\"{x:1317,y:525,t:1527268266390};\\\", \\\"{x:1317,y:522,t:1527268266407};\\\", \\\"{x:1316,y:521,t:1527268266424};\\\", \\\"{x:1316,y:516,t:1527268266440};\\\", \\\"{x:1316,y:515,t:1527268266457};\\\", \\\"{x:1315,y:513,t:1527268266473};\\\", \\\"{x:1315,y:511,t:1527268266490};\\\", \\\"{x:1315,y:510,t:1527268266507};\\\", \\\"{x:1312,y:508,t:1527268266524};\\\", \\\"{x:1312,y:507,t:1527268266541};\\\", \\\"{x:1312,y:506,t:1527268266558};\\\", \\\"{x:1311,y:505,t:1527268266574};\\\", \\\"{x:1309,y:502,t:1527268266590};\\\", \\\"{x:1309,y:501,t:1527268266616};\\\", \\\"{x:1309,y:500,t:1527268266632};\\\", \\\"{x:1309,y:499,t:1527268266648};\\\", \\\"{x:1309,y:498,t:1527268266680};\\\", \\\"{x:1309,y:497,t:1527268266696};\\\", \\\"{x:1308,y:496,t:1527268266713};\\\", \\\"{x:1308,y:497,t:1527268266929};\\\", \\\"{x:1308,y:498,t:1527268266942};\\\", \\\"{x:1308,y:502,t:1527268266960};\\\", \\\"{x:1308,y:507,t:1527268266975};\\\", \\\"{x:1308,y:517,t:1527268266992};\\\", \\\"{x:1308,y:522,t:1527268267010};\\\", \\\"{x:1308,y:526,t:1527268267025};\\\", \\\"{x:1308,y:532,t:1527268267043};\\\", \\\"{x:1308,y:537,t:1527268267059};\\\", \\\"{x:1308,y:543,t:1527268267077};\\\", \\\"{x:1308,y:547,t:1527268267092};\\\", \\\"{x:1308,y:550,t:1527268267109};\\\", \\\"{x:1308,y:553,t:1527268267127};\\\", \\\"{x:1308,y:557,t:1527268267143};\\\", \\\"{x:1308,y:562,t:1527268267160};\\\", \\\"{x:1308,y:566,t:1527268267177};\\\", \\\"{x:1308,y:569,t:1527268267194};\\\", \\\"{x:1308,y:575,t:1527268267210};\\\", \\\"{x:1308,y:581,t:1527268267226};\\\", \\\"{x:1308,y:589,t:1527268267243};\\\", \\\"{x:1308,y:602,t:1527268267259};\\\", \\\"{x:1308,y:616,t:1527268267275};\\\", \\\"{x:1308,y:627,t:1527268267293};\\\", \\\"{x:1308,y:641,t:1527268267309};\\\", \\\"{x:1308,y:656,t:1527268267327};\\\", \\\"{x:1308,y:674,t:1527268267343};\\\", \\\"{x:1310,y:697,t:1527268267360};\\\", \\\"{x:1310,y:712,t:1527268267377};\\\", \\\"{x:1310,y:723,t:1527268267394};\\\", \\\"{x:1310,y:732,t:1527268267410};\\\", \\\"{x:1310,y:742,t:1527268267427};\\\", \\\"{x:1310,y:755,t:1527268267444};\\\", \\\"{x:1310,y:771,t:1527268267460};\\\", \\\"{x:1308,y:789,t:1527268267478};\\\", \\\"{x:1307,y:803,t:1527268267494};\\\", \\\"{x:1305,y:817,t:1527268267511};\\\", \\\"{x:1304,y:826,t:1527268267527};\\\", \\\"{x:1303,y:837,t:1527268267544};\\\", \\\"{x:1301,y:845,t:1527268267561};\\\", \\\"{x:1300,y:853,t:1527268267578};\\\", \\\"{x:1300,y:867,t:1527268267595};\\\", \\\"{x:1300,y:887,t:1527268267612};\\\", \\\"{x:1300,y:912,t:1527268267629};\\\", \\\"{x:1298,y:930,t:1527268267646};\\\", \\\"{x:1295,y:951,t:1527268267662};\\\", \\\"{x:1293,y:966,t:1527268267678};\\\", \\\"{x:1289,y:980,t:1527268267695};\\\", \\\"{x:1289,y:992,t:1527268267713};\\\", \\\"{x:1288,y:996,t:1527268267728};\\\", \\\"{x:1286,y:999,t:1527268267745};\\\", \\\"{x:1286,y:1000,t:1527268267976};\\\", \\\"{x:1288,y:999,t:1527268268041};\\\", \\\"{x:1290,y:997,t:1527268268048};\\\", \\\"{x:1291,y:997,t:1527268268064};\\\", \\\"{x:1293,y:994,t:1527268268079};\\\", \\\"{x:1298,y:990,t:1527268268096};\\\", \\\"{x:1300,y:988,t:1527268268113};\\\", \\\"{x:1302,y:985,t:1527268268130};\\\", \\\"{x:1305,y:980,t:1527268268147};\\\", \\\"{x:1309,y:974,t:1527268268163};\\\", \\\"{x:1313,y:969,t:1527268268180};\\\", \\\"{x:1316,y:966,t:1527268268197};\\\", \\\"{x:1319,y:964,t:1527268268213};\\\", \\\"{x:1321,y:963,t:1527268268230};\\\", \\\"{x:1322,y:963,t:1527268268248};\\\", \\\"{x:1323,y:962,t:1527268268265};\\\", \\\"{x:1324,y:962,t:1527268268584};\\\", \\\"{x:1325,y:962,t:1527268268600};\\\", \\\"{x:1325,y:963,t:1527268268897};\\\", \\\"{x:1325,y:964,t:1527268269025};\\\", \\\"{x:1325,y:965,t:1527268269040};\\\", \\\"{x:1325,y:966,t:1527268269056};\\\", \\\"{x:1325,y:967,t:1527268269080};\\\", \\\"{x:1325,y:969,t:1527268269104};\\\", \\\"{x:1325,y:970,t:1527268269144};\\\", \\\"{x:1325,y:971,t:1527268269176};\\\", \\\"{x:1325,y:972,t:1527268269200};\\\", \\\"{x:1325,y:973,t:1527268269264};\\\", \\\"{x:1325,y:974,t:1527268269272};\\\", \\\"{x:1324,y:975,t:1527268269321};\\\", \\\"{x:1323,y:975,t:1527268269360};\\\", \\\"{x:1322,y:975,t:1527268269376};\\\", \\\"{x:1320,y:975,t:1527268269386};\\\", \\\"{x:1317,y:975,t:1527268269403};\\\", \\\"{x:1313,y:975,t:1527268269418};\\\", \\\"{x:1311,y:974,t:1527268269436};\\\", \\\"{x:1310,y:974,t:1527268269452};\\\", \\\"{x:1309,y:974,t:1527268269617};\\\", \\\"{x:1308,y:973,t:1527268269697};\\\", \\\"{x:1306,y:971,t:1527268269745};\\\", \\\"{x:1306,y:970,t:1527268269784};\\\", \\\"{x:1306,y:969,t:1527268269816};\\\", \\\"{x:1306,y:968,t:1527268269873};\\\", \\\"{x:1306,y:967,t:1527268269888};\\\", \\\"{x:1306,y:966,t:1527268269921};\\\", \\\"{x:1306,y:965,t:1527268269952};\\\", \\\"{x:1306,y:964,t:1527268269969};\\\", \\\"{x:1306,y:963,t:1527268270000};\\\", \\\"{x:1307,y:962,t:1527268270025};\\\", \\\"{x:1307,y:960,t:1527268270129};\\\", \\\"{x:1308,y:958,t:1527268270169};\\\", \\\"{x:1311,y:957,t:1527268270185};\\\", \\\"{x:1313,y:957,t:1527268270200};\\\", \\\"{x:1317,y:956,t:1527268270208};\\\", \\\"{x:1322,y:956,t:1527268270223};\\\", \\\"{x:1337,y:956,t:1527268270238};\\\", \\\"{x:1355,y:956,t:1527268270256};\\\", \\\"{x:1378,y:956,t:1527268270272};\\\", \\\"{x:1402,y:956,t:1527268270288};\\\", \\\"{x:1424,y:956,t:1527268270306};\\\", \\\"{x:1439,y:956,t:1527268270323};\\\", \\\"{x:1454,y:956,t:1527268270339};\\\", \\\"{x:1465,y:956,t:1527268270356};\\\", \\\"{x:1474,y:956,t:1527268270372};\\\", \\\"{x:1482,y:956,t:1527268270390};\\\", \\\"{x:1491,y:956,t:1527268270406};\\\", \\\"{x:1502,y:956,t:1527268270423};\\\", \\\"{x:1516,y:956,t:1527268270440};\\\", \\\"{x:1546,y:956,t:1527268270456};\\\", \\\"{x:1566,y:956,t:1527268270474};\\\", \\\"{x:1584,y:956,t:1527268270489};\\\", \\\"{x:1596,y:956,t:1527268270506};\\\", \\\"{x:1605,y:956,t:1527268270523};\\\", \\\"{x:1610,y:956,t:1527268270540};\\\", \\\"{x:1612,y:956,t:1527268270556};\\\", \\\"{x:1613,y:956,t:1527268270607};\\\", \\\"{x:1613,y:955,t:1527268270623};\\\", \\\"{x:1614,y:954,t:1527268270647};\\\", \\\"{x:1615,y:954,t:1527268270657};\\\", \\\"{x:1616,y:953,t:1527268270673};\\\", \\\"{x:1619,y:952,t:1527268270690};\\\", \\\"{x:1621,y:952,t:1527268270707};\\\", \\\"{x:1627,y:952,t:1527268270723};\\\", \\\"{x:1635,y:952,t:1527268270740};\\\", \\\"{x:1644,y:952,t:1527268270757};\\\", \\\"{x:1655,y:952,t:1527268270774};\\\", \\\"{x:1666,y:954,t:1527268270790};\\\", \\\"{x:1672,y:954,t:1527268270808};\\\", \\\"{x:1677,y:954,t:1527268270824};\\\", \\\"{x:1678,y:954,t:1527268270881};\\\", \\\"{x:1679,y:954,t:1527268270944};\\\", \\\"{x:1681,y:954,t:1527268270976};\\\", \\\"{x:1682,y:953,t:1527268270992};\\\", \\\"{x:1689,y:953,t:1527268271008};\\\", \\\"{x:1696,y:953,t:1527268271026};\\\", \\\"{x:1707,y:953,t:1527268271041};\\\", \\\"{x:1715,y:954,t:1527268271059};\\\", \\\"{x:1723,y:956,t:1527268271076};\\\", \\\"{x:1728,y:957,t:1527268271093};\\\", \\\"{x:1730,y:957,t:1527268271108};\\\", \\\"{x:1731,y:958,t:1527268271128};\\\", \\\"{x:1732,y:958,t:1527268271169};\\\", \\\"{x:1733,y:958,t:1527268271176};\\\", \\\"{x:1734,y:957,t:1527268271192};\\\", \\\"{x:1737,y:956,t:1527268271209};\\\", \\\"{x:1737,y:955,t:1527268271226};\\\", \\\"{x:1738,y:955,t:1527268271243};\\\", \\\"{x:1739,y:955,t:1527268271264};\\\", \\\"{x:1740,y:955,t:1527268271276};\\\", \\\"{x:1742,y:955,t:1527268271292};\\\", \\\"{x:1743,y:955,t:1527268271310};\\\", \\\"{x:1745,y:955,t:1527268271326};\\\", \\\"{x:1747,y:955,t:1527268271433};\\\", \\\"{x:1747,y:954,t:1527268271624};\\\", \\\"{x:1747,y:953,t:1527268271721};\\\", \\\"{x:1748,y:953,t:1527268271728};\\\", \\\"{x:1748,y:952,t:1527268271873};\\\", \\\"{x:1748,y:951,t:1527268271896};\\\", \\\"{x:1748,y:950,t:1527268271936};\\\", \\\"{x:1749,y:950,t:1527268272624};\\\", \\\"{x:1750,y:950,t:1527268272633};\\\", \\\"{x:1751,y:955,t:1527268272648};\\\", \\\"{x:1753,y:961,t:1527268272666};\\\", \\\"{x:1753,y:967,t:1527268272681};\\\", \\\"{x:1753,y:972,t:1527268272699};\\\", \\\"{x:1753,y:979,t:1527268272716};\\\", \\\"{x:1753,y:984,t:1527268272732};\\\", \\\"{x:1753,y:988,t:1527268272750};\\\", \\\"{x:1753,y:990,t:1527268272766};\\\", \\\"{x:1753,y:991,t:1527268272783};\\\", \\\"{x:1752,y:990,t:1527268273000};\\\", \\\"{x:1751,y:989,t:1527268273024};\\\", \\\"{x:1751,y:987,t:1527268273040};\\\", \\\"{x:1751,y:983,t:1527268273050};\\\", \\\"{x:1751,y:977,t:1527268273067};\\\", \\\"{x:1751,y:973,t:1527268273084};\\\", \\\"{x:1751,y:969,t:1527268273101};\\\", \\\"{x:1752,y:965,t:1527268273118};\\\", \\\"{x:1755,y:961,t:1527268273134};\\\", \\\"{x:1756,y:960,t:1527268273151};\\\", \\\"{x:1760,y:957,t:1527268273169};\\\", \\\"{x:1761,y:957,t:1527268273183};\\\", \\\"{x:1762,y:957,t:1527268273216};\\\", \\\"{x:1763,y:957,t:1527268273225};\\\", \\\"{x:1764,y:957,t:1527268273235};\\\", \\\"{x:1765,y:957,t:1527268273280};\\\", \\\"{x:1767,y:957,t:1527268273305};\\\", \\\"{x:1767,y:956,t:1527268273320};\\\", \\\"{x:1768,y:955,t:1527268273336};\\\", \\\"{x:1769,y:954,t:1527268273351};\\\", \\\"{x:1770,y:954,t:1527268273369};\\\", \\\"{x:1772,y:953,t:1527268273400};\\\", \\\"{x:1774,y:953,t:1527268273441};\\\", \\\"{x:1775,y:953,t:1527268273452};\\\", \\\"{x:1777,y:954,t:1527268273469};\\\", \\\"{x:1780,y:958,t:1527268273484};\\\", \\\"{x:1781,y:959,t:1527268273501};\\\", \\\"{x:1782,y:959,t:1527268273633};\\\", \\\"{x:1782,y:958,t:1527268274057};\\\", \\\"{x:1782,y:956,t:1527268274081};\\\", \\\"{x:1782,y:955,t:1527268274096};\\\", \\\"{x:1782,y:953,t:1527268274120};\\\", \\\"{x:1782,y:951,t:1527268274138};\\\", \\\"{x:1782,y:950,t:1527268274154};\\\", \\\"{x:1782,y:949,t:1527268274336};\\\", \\\"{x:1782,y:948,t:1527268274344};\\\", \\\"{x:1782,y:947,t:1527268274356};\\\", \\\"{x:1782,y:946,t:1527268274377};\\\", \\\"{x:1782,y:945,t:1527268274545};\\\", \\\"{x:1782,y:944,t:1527268274555};\\\", \\\"{x:1782,y:943,t:1527268274572};\\\", \\\"{x:1782,y:941,t:1527268274590};\\\", \\\"{x:1782,y:940,t:1527268274608};\\\", \\\"{x:1782,y:941,t:1527268274992};\\\", \\\"{x:1782,y:943,t:1527268275153};\\\", \\\"{x:1782,y:945,t:1527268275169};\\\", \\\"{x:1782,y:948,t:1527268275176};\\\", \\\"{x:1782,y:951,t:1527268275192};\\\", \\\"{x:1782,y:955,t:1527268275208};\\\", \\\"{x:1782,y:956,t:1527268275226};\\\", \\\"{x:1782,y:958,t:1527268275288};\\\", \\\"{x:1783,y:958,t:1527268275345};\\\", \\\"{x:1784,y:959,t:1527268275391};\\\", \\\"{x:1784,y:960,t:1527268275407};\\\", \\\"{x:1784,y:962,t:1527268275431};\\\", \\\"{x:1784,y:963,t:1527268275442};\\\", \\\"{x:1784,y:966,t:1527268275459};\\\", \\\"{x:1784,y:967,t:1527268275476};\\\", \\\"{x:1784,y:968,t:1527268275492};\\\", \\\"{x:1784,y:970,t:1527268275689};\\\", \\\"{x:1784,y:969,t:1527268277033};\\\", \\\"{x:1784,y:967,t:1527268277050};\\\", \\\"{x:1783,y:964,t:1527268277066};\\\", \\\"{x:1783,y:963,t:1527268277083};\\\", \\\"{x:1783,y:961,t:1527268277100};\\\", \\\"{x:1783,y:958,t:1527268277117};\\\", \\\"{x:1783,y:957,t:1527268277133};\\\", \\\"{x:1782,y:956,t:1527268277153};\\\", \\\"{x:1782,y:955,t:1527268277240};\\\", \\\"{x:1781,y:954,t:1527268277249};\\\", \\\"{x:1780,y:952,t:1527268277266};\\\", \\\"{x:1780,y:950,t:1527268277284};\\\", \\\"{x:1779,y:946,t:1527268277301};\\\", \\\"{x:1779,y:944,t:1527268277316};\\\", \\\"{x:1779,y:942,t:1527268277334};\\\", \\\"{x:1779,y:941,t:1527268277351};\\\", \\\"{x:1779,y:939,t:1527268277367};\\\", \\\"{x:1779,y:938,t:1527268277383};\\\", \\\"{x:1778,y:938,t:1527268277432};\\\", \\\"{x:1778,y:936,t:1527268277456};\\\", \\\"{x:1778,y:934,t:1527268277468};\\\", \\\"{x:1776,y:931,t:1527268277485};\\\", \\\"{x:1776,y:927,t:1527268277501};\\\", \\\"{x:1776,y:923,t:1527268277518};\\\", \\\"{x:1775,y:918,t:1527268277534};\\\", \\\"{x:1774,y:910,t:1527268277552};\\\", \\\"{x:1773,y:906,t:1527268277570};\\\", \\\"{x:1773,y:901,t:1527268277584};\\\", \\\"{x:1773,y:899,t:1527268277602};\\\", \\\"{x:1773,y:895,t:1527268277618};\\\", \\\"{x:1772,y:893,t:1527268277634};\\\", \\\"{x:1772,y:891,t:1527268277651};\\\", \\\"{x:1772,y:884,t:1527268277668};\\\", \\\"{x:1772,y:882,t:1527268277685};\\\", \\\"{x:1772,y:881,t:1527268277701};\\\", \\\"{x:1772,y:877,t:1527268277719};\\\", \\\"{x:1772,y:870,t:1527268277735};\\\", \\\"{x:1772,y:865,t:1527268277752};\\\", \\\"{x:1772,y:860,t:1527268277768};\\\", \\\"{x:1772,y:856,t:1527268277786};\\\", \\\"{x:1772,y:851,t:1527268277803};\\\", \\\"{x:1772,y:848,t:1527268277819};\\\", \\\"{x:1772,y:845,t:1527268277836};\\\", \\\"{x:1772,y:842,t:1527268277853};\\\", \\\"{x:1772,y:837,t:1527268277870};\\\", \\\"{x:1772,y:835,t:1527268277885};\\\", \\\"{x:1772,y:831,t:1527268277903};\\\", \\\"{x:1772,y:830,t:1527268277920};\\\", \\\"{x:1772,y:829,t:1527268277937};\\\", \\\"{x:1772,y:830,t:1527268278273};\\\", \\\"{x:1772,y:831,t:1527268278457};\\\", \\\"{x:1772,y:833,t:1527268278472};\\\", \\\"{x:1772,y:834,t:1527268278985};\\\", \\\"{x:1771,y:836,t:1527268278992};\\\", \\\"{x:1771,y:837,t:1527268279224};\\\", \\\"{x:1771,y:839,t:1527268279464};\\\", \\\"{x:1771,y:838,t:1527268280377};\\\", \\\"{x:1771,y:837,t:1527268281105};\\\", \\\"{x:1773,y:837,t:1527268288809};\\\", \\\"{x:1775,y:837,t:1527268288816};\\\", \\\"{x:1777,y:838,t:1527268288831};\\\", \\\"{x:1779,y:838,t:1527268288847};\\\", \\\"{x:1778,y:838,t:1527268312984};\\\", \\\"{x:1775,y:838,t:1527268312994};\\\", \\\"{x:1768,y:838,t:1527268313011};\\\", \\\"{x:1792,y:827,t:1527268313136};\\\", \\\"{x:1873,y:793,t:1527268313144};\\\", \\\"{x:1919,y:642,t:1527268313161};\\\", \\\"{x:1919,y:506,t:1527268313178};\\\", \\\"{x:1919,y:472,t:1527268313198};\\\", \\\"{x:1918,y:471,t:1527268313246};\\\", \\\"{x:1911,y:469,t:1527268313255};\\\", \\\"{x:1860,y:457,t:1527268313265};\\\", \\\"{x:1704,y:444,t:1527268313282};\\\", \\\"{x:1563,y:445,t:1527268313298};\\\", \\\"{x:1420,y:473,t:1527268313315};\\\", \\\"{x:1308,y:514,t:1527268313331};\\\", \\\"{x:1239,y:559,t:1527268313348};\\\", \\\"{x:1219,y:582,t:1527268313365};\\\", \\\"{x:1217,y:585,t:1527268313380};\\\", \\\"{x:1217,y:586,t:1527268313399};\\\", \\\"{x:1221,y:584,t:1527268313415};\\\", \\\"{x:1233,y:575,t:1527268313431};\\\", \\\"{x:1240,y:566,t:1527268313448};\\\", \\\"{x:1242,y:565,t:1527268313465};\\\", \\\"{x:1231,y:565,t:1527268313512};\\\", \\\"{x:1206,y:574,t:1527268313520};\\\", \\\"{x:1180,y:585,t:1527268313532};\\\", \\\"{x:1129,y:610,t:1527268313549};\\\", \\\"{x:1093,y:619,t:1527268313566};\\\", \\\"{x:1069,y:619,t:1527268313581};\\\", \\\"{x:1004,y:610,t:1527268313598};\\\", \\\"{x:848,y:559,t:1527268313617};\\\", \\\"{x:746,y:529,t:1527268313632};\\\", \\\"{x:666,y:510,t:1527268313648};\\\", \\\"{x:598,y:495,t:1527268313665};\\\", \\\"{x:535,y:481,t:1527268313681};\\\", \\\"{x:477,y:466,t:1527268313698};\\\", \\\"{x:436,y:457,t:1527268313715};\\\", \\\"{x:406,y:455,t:1527268313732};\\\", \\\"{x:389,y:455,t:1527268313748};\\\", \\\"{x:383,y:455,t:1527268313765};\\\", \\\"{x:382,y:455,t:1527268313782};\\\", \\\"{x:380,y:455,t:1527268313798};\\\", \\\"{x:380,y:456,t:1527268313847};\\\", \\\"{x:384,y:462,t:1527268313855};\\\", \\\"{x:391,y:468,t:1527268313865};\\\", \\\"{x:402,y:481,t:1527268313883};\\\", \\\"{x:424,y:501,t:1527268313899};\\\", \\\"{x:448,y:519,t:1527268313916};\\\", \\\"{x:467,y:531,t:1527268313933};\\\", \\\"{x:475,y:536,t:1527268313948};\\\", \\\"{x:477,y:536,t:1527268313965};\\\", \\\"{x:478,y:537,t:1527268313983};\\\", \\\"{x:478,y:539,t:1527268314031};\\\", \\\"{x:479,y:539,t:1527268314039};\\\", \\\"{x:479,y:540,t:1527268314049};\\\", \\\"{x:482,y:542,t:1527268314066};\\\", \\\"{x:496,y:544,t:1527268314082};\\\", \\\"{x:516,y:546,t:1527268314100};\\\", \\\"{x:539,y:546,t:1527268314116};\\\", \\\"{x:552,y:546,t:1527268314132};\\\", \\\"{x:553,y:546,t:1527268314149};\\\", \\\"{x:554,y:546,t:1527268314165};\\\", \\\"{x:556,y:546,t:1527268314182};\\\", \\\"{x:560,y:543,t:1527268314199};\\\", \\\"{x:568,y:539,t:1527268314215};\\\", \\\"{x:572,y:538,t:1527268314232};\\\", \\\"{x:576,y:535,t:1527268314249};\\\", \\\"{x:578,y:535,t:1527268314265};\\\", \\\"{x:579,y:534,t:1527268314282};\\\", \\\"{x:581,y:534,t:1527268314300};\\\", \\\"{x:586,y:533,t:1527268314315};\\\", \\\"{x:587,y:532,t:1527268314332};\\\", \\\"{x:588,y:532,t:1527268314349};\\\", \\\"{x:589,y:532,t:1527268314369};\\\", \\\"{x:591,y:532,t:1527268314391};\\\", \\\"{x:592,y:532,t:1527268314399};\\\", \\\"{x:594,y:532,t:1527268314416};\\\", \\\"{x:597,y:532,t:1527268314433};\\\", \\\"{x:598,y:532,t:1527268314449};\\\", \\\"{x:601,y:532,t:1527268314465};\\\", \\\"{x:602,y:532,t:1527268314482};\\\", \\\"{x:604,y:533,t:1527268314500};\\\", \\\"{x:605,y:533,t:1527268314516};\\\", \\\"{x:607,y:534,t:1527268314532};\\\", \\\"{x:608,y:535,t:1527268314548};\\\", \\\"{x:610,y:535,t:1527268314566};\\\", \\\"{x:611,y:535,t:1527268314582};\\\", \\\"{x:612,y:535,t:1527268314606};\\\", \\\"{x:613,y:536,t:1527268314616};\\\", \\\"{x:614,y:536,t:1527268314719};\\\", \\\"{x:614,y:536,t:1527268314736};\\\", \\\"{x:614,y:537,t:1527268314822};\\\", \\\"{x:615,y:538,t:1527268314831};\\\", \\\"{x:620,y:542,t:1527268314849};\\\", \\\"{x:627,y:559,t:1527268314867};\\\", \\\"{x:632,y:584,t:1527268314883};\\\", \\\"{x:639,y:605,t:1527268314899};\\\", \\\"{x:643,y:617,t:1527268314916};\\\", \\\"{x:644,y:629,t:1527268314934};\\\", \\\"{x:645,y:639,t:1527268314949};\\\", \\\"{x:645,y:654,t:1527268314966};\\\", \\\"{x:636,y:683,t:1527268314983};\\\", \\\"{x:630,y:700,t:1527268314998};\\\", \\\"{x:623,y:713,t:1527268315016};\\\", \\\"{x:616,y:723,t:1527268315033};\\\", \\\"{x:610,y:731,t:1527268315049};\\\", \\\"{x:601,y:740,t:1527268315066};\\\", \\\"{x:590,y:749,t:1527268315083};\\\", \\\"{x:581,y:755,t:1527268315099};\\\", \\\"{x:577,y:757,t:1527268315116};\\\", \\\"{x:576,y:757,t:1527268315133};\\\", \\\"{x:575,y:757,t:1527268315151};\\\", \\\"{x:572,y:757,t:1527268315169};\\\", \\\"{x:565,y:756,t:1527268315184};\\\", \\\"{x:553,y:752,t:1527268315200};\\\", \\\"{x:542,y:746,t:1527268315217};\\\", \\\"{x:533,y:741,t:1527268315232};\\\", \\\"{x:523,y:736,t:1527268315248};\\\", \\\"{x:516,y:732,t:1527268315265};\\\", \\\"{x:510,y:728,t:1527268315283};\\\", \\\"{x:505,y:726,t:1527268315300};\\\", \\\"{x:503,y:726,t:1527268315316};\\\", \\\"{x:503,y:725,t:1527268315333};\\\", \\\"{x:501,y:725,t:1527268315350};\\\", \\\"{x:501,y:724,t:1527268315366};\\\", \\\"{x:500,y:724,t:1527268315759};\\\", \\\"{x:498,y:724,t:1527268315840};\\\", \\\"{x:497,y:724,t:1527268315850};\\\", \\\"{x:496,y:723,t:1527268315867};\\\", \\\"{x:495,y:723,t:1527268315883};\\\" ] }, { \\\"rt\\\": 10886, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 363731, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:722,t:1527268317455};\\\", \\\"{x:495,y:720,t:1527268317880};\\\", \\\"{x:498,y:716,t:1527268317888};\\\", \\\"{x:501,y:708,t:1527268317900};\\\", \\\"{x:505,y:699,t:1527268317918};\\\", \\\"{x:513,y:685,t:1527268317935};\\\", \\\"{x:517,y:678,t:1527268317951};\\\", \\\"{x:522,y:672,t:1527268317968};\\\", \\\"{x:525,y:667,t:1527268317985};\\\", \\\"{x:527,y:664,t:1527268318002};\\\", \\\"{x:532,y:656,t:1527268318018};\\\", \\\"{x:539,y:647,t:1527268318035};\\\", \\\"{x:546,y:635,t:1527268318052};\\\", \\\"{x:551,y:624,t:1527268318069};\\\", \\\"{x:558,y:613,t:1527268318085};\\\", \\\"{x:564,y:604,t:1527268318102};\\\", \\\"{x:568,y:592,t:1527268318119};\\\", \\\"{x:575,y:575,t:1527268318135};\\\", \\\"{x:578,y:566,t:1527268318152};\\\", \\\"{x:579,y:561,t:1527268318169};\\\", \\\"{x:579,y:559,t:1527268318185};\\\", \\\"{x:579,y:557,t:1527268318202};\\\", \\\"{x:579,y:556,t:1527268318223};\\\", \\\"{x:579,y:555,t:1527268318248};\\\", \\\"{x:579,y:554,t:1527268318254};\\\", \\\"{x:579,y:553,t:1527268318271};\\\", \\\"{x:579,y:551,t:1527268318285};\\\", \\\"{x:579,y:550,t:1527268318302};\\\", \\\"{x:578,y:543,t:1527268318318};\\\", \\\"{x:578,y:535,t:1527268318335};\\\", \\\"{x:577,y:526,t:1527268318353};\\\", \\\"{x:577,y:516,t:1527268318370};\\\", \\\"{x:577,y:508,t:1527268318385};\\\", \\\"{x:577,y:500,t:1527268318402};\\\", \\\"{x:577,y:498,t:1527268318419};\\\", \\\"{x:577,y:497,t:1527268318435};\\\", \\\"{x:577,y:496,t:1527268318453};\\\", \\\"{x:577,y:495,t:1527268318469};\\\", \\\"{x:577,y:493,t:1527268318487};\\\", \\\"{x:577,y:492,t:1527268318502};\\\", \\\"{x:577,y:489,t:1527268318519};\\\", \\\"{x:577,y:488,t:1527268318536};\\\", \\\"{x:577,y:485,t:1527268318553};\\\", \\\"{x:577,y:482,t:1527268318569};\\\", \\\"{x:577,y:479,t:1527268318584};\\\", \\\"{x:577,y:475,t:1527268318602};\\\", \\\"{x:577,y:471,t:1527268318619};\\\", \\\"{x:577,y:470,t:1527268318635};\\\", \\\"{x:578,y:469,t:1527268318652};\\\", \\\"{x:577,y:469,t:1527268318887};\\\", \\\"{x:575,y:468,t:1527268318902};\\\", \\\"{x:570,y:467,t:1527268318919};\\\", \\\"{x:562,y:467,t:1527268318936};\\\", \\\"{x:542,y:466,t:1527268318952};\\\", \\\"{x:515,y:466,t:1527268318970};\\\", \\\"{x:480,y:471,t:1527268318987};\\\", \\\"{x:451,y:473,t:1527268319002};\\\", \\\"{x:447,y:473,t:1527268319019};\\\", \\\"{x:446,y:473,t:1527268319048};\\\", \\\"{x:446,y:472,t:1527268319063};\\\", \\\"{x:445,y:471,t:1527268319087};\\\", \\\"{x:444,y:471,t:1527268319240};\\\", \\\"{x:444,y:469,t:1527268319264};\\\", \\\"{x:444,y:467,t:1527268319271};\\\", \\\"{x:444,y:465,t:1527268319286};\\\", \\\"{x:446,y:463,t:1527268319303};\\\", \\\"{x:450,y:460,t:1527268319320};\\\", \\\"{x:455,y:458,t:1527268319336};\\\", \\\"{x:458,y:457,t:1527268319354};\\\", \\\"{x:464,y:457,t:1527268319369};\\\", \\\"{x:473,y:457,t:1527268319386};\\\", \\\"{x:484,y:457,t:1527268319403};\\\", \\\"{x:496,y:457,t:1527268319420};\\\", \\\"{x:508,y:457,t:1527268319436};\\\", \\\"{x:522,y:454,t:1527268319454};\\\", \\\"{x:531,y:453,t:1527268319469};\\\", \\\"{x:540,y:450,t:1527268319487};\\\", \\\"{x:548,y:448,t:1527268319504};\\\", \\\"{x:555,y:445,t:1527268319520};\\\", \\\"{x:561,y:444,t:1527268319536};\\\", \\\"{x:568,y:444,t:1527268319553};\\\", \\\"{x:575,y:444,t:1527268319570};\\\", \\\"{x:580,y:444,t:1527268319586};\\\", \\\"{x:585,y:446,t:1527268319603};\\\", \\\"{x:594,y:448,t:1527268319620};\\\", \\\"{x:599,y:448,t:1527268319637};\\\", \\\"{x:603,y:449,t:1527268319654};\\\", \\\"{x:604,y:449,t:1527268319669};\\\", \\\"{x:606,y:449,t:1527268319686};\\\", \\\"{x:607,y:449,t:1527268319703};\\\", \\\"{x:608,y:449,t:1527268319824};\\\", \\\"{x:608,y:451,t:1527268319839};\\\", \\\"{x:608,y:452,t:1527268319854};\\\", \\\"{x:607,y:455,t:1527268319870};\\\", \\\"{x:606,y:456,t:1527268319886};\\\", \\\"{x:605,y:458,t:1527268319904};\\\", \\\"{x:604,y:459,t:1527268319960};\\\", \\\"{x:603,y:460,t:1527268320007};\\\", \\\"{x:603,y:461,t:1527268320020};\\\", \\\"{x:599,y:463,t:1527268320037};\\\", \\\"{x:590,y:468,t:1527268320054};\\\", \\\"{x:580,y:474,t:1527268320071};\\\", \\\"{x:573,y:477,t:1527268320087};\\\", \\\"{x:563,y:481,t:1527268320104};\\\", \\\"{x:562,y:481,t:1527268320121};\\\", \\\"{x:561,y:481,t:1527268320137};\\\", \\\"{x:566,y:481,t:1527268320344};\\\", \\\"{x:582,y:479,t:1527268320353};\\\", \\\"{x:621,y:475,t:1527268320371};\\\", \\\"{x:679,y:467,t:1527268320388};\\\", \\\"{x:738,y:459,t:1527268320403};\\\", \\\"{x:798,y:447,t:1527268320421};\\\", \\\"{x:853,y:442,t:1527268320438};\\\", \\\"{x:889,y:442,t:1527268320454};\\\", \\\"{x:920,y:442,t:1527268320471};\\\", \\\"{x:963,y:442,t:1527268320488};\\\", \\\"{x:999,y:442,t:1527268320504};\\\", \\\"{x:1050,y:442,t:1527268320521};\\\", \\\"{x:1116,y:448,t:1527268320537};\\\", \\\"{x:1205,y:450,t:1527268320554};\\\", \\\"{x:1288,y:450,t:1527268320570};\\\", \\\"{x:1350,y:450,t:1527268320588};\\\", \\\"{x:1397,y:450,t:1527268320604};\\\", \\\"{x:1431,y:450,t:1527268320620};\\\", \\\"{x:1447,y:450,t:1527268320637};\\\", \\\"{x:1456,y:450,t:1527268320655};\\\", \\\"{x:1459,y:450,t:1527268320671};\\\", \\\"{x:1461,y:452,t:1527268320687};\\\", \\\"{x:1465,y:456,t:1527268320705};\\\", \\\"{x:1472,y:465,t:1527268320721};\\\", \\\"{x:1481,y:479,t:1527268320738};\\\", \\\"{x:1490,y:494,t:1527268320754};\\\", \\\"{x:1500,y:506,t:1527268320770};\\\", \\\"{x:1505,y:514,t:1527268320788};\\\", \\\"{x:1507,y:516,t:1527268320805};\\\", \\\"{x:1507,y:519,t:1527268320821};\\\", \\\"{x:1507,y:520,t:1527268320847};\\\", \\\"{x:1507,y:521,t:1527268320871};\\\", \\\"{x:1506,y:526,t:1527268320888};\\\", \\\"{x:1497,y:544,t:1527268320905};\\\", \\\"{x:1486,y:565,t:1527268320921};\\\", \\\"{x:1475,y:583,t:1527268320938};\\\", \\\"{x:1463,y:599,t:1527268320955};\\\", \\\"{x:1454,y:610,t:1527268320972};\\\", \\\"{x:1438,y:621,t:1527268320988};\\\", \\\"{x:1417,y:632,t:1527268321004};\\\", \\\"{x:1393,y:642,t:1527268321020};\\\", \\\"{x:1373,y:651,t:1527268321037};\\\", \\\"{x:1364,y:658,t:1527268321054};\\\", \\\"{x:1352,y:661,t:1527268321070};\\\", \\\"{x:1351,y:661,t:1527268321087};\\\", \\\"{x:1350,y:661,t:1527268321104};\\\", \\\"{x:1349,y:662,t:1527268321167};\\\", \\\"{x:1349,y:664,t:1527268321182};\\\", \\\"{x:1349,y:665,t:1527268321191};\\\", \\\"{x:1349,y:668,t:1527268321205};\\\", \\\"{x:1351,y:677,t:1527268321222};\\\", \\\"{x:1355,y:683,t:1527268321238};\\\", \\\"{x:1362,y:691,t:1527268321254};\\\", \\\"{x:1368,y:698,t:1527268321271};\\\", \\\"{x:1370,y:700,t:1527268321287};\\\", \\\"{x:1371,y:702,t:1527268321305};\\\", \\\"{x:1372,y:703,t:1527268321322};\\\", \\\"{x:1373,y:703,t:1527268321338};\\\", \\\"{x:1373,y:705,t:1527268321368};\\\", \\\"{x:1373,y:711,t:1527268321376};\\\", \\\"{x:1373,y:720,t:1527268321388};\\\", \\\"{x:1373,y:747,t:1527268321404};\\\", \\\"{x:1371,y:775,t:1527268321422};\\\", \\\"{x:1362,y:794,t:1527268321437};\\\", \\\"{x:1356,y:809,t:1527268321454};\\\", \\\"{x:1351,y:819,t:1527268321471};\\\", \\\"{x:1350,y:819,t:1527268321494};\\\", \\\"{x:1349,y:819,t:1527268321567};\\\", \\\"{x:1348,y:819,t:1527268321591};\\\", \\\"{x:1346,y:819,t:1527268321604};\\\", \\\"{x:1342,y:813,t:1527268321621};\\\", \\\"{x:1340,y:810,t:1527268321638};\\\", \\\"{x:1336,y:806,t:1527268321655};\\\", \\\"{x:1328,y:801,t:1527268321671};\\\", \\\"{x:1322,y:796,t:1527268321688};\\\", \\\"{x:1316,y:788,t:1527268321705};\\\", \\\"{x:1313,y:781,t:1527268321721};\\\", \\\"{x:1310,y:773,t:1527268321739};\\\", \\\"{x:1309,y:767,t:1527268321754};\\\", \\\"{x:1308,y:760,t:1527268321772};\\\", \\\"{x:1307,y:751,t:1527268321788};\\\", \\\"{x:1306,y:745,t:1527268321805};\\\", \\\"{x:1304,y:739,t:1527268321822};\\\", \\\"{x:1303,y:735,t:1527268321838};\\\", \\\"{x:1303,y:731,t:1527268321855};\\\", \\\"{x:1301,y:726,t:1527268321872};\\\", \\\"{x:1300,y:723,t:1527268321889};\\\", \\\"{x:1300,y:717,t:1527268321905};\\\", \\\"{x:1299,y:714,t:1527268321922};\\\", \\\"{x:1298,y:706,t:1527268321939};\\\", \\\"{x:1297,y:695,t:1527268321956};\\\", \\\"{x:1295,y:684,t:1527268321972};\\\", \\\"{x:1291,y:670,t:1527268321989};\\\", \\\"{x:1287,y:655,t:1527268322006};\\\", \\\"{x:1285,y:648,t:1527268322022};\\\", \\\"{x:1282,y:636,t:1527268322039};\\\", \\\"{x:1280,y:626,t:1527268322055};\\\", \\\"{x:1279,y:622,t:1527268322073};\\\", \\\"{x:1279,y:618,t:1527268322089};\\\", \\\"{x:1278,y:609,t:1527268322105};\\\", \\\"{x:1275,y:601,t:1527268322122};\\\", \\\"{x:1273,y:596,t:1527268322139};\\\", \\\"{x:1272,y:592,t:1527268322156};\\\", \\\"{x:1271,y:589,t:1527268322172};\\\", \\\"{x:1270,y:587,t:1527268322189};\\\", \\\"{x:1268,y:584,t:1527268322206};\\\", \\\"{x:1267,y:582,t:1527268322222};\\\", \\\"{x:1265,y:581,t:1527268322238};\\\", \\\"{x:1264,y:580,t:1527268322255};\\\", \\\"{x:1262,y:580,t:1527268322272};\\\", \\\"{x:1260,y:578,t:1527268322288};\\\", \\\"{x:1258,y:576,t:1527268322305};\\\", \\\"{x:1258,y:575,t:1527268322321};\\\", \\\"{x:1257,y:575,t:1527268322339};\\\", \\\"{x:1257,y:574,t:1527268322355};\\\", \\\"{x:1257,y:573,t:1527268322391};\\\", \\\"{x:1257,y:572,t:1527268322496};\\\", \\\"{x:1255,y:572,t:1527268322592};\\\", \\\"{x:1238,y:573,t:1527268322606};\\\", \\\"{x:1084,y:592,t:1527268322623};\\\", \\\"{x:1014,y:598,t:1527268322639};\\\", \\\"{x:785,y:618,t:1527268322656};\\\", \\\"{x:647,y:618,t:1527268322673};\\\", \\\"{x:535,y:615,t:1527268322689};\\\", \\\"{x:452,y:604,t:1527268322705};\\\", \\\"{x:398,y:596,t:1527268322722};\\\", \\\"{x:369,y:594,t:1527268322738};\\\", \\\"{x:354,y:594,t:1527268322755};\\\", \\\"{x:344,y:594,t:1527268322772};\\\", \\\"{x:328,y:594,t:1527268322789};\\\", \\\"{x:307,y:594,t:1527268322805};\\\", \\\"{x:290,y:594,t:1527268322822};\\\", \\\"{x:273,y:592,t:1527268322839};\\\", \\\"{x:266,y:590,t:1527268322856};\\\", \\\"{x:264,y:588,t:1527268322873};\\\", \\\"{x:261,y:586,t:1527268322888};\\\", \\\"{x:259,y:584,t:1527268322905};\\\", \\\"{x:259,y:583,t:1527268322921};\\\", \\\"{x:259,y:580,t:1527268322938};\\\", \\\"{x:259,y:577,t:1527268322956};\\\", \\\"{x:259,y:572,t:1527268322972};\\\", \\\"{x:268,y:567,t:1527268322988};\\\", \\\"{x:289,y:560,t:1527268323006};\\\", \\\"{x:326,y:554,t:1527268323022};\\\", \\\"{x:373,y:549,t:1527268323038};\\\", \\\"{x:433,y:548,t:1527268323056};\\\", \\\"{x:464,y:548,t:1527268323072};\\\", \\\"{x:491,y:548,t:1527268323089};\\\", \\\"{x:518,y:547,t:1527268323107};\\\", \\\"{x:546,y:544,t:1527268323124};\\\", \\\"{x:580,y:541,t:1527268323139};\\\", \\\"{x:614,y:536,t:1527268323156};\\\", \\\"{x:638,y:531,t:1527268323173};\\\", \\\"{x:663,y:529,t:1527268323190};\\\", \\\"{x:685,y:529,t:1527268323206};\\\", \\\"{x:699,y:529,t:1527268323222};\\\", \\\"{x:708,y:528,t:1527268323239};\\\", \\\"{x:710,y:528,t:1527268323257};\\\", \\\"{x:710,y:527,t:1527268323327};\\\", \\\"{x:706,y:525,t:1527268323339};\\\", \\\"{x:690,y:519,t:1527268323358};\\\", \\\"{x:667,y:510,t:1527268323373};\\\", \\\"{x:650,y:504,t:1527268323389};\\\", \\\"{x:635,y:501,t:1527268323406};\\\", \\\"{x:632,y:500,t:1527268323422};\\\", \\\"{x:630,y:500,t:1527268323439};\\\", \\\"{x:629,y:500,t:1527268323503};\\\", \\\"{x:629,y:499,t:1527268323511};\\\", \\\"{x:628,y:499,t:1527268323567};\\\", \\\"{x:627,y:499,t:1527268323579};\\\", \\\"{x:626,y:499,t:1527268323595};\\\", \\\"{x:625,y:499,t:1527268323643};\\\", \\\"{x:624,y:499,t:1527268323661};\\\", \\\"{x:623,y:499,t:1527268323683};\\\", \\\"{x:621,y:499,t:1527268323707};\\\", \\\"{x:620,y:499,t:1527268323715};\\\", \\\"{x:619,y:499,t:1527268323740};\\\", \\\"{x:618,y:499,t:1527268323756};\\\", \\\"{x:617,y:499,t:1527268323771};\\\", \\\"{x:616,y:499,t:1527268323802};\\\", \\\"{x:615,y:499,t:1527268323811};\\\", \\\"{x:614,y:499,t:1527268323826};\\\", \\\"{x:613,y:500,t:1527268324388};\\\", \\\"{x:613,y:501,t:1527268324395};\\\", \\\"{x:613,y:505,t:1527268324411};\\\", \\\"{x:613,y:515,t:1527268324429};\\\", \\\"{x:613,y:522,t:1527268324445};\\\", \\\"{x:613,y:527,t:1527268324461};\\\", \\\"{x:613,y:529,t:1527268324477};\\\", \\\"{x:613,y:530,t:1527268324494};\\\", \\\"{x:613,y:531,t:1527268324580};\\\", \\\"{x:613,y:533,t:1527268324603};\\\", \\\"{x:613,y:535,t:1527268324611};\\\", \\\"{x:613,y:543,t:1527268324627};\\\", \\\"{x:608,y:551,t:1527268324644};\\\", \\\"{x:602,y:561,t:1527268324662};\\\", \\\"{x:592,y:568,t:1527268324678};\\\", \\\"{x:581,y:576,t:1527268324693};\\\", \\\"{x:570,y:580,t:1527268324710};\\\", \\\"{x:563,y:582,t:1527268324727};\\\", \\\"{x:560,y:584,t:1527268324743};\\\", \\\"{x:559,y:584,t:1527268324770};\\\", \\\"{x:557,y:585,t:1527268324794};\\\", \\\"{x:554,y:586,t:1527268324810};\\\", \\\"{x:535,y:595,t:1527268324827};\\\", \\\"{x:510,y:604,t:1527268324844};\\\", \\\"{x:481,y:612,t:1527268324862};\\\", \\\"{x:457,y:619,t:1527268324877};\\\", \\\"{x:434,y:623,t:1527268324894};\\\", \\\"{x:414,y:627,t:1527268324911};\\\", \\\"{x:399,y:627,t:1527268324927};\\\", \\\"{x:384,y:627,t:1527268324945};\\\", \\\"{x:369,y:627,t:1527268324961};\\\", \\\"{x:340,y:627,t:1527268324979};\\\", \\\"{x:325,y:624,t:1527268324994};\\\", \\\"{x:309,y:621,t:1527268325011};\\\", \\\"{x:296,y:619,t:1527268325028};\\\", \\\"{x:285,y:615,t:1527268325046};\\\", \\\"{x:279,y:612,t:1527268325061};\\\", \\\"{x:275,y:611,t:1527268325078};\\\", \\\"{x:273,y:609,t:1527268325095};\\\", \\\"{x:270,y:607,t:1527268325112};\\\", \\\"{x:267,y:606,t:1527268325129};\\\", \\\"{x:265,y:605,t:1527268325144};\\\", \\\"{x:262,y:602,t:1527268325161};\\\", \\\"{x:256,y:598,t:1527268325179};\\\", \\\"{x:254,y:597,t:1527268325194};\\\", \\\"{x:247,y:594,t:1527268325211};\\\", \\\"{x:240,y:591,t:1527268325229};\\\", \\\"{x:220,y:584,t:1527268325244};\\\", \\\"{x:194,y:580,t:1527268325262};\\\", \\\"{x:163,y:576,t:1527268325279};\\\", \\\"{x:135,y:574,t:1527268325294};\\\", \\\"{x:121,y:573,t:1527268325311};\\\", \\\"{x:119,y:573,t:1527268325328};\\\", \\\"{x:124,y:573,t:1527268325420};\\\", \\\"{x:135,y:573,t:1527268325429};\\\", \\\"{x:175,y:570,t:1527268325446};\\\", \\\"{x:249,y:563,t:1527268325462};\\\", \\\"{x:331,y:557,t:1527268325479};\\\", \\\"{x:406,y:557,t:1527268325495};\\\", \\\"{x:476,y:557,t:1527268325512};\\\", \\\"{x:531,y:557,t:1527268325529};\\\", \\\"{x:573,y:557,t:1527268325546};\\\", \\\"{x:600,y:557,t:1527268325562};\\\", \\\"{x:619,y:557,t:1527268325579};\\\", \\\"{x:631,y:557,t:1527268325595};\\\", \\\"{x:642,y:559,t:1527268325612};\\\", \\\"{x:656,y:561,t:1527268325629};\\\", \\\"{x:671,y:562,t:1527268325645};\\\", \\\"{x:694,y:562,t:1527268325662};\\\", \\\"{x:716,y:562,t:1527268325678};\\\", \\\"{x:734,y:562,t:1527268325696};\\\", \\\"{x:752,y:561,t:1527268325712};\\\", \\\"{x:763,y:559,t:1527268325728};\\\", \\\"{x:767,y:557,t:1527268325745};\\\", \\\"{x:768,y:557,t:1527268325787};\\\", \\\"{x:769,y:557,t:1527268325827};\\\", \\\"{x:770,y:557,t:1527268325852};\\\", \\\"{x:772,y:557,t:1527268325868};\\\", \\\"{x:773,y:557,t:1527268325878};\\\", \\\"{x:783,y:562,t:1527268325895};\\\", \\\"{x:793,y:564,t:1527268325913};\\\", \\\"{x:804,y:568,t:1527268325928};\\\", \\\"{x:811,y:568,t:1527268325946};\\\", \\\"{x:817,y:568,t:1527268325963};\\\", \\\"{x:819,y:568,t:1527268325979};\\\", \\\"{x:821,y:568,t:1527268325995};\\\", \\\"{x:823,y:567,t:1527268326013};\\\", \\\"{x:824,y:567,t:1527268326029};\\\", \\\"{x:827,y:566,t:1527268326046};\\\", \\\"{x:828,y:565,t:1527268326063};\\\", \\\"{x:831,y:563,t:1527268326078};\\\", \\\"{x:835,y:560,t:1527268326096};\\\", \\\"{x:840,y:557,t:1527268326112};\\\", \\\"{x:844,y:553,t:1527268326129};\\\", \\\"{x:850,y:549,t:1527268326146};\\\", \\\"{x:853,y:548,t:1527268326163};\\\", \\\"{x:851,y:546,t:1527268326394};\\\", \\\"{x:850,y:546,t:1527268326402};\\\", \\\"{x:849,y:546,t:1527268326412};\\\", \\\"{x:846,y:546,t:1527268326429};\\\", \\\"{x:845,y:545,t:1527268326445};\\\", \\\"{x:844,y:545,t:1527268326463};\\\", \\\"{x:843,y:545,t:1527268326479};\\\", \\\"{x:842,y:545,t:1527268326898};\\\", \\\"{x:840,y:545,t:1527268326912};\\\", \\\"{x:829,y:551,t:1527268326929};\\\", \\\"{x:794,y:572,t:1527268326947};\\\", \\\"{x:749,y:593,t:1527268326962};\\\", \\\"{x:680,y:623,t:1527268326980};\\\", \\\"{x:595,y:653,t:1527268326997};\\\", \\\"{x:527,y:678,t:1527268327012};\\\", \\\"{x:471,y:696,t:1527268327030};\\\", \\\"{x:432,y:708,t:1527268327046};\\\", \\\"{x:411,y:713,t:1527268327063};\\\", \\\"{x:403,y:715,t:1527268327080};\\\", \\\"{x:402,y:715,t:1527268327097};\\\", \\\"{x:401,y:716,t:1527268327219};\\\", \\\"{x:403,y:719,t:1527268327230};\\\", \\\"{x:414,y:731,t:1527268327247};\\\", \\\"{x:427,y:749,t:1527268327263};\\\", \\\"{x:441,y:764,t:1527268327279};\\\", \\\"{x:458,y:776,t:1527268327296};\\\", \\\"{x:475,y:782,t:1527268327313};\\\", \\\"{x:496,y:784,t:1527268327330};\\\", \\\"{x:500,y:784,t:1527268327347};\\\", \\\"{x:501,y:784,t:1527268327386};\\\", \\\"{x:501,y:783,t:1527268327403};\\\", \\\"{x:501,y:782,t:1527268327435};\\\", \\\"{x:501,y:780,t:1527268327484};\\\", \\\"{x:501,y:778,t:1527268327508};\\\", \\\"{x:501,y:777,t:1527268327515};\\\", \\\"{x:501,y:772,t:1527268327532};\\\", \\\"{x:501,y:766,t:1527268327548};\\\", \\\"{x:501,y:760,t:1527268327564};\\\", \\\"{x:501,y:757,t:1527268327580};\\\", \\\"{x:502,y:752,t:1527268327597};\\\", \\\"{x:503,y:748,t:1527268327613};\\\", \\\"{x:503,y:743,t:1527268327629};\\\", \\\"{x:504,y:739,t:1527268327646};\\\", \\\"{x:505,y:736,t:1527268327663};\\\", \\\"{x:506,y:736,t:1527268329099};\\\" ] }, { \\\"rt\\\": 35052, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 400061, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -C -G -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:736,t:1527268329633};\\\", \\\"{x:508,y:736,t:1527268329739};\\\", \\\"{x:509,y:736,t:1527268329811};\\\", \\\"{x:510,y:736,t:1527268329827};\\\", \\\"{x:511,y:736,t:1527268329916};\\\", \\\"{x:515,y:736,t:1527268329931};\\\", \\\"{x:569,y:689,t:1527268329950};\\\", \\\"{x:651,y:621,t:1527268329966};\\\", \\\"{x:691,y:576,t:1527268329984};\\\", \\\"{x:709,y:548,t:1527268329999};\\\", \\\"{x:720,y:531,t:1527268330015};\\\", \\\"{x:721,y:529,t:1527268330032};\\\", \\\"{x:721,y:528,t:1527268330048};\\\", \\\"{x:721,y:525,t:1527268330066};\\\", \\\"{x:721,y:524,t:1527268330082};\\\", \\\"{x:721,y:521,t:1527268330098};\\\", \\\"{x:720,y:519,t:1527268330115};\\\", \\\"{x:716,y:514,t:1527268330133};\\\", \\\"{x:711,y:509,t:1527268330149};\\\", \\\"{x:704,y:505,t:1527268330165};\\\", \\\"{x:692,y:497,t:1527268330183};\\\", \\\"{x:680,y:491,t:1527268330198};\\\", \\\"{x:666,y:486,t:1527268330216};\\\", \\\"{x:643,y:481,t:1527268330233};\\\", \\\"{x:617,y:479,t:1527268330248};\\\", \\\"{x:588,y:479,t:1527268330266};\\\", \\\"{x:544,y:479,t:1527268330282};\\\", \\\"{x:520,y:479,t:1527268330299};\\\", \\\"{x:502,y:479,t:1527268330316};\\\", \\\"{x:493,y:479,t:1527268330333};\\\", \\\"{x:488,y:479,t:1527268330349};\\\", \\\"{x:485,y:479,t:1527268330366};\\\", \\\"{x:483,y:479,t:1527268330383};\\\", \\\"{x:482,y:479,t:1527268330399};\\\", \\\"{x:480,y:479,t:1527268330416};\\\", \\\"{x:476,y:479,t:1527268330433};\\\", \\\"{x:472,y:479,t:1527268330450};\\\", \\\"{x:464,y:479,t:1527268330466};\\\", \\\"{x:443,y:479,t:1527268330483};\\\", \\\"{x:433,y:479,t:1527268330500};\\\", \\\"{x:426,y:478,t:1527268330515};\\\", \\\"{x:418,y:478,t:1527268330533};\\\", \\\"{x:410,y:478,t:1527268330550};\\\", \\\"{x:401,y:476,t:1527268330566};\\\", \\\"{x:396,y:475,t:1527268330583};\\\", \\\"{x:392,y:474,t:1527268330600};\\\", \\\"{x:388,y:472,t:1527268330615};\\\", \\\"{x:386,y:472,t:1527268330633};\\\", \\\"{x:385,y:472,t:1527268330659};\\\", \\\"{x:384,y:472,t:1527268330676};\\\", \\\"{x:383,y:471,t:1527268330691};\\\", \\\"{x:386,y:469,t:1527268331050};\\\", \\\"{x:401,y:469,t:1527268331066};\\\", \\\"{x:420,y:466,t:1527268331083};\\\", \\\"{x:441,y:463,t:1527268331099};\\\", \\\"{x:460,y:460,t:1527268331116};\\\", \\\"{x:477,y:457,t:1527268331133};\\\", \\\"{x:485,y:456,t:1527268331150};\\\", \\\"{x:487,y:456,t:1527268331167};\\\", \\\"{x:487,y:455,t:1527268331186};\\\", \\\"{x:488,y:455,t:1527268331202};\\\", \\\"{x:490,y:455,t:1527268331234};\\\", \\\"{x:497,y:455,t:1527268331250};\\\", \\\"{x:506,y:455,t:1527268331267};\\\", \\\"{x:513,y:455,t:1527268331283};\\\", \\\"{x:518,y:455,t:1527268331300};\\\", \\\"{x:521,y:455,t:1527268331316};\\\", \\\"{x:524,y:455,t:1527268331333};\\\", \\\"{x:525,y:455,t:1527268331362};\\\", \\\"{x:526,y:455,t:1527268331378};\\\", \\\"{x:527,y:455,t:1527268331394};\\\", \\\"{x:528,y:455,t:1527268331402};\\\", \\\"{x:530,y:455,t:1527268331417};\\\", \\\"{x:533,y:455,t:1527268331434};\\\", \\\"{x:542,y:456,t:1527268331450};\\\", \\\"{x:546,y:457,t:1527268331468};\\\", \\\"{x:550,y:459,t:1527268331483};\\\", \\\"{x:551,y:459,t:1527268331500};\\\", \\\"{x:552,y:459,t:1527268331517};\\\", \\\"{x:553,y:459,t:1527268331594};\\\", \\\"{x:554,y:459,t:1527268331635};\\\", \\\"{x:555,y:460,t:1527268331666};\\\", \\\"{x:558,y:461,t:1527268331682};\\\", \\\"{x:559,y:461,t:1527268331691};\\\", \\\"{x:562,y:462,t:1527268331701};\\\", \\\"{x:567,y:463,t:1527268331718};\\\", \\\"{x:573,y:463,t:1527268331733};\\\", \\\"{x:577,y:465,t:1527268331751};\\\", \\\"{x:581,y:465,t:1527268331768};\\\", \\\"{x:583,y:465,t:1527268331784};\\\", \\\"{x:585,y:465,t:1527268331800};\\\", \\\"{x:587,y:465,t:1527268331817};\\\", \\\"{x:594,y:466,t:1527268331834};\\\", \\\"{x:599,y:468,t:1527268331851};\\\", \\\"{x:601,y:469,t:1527268331868};\\\", \\\"{x:606,y:470,t:1527268331885};\\\", \\\"{x:611,y:473,t:1527268331901};\\\", \\\"{x:615,y:474,t:1527268331918};\\\", \\\"{x:618,y:477,t:1527268331935};\\\", \\\"{x:620,y:477,t:1527268331951};\\\", \\\"{x:621,y:477,t:1527268331968};\\\", \\\"{x:621,y:478,t:1527268331985};\\\", \\\"{x:623,y:478,t:1527268332050};\\\", \\\"{x:624,y:478,t:1527268332115};\\\", \\\"{x:626,y:478,t:1527268332138};\\\", \\\"{x:627,y:478,t:1527268332162};\\\", \\\"{x:629,y:478,t:1527268332170};\\\", \\\"{x:631,y:478,t:1527268332186};\\\", \\\"{x:633,y:478,t:1527268332201};\\\", \\\"{x:636,y:478,t:1527268332217};\\\", \\\"{x:644,y:476,t:1527268332234};\\\", \\\"{x:647,y:475,t:1527268332252};\\\", \\\"{x:650,y:475,t:1527268332268};\\\", \\\"{x:651,y:473,t:1527268332284};\\\", \\\"{x:653,y:473,t:1527268332301};\\\", \\\"{x:654,y:472,t:1527268332322};\\\", \\\"{x:655,y:472,t:1527268332346};\\\", \\\"{x:655,y:471,t:1527268332379};\\\", \\\"{x:656,y:471,t:1527268332435};\\\", \\\"{x:657,y:471,t:1527268332452};\\\", \\\"{x:658,y:471,t:1527268332468};\\\", \\\"{x:659,y:471,t:1527268332571};\\\", \\\"{x:660,y:471,t:1527268332597};\\\", \\\"{x:661,y:470,t:1527268332627};\\\", \\\"{x:662,y:469,t:1527268333197};\\\", \\\"{x:663,y:469,t:1527268333284};\\\", \\\"{x:664,y:469,t:1527268334100};\\\", \\\"{x:688,y:469,t:1527268343123};\\\", \\\"{x:757,y:487,t:1527268343135};\\\", \\\"{x:926,y:536,t:1527268343150};\\\", \\\"{x:1126,y:578,t:1527268343166};\\\", \\\"{x:1275,y:648,t:1527268343193};\\\", \\\"{x:1314,y:680,t:1527268343209};\\\", \\\"{x:1340,y:696,t:1527268343227};\\\", \\\"{x:1355,y:702,t:1527268343243};\\\", \\\"{x:1370,y:708,t:1527268343259};\\\", \\\"{x:1383,y:713,t:1527268343276};\\\", \\\"{x:1395,y:719,t:1527268343293};\\\", \\\"{x:1403,y:725,t:1527268343309};\\\", \\\"{x:1410,y:727,t:1527268343326};\\\", \\\"{x:1419,y:731,t:1527268343343};\\\", \\\"{x:1428,y:735,t:1527268343360};\\\", \\\"{x:1440,y:737,t:1527268343377};\\\", \\\"{x:1448,y:740,t:1527268343393};\\\", \\\"{x:1453,y:741,t:1527268343409};\\\", \\\"{x:1456,y:743,t:1527268343427};\\\", \\\"{x:1455,y:743,t:1527268343532};\\\", \\\"{x:1451,y:743,t:1527268343544};\\\", \\\"{x:1442,y:739,t:1527268343560};\\\", \\\"{x:1434,y:737,t:1527268343576};\\\", \\\"{x:1428,y:735,t:1527268343593};\\\", \\\"{x:1419,y:733,t:1527268343610};\\\", \\\"{x:1408,y:730,t:1527268343627};\\\", \\\"{x:1399,y:727,t:1527268343644};\\\", \\\"{x:1394,y:725,t:1527268343661};\\\", \\\"{x:1390,y:725,t:1527268343677};\\\", \\\"{x:1388,y:725,t:1527268343694};\\\", \\\"{x:1382,y:723,t:1527268343711};\\\", \\\"{x:1371,y:721,t:1527268343726};\\\", \\\"{x:1355,y:718,t:1527268343744};\\\", \\\"{x:1349,y:717,t:1527268343761};\\\", \\\"{x:1345,y:716,t:1527268343777};\\\", \\\"{x:1341,y:714,t:1527268343794};\\\", \\\"{x:1338,y:713,t:1527268343811};\\\", \\\"{x:1337,y:712,t:1527268343827};\\\", \\\"{x:1335,y:712,t:1527268343899};\\\", \\\"{x:1334,y:712,t:1527268344188};\\\", \\\"{x:1334,y:713,t:1527268344203};\\\", \\\"{x:1334,y:714,t:1527268344211};\\\", \\\"{x:1334,y:716,t:1527268344244};\\\", \\\"{x:1334,y:718,t:1527268344275};\\\", \\\"{x:1335,y:720,t:1527268344283};\\\", \\\"{x:1335,y:721,t:1527268344294};\\\", \\\"{x:1335,y:725,t:1527268344311};\\\", \\\"{x:1335,y:732,t:1527268344328};\\\", \\\"{x:1335,y:736,t:1527268344344};\\\", \\\"{x:1335,y:742,t:1527268344361};\\\", \\\"{x:1335,y:746,t:1527268344378};\\\", \\\"{x:1335,y:748,t:1527268344394};\\\", \\\"{x:1335,y:749,t:1527268344459};\\\", \\\"{x:1336,y:750,t:1527268344478};\\\", \\\"{x:1338,y:750,t:1527268344532};\\\", \\\"{x:1338,y:751,t:1527268344563};\\\", \\\"{x:1338,y:753,t:1527268344578};\\\", \\\"{x:1338,y:755,t:1527268344595};\\\", \\\"{x:1339,y:756,t:1527268344611};\\\", \\\"{x:1340,y:756,t:1527268344699};\\\", \\\"{x:1341,y:756,t:1527268344715};\\\", \\\"{x:1343,y:757,t:1527268344771};\\\", \\\"{x:1343,y:758,t:1527268344788};\\\", \\\"{x:1344,y:759,t:1527268344797};\\\", \\\"{x:1344,y:760,t:1527268344810};\\\", \\\"{x:1344,y:761,t:1527268345019};\\\", \\\"{x:1344,y:762,t:1527268345579};\\\", \\\"{x:1346,y:762,t:1527268345594};\\\", \\\"{x:1349,y:763,t:1527268345612};\\\", \\\"{x:1351,y:764,t:1527268345629};\\\", \\\"{x:1353,y:765,t:1527268345644};\\\", \\\"{x:1353,y:766,t:1527268345662};\\\", \\\"{x:1356,y:766,t:1527268345679};\\\", \\\"{x:1357,y:766,t:1527268345708};\\\", \\\"{x:1358,y:767,t:1527268345907};\\\", \\\"{x:1359,y:767,t:1527268346068};\\\", \\\"{x:1360,y:767,t:1527268346099};\\\", \\\"{x:1361,y:768,t:1527268346112};\\\", \\\"{x:1362,y:769,t:1527268346131};\\\", \\\"{x:1362,y:770,t:1527268346220};\\\", \\\"{x:1362,y:772,t:1527268346397};\\\", \\\"{x:1362,y:774,t:1527268346428};\\\", \\\"{x:1362,y:773,t:1527268347156};\\\", \\\"{x:1362,y:770,t:1527268347163};\\\", \\\"{x:1366,y:760,t:1527268347179};\\\", \\\"{x:1369,y:750,t:1527268347198};\\\", \\\"{x:1373,y:739,t:1527268347213};\\\", \\\"{x:1379,y:729,t:1527268347230};\\\", \\\"{x:1381,y:722,t:1527268347247};\\\", \\\"{x:1384,y:715,t:1527268347263};\\\", \\\"{x:1387,y:710,t:1527268347279};\\\", \\\"{x:1396,y:699,t:1527268347296};\\\", \\\"{x:1401,y:692,t:1527268347313};\\\", \\\"{x:1409,y:681,t:1527268347329};\\\", \\\"{x:1420,y:662,t:1527268347347};\\\", \\\"{x:1431,y:647,t:1527268347362};\\\", \\\"{x:1437,y:635,t:1527268347379};\\\", \\\"{x:1442,y:625,t:1527268347396};\\\", \\\"{x:1448,y:614,t:1527268347413};\\\", \\\"{x:1455,y:603,t:1527268347429};\\\", \\\"{x:1459,y:595,t:1527268347446};\\\", \\\"{x:1462,y:590,t:1527268347462};\\\", \\\"{x:1464,y:586,t:1527268347480};\\\", \\\"{x:1464,y:585,t:1527268347496};\\\", \\\"{x:1464,y:584,t:1527268347512};\\\", \\\"{x:1464,y:583,t:1527268347530};\\\", \\\"{x:1465,y:578,t:1527268347547};\\\", \\\"{x:1466,y:575,t:1527268347563};\\\", \\\"{x:1466,y:573,t:1527268347580};\\\", \\\"{x:1466,y:571,t:1527268347598};\\\", \\\"{x:1466,y:570,t:1527268347613};\\\", \\\"{x:1466,y:567,t:1527268347630};\\\", \\\"{x:1466,y:564,t:1527268347647};\\\", \\\"{x:1466,y:561,t:1527268347663};\\\", \\\"{x:1466,y:557,t:1527268347680};\\\", \\\"{x:1466,y:555,t:1527268347697};\\\", \\\"{x:1466,y:554,t:1527268347715};\\\", \\\"{x:1466,y:552,t:1527268347730};\\\", \\\"{x:1466,y:546,t:1527268347747};\\\", \\\"{x:1466,y:532,t:1527268347764};\\\", \\\"{x:1465,y:511,t:1527268347781};\\\", \\\"{x:1465,y:494,t:1527268347797};\\\", \\\"{x:1465,y:480,t:1527268347814};\\\", \\\"{x:1462,y:468,t:1527268347830};\\\", \\\"{x:1459,y:458,t:1527268347847};\\\", \\\"{x:1457,y:451,t:1527268347864};\\\", \\\"{x:1455,y:448,t:1527268347880};\\\", \\\"{x:1453,y:443,t:1527268347896};\\\", \\\"{x:1452,y:441,t:1527268347913};\\\", \\\"{x:1450,y:438,t:1527268347930};\\\", \\\"{x:1449,y:437,t:1527268347947};\\\", \\\"{x:1447,y:437,t:1527268347963};\\\", \\\"{x:1446,y:437,t:1527268347980};\\\", \\\"{x:1444,y:437,t:1527268347997};\\\", \\\"{x:1442,y:437,t:1527268348014};\\\", \\\"{x:1440,y:435,t:1527268348030};\\\", \\\"{x:1439,y:434,t:1527268348059};\\\", \\\"{x:1438,y:434,t:1527268348075};\\\", \\\"{x:1437,y:434,t:1527268348091};\\\", \\\"{x:1436,y:433,t:1527268348100};\\\", \\\"{x:1435,y:433,t:1527268348114};\\\", \\\"{x:1433,y:433,t:1527268348154};\\\", \\\"{x:1432,y:437,t:1527268348163};\\\", \\\"{x:1428,y:443,t:1527268348181};\\\", \\\"{x:1421,y:457,t:1527268348196};\\\", \\\"{x:1416,y:469,t:1527268348213};\\\", \\\"{x:1414,y:479,t:1527268348230};\\\", \\\"{x:1412,y:485,t:1527268348246};\\\", \\\"{x:1412,y:488,t:1527268348263};\\\", \\\"{x:1411,y:489,t:1527268348280};\\\", \\\"{x:1411,y:491,t:1527268348436};\\\", \\\"{x:1411,y:493,t:1527268348447};\\\", \\\"{x:1411,y:500,t:1527268348464};\\\", \\\"{x:1411,y:504,t:1527268348481};\\\", \\\"{x:1411,y:507,t:1527268348497};\\\", \\\"{x:1411,y:508,t:1527268348514};\\\", \\\"{x:1411,y:509,t:1527268348620};\\\", \\\"{x:1411,y:511,t:1527268348635};\\\", \\\"{x:1411,y:513,t:1527268348648};\\\", \\\"{x:1411,y:516,t:1527268348664};\\\", \\\"{x:1411,y:521,t:1527268348681};\\\", \\\"{x:1411,y:526,t:1527268348698};\\\", \\\"{x:1411,y:531,t:1527268348714};\\\", \\\"{x:1411,y:535,t:1527268348730};\\\", \\\"{x:1411,y:536,t:1527268348755};\\\", \\\"{x:1411,y:538,t:1527268348891};\\\", \\\"{x:1411,y:539,t:1527268348899};\\\", \\\"{x:1411,y:543,t:1527268348915};\\\", \\\"{x:1411,y:547,t:1527268348930};\\\", \\\"{x:1411,y:550,t:1527268348947};\\\", \\\"{x:1411,y:552,t:1527268348963};\\\", \\\"{x:1411,y:553,t:1527268349227};\\\", \\\"{x:1410,y:553,t:1527268349428};\\\", \\\"{x:1409,y:553,t:1527268349628};\\\", \\\"{x:1408,y:553,t:1527268350100};\\\", \\\"{x:1405,y:558,t:1527268350115};\\\", \\\"{x:1401,y:564,t:1527268350132};\\\", \\\"{x:1400,y:567,t:1527268350149};\\\", \\\"{x:1399,y:571,t:1527268350165};\\\", \\\"{x:1398,y:574,t:1527268350182};\\\", \\\"{x:1396,y:575,t:1527268350198};\\\", \\\"{x:1396,y:577,t:1527268350339};\\\", \\\"{x:1396,y:578,t:1527268350348};\\\", \\\"{x:1396,y:581,t:1527268350366};\\\", \\\"{x:1396,y:583,t:1527268350382};\\\", \\\"{x:1396,y:584,t:1527268350398};\\\", \\\"{x:1396,y:585,t:1527268350416};\\\", \\\"{x:1396,y:587,t:1527268350612};\\\", \\\"{x:1394,y:590,t:1527268350619};\\\", \\\"{x:1394,y:592,t:1527268350632};\\\", \\\"{x:1393,y:594,t:1527268350649};\\\", \\\"{x:1393,y:596,t:1527268350666};\\\", \\\"{x:1393,y:597,t:1527268350835};\\\", \\\"{x:1393,y:598,t:1527268350852};\\\", \\\"{x:1393,y:599,t:1527268350867};\\\", \\\"{x:1393,y:600,t:1527268350907};\\\", \\\"{x:1393,y:601,t:1527268350988};\\\", \\\"{x:1393,y:602,t:1527268350999};\\\", \\\"{x:1389,y:609,t:1527268351016};\\\", \\\"{x:1385,y:620,t:1527268351032};\\\", \\\"{x:1379,y:633,t:1527268351049};\\\", \\\"{x:1373,y:648,t:1527268351066};\\\", \\\"{x:1362,y:666,t:1527268351083};\\\", \\\"{x:1357,y:675,t:1527268351099};\\\", \\\"{x:1353,y:679,t:1527268351116};\\\", \\\"{x:1352,y:682,t:1527268351133};\\\", \\\"{x:1351,y:683,t:1527268351195};\\\", \\\"{x:1350,y:683,t:1527268351228};\\\", \\\"{x:1350,y:684,t:1527268351235};\\\", \\\"{x:1348,y:686,t:1527268351251};\\\", \\\"{x:1348,y:687,t:1527268351266};\\\", \\\"{x:1346,y:692,t:1527268351284};\\\", \\\"{x:1344,y:697,t:1527268351299};\\\", \\\"{x:1343,y:698,t:1527268351316};\\\", \\\"{x:1343,y:699,t:1527268351435};\\\", \\\"{x:1343,y:701,t:1527268351468};\\\", \\\"{x:1343,y:702,t:1527268351491};\\\", \\\"{x:1343,y:704,t:1527268351500};\\\", \\\"{x:1343,y:708,t:1527268351516};\\\", \\\"{x:1343,y:711,t:1527268351533};\\\", \\\"{x:1345,y:717,t:1527268351550};\\\", \\\"{x:1348,y:723,t:1527268351566};\\\", \\\"{x:1350,y:727,t:1527268351583};\\\", \\\"{x:1350,y:730,t:1527268351600};\\\", \\\"{x:1352,y:732,t:1527268351617};\\\", \\\"{x:1352,y:733,t:1527268351633};\\\", \\\"{x:1352,y:734,t:1527268351650};\\\", \\\"{x:1352,y:736,t:1527268351667};\\\", \\\"{x:1353,y:737,t:1527268351683};\\\", \\\"{x:1353,y:738,t:1527268351700};\\\", \\\"{x:1353,y:740,t:1527268351717};\\\", \\\"{x:1353,y:741,t:1527268351733};\\\", \\\"{x:1353,y:743,t:1527268351750};\\\", \\\"{x:1353,y:744,t:1527268351767};\\\", \\\"{x:1353,y:746,t:1527268351783};\\\", \\\"{x:1353,y:750,t:1527268351800};\\\", \\\"{x:1353,y:755,t:1527268351816};\\\", \\\"{x:1353,y:757,t:1527268351832};\\\", \\\"{x:1353,y:760,t:1527268351849};\\\", \\\"{x:1353,y:762,t:1527268351867};\\\", \\\"{x:1353,y:763,t:1527268351899};\\\", \\\"{x:1352,y:763,t:1527268351970};\\\", \\\"{x:1351,y:763,t:1527268352044};\\\", \\\"{x:1350,y:763,t:1527268352051};\\\", \\\"{x:1348,y:763,t:1527268352067};\\\", \\\"{x:1342,y:763,t:1527268352083};\\\", \\\"{x:1328,y:761,t:1527268352101};\\\", \\\"{x:1310,y:758,t:1527268352117};\\\", \\\"{x:1287,y:751,t:1527268352135};\\\", \\\"{x:1262,y:747,t:1527268352150};\\\", \\\"{x:1229,y:743,t:1527268352167};\\\", \\\"{x:1184,y:737,t:1527268352184};\\\", \\\"{x:1144,y:729,t:1527268352200};\\\", \\\"{x:1111,y:721,t:1527268352217};\\\", \\\"{x:1083,y:712,t:1527268352235};\\\", \\\"{x:1043,y:703,t:1527268352250};\\\", \\\"{x:996,y:688,t:1527268352267};\\\", \\\"{x:962,y:679,t:1527268352285};\\\", \\\"{x:926,y:668,t:1527268352300};\\\", \\\"{x:894,y:659,t:1527268352317};\\\", \\\"{x:870,y:653,t:1527268352333};\\\", \\\"{x:843,y:642,t:1527268352351};\\\", \\\"{x:814,y:632,t:1527268352367};\\\", \\\"{x:786,y:624,t:1527268352386};\\\", \\\"{x:756,y:615,t:1527268352399};\\\", \\\"{x:735,y:609,t:1527268352416};\\\", \\\"{x:723,y:606,t:1527268352434};\\\", \\\"{x:720,y:604,t:1527268352450};\\\", \\\"{x:719,y:603,t:1527268352570};\\\", \\\"{x:719,y:602,t:1527268352635};\\\", \\\"{x:719,y:600,t:1527268352652};\\\", \\\"{x:719,y:598,t:1527268352675};\\\", \\\"{x:719,y:597,t:1527268352690};\\\", \\\"{x:719,y:595,t:1527268352701};\\\", \\\"{x:721,y:592,t:1527268352717};\\\", \\\"{x:726,y:585,t:1527268352735};\\\", \\\"{x:733,y:580,t:1527268352750};\\\", \\\"{x:746,y:572,t:1527268352768};\\\", \\\"{x:763,y:561,t:1527268352785};\\\", \\\"{x:781,y:550,t:1527268352801};\\\", \\\"{x:798,y:541,t:1527268352818};\\\", \\\"{x:811,y:533,t:1527268352834};\\\", \\\"{x:825,y:525,t:1527268352850};\\\", \\\"{x:832,y:522,t:1527268352868};\\\", \\\"{x:836,y:519,t:1527268352883};\\\", \\\"{x:843,y:515,t:1527268352900};\\\", \\\"{x:848,y:512,t:1527268352916};\\\", \\\"{x:852,y:510,t:1527268352934};\\\", \\\"{x:857,y:508,t:1527268352950};\\\", \\\"{x:865,y:503,t:1527268352967};\\\", \\\"{x:869,y:502,t:1527268352983};\\\", \\\"{x:871,y:499,t:1527268353000};\\\", \\\"{x:872,y:499,t:1527268353018};\\\", \\\"{x:872,y:498,t:1527268353155};\\\", \\\"{x:871,y:498,t:1527268353167};\\\", \\\"{x:868,y:497,t:1527268353184};\\\", \\\"{x:866,y:496,t:1527268353201};\\\", \\\"{x:865,y:496,t:1527268353217};\\\", \\\"{x:863,y:496,t:1527268353234};\\\", \\\"{x:859,y:496,t:1527268353251};\\\", \\\"{x:854,y:496,t:1527268353268};\\\", \\\"{x:850,y:496,t:1527268353284};\\\", \\\"{x:849,y:496,t:1527268353301};\\\", \\\"{x:847,y:497,t:1527268353317};\\\", \\\"{x:845,y:498,t:1527268353411};\\\", \\\"{x:845,y:499,t:1527268353443};\\\", \\\"{x:845,y:500,t:1527268353468};\\\", \\\"{x:846,y:501,t:1527268353484};\\\", \\\"{x:847,y:501,t:1527268353500};\\\", \\\"{x:847,y:502,t:1527268353530};\\\", \\\"{x:847,y:502,t:1527268353562};\\\", \\\"{x:846,y:503,t:1527268353780};\\\", \\\"{x:845,y:504,t:1527268353787};\\\", \\\"{x:844,y:505,t:1527268353802};\\\", \\\"{x:839,y:509,t:1527268353819};\\\", \\\"{x:835,y:512,t:1527268353834};\\\", \\\"{x:833,y:514,t:1527268353853};\\\", \\\"{x:829,y:516,t:1527268353868};\\\", \\\"{x:823,y:521,t:1527268353884};\\\", \\\"{x:812,y:526,t:1527268353902};\\\", \\\"{x:809,y:526,t:1527268353917};\\\", \\\"{x:807,y:527,t:1527268353935};\\\", \\\"{x:807,y:528,t:1527268353951};\\\", \\\"{x:806,y:528,t:1527268353967};\\\", \\\"{x:806,y:527,t:1527268354083};\\\", \\\"{x:806,y:526,t:1527268354090};\\\", \\\"{x:807,y:526,t:1527268354101};\\\", \\\"{x:809,y:522,t:1527268354119};\\\", \\\"{x:810,y:521,t:1527268354135};\\\", \\\"{x:811,y:520,t:1527268354152};\\\", \\\"{x:812,y:518,t:1527268354168};\\\", \\\"{x:813,y:518,t:1527268354185};\\\", \\\"{x:813,y:517,t:1527268354202};\\\", \\\"{x:814,y:517,t:1527268354218};\\\", \\\"{x:814,y:516,t:1527268354242};\\\", \\\"{x:815,y:516,t:1527268354252};\\\", \\\"{x:816,y:516,t:1527268354282};\\\", \\\"{x:817,y:516,t:1527268354307};\\\", \\\"{x:818,y:516,t:1527268354318};\\\", \\\"{x:819,y:516,t:1527268354335};\\\", \\\"{x:820,y:516,t:1527268354355};\\\", \\\"{x:821,y:516,t:1527268354369};\\\", \\\"{x:822,y:516,t:1527268354384};\\\", \\\"{x:824,y:516,t:1527268354402};\\\", \\\"{x:825,y:516,t:1527268354419};\\\", \\\"{x:827,y:516,t:1527268354435};\\\", \\\"{x:828,y:516,t:1527268354508};\\\", \\\"{x:828,y:515,t:1527268354739};\\\", \\\"{x:828,y:514,t:1527268354754};\\\", \\\"{x:827,y:514,t:1527268354883};\\\", \\\"{x:822,y:514,t:1527268354891};\\\", \\\"{x:815,y:518,t:1527268354903};\\\", \\\"{x:797,y:519,t:1527268354918};\\\", \\\"{x:775,y:521,t:1527268354936};\\\", \\\"{x:747,y:521,t:1527268354951};\\\", \\\"{x:720,y:521,t:1527268354969};\\\", \\\"{x:695,y:521,t:1527268354986};\\\", \\\"{x:674,y:521,t:1527268355002};\\\", \\\"{x:658,y:521,t:1527268355019};\\\", \\\"{x:657,y:521,t:1527268355035};\\\", \\\"{x:656,y:521,t:1527268355052};\\\", \\\"{x:657,y:521,t:1527268355139};\\\", \\\"{x:661,y:521,t:1527268355153};\\\", \\\"{x:675,y:519,t:1527268355169};\\\", \\\"{x:694,y:513,t:1527268355188};\\\", \\\"{x:731,y:502,t:1527268355202};\\\", \\\"{x:754,y:495,t:1527268355218};\\\", \\\"{x:776,y:488,t:1527268355235};\\\", \\\"{x:793,y:483,t:1527268355253};\\\", \\\"{x:809,y:478,t:1527268355268};\\\", \\\"{x:813,y:477,t:1527268355285};\\\", \\\"{x:817,y:477,t:1527268355303};\\\", \\\"{x:820,y:477,t:1527268355319};\\\", \\\"{x:822,y:477,t:1527268355335};\\\", \\\"{x:823,y:477,t:1527268355352};\\\", \\\"{x:823,y:478,t:1527268355475};\\\", \\\"{x:823,y:479,t:1527268355486};\\\", \\\"{x:821,y:486,t:1527268355503};\\\", \\\"{x:819,y:490,t:1527268355520};\\\", \\\"{x:819,y:491,t:1527268355535};\\\", \\\"{x:819,y:493,t:1527268355552};\\\", \\\"{x:819,y:494,t:1527268355570};\\\", \\\"{x:819,y:495,t:1527268355602};\\\", \\\"{x:820,y:496,t:1527268355626};\\\", \\\"{x:821,y:496,t:1527268355642};\\\", \\\"{x:821,y:497,t:1527268355652};\\\", \\\"{x:824,y:497,t:1527268355669};\\\", \\\"{x:826,y:499,t:1527268355686};\\\", \\\"{x:831,y:499,t:1527268355703};\\\", \\\"{x:833,y:500,t:1527268355722};\\\", \\\"{x:834,y:500,t:1527268355738};\\\", \\\"{x:835,y:501,t:1527268355762};\\\", \\\"{x:836,y:501,t:1527268355787};\\\", \\\"{x:838,y:502,t:1527268355827};\\\", \\\"{x:838,y:503,t:1527268355851};\\\", \\\"{x:840,y:503,t:1527268355874};\\\", \\\"{x:840,y:503,t:1527268355946};\\\", \\\"{x:841,y:503,t:1527268356018};\\\", \\\"{x:839,y:508,t:1527268356026};\\\", \\\"{x:833,y:510,t:1527268356036};\\\", \\\"{x:810,y:521,t:1527268356053};\\\", \\\"{x:771,y:535,t:1527268356070};\\\", \\\"{x:729,y:547,t:1527268356086};\\\", \\\"{x:685,y:557,t:1527268356103};\\\", \\\"{x:655,y:561,t:1527268356119};\\\", \\\"{x:639,y:563,t:1527268356137};\\\", \\\"{x:628,y:563,t:1527268356153};\\\", \\\"{x:610,y:563,t:1527268356169};\\\", \\\"{x:564,y:564,t:1527268356186};\\\", \\\"{x:524,y:566,t:1527268356202};\\\", \\\"{x:482,y:566,t:1527268356221};\\\", \\\"{x:438,y:570,t:1527268356236};\\\", \\\"{x:401,y:577,t:1527268356253};\\\", \\\"{x:373,y:580,t:1527268356270};\\\", \\\"{x:355,y:584,t:1527268356287};\\\", \\\"{x:342,y:589,t:1527268356302};\\\", \\\"{x:331,y:590,t:1527268356320};\\\", \\\"{x:322,y:592,t:1527268356337};\\\", \\\"{x:315,y:592,t:1527268356353};\\\", \\\"{x:310,y:592,t:1527268356370};\\\", \\\"{x:297,y:585,t:1527268356386};\\\", \\\"{x:292,y:580,t:1527268356403};\\\", \\\"{x:285,y:573,t:1527268356420};\\\", \\\"{x:280,y:565,t:1527268356437};\\\", \\\"{x:273,y:556,t:1527268356455};\\\", \\\"{x:269,y:551,t:1527268356471};\\\", \\\"{x:264,y:547,t:1527268356486};\\\", \\\"{x:260,y:546,t:1527268356504};\\\", \\\"{x:251,y:546,t:1527268356520};\\\", \\\"{x:240,y:546,t:1527268356537};\\\", \\\"{x:220,y:546,t:1527268356555};\\\", \\\"{x:206,y:546,t:1527268356570};\\\", \\\"{x:193,y:546,t:1527268356587};\\\", \\\"{x:190,y:546,t:1527268356604};\\\", \\\"{x:187,y:544,t:1527268356620};\\\", \\\"{x:185,y:543,t:1527268356636};\\\", \\\"{x:183,y:542,t:1527268356653};\\\", \\\"{x:181,y:541,t:1527268356669};\\\", \\\"{x:179,y:539,t:1527268356687};\\\", \\\"{x:177,y:539,t:1527268356723};\\\", \\\"{x:176,y:539,t:1527268356755};\\\", \\\"{x:173,y:539,t:1527268356770};\\\", \\\"{x:169,y:539,t:1527268356787};\\\", \\\"{x:168,y:539,t:1527268356802};\\\", \\\"{x:165,y:538,t:1527268356820};\\\", \\\"{x:164,y:538,t:1527268356837};\\\", \\\"{x:163,y:537,t:1527268356853};\\\", \\\"{x:162,y:537,t:1527268356870};\\\", \\\"{x:161,y:536,t:1527268356887};\\\", \\\"{x:162,y:536,t:1527268358139};\\\", \\\"{x:163,y:536,t:1527268358155};\\\", \\\"{x:171,y:539,t:1527268358173};\\\", \\\"{x:180,y:540,t:1527268358188};\\\", \\\"{x:190,y:541,t:1527268358205};\\\", \\\"{x:199,y:541,t:1527268358223};\\\", \\\"{x:208,y:541,t:1527268358237};\\\", \\\"{x:219,y:541,t:1527268358255};\\\", \\\"{x:231,y:541,t:1527268358271};\\\", \\\"{x:245,y:541,t:1527268358288};\\\", \\\"{x:256,y:541,t:1527268358305};\\\", \\\"{x:266,y:541,t:1527268358321};\\\", \\\"{x:280,y:544,t:1527268358341};\\\", \\\"{x:288,y:546,t:1527268358354};\\\", \\\"{x:297,y:550,t:1527268358372};\\\", \\\"{x:312,y:554,t:1527268358387};\\\", \\\"{x:323,y:556,t:1527268358406};\\\", \\\"{x:333,y:559,t:1527268358422};\\\", \\\"{x:346,y:560,t:1527268358438};\\\", \\\"{x:356,y:561,t:1527268358455};\\\", \\\"{x:366,y:561,t:1527268358472};\\\", \\\"{x:378,y:561,t:1527268358487};\\\", \\\"{x:388,y:561,t:1527268358505};\\\", \\\"{x:403,y:561,t:1527268358522};\\\", \\\"{x:421,y:561,t:1527268358538};\\\", \\\"{x:461,y:561,t:1527268358554};\\\", \\\"{x:498,y:567,t:1527268358573};\\\", \\\"{x:537,y:572,t:1527268358589};\\\", \\\"{x:585,y:580,t:1527268358605};\\\", \\\"{x:619,y:585,t:1527268358621};\\\", \\\"{x:650,y:590,t:1527268358639};\\\", \\\"{x:673,y:593,t:1527268358654};\\\", \\\"{x:687,y:593,t:1527268358671};\\\", \\\"{x:692,y:593,t:1527268358689};\\\", \\\"{x:696,y:593,t:1527268358705};\\\", \\\"{x:702,y:593,t:1527268358721};\\\", \\\"{x:716,y:592,t:1527268358738};\\\", \\\"{x:729,y:591,t:1527268358755};\\\", \\\"{x:746,y:588,t:1527268358771};\\\", \\\"{x:768,y:585,t:1527268358788};\\\", \\\"{x:797,y:584,t:1527268358805};\\\", \\\"{x:833,y:584,t:1527268358822};\\\", \\\"{x:881,y:584,t:1527268358839};\\\", \\\"{x:928,y:584,t:1527268358855};\\\", \\\"{x:1001,y:596,t:1527268358873};\\\", \\\"{x:1068,y:604,t:1527268358888};\\\", \\\"{x:1138,y:617,t:1527268358905};\\\", \\\"{x:1210,y:626,t:1527268358921};\\\", \\\"{x:1272,y:634,t:1527268358939};\\\", \\\"{x:1291,y:634,t:1527268358955};\\\", \\\"{x:1303,y:634,t:1527268358972};\\\", \\\"{x:1308,y:634,t:1527268358989};\\\", \\\"{x:1311,y:634,t:1527268359006};\\\", \\\"{x:1316,y:634,t:1527268359022};\\\", \\\"{x:1323,y:636,t:1527268359039};\\\", \\\"{x:1338,y:638,t:1527268359056};\\\", \\\"{x:1363,y:643,t:1527268359072};\\\", \\\"{x:1390,y:651,t:1527268359089};\\\", \\\"{x:1444,y:661,t:1527268359107};\\\", \\\"{x:1468,y:664,t:1527268359122};\\\", \\\"{x:1525,y:671,t:1527268359139};\\\", \\\"{x:1551,y:673,t:1527268359156};\\\", \\\"{x:1569,y:673,t:1527268359172};\\\", \\\"{x:1573,y:674,t:1527268359189};\\\", \\\"{x:1574,y:674,t:1527268359291};\\\", \\\"{x:1574,y:679,t:1527268359307};\\\", \\\"{x:1574,y:685,t:1527268359323};\\\", \\\"{x:1566,y:698,t:1527268359339};\\\", \\\"{x:1560,y:705,t:1527268359356};\\\", \\\"{x:1554,y:710,t:1527268359373};\\\", \\\"{x:1548,y:712,t:1527268359390};\\\", \\\"{x:1546,y:712,t:1527268359406};\\\", \\\"{x:1544,y:712,t:1527268359423};\\\", \\\"{x:1541,y:712,t:1527268359439};\\\", \\\"{x:1540,y:712,t:1527268359457};\\\", \\\"{x:1538,y:712,t:1527268359472};\\\", \\\"{x:1537,y:712,t:1527268359490};\\\", \\\"{x:1535,y:711,t:1527268359507};\\\", \\\"{x:1532,y:710,t:1527268359523};\\\", \\\"{x:1526,y:709,t:1527268359539};\\\", \\\"{x:1512,y:709,t:1527268359556};\\\", \\\"{x:1490,y:709,t:1527268359574};\\\", \\\"{x:1464,y:709,t:1527268359589};\\\", \\\"{x:1440,y:709,t:1527268359607};\\\", \\\"{x:1413,y:709,t:1527268359624};\\\", \\\"{x:1395,y:706,t:1527268359639};\\\", \\\"{x:1386,y:702,t:1527268359657};\\\", \\\"{x:1382,y:700,t:1527268359674};\\\", \\\"{x:1380,y:699,t:1527268359691};\\\", \\\"{x:1380,y:698,t:1527268359707};\\\", \\\"{x:1381,y:698,t:1527268360275};\\\", \\\"{x:1383,y:698,t:1527268360290};\\\", \\\"{x:1393,y:698,t:1527268360307};\\\", \\\"{x:1398,y:698,t:1527268360324};\\\", \\\"{x:1402,y:698,t:1527268360341};\\\", \\\"{x:1406,y:698,t:1527268360357};\\\", \\\"{x:1412,y:698,t:1527268360373};\\\", \\\"{x:1416,y:698,t:1527268360391};\\\", \\\"{x:1420,y:696,t:1527268360406};\\\", \\\"{x:1422,y:695,t:1527268360423};\\\", \\\"{x:1426,y:695,t:1527268360440};\\\", \\\"{x:1432,y:695,t:1527268360456};\\\", \\\"{x:1440,y:693,t:1527268360473};\\\", \\\"{x:1458,y:693,t:1527268360490};\\\", \\\"{x:1472,y:693,t:1527268360506};\\\", \\\"{x:1490,y:697,t:1527268360523};\\\", \\\"{x:1507,y:703,t:1527268360540};\\\", \\\"{x:1521,y:705,t:1527268360557};\\\", \\\"{x:1530,y:707,t:1527268360572};\\\", \\\"{x:1534,y:707,t:1527268360590};\\\", \\\"{x:1536,y:707,t:1527268360606};\\\", \\\"{x:1537,y:707,t:1527268360634};\\\", \\\"{x:1538,y:707,t:1527268360650};\\\", \\\"{x:1540,y:708,t:1527268360739};\\\", \\\"{x:1540,y:709,t:1527268360758};\\\", \\\"{x:1541,y:712,t:1527268360773};\\\", \\\"{x:1542,y:717,t:1527268360790};\\\", \\\"{x:1544,y:723,t:1527268360807};\\\", \\\"{x:1544,y:729,t:1527268360823};\\\", \\\"{x:1545,y:733,t:1527268360841};\\\", \\\"{x:1545,y:737,t:1527268360857};\\\", \\\"{x:1545,y:740,t:1527268360874};\\\", \\\"{x:1545,y:743,t:1527268360890};\\\", \\\"{x:1545,y:744,t:1527268360907};\\\", \\\"{x:1545,y:745,t:1527268360923};\\\", \\\"{x:1545,y:746,t:1527268360947};\\\", \\\"{x:1545,y:747,t:1527268360963};\\\", \\\"{x:1545,y:749,t:1527268360973};\\\", \\\"{x:1545,y:754,t:1527268360990};\\\", \\\"{x:1545,y:756,t:1527268361008};\\\", \\\"{x:1545,y:758,t:1527268361024};\\\", \\\"{x:1545,y:760,t:1527268361041};\\\", \\\"{x:1545,y:761,t:1527268361107};\\\", \\\"{x:1543,y:761,t:1527268361131};\\\", \\\"{x:1542,y:760,t:1527268361140};\\\", \\\"{x:1540,y:758,t:1527268361157};\\\", \\\"{x:1540,y:753,t:1527268361174};\\\", \\\"{x:1540,y:745,t:1527268361190};\\\", \\\"{x:1540,y:732,t:1527268361207};\\\", \\\"{x:1541,y:721,t:1527268361225};\\\", \\\"{x:1542,y:708,t:1527268361241};\\\", \\\"{x:1543,y:700,t:1527268361258};\\\", \\\"{x:1544,y:689,t:1527268361275};\\\", \\\"{x:1544,y:687,t:1527268361291};\\\", \\\"{x:1545,y:680,t:1527268361307};\\\", \\\"{x:1545,y:677,t:1527268361324};\\\", \\\"{x:1545,y:675,t:1527268361341};\\\", \\\"{x:1546,y:671,t:1527268361358};\\\", \\\"{x:1546,y:670,t:1527268361374};\\\", \\\"{x:1546,y:669,t:1527268361564};\\\", \\\"{x:1548,y:669,t:1527268361575};\\\", \\\"{x:1551,y:676,t:1527268361591};\\\", \\\"{x:1556,y:686,t:1527268361608};\\\", \\\"{x:1558,y:693,t:1527268361624};\\\", \\\"{x:1559,y:698,t:1527268361642};\\\", \\\"{x:1561,y:704,t:1527268361658};\\\", \\\"{x:1562,y:711,t:1527268361675};\\\", \\\"{x:1563,y:717,t:1527268361691};\\\", \\\"{x:1564,y:722,t:1527268361708};\\\", \\\"{x:1564,y:725,t:1527268361725};\\\", \\\"{x:1564,y:728,t:1527268361742};\\\", \\\"{x:1564,y:729,t:1527268361758};\\\", \\\"{x:1563,y:729,t:1527268361884};\\\", \\\"{x:1562,y:728,t:1527268361891};\\\", \\\"{x:1557,y:724,t:1527268361908};\\\", \\\"{x:1553,y:717,t:1527268361925};\\\", \\\"{x:1548,y:709,t:1527268361942};\\\", \\\"{x:1545,y:701,t:1527268361957};\\\", \\\"{x:1543,y:688,t:1527268361975};\\\", \\\"{x:1541,y:678,t:1527268361992};\\\", \\\"{x:1541,y:670,t:1527268362007};\\\", \\\"{x:1541,y:664,t:1527268362025};\\\", \\\"{x:1541,y:659,t:1527268362041};\\\", \\\"{x:1541,y:654,t:1527268362057};\\\", \\\"{x:1541,y:648,t:1527268362075};\\\", \\\"{x:1541,y:647,t:1527268362091};\\\", \\\"{x:1540,y:647,t:1527268362123};\\\", \\\"{x:1539,y:649,t:1527268362211};\\\", \\\"{x:1538,y:654,t:1527268362224};\\\", \\\"{x:1530,y:670,t:1527268362242};\\\", \\\"{x:1514,y:698,t:1527268362259};\\\", \\\"{x:1502,y:716,t:1527268362275};\\\", \\\"{x:1491,y:731,t:1527268362291};\\\", \\\"{x:1483,y:742,t:1527268362308};\\\", \\\"{x:1479,y:749,t:1527268362323};\\\", \\\"{x:1477,y:751,t:1527268362340};\\\", \\\"{x:1474,y:754,t:1527268362358};\\\", \\\"{x:1472,y:757,t:1527268362374};\\\", \\\"{x:1468,y:761,t:1527268362391};\\\", \\\"{x:1463,y:764,t:1527268362408};\\\", \\\"{x:1459,y:765,t:1527268362424};\\\", \\\"{x:1451,y:767,t:1527268362441};\\\", \\\"{x:1437,y:768,t:1527268362458};\\\", \\\"{x:1428,y:768,t:1527268362475};\\\", \\\"{x:1420,y:768,t:1527268362491};\\\", \\\"{x:1407,y:766,t:1527268362508};\\\", \\\"{x:1397,y:765,t:1527268362524};\\\", \\\"{x:1393,y:764,t:1527268362541};\\\", \\\"{x:1390,y:764,t:1527268362558};\\\", \\\"{x:1389,y:764,t:1527268362574};\\\", \\\"{x:1388,y:764,t:1527268362592};\\\", \\\"{x:1387,y:764,t:1527268362608};\\\", \\\"{x:1385,y:764,t:1527268362624};\\\", \\\"{x:1384,y:764,t:1527268362642};\\\", \\\"{x:1380,y:767,t:1527268362658};\\\", \\\"{x:1380,y:773,t:1527268362675};\\\", \\\"{x:1376,y:781,t:1527268362691};\\\", \\\"{x:1375,y:787,t:1527268362708};\\\", \\\"{x:1374,y:791,t:1527268362725};\\\", \\\"{x:1372,y:797,t:1527268362741};\\\", \\\"{x:1371,y:800,t:1527268362758};\\\", \\\"{x:1371,y:801,t:1527268362775};\\\", \\\"{x:1371,y:804,t:1527268362791};\\\", \\\"{x:1371,y:805,t:1527268362809};\\\", \\\"{x:1371,y:807,t:1527268362826};\\\", \\\"{x:1371,y:809,t:1527268362842};\\\", \\\"{x:1371,y:811,t:1527268362859};\\\", \\\"{x:1369,y:814,t:1527268362875};\\\", \\\"{x:1368,y:816,t:1527268362899};\\\", \\\"{x:1368,y:817,t:1527268362915};\\\", \\\"{x:1367,y:818,t:1527268362925};\\\", \\\"{x:1366,y:819,t:1527268362942};\\\", \\\"{x:1366,y:820,t:1527268362958};\\\", \\\"{x:1365,y:820,t:1527268362979};\\\", \\\"{x:1362,y:820,t:1527268363036};\\\", \\\"{x:1361,y:817,t:1527268363043};\\\", \\\"{x:1352,y:808,t:1527268363059};\\\", \\\"{x:1344,y:797,t:1527268363075};\\\", \\\"{x:1336,y:784,t:1527268363092};\\\", \\\"{x:1329,y:772,t:1527268363108};\\\", \\\"{x:1323,y:759,t:1527268363126};\\\", \\\"{x:1317,y:744,t:1527268363142};\\\", \\\"{x:1312,y:731,t:1527268363159};\\\", \\\"{x:1308,y:723,t:1527268363175};\\\", \\\"{x:1306,y:718,t:1527268363192};\\\", \\\"{x:1304,y:716,t:1527268363208};\\\", \\\"{x:1303,y:714,t:1527268363226};\\\", \\\"{x:1302,y:714,t:1527268363242};\\\", \\\"{x:1299,y:713,t:1527268363259};\\\", \\\"{x:1292,y:710,t:1527268363275};\\\", \\\"{x:1287,y:710,t:1527268363293};\\\", \\\"{x:1275,y:709,t:1527268363309};\\\", \\\"{x:1253,y:708,t:1527268363326};\\\", \\\"{x:1200,y:708,t:1527268363343};\\\", \\\"{x:1110,y:704,t:1527268363358};\\\", \\\"{x:1013,y:704,t:1527268363375};\\\", \\\"{x:919,y:702,t:1527268363393};\\\", \\\"{x:821,y:700,t:1527268363408};\\\", \\\"{x:742,y:695,t:1527268363426};\\\", \\\"{x:690,y:692,t:1527268363443};\\\", \\\"{x:674,y:691,t:1527268363459};\\\", \\\"{x:669,y:691,t:1527268363475};\\\", \\\"{x:665,y:691,t:1527268363492};\\\", \\\"{x:660,y:691,t:1527268363507};\\\", \\\"{x:659,y:691,t:1527268363570};\\\", \\\"{x:658,y:691,t:1527268363578};\\\", \\\"{x:657,y:691,t:1527268363592};\\\", \\\"{x:655,y:691,t:1527268363608};\\\", \\\"{x:652,y:691,t:1527268363625};\\\", \\\"{x:618,y:691,t:1527268363642};\\\", \\\"{x:586,y:696,t:1527268363658};\\\", \\\"{x:561,y:701,t:1527268363675};\\\", \\\"{x:544,y:703,t:1527268363692};\\\", \\\"{x:535,y:704,t:1527268363709};\\\", \\\"{x:534,y:705,t:1527268363883};\\\", \\\"{x:535,y:707,t:1527268363899};\\\", \\\"{x:535,y:709,t:1527268363909};\\\", \\\"{x:536,y:718,t:1527268363926};\\\", \\\"{x:537,y:721,t:1527268363944};\\\", \\\"{x:537,y:724,t:1527268363959};\\\", \\\"{x:537,y:726,t:1527268363975};\\\", \\\"{x:537,y:727,t:1527268363993};\\\", \\\"{x:537,y:728,t:1527268364009};\\\" ] }, { \\\"rt\\\": 45541, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 446854, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -C -B -B -F -G -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:728,t:1527268365545};\\\", \\\"{x:538,y:727,t:1527268365593};\\\", \\\"{x:542,y:725,t:1527268365611};\\\", \\\"{x:542,y:723,t:1527268365635};\\\", \\\"{x:543,y:722,t:1527268365658};\\\", \\\"{x:544,y:721,t:1527268365706};\\\", \\\"{x:545,y:720,t:1527268365754};\\\", \\\"{x:546,y:719,t:1527268365763};\\\", \\\"{x:547,y:719,t:1527268365778};\\\", \\\"{x:550,y:717,t:1527268365794};\\\", \\\"{x:551,y:716,t:1527268365811};\\\", \\\"{x:552,y:716,t:1527268365827};\\\", \\\"{x:556,y:716,t:1527268365844};\\\", \\\"{x:557,y:716,t:1527268365861};\\\", \\\"{x:562,y:715,t:1527268365877};\\\", \\\"{x:569,y:715,t:1527268365894};\\\", \\\"{x:579,y:712,t:1527268365911};\\\", \\\"{x:596,y:710,t:1527268365927};\\\", \\\"{x:616,y:707,t:1527268365944};\\\", \\\"{x:637,y:706,t:1527268365961};\\\", \\\"{x:657,y:702,t:1527268365978};\\\", \\\"{x:686,y:702,t:1527268365994};\\\", \\\"{x:699,y:702,t:1527268366010};\\\", \\\"{x:709,y:702,t:1527268366026};\\\", \\\"{x:720,y:701,t:1527268366044};\\\", \\\"{x:793,y:700,t:1527268366137};\\\", \\\"{x:799,y:700,t:1527268366144};\\\", \\\"{x:806,y:700,t:1527268366161};\\\", \\\"{x:820,y:702,t:1527268366178};\\\", \\\"{x:836,y:704,t:1527268366194};\\\", \\\"{x:854,y:708,t:1527268366210};\\\", \\\"{x:871,y:710,t:1527268366228};\\\", \\\"{x:888,y:715,t:1527268366243};\\\", \\\"{x:909,y:721,t:1527268366261};\\\", \\\"{x:926,y:726,t:1527268366278};\\\", \\\"{x:943,y:731,t:1527268366294};\\\", \\\"{x:955,y:735,t:1527268366311};\\\", \\\"{x:960,y:736,t:1527268366328};\\\", \\\"{x:964,y:738,t:1527268366344};\\\", \\\"{x:964,y:739,t:1527268366362};\\\", \\\"{x:966,y:740,t:1527268366386};\\\", \\\"{x:967,y:741,t:1527268366411};\\\", \\\"{x:967,y:742,t:1527268366442};\\\", \\\"{x:967,y:743,t:1527268366450};\\\", \\\"{x:967,y:745,t:1527268366461};\\\", \\\"{x:967,y:747,t:1527268366479};\\\", \\\"{x:967,y:751,t:1527268366495};\\\", \\\"{x:966,y:755,t:1527268366512};\\\", \\\"{x:960,y:765,t:1527268366529};\\\", \\\"{x:950,y:779,t:1527268366545};\\\", \\\"{x:935,y:794,t:1527268366562};\\\", \\\"{x:915,y:807,t:1527268366578};\\\", \\\"{x:906,y:811,t:1527268366594};\\\", \\\"{x:892,y:811,t:1527268366611};\\\", \\\"{x:888,y:812,t:1527268366629};\\\", \\\"{x:883,y:812,t:1527268366644};\\\", \\\"{x:871,y:812,t:1527268366661};\\\", \\\"{x:857,y:810,t:1527268366679};\\\", \\\"{x:834,y:802,t:1527268366695};\\\", \\\"{x:806,y:790,t:1527268366712};\\\", \\\"{x:765,y:772,t:1527268366728};\\\", \\\"{x:710,y:751,t:1527268366744};\\\", \\\"{x:654,y:734,t:1527268366761};\\\", \\\"{x:587,y:713,t:1527268366778};\\\", \\\"{x:559,y:706,t:1527268366795};\\\", \\\"{x:535,y:696,t:1527268366812};\\\", \\\"{x:520,y:688,t:1527268366828};\\\", \\\"{x:513,y:681,t:1527268366845};\\\", \\\"{x:506,y:673,t:1527268366862};\\\", \\\"{x:501,y:661,t:1527268366879};\\\", \\\"{x:494,y:646,t:1527268366896};\\\", \\\"{x:482,y:628,t:1527268366912};\\\", \\\"{x:471,y:613,t:1527268366928};\\\", \\\"{x:461,y:594,t:1527268366946};\\\", \\\"{x:448,y:566,t:1527268366963};\\\", \\\"{x:442,y:552,t:1527268366979};\\\", \\\"{x:435,y:540,t:1527268366995};\\\", \\\"{x:427,y:529,t:1527268367012};\\\", \\\"{x:421,y:521,t:1527268367028};\\\", \\\"{x:418,y:515,t:1527268367045};\\\", \\\"{x:417,y:512,t:1527268367062};\\\", \\\"{x:416,y:506,t:1527268367077};\\\", \\\"{x:416,y:503,t:1527268367095};\\\", \\\"{x:413,y:498,t:1527268367112};\\\", \\\"{x:412,y:494,t:1527268367129};\\\", \\\"{x:410,y:491,t:1527268367145};\\\", \\\"{x:410,y:483,t:1527268367162};\\\", \\\"{x:410,y:479,t:1527268367178};\\\", \\\"{x:410,y:475,t:1527268367196};\\\", \\\"{x:410,y:472,t:1527268367212};\\\", \\\"{x:410,y:469,t:1527268367228};\\\", \\\"{x:410,y:467,t:1527268367246};\\\", \\\"{x:410,y:465,t:1527268367263};\\\", \\\"{x:410,y:462,t:1527268367278};\\\", \\\"{x:411,y:459,t:1527268367295};\\\", \\\"{x:411,y:458,t:1527268367547};\\\", \\\"{x:415,y:460,t:1527268367563};\\\", \\\"{x:426,y:469,t:1527268367579};\\\", \\\"{x:434,y:474,t:1527268367596};\\\", \\\"{x:441,y:479,t:1527268367612};\\\", \\\"{x:448,y:482,t:1527268367630};\\\", \\\"{x:453,y:484,t:1527268367645};\\\", \\\"{x:454,y:484,t:1527268367663};\\\", \\\"{x:455,y:485,t:1527268367680};\\\", \\\"{x:456,y:485,t:1527268367722};\\\", \\\"{x:458,y:485,t:1527268367811};\\\", \\\"{x:459,y:485,t:1527268367827};\\\", \\\"{x:461,y:485,t:1527268367843};\\\", \\\"{x:462,y:485,t:1527268367859};\\\", \\\"{x:465,y:485,t:1527268367867};\\\", \\\"{x:466,y:485,t:1527268367882};\\\", \\\"{x:468,y:485,t:1527268367896};\\\", \\\"{x:470,y:485,t:1527268367915};\\\", \\\"{x:471,y:485,t:1527268367939};\\\", \\\"{x:472,y:484,t:1527268367971};\\\", \\\"{x:473,y:484,t:1527268368019};\\\", \\\"{x:475,y:483,t:1527268368035};\\\", \\\"{x:476,y:482,t:1527268368059};\\\", \\\"{x:477,y:482,t:1527268368067};\\\", \\\"{x:478,y:482,t:1527268368079};\\\", \\\"{x:482,y:481,t:1527268368096};\\\", \\\"{x:485,y:481,t:1527268368112};\\\", \\\"{x:488,y:479,t:1527268368129};\\\", \\\"{x:491,y:479,t:1527268368147};\\\", \\\"{x:493,y:479,t:1527268368163};\\\", \\\"{x:494,y:479,t:1527268368180};\\\", \\\"{x:495,y:479,t:1527268368196};\\\", \\\"{x:496,y:479,t:1527268368214};\\\", \\\"{x:498,y:478,t:1527268368230};\\\", \\\"{x:499,y:477,t:1527268368274};\\\", \\\"{x:499,y:475,t:1527268368355};\\\", \\\"{x:500,y:475,t:1527268368363};\\\", \\\"{x:501,y:474,t:1527268368380};\\\", \\\"{x:504,y:473,t:1527268368397};\\\", \\\"{x:505,y:472,t:1527268368414};\\\", \\\"{x:506,y:472,t:1527268368429};\\\", \\\"{x:507,y:472,t:1527268368446};\\\", \\\"{x:508,y:471,t:1527268368464};\\\", \\\"{x:508,y:470,t:1527268368483};\\\", \\\"{x:509,y:470,t:1527268368497};\\\", \\\"{x:511,y:469,t:1527268368514};\\\", \\\"{x:513,y:467,t:1527268368530};\\\", \\\"{x:514,y:466,t:1527268368547};\\\", \\\"{x:517,y:463,t:1527268368564};\\\", \\\"{x:519,y:462,t:1527268368580};\\\", \\\"{x:519,y:461,t:1527268368596};\\\", \\\"{x:521,y:460,t:1527268368747};\\\", \\\"{x:522,y:459,t:1527268368764};\\\", \\\"{x:524,y:458,t:1527268368781};\\\", \\\"{x:525,y:458,t:1527268368797};\\\", \\\"{x:526,y:457,t:1527268368813};\\\", \\\"{x:527,y:457,t:1527268368858};\\\", \\\"{x:528,y:457,t:1527268368867};\\\", \\\"{x:529,y:457,t:1527268368880};\\\", \\\"{x:532,y:457,t:1527268368896};\\\", \\\"{x:541,y:458,t:1527268368914};\\\", \\\"{x:558,y:461,t:1527268368930};\\\", \\\"{x:569,y:461,t:1527268368947};\\\", \\\"{x:580,y:461,t:1527268368963};\\\", \\\"{x:595,y:461,t:1527268368980};\\\", \\\"{x:608,y:461,t:1527268368996};\\\", \\\"{x:617,y:461,t:1527268369014};\\\", \\\"{x:626,y:461,t:1527268369031};\\\", \\\"{x:639,y:459,t:1527268369046};\\\", \\\"{x:652,y:459,t:1527268369063};\\\", \\\"{x:668,y:459,t:1527268369081};\\\", \\\"{x:688,y:462,t:1527268369097};\\\", \\\"{x:728,y:473,t:1527268369114};\\\", \\\"{x:807,y:492,t:1527268369132};\\\", \\\"{x:880,y:501,t:1527268369147};\\\", \\\"{x:1002,y:520,t:1527268369164};\\\", \\\"{x:1189,y:545,t:1527268369180};\\\", \\\"{x:1428,y:561,t:1527268369197};\\\", \\\"{x:1676,y:582,t:1527268369213};\\\", \\\"{x:1896,y:606,t:1527268369230};\\\", \\\"{x:1919,y:617,t:1527268369247};\\\", \\\"{x:1919,y:623,t:1527268369263};\\\", \\\"{x:1919,y:630,t:1527268369280};\\\", \\\"{x:1919,y:631,t:1527268369297};\\\", \\\"{x:1919,y:632,t:1527268369331};\\\", \\\"{x:1917,y:635,t:1527268369348};\\\", \\\"{x:1911,y:637,t:1527268369363};\\\", \\\"{x:1906,y:640,t:1527268369381};\\\", \\\"{x:1900,y:642,t:1527268369398};\\\", \\\"{x:1890,y:643,t:1527268369413};\\\", \\\"{x:1871,y:643,t:1527268369431};\\\", \\\"{x:1846,y:641,t:1527268369447};\\\", \\\"{x:1805,y:634,t:1527268369463};\\\", \\\"{x:1763,y:629,t:1527268369480};\\\", \\\"{x:1712,y:625,t:1527268369498};\\\", \\\"{x:1666,y:624,t:1527268369514};\\\", \\\"{x:1610,y:624,t:1527268369530};\\\", \\\"{x:1577,y:624,t:1527268369548};\\\", \\\"{x:1555,y:624,t:1527268369565};\\\", \\\"{x:1537,y:630,t:1527268369580};\\\", \\\"{x:1528,y:633,t:1527268369598};\\\", \\\"{x:1525,y:633,t:1527268369615};\\\", \\\"{x:1524,y:633,t:1527268369630};\\\", \\\"{x:1522,y:633,t:1527268369699};\\\", \\\"{x:1516,y:633,t:1527268369714};\\\", \\\"{x:1508,y:633,t:1527268369730};\\\", \\\"{x:1493,y:632,t:1527268369748};\\\", \\\"{x:1477,y:632,t:1527268369765};\\\", \\\"{x:1458,y:632,t:1527268369780};\\\", \\\"{x:1443,y:632,t:1527268369800};\\\", \\\"{x:1429,y:632,t:1527268369814};\\\", \\\"{x:1419,y:632,t:1527268369830};\\\", \\\"{x:1415,y:632,t:1527268369847};\\\", \\\"{x:1412,y:632,t:1527268369864};\\\", \\\"{x:1411,y:632,t:1527268370051};\\\", \\\"{x:1408,y:631,t:1527268370065};\\\", \\\"{x:1398,y:630,t:1527268370083};\\\", \\\"{x:1386,y:626,t:1527268370099};\\\", \\\"{x:1380,y:623,t:1527268370114};\\\", \\\"{x:1378,y:623,t:1527268370132};\\\", \\\"{x:1374,y:622,t:1527268370147};\\\", \\\"{x:1372,y:621,t:1527268370164};\\\", \\\"{x:1368,y:621,t:1527268370181};\\\", \\\"{x:1364,y:621,t:1527268370197};\\\", \\\"{x:1362,y:621,t:1527268370215};\\\", \\\"{x:1361,y:621,t:1527268370231};\\\", \\\"{x:1360,y:622,t:1527268370247};\\\", \\\"{x:1360,y:626,t:1527268370265};\\\", \\\"{x:1360,y:627,t:1527268370281};\\\", \\\"{x:1360,y:629,t:1527268370297};\\\", \\\"{x:1366,y:631,t:1527268370314};\\\", \\\"{x:1372,y:633,t:1527268370331};\\\", \\\"{x:1374,y:633,t:1527268370347};\\\", \\\"{x:1375,y:633,t:1527268370365};\\\", \\\"{x:1376,y:633,t:1527268370394};\\\", \\\"{x:1377,y:633,t:1527268370418};\\\", \\\"{x:1378,y:634,t:1527268370434};\\\", \\\"{x:1379,y:635,t:1527268370449};\\\", \\\"{x:1387,y:642,t:1527268370464};\\\", \\\"{x:1396,y:646,t:1527268370482};\\\", \\\"{x:1404,y:652,t:1527268370499};\\\", \\\"{x:1405,y:654,t:1527268370515};\\\", \\\"{x:1405,y:658,t:1527268370628};\\\", \\\"{x:1405,y:664,t:1527268370635};\\\", \\\"{x:1405,y:673,t:1527268370649};\\\", \\\"{x:1404,y:690,t:1527268370665};\\\", \\\"{x:1399,y:707,t:1527268370682};\\\", \\\"{x:1389,y:741,t:1527268370698};\\\", \\\"{x:1385,y:760,t:1527268370715};\\\", \\\"{x:1381,y:772,t:1527268370731};\\\", \\\"{x:1379,y:777,t:1527268370750};\\\", \\\"{x:1378,y:778,t:1527268370765};\\\", \\\"{x:1378,y:779,t:1527268370787};\\\", \\\"{x:1378,y:781,t:1527268370883};\\\", \\\"{x:1371,y:786,t:1527268370899};\\\", \\\"{x:1365,y:789,t:1527268370916};\\\", \\\"{x:1361,y:790,t:1527268370931};\\\", \\\"{x:1358,y:790,t:1527268370949};\\\", \\\"{x:1355,y:790,t:1527268370966};\\\", \\\"{x:1353,y:790,t:1527268370982};\\\", \\\"{x:1349,y:789,t:1527268370998};\\\", \\\"{x:1345,y:786,t:1527268371016};\\\", \\\"{x:1342,y:782,t:1527268371031};\\\", \\\"{x:1340,y:780,t:1527268371048};\\\", \\\"{x:1339,y:778,t:1527268371066};\\\", \\\"{x:1339,y:777,t:1527268371081};\\\", \\\"{x:1339,y:776,t:1527268371220};\\\", \\\"{x:1339,y:775,t:1527268371232};\\\", \\\"{x:1339,y:773,t:1527268371249};\\\", \\\"{x:1339,y:772,t:1527268371266};\\\", \\\"{x:1339,y:770,t:1527268371283};\\\", \\\"{x:1339,y:769,t:1527268371483};\\\", \\\"{x:1339,y:767,t:1527268371499};\\\", \\\"{x:1339,y:766,t:1527268371516};\\\", \\\"{x:1339,y:765,t:1527268371691};\\\", \\\"{x:1339,y:764,t:1527268371699};\\\", \\\"{x:1339,y:763,t:1527268371716};\\\", \\\"{x:1340,y:761,t:1527268371733};\\\", \\\"{x:1341,y:760,t:1527268371755};\\\", \\\"{x:1341,y:759,t:1527268371771};\\\", \\\"{x:1343,y:759,t:1527268371996};\\\", \\\"{x:1344,y:759,t:1527268373268};\\\", \\\"{x:1346,y:759,t:1527268373515};\\\", \\\"{x:1346,y:760,t:1527268374851};\\\", \\\"{x:1347,y:760,t:1527268374939};\\\", \\\"{x:1348,y:760,t:1527268375571};\\\", \\\"{x:1348,y:759,t:1527268375586};\\\", \\\"{x:1350,y:755,t:1527268375603};\\\", \\\"{x:1350,y:746,t:1527268375618};\\\", \\\"{x:1352,y:738,t:1527268375636};\\\", \\\"{x:1352,y:736,t:1527268375653};\\\", \\\"{x:1353,y:733,t:1527268375669};\\\", \\\"{x:1353,y:732,t:1527268375686};\\\", \\\"{x:1353,y:731,t:1527268375703};\\\", \\\"{x:1353,y:729,t:1527268375723};\\\", \\\"{x:1353,y:728,t:1527268375747};\\\", \\\"{x:1354,y:726,t:1527268375762};\\\", \\\"{x:1354,y:725,t:1527268375779};\\\", \\\"{x:1354,y:724,t:1527268375794};\\\", \\\"{x:1354,y:723,t:1527268375811};\\\", \\\"{x:1354,y:722,t:1527268375842};\\\", \\\"{x:1354,y:721,t:1527268375858};\\\", \\\"{x:1354,y:720,t:1527268375875};\\\", \\\"{x:1354,y:719,t:1527268375891};\\\", \\\"{x:1354,y:718,t:1527268375915};\\\", \\\"{x:1354,y:717,t:1527268375931};\\\", \\\"{x:1354,y:716,t:1527268375939};\\\", \\\"{x:1353,y:714,t:1527268375955};\\\", \\\"{x:1353,y:713,t:1527268375971};\\\", \\\"{x:1353,y:711,t:1527268375987};\\\", \\\"{x:1350,y:708,t:1527268376003};\\\", \\\"{x:1350,y:707,t:1527268376019};\\\", \\\"{x:1348,y:704,t:1527268376036};\\\", \\\"{x:1347,y:702,t:1527268376054};\\\", \\\"{x:1346,y:700,t:1527268376068};\\\", \\\"{x:1345,y:698,t:1527268376090};\\\", \\\"{x:1345,y:697,t:1527268376113};\\\", \\\"{x:1344,y:696,t:1527268376121};\\\", \\\"{x:1343,y:694,t:1527268376146};\\\", \\\"{x:1343,y:693,t:1527268376170};\\\", \\\"{x:1343,y:692,t:1527268376186};\\\", \\\"{x:1342,y:691,t:1527268376202};\\\", \\\"{x:1342,y:690,t:1527268376242};\\\", \\\"{x:1342,y:689,t:1527268376259};\\\", \\\"{x:1341,y:689,t:1527268376282};\\\", \\\"{x:1340,y:689,t:1527268377324};\\\", \\\"{x:1340,y:690,t:1527268377771};\\\", \\\"{x:1340,y:691,t:1527268378403};\\\", \\\"{x:1339,y:691,t:1527268378419};\\\", \\\"{x:1338,y:691,t:1527268378435};\\\", \\\"{x:1337,y:691,t:1527268378443};\\\", \\\"{x:1336,y:691,t:1527268378458};\\\", \\\"{x:1334,y:690,t:1527268378481};\\\", \\\"{x:1334,y:689,t:1527268378498};\\\", \\\"{x:1333,y:689,t:1527268378506};\\\", \\\"{x:1332,y:689,t:1527268378521};\\\", \\\"{x:1326,y:675,t:1527268378538};\\\", \\\"{x:1321,y:666,t:1527268378554};\\\", \\\"{x:1318,y:661,t:1527268378571};\\\", \\\"{x:1317,y:655,t:1527268378587};\\\", \\\"{x:1314,y:650,t:1527268378604};\\\", \\\"{x:1313,y:647,t:1527268378621};\\\", \\\"{x:1310,y:641,t:1527268378638};\\\", \\\"{x:1310,y:639,t:1527268378655};\\\", \\\"{x:1310,y:636,t:1527268378671};\\\", \\\"{x:1309,y:633,t:1527268378688};\\\", \\\"{x:1308,y:631,t:1527268378705};\\\", \\\"{x:1308,y:629,t:1527268378722};\\\", \\\"{x:1308,y:627,t:1527268378738};\\\", \\\"{x:1307,y:624,t:1527268378755};\\\", \\\"{x:1306,y:620,t:1527268378772};\\\", \\\"{x:1305,y:611,t:1527268378788};\\\", \\\"{x:1302,y:601,t:1527268378805};\\\", \\\"{x:1300,y:588,t:1527268378822};\\\", \\\"{x:1295,y:579,t:1527268378837};\\\", \\\"{x:1291,y:573,t:1527268378855};\\\", \\\"{x:1289,y:568,t:1527268378872};\\\", \\\"{x:1288,y:566,t:1527268378888};\\\", \\\"{x:1288,y:565,t:1527268378906};\\\", \\\"{x:1288,y:566,t:1527268380139};\\\", \\\"{x:1289,y:567,t:1527268382227};\\\", \\\"{x:1290,y:568,t:1527268382539};\\\", \\\"{x:1290,y:569,t:1527268382938};\\\", \\\"{x:1290,y:570,t:1527268383686};\\\", \\\"{x:1291,y:570,t:1527268389070};\\\", \\\"{x:1292,y:570,t:1527268389133};\\\", \\\"{x:1293,y:570,t:1527268389149};\\\", \\\"{x:1294,y:570,t:1527268389173};\\\", \\\"{x:1295,y:570,t:1527268389238};\\\", \\\"{x:1296,y:570,t:1527268389253};\\\", \\\"{x:1297,y:570,t:1527268389294};\\\", \\\"{x:1298,y:570,t:1527268389341};\\\", \\\"{x:1299,y:570,t:1527268389349};\\\", \\\"{x:1300,y:570,t:1527268389367};\\\", \\\"{x:1301,y:570,t:1527268389406};\\\", \\\"{x:1303,y:570,t:1527268389421};\\\", \\\"{x:1304,y:570,t:1527268389434};\\\", \\\"{x:1307,y:570,t:1527268389449};\\\", \\\"{x:1315,y:570,t:1527268389467};\\\", \\\"{x:1331,y:568,t:1527268389483};\\\", \\\"{x:1353,y:566,t:1527268389499};\\\", \\\"{x:1370,y:562,t:1527268389516};\\\", \\\"{x:1396,y:557,t:1527268389532};\\\", \\\"{x:1405,y:557,t:1527268389549};\\\", \\\"{x:1408,y:557,t:1527268389566};\\\", \\\"{x:1409,y:557,t:1527268389596};\\\", \\\"{x:1410,y:556,t:1527268389605};\\\", \\\"{x:1411,y:556,t:1527268389637};\\\", \\\"{x:1413,y:556,t:1527268389653};\\\", \\\"{x:1414,y:556,t:1527268389665};\\\", \\\"{x:1417,y:556,t:1527268389683};\\\", \\\"{x:1420,y:556,t:1527268389699};\\\", \\\"{x:1425,y:556,t:1527268389716};\\\", \\\"{x:1427,y:556,t:1527268389733};\\\", \\\"{x:1428,y:556,t:1527268389750};\\\", \\\"{x:1429,y:556,t:1527268389766};\\\", \\\"{x:1430,y:556,t:1527268389789};\\\", \\\"{x:1431,y:556,t:1527268390158};\\\", \\\"{x:1433,y:557,t:1527268390167};\\\", \\\"{x:1439,y:558,t:1527268390183};\\\", \\\"{x:1447,y:559,t:1527268390201};\\\", \\\"{x:1456,y:560,t:1527268390217};\\\", \\\"{x:1464,y:560,t:1527268390233};\\\", \\\"{x:1471,y:560,t:1527268390250};\\\", \\\"{x:1473,y:560,t:1527268390268};\\\", \\\"{x:1475,y:560,t:1527268390283};\\\", \\\"{x:1476,y:560,t:1527268390300};\\\", \\\"{x:1477,y:560,t:1527268390318};\\\", \\\"{x:1478,y:560,t:1527268390334};\\\", \\\"{x:1483,y:560,t:1527268390350};\\\", \\\"{x:1490,y:562,t:1527268390368};\\\", \\\"{x:1497,y:564,t:1527268390384};\\\", \\\"{x:1508,y:567,t:1527268390401};\\\", \\\"{x:1518,y:569,t:1527268390417};\\\", \\\"{x:1526,y:571,t:1527268390433};\\\", \\\"{x:1534,y:572,t:1527268390450};\\\", \\\"{x:1540,y:572,t:1527268390467};\\\", \\\"{x:1543,y:572,t:1527268390484};\\\", \\\"{x:1545,y:572,t:1527268390501};\\\", \\\"{x:1547,y:572,t:1527268390517};\\\", \\\"{x:1550,y:571,t:1527268390534};\\\", \\\"{x:1553,y:571,t:1527268390551};\\\", \\\"{x:1559,y:571,t:1527268390567};\\\", \\\"{x:1565,y:571,t:1527268390584};\\\", \\\"{x:1569,y:571,t:1527268390601};\\\", \\\"{x:1572,y:571,t:1527268390617};\\\", \\\"{x:1577,y:571,t:1527268390634};\\\", \\\"{x:1581,y:572,t:1527268390651};\\\", \\\"{x:1586,y:572,t:1527268390667};\\\", \\\"{x:1589,y:572,t:1527268390685};\\\", \\\"{x:1591,y:572,t:1527268390701};\\\", \\\"{x:1593,y:572,t:1527268390717};\\\", \\\"{x:1594,y:572,t:1527268390733};\\\", \\\"{x:1596,y:572,t:1527268390766};\\\", \\\"{x:1597,y:572,t:1527268390797};\\\", \\\"{x:1598,y:572,t:1527268390821};\\\", \\\"{x:1599,y:572,t:1527268390834};\\\", \\\"{x:1600,y:572,t:1527268390852};\\\", \\\"{x:1603,y:572,t:1527268390868};\\\", \\\"{x:1605,y:572,t:1527268390885};\\\", \\\"{x:1607,y:570,t:1527268390901};\\\", \\\"{x:1610,y:570,t:1527268390917};\\\", \\\"{x:1610,y:569,t:1527268390934};\\\", \\\"{x:1611,y:569,t:1527268390950};\\\", \\\"{x:1612,y:569,t:1527268391094};\\\", \\\"{x:1613,y:569,t:1527268391109};\\\", \\\"{x:1614,y:569,t:1527268391134};\\\", \\\"{x:1616,y:568,t:1527268391153};\\\", \\\"{x:1617,y:567,t:1527268391168};\\\", \\\"{x:1619,y:566,t:1527268391185};\\\", \\\"{x:1621,y:566,t:1527268391213};\\\", \\\"{x:1622,y:565,t:1527268391358};\\\", \\\"{x:1624,y:564,t:1527268391413};\\\", \\\"{x:1626,y:563,t:1527268391436};\\\", \\\"{x:1627,y:563,t:1527268391452};\\\", \\\"{x:1628,y:562,t:1527268391468};\\\", \\\"{x:1629,y:562,t:1527268391501};\\\", \\\"{x:1630,y:562,t:1527268391518};\\\", \\\"{x:1632,y:562,t:1527268391534};\\\", \\\"{x:1635,y:562,t:1527268391552};\\\", \\\"{x:1640,y:562,t:1527268391568};\\\", \\\"{x:1644,y:562,t:1527268391584};\\\", \\\"{x:1647,y:561,t:1527268391601};\\\", \\\"{x:1650,y:559,t:1527268391618};\\\", \\\"{x:1651,y:559,t:1527268391634};\\\", \\\"{x:1652,y:559,t:1527268391692};\\\", \\\"{x:1653,y:559,t:1527268391974};\\\", \\\"{x:1653,y:560,t:1527268391989};\\\", \\\"{x:1652,y:560,t:1527268392002};\\\", \\\"{x:1648,y:562,t:1527268392018};\\\", \\\"{x:1641,y:563,t:1527268392036};\\\", \\\"{x:1629,y:565,t:1527268392052};\\\", \\\"{x:1616,y:567,t:1527268392069};\\\", \\\"{x:1582,y:572,t:1527268392085};\\\", \\\"{x:1555,y:574,t:1527268392101};\\\", \\\"{x:1526,y:577,t:1527268392119};\\\", \\\"{x:1500,y:581,t:1527268392135};\\\", \\\"{x:1479,y:584,t:1527268392152};\\\", \\\"{x:1463,y:586,t:1527268392168};\\\", \\\"{x:1456,y:588,t:1527268392185};\\\", \\\"{x:1450,y:589,t:1527268392201};\\\", \\\"{x:1449,y:589,t:1527268392218};\\\", \\\"{x:1449,y:588,t:1527268392486};\\\", \\\"{x:1453,y:585,t:1527268392502};\\\", \\\"{x:1457,y:582,t:1527268392518};\\\", \\\"{x:1460,y:579,t:1527268392536};\\\", \\\"{x:1461,y:577,t:1527268392555};\\\", \\\"{x:1462,y:577,t:1527268392598};\\\", \\\"{x:1463,y:576,t:1527268392709};\\\", \\\"{x:1463,y:575,t:1527268392733};\\\", \\\"{x:1464,y:575,t:1527268392741};\\\", \\\"{x:1465,y:574,t:1527268392752};\\\", \\\"{x:1466,y:573,t:1527268392768};\\\", \\\"{x:1467,y:572,t:1527268392786};\\\", \\\"{x:1468,y:572,t:1527268392990};\\\", \\\"{x:1469,y:572,t:1527268393014};\\\", \\\"{x:1471,y:571,t:1527268393046};\\\", \\\"{x:1472,y:571,t:1527268393110};\\\", \\\"{x:1474,y:571,t:1527268393125};\\\", \\\"{x:1478,y:571,t:1527268393136};\\\", \\\"{x:1494,y:571,t:1527268393153};\\\", \\\"{x:1511,y:571,t:1527268393170};\\\", \\\"{x:1526,y:571,t:1527268393186};\\\", \\\"{x:1538,y:571,t:1527268393203};\\\", \\\"{x:1555,y:571,t:1527268393219};\\\", \\\"{x:1571,y:568,t:1527268393236};\\\", \\\"{x:1590,y:565,t:1527268393252};\\\", \\\"{x:1614,y:560,t:1527268393269};\\\", \\\"{x:1626,y:559,t:1527268393286};\\\", \\\"{x:1635,y:559,t:1527268393303};\\\", \\\"{x:1644,y:559,t:1527268393320};\\\", \\\"{x:1659,y:563,t:1527268393337};\\\", \\\"{x:1676,y:567,t:1527268393353};\\\", \\\"{x:1693,y:571,t:1527268393370};\\\", \\\"{x:1707,y:574,t:1527268393386};\\\", \\\"{x:1717,y:575,t:1527268393403};\\\", \\\"{x:1719,y:575,t:1527268393420};\\\", \\\"{x:1720,y:575,t:1527268393470};\\\", \\\"{x:1721,y:575,t:1527268393517};\\\", \\\"{x:1721,y:576,t:1527268393814};\\\", \\\"{x:1721,y:577,t:1527268393821};\\\", \\\"{x:1716,y:578,t:1527268393837};\\\", \\\"{x:1714,y:578,t:1527268393853};\\\", \\\"{x:1707,y:579,t:1527268393870};\\\", \\\"{x:1705,y:579,t:1527268393886};\\\", \\\"{x:1702,y:579,t:1527268393903};\\\", \\\"{x:1701,y:579,t:1527268393920};\\\", \\\"{x:1698,y:578,t:1527268393937};\\\", \\\"{x:1697,y:577,t:1527268393953};\\\", \\\"{x:1695,y:577,t:1527268394102};\\\", \\\"{x:1694,y:577,t:1527268394189};\\\", \\\"{x:1693,y:576,t:1527268394205};\\\", \\\"{x:1692,y:576,t:1527268394222};\\\", \\\"{x:1691,y:576,t:1527268394253};\\\", \\\"{x:1689,y:576,t:1527268394277};\\\", \\\"{x:1687,y:576,t:1527268394287};\\\", \\\"{x:1685,y:577,t:1527268394304};\\\", \\\"{x:1684,y:577,t:1527268394326};\\\", \\\"{x:1683,y:577,t:1527268394366};\\\", \\\"{x:1682,y:577,t:1527268394390};\\\", \\\"{x:1681,y:577,t:1527268394438};\\\", \\\"{x:1681,y:576,t:1527268394893};\\\", \\\"{x:1681,y:575,t:1527268395358};\\\", \\\"{x:1681,y:574,t:1527268395605};\\\", \\\"{x:1682,y:574,t:1527268395925};\\\", \\\"{x:1682,y:575,t:1527268396221};\\\", \\\"{x:1684,y:575,t:1527268396380};\\\", \\\"{x:1685,y:575,t:1527268396597};\\\", \\\"{x:1687,y:575,t:1527268396806};\\\", \\\"{x:1688,y:575,t:1527268396869};\\\", \\\"{x:1690,y:575,t:1527268397046};\\\", \\\"{x:1691,y:576,t:1527268397109};\\\", \\\"{x:1688,y:576,t:1527268398078};\\\", \\\"{x:1680,y:576,t:1527268398090};\\\", \\\"{x:1653,y:576,t:1527268398106};\\\", \\\"{x:1608,y:576,t:1527268398124};\\\", \\\"{x:1544,y:576,t:1527268398140};\\\", \\\"{x:1461,y:588,t:1527268398158};\\\", \\\"{x:1419,y:594,t:1527268398173};\\\", \\\"{x:1391,y:598,t:1527268398190};\\\", \\\"{x:1373,y:601,t:1527268398207};\\\", \\\"{x:1367,y:602,t:1527268398224};\\\", \\\"{x:1365,y:602,t:1527268398240};\\\", \\\"{x:1364,y:604,t:1527268398269};\\\", \\\"{x:1363,y:604,t:1527268398286};\\\", \\\"{x:1362,y:605,t:1527268398293};\\\", \\\"{x:1360,y:607,t:1527268398306};\\\", \\\"{x:1353,y:615,t:1527268398323};\\\", \\\"{x:1346,y:624,t:1527268398340};\\\", \\\"{x:1332,y:644,t:1527268398356};\\\", \\\"{x:1321,y:659,t:1527268398373};\\\", \\\"{x:1309,y:676,t:1527268398390};\\\", \\\"{x:1297,y:694,t:1527268398407};\\\", \\\"{x:1287,y:708,t:1527268398424};\\\", \\\"{x:1284,y:715,t:1527268398439};\\\", \\\"{x:1280,y:720,t:1527268398457};\\\", \\\"{x:1276,y:726,t:1527268398473};\\\", \\\"{x:1268,y:736,t:1527268398490};\\\", \\\"{x:1254,y:749,t:1527268398507};\\\", \\\"{x:1237,y:761,t:1527268398524};\\\", \\\"{x:1224,y:768,t:1527268398540};\\\", \\\"{x:1212,y:775,t:1527268398557};\\\", \\\"{x:1209,y:777,t:1527268398573};\\\", \\\"{x:1207,y:777,t:1527268398591};\\\", \\\"{x:1206,y:779,t:1527268398607};\\\", \\\"{x:1203,y:781,t:1527268398624};\\\", \\\"{x:1199,y:785,t:1527268398641};\\\", \\\"{x:1192,y:788,t:1527268398657};\\\", \\\"{x:1184,y:792,t:1527268398674};\\\", \\\"{x:1180,y:792,t:1527268398691};\\\", \\\"{x:1178,y:792,t:1527268398707};\\\", \\\"{x:1177,y:792,t:1527268398724};\\\", \\\"{x:1175,y:792,t:1527268398765};\\\", \\\"{x:1174,y:792,t:1527268398782};\\\", \\\"{x:1173,y:792,t:1527268398791};\\\", \\\"{x:1173,y:791,t:1527268398807};\\\", \\\"{x:1172,y:791,t:1527268398824};\\\", \\\"{x:1171,y:791,t:1527268398841};\\\", \\\"{x:1170,y:790,t:1527268398861};\\\", \\\"{x:1169,y:790,t:1527268398878};\\\", \\\"{x:1168,y:790,t:1527268398891};\\\", \\\"{x:1167,y:790,t:1527268398907};\\\", \\\"{x:1166,y:789,t:1527268398924};\\\", \\\"{x:1165,y:788,t:1527268398941};\\\", \\\"{x:1164,y:787,t:1527268398957};\\\", \\\"{x:1163,y:786,t:1527268398974};\\\", \\\"{x:1163,y:783,t:1527268398991};\\\", \\\"{x:1163,y:781,t:1527268399007};\\\", \\\"{x:1163,y:779,t:1527268399024};\\\", \\\"{x:1163,y:777,t:1527268399041};\\\", \\\"{x:1163,y:776,t:1527268399057};\\\", \\\"{x:1163,y:775,t:1527268399110};\\\", \\\"{x:1163,y:774,t:1527268399134};\\\", \\\"{x:1163,y:773,t:1527268399158};\\\", \\\"{x:1163,y:772,t:1527268399174};\\\", \\\"{x:1164,y:771,t:1527268399191};\\\", \\\"{x:1165,y:770,t:1527268399208};\\\", \\\"{x:1166,y:768,t:1527268399224};\\\", \\\"{x:1167,y:767,t:1527268399241};\\\", \\\"{x:1168,y:766,t:1527268399258};\\\", \\\"{x:1170,y:765,t:1527268399274};\\\", \\\"{x:1171,y:764,t:1527268399294};\\\", \\\"{x:1172,y:764,t:1527268399422};\\\", \\\"{x:1173,y:764,t:1527268399478};\\\", \\\"{x:1174,y:764,t:1527268399582};\\\", \\\"{x:1175,y:764,t:1527268399597};\\\", \\\"{x:1176,y:764,t:1527268399622};\\\", \\\"{x:1177,y:764,t:1527268399749};\\\", \\\"{x:1178,y:764,t:1527268399822};\\\", \\\"{x:1179,y:764,t:1527268399942};\\\", \\\"{x:1180,y:765,t:1527268400101};\\\", \\\"{x:1181,y:765,t:1527268400221};\\\", \\\"{x:1182,y:766,t:1527268400286};\\\", \\\"{x:1183,y:767,t:1527268400638};\\\", \\\"{x:1184,y:767,t:1527268401173};\\\", \\\"{x:1186,y:767,t:1527268401238};\\\", \\\"{x:1186,y:769,t:1527268401293};\\\", \\\"{x:1186,y:773,t:1527268401309};\\\", \\\"{x:1186,y:774,t:1527268401326};\\\", \\\"{x:1186,y:777,t:1527268401343};\\\", \\\"{x:1186,y:779,t:1527268401359};\\\", \\\"{x:1186,y:780,t:1527268401486};\\\", \\\"{x:1186,y:782,t:1527268401501};\\\", \\\"{x:1186,y:784,t:1527268401517};\\\", \\\"{x:1186,y:787,t:1527268401526};\\\", \\\"{x:1185,y:792,t:1527268401543};\\\", \\\"{x:1185,y:796,t:1527268401559};\\\", \\\"{x:1185,y:801,t:1527268401575};\\\", \\\"{x:1184,y:802,t:1527268401593};\\\", \\\"{x:1184,y:803,t:1527268401609};\\\", \\\"{x:1184,y:804,t:1527268401702};\\\", \\\"{x:1184,y:805,t:1527268401733};\\\", \\\"{x:1184,y:806,t:1527268401743};\\\", \\\"{x:1184,y:808,t:1527268401760};\\\", \\\"{x:1183,y:814,t:1527268401776};\\\", \\\"{x:1182,y:819,t:1527268401793};\\\", \\\"{x:1181,y:824,t:1527268401810};\\\", \\\"{x:1181,y:827,t:1527268401826};\\\", \\\"{x:1181,y:830,t:1527268401843};\\\", \\\"{x:1181,y:831,t:1527268401886};\\\", \\\"{x:1181,y:832,t:1527268401917};\\\", \\\"{x:1181,y:833,t:1527268401927};\\\", \\\"{x:1181,y:835,t:1527268401943};\\\", \\\"{x:1181,y:836,t:1527268401960};\\\", \\\"{x:1181,y:840,t:1527268401976};\\\", \\\"{x:1181,y:843,t:1527268401993};\\\", \\\"{x:1181,y:845,t:1527268402010};\\\", \\\"{x:1181,y:848,t:1527268402026};\\\", \\\"{x:1181,y:849,t:1527268402043};\\\", \\\"{x:1181,y:851,t:1527268402060};\\\", \\\"{x:1180,y:849,t:1527268402165};\\\", \\\"{x:1180,y:846,t:1527268402177};\\\", \\\"{x:1178,y:841,t:1527268402193};\\\", \\\"{x:1177,y:833,t:1527268402210};\\\", \\\"{x:1177,y:828,t:1527268402227};\\\", \\\"{x:1177,y:825,t:1527268402243};\\\", \\\"{x:1177,y:823,t:1527268402260};\\\", \\\"{x:1177,y:822,t:1527268402285};\\\", \\\"{x:1177,y:820,t:1527268402325};\\\", \\\"{x:1177,y:817,t:1527268402332};\\\", \\\"{x:1177,y:814,t:1527268402342};\\\", \\\"{x:1179,y:807,t:1527268402360};\\\", \\\"{x:1184,y:796,t:1527268402376};\\\", \\\"{x:1189,y:784,t:1527268402392};\\\", \\\"{x:1193,y:777,t:1527268402409};\\\", \\\"{x:1194,y:771,t:1527268402426};\\\", \\\"{x:1196,y:768,t:1527268402443};\\\", \\\"{x:1197,y:766,t:1527268402460};\\\", \\\"{x:1197,y:765,t:1527268402477};\\\", \\\"{x:1198,y:765,t:1527268402525};\\\", \\\"{x:1199,y:765,t:1527268402670};\\\", \\\"{x:1200,y:765,t:1527268402709};\\\", \\\"{x:1201,y:765,t:1527268402727};\\\", \\\"{x:1205,y:765,t:1527268402744};\\\", \\\"{x:1214,y:765,t:1527268402761};\\\", \\\"{x:1230,y:765,t:1527268402776};\\\", \\\"{x:1253,y:767,t:1527268402793};\\\", \\\"{x:1278,y:771,t:1527268402809};\\\", \\\"{x:1299,y:773,t:1527268402826};\\\", \\\"{x:1317,y:773,t:1527268402844};\\\", \\\"{x:1323,y:773,t:1527268402859};\\\", \\\"{x:1325,y:773,t:1527268402876};\\\", \\\"{x:1325,y:772,t:1527268402901};\\\", \\\"{x:1326,y:772,t:1527268402917};\\\", \\\"{x:1327,y:771,t:1527268402949};\\\", \\\"{x:1328,y:771,t:1527268402981};\\\", \\\"{x:1329,y:771,t:1527268402994};\\\", \\\"{x:1330,y:771,t:1527268403011};\\\", \\\"{x:1331,y:771,t:1527268403027};\\\", \\\"{x:1334,y:770,t:1527268403044};\\\", \\\"{x:1337,y:768,t:1527268403061};\\\", \\\"{x:1341,y:768,t:1527268403077};\\\", \\\"{x:1343,y:766,t:1527268403094};\\\", \\\"{x:1344,y:765,t:1527268403111};\\\", \\\"{x:1348,y:763,t:1527268403127};\\\", \\\"{x:1352,y:760,t:1527268403143};\\\", \\\"{x:1354,y:759,t:1527268403162};\\\", \\\"{x:1355,y:758,t:1527268403177};\\\", \\\"{x:1356,y:758,t:1527268403245};\\\", \\\"{x:1357,y:758,t:1527268403293};\\\", \\\"{x:1358,y:758,t:1527268403494};\\\", \\\"{x:1359,y:758,t:1527268403511};\\\", \\\"{x:1360,y:758,t:1527268403528};\\\", \\\"{x:1361,y:758,t:1527268403558};\\\", \\\"{x:1362,y:758,t:1527268403589};\\\", \\\"{x:1363,y:758,t:1527268403597};\\\", \\\"{x:1364,y:758,t:1527268403621};\\\", \\\"{x:1365,y:758,t:1527268403645};\\\", \\\"{x:1366,y:758,t:1527268403669};\\\", \\\"{x:1367,y:758,t:1527268403685};\\\", \\\"{x:1368,y:758,t:1527268403749};\\\", \\\"{x:1369,y:758,t:1527268403766};\\\", \\\"{x:1370,y:758,t:1527268403902};\\\", \\\"{x:1371,y:758,t:1527268403925};\\\", \\\"{x:1372,y:758,t:1527268403949};\\\", \\\"{x:1372,y:759,t:1527268403965};\\\", \\\"{x:1373,y:759,t:1527268403989};\\\", \\\"{x:1374,y:759,t:1527268403998};\\\", \\\"{x:1375,y:759,t:1527268404053};\\\", \\\"{x:1376,y:760,t:1527268404069};\\\", \\\"{x:1377,y:760,t:1527268404085};\\\", \\\"{x:1378,y:761,t:1527268404102};\\\", \\\"{x:1379,y:761,t:1527268404141};\\\", \\\"{x:1380,y:761,t:1527268404157};\\\", \\\"{x:1381,y:761,t:1527268404165};\\\", \\\"{x:1381,y:762,t:1527268404178};\\\", \\\"{x:1382,y:762,t:1527268404195};\\\", \\\"{x:1383,y:763,t:1527268404211};\\\", \\\"{x:1384,y:763,t:1527268404228};\\\", \\\"{x:1385,y:763,t:1527268404245};\\\", \\\"{x:1386,y:764,t:1527268404261};\\\", \\\"{x:1387,y:764,t:1527268404279};\\\", \\\"{x:1388,y:764,t:1527268404301};\\\", \\\"{x:1389,y:764,t:1527268404317};\\\", \\\"{x:1389,y:765,t:1527268404798};\\\", \\\"{x:1388,y:765,t:1527268404812};\\\", \\\"{x:1387,y:765,t:1527268404829};\\\", \\\"{x:1377,y:768,t:1527268404845};\\\", \\\"{x:1371,y:771,t:1527268404862};\\\", \\\"{x:1362,y:775,t:1527268404879};\\\", \\\"{x:1350,y:780,t:1527268404895};\\\", \\\"{x:1335,y:787,t:1527268404912};\\\", \\\"{x:1323,y:792,t:1527268404929};\\\", \\\"{x:1311,y:797,t:1527268404946};\\\", \\\"{x:1300,y:801,t:1527268404962};\\\", \\\"{x:1288,y:803,t:1527268404979};\\\", \\\"{x:1275,y:806,t:1527268404995};\\\", \\\"{x:1261,y:811,t:1527268405012};\\\", \\\"{x:1235,y:818,t:1527268405029};\\\", \\\"{x:1218,y:822,t:1527268405045};\\\", \\\"{x:1199,y:824,t:1527268405062};\\\", \\\"{x:1181,y:828,t:1527268405080};\\\", \\\"{x:1174,y:829,t:1527268405095};\\\", \\\"{x:1172,y:829,t:1527268405113};\\\", \\\"{x:1171,y:829,t:1527268405174};\\\", \\\"{x:1171,y:831,t:1527268405310};\\\", \\\"{x:1173,y:831,t:1527268405317};\\\", \\\"{x:1175,y:831,t:1527268405333};\\\", \\\"{x:1177,y:832,t:1527268405346};\\\", \\\"{x:1177,y:833,t:1527268405362};\\\", \\\"{x:1179,y:833,t:1527268405378};\\\", \\\"{x:1180,y:833,t:1527268405396};\\\", \\\"{x:1181,y:834,t:1527268405411};\\\", \\\"{x:1183,y:834,t:1527268405452};\\\", \\\"{x:1182,y:834,t:1527268405654};\\\", \\\"{x:1180,y:831,t:1527268405669};\\\", \\\"{x:1180,y:830,t:1527268405685};\\\", \\\"{x:1179,y:828,t:1527268405696};\\\", \\\"{x:1177,y:827,t:1527268405712};\\\", \\\"{x:1176,y:826,t:1527268405733};\\\", \\\"{x:1176,y:825,t:1527268405757};\\\", \\\"{x:1176,y:824,t:1527268405765};\\\", \\\"{x:1174,y:822,t:1527268405779};\\\", \\\"{x:1172,y:815,t:1527268405796};\\\", \\\"{x:1166,y:804,t:1527268405813};\\\", \\\"{x:1161,y:798,t:1527268405829};\\\", \\\"{x:1148,y:794,t:1527268405846};\\\", \\\"{x:1118,y:790,t:1527268405863};\\\", \\\"{x:1032,y:790,t:1527268405879};\\\", \\\"{x:910,y:790,t:1527268405896};\\\", \\\"{x:774,y:790,t:1527268405913};\\\", \\\"{x:651,y:780,t:1527268405929};\\\", \\\"{x:565,y:771,t:1527268405946};\\\", \\\"{x:512,y:763,t:1527268405964};\\\", \\\"{x:493,y:760,t:1527268405979};\\\", \\\"{x:486,y:757,t:1527268405996};\\\", \\\"{x:483,y:755,t:1527268406012};\\\", \\\"{x:481,y:751,t:1527268406030};\\\", \\\"{x:479,y:745,t:1527268406046};\\\", \\\"{x:477,y:741,t:1527268406062};\\\", \\\"{x:474,y:734,t:1527268406079};\\\", \\\"{x:469,y:725,t:1527268406096};\\\", \\\"{x:461,y:717,t:1527268406113};\\\", \\\"{x:453,y:709,t:1527268406129};\\\", \\\"{x:443,y:700,t:1527268406146};\\\", \\\"{x:424,y:687,t:1527268406163};\\\", \\\"{x:404,y:673,t:1527268406180};\\\", \\\"{x:379,y:661,t:1527268406196};\\\", \\\"{x:323,y:638,t:1527268406213};\\\", \\\"{x:278,y:623,t:1527268406230};\\\", \\\"{x:243,y:611,t:1527268406247};\\\", \\\"{x:214,y:604,t:1527268406262};\\\", \\\"{x:197,y:598,t:1527268406279};\\\", \\\"{x:187,y:593,t:1527268406297};\\\", \\\"{x:183,y:590,t:1527268406312};\\\", \\\"{x:182,y:588,t:1527268406330};\\\", \\\"{x:180,y:586,t:1527268406347};\\\", \\\"{x:180,y:584,t:1527268406362};\\\", \\\"{x:179,y:582,t:1527268406380};\\\", \\\"{x:175,y:577,t:1527268406396};\\\", \\\"{x:172,y:574,t:1527268406413};\\\", \\\"{x:170,y:571,t:1527268406429};\\\", \\\"{x:170,y:570,t:1527268406446};\\\", \\\"{x:170,y:568,t:1527268406463};\\\", \\\"{x:170,y:564,t:1527268406480};\\\", \\\"{x:170,y:560,t:1527268406498};\\\", \\\"{x:170,y:553,t:1527268406513};\\\", \\\"{x:170,y:546,t:1527268406530};\\\", \\\"{x:170,y:539,t:1527268406547};\\\", \\\"{x:171,y:533,t:1527268406562};\\\", \\\"{x:171,y:529,t:1527268406580};\\\", \\\"{x:171,y:525,t:1527268406596};\\\", \\\"{x:171,y:524,t:1527268406628};\\\", \\\"{x:171,y:523,t:1527268406646};\\\", \\\"{x:171,y:522,t:1527268406663};\\\", \\\"{x:170,y:520,t:1527268406679};\\\", \\\"{x:170,y:517,t:1527268406698};\\\", \\\"{x:170,y:516,t:1527268406714};\\\", \\\"{x:169,y:514,t:1527268406730};\\\", \\\"{x:169,y:513,t:1527268406747};\\\", \\\"{x:169,y:511,t:1527268406764};\\\", \\\"{x:168,y:509,t:1527268406780};\\\", \\\"{x:168,y:506,t:1527268406796};\\\", \\\"{x:168,y:504,t:1527268406814};\\\", \\\"{x:168,y:503,t:1527268406831};\\\", \\\"{x:167,y:502,t:1527268406847};\\\", \\\"{x:167,y:501,t:1527268406877};\\\", \\\"{x:166,y:500,t:1527268406885};\\\", \\\"{x:166,y:499,t:1527268406897};\\\", \\\"{x:166,y:498,t:1527268406914};\\\", \\\"{x:166,y:497,t:1527268406931};\\\", \\\"{x:166,y:496,t:1527268406997};\\\", \\\"{x:168,y:496,t:1527268408837};\\\", \\\"{x:170,y:497,t:1527268408848};\\\", \\\"{x:173,y:497,t:1527268408865};\\\", \\\"{x:190,y:497,t:1527268408882};\\\", \\\"{x:215,y:497,t:1527268408899};\\\", \\\"{x:239,y:497,t:1527268408915};\\\", \\\"{x:264,y:499,t:1527268408933};\\\", \\\"{x:292,y:503,t:1527268408950};\\\", \\\"{x:300,y:505,t:1527268408965};\\\", \\\"{x:302,y:506,t:1527268408981};\\\", \\\"{x:303,y:506,t:1527268409044};\\\", \\\"{x:305,y:506,t:1527268409245};\\\", \\\"{x:307,y:506,t:1527268409253};\\\", \\\"{x:310,y:506,t:1527268409265};\\\", \\\"{x:317,y:505,t:1527268409282};\\\", \\\"{x:330,y:502,t:1527268409299};\\\", \\\"{x:344,y:501,t:1527268409317};\\\", \\\"{x:354,y:499,t:1527268409332};\\\", \\\"{x:360,y:497,t:1527268409349};\\\", \\\"{x:360,y:496,t:1527268409381};\\\", \\\"{x:361,y:496,t:1527268409399};\\\", \\\"{x:362,y:496,t:1527268409580};\\\", \\\"{x:364,y:496,t:1527268409588};\\\", \\\"{x:365,y:496,t:1527268409599};\\\", \\\"{x:370,y:496,t:1527268409616};\\\", \\\"{x:374,y:495,t:1527268409633};\\\", \\\"{x:377,y:495,t:1527268409649};\\\", \\\"{x:378,y:493,t:1527268409666};\\\", \\\"{x:379,y:493,t:1527268409681};\\\", \\\"{x:380,y:493,t:1527268409948};\\\", \\\"{x:380,y:496,t:1527268409956};\\\", \\\"{x:382,y:499,t:1527268409966};\\\", \\\"{x:385,y:506,t:1527268409983};\\\", \\\"{x:387,y:512,t:1527268409999};\\\", \\\"{x:392,y:520,t:1527268410016};\\\", \\\"{x:396,y:527,t:1527268410033};\\\", \\\"{x:402,y:538,t:1527268410050};\\\", \\\"{x:408,y:546,t:1527268410065};\\\", \\\"{x:415,y:557,t:1527268410083};\\\", \\\"{x:427,y:572,t:1527268410099};\\\", \\\"{x:437,y:589,t:1527268410116};\\\", \\\"{x:459,y:615,t:1527268410133};\\\", \\\"{x:474,y:638,t:1527268410151};\\\", \\\"{x:497,y:670,t:1527268410166};\\\", \\\"{x:517,y:701,t:1527268410183};\\\", \\\"{x:538,y:732,t:1527268410199};\\\", \\\"{x:554,y:755,t:1527268410216};\\\", \\\"{x:564,y:769,t:1527268410232};\\\", \\\"{x:568,y:774,t:1527268410250};\\\", \\\"{x:569,y:775,t:1527268410266};\\\", \\\"{x:570,y:776,t:1527268410283};\\\", \\\"{x:570,y:777,t:1527268410413};\\\", \\\"{x:569,y:778,t:1527268410421};\\\", \\\"{x:566,y:779,t:1527268410437};\\\", \\\"{x:565,y:779,t:1527268410461};\\\", \\\"{x:564,y:779,t:1527268410469};\\\", \\\"{x:563,y:779,t:1527268410483};\\\", \\\"{x:560,y:779,t:1527268410500};\\\", \\\"{x:556,y:778,t:1527268410517};\\\", \\\"{x:553,y:777,t:1527268410533};\\\", \\\"{x:552,y:776,t:1527268410550};\\\", \\\"{x:550,y:775,t:1527268410568};\\\", \\\"{x:548,y:774,t:1527268410583};\\\", \\\"{x:547,y:774,t:1527268410613};\\\", \\\"{x:546,y:774,t:1527268410621};\\\", \\\"{x:546,y:773,t:1527268410634};\\\", \\\"{x:545,y:772,t:1527268410650};\\\", \\\"{x:543,y:771,t:1527268410667};\\\", \\\"{x:542,y:770,t:1527268410683};\\\", \\\"{x:542,y:767,t:1527268410701};\\\", \\\"{x:539,y:761,t:1527268410717};\\\", \\\"{x:536,y:754,t:1527268410735};\\\", \\\"{x:535,y:749,t:1527268410750};\\\", \\\"{x:532,y:743,t:1527268410765};\\\", \\\"{x:532,y:739,t:1527268410781};\\\", \\\"{x:531,y:736,t:1527268410798};\\\", \\\"{x:531,y:735,t:1527268410828};\\\", \\\"{x:532,y:735,t:1527268411453};\\\", \\\"{x:533,y:735,t:1527268411476};\\\", \\\"{x:534,y:735,t:1527268411509};\\\", \\\"{x:535,y:735,t:1527268411813};\\\" ] }, { \\\"rt\\\": 35538, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 483600, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -B -B -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:736,t:1527268414141};\\\", \\\"{x:534,y:735,t:1527268414220};\\\", \\\"{x:530,y:725,t:1527268414228};\\\", \\\"{x:524,y:714,t:1527268414239};\\\", \\\"{x:512,y:689,t:1527268414255};\\\", \\\"{x:494,y:659,t:1527268414272};\\\", \\\"{x:480,y:634,t:1527268414287};\\\", \\\"{x:463,y:603,t:1527268414304};\\\", \\\"{x:452,y:586,t:1527268414319};\\\", \\\"{x:446,y:577,t:1527268414336};\\\", \\\"{x:441,y:571,t:1527268414352};\\\", \\\"{x:436,y:568,t:1527268414370};\\\", \\\"{x:433,y:567,t:1527268414386};\\\", \\\"{x:431,y:566,t:1527268414402};\\\", \\\"{x:425,y:561,t:1527268414420};\\\", \\\"{x:420,y:555,t:1527268414436};\\\", \\\"{x:416,y:550,t:1527268414454};\\\", \\\"{x:411,y:544,t:1527268414470};\\\", \\\"{x:406,y:535,t:1527268414486};\\\", \\\"{x:400,y:527,t:1527268414503};\\\", \\\"{x:394,y:519,t:1527268414520};\\\", \\\"{x:388,y:512,t:1527268414536};\\\", \\\"{x:385,y:508,t:1527268414552};\\\", \\\"{x:383,y:505,t:1527268414569};\\\", \\\"{x:381,y:504,t:1527268414586};\\\", \\\"{x:378,y:502,t:1527268414603};\\\", \\\"{x:375,y:502,t:1527268414620};\\\", \\\"{x:374,y:501,t:1527268414636};\\\", \\\"{x:372,y:501,t:1527268414653};\\\", \\\"{x:371,y:500,t:1527268414670};\\\", \\\"{x:370,y:499,t:1527268414686};\\\", \\\"{x:369,y:498,t:1527268414703};\\\", \\\"{x:369,y:496,t:1527268414720};\\\", \\\"{x:368,y:492,t:1527268414736};\\\", \\\"{x:368,y:488,t:1527268414753};\\\", \\\"{x:368,y:482,t:1527268414770};\\\", \\\"{x:368,y:479,t:1527268414787};\\\", \\\"{x:368,y:477,t:1527268414803};\\\", \\\"{x:368,y:476,t:1527268414820};\\\", \\\"{x:369,y:475,t:1527268414844};\\\", \\\"{x:369,y:474,t:1527268414925};\\\", \\\"{x:370,y:474,t:1527268414936};\\\", \\\"{x:372,y:472,t:1527268414953};\\\", \\\"{x:374,y:470,t:1527268414970};\\\", \\\"{x:380,y:466,t:1527268414988};\\\", \\\"{x:387,y:462,t:1527268415004};\\\", \\\"{x:392,y:459,t:1527268415021};\\\", \\\"{x:397,y:457,t:1527268415037};\\\", \\\"{x:401,y:456,t:1527268415053};\\\", \\\"{x:403,y:455,t:1527268415071};\\\", \\\"{x:404,y:455,t:1527268415088};\\\", \\\"{x:405,y:455,t:1527268415103};\\\", \\\"{x:406,y:455,t:1527268415133};\\\", \\\"{x:407,y:455,t:1527268415173};\\\", \\\"{x:408,y:455,t:1527268415213};\\\", \\\"{x:409,y:455,t:1527268415252};\\\", \\\"{x:410,y:455,t:1527268415270};\\\", \\\"{x:411,y:455,t:1527268415287};\\\", \\\"{x:413,y:455,t:1527268415309};\\\", \\\"{x:414,y:455,t:1527268415320};\\\", \\\"{x:417,y:455,t:1527268415337};\\\", \\\"{x:421,y:455,t:1527268415354};\\\", \\\"{x:431,y:456,t:1527268415370};\\\", \\\"{x:438,y:457,t:1527268415387};\\\", \\\"{x:447,y:458,t:1527268415405};\\\", \\\"{x:450,y:458,t:1527268415420};\\\", \\\"{x:453,y:458,t:1527268415437};\\\", \\\"{x:454,y:458,t:1527268415454};\\\", \\\"{x:455,y:458,t:1527268415470};\\\", \\\"{x:456,y:458,t:1527268415487};\\\", \\\"{x:457,y:458,t:1527268415503};\\\", \\\"{x:459,y:458,t:1527268415524};\\\", \\\"{x:460,y:458,t:1527268415536};\\\", \\\"{x:467,y:458,t:1527268415554};\\\", \\\"{x:474,y:458,t:1527268415570};\\\", \\\"{x:480,y:458,t:1527268415587};\\\", \\\"{x:487,y:458,t:1527268415604};\\\", \\\"{x:490,y:460,t:1527268415620};\\\", \\\"{x:492,y:460,t:1527268415637};\\\", \\\"{x:494,y:460,t:1527268415654};\\\", \\\"{x:496,y:460,t:1527268415670};\\\", \\\"{x:500,y:460,t:1527268415687};\\\", \\\"{x:505,y:460,t:1527268415704};\\\", \\\"{x:511,y:460,t:1527268415720};\\\", \\\"{x:519,y:460,t:1527268415737};\\\", \\\"{x:528,y:460,t:1527268415755};\\\", \\\"{x:537,y:460,t:1527268415770};\\\", \\\"{x:541,y:460,t:1527268415787};\\\", \\\"{x:548,y:460,t:1527268415805};\\\", \\\"{x:549,y:460,t:1527268415820};\\\", \\\"{x:550,y:460,t:1527268415837};\\\", \\\"{x:551,y:461,t:1527268415869};\\\", \\\"{x:552,y:461,t:1527268415973};\\\", \\\"{x:552,y:462,t:1527268415988};\\\", \\\"{x:554,y:462,t:1527268416004};\\\", \\\"{x:555,y:462,t:1527268416037};\\\", \\\"{x:556,y:462,t:1527268416077};\\\", \\\"{x:557,y:462,t:1527268416125};\\\", \\\"{x:558,y:462,t:1527268416406};\\\", \\\"{x:559,y:463,t:1527268416422};\\\", \\\"{x:560,y:463,t:1527268416444};\\\", \\\"{x:561,y:463,t:1527268416501};\\\", \\\"{x:562,y:463,t:1527268416525};\\\", \\\"{x:563,y:463,t:1527268416557};\\\", \\\"{x:563,y:464,t:1527268416571};\\\", \\\"{x:564,y:464,t:1527268416621};\\\", \\\"{x:566,y:464,t:1527268416639};\\\", \\\"{x:568,y:464,t:1527268416655};\\\", \\\"{x:572,y:464,t:1527268416671};\\\", \\\"{x:576,y:464,t:1527268416689};\\\", \\\"{x:582,y:464,t:1527268416706};\\\", \\\"{x:589,y:464,t:1527268416721};\\\", \\\"{x:595,y:464,t:1527268416738};\\\", \\\"{x:599,y:464,t:1527268416755};\\\", \\\"{x:603,y:464,t:1527268416772};\\\", \\\"{x:606,y:464,t:1527268416788};\\\", \\\"{x:607,y:464,t:1527268416805};\\\", \\\"{x:610,y:463,t:1527268416822};\\\", \\\"{x:611,y:463,t:1527268416839};\\\", \\\"{x:613,y:462,t:1527268416855};\\\", \\\"{x:616,y:462,t:1527268416871};\\\", \\\"{x:618,y:462,t:1527268416888};\\\", \\\"{x:620,y:462,t:1527268416906};\\\", \\\"{x:621,y:460,t:1527268416921};\\\", \\\"{x:622,y:460,t:1527268416964};\\\", \\\"{x:623,y:460,t:1527268416981};\\\", \\\"{x:624,y:460,t:1527268417206};\\\", \\\"{x:625,y:460,t:1527268417222};\\\", \\\"{x:626,y:460,t:1527268417252};\\\", \\\"{x:627,y:460,t:1527268417285};\\\", \\\"{x:628,y:460,t:1527268417309};\\\", \\\"{x:629,y:460,t:1527268417323};\\\", \\\"{x:631,y:461,t:1527268417339};\\\", \\\"{x:636,y:463,t:1527268417355};\\\", \\\"{x:655,y:464,t:1527268417372};\\\", \\\"{x:676,y:469,t:1527268417388};\\\", \\\"{x:693,y:470,t:1527268417405};\\\", \\\"{x:708,y:471,t:1527268417422};\\\", \\\"{x:721,y:473,t:1527268417438};\\\", \\\"{x:731,y:474,t:1527268417455};\\\", \\\"{x:739,y:475,t:1527268417472};\\\", \\\"{x:748,y:476,t:1527268417488};\\\", \\\"{x:757,y:478,t:1527268417505};\\\", \\\"{x:767,y:479,t:1527268417523};\\\", \\\"{x:777,y:480,t:1527268417538};\\\", \\\"{x:791,y:483,t:1527268417555};\\\", \\\"{x:818,y:485,t:1527268417573};\\\", \\\"{x:843,y:490,t:1527268417590};\\\", \\\"{x:881,y:496,t:1527268417605};\\\", \\\"{x:940,y:504,t:1527268417622};\\\", \\\"{x:1009,y:515,t:1527268417639};\\\", \\\"{x:1087,y:524,t:1527268417655};\\\", \\\"{x:1170,y:535,t:1527268417672};\\\", \\\"{x:1243,y:547,t:1527268417689};\\\", \\\"{x:1300,y:557,t:1527268417705};\\\", \\\"{x:1342,y:564,t:1527268417722};\\\", \\\"{x:1364,y:566,t:1527268417739};\\\", \\\"{x:1381,y:570,t:1527268417755};\\\", \\\"{x:1393,y:571,t:1527268417772};\\\", \\\"{x:1396,y:573,t:1527268417789};\\\", \\\"{x:1407,y:574,t:1527268417805};\\\", \\\"{x:1420,y:579,t:1527268417822};\\\", \\\"{x:1443,y:581,t:1527268417839};\\\", \\\"{x:1470,y:585,t:1527268417855};\\\", \\\"{x:1501,y:590,t:1527268417873};\\\", \\\"{x:1529,y:595,t:1527268417889};\\\", \\\"{x:1558,y:598,t:1527268417905};\\\", \\\"{x:1581,y:602,t:1527268417922};\\\", \\\"{x:1598,y:604,t:1527268417940};\\\", \\\"{x:1606,y:605,t:1527268417956};\\\", \\\"{x:1611,y:606,t:1527268417973};\\\", \\\"{x:1613,y:607,t:1527268417990};\\\", \\\"{x:1613,y:608,t:1527268418109};\\\", \\\"{x:1613,y:609,t:1527268418122};\\\", \\\"{x:1613,y:611,t:1527268418140};\\\", \\\"{x:1612,y:614,t:1527268418156};\\\", \\\"{x:1609,y:617,t:1527268418171};\\\", \\\"{x:1608,y:619,t:1527268418189};\\\", \\\"{x:1603,y:623,t:1527268418206};\\\", \\\"{x:1596,y:627,t:1527268418222};\\\", \\\"{x:1585,y:633,t:1527268418240};\\\", \\\"{x:1573,y:640,t:1527268418256};\\\", \\\"{x:1560,y:651,t:1527268418272};\\\", \\\"{x:1538,y:673,t:1527268418289};\\\", \\\"{x:1521,y:689,t:1527268418306};\\\", \\\"{x:1512,y:697,t:1527268418322};\\\", \\\"{x:1505,y:706,t:1527268418339};\\\", \\\"{x:1489,y:723,t:1527268418356};\\\", \\\"{x:1484,y:730,t:1527268418372};\\\", \\\"{x:1482,y:732,t:1527268418389};\\\", \\\"{x:1481,y:733,t:1527268418406};\\\", \\\"{x:1481,y:734,t:1527268418734};\\\", \\\"{x:1482,y:734,t:1527268418814};\\\", \\\"{x:1483,y:735,t:1527268418829};\\\", \\\"{x:1484,y:735,t:1527268418877};\\\", \\\"{x:1485,y:735,t:1527268418893};\\\", \\\"{x:1486,y:735,t:1527268418917};\\\", \\\"{x:1487,y:736,t:1527268419205};\\\", \\\"{x:1488,y:736,t:1527268419237};\\\", \\\"{x:1488,y:737,t:1527268419261};\\\", \\\"{x:1489,y:737,t:1527268419274};\\\", \\\"{x:1490,y:737,t:1527268419293};\\\", \\\"{x:1491,y:738,t:1527268419307};\\\", \\\"{x:1492,y:738,t:1527268419340};\\\", \\\"{x:1493,y:738,t:1527268419421};\\\", \\\"{x:1494,y:738,t:1527268419461};\\\", \\\"{x:1495,y:739,t:1527268419557};\\\", \\\"{x:1496,y:740,t:1527268419821};\\\", \\\"{x:1496,y:738,t:1527268421558};\\\", \\\"{x:1491,y:731,t:1527268421575};\\\", \\\"{x:1484,y:721,t:1527268421592};\\\", \\\"{x:1479,y:714,t:1527268421608};\\\", \\\"{x:1473,y:705,t:1527268421625};\\\", \\\"{x:1467,y:697,t:1527268421641};\\\", \\\"{x:1461,y:691,t:1527268421658};\\\", \\\"{x:1458,y:688,t:1527268421676};\\\", \\\"{x:1458,y:687,t:1527268421725};\\\", \\\"{x:1458,y:685,t:1527268421909};\\\", \\\"{x:1458,y:684,t:1527268421926};\\\", \\\"{x:1458,y:682,t:1527268421943};\\\", \\\"{x:1458,y:681,t:1527268421959};\\\", \\\"{x:1457,y:679,t:1527268421976};\\\", \\\"{x:1456,y:677,t:1527268422053};\\\", \\\"{x:1455,y:674,t:1527268422061};\\\", \\\"{x:1454,y:672,t:1527268422077};\\\", \\\"{x:1449,y:661,t:1527268422093};\\\", \\\"{x:1444,y:652,t:1527268422109};\\\", \\\"{x:1441,y:646,t:1527268422126};\\\", \\\"{x:1436,y:640,t:1527268422143};\\\", \\\"{x:1432,y:636,t:1527268422158};\\\", \\\"{x:1431,y:634,t:1527268422175};\\\", \\\"{x:1430,y:633,t:1527268422192};\\\", \\\"{x:1429,y:632,t:1527268422208};\\\", \\\"{x:1429,y:630,t:1527268422225};\\\", \\\"{x:1429,y:626,t:1527268422243};\\\", \\\"{x:1426,y:617,t:1527268422259};\\\", \\\"{x:1426,y:602,t:1527268422276};\\\", \\\"{x:1426,y:585,t:1527268422292};\\\", \\\"{x:1428,y:575,t:1527268422308};\\\", \\\"{x:1435,y:563,t:1527268422326};\\\", \\\"{x:1441,y:554,t:1527268422342};\\\", \\\"{x:1446,y:545,t:1527268422360};\\\", \\\"{x:1454,y:535,t:1527268422376};\\\", \\\"{x:1461,y:526,t:1527268422392};\\\", \\\"{x:1466,y:520,t:1527268422409};\\\", \\\"{x:1473,y:515,t:1527268422426};\\\", \\\"{x:1482,y:508,t:1527268422443};\\\", \\\"{x:1486,y:504,t:1527268422460};\\\", \\\"{x:1492,y:498,t:1527268422476};\\\", \\\"{x:1500,y:493,t:1527268422493};\\\", \\\"{x:1505,y:488,t:1527268422510};\\\", \\\"{x:1511,y:483,t:1527268422526};\\\", \\\"{x:1516,y:480,t:1527268422543};\\\", \\\"{x:1517,y:479,t:1527268422560};\\\", \\\"{x:1518,y:478,t:1527268422576};\\\", \\\"{x:1519,y:478,t:1527268422910};\\\", \\\"{x:1519,y:480,t:1527268422927};\\\", \\\"{x:1518,y:484,t:1527268422943};\\\", \\\"{x:1517,y:487,t:1527268422960};\\\", \\\"{x:1516,y:489,t:1527268422977};\\\", \\\"{x:1515,y:492,t:1527268422993};\\\", \\\"{x:1515,y:496,t:1527268423010};\\\", \\\"{x:1515,y:498,t:1527268423027};\\\", \\\"{x:1515,y:503,t:1527268423043};\\\", \\\"{x:1514,y:513,t:1527268423060};\\\", \\\"{x:1512,y:542,t:1527268423077};\\\", \\\"{x:1506,y:581,t:1527268423093};\\\", \\\"{x:1489,y:637,t:1527268423110};\\\", \\\"{x:1469,y:694,t:1527268423127};\\\", \\\"{x:1451,y:738,t:1527268423143};\\\", \\\"{x:1439,y:762,t:1527268423160};\\\", \\\"{x:1427,y:779,t:1527268423177};\\\", \\\"{x:1420,y:789,t:1527268423193};\\\", \\\"{x:1419,y:791,t:1527268423210};\\\", \\\"{x:1417,y:793,t:1527268423227};\\\", \\\"{x:1416,y:793,t:1527268423243};\\\", \\\"{x:1416,y:794,t:1527268423260};\\\", \\\"{x:1413,y:796,t:1527268423277};\\\", \\\"{x:1410,y:796,t:1527268423294};\\\", \\\"{x:1406,y:798,t:1527268423310};\\\", \\\"{x:1404,y:798,t:1527268423327};\\\", \\\"{x:1399,y:798,t:1527268423344};\\\", \\\"{x:1393,y:798,t:1527268423360};\\\", \\\"{x:1387,y:798,t:1527268423377};\\\", \\\"{x:1381,y:798,t:1527268423394};\\\", \\\"{x:1375,y:796,t:1527268423410};\\\", \\\"{x:1368,y:794,t:1527268423427};\\\", \\\"{x:1361,y:791,t:1527268423444};\\\", \\\"{x:1359,y:790,t:1527268423460};\\\", \\\"{x:1357,y:790,t:1527268423509};\\\", \\\"{x:1357,y:789,t:1527268423526};\\\", \\\"{x:1356,y:789,t:1527268423549};\\\", \\\"{x:1354,y:787,t:1527268423573};\\\", \\\"{x:1352,y:787,t:1527268423597};\\\", \\\"{x:1351,y:787,t:1527268423629};\\\", \\\"{x:1350,y:786,t:1527268423693};\\\", \\\"{x:1348,y:785,t:1527268423725};\\\", \\\"{x:1347,y:784,t:1527268423757};\\\", \\\"{x:1346,y:784,t:1527268423773};\\\", \\\"{x:1346,y:783,t:1527268423829};\\\", \\\"{x:1345,y:783,t:1527268423909};\\\", \\\"{x:1344,y:781,t:1527268423925};\\\", \\\"{x:1343,y:780,t:1527268423941};\\\", \\\"{x:1343,y:778,t:1527268423949};\\\", \\\"{x:1343,y:777,t:1527268423965};\\\", \\\"{x:1342,y:776,t:1527268423977};\\\", \\\"{x:1342,y:775,t:1527268423994};\\\", \\\"{x:1342,y:774,t:1527268424013};\\\", \\\"{x:1342,y:773,t:1527268424044};\\\", \\\"{x:1342,y:772,t:1527268424182};\\\", \\\"{x:1342,y:771,t:1527268424197};\\\", \\\"{x:1342,y:770,t:1527268424211};\\\", \\\"{x:1342,y:769,t:1527268424228};\\\", \\\"{x:1342,y:767,t:1527268424244};\\\", \\\"{x:1342,y:764,t:1527268424261};\\\", \\\"{x:1343,y:764,t:1527268424277};\\\", \\\"{x:1343,y:763,t:1527268424294};\\\", \\\"{x:1344,y:762,t:1527268424311};\\\", \\\"{x:1344,y:761,t:1527268424333};\\\", \\\"{x:1345,y:761,t:1527268424413};\\\", \\\"{x:1346,y:761,t:1527268424453};\\\", \\\"{x:1347,y:761,t:1527268424468};\\\", \\\"{x:1348,y:762,t:1527268424492};\\\", \\\"{x:1349,y:762,t:1527268424511};\\\", \\\"{x:1349,y:766,t:1527268424528};\\\", \\\"{x:1349,y:768,t:1527268424544};\\\", \\\"{x:1349,y:772,t:1527268424562};\\\", \\\"{x:1349,y:774,t:1527268424578};\\\", \\\"{x:1349,y:777,t:1527268424594};\\\", \\\"{x:1349,y:781,t:1527268424612};\\\", \\\"{x:1349,y:784,t:1527268424628};\\\", \\\"{x:1349,y:786,t:1527268424644};\\\", \\\"{x:1349,y:792,t:1527268424661};\\\", \\\"{x:1346,y:801,t:1527268424678};\\\", \\\"{x:1344,y:808,t:1527268424694};\\\", \\\"{x:1342,y:812,t:1527268424711};\\\", \\\"{x:1339,y:818,t:1527268424728};\\\", \\\"{x:1338,y:823,t:1527268424745};\\\", \\\"{x:1338,y:824,t:1527268424761};\\\", \\\"{x:1338,y:825,t:1527268424789};\\\", \\\"{x:1338,y:826,t:1527268424797};\\\", \\\"{x:1338,y:827,t:1527268424829};\\\", \\\"{x:1338,y:828,t:1527268424845};\\\", \\\"{x:1338,y:829,t:1527268424869};\\\", \\\"{x:1339,y:830,t:1527268424893};\\\", \\\"{x:1339,y:831,t:1527268424917};\\\", \\\"{x:1339,y:832,t:1527268424928};\\\", \\\"{x:1339,y:833,t:1527268424945};\\\", \\\"{x:1340,y:834,t:1527268424961};\\\", \\\"{x:1340,y:835,t:1527268424989};\\\", \\\"{x:1340,y:834,t:1527268425069};\\\", \\\"{x:1340,y:832,t:1527268425079};\\\", \\\"{x:1337,y:829,t:1527268425095};\\\", \\\"{x:1333,y:825,t:1527268425111};\\\", \\\"{x:1331,y:817,t:1527268425128};\\\", \\\"{x:1327,y:809,t:1527268425145};\\\", \\\"{x:1325,y:803,t:1527268425161};\\\", \\\"{x:1324,y:798,t:1527268425179};\\\", \\\"{x:1323,y:794,t:1527268425195};\\\", \\\"{x:1323,y:790,t:1527268425212};\\\", \\\"{x:1323,y:788,t:1527268425228};\\\", \\\"{x:1323,y:786,t:1527268425245};\\\", \\\"{x:1323,y:784,t:1527268425261};\\\", \\\"{x:1323,y:782,t:1527268425278};\\\", \\\"{x:1323,y:780,t:1527268425296};\\\", \\\"{x:1323,y:777,t:1527268425313};\\\", \\\"{x:1324,y:775,t:1527268425328};\\\", \\\"{x:1325,y:773,t:1527268425349};\\\", \\\"{x:1326,y:773,t:1527268425389};\\\", \\\"{x:1327,y:772,t:1527268425397};\\\", \\\"{x:1327,y:771,t:1527268425413};\\\", \\\"{x:1328,y:771,t:1527268425429};\\\", \\\"{x:1330,y:772,t:1527268425445};\\\", \\\"{x:1331,y:772,t:1527268425462};\\\", \\\"{x:1332,y:772,t:1527268425478};\\\", \\\"{x:1333,y:774,t:1527268425495};\\\", \\\"{x:1335,y:775,t:1527268425512};\\\", \\\"{x:1336,y:778,t:1527268425528};\\\", \\\"{x:1337,y:785,t:1527268425545};\\\", \\\"{x:1338,y:792,t:1527268425562};\\\", \\\"{x:1340,y:802,t:1527268425578};\\\", \\\"{x:1341,y:811,t:1527268425595};\\\", \\\"{x:1343,y:820,t:1527268425612};\\\", \\\"{x:1345,y:830,t:1527268425629};\\\", \\\"{x:1346,y:839,t:1527268425645};\\\", \\\"{x:1346,y:843,t:1527268425662};\\\", \\\"{x:1346,y:848,t:1527268425679};\\\", \\\"{x:1346,y:852,t:1527268425695};\\\", \\\"{x:1347,y:856,t:1527268425713};\\\", \\\"{x:1349,y:862,t:1527268425729};\\\", \\\"{x:1349,y:867,t:1527268425745};\\\", \\\"{x:1349,y:870,t:1527268425762};\\\", \\\"{x:1349,y:871,t:1527268425779};\\\", \\\"{x:1350,y:873,t:1527268425795};\\\", \\\"{x:1351,y:874,t:1527268425821};\\\", \\\"{x:1351,y:875,t:1527268425829};\\\", \\\"{x:1351,y:877,t:1527268425845};\\\", \\\"{x:1351,y:879,t:1527268425862};\\\", \\\"{x:1351,y:882,t:1527268425879};\\\", \\\"{x:1351,y:884,t:1527268425895};\\\", \\\"{x:1351,y:886,t:1527268425912};\\\", \\\"{x:1351,y:887,t:1527268425929};\\\", \\\"{x:1351,y:889,t:1527268425946};\\\", \\\"{x:1351,y:890,t:1527268425962};\\\", \\\"{x:1351,y:892,t:1527268425979};\\\", \\\"{x:1351,y:893,t:1527268425995};\\\", \\\"{x:1351,y:895,t:1527268426013};\\\", \\\"{x:1350,y:896,t:1527268426029};\\\", \\\"{x:1350,y:898,t:1527268426045};\\\", \\\"{x:1349,y:900,t:1527268426062};\\\", \\\"{x:1349,y:901,t:1527268426085};\\\", \\\"{x:1349,y:899,t:1527268426165};\\\", \\\"{x:1349,y:894,t:1527268426179};\\\", \\\"{x:1349,y:877,t:1527268426196};\\\", \\\"{x:1350,y:854,t:1527268426212};\\\", \\\"{x:1359,y:819,t:1527268426229};\\\", \\\"{x:1370,y:798,t:1527268426246};\\\", \\\"{x:1375,y:785,t:1527268426262};\\\", \\\"{x:1379,y:775,t:1527268426279};\\\", \\\"{x:1383,y:766,t:1527268426296};\\\", \\\"{x:1385,y:761,t:1527268426313};\\\", \\\"{x:1387,y:758,t:1527268426329};\\\", \\\"{x:1388,y:756,t:1527268426346};\\\", \\\"{x:1388,y:755,t:1527268426429};\\\", \\\"{x:1389,y:755,t:1527268426460};\\\", \\\"{x:1391,y:755,t:1527268426479};\\\", \\\"{x:1393,y:755,t:1527268426496};\\\", \\\"{x:1394,y:755,t:1527268426517};\\\", \\\"{x:1396,y:755,t:1527268426531};\\\", \\\"{x:1398,y:756,t:1527268426547};\\\", \\\"{x:1399,y:757,t:1527268426564};\\\", \\\"{x:1400,y:757,t:1527268426596};\\\", \\\"{x:1402,y:757,t:1527268426612};\\\", \\\"{x:1405,y:759,t:1527268426629};\\\", \\\"{x:1409,y:759,t:1527268426646};\\\", \\\"{x:1413,y:759,t:1527268426663};\\\", \\\"{x:1416,y:759,t:1527268426679};\\\", \\\"{x:1424,y:759,t:1527268426696};\\\", \\\"{x:1428,y:759,t:1527268426712};\\\", \\\"{x:1432,y:759,t:1527268426729};\\\", \\\"{x:1436,y:759,t:1527268426746};\\\", \\\"{x:1438,y:759,t:1527268426763};\\\", \\\"{x:1438,y:760,t:1527268426901};\\\", \\\"{x:1438,y:762,t:1527268426913};\\\", \\\"{x:1435,y:763,t:1527268426929};\\\", \\\"{x:1431,y:766,t:1527268426946};\\\", \\\"{x:1415,y:768,t:1527268426963};\\\", \\\"{x:1398,y:773,t:1527268426980};\\\", \\\"{x:1385,y:776,t:1527268426996};\\\", \\\"{x:1374,y:777,t:1527268427014};\\\", \\\"{x:1370,y:777,t:1527268427030};\\\", \\\"{x:1368,y:777,t:1527268427046};\\\", \\\"{x:1366,y:777,t:1527268427063};\\\", \\\"{x:1364,y:777,t:1527268427080};\\\", \\\"{x:1362,y:777,t:1527268427096};\\\", \\\"{x:1360,y:776,t:1527268427116};\\\", \\\"{x:1359,y:776,t:1527268427133};\\\", \\\"{x:1358,y:776,t:1527268427146};\\\", \\\"{x:1356,y:775,t:1527268427163};\\\", \\\"{x:1355,y:774,t:1527268427180};\\\", \\\"{x:1354,y:774,t:1527268427196};\\\", \\\"{x:1353,y:773,t:1527268427213};\\\", \\\"{x:1353,y:771,t:1527268427286};\\\", \\\"{x:1353,y:770,t:1527268427309};\\\", \\\"{x:1353,y:768,t:1527268427324};\\\", \\\"{x:1353,y:767,t:1527268427348};\\\", \\\"{x:1353,y:766,t:1527268427372};\\\", \\\"{x:1353,y:765,t:1527268427380};\\\", \\\"{x:1354,y:765,t:1527268427437};\\\", \\\"{x:1355,y:765,t:1527268427445};\\\", \\\"{x:1356,y:764,t:1527268427463};\\\", \\\"{x:1358,y:764,t:1527268427480};\\\", \\\"{x:1362,y:763,t:1527268427496};\\\", \\\"{x:1367,y:763,t:1527268427512};\\\", \\\"{x:1372,y:763,t:1527268427529};\\\", \\\"{x:1381,y:763,t:1527268427546};\\\", \\\"{x:1393,y:763,t:1527268427563};\\\", \\\"{x:1406,y:763,t:1527268427580};\\\", \\\"{x:1425,y:763,t:1527268427596};\\\", \\\"{x:1436,y:763,t:1527268427613};\\\", \\\"{x:1442,y:763,t:1527268427630};\\\", \\\"{x:1443,y:763,t:1527268427646};\\\", \\\"{x:1445,y:763,t:1527268427663};\\\", \\\"{x:1446,y:763,t:1527268427733};\\\", \\\"{x:1448,y:763,t:1527268428061};\\\", \\\"{x:1449,y:762,t:1527268428269};\\\", \\\"{x:1448,y:762,t:1527268428566};\\\", \\\"{x:1446,y:762,t:1527268428581};\\\", \\\"{x:1434,y:763,t:1527268428597};\\\", \\\"{x:1423,y:763,t:1527268428614};\\\", \\\"{x:1415,y:763,t:1527268428631};\\\", \\\"{x:1404,y:763,t:1527268428647};\\\", \\\"{x:1398,y:763,t:1527268428664};\\\", \\\"{x:1394,y:763,t:1527268428681};\\\", \\\"{x:1391,y:763,t:1527268428697};\\\", \\\"{x:1390,y:763,t:1527268428714};\\\", \\\"{x:1388,y:763,t:1527268428740};\\\", \\\"{x:1387,y:763,t:1527268428813};\\\", \\\"{x:1391,y:763,t:1527268429149};\\\", \\\"{x:1404,y:763,t:1527268429165};\\\", \\\"{x:1422,y:763,t:1527268429181};\\\", \\\"{x:1439,y:763,t:1527268429198};\\\", \\\"{x:1454,y:763,t:1527268429214};\\\", \\\"{x:1461,y:763,t:1527268429231};\\\", \\\"{x:1465,y:763,t:1527268429249};\\\", \\\"{x:1466,y:763,t:1527268429357};\\\", \\\"{x:1467,y:763,t:1527268429381};\\\", \\\"{x:1468,y:764,t:1527268429399};\\\", \\\"{x:1469,y:764,t:1527268429414};\\\", \\\"{x:1471,y:765,t:1527268429432};\\\", \\\"{x:1474,y:765,t:1527268429448};\\\", \\\"{x:1479,y:768,t:1527268429464};\\\", \\\"{x:1486,y:769,t:1527268429482};\\\", \\\"{x:1492,y:769,t:1527268429498};\\\", \\\"{x:1495,y:770,t:1527268429516};\\\", \\\"{x:1499,y:770,t:1527268429532};\\\", \\\"{x:1502,y:771,t:1527268429549};\\\", \\\"{x:1503,y:771,t:1527268429565};\\\", \\\"{x:1504,y:771,t:1527268429605};\\\", \\\"{x:1505,y:771,t:1527268429621};\\\", \\\"{x:1506,y:771,t:1527268429637};\\\", \\\"{x:1507,y:771,t:1527268429653};\\\", \\\"{x:1509,y:771,t:1527268429666};\\\", \\\"{x:1512,y:771,t:1527268429682};\\\", \\\"{x:1515,y:771,t:1527268429699};\\\", \\\"{x:1516,y:771,t:1527268429717};\\\", \\\"{x:1517,y:771,t:1527268429733};\\\", \\\"{x:1519,y:771,t:1527268429765};\\\", \\\"{x:1520,y:771,t:1527268429789};\\\", \\\"{x:1520,y:770,t:1527268429798};\\\", \\\"{x:1521,y:769,t:1527268429815};\\\", \\\"{x:1522,y:769,t:1527268429957};\\\", \\\"{x:1523,y:769,t:1527268429981};\\\", \\\"{x:1525,y:769,t:1527268430013};\\\", \\\"{x:1526,y:769,t:1527268430021};\\\", \\\"{x:1527,y:769,t:1527268430032};\\\", \\\"{x:1532,y:769,t:1527268430048};\\\", \\\"{x:1536,y:768,t:1527268430065};\\\", \\\"{x:1540,y:767,t:1527268430082};\\\", \\\"{x:1542,y:767,t:1527268430098};\\\", \\\"{x:1544,y:766,t:1527268430115};\\\", \\\"{x:1545,y:766,t:1527268430133};\\\", \\\"{x:1545,y:765,t:1527268430148};\\\", \\\"{x:1546,y:765,t:1527268430165};\\\", \\\"{x:1547,y:765,t:1527268430197};\\\", \\\"{x:1548,y:765,t:1527268430228};\\\", \\\"{x:1548,y:764,t:1527268430237};\\\", \\\"{x:1550,y:763,t:1527268430558};\\\", \\\"{x:1550,y:761,t:1527268430582};\\\", \\\"{x:1551,y:761,t:1527268430741};\\\", \\\"{x:1549,y:761,t:1527268430772};\\\", \\\"{x:1549,y:760,t:1527268442645};\\\", \\\"{x:1548,y:760,t:1527268445447};\\\", \\\"{x:1545,y:760,t:1527268445462};\\\", \\\"{x:1513,y:750,t:1527268445479};\\\", \\\"{x:1445,y:727,t:1527268445496};\\\", \\\"{x:1349,y:703,t:1527268445511};\\\", \\\"{x:1223,y:654,t:1527268445529};\\\", \\\"{x:1108,y:590,t:1527268445545};\\\", \\\"{x:1010,y:520,t:1527268445562};\\\", \\\"{x:889,y:444,t:1527268445579};\\\", \\\"{x:762,y:388,t:1527268445595};\\\", \\\"{x:636,y:337,t:1527268445611};\\\", \\\"{x:509,y:305,t:1527268445628};\\\", \\\"{x:370,y:284,t:1527268445645};\\\", \\\"{x:236,y:274,t:1527268445662};\\\", \\\"{x:60,y:264,t:1527268445679};\\\", \\\"{x:0,y:253,t:1527268445695};\\\", \\\"{x:0,y:247,t:1527268445712};\\\", \\\"{x:0,y:246,t:1527268445729};\\\", \\\"{x:0,y:245,t:1527268445744};\\\", \\\"{x:0,y:247,t:1527268445854};\\\", \\\"{x:2,y:250,t:1527268445862};\\\", \\\"{x:11,y:260,t:1527268445878};\\\", \\\"{x:28,y:279,t:1527268445896};\\\", \\\"{x:51,y:308,t:1527268445912};\\\", \\\"{x:71,y:328,t:1527268445929};\\\", \\\"{x:91,y:347,t:1527268445945};\\\", \\\"{x:110,y:367,t:1527268445961};\\\", \\\"{x:139,y:397,t:1527268445979};\\\", \\\"{x:179,y:428,t:1527268445996};\\\", \\\"{x:210,y:454,t:1527268446012};\\\", \\\"{x:226,y:466,t:1527268446029};\\\", \\\"{x:231,y:470,t:1527268446046};\\\", \\\"{x:226,y:469,t:1527268446127};\\\", \\\"{x:224,y:469,t:1527268446134};\\\", \\\"{x:223,y:469,t:1527268446146};\\\", \\\"{x:222,y:468,t:1527268446162};\\\", \\\"{x:220,y:468,t:1527268446178};\\\", \\\"{x:219,y:468,t:1527268446198};\\\", \\\"{x:218,y:468,t:1527268446211};\\\", \\\"{x:216,y:468,t:1527268446228};\\\", \\\"{x:212,y:466,t:1527268446247};\\\", \\\"{x:211,y:466,t:1527268446262};\\\", \\\"{x:209,y:466,t:1527268446279};\\\", \\\"{x:204,y:467,t:1527268446295};\\\", \\\"{x:193,y:473,t:1527268446312};\\\", \\\"{x:182,y:480,t:1527268446329};\\\", \\\"{x:167,y:487,t:1527268446347};\\\", \\\"{x:156,y:493,t:1527268446363};\\\", \\\"{x:150,y:495,t:1527268446378};\\\", \\\"{x:148,y:496,t:1527268446397};\\\", \\\"{x:146,y:497,t:1527268446414};\\\", \\\"{x:147,y:498,t:1527268446631};\\\", \\\"{x:148,y:499,t:1527268446647};\\\", \\\"{x:149,y:499,t:1527268446665};\\\", \\\"{x:151,y:499,t:1527268446681};\\\", \\\"{x:152,y:499,t:1527268446703};\\\", \\\"{x:153,y:499,t:1527268446715};\\\", \\\"{x:154,y:500,t:1527268446731};\\\", \\\"{x:156,y:500,t:1527268446981};\\\", \\\"{x:169,y:508,t:1527268446997};\\\", \\\"{x:210,y:527,t:1527268447015};\\\", \\\"{x:263,y:554,t:1527268447031};\\\", \\\"{x:312,y:581,t:1527268447047};\\\", \\\"{x:360,y:603,t:1527268447065};\\\", \\\"{x:403,y:628,t:1527268447082};\\\", \\\"{x:429,y:641,t:1527268447098};\\\", \\\"{x:454,y:657,t:1527268447115};\\\", \\\"{x:463,y:661,t:1527268447131};\\\", \\\"{x:466,y:664,t:1527268447148};\\\", \\\"{x:466,y:665,t:1527268447164};\\\", \\\"{x:467,y:667,t:1527268447181};\\\", \\\"{x:467,y:668,t:1527268447197};\\\", \\\"{x:468,y:671,t:1527268447215};\\\", \\\"{x:468,y:672,t:1527268447294};\\\", \\\"{x:470,y:674,t:1527268447302};\\\", \\\"{x:470,y:677,t:1527268447318};\\\", \\\"{x:472,y:679,t:1527268447332};\\\", \\\"{x:473,y:685,t:1527268447349};\\\", \\\"{x:474,y:690,t:1527268447366};\\\", \\\"{x:477,y:698,t:1527268447382};\\\", \\\"{x:480,y:712,t:1527268447399};\\\", \\\"{x:482,y:719,t:1527268447414};\\\", \\\"{x:483,y:724,t:1527268447432};\\\", \\\"{x:483,y:727,t:1527268447449};\\\", \\\"{x:484,y:729,t:1527268447464};\\\", \\\"{x:484,y:730,t:1527268447567};\\\", \\\"{x:485,y:730,t:1527268447582};\\\", \\\"{x:486,y:733,t:1527268447599};\\\", \\\"{x:488,y:738,t:1527268447615};\\\", \\\"{x:488,y:739,t:1527268447631};\\\", \\\"{x:488,y:741,t:1527268447649};\\\", \\\"{x:489,y:741,t:1527268447679};\\\", \\\"{x:488,y:741,t:1527268448030};\\\", \\\"{x:487,y:740,t:1527268448038};\\\", \\\"{x:486,y:740,t:1527268448062};\\\", \\\"{x:485,y:740,t:1527268448110};\\\", \\\"{x:485,y:739,t:1527268448126};\\\", \\\"{x:483,y:739,t:1527268448159};\\\", \\\"{x:482,y:738,t:1527268448263};\\\", \\\"{x:480,y:738,t:1527268448303};\\\", \\\"{x:479,y:738,t:1527268448358};\\\", \\\"{x:479,y:737,t:1527268448406};\\\", \\\"{x:480,y:734,t:1527268448446};\\\", \\\"{x:483,y:728,t:1527268448455};\\\", \\\"{x:484,y:726,t:1527268448465};\\\", \\\"{x:485,y:722,t:1527268448482};\\\", \\\"{x:485,y:721,t:1527268448734};\\\" ] }, { \\\"rt\\\": 49757, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 534709, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:721,t:1527268449750};\\\", \\\"{x:484,y:719,t:1527268449878};\\\", \\\"{x:484,y:715,t:1527268449885};\\\", \\\"{x:484,y:705,t:1527268449900};\\\", \\\"{x:484,y:645,t:1527268449917};\\\", \\\"{x:468,y:556,t:1527268449934};\\\", \\\"{x:466,y:527,t:1527268449950};\\\", \\\"{x:463,y:499,t:1527268449967};\\\", \\\"{x:460,y:468,t:1527268449984};\\\", \\\"{x:456,y:447,t:1527268450001};\\\", \\\"{x:455,y:438,t:1527268450016};\\\", \\\"{x:453,y:432,t:1527268450034};\\\", \\\"{x:452,y:431,t:1527268450050};\\\", \\\"{x:452,y:430,t:1527268450086};\\\", \\\"{x:451,y:430,t:1527268450110};\\\", \\\"{x:450,y:430,t:1527268450119};\\\", \\\"{x:447,y:427,t:1527268450134};\\\", \\\"{x:445,y:427,t:1527268450150};\\\", \\\"{x:444,y:426,t:1527268450166};\\\", \\\"{x:442,y:426,t:1527268450184};\\\", \\\"{x:441,y:426,t:1527268450200};\\\", \\\"{x:440,y:426,t:1527268450230};\\\", \\\"{x:439,y:426,t:1527268450262};\\\", \\\"{x:439,y:427,t:1527268450279};\\\", \\\"{x:437,y:429,t:1527268450287};\\\", \\\"{x:436,y:431,t:1527268450300};\\\", \\\"{x:435,y:434,t:1527268450317};\\\", \\\"{x:434,y:435,t:1527268450333};\\\", \\\"{x:434,y:437,t:1527268450350};\\\", \\\"{x:434,y:438,t:1527268450407};\\\", \\\"{x:435,y:438,t:1527268450438};\\\", \\\"{x:436,y:439,t:1527268450451};\\\", \\\"{x:437,y:440,t:1527268450478};\\\", \\\"{x:438,y:440,t:1527268450503};\\\", \\\"{x:440,y:444,t:1527268450519};\\\", \\\"{x:440,y:446,t:1527268450535};\\\", \\\"{x:440,y:448,t:1527268450551};\\\", \\\"{x:440,y:450,t:1527268450568};\\\", \\\"{x:441,y:451,t:1527268450638};\\\", \\\"{x:442,y:451,t:1527268450654};\\\", \\\"{x:443,y:452,t:1527268450670};\\\", \\\"{x:444,y:454,t:1527268450686};\\\", \\\"{x:444,y:455,t:1527268450702};\\\", \\\"{x:444,y:459,t:1527268450718};\\\", \\\"{x:444,y:461,t:1527268450735};\\\", \\\"{x:444,y:465,t:1527268450751};\\\", \\\"{x:443,y:466,t:1527268450768};\\\", \\\"{x:443,y:467,t:1527268450785};\\\", \\\"{x:444,y:466,t:1527268451030};\\\", \\\"{x:445,y:464,t:1527268451038};\\\", \\\"{x:450,y:462,t:1527268451051};\\\", \\\"{x:457,y:456,t:1527268451068};\\\", \\\"{x:461,y:452,t:1527268451084};\\\", \\\"{x:470,y:446,t:1527268451101};\\\", \\\"{x:476,y:442,t:1527268451118};\\\", \\\"{x:480,y:441,t:1527268451135};\\\", \\\"{x:482,y:440,t:1527268451151};\\\", \\\"{x:484,y:440,t:1527268451168};\\\", \\\"{x:485,y:440,t:1527268451185};\\\", \\\"{x:489,y:440,t:1527268451201};\\\", \\\"{x:496,y:440,t:1527268451218};\\\", \\\"{x:507,y:443,t:1527268451235};\\\", \\\"{x:515,y:445,t:1527268451252};\\\", \\\"{x:522,y:446,t:1527268451268};\\\", \\\"{x:529,y:448,t:1527268451285};\\\", \\\"{x:536,y:448,t:1527268451302};\\\", \\\"{x:537,y:448,t:1527268451318};\\\", \\\"{x:538,y:448,t:1527268451335};\\\", \\\"{x:539,y:448,t:1527268451351};\\\", \\\"{x:540,y:449,t:1527268451590};\\\", \\\"{x:541,y:450,t:1527268451631};\\\", \\\"{x:543,y:450,t:1527268451646};\\\", \\\"{x:545,y:451,t:1527268451655};\\\", \\\"{x:547,y:451,t:1527268451669};\\\", \\\"{x:554,y:452,t:1527268451685};\\\", \\\"{x:579,y:456,t:1527268451702};\\\", \\\"{x:596,y:458,t:1527268451718};\\\", \\\"{x:612,y:461,t:1527268451735};\\\", \\\"{x:624,y:462,t:1527268451752};\\\", \\\"{x:630,y:463,t:1527268451769};\\\", \\\"{x:632,y:463,t:1527268451785};\\\", \\\"{x:633,y:464,t:1527268451802};\\\", \\\"{x:634,y:464,t:1527268451935};\\\", \\\"{x:635,y:464,t:1527268451958};\\\", \\\"{x:638,y:464,t:1527268451969};\\\", \\\"{x:641,y:464,t:1527268451985};\\\", \\\"{x:645,y:464,t:1527268452002};\\\", \\\"{x:650,y:464,t:1527268452019};\\\", \\\"{x:653,y:464,t:1527268452035};\\\", \\\"{x:655,y:464,t:1527268452052};\\\", \\\"{x:656,y:464,t:1527268452070};\\\", \\\"{x:657,y:464,t:1527268452150};\\\", \\\"{x:658,y:464,t:1527268452174};\\\", \\\"{x:659,y:465,t:1527268452186};\\\", \\\"{x:661,y:465,t:1527268452202};\\\", \\\"{x:666,y:467,t:1527268452219};\\\", \\\"{x:673,y:470,t:1527268452236};\\\", \\\"{x:690,y:476,t:1527268452252};\\\", \\\"{x:716,y:483,t:1527268452269};\\\", \\\"{x:777,y:494,t:1527268452287};\\\", \\\"{x:812,y:500,t:1527268452301};\\\", \\\"{x:845,y:500,t:1527268452319};\\\", \\\"{x:870,y:503,t:1527268452336};\\\", \\\"{x:885,y:503,t:1527268452351};\\\", \\\"{x:893,y:505,t:1527268452368};\\\", \\\"{x:894,y:505,t:1527268452385};\\\", \\\"{x:895,y:505,t:1527268452413};\\\", \\\"{x:897,y:505,t:1527268452478};\\\", \\\"{x:899,y:505,t:1527268452486};\\\", \\\"{x:907,y:506,t:1527268452502};\\\", \\\"{x:917,y:507,t:1527268452518};\\\", \\\"{x:935,y:510,t:1527268452535};\\\", \\\"{x:960,y:515,t:1527268452554};\\\", \\\"{x:999,y:518,t:1527268452569};\\\", \\\"{x:1044,y:523,t:1527268452585};\\\", \\\"{x:1094,y:529,t:1527268452603};\\\", \\\"{x:1128,y:529,t:1527268452619};\\\", \\\"{x:1164,y:529,t:1527268452636};\\\", \\\"{x:1193,y:529,t:1527268452653};\\\", \\\"{x:1216,y:529,t:1527268452669};\\\", \\\"{x:1220,y:529,t:1527268452686};\\\", \\\"{x:1200,y:527,t:1527268465623};\\\", \\\"{x:1163,y:522,t:1527268465630};\\\", \\\"{x:1106,y:513,t:1527268465643};\\\", \\\"{x:975,y:486,t:1527268465660};\\\", \\\"{x:870,y:458,t:1527268465676};\\\", \\\"{x:839,y:445,t:1527268465693};\\\", \\\"{x:838,y:445,t:1527268465726};\\\", \\\"{x:831,y:445,t:1527268465742};\\\", \\\"{x:781,y:466,t:1527268465760};\\\", \\\"{x:688,y:506,t:1527268465777};\\\", \\\"{x:638,y:521,t:1527268465793};\\\", \\\"{x:628,y:521,t:1527268465809};\\\", \\\"{x:628,y:519,t:1527268465893};\\\", \\\"{x:634,y:480,t:1527268465901};\\\", \\\"{x:646,y:347,t:1527268465913};\\\", \\\"{x:644,y:32,t:1527268465929};\\\", \\\"{x:611,y:0,t:1527268465946};\\\", \\\"{x:579,y:0,t:1527268465964};\\\", \\\"{x:561,y:0,t:1527268465980};\\\", \\\"{x:550,y:0,t:1527268465997};\\\", \\\"{x:547,y:0,t:1527268466013};\\\", \\\"{x:559,y:13,t:1527268466030};\\\", \\\"{x:590,y:36,t:1527268466046};\\\", \\\"{x:632,y:75,t:1527268466064};\\\", \\\"{x:694,y:139,t:1527268466080};\\\", \\\"{x:762,y:207,t:1527268466096};\\\", \\\"{x:810,y:262,t:1527268466114};\\\", \\\"{x:822,y:278,t:1527268466130};\\\", \\\"{x:823,y:284,t:1527268466146};\\\", \\\"{x:823,y:289,t:1527268466163};\\\", \\\"{x:823,y:292,t:1527268466180};\\\", \\\"{x:822,y:297,t:1527268466196};\\\", \\\"{x:821,y:306,t:1527268466213};\\\", \\\"{x:821,y:330,t:1527268466231};\\\", \\\"{x:823,y:346,t:1527268466246};\\\", \\\"{x:825,y:363,t:1527268466264};\\\", \\\"{x:828,y:377,t:1527268466281};\\\", \\\"{x:828,y:391,t:1527268466297};\\\", \\\"{x:828,y:414,t:1527268466314};\\\", \\\"{x:824,y:445,t:1527268466331};\\\", \\\"{x:812,y:482,t:1527268466348};\\\", \\\"{x:800,y:509,t:1527268466364};\\\", \\\"{x:792,y:521,t:1527268466381};\\\", \\\"{x:781,y:530,t:1527268466397};\\\", \\\"{x:761,y:541,t:1527268466413};\\\", \\\"{x:745,y:547,t:1527268466430};\\\", \\\"{x:729,y:551,t:1527268466447};\\\", \\\"{x:713,y:557,t:1527268466463};\\\", \\\"{x:696,y:561,t:1527268466480};\\\", \\\"{x:682,y:563,t:1527268466497};\\\", \\\"{x:669,y:566,t:1527268466513};\\\", \\\"{x:655,y:567,t:1527268466530};\\\", \\\"{x:644,y:570,t:1527268466547};\\\", \\\"{x:642,y:570,t:1527268466564};\\\", \\\"{x:641,y:570,t:1527268466580};\\\", \\\"{x:640,y:571,t:1527268466646};\\\", \\\"{x:640,y:572,t:1527268466670};\\\", \\\"{x:639,y:573,t:1527268466681};\\\", \\\"{x:638,y:574,t:1527268466697};\\\", \\\"{x:635,y:576,t:1527268466714};\\\", \\\"{x:634,y:577,t:1527268466731};\\\", \\\"{x:634,y:578,t:1527268466747};\\\", \\\"{x:631,y:579,t:1527268466765};\\\", \\\"{x:630,y:579,t:1527268466781};\\\", \\\"{x:629,y:579,t:1527268466822};\\\", \\\"{x:628,y:579,t:1527268466831};\\\", \\\"{x:627,y:580,t:1527268466848};\\\", \\\"{x:625,y:580,t:1527268466864};\\\", \\\"{x:624,y:580,t:1527268466881};\\\", \\\"{x:623,y:580,t:1527268466897};\\\", \\\"{x:622,y:580,t:1527268466914};\\\", \\\"{x:621,y:580,t:1527268466934};\\\", \\\"{x:620,y:580,t:1527268466959};\\\", \\\"{x:619,y:580,t:1527268466982};\\\", \\\"{x:618,y:580,t:1527268466998};\\\", \\\"{x:616,y:580,t:1527268467015};\\\", \\\"{x:615,y:580,t:1527268467032};\\\", \\\"{x:614,y:579,t:1527268467054};\\\", \\\"{x:625,y:576,t:1527268467590};\\\", \\\"{x:644,y:575,t:1527268467599};\\\", \\\"{x:697,y:567,t:1527268467614};\\\", \\\"{x:756,y:559,t:1527268467631};\\\", \\\"{x:826,y:548,t:1527268467647};\\\", \\\"{x:884,y:540,t:1527268467664};\\\", \\\"{x:940,y:532,t:1527268467681};\\\", \\\"{x:991,y:524,t:1527268467698};\\\", \\\"{x:1027,y:519,t:1527268467714};\\\", \\\"{x:1046,y:517,t:1527268467731};\\\", \\\"{x:1063,y:515,t:1527268467749};\\\", \\\"{x:1073,y:514,t:1527268467764};\\\", \\\"{x:1083,y:514,t:1527268467782};\\\", \\\"{x:1089,y:514,t:1527268467798};\\\", \\\"{x:1096,y:514,t:1527268467814};\\\", \\\"{x:1098,y:514,t:1527268467831};\\\", \\\"{x:1099,y:514,t:1527268467848};\\\", \\\"{x:1100,y:513,t:1527268488279};\\\", \\\"{x:1100,y:512,t:1527268488294};\\\", \\\"{x:1102,y:510,t:1527268488302};\\\", \\\"{x:1111,y:504,t:1527268488316};\\\", \\\"{x:1138,y:495,t:1527268488333};\\\", \\\"{x:1180,y:483,t:1527268488350};\\\", \\\"{x:1203,y:477,t:1527268488366};\\\", \\\"{x:1217,y:477,t:1527268488382};\\\", \\\"{x:1223,y:477,t:1527268488400};\\\", \\\"{x:1227,y:483,t:1527268488416};\\\", \\\"{x:1239,y:520,t:1527268488433};\\\", \\\"{x:1246,y:578,t:1527268488450};\\\", \\\"{x:1248,y:643,t:1527268488466};\\\", \\\"{x:1248,y:702,t:1527268488483};\\\", \\\"{x:1242,y:747,t:1527268488500};\\\", \\\"{x:1236,y:770,t:1527268488516};\\\", \\\"{x:1233,y:777,t:1527268488533};\\\", \\\"{x:1233,y:778,t:1527268488550};\\\", \\\"{x:1233,y:779,t:1527268488670};\\\", \\\"{x:1233,y:777,t:1527268488782};\\\", \\\"{x:1233,y:772,t:1527268488800};\\\", \\\"{x:1234,y:768,t:1527268488817};\\\", \\\"{x:1238,y:762,t:1527268488832};\\\", \\\"{x:1245,y:753,t:1527268488850};\\\", \\\"{x:1253,y:740,t:1527268488867};\\\", \\\"{x:1262,y:731,t:1527268488882};\\\", \\\"{x:1269,y:720,t:1527268488899};\\\", \\\"{x:1276,y:711,t:1527268488916};\\\", \\\"{x:1280,y:702,t:1527268488932};\\\", \\\"{x:1284,y:695,t:1527268488949};\\\", \\\"{x:1285,y:689,t:1527268488966};\\\", \\\"{x:1286,y:687,t:1527268488983};\\\", \\\"{x:1287,y:685,t:1527268489000};\\\", \\\"{x:1287,y:684,t:1527268489016};\\\", \\\"{x:1288,y:684,t:1527268489033};\\\", \\\"{x:1288,y:683,t:1527268489479};\\\", \\\"{x:1288,y:682,t:1527268489486};\\\", \\\"{x:1288,y:681,t:1527268489503};\\\", \\\"{x:1289,y:680,t:1527268489534};\\\", \\\"{x:1290,y:679,t:1527268489566};\\\", \\\"{x:1291,y:677,t:1527268489583};\\\", \\\"{x:1292,y:674,t:1527268489601};\\\", \\\"{x:1294,y:670,t:1527268489617};\\\", \\\"{x:1295,y:667,t:1527268489634};\\\", \\\"{x:1297,y:662,t:1527268489650};\\\", \\\"{x:1298,y:661,t:1527268489666};\\\", \\\"{x:1298,y:660,t:1527268489683};\\\", \\\"{x:1299,y:659,t:1527268489700};\\\", \\\"{x:1299,y:657,t:1527268489717};\\\", \\\"{x:1301,y:656,t:1527268489831};\\\", \\\"{x:1301,y:655,t:1527268489847};\\\", \\\"{x:1302,y:654,t:1527268489854};\\\", \\\"{x:1302,y:652,t:1527268489870};\\\", \\\"{x:1302,y:651,t:1527268489884};\\\", \\\"{x:1304,y:649,t:1527268489901};\\\", \\\"{x:1307,y:646,t:1527268489918};\\\", \\\"{x:1307,y:645,t:1527268489942};\\\", \\\"{x:1308,y:644,t:1527268490087};\\\", \\\"{x:1310,y:642,t:1527268490359};\\\", \\\"{x:1311,y:641,t:1527268490368};\\\", \\\"{x:1313,y:637,t:1527268490384};\\\", \\\"{x:1314,y:635,t:1527268490401};\\\", \\\"{x:1315,y:635,t:1527268490438};\\\", \\\"{x:1316,y:634,t:1527268490510};\\\", \\\"{x:1317,y:633,t:1527268490518};\\\", \\\"{x:1319,y:630,t:1527268490534};\\\", \\\"{x:1322,y:625,t:1527268490551};\\\", \\\"{x:1325,y:622,t:1527268490568};\\\", \\\"{x:1326,y:619,t:1527268490585};\\\", \\\"{x:1328,y:617,t:1527268490601};\\\", \\\"{x:1329,y:615,t:1527268490618};\\\", \\\"{x:1330,y:614,t:1527268490775};\\\", \\\"{x:1332,y:611,t:1527268490785};\\\", \\\"{x:1336,y:603,t:1527268490801};\\\", \\\"{x:1343,y:592,t:1527268490817};\\\", \\\"{x:1351,y:579,t:1527268490835};\\\", \\\"{x:1360,y:563,t:1527268490852};\\\", \\\"{x:1365,y:549,t:1527268490868};\\\", \\\"{x:1369,y:541,t:1527268490885};\\\", \\\"{x:1369,y:538,t:1527268490902};\\\", \\\"{x:1368,y:538,t:1527268491014};\\\", \\\"{x:1366,y:539,t:1527268491022};\\\", \\\"{x:1364,y:541,t:1527268491034};\\\", \\\"{x:1357,y:544,t:1527268491052};\\\", \\\"{x:1350,y:548,t:1527268491069};\\\", \\\"{x:1339,y:553,t:1527268491085};\\\", \\\"{x:1322,y:561,t:1527268491102};\\\", \\\"{x:1310,y:565,t:1527268491118};\\\", \\\"{x:1301,y:567,t:1527268491135};\\\", \\\"{x:1298,y:569,t:1527268491152};\\\", \\\"{x:1297,y:569,t:1527268491169};\\\", \\\"{x:1296,y:569,t:1527268491185};\\\", \\\"{x:1295,y:569,t:1527268491222};\\\", \\\"{x:1294,y:569,t:1527268491235};\\\", \\\"{x:1293,y:570,t:1527268491270};\\\", \\\"{x:1291,y:572,t:1527268491310};\\\", \\\"{x:1290,y:573,t:1527268491319};\\\", \\\"{x:1287,y:577,t:1527268491335};\\\", \\\"{x:1284,y:581,t:1527268491352};\\\", \\\"{x:1282,y:584,t:1527268491369};\\\", \\\"{x:1281,y:588,t:1527268491385};\\\", \\\"{x:1280,y:590,t:1527268491415};\\\", \\\"{x:1280,y:591,t:1527268491454};\\\", \\\"{x:1280,y:592,t:1527268491478};\\\", \\\"{x:1280,y:593,t:1527268491486};\\\", \\\"{x:1282,y:596,t:1527268491502};\\\", \\\"{x:1282,y:600,t:1527268491519};\\\", \\\"{x:1282,y:604,t:1527268491536};\\\", \\\"{x:1282,y:610,t:1527268491551};\\\", \\\"{x:1282,y:616,t:1527268491569};\\\", \\\"{x:1282,y:623,t:1527268491586};\\\", \\\"{x:1282,y:630,t:1527268491603};\\\", \\\"{x:1282,y:635,t:1527268491619};\\\", \\\"{x:1282,y:637,t:1527268491636};\\\", \\\"{x:1282,y:639,t:1527268491652};\\\", \\\"{x:1282,y:640,t:1527268491743};\\\", \\\"{x:1282,y:641,t:1527268491758};\\\", \\\"{x:1282,y:642,t:1527268491769};\\\", \\\"{x:1282,y:645,t:1527268491785};\\\", \\\"{x:1282,y:647,t:1527268491802};\\\", \\\"{x:1282,y:648,t:1527268491819};\\\", \\\"{x:1281,y:650,t:1527268491836};\\\", \\\"{x:1281,y:651,t:1527268491853};\\\", \\\"{x:1283,y:647,t:1527268491975};\\\", \\\"{x:1283,y:642,t:1527268491986};\\\", \\\"{x:1288,y:633,t:1527268492002};\\\", \\\"{x:1293,y:625,t:1527268492018};\\\", \\\"{x:1299,y:616,t:1527268492036};\\\", \\\"{x:1306,y:609,t:1527268492053};\\\", \\\"{x:1314,y:600,t:1527268492069};\\\", \\\"{x:1325,y:587,t:1527268492086};\\\", \\\"{x:1334,y:577,t:1527268492102};\\\", \\\"{x:1341,y:568,t:1527268492119};\\\", \\\"{x:1350,y:561,t:1527268492136};\\\", \\\"{x:1354,y:555,t:1527268492153};\\\", \\\"{x:1359,y:550,t:1527268492169};\\\", \\\"{x:1363,y:545,t:1527268492186};\\\", \\\"{x:1366,y:542,t:1527268492203};\\\", \\\"{x:1367,y:542,t:1527268492375};\\\", \\\"{x:1368,y:542,t:1527268492386};\\\", \\\"{x:1370,y:542,t:1527268492403};\\\", \\\"{x:1375,y:542,t:1527268492420};\\\", \\\"{x:1378,y:542,t:1527268492436};\\\", \\\"{x:1383,y:542,t:1527268492453};\\\", \\\"{x:1394,y:545,t:1527268492470};\\\", \\\"{x:1400,y:548,t:1527268492486};\\\", \\\"{x:1410,y:556,t:1527268492503};\\\", \\\"{x:1422,y:564,t:1527268492521};\\\", \\\"{x:1433,y:570,t:1527268492536};\\\", \\\"{x:1438,y:572,t:1527268492553};\\\", \\\"{x:1441,y:573,t:1527268492570};\\\", \\\"{x:1443,y:573,t:1527268492586};\\\", \\\"{x:1446,y:573,t:1527268492603};\\\", \\\"{x:1447,y:573,t:1527268492622};\\\", \\\"{x:1448,y:573,t:1527268492662};\\\", \\\"{x:1449,y:573,t:1527268492686};\\\", \\\"{x:1451,y:573,t:1527268492703};\\\", \\\"{x:1455,y:573,t:1527268492720};\\\", \\\"{x:1458,y:573,t:1527268492737};\\\", \\\"{x:1464,y:576,t:1527268492753};\\\", \\\"{x:1468,y:577,t:1527268492770};\\\", \\\"{x:1472,y:577,t:1527268492786};\\\", \\\"{x:1473,y:577,t:1527268492804};\\\", \\\"{x:1476,y:577,t:1527268492820};\\\", \\\"{x:1480,y:577,t:1527268492837};\\\", \\\"{x:1485,y:575,t:1527268492853};\\\", \\\"{x:1492,y:571,t:1527268492870};\\\", \\\"{x:1495,y:570,t:1527268492886};\\\", \\\"{x:1497,y:568,t:1527268492903};\\\", \\\"{x:1498,y:568,t:1527268492920};\\\", \\\"{x:1496,y:568,t:1527268493198};\\\", \\\"{x:1492,y:568,t:1527268493206};\\\", \\\"{x:1485,y:567,t:1527268493220};\\\", \\\"{x:1475,y:566,t:1527268493237};\\\", \\\"{x:1461,y:562,t:1527268493253};\\\", \\\"{x:1456,y:561,t:1527268493270};\\\", \\\"{x:1452,y:559,t:1527268493287};\\\", \\\"{x:1448,y:558,t:1527268493304};\\\", \\\"{x:1447,y:557,t:1527268493320};\\\", \\\"{x:1448,y:557,t:1527268493462};\\\", \\\"{x:1449,y:557,t:1527268493478};\\\", \\\"{x:1451,y:558,t:1527268493487};\\\", \\\"{x:1453,y:559,t:1527268493504};\\\", \\\"{x:1455,y:560,t:1527268493521};\\\", \\\"{x:1457,y:560,t:1527268493537};\\\", \\\"{x:1460,y:560,t:1527268493554};\\\", \\\"{x:1461,y:562,t:1527268493572};\\\", \\\"{x:1462,y:562,t:1527268493587};\\\", \\\"{x:1464,y:562,t:1527268493604};\\\", \\\"{x:1468,y:563,t:1527268493621};\\\", \\\"{x:1469,y:563,t:1527268493646};\\\", \\\"{x:1470,y:563,t:1527268493654};\\\", \\\"{x:1471,y:564,t:1527268493686};\\\", \\\"{x:1471,y:565,t:1527268493774};\\\", \\\"{x:1472,y:565,t:1527268493814};\\\", \\\"{x:1473,y:565,t:1527268494014};\\\", \\\"{x:1474,y:565,t:1527268494022};\\\", \\\"{x:1475,y:565,t:1527268494038};\\\", \\\"{x:1476,y:565,t:1527268494063};\\\", \\\"{x:1477,y:564,t:1527268494078};\\\", \\\"{x:1479,y:564,t:1527268494088};\\\", \\\"{x:1480,y:563,t:1527268494104};\\\", \\\"{x:1483,y:562,t:1527268494121};\\\", \\\"{x:1487,y:562,t:1527268494138};\\\", \\\"{x:1495,y:562,t:1527268494154};\\\", \\\"{x:1505,y:562,t:1527268494171};\\\", \\\"{x:1517,y:563,t:1527268494188};\\\", \\\"{x:1531,y:564,t:1527268494204};\\\", \\\"{x:1549,y:566,t:1527268494221};\\\", \\\"{x:1561,y:566,t:1527268494238};\\\", \\\"{x:1567,y:566,t:1527268494254};\\\", \\\"{x:1572,y:566,t:1527268494271};\\\", \\\"{x:1577,y:566,t:1527268494288};\\\", \\\"{x:1581,y:566,t:1527268494305};\\\", \\\"{x:1583,y:566,t:1527268494321};\\\", \\\"{x:1586,y:566,t:1527268494338};\\\", \\\"{x:1590,y:566,t:1527268494355};\\\", \\\"{x:1597,y:566,t:1527268494371};\\\", \\\"{x:1605,y:566,t:1527268494388};\\\", \\\"{x:1613,y:566,t:1527268494406};\\\", \\\"{x:1623,y:566,t:1527268494421};\\\", \\\"{x:1639,y:567,t:1527268494438};\\\", \\\"{x:1648,y:569,t:1527268494455};\\\", \\\"{x:1654,y:569,t:1527268494472};\\\", \\\"{x:1658,y:571,t:1527268494488};\\\", \\\"{x:1661,y:572,t:1527268494505};\\\", \\\"{x:1664,y:573,t:1527268494520};\\\", \\\"{x:1666,y:573,t:1527268494537};\\\", \\\"{x:1669,y:573,t:1527268494554};\\\", \\\"{x:1675,y:573,t:1527268494570};\\\", \\\"{x:1676,y:573,t:1527268494587};\\\", \\\"{x:1678,y:573,t:1527268494604};\\\", \\\"{x:1679,y:573,t:1527268494620};\\\", \\\"{x:1680,y:573,t:1527268494637};\\\", \\\"{x:1681,y:573,t:1527268494935};\\\", \\\"{x:1682,y:573,t:1527268494950};\\\", \\\"{x:1684,y:573,t:1527268494958};\\\", \\\"{x:1685,y:572,t:1527268494972};\\\", \\\"{x:1687,y:571,t:1527268494988};\\\", \\\"{x:1687,y:570,t:1527268495005};\\\", \\\"{x:1688,y:570,t:1527268495022};\\\", \\\"{x:1688,y:569,t:1527268495326};\\\", \\\"{x:1688,y:568,t:1527268495339};\\\", \\\"{x:1667,y:563,t:1527268495355};\\\", \\\"{x:1640,y:559,t:1527268495372};\\\", \\\"{x:1599,y:559,t:1527268495389};\\\", \\\"{x:1551,y:559,t:1527268495405};\\\", \\\"{x:1490,y:571,t:1527268495422};\\\", \\\"{x:1441,y:582,t:1527268495439};\\\", \\\"{x:1422,y:585,t:1527268495454};\\\", \\\"{x:1419,y:585,t:1527268495472};\\\", \\\"{x:1418,y:585,t:1527268495489};\\\", \\\"{x:1417,y:585,t:1527268495557};\\\", \\\"{x:1413,y:585,t:1527268495702};\\\", \\\"{x:1408,y:585,t:1527268495710};\\\", \\\"{x:1402,y:585,t:1527268495722};\\\", \\\"{x:1384,y:585,t:1527268495740};\\\", \\\"{x:1368,y:585,t:1527268495756};\\\", \\\"{x:1355,y:585,t:1527268495772};\\\", \\\"{x:1345,y:585,t:1527268495789};\\\", \\\"{x:1332,y:585,t:1527268495806};\\\", \\\"{x:1327,y:585,t:1527268495822};\\\", \\\"{x:1320,y:588,t:1527268495839};\\\", \\\"{x:1312,y:591,t:1527268495856};\\\", \\\"{x:1303,y:594,t:1527268495872};\\\", \\\"{x:1297,y:598,t:1527268495889};\\\", \\\"{x:1293,y:599,t:1527268495906};\\\", \\\"{x:1293,y:600,t:1527268495922};\\\", \\\"{x:1292,y:600,t:1527268495942};\\\", \\\"{x:1291,y:601,t:1527268495958};\\\", \\\"{x:1290,y:602,t:1527268495973};\\\", \\\"{x:1289,y:605,t:1527268495989};\\\", \\\"{x:1285,y:615,t:1527268496006};\\\", \\\"{x:1282,y:620,t:1527268496022};\\\", \\\"{x:1281,y:628,t:1527268496039};\\\", \\\"{x:1281,y:632,t:1527268496056};\\\", \\\"{x:1279,y:639,t:1527268496073};\\\", \\\"{x:1278,y:646,t:1527268496089};\\\", \\\"{x:1276,y:653,t:1527268496105};\\\", \\\"{x:1274,y:661,t:1527268496123};\\\", \\\"{x:1273,y:673,t:1527268496139};\\\", \\\"{x:1273,y:690,t:1527268496156};\\\", \\\"{x:1270,y:703,t:1527268496172};\\\", \\\"{x:1270,y:716,t:1527268496188};\\\", \\\"{x:1267,y:739,t:1527268496205};\\\", \\\"{x:1265,y:750,t:1527268496223};\\\", \\\"{x:1264,y:758,t:1527268496238};\\\", \\\"{x:1263,y:762,t:1527268496255};\\\", \\\"{x:1263,y:766,t:1527268496272};\\\", \\\"{x:1263,y:770,t:1527268496288};\\\", \\\"{x:1263,y:773,t:1527268496305};\\\", \\\"{x:1263,y:777,t:1527268496322};\\\", \\\"{x:1263,y:783,t:1527268496339};\\\", \\\"{x:1260,y:795,t:1527268496355};\\\", \\\"{x:1258,y:809,t:1527268496373};\\\", \\\"{x:1246,y:841,t:1527268496389};\\\", \\\"{x:1232,y:872,t:1527268496406};\\\", \\\"{x:1207,y:912,t:1527268496423};\\\", \\\"{x:1167,y:953,t:1527268496440};\\\", \\\"{x:1115,y:985,t:1527268496456};\\\", \\\"{x:1051,y:1012,t:1527268496473};\\\", \\\"{x:982,y:1029,t:1527268496490};\\\", \\\"{x:897,y:1039,t:1527268496506};\\\", \\\"{x:818,y:1044,t:1527268496523};\\\", \\\"{x:730,y:1050,t:1527268496540};\\\", \\\"{x:639,y:1050,t:1527268496556};\\\", \\\"{x:567,y:1044,t:1527268496573};\\\", \\\"{x:492,y:1025,t:1527268496588};\\\", \\\"{x:464,y:1017,t:1527268496605};\\\", \\\"{x:441,y:1007,t:1527268496622};\\\", \\\"{x:421,y:994,t:1527268496639};\\\", \\\"{x:407,y:983,t:1527268496656};\\\", \\\"{x:397,y:968,t:1527268496673};\\\", \\\"{x:388,y:952,t:1527268496689};\\\", \\\"{x:378,y:929,t:1527268496705};\\\", \\\"{x:368,y:900,t:1527268496722};\\\", \\\"{x:355,y:876,t:1527268496739};\\\", \\\"{x:341,y:853,t:1527268496757};\\\", \\\"{x:330,y:833,t:1527268496773};\\\", \\\"{x:323,y:807,t:1527268496789};\\\", \\\"{x:323,y:792,t:1527268496806};\\\", \\\"{x:330,y:771,t:1527268496822};\\\", \\\"{x:341,y:751,t:1527268496840};\\\", \\\"{x:355,y:734,t:1527268496857};\\\", \\\"{x:361,y:729,t:1527268496873};\\\", \\\"{x:364,y:727,t:1527268496890};\\\", \\\"{x:365,y:727,t:1527268496918};\\\", \\\"{x:368,y:727,t:1527268496926};\\\", \\\"{x:370,y:727,t:1527268496940};\\\", \\\"{x:376,y:728,t:1527268496957};\\\", \\\"{x:379,y:731,t:1527268496973};\\\", \\\"{x:384,y:732,t:1527268496990};\\\", \\\"{x:386,y:733,t:1527268497007};\\\", \\\"{x:387,y:734,t:1527268497023};\\\", \\\"{x:391,y:735,t:1527268497039};\\\", \\\"{x:392,y:737,t:1527268497057};\\\", \\\"{x:393,y:738,t:1527268497073};\\\", \\\"{x:396,y:739,t:1527268497090};\\\", \\\"{x:398,y:740,t:1527268497107};\\\", \\\"{x:400,y:741,t:1527268497123};\\\", \\\"{x:403,y:742,t:1527268497140};\\\", \\\"{x:407,y:744,t:1527268497157};\\\", \\\"{x:413,y:747,t:1527268497174};\\\", \\\"{x:415,y:748,t:1527268497189};\\\", \\\"{x:417,y:749,t:1527268497207};\\\", \\\"{x:419,y:749,t:1527268497224};\\\", \\\"{x:424,y:749,t:1527268497241};\\\", \\\"{x:439,y:744,t:1527268497257};\\\", \\\"{x:457,y:734,t:1527268497275};\\\", \\\"{x:474,y:723,t:1527268497289};\\\", \\\"{x:486,y:715,t:1527268497307};\\\", \\\"{x:488,y:714,t:1527268497321};\\\", \\\"{x:489,y:714,t:1527268497365};\\\", \\\"{x:490,y:714,t:1527268497372};\\\", \\\"{x:491,y:714,t:1527268497454};\\\", \\\"{x:492,y:714,t:1527268497461};\\\", \\\"{x:493,y:715,t:1527268497477};\\\", \\\"{x:495,y:715,t:1527268497493};\\\", \\\"{x:497,y:715,t:1527268497506};\\\", \\\"{x:498,y:715,t:1527268497521};\\\", \\\"{x:499,y:715,t:1527268497590};\\\", \\\"{x:499,y:718,t:1527268497605};\\\", \\\"{x:499,y:725,t:1527268497622};\\\", \\\"{x:499,y:732,t:1527268497639};\\\", \\\"{x:497,y:742,t:1527268497655};\\\", \\\"{x:494,y:751,t:1527268497673};\\\", \\\"{x:493,y:762,t:1527268497689};\\\", \\\"{x:493,y:764,t:1527268497705};\\\", \\\"{x:492,y:764,t:1527268497806};\\\", \\\"{x:491,y:764,t:1527268497870};\\\", \\\"{x:491,y:762,t:1527268497942};\\\", \\\"{x:491,y:761,t:1527268497956};\\\", \\\"{x:491,y:756,t:1527268497973};\\\", \\\"{x:491,y:751,t:1527268497990};\\\", \\\"{x:492,y:746,t:1527268498005};\\\", \\\"{x:492,y:744,t:1527268498023};\\\", \\\"{x:492,y:743,t:1527268499149};\\\", \\\"{x:492,y:741,t:1527268499214};\\\", \\\"{x:492,y:740,t:1527268499286};\\\", \\\"{x:491,y:739,t:1527268499309};\\\", \\\"{x:491,y:738,t:1527268499326};\\\", \\\"{x:491,y:737,t:1527268499358};\\\", \\\"{x:491,y:735,t:1527268499374};\\\", \\\"{x:491,y:734,t:1527268499398};\\\", \\\"{x:491,y:733,t:1527268499407};\\\", \\\"{x:490,y:733,t:1527268499424};\\\", \\\"{x:490,y:732,t:1527268499462};\\\", \\\"{x:490,y:731,t:1527268499502};\\\", \\\"{x:489,y:730,t:1527268499518};\\\", \\\"{x:489,y:729,t:1527268499526};\\\", \\\"{x:489,y:728,t:1527268499550};\\\", \\\"{x:489,y:726,t:1527268499574};\\\", \\\"{x:489,y:724,t:1527268499590};\\\", \\\"{x:489,y:723,t:1527268499607};\\\", \\\"{x:490,y:723,t:1527268499624};\\\", \\\"{x:490,y:722,t:1527268499640};\\\", \\\"{x:490,y:721,t:1527268499657};\\\", \\\"{x:490,y:719,t:1527268499674};\\\", \\\"{x:491,y:719,t:1527268499690};\\\", \\\"{x:491,y:718,t:1527268499717};\\\", \\\"{x:492,y:718,t:1527268499741};\\\", \\\"{x:492,y:717,t:1527268499822};\\\" ] }, { \\\"rt\\\": 19794, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 555867, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:716,t:1527268500307};\\\", \\\"{x:491,y:514,t:1527268500923};\\\", \\\"{x:472,y:478,t:1527268500941};\\\", \\\"{x:428,y:379,t:1527268500958};\\\", \\\"{x:352,y:202,t:1527268500975};\\\", \\\"{x:279,y:26,t:1527268500992};\\\", \\\"{x:193,y:0,t:1527268501007};\\\", \\\"{x:91,y:0,t:1527268501024};\\\", \\\"{x:0,y:0,t:1527268501042};\\\", \\\"{x:1,y:0,t:1527268501214};\\\", \\\"{x:16,y:0,t:1527268501225};\\\", \\\"{x:54,y:0,t:1527268501242};\\\", \\\"{x:97,y:0,t:1527268501258};\\\", \\\"{x:141,y:0,t:1527268501275};\\\", \\\"{x:176,y:0,t:1527268501292};\\\", \\\"{x:199,y:0,t:1527268501308};\\\", \\\"{x:235,y:0,t:1527268501325};\\\", \\\"{x:244,y:0,t:1527268501342};\\\", \\\"{x:238,y:0,t:1527268501374};\\\", \\\"{x:219,y:0,t:1527268501392};\\\", \\\"{x:187,y:0,t:1527268501409};\\\", \\\"{x:161,y:0,t:1527268501425};\\\", \\\"{x:134,y:0,t:1527268501442};\\\", \\\"{x:122,y:0,t:1527268501459};\\\", \\\"{x:120,y:0,t:1527268501475};\\\", \\\"{x:120,y:1,t:1527268501510};\\\", \\\"{x:121,y:15,t:1527268501526};\\\", \\\"{x:141,y:48,t:1527268501542};\\\", \\\"{x:183,y:92,t:1527268501559};\\\", \\\"{x:268,y:157,t:1527268501576};\\\", \\\"{x:379,y:211,t:1527268501592};\\\", \\\"{x:499,y:258,t:1527268501609};\\\", \\\"{x:637,y:294,t:1527268501626};\\\", \\\"{x:778,y:311,t:1527268501642};\\\", \\\"{x:896,y:322,t:1527268501659};\\\", \\\"{x:1007,y:322,t:1527268501677};\\\", \\\"{x:1086,y:325,t:1527268501692};\\\", \\\"{x:1116,y:325,t:1527268501710};\\\", \\\"{x:1120,y:325,t:1527268501726};\\\", \\\"{x:1121,y:326,t:1527268501766};\\\", \\\"{x:1120,y:326,t:1527268501838};\\\", \\\"{x:1115,y:327,t:1527268501846};\\\", \\\"{x:1107,y:327,t:1527268501859};\\\", \\\"{x:1083,y:331,t:1527268501876};\\\", \\\"{x:1041,y:331,t:1527268501893};\\\", \\\"{x:986,y:331,t:1527268501909};\\\", \\\"{x:866,y:331,t:1527268501926};\\\", \\\"{x:791,y:331,t:1527268501943};\\\", \\\"{x:719,y:331,t:1527268501959};\\\", \\\"{x:677,y:331,t:1527268501977};\\\", \\\"{x:643,y:331,t:1527268501993};\\\", \\\"{x:617,y:332,t:1527268502009};\\\", \\\"{x:601,y:336,t:1527268502026};\\\", \\\"{x:597,y:336,t:1527268502043};\\\", \\\"{x:596,y:336,t:1527268502059};\\\", \\\"{x:595,y:337,t:1527268502358};\\\", \\\"{x:595,y:338,t:1527268502382};\\\", \\\"{x:595,y:339,t:1527268502393};\\\", \\\"{x:596,y:343,t:1527268502410};\\\", \\\"{x:598,y:345,t:1527268502426};\\\", \\\"{x:598,y:347,t:1527268502443};\\\", \\\"{x:599,y:349,t:1527268502460};\\\", \\\"{x:600,y:349,t:1527268502476};\\\", \\\"{x:601,y:351,t:1527268502493};\\\", \\\"{x:601,y:352,t:1527268502510};\\\", \\\"{x:602,y:352,t:1527268502526};\\\", \\\"{x:603,y:353,t:1527268502566};\\\", \\\"{x:604,y:353,t:1527268502726};\\\", \\\"{x:605,y:353,t:1527268503118};\\\", \\\"{x:606,y:353,t:1527268503374};\\\", \\\"{x:607,y:353,t:1527268503574};\\\", \\\"{x:608,y:354,t:1527268503804};\\\", \\\"{x:609,y:355,t:1527268503819};\\\", \\\"{x:618,y:357,t:1527268504283};\\\", \\\"{x:640,y:361,t:1527268504292};\\\", \\\"{x:707,y:371,t:1527268504310};\\\", \\\"{x:802,y:389,t:1527268504325};\\\", \\\"{x:890,y:400,t:1527268504342};\\\", \\\"{x:957,y:418,t:1527268504360};\\\", \\\"{x:1011,y:429,t:1527268504376};\\\", \\\"{x:1066,y:442,t:1527268504393};\\\", \\\"{x:1106,y:455,t:1527268504410};\\\", \\\"{x:1123,y:460,t:1527268504426};\\\", \\\"{x:1130,y:463,t:1527268504443};\\\", \\\"{x:1132,y:464,t:1527268504460};\\\", \\\"{x:1132,y:465,t:1527268504476};\\\", \\\"{x:1132,y:467,t:1527268504523};\\\", \\\"{x:1132,y:470,t:1527268504531};\\\", \\\"{x:1132,y:476,t:1527268504543};\\\", \\\"{x:1129,y:491,t:1527268504560};\\\", \\\"{x:1122,y:514,t:1527268504577};\\\", \\\"{x:1119,y:538,t:1527268504592};\\\", \\\"{x:1119,y:565,t:1527268504610};\\\", \\\"{x:1120,y:605,t:1527268504627};\\\", \\\"{x:1134,y:640,t:1527268504643};\\\", \\\"{x:1152,y:682,t:1527268504659};\\\", \\\"{x:1171,y:717,t:1527268504677};\\\", \\\"{x:1186,y:743,t:1527268504693};\\\", \\\"{x:1194,y:758,t:1527268504710};\\\", \\\"{x:1198,y:768,t:1527268504727};\\\", \\\"{x:1199,y:771,t:1527268504743};\\\", \\\"{x:1200,y:774,t:1527268504760};\\\", \\\"{x:1201,y:774,t:1527268504777};\\\", \\\"{x:1202,y:775,t:1527268504852};\\\", \\\"{x:1203,y:775,t:1527268504867};\\\", \\\"{x:1205,y:775,t:1527268504876};\\\", \\\"{x:1211,y:775,t:1527268504894};\\\", \\\"{x:1217,y:775,t:1527268504910};\\\", \\\"{x:1227,y:773,t:1527268504927};\\\", \\\"{x:1233,y:772,t:1527268504944};\\\", \\\"{x:1237,y:769,t:1527268504959};\\\", \\\"{x:1244,y:765,t:1527268504977};\\\", \\\"{x:1247,y:764,t:1527268504994};\\\", \\\"{x:1249,y:762,t:1527268505011};\\\", \\\"{x:1250,y:761,t:1527268505035};\\\", \\\"{x:1251,y:761,t:1527268505043};\\\", \\\"{x:1254,y:757,t:1527268505059};\\\", \\\"{x:1260,y:750,t:1527268505077};\\\", \\\"{x:1267,y:742,t:1527268505094};\\\", \\\"{x:1275,y:734,t:1527268505110};\\\", \\\"{x:1281,y:729,t:1527268505127};\\\", \\\"{x:1287,y:723,t:1527268505144};\\\", \\\"{x:1293,y:717,t:1527268505160};\\\", \\\"{x:1296,y:714,t:1527268505177};\\\", \\\"{x:1298,y:713,t:1527268505194};\\\", \\\"{x:1300,y:711,t:1527268505211};\\\", \\\"{x:1300,y:710,t:1527268505227};\\\", \\\"{x:1302,y:710,t:1527268505243};\\\", \\\"{x:1303,y:708,t:1527268505260};\\\", \\\"{x:1306,y:706,t:1527268505277};\\\", \\\"{x:1307,y:705,t:1527268505294};\\\", \\\"{x:1308,y:704,t:1527268505311};\\\", \\\"{x:1309,y:704,t:1527268505327};\\\", \\\"{x:1311,y:703,t:1527268505344};\\\", \\\"{x:1314,y:702,t:1527268505361};\\\", \\\"{x:1318,y:701,t:1527268505377};\\\", \\\"{x:1323,y:700,t:1527268505394};\\\", \\\"{x:1335,y:696,t:1527268505411};\\\", \\\"{x:1343,y:693,t:1527268505430};\\\", \\\"{x:1348,y:693,t:1527268505443};\\\", \\\"{x:1356,y:693,t:1527268505460};\\\", \\\"{x:1360,y:693,t:1527268505476};\\\", \\\"{x:1362,y:693,t:1527268505493};\\\", \\\"{x:1364,y:694,t:1527268505510};\\\", \\\"{x:1366,y:694,t:1527268505526};\\\", \\\"{x:1369,y:698,t:1527268505543};\\\", \\\"{x:1373,y:702,t:1527268505560};\\\", \\\"{x:1377,y:708,t:1527268505578};\\\", \\\"{x:1380,y:718,t:1527268505593};\\\", \\\"{x:1387,y:737,t:1527268505610};\\\", \\\"{x:1390,y:753,t:1527268505627};\\\", \\\"{x:1393,y:768,t:1527268505644};\\\", \\\"{x:1394,y:782,t:1527268505661};\\\", \\\"{x:1395,y:795,t:1527268505678};\\\", \\\"{x:1395,y:807,t:1527268505694};\\\", \\\"{x:1395,y:827,t:1527268505711};\\\", \\\"{x:1395,y:849,t:1527268505728};\\\", \\\"{x:1395,y:863,t:1527268505744};\\\", \\\"{x:1395,y:875,t:1527268505761};\\\", \\\"{x:1395,y:888,t:1527268505778};\\\", \\\"{x:1391,y:899,t:1527268505794};\\\", \\\"{x:1386,y:911,t:1527268505811};\\\", \\\"{x:1380,y:918,t:1527268505827};\\\", \\\"{x:1376,y:922,t:1527268505844};\\\", \\\"{x:1374,y:925,t:1527268505861};\\\", \\\"{x:1372,y:927,t:1527268505877};\\\", \\\"{x:1371,y:928,t:1527268505894};\\\", \\\"{x:1370,y:929,t:1527268505931};\\\", \\\"{x:1370,y:927,t:1527268506060};\\\", \\\"{x:1370,y:924,t:1527268506077};\\\", \\\"{x:1370,y:919,t:1527268506095};\\\", \\\"{x:1370,y:914,t:1527268506111};\\\", \\\"{x:1370,y:910,t:1527268506128};\\\", \\\"{x:1371,y:904,t:1527268506145};\\\", \\\"{x:1373,y:898,t:1527268506161};\\\", \\\"{x:1374,y:895,t:1527268506178};\\\", \\\"{x:1374,y:892,t:1527268506196};\\\", \\\"{x:1375,y:891,t:1527268506387};\\\", \\\"{x:1375,y:890,t:1527268506403};\\\", \\\"{x:1375,y:888,t:1527268506411};\\\", \\\"{x:1375,y:882,t:1527268506428};\\\", \\\"{x:1375,y:876,t:1527268506445};\\\", \\\"{x:1375,y:873,t:1527268506462};\\\", \\\"{x:1374,y:867,t:1527268506478};\\\", \\\"{x:1371,y:861,t:1527268506495};\\\", \\\"{x:1371,y:857,t:1527268506512};\\\", \\\"{x:1365,y:844,t:1527268506528};\\\", \\\"{x:1358,y:836,t:1527268506545};\\\", \\\"{x:1356,y:829,t:1527268506562};\\\", \\\"{x:1349,y:817,t:1527268506579};\\\", \\\"{x:1347,y:814,t:1527268506595};\\\", \\\"{x:1344,y:809,t:1527268506612};\\\", \\\"{x:1341,y:805,t:1527268506629};\\\", \\\"{x:1340,y:801,t:1527268506645};\\\", \\\"{x:1337,y:797,t:1527268506662};\\\", \\\"{x:1337,y:796,t:1527268506678};\\\", \\\"{x:1336,y:795,t:1527268506695};\\\", \\\"{x:1336,y:794,t:1527268506712};\\\", \\\"{x:1335,y:794,t:1527268506729};\\\", \\\"{x:1334,y:792,t:1527268506745};\\\", \\\"{x:1334,y:791,t:1527268506763};\\\", \\\"{x:1333,y:789,t:1527268506779};\\\", \\\"{x:1332,y:786,t:1527268506795};\\\", \\\"{x:1330,y:782,t:1527268506811};\\\", \\\"{x:1330,y:779,t:1527268506828};\\\", \\\"{x:1328,y:778,t:1527268506845};\\\", \\\"{x:1328,y:774,t:1527268506862};\\\", \\\"{x:1328,y:771,t:1527268506879};\\\", \\\"{x:1328,y:768,t:1527268506895};\\\", \\\"{x:1328,y:765,t:1527268506911};\\\", \\\"{x:1328,y:764,t:1527268506931};\\\", \\\"{x:1328,y:763,t:1527268506996};\\\", \\\"{x:1330,y:763,t:1527268507515};\\\", \\\"{x:1331,y:763,t:1527268507555};\\\", \\\"{x:1333,y:763,t:1527268507570};\\\", \\\"{x:1334,y:763,t:1527268507610};\\\", \\\"{x:1336,y:763,t:1527268507643};\\\", \\\"{x:1337,y:763,t:1527268507659};\\\", \\\"{x:1340,y:763,t:1527268507667};\\\", \\\"{x:1343,y:763,t:1527268507681};\\\", \\\"{x:1344,y:763,t:1527268507695};\\\", \\\"{x:1346,y:763,t:1527268507713};\\\", \\\"{x:1348,y:763,t:1527268507730};\\\", \\\"{x:1350,y:763,t:1527268507756};\\\", \\\"{x:1350,y:762,t:1527268507763};\\\", \\\"{x:1351,y:761,t:1527268507843};\\\", \\\"{x:1351,y:762,t:1527268508083};\\\", \\\"{x:1351,y:763,t:1527268508123};\\\", \\\"{x:1351,y:764,t:1527268508179};\\\", \\\"{x:1351,y:765,t:1527268508203};\\\", \\\"{x:1351,y:766,t:1527268508219};\\\", \\\"{x:1351,y:767,t:1527268508235};\\\", \\\"{x:1350,y:767,t:1527268508275};\\\", \\\"{x:1349,y:765,t:1527268508659};\\\", \\\"{x:1349,y:763,t:1527268508667};\\\", \\\"{x:1349,y:761,t:1527268508681};\\\", \\\"{x:1349,y:758,t:1527268508697};\\\", \\\"{x:1349,y:753,t:1527268508715};\\\", \\\"{x:1349,y:747,t:1527268508731};\\\", \\\"{x:1349,y:739,t:1527268508748};\\\", \\\"{x:1350,y:735,t:1527268508764};\\\", \\\"{x:1350,y:731,t:1527268508781};\\\", \\\"{x:1352,y:722,t:1527268508797};\\\", \\\"{x:1352,y:715,t:1527268508814};\\\", \\\"{x:1352,y:712,t:1527268508831};\\\", \\\"{x:1352,y:711,t:1527268508847};\\\", \\\"{x:1352,y:710,t:1527268508864};\\\", \\\"{x:1353,y:710,t:1527268508882};\\\", \\\"{x:1354,y:709,t:1527268508907};\\\", \\\"{x:1354,y:708,t:1527268508939};\\\", \\\"{x:1354,y:707,t:1527268508963};\\\", \\\"{x:1353,y:711,t:1527268509115};\\\", \\\"{x:1352,y:717,t:1527268509130};\\\", \\\"{x:1350,y:726,t:1527268509148};\\\", \\\"{x:1348,y:738,t:1527268509164};\\\", \\\"{x:1346,y:748,t:1527268509181};\\\", \\\"{x:1344,y:755,t:1527268509198};\\\", \\\"{x:1341,y:765,t:1527268509214};\\\", \\\"{x:1340,y:770,t:1527268509231};\\\", \\\"{x:1338,y:774,t:1527268509248};\\\", \\\"{x:1338,y:776,t:1527268509265};\\\", \\\"{x:1338,y:777,t:1527268509291};\\\", \\\"{x:1338,y:775,t:1527268509396};\\\", \\\"{x:1338,y:774,t:1527268509403};\\\", \\\"{x:1338,y:773,t:1527268509414};\\\", \\\"{x:1338,y:769,t:1527268509430};\\\", \\\"{x:1338,y:763,t:1527268509447};\\\", \\\"{x:1339,y:759,t:1527268509464};\\\", \\\"{x:1339,y:755,t:1527268509480};\\\", \\\"{x:1340,y:753,t:1527268509498};\\\", \\\"{x:1340,y:752,t:1527268509515};\\\", \\\"{x:1340,y:751,t:1527268509530};\\\", \\\"{x:1340,y:750,t:1527268509555};\\\", \\\"{x:1341,y:748,t:1527268509570};\\\", \\\"{x:1341,y:746,t:1527268509581};\\\", \\\"{x:1341,y:742,t:1527268509598};\\\", \\\"{x:1341,y:737,t:1527268509615};\\\", \\\"{x:1341,y:732,t:1527268509631};\\\", \\\"{x:1341,y:727,t:1527268509648};\\\", \\\"{x:1341,y:721,t:1527268509665};\\\", \\\"{x:1341,y:715,t:1527268509682};\\\", \\\"{x:1341,y:707,t:1527268509697};\\\", \\\"{x:1341,y:702,t:1527268509715};\\\", \\\"{x:1341,y:696,t:1527268509731};\\\", \\\"{x:1341,y:694,t:1527268509748};\\\", \\\"{x:1341,y:692,t:1527268509765};\\\", \\\"{x:1341,y:691,t:1527268509782};\\\", \\\"{x:1338,y:692,t:1527268509995};\\\", \\\"{x:1336,y:693,t:1527268510006};\\\", \\\"{x:1331,y:695,t:1527268510014};\\\", \\\"{x:1315,y:699,t:1527268510031};\\\", \\\"{x:1282,y:704,t:1527268510048};\\\", \\\"{x:1209,y:706,t:1527268510064};\\\", \\\"{x:1065,y:706,t:1527268510082};\\\", \\\"{x:794,y:706,t:1527268510098};\\\", \\\"{x:623,y:706,t:1527268510114};\\\", \\\"{x:481,y:702,t:1527268510131};\\\", \\\"{x:385,y:693,t:1527268510148};\\\", \\\"{x:342,y:686,t:1527268510165};\\\", \\\"{x:324,y:685,t:1527268510182};\\\", \\\"{x:316,y:684,t:1527268510198};\\\", \\\"{x:311,y:681,t:1527268510214};\\\", \\\"{x:309,y:678,t:1527268510232};\\\", \\\"{x:306,y:671,t:1527268510248};\\\", \\\"{x:302,y:661,t:1527268510266};\\\", \\\"{x:297,y:645,t:1527268510282};\\\", \\\"{x:288,y:622,t:1527268510299};\\\", \\\"{x:282,y:612,t:1527268510312};\\\", \\\"{x:273,y:594,t:1527268510330};\\\", \\\"{x:253,y:569,t:1527268510346};\\\", \\\"{x:246,y:561,t:1527268510362};\\\", \\\"{x:241,y:554,t:1527268510380};\\\", \\\"{x:238,y:550,t:1527268510396};\\\", \\\"{x:238,y:546,t:1527268510413};\\\", \\\"{x:238,y:544,t:1527268510429};\\\", \\\"{x:238,y:540,t:1527268510446};\\\", \\\"{x:238,y:538,t:1527268510463};\\\", \\\"{x:238,y:535,t:1527268510479};\\\", \\\"{x:239,y:532,t:1527268510496};\\\", \\\"{x:242,y:528,t:1527268510513};\\\", \\\"{x:247,y:525,t:1527268510529};\\\", \\\"{x:267,y:524,t:1527268510546};\\\", \\\"{x:287,y:524,t:1527268510563};\\\", \\\"{x:312,y:524,t:1527268510579};\\\", \\\"{x:346,y:531,t:1527268510598};\\\", \\\"{x:382,y:540,t:1527268510612};\\\", \\\"{x:407,y:547,t:1527268510630};\\\", \\\"{x:435,y:558,t:1527268510647};\\\", \\\"{x:452,y:567,t:1527268510664};\\\", \\\"{x:466,y:573,t:1527268510680};\\\", \\\"{x:477,y:580,t:1527268510696};\\\", \\\"{x:487,y:584,t:1527268510714};\\\", \\\"{x:495,y:585,t:1527268510729};\\\", \\\"{x:507,y:585,t:1527268510747};\\\", \\\"{x:514,y:585,t:1527268510763};\\\", \\\"{x:522,y:585,t:1527268510779};\\\", \\\"{x:531,y:580,t:1527268510797};\\\", \\\"{x:545,y:572,t:1527268510813};\\\", \\\"{x:562,y:561,t:1527268510831};\\\", \\\"{x:580,y:551,t:1527268510847};\\\", \\\"{x:596,y:540,t:1527268510864};\\\", \\\"{x:611,y:533,t:1527268510880};\\\", \\\"{x:628,y:528,t:1527268510896};\\\", \\\"{x:641,y:521,t:1527268510914};\\\", \\\"{x:664,y:513,t:1527268510930};\\\", \\\"{x:676,y:510,t:1527268510946};\\\", \\\"{x:680,y:510,t:1527268510964};\\\", \\\"{x:684,y:509,t:1527268510979};\\\", \\\"{x:685,y:509,t:1527268510996};\\\", \\\"{x:686,y:509,t:1527268511013};\\\", \\\"{x:687,y:509,t:1527268511030};\\\", \\\"{x:689,y:509,t:1527268511047};\\\", \\\"{x:693,y:512,t:1527268511064};\\\", \\\"{x:698,y:514,t:1527268511079};\\\", \\\"{x:702,y:516,t:1527268511097};\\\", \\\"{x:706,y:517,t:1527268511114};\\\", \\\"{x:708,y:518,t:1527268511131};\\\", \\\"{x:711,y:518,t:1527268511299};\\\", \\\"{x:719,y:518,t:1527268511315};\\\", \\\"{x:732,y:517,t:1527268511333};\\\", \\\"{x:754,y:515,t:1527268511347};\\\", \\\"{x:782,y:515,t:1527268511364};\\\", \\\"{x:809,y:515,t:1527268511380};\\\", \\\"{x:830,y:515,t:1527268511397};\\\", \\\"{x:840,y:515,t:1527268511414};\\\", \\\"{x:843,y:515,t:1527268511430};\\\", \\\"{x:844,y:515,t:1527268511474};\\\", \\\"{x:845,y:515,t:1527268511490};\\\", \\\"{x:846,y:515,t:1527268511498};\\\", \\\"{x:847,y:515,t:1527268511515};\\\", \\\"{x:848,y:515,t:1527268511530};\\\", \\\"{x:848,y:514,t:1527268511835};\\\", \\\"{x:847,y:513,t:1527268511848};\\\", \\\"{x:845,y:513,t:1527268511865};\\\", \\\"{x:843,y:512,t:1527268511882};\\\", \\\"{x:842,y:512,t:1527268511922};\\\", \\\"{x:842,y:511,t:1527268511938};\\\", \\\"{x:840,y:511,t:1527268512314};\\\", \\\"{x:839,y:511,t:1527268512331};\\\", \\\"{x:833,y:513,t:1527268512348};\\\", \\\"{x:827,y:517,t:1527268512366};\\\", \\\"{x:817,y:521,t:1527268512382};\\\", \\\"{x:802,y:527,t:1527268512398};\\\", \\\"{x:787,y:530,t:1527268512415};\\\", \\\"{x:775,y:531,t:1527268512432};\\\", \\\"{x:759,y:534,t:1527268512448};\\\", \\\"{x:737,y:535,t:1527268512464};\\\", \\\"{x:715,y:537,t:1527268512483};\\\", \\\"{x:699,y:538,t:1527268512497};\\\", \\\"{x:675,y:542,t:1527268512514};\\\", \\\"{x:662,y:543,t:1527268512532};\\\", \\\"{x:648,y:544,t:1527268512547};\\\", \\\"{x:634,y:547,t:1527268512565};\\\", \\\"{x:617,y:548,t:1527268512582};\\\", \\\"{x:602,y:550,t:1527268512598};\\\", \\\"{x:593,y:552,t:1527268512616};\\\", \\\"{x:590,y:553,t:1527268512631};\\\", \\\"{x:585,y:554,t:1527268512647};\\\", \\\"{x:577,y:556,t:1527268512666};\\\", \\\"{x:568,y:558,t:1527268512682};\\\", \\\"{x:550,y:562,t:1527268512698};\\\", \\\"{x:511,y:565,t:1527268512715};\\\", \\\"{x:483,y:565,t:1527268512732};\\\", \\\"{x:464,y:568,t:1527268512747};\\\", \\\"{x:454,y:569,t:1527268512765};\\\", \\\"{x:450,y:569,t:1527268512781};\\\", \\\"{x:447,y:569,t:1527268512798};\\\", \\\"{x:443,y:570,t:1527268512814};\\\", \\\"{x:442,y:572,t:1527268512832};\\\", \\\"{x:436,y:573,t:1527268512848};\\\", \\\"{x:427,y:576,t:1527268512865};\\\", \\\"{x:418,y:577,t:1527268512882};\\\", \\\"{x:391,y:581,t:1527268512898};\\\", \\\"{x:372,y:582,t:1527268512915};\\\", \\\"{x:354,y:582,t:1527268512932};\\\", \\\"{x:334,y:582,t:1527268512948};\\\", \\\"{x:323,y:582,t:1527268512965};\\\", \\\"{x:312,y:582,t:1527268512981};\\\", \\\"{x:307,y:582,t:1527268512999};\\\", \\\"{x:303,y:582,t:1527268513016};\\\", \\\"{x:299,y:581,t:1527268513032};\\\", \\\"{x:294,y:579,t:1527268513049};\\\", \\\"{x:285,y:578,t:1527268513066};\\\", \\\"{x:273,y:577,t:1527268513082};\\\", \\\"{x:250,y:575,t:1527268513100};\\\", \\\"{x:235,y:571,t:1527268513116};\\\", \\\"{x:219,y:570,t:1527268513132};\\\", \\\"{x:212,y:570,t:1527268513149};\\\", \\\"{x:208,y:568,t:1527268513165};\\\", \\\"{x:204,y:567,t:1527268513181};\\\", \\\"{x:199,y:567,t:1527268513199};\\\", \\\"{x:195,y:564,t:1527268513214};\\\", \\\"{x:191,y:563,t:1527268513232};\\\", \\\"{x:189,y:562,t:1527268513250};\\\", \\\"{x:184,y:559,t:1527268513265};\\\", \\\"{x:179,y:555,t:1527268513287};\\\", \\\"{x:172,y:551,t:1527268513298};\\\", \\\"{x:169,y:548,t:1527268513316};\\\", \\\"{x:164,y:546,t:1527268513331};\\\", \\\"{x:162,y:544,t:1527268513348};\\\", \\\"{x:160,y:543,t:1527268513366};\\\", \\\"{x:159,y:542,t:1527268513382};\\\", \\\"{x:157,y:541,t:1527268513398};\\\", \\\"{x:156,y:540,t:1527268513434};\\\", \\\"{x:155,y:539,t:1527268513450};\\\", \\\"{x:154,y:539,t:1527268513465};\\\", \\\"{x:153,y:538,t:1527268513482};\\\", \\\"{x:153,y:537,t:1527268513515};\\\", \\\"{x:153,y:536,t:1527268513843};\\\", \\\"{x:154,y:536,t:1527268513850};\\\", \\\"{x:159,y:536,t:1527268513865};\\\", \\\"{x:197,y:536,t:1527268513884};\\\", \\\"{x:250,y:536,t:1527268513899};\\\", \\\"{x:323,y:536,t:1527268513917};\\\", \\\"{x:399,y:539,t:1527268513933};\\\", \\\"{x:488,y:554,t:1527268513950};\\\", \\\"{x:593,y:568,t:1527268513967};\\\", \\\"{x:694,y:584,t:1527268513982};\\\", \\\"{x:788,y:595,t:1527268513999};\\\", \\\"{x:866,y:606,t:1527268514017};\\\", \\\"{x:919,y:614,t:1527268514033};\\\", \\\"{x:972,y:622,t:1527268514049};\\\", \\\"{x:1034,y:634,t:1527268514066};\\\", \\\"{x:1110,y:656,t:1527268514083};\\\", \\\"{x:1147,y:667,t:1527268514099};\\\", \\\"{x:1170,y:673,t:1527268514116};\\\", \\\"{x:1195,y:684,t:1527268514133};\\\", \\\"{x:1223,y:692,t:1527268514149};\\\", \\\"{x:1248,y:699,t:1527268514165};\\\", \\\"{x:1270,y:704,t:1527268514183};\\\", \\\"{x:1287,y:708,t:1527268514199};\\\", \\\"{x:1302,y:709,t:1527268514215};\\\", \\\"{x:1316,y:712,t:1527268514233};\\\", \\\"{x:1329,y:714,t:1527268514248};\\\", \\\"{x:1343,y:716,t:1527268514266};\\\", \\\"{x:1356,y:717,t:1527268514282};\\\", \\\"{x:1376,y:721,t:1527268514299};\\\", \\\"{x:1388,y:722,t:1527268514316};\\\", \\\"{x:1400,y:724,t:1527268514332};\\\", \\\"{x:1410,y:725,t:1527268514349};\\\", \\\"{x:1418,y:726,t:1527268514366};\\\", \\\"{x:1421,y:726,t:1527268514382};\\\", \\\"{x:1422,y:726,t:1527268514532};\\\", \\\"{x:1422,y:722,t:1527268514549};\\\", \\\"{x:1415,y:716,t:1527268514565};\\\", \\\"{x:1402,y:707,t:1527268514582};\\\", \\\"{x:1390,y:701,t:1527268514600};\\\", \\\"{x:1378,y:694,t:1527268514615};\\\", \\\"{x:1369,y:690,t:1527268514632};\\\", \\\"{x:1363,y:687,t:1527268514649};\\\", \\\"{x:1359,y:684,t:1527268514665};\\\", \\\"{x:1358,y:683,t:1527268514691};\\\", \\\"{x:1357,y:682,t:1527268514716};\\\", \\\"{x:1356,y:682,t:1527268514732};\\\", \\\"{x:1356,y:681,t:1527268514749};\\\", \\\"{x:1355,y:680,t:1527268514766};\\\", \\\"{x:1354,y:679,t:1527268514796};\\\", \\\"{x:1353,y:679,t:1527268514947};\\\", \\\"{x:1353,y:681,t:1527268514965};\\\", \\\"{x:1351,y:687,t:1527268514981};\\\", \\\"{x:1349,y:694,t:1527268514998};\\\", \\\"{x:1347,y:700,t:1527268515014};\\\", \\\"{x:1344,y:708,t:1527268515031};\\\", \\\"{x:1343,y:713,t:1527268515047};\\\", \\\"{x:1340,y:719,t:1527268515065};\\\", \\\"{x:1340,y:722,t:1527268515081};\\\", \\\"{x:1340,y:724,t:1527268515098};\\\", \\\"{x:1338,y:727,t:1527268515114};\\\", \\\"{x:1338,y:728,t:1527268515131};\\\", \\\"{x:1337,y:730,t:1527268515147};\\\", \\\"{x:1337,y:731,t:1527268515165};\\\", \\\"{x:1337,y:732,t:1527268515235};\\\", \\\"{x:1337,y:733,t:1527268515248};\\\", \\\"{x:1338,y:733,t:1527268515264};\\\", \\\"{x:1339,y:735,t:1527268515281};\\\", \\\"{x:1340,y:739,t:1527268515298};\\\", \\\"{x:1342,y:743,t:1527268515315};\\\", \\\"{x:1343,y:749,t:1527268515332};\\\", \\\"{x:1344,y:753,t:1527268515348};\\\", \\\"{x:1345,y:760,t:1527268515365};\\\", \\\"{x:1346,y:763,t:1527268515381};\\\", \\\"{x:1346,y:765,t:1527268515399};\\\", \\\"{x:1346,y:767,t:1527268515414};\\\", \\\"{x:1346,y:769,t:1527268515432};\\\", \\\"{x:1346,y:771,t:1527268515448};\\\", \\\"{x:1346,y:773,t:1527268515464};\\\", \\\"{x:1346,y:776,t:1527268515482};\\\", \\\"{x:1346,y:777,t:1527268515497};\\\", \\\"{x:1346,y:779,t:1527268515515};\\\", \\\"{x:1346,y:783,t:1527268515531};\\\", \\\"{x:1346,y:786,t:1527268515547};\\\", \\\"{x:1346,y:789,t:1527268515565};\\\", \\\"{x:1345,y:791,t:1527268515581};\\\", \\\"{x:1345,y:794,t:1527268515597};\\\", \\\"{x:1344,y:797,t:1527268515614};\\\", \\\"{x:1344,y:799,t:1527268515632};\\\", \\\"{x:1344,y:802,t:1527268515647};\\\", \\\"{x:1343,y:807,t:1527268515664};\\\", \\\"{x:1342,y:811,t:1527268515680};\\\", \\\"{x:1340,y:818,t:1527268515697};\\\", \\\"{x:1340,y:823,t:1527268515714};\\\", \\\"{x:1339,y:830,t:1527268515732};\\\", \\\"{x:1338,y:834,t:1527268515748};\\\", \\\"{x:1337,y:839,t:1527268515764};\\\", \\\"{x:1336,y:846,t:1527268515781};\\\", \\\"{x:1335,y:852,t:1527268515798};\\\", \\\"{x:1335,y:858,t:1527268515814};\\\", \\\"{x:1335,y:864,t:1527268515830};\\\", \\\"{x:1335,y:867,t:1527268515848};\\\", \\\"{x:1335,y:868,t:1527268515864};\\\", \\\"{x:1335,y:869,t:1527268515880};\\\", \\\"{x:1334,y:869,t:1527268515988};\\\", \\\"{x:1333,y:868,t:1527268516003};\\\", \\\"{x:1333,y:863,t:1527268516013};\\\", \\\"{x:1333,y:852,t:1527268516030};\\\", \\\"{x:1333,y:841,t:1527268516047};\\\", \\\"{x:1333,y:822,t:1527268516064};\\\", \\\"{x:1333,y:804,t:1527268516081};\\\", \\\"{x:1333,y:789,t:1527268516098};\\\", \\\"{x:1333,y:780,t:1527268516114};\\\", \\\"{x:1333,y:768,t:1527268516131};\\\", \\\"{x:1333,y:754,t:1527268516147};\\\", \\\"{x:1333,y:750,t:1527268516163};\\\", \\\"{x:1333,y:745,t:1527268516180};\\\", \\\"{x:1333,y:740,t:1527268516197};\\\", \\\"{x:1333,y:736,t:1527268516213};\\\", \\\"{x:1333,y:731,t:1527268516230};\\\", \\\"{x:1333,y:726,t:1527268516246};\\\", \\\"{x:1333,y:721,t:1527268516264};\\\", \\\"{x:1333,y:717,t:1527268516280};\\\", \\\"{x:1333,y:714,t:1527268516297};\\\", \\\"{x:1333,y:713,t:1527268516314};\\\", \\\"{x:1333,y:711,t:1527268516330};\\\", \\\"{x:1333,y:710,t:1527268516347};\\\", \\\"{x:1333,y:708,t:1527268516379};\\\", \\\"{x:1333,y:707,t:1527268516436};\\\", \\\"{x:1333,y:705,t:1527268516452};\\\", \\\"{x:1333,y:704,t:1527268516475};\\\", \\\"{x:1333,y:702,t:1527268516499};\\\", \\\"{x:1333,y:701,t:1527268516523};\\\", \\\"{x:1333,y:699,t:1527268516555};\\\", \\\"{x:1333,y:701,t:1527268516723};\\\", \\\"{x:1333,y:702,t:1527268516731};\\\", \\\"{x:1333,y:707,t:1527268516747};\\\", \\\"{x:1333,y:712,t:1527268516762};\\\", \\\"{x:1333,y:719,t:1527268516779};\\\", \\\"{x:1333,y:722,t:1527268516797};\\\", \\\"{x:1333,y:726,t:1527268516812};\\\", \\\"{x:1333,y:731,t:1527268516830};\\\", \\\"{x:1333,y:738,t:1527268516846};\\\", \\\"{x:1333,y:743,t:1527268516862};\\\", \\\"{x:1332,y:750,t:1527268516879};\\\", \\\"{x:1331,y:756,t:1527268516895};\\\", \\\"{x:1331,y:762,t:1527268516912};\\\", \\\"{x:1331,y:765,t:1527268516930};\\\", \\\"{x:1329,y:770,t:1527268516946};\\\", \\\"{x:1329,y:773,t:1527268516963};\\\", \\\"{x:1329,y:779,t:1527268516979};\\\", \\\"{x:1329,y:783,t:1527268516995};\\\", \\\"{x:1329,y:787,t:1527268517013};\\\", \\\"{x:1329,y:792,t:1527268517029};\\\", \\\"{x:1329,y:798,t:1527268517045};\\\", \\\"{x:1329,y:804,t:1527268517062};\\\", \\\"{x:1329,y:809,t:1527268517078};\\\", \\\"{x:1329,y:815,t:1527268517095};\\\", \\\"{x:1330,y:821,t:1527268517111};\\\", \\\"{x:1330,y:826,t:1527268517128};\\\", \\\"{x:1332,y:831,t:1527268517145};\\\", \\\"{x:1332,y:836,t:1527268517162};\\\", \\\"{x:1332,y:849,t:1527268517178};\\\", \\\"{x:1332,y:857,t:1527268517195};\\\", \\\"{x:1332,y:864,t:1527268517212};\\\", \\\"{x:1332,y:869,t:1527268517228};\\\", \\\"{x:1332,y:874,t:1527268517245};\\\", \\\"{x:1332,y:879,t:1527268517262};\\\", \\\"{x:1332,y:880,t:1527268517278};\\\", \\\"{x:1332,y:883,t:1527268517295};\\\", \\\"{x:1332,y:884,t:1527268517331};\\\", \\\"{x:1332,y:886,t:1527268517379};\\\", \\\"{x:1332,y:888,t:1527268517395};\\\", \\\"{x:1332,y:890,t:1527268517412};\\\", \\\"{x:1332,y:894,t:1527268517429};\\\", \\\"{x:1333,y:899,t:1527268517445};\\\", \\\"{x:1333,y:904,t:1527268517461};\\\", \\\"{x:1334,y:908,t:1527268517478};\\\", \\\"{x:1334,y:914,t:1527268517495};\\\", \\\"{x:1334,y:919,t:1527268517511};\\\", \\\"{x:1336,y:921,t:1527268517528};\\\", \\\"{x:1336,y:923,t:1527268517544};\\\", \\\"{x:1336,y:924,t:1527268517561};\\\", \\\"{x:1336,y:925,t:1527268517578};\\\", \\\"{x:1336,y:926,t:1527268517602};\\\", \\\"{x:1337,y:928,t:1527268517651};\\\", \\\"{x:1337,y:929,t:1527268517700};\\\", \\\"{x:1337,y:931,t:1527268517715};\\\", \\\"{x:1337,y:932,t:1527268517731};\\\", \\\"{x:1337,y:933,t:1527268517747};\\\", \\\"{x:1336,y:933,t:1527268517964};\\\", \\\"{x:1335,y:933,t:1527268518020};\\\", \\\"{x:1335,y:932,t:1527268518027};\\\", \\\"{x:1334,y:932,t:1527268518045};\\\", \\\"{x:1331,y:929,t:1527268518061};\\\", \\\"{x:1317,y:922,t:1527268518078};\\\", \\\"{x:1295,y:917,t:1527268518095};\\\", \\\"{x:1262,y:908,t:1527268518111};\\\", \\\"{x:1212,y:894,t:1527268518128};\\\", \\\"{x:1167,y:880,t:1527268518145};\\\", \\\"{x:1126,y:870,t:1527268518161};\\\", \\\"{x:1101,y:865,t:1527268518178};\\\", \\\"{x:1082,y:860,t:1527268518195};\\\", \\\"{x:1062,y:857,t:1527268518211};\\\", \\\"{x:1033,y:854,t:1527268518227};\\\", \\\"{x:1014,y:851,t:1527268518245};\\\", \\\"{x:989,y:846,t:1527268518260};\\\", \\\"{x:974,y:844,t:1527268518278};\\\", \\\"{x:961,y:841,t:1527268518294};\\\", \\\"{x:952,y:840,t:1527268518310};\\\", \\\"{x:946,y:839,t:1527268518327};\\\", \\\"{x:942,y:837,t:1527268518343};\\\", \\\"{x:934,y:835,t:1527268518360};\\\", \\\"{x:929,y:833,t:1527268518377};\\\", \\\"{x:924,y:832,t:1527268518393};\\\", \\\"{x:913,y:828,t:1527268518411};\\\", \\\"{x:906,y:827,t:1527268518427};\\\", \\\"{x:899,y:824,t:1527268518443};\\\", \\\"{x:893,y:823,t:1527268518460};\\\", \\\"{x:888,y:821,t:1527268518477};\\\", \\\"{x:881,y:819,t:1527268518493};\\\", \\\"{x:870,y:815,t:1527268518510};\\\", \\\"{x:863,y:814,t:1527268518527};\\\", \\\"{x:851,y:809,t:1527268518543};\\\", \\\"{x:835,y:805,t:1527268518560};\\\", \\\"{x:820,y:801,t:1527268518577};\\\", \\\"{x:802,y:798,t:1527268518593};\\\", \\\"{x:778,y:794,t:1527268518611};\\\", \\\"{x:771,y:794,t:1527268518626};\\\", \\\"{x:751,y:788,t:1527268518643};\\\", \\\"{x:742,y:786,t:1527268518660};\\\", \\\"{x:730,y:784,t:1527268518677};\\\", \\\"{x:720,y:781,t:1527268518693};\\\", \\\"{x:713,y:781,t:1527268518711};\\\", \\\"{x:705,y:779,t:1527268518726};\\\", \\\"{x:698,y:779,t:1527268518743};\\\", \\\"{x:691,y:777,t:1527268518760};\\\", \\\"{x:685,y:775,t:1527268518776};\\\", \\\"{x:678,y:774,t:1527268518794};\\\", \\\"{x:673,y:772,t:1527268518810};\\\", \\\"{x:667,y:771,t:1527268518827};\\\", \\\"{x:661,y:768,t:1527268518842};\\\", \\\"{x:660,y:767,t:1527268518867};\\\", \\\"{x:659,y:767,t:1527268518923};\\\", \\\"{x:658,y:767,t:1527268518931};\\\", \\\"{x:658,y:766,t:1527268518943};\\\", \\\"{x:657,y:766,t:1527268518960};\\\", \\\"{x:655,y:764,t:1527268518976};\\\", \\\"{x:653,y:762,t:1527268518993};\\\", \\\"{x:651,y:761,t:1527268519010};\\\", \\\"{x:648,y:760,t:1527268519027};\\\", \\\"{x:647,y:759,t:1527268519042};\\\", \\\"{x:645,y:758,t:1527268519059};\\\", \\\"{x:642,y:758,t:1527268519076};\\\", \\\"{x:637,y:756,t:1527268519092};\\\", \\\"{x:630,y:754,t:1527268519109};\\\", \\\"{x:624,y:752,t:1527268519126};\\\", \\\"{x:618,y:750,t:1527268519142};\\\", \\\"{x:610,y:748,t:1527268519160};\\\", \\\"{x:607,y:747,t:1527268519175};\\\", \\\"{x:602,y:746,t:1527268519192};\\\", \\\"{x:592,y:743,t:1527268519210};\\\", \\\"{x:579,y:739,t:1527268519227};\\\", \\\"{x:575,y:737,t:1527268519242};\\\", \\\"{x:559,y:728,t:1527268519260};\\\", \\\"{x:552,y:724,t:1527268519276};\\\", \\\"{x:546,y:720,t:1527268519291};\\\", \\\"{x:545,y:719,t:1527268519310};\\\", \\\"{x:545,y:720,t:1527268519434};\\\", \\\"{x:542,y:725,t:1527268519453};\\\", \\\"{x:542,y:731,t:1527268519470};\\\", \\\"{x:541,y:734,t:1527268519486};\\\", \\\"{x:538,y:739,t:1527268519503};\\\", \\\"{x:535,y:742,t:1527268519519};\\\", \\\"{x:534,y:743,t:1527268519537};\\\", \\\"{x:533,y:743,t:1527268519554};\\\", \\\"{x:532,y:743,t:1527268519635};\\\", \\\"{x:529,y:743,t:1527268519667};\\\", \\\"{x:528,y:742,t:1527268519682};\\\", \\\"{x:527,y:741,t:1527268519755};\\\", \\\"{x:526,y:741,t:1527268519804};\\\", \\\"{x:526,y:740,t:1527268520659};\\\", \\\"{x:526,y:739,t:1527268520763};\\\", \\\"{x:527,y:739,t:1527268520883};\\\", \\\"{x:528,y:738,t:1527268520890};\\\", \\\"{x:529,y:738,t:1527268520923};\\\", \\\"{x:530,y:737,t:1527268521035};\\\", \\\"{x:531,y:736,t:1527268521066};\\\", \\\"{x:532,y:735,t:1527268521091};\\\", \\\"{x:535,y:735,t:1527268521105};\\\", \\\"{x:538,y:733,t:1527268521130};\\\", \\\"{x:538,y:732,t:1527268521146};\\\", \\\"{x:540,y:732,t:1527268521155};\\\", \\\"{x:541,y:731,t:1527268521172};\\\" ] }, { \\\"rt\\\": 16331, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 573419, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:563,y:726,t:1527268521321};\\\", \\\"{x:569,y:726,t:1527268521338};\\\", \\\"{x:572,y:726,t:1527268521355};\\\", \\\"{x:576,y:725,t:1527268521372};\\\", \\\"{x:581,y:723,t:1527268521388};\\\", \\\"{x:586,y:723,t:1527268521405};\\\", \\\"{x:592,y:723,t:1527268521421};\\\", \\\"{x:599,y:722,t:1527268521438};\\\", \\\"{x:622,y:721,t:1527268521470};\\\", \\\"{x:631,y:721,t:1527268521488};\\\", \\\"{x:632,y:721,t:1527268521505};\\\", \\\"{x:634,y:721,t:1527268521520};\\\", \\\"{x:635,y:720,t:1527268521538};\\\", \\\"{x:636,y:720,t:1527268521555};\\\", \\\"{x:637,y:719,t:1527268521578};\\\", \\\"{x:638,y:719,t:1527268521602};\\\", \\\"{x:639,y:718,t:1527268521610};\\\", \\\"{x:640,y:718,t:1527268521621};\\\", \\\"{x:644,y:716,t:1527268521638};\\\", \\\"{x:646,y:715,t:1527268521655};\\\", \\\"{x:653,y:712,t:1527268521671};\\\", \\\"{x:657,y:711,t:1527268521689};\\\", \\\"{x:659,y:711,t:1527268521704};\\\", \\\"{x:661,y:710,t:1527268521721};\\\", \\\"{x:662,y:710,t:1527268521739};\\\", \\\"{x:662,y:704,t:1527268522002};\\\", \\\"{x:673,y:689,t:1527268522009};\\\", \\\"{x:687,y:667,t:1527268522021};\\\", \\\"{x:713,y:625,t:1527268522038};\\\", \\\"{x:733,y:590,t:1527268522053};\\\", \\\"{x:747,y:569,t:1527268522072};\\\", \\\"{x:758,y:556,t:1527268522089};\\\", \\\"{x:764,y:547,t:1527268522107};\\\", \\\"{x:764,y:544,t:1527268522122};\\\", \\\"{x:764,y:540,t:1527268522139};\\\", \\\"{x:764,y:539,t:1527268522156};\\\", \\\"{x:763,y:537,t:1527268522172};\\\", \\\"{x:763,y:535,t:1527268522189};\\\", \\\"{x:760,y:532,t:1527268522206};\\\", \\\"{x:757,y:530,t:1527268522222};\\\", \\\"{x:749,y:523,t:1527268522239};\\\", \\\"{x:732,y:514,t:1527268522257};\\\", \\\"{x:713,y:506,t:1527268522274};\\\", \\\"{x:693,y:497,t:1527268522289};\\\", \\\"{x:659,y:489,t:1527268522306};\\\", \\\"{x:634,y:481,t:1527268522323};\\\", \\\"{x:615,y:479,t:1527268522339};\\\", \\\"{x:601,y:478,t:1527268522356};\\\", \\\"{x:591,y:476,t:1527268522373};\\\", \\\"{x:588,y:476,t:1527268522389};\\\", \\\"{x:587,y:476,t:1527268522406};\\\", \\\"{x:586,y:476,t:1527268522426};\\\", \\\"{x:584,y:476,t:1527268522474};\\\", \\\"{x:583,y:476,t:1527268522595};\\\", \\\"{x:584,y:475,t:1527268522606};\\\", \\\"{x:587,y:475,t:1527268522623};\\\", \\\"{x:590,y:475,t:1527268522640};\\\", \\\"{x:597,y:475,t:1527268522656};\\\", \\\"{x:604,y:475,t:1527268522673};\\\", \\\"{x:612,y:475,t:1527268522691};\\\", \\\"{x:613,y:475,t:1527268522707};\\\", \\\"{x:613,y:476,t:1527268522843};\\\", \\\"{x:613,y:477,t:1527268522856};\\\", \\\"{x:607,y:481,t:1527268522873};\\\", \\\"{x:585,y:485,t:1527268522891};\\\", \\\"{x:566,y:487,t:1527268522908};\\\", \\\"{x:548,y:490,t:1527268522924};\\\", \\\"{x:539,y:490,t:1527268522941};\\\", \\\"{x:533,y:490,t:1527268522956};\\\", \\\"{x:532,y:490,t:1527268522987};\\\", \\\"{x:534,y:490,t:1527268523259};\\\", \\\"{x:536,y:490,t:1527268523273};\\\", \\\"{x:543,y:487,t:1527268523291};\\\", \\\"{x:548,y:485,t:1527268523308};\\\", \\\"{x:556,y:482,t:1527268523323};\\\", \\\"{x:563,y:482,t:1527268523340};\\\", \\\"{x:568,y:482,t:1527268523357};\\\", \\\"{x:572,y:482,t:1527268523373};\\\", \\\"{x:577,y:482,t:1527268523390};\\\", \\\"{x:583,y:481,t:1527268523407};\\\", \\\"{x:587,y:480,t:1527268523423};\\\", \\\"{x:593,y:480,t:1527268523440};\\\", \\\"{x:598,y:479,t:1527268523457};\\\", \\\"{x:601,y:479,t:1527268523473};\\\", \\\"{x:609,y:476,t:1527268523491};\\\", \\\"{x:614,y:476,t:1527268523507};\\\", \\\"{x:618,y:474,t:1527268523524};\\\", \\\"{x:620,y:474,t:1527268523541};\\\", \\\"{x:621,y:474,t:1527268523558};\\\", \\\"{x:623,y:474,t:1527268523573};\\\", \\\"{x:623,y:473,t:1527268523590};\\\", \\\"{x:626,y:473,t:1527268523607};\\\", \\\"{x:628,y:473,t:1527268523624};\\\", \\\"{x:632,y:471,t:1527268523640};\\\", \\\"{x:634,y:471,t:1527268523657};\\\", \\\"{x:639,y:471,t:1527268523674};\\\", \\\"{x:652,y:471,t:1527268523690};\\\", \\\"{x:666,y:471,t:1527268523707};\\\", \\\"{x:684,y:471,t:1527268523723};\\\", \\\"{x:701,y:471,t:1527268523740};\\\", \\\"{x:722,y:471,t:1527268523758};\\\", \\\"{x:737,y:471,t:1527268523774};\\\", \\\"{x:747,y:471,t:1527268523790};\\\", \\\"{x:759,y:471,t:1527268523807};\\\", \\\"{x:773,y:471,t:1527268523824};\\\", \\\"{x:784,y:471,t:1527268523840};\\\", \\\"{x:797,y:471,t:1527268523857};\\\", \\\"{x:812,y:471,t:1527268523874};\\\", \\\"{x:825,y:472,t:1527268523890};\\\", \\\"{x:838,y:476,t:1527268523907};\\\", \\\"{x:857,y:479,t:1527268523925};\\\", \\\"{x:878,y:486,t:1527268523940};\\\", \\\"{x:906,y:493,t:1527268523958};\\\", \\\"{x:947,y:502,t:1527268523975};\\\", \\\"{x:1003,y:512,t:1527268523991};\\\", \\\"{x:1085,y:527,t:1527268524007};\\\", \\\"{x:1157,y:537,t:1527268524024};\\\", \\\"{x:1243,y:548,t:1527268524041};\\\", \\\"{x:1358,y:556,t:1527268524057};\\\", \\\"{x:1520,y:578,t:1527268524073};\\\", \\\"{x:1609,y:592,t:1527268524091};\\\", \\\"{x:1687,y:601,t:1527268524107};\\\", \\\"{x:1725,y:605,t:1527268524124};\\\", \\\"{x:1755,y:608,t:1527268524141};\\\", \\\"{x:1767,y:611,t:1527268524157};\\\", \\\"{x:1773,y:612,t:1527268524174};\\\", \\\"{x:1774,y:612,t:1527268524192};\\\", \\\"{x:1773,y:612,t:1527268524395};\\\", \\\"{x:1770,y:612,t:1527268524408};\\\", \\\"{x:1763,y:612,t:1527268524425};\\\", \\\"{x:1758,y:612,t:1527268524441};\\\", \\\"{x:1756,y:611,t:1527268524459};\\\", \\\"{x:1755,y:611,t:1527268524475};\\\", \\\"{x:1754,y:611,t:1527268524508};\\\", \\\"{x:1753,y:611,t:1527268524515};\\\", \\\"{x:1751,y:610,t:1527268524525};\\\", \\\"{x:1747,y:610,t:1527268524542};\\\", \\\"{x:1738,y:609,t:1527268524558};\\\", \\\"{x:1728,y:607,t:1527268524575};\\\", \\\"{x:1712,y:605,t:1527268524592};\\\", \\\"{x:1701,y:603,t:1527268524609};\\\", \\\"{x:1684,y:602,t:1527268524625};\\\", \\\"{x:1667,y:602,t:1527268524642};\\\", \\\"{x:1635,y:602,t:1527268524659};\\\", \\\"{x:1612,y:602,t:1527268524675};\\\", \\\"{x:1589,y:602,t:1527268524692};\\\", \\\"{x:1575,y:602,t:1527268524708};\\\", \\\"{x:1567,y:600,t:1527268524725};\\\", \\\"{x:1563,y:600,t:1527268524742};\\\", \\\"{x:1560,y:600,t:1527268524759};\\\", \\\"{x:1558,y:600,t:1527268524775};\\\", \\\"{x:1556,y:600,t:1527268524792};\\\", \\\"{x:1551,y:601,t:1527268524809};\\\", \\\"{x:1543,y:604,t:1527268524826};\\\", \\\"{x:1533,y:608,t:1527268524842};\\\", \\\"{x:1520,y:611,t:1527268524859};\\\", \\\"{x:1514,y:613,t:1527268524876};\\\", \\\"{x:1511,y:614,t:1527268524892};\\\", \\\"{x:1509,y:614,t:1527268524909};\\\", \\\"{x:1507,y:616,t:1527268524932};\\\", \\\"{x:1506,y:616,t:1527268524947};\\\", \\\"{x:1504,y:617,t:1527268524958};\\\", \\\"{x:1501,y:618,t:1527268524975};\\\", \\\"{x:1496,y:620,t:1527268524992};\\\", \\\"{x:1492,y:622,t:1527268525008};\\\", \\\"{x:1491,y:624,t:1527268525025};\\\", \\\"{x:1490,y:627,t:1527268525042};\\\", \\\"{x:1489,y:644,t:1527268525059};\\\", \\\"{x:1491,y:656,t:1527268525075};\\\", \\\"{x:1493,y:672,t:1527268525092};\\\", \\\"{x:1493,y:678,t:1527268525109};\\\", \\\"{x:1493,y:681,t:1527268525126};\\\", \\\"{x:1493,y:684,t:1527268525142};\\\", \\\"{x:1493,y:686,t:1527268525158};\\\", \\\"{x:1492,y:687,t:1527268525176};\\\", \\\"{x:1491,y:689,t:1527268525192};\\\", \\\"{x:1489,y:690,t:1527268525208};\\\", \\\"{x:1486,y:691,t:1527268525226};\\\", \\\"{x:1483,y:692,t:1527268525242};\\\", \\\"{x:1476,y:692,t:1527268525260};\\\", \\\"{x:1468,y:692,t:1527268525275};\\\", \\\"{x:1451,y:692,t:1527268525292};\\\", \\\"{x:1424,y:692,t:1527268525308};\\\", \\\"{x:1394,y:692,t:1527268525326};\\\", \\\"{x:1358,y:692,t:1527268525343};\\\", \\\"{x:1316,y:692,t:1527268525358};\\\", \\\"{x:1269,y:692,t:1527268525375};\\\", \\\"{x:1236,y:692,t:1527268525392};\\\", \\\"{x:1197,y:692,t:1527268525408};\\\", \\\"{x:1158,y:692,t:1527268525425};\\\", \\\"{x:1101,y:690,t:1527268525442};\\\", \\\"{x:1070,y:683,t:1527268525458};\\\", \\\"{x:1038,y:672,t:1527268525475};\\\", \\\"{x:1003,y:657,t:1527268525492};\\\", \\\"{x:955,y:637,t:1527268525508};\\\", \\\"{x:900,y:611,t:1527268525526};\\\", \\\"{x:848,y:590,t:1527268525543};\\\", \\\"{x:794,y:570,t:1527268525556};\\\", \\\"{x:741,y:558,t:1527268525574};\\\", \\\"{x:691,y:544,t:1527268525591};\\\", \\\"{x:648,y:535,t:1527268525608};\\\", \\\"{x:611,y:529,t:1527268525626};\\\", \\\"{x:580,y:525,t:1527268525642};\\\", \\\"{x:567,y:525,t:1527268525658};\\\", \\\"{x:559,y:525,t:1527268525675};\\\", \\\"{x:552,y:524,t:1527268525692};\\\", \\\"{x:551,y:523,t:1527268525709};\\\", \\\"{x:550,y:523,t:1527268525786};\\\", \\\"{x:550,y:522,t:1527268525867};\\\", \\\"{x:550,y:519,t:1527268525876};\\\", \\\"{x:554,y:515,t:1527268525894};\\\", \\\"{x:564,y:509,t:1527268525909};\\\", \\\"{x:585,y:503,t:1527268525925};\\\", \\\"{x:609,y:501,t:1527268525943};\\\", \\\"{x:636,y:501,t:1527268525959};\\\", \\\"{x:670,y:501,t:1527268525975};\\\", \\\"{x:717,y:513,t:1527268525992};\\\", \\\"{x:764,y:527,t:1527268526010};\\\", \\\"{x:807,y:540,t:1527268526025};\\\", \\\"{x:862,y:560,t:1527268526043};\\\", \\\"{x:897,y:573,t:1527268526060};\\\", \\\"{x:928,y:589,t:1527268526075};\\\", \\\"{x:960,y:602,t:1527268526093};\\\", \\\"{x:1002,y:620,t:1527268526109};\\\", \\\"{x:1042,y:634,t:1527268526126};\\\", \\\"{x:1080,y:646,t:1527268526142};\\\", \\\"{x:1138,y:663,t:1527268526160};\\\", \\\"{x:1186,y:680,t:1527268526175};\\\", \\\"{x:1235,y:698,t:1527268526192};\\\", \\\"{x:1284,y:719,t:1527268526210};\\\", \\\"{x:1334,y:739,t:1527268526225};\\\", \\\"{x:1395,y:771,t:1527268526242};\\\", \\\"{x:1422,y:785,t:1527268526260};\\\", \\\"{x:1436,y:795,t:1527268526277};\\\", \\\"{x:1444,y:801,t:1527268526292};\\\", \\\"{x:1449,y:806,t:1527268526309};\\\", \\\"{x:1452,y:812,t:1527268526326};\\\", \\\"{x:1454,y:818,t:1527268526343};\\\", \\\"{x:1459,y:827,t:1527268526360};\\\", \\\"{x:1463,y:834,t:1527268526376};\\\", \\\"{x:1468,y:838,t:1527268526393};\\\", \\\"{x:1470,y:839,t:1527268526410};\\\", \\\"{x:1471,y:840,t:1527268526427};\\\", \\\"{x:1472,y:840,t:1527268526451};\\\", \\\"{x:1470,y:840,t:1527268526611};\\\", \\\"{x:1452,y:840,t:1527268526626};\\\", \\\"{x:1425,y:840,t:1527268526643};\\\", \\\"{x:1387,y:835,t:1527268526660};\\\", \\\"{x:1355,y:829,t:1527268526677};\\\", \\\"{x:1327,y:823,t:1527268526693};\\\", \\\"{x:1311,y:820,t:1527268526710};\\\", \\\"{x:1305,y:816,t:1527268526726};\\\", \\\"{x:1303,y:815,t:1527268526744};\\\", \\\"{x:1302,y:815,t:1527268526760};\\\", \\\"{x:1302,y:814,t:1527268526779};\\\", \\\"{x:1300,y:812,t:1527268526795};\\\", \\\"{x:1300,y:811,t:1527268526809};\\\", \\\"{x:1296,y:806,t:1527268526826};\\\", \\\"{x:1294,y:803,t:1527268526843};\\\", \\\"{x:1292,y:802,t:1527268526860};\\\", \\\"{x:1290,y:800,t:1527268526877};\\\", \\\"{x:1290,y:799,t:1527268526894};\\\", \\\"{x:1289,y:799,t:1527268526963};\\\", \\\"{x:1289,y:798,t:1527268526987};\\\", \\\"{x:1289,y:795,t:1527268527003};\\\", \\\"{x:1289,y:793,t:1527268527011};\\\", \\\"{x:1289,y:789,t:1527268527027};\\\", \\\"{x:1289,y:778,t:1527268527044};\\\", \\\"{x:1293,y:761,t:1527268527060};\\\", \\\"{x:1308,y:738,t:1527268527077};\\\", \\\"{x:1325,y:713,t:1527268527093};\\\", \\\"{x:1333,y:700,t:1527268527110};\\\", \\\"{x:1344,y:686,t:1527268527127};\\\", \\\"{x:1357,y:668,t:1527268527144};\\\", \\\"{x:1372,y:648,t:1527268527161};\\\", \\\"{x:1386,y:631,t:1527268527176};\\\", \\\"{x:1398,y:615,t:1527268527193};\\\", \\\"{x:1406,y:604,t:1527268527209};\\\", \\\"{x:1408,y:601,t:1527268527226};\\\", \\\"{x:1410,y:600,t:1527268527243};\\\", \\\"{x:1410,y:599,t:1527268527260};\\\", \\\"{x:1411,y:597,t:1527268527452};\\\", \\\"{x:1414,y:595,t:1527268527460};\\\", \\\"{x:1423,y:590,t:1527268527477};\\\", \\\"{x:1443,y:584,t:1527268527494};\\\", \\\"{x:1468,y:575,t:1527268527511};\\\", \\\"{x:1495,y:565,t:1527268527527};\\\", \\\"{x:1520,y:555,t:1527268527544};\\\", \\\"{x:1544,y:546,t:1527268527561};\\\", \\\"{x:1561,y:541,t:1527268527577};\\\", \\\"{x:1566,y:539,t:1527268527594};\\\", \\\"{x:1567,y:538,t:1527268527611};\\\", \\\"{x:1567,y:537,t:1527268527828};\\\", \\\"{x:1567,y:536,t:1527268527883};\\\", \\\"{x:1567,y:531,t:1527268527895};\\\", \\\"{x:1567,y:522,t:1527268527911};\\\", \\\"{x:1567,y:515,t:1527268527928};\\\", \\\"{x:1567,y:509,t:1527268527945};\\\", \\\"{x:1568,y:505,t:1527268527961};\\\", \\\"{x:1568,y:507,t:1527268528147};\\\", \\\"{x:1568,y:508,t:1527268528162};\\\", \\\"{x:1568,y:510,t:1527268528178};\\\", \\\"{x:1568,y:515,t:1527268528194};\\\", \\\"{x:1568,y:519,t:1527268528211};\\\", \\\"{x:1568,y:521,t:1527268528228};\\\", \\\"{x:1568,y:522,t:1527268528245};\\\", \\\"{x:1568,y:527,t:1527268528262};\\\", \\\"{x:1568,y:531,t:1527268528278};\\\", \\\"{x:1568,y:535,t:1527268528295};\\\", \\\"{x:1568,y:540,t:1527268528312};\\\", \\\"{x:1568,y:546,t:1527268528328};\\\", \\\"{x:1570,y:551,t:1527268528345};\\\", \\\"{x:1573,y:556,t:1527268528362};\\\", \\\"{x:1574,y:560,t:1527268528378};\\\", \\\"{x:1576,y:565,t:1527268528395};\\\", \\\"{x:1578,y:570,t:1527268528412};\\\", \\\"{x:1579,y:572,t:1527268528428};\\\", \\\"{x:1581,y:576,t:1527268528445};\\\", \\\"{x:1583,y:579,t:1527268528461};\\\", \\\"{x:1584,y:583,t:1527268528479};\\\", \\\"{x:1586,y:586,t:1527268528495};\\\", \\\"{x:1588,y:590,t:1527268528511};\\\", \\\"{x:1589,y:592,t:1527268528529};\\\", \\\"{x:1590,y:595,t:1527268528545};\\\", \\\"{x:1592,y:598,t:1527268528562};\\\", \\\"{x:1594,y:602,t:1527268528579};\\\", \\\"{x:1596,y:605,t:1527268528595};\\\", \\\"{x:1596,y:606,t:1527268528612};\\\", \\\"{x:1598,y:608,t:1527268528629};\\\", \\\"{x:1599,y:609,t:1527268528645};\\\", \\\"{x:1599,y:610,t:1527268528662};\\\", \\\"{x:1600,y:611,t:1527268528679};\\\", \\\"{x:1597,y:611,t:1527268528804};\\\", \\\"{x:1594,y:610,t:1527268528812};\\\", \\\"{x:1584,y:608,t:1527268528829};\\\", \\\"{x:1572,y:605,t:1527268528846};\\\", \\\"{x:1564,y:602,t:1527268528862};\\\", \\\"{x:1560,y:601,t:1527268528879};\\\", \\\"{x:1558,y:600,t:1527268528896};\\\", \\\"{x:1554,y:599,t:1527268528912};\\\", \\\"{x:1552,y:598,t:1527268528929};\\\", \\\"{x:1551,y:597,t:1527268528963};\\\", \\\"{x:1550,y:597,t:1527268528986};\\\", \\\"{x:1549,y:597,t:1527268528996};\\\", \\\"{x:1548,y:597,t:1527268529075};\\\", \\\"{x:1548,y:598,t:1527268529083};\\\", \\\"{x:1548,y:601,t:1527268529096};\\\", \\\"{x:1550,y:610,t:1527268529112};\\\", \\\"{x:1551,y:621,t:1527268529129};\\\", \\\"{x:1551,y:629,t:1527268529146};\\\", \\\"{x:1551,y:637,t:1527268529161};\\\", \\\"{x:1551,y:642,t:1527268529179};\\\", \\\"{x:1550,y:647,t:1527268529196};\\\", \\\"{x:1548,y:652,t:1527268529212};\\\", \\\"{x:1544,y:656,t:1527268529229};\\\", \\\"{x:1540,y:660,t:1527268529246};\\\", \\\"{x:1535,y:661,t:1527268529263};\\\", \\\"{x:1530,y:664,t:1527268529279};\\\", \\\"{x:1526,y:664,t:1527268529296};\\\", \\\"{x:1521,y:664,t:1527268529313};\\\", \\\"{x:1515,y:664,t:1527268529329};\\\", \\\"{x:1510,y:662,t:1527268529346};\\\", \\\"{x:1504,y:660,t:1527268529363};\\\", \\\"{x:1499,y:657,t:1527268529379};\\\", \\\"{x:1496,y:654,t:1527268529396};\\\", \\\"{x:1495,y:654,t:1527268529413};\\\", \\\"{x:1495,y:652,t:1527268529429};\\\", \\\"{x:1494,y:651,t:1527268529446};\\\", \\\"{x:1494,y:646,t:1527268529463};\\\", \\\"{x:1494,y:638,t:1527268529479};\\\", \\\"{x:1494,y:626,t:1527268529496};\\\", \\\"{x:1494,y:608,t:1527268529513};\\\", \\\"{x:1493,y:590,t:1527268529529};\\\", \\\"{x:1491,y:576,t:1527268529546};\\\", \\\"{x:1489,y:566,t:1527268529563};\\\", \\\"{x:1488,y:561,t:1527268529579};\\\", \\\"{x:1487,y:559,t:1527268529596};\\\", \\\"{x:1485,y:556,t:1527268529613};\\\", \\\"{x:1485,y:555,t:1527268529629};\\\", \\\"{x:1484,y:555,t:1527268529646};\\\", \\\"{x:1481,y:555,t:1527268529663};\\\", \\\"{x:1476,y:560,t:1527268529680};\\\", \\\"{x:1471,y:567,t:1527268529696};\\\", \\\"{x:1464,y:579,t:1527268529713};\\\", \\\"{x:1457,y:590,t:1527268529730};\\\", \\\"{x:1449,y:606,t:1527268529746};\\\", \\\"{x:1438,y:626,t:1527268529763};\\\", \\\"{x:1427,y:642,t:1527268529779};\\\", \\\"{x:1415,y:659,t:1527268529796};\\\", \\\"{x:1403,y:674,t:1527268529813};\\\", \\\"{x:1396,y:683,t:1527268529830};\\\", \\\"{x:1392,y:687,t:1527268529846};\\\", \\\"{x:1388,y:690,t:1527268529863};\\\", \\\"{x:1386,y:692,t:1527268529881};\\\", \\\"{x:1385,y:692,t:1527268529896};\\\", \\\"{x:1382,y:694,t:1527268529913};\\\", \\\"{x:1380,y:695,t:1527268529930};\\\", \\\"{x:1378,y:695,t:1527268529946};\\\", \\\"{x:1375,y:695,t:1527268529963};\\\", \\\"{x:1374,y:695,t:1527268529980};\\\", \\\"{x:1373,y:695,t:1527268529997};\\\", \\\"{x:1369,y:695,t:1527268530013};\\\", \\\"{x:1364,y:695,t:1527268530030};\\\", \\\"{x:1356,y:696,t:1527268530047};\\\", \\\"{x:1348,y:697,t:1527268530066};\\\", \\\"{x:1344,y:697,t:1527268530080};\\\", \\\"{x:1343,y:697,t:1527268530115};\\\", \\\"{x:1342,y:698,t:1527268530211};\\\", \\\"{x:1343,y:698,t:1527268530226};\\\", \\\"{x:1344,y:699,t:1527268530243};\\\", \\\"{x:1345,y:700,t:1527268530267};\\\", \\\"{x:1346,y:701,t:1527268530283};\\\", \\\"{x:1347,y:702,t:1527268530297};\\\", \\\"{x:1347,y:703,t:1527268530314};\\\", \\\"{x:1348,y:704,t:1527268530330};\\\", \\\"{x:1353,y:710,t:1527268530347};\\\", \\\"{x:1358,y:712,t:1527268530363};\\\", \\\"{x:1359,y:714,t:1527268530381};\\\", \\\"{x:1360,y:716,t:1527268530396};\\\", \\\"{x:1362,y:719,t:1527268530414};\\\", \\\"{x:1363,y:721,t:1527268530430};\\\", \\\"{x:1363,y:723,t:1527268530447};\\\", \\\"{x:1363,y:725,t:1527268530464};\\\", \\\"{x:1363,y:726,t:1527268530480};\\\", \\\"{x:1363,y:729,t:1527268530497};\\\", \\\"{x:1363,y:731,t:1527268530514};\\\", \\\"{x:1363,y:736,t:1527268530530};\\\", \\\"{x:1363,y:748,t:1527268530546};\\\", \\\"{x:1363,y:757,t:1527268530563};\\\", \\\"{x:1361,y:764,t:1527268530580};\\\", \\\"{x:1360,y:768,t:1527268530597};\\\", \\\"{x:1359,y:770,t:1527268530614};\\\", \\\"{x:1358,y:771,t:1527268530631};\\\", \\\"{x:1357,y:772,t:1527268530647};\\\", \\\"{x:1357,y:771,t:1527268531659};\\\", \\\"{x:1354,y:769,t:1527268531788};\\\", \\\"{x:1343,y:769,t:1527268531798};\\\", \\\"{x:1314,y:767,t:1527268531814};\\\", \\\"{x:1269,y:767,t:1527268531831};\\\", \\\"{x:1213,y:767,t:1527268531847};\\\", \\\"{x:1154,y:767,t:1527268531865};\\\", \\\"{x:1101,y:765,t:1527268531881};\\\", \\\"{x:1059,y:761,t:1527268531898};\\\", \\\"{x:1002,y:754,t:1527268531915};\\\", \\\"{x:971,y:752,t:1527268531931};\\\", \\\"{x:941,y:747,t:1527268531948};\\\", \\\"{x:913,y:743,t:1527268531964};\\\", \\\"{x:876,y:737,t:1527268531982};\\\", \\\"{x:840,y:734,t:1527268531998};\\\", \\\"{x:793,y:721,t:1527268532015};\\\", \\\"{x:762,y:703,t:1527268532031};\\\", \\\"{x:741,y:689,t:1527268532048};\\\", \\\"{x:723,y:680,t:1527268532065};\\\", \\\"{x:708,y:674,t:1527268532082};\\\", \\\"{x:693,y:670,t:1527268532098};\\\", \\\"{x:679,y:669,t:1527268532115};\\\", \\\"{x:669,y:668,t:1527268532132};\\\", \\\"{x:656,y:665,t:1527268532148};\\\", \\\"{x:644,y:662,t:1527268532165};\\\", \\\"{x:631,y:655,t:1527268532182};\\\", \\\"{x:622,y:652,t:1527268532197};\\\", \\\"{x:616,y:648,t:1527268532215};\\\", \\\"{x:611,y:645,t:1527268532232};\\\", \\\"{x:608,y:642,t:1527268532248};\\\", \\\"{x:606,y:639,t:1527268532265};\\\", \\\"{x:605,y:634,t:1527268532282};\\\", \\\"{x:605,y:629,t:1527268532299};\\\", \\\"{x:605,y:621,t:1527268532314};\\\", \\\"{x:605,y:614,t:1527268532331};\\\", \\\"{x:609,y:608,t:1527268532347};\\\", \\\"{x:612,y:603,t:1527268532365};\\\", \\\"{x:614,y:600,t:1527268532380};\\\", \\\"{x:618,y:596,t:1527268532397};\\\", \\\"{x:620,y:593,t:1527268532415};\\\", \\\"{x:623,y:589,t:1527268532430};\\\", \\\"{x:629,y:585,t:1527268532448};\\\", \\\"{x:639,y:580,t:1527268532464};\\\", \\\"{x:651,y:573,t:1527268532480};\\\", \\\"{x:664,y:565,t:1527268532497};\\\", \\\"{x:680,y:558,t:1527268532514};\\\", \\\"{x:689,y:554,t:1527268532531};\\\", \\\"{x:695,y:550,t:1527268532548};\\\", \\\"{x:698,y:549,t:1527268532564};\\\", \\\"{x:700,y:547,t:1527268532580};\\\", \\\"{x:704,y:545,t:1527268532597};\\\", \\\"{x:705,y:544,t:1527268532614};\\\", \\\"{x:711,y:541,t:1527268532630};\\\", \\\"{x:719,y:538,t:1527268532647};\\\", \\\"{x:731,y:534,t:1527268532665};\\\", \\\"{x:739,y:533,t:1527268532680};\\\", \\\"{x:750,y:530,t:1527268532697};\\\", \\\"{x:761,y:529,t:1527268532714};\\\", \\\"{x:766,y:529,t:1527268532730};\\\", \\\"{x:772,y:529,t:1527268532747};\\\", \\\"{x:777,y:529,t:1527268532764};\\\", \\\"{x:782,y:529,t:1527268532781};\\\", \\\"{x:789,y:529,t:1527268532798};\\\", \\\"{x:796,y:531,t:1527268532815};\\\", \\\"{x:800,y:531,t:1527268532831};\\\", \\\"{x:807,y:532,t:1527268532848};\\\", \\\"{x:816,y:534,t:1527268532864};\\\", \\\"{x:823,y:535,t:1527268532882};\\\", \\\"{x:829,y:536,t:1527268532897};\\\", \\\"{x:839,y:540,t:1527268532914};\\\", \\\"{x:846,y:544,t:1527268532932};\\\", \\\"{x:849,y:548,t:1527268532947};\\\", \\\"{x:849,y:554,t:1527268532964};\\\", \\\"{x:849,y:561,t:1527268532981};\\\", \\\"{x:849,y:572,t:1527268532997};\\\", \\\"{x:843,y:579,t:1527268533014};\\\", \\\"{x:833,y:587,t:1527268533031};\\\", \\\"{x:821,y:591,t:1527268533048};\\\", \\\"{x:804,y:598,t:1527268533065};\\\", \\\"{x:776,y:605,t:1527268533082};\\\", \\\"{x:733,y:612,t:1527268533097};\\\", \\\"{x:656,y:623,t:1527268533115};\\\", \\\"{x:619,y:629,t:1527268533131};\\\", \\\"{x:597,y:632,t:1527268533148};\\\", \\\"{x:576,y:635,t:1527268533164};\\\", \\\"{x:553,y:638,t:1527268533181};\\\", \\\"{x:528,y:642,t:1527268533198};\\\", \\\"{x:505,y:643,t:1527268533215};\\\", \\\"{x:479,y:645,t:1527268533233};\\\", \\\"{x:456,y:646,t:1527268533249};\\\", \\\"{x:431,y:646,t:1527268533264};\\\", \\\"{x:411,y:646,t:1527268533281};\\\", \\\"{x:396,y:646,t:1527268533298};\\\", \\\"{x:383,y:647,t:1527268533314};\\\", \\\"{x:377,y:648,t:1527268533332};\\\", \\\"{x:377,y:646,t:1527268533426};\\\", \\\"{x:380,y:645,t:1527268533434};\\\", \\\"{x:383,y:642,t:1527268533448};\\\", \\\"{x:398,y:637,t:1527268533466};\\\", \\\"{x:416,y:632,t:1527268533482};\\\", \\\"{x:453,y:627,t:1527268533499};\\\", \\\"{x:480,y:625,t:1527268533514};\\\", \\\"{x:508,y:623,t:1527268533532};\\\", \\\"{x:535,y:623,t:1527268533548};\\\", \\\"{x:562,y:623,t:1527268533565};\\\", \\\"{x:584,y:623,t:1527268533581};\\\", \\\"{x:604,y:623,t:1527268533599};\\\", \\\"{x:622,y:623,t:1527268533616};\\\", \\\"{x:637,y:623,t:1527268533631};\\\", \\\"{x:645,y:623,t:1527268533649};\\\", \\\"{x:655,y:623,t:1527268533665};\\\", \\\"{x:660,y:623,t:1527268533682};\\\", \\\"{x:664,y:622,t:1527268533698};\\\", \\\"{x:666,y:622,t:1527268533714};\\\", \\\"{x:667,y:622,t:1527268533731};\\\", \\\"{x:668,y:622,t:1527268533770};\\\", \\\"{x:669,y:622,t:1527268533827};\\\", \\\"{x:670,y:622,t:1527268533858};\\\", \\\"{x:672,y:622,t:1527268533883};\\\", \\\"{x:677,y:622,t:1527268533899};\\\", \\\"{x:690,y:620,t:1527268533915};\\\", \\\"{x:703,y:616,t:1527268533931};\\\", \\\"{x:717,y:611,t:1527268533949};\\\", \\\"{x:729,y:608,t:1527268533967};\\\", \\\"{x:741,y:605,t:1527268533981};\\\", \\\"{x:747,y:603,t:1527268533999};\\\", \\\"{x:752,y:601,t:1527268534015};\\\", \\\"{x:754,y:601,t:1527268534033};\\\", \\\"{x:755,y:601,t:1527268534048};\\\", \\\"{x:757,y:599,t:1527268534065};\\\", \\\"{x:761,y:599,t:1527268534081};\\\", \\\"{x:763,y:599,t:1527268534099};\\\", \\\"{x:765,y:598,t:1527268534115};\\\", \\\"{x:766,y:598,t:1527268534132};\\\", \\\"{x:764,y:598,t:1527268534212};\\\", \\\"{x:752,y:598,t:1527268534218};\\\", \\\"{x:730,y:602,t:1527268534233};\\\", \\\"{x:666,y:611,t:1527268534249};\\\", \\\"{x:610,y:619,t:1527268534266};\\\", \\\"{x:552,y:627,t:1527268534282};\\\", \\\"{x:532,y:629,t:1527268534298};\\\", \\\"{x:526,y:629,t:1527268534316};\\\", \\\"{x:525,y:629,t:1527268534331};\\\", \\\"{x:525,y:630,t:1527268534349};\\\", \\\"{x:524,y:630,t:1527268534386};\\\", \\\"{x:523,y:630,t:1527268534399};\\\", \\\"{x:522,y:631,t:1527268534414};\\\", \\\"{x:521,y:631,t:1527268534450};\\\", \\\"{x:519,y:631,t:1527268534465};\\\", \\\"{x:516,y:631,t:1527268534483};\\\", \\\"{x:513,y:629,t:1527268534498};\\\", \\\"{x:509,y:626,t:1527268534515};\\\", \\\"{x:503,y:618,t:1527268534532};\\\", \\\"{x:494,y:610,t:1527268534549};\\\", \\\"{x:485,y:605,t:1527268534564};\\\", \\\"{x:471,y:599,t:1527268534583};\\\", \\\"{x:460,y:595,t:1527268534599};\\\", \\\"{x:451,y:593,t:1527268534617};\\\", \\\"{x:439,y:591,t:1527268534632};\\\", \\\"{x:425,y:590,t:1527268534650};\\\", \\\"{x:410,y:590,t:1527268534666};\\\", \\\"{x:375,y:590,t:1527268534683};\\\", \\\"{x:344,y:590,t:1527268534700};\\\", \\\"{x:313,y:590,t:1527268534717};\\\", \\\"{x:274,y:590,t:1527268534732};\\\", \\\"{x:229,y:583,t:1527268534752};\\\", \\\"{x:195,y:577,t:1527268534767};\\\", \\\"{x:172,y:568,t:1527268534782};\\\", \\\"{x:156,y:562,t:1527268534800};\\\", \\\"{x:150,y:559,t:1527268534815};\\\", \\\"{x:149,y:558,t:1527268534833};\\\", \\\"{x:148,y:557,t:1527268534850};\\\", \\\"{x:147,y:556,t:1527268534866};\\\", \\\"{x:146,y:554,t:1527268534883};\\\", \\\"{x:144,y:551,t:1527268534900};\\\", \\\"{x:142,y:548,t:1527268534915};\\\", \\\"{x:140,y:547,t:1527268534932};\\\", \\\"{x:140,y:545,t:1527268534949};\\\", \\\"{x:139,y:543,t:1527268534967};\\\", \\\"{x:139,y:542,t:1527268534982};\\\", \\\"{x:139,y:540,t:1527268534999};\\\", \\\"{x:139,y:539,t:1527268535015};\\\", \\\"{x:139,y:537,t:1527268535034};\\\", \\\"{x:139,y:536,t:1527268535058};\\\", \\\"{x:141,y:536,t:1527268535066};\\\", \\\"{x:142,y:536,t:1527268535083};\\\", \\\"{x:144,y:536,t:1527268535099};\\\", \\\"{x:146,y:536,t:1527268535117};\\\", \\\"{x:149,y:536,t:1527268535133};\\\", \\\"{x:151,y:537,t:1527268535149};\\\", \\\"{x:153,y:538,t:1527268535166};\\\", \\\"{x:154,y:538,t:1527268535182};\\\", \\\"{x:156,y:539,t:1527268535199};\\\", \\\"{x:156,y:540,t:1527268535218};\\\", \\\"{x:158,y:540,t:1527268535242};\\\", \\\"{x:159,y:541,t:1527268535306};\\\", \\\"{x:160,y:542,t:1527268536315};\\\", \\\"{x:161,y:542,t:1527268536459};\\\", \\\"{x:168,y:542,t:1527268536468};\\\", \\\"{x:195,y:542,t:1527268536485};\\\", \\\"{x:237,y:542,t:1527268536501};\\\", \\\"{x:301,y:542,t:1527268536519};\\\", \\\"{x:376,y:542,t:1527268536534};\\\", \\\"{x:443,y:542,t:1527268536551};\\\", \\\"{x:518,y:542,t:1527268536568};\\\", \\\"{x:588,y:542,t:1527268536583};\\\", \\\"{x:655,y:542,t:1527268536601};\\\", \\\"{x:713,y:535,t:1527268536618};\\\", \\\"{x:759,y:532,t:1527268536635};\\\", \\\"{x:799,y:529,t:1527268536651};\\\", \\\"{x:817,y:527,t:1527268536668};\\\", \\\"{x:834,y:526,t:1527268536684};\\\", \\\"{x:848,y:523,t:1527268536701};\\\", \\\"{x:858,y:522,t:1527268536717};\\\", \\\"{x:869,y:522,t:1527268536734};\\\", \\\"{x:880,y:522,t:1527268536751};\\\", \\\"{x:892,y:522,t:1527268536768};\\\", \\\"{x:902,y:522,t:1527268536785};\\\", \\\"{x:909,y:522,t:1527268536800};\\\", \\\"{x:911,y:522,t:1527268536818};\\\", \\\"{x:914,y:522,t:1527268536835};\\\", \\\"{x:916,y:522,t:1527268536851};\\\", \\\"{x:918,y:524,t:1527268536868};\\\", \\\"{x:919,y:529,t:1527268536885};\\\", \\\"{x:921,y:541,t:1527268536901};\\\", \\\"{x:921,y:554,t:1527268536918};\\\", \\\"{x:920,y:571,t:1527268536935};\\\", \\\"{x:909,y:592,t:1527268536951};\\\", \\\"{x:891,y:618,t:1527268536968};\\\", \\\"{x:869,y:638,t:1527268536986};\\\", \\\"{x:836,y:657,t:1527268537000};\\\", \\\"{x:797,y:676,t:1527268537018};\\\", \\\"{x:750,y:691,t:1527268537035};\\\", \\\"{x:733,y:696,t:1527268537051};\\\", \\\"{x:717,y:700,t:1527268537068};\\\", \\\"{x:701,y:701,t:1527268537085};\\\", \\\"{x:684,y:704,t:1527268537101};\\\", \\\"{x:663,y:706,t:1527268537118};\\\", \\\"{x:638,y:710,t:1527268537135};\\\", \\\"{x:611,y:715,t:1527268537152};\\\", \\\"{x:589,y:717,t:1527268537168};\\\", \\\"{x:567,y:721,t:1527268537185};\\\", \\\"{x:554,y:721,t:1527268537203};\\\", \\\"{x:544,y:722,t:1527268537218};\\\", \\\"{x:541,y:722,t:1527268537235};\\\", \\\"{x:538,y:722,t:1527268537252};\\\", \\\"{x:537,y:722,t:1527268537268};\\\", \\\"{x:536,y:722,t:1527268537285};\\\", \\\"{x:535,y:722,t:1527268537302};\\\", \\\"{x:534,y:722,t:1527268537331};\\\", \\\"{x:533,y:722,t:1527268537338};\\\" ] }, { \\\"rt\\\": 33656, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 608395, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:722,t:1527268539299};\\\", \\\"{x:536,y:722,t:1527268539306};\\\", \\\"{x:537,y:722,t:1527268539322};\\\", \\\"{x:539,y:721,t:1527268539337};\\\", \\\"{x:541,y:721,t:1527268539355};\\\", \\\"{x:543,y:721,t:1527268539371};\\\", \\\"{x:545,y:720,t:1527268539387};\\\", \\\"{x:547,y:720,t:1527268539404};\\\", \\\"{x:548,y:718,t:1527268539422};\\\", \\\"{x:552,y:718,t:1527268539438};\\\", \\\"{x:556,y:717,t:1527268539452};\\\", \\\"{x:561,y:715,t:1527268539470};\\\", \\\"{x:584,y:707,t:1527268539559};\\\", \\\"{x:588,y:705,t:1527268539571};\\\", \\\"{x:593,y:703,t:1527268539586};\\\", \\\"{x:597,y:702,t:1527268539602};\\\", \\\"{x:600,y:701,t:1527268539620};\\\", \\\"{x:602,y:701,t:1527268539636};\\\", \\\"{x:603,y:701,t:1527268539654};\\\", \\\"{x:604,y:701,t:1527268539697};\\\", \\\"{x:605,y:701,t:1527268539729};\\\", \\\"{x:606,y:701,t:1527268539738};\\\", \\\"{x:608,y:701,t:1527268539754};\\\", \\\"{x:612,y:699,t:1527268539770};\\\", \\\"{x:615,y:698,t:1527268539786};\\\", \\\"{x:621,y:698,t:1527268539804};\\\", \\\"{x:629,y:698,t:1527268539820};\\\", \\\"{x:642,y:695,t:1527268539837};\\\", \\\"{x:655,y:692,t:1527268539854};\\\", \\\"{x:668,y:689,t:1527268539869};\\\", \\\"{x:682,y:683,t:1527268539887};\\\", \\\"{x:691,y:682,t:1527268539904};\\\", \\\"{x:697,y:679,t:1527268539920};\\\", \\\"{x:699,y:679,t:1527268539937};\\\", \\\"{x:700,y:679,t:1527268540307};\\\", \\\"{x:708,y:678,t:1527268540321};\\\", \\\"{x:722,y:678,t:1527268540338};\\\", \\\"{x:752,y:678,t:1527268540355};\\\", \\\"{x:776,y:678,t:1527268540371};\\\", \\\"{x:799,y:678,t:1527268540387};\\\", \\\"{x:816,y:680,t:1527268540405};\\\", \\\"{x:831,y:682,t:1527268540421};\\\", \\\"{x:846,y:686,t:1527268540437};\\\", \\\"{x:856,y:689,t:1527268540454};\\\", \\\"{x:860,y:690,t:1527268540471};\\\", \\\"{x:862,y:691,t:1527268540488};\\\", \\\"{x:864,y:691,t:1527268540504};\\\", \\\"{x:865,y:691,t:1527268540563};\\\", \\\"{x:865,y:693,t:1527268540755};\\\", \\\"{x:857,y:694,t:1527268540771};\\\", \\\"{x:851,y:694,t:1527268540788};\\\", \\\"{x:845,y:694,t:1527268540805};\\\", \\\"{x:837,y:694,t:1527268540821};\\\", \\\"{x:826,y:694,t:1527268540838};\\\", \\\"{x:812,y:688,t:1527268540855};\\\", \\\"{x:803,y:682,t:1527268540871};\\\", \\\"{x:788,y:674,t:1527268540888};\\\", \\\"{x:772,y:661,t:1527268540905};\\\", \\\"{x:758,y:644,t:1527268540921};\\\", \\\"{x:732,y:616,t:1527268540940};\\\", \\\"{x:720,y:601,t:1527268540955};\\\", \\\"{x:712,y:588,t:1527268540972};\\\", \\\"{x:706,y:579,t:1527268540988};\\\", \\\"{x:701,y:568,t:1527268541004};\\\", \\\"{x:700,y:557,t:1527268541021};\\\", \\\"{x:697,y:545,t:1527268541038};\\\", \\\"{x:692,y:531,t:1527268541055};\\\", \\\"{x:690,y:515,t:1527268541072};\\\", \\\"{x:687,y:505,t:1527268541087};\\\", \\\"{x:685,y:497,t:1527268541104};\\\", \\\"{x:681,y:492,t:1527268541120};\\\", \\\"{x:678,y:482,t:1527268541138};\\\", \\\"{x:675,y:476,t:1527268541154};\\\", \\\"{x:673,y:474,t:1527268541170};\\\", \\\"{x:669,y:470,t:1527268541188};\\\", \\\"{x:664,y:469,t:1527268541204};\\\", \\\"{x:661,y:468,t:1527268541221};\\\", \\\"{x:658,y:466,t:1527268541238};\\\", \\\"{x:656,y:466,t:1527268541255};\\\", \\\"{x:651,y:466,t:1527268541270};\\\", \\\"{x:645,y:466,t:1527268541288};\\\", \\\"{x:635,y:466,t:1527268541304};\\\", \\\"{x:622,y:466,t:1527268541321};\\\", \\\"{x:602,y:466,t:1527268541338};\\\", \\\"{x:589,y:466,t:1527268541355};\\\", \\\"{x:581,y:466,t:1527268541371};\\\", \\\"{x:573,y:466,t:1527268541388};\\\", \\\"{x:567,y:466,t:1527268541405};\\\", \\\"{x:560,y:466,t:1527268541421};\\\", \\\"{x:556,y:466,t:1527268541438};\\\", \\\"{x:553,y:466,t:1527268541455};\\\", \\\"{x:549,y:466,t:1527268541471};\\\", \\\"{x:548,y:466,t:1527268541488};\\\", \\\"{x:547,y:466,t:1527268541505};\\\", \\\"{x:549,y:466,t:1527268541683};\\\", \\\"{x:553,y:466,t:1527268541690};\\\", \\\"{x:560,y:466,t:1527268541705};\\\", \\\"{x:580,y:471,t:1527268541722};\\\", \\\"{x:614,y:474,t:1527268541739};\\\", \\\"{x:639,y:479,t:1527268541754};\\\", \\\"{x:662,y:482,t:1527268541772};\\\", \\\"{x:679,y:484,t:1527268541789};\\\", \\\"{x:687,y:484,t:1527268541805};\\\", \\\"{x:692,y:484,t:1527268541821};\\\", \\\"{x:695,y:484,t:1527268541838};\\\", \\\"{x:696,y:484,t:1527268541855};\\\", \\\"{x:698,y:484,t:1527268541871};\\\", \\\"{x:699,y:484,t:1527268541889};\\\", \\\"{x:703,y:484,t:1527268541905};\\\", \\\"{x:708,y:484,t:1527268541922};\\\", \\\"{x:718,y:487,t:1527268541939};\\\", \\\"{x:722,y:487,t:1527268541954};\\\", \\\"{x:728,y:488,t:1527268541972};\\\", \\\"{x:734,y:488,t:1527268541989};\\\", \\\"{x:740,y:488,t:1527268542004};\\\", \\\"{x:748,y:489,t:1527268542022};\\\", \\\"{x:756,y:491,t:1527268542039};\\\", \\\"{x:763,y:492,t:1527268542055};\\\", \\\"{x:771,y:493,t:1527268542072};\\\", \\\"{x:779,y:495,t:1527268542089};\\\", \\\"{x:787,y:497,t:1527268542105};\\\", \\\"{x:806,y:500,t:1527268542121};\\\", \\\"{x:820,y:501,t:1527268542139};\\\", \\\"{x:832,y:503,t:1527268542156};\\\", \\\"{x:844,y:505,t:1527268542172};\\\", \\\"{x:854,y:506,t:1527268542189};\\\", \\\"{x:864,y:507,t:1527268542206};\\\", \\\"{x:871,y:507,t:1527268542223};\\\", \\\"{x:880,y:508,t:1527268542239};\\\", \\\"{x:888,y:508,t:1527268542255};\\\", \\\"{x:897,y:508,t:1527268542272};\\\", \\\"{x:905,y:508,t:1527268542289};\\\", \\\"{x:920,y:508,t:1527268542306};\\\", \\\"{x:939,y:510,t:1527268542322};\\\", \\\"{x:957,y:512,t:1527268542340};\\\", \\\"{x:982,y:517,t:1527268542355};\\\", \\\"{x:1008,y:519,t:1527268542372};\\\", \\\"{x:1037,y:524,t:1527268542389};\\\", \\\"{x:1070,y:529,t:1527268542405};\\\", \\\"{x:1108,y:535,t:1527268542422};\\\", \\\"{x:1146,y:538,t:1527268542439};\\\", \\\"{x:1187,y:542,t:1527268542456};\\\", \\\"{x:1222,y:543,t:1527268542472};\\\", \\\"{x:1256,y:548,t:1527268542489};\\\", \\\"{x:1294,y:554,t:1527268542506};\\\", \\\"{x:1316,y:556,t:1527268542521};\\\", \\\"{x:1336,y:561,t:1527268542539};\\\", \\\"{x:1354,y:562,t:1527268542556};\\\", \\\"{x:1361,y:564,t:1527268542572};\\\", \\\"{x:1363,y:564,t:1527268542589};\\\", \\\"{x:1364,y:564,t:1527268542607};\\\", \\\"{x:1365,y:564,t:1527268542819};\\\", \\\"{x:1366,y:564,t:1527268542899};\\\", \\\"{x:1368,y:564,t:1527268542907};\\\", \\\"{x:1369,y:563,t:1527268542922};\\\", \\\"{x:1371,y:563,t:1527268543019};\\\", \\\"{x:1372,y:563,t:1527268543027};\\\", \\\"{x:1373,y:563,t:1527268543040};\\\", \\\"{x:1376,y:563,t:1527268543056};\\\", \\\"{x:1381,y:565,t:1527268543074};\\\", \\\"{x:1385,y:566,t:1527268543090};\\\", \\\"{x:1390,y:569,t:1527268543106};\\\", \\\"{x:1394,y:570,t:1527268543123};\\\", \\\"{x:1395,y:570,t:1527268543140};\\\", \\\"{x:1396,y:571,t:1527268543157};\\\", \\\"{x:1397,y:571,t:1527268543173};\\\", \\\"{x:1397,y:572,t:1527268543211};\\\", \\\"{x:1398,y:572,t:1527268543251};\\\", \\\"{x:1399,y:573,t:1527268543267};\\\", \\\"{x:1400,y:573,t:1527268543283};\\\", \\\"{x:1401,y:574,t:1527268543291};\\\", \\\"{x:1402,y:575,t:1527268543315};\\\", \\\"{x:1404,y:576,t:1527268543339};\\\", \\\"{x:1406,y:576,t:1527268543363};\\\", \\\"{x:1408,y:578,t:1527268543379};\\\", \\\"{x:1410,y:578,t:1527268543391};\\\", \\\"{x:1418,y:580,t:1527268543406};\\\", \\\"{x:1428,y:584,t:1527268543423};\\\", \\\"{x:1443,y:588,t:1527268543440};\\\", \\\"{x:1456,y:592,t:1527268543456};\\\", \\\"{x:1469,y:593,t:1527268543474};\\\", \\\"{x:1495,y:597,t:1527268543491};\\\", \\\"{x:1515,y:599,t:1527268543507};\\\", \\\"{x:1533,y:603,t:1527268543524};\\\", \\\"{x:1558,y:605,t:1527268543540};\\\", \\\"{x:1580,y:608,t:1527268543557};\\\", \\\"{x:1597,y:608,t:1527268543573};\\\", \\\"{x:1615,y:609,t:1527268543591};\\\", \\\"{x:1633,y:611,t:1527268543607};\\\", \\\"{x:1642,y:613,t:1527268543623};\\\", \\\"{x:1647,y:614,t:1527268543640};\\\", \\\"{x:1653,y:616,t:1527268543656};\\\", \\\"{x:1659,y:618,t:1527268543673};\\\", \\\"{x:1671,y:622,t:1527268543691};\\\", \\\"{x:1680,y:626,t:1527268543707};\\\", \\\"{x:1688,y:629,t:1527268543724};\\\", \\\"{x:1693,y:632,t:1527268543741};\\\", \\\"{x:1697,y:634,t:1527268543756};\\\", \\\"{x:1700,y:636,t:1527268543773};\\\", \\\"{x:1702,y:637,t:1527268543791};\\\", \\\"{x:1702,y:638,t:1527268543819};\\\", \\\"{x:1703,y:639,t:1527268543843};\\\", \\\"{x:1703,y:640,t:1527268543859};\\\", \\\"{x:1703,y:641,t:1527268543874};\\\", \\\"{x:1703,y:648,t:1527268543891};\\\", \\\"{x:1703,y:652,t:1527268543907};\\\", \\\"{x:1703,y:659,t:1527268543923};\\\", \\\"{x:1701,y:667,t:1527268543940};\\\", \\\"{x:1694,y:676,t:1527268543957};\\\", \\\"{x:1684,y:685,t:1527268543974};\\\", \\\"{x:1673,y:691,t:1527268543990};\\\", \\\"{x:1666,y:694,t:1527268544008};\\\", \\\"{x:1660,y:697,t:1527268544023};\\\", \\\"{x:1655,y:698,t:1527268544040};\\\", \\\"{x:1651,y:701,t:1527268544057};\\\", \\\"{x:1650,y:701,t:1527268544074};\\\", \\\"{x:1647,y:701,t:1527268544091};\\\", \\\"{x:1645,y:702,t:1527268544115};\\\", \\\"{x:1644,y:702,t:1527268544267};\\\", \\\"{x:1643,y:703,t:1527268544273};\\\", \\\"{x:1643,y:704,t:1527268544290};\\\", \\\"{x:1642,y:704,t:1527268544411};\\\", \\\"{x:1641,y:704,t:1527268544424};\\\", \\\"{x:1637,y:704,t:1527268544440};\\\", \\\"{x:1633,y:704,t:1527268544458};\\\", \\\"{x:1628,y:704,t:1527268544475};\\\", \\\"{x:1626,y:704,t:1527268544490};\\\", \\\"{x:1624,y:704,t:1527268544507};\\\", \\\"{x:1623,y:704,t:1527268544579};\\\", \\\"{x:1622,y:704,t:1527268544635};\\\", \\\"{x:1621,y:703,t:1527268544643};\\\", \\\"{x:1620,y:703,t:1527268544675};\\\", \\\"{x:1617,y:702,t:1527268544699};\\\", \\\"{x:1617,y:701,t:1527268544717};\\\", \\\"{x:1616,y:701,t:1527268544741};\\\", \\\"{x:1615,y:701,t:1527268544762};\\\", \\\"{x:1614,y:701,t:1527268544774};\\\", \\\"{x:1614,y:700,t:1527268544794};\\\", \\\"{x:1613,y:700,t:1527268545315};\\\", \\\"{x:1613,y:699,t:1527268545419};\\\", \\\"{x:1614,y:699,t:1527268546251};\\\", \\\"{x:1615,y:699,t:1527268546290};\\\", \\\"{x:1616,y:699,t:1527268546371};\\\", \\\"{x:1617,y:699,t:1527268546443};\\\", \\\"{x:1618,y:699,t:1527268547002};\\\", \\\"{x:1617,y:699,t:1527268547323};\\\", \\\"{x:1606,y:699,t:1527268547332};\\\", \\\"{x:1589,y:699,t:1527268547343};\\\", \\\"{x:1550,y:699,t:1527268547360};\\\", \\\"{x:1497,y:699,t:1527268547377};\\\", \\\"{x:1441,y:699,t:1527268547394};\\\", \\\"{x:1374,y:699,t:1527268547409};\\\", \\\"{x:1283,y:687,t:1527268547426};\\\", \\\"{x:1218,y:673,t:1527268547444};\\\", \\\"{x:1151,y:656,t:1527268547459};\\\", \\\"{x:1068,y:629,t:1527268547476};\\\", \\\"{x:988,y:611,t:1527268547493};\\\", \\\"{x:933,y:596,t:1527268547510};\\\", \\\"{x:882,y:588,t:1527268547528};\\\", \\\"{x:843,y:583,t:1527268547543};\\\", \\\"{x:798,y:583,t:1527268547576};\\\", \\\"{x:785,y:583,t:1527268547591};\\\", \\\"{x:772,y:582,t:1527268547608};\\\", \\\"{x:748,y:582,t:1527268547625};\\\", \\\"{x:724,y:582,t:1527268547641};\\\", \\\"{x:685,y:582,t:1527268547658};\\\", \\\"{x:658,y:582,t:1527268547675};\\\", \\\"{x:635,y:582,t:1527268547694};\\\", \\\"{x:615,y:582,t:1527268547709};\\\", \\\"{x:607,y:582,t:1527268547726};\\\", \\\"{x:606,y:582,t:1527268547743};\\\", \\\"{x:606,y:581,t:1527268547760};\\\", \\\"{x:605,y:581,t:1527268547810};\\\", \\\"{x:604,y:580,t:1527268547842};\\\", \\\"{x:604,y:579,t:1527268547939};\\\", \\\"{x:604,y:577,t:1527268547955};\\\", \\\"{x:608,y:574,t:1527268547962};\\\", \\\"{x:613,y:571,t:1527268547977};\\\", \\\"{x:631,y:567,t:1527268547993};\\\", \\\"{x:669,y:560,t:1527268548012};\\\", \\\"{x:699,y:557,t:1527268548027};\\\", \\\"{x:732,y:555,t:1527268548043};\\\", \\\"{x:764,y:552,t:1527268548060};\\\", \\\"{x:798,y:551,t:1527268548076};\\\", \\\"{x:823,y:548,t:1527268548093};\\\", \\\"{x:839,y:546,t:1527268548110};\\\", \\\"{x:849,y:544,t:1527268548126};\\\", \\\"{x:852,y:543,t:1527268548143};\\\", \\\"{x:853,y:542,t:1527268548242};\\\", \\\"{x:853,y:541,t:1527268548315};\\\", \\\"{x:853,y:540,t:1527268548327};\\\", \\\"{x:852,y:539,t:1527268548344};\\\", \\\"{x:850,y:537,t:1527268548360};\\\", \\\"{x:848,y:534,t:1527268548378};\\\", \\\"{x:847,y:530,t:1527268548394};\\\", \\\"{x:845,y:527,t:1527268548411};\\\", \\\"{x:845,y:526,t:1527268548427};\\\", \\\"{x:845,y:524,t:1527268548466};\\\", \\\"{x:845,y:523,t:1527268548481};\\\", \\\"{x:844,y:521,t:1527268548498};\\\", \\\"{x:844,y:520,t:1527268548522};\\\", \\\"{x:844,y:518,t:1527268548554};\\\", \\\"{x:844,y:517,t:1527268548603};\\\", \\\"{x:843,y:515,t:1527268548618};\\\", \\\"{x:843,y:514,t:1527268548633};\\\", \\\"{x:842,y:512,t:1527268548644};\\\", \\\"{x:842,y:511,t:1527268548666};\\\", \\\"{x:842,y:510,t:1527268548682};\\\", \\\"{x:841,y:508,t:1527268548694};\\\", \\\"{x:841,y:507,t:1527268548714};\\\", \\\"{x:841,y:505,t:1527268548727};\\\", \\\"{x:840,y:503,t:1527268548755};\\\", \\\"{x:840,y:502,t:1527268549170};\\\", \\\"{x:844,y:503,t:1527268549178};\\\", \\\"{x:872,y:514,t:1527268549195};\\\", \\\"{x:914,y:527,t:1527268549211};\\\", \\\"{x:976,y:546,t:1527268549228};\\\", \\\"{x:1042,y:563,t:1527268549244};\\\", \\\"{x:1119,y:581,t:1527268549261};\\\", \\\"{x:1177,y:596,t:1527268549277};\\\", \\\"{x:1218,y:606,t:1527268549294};\\\", \\\"{x:1247,y:613,t:1527268549312};\\\", \\\"{x:1270,y:621,t:1527268549328};\\\", \\\"{x:1291,y:627,t:1527268549345};\\\", \\\"{x:1306,y:630,t:1527268549361};\\\", \\\"{x:1313,y:632,t:1527268549378};\\\", \\\"{x:1322,y:636,t:1527268549394};\\\", \\\"{x:1329,y:637,t:1527268549412};\\\", \\\"{x:1337,y:641,t:1527268549429};\\\", \\\"{x:1343,y:644,t:1527268549445};\\\", \\\"{x:1349,y:647,t:1527268549461};\\\", \\\"{x:1357,y:651,t:1527268549479};\\\", \\\"{x:1368,y:657,t:1527268549494};\\\", \\\"{x:1372,y:660,t:1527268549511};\\\", \\\"{x:1376,y:663,t:1527268549528};\\\", \\\"{x:1385,y:667,t:1527268549545};\\\", \\\"{x:1397,y:672,t:1527268549561};\\\", \\\"{x:1422,y:683,t:1527268549578};\\\", \\\"{x:1443,y:692,t:1527268549594};\\\", \\\"{x:1466,y:701,t:1527268549611};\\\", \\\"{x:1493,y:712,t:1527268549628};\\\", \\\"{x:1511,y:717,t:1527268549644};\\\", \\\"{x:1521,y:720,t:1527268549661};\\\", \\\"{x:1525,y:720,t:1527268549678};\\\", \\\"{x:1527,y:721,t:1527268549694};\\\", \\\"{x:1528,y:721,t:1527268549712};\\\", \\\"{x:1530,y:722,t:1527268549731};\\\", \\\"{x:1532,y:723,t:1527268549745};\\\", \\\"{x:1534,y:723,t:1527268549762};\\\", \\\"{x:1540,y:724,t:1527268549778};\\\", \\\"{x:1542,y:724,t:1527268549796};\\\", \\\"{x:1543,y:724,t:1527268549811};\\\", \\\"{x:1544,y:725,t:1527268550211};\\\", \\\"{x:1544,y:726,t:1527268550234};\\\", \\\"{x:1545,y:727,t:1527268550246};\\\", \\\"{x:1545,y:728,t:1527268550263};\\\", \\\"{x:1545,y:730,t:1527268550279};\\\", \\\"{x:1545,y:733,t:1527268550296};\\\", \\\"{x:1545,y:735,t:1527268550313};\\\", \\\"{x:1545,y:737,t:1527268550328};\\\", \\\"{x:1545,y:743,t:1527268550346};\\\", \\\"{x:1544,y:749,t:1527268550362};\\\", \\\"{x:1542,y:756,t:1527268550379};\\\", \\\"{x:1540,y:759,t:1527268550396};\\\", \\\"{x:1539,y:764,t:1527268550413};\\\", \\\"{x:1537,y:765,t:1527268550431};\\\", \\\"{x:1537,y:767,t:1527268550446};\\\", \\\"{x:1536,y:767,t:1527268550491};\\\", \\\"{x:1534,y:767,t:1527268550499};\\\", \\\"{x:1533,y:768,t:1527268550513};\\\", \\\"{x:1529,y:770,t:1527268550530};\\\", \\\"{x:1525,y:771,t:1527268550547};\\\", \\\"{x:1520,y:771,t:1527268550563};\\\", \\\"{x:1518,y:771,t:1527268550580};\\\", \\\"{x:1515,y:771,t:1527268550597};\\\", \\\"{x:1513,y:771,t:1527268550612};\\\", \\\"{x:1512,y:771,t:1527268550635};\\\", \\\"{x:1511,y:771,t:1527268550646};\\\", \\\"{x:1510,y:771,t:1527268550663};\\\", \\\"{x:1509,y:770,t:1527268550684};\\\", \\\"{x:1508,y:770,t:1527268550698};\\\", \\\"{x:1507,y:770,t:1527268550712};\\\", \\\"{x:1508,y:770,t:1527268555451};\\\", \\\"{x:1510,y:774,t:1527268555468};\\\", \\\"{x:1512,y:777,t:1527268555484};\\\", \\\"{x:1514,y:778,t:1527268555501};\\\", \\\"{x:1515,y:781,t:1527268555518};\\\", \\\"{x:1516,y:782,t:1527268555534};\\\", \\\"{x:1517,y:782,t:1527268555551};\\\", \\\"{x:1517,y:784,t:1527268555568};\\\", \\\"{x:1518,y:785,t:1527268555584};\\\", \\\"{x:1520,y:786,t:1527268555601};\\\", \\\"{x:1520,y:788,t:1527268555617};\\\", \\\"{x:1520,y:789,t:1527268555633};\\\", \\\"{x:1521,y:791,t:1527268555650};\\\", \\\"{x:1522,y:793,t:1527268555668};\\\", \\\"{x:1522,y:794,t:1527268555698};\\\", \\\"{x:1522,y:795,t:1527268555714};\\\", \\\"{x:1523,y:796,t:1527268555721};\\\", \\\"{x:1523,y:797,t:1527268555738};\\\", \\\"{x:1523,y:798,t:1527268555750};\\\", \\\"{x:1523,y:799,t:1527268555767};\\\", \\\"{x:1523,y:800,t:1527268555785};\\\", \\\"{x:1523,y:802,t:1527268555800};\\\", \\\"{x:1524,y:805,t:1527268555818};\\\", \\\"{x:1524,y:806,t:1527268555834};\\\", \\\"{x:1525,y:810,t:1527268555851};\\\", \\\"{x:1526,y:814,t:1527268555867};\\\", \\\"{x:1527,y:817,t:1527268555885};\\\", \\\"{x:1528,y:821,t:1527268555900};\\\", \\\"{x:1528,y:824,t:1527268555917};\\\", \\\"{x:1530,y:826,t:1527268555935};\\\", \\\"{x:1530,y:827,t:1527268555951};\\\", \\\"{x:1531,y:828,t:1527268555968};\\\", \\\"{x:1532,y:830,t:1527268555985};\\\", \\\"{x:1533,y:831,t:1527268556002};\\\", \\\"{x:1534,y:833,t:1527268556019};\\\", \\\"{x:1535,y:834,t:1527268556035};\\\", \\\"{x:1536,y:834,t:1527268556051};\\\", \\\"{x:1537,y:836,t:1527268556068};\\\", \\\"{x:1538,y:836,t:1527268556090};\\\", \\\"{x:1539,y:837,t:1527268556101};\\\", \\\"{x:1540,y:837,t:1527268556138};\\\", \\\"{x:1539,y:838,t:1527268556387};\\\", \\\"{x:1535,y:840,t:1527268556403};\\\", \\\"{x:1529,y:840,t:1527268556419};\\\", \\\"{x:1525,y:841,t:1527268556435};\\\", \\\"{x:1520,y:841,t:1527268556452};\\\", \\\"{x:1518,y:843,t:1527268556469};\\\", \\\"{x:1516,y:843,t:1527268556486};\\\", \\\"{x:1515,y:843,t:1527268556502};\\\", \\\"{x:1514,y:843,t:1527268556522};\\\", \\\"{x:1515,y:843,t:1527268556683};\\\", \\\"{x:1516,y:843,t:1527268556690};\\\", \\\"{x:1518,y:843,t:1527268556701};\\\", \\\"{x:1523,y:843,t:1527268556719};\\\", \\\"{x:1529,y:843,t:1527268556734};\\\", \\\"{x:1537,y:843,t:1527268556752};\\\", \\\"{x:1547,y:843,t:1527268556768};\\\", \\\"{x:1555,y:843,t:1527268556784};\\\", \\\"{x:1567,y:843,t:1527268556802};\\\", \\\"{x:1575,y:843,t:1527268556818};\\\", \\\"{x:1582,y:843,t:1527268556834};\\\", \\\"{x:1587,y:843,t:1527268556851};\\\", \\\"{x:1594,y:843,t:1527268556869};\\\", \\\"{x:1600,y:843,t:1527268556885};\\\", \\\"{x:1605,y:843,t:1527268556902};\\\", \\\"{x:1609,y:843,t:1527268556919};\\\", \\\"{x:1612,y:843,t:1527268556935};\\\", \\\"{x:1615,y:843,t:1527268556952};\\\", \\\"{x:1616,y:843,t:1527268556978};\\\", \\\"{x:1615,y:843,t:1527268557091};\\\", \\\"{x:1606,y:843,t:1527268557102};\\\", \\\"{x:1573,y:843,t:1527268557119};\\\", \\\"{x:1498,y:842,t:1527268557136};\\\", \\\"{x:1412,y:829,t:1527268557152};\\\", \\\"{x:1311,y:813,t:1527268557169};\\\", \\\"{x:1166,y:791,t:1527268557186};\\\", \\\"{x:1088,y:782,t:1527268557202};\\\", \\\"{x:1042,y:773,t:1527268557219};\\\", \\\"{x:1000,y:766,t:1527268557236};\\\", \\\"{x:983,y:761,t:1527268557253};\\\", \\\"{x:971,y:756,t:1527268557269};\\\", \\\"{x:966,y:752,t:1527268557286};\\\", \\\"{x:956,y:744,t:1527268557303};\\\", \\\"{x:943,y:727,t:1527268557319};\\\", \\\"{x:926,y:705,t:1527268557336};\\\", \\\"{x:905,y:684,t:1527268557354};\\\", \\\"{x:874,y:661,t:1527268557369};\\\", \\\"{x:825,y:639,t:1527268557386};\\\", \\\"{x:799,y:632,t:1527268557402};\\\", \\\"{x:779,y:626,t:1527268557419};\\\", \\\"{x:762,y:622,t:1527268557436};\\\", \\\"{x:748,y:621,t:1527268557452};\\\", \\\"{x:735,y:618,t:1527268557468};\\\", \\\"{x:725,y:616,t:1527268557485};\\\", \\\"{x:709,y:611,t:1527268557501};\\\", \\\"{x:689,y:603,t:1527268557517};\\\", \\\"{x:668,y:598,t:1527268557535};\\\", \\\"{x:640,y:589,t:1527268557551};\\\", \\\"{x:604,y:579,t:1527268557567};\\\", \\\"{x:577,y:572,t:1527268557584};\\\", \\\"{x:556,y:566,t:1527268557600};\\\", \\\"{x:536,y:562,t:1527268557617};\\\", \\\"{x:527,y:562,t:1527268557634};\\\", \\\"{x:517,y:562,t:1527268557651};\\\", \\\"{x:503,y:562,t:1527268557668};\\\", \\\"{x:489,y:562,t:1527268557685};\\\", \\\"{x:473,y:562,t:1527268557701};\\\", \\\"{x:455,y:562,t:1527268557717};\\\", \\\"{x:438,y:564,t:1527268557735};\\\", \\\"{x:420,y:567,t:1527268557751};\\\", \\\"{x:407,y:569,t:1527268557768};\\\", \\\"{x:402,y:571,t:1527268557784};\\\", \\\"{x:395,y:571,t:1527268557802};\\\", \\\"{x:387,y:573,t:1527268557818};\\\", \\\"{x:379,y:576,t:1527268557834};\\\", \\\"{x:363,y:578,t:1527268557852};\\\", \\\"{x:347,y:581,t:1527268557867};\\\", \\\"{x:326,y:583,t:1527268557884};\\\", \\\"{x:293,y:589,t:1527268557902};\\\", \\\"{x:237,y:597,t:1527268557918};\\\", \\\"{x:175,y:605,t:1527268557936};\\\", \\\"{x:126,y:616,t:1527268557952};\\\", \\\"{x:104,y:619,t:1527268557967};\\\", \\\"{x:92,y:623,t:1527268557985};\\\", \\\"{x:88,y:623,t:1527268558002};\\\", \\\"{x:89,y:623,t:1527268558123};\\\", \\\"{x:90,y:623,t:1527268558135};\\\", \\\"{x:93,y:623,t:1527268558152};\\\", \\\"{x:105,y:625,t:1527268558168};\\\", \\\"{x:124,y:631,t:1527268558185};\\\", \\\"{x:168,y:641,t:1527268558204};\\\", \\\"{x:201,y:645,t:1527268558218};\\\", \\\"{x:234,y:649,t:1527268558234};\\\", \\\"{x:270,y:653,t:1527268558252};\\\", \\\"{x:310,y:654,t:1527268558272};\\\", \\\"{x:346,y:656,t:1527268558285};\\\", \\\"{x:393,y:656,t:1527268558301};\\\", \\\"{x:436,y:656,t:1527268558319};\\\", \\\"{x:480,y:656,t:1527268558334};\\\", \\\"{x:520,y:656,t:1527268558352};\\\", \\\"{x:556,y:656,t:1527268558369};\\\", \\\"{x:583,y:656,t:1527268558384};\\\", \\\"{x:609,y:656,t:1527268558401};\\\", \\\"{x:616,y:656,t:1527268558419};\\\", \\\"{x:618,y:655,t:1527268558514};\\\", \\\"{x:618,y:653,t:1527268558522};\\\", \\\"{x:619,y:651,t:1527268558535};\\\", \\\"{x:620,y:647,t:1527268558552};\\\", \\\"{x:620,y:642,t:1527268558569};\\\", \\\"{x:620,y:635,t:1527268558585};\\\", \\\"{x:620,y:627,t:1527268558603};\\\", \\\"{x:620,y:623,t:1527268558619};\\\", \\\"{x:620,y:621,t:1527268558635};\\\", \\\"{x:620,y:620,t:1527268558651};\\\", \\\"{x:620,y:619,t:1527268558674};\\\", \\\"{x:620,y:618,t:1527268558690};\\\", \\\"{x:620,y:615,t:1527268558706};\\\", \\\"{x:620,y:614,t:1527268558719};\\\", \\\"{x:620,y:610,t:1527268558736};\\\", \\\"{x:621,y:605,t:1527268558752};\\\", \\\"{x:623,y:599,t:1527268558770};\\\", \\\"{x:624,y:595,t:1527268558785};\\\", \\\"{x:624,y:593,t:1527268558803};\\\", \\\"{x:625,y:592,t:1527268558818};\\\", \\\"{x:625,y:590,t:1527268558889};\\\", \\\"{x:625,y:589,t:1527268558946};\\\", \\\"{x:625,y:588,t:1527268559027};\\\", \\\"{x:625,y:587,t:1527268559043};\\\", \\\"{x:625,y:585,t:1527268559066};\\\", \\\"{x:624,y:584,t:1527268559091};\\\", \\\"{x:623,y:583,t:1527268559179};\\\", \\\"{x:626,y:583,t:1527268559651};\\\", \\\"{x:633,y:585,t:1527268559658};\\\", \\\"{x:643,y:588,t:1527268559671};\\\", \\\"{x:670,y:596,t:1527268559686};\\\", \\\"{x:711,y:604,t:1527268559703};\\\", \\\"{x:759,y:619,t:1527268559720};\\\", \\\"{x:814,y:632,t:1527268559736};\\\", \\\"{x:874,y:646,t:1527268559752};\\\", \\\"{x:942,y:667,t:1527268559769};\\\", \\\"{x:991,y:687,t:1527268559785};\\\", \\\"{x:1040,y:706,t:1527268559803};\\\", \\\"{x:1089,y:736,t:1527268559820};\\\", \\\"{x:1138,y:764,t:1527268559837};\\\", \\\"{x:1178,y:785,t:1527268559853};\\\", \\\"{x:1211,y:804,t:1527268559870};\\\", \\\"{x:1244,y:817,t:1527268559887};\\\", \\\"{x:1271,y:829,t:1527268559903};\\\", \\\"{x:1295,y:835,t:1527268559920};\\\", \\\"{x:1324,y:841,t:1527268559937};\\\", \\\"{x:1349,y:847,t:1527268559952};\\\", \\\"{x:1390,y:856,t:1527268559969};\\\", \\\"{x:1416,y:860,t:1527268559986};\\\", \\\"{x:1442,y:864,t:1527268560003};\\\", \\\"{x:1463,y:865,t:1527268560020};\\\", \\\"{x:1481,y:870,t:1527268560038};\\\", \\\"{x:1494,y:871,t:1527268560053};\\\", \\\"{x:1505,y:873,t:1527268560070};\\\", \\\"{x:1511,y:873,t:1527268560087};\\\", \\\"{x:1513,y:874,t:1527268560103};\\\", \\\"{x:1514,y:874,t:1527268560120};\\\", \\\"{x:1516,y:874,t:1527268560136};\\\", \\\"{x:1513,y:873,t:1527268560275};\\\", \\\"{x:1511,y:872,t:1527268560287};\\\", \\\"{x:1508,y:870,t:1527268560303};\\\", \\\"{x:1504,y:869,t:1527268560319};\\\", \\\"{x:1494,y:867,t:1527268560336};\\\", \\\"{x:1471,y:861,t:1527268560353};\\\", \\\"{x:1455,y:857,t:1527268560370};\\\", \\\"{x:1451,y:857,t:1527268560387};\\\", \\\"{x:1448,y:857,t:1527268560523};\\\", \\\"{x:1447,y:857,t:1527268560538};\\\", \\\"{x:1431,y:857,t:1527268560555};\\\", \\\"{x:1422,y:857,t:1527268560571};\\\", \\\"{x:1417,y:857,t:1527268560588};\\\", \\\"{x:1414,y:857,t:1527268560604};\\\", \\\"{x:1412,y:857,t:1527268560620};\\\", \\\"{x:1411,y:857,t:1527268560667};\\\", \\\"{x:1410,y:858,t:1527268560674};\\\", \\\"{x:1409,y:858,t:1527268560687};\\\", \\\"{x:1407,y:863,t:1527268560704};\\\", \\\"{x:1405,y:870,t:1527268560720};\\\", \\\"{x:1403,y:875,t:1527268560737};\\\", \\\"{x:1399,y:888,t:1527268560754};\\\", \\\"{x:1398,y:895,t:1527268560770};\\\", \\\"{x:1398,y:899,t:1527268560787};\\\", \\\"{x:1397,y:902,t:1527268560803};\\\", \\\"{x:1397,y:903,t:1527268560821};\\\", \\\"{x:1397,y:904,t:1527268560837};\\\", \\\"{x:1396,y:905,t:1527268560995};\\\", \\\"{x:1396,y:903,t:1527268561010};\\\", \\\"{x:1396,y:900,t:1527268561021};\\\", \\\"{x:1399,y:895,t:1527268561038};\\\", \\\"{x:1404,y:889,t:1527268561054};\\\", \\\"{x:1413,y:880,t:1527268561071};\\\", \\\"{x:1418,y:876,t:1527268561087};\\\", \\\"{x:1425,y:872,t:1527268561104};\\\", \\\"{x:1431,y:867,t:1527268561121};\\\", \\\"{x:1436,y:865,t:1527268561138};\\\", \\\"{x:1443,y:860,t:1527268561155};\\\", \\\"{x:1447,y:857,t:1527268561170};\\\", \\\"{x:1450,y:854,t:1527268561187};\\\", \\\"{x:1458,y:850,t:1527268561204};\\\", \\\"{x:1468,y:845,t:1527268561222};\\\", \\\"{x:1478,y:838,t:1527268561238};\\\", \\\"{x:1494,y:831,t:1527268561254};\\\", \\\"{x:1513,y:824,t:1527268561271};\\\", \\\"{x:1532,y:816,t:1527268561288};\\\", \\\"{x:1547,y:810,t:1527268561304};\\\", \\\"{x:1561,y:806,t:1527268561321};\\\", \\\"{x:1569,y:805,t:1527268561339};\\\", \\\"{x:1572,y:802,t:1527268561354};\\\", \\\"{x:1573,y:802,t:1527268561371};\\\", \\\"{x:1574,y:802,t:1527268561389};\\\", \\\"{x:1571,y:803,t:1527268561635};\\\", \\\"{x:1565,y:804,t:1527268561643};\\\", \\\"{x:1561,y:807,t:1527268561654};\\\", \\\"{x:1556,y:809,t:1527268561671};\\\", \\\"{x:1555,y:809,t:1527268561689};\\\", \\\"{x:1554,y:809,t:1527268561778};\\\", \\\"{x:1553,y:809,t:1527268561794};\\\", \\\"{x:1552,y:809,t:1527268561875};\\\", \\\"{x:1552,y:808,t:1527268561888};\\\", \\\"{x:1552,y:803,t:1527268561906};\\\", \\\"{x:1552,y:799,t:1527268561921};\\\", \\\"{x:1552,y:792,t:1527268561939};\\\", \\\"{x:1552,y:790,t:1527268561955};\\\", \\\"{x:1552,y:789,t:1527268561987};\\\", \\\"{x:1552,y:787,t:1527268562018};\\\", \\\"{x:1551,y:785,t:1527268562027};\\\", \\\"{x:1551,y:784,t:1527268562042};\\\", \\\"{x:1550,y:781,t:1527268562055};\\\", \\\"{x:1549,y:781,t:1527268562072};\\\", \\\"{x:1548,y:779,t:1527268562088};\\\", \\\"{x:1548,y:778,t:1527268562106};\\\", \\\"{x:1547,y:776,t:1527268562122};\\\", \\\"{x:1545,y:773,t:1527268562139};\\\", \\\"{x:1541,y:769,t:1527268562156};\\\", \\\"{x:1535,y:764,t:1527268562173};\\\", \\\"{x:1527,y:757,t:1527268562189};\\\", \\\"{x:1517,y:754,t:1527268562206};\\\", \\\"{x:1506,y:749,t:1527268562223};\\\", \\\"{x:1495,y:746,t:1527268562239};\\\", \\\"{x:1484,y:743,t:1527268562256};\\\", \\\"{x:1478,y:741,t:1527268562272};\\\", \\\"{x:1477,y:741,t:1527268562288};\\\", \\\"{x:1476,y:740,t:1527268562306};\\\", \\\"{x:1475,y:740,t:1527268562347};\\\", \\\"{x:1474,y:739,t:1527268562363};\\\", \\\"{x:1473,y:739,t:1527268562427};\\\", \\\"{x:1472,y:738,t:1527268562491};\\\", \\\"{x:1472,y:737,t:1527268562571};\\\", \\\"{x:1471,y:737,t:1527268562635};\\\", \\\"{x:1470,y:736,t:1527268562715};\\\", \\\"{x:1470,y:735,t:1527268562746};\\\", \\\"{x:1470,y:734,t:1527268562771};\\\", \\\"{x:1470,y:733,t:1527268562779};\\\", \\\"{x:1470,y:732,t:1527268562802};\\\", \\\"{x:1470,y:731,t:1527268562810};\\\", \\\"{x:1470,y:730,t:1527268562822};\\\", \\\"{x:1470,y:729,t:1527268562840};\\\", \\\"{x:1470,y:728,t:1527268562856};\\\", \\\"{x:1470,y:727,t:1527268562872};\\\", \\\"{x:1470,y:726,t:1527268563251};\\\", \\\"{x:1470,y:725,t:1527268563258};\\\", \\\"{x:1470,y:723,t:1527268563273};\\\", \\\"{x:1469,y:721,t:1527268563289};\\\", \\\"{x:1466,y:717,t:1527268563306};\\\", \\\"{x:1465,y:715,t:1527268563323};\\\", \\\"{x:1462,y:712,t:1527268563339};\\\", \\\"{x:1462,y:710,t:1527268563357};\\\", \\\"{x:1460,y:708,t:1527268563373};\\\", \\\"{x:1459,y:707,t:1527268563389};\\\", \\\"{x:1459,y:704,t:1527268563406};\\\", \\\"{x:1457,y:703,t:1527268563422};\\\", \\\"{x:1456,y:701,t:1527268563440};\\\", \\\"{x:1456,y:699,t:1527268563457};\\\", \\\"{x:1455,y:698,t:1527268563474};\\\", \\\"{x:1455,y:697,t:1527268563489};\\\", \\\"{x:1454,y:694,t:1527268563507};\\\", \\\"{x:1453,y:691,t:1527268563523};\\\", \\\"{x:1453,y:689,t:1527268563540};\\\", \\\"{x:1453,y:685,t:1527268563556};\\\", \\\"{x:1453,y:682,t:1527268563574};\\\", \\\"{x:1453,y:677,t:1527268563590};\\\", \\\"{x:1453,y:670,t:1527268563606};\\\", \\\"{x:1453,y:666,t:1527268563624};\\\", \\\"{x:1453,y:661,t:1527268563640};\\\", \\\"{x:1453,y:659,t:1527268563657};\\\", \\\"{x:1453,y:658,t:1527268563674};\\\", \\\"{x:1453,y:656,t:1527268563690};\\\", \\\"{x:1453,y:655,t:1527268563722};\\\", \\\"{x:1452,y:654,t:1527268563936};\\\", \\\"{x:1450,y:654,t:1527268563944};\\\", \\\"{x:1446,y:654,t:1527268563954};\\\", \\\"{x:1439,y:654,t:1527268563971};\\\", \\\"{x:1434,y:654,t:1527268563988};\\\", \\\"{x:1429,y:657,t:1527268564004};\\\", \\\"{x:1425,y:660,t:1527268564022};\\\", \\\"{x:1422,y:662,t:1527268564038};\\\", \\\"{x:1421,y:664,t:1527268564054};\\\", \\\"{x:1419,y:669,t:1527268564072};\\\", \\\"{x:1418,y:675,t:1527268564089};\\\", \\\"{x:1417,y:678,t:1527268564104};\\\", \\\"{x:1416,y:682,t:1527268564121};\\\", \\\"{x:1415,y:684,t:1527268564138};\\\", \\\"{x:1415,y:686,t:1527268564155};\\\", \\\"{x:1414,y:686,t:1527268564171};\\\", \\\"{x:1414,y:687,t:1527268564188};\\\", \\\"{x:1414,y:688,t:1527268564313};\\\", \\\"{x:1413,y:689,t:1527268564336};\\\", \\\"{x:1411,y:689,t:1527268564344};\\\", \\\"{x:1408,y:690,t:1527268564356};\\\", \\\"{x:1404,y:691,t:1527268564371};\\\", \\\"{x:1396,y:692,t:1527268564389};\\\", \\\"{x:1388,y:693,t:1527268564405};\\\", \\\"{x:1379,y:696,t:1527268564421};\\\", \\\"{x:1370,y:698,t:1527268564439};\\\", \\\"{x:1363,y:701,t:1527268564455};\\\", \\\"{x:1361,y:701,t:1527268564472};\\\", \\\"{x:1360,y:701,t:1527268564488};\\\", \\\"{x:1359,y:701,t:1527268564504};\\\", \\\"{x:1361,y:701,t:1527268564713};\\\", \\\"{x:1366,y:699,t:1527268564722};\\\", \\\"{x:1379,y:691,t:1527268564738};\\\", \\\"{x:1395,y:682,t:1527268564755};\\\", \\\"{x:1417,y:670,t:1527268564772};\\\", \\\"{x:1435,y:658,t:1527268564789};\\\", \\\"{x:1448,y:649,t:1527268564805};\\\", \\\"{x:1457,y:642,t:1527268564822};\\\", \\\"{x:1465,y:636,t:1527268564838};\\\", \\\"{x:1471,y:632,t:1527268564856};\\\", \\\"{x:1475,y:628,t:1527268564873};\\\", \\\"{x:1475,y:627,t:1527268564889};\\\", \\\"{x:1474,y:627,t:1527268565073};\\\", \\\"{x:1464,y:630,t:1527268565088};\\\", \\\"{x:1452,y:634,t:1527268565106};\\\", \\\"{x:1434,y:638,t:1527268565123};\\\", \\\"{x:1406,y:643,t:1527268565139};\\\", \\\"{x:1379,y:648,t:1527268565155};\\\", \\\"{x:1346,y:653,t:1527268565173};\\\", \\\"{x:1320,y:655,t:1527268565189};\\\", \\\"{x:1304,y:658,t:1527268565206};\\\", \\\"{x:1293,y:659,t:1527268565222};\\\", \\\"{x:1287,y:660,t:1527268565239};\\\", \\\"{x:1282,y:662,t:1527268565256};\\\", \\\"{x:1280,y:662,t:1527268565272};\\\", \\\"{x:1278,y:662,t:1527268565288};\\\", \\\"{x:1278,y:664,t:1527268565417};\\\", \\\"{x:1278,y:667,t:1527268565424};\\\", \\\"{x:1280,y:669,t:1527268565440};\\\", \\\"{x:1285,y:675,t:1527268565456};\\\", \\\"{x:1292,y:683,t:1527268565473};\\\", \\\"{x:1298,y:689,t:1527268565489};\\\", \\\"{x:1305,y:695,t:1527268565506};\\\", \\\"{x:1312,y:701,t:1527268565523};\\\", \\\"{x:1314,y:702,t:1527268565540};\\\", \\\"{x:1315,y:703,t:1527268565556};\\\", \\\"{x:1315,y:704,t:1527268565600};\\\", \\\"{x:1316,y:704,t:1527268565617};\\\", \\\"{x:1317,y:704,t:1527268565624};\\\", \\\"{x:1317,y:705,t:1527268565656};\\\", \\\"{x:1318,y:706,t:1527268565672};\\\", \\\"{x:1319,y:707,t:1527268565720};\\\", \\\"{x:1321,y:709,t:1527268565743};\\\", \\\"{x:1322,y:709,t:1527268565755};\\\", \\\"{x:1323,y:710,t:1527268565771};\\\", \\\"{x:1325,y:710,t:1527268565789};\\\", \\\"{x:1326,y:710,t:1527268565808};\\\", \\\"{x:1328,y:710,t:1527268565856};\\\", \\\"{x:1329,y:710,t:1527268565896};\\\", \\\"{x:1329,y:711,t:1527268565906};\\\", \\\"{x:1330,y:712,t:1527268565922};\\\", \\\"{x:1331,y:712,t:1527268565939};\\\", \\\"{x:1332,y:712,t:1527268565956};\\\", \\\"{x:1333,y:712,t:1527268565976};\\\", \\\"{x:1334,y:712,t:1527268566273};\\\", \\\"{x:1336,y:713,t:1527268566361};\\\", \\\"{x:1338,y:713,t:1527268566373};\\\", \\\"{x:1341,y:715,t:1527268566389};\\\", \\\"{x:1344,y:716,t:1527268566406};\\\", \\\"{x:1349,y:718,t:1527268566424};\\\", \\\"{x:1353,y:720,t:1527268566439};\\\", \\\"{x:1359,y:721,t:1527268566457};\\\", \\\"{x:1362,y:722,t:1527268566473};\\\", \\\"{x:1363,y:723,t:1527268566512};\\\", \\\"{x:1363,y:722,t:1527268567321};\\\", \\\"{x:1362,y:721,t:1527268567336};\\\", \\\"{x:1361,y:720,t:1527268567344};\\\", \\\"{x:1360,y:719,t:1527268567360};\\\", \\\"{x:1359,y:719,t:1527268567374};\\\", \\\"{x:1357,y:719,t:1527268567505};\\\", \\\"{x:1352,y:718,t:1527268567512};\\\", \\\"{x:1346,y:715,t:1527268567524};\\\", \\\"{x:1328,y:711,t:1527268567541};\\\", \\\"{x:1308,y:704,t:1527268567558};\\\", \\\"{x:1283,y:699,t:1527268567574};\\\", \\\"{x:1263,y:694,t:1527268567590};\\\", \\\"{x:1240,y:687,t:1527268567608};\\\", \\\"{x:1224,y:682,t:1527268567625};\\\", \\\"{x:1220,y:682,t:1527268567641};\\\", \\\"{x:1219,y:681,t:1527268567658};\\\", \\\"{x:1217,y:680,t:1527268567768};\\\", \\\"{x:1216,y:679,t:1527268567841};\\\", \\\"{x:1216,y:678,t:1527268567889};\\\", \\\"{x:1217,y:678,t:1527268567904};\\\", \\\"{x:1219,y:678,t:1527268567912};\\\", \\\"{x:1224,y:678,t:1527268567924};\\\", \\\"{x:1232,y:678,t:1527268567941};\\\", \\\"{x:1242,y:678,t:1527268567957};\\\", \\\"{x:1256,y:678,t:1527268567973};\\\", \\\"{x:1268,y:680,t:1527268567990};\\\", \\\"{x:1278,y:681,t:1527268568007};\\\", \\\"{x:1290,y:683,t:1527268568023};\\\", \\\"{x:1296,y:684,t:1527268568041};\\\", \\\"{x:1300,y:685,t:1527268568056};\\\", \\\"{x:1302,y:685,t:1527268568074};\\\", \\\"{x:1303,y:685,t:1527268568091};\\\", \\\"{x:1304,y:686,t:1527268568107};\\\", \\\"{x:1306,y:686,t:1527268568124};\\\", \\\"{x:1306,y:687,t:1527268568141};\\\", \\\"{x:1308,y:688,t:1527268568158};\\\", \\\"{x:1309,y:688,t:1527268568176};\\\", \\\"{x:1311,y:689,t:1527268568200};\\\", \\\"{x:1313,y:691,t:1527268568208};\\\", \\\"{x:1317,y:693,t:1527268568224};\\\", \\\"{x:1321,y:695,t:1527268568242};\\\", \\\"{x:1326,y:697,t:1527268568257};\\\", \\\"{x:1328,y:698,t:1527268568275};\\\", \\\"{x:1329,y:698,t:1527268568291};\\\", \\\"{x:1330,y:698,t:1527268568308};\\\", \\\"{x:1331,y:698,t:1527268568343};\\\", \\\"{x:1332,y:699,t:1527268568367};\\\", \\\"{x:1333,y:699,t:1527268568384};\\\", \\\"{x:1335,y:699,t:1527268568407};\\\", \\\"{x:1336,y:700,t:1527268568424};\\\", \\\"{x:1339,y:700,t:1527268568441};\\\", \\\"{x:1341,y:702,t:1527268568458};\\\", \\\"{x:1342,y:702,t:1527268568474};\\\", \\\"{x:1343,y:702,t:1527268568491};\\\", \\\"{x:1344,y:702,t:1527268568519};\\\", \\\"{x:1345,y:702,t:1527268568528};\\\", \\\"{x:1345,y:703,t:1527268568541};\\\", \\\"{x:1346,y:705,t:1527268568559};\\\", \\\"{x:1349,y:709,t:1527268568574};\\\", \\\"{x:1349,y:712,t:1527268568592};\\\", \\\"{x:1352,y:718,t:1527268568608};\\\", \\\"{x:1353,y:720,t:1527268568624};\\\", \\\"{x:1354,y:722,t:1527268568641};\\\", \\\"{x:1354,y:723,t:1527268568658};\\\", \\\"{x:1354,y:724,t:1527268568688};\\\", \\\"{x:1354,y:725,t:1527268568713};\\\", \\\"{x:1354,y:726,t:1527268568725};\\\", \\\"{x:1354,y:727,t:1527268568745};\\\", \\\"{x:1354,y:728,t:1527268568760};\\\", \\\"{x:1354,y:729,t:1527268568776};\\\", \\\"{x:1354,y:730,t:1527268568791};\\\", \\\"{x:1355,y:732,t:1527268568808};\\\", \\\"{x:1356,y:732,t:1527268568826};\\\", \\\"{x:1356,y:733,t:1527268568864};\\\", \\\"{x:1356,y:734,t:1527268568993};\\\", \\\"{x:1352,y:737,t:1527268569009};\\\", \\\"{x:1346,y:739,t:1527268569026};\\\", \\\"{x:1331,y:744,t:1527268569042};\\\", \\\"{x:1312,y:749,t:1527268569059};\\\", \\\"{x:1303,y:750,t:1527268569075};\\\", \\\"{x:1294,y:752,t:1527268569092};\\\", \\\"{x:1290,y:752,t:1527268569109};\\\", \\\"{x:1287,y:753,t:1527268569126};\\\", \\\"{x:1285,y:753,t:1527268569141};\\\", \\\"{x:1284,y:754,t:1527268569158};\\\", \\\"{x:1281,y:754,t:1527268569176};\\\", \\\"{x:1278,y:756,t:1527268569192};\\\", \\\"{x:1274,y:757,t:1527268569209};\\\", \\\"{x:1270,y:758,t:1527268569226};\\\", \\\"{x:1266,y:759,t:1527268569242};\\\", \\\"{x:1263,y:760,t:1527268569258};\\\", \\\"{x:1255,y:762,t:1527268569276};\\\", \\\"{x:1250,y:763,t:1527268569292};\\\", \\\"{x:1242,y:765,t:1527268569308};\\\", \\\"{x:1230,y:769,t:1527268569325};\\\", \\\"{x:1216,y:772,t:1527268569343};\\\", \\\"{x:1199,y:775,t:1527268569359};\\\", \\\"{x:1181,y:781,t:1527268569376};\\\", \\\"{x:1149,y:785,t:1527268569392};\\\", \\\"{x:1117,y:790,t:1527268569408};\\\", \\\"{x:1090,y:791,t:1527268569426};\\\", \\\"{x:1063,y:791,t:1527268569443};\\\", \\\"{x:1041,y:788,t:1527268569458};\\\", \\\"{x:1023,y:782,t:1527268569475};\\\", \\\"{x:1009,y:775,t:1527268569492};\\\", \\\"{x:1000,y:773,t:1527268569508};\\\", \\\"{x:993,y:769,t:1527268569525};\\\", \\\"{x:984,y:767,t:1527268569542};\\\", \\\"{x:977,y:765,t:1527268569559};\\\", \\\"{x:969,y:762,t:1527268569574};\\\", \\\"{x:963,y:761,t:1527268569591};\\\", \\\"{x:962,y:761,t:1527268569624};\\\", \\\"{x:962,y:760,t:1527268569631};\\\", \\\"{x:961,y:760,t:1527268569656};\\\", \\\"{x:960,y:759,t:1527268569664};\\\", \\\"{x:960,y:758,t:1527268569675};\\\", \\\"{x:958,y:756,t:1527268569692};\\\", \\\"{x:956,y:751,t:1527268569709};\\\", \\\"{x:955,y:746,t:1527268569725};\\\", \\\"{x:955,y:741,t:1527268569742};\\\", \\\"{x:954,y:735,t:1527268569759};\\\", \\\"{x:954,y:729,t:1527268569775};\\\", \\\"{x:954,y:723,t:1527268569792};\\\", \\\"{x:954,y:718,t:1527268569809};\\\", \\\"{x:954,y:713,t:1527268569825};\\\", \\\"{x:955,y:707,t:1527268569843};\\\", \\\"{x:958,y:702,t:1527268569859};\\\", \\\"{x:959,y:694,t:1527268569876};\\\", \\\"{x:959,y:693,t:1527268569892};\\\", \\\"{x:961,y:689,t:1527268569910};\\\", \\\"{x:961,y:688,t:1527268569925};\\\", \\\"{x:962,y:685,t:1527268569942};\\\", \\\"{x:965,y:681,t:1527268569960};\\\", \\\"{x:965,y:680,t:1527268569975};\\\", \\\"{x:966,y:677,t:1527268569993};\\\", \\\"{x:967,y:675,t:1527268570010};\\\", \\\"{x:967,y:674,t:1527268570026};\\\", \\\"{x:968,y:673,t:1527268570048};\\\", \\\"{x:969,y:673,t:1527268570080};\\\", \\\"{x:968,y:673,t:1527268570576};\\\", \\\"{x:956,y:673,t:1527268570592};\\\", \\\"{x:941,y:673,t:1527268570609};\\\", \\\"{x:923,y:673,t:1527268570626};\\\", \\\"{x:902,y:673,t:1527268570642};\\\", \\\"{x:883,y:673,t:1527268570659};\\\", \\\"{x:866,y:673,t:1527268570676};\\\", \\\"{x:850,y:673,t:1527268570693};\\\", \\\"{x:836,y:673,t:1527268570709};\\\", \\\"{x:827,y:675,t:1527268570726};\\\", \\\"{x:821,y:676,t:1527268570743};\\\", \\\"{x:816,y:676,t:1527268570759};\\\", \\\"{x:808,y:677,t:1527268570776};\\\", \\\"{x:803,y:679,t:1527268570793};\\\", \\\"{x:794,y:680,t:1527268570809};\\\", \\\"{x:786,y:681,t:1527268570827};\\\", \\\"{x:778,y:681,t:1527268570843};\\\", \\\"{x:775,y:683,t:1527268570860};\\\", \\\"{x:773,y:683,t:1527268570876};\\\", \\\"{x:771,y:684,t:1527268570893};\\\", \\\"{x:767,y:684,t:1527268570910};\\\", \\\"{x:766,y:685,t:1527268570927};\\\", \\\"{x:765,y:685,t:1527268570943};\\\", \\\"{x:764,y:686,t:1527268570960};\\\", \\\"{x:762,y:686,t:1527268570984};\\\", \\\"{x:761,y:687,t:1527268571000};\\\", \\\"{x:760,y:687,t:1527268571032};\\\", \\\"{x:760,y:688,t:1527268571044};\\\", \\\"{x:759,y:688,t:1527268571192};\\\", \\\"{x:759,y:689,t:1527268571272};\\\", \\\"{x:757,y:691,t:1527268571288};\\\", \\\"{x:757,y:693,t:1527268571297};\\\", \\\"{x:754,y:696,t:1527268571310};\\\", \\\"{x:751,y:701,t:1527268571327};\\\", \\\"{x:747,y:707,t:1527268571344};\\\", \\\"{x:743,y:710,t:1527268571361};\\\", \\\"{x:742,y:713,t:1527268571377};\\\", \\\"{x:738,y:718,t:1527268571393};\\\", \\\"{x:735,y:722,t:1527268571410};\\\", \\\"{x:731,y:727,t:1527268571428};\\\", \\\"{x:726,y:732,t:1527268571443};\\\", \\\"{x:722,y:736,t:1527268571460};\\\", \\\"{x:718,y:740,t:1527268571479};\\\", \\\"{x:712,y:741,t:1527268571494};\\\", \\\"{x:705,y:746,t:1527268571511};\\\", \\\"{x:699,y:749,t:1527268571528};\\\", \\\"{x:693,y:753,t:1527268571544};\\\", \\\"{x:686,y:756,t:1527268571561};\\\", \\\"{x:677,y:760,t:1527268571578};\\\", \\\"{x:672,y:762,t:1527268571594};\\\", \\\"{x:665,y:766,t:1527268571610};\\\", \\\"{x:656,y:768,t:1527268571628};\\\", \\\"{x:642,y:769,t:1527268571644};\\\", \\\"{x:628,y:770,t:1527268571660};\\\", \\\"{x:611,y:770,t:1527268571680};\\\", \\\"{x:596,y:770,t:1527268571693};\\\", \\\"{x:583,y:770,t:1527268571710};\\\", \\\"{x:568,y:769,t:1527268571727};\\\", \\\"{x:559,y:766,t:1527268571744};\\\", \\\"{x:554,y:764,t:1527268571761};\\\", \\\"{x:550,y:760,t:1527268571777};\\\", \\\"{x:545,y:757,t:1527268571793};\\\", \\\"{x:543,y:756,t:1527268571810};\\\", \\\"{x:539,y:753,t:1527268571829};\\\", \\\"{x:535,y:750,t:1527268571844};\\\", \\\"{x:530,y:747,t:1527268571860};\\\", \\\"{x:526,y:745,t:1527268571877};\\\", \\\"{x:523,y:744,t:1527268571894};\\\", \\\"{x:522,y:744,t:1527268571910};\\\", \\\"{x:521,y:744,t:1527268571943};\\\", \\\"{x:520,y:743,t:1527268571960};\\\", \\\"{x:520,y:742,t:1527268573056};\\\", \\\"{x:521,y:741,t:1527268573128};\\\", \\\"{x:522,y:739,t:1527268573146};\\\", \\\"{x:524,y:738,t:1527268573161};\\\", \\\"{x:525,y:738,t:1527268573178};\\\", \\\"{x:527,y:736,t:1527268573195};\\\", \\\"{x:528,y:736,t:1527268573211};\\\", \\\"{x:528,y:735,t:1527268573228};\\\", \\\"{x:529,y:735,t:1527268573246};\\\", \\\"{x:530,y:734,t:1527268573261};\\\", \\\"{x:531,y:734,t:1527268573278};\\\", \\\"{x:532,y:733,t:1527268573296};\\\", \\\"{x:533,y:733,t:1527268573328};\\\", \\\"{x:534,y:732,t:1527268573345};\\\", \\\"{x:535,y:730,t:1527268573425};\\\", \\\"{x:537,y:729,t:1527268573528};\\\", \\\"{x:539,y:729,t:1527268573616};\\\" ] }, { \\\"rt\\\": 31413, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 641081, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:729,t:1527268574007};\\\", \\\"{x:543,y:728,t:1527268574016};\\\", \\\"{x:544,y:727,t:1527268574031};\\\", \\\"{x:545,y:726,t:1527268574046};\\\", \\\"{x:546,y:726,t:1527268574062};\\\", \\\"{x:548,y:725,t:1527268574079};\\\", \\\"{x:550,y:724,t:1527268574359};\\\", \\\"{x:553,y:723,t:1527268574664};\\\", \\\"{x:560,y:721,t:1527268574681};\\\", \\\"{x:570,y:718,t:1527268574699};\\\", \\\"{x:581,y:717,t:1527268574715};\\\", \\\"{x:595,y:714,t:1527268574729};\\\", \\\"{x:607,y:712,t:1527268574747};\\\", \\\"{x:618,y:712,t:1527268574763};\\\", \\\"{x:624,y:710,t:1527268574779};\\\", \\\"{x:628,y:709,t:1527268574797};\\\", \\\"{x:629,y:709,t:1527268574813};\\\", \\\"{x:631,y:708,t:1527268574829};\\\", \\\"{x:633,y:708,t:1527268574846};\\\", \\\"{x:636,y:707,t:1527268574864};\\\", \\\"{x:637,y:707,t:1527268574960};\\\", \\\"{x:639,y:707,t:1527268574992};\\\", \\\"{x:641,y:707,t:1527268575016};\\\", \\\"{x:642,y:707,t:1527268575030};\\\", \\\"{x:645,y:707,t:1527268575047};\\\", \\\"{x:650,y:708,t:1527268575064};\\\", \\\"{x:654,y:709,t:1527268575080};\\\", \\\"{x:656,y:710,t:1527268575096};\\\", \\\"{x:660,y:711,t:1527268575113};\\\", \\\"{x:661,y:711,t:1527268575130};\\\", \\\"{x:662,y:711,t:1527268575147};\\\", \\\"{x:664,y:712,t:1527268575163};\\\", \\\"{x:665,y:712,t:1527268575473};\\\", \\\"{x:666,y:713,t:1527268575536};\\\", \\\"{x:667,y:714,t:1527268575632};\\\", \\\"{x:668,y:714,t:1527268575760};\\\", \\\"{x:669,y:714,t:1527268575768};\\\", \\\"{x:670,y:714,t:1527268575780};\\\", \\\"{x:671,y:714,t:1527268575865};\\\", \\\"{x:672,y:715,t:1527268575896};\\\", \\\"{x:673,y:716,t:1527268575904};\\\", \\\"{x:675,y:716,t:1527268576000};\\\", \\\"{x:677,y:716,t:1527268576016};\\\", \\\"{x:683,y:717,t:1527268576031};\\\", \\\"{x:707,y:720,t:1527268576048};\\\", \\\"{x:729,y:723,t:1527268576064};\\\", \\\"{x:750,y:727,t:1527268576081};\\\", \\\"{x:760,y:728,t:1527268576097};\\\", \\\"{x:769,y:729,t:1527268576114};\\\", \\\"{x:772,y:730,t:1527268576130};\\\", \\\"{x:774,y:730,t:1527268576147};\\\", \\\"{x:776,y:730,t:1527268576473};\\\", \\\"{x:780,y:730,t:1527268576480};\\\", \\\"{x:798,y:733,t:1527268576498};\\\", \\\"{x:817,y:736,t:1527268576515};\\\", \\\"{x:843,y:738,t:1527268576530};\\\", \\\"{x:876,y:742,t:1527268576548};\\\", \\\"{x:902,y:744,t:1527268576565};\\\", \\\"{x:924,y:745,t:1527268576581};\\\", \\\"{x:945,y:745,t:1527268576597};\\\", \\\"{x:966,y:745,t:1527268576614};\\\", \\\"{x:985,y:745,t:1527268576631};\\\", \\\"{x:1017,y:745,t:1527268576648};\\\", \\\"{x:1043,y:745,t:1527268576665};\\\", \\\"{x:1072,y:745,t:1527268576682};\\\", \\\"{x:1102,y:745,t:1527268576697};\\\", \\\"{x:1140,y:745,t:1527268576715};\\\", \\\"{x:1182,y:745,t:1527268576732};\\\", \\\"{x:1230,y:745,t:1527268576748};\\\", \\\"{x:1277,y:745,t:1527268576765};\\\", \\\"{x:1311,y:745,t:1527268576782};\\\", \\\"{x:1340,y:745,t:1527268576797};\\\", \\\"{x:1367,y:745,t:1527268576815};\\\", \\\"{x:1397,y:745,t:1527268576833};\\\", \\\"{x:1414,y:745,t:1527268576848};\\\", \\\"{x:1426,y:745,t:1527268576864};\\\", \\\"{x:1433,y:745,t:1527268576882};\\\", \\\"{x:1436,y:745,t:1527268576898};\\\", \\\"{x:1438,y:745,t:1527268577201};\\\", \\\"{x:1440,y:745,t:1527268577215};\\\", \\\"{x:1454,y:752,t:1527268577232};\\\", \\\"{x:1464,y:758,t:1527268577248};\\\", \\\"{x:1472,y:763,t:1527268577265};\\\", \\\"{x:1477,y:767,t:1527268577283};\\\", \\\"{x:1480,y:769,t:1527268577299};\\\", \\\"{x:1480,y:770,t:1527268577315};\\\", \\\"{x:1480,y:779,t:1527268577332};\\\", \\\"{x:1479,y:794,t:1527268577349};\\\", \\\"{x:1464,y:823,t:1527268577365};\\\", \\\"{x:1441,y:846,t:1527268577382};\\\", \\\"{x:1432,y:853,t:1527268577400};\\\", \\\"{x:1431,y:853,t:1527268577415};\\\", \\\"{x:1431,y:854,t:1527268577456};\\\", \\\"{x:1431,y:856,t:1527268577465};\\\", \\\"{x:1431,y:859,t:1527268577481};\\\", \\\"{x:1438,y:866,t:1527268577499};\\\", \\\"{x:1447,y:876,t:1527268577514};\\\", \\\"{x:1459,y:890,t:1527268577531};\\\", \\\"{x:1472,y:899,t:1527268577548};\\\", \\\"{x:1485,y:910,t:1527268577564};\\\", \\\"{x:1500,y:922,t:1527268577581};\\\", \\\"{x:1511,y:931,t:1527268577598};\\\", \\\"{x:1520,y:938,t:1527268577615};\\\", \\\"{x:1527,y:943,t:1527268577631};\\\", \\\"{x:1533,y:948,t:1527268577648};\\\", \\\"{x:1538,y:951,t:1527268577665};\\\", \\\"{x:1541,y:954,t:1527268577681};\\\", \\\"{x:1542,y:954,t:1527268577698};\\\", \\\"{x:1546,y:957,t:1527268577715};\\\", \\\"{x:1551,y:961,t:1527268577731};\\\", \\\"{x:1554,y:962,t:1527268577748};\\\", \\\"{x:1559,y:964,t:1527268577766};\\\", \\\"{x:1565,y:964,t:1527268577782};\\\", \\\"{x:1571,y:965,t:1527268577799};\\\", \\\"{x:1580,y:965,t:1527268577816};\\\", \\\"{x:1585,y:965,t:1527268577833};\\\", \\\"{x:1590,y:965,t:1527268577849};\\\", \\\"{x:1596,y:965,t:1527268577866};\\\", \\\"{x:1598,y:964,t:1527268577882};\\\", \\\"{x:1601,y:963,t:1527268577898};\\\", \\\"{x:1602,y:962,t:1527268577916};\\\", \\\"{x:1604,y:961,t:1527268577933};\\\", \\\"{x:1604,y:960,t:1527268577960};\\\", \\\"{x:1604,y:959,t:1527268578080};\\\", \\\"{x:1603,y:959,t:1527268578096};\\\", \\\"{x:1601,y:959,t:1527268578104};\\\", \\\"{x:1597,y:959,t:1527268578116};\\\", \\\"{x:1582,y:959,t:1527268578133};\\\", \\\"{x:1570,y:959,t:1527268578149};\\\", \\\"{x:1558,y:959,t:1527268578166};\\\", \\\"{x:1549,y:958,t:1527268578183};\\\", \\\"{x:1547,y:957,t:1527268578199};\\\", \\\"{x:1543,y:956,t:1527268578216};\\\", \\\"{x:1541,y:956,t:1527268578233};\\\", \\\"{x:1540,y:956,t:1527268578249};\\\", \\\"{x:1539,y:955,t:1527268578288};\\\", \\\"{x:1539,y:954,t:1527268578336};\\\", \\\"{x:1539,y:953,t:1527268578376};\\\", \\\"{x:1539,y:952,t:1527268578383};\\\", \\\"{x:1539,y:951,t:1527268578399};\\\", \\\"{x:1539,y:949,t:1527268578415};\\\", \\\"{x:1539,y:948,t:1527268578433};\\\", \\\"{x:1539,y:947,t:1527268578472};\\\", \\\"{x:1539,y:946,t:1527268578488};\\\", \\\"{x:1539,y:945,t:1527268578499};\\\", \\\"{x:1539,y:944,t:1527268578516};\\\", \\\"{x:1539,y:942,t:1527268578533};\\\", \\\"{x:1540,y:937,t:1527268578550};\\\", \\\"{x:1540,y:929,t:1527268578566};\\\", \\\"{x:1544,y:915,t:1527268578583};\\\", \\\"{x:1544,y:906,t:1527268578599};\\\", \\\"{x:1544,y:893,t:1527268578616};\\\", \\\"{x:1544,y:889,t:1527268578632};\\\", \\\"{x:1544,y:885,t:1527268578650};\\\", \\\"{x:1544,y:882,t:1527268578666};\\\", \\\"{x:1544,y:878,t:1527268578682};\\\", \\\"{x:1544,y:872,t:1527268578699};\\\", \\\"{x:1544,y:865,t:1527268578716};\\\", \\\"{x:1544,y:860,t:1527268578733};\\\", \\\"{x:1544,y:856,t:1527268578750};\\\", \\\"{x:1544,y:854,t:1527268578766};\\\", \\\"{x:1544,y:853,t:1527268578783};\\\", \\\"{x:1544,y:850,t:1527268578800};\\\", \\\"{x:1544,y:847,t:1527268578816};\\\", \\\"{x:1544,y:844,t:1527268578833};\\\", \\\"{x:1544,y:843,t:1527268578850};\\\", \\\"{x:1544,y:842,t:1527268579064};\\\", \\\"{x:1544,y:841,t:1527268579608};\\\", \\\"{x:1544,y:839,t:1527268580017};\\\", \\\"{x:1544,y:838,t:1527268580035};\\\", \\\"{x:1544,y:837,t:1527268580056};\\\", \\\"{x:1544,y:836,t:1527268580080};\\\", \\\"{x:1544,y:835,t:1527268580161};\\\", \\\"{x:1544,y:834,t:1527268587033};\\\", \\\"{x:1544,y:833,t:1527268587656};\\\", \\\"{x:1543,y:832,t:1527268589264};\\\", \\\"{x:1514,y:832,t:1527268589275};\\\", \\\"{x:1416,y:830,t:1527268589291};\\\", \\\"{x:1283,y:809,t:1527268589308};\\\", \\\"{x:1139,y:790,t:1527268589325};\\\", \\\"{x:1003,y:767,t:1527268589340};\\\", \\\"{x:893,y:738,t:1527268589356};\\\", \\\"{x:830,y:716,t:1527268589374};\\\", \\\"{x:786,y:698,t:1527268589390};\\\", \\\"{x:766,y:689,t:1527268589406};\\\", \\\"{x:755,y:682,t:1527268589423};\\\", \\\"{x:751,y:678,t:1527268589440};\\\", \\\"{x:748,y:676,t:1527268589457};\\\", \\\"{x:745,y:674,t:1527268589473};\\\", \\\"{x:743,y:672,t:1527268589489};\\\", \\\"{x:739,y:666,t:1527268589506};\\\", \\\"{x:730,y:655,t:1527268589524};\\\", \\\"{x:720,y:643,t:1527268589540};\\\", \\\"{x:711,y:633,t:1527268589557};\\\", \\\"{x:702,y:625,t:1527268589575};\\\", \\\"{x:694,y:618,t:1527268589591};\\\", \\\"{x:691,y:615,t:1527268589607};\\\", \\\"{x:690,y:614,t:1527268589625};\\\", \\\"{x:689,y:613,t:1527268589641};\\\", \\\"{x:689,y:612,t:1527268589658};\\\", \\\"{x:689,y:611,t:1527268589675};\\\", \\\"{x:689,y:609,t:1527268589692};\\\", \\\"{x:689,y:608,t:1527268589708};\\\", \\\"{x:691,y:605,t:1527268589725};\\\", \\\"{x:695,y:601,t:1527268589741};\\\", \\\"{x:700,y:597,t:1527268589758};\\\", \\\"{x:701,y:596,t:1527268589775};\\\", \\\"{x:702,y:595,t:1527268589800};\\\", \\\"{x:699,y:594,t:1527268589816};\\\", \\\"{x:686,y:594,t:1527268589825};\\\", \\\"{x:659,y:594,t:1527268589842};\\\", \\\"{x:616,y:594,t:1527268589858};\\\", \\\"{x:557,y:593,t:1527268589876};\\\", \\\"{x:498,y:591,t:1527268589893};\\\", \\\"{x:453,y:591,t:1527268589907};\\\", \\\"{x:420,y:587,t:1527268589925};\\\", \\\"{x:397,y:585,t:1527268589943};\\\", \\\"{x:380,y:583,t:1527268589959};\\\", \\\"{x:366,y:582,t:1527268589975};\\\", \\\"{x:355,y:580,t:1527268589992};\\\", \\\"{x:351,y:578,t:1527268590008};\\\", \\\"{x:346,y:577,t:1527268590025};\\\", \\\"{x:340,y:576,t:1527268590042};\\\", \\\"{x:328,y:572,t:1527268590058};\\\", \\\"{x:318,y:571,t:1527268590075};\\\", \\\"{x:302,y:568,t:1527268590092};\\\", \\\"{x:289,y:567,t:1527268590109};\\\", \\\"{x:282,y:567,t:1527268590125};\\\", \\\"{x:279,y:566,t:1527268590142};\\\", \\\"{x:279,y:565,t:1527268590177};\\\", \\\"{x:273,y:565,t:1527268590192};\\\", \\\"{x:265,y:566,t:1527268590211};\\\", \\\"{x:254,y:567,t:1527268590225};\\\", \\\"{x:243,y:567,t:1527268590242};\\\", \\\"{x:233,y:567,t:1527268590259};\\\", \\\"{x:228,y:567,t:1527268590275};\\\", \\\"{x:225,y:567,t:1527268590292};\\\", \\\"{x:220,y:567,t:1527268590309};\\\", \\\"{x:217,y:566,t:1527268590325};\\\", \\\"{x:211,y:564,t:1527268590342};\\\", \\\"{x:191,y:559,t:1527268590361};\\\", \\\"{x:182,y:556,t:1527268590375};\\\", \\\"{x:167,y:550,t:1527268590393};\\\", \\\"{x:164,y:550,t:1527268590409};\\\", \\\"{x:162,y:550,t:1527268590488};\\\", \\\"{x:161,y:549,t:1527268590495};\\\", \\\"{x:160,y:549,t:1527268590508};\\\", \\\"{x:156,y:548,t:1527268590525};\\\", \\\"{x:150,y:547,t:1527268590541};\\\", \\\"{x:148,y:546,t:1527268590559};\\\", \\\"{x:147,y:546,t:1527268590576};\\\", \\\"{x:146,y:545,t:1527268590592};\\\", \\\"{x:146,y:544,t:1527268591048};\\\", \\\"{x:149,y:544,t:1527268591061};\\\", \\\"{x:180,y:544,t:1527268591077};\\\", \\\"{x:228,y:544,t:1527268591093};\\\", \\\"{x:297,y:544,t:1527268591109};\\\", \\\"{x:367,y:544,t:1527268591126};\\\", \\\"{x:492,y:544,t:1527268591143};\\\", \\\"{x:533,y:544,t:1527268591159};\\\", \\\"{x:645,y:555,t:1527268591176};\\\", \\\"{x:726,y:566,t:1527268591193};\\\", \\\"{x:788,y:576,t:1527268591209};\\\", \\\"{x:846,y:584,t:1527268591226};\\\", \\\"{x:906,y:596,t:1527268591244};\\\", \\\"{x:945,y:600,t:1527268591260};\\\", \\\"{x:981,y:605,t:1527268591276};\\\", \\\"{x:1026,y:611,t:1527268591292};\\\", \\\"{x:1058,y:612,t:1527268591310};\\\", \\\"{x:1087,y:617,t:1527268591326};\\\", \\\"{x:1119,y:621,t:1527268591343};\\\", \\\"{x:1134,y:623,t:1527268591359};\\\", \\\"{x:1147,y:626,t:1527268591376};\\\", \\\"{x:1155,y:628,t:1527268591393};\\\", \\\"{x:1158,y:629,t:1527268591410};\\\", \\\"{x:1162,y:631,t:1527268591426};\\\", \\\"{x:1162,y:632,t:1527268591456};\\\", \\\"{x:1163,y:632,t:1527268591512};\\\", \\\"{x:1163,y:633,t:1527268591544};\\\", \\\"{x:1163,y:634,t:1527268591560};\\\", \\\"{x:1163,y:635,t:1527268591576};\\\", \\\"{x:1162,y:636,t:1527268591593};\\\", \\\"{x:1160,y:636,t:1527268591648};\\\", \\\"{x:1158,y:637,t:1527268591729};\\\", \\\"{x:1154,y:638,t:1527268591977};\\\", \\\"{x:1140,y:638,t:1527268591993};\\\", \\\"{x:1120,y:638,t:1527268592011};\\\", \\\"{x:1090,y:638,t:1527268592027};\\\", \\\"{x:1041,y:636,t:1527268592043};\\\", \\\"{x:963,y:625,t:1527268592060};\\\", \\\"{x:886,y:614,t:1527268592078};\\\", \\\"{x:803,y:605,t:1527268592093};\\\", \\\"{x:719,y:590,t:1527268592110};\\\", \\\"{x:631,y:579,t:1527268592127};\\\", \\\"{x:602,y:574,t:1527268592143};\\\", \\\"{x:584,y:573,t:1527268592161};\\\", \\\"{x:569,y:573,t:1527268592176};\\\", \\\"{x:558,y:573,t:1527268592193};\\\", \\\"{x:546,y:573,t:1527268592210};\\\", \\\"{x:532,y:573,t:1527268592226};\\\", \\\"{x:514,y:573,t:1527268592244};\\\", \\\"{x:495,y:573,t:1527268592261};\\\", \\\"{x:473,y:573,t:1527268592277};\\\", \\\"{x:453,y:573,t:1527268592294};\\\", \\\"{x:430,y:573,t:1527268592310};\\\", \\\"{x:404,y:573,t:1527268592327};\\\", \\\"{x:393,y:573,t:1527268592344};\\\", \\\"{x:380,y:573,t:1527268592360};\\\", \\\"{x:363,y:570,t:1527268592378};\\\", \\\"{x:335,y:566,t:1527268592394};\\\", \\\"{x:307,y:563,t:1527268592410};\\\", \\\"{x:285,y:562,t:1527268592428};\\\", \\\"{x:270,y:559,t:1527268592444};\\\", \\\"{x:259,y:556,t:1527268592460};\\\", \\\"{x:258,y:555,t:1527268592478};\\\", \\\"{x:255,y:553,t:1527268592494};\\\", \\\"{x:250,y:550,t:1527268592510};\\\", \\\"{x:238,y:545,t:1527268592527};\\\", \\\"{x:229,y:543,t:1527268592543};\\\", \\\"{x:223,y:541,t:1527268592560};\\\", \\\"{x:221,y:540,t:1527268592577};\\\", \\\"{x:219,y:538,t:1527268592594};\\\", \\\"{x:218,y:538,t:1527268592610};\\\", \\\"{x:217,y:537,t:1527268592627};\\\", \\\"{x:216,y:536,t:1527268592644};\\\", \\\"{x:214,y:536,t:1527268592660};\\\", \\\"{x:212,y:536,t:1527268592677};\\\", \\\"{x:210,y:536,t:1527268592694};\\\", \\\"{x:207,y:536,t:1527268592712};\\\", \\\"{x:203,y:536,t:1527268592728};\\\", \\\"{x:189,y:536,t:1527268592745};\\\", \\\"{x:175,y:538,t:1527268592761};\\\", \\\"{x:160,y:538,t:1527268592778};\\\", \\\"{x:154,y:538,t:1527268592794};\\\", \\\"{x:152,y:538,t:1527268592812};\\\", \\\"{x:151,y:539,t:1527268592827};\\\", \\\"{x:160,y:539,t:1527268593232};\\\", \\\"{x:174,y:539,t:1527268593244};\\\", \\\"{x:212,y:539,t:1527268593261};\\\", \\\"{x:266,y:539,t:1527268593278};\\\", \\\"{x:327,y:541,t:1527268593295};\\\", \\\"{x:419,y:547,t:1527268593311};\\\", \\\"{x:482,y:554,t:1527268593328};\\\", \\\"{x:531,y:557,t:1527268593345};\\\", \\\"{x:576,y:563,t:1527268593361};\\\", \\\"{x:624,y:570,t:1527268593378};\\\", \\\"{x:666,y:576,t:1527268593394};\\\", \\\"{x:699,y:580,t:1527268593411};\\\", \\\"{x:739,y:585,t:1527268593429};\\\", \\\"{x:794,y:590,t:1527268593445};\\\", \\\"{x:870,y:593,t:1527268593461};\\\", \\\"{x:946,y:599,t:1527268593479};\\\", \\\"{x:1037,y:604,t:1527268593495};\\\", \\\"{x:1166,y:623,t:1527268593511};\\\", \\\"{x:1251,y:632,t:1527268593528};\\\", \\\"{x:1327,y:645,t:1527268593545};\\\", \\\"{x:1391,y:655,t:1527268593562};\\\", \\\"{x:1458,y:664,t:1527268593578};\\\", \\\"{x:1500,y:664,t:1527268593595};\\\", \\\"{x:1540,y:664,t:1527268593612};\\\", \\\"{x:1555,y:669,t:1527268593629};\\\", \\\"{x:1564,y:673,t:1527268593646};\\\", \\\"{x:1566,y:677,t:1527268593661};\\\", \\\"{x:1566,y:678,t:1527268593737};\\\", \\\"{x:1566,y:679,t:1527268593752};\\\", \\\"{x:1566,y:680,t:1527268593768};\\\", \\\"{x:1565,y:681,t:1527268593792};\\\", \\\"{x:1564,y:682,t:1527268593824};\\\", \\\"{x:1561,y:682,t:1527268593832};\\\", \\\"{x:1559,y:683,t:1527268593845};\\\", \\\"{x:1552,y:685,t:1527268593862};\\\", \\\"{x:1543,y:687,t:1527268593879};\\\", \\\"{x:1536,y:689,t:1527268593895};\\\", \\\"{x:1535,y:690,t:1527268593911};\\\", \\\"{x:1534,y:690,t:1527268593928};\\\", \\\"{x:1533,y:690,t:1527268594055};\\\", \\\"{x:1533,y:691,t:1527268594193};\\\", \\\"{x:1533,y:692,t:1527268594208};\\\", \\\"{x:1533,y:694,t:1527268594216};\\\", \\\"{x:1535,y:696,t:1527268594229};\\\", \\\"{x:1537,y:698,t:1527268594246};\\\", \\\"{x:1542,y:702,t:1527268594263};\\\", \\\"{x:1547,y:705,t:1527268594278};\\\", \\\"{x:1553,y:708,t:1527268594296};\\\", \\\"{x:1555,y:709,t:1527268594312};\\\", \\\"{x:1555,y:710,t:1527268594329};\\\", \\\"{x:1556,y:710,t:1527268594608};\\\", \\\"{x:1558,y:711,t:1527268594632};\\\", \\\"{x:1560,y:711,t:1527268594648};\\\", \\\"{x:1561,y:711,t:1527268594663};\\\", \\\"{x:1563,y:711,t:1527268594680};\\\", \\\"{x:1565,y:711,t:1527268594695};\\\", \\\"{x:1567,y:711,t:1527268594712};\\\", \\\"{x:1568,y:711,t:1527268594730};\\\", \\\"{x:1569,y:711,t:1527268594746};\\\", \\\"{x:1569,y:710,t:1527268594784};\\\", \\\"{x:1569,y:708,t:1527268594928};\\\", \\\"{x:1568,y:708,t:1527268594976};\\\", \\\"{x:1567,y:707,t:1527268595000};\\\", \\\"{x:1566,y:707,t:1527268595056};\\\", \\\"{x:1566,y:708,t:1527268595201};\\\", \\\"{x:1566,y:709,t:1527268595213};\\\", \\\"{x:1566,y:710,t:1527268595229};\\\", \\\"{x:1566,y:711,t:1527268595247};\\\", \\\"{x:1566,y:712,t:1527268595272};\\\", \\\"{x:1566,y:713,t:1527268595481};\\\", \\\"{x:1564,y:713,t:1527268595496};\\\", \\\"{x:1562,y:712,t:1527268595514};\\\", \\\"{x:1559,y:712,t:1527268595530};\\\", \\\"{x:1558,y:711,t:1527268595546};\\\", \\\"{x:1557,y:711,t:1527268595564};\\\", \\\"{x:1555,y:711,t:1527268595580};\\\", \\\"{x:1552,y:709,t:1527268595597};\\\", \\\"{x:1547,y:708,t:1527268595614};\\\", \\\"{x:1539,y:707,t:1527268595630};\\\", \\\"{x:1535,y:706,t:1527268595647};\\\", \\\"{x:1526,y:705,t:1527268595664};\\\", \\\"{x:1521,y:704,t:1527268595680};\\\", \\\"{x:1519,y:704,t:1527268595696};\\\", \\\"{x:1517,y:704,t:1527268595714};\\\", \\\"{x:1516,y:704,t:1527268595744};\\\", \\\"{x:1519,y:704,t:1527268596057};\\\", \\\"{x:1523,y:704,t:1527268596064};\\\", \\\"{x:1526,y:704,t:1527268596080};\\\", \\\"{x:1529,y:704,t:1527268596096};\\\", \\\"{x:1532,y:704,t:1527268596113};\\\", \\\"{x:1533,y:705,t:1527268596131};\\\", \\\"{x:1533,y:706,t:1527268596147};\\\", \\\"{x:1533,y:708,t:1527268596164};\\\", \\\"{x:1533,y:709,t:1527268596181};\\\", \\\"{x:1534,y:710,t:1527268596197};\\\", \\\"{x:1535,y:711,t:1527268596401};\\\", \\\"{x:1536,y:711,t:1527268596448};\\\", \\\"{x:1538,y:710,t:1527268596464};\\\", \\\"{x:1539,y:710,t:1527268596481};\\\", \\\"{x:1540,y:708,t:1527268596498};\\\", \\\"{x:1541,y:707,t:1527268596514};\\\", \\\"{x:1542,y:706,t:1527268596617};\\\", \\\"{x:1542,y:705,t:1527268596649};\\\", \\\"{x:1542,y:704,t:1527268596664};\\\", \\\"{x:1542,y:703,t:1527268596680};\\\", \\\"{x:1543,y:701,t:1527268596697};\\\", \\\"{x:1544,y:700,t:1527268596728};\\\", \\\"{x:1544,y:699,t:1527268596856};\\\", \\\"{x:1545,y:699,t:1527268597809};\\\", \\\"{x:1546,y:700,t:1527268599392};\\\", \\\"{x:1546,y:701,t:1527268599720};\\\", \\\"{x:1548,y:701,t:1527268599864};\\\", \\\"{x:1548,y:702,t:1527268601512};\\\", \\\"{x:1548,y:703,t:1527268601585};\\\", \\\"{x:1550,y:703,t:1527268601729};\\\", \\\"{x:1551,y:704,t:1527268601760};\\\", \\\"{x:1552,y:704,t:1527268601808};\\\", \\\"{x:1553,y:704,t:1527268601873};\\\", \\\"{x:1554,y:704,t:1527268602928};\\\", \\\"{x:1552,y:704,t:1527268604241};\\\", \\\"{x:1535,y:704,t:1527268604253};\\\", \\\"{x:1477,y:704,t:1527268604270};\\\", \\\"{x:1396,y:704,t:1527268604286};\\\", \\\"{x:1299,y:704,t:1527268604303};\\\", \\\"{x:1155,y:704,t:1527268604319};\\\", \\\"{x:1074,y:704,t:1527268604336};\\\", \\\"{x:1010,y:704,t:1527268604353};\\\", \\\"{x:957,y:704,t:1527268604370};\\\", \\\"{x:918,y:704,t:1527268604386};\\\", \\\"{x:887,y:704,t:1527268604403};\\\", \\\"{x:861,y:704,t:1527268604420};\\\", \\\"{x:841,y:704,t:1527268604436};\\\", \\\"{x:818,y:704,t:1527268604453};\\\", \\\"{x:797,y:706,t:1527268604470};\\\", \\\"{x:784,y:707,t:1527268604486};\\\", \\\"{x:773,y:710,t:1527268604503};\\\", \\\"{x:758,y:715,t:1527268604520};\\\", \\\"{x:747,y:720,t:1527268604537};\\\", \\\"{x:731,y:727,t:1527268604553};\\\", \\\"{x:716,y:737,t:1527268604570};\\\", \\\"{x:708,y:742,t:1527268604587};\\\", \\\"{x:703,y:746,t:1527268604603};\\\", \\\"{x:701,y:748,t:1527268604620};\\\", \\\"{x:699,y:748,t:1527268604637};\\\", \\\"{x:697,y:748,t:1527268604653};\\\", \\\"{x:692,y:748,t:1527268604670};\\\", \\\"{x:685,y:748,t:1527268604687};\\\", \\\"{x:682,y:748,t:1527268604703};\\\", \\\"{x:670,y:748,t:1527268604720};\\\", \\\"{x:659,y:743,t:1527268604737};\\\", \\\"{x:650,y:738,t:1527268604753};\\\", \\\"{x:640,y:736,t:1527268604770};\\\", \\\"{x:632,y:734,t:1527268604787};\\\", \\\"{x:628,y:733,t:1527268604803};\\\", \\\"{x:627,y:732,t:1527268604820};\\\", \\\"{x:623,y:732,t:1527268604837};\\\", \\\"{x:619,y:730,t:1527268604853};\\\", \\\"{x:616,y:729,t:1527268604870};\\\", \\\"{x:615,y:729,t:1527268604887};\\\", \\\"{x:614,y:728,t:1527268604903};\\\", \\\"{x:611,y:726,t:1527268604920};\\\", \\\"{x:606,y:724,t:1527268604937};\\\", \\\"{x:593,y:723,t:1527268604954};\\\", \\\"{x:573,y:723,t:1527268604970};\\\", \\\"{x:550,y:723,t:1527268604988};\\\", \\\"{x:529,y:723,t:1527268605003};\\\", \\\"{x:513,y:723,t:1527268605019};\\\", \\\"{x:498,y:723,t:1527268605036};\\\", \\\"{x:488,y:723,t:1527268605053};\\\", \\\"{x:486,y:723,t:1527268605070};\\\", \\\"{x:484,y:723,t:1527268605303};\\\", \\\"{x:482,y:728,t:1527268605330};\\\", \\\"{x:482,y:729,t:1527268605338};\\\", \\\"{x:482,y:730,t:1527268605353};\\\", \\\"{x:482,y:728,t:1527268605560};\\\", \\\"{x:482,y:727,t:1527268605571};\\\", \\\"{x:482,y:726,t:1527268605588};\\\", \\\"{x:483,y:724,t:1527268605605};\\\", \\\"{x:484,y:722,t:1527268605688};\\\", \\\"{x:485,y:721,t:1527268605705};\\\", \\\"{x:486,y:720,t:1527268605735};\\\", \\\"{x:487,y:719,t:1527268605768};\\\", \\\"{x:488,y:718,t:1527268605791};\\\", \\\"{x:490,y:719,t:1527268605864};\\\", \\\"{x:491,y:719,t:1527268605903};\\\", \\\"{x:492,y:720,t:1527268605984};\\\", \\\"{x:493,y:720,t:1527268605991};\\\", \\\"{x:493,y:721,t:1527268606008};\\\", \\\"{x:494,y:721,t:1527268606039};\\\", \\\"{x:496,y:722,t:1527268606055};\\\", \\\"{x:498,y:724,t:1527268606071};\\\", \\\"{x:499,y:725,t:1527268606088};\\\", \\\"{x:502,y:727,t:1527268606105};\\\", \\\"{x:506,y:730,t:1527268606122};\\\", \\\"{x:513,y:735,t:1527268606138};\\\", \\\"{x:516,y:737,t:1527268606155};\\\", \\\"{x:520,y:739,t:1527268606172};\\\", \\\"{x:523,y:740,t:1527268606188};\\\", \\\"{x:523,y:741,t:1527268606288};\\\", \\\"{x:524,y:741,t:1527268606305};\\\", \\\"{x:525,y:742,t:1527268606322};\\\", \\\"{x:526,y:743,t:1527268606341};\\\" ] }, { \\\"rt\\\": 57030, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 699335, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-F -X -O -X -X -B -12 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:744,t:1527268606535};\\\", \\\"{x:534,y:744,t:1527268606655};\\\", \\\"{x:535,y:744,t:1527268606693};\\\", \\\"{x:536,y:743,t:1527268606719};\\\", \\\"{x:537,y:743,t:1527268606727};\\\", \\\"{x:537,y:742,t:1527268606738};\\\", \\\"{x:541,y:741,t:1527268606756};\\\", \\\"{x:542,y:741,t:1527268606775};\\\", \\\"{x:543,y:741,t:1527268606788};\\\", \\\"{x:544,y:741,t:1527268606806};\\\", \\\"{x:546,y:741,t:1527268606822};\\\", \\\"{x:547,y:741,t:1527268606838};\\\", \\\"{x:548,y:741,t:1527268606855};\\\", \\\"{x:551,y:741,t:1527268606871};\\\", \\\"{x:553,y:741,t:1527268606889};\\\", \\\"{x:554,y:741,t:1527268606906};\\\", \\\"{x:555,y:741,t:1527268607030};\\\", \\\"{x:556,y:741,t:1527268607076};\\\", \\\"{x:557,y:741,t:1527268607094};\\\", \\\"{x:558,y:741,t:1527268607118};\\\", \\\"{x:559,y:741,t:1527268607142};\\\", \\\"{x:561,y:740,t:1527268607167};\\\", \\\"{x:561,y:739,t:1527268607190};\\\", \\\"{x:562,y:739,t:1527268607207};\\\", \\\"{x:563,y:739,t:1527268607231};\\\", \\\"{x:564,y:739,t:1527268607247};\\\", \\\"{x:565,y:739,t:1527268607256};\\\", \\\"{x:567,y:739,t:1527268607287};\\\", \\\"{x:568,y:739,t:1527268607311};\\\", \\\"{x:569,y:739,t:1527268607328};\\\", \\\"{x:571,y:739,t:1527268607343};\\\", \\\"{x:572,y:739,t:1527268607359};\\\", \\\"{x:572,y:738,t:1527268607373};\\\", \\\"{x:575,y:738,t:1527268607389};\\\", \\\"{x:578,y:738,t:1527268607406};\\\", \\\"{x:583,y:738,t:1527268607423};\\\", \\\"{x:586,y:738,t:1527268607439};\\\", \\\"{x:589,y:738,t:1527268607456};\\\", \\\"{x:591,y:738,t:1527268607472};\\\", \\\"{x:592,y:737,t:1527268607504};\\\", \\\"{x:593,y:737,t:1527268607543};\\\", \\\"{x:593,y:736,t:1527268607559};\\\", \\\"{x:594,y:736,t:1527268607572};\\\", \\\"{x:595,y:735,t:1527268607590};\\\", \\\"{x:596,y:734,t:1527268607606};\\\", \\\"{x:597,y:733,t:1527268607622};\\\", \\\"{x:598,y:732,t:1527268607639};\\\", \\\"{x:601,y:729,t:1527268607656};\\\", \\\"{x:605,y:727,t:1527268607672};\\\", \\\"{x:609,y:724,t:1527268607689};\\\", \\\"{x:613,y:721,t:1527268607705};\\\", \\\"{x:618,y:717,t:1527268607723};\\\", \\\"{x:624,y:712,t:1527268607740};\\\", \\\"{x:630,y:707,t:1527268607755};\\\", \\\"{x:639,y:702,t:1527268607773};\\\", \\\"{x:641,y:699,t:1527268607791};\\\", \\\"{x:643,y:697,t:1527268607806};\\\", \\\"{x:645,y:695,t:1527268607823};\\\", \\\"{x:646,y:694,t:1527268607848};\\\", \\\"{x:648,y:692,t:1527268607856};\\\", \\\"{x:653,y:687,t:1527268607873};\\\", \\\"{x:656,y:684,t:1527268607890};\\\", \\\"{x:658,y:682,t:1527268607906};\\\", \\\"{x:661,y:678,t:1527268607923};\\\", \\\"{x:664,y:676,t:1527268607940};\\\", \\\"{x:664,y:675,t:1527268607957};\\\", \\\"{x:665,y:674,t:1527268608471};\\\", \\\"{x:666,y:674,t:1527268608784};\\\", \\\"{x:667,y:674,t:1527268608816};\\\", \\\"{x:668,y:674,t:1527268608823};\\\", \\\"{x:670,y:672,t:1527268608841};\\\", \\\"{x:671,y:671,t:1527268608857};\\\", \\\"{x:672,y:670,t:1527268608895};\\\", \\\"{x:674,y:668,t:1527268608907};\\\", \\\"{x:676,y:668,t:1527268608924};\\\", \\\"{x:676,y:667,t:1527268608959};\\\", \\\"{x:677,y:666,t:1527268608974};\\\", \\\"{x:679,y:666,t:1527268609088};\\\", \\\"{x:680,y:666,t:1527268609104};\\\", \\\"{x:682,y:666,t:1527268609111};\\\", \\\"{x:683,y:666,t:1527268609128};\\\", \\\"{x:684,y:666,t:1527268609141};\\\", \\\"{x:685,y:666,t:1527268609157};\\\", \\\"{x:686,y:666,t:1527268609240};\\\", \\\"{x:687,y:666,t:1527268609263};\\\", \\\"{x:688,y:666,t:1527268609274};\\\", \\\"{x:690,y:666,t:1527268609291};\\\", \\\"{x:696,y:669,t:1527268609308};\\\", \\\"{x:700,y:669,t:1527268609324};\\\", \\\"{x:703,y:671,t:1527268609341};\\\", \\\"{x:708,y:673,t:1527268609358};\\\", \\\"{x:710,y:674,t:1527268609375};\\\", \\\"{x:713,y:678,t:1527268609391};\\\", \\\"{x:713,y:688,t:1527268609408};\\\", \\\"{x:713,y:691,t:1527268609424};\\\", \\\"{x:713,y:695,t:1527268609441};\\\", \\\"{x:713,y:697,t:1527268609458};\\\", \\\"{x:713,y:698,t:1527268609474};\\\", \\\"{x:713,y:699,t:1527268609496};\\\", \\\"{x:715,y:699,t:1527268609992};\\\", \\\"{x:716,y:699,t:1527268610023};\\\", \\\"{x:716,y:698,t:1527268610032};\\\", \\\"{x:717,y:698,t:1527268610088};\\\", \\\"{x:718,y:698,t:1527268610112};\\\", \\\"{x:719,y:698,t:1527268610144};\\\", \\\"{x:719,y:697,t:1527268610160};\\\", \\\"{x:721,y:695,t:1527268610175};\\\", \\\"{x:722,y:694,t:1527268610200};\\\", \\\"{x:722,y:693,t:1527268610216};\\\", \\\"{x:723,y:692,t:1527268610239};\\\", \\\"{x:724,y:691,t:1527268610247};\\\", \\\"{x:724,y:690,t:1527268610280};\\\", \\\"{x:725,y:689,t:1527268610295};\\\", \\\"{x:725,y:688,t:1527268610344};\\\", \\\"{x:725,y:687,t:1527268610368};\\\", \\\"{x:726,y:686,t:1527268610384};\\\", \\\"{x:727,y:686,t:1527268610392};\\\", \\\"{x:727,y:685,t:1527268610408};\\\", \\\"{x:728,y:683,t:1527268610776};\\\", \\\"{x:728,y:682,t:1527268610848};\\\", \\\"{x:729,y:681,t:1527268610879};\\\", \\\"{x:730,y:681,t:1527268611016};\\\", \\\"{x:730,y:680,t:1527268611032};\\\", \\\"{x:731,y:679,t:1527268611047};\\\", \\\"{x:731,y:678,t:1527268611064};\\\", \\\"{x:731,y:677,t:1527268611079};\\\", \\\"{x:732,y:677,t:1527268611093};\\\", \\\"{x:733,y:675,t:1527268611110};\\\", \\\"{x:734,y:673,t:1527268611126};\\\", \\\"{x:734,y:672,t:1527268611160};\\\", \\\"{x:735,y:672,t:1527268611176};\\\", \\\"{x:736,y:670,t:1527268611192};\\\", \\\"{x:737,y:668,t:1527268611210};\\\", \\\"{x:738,y:666,t:1527268611226};\\\", \\\"{x:739,y:664,t:1527268611242};\\\", \\\"{x:740,y:662,t:1527268611259};\\\", \\\"{x:740,y:661,t:1527268611279};\\\", \\\"{x:740,y:660,t:1527268611304};\\\", \\\"{x:740,y:659,t:1527268611592};\\\", \\\"{x:741,y:658,t:1527268611609};\\\", \\\"{x:743,y:655,t:1527268611626};\\\", \\\"{x:743,y:654,t:1527268611643};\\\", \\\"{x:742,y:654,t:1527268612152};\\\", \\\"{x:741,y:654,t:1527268612184};\\\", \\\"{x:740,y:655,t:1527268612328};\\\", \\\"{x:739,y:656,t:1527268612344};\\\", \\\"{x:738,y:656,t:1527268612367};\\\", \\\"{x:737,y:657,t:1527268612392};\\\", \\\"{x:736,y:658,t:1527268612440};\\\", \\\"{x:735,y:658,t:1527268612487};\\\", \\\"{x:734,y:658,t:1527268612496};\\\", \\\"{x:733,y:659,t:1527268612518};\\\", \\\"{x:730,y:661,t:1527268612527};\\\", \\\"{x:728,y:663,t:1527268612543};\\\", \\\"{x:725,y:667,t:1527268612560};\\\", \\\"{x:721,y:671,t:1527268612577};\\\", \\\"{x:719,y:673,t:1527268612593};\\\", \\\"{x:717,y:676,t:1527268612610};\\\", \\\"{x:717,y:677,t:1527268612627};\\\", \\\"{x:716,y:677,t:1527268612643};\\\", \\\"{x:715,y:679,t:1527268612663};\\\", \\\"{x:714,y:680,t:1527268612677};\\\", \\\"{x:711,y:683,t:1527268612692};\\\", \\\"{x:708,y:690,t:1527268612710};\\\", \\\"{x:705,y:693,t:1527268612727};\\\", \\\"{x:705,y:694,t:1527268612976};\\\", \\\"{x:703,y:695,t:1527268613016};\\\", \\\"{x:702,y:696,t:1527268613040};\\\", \\\"{x:702,y:697,t:1527268613056};\\\", \\\"{x:702,y:696,t:1527268613528};\\\", \\\"{x:703,y:694,t:1527268613544};\\\", \\\"{x:703,y:693,t:1527268613561};\\\", \\\"{x:705,y:690,t:1527268613578};\\\", \\\"{x:706,y:690,t:1527268613600};\\\", \\\"{x:707,y:688,t:1527268613615};\\\", \\\"{x:707,y:686,t:1527268613655};\\\", \\\"{x:707,y:685,t:1527268613664};\\\", \\\"{x:709,y:684,t:1527268613678};\\\", \\\"{x:710,y:682,t:1527268613695};\\\", \\\"{x:712,y:679,t:1527268613711};\\\", \\\"{x:713,y:679,t:1527268613728};\\\", \\\"{x:714,y:678,t:1527268613745};\\\", \\\"{x:715,y:677,t:1527268613767};\\\", \\\"{x:716,y:677,t:1527268613784};\\\", \\\"{x:717,y:676,t:1527268613794};\\\", \\\"{x:719,y:675,t:1527268613811};\\\", \\\"{x:720,y:674,t:1527268613828};\\\", \\\"{x:723,y:674,t:1527268613844};\\\", \\\"{x:729,y:674,t:1527268613861};\\\", \\\"{x:736,y:673,t:1527268613877};\\\", \\\"{x:739,y:671,t:1527268613894};\\\", \\\"{x:741,y:671,t:1527268613910};\\\", \\\"{x:744,y:670,t:1527268613928};\\\", \\\"{x:747,y:667,t:1527268613943};\\\", \\\"{x:752,y:663,t:1527268613961};\\\", \\\"{x:760,y:658,t:1527268613978};\\\", \\\"{x:768,y:654,t:1527268613994};\\\", \\\"{x:771,y:652,t:1527268614011};\\\", \\\"{x:773,y:650,t:1527268614028};\\\", \\\"{x:773,y:649,t:1527268614044};\\\", \\\"{x:774,y:648,t:1527268614061};\\\", \\\"{x:775,y:647,t:1527268614079};\\\", \\\"{x:776,y:646,t:1527268614095};\\\", \\\"{x:779,y:644,t:1527268614113};\\\", \\\"{x:781,y:640,t:1527268614128};\\\", \\\"{x:786,y:632,t:1527268614144};\\\", \\\"{x:792,y:626,t:1527268614161};\\\", \\\"{x:794,y:623,t:1527268614178};\\\", \\\"{x:796,y:620,t:1527268614195};\\\", \\\"{x:796,y:618,t:1527268614210};\\\", \\\"{x:798,y:617,t:1527268614255};\\\", \\\"{x:798,y:616,t:1527268614271};\\\", \\\"{x:799,y:616,t:1527268614278};\\\", \\\"{x:799,y:615,t:1527268614295};\\\", \\\"{x:800,y:614,t:1527268614320};\\\", \\\"{x:801,y:613,t:1527268614344};\\\", \\\"{x:802,y:612,t:1527268614367};\\\", \\\"{x:803,y:611,t:1527268614424};\\\", \\\"{x:804,y:610,t:1527268614448};\\\", \\\"{x:805,y:609,t:1527268614463};\\\", \\\"{x:805,y:608,t:1527268614488};\\\", \\\"{x:806,y:608,t:1527268614495};\\\", \\\"{x:806,y:606,t:1527268614513};\\\", \\\"{x:807,y:606,t:1527268614528};\\\", \\\"{x:807,y:605,t:1527268614550};\\\", \\\"{x:808,y:605,t:1527268614566};\\\", \\\"{x:808,y:604,t:1527268614591};\\\", \\\"{x:809,y:603,t:1527268614712};\\\", \\\"{x:811,y:602,t:1527268614752};\\\", \\\"{x:814,y:602,t:1527268614762};\\\", \\\"{x:815,y:601,t:1527268614783};\\\", \\\"{x:816,y:601,t:1527268614823};\\\", \\\"{x:819,y:601,t:1527268614855};\\\", \\\"{x:822,y:599,t:1527268614864};\\\", \\\"{x:825,y:599,t:1527268614879};\\\", \\\"{x:838,y:598,t:1527268614895};\\\", \\\"{x:844,y:597,t:1527268614912};\\\", \\\"{x:845,y:597,t:1527268614929};\\\", \\\"{x:848,y:597,t:1527268614944};\\\", \\\"{x:851,y:595,t:1527268614962};\\\", \\\"{x:853,y:595,t:1527268614979};\\\", \\\"{x:857,y:595,t:1527268614995};\\\", \\\"{x:860,y:595,t:1527268615012};\\\", \\\"{x:863,y:594,t:1527268615029};\\\", \\\"{x:865,y:594,t:1527268615045};\\\", \\\"{x:862,y:593,t:1527268615201};\\\", \\\"{x:861,y:593,t:1527268615212};\\\", \\\"{x:860,y:593,t:1527268615229};\\\", \\\"{x:860,y:592,t:1527268615246};\\\", \\\"{x:858,y:592,t:1527268615262};\\\", \\\"{x:856,y:591,t:1527268615287};\\\", \\\"{x:855,y:590,t:1527268615295};\\\", \\\"{x:851,y:589,t:1527268615312};\\\", \\\"{x:849,y:589,t:1527268615329};\\\", \\\"{x:846,y:588,t:1527268615345};\\\", \\\"{x:844,y:588,t:1527268615362};\\\", \\\"{x:843,y:588,t:1527268615383};\\\", \\\"{x:842,y:588,t:1527268615560};\\\", \\\"{x:841,y:588,t:1527268615568};\\\", \\\"{x:840,y:588,t:1527268615579};\\\", \\\"{x:837,y:592,t:1527268615596};\\\", \\\"{x:834,y:596,t:1527268615612};\\\", \\\"{x:831,y:601,t:1527268615629};\\\", \\\"{x:826,y:608,t:1527268615647};\\\", \\\"{x:814,y:619,t:1527268615663};\\\", \\\"{x:805,y:627,t:1527268615679};\\\", \\\"{x:798,y:632,t:1527268615696};\\\", \\\"{x:794,y:636,t:1527268615712};\\\", \\\"{x:791,y:639,t:1527268615729};\\\", \\\"{x:788,y:641,t:1527268615746};\\\", \\\"{x:786,y:643,t:1527268615762};\\\", \\\"{x:785,y:643,t:1527268615779};\\\", \\\"{x:783,y:646,t:1527268615842};\\\", \\\"{x:783,y:648,t:1527268616031};\\\", \\\"{x:783,y:649,t:1527268616047};\\\", \\\"{x:784,y:649,t:1527268616064};\\\", \\\"{x:785,y:650,t:1527268616080};\\\", \\\"{x:786,y:651,t:1527268616097};\\\", \\\"{x:787,y:652,t:1527268616114};\\\", \\\"{x:788,y:652,t:1527268616131};\\\", \\\"{x:788,y:654,t:1527268616167};\\\", \\\"{x:789,y:654,t:1527268616183};\\\", \\\"{x:790,y:655,t:1527268616198};\\\", \\\"{x:791,y:655,t:1527268616239};\\\", \\\"{x:793,y:655,t:1527268616255};\\\", \\\"{x:795,y:655,t:1527268616271};\\\", \\\"{x:796,y:655,t:1527268616281};\\\", \\\"{x:798,y:655,t:1527268616298};\\\", \\\"{x:799,y:656,t:1527268616315};\\\", \\\"{x:801,y:656,t:1527268616344};\\\", \\\"{x:803,y:657,t:1527268616359};\\\", \\\"{x:805,y:657,t:1527268616375};\\\", \\\"{x:806,y:658,t:1527268616391};\\\", \\\"{x:807,y:658,t:1527268616407};\\\", \\\"{x:808,y:658,t:1527268616415};\\\", \\\"{x:809,y:658,t:1527268616476};\\\", \\\"{x:810,y:659,t:1527268616896};\\\", \\\"{x:811,y:659,t:1527268616903};\\\", \\\"{x:812,y:659,t:1527268616968};\\\", \\\"{x:813,y:660,t:1527268616985};\\\", \\\"{x:814,y:660,t:1527268617007};\\\", \\\"{x:816,y:660,t:1527268617032};\\\", \\\"{x:817,y:660,t:1527268617039};\\\", \\\"{x:818,y:661,t:1527268617056};\\\", \\\"{x:819,y:661,t:1527268617068};\\\", \\\"{x:820,y:661,t:1527268617086};\\\", \\\"{x:821,y:661,t:1527268617102};\\\", \\\"{x:822,y:661,t:1527268617119};\\\", \\\"{x:823,y:661,t:1527268617136};\\\", \\\"{x:824,y:662,t:1527268617152};\\\", \\\"{x:826,y:662,t:1527268617170};\\\", \\\"{x:828,y:663,t:1527268617186};\\\", \\\"{x:829,y:663,t:1527268617207};\\\", \\\"{x:830,y:664,t:1527268617224};\\\", \\\"{x:831,y:664,t:1527268617236};\\\", \\\"{x:832,y:664,t:1527268617252};\\\", \\\"{x:833,y:664,t:1527268617269};\\\", \\\"{x:834,y:664,t:1527268617287};\\\", \\\"{x:835,y:664,t:1527268617303};\\\", \\\"{x:838,y:665,t:1527268617320};\\\", \\\"{x:846,y:665,t:1527268617337};\\\", \\\"{x:870,y:670,t:1527268617353};\\\", \\\"{x:914,y:675,t:1527268617369};\\\", \\\"{x:975,y:683,t:1527268617387};\\\", \\\"{x:1061,y:692,t:1527268617404};\\\", \\\"{x:1133,y:692,t:1527268617422};\\\", \\\"{x:1209,y:696,t:1527268617437};\\\", \\\"{x:1276,y:696,t:1527268617454};\\\", \\\"{x:1343,y:696,t:1527268617473};\\\", \\\"{x:1426,y:696,t:1527268617487};\\\", \\\"{x:1477,y:696,t:1527268617503};\\\", \\\"{x:1505,y:696,t:1527268617520};\\\", \\\"{x:1523,y:696,t:1527268617537};\\\", \\\"{x:1535,y:696,t:1527268617554};\\\", \\\"{x:1542,y:698,t:1527268617570};\\\", \\\"{x:1548,y:699,t:1527268617587};\\\", \\\"{x:1553,y:699,t:1527268617604};\\\", \\\"{x:1560,y:700,t:1527268617621};\\\", \\\"{x:1573,y:702,t:1527268617637};\\\", \\\"{x:1593,y:703,t:1527268617654};\\\", \\\"{x:1629,y:704,t:1527268617671};\\\", \\\"{x:1652,y:704,t:1527268617688};\\\", \\\"{x:1676,y:704,t:1527268617704};\\\", \\\"{x:1702,y:704,t:1527268617721};\\\", \\\"{x:1717,y:704,t:1527268617738};\\\", \\\"{x:1723,y:704,t:1527268617756};\\\", \\\"{x:1724,y:704,t:1527268617772};\\\", \\\"{x:1725,y:704,t:1527268617788};\\\", \\\"{x:1726,y:706,t:1527268617816};\\\", \\\"{x:1726,y:707,t:1527268617824};\\\", \\\"{x:1727,y:708,t:1527268617839};\\\", \\\"{x:1729,y:715,t:1527268617855};\\\", \\\"{x:1730,y:719,t:1527268617873};\\\", \\\"{x:1730,y:721,t:1527268617889};\\\", \\\"{x:1730,y:725,t:1527268617905};\\\", \\\"{x:1730,y:727,t:1527268617922};\\\", \\\"{x:1731,y:732,t:1527268617940};\\\", \\\"{x:1733,y:741,t:1527268617956};\\\", \\\"{x:1734,y:752,t:1527268617972};\\\", \\\"{x:1734,y:761,t:1527268617989};\\\", \\\"{x:1734,y:769,t:1527268618007};\\\", \\\"{x:1734,y:775,t:1527268618023};\\\", \\\"{x:1734,y:782,t:1527268618040};\\\", \\\"{x:1734,y:784,t:1527268618057};\\\", \\\"{x:1733,y:785,t:1527268618074};\\\", \\\"{x:1733,y:786,t:1527268618119};\\\", \\\"{x:1732,y:788,t:1527268618136};\\\", \\\"{x:1730,y:789,t:1527268618152};\\\", \\\"{x:1728,y:791,t:1527268618160};\\\", \\\"{x:1725,y:793,t:1527268618174};\\\", \\\"{x:1717,y:797,t:1527268618191};\\\", \\\"{x:1704,y:801,t:1527268618207};\\\", \\\"{x:1695,y:803,t:1527268618223};\\\", \\\"{x:1692,y:803,t:1527268618241};\\\", \\\"{x:1689,y:804,t:1527268618258};\\\", \\\"{x:1688,y:804,t:1527268618274};\\\", \\\"{x:1685,y:804,t:1527268618291};\\\", \\\"{x:1683,y:805,t:1527268618308};\\\", \\\"{x:1678,y:805,t:1527268618324};\\\", \\\"{x:1675,y:806,t:1527268618343};\\\", \\\"{x:1672,y:806,t:1527268618358};\\\", \\\"{x:1670,y:806,t:1527268618375};\\\", \\\"{x:1664,y:806,t:1527268618391};\\\", \\\"{x:1658,y:806,t:1527268618408};\\\", \\\"{x:1653,y:809,t:1527268618425};\\\", \\\"{x:1650,y:810,t:1527268618441};\\\", \\\"{x:1645,y:812,t:1527268618459};\\\", \\\"{x:1637,y:813,t:1527268618475};\\\", \\\"{x:1630,y:813,t:1527268618492};\\\", \\\"{x:1624,y:813,t:1527268618508};\\\", \\\"{x:1619,y:813,t:1527268618525};\\\", \\\"{x:1616,y:813,t:1527268618543};\\\", \\\"{x:1615,y:813,t:1527268618616};\\\", \\\"{x:1614,y:814,t:1527268618713};\\\", \\\"{x:1614,y:817,t:1527268618726};\\\", \\\"{x:1613,y:824,t:1527268618743};\\\", \\\"{x:1608,y:832,t:1527268618760};\\\", \\\"{x:1605,y:841,t:1527268618777};\\\", \\\"{x:1599,y:847,t:1527268618793};\\\", \\\"{x:1590,y:855,t:1527268618810};\\\", \\\"{x:1583,y:860,t:1527268618827};\\\", \\\"{x:1575,y:866,t:1527268618843};\\\", \\\"{x:1567,y:866,t:1527268618861};\\\", \\\"{x:1559,y:868,t:1527268618877};\\\", \\\"{x:1551,y:872,t:1527268618893};\\\", \\\"{x:1546,y:873,t:1527268618911};\\\", \\\"{x:1540,y:876,t:1527268618928};\\\", \\\"{x:1537,y:877,t:1527268618943};\\\", \\\"{x:1536,y:878,t:1527268618976};\\\", \\\"{x:1535,y:878,t:1527268618984};\\\", \\\"{x:1534,y:879,t:1527268619000};\\\", \\\"{x:1534,y:880,t:1527268619011};\\\", \\\"{x:1532,y:881,t:1527268619028};\\\", \\\"{x:1531,y:885,t:1527268619045};\\\", \\\"{x:1531,y:891,t:1527268619061};\\\", \\\"{x:1531,y:898,t:1527268619078};\\\", \\\"{x:1533,y:906,t:1527268619095};\\\", \\\"{x:1535,y:910,t:1527268619112};\\\", \\\"{x:1537,y:913,t:1527268619128};\\\", \\\"{x:1537,y:916,t:1527268619145};\\\", \\\"{x:1539,y:920,t:1527268619162};\\\", \\\"{x:1540,y:923,t:1527268619179};\\\", \\\"{x:1542,y:925,t:1527268619195};\\\", \\\"{x:1543,y:929,t:1527268619212};\\\", \\\"{x:1543,y:931,t:1527268619229};\\\", \\\"{x:1544,y:933,t:1527268619246};\\\", \\\"{x:1544,y:934,t:1527268619262};\\\", \\\"{x:1544,y:935,t:1527268619279};\\\", \\\"{x:1544,y:936,t:1527268619304};\\\", \\\"{x:1544,y:937,t:1527268619352};\\\", \\\"{x:1543,y:937,t:1527268619448};\\\", \\\"{x:1539,y:937,t:1527268619462};\\\", \\\"{x:1532,y:934,t:1527268619480};\\\", \\\"{x:1526,y:931,t:1527268619497};\\\", \\\"{x:1516,y:927,t:1527268619514};\\\", \\\"{x:1510,y:923,t:1527268619530};\\\", \\\"{x:1503,y:920,t:1527268619547};\\\", \\\"{x:1501,y:919,t:1527268619564};\\\", \\\"{x:1501,y:918,t:1527268619580};\\\", \\\"{x:1500,y:918,t:1527268619632};\\\", \\\"{x:1499,y:918,t:1527268619655};\\\", \\\"{x:1498,y:918,t:1527268619745};\\\", \\\"{x:1497,y:920,t:1527268619776};\\\", \\\"{x:1496,y:920,t:1527268619783};\\\", \\\"{x:1495,y:921,t:1527268619798};\\\", \\\"{x:1492,y:926,t:1527268619815};\\\", \\\"{x:1487,y:934,t:1527268619831};\\\", \\\"{x:1482,y:938,t:1527268619848};\\\", \\\"{x:1479,y:940,t:1527268619864};\\\", \\\"{x:1477,y:942,t:1527268619882};\\\", \\\"{x:1476,y:943,t:1527268619898};\\\", \\\"{x:1476,y:944,t:1527268619936};\\\", \\\"{x:1475,y:945,t:1527268620223};\\\", \\\"{x:1474,y:942,t:1527268620247};\\\", \\\"{x:1474,y:939,t:1527268620255};\\\", \\\"{x:1474,y:937,t:1527268620267};\\\", \\\"{x:1474,y:931,t:1527268620283};\\\", \\\"{x:1474,y:926,t:1527268620299};\\\", \\\"{x:1474,y:918,t:1527268620316};\\\", \\\"{x:1474,y:911,t:1527268620333};\\\", \\\"{x:1474,y:906,t:1527268620350};\\\", \\\"{x:1474,y:900,t:1527268620367};\\\", \\\"{x:1474,y:889,t:1527268620383};\\\", \\\"{x:1474,y:884,t:1527268620401};\\\", \\\"{x:1474,y:882,t:1527268620417};\\\", \\\"{x:1474,y:877,t:1527268620433};\\\", \\\"{x:1474,y:870,t:1527268620451};\\\", \\\"{x:1474,y:866,t:1527268620468};\\\", \\\"{x:1474,y:862,t:1527268620484};\\\", \\\"{x:1474,y:858,t:1527268620501};\\\", \\\"{x:1474,y:856,t:1527268620518};\\\", \\\"{x:1474,y:854,t:1527268620535};\\\", \\\"{x:1474,y:851,t:1527268620551};\\\", \\\"{x:1474,y:848,t:1527268620567};\\\", \\\"{x:1474,y:846,t:1527268620585};\\\", \\\"{x:1474,y:843,t:1527268620602};\\\", \\\"{x:1474,y:841,t:1527268620619};\\\", \\\"{x:1474,y:838,t:1527268620635};\\\", \\\"{x:1474,y:836,t:1527268620651};\\\", \\\"{x:1474,y:835,t:1527268620669};\\\", \\\"{x:1474,y:834,t:1527268620685};\\\", \\\"{x:1474,y:833,t:1527268620702};\\\", \\\"{x:1474,y:832,t:1527268620718};\\\", \\\"{x:1474,y:831,t:1527268621280};\\\", \\\"{x:1475,y:831,t:1527268621376};\\\", \\\"{x:1476,y:831,t:1527268622849};\\\", \\\"{x:1477,y:831,t:1527268623814};\\\", \\\"{x:1478,y:831,t:1527268623909};\\\", \\\"{x:1479,y:831,t:1527268624029};\\\", \\\"{x:1480,y:831,t:1527268625365};\\\", \\\"{x:1482,y:833,t:1527268625389};\\\", \\\"{x:1483,y:833,t:1527268625412};\\\", \\\"{x:1484,y:833,t:1527268625421};\\\", \\\"{x:1484,y:834,t:1527268625469};\\\", \\\"{x:1482,y:834,t:1527268625669};\\\", \\\"{x:1476,y:834,t:1527268625678};\\\", \\\"{x:1466,y:834,t:1527268625689};\\\", \\\"{x:1445,y:826,t:1527268625705};\\\", \\\"{x:1425,y:815,t:1527268625722};\\\", \\\"{x:1318,y:757,t:1527268625741};\\\", \\\"{x:1264,y:727,t:1527268625755};\\\", \\\"{x:1145,y:672,t:1527268625772};\\\", \\\"{x:973,y:599,t:1527268625789};\\\", \\\"{x:881,y:567,t:1527268625806};\\\", \\\"{x:845,y:556,t:1527268625821};\\\", \\\"{x:837,y:554,t:1527268625839};\\\", \\\"{x:836,y:554,t:1527268625852};\\\", \\\"{x:836,y:556,t:1527268625956};\\\", \\\"{x:836,y:561,t:1527268625966};\\\", \\\"{x:833,y:574,t:1527268625983};\\\", \\\"{x:822,y:590,t:1527268625999};\\\", \\\"{x:802,y:611,t:1527268626018};\\\", \\\"{x:768,y:633,t:1527268626036};\\\", \\\"{x:731,y:652,t:1527268626052};\\\", \\\"{x:674,y:674,t:1527268626067};\\\", \\\"{x:582,y:699,t:1527268626085};\\\", \\\"{x:526,y:707,t:1527268626102};\\\", \\\"{x:473,y:715,t:1527268626118};\\\", \\\"{x:441,y:715,t:1527268626135};\\\", \\\"{x:425,y:715,t:1527268626152};\\\", \\\"{x:418,y:713,t:1527268626168};\\\", \\\"{x:413,y:709,t:1527268626185};\\\", \\\"{x:405,y:702,t:1527268626202};\\\", \\\"{x:392,y:692,t:1527268626218};\\\", \\\"{x:381,y:683,t:1527268626236};\\\", \\\"{x:369,y:670,t:1527268626253};\\\", \\\"{x:364,y:663,t:1527268626269};\\\", \\\"{x:357,y:654,t:1527268626285};\\\", \\\"{x:353,y:648,t:1527268626302};\\\", \\\"{x:351,y:645,t:1527268626318};\\\", \\\"{x:350,y:643,t:1527268626334};\\\", \\\"{x:350,y:642,t:1527268626352};\\\", \\\"{x:350,y:636,t:1527268626368};\\\", \\\"{x:350,y:631,t:1527268626384};\\\", \\\"{x:350,y:623,t:1527268626401};\\\", \\\"{x:351,y:610,t:1527268626419};\\\", \\\"{x:352,y:599,t:1527268626435};\\\", \\\"{x:352,y:593,t:1527268626452};\\\", \\\"{x:352,y:589,t:1527268626468};\\\", \\\"{x:350,y:587,t:1527268626486};\\\", \\\"{x:348,y:585,t:1527268626501};\\\", \\\"{x:347,y:585,t:1527268626540};\\\", \\\"{x:346,y:585,t:1527268626580};\\\", \\\"{x:345,y:585,t:1527268626588};\\\", \\\"{x:345,y:586,t:1527268626629};\\\", \\\"{x:345,y:587,t:1527268626636};\\\", \\\"{x:345,y:588,t:1527268626701};\\\", \\\"{x:345,y:589,t:1527268626708};\\\", \\\"{x:345,y:590,t:1527268626725};\\\", \\\"{x:345,y:591,t:1527268626740};\\\", \\\"{x:345,y:594,t:1527268626753};\\\", \\\"{x:338,y:599,t:1527268626770};\\\", \\\"{x:319,y:608,t:1527268626787};\\\", \\\"{x:298,y:615,t:1527268626803};\\\", \\\"{x:278,y:621,t:1527268626817};\\\", \\\"{x:265,y:626,t:1527268626834};\\\", \\\"{x:261,y:627,t:1527268626850};\\\", \\\"{x:263,y:627,t:1527268626972};\\\", \\\"{x:267,y:627,t:1527268626986};\\\", \\\"{x:283,y:625,t:1527268627004};\\\", \\\"{x:323,y:619,t:1527268627020};\\\", \\\"{x:355,y:617,t:1527268627036};\\\", \\\"{x:411,y:609,t:1527268627053};\\\", \\\"{x:465,y:605,t:1527268627069};\\\", \\\"{x:509,y:600,t:1527268627086};\\\", \\\"{x:541,y:595,t:1527268627103};\\\", \\\"{x:561,y:592,t:1527268627119};\\\", \\\"{x:571,y:591,t:1527268627136};\\\", \\\"{x:576,y:589,t:1527268627151};\\\", \\\"{x:579,y:589,t:1527268627168};\\\", \\\"{x:580,y:588,t:1527268627186};\\\", \\\"{x:581,y:587,t:1527268627202};\\\", \\\"{x:584,y:586,t:1527268627218};\\\", \\\"{x:593,y:580,t:1527268627236};\\\", \\\"{x:600,y:575,t:1527268627252};\\\", \\\"{x:612,y:570,t:1527268627269};\\\", \\\"{x:626,y:562,t:1527268627286};\\\", \\\"{x:637,y:555,t:1527268627302};\\\", \\\"{x:644,y:549,t:1527268627319};\\\", \\\"{x:646,y:546,t:1527268627335};\\\", \\\"{x:648,y:543,t:1527268627353};\\\", \\\"{x:650,y:541,t:1527268627369};\\\", \\\"{x:650,y:540,t:1527268627386};\\\", \\\"{x:651,y:539,t:1527268627402};\\\", \\\"{x:654,y:535,t:1527268627419};\\\", \\\"{x:655,y:534,t:1527268627436};\\\", \\\"{x:656,y:533,t:1527268627453};\\\", \\\"{x:657,y:533,t:1527268627476};\\\", \\\"{x:658,y:531,t:1527268627516};\\\", \\\"{x:659,y:530,t:1527268627532};\\\", \\\"{x:660,y:529,t:1527268627540};\\\", \\\"{x:661,y:528,t:1527268627553};\\\", \\\"{x:666,y:526,t:1527268627570};\\\", \\\"{x:676,y:522,t:1527268627586};\\\", \\\"{x:682,y:519,t:1527268627603};\\\", \\\"{x:694,y:517,t:1527268627619};\\\", \\\"{x:700,y:517,t:1527268627636};\\\", \\\"{x:709,y:517,t:1527268627653};\\\", \\\"{x:719,y:517,t:1527268627670};\\\", \\\"{x:730,y:517,t:1527268627686};\\\", \\\"{x:736,y:517,t:1527268627702};\\\", \\\"{x:744,y:517,t:1527268627719};\\\", \\\"{x:756,y:517,t:1527268627736};\\\", \\\"{x:763,y:517,t:1527268627753};\\\", \\\"{x:769,y:517,t:1527268627770};\\\", \\\"{x:774,y:517,t:1527268627786};\\\", \\\"{x:780,y:517,t:1527268627803};\\\", \\\"{x:785,y:517,t:1527268627820};\\\", \\\"{x:788,y:517,t:1527268627836};\\\", \\\"{x:791,y:517,t:1527268627853};\\\", \\\"{x:794,y:517,t:1527268627870};\\\", \\\"{x:796,y:518,t:1527268627886};\\\", \\\"{x:799,y:518,t:1527268627903};\\\", \\\"{x:801,y:519,t:1527268627920};\\\", \\\"{x:802,y:519,t:1527268627936};\\\", \\\"{x:803,y:519,t:1527268627956};\\\", \\\"{x:804,y:520,t:1527268628109};\\\", \\\"{x:804,y:521,t:1527268628133};\\\", \\\"{x:804,y:522,t:1527268628141};\\\", \\\"{x:804,y:523,t:1527268628153};\\\", \\\"{x:804,y:525,t:1527268628170};\\\", \\\"{x:803,y:527,t:1527268628187};\\\", \\\"{x:803,y:528,t:1527268628204};\\\", \\\"{x:800,y:532,t:1527268628222};\\\", \\\"{x:798,y:536,t:1527268628236};\\\", \\\"{x:796,y:539,t:1527268628253};\\\", \\\"{x:793,y:541,t:1527268628270};\\\", \\\"{x:790,y:544,t:1527268628286};\\\", \\\"{x:789,y:546,t:1527268628303};\\\", \\\"{x:787,y:546,t:1527268628319};\\\", \\\"{x:785,y:547,t:1527268628336};\\\", \\\"{x:782,y:549,t:1527268628353};\\\", \\\"{x:776,y:551,t:1527268628370};\\\", \\\"{x:772,y:553,t:1527268628387};\\\", \\\"{x:760,y:557,t:1527268628404};\\\", \\\"{x:752,y:558,t:1527268628420};\\\", \\\"{x:744,y:561,t:1527268628437};\\\", \\\"{x:734,y:563,t:1527268628453};\\\", \\\"{x:725,y:567,t:1527268628469};\\\", \\\"{x:716,y:568,t:1527268628488};\\\", \\\"{x:703,y:573,t:1527268628504};\\\", \\\"{x:691,y:575,t:1527268628519};\\\", \\\"{x:682,y:577,t:1527268628537};\\\", \\\"{x:676,y:581,t:1527268628553};\\\", \\\"{x:668,y:582,t:1527268628570};\\\", \\\"{x:659,y:585,t:1527268628587};\\\", \\\"{x:639,y:591,t:1527268628604};\\\", \\\"{x:623,y:596,t:1527268628620};\\\", \\\"{x:606,y:601,t:1527268628637};\\\", \\\"{x:585,y:605,t:1527268628654};\\\", \\\"{x:568,y:608,t:1527268628670};\\\", \\\"{x:553,y:612,t:1527268628687};\\\", \\\"{x:539,y:614,t:1527268628704};\\\", \\\"{x:529,y:616,t:1527268628721};\\\", \\\"{x:521,y:617,t:1527268628737};\\\", \\\"{x:519,y:617,t:1527268628754};\\\", \\\"{x:518,y:617,t:1527268628770};\\\", \\\"{x:518,y:616,t:1527268628885};\\\", \\\"{x:520,y:615,t:1527268628893};\\\", \\\"{x:522,y:613,t:1527268628905};\\\", \\\"{x:527,y:611,t:1527268628922};\\\", \\\"{x:532,y:608,t:1527268628937};\\\", \\\"{x:538,y:606,t:1527268628954};\\\", \\\"{x:540,y:605,t:1527268628970};\\\", \\\"{x:545,y:603,t:1527268628986};\\\", \\\"{x:549,y:602,t:1527268629004};\\\", \\\"{x:553,y:601,t:1527268629020};\\\", \\\"{x:557,y:598,t:1527268629037};\\\", \\\"{x:558,y:598,t:1527268629054};\\\", \\\"{x:564,y:596,t:1527268629071};\\\", \\\"{x:572,y:592,t:1527268629087};\\\", \\\"{x:575,y:592,t:1527268629104};\\\", \\\"{x:577,y:590,t:1527268629121};\\\", \\\"{x:579,y:590,t:1527268629137};\\\", \\\"{x:580,y:589,t:1527268629154};\\\", \\\"{x:582,y:589,t:1527268629171};\\\", \\\"{x:583,y:589,t:1527268629187};\\\", \\\"{x:584,y:589,t:1527268629261};\\\", \\\"{x:585,y:589,t:1527268629272};\\\", \\\"{x:586,y:589,t:1527268629293};\\\", \\\"{x:587,y:589,t:1527268629304};\\\", \\\"{x:588,y:589,t:1527268629333};\\\", \\\"{x:589,y:589,t:1527268629341};\\\", \\\"{x:590,y:589,t:1527268629363};\\\", \\\"{x:592,y:589,t:1527268629380};\\\", \\\"{x:593,y:589,t:1527268629396};\\\", \\\"{x:594,y:589,t:1527268629404};\\\", \\\"{x:595,y:589,t:1527268629443};\\\", \\\"{x:596,y:589,t:1527268629454};\\\", \\\"{x:597,y:589,t:1527268629471};\\\", \\\"{x:599,y:589,t:1527268629488};\\\", \\\"{x:600,y:589,t:1527268629509};\\\", \\\"{x:602,y:589,t:1527268629555};\\\", \\\"{x:603,y:589,t:1527268629572};\\\", \\\"{x:604,y:589,t:1527268629637};\\\", \\\"{x:604,y:590,t:1527268629652};\\\", \\\"{x:604,y:591,t:1527268629660};\\\", \\\"{x:604,y:592,t:1527268629670};\\\", \\\"{x:607,y:593,t:1527268629836};\\\", \\\"{x:618,y:593,t:1527268629844};\\\", \\\"{x:634,y:593,t:1527268629855};\\\", \\\"{x:701,y:593,t:1527268629871};\\\", \\\"{x:795,y:593,t:1527268629888};\\\", \\\"{x:909,y:593,t:1527268629905};\\\", \\\"{x:1052,y:606,t:1527268629921};\\\", \\\"{x:1180,y:627,t:1527268629938};\\\", \\\"{x:1290,y:639,t:1527268629955};\\\", \\\"{x:1371,y:654,t:1527268629971};\\\", \\\"{x:1448,y:665,t:1527268629988};\\\", \\\"{x:1478,y:668,t:1527268630005};\\\", \\\"{x:1502,y:673,t:1527268630022};\\\", \\\"{x:1525,y:676,t:1527268630038};\\\", \\\"{x:1544,y:680,t:1527268630055};\\\", \\\"{x:1554,y:681,t:1527268630072};\\\", \\\"{x:1560,y:683,t:1527268630088};\\\", \\\"{x:1562,y:684,t:1527268630105};\\\", \\\"{x:1564,y:684,t:1527268630122};\\\", \\\"{x:1565,y:684,t:1527268630181};\\\", \\\"{x:1566,y:686,t:1527268630188};\\\", \\\"{x:1566,y:694,t:1527268630205};\\\", \\\"{x:1566,y:705,t:1527268630222};\\\", \\\"{x:1563,y:719,t:1527268630239};\\\", \\\"{x:1551,y:737,t:1527268630255};\\\", \\\"{x:1534,y:750,t:1527268630272};\\\", \\\"{x:1513,y:761,t:1527268630289};\\\", \\\"{x:1497,y:770,t:1527268630306};\\\", \\\"{x:1486,y:775,t:1527268630322};\\\", \\\"{x:1476,y:781,t:1527268630341};\\\", \\\"{x:1472,y:784,t:1527268630356};\\\", \\\"{x:1467,y:788,t:1527268630373};\\\", \\\"{x:1466,y:790,t:1527268630389};\\\", \\\"{x:1463,y:794,t:1527268630406};\\\", \\\"{x:1463,y:795,t:1527268630423};\\\", \\\"{x:1462,y:798,t:1527268630439};\\\", \\\"{x:1460,y:801,t:1527268630456};\\\", \\\"{x:1460,y:803,t:1527268630472};\\\", \\\"{x:1459,y:806,t:1527268630489};\\\", \\\"{x:1459,y:809,t:1527268630507};\\\", \\\"{x:1459,y:814,t:1527268630523};\\\", \\\"{x:1459,y:818,t:1527268630540};\\\", \\\"{x:1460,y:822,t:1527268630557};\\\", \\\"{x:1461,y:827,t:1527268630572};\\\", \\\"{x:1461,y:832,t:1527268630590};\\\", \\\"{x:1461,y:836,t:1527268630607};\\\", \\\"{x:1462,y:839,t:1527268630624};\\\", \\\"{x:1462,y:841,t:1527268630640};\\\", \\\"{x:1462,y:843,t:1527268630657};\\\", \\\"{x:1463,y:843,t:1527268630674};\\\", \\\"{x:1464,y:843,t:1527268630981};\\\", \\\"{x:1465,y:843,t:1527268631037};\\\", \\\"{x:1466,y:843,t:1527268631053};\\\", \\\"{x:1467,y:842,t:1527268631077};\\\", \\\"{x:1467,y:841,t:1527268631101};\\\", \\\"{x:1468,y:840,t:1527268631125};\\\", \\\"{x:1469,y:839,t:1527268631141};\\\", \\\"{x:1470,y:838,t:1527268631165};\\\", \\\"{x:1470,y:837,t:1527268631189};\\\", \\\"{x:1471,y:835,t:1527268631237};\\\", \\\"{x:1471,y:834,t:1527268631334};\\\", \\\"{x:1472,y:834,t:1527268631438};\\\", \\\"{x:1473,y:833,t:1527268631628};\\\", \\\"{x:1473,y:832,t:1527268632414};\\\", \\\"{x:1473,y:831,t:1527268636805};\\\", \\\"{x:1474,y:831,t:1527268637285};\\\", \\\"{x:1475,y:831,t:1527268637317};\\\", \\\"{x:1476,y:831,t:1527268637342};\\\", \\\"{x:1477,y:831,t:1527268637388};\\\", \\\"{x:1479,y:831,t:1527268637404};\\\", \\\"{x:1481,y:831,t:1527268637429};\\\", \\\"{x:1482,y:831,t:1527268637453};\\\", \\\"{x:1483,y:831,t:1527268638677};\\\", \\\"{x:1486,y:832,t:1527268642973};\\\", \\\"{x:1489,y:832,t:1527268642984};\\\", \\\"{x:1499,y:838,t:1527268643001};\\\", \\\"{x:1504,y:855,t:1527268643017};\\\", \\\"{x:1505,y:873,t:1527268643035};\\\", \\\"{x:1505,y:890,t:1527268643050};\\\", \\\"{x:1505,y:899,t:1527268643068};\\\", \\\"{x:1505,y:900,t:1527268643084};\\\", \\\"{x:1506,y:901,t:1527268643189};\\\", \\\"{x:1507,y:901,t:1527268643365};\\\", \\\"{x:1509,y:898,t:1527268643373};\\\", \\\"{x:1509,y:896,t:1527268643384};\\\", \\\"{x:1513,y:891,t:1527268643402};\\\", \\\"{x:1518,y:884,t:1527268643419};\\\", \\\"{x:1521,y:878,t:1527268643434};\\\", \\\"{x:1524,y:871,t:1527268643451};\\\", \\\"{x:1524,y:868,t:1527268643468};\\\", \\\"{x:1524,y:859,t:1527268643484};\\\", \\\"{x:1524,y:856,t:1527268643501};\\\", \\\"{x:1524,y:853,t:1527268643518};\\\", \\\"{x:1524,y:851,t:1527268643535};\\\", \\\"{x:1523,y:849,t:1527268643551};\\\", \\\"{x:1523,y:847,t:1527268643568};\\\", \\\"{x:1523,y:846,t:1527268643585};\\\", \\\"{x:1522,y:844,t:1527268643601};\\\", \\\"{x:1521,y:843,t:1527268643620};\\\", \\\"{x:1520,y:842,t:1527268643636};\\\", \\\"{x:1519,y:841,t:1527268643661};\\\", \\\"{x:1518,y:841,t:1527268643677};\\\", \\\"{x:1517,y:841,t:1527268643685};\\\", \\\"{x:1511,y:839,t:1527268643702};\\\", \\\"{x:1503,y:836,t:1527268643718};\\\", \\\"{x:1497,y:834,t:1527268643735};\\\", \\\"{x:1493,y:833,t:1527268643752};\\\", \\\"{x:1491,y:832,t:1527268643768};\\\", \\\"{x:1490,y:832,t:1527268643786};\\\", \\\"{x:1488,y:832,t:1527268645853};\\\", \\\"{x:1487,y:832,t:1527268645973};\\\", \\\"{x:1485,y:832,t:1527268646005};\\\", \\\"{x:1484,y:830,t:1527268646023};\\\", \\\"{x:1482,y:830,t:1527268646069};\\\", \\\"{x:1482,y:829,t:1527268646077};\\\", \\\"{x:1481,y:829,t:1527268646100};\\\", \\\"{x:1480,y:829,t:1527268646125};\\\", \\\"{x:1479,y:828,t:1527268646396};\\\", \\\"{x:1477,y:826,t:1527268646406};\\\", \\\"{x:1474,y:826,t:1527268646424};\\\", \\\"{x:1466,y:823,t:1527268646441};\\\", \\\"{x:1450,y:821,t:1527268646458};\\\", \\\"{x:1432,y:818,t:1527268646474};\\\", \\\"{x:1414,y:818,t:1527268646491};\\\", \\\"{x:1387,y:818,t:1527268646507};\\\", \\\"{x:1369,y:818,t:1527268646524};\\\", \\\"{x:1352,y:818,t:1527268646541};\\\", \\\"{x:1338,y:818,t:1527268646558};\\\", \\\"{x:1328,y:818,t:1527268646574};\\\", \\\"{x:1321,y:818,t:1527268646591};\\\", \\\"{x:1316,y:818,t:1527268646608};\\\", \\\"{x:1311,y:818,t:1527268646624};\\\", \\\"{x:1305,y:818,t:1527268646641};\\\", \\\"{x:1303,y:818,t:1527268646658};\\\", \\\"{x:1302,y:818,t:1527268646675};\\\", \\\"{x:1301,y:818,t:1527268646716};\\\", \\\"{x:1300,y:817,t:1527268646757};\\\", \\\"{x:1299,y:817,t:1527268646789};\\\", \\\"{x:1298,y:817,t:1527268646796};\\\", \\\"{x:1296,y:817,t:1527268646845};\\\", \\\"{x:1295,y:816,t:1527268646858};\\\", \\\"{x:1291,y:815,t:1527268646875};\\\", \\\"{x:1288,y:814,t:1527268646893};\\\", \\\"{x:1285,y:813,t:1527268646909};\\\", \\\"{x:1283,y:812,t:1527268646925};\\\", \\\"{x:1280,y:812,t:1527268646942};\\\", \\\"{x:1277,y:810,t:1527268646960};\\\", \\\"{x:1274,y:809,t:1527268646975};\\\", \\\"{x:1266,y:805,t:1527268646992};\\\", \\\"{x:1254,y:800,t:1527268647009};\\\", \\\"{x:1247,y:800,t:1527268647025};\\\", \\\"{x:1235,y:796,t:1527268647043};\\\", \\\"{x:1223,y:792,t:1527268647059};\\\", \\\"{x:1213,y:788,t:1527268647077};\\\", \\\"{x:1211,y:788,t:1527268647093};\\\", \\\"{x:1209,y:788,t:1527268647116};\\\", \\\"{x:1208,y:787,t:1527268647157};\\\", \\\"{x:1207,y:787,t:1527268647862};\\\", \\\"{x:1207,y:786,t:1527268647885};\\\", \\\"{x:1207,y:785,t:1527268647924};\\\", \\\"{x:1206,y:785,t:1527268647932};\\\", \\\"{x:1206,y:784,t:1527268647947};\\\", \\\"{x:1204,y:783,t:1527268647961};\\\", \\\"{x:1204,y:781,t:1527268647977};\\\", \\\"{x:1202,y:779,t:1527268647994};\\\", \\\"{x:1201,y:778,t:1527268648011};\\\", \\\"{x:1201,y:776,t:1527268648036};\\\", \\\"{x:1201,y:775,t:1527268648156};\\\", \\\"{x:1201,y:773,t:1527268648228};\\\", \\\"{x:1202,y:773,t:1527268648798};\\\", \\\"{x:1205,y:773,t:1527268649701};\\\", \\\"{x:1205,y:774,t:1527268649797};\\\", \\\"{x:1206,y:774,t:1527268649837};\\\", \\\"{x:1207,y:774,t:1527268649848};\\\", \\\"{x:1208,y:774,t:1527268649868};\\\", \\\"{x:1209,y:775,t:1527268649925};\\\", \\\"{x:1210,y:775,t:1527268650021};\\\", \\\"{x:1211,y:775,t:1527268650069};\\\", \\\"{x:1212,y:775,t:1527268650125};\\\", \\\"{x:1213,y:775,t:1527268650133};\\\", \\\"{x:1214,y:776,t:1527268650149};\\\", \\\"{x:1217,y:776,t:1527268650165};\\\", \\\"{x:1219,y:776,t:1527268650212};\\\", \\\"{x:1220,y:775,t:1527268650260};\\\", \\\"{x:1221,y:775,t:1527268650413};\\\", \\\"{x:1222,y:775,t:1527268650429};\\\", \\\"{x:1223,y:775,t:1527268650445};\\\", \\\"{x:1225,y:774,t:1527268650453};\\\", \\\"{x:1226,y:774,t:1527268650469};\\\", \\\"{x:1227,y:774,t:1527268650484};\\\", \\\"{x:1229,y:774,t:1527268650509};\\\", \\\"{x:1231,y:772,t:1527268650516};\\\", \\\"{x:1240,y:769,t:1527268650534};\\\", \\\"{x:1254,y:766,t:1527268650550};\\\", \\\"{x:1271,y:764,t:1527268650567};\\\", \\\"{x:1290,y:764,t:1527268650584};\\\", \\\"{x:1308,y:763,t:1527268650601};\\\", \\\"{x:1322,y:761,t:1527268650617};\\\", \\\"{x:1336,y:761,t:1527268650634};\\\", \\\"{x:1343,y:761,t:1527268650651};\\\", \\\"{x:1346,y:761,t:1527268650667};\\\", \\\"{x:1348,y:760,t:1527268650683};\\\", \\\"{x:1351,y:760,t:1527268650700};\\\", \\\"{x:1352,y:760,t:1527268650725};\\\", \\\"{x:1353,y:760,t:1527268650750};\\\", \\\"{x:1354,y:760,t:1527268650781};\\\", \\\"{x:1355,y:760,t:1527268650796};\\\", \\\"{x:1356,y:760,t:1527268650805};\\\", \\\"{x:1360,y:760,t:1527268650821};\\\", \\\"{x:1363,y:760,t:1527268650834};\\\", \\\"{x:1369,y:760,t:1527268650850};\\\", \\\"{x:1377,y:760,t:1527268650868};\\\", \\\"{x:1383,y:760,t:1527268650885};\\\", \\\"{x:1384,y:760,t:1527268650901};\\\", \\\"{x:1384,y:761,t:1527268654661};\\\", \\\"{x:1384,y:762,t:1527268654685};\\\", \\\"{x:1384,y:765,t:1527268654693};\\\", \\\"{x:1383,y:768,t:1527268654709};\\\", \\\"{x:1383,y:772,t:1527268654726};\\\", \\\"{x:1382,y:778,t:1527268654743};\\\", \\\"{x:1378,y:791,t:1527268654760};\\\", \\\"{x:1372,y:802,t:1527268654775};\\\", \\\"{x:1370,y:810,t:1527268654793};\\\", \\\"{x:1367,y:816,t:1527268654809};\\\", \\\"{x:1366,y:822,t:1527268654826};\\\", \\\"{x:1364,y:828,t:1527268654843};\\\", \\\"{x:1363,y:836,t:1527268654860};\\\", \\\"{x:1363,y:842,t:1527268654875};\\\", \\\"{x:1361,y:860,t:1527268654892};\\\", \\\"{x:1361,y:877,t:1527268654910};\\\", \\\"{x:1360,y:889,t:1527268654927};\\\", \\\"{x:1359,y:901,t:1527268654943};\\\", \\\"{x:1359,y:913,t:1527268654960};\\\", \\\"{x:1359,y:927,t:1527268654977};\\\", \\\"{x:1359,y:938,t:1527268654993};\\\", \\\"{x:1359,y:945,t:1527268655009};\\\", \\\"{x:1359,y:950,t:1527268655027};\\\", \\\"{x:1359,y:951,t:1527268655042};\\\", \\\"{x:1359,y:952,t:1527268655059};\\\", \\\"{x:1359,y:953,t:1527268655076};\\\", \\\"{x:1359,y:954,t:1527268655117};\\\", \\\"{x:1360,y:954,t:1527268655294};\\\", \\\"{x:1361,y:955,t:1527268655310};\\\", \\\"{x:1363,y:957,t:1527268655327};\\\", \\\"{x:1364,y:960,t:1527268655344};\\\", \\\"{x:1366,y:963,t:1527268655360};\\\", \\\"{x:1367,y:963,t:1527268655377};\\\", \\\"{x:1368,y:966,t:1527268655394};\\\", \\\"{x:1368,y:968,t:1527268655410};\\\", \\\"{x:1368,y:969,t:1527268655427};\\\", \\\"{x:1368,y:971,t:1527268655443};\\\", \\\"{x:1369,y:972,t:1527268655460};\\\", \\\"{x:1369,y:970,t:1527268655725};\\\", \\\"{x:1369,y:969,t:1527268655733};\\\", \\\"{x:1369,y:968,t:1527268655749};\\\", \\\"{x:1369,y:967,t:1527268655765};\\\", \\\"{x:1369,y:966,t:1527268655777};\\\", \\\"{x:1369,y:965,t:1527268655795};\\\", \\\"{x:1369,y:962,t:1527268655812};\\\", \\\"{x:1369,y:958,t:1527268655828};\\\", \\\"{x:1369,y:956,t:1527268655845};\\\", \\\"{x:1369,y:952,t:1527268655861};\\\", \\\"{x:1369,y:948,t:1527268655878};\\\", \\\"{x:1369,y:940,t:1527268655895};\\\", \\\"{x:1368,y:932,t:1527268655912};\\\", \\\"{x:1366,y:924,t:1527268655929};\\\", \\\"{x:1365,y:919,t:1527268655945};\\\", \\\"{x:1364,y:913,t:1527268655961};\\\", \\\"{x:1363,y:911,t:1527268655978};\\\", \\\"{x:1363,y:910,t:1527268655995};\\\", \\\"{x:1362,y:908,t:1527268656011};\\\", \\\"{x:1362,y:906,t:1527268656029};\\\", \\\"{x:1362,y:905,t:1527268656045};\\\", \\\"{x:1362,y:904,t:1527268656062};\\\", \\\"{x:1362,y:903,t:1527268656078};\\\", \\\"{x:1362,y:902,t:1527268656096};\\\", \\\"{x:1362,y:901,t:1527268656112};\\\", \\\"{x:1363,y:900,t:1527268656261};\\\", \\\"{x:1364,y:900,t:1527268656277};\\\", \\\"{x:1365,y:900,t:1527268656285};\\\", \\\"{x:1366,y:900,t:1527268656309};\\\", \\\"{x:1367,y:900,t:1527268656348};\\\", \\\"{x:1368,y:900,t:1527268656362};\\\", \\\"{x:1374,y:900,t:1527268656379};\\\", \\\"{x:1383,y:900,t:1527268656395};\\\", \\\"{x:1423,y:900,t:1527268656412};\\\", \\\"{x:1448,y:901,t:1527268656429};\\\", \\\"{x:1468,y:903,t:1527268656445};\\\", \\\"{x:1479,y:906,t:1527268656462};\\\", \\\"{x:1485,y:906,t:1527268656479};\\\", \\\"{x:1484,y:906,t:1527268657037};\\\", \\\"{x:1483,y:905,t:1527268657048};\\\", \\\"{x:1480,y:905,t:1527268657069};\\\", \\\"{x:1479,y:905,t:1527268657081};\\\", \\\"{x:1469,y:901,t:1527268657098};\\\", \\\"{x:1457,y:899,t:1527268657114};\\\", \\\"{x:1449,y:897,t:1527268657131};\\\", \\\"{x:1441,y:896,t:1527268657148};\\\", \\\"{x:1419,y:895,t:1527268657164};\\\", \\\"{x:1402,y:893,t:1527268657180};\\\", \\\"{x:1388,y:891,t:1527268657198};\\\", \\\"{x:1382,y:891,t:1527268657215};\\\", \\\"{x:1380,y:890,t:1527268657231};\\\", \\\"{x:1381,y:890,t:1527268657397};\\\", \\\"{x:1384,y:890,t:1527268657412};\\\", \\\"{x:1386,y:890,t:1527268657421};\\\", \\\"{x:1388,y:890,t:1527268657431};\\\", \\\"{x:1392,y:891,t:1527268657449};\\\", \\\"{x:1399,y:893,t:1527268657465};\\\", \\\"{x:1402,y:894,t:1527268657482};\\\", \\\"{x:1411,y:897,t:1527268657498};\\\", \\\"{x:1416,y:898,t:1527268657515};\\\", \\\"{x:1419,y:899,t:1527268657532};\\\", \\\"{x:1426,y:901,t:1527268657548};\\\", \\\"{x:1429,y:901,t:1527268657565};\\\", \\\"{x:1431,y:903,t:1527268657581};\\\", \\\"{x:1432,y:903,t:1527268657599};\\\", \\\"{x:1433,y:903,t:1527268657643};\\\", \\\"{x:1435,y:903,t:1527268657853};\\\", \\\"{x:1438,y:901,t:1527268657865};\\\", \\\"{x:1439,y:898,t:1527268657883};\\\", \\\"{x:1440,y:897,t:1527268657900};\\\", \\\"{x:1441,y:896,t:1527268657916};\\\", \\\"{x:1441,y:895,t:1527268657934};\\\", \\\"{x:1441,y:894,t:1527268657956};\\\", \\\"{x:1441,y:893,t:1527268657997};\\\", \\\"{x:1442,y:893,t:1527268658004};\\\", \\\"{x:1443,y:893,t:1527268658325};\\\", \\\"{x:1444,y:893,t:1527268658701};\\\", \\\"{x:1445,y:893,t:1527268659133};\\\", \\\"{x:1446,y:893,t:1527268659149};\\\", \\\"{x:1447,y:893,t:1527268659157};\\\", \\\"{x:1448,y:893,t:1527268659181};\\\", \\\"{x:1449,y:894,t:1527268659221};\\\", \\\"{x:1450,y:894,t:1527268659285};\\\", \\\"{x:1451,y:894,t:1527268659342};\\\", \\\"{x:1449,y:896,t:1527268659661};\\\", \\\"{x:1441,y:900,t:1527268659671};\\\", \\\"{x:1435,y:903,t:1527268659687};\\\", \\\"{x:1435,y:904,t:1527268659703};\\\", \\\"{x:1433,y:904,t:1527268659720};\\\", \\\"{x:1432,y:904,t:1527268659737};\\\", \\\"{x:1431,y:904,t:1527268659754};\\\", \\\"{x:1430,y:904,t:1527268659869};\\\", \\\"{x:1428,y:901,t:1527268659887};\\\", \\\"{x:1428,y:894,t:1527268659904};\\\", \\\"{x:1428,y:885,t:1527268659921};\\\", \\\"{x:1428,y:875,t:1527268659937};\\\", \\\"{x:1428,y:864,t:1527268659953};\\\", \\\"{x:1428,y:849,t:1527268659970};\\\", \\\"{x:1428,y:837,t:1527268659986};\\\", \\\"{x:1428,y:808,t:1527268660003};\\\", \\\"{x:1428,y:790,t:1527268660020};\\\", \\\"{x:1428,y:774,t:1527268660037};\\\", \\\"{x:1430,y:760,t:1527268660053};\\\", \\\"{x:1434,y:744,t:1527268660071};\\\", \\\"{x:1439,y:731,t:1527268660088};\\\", \\\"{x:1443,y:718,t:1527268660103};\\\", \\\"{x:1445,y:709,t:1527268660120};\\\", \\\"{x:1447,y:702,t:1527268660137};\\\", \\\"{x:1450,y:696,t:1527268660154};\\\", \\\"{x:1452,y:692,t:1527268660171};\\\", \\\"{x:1453,y:688,t:1527268660188};\\\", \\\"{x:1453,y:687,t:1527268660203};\\\", \\\"{x:1455,y:685,t:1527268660221};\\\", \\\"{x:1455,y:684,t:1527268660238};\\\", \\\"{x:1455,y:682,t:1527268660255};\\\", \\\"{x:1456,y:680,t:1527268660271};\\\", \\\"{x:1456,y:677,t:1527268660288};\\\", \\\"{x:1459,y:673,t:1527268660305};\\\", \\\"{x:1460,y:667,t:1527268660320};\\\", \\\"{x:1462,y:662,t:1527268660338};\\\", \\\"{x:1462,y:657,t:1527268660355};\\\", \\\"{x:1462,y:652,t:1527268660372};\\\", \\\"{x:1462,y:649,t:1527268660388};\\\", \\\"{x:1462,y:645,t:1527268660405};\\\", \\\"{x:1462,y:644,t:1527268660422};\\\", \\\"{x:1462,y:642,t:1527268660444};\\\", \\\"{x:1462,y:641,t:1527268660549};\\\", \\\"{x:1461,y:641,t:1527268660580};\\\", \\\"{x:1461,y:639,t:1527268660604};\\\", \\\"{x:1460,y:639,t:1527268660619};\\\", \\\"{x:1460,y:638,t:1527268660628};\\\", \\\"{x:1459,y:638,t:1527268660708};\\\", \\\"{x:1458,y:638,t:1527268660724};\\\", \\\"{x:1457,y:638,t:1527268660740};\\\", \\\"{x:1456,y:638,t:1527268660755};\\\", \\\"{x:1454,y:637,t:1527268660771};\\\", \\\"{x:1452,y:636,t:1527268660788};\\\", \\\"{x:1451,y:636,t:1527268660806};\\\", \\\"{x:1450,y:636,t:1527268660822};\\\", \\\"{x:1449,y:636,t:1527268660844};\\\", \\\"{x:1448,y:636,t:1527268660856};\\\", \\\"{x:1445,y:636,t:1527268660873};\\\", \\\"{x:1441,y:636,t:1527268660889};\\\", \\\"{x:1440,y:636,t:1527268660906};\\\", \\\"{x:1438,y:638,t:1527268660922};\\\", \\\"{x:1437,y:639,t:1527268660939};\\\", \\\"{x:1436,y:640,t:1527268661045};\\\", \\\"{x:1434,y:640,t:1527268661056};\\\", \\\"{x:1434,y:641,t:1527268661073};\\\", \\\"{x:1433,y:642,t:1527268661090};\\\", \\\"{x:1431,y:642,t:1527268661106};\\\", \\\"{x:1430,y:642,t:1527268661123};\\\", \\\"{x:1425,y:643,t:1527268661141};\\\", \\\"{x:1423,y:644,t:1527268661156};\\\", \\\"{x:1418,y:644,t:1527268661173};\\\", \\\"{x:1416,y:644,t:1527268661190};\\\", \\\"{x:1414,y:644,t:1527268661207};\\\", \\\"{x:1411,y:644,t:1527268661223};\\\", \\\"{x:1409,y:642,t:1527268661240};\\\", \\\"{x:1406,y:640,t:1527268661257};\\\", \\\"{x:1404,y:637,t:1527268661273};\\\", \\\"{x:1403,y:635,t:1527268661290};\\\", \\\"{x:1402,y:632,t:1527268661307};\\\", \\\"{x:1399,y:627,t:1527268661324};\\\", \\\"{x:1399,y:623,t:1527268661341};\\\", \\\"{x:1397,y:617,t:1527268661357};\\\", \\\"{x:1396,y:614,t:1527268661374};\\\", \\\"{x:1396,y:612,t:1527268661390};\\\", \\\"{x:1396,y:609,t:1527268661407};\\\", \\\"{x:1396,y:605,t:1527268661424};\\\", \\\"{x:1396,y:602,t:1527268661440};\\\", \\\"{x:1396,y:600,t:1527268661458};\\\", \\\"{x:1396,y:599,t:1527268661474};\\\", \\\"{x:1396,y:597,t:1527268661491};\\\", \\\"{x:1396,y:594,t:1527268661507};\\\", \\\"{x:1399,y:589,t:1527268661524};\\\", \\\"{x:1402,y:585,t:1527268661541};\\\", \\\"{x:1405,y:579,t:1527268661557};\\\", \\\"{x:1408,y:576,t:1527268661574};\\\", \\\"{x:1408,y:575,t:1527268661591};\\\", \\\"{x:1409,y:575,t:1527268661607};\\\", \\\"{x:1410,y:575,t:1527268661877};\\\", \\\"{x:1411,y:577,t:1527268661917};\\\", \\\"{x:1411,y:578,t:1527268661924};\\\", \\\"{x:1412,y:580,t:1527268661942};\\\", \\\"{x:1412,y:581,t:1527268661958};\\\", \\\"{x:1412,y:584,t:1527268661975};\\\", \\\"{x:1413,y:586,t:1527268661991};\\\", \\\"{x:1414,y:590,t:1527268662007};\\\", \\\"{x:1415,y:594,t:1527268662025};\\\", \\\"{x:1418,y:599,t:1527268662041};\\\", \\\"{x:1418,y:602,t:1527268662058};\\\", \\\"{x:1419,y:605,t:1527268662075};\\\", \\\"{x:1421,y:610,t:1527268662091};\\\", \\\"{x:1421,y:612,t:1527268662108};\\\", \\\"{x:1421,y:613,t:1527268662124};\\\", \\\"{x:1421,y:615,t:1527268662309};\\\", \\\"{x:1421,y:616,t:1527268662326};\\\", \\\"{x:1420,y:619,t:1527268662342};\\\", \\\"{x:1416,y:620,t:1527268662359};\\\", \\\"{x:1411,y:623,t:1527268662375};\\\", \\\"{x:1405,y:625,t:1527268662392};\\\", \\\"{x:1395,y:630,t:1527268662408};\\\", \\\"{x:1387,y:636,t:1527268662426};\\\", \\\"{x:1382,y:638,t:1527268662442};\\\", \\\"{x:1374,y:643,t:1527268662459};\\\", \\\"{x:1355,y:653,t:1527268662476};\\\", \\\"{x:1344,y:657,t:1527268662492};\\\", \\\"{x:1334,y:661,t:1527268662509};\\\", \\\"{x:1327,y:662,t:1527268662525};\\\", \\\"{x:1323,y:662,t:1527268662543};\\\", \\\"{x:1316,y:662,t:1527268662560};\\\", \\\"{x:1279,y:662,t:1527268662575};\\\", \\\"{x:1187,y:662,t:1527268662592};\\\", \\\"{x:1052,y:662,t:1527268662609};\\\", \\\"{x:879,y:675,t:1527268662626};\\\", \\\"{x:729,y:697,t:1527268662642};\\\", \\\"{x:626,y:701,t:1527268662659};\\\", \\\"{x:600,y:701,t:1527268662675};\\\", \\\"{x:583,y:701,t:1527268662693};\\\", \\\"{x:568,y:704,t:1527268662709};\\\", \\\"{x:553,y:709,t:1527268662727};\\\", \\\"{x:544,y:714,t:1527268662743};\\\", \\\"{x:533,y:719,t:1527268662760};\\\", \\\"{x:524,y:723,t:1527268662777};\\\", \\\"{x:516,y:726,t:1527268662793};\\\", \\\"{x:508,y:731,t:1527268662810};\\\", \\\"{x:498,y:732,t:1527268662827};\\\", \\\"{x:484,y:740,t:1527268662843};\\\", \\\"{x:466,y:751,t:1527268662859};\\\", \\\"{x:459,y:755,t:1527268662876};\\\", \\\"{x:458,y:756,t:1527268662894};\\\", \\\"{x:459,y:756,t:1527268663077};\\\", \\\"{x:460,y:756,t:1527268663085};\\\", \\\"{x:462,y:756,t:1527268663100};\\\", \\\"{x:463,y:756,t:1527268663112};\\\", \\\"{x:466,y:756,t:1527268663128};\\\", \\\"{x:469,y:756,t:1527268663145};\\\", \\\"{x:470,y:756,t:1527268663180};\\\", \\\"{x:471,y:756,t:1527268663245};\\\" ] }, { \\\"rt\\\": 36420, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 737124, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at 12pm and what is above are the events start at 12pm\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9782, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 747918, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 24023, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 772961, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 68801, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 843089, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"3A2HT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"3A2HT\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 324, dom: 1094, initialDom: 1158",
  "javascriptErrors": []
}