var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a9f045037046e036e09074d2701cfaf2",
  "created": "2018-06-01T10:14:23.3174568-07:00",
  "lastActivity": "2018-06-01T10:15:16.9296062-07:00",
  "pageViews": [
    {
      "id": "0601234811f69189cb9e3e149619b9a29b6d2e30",
      "startTime": "2018-06-01T10:14:23.5946062-07:00",
      "endTime": "2018-06-01T10:15:16.9296062-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 53335,
      "engagementTime": 38332,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 53335,
  "engagementTime": 38332,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1Z2H9",
    "CONDITION=115",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "cb62d3e0a13149e99a182b7e511af2eb",
  "gdpr": false
}