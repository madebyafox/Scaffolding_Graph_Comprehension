var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d4d1822e39c717e0a7225b880b0092b8",
  "created": "2018-05-22T14:01:54.5639183-07:00",
  "lastActivity": "2018-05-22T14:07:49.1885186-07:00",
  "pageViews": [
    {
      "id": "0522542774b4ae86d00e0f7fd7f18da9c71b2db6",
      "startTime": "2018-05-22T14:01:54.5639183-07:00",
      "endTime": "2018-05-22T14:07:49.1885186-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 354787,
      "engagementTime": 59548,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 354787,
  "engagementTime": 59548,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e17e51948cc450676149512262c2af82",
  "gdpr": false
}