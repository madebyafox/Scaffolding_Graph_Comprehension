var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "199653918d27db5fed72183cbf05ffee",
  "created": "2018-05-21T12:13:21.6355807-07:00",
  "lastActivity": "2018-05-21T12:13:39.6085807-07:00",
  "pageViews": [
    {
      "id": "0521217485275e33eab9e3a8b3e27babe763403a",
      "startTime": "2018-05-21T12:13:21.6355807-07:00",
      "endTime": "2018-05-21T12:13:39.6085807-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 17973,
      "engagementTime": 17923,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17973,
  "engagementTime": 17923,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WKBNA",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "85516a714eb84e78dc847c7f5fed4448",
  "gdpr": false
}