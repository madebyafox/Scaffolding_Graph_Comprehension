var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "65b027ab530b3112d73003493999809e",
  "created": "2018-05-21T12:15:55.935876-07:00",
  "lastActivity": "2018-05-21T12:16:16.3195042-07:00",
  "pageViews": [
    {
      "id": "052156109b82655a57ced92ba52421b89c424bab",
      "startTime": "2018-05-21T12:15:56.2936501-07:00",
      "endTime": "2018-05-21T12:16:16.3195042-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 20288,
      "engagementTime": 12987,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20288,
  "engagementTime": 12987,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=A9CZD",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "35a489faa7f66628a6821f2ac1b3907d",
  "gdpr": false
}