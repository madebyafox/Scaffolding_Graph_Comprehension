var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "22fc634f6ee13037ff193a2f067e6630",
  "created": "2018-06-01T11:16:08.0005275-07:00",
  "lastActivity": "2018-06-01T11:16:20.4125275-07:00",
  "pageViews": [
    {
      "id": "06010862e2e9f9282cf9ac13fbf43ba78d3a695e",
      "startTime": "2018-06-01T11:16:08.0005275-07:00",
      "endTime": "2018-06-01T11:16:20.4125275-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 12412,
      "engagementTime": 12412,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12412,
  "engagementTime": 12412,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKY5H",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5bfcf2dcbff217b12a40e8f6a4ced3f3",
  "gdpr": false
}