var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "718f8063ac7f6f5863b427dd0a2fefd0",
  "created": "2018-05-25T10:05:56.4361785-07:00",
  "lastActivity": "2018-05-25T10:08:17.901605-07:00",
  "pageViews": [
    {
      "id": "05255694f0834f75cc1f52ae3f2535478b8fb29d",
      "startTime": "2018-05-25T10:05:56.4361785-07:00",
      "endTime": "2018-05-25T10:08:17.901605-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 141667,
      "engagementTime": 47343,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 141667,
  "engagementTime": 47343,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "55d5145b877bdadb27928bdf7cfdaa1e",
  "gdpr": false
}