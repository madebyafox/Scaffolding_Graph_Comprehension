var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05293537b14ad19732e61188a2d8a70f3d1765d9"] = {
  "startTime": "2018-05-29T18:53:35.4185377Z",
  "websitePageUrl": "/",
  "visitTime": 21966,
  "engagementTime": 19501,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [],
  "session": {
    "id": "9b26e58a78160d9c739ae1ccddc4432a",
    "created": "2018-05-29T18:53:34.898293+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "61aa6e9abe8179934ba5984df3b6af89",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/9b26e58a78160d9c739ae1ccddc4432a/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 250,
      "e": 250,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1253,
      "e": 1253,
      "ty": 41,
      "x": 49724,
      "y": 11919,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 1264,
      "y": 295
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 1260,
      "y": 298
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 1258,
      "y": 301
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 49069,
      "y": 12656,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3602,
      "e": 3602,
      "ty": 2,
      "x": 1219,
      "y": 434
    },
    {
      "t": 3676,
      "e": 3676,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3702,
      "e": 3702,
      "ty": 2,
      "x": 906,
      "y": 1087
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 687,
      "y": 968
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 23383,
      "y": 58415,
      "ta": "html > body"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 705,
      "y": 915
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 724,
      "y": 885
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 21817,
      "y": 56810,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 777,
      "y": 810
    },
    {
      "t": 4402,
      "e": 4402,
      "ty": 2,
      "x": 780,
      "y": 805
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 784,
      "y": 802
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 23183,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4541,
      "e": 4541,
      "ty": 3,
      "x": 784,
      "y": 802,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4652,
      "e": 4652,
      "ty": 4,
      "x": 23183,
      "y": 53697,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4653,
      "e": 4653,
      "ty": 5,
      "x": 784,
      "y": 802,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 831,
      "y": 772
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 935,
      "y": 650
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 32794,
      "y": 37641,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8302,
      "e": 8302,
      "ty": 2,
      "x": 983,
      "y": 536
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 879,
      "y": 316
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 853,
      "y": 300
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 26951,
      "y": 12574,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 844,
      "y": 380
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 828,
      "y": 478
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 25531,
      "y": 28384,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 827,
      "y": 495
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 3,
      "x": 827,
      "y": 497,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 827,
      "y": 497
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 25531,
      "y": 28712,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9019,
      "e": 9019,
      "ty": 4,
      "x": 25531,
      "y": 28712,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9019,
      "e": 9019,
      "ty": 5,
      "x": 827,
      "y": 497,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9701,
      "e": 9701,
      "ty": 2,
      "x": 834,
      "y": 448
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 26350,
      "y": 19701,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9801,
      "e": 9801,
      "ty": 2,
      "x": 857,
      "y": 322
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 861,
      "y": 307
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 41,
      "x": 27388,
      "y": 13147,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10401,
      "e": 10401,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 2,
      "x": 858,
      "y": 293
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 41,
      "x": 27224,
      "y": 12001,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10601,
      "e": 10601,
      "ty": 2,
      "x": 830,
      "y": 133
    },
    {
      "t": 10601,
      "e": 10601,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 10700,
      "e": 10700,
      "ty": 2,
      "x": 814,
      "y": 33
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 27722,
      "y": 973,
      "ta": "html > body"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 813,
      "y": 24
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 2,
      "x": 810,
      "y": 7
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 27894,
      "y": 425,
      "ta": "html"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 2,
      "x": 806,
      "y": 8
    },
    {
      "t": 11201,
      "e": 11201,
      "ty": 2,
      "x": 805,
      "y": 8
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 27343,
      "y": 730,
      "ta": "html > body"
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 2,
      "x": 796,
      "y": 58
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 789,
      "y": 87
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 789,
      "y": 109
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 41,
      "x": 26895,
      "y": 6145,
      "ta": "html > body"
    },
    {
      "t": 11601,
      "e": 11601,
      "ty": 2,
      "x": 916,
      "y": 425
    },
    {
      "t": 11701,
      "e": 11701,
      "ty": 2,
      "x": 1019,
      "y": 1008
    },
    {
      "t": 11716,
      "e": 11716,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 35298,
      "y": 65534,
      "ta": "html"
    },
    {
      "t": 11800,
      "e": 11800,
      "ty": 2,
      "x": 1025,
      "y": 1090
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 2,
      "x": 1020,
      "y": 1053
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 34850,
      "y": 63587,
      "ta": "html > body"
    },
    {
      "t": 12101,
      "e": 12101,
      "ty": 2,
      "x": 1001,
      "y": 982
    },
    {
      "t": 12201,
      "e": 12201,
      "ty": 2,
      "x": 987,
      "y": 950
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 32794,
      "y": 61889,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12301,
      "e": 12301,
      "ty": 2,
      "x": 938,
      "y": 852
    },
    {
      "t": 12400,
      "e": 12400,
      "ty": 2,
      "x": 918,
      "y": 807
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 2,
      "x": 918,
      "y": 806
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 41,
      "x": 30501,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12556,
      "e": 12556,
      "ty": 3,
      "x": 918,
      "y": 806,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12756,
      "e": 12756,
      "ty": 4,
      "x": 30501,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12756,
      "e": 12756,
      "ty": 5,
      "x": 918,
      "y": 806,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12901,
      "e": 12901,
      "ty": 2,
      "x": 914,
      "y": 842
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 2,
      "x": 899,
      "y": 905
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 41,
      "x": 29463,
      "y": 62135,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 2,
      "x": 898,
      "y": 908
    },
    {
      "t": 13201,
      "e": 13201,
      "ty": 2,
      "x": 878,
      "y": 868
    },
    {
      "t": 13251,
      "e": 13251,
      "ty": 41,
      "x": 25913,
      "y": 54353,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13301,
      "e": 13301,
      "ty": 2,
      "x": 776,
      "y": 737
    },
    {
      "t": 13401,
      "e": 13401,
      "ty": 2,
      "x": 650,
      "y": 590
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 2,
      "x": 568,
      "y": 512
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 41,
      "x": 11386,
      "y": 29941,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13601,
      "e": 13601,
      "ty": 2,
      "x": 594,
      "y": 501
    },
    {
      "t": 13701,
      "e": 13701,
      "ty": 2,
      "x": 690,
      "y": 464
    },
    {
      "t": 13751,
      "e": 13751,
      "ty": 41,
      "x": 19196,
      "y": 25845,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13801,
      "e": 13801,
      "ty": 2,
      "x": 732,
      "y": 467
    },
    {
      "t": 13901,
      "e": 13901,
      "ty": 2,
      "x": 825,
      "y": 526
    },
    {
      "t": 14001,
      "e": 14001,
      "ty": 2,
      "x": 844,
      "y": 538
    },
    {
      "t": 14001,
      "e": 14001,
      "ty": 41,
      "x": 26459,
      "y": 32071,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14012,
      "e": 14012,
      "ty": 3,
      "x": 844,
      "y": 538,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14100,
      "e": 14100,
      "ty": 4,
      "x": 26459,
      "y": 32071,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14100,
      "e": 14100,
      "ty": 5,
      "x": 844,
      "y": 538,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14201,
      "e": 14201,
      "ty": 2,
      "x": 844,
      "y": 535
    },
    {
      "t": 14252,
      "e": 14252,
      "ty": 41,
      "x": 25913,
      "y": 24862,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 14301,
      "e": 14301,
      "ty": 2,
      "x": 785,
      "y": 190
    },
    {
      "t": 14324,
      "e": 14324,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 14401,
      "e": 14401,
      "ty": 2,
      "x": 765,
      "y": 29
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 41,
      "x": 26069,
      "y": 1277,
      "ta": "html > body"
    },
    {
      "t": 20001,
      "e": 19501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21966,
      "e": 19501,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 294, dom: 294, initialDom: 299",
  "javascriptErrors": []
}