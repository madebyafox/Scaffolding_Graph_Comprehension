var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "263e37342df50bf33cdca274599ecdc0",
  "created": "2018-05-18T11:38:09.8279562-07:00",
  "lastActivity": "2018-05-18T11:42:29.6509562-07:00",
  "pageViews": [
    {
      "id": "05181017957cf42609e820eb8de532fa9ffbf5ae",
      "startTime": "2018-05-18T11:38:09.8279562-07:00",
      "endTime": "2018-05-18T11:42:29.6509562-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 259823,
      "engagementTime": 220125,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 259823,
  "engagementTime": 220125,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.45",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=JDT07",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7e0dacd8a9293693d5a292b6257f6c02",
  "gdpr": false
}