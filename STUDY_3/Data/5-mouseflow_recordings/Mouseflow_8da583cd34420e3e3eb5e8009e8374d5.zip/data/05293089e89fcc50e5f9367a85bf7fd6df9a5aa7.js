var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05293089e89fcc50e5f9367a85bf7fd6df9a5aa7"] = {
  "startTime": "2018-05-29T21:02:30.2067903Z",
  "websitePageUrl": "/",
  "visitTime": 151335,
  "engagementTime": 38224,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "8da583cd34420e3e3eb5e8009e8374d5",
    "created": "2018-05-29T21:02:30.2067903+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9188e8af24ee97c7814697018d490d78",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8da583cd34420e3e3eb5e8009e8374d5/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 232,
      "e": 232,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 8067,
      "e": 5101,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8101,
      "e": 5135,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 8101,
      "e": 5135,
      "ty": 2,
      "x": 883,
      "y": 49
    },
    {
      "t": 8252,
      "e": 5286,
      "ty": 41,
      "x": 30133,
      "y": 2271,
      "ta": "html > body"
    },
    {
      "t": 10008,
      "e": 7042,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 123397,
      "e": 10286,
      "ty": 2,
      "x": 946,
      "y": 50
    },
    {
      "t": 123435,
      "e": 10324,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 123498,
      "e": 10387,
      "ty": 2,
      "x": 1860,
      "y": 30
    },
    {
      "t": 123498,
      "e": 10387,
      "ty": 41,
      "x": 63778,
      "y": 1218,
      "ta": "> div.masterdiv"
    },
    {
      "t": 123697,
      "e": 10586,
      "ty": 2,
      "x": 1806,
      "y": 531
    },
    {
      "t": 123747,
      "e": 10636,
      "ty": 41,
      "x": 55995,
      "y": 41215,
      "ta": "> div.masterdiv"
    },
    {
      "t": 123797,
      "e": 10686,
      "ty": 2,
      "x": 1436,
      "y": 973
    },
    {
      "t": 123896,
      "e": 10785,
      "ty": 2,
      "x": 1090,
      "y": 1199
    },
    {
      "t": 123998,
      "e": 10887,
      "ty": 2,
      "x": 880,
      "y": 1199
    },
    {
      "t": 124096,
      "e": 10985,
      "ty": 2,
      "x": 803,
      "y": 1178
    },
    {
      "t": 124197,
      "e": 11086,
      "ty": 2,
      "x": 750,
      "y": 1079
    },
    {
      "t": 124248,
      "e": 11137,
      "ty": 41,
      "x": 22362,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 124297,
      "e": 11186,
      "ty": 2,
      "x": 760,
      "y": 1024
    },
    {
      "t": 124396,
      "e": 11285,
      "ty": 2,
      "x": 783,
      "y": 991
    },
    {
      "t": 124496,
      "e": 11385,
      "ty": 2,
      "x": 787,
      "y": 985
    },
    {
      "t": 124497,
      "e": 11386,
      "ty": 41,
      "x": 24281,
      "y": 59462,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 124597,
      "e": 11486,
      "ty": 2,
      "x": 785,
      "y": 957
    },
    {
      "t": 124697,
      "e": 11586,
      "ty": 2,
      "x": 782,
      "y": 931
    },
    {
      "t": 124747,
      "e": 11636,
      "ty": 41,
      "x": 24231,
      "y": 33932,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 124796,
      "e": 11685,
      "ty": 2,
      "x": 789,
      "y": 913
    },
    {
      "t": 124897,
      "e": 11786,
      "ty": 2,
      "x": 795,
      "y": 899
    },
    {
      "t": 124996,
      "e": 11885,
      "ty": 2,
      "x": 799,
      "y": 892
    },
    {
      "t": 124997,
      "e": 11886,
      "ty": 41,
      "x": 24871,
      "y": 61188,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125076,
      "e": 11965,
      "ty": 3,
      "x": 799,
      "y": 892,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125196,
      "e": 12085,
      "ty": 4,
      "x": 24871,
      "y": 61188,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125197,
      "e": 12086,
      "ty": 5,
      "x": 799,
      "y": 892,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125496,
      "e": 12385,
      "ty": 2,
      "x": 800,
      "y": 891
    },
    {
      "t": 125497,
      "e": 12386,
      "ty": 41,
      "x": 24920,
      "y": 61084,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 125596,
      "e": 12485,
      "ty": 2,
      "x": 802,
      "y": 901
    },
    {
      "t": 125697,
      "e": 12586,
      "ty": 2,
      "x": 803,
      "y": 905
    },
    {
      "t": 125724,
      "e": 12613,
      "ty": 3,
      "x": 803,
      "y": 908,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 125748,
      "e": 12637,
      "ty": 41,
      "x": 118,
      "y": 3025,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 125796,
      "e": 12685,
      "ty": 2,
      "x": 804,
      "y": 912
    },
    {
      "t": 125896,
      "e": 12785,
      "ty": 2,
      "x": 808,
      "y": 922
    },
    {
      "t": 125899,
      "e": 12788,
      "ty": 4,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 125996,
      "e": 12885,
      "ty": 2,
      "x": 811,
      "y": 923
    },
    {
      "t": 125997,
      "e": 12886,
      "ty": 41,
      "x": 24780,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 126096,
      "e": 12985,
      "ty": 2,
      "x": 812,
      "y": 924
    },
    {
      "t": 126171,
      "e": 13060,
      "ty": 3,
      "x": 812,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 126246,
      "e": 13135,
      "ty": 41,
      "x": 28057,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 126252,
      "e": 13141,
      "ty": 4,
      "x": 28057,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 126253,
      "e": 13142,
      "ty": 5,
      "x": 812,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 126255,
      "e": 13144,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 126262,
      "e": 13151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 126496,
      "e": 13385,
      "ty": 2,
      "x": 830,
      "y": 945
    },
    {
      "t": 126496,
      "e": 13385,
      "ty": 41,
      "x": 26396,
      "y": 56692,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126597,
      "e": 13486,
      "ty": 2,
      "x": 901,
      "y": 1037
    },
    {
      "t": 126696,
      "e": 13585,
      "ty": 2,
      "x": 921,
      "y": 1059
    },
    {
      "t": 126746,
      "e": 13635,
      "ty": 41,
      "x": 31217,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126796,
      "e": 13685,
      "ty": 2,
      "x": 931,
      "y": 1074
    },
    {
      "t": 126897,
      "e": 13786,
      "ty": 2,
      "x": 954,
      "y": 1098
    },
    {
      "t": 126996,
      "e": 13885,
      "ty": 2,
      "x": 955,
      "y": 1099
    },
    {
      "t": 126997,
      "e": 13886,
      "ty": 41,
      "x": 24848,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 127044,
      "e": 13933,
      "ty": 3,
      "x": 955,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 127046,
      "e": 13935,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 127046,
      "e": 13935,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 127155,
      "e": 14044,
      "ty": 4,
      "x": 24848,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 127156,
      "e": 14045,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 127158,
      "e": 14047,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 127158,
      "e": 14047,
      "ty": 5,
      "x": 955,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 128161,
      "e": 15050,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 128896,
      "e": 15785,
      "ty": 2,
      "x": 920,
      "y": 767
    },
    {
      "t": 128905,
      "e": 15794,
      "ty": 6,
      "x": 915,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 128921,
      "e": 15810,
      "ty": 7,
      "x": 907,
      "y": 645,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 128956,
      "e": 15845,
      "ty": 6,
      "x": 900,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128996,
      "e": 15885,
      "ty": 2,
      "x": 898,
      "y": 588
    },
    {
      "t": 128996,
      "e": 15885,
      "ty": 41,
      "x": 19465,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129436,
      "e": 16325,
      "ty": 3,
      "x": 898,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129437,
      "e": 16326,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129580,
      "e": 16469,
      "ty": 4,
      "x": 19465,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129581,
      "e": 16470,
      "ty": 5,
      "x": 898,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129997,
      "e": 16886,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 131089,
      "e": 17978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 131089,
      "e": 17978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131190,
      "e": 18079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "r"
    },
    {
      "t": 131231,
      "e": 18120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 131231,
      "e": 18120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131288,
      "e": 18177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ro"
    },
    {
      "t": 131402,
      "e": 18291,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ro"
    },
    {
      "t": 131431,
      "e": 18320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 131432,
      "e": 18321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131487,
      "e": 18376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 131487,
      "e": 18376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131502,
      "e": 18391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "rome"
    },
    {
      "t": 131599,
      "e": 18488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 131615,
      "e": 18504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 131616,
      "e": 18505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131686,
      "e": 18575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||o"
    },
    {
      "t": 131802,
      "e": 18691,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "romeo"
    },
    {
      "t": 132575,
      "e": 19464,
      "ty": 7,
      "x": 883,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132596,
      "e": 19485,
      "ty": 2,
      "x": 879,
      "y": 618
    },
    {
      "t": 132696,
      "e": 19585,
      "ty": 2,
      "x": 867,
      "y": 642
    },
    {
      "t": 132747,
      "e": 19636,
      "ty": 41,
      "x": 12544,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 132796,
      "e": 19685,
      "ty": 2,
      "x": 862,
      "y": 660
    },
    {
      "t": 132897,
      "e": 19786,
      "ty": 2,
      "x": 857,
      "y": 671
    },
    {
      "t": 132996,
      "e": 19885,
      "ty": 2,
      "x": 856,
      "y": 671
    },
    {
      "t": 132997,
      "e": 19886,
      "ty": 41,
      "x": 10381,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 133092,
      "e": 19981,
      "ty": 6,
      "x": 856,
      "y": 687,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133097,
      "e": 19986,
      "ty": 2,
      "x": 856,
      "y": 687
    },
    {
      "t": 133108,
      "e": 19997,
      "ty": 7,
      "x": 856,
      "y": 703,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133197,
      "e": 20086,
      "ty": 2,
      "x": 855,
      "y": 719
    },
    {
      "t": 133247,
      "e": 20136,
      "ty": 41,
      "x": 29168,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 133251,
      "e": 20140,
      "ty": 3,
      "x": 855,
      "y": 719,
      "ta": "html > body"
    },
    {
      "t": 133251,
      "e": 20140,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "romeo"
    },
    {
      "t": 133252,
      "e": 20141,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 133364,
      "e": 20253,
      "ty": 4,
      "x": 29168,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 133364,
      "e": 20253,
      "ty": 5,
      "x": 855,
      "y": 719,
      "ta": "html > body"
    },
    {
      "t": 133476,
      "e": 20365,
      "ty": 6,
      "x": 847,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133496,
      "e": 20385,
      "ty": 2,
      "x": 847,
      "y": 693
    },
    {
      "t": 133497,
      "e": 20386,
      "ty": 41,
      "x": 8435,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133596,
      "e": 20485,
      "ty": 2,
      "x": 846,
      "y": 692
    },
    {
      "t": 133620,
      "e": 20509,
      "ty": 3,
      "x": 846,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133621,
      "e": 20510,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133739,
      "e": 20628,
      "ty": 4,
      "x": 8218,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133739,
      "e": 20628,
      "ty": 5,
      "x": 846,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133747,
      "e": 20636,
      "ty": 41,
      "x": 8218,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134119,
      "e": 21008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 134120,
      "e": 21009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134183,
      "e": 21072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 134263,
      "e": 21152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 134265,
      "e": 21154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134318,
      "e": 21207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 134596,
      "e": 21485,
      "ty": 2,
      "x": 852,
      "y": 693
    },
    {
      "t": 134640,
      "e": 21529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "53"
    },
    {
      "t": 134641,
      "e": 21530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134676,
      "e": 21565,
      "ty": 7,
      "x": 866,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134697,
      "e": 21586,
      "ty": 2,
      "x": 867,
      "y": 703
    },
    {
      "t": 134726,
      "e": 21615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 134747,
      "e": 21636,
      "ty": 41,
      "x": 29823,
      "y": 38778,
      "ta": "html > body"
    },
    {
      "t": 134796,
      "e": 21685,
      "ty": 2,
      "x": 890,
      "y": 719
    },
    {
      "t": 134894,
      "e": 21783,
      "ty": 6,
      "x": 895,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 134897,
      "e": 21786,
      "ty": 2,
      "x": 895,
      "y": 721
    },
    {
      "t": 134997,
      "e": 21886,
      "ty": 2,
      "x": 903,
      "y": 722
    },
    {
      "t": 134997,
      "e": 21886,
      "ty": 41,
      "x": 3647,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135097,
      "e": 21986,
      "ty": 2,
      "x": 908,
      "y": 723
    },
    {
      "t": 135148,
      "e": 22037,
      "ty": 3,
      "x": 908,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135149,
      "e": 22038,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 135150,
      "e": 22039,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135150,
      "e": 22039,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135247,
      "e": 22136,
      "ty": 41,
      "x": 6224,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135250,
      "e": 22139,
      "ty": 4,
      "x": 6224,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135252,
      "e": 22141,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135253,
      "e": 22142,
      "ty": 5,
      "x": 908,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135253,
      "e": 22142,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 135597,
      "e": 22486,
      "ty": 2,
      "x": 885,
      "y": 693
    },
    {
      "t": 135697,
      "e": 22586,
      "ty": 2,
      "x": 823,
      "y": 612
    },
    {
      "t": 135747,
      "e": 22636,
      "ty": 41,
      "x": 26930,
      "y": 30579,
      "ta": "html > body"
    },
    {
      "t": 135796,
      "e": 22685,
      "ty": 2,
      "x": 771,
      "y": 520
    },
    {
      "t": 135896,
      "e": 22785,
      "ty": 2,
      "x": 745,
      "y": 169
    },
    {
      "t": 135997,
      "e": 22886,
      "ty": 2,
      "x": 626,
      "y": 0
    },
    {
      "t": 135997,
      "e": 22886,
      "ty": 41,
      "x": 21558,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 136097,
      "e": 22986,
      "ty": 2,
      "x": 553,
      "y": 0
    },
    {
      "t": 136247,
      "e": 23136,
      "ty": 41,
      "x": 18389,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 136296,
      "e": 23185,
      "ty": 2,
      "x": 378,
      "y": 0
    },
    {
      "t": 136342,
      "e": 23231,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 136396,
      "e": 23285,
      "ty": 2,
      "x": 390,
      "y": 0
    },
    {
      "t": 136496,
      "e": 23385,
      "ty": 2,
      "x": 451,
      "y": 0
    },
    {
      "t": 136497,
      "e": 23386,
      "ty": 41,
      "x": 15531,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 136596,
      "e": 23485,
      "ty": 2,
      "x": 559,
      "y": 0
    },
    {
      "t": 136697,
      "e": 23586,
      "ty": 2,
      "x": 954,
      "y": 46
    },
    {
      "t": 136747,
      "e": 23636,
      "ty": 41,
      "x": 36607,
      "y": 4431,
      "ta": "> div.masterdiv"
    },
    {
      "t": 136796,
      "e": 23685,
      "ty": 2,
      "x": 1074,
      "y": 99
    },
    {
      "t": 136897,
      "e": 23786,
      "ty": 2,
      "x": 1019,
      "y": 229
    },
    {
      "t": 136997,
      "e": 23886,
      "ty": 2,
      "x": 807,
      "y": 359
    },
    {
      "t": 136997,
      "e": 23886,
      "ty": 41,
      "x": 25264,
      "y": 16114,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 137097,
      "e": 23986,
      "ty": 2,
      "x": 700,
      "y": 393
    },
    {
      "t": 137197,
      "e": 24086,
      "ty": 2,
      "x": 678,
      "y": 397
    },
    {
      "t": 137247,
      "e": 24136,
      "ty": 41,
      "x": 18623,
      "y": 18814,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 137297,
      "e": 24186,
      "ty": 2,
      "x": 668,
      "y": 400
    },
    {
      "t": 137397,
      "e": 24286,
      "ty": 2,
      "x": 662,
      "y": 403
    },
    {
      "t": 137497,
      "e": 24386,
      "ty": 41,
      "x": 18131,
      "y": 19160,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 137597,
      "e": 24486,
      "ty": 2,
      "x": 679,
      "y": 438
    },
    {
      "t": 137696,
      "e": 24585,
      "ty": 2,
      "x": 855,
      "y": 583
    },
    {
      "t": 137745,
      "e": 24634,
      "ty": 6,
      "x": 929,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 137746,
      "e": 24635,
      "ty": 41,
      "x": 30245,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 137761,
      "e": 24650,
      "ty": 7,
      "x": 950,
      "y": 746,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 137761,
      "e": 24650,
      "ty": 6,
      "x": 950,
      "y": 746,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 137778,
      "e": 24667,
      "ty": 7,
      "x": 972,
      "y": 806,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 137797,
      "e": 24686,
      "ty": 2,
      "x": 992,
      "y": 896
    },
    {
      "t": 137897,
      "e": 24786,
      "ty": 2,
      "x": 976,
      "y": 1063
    },
    {
      "t": 137997,
      "e": 24886,
      "ty": 2,
      "x": 976,
      "y": 1066
    },
    {
      "t": 137997,
      "e": 24886,
      "ty": 41,
      "x": 33579,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 138012,
      "e": 24901,
      "ty": 6,
      "x": 974,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 138097,
      "e": 24986,
      "ty": 2,
      "x": 956,
      "y": 1088
    },
    {
      "t": 138247,
      "e": 25136,
      "ty": 41,
      "x": 25394,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 138379,
      "e": 25268,
      "ty": 7,
      "x": 944,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 138397,
      "e": 25286,
      "ty": 2,
      "x": 938,
      "y": 1063
    },
    {
      "t": 138497,
      "e": 25386,
      "ty": 2,
      "x": 931,
      "y": 1054
    },
    {
      "t": 138497,
      "e": 25386,
      "ty": 41,
      "x": 31365,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 138597,
      "e": 25486,
      "ty": 2,
      "x": 930,
      "y": 1054
    },
    {
      "t": 138748,
      "e": 25637,
      "ty": 41,
      "x": 31316,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 138996,
      "e": 25885,
      "ty": 2,
      "x": 936,
      "y": 1032
    },
    {
      "t": 138996,
      "e": 25885,
      "ty": 41,
      "x": 31611,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139097,
      "e": 25986,
      "ty": 2,
      "x": 938,
      "y": 1021
    },
    {
      "t": 139247,
      "e": 26136,
      "ty": 41,
      "x": 31709,
      "y": 61955,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139397,
      "e": 26286,
      "ty": 2,
      "x": 944,
      "y": 1053
    },
    {
      "t": 139480,
      "e": 26369,
      "ty": 6,
      "x": 948,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 139496,
      "e": 26385,
      "ty": 2,
      "x": 948,
      "y": 1074
    },
    {
      "t": 139496,
      "e": 26385,
      "ty": 41,
      "x": 21025,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 139597,
      "e": 26486,
      "ty": 2,
      "x": 954,
      "y": 1086
    },
    {
      "t": 139747,
      "e": 26636,
      "ty": 41,
      "x": 24302,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 139820,
      "e": 26709,
      "ty": 3,
      "x": 954,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 139822,
      "e": 26711,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 139963,
      "e": 26852,
      "ty": 4,
      "x": 24302,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 139964,
      "e": 26853,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 139965,
      "e": 26854,
      "ty": 5,
      "x": 954,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 139968,
      "e": 26857,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 140297,
      "e": 27186,
      "ty": 2,
      "x": 954,
      "y": 1075
    },
    {
      "t": 140397,
      "e": 27286,
      "ty": 2,
      "x": 951,
      "y": 1019
    },
    {
      "t": 140497,
      "e": 27386,
      "ty": 2,
      "x": 1040,
      "y": 903
    },
    {
      "t": 140497,
      "e": 27386,
      "ty": 41,
      "x": 35539,
      "y": 49580,
      "ta": "html > body"
    },
    {
      "t": 140564,
      "e": 27453,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 140597,
      "e": 27486,
      "ty": 2,
      "x": 1888,
      "y": 609
    },
    {
      "t": 140747,
      "e": 27636,
      "ty": 41,
      "x": 65259,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 140797,
      "e": 27686,
      "ty": 2,
      "x": 1647,
      "y": 0
    },
    {
      "t": 140897,
      "e": 27786,
      "ty": 2,
      "x": 1143,
      "y": 0
    },
    {
      "t": 140969,
      "e": 27858,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 140997,
      "e": 27886,
      "ty": 2,
      "x": 1075,
      "y": 0
    },
    {
      "t": 140997,
      "e": 27886,
      "ty": 41,
      "x": 37020,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 141097,
      "e": 27986,
      "ty": 2,
      "x": 706,
      "y": 0
    },
    {
      "t": 141197,
      "e": 28086,
      "ty": 2,
      "x": 0,
      "y": 0
    },
    {
      "t": 141247,
      "e": 28136,
      "ty": 41,
      "x": 0,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 141397,
      "e": 28286,
      "ty": 2,
      "x": 0,
      "y": 1
    },
    {
      "t": 141497,
      "e": 28386,
      "ty": 2,
      "x": 14,
      "y": 24
    },
    {
      "t": 141497,
      "e": 28386,
      "ty": 41,
      "x": 206,
      "y": 886,
      "ta": "html > body"
    },
    {
      "t": 141597,
      "e": 28486,
      "ty": 2,
      "x": 248,
      "y": 121
    },
    {
      "t": 141697,
      "e": 28586,
      "ty": 2,
      "x": 786,
      "y": 248
    },
    {
      "t": 141747,
      "e": 28636,
      "ty": 41,
      "x": 35364,
      "y": 13704,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 141796,
      "e": 28685,
      "ty": 2,
      "x": 1054,
      "y": 345
    },
    {
      "t": 141897,
      "e": 28786,
      "ty": 2,
      "x": 1053,
      "y": 358
    },
    {
      "t": 141997,
      "e": 28886,
      "ty": 2,
      "x": 1007,
      "y": 399
    },
    {
      "t": 141997,
      "e": 28886,
      "ty": 41,
      "x": 35073,
      "y": 19683,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 142097,
      "e": 28986,
      "ty": 2,
      "x": 987,
      "y": 414
    },
    {
      "t": 142197,
      "e": 29086,
      "ty": 2,
      "x": 981,
      "y": 416
    },
    {
      "t": 142247,
      "e": 29136,
      "ty": 41,
      "x": 33617,
      "y": 21081,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 142297,
      "e": 29186,
      "ty": 2,
      "x": 970,
      "y": 419
    },
    {
      "t": 142397,
      "e": 29286,
      "ty": 2,
      "x": 957,
      "y": 421
    },
    {
      "t": 142497,
      "e": 29386,
      "ty": 2,
      "x": 950,
      "y": 423
    },
    {
      "t": 142497,
      "e": 29386,
      "ty": 41,
      "x": 32306,
      "y": 21547,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 142596,
      "e": 29485,
      "ty": 2,
      "x": 949,
      "y": 423
    },
    {
      "t": 142748,
      "e": 29637,
      "ty": 41,
      "x": 32257,
      "y": 21547,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 147496,
      "e": 34385,
      "ty": 2,
      "x": 949,
      "y": 436
    },
    {
      "t": 147496,
      "e": 34385,
      "ty": 41,
      "x": 32257,
      "y": 22556,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 147596,
      "e": 34485,
      "ty": 2,
      "x": 948,
      "y": 499
    },
    {
      "t": 147696,
      "e": 34585,
      "ty": 2,
      "x": 967,
      "y": 600
    },
    {
      "t": 147746,
      "e": 34635,
      "ty": 41,
      "x": 33859,
      "y": 39018,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 147796,
      "e": 34685,
      "ty": 2,
      "x": 996,
      "y": 693
    },
    {
      "t": 147896,
      "e": 34785,
      "ty": 2,
      "x": 1009,
      "y": 735
    },
    {
      "t": 147996,
      "e": 34885,
      "ty": 2,
      "x": 1019,
      "y": 755
    },
    {
      "t": 147996,
      "e": 34885,
      "ty": 41,
      "x": 35655,
      "y": 47326,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 148596,
      "e": 35485,
      "ty": 2,
      "x": 1019,
      "y": 739
    },
    {
      "t": 148697,
      "e": 35586,
      "ty": 2,
      "x": 1019,
      "y": 738
    },
    {
      "t": 148747,
      "e": 35636,
      "ty": 41,
      "x": 35655,
      "y": 46006,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 149097,
      "e": 35986,
      "ty": 2,
      "x": 1019,
      "y": 737
    },
    {
      "t": 149247,
      "e": 36136,
      "ty": 41,
      "x": 35655,
      "y": 45928,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 149997,
      "e": 36886,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150329,
      "e": 37218,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 151335,
      "e": 38224,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 254, dom: 705, initialDom: 709",
  "javascriptErrors": []
}