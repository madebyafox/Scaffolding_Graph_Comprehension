var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060435693f3e1b08e1796061f473f781572be0e0"] = {
  "startTime": "2018-06-04T20:08:35.2267206Z",
  "websitePageUrl": "/",
  "visitTime": 479792,
  "engagementTime": 63924,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c824d72094d6d2e2837182e4937a136f",
    "created": "2018-06-04T20:08:35.2267206+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "738e0bfd7dd4a92651390e255f02dfbb",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c824d72094d6d2e2837182e4937a136f/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 323,
      "e": 323,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 7001,
      "e": 5102,
      "ty": 2,
      "x": 0,
      "y": 28
    },
    {
      "t": 7002,
      "e": 5103,
      "ty": 41,
      "x": 0,
      "y": 1703,
      "ta": "html"
    },
    {
      "t": 7031,
      "e": 5132,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7102,
      "e": 5203,
      "ty": 2,
      "x": 15,
      "y": 6
    },
    {
      "t": 7252,
      "e": 5353,
      "ty": 41,
      "x": 516,
      "y": 365,
      "ta": "html"
    },
    {
      "t": 9001,
      "e": 7102,
      "ty": 2,
      "x": 294,
      "y": 149
    },
    {
      "t": 9001,
      "e": 7102,
      "ty": 41,
      "x": 9849,
      "y": 8579,
      "ta": "html > body"
    },
    {
      "t": 9101,
      "e": 7202,
      "ty": 2,
      "x": 294,
      "y": 152
    },
    {
      "t": 9251,
      "e": 7352,
      "ty": 41,
      "x": 9849,
      "y": 8762,
      "ta": "html > body"
    },
    {
      "t": 10006,
      "e": 8107,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33502,
      "e": 12352,
      "ty": 2,
      "x": 513,
      "y": 667
    },
    {
      "t": 33503,
      "e": 12353,
      "ty": 41,
      "x": 8383,
      "y": 42638,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 33576,
      "e": 12426,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 33602,
      "e": 12452,
      "ty": 2,
      "x": 708,
      "y": 1080
    },
    {
      "t": 33902,
      "e": 12752,
      "ty": 2,
      "x": 824,
      "y": 951
    },
    {
      "t": 34002,
      "e": 12852,
      "ty": 2,
      "x": 842,
      "y": 832
    },
    {
      "t": 34002,
      "e": 12852,
      "ty": 41,
      "x": 26350,
      "y": 56155,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34102,
      "e": 12952,
      "ty": 2,
      "x": 843,
      "y": 825
    },
    {
      "t": 34193,
      "e": 13043,
      "ty": 3,
      "x": 843,
      "y": 824,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34202,
      "e": 13052,
      "ty": 2,
      "x": 843,
      "y": 824
    },
    {
      "t": 34252,
      "e": 13102,
      "ty": 41,
      "x": 26405,
      "y": 55499,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34294,
      "e": 13144,
      "ty": 4,
      "x": 26405,
      "y": 55499,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34295,
      "e": 13145,
      "ty": 5,
      "x": 843,
      "y": 824,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34702,
      "e": 13552,
      "ty": 2,
      "x": 847,
      "y": 813
    },
    {
      "t": 34752,
      "e": 13602,
      "ty": 41,
      "x": 27278,
      "y": 52960,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34801,
      "e": 13651,
      "ty": 2,
      "x": 860,
      "y": 791
    },
    {
      "t": 35002,
      "e": 13852,
      "ty": 41,
      "x": 27333,
      "y": 52796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 35202,
      "e": 14052,
      "ty": 2,
      "x": 1265,
      "y": 1007
    },
    {
      "t": 35252,
      "e": 14102,
      "ty": 41,
      "x": 48798,
      "y": 63405,
      "ta": "html > body"
    },
    {
      "t": 35302,
      "e": 14152,
      "ty": 2,
      "x": 1442,
      "y": 1067
    },
    {
      "t": 35402,
      "e": 14252,
      "ty": 2,
      "x": 1448,
      "y": 1074
    },
    {
      "t": 35502,
      "e": 14352,
      "ty": 41,
      "x": 49590,
      "y": 64865,
      "ta": "html > body"
    },
    {
      "t": 35702,
      "e": 14552,
      "ty": 2,
      "x": 1447,
      "y": 1076
    },
    {
      "t": 35752,
      "e": 14602,
      "ty": 41,
      "x": 49624,
      "y": 64561,
      "ta": "html > body"
    },
    {
      "t": 35802,
      "e": 14652,
      "ty": 2,
      "x": 1448,
      "y": 1011
    },
    {
      "t": 35902,
      "e": 14752,
      "ty": 2,
      "x": 1436,
      "y": 888
    },
    {
      "t": 36002,
      "e": 14852,
      "ty": 2,
      "x": 1432,
      "y": 868
    },
    {
      "t": 36002,
      "e": 14852,
      "ty": 41,
      "x": 58571,
      "y": 59104,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36102,
      "e": 14952,
      "ty": 2,
      "x": 1405,
      "y": 804
    },
    {
      "t": 36202,
      "e": 15052,
      "ty": 2,
      "x": 1351,
      "y": 729
    },
    {
      "t": 36252,
      "e": 15102,
      "ty": 41,
      "x": 54148,
      "y": 47717,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36401,
      "e": 15251,
      "ty": 2,
      "x": 1295,
      "y": 696
    },
    {
      "t": 36501,
      "e": 15351,
      "ty": 2,
      "x": 1098,
      "y": 615
    },
    {
      "t": 36502,
      "e": 15352,
      "ty": 41,
      "x": 40331,
      "y": 38378,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36602,
      "e": 15452,
      "ty": 2,
      "x": 1079,
      "y": 603
    },
    {
      "t": 36703,
      "e": 15553,
      "ty": 3,
      "x": 1079,
      "y": 603,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36751,
      "e": 15601,
      "ty": 41,
      "x": 39293,
      "y": 37395,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36807,
      "e": 15657,
      "ty": 4,
      "x": 39293,
      "y": 37395,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36807,
      "e": 15657,
      "ty": 5,
      "x": 1079,
      "y": 603,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37002,
      "e": 15852,
      "ty": 2,
      "x": 855,
      "y": 594
    },
    {
      "t": 37003,
      "e": 15853,
      "ty": 41,
      "x": 27060,
      "y": 36658,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37102,
      "e": 15952,
      "ty": 2,
      "x": 847,
      "y": 592
    },
    {
      "t": 37208,
      "e": 16058,
      "ty": 3,
      "x": 847,
      "y": 592,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37251,
      "e": 16101,
      "ty": 41,
      "x": 26623,
      "y": 36494,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37343,
      "e": 16193,
      "ty": 4,
      "x": 26623,
      "y": 36494,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37344,
      "e": 16194,
      "ty": 5,
      "x": 847,
      "y": 592,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 37601,
      "e": 16451,
      "ty": 2,
      "x": 976,
      "y": 438
    },
    {
      "t": 37655,
      "e": 16505,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 37701,
      "e": 16551,
      "ty": 2,
      "x": 1092,
      "y": 4
    },
    {
      "t": 37751,
      "e": 16601,
      "ty": 41,
      "x": 37606,
      "y": 243,
      "ta": "html"
    },
    {
      "t": 37901,
      "e": 16751,
      "ty": 2,
      "x": 1038,
      "y": 21
    },
    {
      "t": 38001,
      "e": 16851,
      "ty": 2,
      "x": 1037,
      "y": 21
    },
    {
      "t": 38001,
      "e": 16851,
      "ty": 41,
      "x": 35436,
      "y": 791,
      "ta": "html > body"
    },
    {
      "t": 40001,
      "e": 18851,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41506,
      "e": 20356,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 41601,
      "e": 20451,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 41701,
      "e": 20551,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 42595,
      "e": 21445,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48602,
      "e": 25551,
      "ty": 2,
      "x": 826,
      "y": 852
    },
    {
      "t": 48701,
      "e": 25650,
      "ty": 2,
      "x": 806,
      "y": 882
    },
    {
      "t": 48752,
      "e": 25701,
      "ty": 41,
      "x": 25707,
      "y": 59123,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48801,
      "e": 25750,
      "ty": 2,
      "x": 816,
      "y": 894
    },
    {
      "t": 48901,
      "e": 25850,
      "ty": 2,
      "x": 816,
      "y": 874
    },
    {
      "t": 49002,
      "e": 25951,
      "ty": 2,
      "x": 817,
      "y": 866
    },
    {
      "t": 49002,
      "e": 25951,
      "ty": 41,
      "x": 44440,
      "y": 26214,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49101,
      "e": 26050,
      "ty": 2,
      "x": 815,
      "y": 862
    },
    {
      "t": 49176,
      "e": 26125,
      "ty": 3,
      "x": 815,
      "y": 862,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49252,
      "e": 26201,
      "ty": 41,
      "x": 37887,
      "y": 13107,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49319,
      "e": 26268,
      "ty": 4,
      "x": 37887,
      "y": 13107,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49319,
      "e": 26268,
      "ty": 5,
      "x": 815,
      "y": 862,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 49323,
      "e": 26272,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 49333,
      "e": 26282,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 49501,
      "e": 26450,
      "ty": 2,
      "x": 820,
      "y": 850
    },
    {
      "t": 49502,
      "e": 26451,
      "ty": 41,
      "x": 25904,
      "y": 62325,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 49601,
      "e": 26550,
      "ty": 2,
      "x": 831,
      "y": 526
    },
    {
      "t": 49695,
      "e": 26644,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 49701,
      "e": 26650,
      "ty": 2,
      "x": 307,
      "y": 51
    },
    {
      "t": 49752,
      "e": 26701,
      "ty": 41,
      "x": 10296,
      "y": 2616,
      "ta": "> div.masterdiv"
    },
    {
      "t": 50001,
      "e": 26950,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50801,
      "e": 27750,
      "ty": 2,
      "x": 529,
      "y": 89
    },
    {
      "t": 50901,
      "e": 27850,
      "ty": 2,
      "x": 511,
      "y": 142
    },
    {
      "t": 51002,
      "e": 27951,
      "ty": 41,
      "x": 10702,
      "y": 2000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60003,
      "e": 32951,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100732,
      "e": 32951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "122"
    },
    {
      "t": 100802,
      "e": 33021,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100802,
      "e": 33021,
      "ty": 2,
      "x": 511,
      "y": 208
    },
    {
      "t": 100866,
      "e": 33085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 101003,
      "e": 33222,
      "ty": 41,
      "x": 10702,
      "y": 5657,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110003,
      "e": 38222,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 447240,
      "e": 38222,
      "ty": 41,
      "x": 13900,
      "y": 9466,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 447289,
      "e": 38271,
      "ty": 2,
      "x": 921,
      "y": 965
    },
    {
      "t": 447389,
      "e": 38371,
      "ty": 2,
      "x": 1080,
      "y": 1215
    },
    {
      "t": 447489,
      "e": 38471,
      "ty": 2,
      "x": 1059,
      "y": 1207
    },
    {
      "t": 447589,
      "e": 38571,
      "ty": 2,
      "x": 851,
      "y": 1059
    },
    {
      "t": 447689,
      "e": 38671,
      "ty": 2,
      "x": 840,
      "y": 1031
    },
    {
      "t": 447739,
      "e": 38721,
      "ty": 41,
      "x": 27085,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 447789,
      "e": 38771,
      "ty": 2,
      "x": 873,
      "y": 1029
    },
    {
      "t": 447889,
      "e": 38871,
      "ty": 2,
      "x": 936,
      "y": 1050
    },
    {
      "t": 447989,
      "e": 38971,
      "ty": 2,
      "x": 936,
      "y": 1061
    },
    {
      "t": 447989,
      "e": 38971,
      "ty": 41,
      "x": 31611,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 448077,
      "e": 39059,
      "ty": 6,
      "x": 940,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 448089,
      "e": 39071,
      "ty": 2,
      "x": 940,
      "y": 1072
    },
    {
      "t": 448189,
      "e": 39171,
      "ty": 2,
      "x": 940,
      "y": 1082
    },
    {
      "t": 448239,
      "e": 39221,
      "ty": 41,
      "x": 15564,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 448289,
      "e": 39271,
      "ty": 2,
      "x": 938,
      "y": 1092
    },
    {
      "t": 448325,
      "e": 39307,
      "ty": 3,
      "x": 938,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 448326,
      "e": 39308,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 448328,
      "e": 39310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 448418,
      "e": 39400,
      "ty": 4,
      "x": 15564,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 448420,
      "e": 39402,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 448420,
      "e": 39402,
      "ty": 5,
      "x": 938,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 448420,
      "e": 39402,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 448489,
      "e": 39471,
      "ty": 41,
      "x": 32027,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 448989,
      "e": 39971,
      "ty": 2,
      "x": 981,
      "y": 932
    },
    {
      "t": 448990,
      "e": 39972,
      "ty": 41,
      "x": 33507,
      "y": 51187,
      "ta": "html > body"
    },
    {
      "t": 449089,
      "e": 40071,
      "ty": 2,
      "x": 1055,
      "y": 670
    },
    {
      "t": 449189,
      "e": 40171,
      "ty": 2,
      "x": 1055,
      "y": 659
    },
    {
      "t": 449239,
      "e": 40221,
      "ty": 41,
      "x": 35987,
      "y": 35952,
      "ta": "html > body"
    },
    {
      "t": 449289,
      "e": 40271,
      "ty": 2,
      "x": 1053,
      "y": 657
    },
    {
      "t": 449428,
      "e": 40410,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 450289,
      "e": 41271,
      "ty": 2,
      "x": 1036,
      "y": 630
    },
    {
      "t": 450328,
      "e": 41310,
      "ty": 6,
      "x": 1008,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 450389,
      "e": 41371,
      "ty": 2,
      "x": 1006,
      "y": 602
    },
    {
      "t": 450490,
      "e": 41472,
      "ty": 41,
      "x": 42824,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 450556,
      "e": 41538,
      "ty": 3,
      "x": 1006,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 450557,
      "e": 41539,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 450658,
      "e": 41640,
      "ty": 4,
      "x": 42824,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 450658,
      "e": 41640,
      "ty": 5,
      "x": 1006,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 452583,
      "e": 43565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 452662,
      "e": 43644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 452879,
      "e": 43861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "90"
    },
    {
      "t": 452879,
      "e": 43861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 452989,
      "e": 43971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Z"
    },
    {
      "t": 453046,
      "e": 44028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 453047,
      "e": 44029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 453135,
      "e": 44117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZU"
    },
    {
      "t": 453295,
      "e": 44277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 453296,
      "e": 44278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 453406,
      "e": 44388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZUL"
    },
    {
      "t": 453567,
      "e": 44549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 453568,
      "e": 44550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 453630,
      "e": 44612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZULU"
    },
    {
      "t": 453767,
      "e": 44749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 453768,
      "e": 44750,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZULU"
    },
    {
      "t": 453768,
      "e": 44750,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 453769,
      "e": 44751,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 453830,
      "e": 44812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 454591,
      "e": 45573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "98"
    },
    {
      "t": 454592,
      "e": 45574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 454678,
      "e": 45660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "2"
    },
    {
      "t": 454950,
      "e": 45932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 454951,
      "e": 45933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 455070,
      "e": 46052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 455159,
      "e": 46141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 455160,
      "e": 46142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 455197,
      "e": 46179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 456476,
      "e": 47458,
      "ty": 7,
      "x": 1006,
      "y": 611,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 456488,
      "e": 47470,
      "ty": 2,
      "x": 1006,
      "y": 622
    },
    {
      "t": 456488,
      "e": 47470,
      "ty": 41,
      "x": 42824,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 456583,
      "e": 47565,
      "ty": 6,
      "x": 1005,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 456589,
      "e": 47571,
      "ty": 2,
      "x": 1005,
      "y": 684
    },
    {
      "t": 456633,
      "e": 47615,
      "ty": 7,
      "x": 992,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 456666,
      "e": 47648,
      "ty": 6,
      "x": 989,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 456688,
      "e": 47670,
      "ty": 2,
      "x": 988,
      "y": 710
    },
    {
      "t": 456738,
      "e": 47720,
      "ty": 41,
      "x": 42817,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 456788,
      "e": 47770,
      "ty": 2,
      "x": 972,
      "y": 727
    },
    {
      "t": 456888,
      "e": 47870,
      "ty": 2,
      "x": 969,
      "y": 732
    },
    {
      "t": 456989,
      "e": 47971,
      "ty": 41,
      "x": 37663,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457123,
      "e": 48105,
      "ty": 3,
      "x": 969,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457124,
      "e": 48106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 457125,
      "e": 48107,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 457126,
      "e": 48108,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457226,
      "e": 48208,
      "ty": 4,
      "x": 37663,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457227,
      "e": 48209,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457228,
      "e": 48210,
      "ty": 5,
      "x": 969,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 457229,
      "e": 48211,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 458563,
      "e": 49545,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 458593,
      "e": 49575,
      "ty": 6,
      "x": 969,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 459988,
      "e": 50970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 464688,
      "e": 54575,
      "ty": 2,
      "x": 966,
      "y": 749
    },
    {
      "t": 464691,
      "e": 54578,
      "ty": 7,
      "x": 962,
      "y": 789,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 464739,
      "e": 54626,
      "ty": 41,
      "x": 32644,
      "y": 56208,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 464774,
      "e": 54661,
      "ty": 6,
      "x": 952,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 464788,
      "e": 54675,
      "ty": 2,
      "x": 952,
      "y": 1072
    },
    {
      "t": 464823,
      "e": 54710,
      "ty": 7,
      "x": 960,
      "y": 1118,
      "ta": "#start"
    },
    {
      "t": 464888,
      "e": 54775,
      "ty": 2,
      "x": 961,
      "y": 1139
    },
    {
      "t": 464989,
      "e": 54876,
      "ty": 2,
      "x": 964,
      "y": 1159
    },
    {
      "t": 464989,
      "e": 54876,
      "ty": 41,
      "x": 34873,
      "y": 47816,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 465088,
      "e": 54975,
      "ty": 2,
      "x": 968,
      "y": 1139
    },
    {
      "t": 465188,
      "e": 55075,
      "ty": 2,
      "x": 971,
      "y": 1132
    },
    {
      "t": 465239,
      "e": 55126,
      "ty": 41,
      "x": 38150,
      "y": 32858,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 465289,
      "e": 55176,
      "ty": 2,
      "x": 971,
      "y": 1131
    },
    {
      "t": 465389,
      "e": 55276,
      "ty": 2,
      "x": 967,
      "y": 1120
    },
    {
      "t": 465490,
      "e": 55377,
      "ty": 41,
      "x": 36278,
      "y": 26210,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 465589,
      "e": 55476,
      "ty": 2,
      "x": 967,
      "y": 1116
    },
    {
      "t": 465689,
      "e": 55576,
      "ty": 2,
      "x": 967,
      "y": 1113
    },
    {
      "t": 465739,
      "e": 55626,
      "ty": 41,
      "x": 36278,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 465789,
      "e": 55676,
      "ty": 2,
      "x": 968,
      "y": 1107
    },
    {
      "t": 465795,
      "e": 55682,
      "ty": 6,
      "x": 968,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 465888,
      "e": 55775,
      "ty": 2,
      "x": 970,
      "y": 1100
    },
    {
      "t": 465989,
      "e": 55876,
      "ty": 2,
      "x": 973,
      "y": 1095
    },
    {
      "t": 465989,
      "e": 55876,
      "ty": 41,
      "x": 34678,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 466332,
      "e": 56219,
      "ty": 3,
      "x": 973,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 466333,
      "e": 56220,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 466482,
      "e": 56369,
      "ty": 4,
      "x": 34678,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 466483,
      "e": 56370,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 466484,
      "e": 56371,
      "ty": 5,
      "x": 973,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 466488,
      "e": 56375,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 467487,
      "e": 57374,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 469989,
      "e": 59876,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 477239,
      "e": 61371,
      "ty": 41,
      "x": 33680,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 477289,
      "e": 61421,
      "ty": 2,
      "x": 986,
      "y": 1064
    },
    {
      "t": 477388,
      "e": 61520,
      "ty": 2,
      "x": 982,
      "y": 1048
    },
    {
      "t": 477489,
      "e": 61621,
      "ty": 2,
      "x": 979,
      "y": 1038
    },
    {
      "t": 477489,
      "e": 61621,
      "ty": 41,
      "x": 33439,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 477589,
      "e": 61721,
      "ty": 2,
      "x": 976,
      "y": 1026
    },
    {
      "t": 477689,
      "e": 61821,
      "ty": 2,
      "x": 975,
      "y": 1024
    },
    {
      "t": 477740,
      "e": 61872,
      "ty": 41,
      "x": 38257,
      "y": 38618,
      "ta": "> p"
    },
    {
      "t": 478785,
      "e": 62917,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 479792,
      "e": 63924,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 219, dom: 826, initialDom: 830",
  "javascriptErrors": []
}