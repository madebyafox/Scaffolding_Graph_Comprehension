var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6bb6caf9095677dad8c763778d4bcba3",
  "created": "2018-05-21T12:15:13.9766071-07:00",
  "lastActivity": "2018-05-21T12:15:57.0246071-07:00",
  "pageViews": [
    {
      "id": "05211416e1dc901b7e7256bf829e468f415e9599",
      "startTime": "2018-05-21T12:15:13.9766071-07:00",
      "endTime": "2018-05-21T12:15:57.0246071-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 43048,
      "engagementTime": 41384,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 43048,
  "engagementTime": 41384,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=W7EBS",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d044eb6d520dacdec7dbde7f83a05223",
  "gdpr": false
}