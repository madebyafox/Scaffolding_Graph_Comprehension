var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05211868428628cf9488e4036e191e07f9c52e34"] = {
  "startTime": "2018-05-21T20:19:18.4983244Z",
  "websitePageUrl": "/16",
  "visitTime": 147914,
  "engagementTime": 115947,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "280f47b87ad02c7e572bb2acb888219a",
    "created": "2018-05-21T20:19:18.4720257+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=FJV2A",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "3a61157936146990010d732fbf7eae01",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/280f47b87ad02c7e572bb2acb888219a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 102,
      "e": 102,
      "ty": 2,
      "x": 566,
      "y": 770
    },
    {
      "t": 252,
      "e": 252,
      "ty": 41,
      "x": 19216,
      "y": 42212,
      "ta": "html > body"
    },
    {
      "t": 536,
      "e": 536,
      "ty": 2,
      "x": 587,
      "y": 770
    },
    {
      "t": 537,
      "e": 537,
      "ty": 41,
      "x": 55070,
      "y": 42212,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 656,
      "e": 656,
      "ty": 2,
      "x": 652,
      "y": 766
    },
    {
      "t": 697,
      "e": 697,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 704,
      "e": 704,
      "ty": 2,
      "x": 653,
      "y": 766
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 62601,
      "y": 41991,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 654,
      "y": 766
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 62601,
      "y": 41880,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 653,
      "y": 756
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 650,
      "y": 746
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 62152,
      "y": 40883,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 643,
      "y": 732
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 625,
      "y": 668
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 57655,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1757,
      "e": 1757,
      "ty": 6,
      "x": 602,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 585,
      "y": 559
    },
    {
      "t": 1891,
      "e": 1891,
      "ty": 7,
      "x": 559,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 559,
      "y": 519
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 551,
      "y": 513
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 51023,
      "y": 42751,
      "ta": "#.strategy > p"
    },
    {
      "t": 2091,
      "e": 2091,
      "ty": 6,
      "x": 548,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 548,
      "y": 524
    },
    {
      "t": 2205,
      "e": 2205,
      "ty": 2,
      "x": 548,
      "y": 542
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 50686,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2302,
      "e": 2302,
      "ty": 2,
      "x": 548,
      "y": 544
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 548,
      "y": 560
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 549,
      "y": 562
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 50798,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2565,
      "e": 2565,
      "ty": 3,
      "x": 549,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2566,
      "e": 2566,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 4,
      "x": 50798,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 5,
      "x": 549,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 593,
      "y": 528
    },
    {
      "t": 3107,
      "e": 3107,
      "ty": 7,
      "x": 645,
      "y": 485,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 814,
      "y": 338
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 2326,
      "y": 13966,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 820,
      "y": 332
    },
    {
      "t": 3503,
      "e": 3503,
      "ty": 41,
      "x": 2397,
      "y": 13894,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10005,
      "e": 8503,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12374,
      "e": 8503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12500,
      "e": 8629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12501,
      "e": 8630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12579,
      "e": 8708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 12588,
      "e": 8717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 12709,
      "e": 8838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12709,
      "e": 8838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12763,
      "e": 8892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 12851,
      "e": 8980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12851,
      "e": 8980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12908,
      "e": 9037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 13044,
      "e": 9173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13045,
      "e": 9174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13155,
      "e": 9284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13155,
      "e": 9284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13195,
      "e": 9324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look "
    },
    {
      "t": 13259,
      "e": 9388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13260,
      "e": 9389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13283,
      "e": 9412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13379,
      "e": 9508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13379,
      "e": 9508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13419,
      "e": 9548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13491,
      "e": 9620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13491,
      "e": 9620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13507,
      "e": 9636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13579,
      "e": 9708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13635,
      "e": 9764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13636,
      "e": 9765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13684,
      "e": 9813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13684,
      "e": 9813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13732,
      "e": 9861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 13771,
      "e": 9900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13812,
      "e": 9941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13812,
      "e": 9941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13884,
      "e": 10013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13885,
      "e": 10014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13932,
      "e": 10061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 13973,
      "e": 10102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14756,
      "e": 10885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14757,
      "e": 10886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14884,
      "e": 11013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 14988,
      "e": 11117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 14989,
      "e": 11118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15067,
      "e": 11196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 15444,
      "e": 11573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15445,
      "e": 11574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15547,
      "e": 11676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15756,
      "e": 11885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 15757,
      "e": 11886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15883,
      "e": 12012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 15940,
      "e": 12069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15940,
      "e": 12069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16019,
      "e": 12148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16091,
      "e": 12220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16092,
      "e": 12221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16179,
      "e": 12308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16396,
      "e": 12525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16451,
      "e": 12580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-aci"
    },
    {
      "t": 16547,
      "e": 12676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16611,
      "e": 12740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-ac"
    },
    {
      "t": 16692,
      "e": 12821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16748,
      "e": 12877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-a"
    },
    {
      "t": 16852,
      "e": 12981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16853,
      "e": 12982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16939,
      "e": 13068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16940,
      "e": 13069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16971,
      "e": 13100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 17044,
      "e": 13173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17540,
      "e": 13669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17540,
      "e": 13669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17651,
      "e": 13780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20005,
      "e": 16134,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27061,
      "e": 18780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27062,
      "e": 18781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27172,
      "e": 18891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27227,
      "e": 18946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27227,
      "e": 18946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27348,
      "e": 19067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27348,
      "e": 19067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27371,
      "e": 19090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 27435,
      "e": 19154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27491,
      "e": 19210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27492,
      "e": 19211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27548,
      "e": 19267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27548,
      "e": 19267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27587,
      "e": 19306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 27643,
      "e": 19362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27732,
      "e": 19451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27732,
      "e": 19451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27780,
      "e": 19499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27780,
      "e": 19499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27835,
      "e": 19554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 27868,
      "e": 19587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27932,
      "e": 19651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27932,
      "e": 19651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28043,
      "e": 19762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28044,
      "e": 19763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28044,
      "e": 19763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28132,
      "e": 19851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28132,
      "e": 19851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28156,
      "e": 19875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 28268,
      "e": 19987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28611,
      "e": 20330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28612,
      "e": 20331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28683,
      "e": 20402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28787,
      "e": 20506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28788,
      "e": 20507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28852,
      "e": 20571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28933,
      "e": 20652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28933,
      "e": 20652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28980,
      "e": 20699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29107,
      "e": 20826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 29107,
      "e": 20826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29227,
      "e": 20946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29228,
      "e": 20947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29243,
      "e": 20962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 29348,
      "e": 21067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31108,
      "e": 22827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31109,
      "e": 22828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31300,
      "e": 23019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31532,
      "e": 23251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31533,
      "e": 23252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31659,
      "e": 23378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31659,
      "e": 23378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31675,
      "e": 23394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 31772,
      "e": 23491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31860,
      "e": 23579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31860,
      "e": 23579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31939,
      "e": 23658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31939,
      "e": 23658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31995,
      "e": 23714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 32027,
      "e": 23746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32100,
      "e": 23819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32101,
      "e": 23820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32187,
      "e": 23906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32188,
      "e": 23907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32203,
      "e": 23922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 32300,
      "e": 24019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32427,
      "e": 24146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32429,
      "e": 24148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32563,
      "e": 24282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 32564,
      "e": 24283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32565,
      "e": 24284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32668,
      "e": 24387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32668,
      "e": 24387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32756,
      "e": 24475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 32804,
      "e": 24523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32804,
      "e": 24523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32811,
      "e": 24530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32891,
      "e": 24610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33235,
      "e": 24954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33235,
      "e": 24954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33396,
      "e": 25115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35036,
      "e": 26755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 35036,
      "e": 26755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35123,
      "e": 26842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;"
    },
    {
      "t": 35564,
      "e": 27283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35564,
      "e": 27283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35660,
      "e": 27379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35684,
      "e": 27403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35684,
      "e": 27403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35780,
      "e": 27499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35780,
      "e": 27499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35835,
      "e": 27554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 35859,
      "e": 27578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35891,
      "e": 27610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35892,
      "e": 27611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35988,
      "e": 27707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35988,
      "e": 27707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36011,
      "e": 27730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 36084,
      "e": 27803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37724,
      "e": 29443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37726,
      "e": 29445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37844,
      "e": 29563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 37955,
      "e": 29674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 37956,
      "e": 29675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38042,
      "e": 29761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 38515,
      "e": 30234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38596,
      "e": 30315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the s"
    },
    {
      "t": 38676,
      "e": 30395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38739,
      "e": 30458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the "
    },
    {
      "t": 38859,
      "e": 30578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 38860,
      "e": 30579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38996,
      "e": 30715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 39004,
      "e": 30723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 39005,
      "e": 30724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39007,
      "e": 30726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 39008,
      "e": 30727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39059,
      "e": 30778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||0-"
    },
    {
      "t": 39059,
      "e": 30778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39467,
      "e": 31186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39540,
      "e": 31188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x0"
    },
    {
      "t": 39618,
      "e": 31266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39691,
      "e": 31339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x"
    },
    {
      "t": 39806,
      "e": 31454,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x"
    },
    {
      "t": 40108,
      "e": 31756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 40108,
      "e": 31756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40179,
      "e": 31827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 40404,
      "e": 32052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40405,
      "e": 32053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40499,
      "e": 32147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40499,
      "e": 32147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40523,
      "e": 32171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||co"
    },
    {
      "t": 40555,
      "e": 32203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40644,
      "e": 32292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40644,
      "e": 32292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40699,
      "e": 32347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40747,
      "e": 32395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40747,
      "e": 32395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40836,
      "e": 32484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40948,
      "e": 32596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40949,
      "e": 32597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41044,
      "e": 32692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41044,
      "e": 32692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41067,
      "e": 32715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 41107,
      "e": 32755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41107,
      "e": 32755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41155,
      "e": 32803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 41202,
      "e": 32850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41203,
      "e": 32851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41219,
      "e": 32867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41332,
      "e": 32980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41333,
      "e": 32981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41339,
      "e": 32987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41442,
      "e": 33090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41443,
      "e": 33091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41483,
      "e": 33131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41555,
      "e": 33203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41579,
      "e": 33227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41581,
      "e": 33229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41684,
      "e": 33332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41835,
      "e": 33483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41837,
      "e": 33485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41915,
      "e": 33563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 41979,
      "e": 33627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 41979,
      "e": 33627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42069,
      "e": 33717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42070,
      "e": 33718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42076,
      "e": 33724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 42147,
      "e": 33795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42178,
      "e": 33826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42179,
      "e": 33827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42243,
      "e": 33891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42243,
      "e": 33891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42299,
      "e": 33947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 42331,
      "e": 33979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42371,
      "e": 34019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42372,
      "e": 34020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42396,
      "e": 34044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42397,
      "e": 34045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42467,
      "e": 34115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 42499,
      "e": 34147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42499,
      "e": 34147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42522,
      "e": 34170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 42611,
      "e": 34259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42611,
      "e": 34259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42643,
      "e": 34291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 42683,
      "e": 34331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42683,
      "e": 34331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42747,
      "e": 34395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 42762,
      "e": 34410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42763,
      "e": 34411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42795,
      "e": 34443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42884,
      "e": 34532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42907,
      "e": 34555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42909,
      "e": 34557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43067,
      "e": 34715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48196,
      "e": 39715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 48198,
      "e": 39717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48267,
      "e": 39786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 48411,
      "e": 39930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48412,
      "e": 39931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48498,
      "e": 40017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48555,
      "e": 40074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 48667,
      "e": 40186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48669,
      "e": 40188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48723,
      "e": 40242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 48779,
      "e": 40298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48835,
      "e": 40354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48836,
      "e": 40355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48900,
      "e": 40419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48900,
      "e": 40419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48901,
      "e": 40420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49007,
      "e": 40526,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For"
    },
    {
      "t": 49012,
      "e": 40531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49019,
      "e": 40538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49021,
      "e": 40540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49122,
      "e": 40641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49380,
      "e": 40899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49381,
      "e": 40900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49459,
      "e": 40978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49547,
      "e": 41066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 49550,
      "e": 41068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49667,
      "e": 41185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 49714,
      "e": 41232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49715,
      "e": 41233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49836,
      "e": 41354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49900,
      "e": 41418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49901,
      "e": 41419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50007,
      "e": 41525,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For exam"
    },
    {
      "t": 50035,
      "e": 41553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50035,
      "e": 41553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50067,
      "e": 41585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mp"
    },
    {
      "t": 50147,
      "e": 41665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50275,
      "e": 41793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50276,
      "e": 41794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50355,
      "e": 41873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 50459,
      "e": 41977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50459,
      "e": 41977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50572,
      "e": 42090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 50572,
      "e": 42090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50587,
      "e": 42105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e,"
    },
    {
      "t": 50667,
      "e": 42185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50667,
      "e": 42185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50691,
      "e": 42209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50807,
      "e": 42325,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, "
    },
    {
      "t": 50851,
      "e": 42369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50971,
      "e": 42489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50972,
      "e": 42490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51043,
      "e": 42561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 51139,
      "e": 42657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51140,
      "e": 42658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51203,
      "e": 42721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51291,
      "e": 42809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51291,
      "e": 42809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51314,
      "e": 42832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51411,
      "e": 42929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 51413,
      "e": 42931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51531,
      "e": 43049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51531,
      "e": 43049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51579,
      "e": 43097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 51611,
      "e": 43129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51612,
      "e": 43130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51667,
      "e": 43185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 51731,
      "e": 43249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51733,
      "e": 43251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51771,
      "e": 43289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51907,
      "e": 43425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51909,
      "e": 43427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51915,
      "e": 43433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52067,
      "e": 43585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52259,
      "e": 43777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 52260,
      "e": 43778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52362,
      "e": 43880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 52363,
      "e": 43881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52427,
      "e": 43945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 52499,
      "e": 44017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52771,
      "e": 44289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52773,
      "e": 44291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52915,
      "e": 44433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 52915,
      "e": 44433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52939,
      "e": 44457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 53059,
      "e": 44577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53420,
      "e": 44938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 53421,
      "e": 44939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53427,
      "e": 44945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53428,
      "e": 44946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53475,
      "e": 44993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,m"
    },
    {
      "t": 53475,
      "e": 44993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53607,
      "e": 45125,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 p,m"
    },
    {
      "t": 53804,
      "e": 45322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53866,
      "e": 45384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 p,"
    },
    {
      "t": 53955,
      "e": 45473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54027,
      "e": 45473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 p"
    },
    {
      "t": 54459,
      "e": 45905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54459,
      "e": 45905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54562,
      "e": 46008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 54571,
      "e": 46017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54571,
      "e": 46017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54692,
      "e": 46138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54731,
      "e": 46177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54732,
      "e": 46178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54787,
      "e": 46233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54788,
      "e": 46234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54858,
      "e": 46304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 54882,
      "e": 46328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55226,
      "e": 46672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55307,
      "e": 46753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm a"
    },
    {
      "t": 55408,
      "e": 46854,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm a"
    },
    {
      "t": 55668,
      "e": 47114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55731,
      "e": 47177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm "
    },
    {
      "t": 55867,
      "e": 47313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55868,
      "e": 47314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56008,
      "e": 47454,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm o"
    },
    {
      "t": 56075,
      "e": 47521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56076,
      "e": 47522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56083,
      "e": 47529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 56106,
      "e": 47552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56207,
      "e": 47653,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm o "
    },
    {
      "t": 56403,
      "e": 47849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56466,
      "e": 47912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm o"
    },
    {
      "t": 56627,
      "e": 48073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56627,
      "e": 48073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56706,
      "e": 48152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56706,
      "e": 48152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56795,
      "e": 48241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 56802,
      "e": 48248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56883,
      "e": 48329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56884,
      "e": 48330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56979,
      "e": 48330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56979,
      "e": 48330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57019,
      "e": 48370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 57083,
      "e": 48434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57139,
      "e": 48490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57140,
      "e": 48491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57227,
      "e": 48578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57227,
      "e": 48578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57251,
      "e": 48602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 57322,
      "e": 48673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57387,
      "e": 48738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 57388,
      "e": 48739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57531,
      "e": 48882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 57532,
      "e": 48883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57547,
      "e": 48898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x-"
    },
    {
      "t": 57635,
      "e": 48986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57795,
      "e": 49146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57796,
      "e": 49147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57891,
      "e": 49242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 58043,
      "e": 49394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 58044,
      "e": 49395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58194,
      "e": 49545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 58228,
      "e": 49579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58228,
      "e": 49579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58308,
      "e": 49659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58564,
      "e": 49915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58627,
      "e": 49978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-ac"
    },
    {
      "t": 58707,
      "e": 50058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58795,
      "e": 50146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-a"
    },
    {
      "t": 58820,
      "e": 50171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 58820,
      "e": 50171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58922,
      "e": 50273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 58931,
      "e": 50282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58931,
      "e": 50282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59019,
      "e": 50370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59043,
      "e": 50394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59044,
      "e": 50395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59123,
      "e": 50474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59363,
      "e": 50714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59364,
      "e": 50715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59459,
      "e": 50810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59482,
      "e": 50833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59482,
      "e": 50833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59563,
      "e": 50914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59564,
      "e": 50915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59595,
      "e": 50946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 59642,
      "e": 50993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59675,
      "e": 51026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 59675,
      "e": 51026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59747,
      "e": 51098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59747,
      "e": 51098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59779,
      "e": 51130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 59826,
      "e": 51177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59883,
      "e": 51234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59884,
      "e": 51235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59955,
      "e": 51306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59955,
      "e": 51306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59995,
      "e": 51346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 60027,
      "e": 51378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60091,
      "e": 51442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60092,
      "e": 51443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60162,
      "e": 51513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60164,
      "e": 51515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60187,
      "e": 51538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 60228,
      "e": 51579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60229,
      "e": 51580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60258,
      "e": 51609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60314,
      "e": 51665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60386,
      "e": 51737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60387,
      "e": 51738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60459,
      "e": 51810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 60555,
      "e": 51906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60556,
      "e": 51907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60627,
      "e": 51978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60698,
      "e": 52049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60699,
      "e": 52050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60763,
      "e": 52114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 61004,
      "e": 52355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61067,
      "e": 52418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then lo"
    },
    {
      "t": 61164,
      "e": 52515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61226,
      "e": 52515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then l"
    },
    {
      "t": 61315,
      "e": 52604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61387,
      "e": 52676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then "
    },
    {
      "t": 61475,
      "e": 52764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61546,
      "e": 52835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then"
    },
    {
      "t": 62171,
      "e": 53460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62172,
      "e": 53461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62283,
      "e": 53572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63067,
      "e": 54356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 63068,
      "e": 54357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63195,
      "e": 54484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 63195,
      "e": 54484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63195,
      "e": 54484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63283,
      "e": 54572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63395,
      "e": 54684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 63396,
      "e": 54685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63467,
      "e": 54756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 63539,
      "e": 54828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 63539,
      "e": 54828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63547,
      "e": 54836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63547,
      "e": 54836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63603,
      "e": 54892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lo"
    },
    {
      "t": 63603,
      "e": 54892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63724,
      "e": 55013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63724,
      "e": 55013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63811,
      "e": 55100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63867,
      "e": 55156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 63867,
      "e": 55156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63987,
      "e": 55276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64315,
      "e": 55604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64378,
      "e": 55667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then folloo"
    },
    {
      "t": 64467,
      "e": 55756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64555,
      "e": 55844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follo"
    },
    {
      "t": 64611,
      "e": 55900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64611,
      "e": 55900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64730,
      "e": 56019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64762,
      "e": 56051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64763,
      "e": 56052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64876,
      "e": 56165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65227,
      "e": 56516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65227,
      "e": 56516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65323,
      "e": 56612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 65387,
      "e": 56676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65390,
      "e": 56679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65531,
      "e": 56820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65531,
      "e": 56820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65539,
      "e": 56821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 65643,
      "e": 56925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65867,
      "e": 57149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65868,
      "e": 57150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65947,
      "e": 57229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 66027,
      "e": 57309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66027,
      "e": 57309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66099,
      "e": 57381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66171,
      "e": 57453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66172,
      "e": 57454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66250,
      "e": 57532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66251,
      "e": 57533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66259,
      "e": 57541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 66387,
      "e": 57669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66395,
      "e": 57677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66396,
      "e": 57678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66490,
      "e": 57772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 66522,
      "e": 57804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 66522,
      "e": 57804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66635,
      "e": 57917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66636,
      "e": 57918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66642,
      "e": 57924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 66707,
      "e": 57989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66747,
      "e": 58029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66747,
      "e": 58029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66855,
      "e": 58137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66856,
      "e": 58138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66903,
      "e": 58185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 66967,
      "e": 58249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 66968,
      "e": 58250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66975,
      "e": 58257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 67063,
      "e": 58345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 67063,
      "e": 58345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67143,
      "e": 58425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67143,
      "e": 58425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67150,
      "e": 58432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p "
    },
    {
      "t": 67175,
      "e": 58457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67231,
      "e": 58513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67255,
      "e": 58537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67256,
      "e": 58538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67335,
      "e": 58617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67335,
      "e": 58617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67375,
      "e": 58657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 67423,
      "e": 58705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67471,
      "e": 58753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 67472,
      "e": 58754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67551,
      "e": 58833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67551,
      "e": 58833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67582,
      "e": 58864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 67639,
      "e": 58921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67792,
      "e": 59074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67792,
      "e": 59074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67846,
      "e": 59128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67846,
      "e": 59128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67895,
      "e": 59177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 67951,
      "e": 59233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67966,
      "e": 59248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 67967,
      "e": 59249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68046,
      "e": 59328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 68152,
      "e": 59434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68152,
      "e": 59434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68199,
      "e": 59481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68199,
      "e": 59481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68263,
      "e": 59545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 68351,
      "e": 59633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 68352,
      "e": 59634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68358,
      "e": 59640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 68438,
      "e": 59720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68454,
      "e": 59736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 68455,
      "e": 59737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68567,
      "e": 59849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 68568,
      "e": 59850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68639,
      "e": 59921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 68695,
      "e": 59977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68696,
      "e": 59978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68743,
      "e": 60025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68824,
      "e": 60106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68910,
      "e": 60192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 68910,
      "e": 60192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68999,
      "e": 60281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68999,
      "e": 60281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69063,
      "e": 60345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69063,
      "e": 60345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69095,
      "e": 60377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rea"
    },
    {
      "t": 69135,
      "e": 60417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69215,
      "e": 60497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69328,
      "e": 60610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 69328,
      "e": 60610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69414,
      "e": 60696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 69462,
      "e": 60744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69463,
      "e": 60745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69575,
      "e": 60857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69576,
      "e": 60858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69598,
      "e": 60880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 69694,
      "e": 60976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70424,
      "e": 61706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70424,
      "e": 61706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70510,
      "e": 61792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 70510,
      "e": 61792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70542,
      "e": 61824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 70607,
      "e": 61889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70631,
      "e": 61913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70631,
      "e": 61913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70671,
      "e": 61953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70672,
      "e": 61954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70734,
      "e": 62016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 70783,
      "e": 62065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 70783,
      "e": 62065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70830,
      "e": 62112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 70903,
      "e": 62185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70904,
      "e": 62186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70910,
      "e": 62192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 71011,
      "e": 62192,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the po"
    },
    {
      "t": 71022,
      "e": 62203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71039,
      "e": 62220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71039,
      "e": 62220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71143,
      "e": 62324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 71511,
      "e": 62692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71575,
      "e": 62756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the po"
    },
    {
      "t": 71721,
      "e": 62902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71721,
      "e": 62902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71790,
      "e": 62971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71791,
      "e": 62972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71846,
      "e": 63027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 71886,
      "e": 63067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71887,
      "e": 63068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71926,
      "e": 63107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72007,
      "e": 63188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72063,
      "e": 63244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72064,
      "e": 63245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72190,
      "e": 63371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 72207,
      "e": 63388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72207,
      "e": 63388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72311,
      "e": 63492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72558,
      "e": 63739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72559,
      "e": 63740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72647,
      "e": 63828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72736,
      "e": 63917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72737,
      "e": 63918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72839,
      "e": 64020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 72839,
      "e": 64020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72862,
      "e": 64043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 72943,
      "e": 64124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72975,
      "e": 64156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72975,
      "e": 64156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73079,
      "e": 64260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73079,
      "e": 64260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73111,
      "e": 64292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 73183,
      "e": 64364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73184,
      "e": 64365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73190,
      "e": 64371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73303,
      "e": 64484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73310,
      "e": 64491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 73311,
      "e": 64492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73399,
      "e": 64580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 73479,
      "e": 64660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 73481,
      "e": 64662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73611,
      "e": 64792,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those po"
    },
    {
      "t": 73622,
      "e": 64803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 73630,
      "e": 64811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73631,
      "e": 64812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73639,
      "e": 64820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73639,
      "e": 64820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73703,
      "e": 64884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 73807,
      "e": 64988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73878,
      "e": 65059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73879,
      "e": 65060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73991,
      "e": 65172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74039,
      "e": 65220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74039,
      "e": 65220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74167,
      "e": 65348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 74215,
      "e": 65396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74215,
      "e": 65396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74327,
      "e": 65397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74790,
      "e": 65860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74790,
      "e": 65860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74935,
      "e": 66005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 75159,
      "e": 66229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75239,
      "e": 66309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 75239,
      "e": 66309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75246,
      "e": 66316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points s"
    },
    {
      "t": 75359,
      "e": 66429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75399,
      "e": 66469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75399,
      "e": 66469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75463,
      "e": 66533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75463,
      "e": 66533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75503,
      "e": 66573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 75613,
      "e": 66683,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points sta"
    },
    {
      "t": 75655,
      "e": 66725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75656,
      "e": 66726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75663,
      "e": 66733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 75742,
      "e": 66812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75839,
      "e": 66909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75839,
      "e": 66909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75959,
      "e": 67029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75960,
      "e": 67030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75967,
      "e": 67037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 76071,
      "e": 67141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76095,
      "e": 67165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76095,
      "e": 67165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76167,
      "e": 67237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76167,
      "e": 67237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76238,
      "e": 67308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 76286,
      "e": 67356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76295,
      "e": 67365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76295,
      "e": 67365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76366,
      "e": 67436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76447,
      "e": 67517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 76448,
      "e": 67518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76583,
      "e": 67653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 76583,
      "e": 67653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76607,
      "e": 67677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 76719,
      "e": 67789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76880,
      "e": 67950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76880,
      "e": 67950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76998,
      "e": 68068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77031,
      "e": 68101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 77031,
      "e": 68101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77135,
      "e": 68205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 77255,
      "e": 68325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 77256,
      "e": 68326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77367,
      "e": 68437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 77768,
      "e": 68838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 77768,
      "e": 68838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77846,
      "e": 68916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 77958,
      "e": 69028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77959,
      "e": 69029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78102,
      "e": 69172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78303,
      "e": 69373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 78392,
      "e": 69462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 78393,
      "e": 69463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78463,
      "e": 69533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 78527,
      "e": 69597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78583,
      "e": 69653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 78584,
      "e": 69654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78678,
      "e": 69748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 78742,
      "e": 69812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78742,
      "e": 69812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78854,
      "e": 69924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78863,
      "e": 69933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 78863,
      "e": 69933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78967,
      "e": 70037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 79023,
      "e": 70093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79024,
      "e": 70094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79079,
      "e": 70149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 79079,
      "e": 70149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79086,
      "e": 70156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||or"
    },
    {
      "t": 79199,
      "e": 70269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79200,
      "e": 70270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79207,
      "e": 70277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79295,
      "e": 70365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79551,
      "e": 70621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 79551,
      "e": 70621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79671,
      "e": 70741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 79672,
      "e": 70741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79727,
      "e": 70796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 79822,
      "e": 70891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79863,
      "e": 70932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79863,
      "e": 70932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80012,
      "e": 71081,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 "
    },
    {
      "t": 80047,
      "e": 71116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80222,
      "e": 71291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 80222,
      "e": 71291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80294,
      "e": 71363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 80412,
      "e": 71481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 p"
    },
    {
      "t": 80415,
      "e": 71484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 80416,
      "e": 71485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80551,
      "e": 71620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 80599,
      "e": 71668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80609,
      "e": 71678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80703,
      "e": 71772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80751,
      "e": 71820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 80751,
      "e": 71820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80823,
      "e": 71892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 80904,
      "e": 71973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80905,
      "e": 71974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80958,
      "e": 72027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80958,
      "e": 72027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81006,
      "e": 72075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 81071,
      "e": 72140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81095,
      "e": 72164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 81095,
      "e": 72164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81159,
      "e": 72228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81159,
      "e": 72228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81206,
      "e": 72275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wo"
    },
    {
      "t": 81214,
      "e": 72283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 81214,
      "e": 72283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81254,
      "e": 72323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 81310,
      "e": 72379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81412,
      "e": 72481,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 pm it wou"
    },
    {
      "t": 81415,
      "e": 72484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 81416,
      "e": 72485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81510,
      "e": 72579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 81612,
      "e": 72579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 pm it woul"
    },
    {
      "t": 81975,
      "e": 72942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 81976,
      "e": 72943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82079,
      "e": 73046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 82087,
      "e": 73054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82088,
      "e": 73055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82198,
      "e": 73165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82223,
      "e": 73190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 82223,
      "e": 73190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82319,
      "e": 73286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 82431,
      "e": 73398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 82431,
      "e": 73398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82558,
      "e": 73525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 83031,
      "e": 73998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83032,
      "e": 73999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83142,
      "e": 74109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 85223,
      "e": 76190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 85224,
      "e": 76191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85286,
      "e": 76253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85286,
      "e": 76253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85318,
      "e": 76285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 85375,
      "e": 76342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 85375,
      "e": 76342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85439,
      "e": 76406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85479,
      "e": 76446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85551,
      "e": 76518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 85552,
      "e": 76519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85662,
      "e": 76629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 85759,
      "e": 76726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85759,
      "e": 76726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85854,
      "e": 76821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 85935,
      "e": 76902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 85935,
      "e": 76902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86055,
      "e": 77022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 86056,
      "e": 77023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86056,
      "e": 77023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86175,
      "e": 77142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 86310,
      "e": 77277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 86567,
      "e": 77534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 86567,
      "e": 77534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86686,
      "e": 77653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 86727,
      "e": 77694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87063,
      "e": 78030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87063,
      "e": 78030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87174,
      "e": 78141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87198,
      "e": 78165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 87199,
      "e": 78166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87319,
      "e": 78286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 87320,
      "e": 78287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87334,
      "e": 78301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 87406,
      "e": 78373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87439,
      "e": 78406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 87439,
      "e": 78406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87534,
      "e": 78501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 87542,
      "e": 78509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87544,
      "e": 78511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87647,
      "e": 78614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87711,
      "e": 78678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 87847,
      "e": 78814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 87847,
      "e": 78814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87942,
      "e": 78909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 87958,
      "e": 78925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88775,
      "e": 79742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 88776,
      "e": 79743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88847,
      "e": 79814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 89608,
      "e": 80575,
      "ty": 2,
      "x": 810,
      "y": 361
    },
    {
      "t": 89651,
      "e": 80618,
      "ty": 6,
      "x": 633,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89701,
      "e": 80668,
      "ty": 7,
      "x": 534,
      "y": 622,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89708,
      "e": 80675,
      "ty": 2,
      "x": 534,
      "y": 622
    },
    {
      "t": 89759,
      "e": 80726,
      "ty": 41,
      "x": 42255,
      "y": 34900,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 89809,
      "e": 80776,
      "ty": 2,
      "x": 452,
      "y": 638
    },
    {
      "t": 89852,
      "e": 80819,
      "ty": 6,
      "x": 415,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 89908,
      "e": 80875,
      "ty": 2,
      "x": 410,
      "y": 656
    },
    {
      "t": 90009,
      "e": 80976,
      "ty": 2,
      "x": 397,
      "y": 669
    },
    {
      "t": 90009,
      "e": 80976,
      "ty": 41,
      "x": 31897,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 90009,
      "e": 80976,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90109,
      "e": 81076,
      "ty": 2,
      "x": 397,
      "y": 671
    },
    {
      "t": 90155,
      "e": 81122,
      "ty": 3,
      "x": 397,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 90155,
      "e": 81122,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 pm it would be shifts B and F."
    },
    {
      "t": 90156,
      "e": 81123,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90156,
      "e": 81123,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 90242,
      "e": 81209,
      "ty": 4,
      "x": 31897,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 90254,
      "e": 81221,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 90256,
      "e": 81223,
      "ty": 5,
      "x": 397,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 90265,
      "e": 81232,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 90268,
      "e": 81235,
      "ty": 41,
      "x": 13396,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 91008,
      "e": 81975,
      "ty": 2,
      "x": 429,
      "y": 678
    },
    {
      "t": 91008,
      "e": 81975,
      "ty": 41,
      "x": 14498,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 91109,
      "e": 82076,
      "ty": 2,
      "x": 538,
      "y": 672
    },
    {
      "t": 91263,
      "e": 82230,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 91265,
      "e": 82232,
      "ty": 41,
      "x": 18251,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 91608,
      "e": 82575,
      "ty": 2,
      "x": 549,
      "y": 669
    },
    {
      "t": 91709,
      "e": 82676,
      "ty": 2,
      "x": 667,
      "y": 652
    },
    {
      "t": 91759,
      "e": 82726,
      "ty": 41,
      "x": 24209,
      "y": 35177,
      "ta": "html > body"
    },
    {
      "t": 91811,
      "e": 82778,
      "ty": 2,
      "x": 850,
      "y": 611
    },
    {
      "t": 91870,
      "e": 82837,
      "ty": 6,
      "x": 991,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91909,
      "e": 82876,
      "ty": 2,
      "x": 1007,
      "y": 564
    },
    {
      "t": 92009,
      "e": 82976,
      "ty": 2,
      "x": 1011,
      "y": 555
    },
    {
      "t": 92009,
      "e": 82976,
      "ty": 41,
      "x": 43906,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92208,
      "e": 83175,
      "ty": 2,
      "x": 1011,
      "y": 557
    },
    {
      "t": 92259,
      "e": 83226,
      "ty": 41,
      "x": 43906,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92267,
      "e": 83234,
      "ty": 3,
      "x": 1011,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92269,
      "e": 83236,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92347,
      "e": 83314,
      "ty": 4,
      "x": 43906,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92348,
      "e": 83315,
      "ty": 5,
      "x": 1011,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93134,
      "e": 84101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 93134,
      "e": 84101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93222,
      "e": 84189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 93222,
      "e": 84189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93254,
      "e": 84221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 93350,
      "e": 84317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 93971,
      "e": 84938,
      "ty": 7,
      "x": 1029,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94009,
      "e": 84976,
      "ty": 2,
      "x": 1029,
      "y": 624
    },
    {
      "t": 94009,
      "e": 84976,
      "ty": 41,
      "x": 47799,
      "y": 53832,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 94089,
      "e": 85056,
      "ty": 6,
      "x": 1024,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94108,
      "e": 85075,
      "ty": 2,
      "x": 1021,
      "y": 654
    },
    {
      "t": 94209,
      "e": 85176,
      "ty": 2,
      "x": 1018,
      "y": 661
    },
    {
      "t": 94259,
      "e": 85226,
      "ty": 41,
      "x": 45420,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94371,
      "e": 85338,
      "ty": 3,
      "x": 1018,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94373,
      "e": 85340,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 94373,
      "e": 85340,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94374,
      "e": 85341,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94450,
      "e": 85417,
      "ty": 4,
      "x": 45420,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94451,
      "e": 85418,
      "ty": 5,
      "x": 1018,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95575,
      "e": 86542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 95735,
      "e": 86702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 95736,
      "e": 86703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95902,
      "e": 86869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 95903,
      "e": 86870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95918,
      "e": 86885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 96031,
      "e": 86998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 96143,
      "e": 87110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 96143,
      "e": 87110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96222,
      "e": 87189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 96246,
      "e": 87213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 97158,
      "e": 88125,
      "ty": 7,
      "x": 1017,
      "y": 676,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97158,
      "e": 88125,
      "ty": 6,
      "x": 1017,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97209,
      "e": 88176,
      "ty": 2,
      "x": 1014,
      "y": 690
    },
    {
      "t": 97259,
      "e": 88226,
      "ty": 41,
      "x": 60856,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97309,
      "e": 88276,
      "ty": 2,
      "x": 1013,
      "y": 693
    },
    {
      "t": 97409,
      "e": 88376,
      "ty": 2,
      "x": 1007,
      "y": 694
    },
    {
      "t": 97509,
      "e": 88476,
      "ty": 41,
      "x": 57248,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97919,
      "e": 88886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 97990,
      "e": 88957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 98078,
      "e": 89045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 98159,
      "e": 89126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 98719,
      "e": 89686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 98720,
      "e": 89687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98766,
      "e": 89733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 99184,
      "e": 90151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 99184,
      "e": 90151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99278,
      "e": 90245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 99326,
      "e": 90293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 99326,
      "e": 90293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99438,
      "e": 90405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 99502,
      "e": 90469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 99502,
      "e": 90469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99567,
      "e": 90534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 99687,
      "e": 90654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 99687,
      "e": 90654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99750,
      "e": 90717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 99750,
      "e": 90717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99782,
      "e": 90749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 99854,
      "e": 90821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 99894,
      "e": 90861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 99958,
      "e": 90925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 99960,
      "e": 90927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100009,
      "e": 90976,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100046,
      "e": 91013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 100070,
      "e": 91037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 100246,
      "e": 91213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 100246,
      "e": 91213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100334,
      "e": 91301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 100766,
      "e": 91733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 100854,
      "e": 91821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United S"
    },
    {
      "t": 100910,
      "e": 91877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 100910,
      "e": 91877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101022,
      "e": 91989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 101023,
      "e": 91990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101094,
      "e": 92061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 101191,
      "e": 92158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 101191,
      "e": 92158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101198,
      "e": 92165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 101366,
      "e": 92333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 101367,
      "e": 92334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101422,
      "e": 92389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 101502,
      "e": 92469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 101663,
      "e": 92630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 101717,
      "e": 92684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stae"
    },
    {
      "t": 101806,
      "e": 92773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 101894,
      "e": 92861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Sta"
    },
    {
      "t": 101911,
      "e": 92878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 101911,
      "e": 92878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102005,
      "e": 92972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 102006,
      "e": 92973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102094,
      "e": 93061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 102102,
      "e": 93069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 102103,
      "e": 93070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102182,
      "e": 93149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 102247,
      "e": 93214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 102247,
      "e": 93214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102262,
      "e": 93229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 102366,
      "e": 93333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 102374,
      "e": 93341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 102374,
      "e": 93341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102470,
      "e": 93437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 102470,
      "e": 93437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 102471,
      "e": 93438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102551,
      "e": 93518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 102552,
      "e": 93519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102614,
      "e": 93581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f "
    },
    {
      "t": 102662,
      "e": 93629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 102710,
      "e": 93677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 102783,
      "e": 93750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 102783,
      "e": 93750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102830,
      "e": 93797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 102903,
      "e": 93870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 102904,
      "e": 93871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 102904,
      "e": 93871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103010,
      "e": 93977,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of Am"
    },
    {
      "t": 103030,
      "e": 93997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 103038,
      "e": 94005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 103039,
      "e": 94006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103126,
      "e": 94093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 103127,
      "e": 94094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103166,
      "e": 94133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 103207,
      "e": 94174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 103208,
      "e": 94175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 103209,
      "e": 94176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103317,
      "e": 94284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 103366,
      "e": 94333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 103366,
      "e": 94333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103463,
      "e": 94430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 103463,
      "e": 94430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103470,
      "e": 94437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ca"
    },
    {
      "t": 103582,
      "e": 94549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 104108,
      "e": 95075,
      "ty": 3,
      "x": 1007,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104108,
      "e": 95075,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 104109,
      "e": 95076,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104109,
      "e": 95076,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104194,
      "e": 95161,
      "ty": 4,
      "x": 57248,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104195,
      "e": 95162,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104195,
      "e": 95162,
      "ty": 5,
      "x": 1007,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104195,
      "e": 95162,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 105208,
      "e": 96175,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 105809,
      "e": 96776,
      "ty": 2,
      "x": 1005,
      "y": 694
    },
    {
      "t": 105909,
      "e": 96876,
      "ty": 2,
      "x": 1003,
      "y": 637
    },
    {
      "t": 106009,
      "e": 96976,
      "ty": 2,
      "x": 1021,
      "y": 467
    },
    {
      "t": 106009,
      "e": 96976,
      "ty": 41,
      "x": 47364,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 106509,
      "e": 97476,
      "ty": 2,
      "x": 925,
      "y": 416
    },
    {
      "t": 106509,
      "e": 97476,
      "ty": 41,
      "x": 24581,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 106609,
      "e": 97576,
      "ty": 2,
      "x": 885,
      "y": 391
    },
    {
      "t": 106651,
      "e": 97618,
      "ty": 6,
      "x": 838,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 106666,
      "e": 97633,
      "ty": 7,
      "x": 826,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 106668,
      "e": 97635,
      "ty": 6,
      "x": 826,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 106681,
      "e": 97648,
      "ty": 7,
      "x": 823,
      "y": 283,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 106709,
      "e": 97676,
      "ty": 2,
      "x": 814,
      "y": 254
    },
    {
      "t": 106759,
      "e": 97726,
      "ty": 41,
      "x": 27446,
      "y": 12187,
      "ta": "html > body"
    },
    {
      "t": 106809,
      "e": 97776,
      "ty": 2,
      "x": 805,
      "y": 218
    },
    {
      "t": 106910,
      "e": 97877,
      "ty": 2,
      "x": 807,
      "y": 213
    },
    {
      "t": 106951,
      "e": 97878,
      "ty": 6,
      "x": 831,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106966,
      "e": 97893,
      "ty": 7,
      "x": 838,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107009,
      "e": 97936,
      "ty": 2,
      "x": 842,
      "y": 252
    },
    {
      "t": 107009,
      "e": 97936,
      "ty": 41,
      "x": 4883,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 107110,
      "e": 98037,
      "ty": 2,
      "x": 843,
      "y": 254
    },
    {
      "t": 107260,
      "e": 98187,
      "ty": 41,
      "x": 5121,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 107309,
      "e": 98236,
      "ty": 2,
      "x": 841,
      "y": 249
    },
    {
      "t": 107366,
      "e": 98293,
      "ty": 6,
      "x": 839,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107409,
      "e": 98336,
      "ty": 2,
      "x": 837,
      "y": 240
    },
    {
      "t": 107510,
      "e": 98437,
      "ty": 2,
      "x": 835,
      "y": 237
    },
    {
      "t": 107510,
      "e": 98437,
      "ty": 41,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107609,
      "e": 98536,
      "ty": 2,
      "x": 834,
      "y": 237
    },
    {
      "t": 107684,
      "e": 98611,
      "ty": 3,
      "x": 834,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107684,
      "e": 98611,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107759,
      "e": 98686,
      "ty": 41,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107794,
      "e": 98721,
      "ty": 4,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107794,
      "e": 98721,
      "ty": 5,
      "x": 834,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107794,
      "e": 98721,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 108150,
      "e": 99077,
      "ty": 7,
      "x": 837,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108209,
      "e": 99136,
      "ty": 2,
      "x": 853,
      "y": 281
    },
    {
      "t": 108259,
      "e": 99186,
      "ty": 41,
      "x": 12403,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 108309,
      "e": 99236,
      "ty": 2,
      "x": 865,
      "y": 312
    },
    {
      "t": 108409,
      "e": 99336,
      "ty": 2,
      "x": 875,
      "y": 336
    },
    {
      "t": 108509,
      "e": 99436,
      "ty": 2,
      "x": 890,
      "y": 368
    },
    {
      "t": 108509,
      "e": 99436,
      "ty": 41,
      "x": 16275,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 108610,
      "e": 99537,
      "ty": 2,
      "x": 891,
      "y": 404
    },
    {
      "t": 108709,
      "e": 99636,
      "ty": 2,
      "x": 881,
      "y": 422
    },
    {
      "t": 108759,
      "e": 99686,
      "ty": 41,
      "x": 13427,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 108810,
      "e": 99737,
      "ty": 2,
      "x": 872,
      "y": 436
    },
    {
      "t": 108909,
      "e": 99836,
      "ty": 2,
      "x": 861,
      "y": 462
    },
    {
      "t": 109010,
      "e": 99937,
      "ty": 2,
      "x": 857,
      "y": 476
    },
    {
      "t": 109010,
      "e": 99937,
      "ty": 41,
      "x": 37606,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 109110,
      "e": 100037,
      "ty": 2,
      "x": 856,
      "y": 480
    },
    {
      "t": 109210,
      "e": 100137,
      "ty": 2,
      "x": 849,
      "y": 478
    },
    {
      "t": 109259,
      "e": 100186,
      "ty": 41,
      "x": 23865,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 109301,
      "e": 100228,
      "ty": 6,
      "x": 839,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109310,
      "e": 100237,
      "ty": 2,
      "x": 839,
      "y": 473
    },
    {
      "t": 109409,
      "e": 100336,
      "ty": 2,
      "x": 835,
      "y": 470
    },
    {
      "t": 109509,
      "e": 100436,
      "ty": 2,
      "x": 831,
      "y": 468
    },
    {
      "t": 109510,
      "e": 100437,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109588,
      "e": 100515,
      "ty": 3,
      "x": 831,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109589,
      "e": 100516,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 109590,
      "e": 100517,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109698,
      "e": 100625,
      "ty": 4,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109698,
      "e": 100625,
      "ty": 5,
      "x": 831,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 109699,
      "e": 100626,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 110002,
      "e": 100929,
      "ty": 7,
      "x": 834,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 110009,
      "e": 100936,
      "ty": 2,
      "x": 834,
      "y": 477
    },
    {
      "t": 110010,
      "e": 100937,
      "ty": 41,
      "x": 13295,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 110109,
      "e": 101036,
      "ty": 2,
      "x": 855,
      "y": 545
    },
    {
      "t": 110210,
      "e": 101137,
      "ty": 2,
      "x": 858,
      "y": 567
    },
    {
      "t": 110259,
      "e": 101186,
      "ty": 41,
      "x": 9630,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 110309,
      "e": 101236,
      "ty": 2,
      "x": 865,
      "y": 604
    },
    {
      "t": 110409,
      "e": 101336,
      "ty": 2,
      "x": 866,
      "y": 608
    },
    {
      "t": 110510,
      "e": 101437,
      "ty": 2,
      "x": 866,
      "y": 614
    },
    {
      "t": 110510,
      "e": 101437,
      "ty": 41,
      "x": 10579,
      "y": 33851,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 110610,
      "e": 101537,
      "ty": 2,
      "x": 867,
      "y": 623
    },
    {
      "t": 110709,
      "e": 101636,
      "ty": 2,
      "x": 869,
      "y": 626
    },
    {
      "t": 110760,
      "e": 101687,
      "ty": 41,
      "x": 12952,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 110809,
      "e": 101736,
      "ty": 2,
      "x": 929,
      "y": 637
    },
    {
      "t": 110910,
      "e": 101837,
      "ty": 2,
      "x": 1067,
      "y": 637
    },
    {
      "t": 111010,
      "e": 101837,
      "ty": 2,
      "x": 1128,
      "y": 642
    },
    {
      "t": 111012,
      "e": 101839,
      "ty": 41,
      "x": 38570,
      "y": 35121,
      "ta": "html > body"
    },
    {
      "t": 111109,
      "e": 101936,
      "ty": 2,
      "x": 1066,
      "y": 666
    },
    {
      "t": 111210,
      "e": 102037,
      "ty": 2,
      "x": 1023,
      "y": 672
    },
    {
      "t": 111260,
      "e": 102087,
      "ty": 41,
      "x": 48753,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 111309,
      "e": 102136,
      "ty": 2,
      "x": 973,
      "y": 678
    },
    {
      "t": 111410,
      "e": 102237,
      "ty": 2,
      "x": 930,
      "y": 678
    },
    {
      "t": 111510,
      "e": 102337,
      "ty": 2,
      "x": 907,
      "y": 678
    },
    {
      "t": 111510,
      "e": 102337,
      "ty": 41,
      "x": 22977,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 111610,
      "e": 102437,
      "ty": 2,
      "x": 897,
      "y": 680
    },
    {
      "t": 111709,
      "e": 102536,
      "ty": 2,
      "x": 895,
      "y": 685
    },
    {
      "t": 111760,
      "e": 102587,
      "ty": 41,
      "x": 16987,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 111809,
      "e": 102636,
      "ty": 2,
      "x": 893,
      "y": 696
    },
    {
      "t": 111909,
      "e": 102736,
      "ty": 2,
      "x": 893,
      "y": 708
    },
    {
      "t": 112009,
      "e": 102836,
      "ty": 2,
      "x": 893,
      "y": 718
    },
    {
      "t": 112009,
      "e": 102836,
      "ty": 41,
      "x": 16987,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 112110,
      "e": 102937,
      "ty": 2,
      "x": 894,
      "y": 725
    },
    {
      "t": 112210,
      "e": 103037,
      "ty": 2,
      "x": 898,
      "y": 740
    },
    {
      "t": 112259,
      "e": 103086,
      "ty": 41,
      "x": 18173,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 112310,
      "e": 103137,
      "ty": 2,
      "x": 879,
      "y": 744
    },
    {
      "t": 112409,
      "e": 103236,
      "ty": 2,
      "x": 859,
      "y": 744
    },
    {
      "t": 112509,
      "e": 103336,
      "ty": 2,
      "x": 847,
      "y": 740
    },
    {
      "t": 112510,
      "e": 103337,
      "ty": 41,
      "x": 6419,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 112587,
      "e": 103414,
      "ty": 6,
      "x": 839,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112609,
      "e": 103436,
      "ty": 2,
      "x": 839,
      "y": 735
    },
    {
      "t": 112710,
      "e": 103537,
      "ty": 2,
      "x": 833,
      "y": 732
    },
    {
      "t": 112759,
      "e": 103586,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112810,
      "e": 103637,
      "ty": 2,
      "x": 832,
      "y": 731
    },
    {
      "t": 112843,
      "e": 103670,
      "ty": 3,
      "x": 832,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112844,
      "e": 103671,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 112845,
      "e": 103672,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112962,
      "e": 103789,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112962,
      "e": 103789,
      "ty": 5,
      "x": 832,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112963,
      "e": 103790,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 113455,
      "e": 104282,
      "ty": 7,
      "x": 838,
      "y": 716,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 113509,
      "e": 104336,
      "ty": 2,
      "x": 849,
      "y": 682
    },
    {
      "t": 113509,
      "e": 104336,
      "ty": 41,
      "x": 7404,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 113609,
      "e": 104436,
      "ty": 2,
      "x": 851,
      "y": 666
    },
    {
      "t": 113760,
      "e": 104587,
      "ty": 41,
      "x": 8713,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 113809,
      "e": 104636,
      "ty": 2,
      "x": 863,
      "y": 749
    },
    {
      "t": 113909,
      "e": 104736,
      "ty": 2,
      "x": 882,
      "y": 798
    },
    {
      "t": 114009,
      "e": 104836,
      "ty": 2,
      "x": 897,
      "y": 831
    },
    {
      "t": 114009,
      "e": 104836,
      "ty": 41,
      "x": 17936,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 114108,
      "e": 104935,
      "ty": 2,
      "x": 906,
      "y": 858
    },
    {
      "t": 114208,
      "e": 105035,
      "ty": 2,
      "x": 899,
      "y": 909
    },
    {
      "t": 114259,
      "e": 105086,
      "ty": 41,
      "x": 16512,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 114310,
      "e": 105137,
      "ty": 2,
      "x": 887,
      "y": 930
    },
    {
      "t": 114409,
      "e": 105236,
      "ty": 2,
      "x": 859,
      "y": 950
    },
    {
      "t": 114509,
      "e": 105336,
      "ty": 2,
      "x": 837,
      "y": 954
    },
    {
      "t": 114510,
      "e": 105337,
      "ty": 41,
      "x": 12601,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 114790,
      "e": 105338,
      "ty": 6,
      "x": 837,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 114810,
      "e": 105358,
      "ty": 2,
      "x": 837,
      "y": 957
    },
    {
      "t": 115009,
      "e": 105557,
      "ty": 41,
      "x": 53325,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115011,
      "e": 105559,
      "ty": 3,
      "x": 837,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115012,
      "e": 105560,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 115013,
      "e": 105561,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115113,
      "e": 105661,
      "ty": 4,
      "x": 53325,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115114,
      "e": 105662,
      "ty": 5,
      "x": 837,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115115,
      "e": 105663,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 115308,
      "e": 105856,
      "ty": 2,
      "x": 837,
      "y": 966
    },
    {
      "t": 115321,
      "e": 105869,
      "ty": 7,
      "x": 837,
      "y": 976,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115339,
      "e": 105887,
      "ty": 6,
      "x": 837,
      "y": 985,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 115372,
      "e": 105920,
      "ty": 7,
      "x": 840,
      "y": 999,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 115405,
      "e": 105953,
      "ty": 6,
      "x": 847,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115410,
      "e": 105958,
      "ty": 2,
      "x": 847,
      "y": 1006
    },
    {
      "t": 115509,
      "e": 106057,
      "ty": 2,
      "x": 856,
      "y": 1014
    },
    {
      "t": 115509,
      "e": 106057,
      "ty": 41,
      "x": 13698,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115716,
      "e": 106264,
      "ty": 3,
      "x": 856,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115716,
      "e": 106264,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 115717,
      "e": 106265,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115794,
      "e": 106342,
      "ty": 4,
      "x": 13698,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115794,
      "e": 106342,
      "ty": 5,
      "x": 856,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115796,
      "e": 106344,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115797,
      "e": 106345,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 115798,
      "e": 106346,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 117122,
      "e": 107670,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 120009,
      "e": 110557,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 143312,
      "e": 111345,
      "ty": 2,
      "x": 880,
      "y": 1032
    },
    {
      "t": 143413,
      "e": 111446,
      "ty": 2,
      "x": 925,
      "y": 1048
    },
    {
      "t": 143512,
      "e": 111545,
      "ty": 2,
      "x": 926,
      "y": 1049
    },
    {
      "t": 143513,
      "e": 111546,
      "ty": 41,
      "x": 31119,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143612,
      "e": 111645,
      "ty": 2,
      "x": 951,
      "y": 1059
    },
    {
      "t": 143658,
      "e": 111691,
      "ty": 6,
      "x": 985,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 143712,
      "e": 111745,
      "ty": 2,
      "x": 1013,
      "y": 1080
    },
    {
      "t": 143714,
      "e": 111747,
      "ty": 7,
      "x": 1032,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 143763,
      "e": 111796,
      "ty": 41,
      "x": 35711,
      "y": 59607,
      "ta": "> div.masterdiv"
    },
    {
      "t": 143812,
      "e": 111845,
      "ty": 2,
      "x": 1046,
      "y": 1084
    },
    {
      "t": 143913,
      "e": 111946,
      "ty": 2,
      "x": 1047,
      "y": 1086
    },
    {
      "t": 144013,
      "e": 112046,
      "ty": 2,
      "x": 1047,
      "y": 1087
    },
    {
      "t": 144013,
      "e": 112046,
      "ty": 41,
      "x": 35780,
      "y": 59773,
      "ta": "> div.masterdiv"
    },
    {
      "t": 144067,
      "e": 112100,
      "ty": 6,
      "x": 1017,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 144112,
      "e": 112145,
      "ty": 2,
      "x": 995,
      "y": 1090
    },
    {
      "t": 144212,
      "e": 112245,
      "ty": 2,
      "x": 984,
      "y": 1090
    },
    {
      "t": 144263,
      "e": 112296,
      "ty": 41,
      "x": 40686,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 145007,
      "e": 113040,
      "ty": 3,
      "x": 984,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 145008,
      "e": 113041,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145117,
      "e": 113150,
      "ty": 4,
      "x": 40686,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 145119,
      "e": 113152,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145120,
      "e": 113153,
      "ty": 5,
      "x": 984,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 145122,
      "e": 113155,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 146171,
      "e": 114204,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 147914,
      "e": 115947,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":3,\"id\":2447,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2446}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"1\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2463}},{\"nodeType\":1,\"id\":2465,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"3\",\"parentNode\":{\"id\":2466}},{\"nodeType\":1,\"id\":2468,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"4\",\"parentNode\":{\"id\":2469}},{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2472,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"5\",\"parentNode\":{\"id\":2472}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"6\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2479,\"textContent\":\"7\",\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2482,\"textContent\":\"8\",\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2485,\"textContent\":\"9\",\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2439}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2488,\"textContent\":\"10\",\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2441}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2491,\"textContent\":\"11\",\"parentNode\":{\"id\":2490}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2443}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2494,\"textContent\":\"12\",\"parentNode\":{\"id\":2493}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2445}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2448}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2449}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2450}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2451}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2452}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2453}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2454}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2455}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2456}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2457}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2458}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2459}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2578},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2580,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2581,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2580},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2582},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2584,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2549}},{\"nodeType\":1,\"id\":2585,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2584},\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"A \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"B \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"C \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"D \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"E \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"F \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"G \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"H \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"I \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"J \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"K \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"L \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2598,\"textContent\":\"M \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2599,\"textContent\":\"N \",\"parentNode\":{\"id\":2577}},{\"nodeType\":3,\"id\":2600,\"textContent\":\"O \",\"parentNode\":{\"id\":2579}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"P \",\"parentNode\":{\"id\":2581}},{\"nodeType\":3,\"id\":2602,\"textContent\":\"Z \",\"parentNode\":{\"id\":2583}},{\"nodeType\":3,\"id\":2603,\"textContent\":\"X \",\"parentNode\":{\"id\":2585}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2446},{\"id\":2447},{\"id\":2422},{\"id\":2460},{\"id\":2461},{\"id\":2423},{\"id\":2462},{\"id\":2424},{\"id\":2463},{\"id\":2464},{\"id\":2425},{\"id\":2465},{\"id\":2426},{\"id\":2466},{\"id\":2467},{\"id\":2427},{\"id\":2468},{\"id\":2428},{\"id\":2469},{\"id\":2470},{\"id\":2429},{\"id\":2471},{\"id\":2430},{\"id\":2472},{\"id\":2473},{\"id\":2431},{\"id\":2474},{\"id\":2432},{\"id\":2475},{\"id\":2476},{\"id\":2433},{\"id\":2477},{\"id\":2434},{\"id\":2478},{\"id\":2479},{\"id\":2435},{\"id\":2480},{\"id\":2436},{\"id\":2481},{\"id\":2482},{\"id\":2437},{\"id\":2483},{\"id\":2438},{\"id\":2484},{\"id\":2485},{\"id\":2439},{\"id\":2486},{\"id\":2440},{\"id\":2487},{\"id\":2488},{\"id\":2441},{\"id\":2489},{\"id\":2442},{\"id\":2490},{\"id\":2491},{\"id\":2443},{\"id\":2492},{\"id\":2444},{\"id\":2493},{\"id\":2494},{\"id\":2445},{\"id\":2495},{\"id\":2313},{\"id\":2448},{\"id\":2496},{\"id\":2449},{\"id\":2497},{\"id\":2450},{\"id\":2498},{\"id\":2451},{\"id\":2499},{\"id\":2452},{\"id\":2500},{\"id\":2453},{\"id\":2501},{\"id\":2454},{\"id\":2502},{\"id\":2455},{\"id\":2503},{\"id\":2456},{\"id\":2504},{\"id\":2457},{\"id\":2505},{\"id\":2458},{\"id\":2506},{\"id\":2459},{\"id\":2507},{\"id\":2314},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2315},{\"id\":2532},{\"id\":2550},{\"id\":2551},{\"id\":2586},{\"id\":2533},{\"id\":2552},{\"id\":2553},{\"id\":2587},{\"id\":2534},{\"id\":2554},{\"id\":2555},{\"id\":2588},{\"id\":2535},{\"id\":2556},{\"id\":2557},{\"id\":2589},{\"id\":2536},{\"id\":2558},{\"id\":2559},{\"id\":2590},{\"id\":2537},{\"id\":2560},{\"id\":2561},{\"id\":2591},{\"id\":2538},{\"id\":2562},{\"id\":2563},{\"id\":2592},{\"id\":2539},{\"id\":2564},{\"id\":2565},{\"id\":2593},{\"id\":2540},{\"id\":2566},{\"id\":2567},{\"id\":2594},{\"id\":2541},{\"id\":2568},{\"id\":2569},{\"id\":2595},{\"id\":2542},{\"id\":2570},{\"id\":2571},{\"id\":2596},{\"id\":2543},{\"id\":2572},{\"id\":2573},{\"id\":2597},{\"id\":2544},{\"id\":2574},{\"id\":2575},{\"id\":2598},{\"id\":2545},{\"id\":2576},{\"id\":2577},{\"id\":2599},{\"id\":2546},{\"id\":2578},{\"id\":2579},{\"id\":2600},{\"id\":2547},{\"id\":2580},{\"id\":2581},{\"id\":2601},{\"id\":2548},{\"id\":2582},{\"id\":2583},{\"id\":2602},{\"id\":2549},{\"id\":2584},{\"id\":2585},{\"id\":2603},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 21040, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 21044, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12223, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 34352, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7521, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"DELTA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 42879, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 17073, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 61041, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12946, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 74990, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 26422, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 102689, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-08 AM-09 AM-10 AM-11 AM-A -A -11 AM-11 AM-A -A -A -3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1141,y:978,t:1526933322083};\\\", \\\"{x:1137,y:977,t:1526933322092};\\\", \\\"{x:1127,y:971,t:1526933322108};\\\", \\\"{x:1114,y:961,t:1526933322125};\\\", \\\"{x:1091,y:951,t:1526933322140};\\\", \\\"{x:1060,y:937,t:1526933322158};\\\", \\\"{x:1028,y:923,t:1526933322175};\\\", \\\"{x:992,y:902,t:1526933322191};\\\", \\\"{x:957,y:878,t:1526933322208};\\\", \\\"{x:925,y:851,t:1526933322225};\\\", \\\"{x:900,y:826,t:1526933322241};\\\", \\\"{x:876,y:805,t:1526933322257};\\\", \\\"{x:859,y:787,t:1526933322275};\\\", \\\"{x:838,y:764,t:1526933322291};\\\", \\\"{x:808,y:732,t:1526933322308};\\\", \\\"{x:799,y:727,t:1526933322325};\\\", \\\"{x:796,y:727,t:1526933322342};\\\", \\\"{x:792,y:725,t:1526933322358};\\\", \\\"{x:777,y:724,t:1526933322375};\\\", \\\"{x:765,y:724,t:1526933322392};\\\", \\\"{x:766,y:724,t:1526933322877};\\\", \\\"{x:768,y:724,t:1526933327397};\\\", \\\"{x:774,y:731,t:1526933327412};\\\", \\\"{x:788,y:749,t:1526933327429};\\\", \\\"{x:806,y:767,t:1526933327446};\\\", \\\"{x:825,y:789,t:1526933327462};\\\", \\\"{x:848,y:808,t:1526933327479};\\\", \\\"{x:868,y:825,t:1526933327496};\\\", \\\"{x:890,y:844,t:1526933327513};\\\", \\\"{x:914,y:863,t:1526933327529};\\\", \\\"{x:938,y:883,t:1526933327546};\\\", \\\"{x:955,y:898,t:1526933327563};\\\", \\\"{x:970,y:911,t:1526933327579};\\\", \\\"{x:986,y:924,t:1526933327596};\\\", \\\"{x:1003,y:935,t:1526933327612};\\\", \\\"{x:1021,y:946,t:1526933327629};\\\", \\\"{x:1044,y:957,t:1526933327645};\\\", \\\"{x:1064,y:967,t:1526933327663};\\\", \\\"{x:1084,y:974,t:1526933327680};\\\", \\\"{x:1102,y:979,t:1526933327696};\\\", \\\"{x:1118,y:983,t:1526933327712};\\\", \\\"{x:1127,y:984,t:1526933327729};\\\", \\\"{x:1131,y:986,t:1526933327746};\\\", \\\"{x:1133,y:986,t:1526933327845};\\\", \\\"{x:1138,y:986,t:1526933327863};\\\", \\\"{x:1145,y:985,t:1526933327880};\\\", \\\"{x:1153,y:982,t:1526933327896};\\\", \\\"{x:1157,y:981,t:1526933327913};\\\", \\\"{x:1160,y:980,t:1526933327929};\\\", \\\"{x:1163,y:980,t:1526933327946};\\\", \\\"{x:1168,y:978,t:1526933327962};\\\", \\\"{x:1175,y:978,t:1526933327980};\\\", \\\"{x:1191,y:977,t:1526933327996};\\\", \\\"{x:1204,y:977,t:1526933328013};\\\", \\\"{x:1220,y:974,t:1526933328029};\\\", \\\"{x:1231,y:973,t:1526933328046};\\\", \\\"{x:1244,y:972,t:1526933328063};\\\", \\\"{x:1252,y:971,t:1526933328080};\\\", \\\"{x:1257,y:971,t:1526933328097};\\\", \\\"{x:1260,y:970,t:1526933328113};\\\", \\\"{x:1264,y:970,t:1526933328129};\\\", \\\"{x:1266,y:970,t:1526933328147};\\\", \\\"{x:1270,y:970,t:1526933328163};\\\", \\\"{x:1277,y:970,t:1526933328180};\\\", \\\"{x:1282,y:970,t:1526933328196};\\\", \\\"{x:1285,y:970,t:1526933328213};\\\", \\\"{x:1289,y:970,t:1526933328229};\\\", \\\"{x:1292,y:970,t:1526933328246};\\\", \\\"{x:1295,y:970,t:1526933328262};\\\", \\\"{x:1296,y:970,t:1526933328279};\\\", \\\"{x:1297,y:970,t:1526933328296};\\\", \\\"{x:1295,y:970,t:1526933328684};\\\", \\\"{x:1293,y:970,t:1526933328697};\\\", \\\"{x:1289,y:970,t:1526933328713};\\\", \\\"{x:1288,y:970,t:1526933328729};\\\", \\\"{x:1285,y:970,t:1526933328746};\\\", \\\"{x:1281,y:969,t:1526933328763};\\\", \\\"{x:1278,y:969,t:1526933328779};\\\", \\\"{x:1278,y:968,t:1526933328797};\\\", \\\"{x:1276,y:968,t:1526933328813};\\\", \\\"{x:1275,y:968,t:1526933328830};\\\", \\\"{x:1272,y:968,t:1526933328847};\\\", \\\"{x:1270,y:968,t:1526933328876};\\\", \\\"{x:1270,y:967,t:1526933329179};\\\", \\\"{x:1270,y:966,t:1526933329211};\\\", \\\"{x:1270,y:965,t:1526933329227};\\\", \\\"{x:1270,y:964,t:1526933329235};\\\", \\\"{x:1270,y:963,t:1526933329251};\\\", \\\"{x:1269,y:962,t:1526933329263};\\\", \\\"{x:1269,y:961,t:1526933329280};\\\", \\\"{x:1269,y:960,t:1526933329299};\\\", \\\"{x:1269,y:958,t:1526933329316};\\\", \\\"{x:1269,y:957,t:1526933329330};\\\", \\\"{x:1269,y:955,t:1526933329346};\\\", \\\"{x:1265,y:937,t:1526933329363};\\\", \\\"{x:1260,y:919,t:1526933329380};\\\", \\\"{x:1260,y:911,t:1526933329396};\\\", \\\"{x:1258,y:899,t:1526933329413};\\\", \\\"{x:1254,y:889,t:1526933329430};\\\", \\\"{x:1254,y:879,t:1526933329447};\\\", \\\"{x:1253,y:874,t:1526933329464};\\\", \\\"{x:1253,y:872,t:1526933329480};\\\", \\\"{x:1253,y:869,t:1526933329497};\\\", \\\"{x:1253,y:866,t:1526933329513};\\\", \\\"{x:1253,y:860,t:1526933329530};\\\", \\\"{x:1253,y:855,t:1526933329552};\\\", \\\"{x:1253,y:849,t:1526933329563};\\\", \\\"{x:1253,y:845,t:1526933329580};\\\", \\\"{x:1253,y:842,t:1526933329597};\\\", \\\"{x:1253,y:838,t:1526933329613};\\\", \\\"{x:1253,y:834,t:1526933329630};\\\", \\\"{x:1253,y:828,t:1526933329647};\\\", \\\"{x:1253,y:821,t:1526933329663};\\\", \\\"{x:1253,y:816,t:1526933329680};\\\", \\\"{x:1253,y:814,t:1526933329697};\\\", \\\"{x:1254,y:812,t:1526933329713};\\\", \\\"{x:1254,y:811,t:1526933329731};\\\", \\\"{x:1254,y:809,t:1526933329748};\\\", \\\"{x:1254,y:808,t:1526933329780};\\\", \\\"{x:1254,y:807,t:1526933329787};\\\", \\\"{x:1255,y:806,t:1526933329797};\\\", \\\"{x:1256,y:805,t:1526933329828};\\\", \\\"{x:1257,y:804,t:1526933329836};\\\", \\\"{x:1258,y:804,t:1526933329851};\\\", \\\"{x:1258,y:803,t:1526933329864};\\\", \\\"{x:1260,y:803,t:1526933329882};\\\", \\\"{x:1261,y:803,t:1526933329897};\\\", \\\"{x:1262,y:803,t:1526933329923};\\\", \\\"{x:1263,y:803,t:1526933329939};\\\", \\\"{x:1264,y:803,t:1526933329955};\\\", \\\"{x:1267,y:804,t:1526933329964};\\\", \\\"{x:1270,y:808,t:1526933329980};\\\", \\\"{x:1274,y:812,t:1526933329997};\\\", \\\"{x:1276,y:817,t:1526933330014};\\\", \\\"{x:1278,y:819,t:1526933330030};\\\", \\\"{x:1278,y:820,t:1526933330047};\\\", \\\"{x:1278,y:822,t:1526933330065};\\\", \\\"{x:1278,y:825,t:1526933339552};\\\", \\\"{x:1278,y:838,t:1526933339571};\\\", \\\"{x:1278,y:852,t:1526933339587};\\\", \\\"{x:1278,y:858,t:1526933339605};\\\", \\\"{x:1277,y:864,t:1526933339620};\\\", \\\"{x:1274,y:876,t:1526933339637};\\\", \\\"{x:1272,y:887,t:1526933339654};\\\", \\\"{x:1271,y:897,t:1526933339670};\\\", \\\"{x:1268,y:910,t:1526933339687};\\\", \\\"{x:1268,y:919,t:1526933339704};\\\", \\\"{x:1267,y:924,t:1526933339720};\\\", \\\"{x:1267,y:929,t:1526933339737};\\\", \\\"{x:1267,y:933,t:1526933339755};\\\", \\\"{x:1267,y:937,t:1526933339771};\\\", \\\"{x:1267,y:945,t:1526933339787};\\\", \\\"{x:1267,y:949,t:1526933339804};\\\", \\\"{x:1267,y:952,t:1526933339821};\\\", \\\"{x:1267,y:957,t:1526933339837};\\\", \\\"{x:1265,y:960,t:1526933339854};\\\", \\\"{x:1265,y:965,t:1526933339871};\\\", \\\"{x:1265,y:966,t:1526933339888};\\\", \\\"{x:1263,y:969,t:1526933339905};\\\", \\\"{x:1263,y:972,t:1526933339921};\\\", \\\"{x:1262,y:973,t:1526933339938};\\\", \\\"{x:1261,y:976,t:1526933339956};\\\", \\\"{x:1260,y:978,t:1526933339972};\\\", \\\"{x:1259,y:979,t:1526933339988};\\\", \\\"{x:1259,y:980,t:1526933340180};\\\", \\\"{x:1260,y:980,t:1526933340188};\\\", \\\"{x:1262,y:978,t:1526933340205};\\\", \\\"{x:1263,y:975,t:1526933340222};\\\", \\\"{x:1264,y:972,t:1526933340238};\\\", \\\"{x:1265,y:970,t:1526933340255};\\\", \\\"{x:1266,y:968,t:1526933340272};\\\", \\\"{x:1266,y:966,t:1526933340289};\\\", \\\"{x:1268,y:964,t:1526933340305};\\\", \\\"{x:1268,y:963,t:1526933340332};\\\", \\\"{x:1269,y:962,t:1526933340348};\\\", \\\"{x:1270,y:960,t:1526933340364};\\\", \\\"{x:1270,y:959,t:1526933340378};\\\", \\\"{x:1272,y:958,t:1526933340389};\\\", \\\"{x:1273,y:956,t:1526933340405};\\\", \\\"{x:1274,y:955,t:1526933340421};\\\", \\\"{x:1276,y:953,t:1526933340438};\\\", \\\"{x:1277,y:952,t:1526933340454};\\\", \\\"{x:1279,y:952,t:1526933340471};\\\", \\\"{x:1279,y:951,t:1526933340488};\\\", \\\"{x:1279,y:949,t:1526933340997};\\\", \\\"{x:1279,y:943,t:1526933341006};\\\", \\\"{x:1279,y:927,t:1526933341022};\\\", \\\"{x:1279,y:915,t:1526933341039};\\\", \\\"{x:1279,y:909,t:1526933341056};\\\", \\\"{x:1279,y:901,t:1526933341072};\\\", \\\"{x:1279,y:883,t:1526933341089};\\\", \\\"{x:1279,y:875,t:1526933341106};\\\", \\\"{x:1279,y:866,t:1526933341122};\\\", \\\"{x:1279,y:858,t:1526933341139};\\\", \\\"{x:1279,y:849,t:1526933341156};\\\", \\\"{x:1279,y:843,t:1526933341171};\\\", \\\"{x:1279,y:839,t:1526933341188};\\\", \\\"{x:1279,y:836,t:1526933341206};\\\", \\\"{x:1279,y:832,t:1526933341221};\\\", \\\"{x:1279,y:828,t:1526933341239};\\\", \\\"{x:1279,y:822,t:1526933341256};\\\", \\\"{x:1279,y:818,t:1526933341272};\\\", \\\"{x:1279,y:815,t:1526933341288};\\\", \\\"{x:1281,y:812,t:1526933341306};\\\", \\\"{x:1281,y:810,t:1526933341997};\\\", \\\"{x:1281,y:808,t:1526933342006};\\\", \\\"{x:1281,y:805,t:1526933342024};\\\", \\\"{x:1281,y:800,t:1526933342040};\\\", \\\"{x:1281,y:797,t:1526933342056};\\\", \\\"{x:1281,y:793,t:1526933342074};\\\", \\\"{x:1281,y:788,t:1526933342090};\\\", \\\"{x:1281,y:784,t:1526933342107};\\\", \\\"{x:1281,y:781,t:1526933342124};\\\", \\\"{x:1281,y:764,t:1526933342140};\\\", \\\"{x:1280,y:754,t:1526933342156};\\\", \\\"{x:1277,y:739,t:1526933342173};\\\", \\\"{x:1275,y:723,t:1526933342190};\\\", \\\"{x:1274,y:716,t:1526933342206};\\\", \\\"{x:1274,y:713,t:1526933342222};\\\", \\\"{x:1274,y:708,t:1526933342239};\\\", \\\"{x:1274,y:705,t:1526933342256};\\\", \\\"{x:1274,y:701,t:1526933342273};\\\", \\\"{x:1274,y:697,t:1526933342289};\\\", \\\"{x:1274,y:695,t:1526933342305};\\\", \\\"{x:1274,y:694,t:1526933342322};\\\", \\\"{x:1274,y:693,t:1526933342340};\\\", \\\"{x:1276,y:692,t:1526933342356};\\\", \\\"{x:1278,y:691,t:1526933342373};\\\", \\\"{x:1285,y:689,t:1526933342390};\\\", \\\"{x:1293,y:686,t:1526933342407};\\\", \\\"{x:1300,y:680,t:1526933342423};\\\", \\\"{x:1309,y:675,t:1526933342440};\\\", \\\"{x:1315,y:672,t:1526933342457};\\\", \\\"{x:1319,y:669,t:1526933342473};\\\", \\\"{x:1323,y:666,t:1526933342490};\\\", \\\"{x:1329,y:660,t:1526933342507};\\\", \\\"{x:1337,y:651,t:1526933342523};\\\", \\\"{x:1348,y:638,t:1526933342540};\\\", \\\"{x:1354,y:630,t:1526933342557};\\\", \\\"{x:1363,y:620,t:1526933342574};\\\", \\\"{x:1370,y:610,t:1526933342590};\\\", \\\"{x:1375,y:600,t:1526933342607};\\\", \\\"{x:1383,y:592,t:1526933342623};\\\", \\\"{x:1388,y:584,t:1526933342640};\\\", \\\"{x:1392,y:576,t:1526933342658};\\\", \\\"{x:1395,y:570,t:1526933342673};\\\", \\\"{x:1397,y:567,t:1526933342691};\\\", \\\"{x:1397,y:565,t:1526933342707};\\\", \\\"{x:1399,y:561,t:1526933342724};\\\", \\\"{x:1400,y:559,t:1526933342740};\\\", \\\"{x:1400,y:558,t:1526933342764};\\\", \\\"{x:1401,y:557,t:1526933342780};\\\", \\\"{x:1401,y:556,t:1526933342796};\\\", \\\"{x:1402,y:555,t:1526933342812};\\\", \\\"{x:1403,y:554,t:1526933342829};\\\", \\\"{x:1404,y:554,t:1526933342840};\\\", \\\"{x:1405,y:552,t:1526933342857};\\\", \\\"{x:1405,y:553,t:1526933343581};\\\", \\\"{x:1405,y:560,t:1526933343591};\\\", \\\"{x:1402,y:583,t:1526933343607};\\\", \\\"{x:1398,y:611,t:1526933343624};\\\", \\\"{x:1393,y:637,t:1526933343642};\\\", \\\"{x:1385,y:667,t:1526933343658};\\\", \\\"{x:1376,y:694,t:1526933343675};\\\", \\\"{x:1364,y:719,t:1526933343692};\\\", \\\"{x:1348,y:757,t:1526933343708};\\\", \\\"{x:1338,y:781,t:1526933343724};\\\", \\\"{x:1327,y:801,t:1526933343741};\\\", \\\"{x:1321,y:815,t:1526933343757};\\\", \\\"{x:1315,y:825,t:1526933343774};\\\", \\\"{x:1310,y:834,t:1526933343791};\\\", \\\"{x:1308,y:842,t:1526933343809};\\\", \\\"{x:1304,y:850,t:1526933343824};\\\", \\\"{x:1300,y:859,t:1526933343841};\\\", \\\"{x:1295,y:870,t:1526933343858};\\\", \\\"{x:1291,y:879,t:1526933343875};\\\", \\\"{x:1289,y:886,t:1526933343891};\\\", \\\"{x:1286,y:891,t:1526933343908};\\\", \\\"{x:1286,y:890,t:1526933344117};\\\", \\\"{x:1286,y:886,t:1526933344124};\\\", \\\"{x:1286,y:883,t:1526933344142};\\\", \\\"{x:1285,y:879,t:1526933344158};\\\", \\\"{x:1284,y:877,t:1526933344175};\\\", \\\"{x:1284,y:876,t:1526933344191};\\\", \\\"{x:1284,y:874,t:1526933344209};\\\", \\\"{x:1283,y:873,t:1526933344225};\\\", \\\"{x:1282,y:871,t:1526933344242};\\\", \\\"{x:1282,y:870,t:1526933344259};\\\", \\\"{x:1282,y:868,t:1526933344276};\\\", \\\"{x:1282,y:867,t:1526933344291};\\\", \\\"{x:1281,y:863,t:1526933344307};\\\", \\\"{x:1280,y:859,t:1526933344325};\\\", \\\"{x:1279,y:853,t:1526933344341};\\\", \\\"{x:1279,y:848,t:1526933344359};\\\", \\\"{x:1277,y:842,t:1526933344375};\\\", \\\"{x:1277,y:837,t:1526933344392};\\\", \\\"{x:1277,y:836,t:1526933344408};\\\", \\\"{x:1277,y:835,t:1526933344426};\\\", \\\"{x:1277,y:833,t:1526933344442};\\\", \\\"{x:1277,y:832,t:1526933344459};\\\", \\\"{x:1277,y:831,t:1526933344476};\\\", \\\"{x:1273,y:830,t:1526933345173};\\\", \\\"{x:1255,y:825,t:1526933345180};\\\", \\\"{x:1228,y:812,t:1526933345192};\\\", \\\"{x:1149,y:767,t:1526933345210};\\\", \\\"{x:1044,y:718,t:1526933345226};\\\", \\\"{x:924,y:678,t:1526933345243};\\\", \\\"{x:808,y:645,t:1526933345260};\\\", \\\"{x:698,y:616,t:1526933345276};\\\", \\\"{x:552,y:566,t:1526933345293};\\\", \\\"{x:471,y:542,t:1526933345308};\\\", \\\"{x:417,y:522,t:1526933345325};\\\", \\\"{x:383,y:516,t:1526933345344};\\\", \\\"{x:359,y:516,t:1526933345359};\\\", \\\"{x:339,y:516,t:1526933345377};\\\", \\\"{x:319,y:516,t:1526933345393};\\\", \\\"{x:298,y:516,t:1526933345410};\\\", \\\"{x:263,y:518,t:1526933345427};\\\", \\\"{x:236,y:523,t:1526933345443};\\\", \\\"{x:211,y:524,t:1526933345460};\\\", \\\"{x:183,y:528,t:1526933345477};\\\", \\\"{x:166,y:531,t:1526933345494};\\\", \\\"{x:162,y:532,t:1526933345509};\\\", \\\"{x:166,y:532,t:1526933345563};\\\", \\\"{x:173,y:532,t:1526933345577};\\\", \\\"{x:194,y:531,t:1526933345594};\\\", \\\"{x:220,y:529,t:1526933345610};\\\", \\\"{x:268,y:520,t:1526933345627};\\\", \\\"{x:294,y:517,t:1526933345645};\\\", \\\"{x:314,y:512,t:1526933345659};\\\", \\\"{x:318,y:510,t:1526933345677};\\\", \\\"{x:322,y:509,t:1526933345694};\\\", \\\"{x:323,y:509,t:1526933345710};\\\", \\\"{x:325,y:509,t:1526933345726};\\\", \\\"{x:330,y:508,t:1526933345744};\\\", \\\"{x:337,y:508,t:1526933345761};\\\", \\\"{x:346,y:506,t:1526933345777};\\\", \\\"{x:354,y:506,t:1526933345793};\\\", \\\"{x:371,y:506,t:1526933345811};\\\", \\\"{x:382,y:506,t:1526933345827};\\\", \\\"{x:392,y:508,t:1526933345844};\\\", \\\"{x:398,y:510,t:1526933345862};\\\", \\\"{x:399,y:511,t:1526933345876};\\\", \\\"{x:401,y:511,t:1526933345893};\\\", \\\"{x:402,y:511,t:1526933345954};\\\", \\\"{x:402,y:512,t:1526933345986};\\\", \\\"{x:402,y:513,t:1526933346075};\\\", \\\"{x:402,y:514,t:1526933346100};\\\", \\\"{x:402,y:515,t:1526933346111};\\\", \\\"{x:402,y:517,t:1526933346148};\\\", \\\"{x:401,y:517,t:1526933346188};\\\", \\\"{x:400,y:517,t:1526933346196};\\\", \\\"{x:398,y:519,t:1526933346211};\\\", \\\"{x:394,y:519,t:1526933346228};\\\", \\\"{x:391,y:519,t:1526933346244};\\\", \\\"{x:389,y:519,t:1526933346261};\\\", \\\"{x:388,y:519,t:1526933346278};\\\", \\\"{x:387,y:519,t:1526933346308};\\\", \\\"{x:386,y:519,t:1526933346315};\\\", \\\"{x:385,y:519,t:1526933346347};\\\", \\\"{x:384,y:519,t:1526933346364};\\\", \\\"{x:383,y:519,t:1526933346380};\\\", \\\"{x:389,y:527,t:1526933346980};\\\", \\\"{x:406,y:554,t:1526933346998};\\\", \\\"{x:417,y:574,t:1526933347011};\\\", \\\"{x:427,y:591,t:1526933347028};\\\", \\\"{x:438,y:611,t:1526933347044};\\\", \\\"{x:448,y:629,t:1526933347061};\\\", \\\"{x:455,y:646,t:1526933347077};\\\", \\\"{x:462,y:661,t:1526933347095};\\\", \\\"{x:468,y:673,t:1526933347111};\\\", \\\"{x:472,y:682,t:1526933347128};\\\", \\\"{x:475,y:688,t:1526933347145};\\\", \\\"{x:479,y:695,t:1526933347162};\\\", \\\"{x:480,y:696,t:1526933347178};\\\", \\\"{x:481,y:698,t:1526933347195};\\\", \\\"{x:481,y:699,t:1526933347218};\\\", \\\"{x:482,y:700,t:1526933347243};\\\", \\\"{x:483,y:701,t:1526933347251};\\\", \\\"{x:483,y:703,t:1526933347275};\\\", \\\"{x:485,y:705,t:1526933347291};\\\", \\\"{x:485,y:706,t:1526933347307};\\\", \\\"{x:486,y:707,t:1526933347356};\\\", \\\"{x:487,y:709,t:1526933347363};\\\", \\\"{x:487,y:710,t:1526933347378};\\\", \\\"{x:490,y:715,t:1526933347395};\\\", \\\"{x:492,y:718,t:1526933347411};\\\", \\\"{x:493,y:719,t:1526933347428};\\\" ] }, { \\\"rt\\\": 52457, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 156495, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -E -D -D -12-X -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:722,t:1526933349740};\\\", \\\"{x:526,y:728,t:1526933349755};\\\", \\\"{x:545,y:730,t:1526933349763};\\\", \\\"{x:589,y:734,t:1526933349780};\\\", \\\"{x:627,y:736,t:1526933349797};\\\", \\\"{x:659,y:738,t:1526933349814};\\\", \\\"{x:685,y:741,t:1526933349830};\\\", \\\"{x:708,y:743,t:1526933349847};\\\", \\\"{x:729,y:747,t:1526933349864};\\\", \\\"{x:744,y:748,t:1526933349880};\\\", \\\"{x:749,y:748,t:1526933349897};\\\", \\\"{x:750,y:748,t:1526933349914};\\\", \\\"{x:751,y:748,t:1526933350308};\\\", \\\"{x:750,y:748,t:1526933350339};\\\", \\\"{x:748,y:748,t:1526933350347};\\\", \\\"{x:747,y:748,t:1526933350364};\\\", \\\"{x:746,y:748,t:1526933350404};\\\", \\\"{x:753,y:753,t:1526933351268};\\\", \\\"{x:770,y:763,t:1526933351282};\\\", \\\"{x:824,y:783,t:1526933351300};\\\", \\\"{x:868,y:802,t:1526933351315};\\\", \\\"{x:907,y:819,t:1526933351332};\\\", \\\"{x:943,y:834,t:1526933351349};\\\", \\\"{x:965,y:841,t:1526933351365};\\\", \\\"{x:987,y:850,t:1526933351382};\\\", \\\"{x:1006,y:856,t:1526933351399};\\\", \\\"{x:1024,y:863,t:1526933351416};\\\", \\\"{x:1041,y:871,t:1526933351432};\\\", \\\"{x:1057,y:875,t:1526933351449};\\\", \\\"{x:1081,y:884,t:1526933351465};\\\", \\\"{x:1118,y:896,t:1526933351483};\\\", \\\"{x:1176,y:911,t:1526933351500};\\\", \\\"{x:1207,y:920,t:1526933351514};\\\", \\\"{x:1244,y:931,t:1526933351532};\\\", \\\"{x:1276,y:937,t:1526933351549};\\\", \\\"{x:1301,y:939,t:1526933351565};\\\", \\\"{x:1327,y:945,t:1526933351582};\\\", \\\"{x:1349,y:948,t:1526933351599};\\\", \\\"{x:1374,y:950,t:1526933351615};\\\", \\\"{x:1405,y:955,t:1526933351632};\\\", \\\"{x:1443,y:960,t:1526933351649};\\\", \\\"{x:1481,y:963,t:1526933351665};\\\", \\\"{x:1511,y:966,t:1526933351682};\\\", \\\"{x:1537,y:966,t:1526933351699};\\\", \\\"{x:1542,y:966,t:1526933351715};\\\", \\\"{x:1543,y:966,t:1526933351732};\\\", \\\"{x:1539,y:966,t:1526933351755};\\\", \\\"{x:1533,y:963,t:1526933351766};\\\", \\\"{x:1523,y:960,t:1526933351782};\\\", \\\"{x:1516,y:958,t:1526933351799};\\\", \\\"{x:1512,y:956,t:1526933351816};\\\", \\\"{x:1509,y:955,t:1526933351832};\\\", \\\"{x:1508,y:955,t:1526933351849};\\\", \\\"{x:1507,y:954,t:1526933351867};\\\", \\\"{x:1506,y:954,t:1526933351883};\\\", \\\"{x:1505,y:954,t:1526933351907};\\\", \\\"{x:1504,y:954,t:1526933351915};\\\", \\\"{x:1502,y:954,t:1526933351932};\\\", \\\"{x:1498,y:954,t:1526933351949};\\\", \\\"{x:1495,y:954,t:1526933351967};\\\", \\\"{x:1492,y:955,t:1526933351982};\\\", \\\"{x:1490,y:956,t:1526933352000};\\\", \\\"{x:1488,y:957,t:1526933352016};\\\", \\\"{x:1487,y:959,t:1526933352032};\\\", \\\"{x:1485,y:959,t:1526933352050};\\\", \\\"{x:1484,y:960,t:1526933352066};\\\", \\\"{x:1483,y:962,t:1526933352084};\\\", \\\"{x:1482,y:962,t:1526933352099};\\\", \\\"{x:1481,y:963,t:1526933352148};\\\", \\\"{x:1481,y:964,t:1526933352189};\\\", \\\"{x:1479,y:965,t:1526933352204};\\\", \\\"{x:1478,y:965,t:1526933352324};\\\", \\\"{x:1477,y:965,t:1526933352333};\\\", \\\"{x:1476,y:965,t:1526933352349};\\\", \\\"{x:1477,y:962,t:1526933352367};\\\", \\\"{x:1480,y:959,t:1526933352383};\\\", \\\"{x:1483,y:957,t:1526933352400};\\\", \\\"{x:1488,y:954,t:1526933352416};\\\", \\\"{x:1492,y:952,t:1526933352433};\\\", \\\"{x:1495,y:950,t:1526933352450};\\\", \\\"{x:1501,y:947,t:1526933352466};\\\", \\\"{x:1509,y:944,t:1526933352483};\\\", \\\"{x:1514,y:942,t:1526933352499};\\\", \\\"{x:1518,y:941,t:1526933352516};\\\", \\\"{x:1521,y:940,t:1526933352533};\\\", \\\"{x:1522,y:940,t:1526933352550};\\\", \\\"{x:1522,y:939,t:1526933352566};\\\", \\\"{x:1524,y:938,t:1526933352584};\\\", \\\"{x:1525,y:938,t:1526933352612};\\\", \\\"{x:1526,y:938,t:1526933352852};\\\", \\\"{x:1527,y:938,t:1526933352876};\\\", \\\"{x:1532,y:930,t:1526933353517};\\\", \\\"{x:1541,y:907,t:1526933353523};\\\", \\\"{x:1556,y:870,t:1526933353534};\\\", \\\"{x:1576,y:806,t:1526933353552};\\\", \\\"{x:1599,y:741,t:1526933353568};\\\", \\\"{x:1613,y:691,t:1526933353585};\\\", \\\"{x:1624,y:641,t:1526933353601};\\\", \\\"{x:1635,y:609,t:1526933353617};\\\", \\\"{x:1642,y:585,t:1526933353634};\\\", \\\"{x:1648,y:550,t:1526933353652};\\\", \\\"{x:1649,y:525,t:1526933353667};\\\", \\\"{x:1649,y:500,t:1526933353684};\\\", \\\"{x:1649,y:467,t:1526933353702};\\\", \\\"{x:1652,y:442,t:1526933353717};\\\", \\\"{x:1653,y:422,t:1526933353734};\\\", \\\"{x:1654,y:405,t:1526933353752};\\\", \\\"{x:1655,y:387,t:1526933353767};\\\", \\\"{x:1655,y:375,t:1526933353784};\\\", \\\"{x:1653,y:359,t:1526933353802};\\\", \\\"{x:1651,y:353,t:1526933353817};\\\", \\\"{x:1650,y:350,t:1526933353835};\\\", \\\"{x:1650,y:349,t:1526933353875};\\\", \\\"{x:1649,y:349,t:1526933353899};\\\", \\\"{x:1646,y:350,t:1526933353908};\\\", \\\"{x:1645,y:353,t:1526933353918};\\\", \\\"{x:1638,y:368,t:1526933353935};\\\", \\\"{x:1632,y:385,t:1526933353951};\\\", \\\"{x:1628,y:399,t:1526933353969};\\\", \\\"{x:1627,y:407,t:1526933353985};\\\", \\\"{x:1625,y:411,t:1526933354002};\\\", \\\"{x:1625,y:412,t:1526933354019};\\\", \\\"{x:1625,y:414,t:1526933354035};\\\", \\\"{x:1625,y:415,t:1526933354051};\\\", \\\"{x:1625,y:417,t:1526933354068};\\\", \\\"{x:1625,y:421,t:1526933354085};\\\", \\\"{x:1625,y:425,t:1526933354101};\\\", \\\"{x:1625,y:429,t:1526933354118};\\\", \\\"{x:1625,y:432,t:1526933354135};\\\", \\\"{x:1625,y:433,t:1526933354163};\\\", \\\"{x:1624,y:435,t:1526933354170};\\\", \\\"{x:1623,y:435,t:1526933354186};\\\", \\\"{x:1622,y:436,t:1526933354201};\\\", \\\"{x:1622,y:437,t:1526933354218};\\\", \\\"{x:1621,y:438,t:1526933354258};\\\", \\\"{x:1620,y:438,t:1526933354283};\\\", \\\"{x:1619,y:438,t:1526933354299};\\\", \\\"{x:1618,y:438,t:1526933354315};\\\", \\\"{x:1617,y:438,t:1526933354323};\\\", \\\"{x:1616,y:438,t:1526933354339};\\\", \\\"{x:1614,y:438,t:1526933354379};\\\", \\\"{x:1613,y:437,t:1526933354469};\\\", \\\"{x:1613,y:435,t:1526933354488};\\\", \\\"{x:1612,y:433,t:1526933354518};\\\", \\\"{x:1611,y:431,t:1526933354534};\\\", \\\"{x:1610,y:430,t:1526933354552};\\\", \\\"{x:1610,y:429,t:1526933354568};\\\", \\\"{x:1610,y:428,t:1526933356956};\\\", \\\"{x:1610,y:430,t:1526933376695};\\\", \\\"{x:1610,y:432,t:1526933376710};\\\", \\\"{x:1610,y:435,t:1526933376727};\\\", \\\"{x:1611,y:437,t:1526933376743};\\\", \\\"{x:1611,y:438,t:1526933376760};\\\", \\\"{x:1611,y:439,t:1526933376781};\\\", \\\"{x:1612,y:440,t:1526933376797};\\\", \\\"{x:1613,y:441,t:1526933376814};\\\", \\\"{x:1613,y:442,t:1526933376829};\\\", \\\"{x:1613,y:444,t:1526933376853};\\\", \\\"{x:1613,y:445,t:1526933376878};\\\", \\\"{x:1613,y:447,t:1526933376893};\\\", \\\"{x:1614,y:448,t:1526933376910};\\\", \\\"{x:1614,y:450,t:1526933376927};\\\", \\\"{x:1614,y:453,t:1526933376943};\\\", \\\"{x:1614,y:455,t:1526933376961};\\\", \\\"{x:1614,y:458,t:1526933376977};\\\", \\\"{x:1616,y:462,t:1526933376993};\\\", \\\"{x:1616,y:465,t:1526933377010};\\\", \\\"{x:1617,y:471,t:1526933377027};\\\", \\\"{x:1618,y:475,t:1526933377044};\\\", \\\"{x:1618,y:481,t:1526933377060};\\\", \\\"{x:1618,y:492,t:1526933377078};\\\", \\\"{x:1618,y:500,t:1526933377093};\\\", \\\"{x:1618,y:508,t:1526933377111};\\\", \\\"{x:1618,y:513,t:1526933377127};\\\", \\\"{x:1618,y:518,t:1526933377143};\\\", \\\"{x:1618,y:523,t:1526933377160};\\\", \\\"{x:1618,y:528,t:1526933377178};\\\", \\\"{x:1618,y:533,t:1526933377193};\\\", \\\"{x:1618,y:534,t:1526933377210};\\\", \\\"{x:1618,y:537,t:1526933377227};\\\", \\\"{x:1618,y:539,t:1526933377244};\\\", \\\"{x:1618,y:543,t:1526933377261};\\\", \\\"{x:1618,y:546,t:1526933377277};\\\", \\\"{x:1618,y:551,t:1526933377294};\\\", \\\"{x:1620,y:558,t:1526933377310};\\\", \\\"{x:1620,y:563,t:1526933377328};\\\", \\\"{x:1621,y:565,t:1526933377345};\\\", \\\"{x:1621,y:569,t:1526933377360};\\\", \\\"{x:1621,y:571,t:1526933377377};\\\", \\\"{x:1621,y:575,t:1526933377395};\\\", \\\"{x:1621,y:577,t:1526933377411};\\\", \\\"{x:1621,y:579,t:1526933377428};\\\", \\\"{x:1621,y:580,t:1526933377519};\\\", \\\"{x:1621,y:581,t:1526933377534};\\\", \\\"{x:1621,y:582,t:1526933377544};\\\", \\\"{x:1621,y:584,t:1526933377561};\\\", \\\"{x:1621,y:588,t:1526933377577};\\\", \\\"{x:1621,y:591,t:1526933377595};\\\", \\\"{x:1621,y:596,t:1526933377611};\\\", \\\"{x:1620,y:598,t:1526933377628};\\\", \\\"{x:1620,y:600,t:1526933377644};\\\", \\\"{x:1620,y:604,t:1526933377662};\\\", \\\"{x:1620,y:606,t:1526933377678};\\\", \\\"{x:1620,y:610,t:1526933377694};\\\", \\\"{x:1620,y:613,t:1526933377712};\\\", \\\"{x:1620,y:616,t:1526933377727};\\\", \\\"{x:1620,y:620,t:1526933377743};\\\", \\\"{x:1620,y:624,t:1526933377760};\\\", \\\"{x:1620,y:628,t:1526933377777};\\\", \\\"{x:1620,y:635,t:1526933377793};\\\", \\\"{x:1620,y:645,t:1526933377811};\\\", \\\"{x:1619,y:657,t:1526933377827};\\\", \\\"{x:1619,y:667,t:1526933377844};\\\", \\\"{x:1618,y:680,t:1526933377861};\\\", \\\"{x:1618,y:695,t:1526933377877};\\\", \\\"{x:1616,y:705,t:1526933377894};\\\", \\\"{x:1616,y:715,t:1526933377911};\\\", \\\"{x:1616,y:725,t:1526933377928};\\\", \\\"{x:1615,y:730,t:1526933377944};\\\", \\\"{x:1615,y:736,t:1526933377961};\\\", \\\"{x:1615,y:742,t:1526933377978};\\\", \\\"{x:1615,y:748,t:1526933377994};\\\", \\\"{x:1615,y:754,t:1526933378011};\\\", \\\"{x:1615,y:756,t:1526933378028};\\\", \\\"{x:1615,y:759,t:1526933378044};\\\", \\\"{x:1615,y:760,t:1526933378061};\\\", \\\"{x:1615,y:763,t:1526933378079};\\\", \\\"{x:1615,y:765,t:1526933378095};\\\", \\\"{x:1615,y:766,t:1526933378111};\\\", \\\"{x:1615,y:769,t:1526933378128};\\\", \\\"{x:1615,y:771,t:1526933378144};\\\", \\\"{x:1615,y:773,t:1526933378161};\\\", \\\"{x:1615,y:776,t:1526933378178};\\\", \\\"{x:1615,y:779,t:1526933378194};\\\", \\\"{x:1615,y:786,t:1526933378211};\\\", \\\"{x:1615,y:791,t:1526933378228};\\\", \\\"{x:1615,y:794,t:1526933378244};\\\", \\\"{x:1615,y:798,t:1526933378261};\\\", \\\"{x:1615,y:809,t:1526933378278};\\\", \\\"{x:1614,y:817,t:1526933378295};\\\", \\\"{x:1614,y:824,t:1526933378312};\\\", \\\"{x:1614,y:827,t:1526933378328};\\\", \\\"{x:1612,y:832,t:1526933378346};\\\", \\\"{x:1612,y:834,t:1526933378361};\\\", \\\"{x:1612,y:835,t:1526933378378};\\\", \\\"{x:1612,y:836,t:1526933378396};\\\", \\\"{x:1612,y:838,t:1526933378412};\\\", \\\"{x:1612,y:841,t:1526933378428};\\\", \\\"{x:1612,y:842,t:1526933378445};\\\", \\\"{x:1612,y:845,t:1526933378461};\\\", \\\"{x:1612,y:849,t:1526933378479};\\\", \\\"{x:1612,y:852,t:1526933378496};\\\", \\\"{x:1612,y:854,t:1526933378511};\\\", \\\"{x:1612,y:858,t:1526933378528};\\\", \\\"{x:1612,y:862,t:1526933378545};\\\", \\\"{x:1612,y:865,t:1526933378561};\\\", \\\"{x:1613,y:870,t:1526933378578};\\\", \\\"{x:1613,y:874,t:1526933378596};\\\", \\\"{x:1614,y:882,t:1526933378612};\\\", \\\"{x:1616,y:894,t:1526933378628};\\\", \\\"{x:1616,y:899,t:1526933378646};\\\", \\\"{x:1619,y:907,t:1526933378662};\\\", \\\"{x:1619,y:909,t:1526933378678};\\\", \\\"{x:1619,y:910,t:1526933378696};\\\", \\\"{x:1620,y:911,t:1526933378734};\\\", \\\"{x:1621,y:910,t:1526933378750};\\\", \\\"{x:1623,y:903,t:1526933378763};\\\", \\\"{x:1624,y:883,t:1526933378779};\\\", \\\"{x:1624,y:828,t:1526933378796};\\\", \\\"{x:1622,y:742,t:1526933378812};\\\", \\\"{x:1610,y:653,t:1526933378828};\\\", \\\"{x:1602,y:594,t:1526933378846};\\\", \\\"{x:1595,y:557,t:1526933378862};\\\", \\\"{x:1589,y:539,t:1526933378879};\\\", \\\"{x:1585,y:523,t:1526933378896};\\\", \\\"{x:1585,y:512,t:1526933378912};\\\", \\\"{x:1585,y:506,t:1526933378928};\\\", \\\"{x:1588,y:498,t:1526933378945};\\\", \\\"{x:1592,y:490,t:1526933378962};\\\", \\\"{x:1596,y:484,t:1526933378979};\\\", \\\"{x:1599,y:475,t:1526933378995};\\\", \\\"{x:1602,y:465,t:1526933379011};\\\", \\\"{x:1605,y:458,t:1526933379029};\\\", \\\"{x:1606,y:452,t:1526933379045};\\\", \\\"{x:1607,y:449,t:1526933379063};\\\", \\\"{x:1608,y:447,t:1526933379079};\\\", \\\"{x:1609,y:444,t:1526933379095};\\\", \\\"{x:1612,y:435,t:1526933379112};\\\", \\\"{x:1613,y:429,t:1526933379130};\\\", \\\"{x:1613,y:424,t:1526933379145};\\\", \\\"{x:1614,y:421,t:1526933379162};\\\", \\\"{x:1614,y:418,t:1526933379179};\\\", \\\"{x:1614,y:417,t:1526933379195};\\\", \\\"{x:1614,y:415,t:1526933379212};\\\", \\\"{x:1614,y:414,t:1526933379229};\\\", \\\"{x:1614,y:413,t:1526933379244};\\\", \\\"{x:1614,y:412,t:1526933379269};\\\", \\\"{x:1614,y:411,t:1526933379317};\\\", \\\"{x:1614,y:412,t:1526933379566};\\\", \\\"{x:1614,y:413,t:1526933379734};\\\", \\\"{x:1614,y:415,t:1526933379750};\\\", \\\"{x:1614,y:416,t:1526933379763};\\\", \\\"{x:1614,y:417,t:1526933379779};\\\", \\\"{x:1614,y:420,t:1526933379796};\\\", \\\"{x:1613,y:420,t:1526933379878};\\\", \\\"{x:1611,y:417,t:1526933379885};\\\", \\\"{x:1606,y:409,t:1526933379897};\\\", \\\"{x:1592,y:388,t:1526933379913};\\\", \\\"{x:1569,y:358,t:1526933379929};\\\", \\\"{x:1549,y:332,t:1526933379946};\\\", \\\"{x:1530,y:308,t:1526933379963};\\\", \\\"{x:1506,y:278,t:1526933379979};\\\", \\\"{x:1493,y:261,t:1526933379996};\\\", \\\"{x:1485,y:249,t:1526933380013};\\\", \\\"{x:1471,y:223,t:1526933380030};\\\", \\\"{x:1463,y:208,t:1526933380046};\\\", \\\"{x:1457,y:199,t:1526933380064};\\\", \\\"{x:1453,y:191,t:1526933380080};\\\", \\\"{x:1450,y:186,t:1526933380096};\\\", \\\"{x:1448,y:182,t:1526933380113};\\\", \\\"{x:1447,y:178,t:1526933380131};\\\", \\\"{x:1446,y:176,t:1526933380147};\\\", \\\"{x:1444,y:171,t:1526933380163};\\\", \\\"{x:1443,y:167,t:1526933380181};\\\", \\\"{x:1442,y:164,t:1526933380197};\\\", \\\"{x:1441,y:160,t:1526933380213};\\\", \\\"{x:1441,y:157,t:1526933380230};\\\", \\\"{x:1441,y:155,t:1526933380246};\\\", \\\"{x:1441,y:154,t:1526933380263};\\\", \\\"{x:1441,y:152,t:1526933380280};\\\", \\\"{x:1441,y:150,t:1526933380296};\\\", \\\"{x:1441,y:149,t:1526933380314};\\\", \\\"{x:1441,y:148,t:1526933380330};\\\", \\\"{x:1443,y:148,t:1526933380494};\\\", \\\"{x:1444,y:148,t:1526933380502};\\\", \\\"{x:1445,y:148,t:1526933380514};\\\", \\\"{x:1446,y:149,t:1526933380531};\\\", \\\"{x:1449,y:152,t:1526933380655};\\\", \\\"{x:1451,y:154,t:1526933380670};\\\", \\\"{x:1453,y:155,t:1526933380681};\\\", \\\"{x:1457,y:157,t:1526933380697};\\\", \\\"{x:1463,y:159,t:1526933380713};\\\", \\\"{x:1466,y:160,t:1526933380730};\\\", \\\"{x:1469,y:160,t:1526933380747};\\\", \\\"{x:1471,y:161,t:1526933380764};\\\", \\\"{x:1471,y:162,t:1526933380780};\\\", \\\"{x:1472,y:162,t:1526933381063};\\\", \\\"{x:1473,y:162,t:1526933381078};\\\", \\\"{x:1474,y:162,t:1526933381085};\\\", \\\"{x:1475,y:162,t:1526933381101};\\\", \\\"{x:1476,y:162,t:1526933381118};\\\", \\\"{x:1477,y:162,t:1526933381131};\\\", \\\"{x:1478,y:162,t:1526933381158};\\\", \\\"{x:1479,y:162,t:1526933381166};\\\", \\\"{x:1480,y:162,t:1526933381190};\\\", \\\"{x:1482,y:161,t:1526933381213};\\\", \\\"{x:1483,y:161,t:1526933381232};\\\", \\\"{x:1485,y:161,t:1526933382615};\\\", \\\"{x:1486,y:162,t:1526933382633};\\\", \\\"{x:1487,y:167,t:1526933382651};\\\", \\\"{x:1487,y:173,t:1526933382665};\\\", \\\"{x:1489,y:184,t:1526933382683};\\\", \\\"{x:1489,y:202,t:1526933382700};\\\", \\\"{x:1489,y:216,t:1526933382715};\\\", \\\"{x:1489,y:228,t:1526933382733};\\\", \\\"{x:1489,y:246,t:1526933382750};\\\", \\\"{x:1489,y:257,t:1526933382766};\\\", \\\"{x:1489,y:266,t:1526933382783};\\\", \\\"{x:1489,y:272,t:1526933382800};\\\", \\\"{x:1489,y:280,t:1526933382816};\\\", \\\"{x:1489,y:292,t:1526933382833};\\\", \\\"{x:1489,y:303,t:1526933382849};\\\", \\\"{x:1489,y:307,t:1526933382866};\\\", \\\"{x:1489,y:311,t:1526933382883};\\\", \\\"{x:1489,y:314,t:1526933382899};\\\", \\\"{x:1489,y:318,t:1526933382917};\\\", \\\"{x:1489,y:321,t:1526933382933};\\\", \\\"{x:1489,y:325,t:1526933382950};\\\", \\\"{x:1489,y:328,t:1526933382966};\\\", \\\"{x:1489,y:331,t:1526933382982};\\\", \\\"{x:1489,y:336,t:1526933383000};\\\", \\\"{x:1489,y:345,t:1526933383017};\\\", \\\"{x:1489,y:358,t:1526933383033};\\\", \\\"{x:1489,y:374,t:1526933383050};\\\", \\\"{x:1489,y:394,t:1526933383066};\\\", \\\"{x:1489,y:412,t:1526933383083};\\\", \\\"{x:1489,y:431,t:1526933383100};\\\", \\\"{x:1489,y:447,t:1526933383117};\\\", \\\"{x:1490,y:461,t:1526933383133};\\\", \\\"{x:1492,y:485,t:1526933383150};\\\", \\\"{x:1494,y:499,t:1526933383166};\\\", \\\"{x:1496,y:513,t:1526933383183};\\\", \\\"{x:1497,y:526,t:1526933383199};\\\", \\\"{x:1499,y:538,t:1526933383217};\\\", \\\"{x:1499,y:547,t:1526933383234};\\\", \\\"{x:1499,y:555,t:1526933383250};\\\", \\\"{x:1499,y:557,t:1526933383267};\\\", \\\"{x:1499,y:559,t:1526933383283};\\\", \\\"{x:1499,y:560,t:1526933383299};\\\", \\\"{x:1501,y:553,t:1526933383414};\\\", \\\"{x:1504,y:528,t:1526933383421};\\\", \\\"{x:1507,y:499,t:1526933383433};\\\", \\\"{x:1509,y:462,t:1526933383450};\\\", \\\"{x:1509,y:446,t:1526933383467};\\\", \\\"{x:1510,y:426,t:1526933383484};\\\", \\\"{x:1510,y:409,t:1526933383499};\\\", \\\"{x:1510,y:391,t:1526933383516};\\\", \\\"{x:1510,y:360,t:1526933383534};\\\", \\\"{x:1510,y:336,t:1526933383550};\\\", \\\"{x:1510,y:316,t:1526933383566};\\\", \\\"{x:1506,y:300,t:1526933383583};\\\", \\\"{x:1506,y:292,t:1526933383601};\\\", \\\"{x:1505,y:283,t:1526933383616};\\\", \\\"{x:1503,y:279,t:1526933383634};\\\", \\\"{x:1502,y:275,t:1526933383650};\\\", \\\"{x:1502,y:271,t:1526933383666};\\\", \\\"{x:1501,y:269,t:1526933383683};\\\", \\\"{x:1501,y:267,t:1526933383700};\\\", \\\"{x:1499,y:263,t:1526933383717};\\\", \\\"{x:1497,y:258,t:1526933383733};\\\", \\\"{x:1496,y:256,t:1526933383750};\\\", \\\"{x:1495,y:255,t:1526933383766};\\\", \\\"{x:1495,y:256,t:1526933384118};\\\", \\\"{x:1501,y:265,t:1526933384133};\\\", \\\"{x:1505,y:274,t:1526933384150};\\\", \\\"{x:1510,y:287,t:1526933384167};\\\", \\\"{x:1512,y:299,t:1526933384183};\\\", \\\"{x:1518,y:316,t:1526933384200};\\\", \\\"{x:1526,y:344,t:1526933384218};\\\", \\\"{x:1538,y:389,t:1526933384233};\\\", \\\"{x:1554,y:442,t:1526933384251};\\\", \\\"{x:1561,y:473,t:1526933384267};\\\", \\\"{x:1563,y:476,t:1526933384284};\\\", \\\"{x:1564,y:476,t:1526933385086};\\\", \\\"{x:1575,y:474,t:1526933385102};\\\", \\\"{x:1576,y:472,t:1526933385119};\\\", \\\"{x:1583,y:469,t:1526933385135};\\\", \\\"{x:1589,y:465,t:1526933385152};\\\", \\\"{x:1590,y:464,t:1526933385168};\\\", \\\"{x:1591,y:463,t:1526933385185};\\\", \\\"{x:1593,y:463,t:1526933385202};\\\", \\\"{x:1595,y:461,t:1526933385219};\\\", \\\"{x:1597,y:460,t:1526933385246};\\\", \\\"{x:1598,y:460,t:1526933385254};\\\", \\\"{x:1599,y:459,t:1526933385269};\\\", \\\"{x:1602,y:457,t:1526933385285};\\\", \\\"{x:1607,y:452,t:1526933385302};\\\", \\\"{x:1613,y:446,t:1526933385318};\\\", \\\"{x:1614,y:443,t:1526933385334};\\\", \\\"{x:1617,y:440,t:1526933385351};\\\", \\\"{x:1617,y:438,t:1526933385369};\\\", \\\"{x:1618,y:438,t:1526933385386};\\\", \\\"{x:1618,y:437,t:1526933385401};\\\", \\\"{x:1619,y:437,t:1526933385878};\\\", \\\"{x:1619,y:435,t:1526933385886};\\\", \\\"{x:1617,y:434,t:1526933385903};\\\", \\\"{x:1615,y:434,t:1526933385919};\\\", \\\"{x:1615,y:433,t:1526933385935};\\\", \\\"{x:1614,y:433,t:1526933385952};\\\", \\\"{x:1613,y:432,t:1526933385968};\\\", \\\"{x:1613,y:433,t:1526933386110};\\\", \\\"{x:1612,y:435,t:1526933386120};\\\", \\\"{x:1611,y:440,t:1526933386137};\\\", \\\"{x:1608,y:446,t:1526933386153};\\\", \\\"{x:1606,y:453,t:1526933386170};\\\", \\\"{x:1605,y:456,t:1526933386186};\\\", \\\"{x:1604,y:460,t:1526933386203};\\\", \\\"{x:1603,y:463,t:1526933386220};\\\", \\\"{x:1603,y:464,t:1526933386236};\\\", \\\"{x:1602,y:465,t:1526933386303};\\\", \\\"{x:1602,y:466,t:1526933386320};\\\", \\\"{x:1602,y:468,t:1526933386336};\\\", \\\"{x:1602,y:469,t:1526933386352};\\\", \\\"{x:1601,y:470,t:1526933386370};\\\", \\\"{x:1601,y:472,t:1526933386386};\\\", \\\"{x:1600,y:476,t:1526933386403};\\\", \\\"{x:1597,y:484,t:1526933386420};\\\", \\\"{x:1592,y:494,t:1526933386437};\\\", \\\"{x:1586,y:503,t:1526933386453};\\\", \\\"{x:1578,y:524,t:1526933386470};\\\", \\\"{x:1572,y:538,t:1526933386486};\\\", \\\"{x:1565,y:552,t:1526933386503};\\\", \\\"{x:1561,y:562,t:1526933386520};\\\", \\\"{x:1557,y:568,t:1526933386537};\\\", \\\"{x:1553,y:573,t:1526933386553};\\\", \\\"{x:1549,y:578,t:1526933386570};\\\", \\\"{x:1546,y:587,t:1526933386587};\\\", \\\"{x:1541,y:600,t:1526933386603};\\\", \\\"{x:1537,y:615,t:1526933386620};\\\", \\\"{x:1534,y:627,t:1526933386637};\\\", \\\"{x:1532,y:632,t:1526933386653};\\\", \\\"{x:1531,y:635,t:1526933386670};\\\", \\\"{x:1531,y:636,t:1526933386687};\\\", \\\"{x:1529,y:639,t:1526933386703};\\\", \\\"{x:1529,y:641,t:1526933386720};\\\", \\\"{x:1528,y:643,t:1526933386737};\\\", \\\"{x:1528,y:645,t:1526933386753};\\\", \\\"{x:1527,y:648,t:1526933386770};\\\", \\\"{x:1526,y:650,t:1526933386786};\\\", \\\"{x:1524,y:655,t:1526933386804};\\\", \\\"{x:1521,y:662,t:1526933386820};\\\", \\\"{x:1519,y:668,t:1526933386837};\\\", \\\"{x:1511,y:689,t:1526933386854};\\\", \\\"{x:1505,y:703,t:1526933386870};\\\", \\\"{x:1495,y:719,t:1526933386887};\\\", \\\"{x:1487,y:734,t:1526933386904};\\\", \\\"{x:1479,y:746,t:1526933386919};\\\", \\\"{x:1472,y:757,t:1526933386936};\\\", \\\"{x:1467,y:771,t:1526933386953};\\\", \\\"{x:1457,y:783,t:1526933386970};\\\", \\\"{x:1445,y:800,t:1526933386986};\\\", \\\"{x:1435,y:813,t:1526933387003};\\\", \\\"{x:1427,y:826,t:1526933387019};\\\", \\\"{x:1421,y:834,t:1526933387036};\\\", \\\"{x:1416,y:846,t:1526933387054};\\\", \\\"{x:1411,y:856,t:1526933387069};\\\", \\\"{x:1406,y:868,t:1526933387087};\\\", \\\"{x:1401,y:880,t:1526933387103};\\\", \\\"{x:1394,y:895,t:1526933387120};\\\", \\\"{x:1389,y:904,t:1526933387137};\\\", \\\"{x:1387,y:910,t:1526933387153};\\\", \\\"{x:1384,y:917,t:1526933387171};\\\", \\\"{x:1383,y:922,t:1526933387187};\\\", \\\"{x:1383,y:929,t:1526933387204};\\\", \\\"{x:1383,y:933,t:1526933387221};\\\", \\\"{x:1383,y:937,t:1526933387237};\\\", \\\"{x:1381,y:942,t:1526933387254};\\\", \\\"{x:1380,y:944,t:1526933387271};\\\", \\\"{x:1379,y:947,t:1526933387286};\\\", \\\"{x:1378,y:949,t:1526933387303};\\\", \\\"{x:1377,y:951,t:1526933387321};\\\", \\\"{x:1376,y:952,t:1526933387358};\\\", \\\"{x:1375,y:954,t:1526933387373};\\\", \\\"{x:1373,y:956,t:1526933387398};\\\", \\\"{x:1371,y:958,t:1526933387406};\\\", \\\"{x:1370,y:959,t:1526933387422};\\\", \\\"{x:1368,y:959,t:1526933387437};\\\", \\\"{x:1363,y:963,t:1526933387454};\\\", \\\"{x:1361,y:964,t:1526933387470};\\\", \\\"{x:1358,y:966,t:1526933387488};\\\", \\\"{x:1355,y:967,t:1526933387504};\\\", \\\"{x:1354,y:968,t:1526933387520};\\\", \\\"{x:1352,y:968,t:1526933387537};\\\", \\\"{x:1351,y:968,t:1526933387557};\\\", \\\"{x:1350,y:968,t:1526933387598};\\\", \\\"{x:1349,y:968,t:1526933387622};\\\", \\\"{x:1348,y:968,t:1526933387718};\\\", \\\"{x:1348,y:967,t:1526933388813};\\\", \\\"{x:1348,y:963,t:1526933388821};\\\", \\\"{x:1348,y:952,t:1526933388838};\\\", \\\"{x:1357,y:932,t:1526933388854};\\\", \\\"{x:1366,y:915,t:1526933388871};\\\", \\\"{x:1377,y:898,t:1526933388889};\\\", \\\"{x:1387,y:885,t:1526933388906};\\\", \\\"{x:1396,y:871,t:1526933388922};\\\", \\\"{x:1402,y:861,t:1526933388938};\\\", \\\"{x:1408,y:851,t:1526933388955};\\\", \\\"{x:1418,y:832,t:1526933388971};\\\", \\\"{x:1424,y:816,t:1526933388988};\\\", \\\"{x:1434,y:795,t:1526933389006};\\\", \\\"{x:1439,y:786,t:1526933389022};\\\", \\\"{x:1444,y:776,t:1526933389039};\\\", \\\"{x:1451,y:765,t:1526933389055};\\\", \\\"{x:1459,y:752,t:1526933389071};\\\", \\\"{x:1469,y:734,t:1526933389089};\\\", \\\"{x:1475,y:721,t:1526933389106};\\\", \\\"{x:1484,y:705,t:1526933389121};\\\", \\\"{x:1493,y:686,t:1526933389138};\\\", \\\"{x:1501,y:672,t:1526933389155};\\\", \\\"{x:1511,y:657,t:1526933389171};\\\", \\\"{x:1519,y:643,t:1526933389188};\\\", \\\"{x:1527,y:626,t:1526933389205};\\\", \\\"{x:1532,y:616,t:1526933389223};\\\", \\\"{x:1535,y:609,t:1526933389239};\\\", \\\"{x:1540,y:600,t:1526933389256};\\\", \\\"{x:1544,y:592,t:1526933389272};\\\", \\\"{x:1546,y:588,t:1526933389289};\\\", \\\"{x:1547,y:583,t:1526933389306};\\\", \\\"{x:1548,y:582,t:1526933389323};\\\", \\\"{x:1548,y:581,t:1526933389339};\\\", \\\"{x:1549,y:579,t:1526933389357};\\\", \\\"{x:1549,y:578,t:1526933389381};\\\", \\\"{x:1549,y:576,t:1526933389398};\\\", \\\"{x:1549,y:575,t:1526933389422};\\\", \\\"{x:1549,y:573,t:1526933389439};\\\", \\\"{x:1549,y:572,t:1526933389456};\\\", \\\"{x:1549,y:570,t:1526933389473};\\\", \\\"{x:1549,y:567,t:1526933389489};\\\", \\\"{x:1550,y:564,t:1526933389506};\\\", \\\"{x:1550,y:560,t:1526933389523};\\\", \\\"{x:1552,y:558,t:1526933389539};\\\", \\\"{x:1552,y:555,t:1526933389556};\\\", \\\"{x:1552,y:552,t:1526933389573};\\\", \\\"{x:1556,y:545,t:1526933389589};\\\", \\\"{x:1563,y:528,t:1526933389606};\\\", \\\"{x:1571,y:512,t:1526933389623};\\\", \\\"{x:1577,y:503,t:1526933389640};\\\", \\\"{x:1582,y:495,t:1526933389656};\\\", \\\"{x:1586,y:486,t:1526933389673};\\\", \\\"{x:1593,y:475,t:1526933389690};\\\", \\\"{x:1600,y:465,t:1526933389706};\\\", \\\"{x:1607,y:456,t:1526933389723};\\\", \\\"{x:1611,y:450,t:1526933389740};\\\", \\\"{x:1614,y:443,t:1526933389756};\\\", \\\"{x:1616,y:436,t:1526933389773};\\\", \\\"{x:1621,y:429,t:1526933389788};\\\", \\\"{x:1623,y:426,t:1526933389805};\\\", \\\"{x:1624,y:424,t:1526933389822};\\\", \\\"{x:1624,y:422,t:1526933389840};\\\", \\\"{x:1625,y:421,t:1526933389855};\\\", \\\"{x:1626,y:420,t:1526933389873};\\\", \\\"{x:1626,y:419,t:1526933389925};\\\", \\\"{x:1626,y:424,t:1526933390150};\\\", \\\"{x:1626,y:429,t:1526933390158};\\\", \\\"{x:1626,y:433,t:1526933390173};\\\", \\\"{x:1626,y:446,t:1526933390190};\\\", \\\"{x:1626,y:454,t:1526933390207};\\\", \\\"{x:1626,y:462,t:1526933390223};\\\", \\\"{x:1626,y:467,t:1526933390239};\\\", \\\"{x:1626,y:473,t:1526933390257};\\\", \\\"{x:1626,y:478,t:1526933390273};\\\", \\\"{x:1626,y:482,t:1526933390289};\\\", \\\"{x:1626,y:489,t:1526933390306};\\\", \\\"{x:1626,y:494,t:1526933390323};\\\", \\\"{x:1626,y:501,t:1526933390339};\\\", \\\"{x:1626,y:508,t:1526933390357};\\\", \\\"{x:1626,y:516,t:1526933390374};\\\", \\\"{x:1626,y:520,t:1526933390390};\\\", \\\"{x:1626,y:523,t:1526933390406};\\\", \\\"{x:1626,y:527,t:1526933390424};\\\", \\\"{x:1626,y:531,t:1526933390440};\\\", \\\"{x:1626,y:535,t:1526933390457};\\\", \\\"{x:1626,y:537,t:1526933390474};\\\", \\\"{x:1626,y:541,t:1526933390490};\\\", \\\"{x:1626,y:545,t:1526933390507};\\\", \\\"{x:1626,y:548,t:1526933390524};\\\", \\\"{x:1626,y:555,t:1526933390540};\\\", \\\"{x:1626,y:559,t:1526933390557};\\\", \\\"{x:1626,y:566,t:1526933390574};\\\", \\\"{x:1626,y:570,t:1526933390590};\\\", \\\"{x:1626,y:573,t:1526933390607};\\\", \\\"{x:1626,y:577,t:1526933390624};\\\", \\\"{x:1626,y:582,t:1526933390641};\\\", \\\"{x:1626,y:589,t:1526933390657};\\\", \\\"{x:1626,y:598,t:1526933390674};\\\", \\\"{x:1626,y:605,t:1526933390691};\\\", \\\"{x:1626,y:610,t:1526933390708};\\\", \\\"{x:1626,y:614,t:1526933390724};\\\", \\\"{x:1625,y:621,t:1526933390741};\\\", \\\"{x:1625,y:625,t:1526933390757};\\\", \\\"{x:1625,y:630,t:1526933390774};\\\", \\\"{x:1624,y:632,t:1526933390791};\\\", \\\"{x:1624,y:637,t:1526933390807};\\\", \\\"{x:1623,y:642,t:1526933390824};\\\", \\\"{x:1620,y:651,t:1526933390841};\\\", \\\"{x:1620,y:656,t:1526933390856};\\\", \\\"{x:1619,y:667,t:1526933390874};\\\", \\\"{x:1617,y:678,t:1526933390890};\\\", \\\"{x:1611,y:694,t:1526933390907};\\\", \\\"{x:1609,y:704,t:1526933390924};\\\", \\\"{x:1606,y:712,t:1526933390941};\\\", \\\"{x:1605,y:720,t:1526933390958};\\\", \\\"{x:1604,y:724,t:1526933390974};\\\", \\\"{x:1604,y:728,t:1526933390991};\\\", \\\"{x:1604,y:734,t:1526933391007};\\\", \\\"{x:1604,y:739,t:1526933391024};\\\", \\\"{x:1604,y:745,t:1526933391041};\\\", \\\"{x:1604,y:750,t:1526933391058};\\\", \\\"{x:1604,y:757,t:1526933391074};\\\", \\\"{x:1604,y:762,t:1526933391091};\\\", \\\"{x:1604,y:770,t:1526933391109};\\\", \\\"{x:1604,y:778,t:1526933391124};\\\", \\\"{x:1604,y:782,t:1526933391141};\\\", \\\"{x:1604,y:789,t:1526933391157};\\\", \\\"{x:1604,y:796,t:1526933391174};\\\", \\\"{x:1604,y:801,t:1526933391191};\\\", \\\"{x:1604,y:808,t:1526933391208};\\\", \\\"{x:1604,y:815,t:1526933391225};\\\", \\\"{x:1604,y:821,t:1526933391241};\\\", \\\"{x:1604,y:826,t:1526933391258};\\\", \\\"{x:1604,y:830,t:1526933391274};\\\", \\\"{x:1604,y:835,t:1526933391291};\\\", \\\"{x:1604,y:840,t:1526933391310};\\\", \\\"{x:1604,y:846,t:1526933391325};\\\", \\\"{x:1606,y:854,t:1526933391341};\\\", \\\"{x:1607,y:867,t:1526933391358};\\\", \\\"{x:1608,y:877,t:1526933391374};\\\", \\\"{x:1610,y:891,t:1526933391391};\\\", \\\"{x:1614,y:906,t:1526933391408};\\\", \\\"{x:1614,y:918,t:1526933391425};\\\", \\\"{x:1614,y:929,t:1526933391441};\\\", \\\"{x:1614,y:933,t:1526933391458};\\\", \\\"{x:1614,y:936,t:1526933391475};\\\", \\\"{x:1613,y:937,t:1526933391491};\\\", \\\"{x:1607,y:938,t:1526933391509};\\\", \\\"{x:1585,y:938,t:1526933391525};\\\", \\\"{x:1527,y:924,t:1526933391541};\\\", \\\"{x:1383,y:884,t:1526933391558};\\\", \\\"{x:1268,y:857,t:1526933391575};\\\", \\\"{x:1145,y:830,t:1526933391591};\\\", \\\"{x:995,y:811,t:1526933391609};\\\", \\\"{x:854,y:789,t:1526933391625};\\\", \\\"{x:715,y:768,t:1526933391640};\\\", \\\"{x:615,y:752,t:1526933391658};\\\", \\\"{x:542,y:742,t:1526933391676};\\\", \\\"{x:498,y:736,t:1526933391691};\\\", \\\"{x:474,y:733,t:1526933391708};\\\", \\\"{x:466,y:732,t:1526933391725};\\\", \\\"{x:463,y:730,t:1526933391741};\\\", \\\"{x:462,y:730,t:1526933391813};\\\", \\\"{x:461,y:730,t:1526933391829};\\\", \\\"{x:457,y:729,t:1526933391845};\\\", \\\"{x:454,y:726,t:1526933391862};\\\", \\\"{x:443,y:718,t:1526933391879};\\\", \\\"{x:436,y:713,t:1526933391896};\\\", \\\"{x:425,y:701,t:1526933391917};\\\", \\\"{x:417,y:693,t:1526933391933};\\\", \\\"{x:407,y:684,t:1526933391951};\\\", \\\"{x:395,y:675,t:1526933391968};\\\", \\\"{x:380,y:663,t:1526933391983};\\\", \\\"{x:363,y:641,t:1526933392002};\\\", \\\"{x:340,y:612,t:1526933392018};\\\", \\\"{x:320,y:592,t:1526933392034};\\\", \\\"{x:296,y:571,t:1526933392051};\\\", \\\"{x:271,y:553,t:1526933392068};\\\", \\\"{x:248,y:540,t:1526933392084};\\\", \\\"{x:233,y:532,t:1526933392101};\\\", \\\"{x:217,y:521,t:1526933392117};\\\", \\\"{x:215,y:520,t:1526933392133};\\\", \\\"{x:211,y:517,t:1526933392151};\\\", \\\"{x:210,y:517,t:1526933392398};\\\", \\\"{x:210,y:520,t:1526933392478};\\\", \\\"{x:210,y:526,t:1526933392485};\\\", \\\"{x:210,y:535,t:1526933392500};\\\", \\\"{x:210,y:556,t:1526933392518};\\\", \\\"{x:210,y:567,t:1526933392534};\\\", \\\"{x:210,y:578,t:1526933392551};\\\", \\\"{x:210,y:583,t:1526933392568};\\\", \\\"{x:210,y:590,t:1526933392584};\\\", \\\"{x:209,y:594,t:1526933392600};\\\", \\\"{x:206,y:599,t:1526933392618};\\\", \\\"{x:203,y:603,t:1526933392634};\\\", \\\"{x:200,y:606,t:1526933392651};\\\", \\\"{x:197,y:608,t:1526933392667};\\\", \\\"{x:194,y:608,t:1526933392684};\\\", \\\"{x:190,y:611,t:1526933392701};\\\", \\\"{x:176,y:616,t:1526933392718};\\\", \\\"{x:164,y:623,t:1526933392736};\\\", \\\"{x:155,y:628,t:1526933392752};\\\", \\\"{x:147,y:632,t:1526933392768};\\\", \\\"{x:142,y:636,t:1526933392784};\\\", \\\"{x:139,y:638,t:1526933392802};\\\", \\\"{x:138,y:638,t:1526933392818};\\\", \\\"{x:136,y:639,t:1526933392834};\\\", \\\"{x:136,y:640,t:1526933392861};\\\", \\\"{x:135,y:640,t:1526933392869};\\\", \\\"{x:134,y:641,t:1526933392909};\\\", \\\"{x:134,y:642,t:1526933393125};\\\", \\\"{x:135,y:643,t:1526933393136};\\\", \\\"{x:138,y:643,t:1526933393153};\\\", \\\"{x:142,y:644,t:1526933393168};\\\", \\\"{x:147,y:644,t:1526933393186};\\\", \\\"{x:150,y:645,t:1526933393203};\\\", \\\"{x:152,y:645,t:1526933393219};\\\", \\\"{x:153,y:645,t:1526933393237};\\\", \\\"{x:154,y:645,t:1526933393250};\\\", \\\"{x:154,y:647,t:1526933393879};\\\", \\\"{x:161,y:657,t:1526933393887};\\\", \\\"{x:184,y:682,t:1526933393902};\\\", \\\"{x:224,y:712,t:1526933393918};\\\", \\\"{x:275,y:741,t:1526933393935};\\\", \\\"{x:338,y:763,t:1526933393953};\\\", \\\"{x:407,y:781,t:1526933393968};\\\", \\\"{x:480,y:793,t:1526933393986};\\\", \\\"{x:567,y:810,t:1526933394003};\\\", \\\"{x:634,y:821,t:1526933394019};\\\", \\\"{x:695,y:829,t:1526933394035};\\\", \\\"{x:743,y:837,t:1526933394052};\\\", \\\"{x:777,y:842,t:1526933394068};\\\", \\\"{x:817,y:842,t:1526933394086};\\\", \\\"{x:832,y:842,t:1526933394103};\\\", \\\"{x:845,y:842,t:1526933394119};\\\", \\\"{x:848,y:842,t:1526933394135};\\\", \\\"{x:851,y:842,t:1526933394152};\\\", \\\"{x:851,y:841,t:1526933396550};\\\", \\\"{x:832,y:826,t:1526933396558};\\\", \\\"{x:806,y:805,t:1526933396572};\\\", \\\"{x:760,y:778,t:1526933396589};\\\", \\\"{x:701,y:755,t:1526933396606};\\\", \\\"{x:643,y:738,t:1526933396622};\\\", \\\"{x:568,y:716,t:1526933396639};\\\", \\\"{x:512,y:699,t:1526933396657};\\\", \\\"{x:469,y:692,t:1526933396672};\\\", \\\"{x:444,y:687,t:1526933396689};\\\", \\\"{x:430,y:686,t:1526933396707};\\\", \\\"{x:424,y:685,t:1526933396722};\\\", \\\"{x:422,y:684,t:1526933396740};\\\", \\\"{x:421,y:684,t:1526933396790};\\\", \\\"{x:421,y:685,t:1526933396806};\\\", \\\"{x:421,y:688,t:1526933396822};\\\", \\\"{x:422,y:689,t:1526933396839};\\\", \\\"{x:424,y:692,t:1526933396856};\\\", \\\"{x:425,y:694,t:1526933396873};\\\", \\\"{x:427,y:696,t:1526933396889};\\\", \\\"{x:428,y:696,t:1526933396950};\\\", \\\"{x:431,y:696,t:1526933396957};\\\", \\\"{x:431,y:697,t:1526933396973};\\\", \\\"{x:436,y:699,t:1526933396989};\\\", \\\"{x:443,y:703,t:1526933397006};\\\", \\\"{x:452,y:706,t:1526933397024};\\\", \\\"{x:459,y:709,t:1526933397039};\\\", \\\"{x:467,y:712,t:1526933397055};\\\", \\\"{x:468,y:712,t:1526933397071};\\\", \\\"{x:472,y:712,t:1526933397087};\\\", \\\"{x:473,y:712,t:1526933397104};\\\", \\\"{x:475,y:713,t:1526933397120};\\\", \\\"{x:477,y:714,t:1526933397137};\\\", \\\"{x:479,y:715,t:1526933397155};\\\", \\\"{x:480,y:715,t:1526933397181};\\\" ] }, { \\\"rt\\\": 25029, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 182801, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -A -C -A -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:715,t:1526933405902};\\\", \\\"{x:484,y:715,t:1526933405918};\\\", \\\"{x:486,y:715,t:1526933405931};\\\", \\\"{x:487,y:715,t:1526933405949};\\\", \\\"{x:488,y:715,t:1526933406093};\\\", \\\"{x:492,y:715,t:1526933406494};\\\", \\\"{x:496,y:715,t:1526933406502};\\\", \\\"{x:498,y:715,t:1526933406516};\\\", \\\"{x:505,y:715,t:1526933406533};\\\", \\\"{x:509,y:715,t:1526933406551};\\\", \\\"{x:511,y:715,t:1526933406622};\\\", \\\"{x:512,y:715,t:1526933406638};\\\", \\\"{x:513,y:715,t:1526933406654};\\\", \\\"{x:514,y:715,t:1526933406667};\\\", \\\"{x:516,y:714,t:1526933406683};\\\", \\\"{x:518,y:714,t:1526933406700};\\\", \\\"{x:520,y:714,t:1526933406717};\\\", \\\"{x:521,y:714,t:1526933406733};\\\", \\\"{x:522,y:714,t:1526933406766};\\\", \\\"{x:523,y:714,t:1526933406790};\\\", \\\"{x:524,y:714,t:1526933406846};\\\", \\\"{x:524,y:713,t:1526933406886};\\\", \\\"{x:525,y:713,t:1526933406902};\\\", \\\"{x:527,y:711,t:1526933406917};\\\", \\\"{x:534,y:710,t:1526933406934};\\\", \\\"{x:544,y:707,t:1526933406951};\\\", \\\"{x:558,y:703,t:1526933406967};\\\", \\\"{x:577,y:700,t:1526933406986};\\\", \\\"{x:600,y:696,t:1526933407000};\\\", \\\"{x:629,y:694,t:1526933407017};\\\", \\\"{x:661,y:690,t:1526933407029};\\\", \\\"{x:692,y:689,t:1526933407045};\\\", \\\"{x:731,y:689,t:1526933407062};\\\", \\\"{x:773,y:689,t:1526933407079};\\\", \\\"{x:817,y:689,t:1526933407095};\\\", \\\"{x:860,y:689,t:1526933407112};\\\", \\\"{x:891,y:689,t:1526933407129};\\\", \\\"{x:919,y:689,t:1526933407145};\\\", \\\"{x:948,y:689,t:1526933407162};\\\", \\\"{x:972,y:689,t:1526933407179};\\\", \\\"{x:986,y:689,t:1526933407195};\\\", \\\"{x:998,y:689,t:1526933407212};\\\", \\\"{x:1011,y:689,t:1526933407229};\\\", \\\"{x:1016,y:688,t:1526933407245};\\\", \\\"{x:1022,y:688,t:1526933407262};\\\", \\\"{x:1030,y:688,t:1526933407280};\\\", \\\"{x:1042,y:685,t:1526933407295};\\\", \\\"{x:1052,y:684,t:1526933407313};\\\", \\\"{x:1068,y:681,t:1526933407329};\\\", \\\"{x:1084,y:680,t:1526933407346};\\\", \\\"{x:1100,y:677,t:1526933407363};\\\", \\\"{x:1110,y:675,t:1526933407379};\\\", \\\"{x:1117,y:674,t:1526933407396};\\\", \\\"{x:1122,y:671,t:1526933407412};\\\", \\\"{x:1125,y:671,t:1526933407429};\\\", \\\"{x:1125,y:670,t:1526933407822};\\\", \\\"{x:1127,y:667,t:1526933407829};\\\", \\\"{x:1141,y:654,t:1526933407846};\\\", \\\"{x:1153,y:643,t:1526933407862};\\\", \\\"{x:1176,y:616,t:1526933407879};\\\", \\\"{x:1225,y:556,t:1526933407897};\\\", \\\"{x:1268,y:507,t:1526933407913};\\\", \\\"{x:1299,y:464,t:1526933407929};\\\", \\\"{x:1327,y:425,t:1526933407947};\\\", \\\"{x:1353,y:392,t:1526933407964};\\\", \\\"{x:1377,y:364,t:1526933407979};\\\", \\\"{x:1391,y:348,t:1526933407997};\\\", \\\"{x:1407,y:326,t:1526933408013};\\\", \\\"{x:1416,y:315,t:1526933408029};\\\", \\\"{x:1426,y:304,t:1526933408046};\\\", \\\"{x:1434,y:295,t:1526933408064};\\\", \\\"{x:1442,y:287,t:1526933408080};\\\", \\\"{x:1445,y:284,t:1526933408097};\\\", \\\"{x:1449,y:281,t:1526933408114};\\\", \\\"{x:1450,y:281,t:1526933408129};\\\", \\\"{x:1452,y:280,t:1526933408147};\\\", \\\"{x:1454,y:284,t:1526933408199};\\\", \\\"{x:1465,y:306,t:1526933408214};\\\", \\\"{x:1475,y:329,t:1526933408230};\\\", \\\"{x:1482,y:354,t:1526933408247};\\\", \\\"{x:1492,y:381,t:1526933408263};\\\", \\\"{x:1499,y:404,t:1526933408280};\\\", \\\"{x:1504,y:422,t:1526933408297};\\\", \\\"{x:1509,y:435,t:1526933408313};\\\", \\\"{x:1513,y:448,t:1526933408329};\\\", \\\"{x:1518,y:459,t:1526933408346};\\\", \\\"{x:1521,y:467,t:1526933408363};\\\", \\\"{x:1523,y:470,t:1526933408379};\\\", \\\"{x:1523,y:475,t:1526933408396};\\\", \\\"{x:1525,y:478,t:1526933408413};\\\", \\\"{x:1525,y:480,t:1526933408430};\\\", \\\"{x:1526,y:483,t:1526933408446};\\\", \\\"{x:1528,y:488,t:1526933408463};\\\", \\\"{x:1528,y:496,t:1526933408480};\\\", \\\"{x:1528,y:503,t:1526933408497};\\\", \\\"{x:1529,y:512,t:1526933408513};\\\", \\\"{x:1529,y:518,t:1526933408531};\\\", \\\"{x:1529,y:525,t:1526933408547};\\\", \\\"{x:1529,y:532,t:1526933408563};\\\", \\\"{x:1529,y:545,t:1526933408580};\\\", \\\"{x:1527,y:559,t:1526933408597};\\\", \\\"{x:1523,y:580,t:1526933408613};\\\", \\\"{x:1522,y:593,t:1526933408631};\\\", \\\"{x:1521,y:608,t:1526933408647};\\\", \\\"{x:1518,y:622,t:1526933408664};\\\", \\\"{x:1518,y:631,t:1526933408683};\\\", \\\"{x:1518,y:638,t:1526933408696};\\\", \\\"{x:1518,y:644,t:1526933408713};\\\", \\\"{x:1518,y:650,t:1526933408730};\\\", \\\"{x:1518,y:654,t:1526933408746};\\\", \\\"{x:1518,y:659,t:1526933408763};\\\", \\\"{x:1518,y:666,t:1526933408780};\\\", \\\"{x:1518,y:674,t:1526933408796};\\\", \\\"{x:1515,y:684,t:1526933408812};\\\", \\\"{x:1511,y:687,t:1526933408830};\\\", \\\"{x:1503,y:690,t:1526933408846};\\\", \\\"{x:1487,y:691,t:1526933408863};\\\", \\\"{x:1466,y:691,t:1526933408880};\\\", \\\"{x:1442,y:691,t:1526933408896};\\\", \\\"{x:1419,y:691,t:1526933408913};\\\", \\\"{x:1398,y:691,t:1526933408930};\\\", \\\"{x:1378,y:691,t:1526933408947};\\\", \\\"{x:1363,y:691,t:1526933408963};\\\", \\\"{x:1351,y:688,t:1526933408980};\\\", \\\"{x:1343,y:686,t:1526933408998};\\\", \\\"{x:1339,y:684,t:1526933409013};\\\", \\\"{x:1337,y:682,t:1526933409142};\\\", \\\"{x:1336,y:681,t:1526933409166};\\\", \\\"{x:1336,y:680,t:1526933409181};\\\", \\\"{x:1329,y:676,t:1526933409197};\\\", \\\"{x:1326,y:675,t:1526933409214};\\\", \\\"{x:1322,y:674,t:1526933409231};\\\", \\\"{x:1320,y:674,t:1526933409248};\\\", \\\"{x:1319,y:674,t:1526933409263};\\\", \\\"{x:1317,y:674,t:1526933409281};\\\", \\\"{x:1316,y:674,t:1526933409297};\\\", \\\"{x:1314,y:676,t:1526933409314};\\\", \\\"{x:1314,y:682,t:1526933409330};\\\", \\\"{x:1314,y:688,t:1526933409348};\\\", \\\"{x:1314,y:695,t:1526933409363};\\\", \\\"{x:1314,y:704,t:1526933409381};\\\", \\\"{x:1314,y:718,t:1526933409398};\\\", \\\"{x:1314,y:729,t:1526933409414};\\\", \\\"{x:1314,y:738,t:1526933409430};\\\", \\\"{x:1314,y:746,t:1526933409448};\\\", \\\"{x:1313,y:751,t:1526933409463};\\\", \\\"{x:1312,y:754,t:1526933409481};\\\", \\\"{x:1312,y:756,t:1526933409497};\\\", \\\"{x:1312,y:758,t:1526933409514};\\\", \\\"{x:1310,y:761,t:1526933409530};\\\", \\\"{x:1309,y:764,t:1526933409548};\\\", \\\"{x:1308,y:765,t:1526933409565};\\\", \\\"{x:1307,y:767,t:1526933409580};\\\", \\\"{x:1306,y:774,t:1526933409597};\\\", \\\"{x:1302,y:782,t:1526933409614};\\\", \\\"{x:1297,y:792,t:1526933409631};\\\", \\\"{x:1290,y:802,t:1526933409648};\\\", \\\"{x:1281,y:813,t:1526933409665};\\\", \\\"{x:1273,y:822,t:1526933409681};\\\", \\\"{x:1266,y:832,t:1526933409698};\\\", \\\"{x:1258,y:837,t:1526933409715};\\\", \\\"{x:1251,y:842,t:1526933409731};\\\", \\\"{x:1247,y:845,t:1526933409748};\\\", \\\"{x:1243,y:846,t:1526933409764};\\\", \\\"{x:1240,y:848,t:1526933409780};\\\", \\\"{x:1237,y:849,t:1526933409797};\\\", \\\"{x:1236,y:849,t:1526933409814};\\\", \\\"{x:1234,y:849,t:1526933409831};\\\", \\\"{x:1233,y:849,t:1526933409847};\\\", \\\"{x:1232,y:849,t:1526933409864};\\\", \\\"{x:1229,y:849,t:1526933409880};\\\", \\\"{x:1228,y:848,t:1526933409901};\\\", \\\"{x:1227,y:848,t:1526933409914};\\\", \\\"{x:1226,y:848,t:1526933409932};\\\", \\\"{x:1225,y:847,t:1526933409948};\\\", \\\"{x:1225,y:846,t:1526933409965};\\\", \\\"{x:1224,y:846,t:1526933410013};\\\", \\\"{x:1224,y:845,t:1526933410032};\\\", \\\"{x:1223,y:843,t:1526933410054};\\\", \\\"{x:1222,y:842,t:1526933410077};\\\", \\\"{x:1222,y:841,t:1526933410094};\\\", \\\"{x:1221,y:841,t:1526933410101};\\\", \\\"{x:1221,y:840,t:1526933410117};\\\", \\\"{x:1220,y:839,t:1526933410133};\\\", \\\"{x:1219,y:838,t:1526933410158};\\\", \\\"{x:1218,y:838,t:1526933410166};\\\", \\\"{x:1216,y:837,t:1526933410182};\\\", \\\"{x:1215,y:836,t:1526933410198};\\\", \\\"{x:1214,y:835,t:1526933410222};\\\", \\\"{x:1213,y:833,t:1526933410248};\\\", \\\"{x:1211,y:832,t:1526933410265};\\\", \\\"{x:1211,y:831,t:1526933410293};\\\", \\\"{x:1216,y:831,t:1526933419246};\\\", \\\"{x:1220,y:831,t:1526933419254};\\\", \\\"{x:1235,y:831,t:1526933419273};\\\", \\\"{x:1247,y:831,t:1526933419287};\\\", \\\"{x:1260,y:831,t:1526933419304};\\\", \\\"{x:1271,y:831,t:1526933419321};\\\", \\\"{x:1277,y:831,t:1526933419337};\\\", \\\"{x:1281,y:831,t:1526933419353};\\\", \\\"{x:1283,y:832,t:1526933419370};\\\", \\\"{x:1284,y:832,t:1526933419421};\\\", \\\"{x:1286,y:832,t:1526933419436};\\\", \\\"{x:1288,y:832,t:1526933419454};\\\", \\\"{x:1290,y:832,t:1526933419470};\\\", \\\"{x:1293,y:832,t:1526933419488};\\\", \\\"{x:1295,y:832,t:1526933419503};\\\", \\\"{x:1298,y:833,t:1526933419521};\\\", \\\"{x:1302,y:833,t:1526933419538};\\\", \\\"{x:1307,y:833,t:1526933419554};\\\", \\\"{x:1313,y:833,t:1526933419571};\\\", \\\"{x:1319,y:833,t:1526933419587};\\\", \\\"{x:1327,y:833,t:1526933419604};\\\", \\\"{x:1335,y:833,t:1526933419621};\\\", \\\"{x:1341,y:833,t:1526933419637};\\\", \\\"{x:1345,y:833,t:1526933419654};\\\", \\\"{x:1347,y:833,t:1526933419671};\\\", \\\"{x:1348,y:833,t:1526933419688};\\\", \\\"{x:1349,y:833,t:1526933419704};\\\", \\\"{x:1350,y:833,t:1526933419721};\\\", \\\"{x:1351,y:833,t:1526933419738};\\\", \\\"{x:1352,y:833,t:1526933419754};\\\", \\\"{x:1353,y:833,t:1526933419853};\\\", \\\"{x:1352,y:833,t:1526933419942};\\\", \\\"{x:1351,y:833,t:1526933419957};\\\", \\\"{x:1349,y:833,t:1526933419971};\\\", \\\"{x:1347,y:831,t:1526933419988};\\\", \\\"{x:1345,y:831,t:1526933420006};\\\", \\\"{x:1345,y:830,t:1526933420654};\\\", \\\"{x:1345,y:829,t:1526933420686};\\\", \\\"{x:1345,y:828,t:1526933420717};\\\", \\\"{x:1345,y:827,t:1526933420726};\\\", \\\"{x:1345,y:826,t:1526933420741};\\\", \\\"{x:1345,y:827,t:1526933421092};\\\", \\\"{x:1345,y:828,t:1526933421105};\\\", \\\"{x:1345,y:831,t:1526933421121};\\\", \\\"{x:1345,y:835,t:1526933421139};\\\", \\\"{x:1345,y:842,t:1526933421154};\\\", \\\"{x:1345,y:847,t:1526933421171};\\\", \\\"{x:1345,y:858,t:1526933421188};\\\", \\\"{x:1345,y:861,t:1526933421205};\\\", \\\"{x:1345,y:864,t:1526933421222};\\\", \\\"{x:1345,y:869,t:1526933421239};\\\", \\\"{x:1345,y:870,t:1526933421254};\\\", \\\"{x:1345,y:872,t:1526933421272};\\\", \\\"{x:1345,y:876,t:1526933421289};\\\", \\\"{x:1345,y:878,t:1526933421305};\\\", \\\"{x:1345,y:880,t:1526933421322};\\\", \\\"{x:1345,y:881,t:1526933421339};\\\", \\\"{x:1346,y:883,t:1526933421355};\\\", \\\"{x:1346,y:885,t:1526933421371};\\\", \\\"{x:1347,y:889,t:1526933421390};\\\", \\\"{x:1347,y:891,t:1526933421405};\\\", \\\"{x:1347,y:894,t:1526933421423};\\\", \\\"{x:1347,y:898,t:1526933421439};\\\", \\\"{x:1347,y:901,t:1526933421456};\\\", \\\"{x:1347,y:902,t:1526933421472};\\\", \\\"{x:1347,y:904,t:1526933421490};\\\", \\\"{x:1347,y:903,t:1526933421958};\\\", \\\"{x:1347,y:901,t:1526933421974};\\\", \\\"{x:1347,y:900,t:1526933421989};\\\", \\\"{x:1347,y:899,t:1526933422007};\\\", \\\"{x:1347,y:898,t:1526933422023};\\\", \\\"{x:1343,y:895,t:1526933423341};\\\", \\\"{x:1314,y:893,t:1526933423357};\\\", \\\"{x:1251,y:876,t:1526933423373};\\\", \\\"{x:1181,y:867,t:1526933423390};\\\", \\\"{x:1120,y:859,t:1526933423407};\\\", \\\"{x:1066,y:850,t:1526933423423};\\\", \\\"{x:1003,y:843,t:1526933423440};\\\", \\\"{x:950,y:835,t:1526933423457};\\\", \\\"{x:898,y:826,t:1526933423473};\\\", \\\"{x:852,y:821,t:1526933423490};\\\", \\\"{x:822,y:815,t:1526933423507};\\\", \\\"{x:783,y:810,t:1526933423523};\\\", \\\"{x:755,y:808,t:1526933423540};\\\", \\\"{x:726,y:807,t:1526933423557};\\\", \\\"{x:711,y:804,t:1526933423573};\\\", \\\"{x:702,y:803,t:1526933423590};\\\", \\\"{x:697,y:801,t:1526933423607};\\\", \\\"{x:695,y:799,t:1526933423645};\\\", \\\"{x:695,y:797,t:1526933423657};\\\", \\\"{x:693,y:790,t:1526933423674};\\\", \\\"{x:691,y:778,t:1526933423690};\\\", \\\"{x:691,y:759,t:1526933423709};\\\", \\\"{x:691,y:736,t:1526933423724};\\\", \\\"{x:691,y:713,t:1526933423740};\\\", \\\"{x:691,y:687,t:1526933423757};\\\", \\\"{x:696,y:670,t:1526933423774};\\\", \\\"{x:702,y:655,t:1526933423791};\\\", \\\"{x:707,y:642,t:1526933423809};\\\", \\\"{x:713,y:625,t:1526933423823};\\\", \\\"{x:716,y:609,t:1526933423841};\\\", \\\"{x:718,y:599,t:1526933423859};\\\", \\\"{x:719,y:596,t:1526933423875};\\\", \\\"{x:721,y:594,t:1526933423892};\\\", \\\"{x:721,y:593,t:1526933423909};\\\", \\\"{x:722,y:593,t:1526933423932};\\\", \\\"{x:722,y:592,t:1526933423942};\\\", \\\"{x:723,y:591,t:1526933423959};\\\", \\\"{x:727,y:589,t:1526933423977};\\\", \\\"{x:730,y:589,t:1526933423993};\\\", \\\"{x:736,y:589,t:1526933424009};\\\", \\\"{x:743,y:589,t:1526933424026};\\\", \\\"{x:746,y:589,t:1526933424042};\\\", \\\"{x:738,y:589,t:1526933424134};\\\", \\\"{x:728,y:589,t:1526933424143};\\\", \\\"{x:697,y:592,t:1526933424164};\\\", \\\"{x:659,y:594,t:1526933424176};\\\", \\\"{x:605,y:596,t:1526933424193};\\\", \\\"{x:541,y:596,t:1526933424210};\\\", \\\"{x:461,y:596,t:1526933424227};\\\", \\\"{x:375,y:596,t:1526933424243};\\\", \\\"{x:289,y:596,t:1526933424259};\\\", \\\"{x:193,y:597,t:1526933424277};\\\", \\\"{x:162,y:602,t:1526933424293};\\\", \\\"{x:142,y:604,t:1526933424310};\\\", \\\"{x:126,y:608,t:1526933424326};\\\", \\\"{x:110,y:614,t:1526933424343};\\\", \\\"{x:107,y:614,t:1526933424359};\\\", \\\"{x:107,y:615,t:1526933424397};\\\", \\\"{x:109,y:615,t:1526933424694};\\\", \\\"{x:114,y:615,t:1526933424710};\\\", \\\"{x:115,y:615,t:1526933424741};\\\", \\\"{x:115,y:614,t:1526933424757};\\\", \\\"{x:116,y:613,t:1526933424773};\\\", \\\"{x:117,y:612,t:1526933424789};\\\", \\\"{x:117,y:611,t:1526933424796};\\\", \\\"{x:118,y:610,t:1526933424809};\\\", \\\"{x:119,y:606,t:1526933424826};\\\", \\\"{x:120,y:601,t:1526933424844};\\\", \\\"{x:122,y:596,t:1526933424860};\\\", \\\"{x:123,y:591,t:1526933424876};\\\", \\\"{x:123,y:586,t:1526933424894};\\\", \\\"{x:125,y:581,t:1526933424910};\\\", \\\"{x:125,y:577,t:1526933424927};\\\", \\\"{x:128,y:572,t:1526933424945};\\\", \\\"{x:129,y:569,t:1526933424961};\\\", \\\"{x:132,y:566,t:1526933424977};\\\", \\\"{x:132,y:565,t:1526933424994};\\\", \\\"{x:133,y:565,t:1526933425093};\\\", \\\"{x:134,y:564,t:1526933425114};\\\", \\\"{x:135,y:563,t:1526933425130};\\\", \\\"{x:137,y:563,t:1526933425148};\\\", \\\"{x:141,y:563,t:1526933425165};\\\", \\\"{x:142,y:563,t:1526933425185};\\\", \\\"{x:145,y:563,t:1526933425198};\\\", \\\"{x:148,y:564,t:1526933425215};\\\", \\\"{x:152,y:567,t:1526933425706};\\\", \\\"{x:158,y:571,t:1526933425715};\\\", \\\"{x:178,y:586,t:1526933425731};\\\", \\\"{x:198,y:598,t:1526933425749};\\\", \\\"{x:230,y:617,t:1526933425765};\\\", \\\"{x:265,y:636,t:1526933425782};\\\", \\\"{x:298,y:651,t:1526933425797};\\\", \\\"{x:329,y:665,t:1526933425814};\\\", \\\"{x:352,y:675,t:1526933425832};\\\", \\\"{x:383,y:688,t:1526933425848};\\\", \\\"{x:399,y:695,t:1526933425864};\\\", \\\"{x:413,y:700,t:1526933425881};\\\", \\\"{x:423,y:705,t:1526933425899};\\\", \\\"{x:431,y:709,t:1526933425915};\\\", \\\"{x:441,y:715,t:1526933425931};\\\", \\\"{x:448,y:719,t:1526933425949};\\\", \\\"{x:456,y:725,t:1526933425964};\\\", \\\"{x:462,y:729,t:1526933425981};\\\", \\\"{x:468,y:733,t:1526933425999};\\\", \\\"{x:472,y:735,t:1526933426015};\\\", \\\"{x:473,y:735,t:1526933426031};\\\", \\\"{x:474,y:735,t:1526933426090};\\\", \\\"{x:473,y:731,t:1526933426099};\\\", \\\"{x:455,y:709,t:1526933426114};\\\", \\\"{x:414,y:674,t:1526933426133};\\\", \\\"{x:371,y:649,t:1526933426149};\\\", \\\"{x:335,y:636,t:1526933426164};\\\", \\\"{x:302,y:623,t:1526933426181};\\\", \\\"{x:267,y:612,t:1526933426198};\\\", \\\"{x:236,y:602,t:1526933426216};\\\", \\\"{x:209,y:596,t:1526933426231};\\\", \\\"{x:179,y:583,t:1526933426248};\\\", \\\"{x:167,y:578,t:1526933426265};\\\", \\\"{x:161,y:576,t:1526933426281};\\\", \\\"{x:159,y:575,t:1526933426298};\\\", \\\"{x:158,y:574,t:1526933426315};\\\", \\\"{x:158,y:573,t:1526933426401};\\\", \\\"{x:158,y:572,t:1526933426424};\\\", \\\"{x:158,y:571,t:1526933426448};\\\", \\\"{x:158,y:570,t:1526933426466};\\\", \\\"{x:158,y:569,t:1526933426481};\\\", \\\"{x:158,y:567,t:1526933426499};\\\", \\\"{x:158,y:566,t:1526933426536};\\\", \\\"{x:158,y:565,t:1526933426552};\\\", \\\"{x:158,y:563,t:1526933426566};\\\", \\\"{x:158,y:562,t:1526933426582};\\\", \\\"{x:158,y:560,t:1526933426599};\\\", \\\"{x:160,y:559,t:1526933427033};\\\", \\\"{x:195,y:581,t:1526933427050};\\\", \\\"{x:242,y:612,t:1526933427066};\\\", \\\"{x:305,y:650,t:1526933427083};\\\", \\\"{x:380,y:683,t:1526933427100};\\\", \\\"{x:449,y:716,t:1526933427115};\\\", \\\"{x:518,y:743,t:1526933427132};\\\", \\\"{x:574,y:760,t:1526933427148};\\\", \\\"{x:608,y:770,t:1526933427165};\\\", \\\"{x:630,y:777,t:1526933427182};\\\", \\\"{x:642,y:778,t:1526933427200};\\\", \\\"{x:645,y:778,t:1526933427215};\\\", \\\"{x:645,y:777,t:1526933427320};\\\", \\\"{x:645,y:774,t:1526933427332};\\\", \\\"{x:639,y:765,t:1526933427349};\\\", \\\"{x:632,y:755,t:1526933427366};\\\", \\\"{x:624,y:749,t:1526933427384};\\\", \\\"{x:613,y:743,t:1526933427400};\\\", \\\"{x:593,y:734,t:1526933427416};\\\", \\\"{x:580,y:730,t:1526933427434};\\\", \\\"{x:569,y:729,t:1526933427449};\\\", \\\"{x:559,y:728,t:1526933427467};\\\", \\\"{x:552,y:728,t:1526933427483};\\\", \\\"{x:546,y:726,t:1526933427500};\\\", \\\"{x:543,y:726,t:1526933427515};\\\", \\\"{x:541,y:725,t:1526933427532};\\\", \\\"{x:540,y:725,t:1526933427549};\\\", \\\"{x:539,y:725,t:1526933427565};\\\", \\\"{x:538,y:725,t:1526933427601};\\\", \\\"{x:538,y:726,t:1526933428193};\\\", \\\"{x:544,y:730,t:1526933428200};\\\", \\\"{x:555,y:742,t:1526933428216};\\\", \\\"{x:573,y:755,t:1526933428233};\\\", \\\"{x:596,y:769,t:1526933428250};\\\", \\\"{x:629,y:782,t:1526933428267};\\\", \\\"{x:673,y:792,t:1526933428284};\\\", \\\"{x:718,y:799,t:1526933428300};\\\", \\\"{x:756,y:802,t:1526933428317};\\\", \\\"{x:785,y:802,t:1526933428334};\\\", \\\"{x:808,y:802,t:1526933428350};\\\", \\\"{x:827,y:802,t:1526933428366};\\\", \\\"{x:835,y:802,t:1526933428384};\\\", \\\"{x:840,y:801,t:1526933428399};\\\" ] }, { \\\"rt\\\": 56000, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 240028, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -01 PM-02 PM-03 PM-04 PM-C -A -A -A -F -F -H -01 PM-A -U -11-X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:841,y:801,t:1526933431032};\\\", \\\"{x:844,y:801,t:1526933431039};\\\", \\\"{x:846,y:799,t:1526933431052};\\\", \\\"{x:847,y:799,t:1526933431068};\\\", \\\"{x:847,y:798,t:1526933431769};\\\", \\\"{x:848,y:798,t:1526933431785};\\\", \\\"{x:848,y:796,t:1526933431808};\\\", \\\"{x:848,y:795,t:1526933431820};\\\", \\\"{x:848,y:793,t:1526933431835};\\\", \\\"{x:849,y:793,t:1526933431852};\\\", \\\"{x:851,y:793,t:1526933431870};\\\", \\\"{x:854,y:792,t:1526933431885};\\\", \\\"{x:857,y:792,t:1526933431903};\\\", \\\"{x:858,y:792,t:1526933431928};\\\", \\\"{x:859,y:792,t:1526933431936};\\\", \\\"{x:861,y:792,t:1526933431952};\\\", \\\"{x:864,y:792,t:1526933431969};\\\", \\\"{x:867,y:792,t:1526933431986};\\\", \\\"{x:871,y:792,t:1526933432003};\\\", \\\"{x:875,y:792,t:1526933432020};\\\", \\\"{x:880,y:792,t:1526933432035};\\\", \\\"{x:884,y:792,t:1526933432052};\\\", \\\"{x:893,y:793,t:1526933432069};\\\", \\\"{x:903,y:799,t:1526933432086};\\\", \\\"{x:915,y:805,t:1526933432103};\\\", \\\"{x:931,y:815,t:1526933432119};\\\", \\\"{x:954,y:827,t:1526933432136};\\\", \\\"{x:1008,y:846,t:1526933432153};\\\", \\\"{x:1061,y:862,t:1526933432170};\\\", \\\"{x:1106,y:875,t:1526933432186};\\\", \\\"{x:1150,y:886,t:1526933432203};\\\", \\\"{x:1199,y:897,t:1526933432220};\\\", \\\"{x:1248,y:901,t:1526933432237};\\\", \\\"{x:1299,y:909,t:1526933432253};\\\", \\\"{x:1335,y:909,t:1526933432270};\\\", \\\"{x:1362,y:909,t:1526933432287};\\\", \\\"{x:1383,y:909,t:1526933432303};\\\", \\\"{x:1394,y:909,t:1526933432320};\\\", \\\"{x:1398,y:909,t:1526933432337};\\\", \\\"{x:1398,y:908,t:1526933432377};\\\", \\\"{x:1398,y:907,t:1526933432387};\\\", \\\"{x:1397,y:906,t:1526933432403};\\\", \\\"{x:1395,y:903,t:1526933432421};\\\", \\\"{x:1394,y:900,t:1526933432437};\\\", \\\"{x:1390,y:895,t:1526933432454};\\\", \\\"{x:1386,y:889,t:1526933432470};\\\", \\\"{x:1384,y:885,t:1526933432487};\\\", \\\"{x:1381,y:880,t:1526933432503};\\\", \\\"{x:1373,y:873,t:1526933432520};\\\", \\\"{x:1363,y:867,t:1526933432536};\\\", \\\"{x:1359,y:866,t:1526933432554};\\\", \\\"{x:1357,y:866,t:1526933432570};\\\", \\\"{x:1356,y:865,t:1526933432625};\\\", \\\"{x:1354,y:869,t:1526933432641};\\\", \\\"{x:1353,y:872,t:1526933432654};\\\", \\\"{x:1350,y:879,t:1526933432670};\\\", \\\"{x:1347,y:887,t:1526933432687};\\\", \\\"{x:1343,y:900,t:1526933432708};\\\", \\\"{x:1341,y:911,t:1526933432721};\\\", \\\"{x:1340,y:923,t:1526933432737};\\\", \\\"{x:1340,y:929,t:1526933432753};\\\", \\\"{x:1340,y:933,t:1526933432769};\\\", \\\"{x:1340,y:937,t:1526933432787};\\\", \\\"{x:1340,y:940,t:1526933432804};\\\", \\\"{x:1340,y:942,t:1526933432819};\\\", \\\"{x:1340,y:943,t:1526933432836};\\\", \\\"{x:1339,y:947,t:1526933432853};\\\", \\\"{x:1339,y:950,t:1526933432870};\\\", \\\"{x:1339,y:956,t:1526933432886};\\\", \\\"{x:1339,y:958,t:1526933432904};\\\", \\\"{x:1341,y:959,t:1526933432920};\\\", \\\"{x:1341,y:962,t:1526933432937};\\\", \\\"{x:1343,y:963,t:1526933432954};\\\", \\\"{x:1345,y:964,t:1526933432984};\\\", \\\"{x:1346,y:964,t:1526933432992};\\\", \\\"{x:1349,y:965,t:1526933433004};\\\", \\\"{x:1356,y:965,t:1526933433020};\\\", \\\"{x:1368,y:967,t:1526933433037};\\\", \\\"{x:1382,y:969,t:1526933433054};\\\", \\\"{x:1398,y:969,t:1526933433070};\\\", \\\"{x:1414,y:971,t:1526933433087};\\\", \\\"{x:1438,y:972,t:1526933433106};\\\", \\\"{x:1452,y:972,t:1526933433121};\\\", \\\"{x:1463,y:973,t:1526933433138};\\\", \\\"{x:1471,y:974,t:1526933433154};\\\", \\\"{x:1476,y:974,t:1526933433170};\\\", \\\"{x:1480,y:974,t:1526933433187};\\\", \\\"{x:1483,y:974,t:1526933433204};\\\", \\\"{x:1485,y:974,t:1526933433222};\\\", \\\"{x:1487,y:974,t:1526933433237};\\\", \\\"{x:1489,y:974,t:1526933433254};\\\", \\\"{x:1491,y:974,t:1526933433271};\\\", \\\"{x:1492,y:974,t:1526933433287};\\\", \\\"{x:1495,y:974,t:1526933433304};\\\", \\\"{x:1501,y:974,t:1526933433321};\\\", \\\"{x:1504,y:974,t:1526933433336};\\\", \\\"{x:1508,y:974,t:1526933433354};\\\", \\\"{x:1510,y:974,t:1526933433371};\\\", \\\"{x:1512,y:974,t:1526933433386};\\\", \\\"{x:1514,y:974,t:1526933433403};\\\", \\\"{x:1516,y:974,t:1526933433421};\\\", \\\"{x:1519,y:974,t:1526933433436};\\\", \\\"{x:1520,y:974,t:1526933433454};\\\", \\\"{x:1522,y:974,t:1526933433471};\\\", \\\"{x:1523,y:974,t:1526933433487};\\\", \\\"{x:1525,y:974,t:1526933433503};\\\", \\\"{x:1526,y:974,t:1526933433520};\\\", \\\"{x:1530,y:974,t:1526933433537};\\\", \\\"{x:1532,y:975,t:1526933433554};\\\", \\\"{x:1537,y:975,t:1526933433571};\\\", \\\"{x:1541,y:976,t:1526933433587};\\\", \\\"{x:1546,y:976,t:1526933433604};\\\", \\\"{x:1553,y:976,t:1526933433621};\\\", \\\"{x:1558,y:976,t:1526933433637};\\\", \\\"{x:1563,y:976,t:1526933433654};\\\", \\\"{x:1567,y:976,t:1526933433671};\\\", \\\"{x:1569,y:976,t:1526933433688};\\\", \\\"{x:1573,y:976,t:1526933433704};\\\", \\\"{x:1577,y:977,t:1526933433720};\\\", \\\"{x:1582,y:978,t:1526933433738};\\\", \\\"{x:1586,y:978,t:1526933433754};\\\", \\\"{x:1592,y:978,t:1526933433771};\\\", \\\"{x:1594,y:978,t:1526933433788};\\\", \\\"{x:1597,y:978,t:1526933433804};\\\", \\\"{x:1599,y:978,t:1526933433821};\\\", \\\"{x:1600,y:978,t:1526933433838};\\\", \\\"{x:1604,y:978,t:1526933433854};\\\", \\\"{x:1609,y:978,t:1526933433871};\\\", \\\"{x:1617,y:978,t:1526933433889};\\\", \\\"{x:1624,y:978,t:1526933433904};\\\", \\\"{x:1628,y:978,t:1526933433920};\\\", \\\"{x:1630,y:978,t:1526933433938};\\\", \\\"{x:1632,y:978,t:1526933433954};\\\", \\\"{x:1633,y:977,t:1526933433971};\\\", \\\"{x:1633,y:976,t:1526933433988};\\\", \\\"{x:1634,y:975,t:1526933434004};\\\", \\\"{x:1635,y:974,t:1526933434021};\\\", \\\"{x:1635,y:973,t:1526933434038};\\\", \\\"{x:1635,y:972,t:1526933434113};\\\", \\\"{x:1633,y:970,t:1526933434145};\\\", \\\"{x:1632,y:969,t:1526933434161};\\\", \\\"{x:1632,y:968,t:1526933434184};\\\", \\\"{x:1631,y:968,t:1526933434232};\\\", \\\"{x:1630,y:968,t:1526933434240};\\\", \\\"{x:1629,y:968,t:1526933434288};\\\", \\\"{x:1628,y:967,t:1526933434312};\\\", \\\"{x:1627,y:967,t:1526933434336};\\\", \\\"{x:1626,y:967,t:1526933434344};\\\", \\\"{x:1625,y:967,t:1526933434360};\\\", \\\"{x:1625,y:966,t:1526933434371};\\\", \\\"{x:1623,y:965,t:1526933434388};\\\", \\\"{x:1622,y:965,t:1526933434433};\\\", \\\"{x:1622,y:964,t:1526933434665};\\\", \\\"{x:1622,y:963,t:1526933434697};\\\", \\\"{x:1622,y:962,t:1526933434714};\\\", \\\"{x:1621,y:961,t:1526933434728};\\\", \\\"{x:1621,y:960,t:1526933434769};\\\", \\\"{x:1620,y:959,t:1526933434824};\\\", \\\"{x:1620,y:958,t:1526933436705};\\\", \\\"{x:1613,y:958,t:1526933436723};\\\", \\\"{x:1600,y:958,t:1526933436740};\\\", \\\"{x:1589,y:958,t:1526933436757};\\\", \\\"{x:1580,y:956,t:1526933436774};\\\", \\\"{x:1576,y:955,t:1526933436789};\\\", \\\"{x:1574,y:955,t:1526933436806};\\\", \\\"{x:1573,y:954,t:1526933436823};\\\", \\\"{x:1572,y:954,t:1526933436921};\\\", \\\"{x:1571,y:953,t:1526933436928};\\\", \\\"{x:1570,y:953,t:1526933436940};\\\", \\\"{x:1566,y:953,t:1526933436956};\\\", \\\"{x:1555,y:953,t:1526933436975};\\\", \\\"{x:1546,y:952,t:1526933436990};\\\", \\\"{x:1534,y:952,t:1526933437007};\\\", \\\"{x:1520,y:951,t:1526933437023};\\\", \\\"{x:1503,y:951,t:1526933437041};\\\", \\\"{x:1492,y:950,t:1526933437057};\\\", \\\"{x:1479,y:948,t:1526933437073};\\\", \\\"{x:1464,y:947,t:1526933437090};\\\", \\\"{x:1447,y:946,t:1526933437108};\\\", \\\"{x:1433,y:945,t:1526933437123};\\\", \\\"{x:1417,y:945,t:1526933437140};\\\", \\\"{x:1400,y:943,t:1526933437157};\\\", \\\"{x:1386,y:942,t:1526933437174};\\\", \\\"{x:1372,y:941,t:1526933437190};\\\", \\\"{x:1359,y:938,t:1526933437207};\\\", \\\"{x:1351,y:936,t:1526933437223};\\\", \\\"{x:1338,y:935,t:1526933437240};\\\", \\\"{x:1327,y:932,t:1526933437257};\\\", \\\"{x:1320,y:932,t:1526933437273};\\\", \\\"{x:1308,y:928,t:1526933437290};\\\", \\\"{x:1298,y:926,t:1526933437307};\\\", \\\"{x:1286,y:922,t:1526933437323};\\\", \\\"{x:1272,y:918,t:1526933437340};\\\", \\\"{x:1258,y:917,t:1526933437357};\\\", \\\"{x:1240,y:917,t:1526933437374};\\\", \\\"{x:1218,y:917,t:1526933437390};\\\", \\\"{x:1193,y:917,t:1526933437407};\\\", \\\"{x:1164,y:917,t:1526933437423};\\\", \\\"{x:1122,y:917,t:1526933437441};\\\", \\\"{x:1093,y:917,t:1526933437456};\\\", \\\"{x:1069,y:917,t:1526933437474};\\\", \\\"{x:1049,y:920,t:1526933437490};\\\", \\\"{x:1035,y:925,t:1526933437507};\\\", \\\"{x:1028,y:929,t:1526933437524};\\\", \\\"{x:1027,y:933,t:1526933437540};\\\", \\\"{x:1027,y:937,t:1526933437558};\\\", \\\"{x:1029,y:944,t:1526933437575};\\\", \\\"{x:1030,y:945,t:1526933437590};\\\", \\\"{x:1036,y:951,t:1526933437607};\\\", \\\"{x:1043,y:952,t:1526933437930};\\\", \\\"{x:1044,y:952,t:1526933437941};\\\", \\\"{x:1050,y:952,t:1526933437958};\\\", \\\"{x:1059,y:952,t:1526933437975};\\\", \\\"{x:1071,y:952,t:1526933437991};\\\", \\\"{x:1080,y:952,t:1526933438008};\\\", \\\"{x:1098,y:952,t:1526933438024};\\\", \\\"{x:1112,y:952,t:1526933438040};\\\", \\\"{x:1128,y:951,t:1526933438058};\\\", \\\"{x:1143,y:949,t:1526933438075};\\\", \\\"{x:1166,y:945,t:1526933438092};\\\", \\\"{x:1186,y:943,t:1526933438107};\\\", \\\"{x:1200,y:940,t:1526933438124};\\\", \\\"{x:1211,y:935,t:1526933438141};\\\", \\\"{x:1218,y:932,t:1526933438157};\\\", \\\"{x:1223,y:927,t:1526933438175};\\\", \\\"{x:1228,y:918,t:1526933438192};\\\", \\\"{x:1232,y:903,t:1526933438208};\\\", \\\"{x:1235,y:883,t:1526933438224};\\\", \\\"{x:1237,y:875,t:1526933438241};\\\", \\\"{x:1237,y:870,t:1526933438258};\\\", \\\"{x:1237,y:866,t:1526933438274};\\\", \\\"{x:1237,y:862,t:1526933438292};\\\", \\\"{x:1235,y:857,t:1526933438307};\\\", \\\"{x:1234,y:852,t:1526933438324};\\\", \\\"{x:1231,y:849,t:1526933438342};\\\", \\\"{x:1231,y:846,t:1526933438357};\\\", \\\"{x:1230,y:845,t:1526933438374};\\\", \\\"{x:1229,y:843,t:1526933438392};\\\", \\\"{x:1227,y:840,t:1526933438409};\\\", \\\"{x:1227,y:838,t:1526933438425};\\\", \\\"{x:1226,y:838,t:1526933438442};\\\", \\\"{x:1223,y:835,t:1526933438459};\\\", \\\"{x:1222,y:834,t:1526933438475};\\\", \\\"{x:1221,y:832,t:1526933438492};\\\", \\\"{x:1220,y:832,t:1526933438509};\\\", \\\"{x:1219,y:832,t:1526933438529};\\\", \\\"{x:1218,y:832,t:1526933438625};\\\", \\\"{x:1218,y:838,t:1526933438642};\\\", \\\"{x:1218,y:843,t:1526933438658};\\\", \\\"{x:1218,y:851,t:1526933438674};\\\", \\\"{x:1218,y:858,t:1526933438691};\\\", \\\"{x:1218,y:864,t:1526933438708};\\\", \\\"{x:1218,y:874,t:1526933438725};\\\", \\\"{x:1218,y:886,t:1526933438742};\\\", \\\"{x:1218,y:902,t:1526933438758};\\\", \\\"{x:1218,y:917,t:1526933438777};\\\", \\\"{x:1218,y:929,t:1526933438790};\\\", \\\"{x:1218,y:939,t:1526933438807};\\\", \\\"{x:1218,y:943,t:1526933438825};\\\", \\\"{x:1218,y:948,t:1526933438841};\\\", \\\"{x:1218,y:950,t:1526933438858};\\\", \\\"{x:1218,y:953,t:1526933438874};\\\", \\\"{x:1218,y:955,t:1526933438891};\\\", \\\"{x:1218,y:958,t:1526933438908};\\\", \\\"{x:1218,y:960,t:1526933438925};\\\", \\\"{x:1218,y:961,t:1526933438940};\\\", \\\"{x:1217,y:963,t:1526933439194};\\\", \\\"{x:1217,y:959,t:1526933439209};\\\", \\\"{x:1220,y:948,t:1526933439225};\\\", \\\"{x:1225,y:939,t:1526933439242};\\\", \\\"{x:1232,y:932,t:1526933439258};\\\", \\\"{x:1239,y:923,t:1526933439275};\\\", \\\"{x:1248,y:911,t:1526933439292};\\\", \\\"{x:1259,y:898,t:1526933439309};\\\", \\\"{x:1267,y:886,t:1526933439326};\\\", \\\"{x:1273,y:880,t:1526933439342};\\\", \\\"{x:1277,y:873,t:1526933439358};\\\", \\\"{x:1280,y:870,t:1526933439376};\\\", \\\"{x:1282,y:866,t:1526933439393};\\\", \\\"{x:1282,y:863,t:1526933439409};\\\", \\\"{x:1283,y:858,t:1526933439425};\\\", \\\"{x:1284,y:851,t:1526933439442};\\\", \\\"{x:1285,y:845,t:1526933439458};\\\", \\\"{x:1285,y:840,t:1526933439475};\\\", \\\"{x:1285,y:834,t:1526933439493};\\\", \\\"{x:1285,y:831,t:1526933439509};\\\", \\\"{x:1285,y:827,t:1526933439526};\\\", \\\"{x:1285,y:823,t:1526933439543};\\\", \\\"{x:1285,y:820,t:1526933439559};\\\", \\\"{x:1285,y:816,t:1526933439575};\\\", \\\"{x:1285,y:813,t:1526933439592};\\\", \\\"{x:1285,y:812,t:1526933439617};\\\", \\\"{x:1286,y:816,t:1526933439800};\\\", \\\"{x:1286,y:820,t:1526933439809};\\\", \\\"{x:1286,y:825,t:1526933439825};\\\", \\\"{x:1286,y:828,t:1526933439842};\\\", \\\"{x:1286,y:831,t:1526933439859};\\\", \\\"{x:1286,y:832,t:1526933439875};\\\", \\\"{x:1285,y:832,t:1526933440633};\\\", \\\"{x:1284,y:832,t:1526933440649};\\\", \\\"{x:1281,y:830,t:1526933440665};\\\", \\\"{x:1280,y:822,t:1526933440677};\\\", \\\"{x:1280,y:796,t:1526933440693};\\\", \\\"{x:1279,y:782,t:1526933440710};\\\", \\\"{x:1278,y:771,t:1526933440727};\\\", \\\"{x:1278,y:758,t:1526933440743};\\\", \\\"{x:1278,y:744,t:1526933440760};\\\", \\\"{x:1278,y:725,t:1526933440777};\\\", \\\"{x:1278,y:709,t:1526933440792};\\\", \\\"{x:1278,y:701,t:1526933440810};\\\", \\\"{x:1278,y:695,t:1526933440827};\\\", \\\"{x:1278,y:691,t:1526933440844};\\\", \\\"{x:1278,y:688,t:1526933440860};\\\", \\\"{x:1280,y:683,t:1526933440876};\\\", \\\"{x:1280,y:680,t:1526933440894};\\\", \\\"{x:1280,y:677,t:1526933440910};\\\", \\\"{x:1280,y:674,t:1526933440927};\\\", \\\"{x:1281,y:669,t:1526933440944};\\\", \\\"{x:1282,y:664,t:1526933440960};\\\", \\\"{x:1286,y:652,t:1526933440977};\\\", \\\"{x:1289,y:648,t:1526933440993};\\\", \\\"{x:1292,y:642,t:1526933441010};\\\", \\\"{x:1295,y:638,t:1526933441027};\\\", \\\"{x:1296,y:637,t:1526933441043};\\\", \\\"{x:1296,y:636,t:1526933441059};\\\", \\\"{x:1297,y:635,t:1526933441088};\\\", \\\"{x:1298,y:634,t:1526933441128};\\\", \\\"{x:1301,y:634,t:1526933441289};\\\", \\\"{x:1303,y:634,t:1526933441305};\\\", \\\"{x:1305,y:634,t:1526933441313};\\\", \\\"{x:1306,y:634,t:1526933441327};\\\", \\\"{x:1309,y:635,t:1526933441343};\\\", \\\"{x:1310,y:635,t:1526933441361};\\\", \\\"{x:1311,y:635,t:1526933441377};\\\", \\\"{x:1312,y:636,t:1526933441497};\\\", \\\"{x:1312,y:637,t:1526933441841};\\\", \\\"{x:1312,y:642,t:1526933441849};\\\", \\\"{x:1313,y:651,t:1526933441860};\\\", \\\"{x:1317,y:671,t:1526933441878};\\\", \\\"{x:1318,y:696,t:1526933441894};\\\", \\\"{x:1318,y:723,t:1526933441911};\\\", \\\"{x:1318,y:739,t:1526933441928};\\\", \\\"{x:1318,y:748,t:1526933441944};\\\", \\\"{x:1318,y:759,t:1526933441961};\\\", \\\"{x:1318,y:774,t:1526933441977};\\\", \\\"{x:1318,y:795,t:1526933441993};\\\", \\\"{x:1317,y:817,t:1526933442011};\\\", \\\"{x:1312,y:840,t:1526933442028};\\\", \\\"{x:1310,y:865,t:1526933442044};\\\", \\\"{x:1307,y:887,t:1526933442061};\\\", \\\"{x:1305,y:902,t:1526933442078};\\\", \\\"{x:1304,y:911,t:1526933442093};\\\", \\\"{x:1304,y:916,t:1526933442111};\\\", \\\"{x:1304,y:921,t:1526933442128};\\\", \\\"{x:1302,y:924,t:1526933442144};\\\", \\\"{x:1302,y:928,t:1526933442160};\\\", \\\"{x:1302,y:933,t:1526933442178};\\\", \\\"{x:1302,y:940,t:1526933442194};\\\", \\\"{x:1302,y:946,t:1526933442211};\\\", \\\"{x:1302,y:950,t:1526933442228};\\\", \\\"{x:1302,y:952,t:1526933442245};\\\", \\\"{x:1302,y:953,t:1526933442260};\\\", \\\"{x:1302,y:954,t:1526933442277};\\\", \\\"{x:1302,y:957,t:1526933442295};\\\", \\\"{x:1303,y:959,t:1526933442311};\\\", \\\"{x:1305,y:962,t:1526933442328};\\\", \\\"{x:1305,y:964,t:1526933442345};\\\", \\\"{x:1306,y:965,t:1526933442361};\\\", \\\"{x:1306,y:966,t:1526933442378};\\\", \\\"{x:1306,y:967,t:1526933442395};\\\", \\\"{x:1308,y:967,t:1526933442481};\\\", \\\"{x:1309,y:968,t:1526933442513};\\\", \\\"{x:1310,y:968,t:1526933442529};\\\", \\\"{x:1311,y:968,t:1526933442665};\\\", \\\"{x:1312,y:969,t:1526933442689};\\\", \\\"{x:1313,y:969,t:1526933442720};\\\", \\\"{x:1314,y:969,t:1526933442761};\\\", \\\"{x:1314,y:970,t:1526933442778};\\\", \\\"{x:1315,y:970,t:1526933442817};\\\", \\\"{x:1316,y:970,t:1526933442865};\\\", \\\"{x:1317,y:970,t:1526933443633};\\\", \\\"{x:1317,y:969,t:1526933443649};\\\", \\\"{x:1317,y:967,t:1526933443662};\\\", \\\"{x:1317,y:966,t:1526933443679};\\\", \\\"{x:1317,y:962,t:1526933443695};\\\", \\\"{x:1316,y:959,t:1526933443712};\\\", \\\"{x:1314,y:952,t:1526933443728};\\\", \\\"{x:1314,y:949,t:1526933443745};\\\", \\\"{x:1313,y:946,t:1526933443762};\\\", \\\"{x:1312,y:945,t:1526933443779};\\\", \\\"{x:1312,y:942,t:1526933443795};\\\", \\\"{x:1312,y:940,t:1526933443811};\\\", \\\"{x:1312,y:938,t:1526933443828};\\\", \\\"{x:1311,y:935,t:1526933443845};\\\", \\\"{x:1310,y:932,t:1526933443861};\\\", \\\"{x:1310,y:928,t:1526933443878};\\\", \\\"{x:1310,y:925,t:1526933443895};\\\", \\\"{x:1310,y:921,t:1526933443911};\\\", \\\"{x:1310,y:913,t:1526933443928};\\\", \\\"{x:1310,y:905,t:1526933443945};\\\", \\\"{x:1310,y:892,t:1526933443962};\\\", \\\"{x:1310,y:879,t:1526933443978};\\\", \\\"{x:1310,y:866,t:1526933443996};\\\", \\\"{x:1310,y:851,t:1526933444011};\\\", \\\"{x:1310,y:833,t:1526933444028};\\\", \\\"{x:1310,y:817,t:1526933444046};\\\", \\\"{x:1310,y:806,t:1526933444061};\\\", \\\"{x:1310,y:797,t:1526933444078};\\\", \\\"{x:1310,y:790,t:1526933444095};\\\", \\\"{x:1310,y:782,t:1526933444111};\\\", \\\"{x:1309,y:765,t:1526933444129};\\\", \\\"{x:1309,y:755,t:1526933444146};\\\", \\\"{x:1309,y:748,t:1526933444162};\\\", \\\"{x:1309,y:743,t:1526933444178};\\\", \\\"{x:1309,y:739,t:1526933444196};\\\", \\\"{x:1309,y:735,t:1526933444212};\\\", \\\"{x:1308,y:731,t:1526933444229};\\\", \\\"{x:1308,y:728,t:1526933444246};\\\", \\\"{x:1308,y:720,t:1526933444262};\\\", \\\"{x:1308,y:714,t:1526933444279};\\\", \\\"{x:1308,y:709,t:1526933444296};\\\", \\\"{x:1308,y:702,t:1526933444313};\\\", \\\"{x:1308,y:698,t:1526933444328};\\\", \\\"{x:1308,y:692,t:1526933444346};\\\", \\\"{x:1308,y:682,t:1526933444363};\\\", \\\"{x:1308,y:675,t:1526933444379};\\\", \\\"{x:1308,y:671,t:1526933444395};\\\", \\\"{x:1308,y:666,t:1526933444412};\\\", \\\"{x:1308,y:663,t:1526933444428};\\\", \\\"{x:1308,y:659,t:1526933444445};\\\", \\\"{x:1308,y:658,t:1526933444462};\\\", \\\"{x:1308,y:656,t:1526933444478};\\\", \\\"{x:1308,y:654,t:1526933444495};\\\", \\\"{x:1308,y:653,t:1526933444520};\\\", \\\"{x:1308,y:652,t:1526933444552};\\\", \\\"{x:1308,y:651,t:1526933444576};\\\", \\\"{x:1308,y:650,t:1526933444592};\\\", \\\"{x:1308,y:648,t:1526933444617};\\\", \\\"{x:1308,y:647,t:1526933444641};\\\", \\\"{x:1308,y:645,t:1526933444657};\\\", \\\"{x:1308,y:644,t:1526933444673};\\\", \\\"{x:1309,y:643,t:1526933444688};\\\", \\\"{x:1309,y:642,t:1526933444704};\\\", \\\"{x:1310,y:641,t:1526933444737};\\\", \\\"{x:1310,y:639,t:1526933444777};\\\", \\\"{x:1310,y:638,t:1526933444808};\\\", \\\"{x:1310,y:636,t:1526933444857};\\\", \\\"{x:1311,y:639,t:1526933450681};\\\", \\\"{x:1317,y:646,t:1526933450688};\\\", \\\"{x:1325,y:654,t:1526933450700};\\\", \\\"{x:1335,y:664,t:1526933450717};\\\", \\\"{x:1340,y:670,t:1526933450734};\\\", \\\"{x:1351,y:682,t:1526933450750};\\\", \\\"{x:1361,y:695,t:1526933450767};\\\", \\\"{x:1370,y:705,t:1526933450784};\\\", \\\"{x:1376,y:710,t:1526933450801};\\\", \\\"{x:1378,y:713,t:1526933450817};\\\", \\\"{x:1378,y:714,t:1526933450834};\\\", \\\"{x:1379,y:715,t:1526933450851};\\\", \\\"{x:1382,y:718,t:1526933451481};\\\", \\\"{x:1383,y:722,t:1526933451489};\\\", \\\"{x:1387,y:728,t:1526933451501};\\\", \\\"{x:1396,y:744,t:1526933451518};\\\", \\\"{x:1401,y:756,t:1526933451534};\\\", \\\"{x:1406,y:767,t:1526933451551};\\\", \\\"{x:1409,y:770,t:1526933451567};\\\", \\\"{x:1409,y:771,t:1526933451584};\\\", \\\"{x:1410,y:772,t:1526933451601};\\\", \\\"{x:1410,y:773,t:1526933451648};\\\", \\\"{x:1410,y:774,t:1526933451681};\\\", \\\"{x:1410,y:775,t:1526933451696};\\\", \\\"{x:1410,y:776,t:1526933451704};\\\", \\\"{x:1409,y:777,t:1526933451720};\\\", \\\"{x:1408,y:777,t:1526933451736};\\\", \\\"{x:1407,y:778,t:1526933451750};\\\", \\\"{x:1406,y:778,t:1526933451823};\\\", \\\"{x:1405,y:778,t:1526933451834};\\\", \\\"{x:1403,y:778,t:1526933451850};\\\", \\\"{x:1401,y:778,t:1526933451868};\\\", \\\"{x:1397,y:778,t:1526933451884};\\\", \\\"{x:1394,y:776,t:1526933451901};\\\", \\\"{x:1393,y:776,t:1526933451917};\\\", \\\"{x:1391,y:776,t:1526933451977};\\\", \\\"{x:1390,y:776,t:1526933451993};\\\", \\\"{x:1388,y:776,t:1526933452008};\\\", \\\"{x:1387,y:775,t:1526933452018};\\\", \\\"{x:1380,y:773,t:1526933452035};\\\", \\\"{x:1380,y:772,t:1526933452051};\\\", \\\"{x:1379,y:771,t:1526933452068};\\\", \\\"{x:1377,y:771,t:1526933452086};\\\", \\\"{x:1376,y:771,t:1526933452101};\\\", \\\"{x:1375,y:772,t:1526933452225};\\\", \\\"{x:1375,y:777,t:1526933452236};\\\", \\\"{x:1375,y:788,t:1526933452252};\\\", \\\"{x:1375,y:802,t:1526933452268};\\\", \\\"{x:1373,y:816,t:1526933452285};\\\", \\\"{x:1372,y:830,t:1526933452302};\\\", \\\"{x:1371,y:844,t:1526933452318};\\\", \\\"{x:1371,y:856,t:1526933452335};\\\", \\\"{x:1371,y:871,t:1526933452352};\\\", \\\"{x:1371,y:881,t:1526933452368};\\\", \\\"{x:1371,y:889,t:1526933452385};\\\", \\\"{x:1372,y:897,t:1526933452402};\\\", \\\"{x:1374,y:904,t:1526933452418};\\\", \\\"{x:1377,y:913,t:1526933452435};\\\", \\\"{x:1378,y:920,t:1526933452452};\\\", \\\"{x:1378,y:925,t:1526933452468};\\\", \\\"{x:1380,y:928,t:1526933452486};\\\", \\\"{x:1381,y:933,t:1526933452502};\\\", \\\"{x:1381,y:938,t:1526933452517};\\\", \\\"{x:1381,y:941,t:1526933452534};\\\", \\\"{x:1382,y:945,t:1526933452551};\\\", \\\"{x:1382,y:949,t:1526933452568};\\\", \\\"{x:1384,y:952,t:1526933452584};\\\", \\\"{x:1385,y:957,t:1526933452601};\\\", \\\"{x:1385,y:960,t:1526933452618};\\\", \\\"{x:1385,y:964,t:1526933452635};\\\", \\\"{x:1386,y:966,t:1526933452651};\\\", \\\"{x:1386,y:967,t:1526933452668};\\\", \\\"{x:1386,y:969,t:1526933452684};\\\", \\\"{x:1386,y:970,t:1526933452701};\\\", \\\"{x:1386,y:971,t:1526933452719};\\\", \\\"{x:1386,y:972,t:1526933452734};\\\", \\\"{x:1386,y:973,t:1526933452752};\\\", \\\"{x:1386,y:972,t:1526933453392};\\\", \\\"{x:1386,y:970,t:1526933453447};\\\", \\\"{x:1386,y:969,t:1526933453544};\\\", \\\"{x:1386,y:967,t:1526933453576};\\\", \\\"{x:1386,y:966,t:1526933453600};\\\", \\\"{x:1386,y:964,t:1526933453624};\\\", \\\"{x:1386,y:963,t:1526933453640};\\\", \\\"{x:1386,y:960,t:1526933453653};\\\", \\\"{x:1386,y:955,t:1526933453669};\\\", \\\"{x:1386,y:944,t:1526933453686};\\\", \\\"{x:1386,y:934,t:1526933453703};\\\", \\\"{x:1385,y:927,t:1526933453719};\\\", \\\"{x:1385,y:918,t:1526933453736};\\\", \\\"{x:1385,y:914,t:1526933453752};\\\", \\\"{x:1385,y:907,t:1526933453770};\\\", \\\"{x:1385,y:897,t:1526933453786};\\\", \\\"{x:1385,y:883,t:1526933453803};\\\", \\\"{x:1385,y:872,t:1526933453818};\\\", \\\"{x:1385,y:860,t:1526933453836};\\\", \\\"{x:1385,y:850,t:1526933453853};\\\", \\\"{x:1385,y:843,t:1526933453869};\\\", \\\"{x:1385,y:837,t:1526933453886};\\\", \\\"{x:1384,y:830,t:1526933453903};\\\", \\\"{x:1384,y:823,t:1526933453920};\\\", \\\"{x:1383,y:807,t:1526933453936};\\\", \\\"{x:1381,y:798,t:1526933453952};\\\", \\\"{x:1380,y:792,t:1526933453969};\\\", \\\"{x:1380,y:787,t:1526933453986};\\\", \\\"{x:1379,y:783,t:1526933454003};\\\", \\\"{x:1379,y:780,t:1526933454019};\\\", \\\"{x:1379,y:778,t:1526933454036};\\\", \\\"{x:1379,y:775,t:1526933454053};\\\", \\\"{x:1379,y:772,t:1526933454068};\\\", \\\"{x:1379,y:771,t:1526933454085};\\\", \\\"{x:1379,y:769,t:1526933454103};\\\", \\\"{x:1379,y:766,t:1526933454120};\\\", \\\"{x:1379,y:764,t:1526933454135};\\\", \\\"{x:1379,y:761,t:1526933454153};\\\", \\\"{x:1379,y:758,t:1526933454169};\\\", \\\"{x:1379,y:756,t:1526933454186};\\\", \\\"{x:1379,y:755,t:1526933454223};\\\", \\\"{x:1379,y:753,t:1526933454256};\\\", \\\"{x:1379,y:752,t:1526933461081};\\\", \\\"{x:1384,y:746,t:1526933461097};\\\", \\\"{x:1401,y:730,t:1526933461107};\\\", \\\"{x:1415,y:717,t:1526933461124};\\\", \\\"{x:1428,y:703,t:1526933461140};\\\", \\\"{x:1438,y:694,t:1526933461158};\\\", \\\"{x:1449,y:685,t:1526933461174};\\\", \\\"{x:1455,y:676,t:1526933461191};\\\", \\\"{x:1459,y:656,t:1526933461207};\\\", \\\"{x:1462,y:643,t:1526933461224};\\\", \\\"{x:1462,y:630,t:1526933461241};\\\", \\\"{x:1462,y:616,t:1526933461258};\\\", \\\"{x:1462,y:601,t:1526933461275};\\\", \\\"{x:1462,y:587,t:1526933461291};\\\", \\\"{x:1462,y:580,t:1526933461308};\\\", \\\"{x:1460,y:573,t:1526933461325};\\\", \\\"{x:1457,y:567,t:1526933461341};\\\", \\\"{x:1455,y:563,t:1526933461359};\\\", \\\"{x:1454,y:562,t:1526933461375};\\\", \\\"{x:1454,y:561,t:1526933461391};\\\", \\\"{x:1452,y:558,t:1526933461408};\\\", \\\"{x:1450,y:557,t:1526933461425};\\\", \\\"{x:1450,y:556,t:1526933461441};\\\", \\\"{x:1448,y:555,t:1526933461458};\\\", \\\"{x:1446,y:555,t:1526933461475};\\\", \\\"{x:1444,y:555,t:1526933461491};\\\", \\\"{x:1442,y:555,t:1526933461508};\\\", \\\"{x:1440,y:555,t:1526933461609};\\\", \\\"{x:1439,y:555,t:1526933461625};\\\", \\\"{x:1437,y:556,t:1526933461656};\\\", \\\"{x:1437,y:557,t:1526933461689};\\\", \\\"{x:1436,y:557,t:1526933461696};\\\", \\\"{x:1436,y:558,t:1526933461709};\\\", \\\"{x:1435,y:559,t:1526933461725};\\\", \\\"{x:1434,y:560,t:1526933461742};\\\", \\\"{x:1434,y:561,t:1526933461760};\\\", \\\"{x:1433,y:561,t:1526933461785};\\\", \\\"{x:1433,y:562,t:1526933461857};\\\", \\\"{x:1431,y:562,t:1526933461864};\\\", \\\"{x:1430,y:562,t:1526933461875};\\\", \\\"{x:1428,y:562,t:1526933461892};\\\", \\\"{x:1424,y:562,t:1526933461908};\\\", \\\"{x:1420,y:561,t:1526933461925};\\\", \\\"{x:1418,y:561,t:1526933461943};\\\", \\\"{x:1417,y:561,t:1526933461958};\\\", \\\"{x:1416,y:561,t:1526933461975};\\\", \\\"{x:1414,y:559,t:1526933461992};\\\", \\\"{x:1413,y:559,t:1526933462208};\\\", \\\"{x:1412,y:561,t:1526933462800};\\\", \\\"{x:1412,y:568,t:1526933462809};\\\", \\\"{x:1414,y:590,t:1526933462828};\\\", \\\"{x:1416,y:607,t:1526933462843};\\\", \\\"{x:1418,y:621,t:1526933462859};\\\", \\\"{x:1420,y:635,t:1526933462877};\\\", \\\"{x:1421,y:644,t:1526933462892};\\\", \\\"{x:1423,y:648,t:1526933462909};\\\", \\\"{x:1423,y:653,t:1526933462927};\\\", \\\"{x:1424,y:658,t:1526933462943};\\\", \\\"{x:1425,y:662,t:1526933462960};\\\", \\\"{x:1425,y:665,t:1526933462976};\\\", \\\"{x:1425,y:668,t:1526933462992};\\\", \\\"{x:1425,y:675,t:1526933463010};\\\", \\\"{x:1425,y:680,t:1526933463027};\\\", \\\"{x:1425,y:686,t:1526933463042};\\\", \\\"{x:1425,y:692,t:1526933463060};\\\", \\\"{x:1425,y:697,t:1526933463076};\\\", \\\"{x:1424,y:699,t:1526933463092};\\\", \\\"{x:1424,y:700,t:1526933463109};\\\", \\\"{x:1424,y:702,t:1526933463126};\\\", \\\"{x:1424,y:703,t:1526933463144};\\\", \\\"{x:1423,y:707,t:1526933463159};\\\", \\\"{x:1423,y:711,t:1526933463177};\\\", \\\"{x:1422,y:715,t:1526933463194};\\\", \\\"{x:1422,y:719,t:1526933463210};\\\", \\\"{x:1420,y:722,t:1526933463226};\\\", \\\"{x:1419,y:727,t:1526933463243};\\\", \\\"{x:1418,y:733,t:1526933463259};\\\", \\\"{x:1415,y:741,t:1526933463276};\\\", \\\"{x:1414,y:753,t:1526933463294};\\\", \\\"{x:1411,y:769,t:1526933463310};\\\", \\\"{x:1410,y:782,t:1526933463327};\\\", \\\"{x:1410,y:793,t:1526933463343};\\\", \\\"{x:1410,y:807,t:1526933463360};\\\", \\\"{x:1410,y:830,t:1526933463377};\\\", \\\"{x:1410,y:845,t:1526933463393};\\\", \\\"{x:1410,y:865,t:1526933463410};\\\", \\\"{x:1410,y:879,t:1526933463427};\\\", \\\"{x:1410,y:890,t:1526933463444};\\\", \\\"{x:1410,y:903,t:1526933463459};\\\", \\\"{x:1411,y:917,t:1526933463477};\\\", \\\"{x:1411,y:929,t:1526933463494};\\\", \\\"{x:1411,y:936,t:1526933463509};\\\", \\\"{x:1412,y:943,t:1526933463526};\\\", \\\"{x:1413,y:947,t:1526933463544};\\\", \\\"{x:1413,y:950,t:1526933463559};\\\", \\\"{x:1413,y:954,t:1526933463576};\\\", \\\"{x:1413,y:957,t:1526933463593};\\\", \\\"{x:1415,y:960,t:1526933463610};\\\", \\\"{x:1415,y:963,t:1526933463626};\\\", \\\"{x:1415,y:965,t:1526933463644};\\\", \\\"{x:1416,y:969,t:1526933463661};\\\", \\\"{x:1416,y:970,t:1526933463680};\\\", \\\"{x:1416,y:968,t:1526933464337};\\\", \\\"{x:1416,y:967,t:1526933464344};\\\", \\\"{x:1416,y:962,t:1526933464360};\\\", \\\"{x:1416,y:957,t:1526933464378};\\\", \\\"{x:1416,y:954,t:1526933464394};\\\", \\\"{x:1416,y:951,t:1526933464410};\\\", \\\"{x:1416,y:949,t:1526933464427};\\\", \\\"{x:1416,y:946,t:1526933464444};\\\", \\\"{x:1417,y:942,t:1526933464460};\\\", \\\"{x:1417,y:939,t:1526933464477};\\\", \\\"{x:1417,y:937,t:1526933464493};\\\", \\\"{x:1417,y:934,t:1526933464511};\\\", \\\"{x:1417,y:933,t:1526933464527};\\\", \\\"{x:1417,y:931,t:1526933464544};\\\", \\\"{x:1417,y:930,t:1526933464560};\\\", \\\"{x:1417,y:928,t:1526933464584};\\\", \\\"{x:1417,y:927,t:1526933464601};\\\", \\\"{x:1417,y:925,t:1526933464625};\\\", \\\"{x:1417,y:924,t:1526933464648};\\\", \\\"{x:1417,y:922,t:1526933464705};\\\", \\\"{x:1417,y:921,t:1526933464720};\\\", \\\"{x:1417,y:919,t:1526933464728};\\\", \\\"{x:1417,y:915,t:1526933464744};\\\", \\\"{x:1417,y:912,t:1526933464760};\\\", \\\"{x:1417,y:910,t:1526933464777};\\\", \\\"{x:1415,y:904,t:1526933464794};\\\", \\\"{x:1415,y:897,t:1526933464811};\\\", \\\"{x:1414,y:890,t:1526933464827};\\\", \\\"{x:1413,y:879,t:1526933464845};\\\", \\\"{x:1410,y:867,t:1526933464860};\\\", \\\"{x:1410,y:854,t:1526933464878};\\\", \\\"{x:1410,y:827,t:1526933464895};\\\", \\\"{x:1409,y:801,t:1526933464910};\\\", \\\"{x:1408,y:775,t:1526933464928};\\\", \\\"{x:1402,y:727,t:1526933464944};\\\", \\\"{x:1398,y:694,t:1526933464961};\\\", \\\"{x:1390,y:652,t:1526933464977};\\\", \\\"{x:1376,y:599,t:1526933464994};\\\", \\\"{x:1368,y:538,t:1526933465010};\\\", \\\"{x:1361,y:495,t:1526933465028};\\\", \\\"{x:1357,y:468,t:1526933465044};\\\", \\\"{x:1352,y:444,t:1526933465062};\\\", \\\"{x:1346,y:423,t:1526933465078};\\\", \\\"{x:1344,y:412,t:1526933465095};\\\", \\\"{x:1343,y:400,t:1526933465112};\\\", \\\"{x:1343,y:394,t:1526933465127};\\\", \\\"{x:1343,y:389,t:1526933465144};\\\", \\\"{x:1343,y:388,t:1526933465161};\\\", \\\"{x:1343,y:386,t:1526933465177};\\\", \\\"{x:1344,y:385,t:1526933465199};\\\", \\\"{x:1345,y:385,t:1526933465248};\\\", \\\"{x:1346,y:385,t:1526933465261};\\\", \\\"{x:1347,y:385,t:1526933465287};\\\", \\\"{x:1348,y:385,t:1526933465303};\\\", \\\"{x:1349,y:385,t:1526933465319};\\\", \\\"{x:1351,y:387,t:1526933465335};\\\", \\\"{x:1353,y:388,t:1526933465343};\\\", \\\"{x:1355,y:390,t:1526933465361};\\\", \\\"{x:1358,y:393,t:1526933465377};\\\", \\\"{x:1361,y:395,t:1526933465394};\\\", \\\"{x:1363,y:397,t:1526933465412};\\\", \\\"{x:1366,y:399,t:1526933465428};\\\", \\\"{x:1367,y:400,t:1526933465444};\\\", \\\"{x:1368,y:400,t:1526933465480};\\\", \\\"{x:1370,y:401,t:1526933465495};\\\", \\\"{x:1371,y:402,t:1526933465512};\\\", \\\"{x:1371,y:403,t:1526933465528};\\\", \\\"{x:1375,y:406,t:1526933465545};\\\", \\\"{x:1378,y:408,t:1526933465561};\\\", \\\"{x:1382,y:412,t:1526933465579};\\\", \\\"{x:1386,y:413,t:1526933465594};\\\", \\\"{x:1391,y:416,t:1526933465611};\\\", \\\"{x:1392,y:417,t:1526933465629};\\\", \\\"{x:1393,y:417,t:1526933465648};\\\", \\\"{x:1394,y:417,t:1526933465662};\\\", \\\"{x:1394,y:418,t:1526933465679};\\\", \\\"{x:1396,y:419,t:1526933465695};\\\", \\\"{x:1397,y:420,t:1526933465712};\\\", \\\"{x:1401,y:424,t:1526933465728};\\\", \\\"{x:1403,y:427,t:1526933465745};\\\", \\\"{x:1405,y:430,t:1526933465762};\\\", \\\"{x:1406,y:432,t:1526933465779};\\\", \\\"{x:1408,y:433,t:1526933465795};\\\", \\\"{x:1408,y:435,t:1526933465812};\\\", \\\"{x:1408,y:436,t:1526933465832};\\\", \\\"{x:1409,y:437,t:1526933465865};\\\", \\\"{x:1410,y:442,t:1526933466241};\\\", \\\"{x:1411,y:446,t:1526933466248};\\\", \\\"{x:1412,y:453,t:1526933466261};\\\", \\\"{x:1418,y:469,t:1526933466279};\\\", \\\"{x:1422,y:485,t:1526933466295};\\\", \\\"{x:1427,y:495,t:1526933466312};\\\", \\\"{x:1430,y:505,t:1526933466329};\\\", \\\"{x:1432,y:509,t:1526933466346};\\\", \\\"{x:1433,y:512,t:1526933466361};\\\", \\\"{x:1435,y:519,t:1526933466378};\\\", \\\"{x:1437,y:535,t:1526933466396};\\\", \\\"{x:1440,y:557,t:1526933466412};\\\", \\\"{x:1443,y:576,t:1526933466429};\\\", \\\"{x:1449,y:595,t:1526933466445};\\\", \\\"{x:1453,y:610,t:1526933466463};\\\", \\\"{x:1458,y:630,t:1526933466478};\\\", \\\"{x:1463,y:655,t:1526933466496};\\\", \\\"{x:1471,y:719,t:1526933466512};\\\", \\\"{x:1478,y:757,t:1526933466529};\\\", \\\"{x:1482,y:785,t:1526933466546};\\\", \\\"{x:1485,y:810,t:1526933466563};\\\", \\\"{x:1489,y:836,t:1526933466579};\\\", \\\"{x:1489,y:857,t:1526933466595};\\\", \\\"{x:1489,y:873,t:1526933466612};\\\", \\\"{x:1490,y:884,t:1526933466629};\\\", \\\"{x:1492,y:899,t:1526933466645};\\\", \\\"{x:1494,y:909,t:1526933466662};\\\", \\\"{x:1495,y:921,t:1526933466679};\\\", \\\"{x:1498,y:932,t:1526933466696};\\\", \\\"{x:1500,y:941,t:1526933466712};\\\", \\\"{x:1502,y:946,t:1526933466729};\\\", \\\"{x:1505,y:951,t:1526933466745};\\\", \\\"{x:1508,y:955,t:1526933466763};\\\", \\\"{x:1512,y:958,t:1526933466778};\\\", \\\"{x:1514,y:961,t:1526933466795};\\\", \\\"{x:1519,y:963,t:1526933466812};\\\", \\\"{x:1523,y:963,t:1526933466828};\\\", \\\"{x:1529,y:964,t:1526933466845};\\\", \\\"{x:1535,y:964,t:1526933466862};\\\", \\\"{x:1545,y:964,t:1526933466878};\\\", \\\"{x:1560,y:964,t:1526933466895};\\\", \\\"{x:1587,y:964,t:1526933466912};\\\", \\\"{x:1604,y:962,t:1526933466928};\\\", \\\"{x:1622,y:961,t:1526933466945};\\\", \\\"{x:1632,y:960,t:1526933466962};\\\", \\\"{x:1637,y:958,t:1526933466979};\\\", \\\"{x:1638,y:957,t:1526933466995};\\\", \\\"{x:1639,y:957,t:1526933467012};\\\", \\\"{x:1639,y:956,t:1526933467265};\\\", \\\"{x:1638,y:955,t:1526933467280};\\\", \\\"{x:1632,y:951,t:1526933467297};\\\", \\\"{x:1629,y:950,t:1526933467313};\\\", \\\"{x:1627,y:949,t:1526933467330};\\\", \\\"{x:1625,y:948,t:1526933467345};\\\", \\\"{x:1624,y:947,t:1526933467384};\\\", \\\"{x:1623,y:947,t:1526933467408};\\\", \\\"{x:1622,y:947,t:1526933467440};\\\", \\\"{x:1621,y:947,t:1526933467448};\\\", \\\"{x:1619,y:947,t:1526933467463};\\\", \\\"{x:1617,y:948,t:1526933467480};\\\", \\\"{x:1613,y:952,t:1526933467496};\\\", \\\"{x:1612,y:953,t:1526933467513};\\\", \\\"{x:1612,y:951,t:1526933467680};\\\", \\\"{x:1612,y:932,t:1526933467696};\\\", \\\"{x:1612,y:920,t:1526933467713};\\\", \\\"{x:1612,y:909,t:1526933467730};\\\", \\\"{x:1612,y:899,t:1526933467747};\\\", \\\"{x:1612,y:891,t:1526933467762};\\\", \\\"{x:1612,y:879,t:1526933467779};\\\", \\\"{x:1612,y:866,t:1526933467797};\\\", \\\"{x:1610,y:857,t:1526933467813};\\\", \\\"{x:1610,y:847,t:1526933467830};\\\", \\\"{x:1610,y:839,t:1526933467847};\\\", \\\"{x:1611,y:831,t:1526933467863};\\\", \\\"{x:1613,y:822,t:1526933467880};\\\", \\\"{x:1615,y:797,t:1526933467896};\\\", \\\"{x:1615,y:777,t:1526933467914};\\\", \\\"{x:1615,y:753,t:1526933467930};\\\", \\\"{x:1615,y:737,t:1526933467947};\\\", \\\"{x:1615,y:729,t:1526933467963};\\\", \\\"{x:1615,y:719,t:1526933467980};\\\", \\\"{x:1615,y:708,t:1526933467997};\\\", \\\"{x:1615,y:698,t:1526933468014};\\\", \\\"{x:1615,y:692,t:1526933468029};\\\", \\\"{x:1614,y:681,t:1526933468047};\\\", \\\"{x:1613,y:668,t:1526933468064};\\\", \\\"{x:1612,y:657,t:1526933468079};\\\", \\\"{x:1610,y:646,t:1526933468097};\\\", \\\"{x:1609,y:639,t:1526933468114};\\\", \\\"{x:1608,y:631,t:1526933468130};\\\", \\\"{x:1607,y:621,t:1526933468147};\\\", \\\"{x:1605,y:613,t:1526933468163};\\\", \\\"{x:1605,y:601,t:1526933468180};\\\", \\\"{x:1604,y:591,t:1526933468197};\\\", \\\"{x:1604,y:585,t:1526933468214};\\\", \\\"{x:1604,y:581,t:1526933468229};\\\", \\\"{x:1604,y:576,t:1526933468246};\\\", \\\"{x:1604,y:573,t:1526933468264};\\\", \\\"{x:1604,y:571,t:1526933468279};\\\", \\\"{x:1604,y:568,t:1526933468297};\\\", \\\"{x:1604,y:567,t:1526933468314};\\\", \\\"{x:1604,y:565,t:1526933468329};\\\", \\\"{x:1604,y:563,t:1526933468347};\\\", \\\"{x:1604,y:562,t:1526933468364};\\\", \\\"{x:1604,y:560,t:1526933468381};\\\", \\\"{x:1604,y:559,t:1526933468396};\\\", \\\"{x:1604,y:557,t:1526933468414};\\\", \\\"{x:1605,y:557,t:1526933468632};\\\", \\\"{x:1606,y:557,t:1526933468648};\\\", \\\"{x:1607,y:557,t:1526933468664};\\\", \\\"{x:1607,y:563,t:1526933471257};\\\", \\\"{x:1607,y:570,t:1526933471266};\\\", \\\"{x:1607,y:590,t:1526933471282};\\\", \\\"{x:1602,y:613,t:1526933471299};\\\", \\\"{x:1596,y:623,t:1526933471316};\\\", \\\"{x:1592,y:632,t:1526933471333};\\\", \\\"{x:1588,y:638,t:1526933471349};\\\", \\\"{x:1586,y:642,t:1526933471366};\\\", \\\"{x:1582,y:646,t:1526933471383};\\\", \\\"{x:1577,y:652,t:1526933471399};\\\", \\\"{x:1563,y:667,t:1526933471416};\\\", \\\"{x:1552,y:674,t:1526933471432};\\\", \\\"{x:1545,y:678,t:1526933471449};\\\", \\\"{x:1539,y:680,t:1526933471466};\\\", \\\"{x:1538,y:680,t:1526933471483};\\\", \\\"{x:1536,y:680,t:1526933471499};\\\", \\\"{x:1535,y:680,t:1526933471520};\\\", \\\"{x:1533,y:680,t:1526933471536};\\\", \\\"{x:1530,y:680,t:1526933471549};\\\", \\\"{x:1525,y:676,t:1526933471565};\\\", \\\"{x:1517,y:669,t:1526933471583};\\\", \\\"{x:1511,y:659,t:1526933471599};\\\", \\\"{x:1506,y:650,t:1526933471616};\\\", \\\"{x:1503,y:646,t:1526933471632};\\\", \\\"{x:1501,y:643,t:1526933471649};\\\", \\\"{x:1501,y:640,t:1526933471666};\\\", \\\"{x:1499,y:638,t:1526933471682};\\\", \\\"{x:1498,y:635,t:1526933471699};\\\", \\\"{x:1498,y:631,t:1526933471716};\\\", \\\"{x:1497,y:630,t:1526933471733};\\\", \\\"{x:1497,y:629,t:1526933471752};\\\", \\\"{x:1497,y:631,t:1526933472208};\\\", \\\"{x:1497,y:634,t:1526933472216};\\\", \\\"{x:1497,y:639,t:1526933472232};\\\", \\\"{x:1497,y:644,t:1526933472250};\\\", \\\"{x:1497,y:650,t:1526933472267};\\\", \\\"{x:1497,y:658,t:1526933472283};\\\", \\\"{x:1497,y:668,t:1526933472299};\\\", \\\"{x:1497,y:680,t:1526933472317};\\\", \\\"{x:1497,y:693,t:1526933472333};\\\", \\\"{x:1497,y:712,t:1526933472350};\\\", \\\"{x:1497,y:730,t:1526933472367};\\\", \\\"{x:1494,y:749,t:1526933472382};\\\", \\\"{x:1493,y:771,t:1526933472400};\\\", \\\"{x:1493,y:782,t:1526933472416};\\\", \\\"{x:1492,y:791,t:1526933472433};\\\", \\\"{x:1492,y:801,t:1526933472450};\\\", \\\"{x:1492,y:809,t:1526933472466};\\\", \\\"{x:1492,y:818,t:1526933472483};\\\", \\\"{x:1492,y:826,t:1526933472500};\\\", \\\"{x:1490,y:831,t:1526933472517};\\\", \\\"{x:1490,y:834,t:1526933472532};\\\", \\\"{x:1490,y:836,t:1526933472550};\\\", \\\"{x:1490,y:837,t:1526933472566};\\\", \\\"{x:1490,y:838,t:1526933472582};\\\", \\\"{x:1490,y:840,t:1526933472600};\\\", \\\"{x:1490,y:841,t:1526933472616};\\\", \\\"{x:1490,y:842,t:1526933472633};\\\", \\\"{x:1490,y:843,t:1526933472649};\\\", \\\"{x:1489,y:843,t:1526933472785};\\\", \\\"{x:1488,y:843,t:1526933472800};\\\", \\\"{x:1487,y:843,t:1526933472817};\\\", \\\"{x:1486,y:843,t:1526933472834};\\\", \\\"{x:1485,y:843,t:1526933472864};\\\", \\\"{x:1484,y:842,t:1526933473000};\\\", \\\"{x:1483,y:841,t:1526933473032};\\\", \\\"{x:1482,y:840,t:1526933473080};\\\", \\\"{x:1481,y:839,t:1526933474921};\\\", \\\"{x:1477,y:839,t:1526933474935};\\\", \\\"{x:1455,y:835,t:1526933474952};\\\", \\\"{x:1433,y:831,t:1526933474968};\\\", \\\"{x:1407,y:830,t:1526933474985};\\\", \\\"{x:1376,y:825,t:1526933475002};\\\", \\\"{x:1340,y:823,t:1526933475018};\\\", \\\"{x:1308,y:817,t:1526933475035};\\\", \\\"{x:1277,y:812,t:1526933475052};\\\", \\\"{x:1243,y:801,t:1526933475070};\\\", \\\"{x:1218,y:793,t:1526933475085};\\\", \\\"{x:1193,y:786,t:1526933475102};\\\", \\\"{x:1172,y:781,t:1526933475119};\\\", \\\"{x:1145,y:772,t:1526933475135};\\\", \\\"{x:1102,y:759,t:1526933475152};\\\", \\\"{x:1066,y:749,t:1526933475168};\\\", \\\"{x:1020,y:739,t:1526933475184};\\\", \\\"{x:966,y:728,t:1526933475202};\\\", \\\"{x:910,y:711,t:1526933475218};\\\", \\\"{x:847,y:698,t:1526933475235};\\\", \\\"{x:796,y:690,t:1526933475251};\\\", \\\"{x:743,y:682,t:1526933475268};\\\", \\\"{x:708,y:680,t:1526933475284};\\\", \\\"{x:679,y:672,t:1526933475301};\\\", \\\"{x:654,y:669,t:1526933475319};\\\", \\\"{x:635,y:667,t:1526933475335};\\\", \\\"{x:613,y:660,t:1526933475352};\\\", \\\"{x:604,y:657,t:1526933475369};\\\", \\\"{x:593,y:650,t:1526933475387};\\\", \\\"{x:585,y:644,t:1526933475401};\\\", \\\"{x:578,y:637,t:1526933475418};\\\", \\\"{x:576,y:634,t:1526933475437};\\\", \\\"{x:574,y:630,t:1526933475454};\\\", \\\"{x:573,y:624,t:1526933475471};\\\", \\\"{x:573,y:617,t:1526933475487};\\\", \\\"{x:574,y:606,t:1526933475505};\\\", \\\"{x:575,y:600,t:1526933475521};\\\", \\\"{x:576,y:598,t:1526933475537};\\\", \\\"{x:577,y:596,t:1526933475554};\\\", \\\"{x:578,y:595,t:1526933475571};\\\", \\\"{x:578,y:594,t:1526933475591};\\\", \\\"{x:579,y:593,t:1526933475672};\\\", \\\"{x:580,y:593,t:1526933475688};\\\", \\\"{x:583,y:593,t:1526933475705};\\\", \\\"{x:586,y:594,t:1526933475722};\\\", \\\"{x:590,y:595,t:1526933475739};\\\", \\\"{x:596,y:598,t:1526933475755};\\\", \\\"{x:601,y:601,t:1526933475772};\\\", \\\"{x:602,y:601,t:1526933475788};\\\", \\\"{x:603,y:602,t:1526933475808};\\\", \\\"{x:606,y:603,t:1526933476433};\\\", \\\"{x:616,y:607,t:1526933476439};\\\", \\\"{x:641,y:614,t:1526933476457};\\\", \\\"{x:682,y:632,t:1526933476473};\\\", \\\"{x:733,y:650,t:1526933476488};\\\", \\\"{x:795,y:669,t:1526933476506};\\\", \\\"{x:863,y:692,t:1526933476522};\\\", \\\"{x:945,y:712,t:1526933476538};\\\", \\\"{x:1034,y:737,t:1526933476555};\\\", \\\"{x:1128,y:763,t:1526933476573};\\\", \\\"{x:1208,y:785,t:1526933476588};\\\", \\\"{x:1288,y:806,t:1526933476605};\\\", \\\"{x:1349,y:823,t:1526933476623};\\\", \\\"{x:1416,y:842,t:1526933476638};\\\", \\\"{x:1505,y:867,t:1526933476656};\\\", \\\"{x:1544,y:872,t:1526933476672};\\\", \\\"{x:1574,y:877,t:1526933476688};\\\", \\\"{x:1593,y:879,t:1526933476706};\\\", \\\"{x:1607,y:880,t:1526933476722};\\\", \\\"{x:1617,y:880,t:1526933476740};\\\", \\\"{x:1623,y:880,t:1526933476755};\\\", \\\"{x:1625,y:882,t:1526933476772};\\\", \\\"{x:1626,y:882,t:1526933476789};\\\", \\\"{x:1627,y:882,t:1526933476807};\\\", \\\"{x:1628,y:882,t:1526933476823};\\\", \\\"{x:1628,y:880,t:1526933476921};\\\", \\\"{x:1628,y:879,t:1526933476928};\\\", \\\"{x:1625,y:878,t:1526933476940};\\\", \\\"{x:1621,y:874,t:1526933476956};\\\", \\\"{x:1616,y:871,t:1526933476973};\\\", \\\"{x:1607,y:867,t:1526933476990};\\\", \\\"{x:1600,y:865,t:1526933477006};\\\", \\\"{x:1589,y:860,t:1526933477023};\\\", \\\"{x:1577,y:856,t:1526933477039};\\\", \\\"{x:1571,y:852,t:1526933477056};\\\", \\\"{x:1563,y:848,t:1526933477073};\\\", \\\"{x:1553,y:843,t:1526933477089};\\\", \\\"{x:1546,y:840,t:1526933477106};\\\", \\\"{x:1538,y:839,t:1526933477123};\\\", \\\"{x:1531,y:836,t:1526933477140};\\\", \\\"{x:1528,y:835,t:1526933477157};\\\", \\\"{x:1526,y:835,t:1526933477173};\\\", \\\"{x:1525,y:835,t:1526933477280};\\\", \\\"{x:1524,y:835,t:1526933477296};\\\", \\\"{x:1523,y:835,t:1526933477307};\\\", \\\"{x:1520,y:835,t:1526933477323};\\\", \\\"{x:1517,y:835,t:1526933477340};\\\", \\\"{x:1512,y:835,t:1526933477357};\\\", \\\"{x:1505,y:835,t:1526933477373};\\\", \\\"{x:1498,y:835,t:1526933477390};\\\", \\\"{x:1492,y:835,t:1526933477407};\\\", \\\"{x:1489,y:835,t:1526933477423};\\\", \\\"{x:1483,y:835,t:1526933477440};\\\", \\\"{x:1482,y:835,t:1526933477456};\\\", \\\"{x:1480,y:835,t:1526933477473};\\\", \\\"{x:1479,y:835,t:1526933477489};\\\", \\\"{x:1477,y:835,t:1526933477508};\\\", \\\"{x:1476,y:835,t:1526933477524};\\\", \\\"{x:1474,y:835,t:1526933477544};\\\", \\\"{x:1473,y:835,t:1526933477584};\\\", \\\"{x:1471,y:834,t:1526933477616};\\\", \\\"{x:1469,y:833,t:1526933477640};\\\", \\\"{x:1467,y:835,t:1526933477928};\\\", \\\"{x:1466,y:836,t:1526933477940};\\\", \\\"{x:1464,y:836,t:1526933478241};\\\", \\\"{x:1461,y:837,t:1526933478257};\\\", \\\"{x:1460,y:837,t:1526933478274};\\\", \\\"{x:1458,y:837,t:1526933478296};\\\", \\\"{x:1456,y:837,t:1526933478307};\\\", \\\"{x:1454,y:837,t:1526933478324};\\\", \\\"{x:1453,y:837,t:1526933478392};\\\", \\\"{x:1451,y:837,t:1526933478408};\\\", \\\"{x:1448,y:837,t:1526933478423};\\\", \\\"{x:1444,y:837,t:1526933478440};\\\", \\\"{x:1439,y:837,t:1526933478458};\\\", \\\"{x:1433,y:837,t:1526933478474};\\\", \\\"{x:1428,y:837,t:1526933478491};\\\", \\\"{x:1422,y:837,t:1526933478508};\\\", \\\"{x:1418,y:837,t:1526933478523};\\\", \\\"{x:1414,y:837,t:1526933478541};\\\", \\\"{x:1408,y:837,t:1526933478558};\\\", \\\"{x:1403,y:837,t:1526933478574};\\\", \\\"{x:1399,y:837,t:1526933478590};\\\", \\\"{x:1392,y:837,t:1526933478607};\\\", \\\"{x:1389,y:837,t:1526933478624};\\\", \\\"{x:1382,y:837,t:1526933478641};\\\", \\\"{x:1376,y:838,t:1526933478658};\\\", \\\"{x:1370,y:839,t:1526933478674};\\\", \\\"{x:1365,y:840,t:1526933478691};\\\", \\\"{x:1364,y:841,t:1526933478708};\\\", \\\"{x:1362,y:842,t:1526933478724};\\\", \\\"{x:1361,y:843,t:1526933478741};\\\", \\\"{x:1360,y:846,t:1526933478758};\\\", \\\"{x:1360,y:850,t:1526933478776};\\\", \\\"{x:1360,y:853,t:1526933478791};\\\", \\\"{x:1360,y:863,t:1526933478808};\\\", \\\"{x:1359,y:867,t:1526933478824};\\\", \\\"{x:1359,y:871,t:1526933478841};\\\", \\\"{x:1359,y:873,t:1526933478858};\\\", \\\"{x:1359,y:876,t:1526933478874};\\\", \\\"{x:1359,y:879,t:1526933478890};\\\", \\\"{x:1360,y:883,t:1526933478908};\\\", \\\"{x:1360,y:886,t:1526933478925};\\\", \\\"{x:1361,y:888,t:1526933478940};\\\", \\\"{x:1361,y:890,t:1526933478957};\\\", \\\"{x:1361,y:892,t:1526933478975};\\\", \\\"{x:1361,y:895,t:1526933478990};\\\", \\\"{x:1361,y:898,t:1526933479007};\\\", \\\"{x:1361,y:900,t:1526933479024};\\\", \\\"{x:1361,y:902,t:1526933479040};\\\", \\\"{x:1361,y:903,t:1526933479058};\\\", \\\"{x:1362,y:904,t:1526933480312};\\\", \\\"{x:1371,y:905,t:1526933480326};\\\", \\\"{x:1390,y:906,t:1526933480342};\\\", \\\"{x:1413,y:906,t:1526933480359};\\\", \\\"{x:1460,y:906,t:1526933480376};\\\", \\\"{x:1484,y:906,t:1526933480393};\\\", \\\"{x:1499,y:906,t:1526933480410};\\\", \\\"{x:1507,y:906,t:1526933480426};\\\", \\\"{x:1510,y:906,t:1526933480443};\\\", \\\"{x:1510,y:905,t:1526933480600};\\\", \\\"{x:1510,y:904,t:1526933480616};\\\", \\\"{x:1510,y:903,t:1526933480626};\\\", \\\"{x:1510,y:902,t:1526933480643};\\\", \\\"{x:1510,y:901,t:1526933480659};\\\", \\\"{x:1510,y:899,t:1526933480676};\\\", \\\"{x:1510,y:898,t:1526933480694};\\\", \\\"{x:1510,y:897,t:1526933480709};\\\", \\\"{x:1510,y:894,t:1526933480726};\\\", \\\"{x:1510,y:893,t:1526933480743};\\\", \\\"{x:1510,y:890,t:1526933480759};\\\", \\\"{x:1510,y:887,t:1526933480776};\\\", \\\"{x:1509,y:886,t:1526933480793};\\\", \\\"{x:1509,y:885,t:1526933480809};\\\", \\\"{x:1509,y:884,t:1526933480827};\\\", \\\"{x:1509,y:882,t:1526933480843};\\\", \\\"{x:1507,y:880,t:1526933480860};\\\", \\\"{x:1507,y:879,t:1526933480880};\\\", \\\"{x:1507,y:876,t:1526933480893};\\\", \\\"{x:1507,y:873,t:1526933480910};\\\", \\\"{x:1506,y:866,t:1526933480926};\\\", \\\"{x:1503,y:859,t:1526933480943};\\\", \\\"{x:1502,y:848,t:1526933480959};\\\", \\\"{x:1498,y:835,t:1526933480976};\\\", \\\"{x:1497,y:817,t:1526933480994};\\\", \\\"{x:1496,y:777,t:1526933481011};\\\", \\\"{x:1488,y:684,t:1526933481026};\\\", \\\"{x:1477,y:593,t:1526933481044};\\\", \\\"{x:1469,y:534,t:1526933481060};\\\", \\\"{x:1463,y:495,t:1526933481076};\\\", \\\"{x:1457,y:463,t:1526933481094};\\\", \\\"{x:1451,y:418,t:1526933481110};\\\", \\\"{x:1444,y:365,t:1526933481126};\\\", \\\"{x:1441,y:321,t:1526933481143};\\\", \\\"{x:1433,y:269,t:1526933481160};\\\", \\\"{x:1429,y:250,t:1526933481176};\\\", \\\"{x:1428,y:241,t:1526933481193};\\\", \\\"{x:1428,y:236,t:1526933481210};\\\", \\\"{x:1427,y:235,t:1526933481228};\\\", \\\"{x:1426,y:235,t:1526933481243};\\\", \\\"{x:1426,y:234,t:1526933481260};\\\", \\\"{x:1426,y:233,t:1526933481277};\\\", \\\"{x:1426,y:232,t:1526933481293};\\\", \\\"{x:1426,y:231,t:1526933481310};\\\", \\\"{x:1426,y:230,t:1526933481327};\\\", \\\"{x:1426,y:228,t:1526933481343};\\\", \\\"{x:1428,y:224,t:1526933481361};\\\", \\\"{x:1430,y:221,t:1526933481377};\\\", \\\"{x:1433,y:218,t:1526933481393};\\\", \\\"{x:1435,y:215,t:1526933481411};\\\", \\\"{x:1436,y:213,t:1526933481428};\\\", \\\"{x:1437,y:212,t:1526933481444};\\\", \\\"{x:1439,y:209,t:1526933481460};\\\", \\\"{x:1441,y:207,t:1526933481477};\\\", \\\"{x:1444,y:204,t:1526933481493};\\\", \\\"{x:1447,y:201,t:1526933481510};\\\", \\\"{x:1449,y:198,t:1526933481528};\\\", \\\"{x:1451,y:195,t:1526933481543};\\\", \\\"{x:1455,y:189,t:1526933481559};\\\", \\\"{x:1456,y:188,t:1526933481577};\\\", \\\"{x:1458,y:186,t:1526933481593};\\\", \\\"{x:1458,y:185,t:1526933481611};\\\", \\\"{x:1459,y:185,t:1526933481627};\\\", \\\"{x:1460,y:183,t:1526933481644};\\\", \\\"{x:1461,y:182,t:1526933481660};\\\", \\\"{x:1462,y:180,t:1526933481677};\\\", \\\"{x:1463,y:179,t:1526933481694};\\\", \\\"{x:1464,y:177,t:1526933481710};\\\", \\\"{x:1465,y:176,t:1526933481727};\\\", \\\"{x:1467,y:174,t:1526933481744};\\\", \\\"{x:1468,y:173,t:1526933481760};\\\", \\\"{x:1469,y:172,t:1526933481777};\\\", \\\"{x:1470,y:171,t:1526933481794};\\\", \\\"{x:1471,y:169,t:1526933481811};\\\", \\\"{x:1473,y:167,t:1526933481827};\\\", \\\"{x:1474,y:166,t:1526933481844};\\\", \\\"{x:1475,y:166,t:1526933481860};\\\", \\\"{x:1475,y:164,t:1526933481877};\\\", \\\"{x:1476,y:163,t:1526933481937};\\\", \\\"{x:1476,y:165,t:1526933483969};\\\", \\\"{x:1476,y:166,t:1526933483979};\\\", \\\"{x:1476,y:167,t:1526933483996};\\\", \\\"{x:1476,y:169,t:1526933484012};\\\", \\\"{x:1477,y:170,t:1526933484030};\\\", \\\"{x:1477,y:173,t:1526933484045};\\\", \\\"{x:1477,y:179,t:1526933484062};\\\", \\\"{x:1478,y:190,t:1526933484080};\\\", \\\"{x:1481,y:211,t:1526933484095};\\\", \\\"{x:1481,y:272,t:1526933484112};\\\", \\\"{x:1465,y:336,t:1526933484129};\\\", \\\"{x:1423,y:430,t:1526933484147};\\\", \\\"{x:1366,y:523,t:1526933484162};\\\", \\\"{x:1291,y:604,t:1526933484179};\\\", \\\"{x:1192,y:666,t:1526933484196};\\\", \\\"{x:1083,y:700,t:1526933484213};\\\", \\\"{x:965,y:732,t:1526933484229};\\\", \\\"{x:834,y:757,t:1526933484246};\\\", \\\"{x:718,y:767,t:1526933484262};\\\", \\\"{x:610,y:767,t:1526933484279};\\\", \\\"{x:485,y:769,t:1526933484296};\\\", \\\"{x:437,y:769,t:1526933484312};\\\", \\\"{x:410,y:769,t:1526933484329};\\\", \\\"{x:392,y:769,t:1526933484346};\\\", \\\"{x:384,y:769,t:1526933484362};\\\", \\\"{x:383,y:769,t:1526933484379};\\\", \\\"{x:382,y:769,t:1526933484441};\\\", \\\"{x:379,y:766,t:1526933484448};\\\", \\\"{x:376,y:764,t:1526933484462};\\\", \\\"{x:372,y:760,t:1526933484480};\\\", \\\"{x:370,y:755,t:1526933484496};\\\", \\\"{x:370,y:749,t:1526933484513};\\\", \\\"{x:370,y:742,t:1526933484530};\\\", \\\"{x:377,y:734,t:1526933484546};\\\", \\\"{x:388,y:726,t:1526933484563};\\\", \\\"{x:402,y:720,t:1526933484579};\\\", \\\"{x:423,y:715,t:1526933484596};\\\", \\\"{x:448,y:708,t:1526933484614};\\\", \\\"{x:469,y:703,t:1526933484629};\\\", \\\"{x:484,y:701,t:1526933484646};\\\", \\\"{x:494,y:701,t:1526933484661};\\\", \\\"{x:503,y:701,t:1526933484679};\\\", \\\"{x:509,y:701,t:1526933484694};\\\", \\\"{x:512,y:701,t:1526933484712};\\\", \\\"{x:513,y:701,t:1526933485252};\\\", \\\"{x:513,y:702,t:1526933485267};\\\", \\\"{x:524,y:711,t:1526933485283};\\\", \\\"{x:567,y:738,t:1526933485300};\\\", \\\"{x:603,y:755,t:1526933485317};\\\", \\\"{x:643,y:769,t:1526933485333};\\\", \\\"{x:691,y:785,t:1526933485350};\\\", \\\"{x:747,y:801,t:1526933485367};\\\", \\\"{x:797,y:816,t:1526933485384};\\\", \\\"{x:839,y:827,t:1526933485400};\\\", \\\"{x:879,y:834,t:1526933485417};\\\", \\\"{x:904,y:839,t:1526933485433};\\\", \\\"{x:923,y:842,t:1526933485450};\\\", \\\"{x:935,y:844,t:1526933485467};\\\", \\\"{x:941,y:844,t:1526933485483};\\\", \\\"{x:942,y:844,t:1526933485500};\\\" ] }, { \\\"rt\\\": 119669, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 360960, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -12 PM-I -I -I -O -12 PM-F -12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:945,y:844,t:1526933496701};\\\", \\\"{x:948,y:844,t:1526933496709};\\\", \\\"{x:955,y:842,t:1526933496726};\\\", \\\"{x:955,y:841,t:1526933497220};\\\", \\\"{x:955,y:840,t:1526933497308};\\\", \\\"{x:955,y:839,t:1526933497326};\\\", \\\"{x:956,y:839,t:1526933497532};\\\", \\\"{x:958,y:839,t:1526933497547};\\\", \\\"{x:960,y:839,t:1526933497559};\\\", \\\"{x:961,y:839,t:1526933497576};\\\", \\\"{x:962,y:839,t:1526933497612};\\\", \\\"{x:963,y:839,t:1526933497625};\\\", \\\"{x:966,y:839,t:1526933497643};\\\", \\\"{x:976,y:836,t:1526933497660};\\\", \\\"{x:985,y:836,t:1526933497676};\\\", \\\"{x:993,y:836,t:1526933497693};\\\", \\\"{x:1001,y:836,t:1526933497710};\\\", \\\"{x:1009,y:836,t:1526933497725};\\\", \\\"{x:1026,y:836,t:1526933497743};\\\", \\\"{x:1038,y:836,t:1526933497760};\\\", \\\"{x:1053,y:836,t:1526933497776};\\\", \\\"{x:1085,y:838,t:1526933497793};\\\", \\\"{x:1147,y:843,t:1526933497810};\\\", \\\"{x:1223,y:843,t:1526933497826};\\\", \\\"{x:1276,y:843,t:1526933497843};\\\", \\\"{x:1357,y:843,t:1526933497860};\\\", \\\"{x:1421,y:843,t:1526933497877};\\\", \\\"{x:1482,y:836,t:1526933497894};\\\", \\\"{x:1528,y:819,t:1526933497911};\\\", \\\"{x:1543,y:810,t:1526933497927};\\\", \\\"{x:1549,y:800,t:1526933497943};\\\", \\\"{x:1550,y:794,t:1526933497960};\\\", \\\"{x:1550,y:788,t:1526933497977};\\\", \\\"{x:1541,y:782,t:1526933497993};\\\", \\\"{x:1528,y:775,t:1526933498010};\\\", \\\"{x:1508,y:767,t:1526933498027};\\\", \\\"{x:1491,y:764,t:1526933498043};\\\", \\\"{x:1472,y:757,t:1526933498060};\\\", \\\"{x:1451,y:752,t:1526933498076};\\\", \\\"{x:1432,y:750,t:1526933498093};\\\", \\\"{x:1416,y:746,t:1526933498110};\\\", \\\"{x:1406,y:745,t:1526933498127};\\\", \\\"{x:1405,y:745,t:1526933498143};\\\", \\\"{x:1404,y:745,t:1526933498161};\\\", \\\"{x:1403,y:744,t:1526933498177};\\\", \\\"{x:1402,y:740,t:1526933498193};\\\", \\\"{x:1398,y:734,t:1526933498209};\\\", \\\"{x:1392,y:708,t:1526933498227};\\\", \\\"{x:1382,y:671,t:1526933498242};\\\", \\\"{x:1375,y:629,t:1526933498259};\\\", \\\"{x:1369,y:603,t:1526933498276};\\\", \\\"{x:1362,y:583,t:1526933498293};\\\", \\\"{x:1351,y:563,t:1526933498310};\\\", \\\"{x:1345,y:551,t:1526933498326};\\\", \\\"{x:1343,y:536,t:1526933498342};\\\", \\\"{x:1341,y:519,t:1526933498359};\\\", \\\"{x:1340,y:509,t:1526933498377};\\\", \\\"{x:1336,y:501,t:1526933498393};\\\", \\\"{x:1333,y:497,t:1526933498410};\\\", \\\"{x:1333,y:495,t:1526933498426};\\\", \\\"{x:1332,y:494,t:1526933498443};\\\", \\\"{x:1331,y:492,t:1526933498460};\\\", \\\"{x:1328,y:488,t:1526933498477};\\\", \\\"{x:1323,y:485,t:1526933498494};\\\", \\\"{x:1318,y:480,t:1526933498510};\\\", \\\"{x:1314,y:478,t:1526933498527};\\\", \\\"{x:1311,y:477,t:1526933498544};\\\", \\\"{x:1310,y:477,t:1526933498563};\\\", \\\"{x:1309,y:477,t:1526933498620};\\\", \\\"{x:1308,y:477,t:1526933498724};\\\", \\\"{x:1308,y:478,t:1526933498732};\\\", \\\"{x:1308,y:480,t:1526933498756};\\\", \\\"{x:1308,y:481,t:1526933498780};\\\", \\\"{x:1308,y:483,t:1526933498804};\\\", \\\"{x:1309,y:484,t:1526933498885};\\\", \\\"{x:1309,y:486,t:1526933498924};\\\", \\\"{x:1309,y:487,t:1526933498940};\\\", \\\"{x:1309,y:489,t:1526933498956};\\\", \\\"{x:1309,y:490,t:1526933498988};\\\", \\\"{x:1310,y:490,t:1526933499037};\\\", \\\"{x:1311,y:490,t:1526933499148};\\\", \\\"{x:1312,y:491,t:1526933499276};\\\", \\\"{x:1312,y:493,t:1526933499487};\\\", \\\"{x:1312,y:495,t:1526933506395};\\\", \\\"{x:1314,y:499,t:1526933506402};\\\", \\\"{x:1315,y:503,t:1526933506416};\\\", \\\"{x:1317,y:511,t:1526933506432};\\\", \\\"{x:1318,y:518,t:1526933506449};\\\", \\\"{x:1320,y:521,t:1526933506466};\\\", \\\"{x:1321,y:528,t:1526933506482};\\\", \\\"{x:1322,y:531,t:1526933506499};\\\", \\\"{x:1322,y:536,t:1526933506516};\\\", \\\"{x:1322,y:544,t:1526933506533};\\\", \\\"{x:1322,y:558,t:1526933506548};\\\", \\\"{x:1322,y:571,t:1526933506566};\\\", \\\"{x:1322,y:583,t:1526933506582};\\\", \\\"{x:1322,y:593,t:1526933506598};\\\", \\\"{x:1322,y:605,t:1526933506616};\\\", \\\"{x:1321,y:615,t:1526933506632};\\\", \\\"{x:1321,y:625,t:1526933506648};\\\", \\\"{x:1321,y:635,t:1526933506665};\\\", \\\"{x:1321,y:648,t:1526933506682};\\\", \\\"{x:1320,y:657,t:1526933506698};\\\", \\\"{x:1320,y:662,t:1526933506715};\\\", \\\"{x:1319,y:669,t:1526933506732};\\\", \\\"{x:1318,y:674,t:1526933506749};\\\", \\\"{x:1317,y:678,t:1526933506766};\\\", \\\"{x:1316,y:685,t:1526933506782};\\\", \\\"{x:1315,y:693,t:1526933506799};\\\", \\\"{x:1313,y:698,t:1526933506816};\\\", \\\"{x:1311,y:703,t:1526933506832};\\\", \\\"{x:1311,y:705,t:1526933506849};\\\", \\\"{x:1310,y:706,t:1526933506866};\\\", \\\"{x:1309,y:709,t:1526933506883};\\\", \\\"{x:1309,y:712,t:1526933506899};\\\", \\\"{x:1309,y:716,t:1526933506916};\\\", \\\"{x:1307,y:724,t:1526933506933};\\\", \\\"{x:1305,y:733,t:1526933506950};\\\", \\\"{x:1304,y:740,t:1526933506966};\\\", \\\"{x:1304,y:746,t:1526933506983};\\\", \\\"{x:1304,y:753,t:1526933507000};\\\", \\\"{x:1304,y:759,t:1526933507016};\\\", \\\"{x:1304,y:768,t:1526933507033};\\\", \\\"{x:1304,y:776,t:1526933507050};\\\", \\\"{x:1304,y:786,t:1526933507066};\\\", \\\"{x:1304,y:805,t:1526933507083};\\\", \\\"{x:1304,y:822,t:1526933507099};\\\", \\\"{x:1304,y:834,t:1526933507116};\\\", \\\"{x:1304,y:843,t:1526933507133};\\\", \\\"{x:1304,y:851,t:1526933507149};\\\", \\\"{x:1304,y:858,t:1526933507165};\\\", \\\"{x:1304,y:865,t:1526933507183};\\\", \\\"{x:1306,y:876,t:1526933507200};\\\", \\\"{x:1308,y:882,t:1526933507216};\\\", \\\"{x:1308,y:894,t:1526933507232};\\\", \\\"{x:1312,y:906,t:1526933507250};\\\", \\\"{x:1313,y:913,t:1526933507266};\\\", \\\"{x:1315,y:922,t:1526933507283};\\\", \\\"{x:1315,y:926,t:1526933507300};\\\", \\\"{x:1315,y:933,t:1526933507316};\\\", \\\"{x:1316,y:939,t:1526933507333};\\\", \\\"{x:1319,y:946,t:1526933507349};\\\", \\\"{x:1319,y:952,t:1526933507366};\\\", \\\"{x:1319,y:957,t:1526933507383};\\\", \\\"{x:1319,y:963,t:1526933507400};\\\", \\\"{x:1320,y:968,t:1526933507417};\\\", \\\"{x:1320,y:971,t:1526933507433};\\\", \\\"{x:1320,y:975,t:1526933507450};\\\", \\\"{x:1320,y:978,t:1526933507467};\\\", \\\"{x:1320,y:980,t:1526933507484};\\\", \\\"{x:1320,y:981,t:1526933507501};\\\", \\\"{x:1320,y:982,t:1526933507524};\\\", \\\"{x:1319,y:982,t:1526933507756};\\\", \\\"{x:1319,y:981,t:1526933507766};\\\", \\\"{x:1318,y:978,t:1526933507783};\\\", \\\"{x:1316,y:977,t:1526933507800};\\\", \\\"{x:1316,y:976,t:1526933507818};\\\", \\\"{x:1316,y:975,t:1526933507834};\\\", \\\"{x:1316,y:974,t:1526933507850};\\\", \\\"{x:1315,y:972,t:1526933507867};\\\", \\\"{x:1314,y:971,t:1526933507884};\\\", \\\"{x:1313,y:969,t:1526933507900};\\\", \\\"{x:1313,y:968,t:1526933507917};\\\", \\\"{x:1313,y:967,t:1526933507934};\\\", \\\"{x:1313,y:966,t:1526933507950};\\\", \\\"{x:1313,y:965,t:1526933507967};\\\", \\\"{x:1312,y:962,t:1526933507985};\\\", \\\"{x:1312,y:959,t:1526933508000};\\\", \\\"{x:1311,y:958,t:1526933508017};\\\", \\\"{x:1311,y:956,t:1526933508034};\\\", \\\"{x:1311,y:955,t:1526933508050};\\\", \\\"{x:1311,y:953,t:1526933508067};\\\", \\\"{x:1311,y:952,t:1526933508092};\\\", \\\"{x:1311,y:951,t:1526933508101};\\\", \\\"{x:1311,y:950,t:1526933508117};\\\", \\\"{x:1311,y:947,t:1526933508135};\\\", \\\"{x:1311,y:945,t:1526933508150};\\\", \\\"{x:1310,y:940,t:1526933508167};\\\", \\\"{x:1310,y:936,t:1526933508184};\\\", \\\"{x:1310,y:931,t:1526933508200};\\\", \\\"{x:1310,y:925,t:1526933508217};\\\", \\\"{x:1310,y:918,t:1526933508234};\\\", \\\"{x:1310,y:910,t:1526933508250};\\\", \\\"{x:1309,y:895,t:1526933508267};\\\", \\\"{x:1309,y:875,t:1526933508284};\\\", \\\"{x:1309,y:858,t:1526933508300};\\\", \\\"{x:1309,y:843,t:1526933508317};\\\", \\\"{x:1309,y:822,t:1526933508334};\\\", \\\"{x:1311,y:800,t:1526933508351};\\\", \\\"{x:1313,y:777,t:1526933508368};\\\", \\\"{x:1316,y:749,t:1526933508385};\\\", \\\"{x:1319,y:718,t:1526933508402};\\\", \\\"{x:1323,y:682,t:1526933508417};\\\", \\\"{x:1324,y:657,t:1526933508434};\\\", \\\"{x:1324,y:628,t:1526933508452};\\\", \\\"{x:1324,y:616,t:1526933508468};\\\", \\\"{x:1325,y:604,t:1526933508484};\\\", \\\"{x:1325,y:592,t:1526933508501};\\\", \\\"{x:1325,y:581,t:1526933508517};\\\", \\\"{x:1325,y:568,t:1526933508534};\\\", \\\"{x:1325,y:553,t:1526933508551};\\\", \\\"{x:1325,y:538,t:1526933508567};\\\", \\\"{x:1325,y:526,t:1526933508584};\\\", \\\"{x:1325,y:517,t:1526933508603};\\\", \\\"{x:1325,y:512,t:1526933508618};\\\", \\\"{x:1325,y:506,t:1526933508634};\\\", \\\"{x:1325,y:497,t:1526933508651};\\\", \\\"{x:1325,y:493,t:1526933508668};\\\", \\\"{x:1325,y:488,t:1526933508685};\\\", \\\"{x:1325,y:483,t:1526933508702};\\\", \\\"{x:1325,y:482,t:1526933508717};\\\", \\\"{x:1325,y:480,t:1526933508734};\\\", \\\"{x:1324,y:482,t:1526933508853};\\\", \\\"{x:1321,y:499,t:1526933508868};\\\", \\\"{x:1317,y:521,t:1526933508885};\\\", \\\"{x:1313,y:548,t:1526933508901};\\\", \\\"{x:1312,y:573,t:1526933508918};\\\", \\\"{x:1312,y:596,t:1526933508934};\\\", \\\"{x:1312,y:618,t:1526933508952};\\\", \\\"{x:1312,y:644,t:1526933508968};\\\", \\\"{x:1312,y:668,t:1526933508984};\\\", \\\"{x:1312,y:695,t:1526933509002};\\\", \\\"{x:1312,y:717,t:1526933509018};\\\", \\\"{x:1312,y:738,t:1526933509034};\\\", \\\"{x:1312,y:761,t:1526933509050};\\\", \\\"{x:1312,y:773,t:1526933509067};\\\", \\\"{x:1312,y:783,t:1526933509084};\\\", \\\"{x:1311,y:797,t:1526933509101};\\\", \\\"{x:1311,y:806,t:1526933509118};\\\", \\\"{x:1311,y:812,t:1526933509133};\\\", \\\"{x:1311,y:815,t:1526933509151};\\\", \\\"{x:1311,y:820,t:1526933509168};\\\", \\\"{x:1311,y:824,t:1526933509183};\\\", \\\"{x:1312,y:831,t:1526933509201};\\\", \\\"{x:1313,y:841,t:1526933509218};\\\", \\\"{x:1315,y:851,t:1526933509234};\\\", \\\"{x:1318,y:872,t:1526933509251};\\\", \\\"{x:1320,y:886,t:1526933509268};\\\", \\\"{x:1322,y:900,t:1526933509285};\\\", \\\"{x:1324,y:911,t:1526933509301};\\\", \\\"{x:1325,y:923,t:1526933509318};\\\", \\\"{x:1328,y:935,t:1526933509335};\\\", \\\"{x:1328,y:946,t:1526933509351};\\\", \\\"{x:1328,y:958,t:1526933509368};\\\", \\\"{x:1329,y:969,t:1526933509385};\\\", \\\"{x:1329,y:973,t:1526933509402};\\\", \\\"{x:1329,y:975,t:1526933509418};\\\", \\\"{x:1329,y:976,t:1526933509435};\\\", \\\"{x:1329,y:977,t:1526933509451};\\\", \\\"{x:1329,y:978,t:1526933509468};\\\", \\\"{x:1329,y:979,t:1526933509485};\\\", \\\"{x:1329,y:981,t:1526933509501};\\\", \\\"{x:1329,y:983,t:1526933509518};\\\", \\\"{x:1329,y:984,t:1526933509536};\\\", \\\"{x:1327,y:986,t:1526933509552};\\\", \\\"{x:1326,y:987,t:1526933509572};\\\", \\\"{x:1325,y:987,t:1526933509587};\\\", \\\"{x:1324,y:987,t:1526933509603};\\\", \\\"{x:1321,y:987,t:1526933509618};\\\", \\\"{x:1316,y:987,t:1526933509635};\\\", \\\"{x:1315,y:986,t:1526933509651};\\\", \\\"{x:1313,y:986,t:1526933509668};\\\", \\\"{x:1312,y:986,t:1526933509686};\\\", \\\"{x:1311,y:985,t:1526933509716};\\\", \\\"{x:1310,y:983,t:1526933509740};\\\", \\\"{x:1310,y:982,t:1526933509770};\\\", \\\"{x:1310,y:981,t:1526933509786};\\\", \\\"{x:1310,y:980,t:1526933509802};\\\", \\\"{x:1309,y:978,t:1526933509817};\\\", \\\"{x:1309,y:974,t:1526933509835};\\\", \\\"{x:1309,y:973,t:1526933509851};\\\", \\\"{x:1309,y:971,t:1526933509868};\\\", \\\"{x:1309,y:969,t:1526933509884};\\\", \\\"{x:1309,y:968,t:1526933509902};\\\", \\\"{x:1309,y:967,t:1526933510484};\\\", \\\"{x:1310,y:967,t:1526933510619};\\\", \\\"{x:1311,y:967,t:1526933510635};\\\", \\\"{x:1312,y:967,t:1526933510722};\\\", \\\"{x:1312,y:965,t:1526933522772};\\\", \\\"{x:1312,y:959,t:1526933522780};\\\", \\\"{x:1314,y:949,t:1526933522795};\\\", \\\"{x:1325,y:925,t:1526933522812};\\\", \\\"{x:1332,y:905,t:1526933522828};\\\", \\\"{x:1337,y:880,t:1526933522846};\\\", \\\"{x:1337,y:854,t:1526933522862};\\\", \\\"{x:1337,y:810,t:1526933522878};\\\", \\\"{x:1337,y:749,t:1526933522895};\\\", \\\"{x:1337,y:693,t:1526933522912};\\\", \\\"{x:1337,y:643,t:1526933522927};\\\", \\\"{x:1337,y:610,t:1526933522945};\\\", \\\"{x:1337,y:584,t:1526933522962};\\\", \\\"{x:1336,y:565,t:1526933522978};\\\", \\\"{x:1336,y:548,t:1526933522995};\\\", \\\"{x:1335,y:530,t:1526933523011};\\\", \\\"{x:1333,y:521,t:1526933523028};\\\", \\\"{x:1332,y:513,t:1526933523045};\\\", \\\"{x:1332,y:505,t:1526933523062};\\\", \\\"{x:1332,y:501,t:1526933523078};\\\", \\\"{x:1332,y:498,t:1526933523095};\\\", \\\"{x:1332,y:497,t:1526933523112};\\\", \\\"{x:1330,y:496,t:1526933523132};\\\", \\\"{x:1329,y:494,t:1526933523148};\\\", \\\"{x:1327,y:492,t:1526933523162};\\\", \\\"{x:1320,y:485,t:1526933523180};\\\", \\\"{x:1317,y:484,t:1526933523195};\\\", \\\"{x:1313,y:482,t:1526933523212};\\\", \\\"{x:1312,y:482,t:1526933523229};\\\", \\\"{x:1310,y:482,t:1526933523244};\\\", \\\"{x:1307,y:482,t:1526933523262};\\\", \\\"{x:1306,y:482,t:1526933523356};\\\", \\\"{x:1306,y:484,t:1526933523379};\\\", \\\"{x:1306,y:487,t:1526933523395};\\\", \\\"{x:1306,y:489,t:1526933523412};\\\", \\\"{x:1306,y:492,t:1526933523429};\\\", \\\"{x:1306,y:495,t:1526933523445};\\\", \\\"{x:1306,y:499,t:1526933523462};\\\", \\\"{x:1307,y:502,t:1526933523479};\\\", \\\"{x:1309,y:506,t:1526933523495};\\\", \\\"{x:1309,y:509,t:1526933523512};\\\", \\\"{x:1309,y:512,t:1526933523529};\\\", \\\"{x:1311,y:513,t:1526933523545};\\\", \\\"{x:1311,y:516,t:1526933523561};\\\", \\\"{x:1312,y:523,t:1526933523579};\\\", \\\"{x:1312,y:527,t:1526933523595};\\\", \\\"{x:1312,y:534,t:1526933523612};\\\", \\\"{x:1312,y:539,t:1526933523629};\\\", \\\"{x:1313,y:547,t:1526933523646};\\\", \\\"{x:1313,y:551,t:1526933523662};\\\", \\\"{x:1314,y:555,t:1526933523679};\\\", \\\"{x:1316,y:558,t:1526933523696};\\\", \\\"{x:1317,y:564,t:1526933523712};\\\", \\\"{x:1319,y:569,t:1526933523729};\\\", \\\"{x:1320,y:574,t:1526933523746};\\\", \\\"{x:1320,y:577,t:1526933523762};\\\", \\\"{x:1321,y:584,t:1526933523780};\\\", \\\"{x:1323,y:590,t:1526933523795};\\\", \\\"{x:1323,y:597,t:1526933523812};\\\", \\\"{x:1323,y:609,t:1526933523829};\\\", \\\"{x:1324,y:619,t:1526933523846};\\\", \\\"{x:1325,y:633,t:1526933523862};\\\", \\\"{x:1325,y:640,t:1526933523879};\\\", \\\"{x:1327,y:646,t:1526933523896};\\\", \\\"{x:1328,y:650,t:1526933523912};\\\", \\\"{x:1328,y:654,t:1526933523929};\\\", \\\"{x:1328,y:660,t:1526933523946};\\\", \\\"{x:1328,y:667,t:1526933523962};\\\", \\\"{x:1328,y:681,t:1526933523979};\\\", \\\"{x:1328,y:685,t:1526933523995};\\\", \\\"{x:1328,y:692,t:1526933524012};\\\", \\\"{x:1327,y:696,t:1526933524029};\\\", \\\"{x:1327,y:700,t:1526933524046};\\\", \\\"{x:1325,y:709,t:1526933524062};\\\", \\\"{x:1323,y:723,t:1526933524079};\\\", \\\"{x:1320,y:737,t:1526933524096};\\\", \\\"{x:1316,y:749,t:1526933524113};\\\", \\\"{x:1313,y:758,t:1526933524129};\\\", \\\"{x:1312,y:764,t:1526933524146};\\\", \\\"{x:1309,y:773,t:1526933524163};\\\", \\\"{x:1308,y:782,t:1526933524179};\\\", \\\"{x:1307,y:791,t:1526933524196};\\\", \\\"{x:1304,y:802,t:1526933524213};\\\", \\\"{x:1302,y:810,t:1526933524229};\\\", \\\"{x:1299,y:817,t:1526933524246};\\\", \\\"{x:1299,y:821,t:1526933524263};\\\", \\\"{x:1299,y:824,t:1526933524279};\\\", \\\"{x:1299,y:828,t:1526933524296};\\\", \\\"{x:1299,y:832,t:1526933524313};\\\", \\\"{x:1298,y:838,t:1526933524329};\\\", \\\"{x:1296,y:844,t:1526933524346};\\\", \\\"{x:1295,y:851,t:1526933524363};\\\", \\\"{x:1295,y:854,t:1526933524379};\\\", \\\"{x:1295,y:857,t:1526933524396};\\\", \\\"{x:1295,y:861,t:1526933524414};\\\", \\\"{x:1295,y:865,t:1526933524429};\\\", \\\"{x:1295,y:871,t:1526933524446};\\\", \\\"{x:1295,y:878,t:1526933524463};\\\", \\\"{x:1295,y:887,t:1526933524479};\\\", \\\"{x:1295,y:895,t:1526933524496};\\\", \\\"{x:1295,y:904,t:1526933524513};\\\", \\\"{x:1295,y:911,t:1526933524530};\\\", \\\"{x:1295,y:915,t:1526933524546};\\\", \\\"{x:1296,y:922,t:1526933524563};\\\", \\\"{x:1297,y:925,t:1526933524580};\\\", \\\"{x:1297,y:928,t:1526933524596};\\\", \\\"{x:1298,y:932,t:1526933524613};\\\", \\\"{x:1299,y:933,t:1526933524630};\\\", \\\"{x:1299,y:939,t:1526933524646};\\\", \\\"{x:1299,y:942,t:1526933524663};\\\", \\\"{x:1299,y:946,t:1526933524680};\\\", \\\"{x:1299,y:949,t:1526933524696};\\\", \\\"{x:1300,y:950,t:1526933524713};\\\", \\\"{x:1302,y:952,t:1526933524730};\\\", \\\"{x:1304,y:954,t:1526933524746};\\\", \\\"{x:1306,y:956,t:1526933524763};\\\", \\\"{x:1308,y:956,t:1526933524779};\\\", \\\"{x:1309,y:957,t:1526933524812};\\\", \\\"{x:1309,y:958,t:1526933524827};\\\", \\\"{x:1310,y:959,t:1526933524835};\\\", \\\"{x:1310,y:960,t:1526933524846};\\\", \\\"{x:1310,y:962,t:1526933524863};\\\", \\\"{x:1312,y:965,t:1526933524880};\\\", \\\"{x:1313,y:966,t:1526933524895};\\\", \\\"{x:1313,y:968,t:1526933524956};\\\", \\\"{x:1315,y:970,t:1526933524988};\\\", \\\"{x:1314,y:966,t:1526933548696};\\\", \\\"{x:1314,y:965,t:1526933548702};\\\", \\\"{x:1314,y:964,t:1526933548717};\\\", \\\"{x:1314,y:959,t:1526933548735};\\\", \\\"{x:1314,y:958,t:1526933548750};\\\", \\\"{x:1314,y:957,t:1526933548767};\\\", \\\"{x:1314,y:956,t:1526933548895};\\\", \\\"{x:1314,y:955,t:1526933548902};\\\", \\\"{x:1314,y:953,t:1526933548919};\\\", \\\"{x:1314,y:952,t:1526933548935};\\\", \\\"{x:1314,y:948,t:1526933548951};\\\", \\\"{x:1314,y:943,t:1526933548967};\\\", \\\"{x:1314,y:938,t:1526933548984};\\\", \\\"{x:1314,y:933,t:1526933549001};\\\", \\\"{x:1314,y:929,t:1526933549017};\\\", \\\"{x:1314,y:926,t:1526933549034};\\\", \\\"{x:1314,y:922,t:1526933549052};\\\", \\\"{x:1314,y:919,t:1526933549068};\\\", \\\"{x:1314,y:917,t:1526933549084};\\\", \\\"{x:1314,y:915,t:1526933549102};\\\", \\\"{x:1314,y:914,t:1526933549117};\\\", \\\"{x:1314,y:913,t:1526933549134};\\\", \\\"{x:1314,y:911,t:1526933549152};\\\", \\\"{x:1314,y:908,t:1526933549167};\\\", \\\"{x:1314,y:906,t:1526933549184};\\\", \\\"{x:1314,y:902,t:1526933549201};\\\", \\\"{x:1314,y:899,t:1526933549217};\\\", \\\"{x:1314,y:895,t:1526933549234};\\\", \\\"{x:1314,y:891,t:1526933549252};\\\", \\\"{x:1314,y:886,t:1526933549268};\\\", \\\"{x:1314,y:883,t:1526933549285};\\\", \\\"{x:1314,y:879,t:1526933549302};\\\", \\\"{x:1314,y:873,t:1526933549318};\\\", \\\"{x:1314,y:872,t:1526933549334};\\\", \\\"{x:1314,y:869,t:1526933549352};\\\", \\\"{x:1314,y:867,t:1526933549368};\\\", \\\"{x:1314,y:865,t:1526933549384};\\\", \\\"{x:1314,y:861,t:1526933549401};\\\", \\\"{x:1315,y:856,t:1526933549417};\\\", \\\"{x:1316,y:851,t:1526933549434};\\\", \\\"{x:1316,y:847,t:1526933549451};\\\", \\\"{x:1319,y:841,t:1526933549468};\\\", \\\"{x:1320,y:837,t:1526933549483};\\\", \\\"{x:1320,y:833,t:1526933549501};\\\", \\\"{x:1320,y:824,t:1526933549517};\\\", \\\"{x:1321,y:819,t:1526933549534};\\\", \\\"{x:1322,y:814,t:1526933549551};\\\", \\\"{x:1323,y:810,t:1526933549568};\\\", \\\"{x:1323,y:806,t:1526933549584};\\\", \\\"{x:1324,y:805,t:1526933549601};\\\", \\\"{x:1324,y:801,t:1526933549618};\\\", \\\"{x:1324,y:798,t:1526933549634};\\\", \\\"{x:1324,y:793,t:1526933549651};\\\", \\\"{x:1324,y:790,t:1526933549668};\\\", \\\"{x:1324,y:783,t:1526933549684};\\\", \\\"{x:1324,y:776,t:1526933549701};\\\", \\\"{x:1324,y:767,t:1526933549718};\\\", \\\"{x:1324,y:759,t:1526933549735};\\\", \\\"{x:1324,y:752,t:1526933549752};\\\", \\\"{x:1324,y:746,t:1526933549767};\\\", \\\"{x:1324,y:742,t:1526933549785};\\\", \\\"{x:1324,y:734,t:1526933549801};\\\", \\\"{x:1324,y:730,t:1526933549817};\\\", \\\"{x:1324,y:727,t:1526933549835};\\\", \\\"{x:1324,y:722,t:1526933549851};\\\", \\\"{x:1324,y:717,t:1526933549868};\\\", \\\"{x:1324,y:712,t:1526933549886};\\\", \\\"{x:1324,y:708,t:1526933549901};\\\", \\\"{x:1324,y:701,t:1526933549918};\\\", \\\"{x:1324,y:696,t:1526933549935};\\\", \\\"{x:1324,y:693,t:1526933549952};\\\", \\\"{x:1324,y:689,t:1526933549969};\\\", \\\"{x:1323,y:679,t:1526933549985};\\\", \\\"{x:1322,y:674,t:1526933550001};\\\", \\\"{x:1318,y:666,t:1526933550019};\\\", \\\"{x:1316,y:657,t:1526933550036};\\\", \\\"{x:1312,y:650,t:1526933550051};\\\", \\\"{x:1309,y:642,t:1526933550068};\\\", \\\"{x:1304,y:633,t:1526933550086};\\\", \\\"{x:1303,y:628,t:1526933550101};\\\", \\\"{x:1301,y:622,t:1526933550118};\\\", \\\"{x:1300,y:617,t:1526933550135};\\\", \\\"{x:1297,y:612,t:1526933550152};\\\", \\\"{x:1297,y:607,t:1526933550168};\\\", \\\"{x:1297,y:605,t:1526933550186};\\\", \\\"{x:1297,y:603,t:1526933550202};\\\", \\\"{x:1297,y:601,t:1526933550218};\\\", \\\"{x:1297,y:600,t:1526933550238};\\\", \\\"{x:1297,y:599,t:1526933550253};\\\", \\\"{x:1297,y:598,t:1526933550269};\\\", \\\"{x:1297,y:597,t:1526933550286};\\\", \\\"{x:1297,y:596,t:1526933550302};\\\", \\\"{x:1299,y:595,t:1526933550318};\\\", \\\"{x:1299,y:594,t:1526933550336};\\\", \\\"{x:1300,y:592,t:1526933550352};\\\", \\\"{x:1301,y:591,t:1526933550383};\\\", \\\"{x:1301,y:590,t:1526933550398};\\\", \\\"{x:1301,y:589,t:1526933550406};\\\", \\\"{x:1302,y:589,t:1526933550418};\\\", \\\"{x:1302,y:588,t:1526933550439};\\\", \\\"{x:1303,y:586,t:1526933550455};\\\", \\\"{x:1303,y:585,t:1526933550469};\\\", \\\"{x:1303,y:583,t:1526933550486};\\\", \\\"{x:1304,y:579,t:1526933550503};\\\", \\\"{x:1305,y:576,t:1526933550519};\\\", \\\"{x:1306,y:573,t:1526933550535};\\\", \\\"{x:1306,y:570,t:1526933550552};\\\", \\\"{x:1307,y:565,t:1526933550569};\\\", \\\"{x:1307,y:559,t:1526933550586};\\\", \\\"{x:1309,y:554,t:1526933550602};\\\", \\\"{x:1309,y:549,t:1526933550619};\\\", \\\"{x:1310,y:545,t:1526933550635};\\\", \\\"{x:1311,y:540,t:1526933550653};\\\", \\\"{x:1311,y:536,t:1526933550668};\\\", \\\"{x:1312,y:532,t:1526933550685};\\\", \\\"{x:1313,y:528,t:1526933550702};\\\", \\\"{x:1315,y:520,t:1526933550719};\\\", \\\"{x:1315,y:517,t:1526933550735};\\\", \\\"{x:1315,y:514,t:1526933550752};\\\", \\\"{x:1315,y:509,t:1526933550770};\\\", \\\"{x:1317,y:506,t:1526933550785};\\\", \\\"{x:1317,y:505,t:1526933550802};\\\", \\\"{x:1317,y:501,t:1526933550820};\\\", \\\"{x:1317,y:500,t:1526933550835};\\\", \\\"{x:1317,y:498,t:1526933550853};\\\", \\\"{x:1317,y:493,t:1526933550869};\\\", \\\"{x:1317,y:492,t:1526933550886};\\\", \\\"{x:1317,y:491,t:1526933550902};\\\", \\\"{x:1318,y:491,t:1526933551664};\\\", \\\"{x:1320,y:491,t:1526933551671};\\\", \\\"{x:1323,y:492,t:1526933551686};\\\", \\\"{x:1324,y:492,t:1526933551703};\\\", \\\"{x:1325,y:492,t:1526933551720};\\\", \\\"{x:1326,y:492,t:1526933551766};\\\", \\\"{x:1327,y:493,t:1526933552055};\\\", \\\"{x:1323,y:495,t:1526933552070};\\\", \\\"{x:1321,y:495,t:1526933552086};\\\", \\\"{x:1319,y:496,t:1526933552104};\\\", \\\"{x:1318,y:496,t:1526933552120};\\\", \\\"{x:1316,y:497,t:1526933552136};\\\", \\\"{x:1316,y:498,t:1526933552183};\\\", \\\"{x:1315,y:498,t:1526933552190};\\\", \\\"{x:1313,y:499,t:1526933552206};\\\", \\\"{x:1312,y:499,t:1526933552238};\\\", \\\"{x:1311,y:499,t:1526933552262};\\\", \\\"{x:1311,y:500,t:1526933552278};\\\", \\\"{x:1310,y:502,t:1526933569663};\\\", \\\"{x:1310,y:503,t:1526933569670};\\\", \\\"{x:1310,y:505,t:1526933569683};\\\", \\\"{x:1310,y:510,t:1526933569700};\\\", \\\"{x:1310,y:513,t:1526933569716};\\\", \\\"{x:1311,y:516,t:1526933569733};\\\", \\\"{x:1311,y:519,t:1526933569749};\\\", \\\"{x:1311,y:522,t:1526933569766};\\\", \\\"{x:1312,y:523,t:1526933569783};\\\", \\\"{x:1312,y:526,t:1526933569799};\\\", \\\"{x:1312,y:528,t:1526933569816};\\\", \\\"{x:1312,y:529,t:1526933569833};\\\", \\\"{x:1313,y:531,t:1526933569849};\\\", \\\"{x:1314,y:532,t:1526933569865};\\\", \\\"{x:1314,y:534,t:1526933569902};\\\", \\\"{x:1314,y:535,t:1526933569915};\\\", \\\"{x:1315,y:537,t:1526933569932};\\\", \\\"{x:1315,y:540,t:1526933569949};\\\", \\\"{x:1315,y:542,t:1526933569966};\\\", \\\"{x:1316,y:547,t:1526933569982};\\\", \\\"{x:1317,y:553,t:1526933570000};\\\", \\\"{x:1317,y:564,t:1526933570016};\\\", \\\"{x:1317,y:577,t:1526933570033};\\\", \\\"{x:1317,y:591,t:1526933570050};\\\", \\\"{x:1317,y:607,t:1526933570066};\\\", \\\"{x:1317,y:622,t:1526933570083};\\\", \\\"{x:1318,y:637,t:1526933570100};\\\", \\\"{x:1319,y:651,t:1526933570116};\\\", \\\"{x:1319,y:665,t:1526933570133};\\\", \\\"{x:1319,y:680,t:1526933570149};\\\", \\\"{x:1319,y:694,t:1526933570166};\\\", \\\"{x:1319,y:707,t:1526933570183};\\\", \\\"{x:1319,y:718,t:1526933570199};\\\", \\\"{x:1319,y:726,t:1526933570215};\\\", \\\"{x:1319,y:736,t:1526933570232};\\\", \\\"{x:1319,y:748,t:1526933570250};\\\", \\\"{x:1319,y:758,t:1526933570267};\\\", \\\"{x:1319,y:771,t:1526933570283};\\\", \\\"{x:1320,y:779,t:1526933570300};\\\", \\\"{x:1322,y:788,t:1526933570317};\\\", \\\"{x:1323,y:794,t:1526933570333};\\\", \\\"{x:1324,y:800,t:1526933570349};\\\", \\\"{x:1324,y:804,t:1526933570367};\\\", \\\"{x:1324,y:805,t:1526933570383};\\\", \\\"{x:1324,y:807,t:1526933570399};\\\", \\\"{x:1324,y:810,t:1526933570417};\\\", \\\"{x:1324,y:813,t:1526933570433};\\\", \\\"{x:1324,y:814,t:1526933570450};\\\", \\\"{x:1324,y:817,t:1526933570467};\\\", \\\"{x:1324,y:820,t:1526933570483};\\\", \\\"{x:1324,y:824,t:1526933570500};\\\", \\\"{x:1324,y:828,t:1526933570517};\\\", \\\"{x:1324,y:834,t:1526933570533};\\\", \\\"{x:1324,y:848,t:1526933570550};\\\", \\\"{x:1324,y:862,t:1526933570567};\\\", \\\"{x:1327,y:876,t:1526933570583};\\\", \\\"{x:1328,y:886,t:1526933570600};\\\", \\\"{x:1331,y:895,t:1526933570617};\\\", \\\"{x:1332,y:903,t:1526933570633};\\\", \\\"{x:1332,y:908,t:1526933570650};\\\", \\\"{x:1333,y:916,t:1526933570667};\\\", \\\"{x:1336,y:928,t:1526933570683};\\\", \\\"{x:1336,y:935,t:1526933570700};\\\", \\\"{x:1336,y:944,t:1526933570717};\\\", \\\"{x:1336,y:955,t:1526933570734};\\\", \\\"{x:1336,y:964,t:1526933570750};\\\", \\\"{x:1335,y:970,t:1526933570767};\\\", \\\"{x:1335,y:974,t:1526933570783};\\\", \\\"{x:1335,y:977,t:1526933570800};\\\", \\\"{x:1333,y:979,t:1526933570817};\\\", \\\"{x:1332,y:982,t:1526933570834};\\\", \\\"{x:1331,y:982,t:1526933570849};\\\", \\\"{x:1330,y:985,t:1526933570868};\\\", \\\"{x:1329,y:986,t:1526933570884};\\\", \\\"{x:1328,y:987,t:1526933570900};\\\", \\\"{x:1326,y:988,t:1526933570917};\\\", \\\"{x:1321,y:988,t:1526933570934};\\\", \\\"{x:1318,y:988,t:1526933570950};\\\", \\\"{x:1314,y:988,t:1526933570967};\\\", \\\"{x:1312,y:988,t:1526933570984};\\\", \\\"{x:1311,y:988,t:1526933571000};\\\", \\\"{x:1310,y:988,t:1526933571017};\\\", \\\"{x:1309,y:988,t:1526933571034};\\\", \\\"{x:1309,y:986,t:1526933571134};\\\", \\\"{x:1309,y:982,t:1526933571151};\\\", \\\"{x:1309,y:979,t:1526933571167};\\\", \\\"{x:1312,y:975,t:1526933571184};\\\", \\\"{x:1315,y:972,t:1526933571201};\\\", \\\"{x:1319,y:969,t:1526933571217};\\\", \\\"{x:1323,y:966,t:1526933571234};\\\", \\\"{x:1324,y:965,t:1526933571251};\\\", \\\"{x:1326,y:963,t:1526933571267};\\\", \\\"{x:1327,y:963,t:1526933571284};\\\", \\\"{x:1330,y:963,t:1526933571302};\\\", \\\"{x:1332,y:963,t:1526933571317};\\\", \\\"{x:1335,y:963,t:1526933571334};\\\", \\\"{x:1337,y:963,t:1526933571352};\\\", \\\"{x:1338,y:963,t:1526933571368};\\\", \\\"{x:1340,y:963,t:1526933571384};\\\", \\\"{x:1342,y:962,t:1526933571402};\\\", \\\"{x:1344,y:960,t:1526933571417};\\\", \\\"{x:1346,y:960,t:1526933571434};\\\", \\\"{x:1349,y:959,t:1526933571451};\\\", \\\"{x:1350,y:958,t:1526933571467};\\\", \\\"{x:1352,y:958,t:1526933571484};\\\", \\\"{x:1354,y:957,t:1526933571501};\\\", \\\"{x:1355,y:956,t:1526933571517};\\\", \\\"{x:1359,y:955,t:1526933571534};\\\", \\\"{x:1364,y:954,t:1526933571552};\\\", \\\"{x:1368,y:953,t:1526933571567};\\\", \\\"{x:1374,y:953,t:1526933571584};\\\", \\\"{x:1379,y:952,t:1526933571601};\\\", \\\"{x:1383,y:951,t:1526933571618};\\\", \\\"{x:1386,y:949,t:1526933571634};\\\", \\\"{x:1388,y:949,t:1526933571651};\\\", \\\"{x:1389,y:949,t:1526933571668};\\\", \\\"{x:1390,y:948,t:1526933571735};\\\", \\\"{x:1391,y:948,t:1526933571854};\\\", \\\"{x:1392,y:948,t:1526933571868};\\\", \\\"{x:1393,y:948,t:1526933571885};\\\", \\\"{x:1395,y:948,t:1526933571909};\\\", \\\"{x:1395,y:949,t:1526933571925};\\\", \\\"{x:1395,y:950,t:1526933571950};\\\", \\\"{x:1395,y:952,t:1526933571957};\\\", \\\"{x:1395,y:953,t:1526933571973};\\\", \\\"{x:1395,y:955,t:1526933572014};\\\", \\\"{x:1394,y:956,t:1526933572022};\\\", \\\"{x:1393,y:956,t:1526933572038};\\\", \\\"{x:1392,y:956,t:1526933572051};\\\", \\\"{x:1390,y:957,t:1526933572068};\\\", \\\"{x:1389,y:957,t:1526933572086};\\\", \\\"{x:1387,y:957,t:1526933572118};\\\", \\\"{x:1386,y:957,t:1526933572510};\\\", \\\"{x:1384,y:957,t:1526933572533};\\\", \\\"{x:1383,y:957,t:1526933572573};\\\", \\\"{x:1382,y:957,t:1526933572621};\\\", \\\"{x:1382,y:956,t:1526933572750};\\\", \\\"{x:1382,y:955,t:1526933572758};\\\", \\\"{x:1382,y:953,t:1526933572768};\\\", \\\"{x:1382,y:950,t:1526933572786};\\\", \\\"{x:1382,y:949,t:1526933572803};\\\", \\\"{x:1382,y:946,t:1526933572818};\\\", \\\"{x:1383,y:944,t:1526933572835};\\\", \\\"{x:1383,y:942,t:1526933572852};\\\", \\\"{x:1384,y:940,t:1526933572868};\\\", \\\"{x:1384,y:938,t:1526933572894};\\\", \\\"{x:1384,y:937,t:1526933572934};\\\", \\\"{x:1384,y:936,t:1526933572991};\\\", \\\"{x:1384,y:935,t:1526933573002};\\\", \\\"{x:1384,y:934,t:1526933573019};\\\", \\\"{x:1385,y:931,t:1526933573035};\\\", \\\"{x:1385,y:930,t:1526933573052};\\\", \\\"{x:1385,y:928,t:1526933573069};\\\", \\\"{x:1385,y:926,t:1526933573086};\\\", \\\"{x:1385,y:919,t:1526933573101};\\\", \\\"{x:1387,y:913,t:1526933573119};\\\", \\\"{x:1388,y:905,t:1526933573135};\\\", \\\"{x:1391,y:897,t:1526933573153};\\\", \\\"{x:1391,y:895,t:1526933573169};\\\", \\\"{x:1391,y:892,t:1526933573185};\\\", \\\"{x:1391,y:888,t:1526933573202};\\\", \\\"{x:1391,y:885,t:1526933573219};\\\", \\\"{x:1391,y:879,t:1526933573235};\\\", \\\"{x:1391,y:874,t:1526933573252};\\\", \\\"{x:1391,y:870,t:1526933573269};\\\", \\\"{x:1391,y:865,t:1526933573285};\\\", \\\"{x:1391,y:861,t:1526933573302};\\\", \\\"{x:1391,y:857,t:1526933573320};\\\", \\\"{x:1391,y:855,t:1526933573335};\\\", \\\"{x:1391,y:853,t:1526933573352};\\\", \\\"{x:1391,y:849,t:1526933573369};\\\", \\\"{x:1391,y:846,t:1526933573385};\\\", \\\"{x:1391,y:843,t:1526933573402};\\\", \\\"{x:1391,y:837,t:1526933573420};\\\", \\\"{x:1391,y:834,t:1526933573435};\\\", \\\"{x:1392,y:830,t:1526933573452};\\\", \\\"{x:1392,y:827,t:1526933573469};\\\", \\\"{x:1392,y:825,t:1526933573485};\\\", \\\"{x:1392,y:819,t:1526933573502};\\\", \\\"{x:1392,y:817,t:1526933573519};\\\", \\\"{x:1392,y:815,t:1526933573536};\\\", \\\"{x:1392,y:813,t:1526933573551};\\\", \\\"{x:1392,y:810,t:1526933573569};\\\", \\\"{x:1392,y:809,t:1526933573586};\\\", \\\"{x:1392,y:807,t:1526933573601};\\\", \\\"{x:1392,y:805,t:1526933573619};\\\", \\\"{x:1392,y:803,t:1526933573636};\\\", \\\"{x:1391,y:802,t:1526933573652};\\\", \\\"{x:1391,y:801,t:1526933573678};\\\", \\\"{x:1391,y:800,t:1526933573693};\\\", \\\"{x:1391,y:798,t:1526933573734};\\\", \\\"{x:1391,y:797,t:1526933573758};\\\", \\\"{x:1391,y:796,t:1526933573782};\\\", \\\"{x:1391,y:795,t:1526933573797};\\\", \\\"{x:1391,y:794,t:1526933573814};\\\", \\\"{x:1390,y:794,t:1526933573822};\\\", \\\"{x:1390,y:793,t:1526933573854};\\\", \\\"{x:1390,y:792,t:1526933573870};\\\", \\\"{x:1389,y:790,t:1526933573886};\\\", \\\"{x:1389,y:789,t:1526933573902};\\\", \\\"{x:1389,y:788,t:1526933573919};\\\", \\\"{x:1388,y:788,t:1526933573936};\\\", \\\"{x:1388,y:787,t:1526933573974};\\\", \\\"{x:1388,y:786,t:1526933574014};\\\", \\\"{x:1388,y:785,t:1526933574046};\\\", \\\"{x:1388,y:784,t:1526933574135};\\\", \\\"{x:1388,y:782,t:1526933574175};\\\", \\\"{x:1388,y:781,t:1526933574326};\\\", \\\"{x:1388,y:780,t:1526933574342};\\\", \\\"{x:1388,y:779,t:1526933574353};\\\", \\\"{x:1388,y:778,t:1526933574398};\\\", \\\"{x:1387,y:777,t:1526933574406};\\\", \\\"{x:1387,y:776,t:1526933574463};\\\", \\\"{x:1387,y:775,t:1526933574493};\\\", \\\"{x:1387,y:774,t:1526933574503};\\\", \\\"{x:1386,y:772,t:1526933574519};\\\", \\\"{x:1386,y:771,t:1526933574565};\\\", \\\"{x:1385,y:770,t:1526933574597};\\\", \\\"{x:1385,y:769,t:1526933574621};\\\", \\\"{x:1384,y:768,t:1526933574637};\\\", \\\"{x:1384,y:767,t:1526933574668};\\\", \\\"{x:1376,y:766,t:1526933580278};\\\", \\\"{x:1353,y:765,t:1526933580292};\\\", \\\"{x:1289,y:756,t:1526933580308};\\\", \\\"{x:1214,y:755,t:1526933580325};\\\", \\\"{x:1140,y:747,t:1526933580340};\\\", \\\"{x:1036,y:746,t:1526933580358};\\\", \\\"{x:969,y:746,t:1526933580374};\\\", \\\"{x:887,y:738,t:1526933580391};\\\", \\\"{x:809,y:738,t:1526933580407};\\\", \\\"{x:732,y:729,t:1526933580425};\\\", \\\"{x:663,y:722,t:1526933580440};\\\", \\\"{x:609,y:719,t:1526933580457};\\\", \\\"{x:561,y:712,t:1526933580474};\\\", \\\"{x:519,y:706,t:1526933580491};\\\", \\\"{x:495,y:701,t:1526933580508};\\\", \\\"{x:492,y:701,t:1526933580524};\\\", \\\"{x:491,y:700,t:1526933580550};\\\", \\\"{x:490,y:699,t:1526933580557};\\\", \\\"{x:487,y:695,t:1526933580574};\\\", \\\"{x:477,y:688,t:1526933580591};\\\", \\\"{x:467,y:680,t:1526933580607};\\\", \\\"{x:461,y:674,t:1526933580624};\\\", \\\"{x:459,y:669,t:1526933580640};\\\", \\\"{x:456,y:662,t:1526933580659};\\\", \\\"{x:455,y:658,t:1526933580674};\\\", \\\"{x:453,y:651,t:1526933580691};\\\", \\\"{x:451,y:640,t:1526933580714};\\\", \\\"{x:451,y:632,t:1526933580730};\\\", \\\"{x:449,y:623,t:1526933580748};\\\", \\\"{x:448,y:615,t:1526933580763};\\\", \\\"{x:448,y:608,t:1526933580780};\\\", \\\"{x:444,y:596,t:1526933580796};\\\", \\\"{x:440,y:584,t:1526933580813};\\\", \\\"{x:437,y:572,t:1526933580830};\\\", \\\"{x:430,y:560,t:1526933580847};\\\", \\\"{x:424,y:554,t:1526933580863};\\\", \\\"{x:420,y:550,t:1526933580880};\\\", \\\"{x:416,y:547,t:1526933580896};\\\", \\\"{x:408,y:545,t:1526933580914};\\\", \\\"{x:402,y:544,t:1526933580930};\\\", \\\"{x:399,y:544,t:1526933580947};\\\", \\\"{x:398,y:544,t:1526933580964};\\\", \\\"{x:397,y:543,t:1526933580980};\\\", \\\"{x:395,y:543,t:1526933580997};\\\", \\\"{x:394,y:543,t:1526933581022};\\\", \\\"{x:392,y:543,t:1526933581053};\\\", \\\"{x:391,y:543,t:1526933581070};\\\", \\\"{x:391,y:544,t:1526933581085};\\\", \\\"{x:391,y:545,t:1526933581097};\\\", \\\"{x:391,y:548,t:1526933581115};\\\", \\\"{x:390,y:548,t:1526933581130};\\\", \\\"{x:390,y:550,t:1526933581147};\\\", \\\"{x:388,y:553,t:1526933581164};\\\", \\\"{x:386,y:557,t:1526933581180};\\\", \\\"{x:385,y:561,t:1526933581197};\\\", \\\"{x:384,y:563,t:1526933581214};\\\", \\\"{x:383,y:565,t:1526933581237};\\\", \\\"{x:383,y:566,t:1526933581269};\\\", \\\"{x:383,y:567,t:1526933581325};\\\", \\\"{x:383,y:568,t:1526933581333};\\\", \\\"{x:383,y:570,t:1526933581347};\\\", \\\"{x:383,y:572,t:1526933581364};\\\", \\\"{x:383,y:574,t:1526933581380};\\\", \\\"{x:385,y:576,t:1526933581910};\\\", \\\"{x:390,y:578,t:1526933581918};\\\", \\\"{x:398,y:580,t:1526933581932};\\\", \\\"{x:416,y:589,t:1526933581950};\\\", \\\"{x:436,y:597,t:1526933581965};\\\", \\\"{x:465,y:613,t:1526933581981};\\\", \\\"{x:502,y:634,t:1526933582000};\\\", \\\"{x:567,y:670,t:1526933582014};\\\", \\\"{x:654,y:718,t:1526933582031};\\\", \\\"{x:754,y:762,t:1526933582048};\\\", \\\"{x:864,y:810,t:1526933582064};\\\", \\\"{x:985,y:857,t:1526933582081};\\\", \\\"{x:1107,y:897,t:1526933582097};\\\", \\\"{x:1232,y:935,t:1526933582114};\\\", \\\"{x:1332,y:965,t:1526933582131};\\\", \\\"{x:1420,y:990,t:1526933582147};\\\", \\\"{x:1476,y:1006,t:1526933582164};\\\", \\\"{x:1530,y:1020,t:1526933582181};\\\", \\\"{x:1551,y:1023,t:1526933582197};\\\", \\\"{x:1567,y:1025,t:1526933582215};\\\", \\\"{x:1575,y:1025,t:1526933582232};\\\", \\\"{x:1578,y:1025,t:1526933582247};\\\", \\\"{x:1579,y:1025,t:1526933582342};\\\", \\\"{x:1579,y:1022,t:1526933582358};\\\", \\\"{x:1576,y:1018,t:1526933582365};\\\", \\\"{x:1569,y:1014,t:1526933582381};\\\", \\\"{x:1556,y:1008,t:1526933582398};\\\", \\\"{x:1547,y:1004,t:1526933582414};\\\", \\\"{x:1537,y:1001,t:1526933582430};\\\", \\\"{x:1525,y:999,t:1526933582447};\\\", \\\"{x:1511,y:997,t:1526933582464};\\\", \\\"{x:1493,y:996,t:1526933582480};\\\", \\\"{x:1471,y:995,t:1526933582498};\\\", \\\"{x:1450,y:995,t:1526933582515};\\\", \\\"{x:1434,y:995,t:1526933582530};\\\", \\\"{x:1419,y:995,t:1526933582547};\\\", \\\"{x:1406,y:995,t:1526933582563};\\\", \\\"{x:1392,y:995,t:1526933582581};\\\", \\\"{x:1376,y:995,t:1526933582597};\\\", \\\"{x:1365,y:995,t:1526933582614};\\\", \\\"{x:1357,y:995,t:1526933582631};\\\", \\\"{x:1347,y:995,t:1526933582648};\\\", \\\"{x:1339,y:995,t:1526933582664};\\\", \\\"{x:1332,y:994,t:1526933582681};\\\", \\\"{x:1321,y:992,t:1526933582697};\\\", \\\"{x:1320,y:992,t:1526933582713};\\\", \\\"{x:1319,y:992,t:1526933582731};\\\", \\\"{x:1321,y:991,t:1526933583254};\\\", \\\"{x:1321,y:990,t:1526933583262};\\\", \\\"{x:1322,y:987,t:1526933583280};\\\", \\\"{x:1325,y:985,t:1526933583297};\\\", \\\"{x:1328,y:981,t:1526933583313};\\\", \\\"{x:1330,y:977,t:1526933583330};\\\", \\\"{x:1336,y:974,t:1526933583346};\\\", \\\"{x:1339,y:972,t:1526933583362};\\\", \\\"{x:1342,y:969,t:1526933583380};\\\", \\\"{x:1343,y:969,t:1526933583396};\\\", \\\"{x:1345,y:968,t:1526933583413};\\\", \\\"{x:1346,y:967,t:1526933583429};\\\", \\\"{x:1347,y:967,t:1526933583446};\\\", \\\"{x:1348,y:966,t:1526933583463};\\\", \\\"{x:1349,y:966,t:1526933583494};\\\", \\\"{x:1344,y:965,t:1526933590885};\\\", \\\"{x:1339,y:963,t:1526933590900};\\\", \\\"{x:1319,y:958,t:1526933590917};\\\", \\\"{x:1309,y:955,t:1526933590934};\\\", \\\"{x:1303,y:954,t:1526933590950};\\\", \\\"{x:1300,y:953,t:1526933590967};\\\", \\\"{x:1299,y:953,t:1526933590988};\\\", \\\"{x:1297,y:953,t:1526933591037};\\\", \\\"{x:1296,y:953,t:1526933591050};\\\", \\\"{x:1294,y:953,t:1526933591067};\\\", \\\"{x:1293,y:954,t:1526933591133};\\\", \\\"{x:1293,y:956,t:1526933591164};\\\", \\\"{x:1293,y:957,t:1526933591172};\\\", \\\"{x:1294,y:958,t:1526933591183};\\\", \\\"{x:1296,y:959,t:1526933591200};\\\", \\\"{x:1297,y:959,t:1526933591221};\\\", \\\"{x:1298,y:960,t:1526933591233};\\\", \\\"{x:1299,y:961,t:1526933591277};\\\", \\\"{x:1300,y:961,t:1526933591292};\\\", \\\"{x:1301,y:962,t:1526933591308};\\\", \\\"{x:1302,y:962,t:1526933591332};\\\", \\\"{x:1302,y:963,t:1526933591348};\\\", \\\"{x:1303,y:963,t:1526933591389};\\\", \\\"{x:1304,y:964,t:1526933591405};\\\", \\\"{x:1305,y:964,t:1526933591420};\\\", \\\"{x:1305,y:965,t:1526933591437};\\\", \\\"{x:1306,y:965,t:1526933591449};\\\", \\\"{x:1308,y:966,t:1526933591466};\\\", \\\"{x:1308,y:967,t:1526933591493};\\\", \\\"{x:1309,y:967,t:1526933591533};\\\", \\\"{x:1310,y:967,t:1526933591564};\\\", \\\"{x:1311,y:967,t:1526933591588};\\\", \\\"{x:1311,y:968,t:1526933591599};\\\", \\\"{x:1308,y:965,t:1526933595190};\\\", \\\"{x:1281,y:957,t:1526933595197};\\\", \\\"{x:1237,y:946,t:1526933595211};\\\", \\\"{x:1115,y:925,t:1526933595228};\\\", \\\"{x:987,y:906,t:1526933595245};\\\", \\\"{x:850,y:877,t:1526933595262};\\\", \\\"{x:850,y:876,t:1526933595278};\\\", \\\"{x:850,y:869,t:1526933595694};\\\", \\\"{x:849,y:846,t:1526933595710};\\\", \\\"{x:850,y:824,t:1526933595727};\\\", \\\"{x:853,y:804,t:1526933595744};\\\", \\\"{x:856,y:783,t:1526933595760};\\\", \\\"{x:857,y:770,t:1526933595777};\\\", \\\"{x:857,y:756,t:1526933595794};\\\", \\\"{x:857,y:737,t:1526933595810};\\\", \\\"{x:856,y:719,t:1526933595827};\\\", \\\"{x:852,y:698,t:1526933595843};\\\", \\\"{x:848,y:672,t:1526933595861};\\\", \\\"{x:839,y:629,t:1526933595877};\\\", \\\"{x:833,y:602,t:1526933595895};\\\", \\\"{x:831,y:579,t:1526933595910};\\\", \\\"{x:826,y:559,t:1526933595926};\\\", \\\"{x:820,y:538,t:1526933595943};\\\", \\\"{x:815,y:519,t:1526933595959};\\\", \\\"{x:809,y:498,t:1526933595975};\\\", \\\"{x:806,y:481,t:1526933595992};\\\", \\\"{x:805,y:470,t:1526933596008};\\\", \\\"{x:805,y:462,t:1526933596026};\\\", \\\"{x:805,y:456,t:1526933596042};\\\", \\\"{x:805,y:453,t:1526933596059};\\\", \\\"{x:805,y:452,t:1526933596075};\\\", \\\"{x:806,y:452,t:1526933596141};\\\", \\\"{x:809,y:453,t:1526933596149};\\\", \\\"{x:811,y:456,t:1526933596160};\\\", \\\"{x:816,y:465,t:1526933596177};\\\", \\\"{x:823,y:476,t:1526933596193};\\\", \\\"{x:828,y:485,t:1526933596209};\\\", \\\"{x:830,y:493,t:1526933596227};\\\", \\\"{x:833,y:498,t:1526933596243};\\\", \\\"{x:834,y:501,t:1526933596259};\\\", \\\"{x:834,y:504,t:1526933596278};\\\", \\\"{x:836,y:507,t:1526933596293};\\\", \\\"{x:836,y:509,t:1526933596310};\\\", \\\"{x:836,y:511,t:1526933596327};\\\", \\\"{x:836,y:515,t:1526933596344};\\\", \\\"{x:836,y:517,t:1526933596360};\\\", \\\"{x:836,y:519,t:1526933596376};\\\", \\\"{x:836,y:521,t:1526933596395};\\\", \\\"{x:836,y:526,t:1526933596411};\\\", \\\"{x:836,y:531,t:1526933596424};\\\", \\\"{x:836,y:535,t:1526933596442};\\\", \\\"{x:836,y:536,t:1526933596457};\\\", \\\"{x:838,y:543,t:1526933597038};\\\", \\\"{x:846,y:555,t:1526933597047};\\\", \\\"{x:854,y:568,t:1526933597060};\\\", \\\"{x:900,y:633,t:1526933597076};\\\", \\\"{x:932,y:671,t:1526933597093};\\\", \\\"{x:970,y:709,t:1526933597110};\\\", \\\"{x:1013,y:744,t:1526933597127};\\\", \\\"{x:1062,y:783,t:1526933597143};\\\", \\\"{x:1098,y:814,t:1526933597160};\\\", \\\"{x:1144,y:850,t:1526933597177};\\\", \\\"{x:1178,y:876,t:1526933597194};\\\", \\\"{x:1229,y:912,t:1526933597210};\\\", \\\"{x:1279,y:947,t:1526933597227};\\\", \\\"{x:1333,y:974,t:1526933597243};\\\", \\\"{x:1364,y:993,t:1526933597260};\\\", \\\"{x:1394,y:1015,t:1526933597277};\\\", \\\"{x:1414,y:1024,t:1526933597294};\\\", \\\"{x:1426,y:1028,t:1526933597310};\\\", \\\"{x:1427,y:1028,t:1526933597327};\\\", \\\"{x:1426,y:1028,t:1526933597469};\\\", \\\"{x:1425,y:1028,t:1526933597477};\\\", \\\"{x:1424,y:1028,t:1526933597493};\\\", \\\"{x:1422,y:1028,t:1526933597511};\\\", \\\"{x:1420,y:1028,t:1526933597534};\\\", \\\"{x:1419,y:1028,t:1526933597550};\\\", \\\"{x:1418,y:1027,t:1526933597561};\\\", \\\"{x:1417,y:1026,t:1526933597577};\\\", \\\"{x:1414,y:1026,t:1526933597594};\\\", \\\"{x:1411,y:1025,t:1526933597611};\\\", \\\"{x:1409,y:1024,t:1526933597627};\\\", \\\"{x:1407,y:1023,t:1526933597645};\\\", \\\"{x:1403,y:1021,t:1526933597661};\\\", \\\"{x:1399,y:1018,t:1526933597677};\\\", \\\"{x:1395,y:1016,t:1526933597694};\\\", \\\"{x:1390,y:1013,t:1526933597712};\\\", \\\"{x:1387,y:1010,t:1526933597727};\\\", \\\"{x:1385,y:1008,t:1526933597745};\\\", \\\"{x:1382,y:1006,t:1526933597762};\\\", \\\"{x:1381,y:1005,t:1526933597778};\\\", \\\"{x:1380,y:1004,t:1526933597795};\\\", \\\"{x:1380,y:1003,t:1526933597814};\\\", \\\"{x:1380,y:1002,t:1526933597894};\\\", \\\"{x:1379,y:1000,t:1526933597912};\\\", \\\"{x:1379,y:999,t:1526933597929};\\\", \\\"{x:1378,y:998,t:1526933597944};\\\", \\\"{x:1378,y:996,t:1526933597961};\\\", \\\"{x:1378,y:994,t:1526933597978};\\\", \\\"{x:1377,y:993,t:1526933597994};\\\", \\\"{x:1376,y:991,t:1526933598011};\\\", \\\"{x:1376,y:989,t:1526933598028};\\\", \\\"{x:1376,y:988,t:1526933598045};\\\", \\\"{x:1376,y:987,t:1526933598078};\\\", \\\"{x:1376,y:986,t:1526933598101};\\\", \\\"{x:1376,y:985,t:1526933598126};\\\", \\\"{x:1376,y:984,t:1526933598166};\\\", \\\"{x:1376,y:983,t:1526933598182};\\\", \\\"{x:1376,y:982,t:1526933602870};\\\", \\\"{x:1375,y:982,t:1526933602990};\\\", \\\"{x:1375,y:980,t:1526933603006};\\\", \\\"{x:1375,y:979,t:1526933603016};\\\", \\\"{x:1376,y:975,t:1526933603032};\\\", \\\"{x:1378,y:972,t:1526933603050};\\\", \\\"{x:1380,y:969,t:1526933603065};\\\", \\\"{x:1381,y:967,t:1526933603083};\\\", \\\"{x:1381,y:966,t:1526933603099};\\\", \\\"{x:1383,y:966,t:1526933603198};\\\", \\\"{x:1384,y:966,t:1526933603207};\\\", \\\"{x:1386,y:966,t:1526933603221};\\\", \\\"{x:1388,y:966,t:1526933603269};\\\", \\\"{x:1389,y:967,t:1526933603282};\\\", \\\"{x:1390,y:968,t:1526933603300};\\\", \\\"{x:1391,y:970,t:1526933603317};\\\", \\\"{x:1392,y:974,t:1526933603332};\\\", \\\"{x:1393,y:975,t:1526933603350};\\\", \\\"{x:1394,y:976,t:1526933603373};\\\", \\\"{x:1393,y:976,t:1526933603909};\\\", \\\"{x:1391,y:976,t:1526933603933};\\\", \\\"{x:1390,y:976,t:1526933603950};\\\", \\\"{x:1389,y:976,t:1526933603998};\\\", \\\"{x:1388,y:975,t:1526933604021};\\\", \\\"{x:1387,y:975,t:1526933604034};\\\", \\\"{x:1384,y:974,t:1526933604050};\\\", \\\"{x:1383,y:970,t:1526933604066};\\\", \\\"{x:1376,y:964,t:1526933604084};\\\", \\\"{x:1374,y:962,t:1526933604101};\\\", \\\"{x:1373,y:962,t:1526933604116};\\\", \\\"{x:1379,y:958,t:1526933604957};\\\", \\\"{x:1382,y:958,t:1526933604968};\\\", \\\"{x:1386,y:955,t:1526933604985};\\\", \\\"{x:1387,y:955,t:1526933605013};\\\", \\\"{x:1388,y:955,t:1526933605190};\\\", \\\"{x:1391,y:955,t:1526933605202};\\\", \\\"{x:1394,y:956,t:1526933605222};\\\", \\\"{x:1398,y:956,t:1526933605239};\\\", \\\"{x:1400,y:958,t:1526933605255};\\\", \\\"{x:1404,y:958,t:1526933605272};\\\", \\\"{x:1407,y:960,t:1526933605289};\\\", \\\"{x:1409,y:961,t:1526933605306};\\\", \\\"{x:1404,y:961,t:1526933605362};\\\", \\\"{x:1397,y:959,t:1526933605372};\\\", \\\"{x:1343,y:940,t:1526933605389};\\\", \\\"{x:1243,y:910,t:1526933605406};\\\", \\\"{x:1104,y:867,t:1526933605423};\\\", \\\"{x:961,y:828,t:1526933605439};\\\", \\\"{x:814,y:786,t:1526933605456};\\\", \\\"{x:694,y:763,t:1526933605473};\\\", \\\"{x:600,y:748,t:1526933605489};\\\", \\\"{x:531,y:737,t:1526933605507};\\\", \\\"{x:510,y:734,t:1526933605522};\\\", \\\"{x:506,y:733,t:1526933605538};\\\", \\\"{x:503,y:732,t:1526933605554};\\\", \\\"{x:500,y:732,t:1526933605632};\\\", \\\"{x:500,y:731,t:1526933605649};\\\", \\\"{x:499,y:730,t:1526933605665};\\\", \\\"{x:498,y:730,t:1526933606216};\\\", \\\"{x:508,y:742,t:1526933606225};\\\", \\\"{x:524,y:761,t:1526933606238};\\\", \\\"{x:579,y:819,t:1526933606255};\\\", \\\"{x:635,y:871,t:1526933606271};\\\", \\\"{x:700,y:934,t:1526933606288};\\\", \\\"{x:804,y:1029,t:1526933606304};\\\", \\\"{x:868,y:1073,t:1526933606321};\\\", \\\"{x:910,y:1102,t:1526933606338};\\\", \\\"{x:928,y:1114,t:1526933606355};\\\", \\\"{x:932,y:1119,t:1526933606371};\\\", \\\"{x:933,y:1119,t:1526933606762};\\\", \\\"{x:936,y:1119,t:1526933606772};\\\", \\\"{x:943,y:1116,t:1526933606788};\\\", \\\"{x:950,y:1111,t:1526933606806};\\\", \\\"{x:960,y:1104,t:1526933606823};\\\", \\\"{x:966,y:1098,t:1526933606838};\\\", \\\"{x:975,y:1089,t:1526933606855};\\\", \\\"{x:981,y:1084,t:1526933606872};\\\", \\\"{x:983,y:1084,t:1526933606888};\\\", \\\"{x:987,y:1081,t:1526933606906};\\\", \\\"{x:994,y:1076,t:1526933606935};\\\", \\\"{x:996,y:1073,t:1526933606938};\\\", \\\"{x:1003,y:1066,t:1526933606962};\\\", \\\"{x:1006,y:1062,t:1526933606972};\\\", \\\"{x:1012,y:1053,t:1526933606988};\\\", \\\"{x:1018,y:1047,t:1526933607005};\\\", \\\"{x:1020,y:1042,t:1526933607023};\\\", \\\"{x:1023,y:1038,t:1526933607038};\\\", \\\"{x:1025,y:1034,t:1526933607055};\\\", \\\"{x:1027,y:1030,t:1526933607073};\\\", \\\"{x:1028,y:1026,t:1526933607088};\\\", \\\"{x:1029,y:1023,t:1526933607105};\\\", \\\"{x:1030,y:1023,t:1526933607122};\\\" ] }, { \\\"rt\\\": 9315, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 371860, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1024,y:1022,t:1526933608114};\\\", \\\"{x:1013,y:1020,t:1526933608124};\\\", \\\"{x:997,y:1013,t:1526933608140};\\\", \\\"{x:981,y:1005,t:1526933608157};\\\", \\\"{x:981,y:1003,t:1526933608174};\\\", \\\"{x:980,y:1001,t:1526933608190};\\\", \\\"{x:978,y:1001,t:1526933608850};\\\", \\\"{x:976,y:1000,t:1526933608865};\\\", \\\"{x:974,y:999,t:1526933608874};\\\", \\\"{x:967,y:997,t:1526933608891};\\\", \\\"{x:963,y:995,t:1526933608907};\\\", \\\"{x:959,y:994,t:1526933608924};\\\", \\\"{x:954,y:992,t:1526933608941};\\\", \\\"{x:948,y:990,t:1526933608957};\\\", \\\"{x:941,y:987,t:1526933608974};\\\", \\\"{x:936,y:986,t:1526933608991};\\\", \\\"{x:932,y:984,t:1526933609008};\\\", \\\"{x:928,y:983,t:1526933609024};\\\", \\\"{x:926,y:982,t:1526933609041};\\\", \\\"{x:922,y:981,t:1526933609058};\\\", \\\"{x:919,y:980,t:1526933609074};\\\", \\\"{x:918,y:980,t:1526933609121};\\\", \\\"{x:917,y:980,t:1526933609129};\\\", \\\"{x:916,y:980,t:1526933609762};\\\", \\\"{x:918,y:983,t:1526933609775};\\\", \\\"{x:924,y:991,t:1526933609791};\\\", \\\"{x:930,y:998,t:1526933609808};\\\", \\\"{x:935,y:1001,t:1526933609825};\\\", \\\"{x:941,y:1004,t:1526933609841};\\\", \\\"{x:946,y:1005,t:1526933609858};\\\", \\\"{x:952,y:1005,t:1526933609875};\\\", \\\"{x:957,y:1005,t:1526933609891};\\\", \\\"{x:964,y:1005,t:1526933609908};\\\", \\\"{x:971,y:1004,t:1526933609925};\\\", \\\"{x:990,y:997,t:1526933609942};\\\", \\\"{x:1009,y:989,t:1526933609958};\\\", \\\"{x:1026,y:978,t:1526933609975};\\\", \\\"{x:1060,y:955,t:1526933609992};\\\", \\\"{x:1124,y:926,t:1526933610008};\\\", \\\"{x:1213,y:866,t:1526933610025};\\\", \\\"{x:1284,y:795,t:1526933610042};\\\", \\\"{x:1317,y:745,t:1526933610058};\\\", \\\"{x:1342,y:692,t:1526933610075};\\\", \\\"{x:1354,y:652,t:1526933610092};\\\", \\\"{x:1361,y:630,t:1526933610108};\\\", \\\"{x:1363,y:613,t:1526933610126};\\\", \\\"{x:1364,y:596,t:1526933610142};\\\", \\\"{x:1364,y:581,t:1526933610157};\\\", \\\"{x:1364,y:566,t:1526933610174};\\\", \\\"{x:1364,y:556,t:1526933610191};\\\", \\\"{x:1364,y:549,t:1526933610208};\\\", \\\"{x:1364,y:538,t:1526933610225};\\\", \\\"{x:1364,y:531,t:1526933610241};\\\", \\\"{x:1364,y:528,t:1526933610258};\\\", \\\"{x:1363,y:525,t:1526933610275};\\\", \\\"{x:1361,y:524,t:1526933610291};\\\", \\\"{x:1361,y:523,t:1526933610321};\\\", \\\"{x:1360,y:523,t:1526933610329};\\\", \\\"{x:1359,y:523,t:1526933610342};\\\", \\\"{x:1356,y:525,t:1526933610359};\\\", \\\"{x:1352,y:528,t:1526933610374};\\\", \\\"{x:1347,y:532,t:1526933610392};\\\", \\\"{x:1341,y:536,t:1526933610409};\\\", \\\"{x:1334,y:541,t:1526933610425};\\\", \\\"{x:1324,y:547,t:1526933610441};\\\", \\\"{x:1317,y:548,t:1526933610459};\\\", \\\"{x:1313,y:550,t:1526933610475};\\\", \\\"{x:1307,y:551,t:1526933610492};\\\", \\\"{x:1298,y:552,t:1526933610508};\\\", \\\"{x:1291,y:556,t:1526933610525};\\\", \\\"{x:1283,y:559,t:1526933610544};\\\", \\\"{x:1275,y:561,t:1526933610559};\\\", \\\"{x:1271,y:563,t:1526933610575};\\\", \\\"{x:1268,y:565,t:1526933610591};\\\", \\\"{x:1267,y:566,t:1526933610657};\\\", \\\"{x:1266,y:567,t:1526933610665};\\\", \\\"{x:1264,y:569,t:1526933610674};\\\", \\\"{x:1264,y:570,t:1526933610691};\\\", \\\"{x:1263,y:573,t:1526933610709};\\\", \\\"{x:1265,y:573,t:1526933611106};\\\", \\\"{x:1268,y:573,t:1526933611113};\\\", \\\"{x:1270,y:572,t:1526933611126};\\\", \\\"{x:1276,y:571,t:1526933611142};\\\", \\\"{x:1282,y:570,t:1526933611159};\\\", \\\"{x:1283,y:570,t:1526933611176};\\\", \\\"{x:1285,y:570,t:1526933611192};\\\", \\\"{x:1286,y:569,t:1526933611218};\\\", \\\"{x:1287,y:569,t:1526933611234};\\\", \\\"{x:1288,y:569,t:1526933611242};\\\", \\\"{x:1290,y:569,t:1526933611258};\\\", \\\"{x:1294,y:569,t:1526933611276};\\\", \\\"{x:1299,y:568,t:1526933611292};\\\", \\\"{x:1303,y:568,t:1526933611309};\\\", \\\"{x:1308,y:568,t:1526933611326};\\\", \\\"{x:1311,y:568,t:1526933611342};\\\", \\\"{x:1315,y:566,t:1526933611359};\\\", \\\"{x:1318,y:566,t:1526933611377};\\\", \\\"{x:1319,y:565,t:1526933611393};\\\", \\\"{x:1321,y:565,t:1526933611409};\\\", \\\"{x:1329,y:564,t:1526933611426};\\\", \\\"{x:1335,y:562,t:1526933611443};\\\", \\\"{x:1339,y:561,t:1526933611459};\\\", \\\"{x:1341,y:561,t:1526933611476};\\\", \\\"{x:1343,y:561,t:1526933611493};\\\", \\\"{x:1346,y:561,t:1526933611509};\\\", \\\"{x:1349,y:560,t:1526933611526};\\\", \\\"{x:1354,y:560,t:1526933611544};\\\", \\\"{x:1359,y:559,t:1526933611558};\\\", \\\"{x:1364,y:558,t:1526933611575};\\\", \\\"{x:1369,y:558,t:1526933611592};\\\", \\\"{x:1371,y:558,t:1526933611608};\\\", \\\"{x:1375,y:558,t:1526933611625};\\\", \\\"{x:1379,y:558,t:1526933611642};\\\", \\\"{x:1385,y:558,t:1526933611659};\\\", \\\"{x:1390,y:558,t:1526933611675};\\\", \\\"{x:1397,y:558,t:1526933611692};\\\", \\\"{x:1404,y:558,t:1526933611708};\\\", \\\"{x:1409,y:558,t:1526933611725};\\\", \\\"{x:1413,y:558,t:1526933611743};\\\", \\\"{x:1414,y:558,t:1526933611759};\\\", \\\"{x:1413,y:558,t:1526933613737};\\\", \\\"{x:1403,y:558,t:1526933613745};\\\", \\\"{x:1376,y:557,t:1526933613761};\\\", \\\"{x:1346,y:557,t:1526933613777};\\\", \\\"{x:1308,y:557,t:1526933613794};\\\", \\\"{x:1280,y:557,t:1526933613811};\\\", \\\"{x:1259,y:557,t:1526933613827};\\\", \\\"{x:1245,y:557,t:1526933613844};\\\", \\\"{x:1229,y:557,t:1526933613861};\\\", \\\"{x:1211,y:557,t:1526933613878};\\\", \\\"{x:1192,y:557,t:1526933613894};\\\", \\\"{x:1174,y:557,t:1526933613911};\\\", \\\"{x:1152,y:557,t:1526933613927};\\\", \\\"{x:1132,y:557,t:1526933613944};\\\", \\\"{x:1102,y:557,t:1526933613961};\\\", \\\"{x:1084,y:557,t:1526933613978};\\\", \\\"{x:1062,y:557,t:1526933613993};\\\", \\\"{x:1041,y:560,t:1526933614012};\\\", \\\"{x:1012,y:565,t:1526933614028};\\\", \\\"{x:983,y:567,t:1526933614044};\\\", \\\"{x:953,y:567,t:1526933614061};\\\", \\\"{x:923,y:567,t:1526933614078};\\\", \\\"{x:893,y:567,t:1526933614095};\\\", \\\"{x:854,y:567,t:1526933614110};\\\", \\\"{x:819,y:570,t:1526933614128};\\\", \\\"{x:759,y:571,t:1526933614144};\\\", \\\"{x:740,y:571,t:1526933614160};\\\", \\\"{x:720,y:571,t:1526933614178};\\\", \\\"{x:709,y:571,t:1526933614194};\\\", \\\"{x:706,y:571,t:1526933614210};\\\", \\\"{x:704,y:571,t:1526933614228};\\\", \\\"{x:701,y:571,t:1526933614273};\\\", \\\"{x:699,y:571,t:1526933614281};\\\", \\\"{x:693,y:571,t:1526933614294};\\\", \\\"{x:683,y:570,t:1526933614311};\\\", \\\"{x:670,y:567,t:1526933614328};\\\", \\\"{x:657,y:562,t:1526933614345};\\\", \\\"{x:646,y:553,t:1526933614362};\\\", \\\"{x:639,y:547,t:1526933614378};\\\", \\\"{x:629,y:540,t:1526933614395};\\\", \\\"{x:622,y:532,t:1526933614412};\\\", \\\"{x:608,y:519,t:1526933614429};\\\", \\\"{x:596,y:508,t:1526933614445};\\\", \\\"{x:591,y:501,t:1526933614462};\\\", \\\"{x:589,y:497,t:1526933614478};\\\", \\\"{x:589,y:495,t:1526933614494};\\\", \\\"{x:587,y:494,t:1526933614512};\\\", \\\"{x:586,y:491,t:1526933614529};\\\", \\\"{x:585,y:489,t:1526933614544};\\\", \\\"{x:585,y:487,t:1526933614561};\\\", \\\"{x:585,y:486,t:1526933614580};\\\", \\\"{x:586,y:486,t:1526933614680};\\\", \\\"{x:587,y:486,t:1526933614695};\\\", \\\"{x:589,y:486,t:1526933614711};\\\", \\\"{x:591,y:486,t:1526933614728};\\\", \\\"{x:597,y:491,t:1526933614745};\\\", \\\"{x:600,y:492,t:1526933614760};\\\", \\\"{x:601,y:493,t:1526933614811};\\\", \\\"{x:602,y:494,t:1526933614833};\\\", \\\"{x:603,y:494,t:1526933614846};\\\", \\\"{x:606,y:498,t:1526933614862};\\\", \\\"{x:608,y:499,t:1526933614879};\\\", \\\"{x:609,y:500,t:1526933614896};\\\", \\\"{x:615,y:504,t:1526933615192};\\\", \\\"{x:626,y:509,t:1526933615201};\\\", \\\"{x:636,y:512,t:1526933615211};\\\", \\\"{x:659,y:522,t:1526933615230};\\\", \\\"{x:701,y:533,t:1526933615246};\\\", \\\"{x:760,y:545,t:1526933615263};\\\", \\\"{x:819,y:553,t:1526933615278};\\\", \\\"{x:872,y:561,t:1526933615297};\\\", \\\"{x:933,y:568,t:1526933615313};\\\", \\\"{x:954,y:568,t:1526933615330};\\\", \\\"{x:968,y:568,t:1526933615346};\\\", \\\"{x:972,y:568,t:1526933615362};\\\", \\\"{x:972,y:567,t:1526933615450};\\\", \\\"{x:969,y:565,t:1526933615465};\\\", \\\"{x:968,y:564,t:1526933615479};\\\", \\\"{x:965,y:562,t:1526933615496};\\\", \\\"{x:959,y:558,t:1526933615512};\\\", \\\"{x:943,y:554,t:1526933615530};\\\", \\\"{x:929,y:550,t:1526933615546};\\\", \\\"{x:916,y:548,t:1526933615561};\\\", \\\"{x:905,y:546,t:1526933615579};\\\", \\\"{x:895,y:545,t:1526933615596};\\\", \\\"{x:887,y:544,t:1526933615611};\\\", \\\"{x:885,y:543,t:1526933615629};\\\", \\\"{x:884,y:543,t:1526933615648};\\\", \\\"{x:883,y:543,t:1526933615662};\\\", \\\"{x:880,y:543,t:1526933615679};\\\", \\\"{x:876,y:543,t:1526933615695};\\\", \\\"{x:871,y:543,t:1526933615711};\\\", \\\"{x:865,y:542,t:1526933615729};\\\", \\\"{x:854,y:538,t:1526933615762};\\\", \\\"{x:851,y:537,t:1526933615778};\\\", \\\"{x:850,y:537,t:1526933615795};\\\", \\\"{x:848,y:537,t:1526933615812};\\\", \\\"{x:845,y:535,t:1526933615828};\\\", \\\"{x:843,y:535,t:1526933615846};\\\", \\\"{x:842,y:534,t:1526933615921};\\\", \\\"{x:837,y:540,t:1526933616144};\\\", \\\"{x:827,y:553,t:1526933616153};\\\", \\\"{x:816,y:566,t:1526933616163};\\\", \\\"{x:794,y:581,t:1526933616179};\\\", \\\"{x:762,y:595,t:1526933616197};\\\", \\\"{x:728,y:610,t:1526933616213};\\\", \\\"{x:708,y:619,t:1526933616230};\\\", \\\"{x:696,y:625,t:1526933616246};\\\", \\\"{x:685,y:631,t:1526933616263};\\\", \\\"{x:682,y:634,t:1526933616281};\\\", \\\"{x:676,y:641,t:1526933616297};\\\", \\\"{x:663,y:650,t:1526933616313};\\\", \\\"{x:644,y:661,t:1526933616330};\\\", \\\"{x:624,y:671,t:1526933616347};\\\", \\\"{x:598,y:686,t:1526933616364};\\\", \\\"{x:583,y:694,t:1526933616384};\\\", \\\"{x:580,y:697,t:1526933616397};\\\", \\\"{x:574,y:702,t:1526933616413};\\\", \\\"{x:570,y:707,t:1526933616430};\\\", \\\"{x:563,y:714,t:1526933616446};\\\", \\\"{x:557,y:721,t:1526933616464};\\\", \\\"{x:547,y:731,t:1526933616480};\\\", \\\"{x:542,y:736,t:1526933616496};\\\", \\\"{x:538,y:741,t:1526933616513};\\\", \\\"{x:536,y:743,t:1526933616529};\\\", \\\"{x:539,y:744,t:1526933617225};\\\", \\\"{x:552,y:745,t:1526933617233};\\\", \\\"{x:566,y:748,t:1526933617246};\\\", \\\"{x:607,y:755,t:1526933617264};\\\", \\\"{x:697,y:767,t:1526933617281};\\\", \\\"{x:764,y:775,t:1526933617298};\\\", \\\"{x:848,y:788,t:1526933617314};\\\", \\\"{x:923,y:801,t:1526933617331};\\\", \\\"{x:995,y:810,t:1526933617348};\\\", \\\"{x:1070,y:820,t:1526933617364};\\\", \\\"{x:1129,y:829,t:1526933617381};\\\", \\\"{x:1167,y:831,t:1526933617398};\\\", \\\"{x:1197,y:831,t:1526933617414};\\\", \\\"{x:1221,y:831,t:1526933617431};\\\", \\\"{x:1238,y:831,t:1526933617448};\\\", \\\"{x:1243,y:831,t:1526933617463};\\\", \\\"{x:1246,y:831,t:1526933617481};\\\" ] }, { \\\"rt\\\": 26580, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 399705, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -B -J -Z -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1246,y:832,t:1526933623034};\\\", \\\"{x:1247,y:833,t:1526933623051};\\\", \\\"{x:1249,y:833,t:1526933623070};\\\", \\\"{x:1250,y:833,t:1526933623096};\\\", \\\"{x:1251,y:834,t:1526933623105};\\\", \\\"{x:1252,y:834,t:1526933623120};\\\", \\\"{x:1252,y:835,t:1526933623135};\\\", \\\"{x:1253,y:835,t:1526933623152};\\\", \\\"{x:1255,y:835,t:1526933623176};\\\", \\\"{x:1256,y:838,t:1526933623185};\\\", \\\"{x:1260,y:841,t:1526933623202};\\\", \\\"{x:1265,y:846,t:1526933623218};\\\", \\\"{x:1269,y:848,t:1526933623235};\\\", \\\"{x:1275,y:852,t:1526933623252};\\\", \\\"{x:1282,y:856,t:1526933623269};\\\", \\\"{x:1289,y:860,t:1526933623285};\\\", \\\"{x:1294,y:864,t:1526933623302};\\\", \\\"{x:1298,y:867,t:1526933623318};\\\", \\\"{x:1303,y:871,t:1526933623335};\\\", \\\"{x:1308,y:873,t:1526933623352};\\\", \\\"{x:1311,y:875,t:1526933623369};\\\", \\\"{x:1325,y:881,t:1526933623385};\\\", \\\"{x:1334,y:883,t:1526933623402};\\\", \\\"{x:1343,y:885,t:1526933623418};\\\", \\\"{x:1349,y:888,t:1526933623435};\\\", \\\"{x:1355,y:889,t:1526933623452};\\\", \\\"{x:1359,y:890,t:1526933623469};\\\", \\\"{x:1363,y:892,t:1526933623485};\\\", \\\"{x:1368,y:894,t:1526933623502};\\\", \\\"{x:1375,y:896,t:1526933623519};\\\", \\\"{x:1379,y:896,t:1526933623536};\\\", \\\"{x:1384,y:897,t:1526933623552};\\\", \\\"{x:1389,y:897,t:1526933623569};\\\", \\\"{x:1394,y:897,t:1526933623585};\\\", \\\"{x:1397,y:897,t:1526933623602};\\\", \\\"{x:1400,y:897,t:1526933623619};\\\", \\\"{x:1401,y:897,t:1526933623635};\\\", \\\"{x:1402,y:897,t:1526933623657};\\\", \\\"{x:1403,y:897,t:1526933623754};\\\", \\\"{x:1402,y:896,t:1526933623978};\\\", \\\"{x:1401,y:896,t:1526933624010};\\\", \\\"{x:1400,y:896,t:1526933624026};\\\", \\\"{x:1398,y:896,t:1526933624049};\\\", \\\"{x:1397,y:895,t:1526933624074};\\\", \\\"{x:1395,y:895,t:1526933624089};\\\", \\\"{x:1394,y:893,t:1526933624102};\\\", \\\"{x:1391,y:893,t:1526933624119};\\\", \\\"{x:1389,y:893,t:1526933624135};\\\", \\\"{x:1387,y:893,t:1526933624152};\\\", \\\"{x:1385,y:893,t:1526933624169};\\\", \\\"{x:1384,y:893,t:1526933624186};\\\", \\\"{x:1382,y:893,t:1526933624209};\\\", \\\"{x:1380,y:893,t:1526933624219};\\\", \\\"{x:1379,y:893,t:1526933624241};\\\", \\\"{x:1378,y:893,t:1526933624257};\\\", \\\"{x:1377,y:893,t:1526933624297};\\\", \\\"{x:1378,y:894,t:1526933628297};\\\", \\\"{x:1377,y:894,t:1526933628498};\\\", \\\"{x:1373,y:894,t:1526933628507};\\\", \\\"{x:1366,y:894,t:1526933628523};\\\", \\\"{x:1357,y:894,t:1526933628539};\\\", \\\"{x:1351,y:894,t:1526933628556};\\\", \\\"{x:1343,y:894,t:1526933628573};\\\", \\\"{x:1337,y:894,t:1526933628590};\\\", \\\"{x:1328,y:894,t:1526933628606};\\\", \\\"{x:1321,y:894,t:1526933628623};\\\", \\\"{x:1315,y:894,t:1526933628640};\\\", \\\"{x:1308,y:894,t:1526933628656};\\\", \\\"{x:1298,y:894,t:1526933628674};\\\", \\\"{x:1293,y:894,t:1526933628689};\\\", \\\"{x:1285,y:894,t:1526933628706};\\\", \\\"{x:1277,y:894,t:1526933628723};\\\", \\\"{x:1273,y:894,t:1526933628740};\\\", \\\"{x:1270,y:894,t:1526933628756};\\\", \\\"{x:1266,y:894,t:1526933628773};\\\", \\\"{x:1263,y:894,t:1526933628790};\\\", \\\"{x:1257,y:894,t:1526933628806};\\\", \\\"{x:1253,y:894,t:1526933628823};\\\", \\\"{x:1249,y:894,t:1526933628840};\\\", \\\"{x:1247,y:894,t:1526933628856};\\\", \\\"{x:1244,y:894,t:1526933628874};\\\", \\\"{x:1243,y:894,t:1526933628889};\\\", \\\"{x:1244,y:894,t:1526933629057};\\\", \\\"{x:1251,y:893,t:1526933629074};\\\", \\\"{x:1264,y:892,t:1526933629090};\\\", \\\"{x:1276,y:890,t:1526933629107};\\\", \\\"{x:1286,y:888,t:1526933629122};\\\", \\\"{x:1296,y:888,t:1526933629139};\\\", \\\"{x:1304,y:887,t:1526933629156};\\\", \\\"{x:1313,y:884,t:1526933629172};\\\", \\\"{x:1321,y:883,t:1526933629190};\\\", \\\"{x:1328,y:882,t:1526933629206};\\\", \\\"{x:1332,y:882,t:1526933629222};\\\", \\\"{x:1337,y:881,t:1526933629239};\\\", \\\"{x:1341,y:880,t:1526933629256};\\\", \\\"{x:1344,y:879,t:1526933629273};\\\", \\\"{x:1345,y:878,t:1526933629290};\\\", \\\"{x:1349,y:875,t:1526933629306};\\\", \\\"{x:1353,y:870,t:1526933629323};\\\", \\\"{x:1357,y:858,t:1526933629340};\\\", \\\"{x:1361,y:841,t:1526933629356};\\\", \\\"{x:1366,y:824,t:1526933629373};\\\", \\\"{x:1366,y:805,t:1526933629390};\\\", \\\"{x:1366,y:790,t:1526933629406};\\\", \\\"{x:1366,y:782,t:1526933629423};\\\", \\\"{x:1366,y:777,t:1526933629440};\\\", \\\"{x:1366,y:772,t:1526933629457};\\\", \\\"{x:1366,y:768,t:1526933629474};\\\", \\\"{x:1364,y:763,t:1526933629490};\\\", \\\"{x:1363,y:758,t:1526933629507};\\\", \\\"{x:1363,y:756,t:1526933629524};\\\", \\\"{x:1362,y:754,t:1526933629539};\\\", \\\"{x:1361,y:753,t:1526933629557};\\\", \\\"{x:1360,y:753,t:1526933629609};\\\", \\\"{x:1359,y:753,t:1526933629625};\\\", \\\"{x:1358,y:752,t:1526933629640};\\\", \\\"{x:1357,y:752,t:1526933629657};\\\", \\\"{x:1354,y:752,t:1526933629674};\\\", \\\"{x:1351,y:752,t:1526933629689};\\\", \\\"{x:1349,y:752,t:1526933629707};\\\", \\\"{x:1348,y:752,t:1526933629724};\\\", \\\"{x:1346,y:752,t:1526933629739};\\\", \\\"{x:1346,y:753,t:1526933629761};\\\", \\\"{x:1345,y:753,t:1526933629777};\\\", \\\"{x:1345,y:754,t:1526933629790};\\\", \\\"{x:1344,y:755,t:1526933629807};\\\", \\\"{x:1342,y:757,t:1526933629825};\\\", \\\"{x:1342,y:758,t:1526933629841};\\\", \\\"{x:1341,y:758,t:1526933630266};\\\", \\\"{x:1341,y:757,t:1526933630281};\\\", \\\"{x:1341,y:756,t:1526933630291};\\\", \\\"{x:1339,y:754,t:1526933630308};\\\", \\\"{x:1339,y:752,t:1526933630324};\\\", \\\"{x:1339,y:750,t:1526933630341};\\\", \\\"{x:1339,y:746,t:1526933630358};\\\", \\\"{x:1339,y:742,t:1526933630374};\\\", \\\"{x:1339,y:738,t:1526933630390};\\\", \\\"{x:1339,y:731,t:1526933630407};\\\", \\\"{x:1339,y:728,t:1526933630424};\\\", \\\"{x:1339,y:721,t:1526933630441};\\\", \\\"{x:1339,y:715,t:1526933630457};\\\", \\\"{x:1339,y:711,t:1526933630474};\\\", \\\"{x:1339,y:708,t:1526933630491};\\\", \\\"{x:1340,y:703,t:1526933630507};\\\", \\\"{x:1340,y:701,t:1526933630524};\\\", \\\"{x:1340,y:699,t:1526933630541};\\\", \\\"{x:1340,y:698,t:1526933630558};\\\", \\\"{x:1340,y:697,t:1526933630574};\\\", \\\"{x:1340,y:696,t:1526933630609};\\\", \\\"{x:1338,y:696,t:1526933631921};\\\", \\\"{x:1327,y:697,t:1526933631928};\\\", \\\"{x:1310,y:700,t:1526933631942};\\\", \\\"{x:1236,y:703,t:1526933631959};\\\", \\\"{x:1134,y:713,t:1526933631974};\\\", \\\"{x:1123,y:716,t:1526933631991};\\\", \\\"{x:1101,y:714,t:1526933632008};\\\", \\\"{x:1092,y:714,t:1526933632025};\\\", \\\"{x:1091,y:713,t:1526933632041};\\\", \\\"{x:1090,y:711,t:1526933632386};\\\", \\\"{x:1089,y:711,t:1526933632394};\\\", \\\"{x:1081,y:708,t:1526933632409};\\\", \\\"{x:1079,y:707,t:1526933632425};\\\", \\\"{x:1068,y:703,t:1526933632442};\\\", \\\"{x:1040,y:697,t:1526933632459};\\\", \\\"{x:1019,y:688,t:1526933632475};\\\", \\\"{x:992,y:678,t:1526933632492};\\\", \\\"{x:960,y:668,t:1526933632509};\\\", \\\"{x:938,y:659,t:1526933632526};\\\", \\\"{x:912,y:649,t:1526933632542};\\\", \\\"{x:888,y:639,t:1526933632559};\\\", \\\"{x:868,y:626,t:1526933632578};\\\", \\\"{x:841,y:606,t:1526933632593};\\\", \\\"{x:806,y:580,t:1526933632627};\\\", \\\"{x:785,y:566,t:1526933632642};\\\", \\\"{x:752,y:552,t:1526933632660};\\\", \\\"{x:705,y:536,t:1526933632677};\\\", \\\"{x:658,y:532,t:1526933632692};\\\", \\\"{x:615,y:530,t:1526933632710};\\\", \\\"{x:588,y:529,t:1526933632726};\\\", \\\"{x:570,y:529,t:1526933632742};\\\", \\\"{x:566,y:527,t:1526933632759};\\\", \\\"{x:565,y:527,t:1526933632800};\\\", \\\"{x:564,y:527,t:1526933632810};\\\", \\\"{x:564,y:528,t:1526933632826};\\\", \\\"{x:563,y:531,t:1526933632842};\\\", \\\"{x:563,y:534,t:1526933632859};\\\", \\\"{x:562,y:535,t:1526933632888};\\\", \\\"{x:561,y:535,t:1526933632897};\\\", \\\"{x:561,y:536,t:1526933632913};\\\", \\\"{x:560,y:537,t:1526933632926};\\\", \\\"{x:557,y:538,t:1526933632943};\\\", \\\"{x:551,y:538,t:1526933632960};\\\", \\\"{x:542,y:538,t:1526933632976};\\\", \\\"{x:535,y:538,t:1526933632992};\\\", \\\"{x:527,y:538,t:1526933633010};\\\", \\\"{x:519,y:538,t:1526933633026};\\\", \\\"{x:507,y:538,t:1526933633042};\\\", \\\"{x:495,y:540,t:1526933633060};\\\", \\\"{x:473,y:540,t:1526933633076};\\\", \\\"{x:444,y:541,t:1526933633094};\\\", \\\"{x:420,y:543,t:1526933633111};\\\", \\\"{x:399,y:548,t:1526933633127};\\\", \\\"{x:383,y:550,t:1526933633144};\\\", \\\"{x:376,y:551,t:1526933633159};\\\", \\\"{x:368,y:555,t:1526933633178};\\\", \\\"{x:366,y:556,t:1526933633194};\\\", \\\"{x:359,y:559,t:1526933633211};\\\", \\\"{x:346,y:564,t:1526933633226};\\\", \\\"{x:325,y:570,t:1526933633243};\\\", \\\"{x:321,y:572,t:1526933633260};\\\", \\\"{x:308,y:579,t:1526933633277};\\\", \\\"{x:302,y:583,t:1526933633293};\\\", \\\"{x:302,y:584,t:1526933633310};\\\", \\\"{x:300,y:584,t:1526933633618};\\\", \\\"{x:297,y:585,t:1526933633628};\\\", \\\"{x:271,y:583,t:1526933633647};\\\", \\\"{x:234,y:580,t:1526933633660};\\\", \\\"{x:211,y:575,t:1526933633677};\\\", \\\"{x:190,y:572,t:1526933633693};\\\", \\\"{x:176,y:571,t:1526933633710};\\\", \\\"{x:166,y:568,t:1526933633726};\\\", \\\"{x:158,y:565,t:1526933633744};\\\", \\\"{x:147,y:560,t:1526933633760};\\\", \\\"{x:140,y:556,t:1526933633777};\\\", \\\"{x:133,y:552,t:1526933633794};\\\", \\\"{x:131,y:550,t:1526933633810};\\\", \\\"{x:131,y:549,t:1526933633828};\\\", \\\"{x:131,y:547,t:1526933633843};\\\", \\\"{x:131,y:546,t:1526933633864};\\\", \\\"{x:131,y:545,t:1526933633877};\\\", \\\"{x:131,y:544,t:1526933633894};\\\", \\\"{x:131,y:542,t:1526933633910};\\\", \\\"{x:132,y:540,t:1526933633927};\\\", \\\"{x:132,y:539,t:1526933633944};\\\", \\\"{x:134,y:537,t:1526933633960};\\\", \\\"{x:134,y:536,t:1526933634009};\\\", \\\"{x:135,y:536,t:1526933634033};\\\", \\\"{x:135,y:535,t:1526933634049};\\\", \\\"{x:136,y:534,t:1526933634065};\\\", \\\"{x:137,y:534,t:1526933634078};\\\", \\\"{x:139,y:534,t:1526933634094};\\\", \\\"{x:141,y:534,t:1526933634112};\\\", \\\"{x:144,y:534,t:1526933634127};\\\", \\\"{x:146,y:534,t:1526933634145};\\\", \\\"{x:147,y:534,t:1526933634193};\\\", \\\"{x:149,y:535,t:1526933634530};\\\", \\\"{x:160,y:536,t:1526933634545};\\\", \\\"{x:182,y:542,t:1526933634561};\\\", \\\"{x:212,y:547,t:1526933634578};\\\", \\\"{x:255,y:555,t:1526933634594};\\\", \\\"{x:311,y:563,t:1526933634612};\\\", \\\"{x:370,y:571,t:1526933634627};\\\", \\\"{x:425,y:578,t:1526933634644};\\\", \\\"{x:473,y:578,t:1526933634661};\\\", \\\"{x:503,y:578,t:1526933634678};\\\", \\\"{x:528,y:578,t:1526933634694};\\\", \\\"{x:548,y:578,t:1526933634711};\\\", \\\"{x:569,y:578,t:1526933634727};\\\", \\\"{x:601,y:578,t:1526933634745};\\\", \\\"{x:622,y:578,t:1526933634762};\\\", \\\"{x:639,y:578,t:1526933634777};\\\", \\\"{x:657,y:578,t:1526933634795};\\\", \\\"{x:672,y:578,t:1526933634811};\\\", \\\"{x:683,y:578,t:1526933634828};\\\", \\\"{x:693,y:578,t:1526933634844};\\\", \\\"{x:700,y:578,t:1526933634862};\\\", \\\"{x:705,y:578,t:1526933634877};\\\", \\\"{x:709,y:578,t:1526933634894};\\\", \\\"{x:712,y:578,t:1526933634912};\\\", \\\"{x:714,y:578,t:1526933634928};\\\", \\\"{x:716,y:578,t:1526933634945};\\\", \\\"{x:717,y:578,t:1526933634961};\\\", \\\"{x:718,y:578,t:1526933635017};\\\", \\\"{x:720,y:578,t:1526933635029};\\\", \\\"{x:722,y:578,t:1526933635045};\\\", \\\"{x:728,y:577,t:1526933635063};\\\", \\\"{x:737,y:574,t:1526933635078};\\\", \\\"{x:753,y:568,t:1526933635094};\\\", \\\"{x:776,y:561,t:1526933635112};\\\", \\\"{x:819,y:546,t:1526933635128};\\\", \\\"{x:843,y:535,t:1526933635144};\\\", \\\"{x:860,y:528,t:1526933635161};\\\", \\\"{x:866,y:525,t:1526933635179};\\\", \\\"{x:867,y:524,t:1526933635195};\\\", \\\"{x:867,y:523,t:1526933635256};\\\", \\\"{x:867,y:522,t:1526933635264};\\\", \\\"{x:867,y:521,t:1526933635280};\\\", \\\"{x:867,y:520,t:1526933635296};\\\", \\\"{x:867,y:519,t:1526933635311};\\\", \\\"{x:864,y:514,t:1526933635329};\\\", \\\"{x:858,y:513,t:1526933635346};\\\", \\\"{x:850,y:511,t:1526933635362};\\\", \\\"{x:847,y:509,t:1526933635378};\\\", \\\"{x:843,y:508,t:1526933635395};\\\", \\\"{x:842,y:508,t:1526933635411};\\\", \\\"{x:840,y:508,t:1526933635474};\\\", \\\"{x:836,y:508,t:1526933635481};\\\", \\\"{x:832,y:507,t:1526933635496};\\\", \\\"{x:823,y:505,t:1526933635512};\\\", \\\"{x:814,y:504,t:1526933635528};\\\", \\\"{x:810,y:503,t:1526933635544};\\\", \\\"{x:811,y:503,t:1526933636081};\\\", \\\"{x:813,y:503,t:1526933636112};\\\", \\\"{x:814,y:503,t:1526933636128};\\\", \\\"{x:815,y:503,t:1526933636145};\\\", \\\"{x:816,y:504,t:1526933636162};\\\", \\\"{x:815,y:504,t:1526933636353};\\\", \\\"{x:810,y:505,t:1526933636361};\\\", \\\"{x:806,y:505,t:1526933636378};\\\", \\\"{x:804,y:505,t:1526933636395};\\\", \\\"{x:798,y:505,t:1526933636411};\\\", \\\"{x:796,y:505,t:1526933636427};\\\", \\\"{x:795,y:505,t:1526933636445};\\\", \\\"{x:792,y:505,t:1526933636461};\\\", \\\"{x:791,y:505,t:1526933636481};\\\", \\\"{x:790,y:505,t:1526933636494};\\\", \\\"{x:789,y:505,t:1526933636521};\\\", \\\"{x:785,y:505,t:1526933636536};\\\", \\\"{x:781,y:506,t:1526933636545};\\\", \\\"{x:764,y:509,t:1526933636561};\\\", \\\"{x:745,y:511,t:1526933636578};\\\", \\\"{x:733,y:514,t:1526933636595};\\\", \\\"{x:735,y:514,t:1526933636657};\\\", \\\"{x:742,y:514,t:1526933636665};\\\", \\\"{x:752,y:514,t:1526933636677};\\\", \\\"{x:775,y:509,t:1526933636695};\\\", \\\"{x:802,y:506,t:1526933636711};\\\", \\\"{x:822,y:502,t:1526933636728};\\\", \\\"{x:833,y:501,t:1526933636746};\\\", \\\"{x:834,y:501,t:1526933636761};\\\", \\\"{x:836,y:501,t:1526933636833};\\\", \\\"{x:837,y:499,t:1526933636865};\\\", \\\"{x:835,y:499,t:1526933637265};\\\", \\\"{x:828,y:499,t:1526933637280};\\\", \\\"{x:765,y:507,t:1526933637298};\\\", \\\"{x:681,y:520,t:1526933637314};\\\", \\\"{x:568,y:536,t:1526933637330};\\\", \\\"{x:421,y:557,t:1526933637347};\\\", \\\"{x:277,y:572,t:1526933637364};\\\", \\\"{x:155,y:579,t:1526933637380};\\\", \\\"{x:50,y:586,t:1526933637397};\\\", \\\"{x:0,y:589,t:1526933637414};\\\", \\\"{x:0,y:590,t:1526933637430};\\\", \\\"{x:0,y:593,t:1526933637446};\\\", \\\"{x:0,y:592,t:1526933637537};\\\", \\\"{x:0,y:591,t:1526933637547};\\\", \\\"{x:0,y:590,t:1526933637657};\\\", \\\"{x:4,y:589,t:1526933637665};\\\", \\\"{x:17,y:587,t:1526933637681};\\\", \\\"{x:39,y:583,t:1526933637696};\\\", \\\"{x:76,y:580,t:1526933637715};\\\", \\\"{x:124,y:572,t:1526933637731};\\\", \\\"{x:163,y:566,t:1526933637747};\\\", \\\"{x:198,y:561,t:1526933637763};\\\", \\\"{x:225,y:559,t:1526933637781};\\\", \\\"{x:241,y:557,t:1526933637796};\\\", \\\"{x:245,y:556,t:1526933637814};\\\", \\\"{x:246,y:555,t:1526933637831};\\\", \\\"{x:244,y:555,t:1526933637873};\\\", \\\"{x:241,y:555,t:1526933637880};\\\", \\\"{x:236,y:555,t:1526933637897};\\\", \\\"{x:229,y:555,t:1526933637913};\\\", \\\"{x:223,y:555,t:1526933637930};\\\", \\\"{x:217,y:555,t:1526933637946};\\\", \\\"{x:214,y:555,t:1526933637963};\\\", \\\"{x:211,y:555,t:1526933637980};\\\", \\\"{x:208,y:555,t:1526933637997};\\\", \\\"{x:207,y:555,t:1526933638014};\\\", \\\"{x:202,y:553,t:1526933638030};\\\", \\\"{x:198,y:552,t:1526933638047};\\\", \\\"{x:190,y:549,t:1526933638064};\\\", \\\"{x:179,y:547,t:1526933638080};\\\", \\\"{x:174,y:544,t:1526933638097};\\\", \\\"{x:171,y:544,t:1526933638113};\\\", \\\"{x:168,y:541,t:1526933638131};\\\", \\\"{x:165,y:540,t:1526933638147};\\\", \\\"{x:155,y:537,t:1526933638163};\\\", \\\"{x:151,y:536,t:1526933638180};\\\", \\\"{x:149,y:536,t:1526933638197};\\\", \\\"{x:154,y:536,t:1526933638729};\\\", \\\"{x:178,y:539,t:1526933638738};\\\", \\\"{x:213,y:546,t:1526933638749};\\\", \\\"{x:307,y:569,t:1526933638765};\\\", \\\"{x:432,y:608,t:1526933638781};\\\", \\\"{x:569,y:644,t:1526933638798};\\\", \\\"{x:721,y:684,t:1526933638815};\\\", \\\"{x:875,y:717,t:1526933638830};\\\", \\\"{x:1019,y:760,t:1526933638848};\\\", \\\"{x:1215,y:813,t:1526933638864};\\\", \\\"{x:1323,y:848,t:1526933638881};\\\", \\\"{x:1412,y:875,t:1526933638898};\\\", \\\"{x:1481,y:895,t:1526933638915};\\\", \\\"{x:1510,y:905,t:1526933638931};\\\", \\\"{x:1530,y:910,t:1526933638948};\\\", \\\"{x:1536,y:913,t:1526933638965};\\\", \\\"{x:1538,y:914,t:1526933638981};\\\", \\\"{x:1538,y:915,t:1526933639562};\\\", \\\"{x:1538,y:917,t:1526933639569};\\\", \\\"{x:1537,y:919,t:1526933639581};\\\", \\\"{x:1535,y:926,t:1526933639597};\\\", \\\"{x:1532,y:933,t:1526933639614};\\\", \\\"{x:1530,y:939,t:1526933639632};\\\", \\\"{x:1526,y:944,t:1526933639647};\\\", \\\"{x:1524,y:946,t:1526933639664};\\\", \\\"{x:1523,y:947,t:1526933639681};\\\", \\\"{x:1523,y:948,t:1526933639697};\\\", \\\"{x:1522,y:949,t:1526933639714};\\\", \\\"{x:1522,y:950,t:1526933639731};\\\", \\\"{x:1522,y:951,t:1526933639747};\\\", \\\"{x:1522,y:952,t:1526933639764};\\\", \\\"{x:1522,y:953,t:1526933639780};\\\", \\\"{x:1522,y:954,t:1526933639797};\\\", \\\"{x:1522,y:955,t:1526933639814};\\\", \\\"{x:1522,y:956,t:1526933639833};\\\", \\\"{x:1522,y:957,t:1526933639849};\\\", \\\"{x:1522,y:958,t:1526933639865};\\\", \\\"{x:1523,y:960,t:1526933639880};\\\", \\\"{x:1523,y:961,t:1526933639897};\\\", \\\"{x:1523,y:962,t:1526933639915};\\\", \\\"{x:1524,y:962,t:1526933639931};\\\", \\\"{x:1522,y:958,t:1526933640713};\\\", \\\"{x:1494,y:919,t:1526933640730};\\\", \\\"{x:1461,y:869,t:1526933640747};\\\", \\\"{x:1430,y:829,t:1526933640763};\\\", \\\"{x:1412,y:794,t:1526933640779};\\\", \\\"{x:1399,y:762,t:1526933640796};\\\", \\\"{x:1392,y:734,t:1526933640813};\\\", \\\"{x:1388,y:715,t:1526933640829};\\\", \\\"{x:1385,y:701,t:1526933640846};\\\", \\\"{x:1381,y:691,t:1526933640863};\\\", \\\"{x:1380,y:688,t:1526933640879};\\\", \\\"{x:1378,y:681,t:1526933640896};\\\", \\\"{x:1373,y:672,t:1526933640913};\\\", \\\"{x:1371,y:669,t:1526933640928};\\\", \\\"{x:1369,y:667,t:1526933640946};\\\", \\\"{x:1367,y:665,t:1526933640964};\\\", \\\"{x:1365,y:662,t:1526933640979};\\\", \\\"{x:1362,y:659,t:1526933640996};\\\", \\\"{x:1359,y:657,t:1526933641014};\\\", \\\"{x:1353,y:653,t:1526933641029};\\\", \\\"{x:1346,y:649,t:1526933641046};\\\", \\\"{x:1340,y:648,t:1526933641063};\\\", \\\"{x:1335,y:647,t:1526933641079};\\\", \\\"{x:1333,y:646,t:1526933641097};\\\", \\\"{x:1337,y:646,t:1526933641258};\\\", \\\"{x:1341,y:646,t:1526933641265};\\\", \\\"{x:1351,y:647,t:1526933641279};\\\", \\\"{x:1371,y:651,t:1526933641296};\\\", \\\"{x:1390,y:652,t:1526933641312};\\\", \\\"{x:1420,y:652,t:1526933641329};\\\", \\\"{x:1437,y:652,t:1526933641346};\\\", \\\"{x:1453,y:652,t:1526933641363};\\\", \\\"{x:1464,y:652,t:1526933641379};\\\", \\\"{x:1470,y:652,t:1526933641397};\\\", \\\"{x:1476,y:652,t:1526933641412};\\\", \\\"{x:1480,y:652,t:1526933641429};\\\", \\\"{x:1482,y:652,t:1526933641446};\\\", \\\"{x:1486,y:652,t:1526933641462};\\\", \\\"{x:1489,y:652,t:1526933641479};\\\", \\\"{x:1494,y:652,t:1526933641495};\\\", \\\"{x:1501,y:653,t:1526933641512};\\\", \\\"{x:1510,y:656,t:1526933641528};\\\", \\\"{x:1512,y:656,t:1526933641545};\\\", \\\"{x:1513,y:656,t:1526933641562};\\\", \\\"{x:1514,y:657,t:1526933641579};\\\", \\\"{x:1518,y:659,t:1526933641595};\\\", \\\"{x:1521,y:659,t:1526933641613};\\\", \\\"{x:1524,y:659,t:1526933641629};\\\", \\\"{x:1528,y:660,t:1526933641645};\\\", \\\"{x:1535,y:661,t:1526933641662};\\\", \\\"{x:1540,y:662,t:1526933641679};\\\", \\\"{x:1547,y:664,t:1526933641695};\\\", \\\"{x:1555,y:665,t:1526933641713};\\\", \\\"{x:1567,y:667,t:1526933641729};\\\", \\\"{x:1573,y:667,t:1526933641745};\\\", \\\"{x:1581,y:668,t:1526933641762};\\\", \\\"{x:1590,y:671,t:1526933641779};\\\", \\\"{x:1596,y:671,t:1526933641796};\\\", \\\"{x:1598,y:672,t:1526933641812};\\\", \\\"{x:1600,y:672,t:1526933641828};\\\", \\\"{x:1605,y:675,t:1526933641845};\\\", \\\"{x:1609,y:677,t:1526933641862};\\\", \\\"{x:1614,y:678,t:1526933641878};\\\", \\\"{x:1618,y:680,t:1526933641896};\\\", \\\"{x:1620,y:680,t:1526933641912};\\\", \\\"{x:1623,y:680,t:1526933641928};\\\", \\\"{x:1625,y:682,t:1526933641945};\\\", \\\"{x:1626,y:683,t:1526933641962};\\\", \\\"{x:1626,y:685,t:1526933641978};\\\", \\\"{x:1626,y:686,t:1526933641995};\\\", \\\"{x:1626,y:688,t:1526933642013};\\\", \\\"{x:1626,y:689,t:1526933642028};\\\", \\\"{x:1626,y:691,t:1526933642045};\\\", \\\"{x:1626,y:694,t:1526933642062};\\\", \\\"{x:1626,y:696,t:1526933642078};\\\", \\\"{x:1626,y:698,t:1526933642095};\\\", \\\"{x:1626,y:699,t:1526933642112};\\\", \\\"{x:1626,y:700,t:1526933642128};\\\", \\\"{x:1625,y:700,t:1526933642146};\\\", \\\"{x:1625,y:701,t:1526933642233};\\\", \\\"{x:1624,y:702,t:1526933642246};\\\", \\\"{x:1623,y:702,t:1526933642261};\\\", \\\"{x:1622,y:702,t:1526933642278};\\\", \\\"{x:1620,y:702,t:1526933642295};\\\", \\\"{x:1618,y:702,t:1526933642311};\\\", \\\"{x:1616,y:703,t:1526933642329};\\\", \\\"{x:1615,y:703,t:1526933642361};\\\", \\\"{x:1614,y:703,t:1526933642378};\\\", \\\"{x:1612,y:703,t:1526933642395};\\\", \\\"{x:1611,y:703,t:1526933642411};\\\", \\\"{x:1610,y:703,t:1526933642428};\\\", \\\"{x:1609,y:703,t:1526933642457};\\\", \\\"{x:1608,y:703,t:1526933642465};\\\", \\\"{x:1607,y:703,t:1526933642480};\\\", \\\"{x:1606,y:703,t:1526933642520};\\\", \\\"{x:1605,y:703,t:1526933642543};\\\", \\\"{x:1605,y:705,t:1526933642753};\\\", \\\"{x:1603,y:709,t:1526933642761};\\\", \\\"{x:1602,y:715,t:1526933642778};\\\", \\\"{x:1599,y:721,t:1526933642794};\\\", \\\"{x:1597,y:726,t:1526933642811};\\\", \\\"{x:1595,y:731,t:1526933642828};\\\", \\\"{x:1594,y:732,t:1526933642844};\\\", \\\"{x:1593,y:732,t:1526933642861};\\\", \\\"{x:1592,y:733,t:1526933642877};\\\", \\\"{x:1589,y:735,t:1526933642894};\\\", \\\"{x:1584,y:738,t:1526933642912};\\\", \\\"{x:1574,y:743,t:1526933642928};\\\", \\\"{x:1562,y:748,t:1526933642945};\\\", \\\"{x:1549,y:753,t:1526933642961};\\\", \\\"{x:1539,y:758,t:1526933642978};\\\", \\\"{x:1531,y:762,t:1526933642995};\\\", \\\"{x:1527,y:763,t:1526933643011};\\\", \\\"{x:1523,y:764,t:1526933643028};\\\", \\\"{x:1519,y:766,t:1526933643045};\\\", \\\"{x:1517,y:766,t:1526933643061};\\\", \\\"{x:1513,y:767,t:1526933643077};\\\", \\\"{x:1511,y:768,t:1526933643095};\\\", \\\"{x:1508,y:768,t:1526933643111};\\\", \\\"{x:1507,y:768,t:1526933643127};\\\", \\\"{x:1506,y:768,t:1526933643145};\\\", \\\"{x:1505,y:768,t:1526933643242};\\\", \\\"{x:1505,y:769,t:1526933643250};\\\", \\\"{x:1505,y:770,t:1526933643274};\\\", \\\"{x:1504,y:771,t:1526933643281};\\\", \\\"{x:1504,y:772,t:1526933643297};\\\", \\\"{x:1504,y:774,t:1526933643313};\\\", \\\"{x:1503,y:775,t:1526933643329};\\\", \\\"{x:1503,y:776,t:1526933643345};\\\", \\\"{x:1502,y:776,t:1526933643361};\\\", \\\"{x:1502,y:777,t:1526933643378};\\\", \\\"{x:1502,y:778,t:1526933643506};\\\", \\\"{x:1499,y:774,t:1526933643513};\\\", \\\"{x:1498,y:771,t:1526933643527};\\\", \\\"{x:1492,y:755,t:1526933643544};\\\", \\\"{x:1482,y:735,t:1526933643561};\\\", \\\"{x:1476,y:722,t:1526933643576};\\\", \\\"{x:1467,y:706,t:1526933643594};\\\", \\\"{x:1461,y:693,t:1526933643610};\\\", \\\"{x:1458,y:687,t:1526933643627};\\\", \\\"{x:1456,y:681,t:1526933643643};\\\", \\\"{x:1454,y:677,t:1526933643660};\\\", \\\"{x:1452,y:675,t:1526933643677};\\\", \\\"{x:1452,y:673,t:1526933643693};\\\", \\\"{x:1451,y:672,t:1526933643711};\\\", \\\"{x:1450,y:670,t:1526933643737};\\\", \\\"{x:1449,y:673,t:1526933643882};\\\", \\\"{x:1448,y:680,t:1526933643893};\\\", \\\"{x:1441,y:701,t:1526933643911};\\\", \\\"{x:1433,y:723,t:1526933643926};\\\", \\\"{x:1422,y:741,t:1526933643943};\\\", \\\"{x:1410,y:758,t:1526933643960};\\\", \\\"{x:1384,y:782,t:1526933643977};\\\", \\\"{x:1350,y:793,t:1526933643993};\\\", \\\"{x:1309,y:797,t:1526933644010};\\\", \\\"{x:1248,y:797,t:1526933644027};\\\", \\\"{x:1171,y:793,t:1526933644043};\\\", \\\"{x:1076,y:776,t:1526933644060};\\\", \\\"{x:975,y:758,t:1526933644077};\\\", \\\"{x:857,y:746,t:1526933644092};\\\", \\\"{x:746,y:746,t:1526933644110};\\\", \\\"{x:655,y:746,t:1526933644126};\\\", \\\"{x:588,y:746,t:1526933644143};\\\", \\\"{x:551,y:748,t:1526933644162};\\\", \\\"{x:522,y:760,t:1526933644177};\\\", \\\"{x:512,y:766,t:1526933644192};\\\", \\\"{x:503,y:775,t:1526933644217};\\\", \\\"{x:500,y:778,t:1526933644234};\\\", \\\"{x:499,y:779,t:1526933644250};\\\", \\\"{x:499,y:780,t:1526933644267};\\\", \\\"{x:497,y:780,t:1526933644284};\\\", \\\"{x:496,y:780,t:1526933644299};\\\", \\\"{x:492,y:780,t:1526933644317};\\\", \\\"{x:489,y:780,t:1526933644333};\\\", \\\"{x:486,y:772,t:1526933644350};\\\", \\\"{x:485,y:758,t:1526933644367};\\\", \\\"{x:485,y:743,t:1526933644384};\\\", \\\"{x:487,y:732,t:1526933644400};\\\", \\\"{x:492,y:724,t:1526933644418};\\\", \\\"{x:494,y:722,t:1526933644436};\\\", \\\"{x:499,y:726,t:1526933645041};\\\", \\\"{x:505,y:736,t:1526933645053};\\\", \\\"{x:523,y:758,t:1526933645070};\\\", \\\"{x:544,y:776,t:1526933645086};\\\", \\\"{x:567,y:795,t:1526933645103};\\\", \\\"{x:592,y:808,t:1526933645120};\\\", \\\"{x:611,y:819,t:1526933645136};\\\", \\\"{x:629,y:829,t:1526933645153};\\\", \\\"{x:636,y:833,t:1526933645170};\\\", \\\"{x:641,y:834,t:1526933645186};\\\", \\\"{x:643,y:836,t:1526933645203};\\\" ] }, { \\\"rt\\\": 34824, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 435890, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:659,y:836,t:1526933650249};\\\", \\\"{x:692,y:830,t:1526933650256};\\\", \\\"{x:795,y:814,t:1526933650273};\\\", \\\"{x:907,y:787,t:1526933650289};\\\", \\\"{x:1039,y:760,t:1526933650307};\\\", \\\"{x:1170,y:732,t:1526933650323};\\\", \\\"{x:1296,y:707,t:1526933650340};\\\", \\\"{x:1403,y:681,t:1526933650357};\\\", \\\"{x:1487,y:652,t:1526933650373};\\\", \\\"{x:1536,y:624,t:1526933650390};\\\", \\\"{x:1561,y:602,t:1526933650407};\\\", \\\"{x:1574,y:584,t:1526933650423};\\\", \\\"{x:1581,y:565,t:1526933650440};\\\", \\\"{x:1582,y:555,t:1526933650457};\\\", \\\"{x:1582,y:545,t:1526933650474};\\\", \\\"{x:1581,y:538,t:1526933650490};\\\", \\\"{x:1574,y:529,t:1526933650508};\\\", \\\"{x:1564,y:524,t:1526933650523};\\\", \\\"{x:1547,y:523,t:1526933650541};\\\", \\\"{x:1529,y:523,t:1526933650557};\\\", \\\"{x:1510,y:525,t:1526933650574};\\\", \\\"{x:1488,y:530,t:1526933650590};\\\", \\\"{x:1466,y:531,t:1526933650608};\\\", \\\"{x:1443,y:531,t:1526933650624};\\\", \\\"{x:1410,y:531,t:1526933650641};\\\", \\\"{x:1396,y:531,t:1526933650657};\\\", \\\"{x:1388,y:531,t:1526933650675};\\\", \\\"{x:1382,y:531,t:1526933650691};\\\", \\\"{x:1379,y:531,t:1526933650708};\\\", \\\"{x:1371,y:530,t:1526933650724};\\\", \\\"{x:1362,y:526,t:1526933650740};\\\", \\\"{x:1352,y:520,t:1526933650758};\\\", \\\"{x:1343,y:515,t:1526933650775};\\\", \\\"{x:1333,y:509,t:1526933650790};\\\", \\\"{x:1329,y:506,t:1526933650807};\\\", \\\"{x:1328,y:505,t:1526933652538};\\\", \\\"{x:1327,y:505,t:1526933652674};\\\", \\\"{x:1326,y:505,t:1526933652705};\\\", \\\"{x:1330,y:504,t:1526933652777};\\\", \\\"{x:1335,y:504,t:1526933652793};\\\", \\\"{x:1342,y:504,t:1526933652809};\\\", \\\"{x:1347,y:504,t:1526933652826};\\\", \\\"{x:1350,y:504,t:1526933652843};\\\", \\\"{x:1352,y:504,t:1526933652859};\\\", \\\"{x:1353,y:504,t:1526933652905};\\\", \\\"{x:1355,y:504,t:1526933652921};\\\", \\\"{x:1356,y:504,t:1526933652937};\\\", \\\"{x:1358,y:504,t:1526933652969};\\\", \\\"{x:1359,y:504,t:1526933652977};\\\", \\\"{x:1360,y:504,t:1526933652993};\\\", \\\"{x:1361,y:504,t:1526933653010};\\\", \\\"{x:1364,y:504,t:1526933653025};\\\", \\\"{x:1365,y:504,t:1526933653043};\\\", \\\"{x:1367,y:504,t:1526933653059};\\\", \\\"{x:1368,y:504,t:1526933653076};\\\", \\\"{x:1369,y:504,t:1526933653105};\\\", \\\"{x:1370,y:504,t:1526933653113};\\\", \\\"{x:1372,y:504,t:1526933653144};\\\", \\\"{x:1373,y:504,t:1526933653160};\\\", \\\"{x:1374,y:504,t:1526933653176};\\\", \\\"{x:1375,y:504,t:1526933653199};\\\", \\\"{x:1376,y:504,t:1526933653216};\\\", \\\"{x:1377,y:504,t:1526933653232};\\\", \\\"{x:1378,y:504,t:1526933653242};\\\", \\\"{x:1380,y:504,t:1526933653259};\\\", \\\"{x:1381,y:504,t:1526933653276};\\\", \\\"{x:1385,y:504,t:1526933653292};\\\", \\\"{x:1387,y:504,t:1526933653394};\\\", \\\"{x:1388,y:504,t:1526933653410};\\\", \\\"{x:1392,y:504,t:1526933653425};\\\", \\\"{x:1394,y:504,t:1526933653443};\\\", \\\"{x:1397,y:505,t:1526933653460};\\\", \\\"{x:1400,y:507,t:1526933653475};\\\", \\\"{x:1402,y:508,t:1526933653492};\\\", \\\"{x:1403,y:508,t:1526933653512};\\\", \\\"{x:1403,y:509,t:1526933653527};\\\", \\\"{x:1404,y:510,t:1526933653543};\\\", \\\"{x:1405,y:511,t:1526933653559};\\\", \\\"{x:1405,y:513,t:1526933653576};\\\", \\\"{x:1406,y:514,t:1526933653599};\\\", \\\"{x:1406,y:515,t:1526933653624};\\\", \\\"{x:1406,y:517,t:1526933653639};\\\", \\\"{x:1406,y:518,t:1526933653680};\\\", \\\"{x:1406,y:519,t:1526933653692};\\\", \\\"{x:1406,y:520,t:1526933653709};\\\", \\\"{x:1406,y:521,t:1526933653785};\\\", \\\"{x:1406,y:522,t:1526933653792};\\\", \\\"{x:1406,y:523,t:1526933653809};\\\", \\\"{x:1407,y:523,t:1526933653827};\\\", \\\"{x:1408,y:525,t:1526933653842};\\\", \\\"{x:1408,y:526,t:1526933653860};\\\", \\\"{x:1408,y:527,t:1526933653877};\\\", \\\"{x:1408,y:529,t:1526933653892};\\\", \\\"{x:1409,y:529,t:1526933653910};\\\", \\\"{x:1409,y:530,t:1526933653927};\\\", \\\"{x:1409,y:531,t:1526933653943};\\\", \\\"{x:1409,y:532,t:1526933653960};\\\", \\\"{x:1410,y:533,t:1526933653977};\\\", \\\"{x:1410,y:534,t:1526933653994};\\\", \\\"{x:1411,y:535,t:1526933654009};\\\", \\\"{x:1411,y:537,t:1526933654057};\\\", \\\"{x:1411,y:538,t:1526933654081};\\\", \\\"{x:1411,y:540,t:1526933654137};\\\", \\\"{x:1411,y:541,t:1526933654249};\\\", \\\"{x:1411,y:543,t:1526933654281};\\\", \\\"{x:1411,y:544,t:1526933654313};\\\", \\\"{x:1411,y:546,t:1526933654345};\\\", \\\"{x:1411,y:547,t:1526933654417};\\\", \\\"{x:1411,y:550,t:1526933654809};\\\", \\\"{x:1411,y:555,t:1526933654816};\\\", \\\"{x:1411,y:563,t:1526933654829};\\\", \\\"{x:1411,y:588,t:1526933654844};\\\", \\\"{x:1411,y:615,t:1526933654860};\\\", \\\"{x:1411,y:642,t:1526933654876};\\\", \\\"{x:1410,y:660,t:1526933654893};\\\", \\\"{x:1407,y:672,t:1526933654910};\\\", \\\"{x:1405,y:680,t:1526933654927};\\\", \\\"{x:1403,y:685,t:1526933654943};\\\", \\\"{x:1398,y:692,t:1526933654960};\\\", \\\"{x:1392,y:700,t:1526933654977};\\\", \\\"{x:1383,y:714,t:1526933654993};\\\", \\\"{x:1376,y:722,t:1526933655010};\\\", \\\"{x:1369,y:732,t:1526933655027};\\\", \\\"{x:1365,y:737,t:1526933655043};\\\", \\\"{x:1363,y:739,t:1526933655060};\\\", \\\"{x:1360,y:740,t:1526933655077};\\\", \\\"{x:1359,y:742,t:1526933655093};\\\", \\\"{x:1357,y:744,t:1526933655110};\\\", \\\"{x:1356,y:746,t:1526933655128};\\\", \\\"{x:1354,y:749,t:1526933655144};\\\", \\\"{x:1354,y:753,t:1526933655161};\\\", \\\"{x:1354,y:756,t:1526933655177};\\\", \\\"{x:1354,y:757,t:1526933655193};\\\", \\\"{x:1354,y:758,t:1526933655211};\\\", \\\"{x:1354,y:759,t:1526933655227};\\\", \\\"{x:1354,y:760,t:1526933655257};\\\", \\\"{x:1354,y:763,t:1526933655265};\\\", \\\"{x:1354,y:764,t:1526933655278};\\\", \\\"{x:1355,y:768,t:1526933655294};\\\", \\\"{x:1355,y:770,t:1526933655310};\\\", \\\"{x:1356,y:771,t:1526933660186};\\\", \\\"{x:1357,y:771,t:1526933660305};\\\", \\\"{x:1358,y:772,t:1526933660315};\\\", \\\"{x:1357,y:772,t:1526933668650};\\\", \\\"{x:1356,y:772,t:1526933669580};\\\", \\\"{x:1354,y:772,t:1526933669592};\\\", \\\"{x:1351,y:772,t:1526933670364};\\\", \\\"{x:1344,y:772,t:1526933670376};\\\", \\\"{x:1337,y:772,t:1526933670392};\\\", \\\"{x:1330,y:772,t:1526933670408};\\\", \\\"{x:1328,y:772,t:1526933670425};\\\", \\\"{x:1327,y:772,t:1526933670500};\\\", \\\"{x:1325,y:772,t:1526933670515};\\\", \\\"{x:1322,y:772,t:1526933670531};\\\", \\\"{x:1320,y:772,t:1526933670541};\\\", \\\"{x:1315,y:772,t:1526933670558};\\\", \\\"{x:1309,y:772,t:1526933670575};\\\", \\\"{x:1305,y:772,t:1526933670591};\\\", \\\"{x:1296,y:771,t:1526933670608};\\\", \\\"{x:1287,y:768,t:1526933670625};\\\", \\\"{x:1281,y:767,t:1526933670642};\\\", \\\"{x:1277,y:767,t:1526933670658};\\\", \\\"{x:1273,y:766,t:1526933670676};\\\", \\\"{x:1272,y:766,t:1526933670708};\\\", \\\"{x:1271,y:764,t:1526933670747};\\\", \\\"{x:1270,y:763,t:1526933670759};\\\", \\\"{x:1267,y:760,t:1526933670775};\\\", \\\"{x:1264,y:757,t:1526933670793};\\\", \\\"{x:1262,y:754,t:1526933670808};\\\", \\\"{x:1260,y:753,t:1526933670826};\\\", \\\"{x:1259,y:751,t:1526933670843};\\\", \\\"{x:1258,y:750,t:1526933670858};\\\", \\\"{x:1256,y:749,t:1526933670876};\\\", \\\"{x:1255,y:747,t:1526933670892};\\\", \\\"{x:1250,y:744,t:1526933670908};\\\", \\\"{x:1246,y:741,t:1526933670925};\\\", \\\"{x:1242,y:739,t:1526933670942};\\\", \\\"{x:1237,y:738,t:1526933670958};\\\", \\\"{x:1233,y:737,t:1526933670975};\\\", \\\"{x:1228,y:736,t:1526933670993};\\\", \\\"{x:1223,y:736,t:1526933671008};\\\", \\\"{x:1220,y:736,t:1526933671026};\\\", \\\"{x:1215,y:736,t:1526933671043};\\\", \\\"{x:1213,y:736,t:1526933671058};\\\", \\\"{x:1209,y:736,t:1526933671075};\\\", \\\"{x:1207,y:736,t:1526933671092};\\\", \\\"{x:1204,y:736,t:1526933671109};\\\", \\\"{x:1203,y:736,t:1526933671125};\\\", \\\"{x:1201,y:736,t:1526933671147};\\\", \\\"{x:1200,y:736,t:1526933671171};\\\", \\\"{x:1200,y:737,t:1526933671196};\\\", \\\"{x:1200,y:739,t:1526933671516};\\\", \\\"{x:1200,y:740,t:1526933671548};\\\", \\\"{x:1200,y:742,t:1526933671571};\\\", \\\"{x:1201,y:742,t:1526933671587};\\\", \\\"{x:1202,y:743,t:1526933671596};\\\", \\\"{x:1204,y:744,t:1526933671610};\\\", \\\"{x:1210,y:744,t:1526933671627};\\\", \\\"{x:1221,y:746,t:1526933671643};\\\", \\\"{x:1246,y:749,t:1526933671660};\\\", \\\"{x:1266,y:751,t:1526933671675};\\\", \\\"{x:1291,y:753,t:1526933671693};\\\", \\\"{x:1318,y:753,t:1526933671709};\\\", \\\"{x:1342,y:753,t:1526933671726};\\\", \\\"{x:1365,y:753,t:1526933671742};\\\", \\\"{x:1386,y:753,t:1526933671759};\\\", \\\"{x:1401,y:753,t:1526933671775};\\\", \\\"{x:1410,y:753,t:1526933671792};\\\", \\\"{x:1414,y:753,t:1526933671808};\\\", \\\"{x:1415,y:753,t:1526933671825};\\\", \\\"{x:1416,y:754,t:1526933671841};\\\", \\\"{x:1417,y:754,t:1526933671907};\\\", \\\"{x:1418,y:754,t:1526933671923};\\\", \\\"{x:1420,y:755,t:1526933671947};\\\", \\\"{x:1421,y:756,t:1526933671971};\\\", \\\"{x:1422,y:756,t:1526933671988};\\\", \\\"{x:1423,y:757,t:1526933671995};\\\", \\\"{x:1423,y:758,t:1526933672010};\\\", \\\"{x:1425,y:760,t:1526933672027};\\\", \\\"{x:1426,y:762,t:1526933672043};\\\", \\\"{x:1428,y:767,t:1526933672059};\\\", \\\"{x:1429,y:770,t:1526933672076};\\\", \\\"{x:1430,y:772,t:1526933672094};\\\", \\\"{x:1430,y:773,t:1526933672109};\\\", \\\"{x:1431,y:774,t:1526933672139};\\\", \\\"{x:1431,y:775,t:1526933672148};\\\", \\\"{x:1432,y:776,t:1526933672163};\\\", \\\"{x:1432,y:777,t:1526933672187};\\\", \\\"{x:1433,y:779,t:1526933672195};\\\", \\\"{x:1433,y:780,t:1526933672220};\\\", \\\"{x:1433,y:781,t:1526933672227};\\\", \\\"{x:1434,y:784,t:1526933672244};\\\", \\\"{x:1436,y:786,t:1526933672267};\\\", \\\"{x:1436,y:788,t:1526933672291};\\\", \\\"{x:1436,y:789,t:1526933672300};\\\", \\\"{x:1436,y:790,t:1526933672316};\\\", \\\"{x:1436,y:791,t:1526933672331};\\\", \\\"{x:1437,y:792,t:1526933672343};\\\", \\\"{x:1438,y:794,t:1526933672359};\\\", \\\"{x:1441,y:799,t:1526933672376};\\\", \\\"{x:1444,y:803,t:1526933672394};\\\", \\\"{x:1446,y:808,t:1526933672409};\\\", \\\"{x:1448,y:811,t:1526933672426};\\\", \\\"{x:1451,y:813,t:1526933672443};\\\", \\\"{x:1451,y:814,t:1526933672459};\\\", \\\"{x:1452,y:817,t:1526933672477};\\\", \\\"{x:1454,y:819,t:1526933672494};\\\", \\\"{x:1454,y:821,t:1526933672510};\\\", \\\"{x:1456,y:822,t:1526933672527};\\\", \\\"{x:1457,y:823,t:1526933672543};\\\", \\\"{x:1457,y:824,t:1526933672561};\\\", \\\"{x:1458,y:825,t:1526933672576};\\\", \\\"{x:1460,y:827,t:1526933672594};\\\", \\\"{x:1461,y:830,t:1526933672611};\\\", \\\"{x:1463,y:832,t:1526933672627};\\\", \\\"{x:1464,y:834,t:1526933672643};\\\", \\\"{x:1464,y:835,t:1526933672660};\\\", \\\"{x:1464,y:836,t:1526933672724};\\\", \\\"{x:1462,y:836,t:1526933672764};\\\", \\\"{x:1458,y:836,t:1526933672777};\\\", \\\"{x:1445,y:836,t:1526933672794};\\\", \\\"{x:1434,y:836,t:1526933672810};\\\", \\\"{x:1423,y:835,t:1526933672827};\\\", \\\"{x:1407,y:830,t:1526933672844};\\\", \\\"{x:1402,y:827,t:1526933672861};\\\", \\\"{x:1400,y:826,t:1526933672876};\\\", \\\"{x:1399,y:825,t:1526933672899};\\\", \\\"{x:1396,y:825,t:1526933672932};\\\", \\\"{x:1395,y:824,t:1526933672944};\\\", \\\"{x:1393,y:823,t:1526933672960};\\\", \\\"{x:1389,y:823,t:1526933672977};\\\", \\\"{x:1386,y:822,t:1526933672994};\\\", \\\"{x:1383,y:821,t:1526933673010};\\\", \\\"{x:1379,y:819,t:1526933673027};\\\", \\\"{x:1378,y:819,t:1526933673044};\\\", \\\"{x:1375,y:817,t:1526933673060};\\\", \\\"{x:1373,y:816,t:1526933673077};\\\", \\\"{x:1370,y:813,t:1526933673093};\\\", \\\"{x:1367,y:810,t:1526933673111};\\\", \\\"{x:1364,y:808,t:1526933673128};\\\", \\\"{x:1362,y:806,t:1526933673143};\\\", \\\"{x:1362,y:805,t:1526933673161};\\\", \\\"{x:1361,y:805,t:1526933673178};\\\", \\\"{x:1360,y:803,t:1526933673194};\\\", \\\"{x:1359,y:802,t:1526933673211};\\\", \\\"{x:1357,y:801,t:1526933673228};\\\", \\\"{x:1356,y:800,t:1526933673243};\\\", \\\"{x:1356,y:799,t:1526933673260};\\\", \\\"{x:1354,y:798,t:1526933673278};\\\", \\\"{x:1353,y:796,t:1526933673294};\\\", \\\"{x:1352,y:795,t:1526933673315};\\\", \\\"{x:1351,y:794,t:1526933673327};\\\", \\\"{x:1351,y:793,t:1526933673348};\\\", \\\"{x:1350,y:792,t:1526933673360};\\\", \\\"{x:1349,y:790,t:1526933673377};\\\", \\\"{x:1348,y:789,t:1526933673394};\\\", \\\"{x:1347,y:786,t:1526933673411};\\\", \\\"{x:1346,y:784,t:1526933673427};\\\", \\\"{x:1346,y:782,t:1526933673459};\\\", \\\"{x:1345,y:782,t:1526933673478};\\\", \\\"{x:1345,y:781,t:1526933673495};\\\", \\\"{x:1345,y:779,t:1526933673516};\\\", \\\"{x:1344,y:778,t:1526933673527};\\\", \\\"{x:1344,y:776,t:1526933673544};\\\", \\\"{x:1344,y:774,t:1526933673561};\\\", \\\"{x:1344,y:773,t:1526933673577};\\\", \\\"{x:1344,y:772,t:1526933673594};\\\", \\\"{x:1344,y:771,t:1526933673610};\\\", \\\"{x:1344,y:769,t:1526933673627};\\\", \\\"{x:1344,y:768,t:1526933673643};\\\", \\\"{x:1345,y:766,t:1526933673660};\\\", \\\"{x:1345,y:764,t:1526933673693};\\\", \\\"{x:1346,y:764,t:1526933673710};\\\", \\\"{x:1346,y:763,t:1526933673726};\\\", \\\"{x:1346,y:760,t:1526933673744};\\\", \\\"{x:1347,y:759,t:1526933673760};\\\", \\\"{x:1347,y:757,t:1526933673777};\\\", \\\"{x:1348,y:755,t:1526933673794};\\\", \\\"{x:1348,y:753,t:1526933673810};\\\", \\\"{x:1349,y:751,t:1526933673827};\\\", \\\"{x:1349,y:750,t:1526933673844};\\\", \\\"{x:1349,y:749,t:1526933673860};\\\", \\\"{x:1349,y:748,t:1526933673877};\\\", \\\"{x:1349,y:747,t:1526933673895};\\\", \\\"{x:1349,y:745,t:1526933673910};\\\", \\\"{x:1349,y:744,t:1526933673927};\\\", \\\"{x:1349,y:743,t:1526933673944};\\\", \\\"{x:1349,y:742,t:1526933673961};\\\", \\\"{x:1349,y:738,t:1526933673977};\\\", \\\"{x:1349,y:734,t:1526933673995};\\\", \\\"{x:1349,y:723,t:1526933674012};\\\", \\\"{x:1347,y:717,t:1526933674027};\\\", \\\"{x:1342,y:707,t:1526933674044};\\\", \\\"{x:1339,y:699,t:1526933674062};\\\", \\\"{x:1334,y:688,t:1526933674077};\\\", \\\"{x:1331,y:680,t:1526933674095};\\\", \\\"{x:1323,y:669,t:1526933674111};\\\", \\\"{x:1318,y:659,t:1526933674128};\\\", \\\"{x:1312,y:649,t:1526933674145};\\\", \\\"{x:1308,y:642,t:1526933674161};\\\", \\\"{x:1306,y:638,t:1526933674178};\\\", \\\"{x:1305,y:634,t:1526933674195};\\\", \\\"{x:1303,y:631,t:1526933674211};\\\", \\\"{x:1302,y:630,t:1526933674228};\\\", \\\"{x:1300,y:626,t:1526933674245};\\\", \\\"{x:1299,y:624,t:1526933674262};\\\", \\\"{x:1297,y:620,t:1526933674278};\\\", \\\"{x:1295,y:617,t:1526933674294};\\\", \\\"{x:1293,y:614,t:1526933674312};\\\", \\\"{x:1291,y:611,t:1526933674327};\\\", \\\"{x:1288,y:606,t:1526933674344};\\\", \\\"{x:1286,y:603,t:1526933674362};\\\", \\\"{x:1283,y:598,t:1526933674378};\\\", \\\"{x:1279,y:590,t:1526933674394};\\\", \\\"{x:1274,y:577,t:1526933674411};\\\", \\\"{x:1271,y:569,t:1526933674428};\\\", \\\"{x:1268,y:563,t:1526933674445};\\\", \\\"{x:1265,y:559,t:1526933674462};\\\", \\\"{x:1262,y:555,t:1526933674478};\\\", \\\"{x:1261,y:554,t:1526933674495};\\\", \\\"{x:1260,y:554,t:1526933674511};\\\", \\\"{x:1260,y:555,t:1526933674660};\\\", \\\"{x:1260,y:557,t:1526933674667};\\\", \\\"{x:1261,y:557,t:1526933674679};\\\", \\\"{x:1261,y:560,t:1526933674694};\\\", \\\"{x:1262,y:563,t:1526933674712};\\\", \\\"{x:1264,y:567,t:1526933674729};\\\", \\\"{x:1265,y:568,t:1526933674745};\\\", \\\"{x:1266,y:569,t:1526933674762};\\\", \\\"{x:1267,y:571,t:1526933674779};\\\", \\\"{x:1265,y:571,t:1526933675035};\\\", \\\"{x:1259,y:571,t:1526933675045};\\\", \\\"{x:1237,y:568,t:1526933675062};\\\", \\\"{x:1198,y:562,t:1526933675079};\\\", \\\"{x:1148,y:562,t:1526933675096};\\\", \\\"{x:1109,y:562,t:1526933675111};\\\", \\\"{x:1072,y:566,t:1526933675128};\\\", \\\"{x:1033,y:572,t:1526933675145};\\\", \\\"{x:986,y:584,t:1526933675161};\\\", \\\"{x:920,y:597,t:1526933675178};\\\", \\\"{x:792,y:622,t:1526933675195};\\\", \\\"{x:701,y:634,t:1526933675211};\\\", \\\"{x:682,y:637,t:1526933675228};\\\", \\\"{x:680,y:636,t:1526933675500};\\\", \\\"{x:680,y:633,t:1526933675515};\\\", \\\"{x:673,y:623,t:1526933675532};\\\", \\\"{x:660,y:608,t:1526933675547};\\\", \\\"{x:655,y:598,t:1526933675564};\\\", \\\"{x:647,y:582,t:1526933675580};\\\", \\\"{x:636,y:562,t:1526933675597};\\\", \\\"{x:623,y:544,t:1526933675614};\\\", \\\"{x:616,y:534,t:1526933675630};\\\", \\\"{x:612,y:527,t:1526933675647};\\\", \\\"{x:609,y:524,t:1526933675664};\\\", \\\"{x:608,y:522,t:1526933675680};\\\", \\\"{x:607,y:520,t:1526933675697};\\\", \\\"{x:606,y:518,t:1526933675713};\\\", \\\"{x:604,y:516,t:1526933675731};\\\", \\\"{x:597,y:507,t:1526933675747};\\\", \\\"{x:591,y:502,t:1526933675764};\\\", \\\"{x:585,y:497,t:1526933675780};\\\", \\\"{x:583,y:495,t:1526933675797};\\\", \\\"{x:583,y:493,t:1526933675875};\\\", \\\"{x:583,y:492,t:1526933675891};\\\", \\\"{x:584,y:492,t:1526933676035};\\\", \\\"{x:585,y:492,t:1526933676051};\\\", \\\"{x:586,y:492,t:1526933676067};\\\", \\\"{x:587,y:492,t:1526933676091};\\\", \\\"{x:588,y:493,t:1526933676131};\\\", \\\"{x:589,y:493,t:1526933676204};\\\", \\\"{x:590,y:494,t:1526933676215};\\\", \\\"{x:592,y:496,t:1526933676231};\\\", \\\"{x:594,y:497,t:1526933676251};\\\", \\\"{x:595,y:498,t:1526933676283};\\\", \\\"{x:596,y:499,t:1526933677507};\\\", \\\"{x:596,y:506,t:1526933677531};\\\", \\\"{x:596,y:517,t:1526933677539};\\\", \\\"{x:596,y:531,t:1526933677550};\\\", \\\"{x:596,y:557,t:1526933677566};\\\", \\\"{x:592,y:581,t:1526933677582};\\\", \\\"{x:590,y:602,t:1526933677599};\\\", \\\"{x:587,y:624,t:1526933677614};\\\", \\\"{x:581,y:650,t:1526933677632};\\\", \\\"{x:575,y:677,t:1526933677649};\\\", \\\"{x:573,y:701,t:1526933677665};\\\", \\\"{x:569,y:721,t:1526933677682};\\\", \\\"{x:566,y:739,t:1526933677698};\\\", \\\"{x:566,y:741,t:1526933677716};\\\", \\\"{x:566,y:733,t:1526933677843};\\\", \\\"{x:567,y:720,t:1526933677851};\\\", \\\"{x:571,y:704,t:1526933677865};\\\", \\\"{x:577,y:670,t:1526933677882};\\\", \\\"{x:588,y:611,t:1526933677899};\\\", \\\"{x:592,y:580,t:1526933677915};\\\", \\\"{x:594,y:548,t:1526933677933};\\\", \\\"{x:596,y:530,t:1526933677949};\\\", \\\"{x:596,y:522,t:1526933677965};\\\", \\\"{x:596,y:515,t:1526933677982};\\\", \\\"{x:597,y:510,t:1526933677999};\\\", \\\"{x:597,y:504,t:1526933678015};\\\", \\\"{x:599,y:495,t:1526933678032};\\\", \\\"{x:601,y:486,t:1526933678050};\\\", \\\"{x:602,y:482,t:1526933678066};\\\", \\\"{x:602,y:481,t:1526933678082};\\\", \\\"{x:603,y:480,t:1526933678140};\\\", \\\"{x:604,y:480,t:1526933678150};\\\", \\\"{x:605,y:480,t:1526933678166};\\\", \\\"{x:609,y:482,t:1526933678182};\\\", \\\"{x:612,y:485,t:1526933678200};\\\", \\\"{x:614,y:489,t:1526933678217};\\\", \\\"{x:615,y:492,t:1526933678233};\\\", \\\"{x:616,y:494,t:1526933678249};\\\", \\\"{x:616,y:496,t:1526933678265};\\\", \\\"{x:616,y:497,t:1526933678281};\\\", \\\"{x:616,y:498,t:1526933678306};\\\", \\\"{x:616,y:499,t:1526933678317};\\\", \\\"{x:615,y:501,t:1526933678332};\\\", \\\"{x:614,y:503,t:1526933678349};\\\", \\\"{x:613,y:504,t:1526933678365};\\\", \\\"{x:612,y:505,t:1526933678382};\\\", \\\"{x:611,y:505,t:1526933678411};\\\", \\\"{x:610,y:505,t:1526933678427};\\\", \\\"{x:609,y:505,t:1526933678451};\\\", \\\"{x:606,y:507,t:1526933679820};\\\", \\\"{x:606,y:508,t:1526933679834};\\\", \\\"{x:605,y:513,t:1526933679850};\\\", \\\"{x:605,y:517,t:1526933679868};\\\", \\\"{x:604,y:519,t:1526933679885};\\\", \\\"{x:604,y:520,t:1526933679900};\\\", \\\"{x:604,y:522,t:1526933679917};\\\", \\\"{x:602,y:526,t:1526933679935};\\\", \\\"{x:602,y:531,t:1526933679950};\\\", \\\"{x:601,y:536,t:1526933679967};\\\", \\\"{x:598,y:545,t:1526933679984};\\\", \\\"{x:597,y:558,t:1526933680001};\\\", \\\"{x:593,y:574,t:1526933680018};\\\", \\\"{x:591,y:604,t:1526933680034};\\\", \\\"{x:584,y:641,t:1526933680050};\\\", \\\"{x:576,y:701,t:1526933680067};\\\", \\\"{x:570,y:733,t:1526933680084};\\\", \\\"{x:564,y:752,t:1526933680100};\\\", \\\"{x:560,y:767,t:1526933680118};\\\", \\\"{x:559,y:774,t:1526933680134};\\\", \\\"{x:556,y:779,t:1526933680150};\\\", \\\"{x:555,y:781,t:1526933680167};\\\", \\\"{x:553,y:784,t:1526933680184};\\\", \\\"{x:552,y:784,t:1526933680291};\\\", \\\"{x:551,y:784,t:1526933680307};\\\", \\\"{x:548,y:782,t:1526933680318};\\\", \\\"{x:545,y:777,t:1526933680335};\\\", \\\"{x:541,y:771,t:1526933680352};\\\", \\\"{x:540,y:766,t:1526933680368};\\\", \\\"{x:538,y:763,t:1526933680384};\\\", \\\"{x:538,y:761,t:1526933680401};\\\", \\\"{x:538,y:760,t:1526933680417};\\\", \\\"{x:538,y:758,t:1526933680434};\\\", \\\"{x:537,y:754,t:1526933680453};\\\", \\\"{x:537,y:753,t:1526933680467};\\\", \\\"{x:537,y:751,t:1526933680484};\\\", \\\"{x:537,y:750,t:1526933680501};\\\" ] }, { \\\"rt\\\": 23381, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 460525, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-I -B -B -J -J -J -I -I -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:750,t:1526933684739};\\\", \\\"{x:598,y:758,t:1526933684760};\\\", \\\"{x:685,y:762,t:1526933684776};\\\", \\\"{x:782,y:762,t:1526933684792};\\\", \\\"{x:879,y:762,t:1526933684805};\\\", \\\"{x:971,y:762,t:1526933684821};\\\", \\\"{x:1054,y:762,t:1526933684837};\\\", \\\"{x:1107,y:762,t:1526933684855};\\\", \\\"{x:1152,y:762,t:1526933684872};\\\", \\\"{x:1177,y:762,t:1526933684888};\\\", \\\"{x:1203,y:762,t:1526933684904};\\\", \\\"{x:1225,y:760,t:1526933684921};\\\", \\\"{x:1246,y:757,t:1526933684937};\\\", \\\"{x:1279,y:754,t:1526933684954};\\\", \\\"{x:1298,y:753,t:1526933684972};\\\", \\\"{x:1316,y:753,t:1526933684987};\\\", \\\"{x:1330,y:752,t:1526933685004};\\\", \\\"{x:1336,y:751,t:1526933685022};\\\", \\\"{x:1341,y:750,t:1526933685038};\\\", \\\"{x:1342,y:750,t:1526933685196};\\\", \\\"{x:1343,y:750,t:1526933685300};\\\", \\\"{x:1343,y:751,t:1526933685307};\\\", \\\"{x:1343,y:753,t:1526933685322};\\\", \\\"{x:1343,y:760,t:1526933685340};\\\", \\\"{x:1343,y:765,t:1526933685355};\\\", \\\"{x:1341,y:770,t:1526933685372};\\\", \\\"{x:1340,y:776,t:1526933685388};\\\", \\\"{x:1337,y:780,t:1526933685405};\\\", \\\"{x:1334,y:784,t:1526933685422};\\\", \\\"{x:1330,y:788,t:1526933685439};\\\", \\\"{x:1327,y:791,t:1526933685455};\\\", \\\"{x:1321,y:796,t:1526933685471};\\\", \\\"{x:1313,y:798,t:1526933685489};\\\", \\\"{x:1305,y:799,t:1526933685505};\\\", \\\"{x:1298,y:799,t:1526933685521};\\\", \\\"{x:1283,y:800,t:1526933685538};\\\", \\\"{x:1270,y:801,t:1526933685554};\\\", \\\"{x:1261,y:801,t:1526933685572};\\\", \\\"{x:1250,y:804,t:1526933685589};\\\", \\\"{x:1243,y:804,t:1526933685604};\\\", \\\"{x:1234,y:805,t:1526933685622};\\\", \\\"{x:1228,y:808,t:1526933685639};\\\", \\\"{x:1223,y:809,t:1526933685656};\\\", \\\"{x:1220,y:809,t:1526933685672};\\\", \\\"{x:1218,y:812,t:1526933685688};\\\", \\\"{x:1216,y:814,t:1526933685706};\\\", \\\"{x:1215,y:819,t:1526933685722};\\\", \\\"{x:1213,y:825,t:1526933685739};\\\", \\\"{x:1212,y:827,t:1526933685756};\\\", \\\"{x:1212,y:828,t:1526933685771};\\\", \\\"{x:1212,y:829,t:1526933689811};\\\", \\\"{x:1212,y:830,t:1526933689899};\\\", \\\"{x:1212,y:831,t:1526933692052};\\\", \\\"{x:1213,y:831,t:1526933692075};\\\", \\\"{x:1213,y:832,t:1526933692083};\\\", \\\"{x:1213,y:830,t:1526933693452};\\\", \\\"{x:1213,y:829,t:1526933693475};\\\", \\\"{x:1213,y:828,t:1526933693483};\\\", \\\"{x:1213,y:827,t:1526933693507};\\\", \\\"{x:1213,y:825,t:1526933695451};\\\", \\\"{x:1213,y:823,t:1526933695464};\\\", \\\"{x:1213,y:821,t:1526933695479};\\\", \\\"{x:1213,y:819,t:1526933695497};\\\", \\\"{x:1213,y:816,t:1526933695512};\\\", \\\"{x:1212,y:815,t:1526933695529};\\\", \\\"{x:1212,y:814,t:1526933695546};\\\", \\\"{x:1212,y:813,t:1526933695563};\\\", \\\"{x:1212,y:812,t:1526933695579};\\\", \\\"{x:1212,y:811,t:1526933695596};\\\", \\\"{x:1211,y:810,t:1526933695613};\\\", \\\"{x:1210,y:809,t:1526933695635};\\\", \\\"{x:1210,y:808,t:1526933695647};\\\", \\\"{x:1210,y:807,t:1526933695664};\\\", \\\"{x:1208,y:805,t:1526933695679};\\\", \\\"{x:1207,y:803,t:1526933695697};\\\", \\\"{x:1206,y:802,t:1526933695713};\\\", \\\"{x:1204,y:801,t:1526933695729};\\\", \\\"{x:1202,y:797,t:1526933695747};\\\", \\\"{x:1198,y:793,t:1526933695763};\\\", \\\"{x:1196,y:791,t:1526933695780};\\\", \\\"{x:1195,y:789,t:1526933695797};\\\", \\\"{x:1193,y:787,t:1526933695813};\\\", \\\"{x:1191,y:785,t:1526933695830};\\\", \\\"{x:1189,y:782,t:1526933695846};\\\", \\\"{x:1187,y:779,t:1526933695865};\\\", \\\"{x:1184,y:776,t:1526933695879};\\\", \\\"{x:1181,y:773,t:1526933695896};\\\", \\\"{x:1180,y:772,t:1526933695912};\\\", \\\"{x:1179,y:771,t:1526933695929};\\\", \\\"{x:1179,y:770,t:1526933695946};\\\", \\\"{x:1178,y:769,t:1526933695963};\\\", \\\"{x:1177,y:768,t:1526933695994};\\\", \\\"{x:1176,y:766,t:1526933696036};\\\", \\\"{x:1176,y:765,t:1526933696064};\\\", \\\"{x:1175,y:764,t:1526933696080};\\\", \\\"{x:1174,y:763,t:1526933696096};\\\", \\\"{x:1174,y:760,t:1526933696114};\\\", \\\"{x:1174,y:759,t:1526933696130};\\\", \\\"{x:1174,y:758,t:1526933696146};\\\", \\\"{x:1173,y:757,t:1526933696539};\\\", \\\"{x:1173,y:758,t:1526933696595};\\\", \\\"{x:1173,y:759,t:1526933696603};\\\", \\\"{x:1173,y:760,t:1526933696613};\\\", \\\"{x:1175,y:761,t:1526933696630};\\\", \\\"{x:1176,y:761,t:1526933696658};\\\", \\\"{x:1177,y:761,t:1526933696682};\\\", \\\"{x:1178,y:761,t:1526933696754};\\\", \\\"{x:1178,y:762,t:1526933696763};\\\", \\\"{x:1178,y:763,t:1526933702500};\\\", \\\"{x:1169,y:763,t:1526933702507};\\\", \\\"{x:1151,y:763,t:1526933702517};\\\", \\\"{x:1119,y:762,t:1526933702536};\\\", \\\"{x:1075,y:761,t:1526933702551};\\\", \\\"{x:1036,y:761,t:1526933702567};\\\", \\\"{x:992,y:757,t:1526933702584};\\\", \\\"{x:933,y:755,t:1526933702602};\\\", \\\"{x:850,y:755,t:1526933702617};\\\", \\\"{x:711,y:755,t:1526933702634};\\\", \\\"{x:628,y:755,t:1526933702651};\\\", \\\"{x:537,y:760,t:1526933702667};\\\", \\\"{x:460,y:760,t:1526933702684};\\\", \\\"{x:442,y:763,t:1526933702701};\\\", \\\"{x:441,y:763,t:1526933702717};\\\", \\\"{x:440,y:763,t:1526933703019};\\\", \\\"{x:433,y:756,t:1526933703035};\\\", \\\"{x:392,y:729,t:1526933703051};\\\", \\\"{x:349,y:698,t:1526933703069};\\\", \\\"{x:314,y:670,t:1526933703084};\\\", \\\"{x:286,y:645,t:1526933703103};\\\", \\\"{x:268,y:622,t:1526933703118};\\\", \\\"{x:258,y:609,t:1526933703134};\\\", \\\"{x:252,y:600,t:1526933703152};\\\", \\\"{x:250,y:595,t:1526933703169};\\\", \\\"{x:248,y:587,t:1526933703187};\\\", \\\"{x:246,y:583,t:1526933703201};\\\", \\\"{x:243,y:579,t:1526933703219};\\\", \\\"{x:241,y:576,t:1526933703236};\\\", \\\"{x:241,y:573,t:1526933703252};\\\", \\\"{x:238,y:569,t:1526933703268};\\\", \\\"{x:234,y:560,t:1526933703286};\\\", \\\"{x:228,y:549,t:1526933703303};\\\", \\\"{x:221,y:540,t:1526933703319};\\\", \\\"{x:214,y:532,t:1526933703336};\\\", \\\"{x:210,y:528,t:1526933703352};\\\", \\\"{x:202,y:522,t:1526933703370};\\\", \\\"{x:181,y:510,t:1526933703387};\\\", \\\"{x:168,y:502,t:1526933703404};\\\", \\\"{x:152,y:496,t:1526933703419};\\\", \\\"{x:138,y:488,t:1526933703436};\\\", \\\"{x:129,y:485,t:1526933703453};\\\", \\\"{x:125,y:483,t:1526933703470};\\\", \\\"{x:124,y:483,t:1526933703485};\\\", \\\"{x:125,y:483,t:1526933703707};\\\", \\\"{x:125,y:484,t:1526933703719};\\\", \\\"{x:126,y:485,t:1526933703736};\\\", \\\"{x:128,y:486,t:1526933703752};\\\", \\\"{x:128,y:487,t:1526933703771};\\\", \\\"{x:130,y:489,t:1526933703786};\\\", \\\"{x:132,y:491,t:1526933703803};\\\", \\\"{x:133,y:493,t:1526933703820};\\\", \\\"{x:135,y:494,t:1526933703837};\\\", \\\"{x:136,y:495,t:1526933703854};\\\", \\\"{x:138,y:496,t:1526933703870};\\\", \\\"{x:139,y:497,t:1526933703887};\\\", \\\"{x:141,y:499,t:1526933703903};\\\", \\\"{x:142,y:499,t:1526933703920};\\\", \\\"{x:143,y:499,t:1526933703963};\\\", \\\"{x:144,y:500,t:1526933703995};\\\", \\\"{x:145,y:500,t:1526933704027};\\\", \\\"{x:146,y:501,t:1526933704075};\\\", \\\"{x:147,y:501,t:1526933704087};\\\", \\\"{x:152,y:502,t:1526933704105};\\\", \\\"{x:161,y:504,t:1526933704121};\\\", \\\"{x:168,y:505,t:1526933704137};\\\", \\\"{x:173,y:505,t:1526933704153};\\\", \\\"{x:174,y:505,t:1526933704170};\\\", \\\"{x:175,y:507,t:1526933704764};\\\", \\\"{x:177,y:514,t:1526933704772};\\\", \\\"{x:198,y:549,t:1526933704787};\\\", \\\"{x:231,y:599,t:1526933704804};\\\", \\\"{x:275,y:653,t:1526933704820};\\\", \\\"{x:325,y:700,t:1526933704837};\\\", \\\"{x:361,y:722,t:1526933704854};\\\", \\\"{x:384,y:733,t:1526933704870};\\\", \\\"{x:399,y:738,t:1526933704887};\\\", \\\"{x:402,y:740,t:1526933704904};\\\", \\\"{x:403,y:740,t:1526933704920};\\\", \\\"{x:404,y:741,t:1526933704971};\\\", \\\"{x:405,y:741,t:1526933704987};\\\", \\\"{x:407,y:741,t:1526933705004};\\\", \\\"{x:410,y:740,t:1526933705020};\\\", \\\"{x:415,y:736,t:1526933705037};\\\", \\\"{x:424,y:731,t:1526933705054};\\\", \\\"{x:436,y:726,t:1526933705070};\\\", \\\"{x:445,y:723,t:1526933705087};\\\", \\\"{x:452,y:721,t:1526933705106};\\\", \\\"{x:458,y:720,t:1526933705121};\\\", \\\"{x:464,y:720,t:1526933705138};\\\", \\\"{x:467,y:720,t:1526933705154};\\\", \\\"{x:468,y:720,t:1526933705186};\\\", \\\"{x:470,y:720,t:1526933705251};\\\", \\\"{x:472,y:721,t:1526933705267};\\\", \\\"{x:473,y:721,t:1526933705956};\\\", \\\"{x:475,y:722,t:1526933705971};\\\", \\\"{x:491,y:732,t:1526933705988};\\\", \\\"{x:514,y:745,t:1526933706005};\\\", \\\"{x:555,y:757,t:1526933706022};\\\", \\\"{x:616,y:774,t:1526933706038};\\\", \\\"{x:673,y:785,t:1526933706055};\\\", \\\"{x:732,y:797,t:1526933706071};\\\", \\\"{x:780,y:804,t:1526933706089};\\\", \\\"{x:812,y:807,t:1526933706106};\\\", \\\"{x:832,y:808,t:1526933706121};\\\", \\\"{x:846,y:808,t:1526933706139};\\\", \\\"{x:848,y:808,t:1526933706155};\\\", \\\"{x:849,y:808,t:1526933706171};\\\" ] }, { \\\"rt\\\": 39422, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 501278, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -12 PM-F -M -12 PM-01 PM-03 PM-04 PM-X -X -X -01 PM-B -B -C -J -2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:853,y:808,t:1526933708691};\\\", \\\"{x:922,y:808,t:1526933708722};\\\", \\\"{x:947,y:808,t:1526933708730};\\\", \\\"{x:975,y:808,t:1526933708740};\\\", \\\"{x:1031,y:808,t:1526933708757};\\\", \\\"{x:1084,y:808,t:1526933708773};\\\", \\\"{x:1126,y:808,t:1526933708791};\\\", \\\"{x:1156,y:808,t:1526933708807};\\\", \\\"{x:1178,y:803,t:1526933708823};\\\", \\\"{x:1195,y:798,t:1526933708840};\\\", \\\"{x:1206,y:793,t:1526933708857};\\\", \\\"{x:1217,y:790,t:1526933708873};\\\", \\\"{x:1236,y:784,t:1526933708890};\\\", \\\"{x:1251,y:780,t:1526933708907};\\\", \\\"{x:1261,y:774,t:1526933708924};\\\", \\\"{x:1270,y:770,t:1526933708941};\\\", \\\"{x:1274,y:765,t:1526933708958};\\\", \\\"{x:1280,y:759,t:1526933708974};\\\", \\\"{x:1288,y:753,t:1526933708991};\\\", \\\"{x:1292,y:749,t:1526933709008};\\\", \\\"{x:1297,y:747,t:1526933709024};\\\", \\\"{x:1301,y:744,t:1526933709041};\\\", \\\"{x:1305,y:740,t:1526933709058};\\\", \\\"{x:1309,y:737,t:1526933709074};\\\", \\\"{x:1313,y:735,t:1526933709091};\\\", \\\"{x:1316,y:733,t:1526933709107};\\\", \\\"{x:1322,y:731,t:1526933709124};\\\", \\\"{x:1327,y:728,t:1526933709141};\\\", \\\"{x:1335,y:725,t:1526933709158};\\\", \\\"{x:1340,y:724,t:1526933709173};\\\", \\\"{x:1341,y:723,t:1526933709190};\\\", \\\"{x:1342,y:723,t:1526933709211};\\\", \\\"{x:1343,y:723,t:1526933709547};\\\", \\\"{x:1343,y:722,t:1526933709558};\\\", \\\"{x:1344,y:719,t:1526933709575};\\\", \\\"{x:1346,y:714,t:1526933709591};\\\", \\\"{x:1348,y:709,t:1526933709608};\\\", \\\"{x:1348,y:706,t:1526933709625};\\\", \\\"{x:1348,y:703,t:1526933709641};\\\", \\\"{x:1349,y:700,t:1526933709661};\\\", \\\"{x:1350,y:696,t:1526933709673};\\\", \\\"{x:1350,y:695,t:1526933709698};\\\", \\\"{x:1350,y:694,t:1526933709722};\\\", \\\"{x:1350,y:693,t:1526933709803};\\\", \\\"{x:1350,y:692,t:1526933709899};\\\", \\\"{x:1349,y:692,t:1526933709963};\\\", \\\"{x:1348,y:693,t:1526933710531};\\\", \\\"{x:1348,y:694,t:1526933710542};\\\", \\\"{x:1348,y:700,t:1526933710559};\\\", \\\"{x:1348,y:707,t:1526933710576};\\\", \\\"{x:1349,y:714,t:1526933710591};\\\", \\\"{x:1350,y:720,t:1526933710608};\\\", \\\"{x:1350,y:722,t:1526933710626};\\\", \\\"{x:1351,y:724,t:1526933710642};\\\", \\\"{x:1351,y:729,t:1526933710658};\\\", \\\"{x:1351,y:736,t:1526933710675};\\\", \\\"{x:1351,y:742,t:1526933710692};\\\", \\\"{x:1352,y:747,t:1526933710709};\\\", \\\"{x:1352,y:752,t:1526933710726};\\\", \\\"{x:1353,y:758,t:1526933710742};\\\", \\\"{x:1353,y:763,t:1526933710760};\\\", \\\"{x:1355,y:770,t:1526933710777};\\\", \\\"{x:1355,y:778,t:1526933710791};\\\", \\\"{x:1355,y:783,t:1526933710809};\\\", \\\"{x:1356,y:786,t:1526933710826};\\\", \\\"{x:1356,y:790,t:1526933710842};\\\", \\\"{x:1356,y:795,t:1526933710859};\\\", \\\"{x:1356,y:796,t:1526933710875};\\\", \\\"{x:1356,y:798,t:1526933710892};\\\", \\\"{x:1356,y:799,t:1526933710909};\\\", \\\"{x:1356,y:802,t:1526933710926};\\\", \\\"{x:1356,y:804,t:1526933710942};\\\", \\\"{x:1356,y:806,t:1526933710959};\\\", \\\"{x:1356,y:808,t:1526933710976};\\\", \\\"{x:1356,y:811,t:1526933710992};\\\", \\\"{x:1356,y:812,t:1526933711009};\\\", \\\"{x:1356,y:817,t:1526933711026};\\\", \\\"{x:1356,y:821,t:1526933711042};\\\", \\\"{x:1356,y:826,t:1526933711059};\\\", \\\"{x:1356,y:830,t:1526933711076};\\\", \\\"{x:1356,y:833,t:1526933711092};\\\", \\\"{x:1356,y:835,t:1526933711109};\\\", \\\"{x:1356,y:839,t:1526933711126};\\\", \\\"{x:1356,y:843,t:1526933711143};\\\", \\\"{x:1356,y:847,t:1526933711159};\\\", \\\"{x:1355,y:850,t:1526933711176};\\\", \\\"{x:1355,y:855,t:1526933711193};\\\", \\\"{x:1354,y:858,t:1526933711209};\\\", \\\"{x:1354,y:862,t:1526933711226};\\\", \\\"{x:1352,y:869,t:1526933711243};\\\", \\\"{x:1352,y:876,t:1526933711259};\\\", \\\"{x:1350,y:886,t:1526933711275};\\\", \\\"{x:1349,y:893,t:1526933711293};\\\", \\\"{x:1347,y:902,t:1526933711309};\\\", \\\"{x:1346,y:914,t:1526933711326};\\\", \\\"{x:1343,y:922,t:1526933711343};\\\", \\\"{x:1341,y:929,t:1526933711359};\\\", \\\"{x:1339,y:936,t:1526933711376};\\\", \\\"{x:1338,y:943,t:1526933711394};\\\", \\\"{x:1338,y:950,t:1526933711409};\\\", \\\"{x:1334,y:960,t:1526933711426};\\\", \\\"{x:1331,y:971,t:1526933711443};\\\", \\\"{x:1329,y:975,t:1526933711459};\\\", \\\"{x:1329,y:976,t:1526933711476};\\\", \\\"{x:1329,y:975,t:1526933711691};\\\", \\\"{x:1331,y:974,t:1526933711699};\\\", \\\"{x:1333,y:973,t:1526933711710};\\\", \\\"{x:1336,y:970,t:1526933711726};\\\", \\\"{x:1337,y:969,t:1526933711742};\\\", \\\"{x:1338,y:968,t:1526933711761};\\\", \\\"{x:1338,y:966,t:1526933712228};\\\", \\\"{x:1338,y:965,t:1526933712243};\\\", \\\"{x:1338,y:963,t:1526933712267};\\\", \\\"{x:1338,y:962,t:1526933712315};\\\", \\\"{x:1339,y:962,t:1526933713619};\\\", \\\"{x:1340,y:962,t:1526933713627};\\\", \\\"{x:1341,y:962,t:1526933713657};\\\", \\\"{x:1342,y:962,t:1526933718667};\\\", \\\"{x:1342,y:960,t:1526933718683};\\\", \\\"{x:1342,y:959,t:1526933718698};\\\", \\\"{x:1342,y:957,t:1526933718715};\\\", \\\"{x:1343,y:956,t:1526933718731};\\\", \\\"{x:1343,y:943,t:1526933720555};\\\", \\\"{x:1343,y:930,t:1526933720567};\\\", \\\"{x:1347,y:908,t:1526933720582};\\\", \\\"{x:1347,y:891,t:1526933720599};\\\", \\\"{x:1345,y:873,t:1526933720617};\\\", \\\"{x:1340,y:853,t:1526933720634};\\\", \\\"{x:1336,y:830,t:1526933720650};\\\", \\\"{x:1336,y:796,t:1526933720667};\\\", \\\"{x:1336,y:776,t:1526933720682};\\\", \\\"{x:1335,y:759,t:1526933720699};\\\", \\\"{x:1333,y:744,t:1526933720716};\\\", \\\"{x:1331,y:734,t:1526933720733};\\\", \\\"{x:1331,y:726,t:1526933720749};\\\", \\\"{x:1331,y:721,t:1526933720766};\\\", \\\"{x:1331,y:717,t:1526933720783};\\\", \\\"{x:1331,y:712,t:1526933720799};\\\", \\\"{x:1331,y:708,t:1526933720817};\\\", \\\"{x:1331,y:703,t:1526933720834};\\\", \\\"{x:1331,y:700,t:1526933720850};\\\", \\\"{x:1332,y:697,t:1526933720866};\\\", \\\"{x:1332,y:696,t:1526933720898};\\\", \\\"{x:1334,y:693,t:1526933720917};\\\", \\\"{x:1335,y:691,t:1526933720934};\\\", \\\"{x:1336,y:689,t:1526933720950};\\\", \\\"{x:1337,y:689,t:1526933721003};\\\", \\\"{x:1339,y:690,t:1526933721019};\\\", \\\"{x:1342,y:698,t:1526933721034};\\\", \\\"{x:1354,y:724,t:1526933721050};\\\", \\\"{x:1373,y:784,t:1526933721067};\\\", \\\"{x:1385,y:823,t:1526933721083};\\\", \\\"{x:1388,y:853,t:1526933721101};\\\", \\\"{x:1390,y:868,t:1526933721117};\\\", \\\"{x:1390,y:874,t:1526933721133};\\\", \\\"{x:1390,y:878,t:1526933721151};\\\", \\\"{x:1390,y:880,t:1526933721166};\\\", \\\"{x:1390,y:883,t:1526933721183};\\\", \\\"{x:1389,y:887,t:1526933721199};\\\", \\\"{x:1388,y:889,t:1526933721216};\\\", \\\"{x:1388,y:891,t:1526933721233};\\\", \\\"{x:1387,y:893,t:1526933721249};\\\", \\\"{x:1387,y:895,t:1526933721266};\\\", \\\"{x:1381,y:901,t:1526933721283};\\\", \\\"{x:1373,y:914,t:1526933721300};\\\", \\\"{x:1363,y:927,t:1526933721315};\\\", \\\"{x:1352,y:941,t:1526933721333};\\\", \\\"{x:1343,y:951,t:1526933721350};\\\", \\\"{x:1334,y:962,t:1526933721366};\\\", \\\"{x:1329,y:969,t:1526933721383};\\\", \\\"{x:1329,y:971,t:1526933721400};\\\", \\\"{x:1329,y:972,t:1526933721416};\\\", \\\"{x:1328,y:973,t:1526933721433};\\\", \\\"{x:1328,y:974,t:1526933721515};\\\", \\\"{x:1330,y:975,t:1526933721530};\\\", \\\"{x:1330,y:976,t:1526933721539};\\\", \\\"{x:1332,y:976,t:1526933721550};\\\", \\\"{x:1334,y:976,t:1526933721566};\\\", \\\"{x:1335,y:976,t:1526933721583};\\\", \\\"{x:1336,y:976,t:1526933721600};\\\", \\\"{x:1337,y:976,t:1526933721616};\\\", \\\"{x:1338,y:976,t:1526933721634};\\\", \\\"{x:1339,y:976,t:1526933721651};\\\", \\\"{x:1342,y:976,t:1526933721667};\\\", \\\"{x:1346,y:973,t:1526933721684};\\\", \\\"{x:1349,y:971,t:1526933721700};\\\", \\\"{x:1350,y:971,t:1526933721717};\\\", \\\"{x:1350,y:970,t:1526933721734};\\\", \\\"{x:1352,y:969,t:1526933723835};\\\", \\\"{x:1368,y:969,t:1526933723851};\\\", \\\"{x:1388,y:969,t:1526933723869};\\\", \\\"{x:1400,y:969,t:1526933723886};\\\", \\\"{x:1405,y:969,t:1526933723901};\\\", \\\"{x:1406,y:969,t:1526933723939};\\\", \\\"{x:1406,y:967,t:1526933723955};\\\", \\\"{x:1406,y:966,t:1526933724003};\\\", \\\"{x:1410,y:963,t:1526933724404};\\\", \\\"{x:1421,y:963,t:1526933724419};\\\", \\\"{x:1440,y:963,t:1526933724435};\\\", \\\"{x:1456,y:963,t:1526933724452};\\\", \\\"{x:1469,y:963,t:1526933724469};\\\", \\\"{x:1472,y:963,t:1526933724485};\\\", \\\"{x:1473,y:962,t:1526933724571};\\\", \\\"{x:1474,y:962,t:1526933724595};\\\", \\\"{x:1477,y:962,t:1526933724915};\\\", \\\"{x:1482,y:962,t:1526933724923};\\\", \\\"{x:1491,y:965,t:1526933724937};\\\", \\\"{x:1507,y:966,t:1526933724953};\\\", \\\"{x:1523,y:969,t:1526933724970};\\\", \\\"{x:1542,y:969,t:1526933724986};\\\", \\\"{x:1547,y:969,t:1526933725002};\\\", \\\"{x:1548,y:969,t:1526933725019};\\\", \\\"{x:1549,y:969,t:1526933725043};\\\", \\\"{x:1551,y:969,t:1526933725307};\\\", \\\"{x:1553,y:969,t:1526933725323};\\\", \\\"{x:1567,y:971,t:1526933725340};\\\", \\\"{x:1584,y:973,t:1526933725357};\\\", \\\"{x:1596,y:973,t:1526933725374};\\\", \\\"{x:1611,y:973,t:1526933725391};\\\", \\\"{x:1615,y:973,t:1526933725407};\\\", \\\"{x:1618,y:973,t:1526933725423};\\\", \\\"{x:1620,y:973,t:1526933725535};\\\", \\\"{x:1619,y:973,t:1526933725719};\\\", \\\"{x:1616,y:972,t:1526933725726};\\\", \\\"{x:1615,y:971,t:1526933725741};\\\", \\\"{x:1611,y:971,t:1526933725758};\\\", \\\"{x:1610,y:971,t:1526933725774};\\\", \\\"{x:1609,y:970,t:1526933725791};\\\", \\\"{x:1608,y:970,t:1526933725814};\\\", \\\"{x:1607,y:969,t:1526933725847};\\\", \\\"{x:1606,y:969,t:1526933725858};\\\", \\\"{x:1606,y:968,t:1526933725879};\\\", \\\"{x:1599,y:968,t:1526933732871};\\\", \\\"{x:1591,y:967,t:1526933732879};\\\", \\\"{x:1579,y:967,t:1526933732896};\\\", \\\"{x:1571,y:967,t:1526933732913};\\\", \\\"{x:1565,y:965,t:1526933732929};\\\", \\\"{x:1563,y:964,t:1526933732946};\\\", \\\"{x:1562,y:964,t:1526933732963};\\\", \\\"{x:1561,y:962,t:1526933732981};\\\", \\\"{x:1559,y:959,t:1526933732996};\\\", \\\"{x:1553,y:953,t:1526933733013};\\\", \\\"{x:1539,y:941,t:1526933733031};\\\", \\\"{x:1521,y:921,t:1526933733047};\\\", \\\"{x:1508,y:907,t:1526933733063};\\\", \\\"{x:1499,y:894,t:1526933733080};\\\", \\\"{x:1492,y:879,t:1526933733097};\\\", \\\"{x:1486,y:867,t:1526933733113};\\\", \\\"{x:1481,y:857,t:1526933733130};\\\", \\\"{x:1478,y:850,t:1526933733146};\\\", \\\"{x:1473,y:844,t:1526933733163};\\\", \\\"{x:1470,y:838,t:1526933733180};\\\", \\\"{x:1469,y:835,t:1526933733196};\\\", \\\"{x:1468,y:830,t:1526933733214};\\\", \\\"{x:1466,y:828,t:1526933733231};\\\", \\\"{x:1466,y:826,t:1526933733247};\\\", \\\"{x:1466,y:824,t:1526933733383};\\\", \\\"{x:1467,y:824,t:1526933733399};\\\", \\\"{x:1468,y:824,t:1526933733447};\\\", \\\"{x:1469,y:824,t:1526933733463};\\\", \\\"{x:1470,y:824,t:1526933733487};\\\", \\\"{x:1472,y:824,t:1526933733511};\\\", \\\"{x:1473,y:824,t:1526933733527};\\\", \\\"{x:1475,y:824,t:1526933733544};\\\", \\\"{x:1476,y:824,t:1526933733551};\\\", \\\"{x:1477,y:824,t:1526933733563};\\\", \\\"{x:1478,y:824,t:1526933733580};\\\", \\\"{x:1479,y:824,t:1526933733597};\\\", \\\"{x:1480,y:825,t:1526933733613};\\\", \\\"{x:1481,y:826,t:1526933733630};\\\", \\\"{x:1483,y:827,t:1526933733645};\\\", \\\"{x:1484,y:828,t:1526933733663};\\\", \\\"{x:1486,y:829,t:1526933733679};\\\", \\\"{x:1488,y:831,t:1526933733696};\\\", \\\"{x:1493,y:835,t:1526933733713};\\\", \\\"{x:1498,y:846,t:1526933733729};\\\", \\\"{x:1502,y:855,t:1526933733746};\\\", \\\"{x:1508,y:868,t:1526933733762};\\\", \\\"{x:1509,y:881,t:1526933733779};\\\", \\\"{x:1509,y:891,t:1526933733796};\\\", \\\"{x:1509,y:899,t:1526933733813};\\\", \\\"{x:1509,y:904,t:1526933733830};\\\", \\\"{x:1509,y:910,t:1526933733846};\\\", \\\"{x:1507,y:917,t:1526933733863};\\\", \\\"{x:1504,y:923,t:1526933733879};\\\", \\\"{x:1502,y:929,t:1526933733897};\\\", \\\"{x:1499,y:933,t:1526933733913};\\\", \\\"{x:1499,y:937,t:1526933733929};\\\", \\\"{x:1499,y:938,t:1526933733947};\\\", \\\"{x:1499,y:939,t:1526933733964};\\\", \\\"{x:1499,y:940,t:1526933733980};\\\", \\\"{x:1499,y:941,t:1526933733997};\\\", \\\"{x:1500,y:943,t:1526933734014};\\\", \\\"{x:1502,y:944,t:1526933734030};\\\", \\\"{x:1506,y:946,t:1526933734046};\\\", \\\"{x:1511,y:948,t:1526933734063};\\\", \\\"{x:1517,y:949,t:1526933734080};\\\", \\\"{x:1521,y:950,t:1526933734096};\\\", \\\"{x:1528,y:951,t:1526933734113};\\\", \\\"{x:1533,y:952,t:1526933734130};\\\", \\\"{x:1539,y:952,t:1526933734146};\\\", \\\"{x:1543,y:952,t:1526933734164};\\\", \\\"{x:1546,y:952,t:1526933734180};\\\", \\\"{x:1547,y:952,t:1526933734196};\\\", \\\"{x:1546,y:952,t:1526933734303};\\\", \\\"{x:1544,y:952,t:1526933734314};\\\", \\\"{x:1542,y:951,t:1526933734330};\\\", \\\"{x:1536,y:946,t:1526933734347};\\\", \\\"{x:1529,y:938,t:1526933734363};\\\", \\\"{x:1519,y:926,t:1526933734379};\\\", \\\"{x:1509,y:910,t:1526933734397};\\\", \\\"{x:1502,y:892,t:1526933734414};\\\", \\\"{x:1491,y:859,t:1526933734430};\\\", \\\"{x:1487,y:846,t:1526933734447};\\\", \\\"{x:1484,y:837,t:1526933734464};\\\", \\\"{x:1483,y:834,t:1526933734481};\\\", \\\"{x:1482,y:833,t:1526933734497};\\\", \\\"{x:1481,y:833,t:1526933734544};\\\", \\\"{x:1480,y:832,t:1526933734550};\\\", \\\"{x:1478,y:832,t:1526933734564};\\\", \\\"{x:1468,y:832,t:1526933734582};\\\", \\\"{x:1447,y:832,t:1526933734597};\\\", \\\"{x:1411,y:832,t:1526933734614};\\\", \\\"{x:1304,y:819,t:1526933734631};\\\", \\\"{x:1207,y:806,t:1526933734647};\\\", \\\"{x:1118,y:794,t:1526933734664};\\\", \\\"{x:1029,y:781,t:1526933734681};\\\", \\\"{x:962,y:771,t:1526933734697};\\\", \\\"{x:916,y:760,t:1526933734714};\\\", \\\"{x:872,y:742,t:1526933734731};\\\", \\\"{x:836,y:727,t:1526933734747};\\\", \\\"{x:803,y:714,t:1526933734764};\\\", \\\"{x:780,y:707,t:1526933734780};\\\", \\\"{x:765,y:702,t:1526933734797};\\\", \\\"{x:756,y:699,t:1526933734814};\\\", \\\"{x:744,y:694,t:1526933734830};\\\", \\\"{x:725,y:685,t:1526933734847};\\\", \\\"{x:701,y:674,t:1526933734864};\\\", \\\"{x:675,y:665,t:1526933734881};\\\", \\\"{x:652,y:660,t:1526933734897};\\\", \\\"{x:634,y:654,t:1526933734913};\\\", \\\"{x:617,y:649,t:1526933734931};\\\", \\\"{x:604,y:644,t:1526933734948};\\\", \\\"{x:590,y:633,t:1526933734964};\\\", \\\"{x:576,y:623,t:1526933734983};\\\", \\\"{x:548,y:605,t:1526933734998};\\\", \\\"{x:526,y:593,t:1526933735014};\\\", \\\"{x:506,y:589,t:1526933735029};\\\", \\\"{x:492,y:587,t:1526933735047};\\\", \\\"{x:481,y:587,t:1526933735064};\\\", \\\"{x:476,y:587,t:1526933735082};\\\", \\\"{x:473,y:587,t:1526933735098};\\\", \\\"{x:470,y:587,t:1526933735115};\\\", \\\"{x:468,y:587,t:1526933735132};\\\", \\\"{x:465,y:587,t:1526933735149};\\\", \\\"{x:464,y:587,t:1526933735165};\\\", \\\"{x:464,y:588,t:1526933735190};\\\", \\\"{x:464,y:589,t:1526933735206};\\\", \\\"{x:467,y:590,t:1526933735221};\\\", \\\"{x:473,y:593,t:1526933735231};\\\", \\\"{x:494,y:594,t:1526933735249};\\\", \\\"{x:523,y:594,t:1526933735266};\\\", \\\"{x:560,y:594,t:1526933735283};\\\", \\\"{x:594,y:594,t:1526933735300};\\\", \\\"{x:620,y:594,t:1526933735315};\\\", \\\"{x:639,y:594,t:1526933735333};\\\", \\\"{x:647,y:594,t:1526933735349};\\\", \\\"{x:647,y:593,t:1526933735382};\\\", \\\"{x:647,y:592,t:1526933735406};\\\", \\\"{x:647,y:590,t:1526933735421};\\\", \\\"{x:645,y:590,t:1526933735438};\\\", \\\"{x:643,y:590,t:1526933735449};\\\", \\\"{x:639,y:589,t:1526933735466};\\\", \\\"{x:633,y:587,t:1526933735483};\\\", \\\"{x:630,y:587,t:1526933735500};\\\", \\\"{x:628,y:586,t:1526933735516};\\\", \\\"{x:627,y:586,t:1526933735533};\\\", \\\"{x:625,y:586,t:1526933735550};\\\", \\\"{x:624,y:585,t:1526933735567};\\\", \\\"{x:622,y:584,t:1526933735583};\\\", \\\"{x:619,y:582,t:1526933735601};\\\", \\\"{x:616,y:582,t:1526933735617};\\\", \\\"{x:615,y:582,t:1526933735632};\\\", \\\"{x:614,y:580,t:1526933735650};\\\", \\\"{x:613,y:580,t:1526933735670};\\\", \\\"{x:612,y:580,t:1526933735686};\\\", \\\"{x:611,y:580,t:1526933735702};\\\", \\\"{x:610,y:580,t:1526933735718};\\\", \\\"{x:609,y:579,t:1526933735732};\\\", \\\"{x:608,y:579,t:1526933735750};\\\", \\\"{x:607,y:579,t:1526933735767};\\\", \\\"{x:611,y:581,t:1526933736271};\\\", \\\"{x:632,y:591,t:1526933736285};\\\", \\\"{x:691,y:620,t:1526933736300};\\\", \\\"{x:787,y:656,t:1526933736317};\\\", \\\"{x:951,y:707,t:1526933736333};\\\", \\\"{x:1072,y:738,t:1526933736350};\\\", \\\"{x:1178,y:769,t:1526933736367};\\\", \\\"{x:1271,y:792,t:1526933736384};\\\", \\\"{x:1360,y:808,t:1526933736400};\\\", \\\"{x:1419,y:816,t:1526933736417};\\\", \\\"{x:1463,y:820,t:1526933736434};\\\", \\\"{x:1486,y:821,t:1526933736450};\\\", \\\"{x:1503,y:822,t:1526933736467};\\\", \\\"{x:1511,y:822,t:1526933736484};\\\", \\\"{x:1514,y:822,t:1526933736501};\\\", \\\"{x:1515,y:822,t:1526933736551};\\\", \\\"{x:1518,y:824,t:1526933736567};\\\", \\\"{x:1520,y:824,t:1526933736584};\\\", \\\"{x:1522,y:824,t:1526933736602};\\\", \\\"{x:1523,y:824,t:1526933736617};\\\", \\\"{x:1524,y:826,t:1526933736634};\\\", \\\"{x:1525,y:831,t:1526933736651};\\\", \\\"{x:1525,y:841,t:1526933736667};\\\", \\\"{x:1525,y:856,t:1526933736684};\\\", \\\"{x:1520,y:872,t:1526933736700};\\\", \\\"{x:1515,y:892,t:1526933736717};\\\", \\\"{x:1513,y:900,t:1526933736733};\\\", \\\"{x:1513,y:903,t:1526933736750};\\\", \\\"{x:1512,y:904,t:1526933736767};\\\", \\\"{x:1511,y:906,t:1526933736783};\\\", \\\"{x:1511,y:907,t:1526933736800};\\\", \\\"{x:1511,y:910,t:1526933736818};\\\", \\\"{x:1509,y:911,t:1526933736833};\\\", \\\"{x:1509,y:913,t:1526933736850};\\\", \\\"{x:1508,y:915,t:1526933736868};\\\", \\\"{x:1506,y:917,t:1526933736884};\\\", \\\"{x:1503,y:921,t:1526933736901};\\\", \\\"{x:1497,y:930,t:1526933736917};\\\", \\\"{x:1490,y:937,t:1526933736934};\\\", \\\"{x:1485,y:944,t:1526933736951};\\\", \\\"{x:1478,y:950,t:1526933736968};\\\", \\\"{x:1470,y:954,t:1526933736983};\\\", \\\"{x:1463,y:958,t:1526933737001};\\\", \\\"{x:1460,y:958,t:1526933737018};\\\", \\\"{x:1457,y:959,t:1526933737034};\\\", \\\"{x:1456,y:959,t:1526933737051};\\\", \\\"{x:1456,y:960,t:1526933737068};\\\", \\\"{x:1455,y:960,t:1526933737086};\\\", \\\"{x:1453,y:960,t:1526933737101};\\\", \\\"{x:1450,y:962,t:1526933737118};\\\", \\\"{x:1449,y:962,t:1526933737134};\\\", \\\"{x:1447,y:963,t:1526933737151};\\\", \\\"{x:1444,y:965,t:1526933737168};\\\", \\\"{x:1439,y:967,t:1526933737184};\\\", \\\"{x:1433,y:969,t:1526933737201};\\\", \\\"{x:1427,y:972,t:1526933737217};\\\", \\\"{x:1418,y:975,t:1526933737234};\\\", \\\"{x:1409,y:977,t:1526933737251};\\\", \\\"{x:1403,y:978,t:1526933737268};\\\", \\\"{x:1399,y:978,t:1526933737285};\\\", \\\"{x:1398,y:978,t:1526933737301};\\\", \\\"{x:1395,y:977,t:1526933737318};\\\", \\\"{x:1395,y:976,t:1526933737343};\\\", \\\"{x:1393,y:975,t:1526933737358};\\\", \\\"{x:1392,y:974,t:1526933737374};\\\", \\\"{x:1392,y:973,t:1526933737385};\\\", \\\"{x:1390,y:971,t:1526933737401};\\\", \\\"{x:1387,y:967,t:1526933737418};\\\", \\\"{x:1387,y:963,t:1526933737436};\\\", \\\"{x:1385,y:959,t:1526933737451};\\\", \\\"{x:1384,y:954,t:1526933737468};\\\", \\\"{x:1384,y:952,t:1526933737485};\\\", \\\"{x:1383,y:951,t:1526933737501};\\\", \\\"{x:1383,y:950,t:1526933737623};\\\", \\\"{x:1382,y:950,t:1526933737636};\\\", \\\"{x:1382,y:949,t:1526933737975};\\\", \\\"{x:1382,y:948,t:1526933737985};\\\", \\\"{x:1382,y:947,t:1526933738002};\\\", \\\"{x:1384,y:945,t:1526933738019};\\\", \\\"{x:1385,y:945,t:1526933738036};\\\", \\\"{x:1385,y:944,t:1526933738052};\\\", \\\"{x:1385,y:942,t:1526933738255};\\\", \\\"{x:1385,y:941,t:1526933738269};\\\", \\\"{x:1380,y:934,t:1526933738285};\\\", \\\"{x:1367,y:918,t:1526933738302};\\\", \\\"{x:1358,y:910,t:1526933738319};\\\", \\\"{x:1346,y:899,t:1526933738335};\\\", \\\"{x:1336,y:891,t:1526933738352};\\\", \\\"{x:1329,y:885,t:1526933738369};\\\", \\\"{x:1323,y:880,t:1526933738386};\\\", \\\"{x:1318,y:874,t:1526933738403};\\\", \\\"{x:1313,y:868,t:1526933738420};\\\", \\\"{x:1305,y:864,t:1526933738436};\\\", \\\"{x:1296,y:859,t:1526933738452};\\\", \\\"{x:1286,y:854,t:1526933738470};\\\", \\\"{x:1274,y:849,t:1526933738486};\\\", \\\"{x:1269,y:847,t:1526933738503};\\\", \\\"{x:1262,y:844,t:1526933738519};\\\", \\\"{x:1255,y:844,t:1526933738536};\\\", \\\"{x:1243,y:844,t:1526933738552};\\\", \\\"{x:1232,y:844,t:1526933738569};\\\", \\\"{x:1218,y:844,t:1526933738585};\\\", \\\"{x:1208,y:845,t:1526933738602};\\\", \\\"{x:1201,y:845,t:1526933738619};\\\", \\\"{x:1199,y:846,t:1526933738636};\\\", \\\"{x:1198,y:846,t:1526933738652};\\\", \\\"{x:1199,y:846,t:1526933738927};\\\", \\\"{x:1206,y:842,t:1526933738936};\\\", \\\"{x:1219,y:836,t:1526933738953};\\\", \\\"{x:1240,y:828,t:1526933738969};\\\", \\\"{x:1263,y:821,t:1526933738986};\\\", \\\"{x:1284,y:816,t:1526933739003};\\\", \\\"{x:1301,y:809,t:1526933739019};\\\", \\\"{x:1316,y:803,t:1526933739036};\\\", \\\"{x:1325,y:800,t:1526933739053};\\\", \\\"{x:1330,y:796,t:1526933739069};\\\", \\\"{x:1336,y:792,t:1526933739086};\\\", \\\"{x:1338,y:790,t:1526933739102};\\\", \\\"{x:1341,y:788,t:1526933739119};\\\", \\\"{x:1343,y:785,t:1526933739136};\\\", \\\"{x:1344,y:785,t:1526933739153};\\\", \\\"{x:1345,y:784,t:1526933739169};\\\", \\\"{x:1346,y:784,t:1526933739186};\\\", \\\"{x:1346,y:783,t:1526933739203};\\\", \\\"{x:1346,y:782,t:1526933740111};\\\", \\\"{x:1346,y:781,t:1526933740120};\\\", \\\"{x:1348,y:779,t:1526933740137};\\\", \\\"{x:1350,y:776,t:1526933740154};\\\", \\\"{x:1350,y:775,t:1526933740175};\\\", \\\"{x:1350,y:774,t:1526933740191};\\\", \\\"{x:1351,y:773,t:1526933740255};\\\", \\\"{x:1352,y:772,t:1526933740407};\\\", \\\"{x:1354,y:771,t:1526933740421};\\\", \\\"{x:1357,y:770,t:1526933740437};\\\", \\\"{x:1359,y:768,t:1526933740454};\\\", \\\"{x:1361,y:766,t:1526933740471};\\\", \\\"{x:1361,y:765,t:1526933740487};\\\", \\\"{x:1362,y:764,t:1526933740504};\\\", \\\"{x:1363,y:764,t:1526933740527};\\\", \\\"{x:1363,y:762,t:1526933740718};\\\", \\\"{x:1363,y:760,t:1526933740726};\\\", \\\"{x:1363,y:759,t:1526933740737};\\\", \\\"{x:1363,y:752,t:1526933740754};\\\", \\\"{x:1362,y:743,t:1526933740771};\\\", \\\"{x:1361,y:733,t:1526933740787};\\\", \\\"{x:1361,y:725,t:1526933740804};\\\", \\\"{x:1361,y:715,t:1526933740821};\\\", \\\"{x:1361,y:709,t:1526933740837};\\\", \\\"{x:1361,y:705,t:1526933740855};\\\", \\\"{x:1361,y:703,t:1526933740879};\\\", \\\"{x:1361,y:702,t:1526933741039};\\\", \\\"{x:1360,y:702,t:1526933741055};\\\", \\\"{x:1359,y:702,t:1526933741103};\\\", \\\"{x:1359,y:701,t:1526933741110};\\\", \\\"{x:1358,y:705,t:1526933741230};\\\", \\\"{x:1356,y:712,t:1526933741238};\\\", \\\"{x:1353,y:730,t:1526933741255};\\\", \\\"{x:1350,y:744,t:1526933741271};\\\", \\\"{x:1349,y:754,t:1526933741288};\\\", \\\"{x:1348,y:763,t:1526933741305};\\\", \\\"{x:1348,y:766,t:1526933741320};\\\", \\\"{x:1348,y:768,t:1526933741337};\\\", \\\"{x:1347,y:769,t:1526933741355};\\\", \\\"{x:1348,y:769,t:1526933741911};\\\", \\\"{x:1349,y:769,t:1526933741927};\\\", \\\"{x:1350,y:769,t:1526933742039};\\\", \\\"{x:1351,y:771,t:1526933742095};\\\", \\\"{x:1352,y:772,t:1526933742106};\\\", \\\"{x:1352,y:773,t:1526933742123};\\\", \\\"{x:1352,y:775,t:1526933742139};\\\", \\\"{x:1353,y:779,t:1526933742155};\\\", \\\"{x:1354,y:782,t:1526933742172};\\\", \\\"{x:1355,y:785,t:1526933742190};\\\", \\\"{x:1356,y:788,t:1526933742205};\\\", \\\"{x:1356,y:792,t:1526933742222};\\\", \\\"{x:1357,y:794,t:1526933742239};\\\", \\\"{x:1357,y:798,t:1526933742256};\\\", \\\"{x:1359,y:801,t:1526933742273};\\\", \\\"{x:1359,y:806,t:1526933742290};\\\", \\\"{x:1360,y:811,t:1526933742305};\\\", \\\"{x:1361,y:820,t:1526933742322};\\\", \\\"{x:1364,y:833,t:1526933742339};\\\", \\\"{x:1365,y:843,t:1526933742356};\\\", \\\"{x:1366,y:851,t:1526933742372};\\\", \\\"{x:1367,y:857,t:1526933742389};\\\", \\\"{x:1368,y:862,t:1526933742405};\\\", \\\"{x:1368,y:867,t:1526933742422};\\\", \\\"{x:1370,y:870,t:1526933742439};\\\", \\\"{x:1370,y:874,t:1526933742455};\\\", \\\"{x:1370,y:877,t:1526933742473};\\\", \\\"{x:1370,y:879,t:1526933742490};\\\", \\\"{x:1370,y:881,t:1526933742506};\\\", \\\"{x:1370,y:883,t:1526933742523};\\\", \\\"{x:1370,y:885,t:1526933742539};\\\", \\\"{x:1370,y:888,t:1526933742556};\\\", \\\"{x:1370,y:892,t:1526933742572};\\\", \\\"{x:1370,y:896,t:1526933742589};\\\", \\\"{x:1370,y:901,t:1526933742606};\\\", \\\"{x:1368,y:905,t:1526933742621};\\\", \\\"{x:1367,y:907,t:1526933742639};\\\", \\\"{x:1367,y:908,t:1526933742656};\\\", \\\"{x:1366,y:910,t:1526933742672};\\\", \\\"{x:1366,y:911,t:1526933742694};\\\", \\\"{x:1365,y:912,t:1526933742706};\\\", \\\"{x:1365,y:913,t:1526933742722};\\\", \\\"{x:1364,y:914,t:1526933742739};\\\", \\\"{x:1364,y:916,t:1526933742756};\\\", \\\"{x:1363,y:917,t:1526933742771};\\\", \\\"{x:1363,y:919,t:1526933742789};\\\", \\\"{x:1362,y:921,t:1526933742806};\\\", \\\"{x:1362,y:923,t:1526933742822};\\\", \\\"{x:1361,y:925,t:1526933742839};\\\", \\\"{x:1361,y:928,t:1526933742856};\\\", \\\"{x:1360,y:930,t:1526933742872};\\\", \\\"{x:1360,y:933,t:1526933742889};\\\", \\\"{x:1359,y:935,t:1526933742905};\\\", \\\"{x:1359,y:936,t:1526933742926};\\\", \\\"{x:1359,y:938,t:1526933742939};\\\", \\\"{x:1358,y:939,t:1526933742957};\\\", \\\"{x:1358,y:941,t:1526933742973};\\\", \\\"{x:1358,y:942,t:1526933742989};\\\", \\\"{x:1358,y:944,t:1526933743006};\\\", \\\"{x:1357,y:945,t:1526933743022};\\\", \\\"{x:1357,y:942,t:1526933743159};\\\", \\\"{x:1357,y:938,t:1526933743174};\\\", \\\"{x:1357,y:929,t:1526933743190};\\\", \\\"{x:1357,y:903,t:1526933743206};\\\", \\\"{x:1357,y:883,t:1526933743223};\\\", \\\"{x:1357,y:856,t:1526933743239};\\\", \\\"{x:1357,y:831,t:1526933743257};\\\", \\\"{x:1357,y:808,t:1526933743273};\\\", \\\"{x:1357,y:789,t:1526933743289};\\\", \\\"{x:1357,y:774,t:1526933743307};\\\", \\\"{x:1357,y:764,t:1526933743323};\\\", \\\"{x:1357,y:752,t:1526933743339};\\\", \\\"{x:1357,y:739,t:1526933743356};\\\", \\\"{x:1357,y:730,t:1526933743373};\\\", \\\"{x:1357,y:719,t:1526933743391};\\\", \\\"{x:1357,y:716,t:1526933743406};\\\", \\\"{x:1357,y:712,t:1526933743424};\\\", \\\"{x:1357,y:709,t:1526933743440};\\\", \\\"{x:1357,y:705,t:1526933743457};\\\", \\\"{x:1357,y:702,t:1526933743474};\\\", \\\"{x:1358,y:698,t:1526933743490};\\\", \\\"{x:1360,y:695,t:1526933743507};\\\", \\\"{x:1362,y:691,t:1526933743523};\\\", \\\"{x:1365,y:687,t:1526933743541};\\\", \\\"{x:1368,y:685,t:1526933743556};\\\", \\\"{x:1375,y:681,t:1526933743573};\\\", \\\"{x:1381,y:678,t:1526933743590};\\\", \\\"{x:1386,y:676,t:1526933743606};\\\", \\\"{x:1388,y:675,t:1526933743623};\\\", \\\"{x:1389,y:675,t:1526933743640};\\\", \\\"{x:1390,y:674,t:1526933743656};\\\", \\\"{x:1391,y:674,t:1526933743673};\\\", \\\"{x:1393,y:672,t:1526933743690};\\\", \\\"{x:1396,y:670,t:1526933743706};\\\", \\\"{x:1401,y:669,t:1526933743723};\\\", \\\"{x:1406,y:667,t:1526933743741};\\\", \\\"{x:1413,y:663,t:1526933743757};\\\", \\\"{x:1415,y:662,t:1526933743773};\\\", \\\"{x:1418,y:660,t:1526933743790};\\\", \\\"{x:1419,y:660,t:1526933743807};\\\", \\\"{x:1421,y:657,t:1526933743823};\\\", \\\"{x:1422,y:655,t:1526933743840};\\\", \\\"{x:1424,y:652,t:1526933743857};\\\", \\\"{x:1425,y:650,t:1526933743873};\\\", \\\"{x:1426,y:648,t:1526933743890};\\\", \\\"{x:1427,y:645,t:1526933743907};\\\", \\\"{x:1427,y:644,t:1526933743924};\\\", \\\"{x:1428,y:641,t:1526933743940};\\\", \\\"{x:1429,y:639,t:1526933743957};\\\", \\\"{x:1431,y:636,t:1526933743973};\\\", \\\"{x:1433,y:633,t:1526933743991};\\\", \\\"{x:1435,y:631,t:1526933744007};\\\", \\\"{x:1435,y:630,t:1526933744031};\\\", \\\"{x:1436,y:630,t:1526933744054};\\\", \\\"{x:1436,y:629,t:1526933744063};\\\", \\\"{x:1436,y:628,t:1526933744118};\\\", \\\"{x:1437,y:628,t:1526933744175};\\\", \\\"{x:1438,y:628,t:1526933744191};\\\", \\\"{x:1439,y:628,t:1526933744207};\\\", \\\"{x:1441,y:628,t:1526933744224};\\\", \\\"{x:1443,y:628,t:1526933744327};\\\", \\\"{x:1444,y:628,t:1526933744357};\\\", \\\"{x:1446,y:628,t:1526933744374};\\\", \\\"{x:1447,y:628,t:1526933744438};\\\", \\\"{x:1448,y:628,t:1526933744766};\\\", \\\"{x:1448,y:629,t:1526933744783};\\\", \\\"{x:1448,y:630,t:1526933744791};\\\", \\\"{x:1448,y:635,t:1526933744807};\\\", \\\"{x:1448,y:639,t:1526933744825};\\\", \\\"{x:1450,y:646,t:1526933744841};\\\", \\\"{x:1450,y:651,t:1526933744857};\\\", \\\"{x:1450,y:654,t:1526933744875};\\\", \\\"{x:1451,y:656,t:1526933744892};\\\", \\\"{x:1451,y:657,t:1526933744908};\\\", \\\"{x:1452,y:659,t:1526933744925};\\\", \\\"{x:1452,y:660,t:1526933744942};\\\", \\\"{x:1453,y:665,t:1526933744959};\\\", \\\"{x:1455,y:670,t:1526933744974};\\\", \\\"{x:1455,y:674,t:1526933744991};\\\", \\\"{x:1455,y:680,t:1526933745008};\\\", \\\"{x:1457,y:689,t:1526933745024};\\\", \\\"{x:1459,y:700,t:1526933745041};\\\", \\\"{x:1460,y:717,t:1526933745059};\\\", \\\"{x:1460,y:739,t:1526933745075};\\\", \\\"{x:1460,y:761,t:1526933745092};\\\", \\\"{x:1458,y:781,t:1526933745108};\\\", \\\"{x:1448,y:799,t:1526933745125};\\\", \\\"{x:1435,y:813,t:1526933745141};\\\", \\\"{x:1381,y:827,t:1526933745159};\\\", \\\"{x:1303,y:828,t:1526933745174};\\\", \\\"{x:1209,y:828,t:1526933745192};\\\", \\\"{x:1120,y:828,t:1526933745209};\\\", \\\"{x:1020,y:828,t:1526933745225};\\\", \\\"{x:937,y:820,t:1526933745242};\\\", \\\"{x:875,y:809,t:1526933745258};\\\", \\\"{x:833,y:802,t:1526933745274};\\\", \\\"{x:797,y:796,t:1526933745291};\\\", \\\"{x:767,y:796,t:1526933745308};\\\", \\\"{x:747,y:796,t:1526933745325};\\\", \\\"{x:728,y:796,t:1526933745341};\\\", \\\"{x:703,y:796,t:1526933745358};\\\", \\\"{x:683,y:796,t:1526933745375};\\\", \\\"{x:658,y:797,t:1526933745391};\\\", \\\"{x:632,y:800,t:1526933745409};\\\", \\\"{x:612,y:800,t:1526933745425};\\\", \\\"{x:602,y:799,t:1526933745441};\\\", \\\"{x:598,y:796,t:1526933745459};\\\", \\\"{x:596,y:792,t:1526933745476};\\\", \\\"{x:589,y:778,t:1526933745491};\\\", \\\"{x:577,y:758,t:1526933745508};\\\", \\\"{x:555,y:728,t:1526933745527};\\\", \\\"{x:538,y:708,t:1526933745541};\\\", \\\"{x:521,y:689,t:1526933745558};\\\", \\\"{x:518,y:686,t:1526933745574};\\\", \\\"{x:518,y:685,t:1526933745590};\\\", \\\"{x:517,y:685,t:1526933745621};\\\", \\\"{x:517,y:688,t:1526933745734};\\\", \\\"{x:517,y:690,t:1526933745742};\\\", \\\"{x:519,y:692,t:1526933745757};\\\", \\\"{x:524,y:699,t:1526933745774};\\\", \\\"{x:528,y:705,t:1526933745791};\\\", \\\"{x:529,y:709,t:1526933745807};\\\", \\\"{x:533,y:714,t:1526933745824};\\\", \\\"{x:536,y:718,t:1526933745841};\\\", \\\"{x:537,y:722,t:1526933745859};\\\", \\\"{x:539,y:724,t:1526933745874};\\\", \\\"{x:540,y:727,t:1526933745891};\\\", \\\"{x:540,y:728,t:1526933745908};\\\", \\\"{x:540,y:730,t:1526933745925};\\\", \\\"{x:540,y:732,t:1526933746030};\\\", \\\"{x:540,y:733,t:1526933746046};\\\", \\\"{x:542,y:734,t:1526933746058};\\\", \\\"{x:544,y:734,t:1526933746831};\\\", \\\"{x:552,y:735,t:1526933746842};\\\", \\\"{x:573,y:748,t:1526933746858};\\\", \\\"{x:603,y:766,t:1526933746875};\\\", \\\"{x:634,y:780,t:1526933746893};\\\", \\\"{x:678,y:802,t:1526933746908};\\\", \\\"{x:710,y:821,t:1526933746925};\\\", \\\"{x:735,y:836,t:1526933746941};\\\", \\\"{x:742,y:846,t:1526933746959};\\\", \\\"{x:749,y:848,t:1526933746975};\\\", \\\"{x:750,y:852,t:1526933746991};\\\", \\\"{x:751,y:852,t:1526933747008};\\\" ] }, { \\\"rt\\\": 9121, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 511652, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:752,y:852,t:1526933747541};\\\", \\\"{x:753,y:852,t:1526933747574};\\\", \\\"{x:755,y:852,t:1526933747581};\\\", \\\"{x:759,y:852,t:1526933747597};\\\", \\\"{x:761,y:852,t:1526933747608};\\\", \\\"{x:762,y:852,t:1526933747626};\\\", \\\"{x:764,y:854,t:1526933747646};\\\", \\\"{x:765,y:854,t:1526933747669};\\\", \\\"{x:776,y:854,t:1526933748607};\\\", \\\"{x:799,y:854,t:1526933748614};\\\", \\\"{x:836,y:850,t:1526933748627};\\\", \\\"{x:933,y:838,t:1526933748644};\\\", \\\"{x:1036,y:822,t:1526933748660};\\\", \\\"{x:1139,y:809,t:1526933748677};\\\", \\\"{x:1225,y:794,t:1526933748693};\\\", \\\"{x:1321,y:783,t:1526933748710};\\\", \\\"{x:1360,y:778,t:1526933748727};\\\", \\\"{x:1386,y:773,t:1526933748743};\\\", \\\"{x:1404,y:771,t:1526933748760};\\\", \\\"{x:1418,y:768,t:1526933748777};\\\", \\\"{x:1432,y:766,t:1526933748793};\\\", \\\"{x:1450,y:765,t:1526933748810};\\\", \\\"{x:1472,y:761,t:1526933748827};\\\", \\\"{x:1493,y:756,t:1526933748843};\\\", \\\"{x:1512,y:751,t:1526933748860};\\\", \\\"{x:1529,y:745,t:1526933748878};\\\", \\\"{x:1538,y:744,t:1526933748893};\\\", \\\"{x:1541,y:741,t:1526933748910};\\\", \\\"{x:1543,y:741,t:1526933748975};\\\", \\\"{x:1543,y:739,t:1526933748990};\\\", \\\"{x:1543,y:738,t:1526933749006};\\\", \\\"{x:1544,y:738,t:1526933749014};\\\", \\\"{x:1544,y:736,t:1526933749028};\\\", \\\"{x:1545,y:735,t:1526933749044};\\\", \\\"{x:1545,y:734,t:1526933749063};\\\", \\\"{x:1545,y:733,t:1526933749078};\\\", \\\"{x:1545,y:731,t:1526933749094};\\\", \\\"{x:1545,y:728,t:1526933749111};\\\", \\\"{x:1545,y:726,t:1526933749127};\\\", \\\"{x:1545,y:722,t:1526933749144};\\\", \\\"{x:1545,y:719,t:1526933749160};\\\", \\\"{x:1545,y:716,t:1526933749177};\\\", \\\"{x:1545,y:713,t:1526933749194};\\\", \\\"{x:1545,y:710,t:1526933749211};\\\", \\\"{x:1545,y:708,t:1526933749228};\\\", \\\"{x:1545,y:706,t:1526933749244};\\\", \\\"{x:1545,y:705,t:1526933749260};\\\", \\\"{x:1545,y:704,t:1526933749366};\\\", \\\"{x:1542,y:704,t:1526933749397};\\\", \\\"{x:1541,y:711,t:1526933749410};\\\", \\\"{x:1536,y:736,t:1526933749427};\\\", \\\"{x:1531,y:762,t:1526933749445};\\\", \\\"{x:1527,y:783,t:1526933749460};\\\", \\\"{x:1525,y:801,t:1526933749478};\\\", \\\"{x:1522,y:825,t:1526933749494};\\\", \\\"{x:1520,y:843,t:1526933749510};\\\", \\\"{x:1515,y:858,t:1526933749528};\\\", \\\"{x:1509,y:874,t:1526933749544};\\\", \\\"{x:1504,y:888,t:1526933749560};\\\", \\\"{x:1498,y:900,t:1526933749577};\\\", \\\"{x:1489,y:911,t:1526933749594};\\\", \\\"{x:1477,y:925,t:1526933749610};\\\", \\\"{x:1464,y:936,t:1526933749627};\\\", \\\"{x:1448,y:947,t:1526933749644};\\\", \\\"{x:1427,y:955,t:1526933749660};\\\", \\\"{x:1406,y:963,t:1526933749677};\\\", \\\"{x:1376,y:970,t:1526933749694};\\\", \\\"{x:1360,y:975,t:1526933749712};\\\", \\\"{x:1352,y:976,t:1526933749727};\\\", \\\"{x:1347,y:976,t:1526933749744};\\\", \\\"{x:1346,y:976,t:1526933749765};\\\", \\\"{x:1345,y:976,t:1526933749777};\\\", \\\"{x:1344,y:976,t:1526933749794};\\\", \\\"{x:1339,y:976,t:1526933749811};\\\", \\\"{x:1333,y:975,t:1526933749828};\\\", \\\"{x:1331,y:974,t:1526933749844};\\\", \\\"{x:1330,y:974,t:1526933749878};\\\", \\\"{x:1330,y:972,t:1526933749902};\\\", \\\"{x:1332,y:970,t:1526933749918};\\\", \\\"{x:1334,y:968,t:1526933749928};\\\", \\\"{x:1339,y:964,t:1526933749944};\\\", \\\"{x:1344,y:959,t:1526933749962};\\\", \\\"{x:1349,y:958,t:1526933749978};\\\", \\\"{x:1353,y:955,t:1526933749994};\\\", \\\"{x:1353,y:954,t:1526933750012};\\\", \\\"{x:1354,y:953,t:1526933750027};\\\", \\\"{x:1354,y:950,t:1526933750207};\\\", \\\"{x:1352,y:945,t:1526933750215};\\\", \\\"{x:1350,y:939,t:1526933750229};\\\", \\\"{x:1342,y:919,t:1526933750244};\\\", \\\"{x:1336,y:896,t:1526933750261};\\\", \\\"{x:1334,y:864,t:1526933750278};\\\", \\\"{x:1334,y:841,t:1526933750294};\\\", \\\"{x:1334,y:818,t:1526933750311};\\\", \\\"{x:1335,y:800,t:1526933750328};\\\", \\\"{x:1335,y:788,t:1526933750344};\\\", \\\"{x:1337,y:776,t:1526933750361};\\\", \\\"{x:1338,y:769,t:1526933750378};\\\", \\\"{x:1340,y:761,t:1526933750394};\\\", \\\"{x:1340,y:757,t:1526933750411};\\\", \\\"{x:1342,y:753,t:1526933750428};\\\", \\\"{x:1342,y:751,t:1526933750444};\\\", \\\"{x:1342,y:750,t:1526933750461};\\\", \\\"{x:1342,y:748,t:1526933750478};\\\", \\\"{x:1342,y:746,t:1526933750495};\\\", \\\"{x:1342,y:744,t:1526933750511};\\\", \\\"{x:1342,y:743,t:1526933750534};\\\", \\\"{x:1342,y:742,t:1526933750582};\\\", \\\"{x:1342,y:741,t:1526933750606};\\\", \\\"{x:1342,y:740,t:1526933750622};\\\", \\\"{x:1342,y:739,t:1526933750630};\\\", \\\"{x:1342,y:738,t:1526933750645};\\\", \\\"{x:1342,y:736,t:1526933750661};\\\", \\\"{x:1342,y:732,t:1526933750678};\\\", \\\"{x:1342,y:729,t:1526933750695};\\\", \\\"{x:1342,y:726,t:1526933750710};\\\", \\\"{x:1342,y:724,t:1526933750728};\\\", \\\"{x:1342,y:721,t:1526933750745};\\\", \\\"{x:1342,y:719,t:1526933750761};\\\", \\\"{x:1342,y:717,t:1526933750778};\\\", \\\"{x:1342,y:714,t:1526933750795};\\\", \\\"{x:1342,y:711,t:1526933750811};\\\", \\\"{x:1342,y:707,t:1526933750828};\\\", \\\"{x:1342,y:704,t:1526933750845};\\\", \\\"{x:1342,y:698,t:1526933750863};\\\", \\\"{x:1342,y:697,t:1526933750878};\\\", \\\"{x:1342,y:695,t:1526933750895};\\\", \\\"{x:1342,y:694,t:1526933750952};\\\", \\\"{x:1342,y:692,t:1526933750990};\\\", \\\"{x:1342,y:691,t:1526933751022};\\\", \\\"{x:1342,y:689,t:1526933751063};\\\", \\\"{x:1341,y:689,t:1526933751111};\\\", \\\"{x:1340,y:688,t:1526933751118};\\\", \\\"{x:1336,y:688,t:1526933751129};\\\", \\\"{x:1305,y:691,t:1526933751145};\\\", \\\"{x:1225,y:711,t:1526933751163};\\\", \\\"{x:1114,y:732,t:1526933751179};\\\", \\\"{x:1004,y:740,t:1526933751196};\\\", \\\"{x:921,y:740,t:1526933751212};\\\", \\\"{x:859,y:741,t:1526933751228};\\\", \\\"{x:820,y:741,t:1526933751245};\\\", \\\"{x:785,y:746,t:1526933751262};\\\", \\\"{x:762,y:750,t:1526933751279};\\\", \\\"{x:744,y:751,t:1526933751295};\\\", \\\"{x:742,y:751,t:1526933751313};\\\", \\\"{x:743,y:751,t:1526933751775};\\\", \\\"{x:744,y:751,t:1526933751853};\\\", \\\"{x:749,y:750,t:1526933751862};\\\", \\\"{x:754,y:749,t:1526933751879};\\\", \\\"{x:758,y:747,t:1526933751895};\\\", \\\"{x:777,y:742,t:1526933751912};\\\", \\\"{x:791,y:735,t:1526933751929};\\\", \\\"{x:804,y:727,t:1526933751946};\\\", \\\"{x:809,y:718,t:1526933751962};\\\", \\\"{x:809,y:714,t:1526933751979};\\\", \\\"{x:807,y:705,t:1526933751996};\\\", \\\"{x:801,y:694,t:1526933752012};\\\", \\\"{x:792,y:678,t:1526933752030};\\\", \\\"{x:786,y:663,t:1526933752046};\\\", \\\"{x:780,y:648,t:1526933752062};\\\", \\\"{x:779,y:634,t:1526933752079};\\\", \\\"{x:777,y:620,t:1526933752098};\\\", \\\"{x:777,y:611,t:1526933752112};\\\", \\\"{x:777,y:599,t:1526933752130};\\\", \\\"{x:775,y:587,t:1526933752146};\\\", \\\"{x:773,y:578,t:1526933752163};\\\", \\\"{x:767,y:567,t:1526933752179};\\\", \\\"{x:762,y:556,t:1526933752196};\\\", \\\"{x:753,y:545,t:1526933752214};\\\", \\\"{x:742,y:537,t:1526933752229};\\\", \\\"{x:728,y:528,t:1526933752246};\\\", \\\"{x:712,y:521,t:1526933752263};\\\", \\\"{x:696,y:513,t:1526933752281};\\\", \\\"{x:680,y:505,t:1526933752296};\\\", \\\"{x:669,y:501,t:1526933752312};\\\", \\\"{x:665,y:499,t:1526933752329};\\\", \\\"{x:663,y:498,t:1526933752346};\\\", \\\"{x:662,y:497,t:1526933752362};\\\", \\\"{x:661,y:497,t:1526933752379};\\\", \\\"{x:660,y:497,t:1526933752396};\\\", \\\"{x:657,y:495,t:1526933752412};\\\", \\\"{x:656,y:495,t:1526933752429};\\\", \\\"{x:648,y:495,t:1526933752446};\\\", \\\"{x:640,y:495,t:1526933752463};\\\", \\\"{x:631,y:496,t:1526933752479};\\\", \\\"{x:619,y:500,t:1526933752496};\\\", \\\"{x:612,y:503,t:1526933752513};\\\", \\\"{x:601,y:509,t:1526933752530};\\\", \\\"{x:591,y:515,t:1526933752547};\\\", \\\"{x:579,y:523,t:1526933752564};\\\", \\\"{x:564,y:531,t:1526933752580};\\\", \\\"{x:552,y:537,t:1526933752596};\\\", \\\"{x:538,y:540,t:1526933752613};\\\", \\\"{x:527,y:540,t:1526933752630};\\\", \\\"{x:513,y:542,t:1526933752646};\\\", \\\"{x:496,y:544,t:1526933752664};\\\", \\\"{x:481,y:545,t:1526933752680};\\\", \\\"{x:469,y:546,t:1526933752696};\\\", \\\"{x:457,y:546,t:1526933752713};\\\", \\\"{x:452,y:548,t:1526933752730};\\\", \\\"{x:445,y:549,t:1526933752746};\\\", \\\"{x:437,y:550,t:1526933752763};\\\", \\\"{x:427,y:552,t:1526933752780};\\\", \\\"{x:419,y:554,t:1526933752796};\\\", \\\"{x:409,y:555,t:1526933752813};\\\", \\\"{x:394,y:559,t:1526933752830};\\\", \\\"{x:379,y:560,t:1526933752847};\\\", \\\"{x:358,y:563,t:1526933752864};\\\", \\\"{x:336,y:563,t:1526933752880};\\\", \\\"{x:312,y:563,t:1526933752896};\\\", \\\"{x:284,y:563,t:1526933752913};\\\", \\\"{x:261,y:563,t:1526933752932};\\\", \\\"{x:237,y:563,t:1526933752947};\\\", \\\"{x:222,y:564,t:1526933752963};\\\", \\\"{x:207,y:568,t:1526933752980};\\\", \\\"{x:199,y:567,t:1526933752997};\\\", \\\"{x:198,y:566,t:1526933753013};\\\", \\\"{x:196,y:564,t:1526933753030};\\\", \\\"{x:194,y:560,t:1526933753048};\\\", \\\"{x:185,y:555,t:1526933753065};\\\", \\\"{x:171,y:549,t:1526933753080};\\\", \\\"{x:155,y:543,t:1526933753097};\\\", \\\"{x:142,y:538,t:1526933753114};\\\", \\\"{x:137,y:535,t:1526933753130};\\\", \\\"{x:135,y:534,t:1526933753146};\\\", \\\"{x:135,y:533,t:1526933753163};\\\", \\\"{x:134,y:533,t:1526933753213};\\\", \\\"{x:137,y:533,t:1526933753302};\\\", \\\"{x:140,y:535,t:1526933753314};\\\", \\\"{x:148,y:539,t:1526933753331};\\\", \\\"{x:157,y:543,t:1526933753348};\\\", \\\"{x:161,y:544,t:1526933753364};\\\", \\\"{x:163,y:545,t:1526933753381};\\\", \\\"{x:164,y:545,t:1526933753398};\\\", \\\"{x:163,y:545,t:1526933753558};\\\", \\\"{x:162,y:545,t:1526933753566};\\\", \\\"{x:161,y:545,t:1526933753590};\\\", \\\"{x:160,y:545,t:1526933753606};\\\", \\\"{x:161,y:545,t:1526933754151};\\\", \\\"{x:167,y:546,t:1526933754164};\\\", \\\"{x:194,y:560,t:1526933754184};\\\", \\\"{x:217,y:570,t:1526933754198};\\\", \\\"{x:234,y:576,t:1526933754214};\\\", \\\"{x:249,y:583,t:1526933754231};\\\", \\\"{x:258,y:586,t:1526933754247};\\\", \\\"{x:263,y:589,t:1526933754264};\\\", \\\"{x:266,y:591,t:1526933754282};\\\", \\\"{x:270,y:594,t:1526933754297};\\\", \\\"{x:274,y:597,t:1526933754314};\\\", \\\"{x:278,y:600,t:1526933754331};\\\", \\\"{x:280,y:602,t:1526933754349};\\\", \\\"{x:285,y:605,t:1526933754365};\\\", \\\"{x:289,y:608,t:1526933754381};\\\", \\\"{x:295,y:612,t:1526933754397};\\\", \\\"{x:300,y:615,t:1526933754415};\\\", \\\"{x:306,y:617,t:1526933754431};\\\", \\\"{x:310,y:620,t:1526933754448};\\\", \\\"{x:316,y:620,t:1526933754464};\\\", \\\"{x:323,y:621,t:1526933754482};\\\", \\\"{x:328,y:621,t:1526933754498};\\\", \\\"{x:336,y:621,t:1526933754514};\\\", \\\"{x:343,y:621,t:1526933754532};\\\", \\\"{x:349,y:621,t:1526933754548};\\\", \\\"{x:355,y:619,t:1526933754564};\\\", \\\"{x:371,y:614,t:1526933754582};\\\", \\\"{x:389,y:612,t:1526933754598};\\\", \\\"{x:408,y:609,t:1526933754615};\\\", \\\"{x:432,y:604,t:1526933754632};\\\", \\\"{x:458,y:602,t:1526933754648};\\\", \\\"{x:486,y:597,t:1526933754665};\\\", \\\"{x:517,y:593,t:1526933754682};\\\", \\\"{x:544,y:590,t:1526933754699};\\\", \\\"{x:571,y:587,t:1526933754716};\\\", \\\"{x:594,y:585,t:1526933754731};\\\", \\\"{x:615,y:581,t:1526933754749};\\\", \\\"{x:646,y:578,t:1526933754766};\\\", \\\"{x:668,y:575,t:1526933754781};\\\", \\\"{x:690,y:570,t:1526933754798};\\\", \\\"{x:704,y:568,t:1526933754815};\\\", \\\"{x:716,y:565,t:1526933754831};\\\", \\\"{x:718,y:565,t:1526933754848};\\\", \\\"{x:723,y:565,t:1526933754864};\\\", \\\"{x:724,y:565,t:1526933754882};\\\", \\\"{x:727,y:563,t:1526933754898};\\\", \\\"{x:728,y:563,t:1526933754915};\\\", \\\"{x:729,y:561,t:1526933754932};\\\", \\\"{x:731,y:558,t:1526933754949};\\\", \\\"{x:731,y:552,t:1526933754966};\\\", \\\"{x:731,y:547,t:1526933754982};\\\", \\\"{x:731,y:541,t:1526933754998};\\\", \\\"{x:730,y:536,t:1526933755015};\\\", \\\"{x:727,y:528,t:1526933755032};\\\", \\\"{x:726,y:521,t:1526933755049};\\\", \\\"{x:726,y:516,t:1526933755066};\\\", \\\"{x:728,y:512,t:1526933755081};\\\", \\\"{x:736,y:506,t:1526933755099};\\\", \\\"{x:750,y:501,t:1526933755115};\\\", \\\"{x:769,y:497,t:1526933755132};\\\", \\\"{x:788,y:494,t:1526933755148};\\\", \\\"{x:816,y:492,t:1526933755165};\\\", \\\"{x:831,y:492,t:1526933755182};\\\", \\\"{x:839,y:491,t:1526933755198};\\\", \\\"{x:842,y:491,t:1526933755215};\\\", \\\"{x:843,y:491,t:1526933755232};\\\", \\\"{x:844,y:491,t:1526933755294};\\\", \\\"{x:845,y:491,t:1526933755309};\\\", \\\"{x:846,y:491,t:1526933755334};\\\", \\\"{x:847,y:491,t:1526933755349};\\\", \\\"{x:848,y:492,t:1526933755365};\\\", \\\"{x:848,y:493,t:1526933755389};\\\", \\\"{x:848,y:494,t:1526933755438};\\\", \\\"{x:848,y:497,t:1526933755448};\\\", \\\"{x:848,y:498,t:1526933755466};\\\", \\\"{x:848,y:501,t:1526933755483};\\\", \\\"{x:847,y:502,t:1526933755499};\\\", \\\"{x:846,y:503,t:1526933755551};\\\", \\\"{x:844,y:504,t:1526933755566};\\\", \\\"{x:843,y:505,t:1526933755582};\\\", \\\"{x:842,y:506,t:1526933755606};\\\", \\\"{x:841,y:507,t:1526933755982};\\\", \\\"{x:820,y:515,t:1526933756000};\\\", \\\"{x:782,y:529,t:1526933756017};\\\", \\\"{x:732,y:552,t:1526933756033};\\\", \\\"{x:666,y:579,t:1526933756052};\\\", \\\"{x:599,y:613,t:1526933756066};\\\", \\\"{x:534,y:647,t:1526933756083};\\\", \\\"{x:488,y:675,t:1526933756099};\\\", \\\"{x:465,y:687,t:1526933756116};\\\", \\\"{x:454,y:695,t:1526933756132};\\\", \\\"{x:448,y:699,t:1526933756149};\\\", \\\"{x:446,y:700,t:1526933756167};\\\", \\\"{x:445,y:701,t:1526933756183};\\\", \\\"{x:445,y:702,t:1526933756205};\\\", \\\"{x:445,y:703,t:1526933756216};\\\", \\\"{x:445,y:705,t:1526933756233};\\\", \\\"{x:445,y:709,t:1526933756250};\\\", \\\"{x:445,y:717,t:1526933756266};\\\", \\\"{x:445,y:723,t:1526933756282};\\\", \\\"{x:445,y:727,t:1526933756301};\\\", \\\"{x:445,y:728,t:1526933756316};\\\", \\\"{x:445,y:729,t:1526933756350};\\\", \\\"{x:445,y:730,t:1526933756366};\\\", \\\"{x:447,y:732,t:1526933756383};\\\", \\\"{x:449,y:734,t:1526933756398};\\\", \\\"{x:453,y:736,t:1526933756416};\\\", \\\"{x:455,y:736,t:1526933756942};\\\", \\\"{x:463,y:736,t:1526933756950};\\\", \\\"{x:491,y:738,t:1526933756967};\\\", \\\"{x:530,y:738,t:1526933756983};\\\", \\\"{x:598,y:740,t:1526933756999};\\\", \\\"{x:665,y:742,t:1526933757017};\\\", \\\"{x:735,y:752,t:1526933757033};\\\", \\\"{x:796,y:760,t:1526933757049};\\\", \\\"{x:846,y:773,t:1526933757067};\\\", \\\"{x:879,y:781,t:1526933757084};\\\", \\\"{x:901,y:786,t:1526933757099};\\\", \\\"{x:916,y:790,t:1526933757116};\\\", \\\"{x:927,y:791,t:1526933757134};\\\", \\\"{x:930,y:792,t:1526933757150};\\\", \\\"{x:931,y:792,t:1526933757167};\\\" ] }, { \\\"rt\\\": 8339, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 521230, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:935,y:792,t:1526933759479};\\\", \\\"{x:948,y:792,t:1526933759486};\\\", \\\"{x:974,y:789,t:1526933759501};\\\", \\\"{x:1003,y:789,t:1526933759519};\\\", \\\"{x:1040,y:789,t:1526933759536};\\\", \\\"{x:1069,y:789,t:1526933759552};\\\", \\\"{x:1104,y:783,t:1526933759569};\\\", \\\"{x:1145,y:779,t:1526933759586};\\\", \\\"{x:1182,y:774,t:1526933759602};\\\", \\\"{x:1210,y:768,t:1526933759619};\\\", \\\"{x:1243,y:763,t:1526933759636};\\\", \\\"{x:1276,y:754,t:1526933759654};\\\", \\\"{x:1310,y:738,t:1526933759669};\\\", \\\"{x:1351,y:721,t:1526933759686};\\\", \\\"{x:1367,y:713,t:1526933759702};\\\", \\\"{x:1377,y:706,t:1526933759718};\\\", \\\"{x:1382,y:700,t:1526933759736};\\\", \\\"{x:1382,y:697,t:1526933759753};\\\", \\\"{x:1382,y:695,t:1526933759769};\\\", \\\"{x:1382,y:691,t:1526933759785};\\\", \\\"{x:1380,y:689,t:1526933759803};\\\", \\\"{x:1379,y:687,t:1526933759819};\\\", \\\"{x:1378,y:684,t:1526933759836};\\\", \\\"{x:1377,y:683,t:1526933759853};\\\", \\\"{x:1374,y:682,t:1526933759869};\\\", \\\"{x:1369,y:681,t:1526933759886};\\\", \\\"{x:1366,y:681,t:1526933759902};\\\", \\\"{x:1363,y:681,t:1526933759919};\\\", \\\"{x:1362,y:681,t:1526933759936};\\\", \\\"{x:1360,y:684,t:1526933759953};\\\", \\\"{x:1360,y:688,t:1526933759969};\\\", \\\"{x:1359,y:694,t:1526933759986};\\\", \\\"{x:1358,y:697,t:1526933760003};\\\", \\\"{x:1357,y:701,t:1526933760019};\\\", \\\"{x:1355,y:703,t:1526933760036};\\\", \\\"{x:1353,y:707,t:1526933760053};\\\", \\\"{x:1352,y:709,t:1526933760069};\\\", \\\"{x:1351,y:709,t:1526933760087};\\\", \\\"{x:1350,y:709,t:1526933760127};\\\", \\\"{x:1349,y:709,t:1526933760136};\\\", \\\"{x:1348,y:709,t:1526933760153};\\\", \\\"{x:1347,y:709,t:1526933760170};\\\", \\\"{x:1346,y:709,t:1526933760186};\\\", \\\"{x:1345,y:709,t:1526933760926};\\\", \\\"{x:1345,y:710,t:1526933760937};\\\", \\\"{x:1346,y:713,t:1526933760953};\\\", \\\"{x:1347,y:719,t:1526933760970};\\\", \\\"{x:1348,y:725,t:1526933760987};\\\", \\\"{x:1349,y:733,t:1526933761003};\\\", \\\"{x:1351,y:745,t:1526933761020};\\\", \\\"{x:1351,y:751,t:1526933761037};\\\", \\\"{x:1352,y:758,t:1526933761054};\\\", \\\"{x:1352,y:766,t:1526933761072};\\\", \\\"{x:1353,y:769,t:1526933761087};\\\", \\\"{x:1353,y:772,t:1526933761104};\\\", \\\"{x:1355,y:773,t:1526933761119};\\\", \\\"{x:1351,y:773,t:1526933761351};\\\", \\\"{x:1343,y:772,t:1526933761358};\\\", \\\"{x:1333,y:769,t:1526933761370};\\\", \\\"{x:1293,y:751,t:1526933761387};\\\", \\\"{x:1227,y:723,t:1526933761404};\\\", \\\"{x:1130,y:683,t:1526933761420};\\\", \\\"{x:1020,y:633,t:1526933761437};\\\", \\\"{x:875,y:570,t:1526933761455};\\\", \\\"{x:825,y:546,t:1526933761471};\\\", \\\"{x:787,y:523,t:1526933761503};\\\", \\\"{x:785,y:521,t:1526933761519};\\\", \\\"{x:785,y:520,t:1526933761549};\\\", \\\"{x:785,y:518,t:1526933761573};\\\", \\\"{x:784,y:517,t:1526933761586};\\\", \\\"{x:783,y:515,t:1526933761603};\\\", \\\"{x:782,y:515,t:1526933761620};\\\", \\\"{x:781,y:514,t:1526933761636};\\\", \\\"{x:775,y:513,t:1526933761653};\\\", \\\"{x:768,y:513,t:1526933761670};\\\", \\\"{x:758,y:515,t:1526933761688};\\\", \\\"{x:746,y:518,t:1526933761705};\\\", \\\"{x:733,y:522,t:1526933761720};\\\", \\\"{x:716,y:527,t:1526933761738};\\\", \\\"{x:700,y:532,t:1526933761753};\\\", \\\"{x:681,y:536,t:1526933761770};\\\", \\\"{x:665,y:538,t:1526933761788};\\\", \\\"{x:654,y:540,t:1526933761803};\\\", \\\"{x:647,y:540,t:1526933761821};\\\", \\\"{x:645,y:540,t:1526933761837};\\\", \\\"{x:644,y:540,t:1526933761853};\\\", \\\"{x:641,y:540,t:1526933761871};\\\", \\\"{x:637,y:540,t:1526933761888};\\\", \\\"{x:630,y:540,t:1526933761904};\\\", \\\"{x:620,y:540,t:1526933761921};\\\", \\\"{x:610,y:540,t:1526933761938};\\\", \\\"{x:600,y:540,t:1526933761955};\\\", \\\"{x:587,y:540,t:1526933761971};\\\", \\\"{x:573,y:540,t:1526933761988};\\\", \\\"{x:559,y:540,t:1526933762004};\\\", \\\"{x:545,y:540,t:1526933762021};\\\", \\\"{x:529,y:540,t:1526933762037};\\\", \\\"{x:518,y:540,t:1526933762055};\\\", \\\"{x:505,y:540,t:1526933762070};\\\", \\\"{x:491,y:542,t:1526933762089};\\\", \\\"{x:481,y:542,t:1526933762105};\\\", \\\"{x:470,y:546,t:1526933762121};\\\", \\\"{x:464,y:549,t:1526933762137};\\\", \\\"{x:455,y:552,t:1526933762154};\\\", \\\"{x:446,y:555,t:1526933762170};\\\", \\\"{x:438,y:560,t:1526933762187};\\\", \\\"{x:426,y:566,t:1526933762205};\\\", \\\"{x:415,y:571,t:1526933762221};\\\", \\\"{x:398,y:579,t:1526933762237};\\\", \\\"{x:381,y:586,t:1526933762255};\\\", \\\"{x:358,y:589,t:1526933762271};\\\", \\\"{x:329,y:594,t:1526933762288};\\\", \\\"{x:301,y:597,t:1526933762304};\\\", \\\"{x:278,y:599,t:1526933762321};\\\", \\\"{x:260,y:599,t:1526933762337};\\\", \\\"{x:252,y:599,t:1526933762355};\\\", \\\"{x:250,y:599,t:1526933762372};\\\", \\\"{x:249,y:599,t:1526933762397};\\\", \\\"{x:248,y:599,t:1526933762405};\\\", \\\"{x:246,y:596,t:1526933762422};\\\", \\\"{x:243,y:593,t:1526933762440};\\\", \\\"{x:236,y:587,t:1526933762456};\\\", \\\"{x:230,y:582,t:1526933762472};\\\", \\\"{x:223,y:575,t:1526933762488};\\\", \\\"{x:214,y:568,t:1526933762504};\\\", \\\"{x:207,y:561,t:1526933762522};\\\", \\\"{x:199,y:553,t:1526933762538};\\\", \\\"{x:194,y:546,t:1526933762555};\\\", \\\"{x:190,y:544,t:1526933762572};\\\", \\\"{x:188,y:542,t:1526933762587};\\\", \\\"{x:184,y:540,t:1526933762605};\\\", \\\"{x:181,y:539,t:1526933762620};\\\", \\\"{x:177,y:538,t:1526933762637};\\\", \\\"{x:176,y:537,t:1526933762655};\\\", \\\"{x:174,y:536,t:1526933762670};\\\", \\\"{x:171,y:536,t:1526933762687};\\\", \\\"{x:170,y:536,t:1526933762704};\\\", \\\"{x:167,y:536,t:1526933762721};\\\", \\\"{x:166,y:536,t:1526933762737};\\\", \\\"{x:164,y:536,t:1526933762755};\\\", \\\"{x:163,y:536,t:1526933762814};\\\", \\\"{x:162,y:536,t:1526933762830};\\\", \\\"{x:161,y:536,t:1526933762838};\\\", \\\"{x:160,y:536,t:1526933762854};\\\", \\\"{x:158,y:536,t:1526933762871};\\\", \\\"{x:157,y:536,t:1526933762958};\\\", \\\"{x:157,y:537,t:1526933765390};\\\", \\\"{x:176,y:562,t:1526933765408};\\\", \\\"{x:203,y:599,t:1526933765423};\\\", \\\"{x:236,y:647,t:1526933765440};\\\", \\\"{x:270,y:699,t:1526933765457};\\\", \\\"{x:302,y:742,t:1526933765474};\\\", \\\"{x:325,y:774,t:1526933765490};\\\", \\\"{x:342,y:795,t:1526933765506};\\\", \\\"{x:353,y:806,t:1526933765523};\\\", \\\"{x:358,y:810,t:1526933765540};\\\", \\\"{x:360,y:810,t:1526933765557};\\\", \\\"{x:362,y:810,t:1526933765597};\\\", \\\"{x:364,y:810,t:1526933765606};\\\", \\\"{x:369,y:810,t:1526933765623};\\\", \\\"{x:381,y:810,t:1526933765641};\\\", \\\"{x:396,y:807,t:1526933765656};\\\", \\\"{x:414,y:801,t:1526933765674};\\\", \\\"{x:430,y:792,t:1526933765691};\\\", \\\"{x:442,y:787,t:1526933765707};\\\", \\\"{x:453,y:781,t:1526933765724};\\\", \\\"{x:461,y:777,t:1526933765740};\\\", \\\"{x:469,y:772,t:1526933765757};\\\", \\\"{x:486,y:762,t:1526933765773};\\\", \\\"{x:497,y:756,t:1526933765791};\\\", \\\"{x:501,y:753,t:1526933765810};\\\", \\\"{x:505,y:751,t:1526933765824};\\\", \\\"{x:506,y:750,t:1526933765839};\\\", \\\"{x:506,y:749,t:1526933765856};\\\", \\\"{x:506,y:747,t:1526933765873};\\\", \\\"{x:509,y:743,t:1526933765890};\\\", \\\"{x:509,y:738,t:1526933765907};\\\", \\\"{x:510,y:734,t:1526933765924};\\\", \\\"{x:511,y:731,t:1526933765940};\\\", \\\"{x:511,y:729,t:1526933765957};\\\" ] }, { \\\"rt\\\": 67129, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 589702, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L -Z -Z -Z -Z -04 PM-O -X -X -X -C -Z -Z -Z -B -X -X -X -C -O -O -O -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:726,t:1526933771118};\\\", \\\"{x:553,y:724,t:1526933771129};\\\", \\\"{x:649,y:716,t:1526933771147};\\\", \\\"{x:710,y:716,t:1526933771162};\\\", \\\"{x:785,y:716,t:1526933771179};\\\", \\\"{x:866,y:716,t:1526933771195};\\\", \\\"{x:930,y:716,t:1526933771211};\\\", \\\"{x:1008,y:716,t:1526933771228};\\\", \\\"{x:1095,y:714,t:1526933771245};\\\", \\\"{x:1127,y:713,t:1526933771261};\\\", \\\"{x:1158,y:711,t:1526933771284};\\\", \\\"{x:1191,y:708,t:1526933771295};\\\", \\\"{x:1252,y:690,t:1526933771312};\\\", \\\"{x:1316,y:670,t:1526933771328};\\\", \\\"{x:1379,y:648,t:1526933771345};\\\", \\\"{x:1438,y:630,t:1526933771362};\\\", \\\"{x:1479,y:612,t:1526933771379};\\\", \\\"{x:1507,y:594,t:1526933771395};\\\", \\\"{x:1527,y:577,t:1526933771412};\\\", \\\"{x:1542,y:556,t:1526933771430};\\\", \\\"{x:1547,y:542,t:1526933771445};\\\", \\\"{x:1548,y:528,t:1526933771462};\\\", \\\"{x:1548,y:513,t:1526933771479};\\\", \\\"{x:1548,y:497,t:1526933771495};\\\", \\\"{x:1548,y:480,t:1526933771512};\\\", \\\"{x:1548,y:467,t:1526933771529};\\\", \\\"{x:1548,y:455,t:1526933771545};\\\", \\\"{x:1548,y:444,t:1526933771562};\\\", \\\"{x:1548,y:435,t:1526933771579};\\\", \\\"{x:1548,y:426,t:1526933771595};\\\", \\\"{x:1548,y:420,t:1526933771612};\\\", \\\"{x:1548,y:413,t:1526933771629};\\\", \\\"{x:1548,y:410,t:1526933771645};\\\", \\\"{x:1548,y:407,t:1526933771663};\\\", \\\"{x:1548,y:405,t:1526933771686};\\\", \\\"{x:1547,y:405,t:1526933771696};\\\", \\\"{x:1546,y:404,t:1526933771713};\\\", \\\"{x:1546,y:402,t:1526933771783};\\\", \\\"{x:1546,y:408,t:1526933772039};\\\", \\\"{x:1546,y:412,t:1526933772046};\\\", \\\"{x:1548,y:421,t:1526933772064};\\\", \\\"{x:1551,y:427,t:1526933772079};\\\", \\\"{x:1552,y:431,t:1526933772096};\\\", \\\"{x:1553,y:435,t:1526933772114};\\\", \\\"{x:1555,y:439,t:1526933772130};\\\", \\\"{x:1557,y:445,t:1526933772147};\\\", \\\"{x:1560,y:451,t:1526933772164};\\\", \\\"{x:1563,y:459,t:1526933772180};\\\", \\\"{x:1567,y:467,t:1526933772196};\\\", \\\"{x:1571,y:479,t:1526933772214};\\\", \\\"{x:1576,y:489,t:1526933772230};\\\", \\\"{x:1580,y:499,t:1526933772249};\\\", \\\"{x:1583,y:514,t:1526933772264};\\\", \\\"{x:1588,y:529,t:1526933772280};\\\", \\\"{x:1593,y:545,t:1526933772295};\\\", \\\"{x:1596,y:557,t:1526933772313};\\\", \\\"{x:1601,y:571,t:1526933772330};\\\", \\\"{x:1603,y:582,t:1526933772346};\\\", \\\"{x:1606,y:588,t:1526933772363};\\\", \\\"{x:1608,y:597,t:1526933772380};\\\", \\\"{x:1610,y:606,t:1526933772396};\\\", \\\"{x:1611,y:618,t:1526933772413};\\\", \\\"{x:1614,y:624,t:1526933772429};\\\", \\\"{x:1614,y:630,t:1526933772446};\\\", \\\"{x:1615,y:633,t:1526933772463};\\\", \\\"{x:1616,y:637,t:1526933772480};\\\", \\\"{x:1618,y:641,t:1526933772496};\\\", \\\"{x:1618,y:644,t:1526933772513};\\\", \\\"{x:1618,y:647,t:1526933772530};\\\", \\\"{x:1619,y:649,t:1526933772547};\\\", \\\"{x:1619,y:654,t:1526933772563};\\\", \\\"{x:1620,y:656,t:1526933772580};\\\", \\\"{x:1621,y:662,t:1526933772597};\\\", \\\"{x:1622,y:666,t:1526933772613};\\\", \\\"{x:1622,y:668,t:1526933772630};\\\", \\\"{x:1622,y:669,t:1526933772647};\\\", \\\"{x:1622,y:670,t:1526933772663};\\\", \\\"{x:1622,y:671,t:1526933772680};\\\", \\\"{x:1623,y:673,t:1526933772698};\\\", \\\"{x:1623,y:674,t:1526933772713};\\\", \\\"{x:1623,y:676,t:1526933772730};\\\", \\\"{x:1624,y:678,t:1526933772748};\\\", \\\"{x:1624,y:679,t:1526933772764};\\\", \\\"{x:1624,y:683,t:1526933772780};\\\", \\\"{x:1625,y:686,t:1526933772797};\\\", \\\"{x:1625,y:689,t:1526933772813};\\\", \\\"{x:1626,y:689,t:1526933772831};\\\", \\\"{x:1626,y:691,t:1526933772848};\\\", \\\"{x:1626,y:692,t:1526933772864};\\\", \\\"{x:1627,y:695,t:1526933772880};\\\", \\\"{x:1628,y:695,t:1526933772897};\\\", \\\"{x:1629,y:697,t:1526933772914};\\\", \\\"{x:1629,y:698,t:1526933772931};\\\", \\\"{x:1629,y:700,t:1526933772950};\\\", \\\"{x:1629,y:701,t:1526933772966};\\\", \\\"{x:1631,y:703,t:1526933772982};\\\", \\\"{x:1631,y:704,t:1526933773006};\\\", \\\"{x:1631,y:705,t:1526933773021};\\\", \\\"{x:1631,y:706,t:1526933773030};\\\", \\\"{x:1631,y:707,t:1526933773048};\\\", \\\"{x:1632,y:708,t:1526933773064};\\\", \\\"{x:1632,y:709,t:1526933773081};\\\", \\\"{x:1632,y:710,t:1526933773098};\\\", \\\"{x:1634,y:713,t:1526933773114};\\\", \\\"{x:1634,y:714,t:1526933773134};\\\", \\\"{x:1634,y:715,t:1526933773148};\\\", \\\"{x:1634,y:716,t:1526933773165};\\\", \\\"{x:1634,y:717,t:1526933773182};\\\", \\\"{x:1634,y:718,t:1526933773214};\\\", \\\"{x:1634,y:717,t:1526933773431};\\\", \\\"{x:1634,y:716,t:1526933773438};\\\", \\\"{x:1633,y:713,t:1526933773449};\\\", \\\"{x:1633,y:712,t:1526933773464};\\\", \\\"{x:1630,y:708,t:1526933773481};\\\", \\\"{x:1630,y:704,t:1526933773499};\\\", \\\"{x:1628,y:701,t:1526933773515};\\\", \\\"{x:1627,y:698,t:1526933773531};\\\", \\\"{x:1626,y:697,t:1526933773548};\\\", \\\"{x:1624,y:695,t:1526933773564};\\\", \\\"{x:1621,y:694,t:1526933773581};\\\", \\\"{x:1618,y:692,t:1526933773599};\\\", \\\"{x:1617,y:691,t:1526933773632};\\\", \\\"{x:1615,y:691,t:1526933773808};\\\", \\\"{x:1614,y:692,t:1526933773837};\\\", \\\"{x:1614,y:693,t:1526933773885};\\\", \\\"{x:1614,y:694,t:1526933773909};\\\", \\\"{x:1614,y:695,t:1526933773925};\\\", \\\"{x:1613,y:695,t:1526933773966};\\\", \\\"{x:1612,y:696,t:1526933773981};\\\", \\\"{x:1611,y:696,t:1526933774014};\\\", \\\"{x:1610,y:696,t:1526933774021};\\\", \\\"{x:1609,y:697,t:1526933774038};\\\", \\\"{x:1609,y:698,t:1526933774049};\\\", \\\"{x:1608,y:698,t:1526933774066};\\\", \\\"{x:1609,y:697,t:1526933774503};\\\", \\\"{x:1610,y:697,t:1526933774558};\\\", \\\"{x:1611,y:697,t:1526933774574};\\\", \\\"{x:1611,y:696,t:1526933774598};\\\", \\\"{x:1613,y:696,t:1526933774621};\\\", \\\"{x:1613,y:695,t:1526933774670};\\\", \\\"{x:1614,y:694,t:1526933774682};\\\", \\\"{x:1614,y:695,t:1526933776934};\\\", \\\"{x:1614,y:697,t:1526933776942};\\\", \\\"{x:1614,y:698,t:1526933776953};\\\", \\\"{x:1615,y:700,t:1526933776968};\\\", \\\"{x:1615,y:701,t:1526933776985};\\\", \\\"{x:1615,y:702,t:1526933777003};\\\", \\\"{x:1615,y:703,t:1526933777020};\\\", \\\"{x:1616,y:704,t:1526933777036};\\\", \\\"{x:1616,y:706,t:1526933777053};\\\", \\\"{x:1616,y:709,t:1526933777070};\\\", \\\"{x:1616,y:712,t:1526933777086};\\\", \\\"{x:1617,y:713,t:1526933777102};\\\", \\\"{x:1618,y:716,t:1526933777120};\\\", \\\"{x:1618,y:719,t:1526933777135};\\\", \\\"{x:1618,y:723,t:1526933777152};\\\", \\\"{x:1618,y:727,t:1526933777170};\\\", \\\"{x:1619,y:734,t:1526933777184};\\\", \\\"{x:1621,y:738,t:1526933777201};\\\", \\\"{x:1622,y:746,t:1526933777220};\\\", \\\"{x:1623,y:752,t:1526933777235};\\\", \\\"{x:1625,y:759,t:1526933777252};\\\", \\\"{x:1626,y:769,t:1526933777268};\\\", \\\"{x:1626,y:775,t:1526933777285};\\\", \\\"{x:1628,y:786,t:1526933777302};\\\", \\\"{x:1629,y:797,t:1526933777319};\\\", \\\"{x:1629,y:808,t:1526933777336};\\\", \\\"{x:1630,y:818,t:1526933777352};\\\", \\\"{x:1630,y:826,t:1526933777369};\\\", \\\"{x:1630,y:834,t:1526933777386};\\\", \\\"{x:1631,y:842,t:1526933777402};\\\", \\\"{x:1631,y:851,t:1526933777420};\\\", \\\"{x:1631,y:863,t:1526933777437};\\\", \\\"{x:1631,y:873,t:1526933777453};\\\", \\\"{x:1631,y:891,t:1526933777469};\\\", \\\"{x:1631,y:901,t:1526933777486};\\\", \\\"{x:1631,y:908,t:1526933777503};\\\", \\\"{x:1631,y:912,t:1526933777520};\\\", \\\"{x:1631,y:915,t:1526933777536};\\\", \\\"{x:1631,y:917,t:1526933777552};\\\", \\\"{x:1631,y:919,t:1526933777570};\\\", \\\"{x:1631,y:924,t:1526933777587};\\\", \\\"{x:1630,y:928,t:1526933777603};\\\", \\\"{x:1629,y:931,t:1526933777620};\\\", \\\"{x:1628,y:934,t:1526933777637};\\\", \\\"{x:1627,y:937,t:1526933777654};\\\", \\\"{x:1626,y:939,t:1526933777670};\\\", \\\"{x:1626,y:942,t:1526933777688};\\\", \\\"{x:1626,y:944,t:1526933777704};\\\", \\\"{x:1623,y:951,t:1526933777720};\\\", \\\"{x:1622,y:955,t:1526933777737};\\\", \\\"{x:1621,y:960,t:1526933777754};\\\", \\\"{x:1620,y:962,t:1526933777770};\\\", \\\"{x:1619,y:963,t:1526933777788};\\\", \\\"{x:1619,y:964,t:1526933777830};\\\", \\\"{x:1619,y:965,t:1526933777838};\\\", \\\"{x:1619,y:966,t:1526933777854};\\\", \\\"{x:1619,y:968,t:1526933777870};\\\", \\\"{x:1618,y:969,t:1526933778246};\\\", \\\"{x:1617,y:969,t:1526933778253};\\\", \\\"{x:1616,y:969,t:1526933778278};\\\", \\\"{x:1615,y:969,t:1526933778293};\\\", \\\"{x:1615,y:968,t:1526933779079};\\\", \\\"{x:1613,y:966,t:1526933780007};\\\", \\\"{x:1612,y:963,t:1526933780023};\\\", \\\"{x:1609,y:954,t:1526933780041};\\\", \\\"{x:1604,y:942,t:1526933780056};\\\", \\\"{x:1598,y:925,t:1526933780073};\\\", \\\"{x:1590,y:909,t:1526933780090};\\\", \\\"{x:1584,y:893,t:1526933780106};\\\", \\\"{x:1578,y:881,t:1526933780122};\\\", \\\"{x:1572,y:871,t:1526933780140};\\\", \\\"{x:1567,y:864,t:1526933780157};\\\", \\\"{x:1561,y:858,t:1526933780173};\\\", \\\"{x:1554,y:850,t:1526933780190};\\\", \\\"{x:1546,y:837,t:1526933780206};\\\", \\\"{x:1540,y:828,t:1526933780222};\\\", \\\"{x:1534,y:816,t:1526933780239};\\\", \\\"{x:1530,y:809,t:1526933780256};\\\", \\\"{x:1529,y:803,t:1526933780272};\\\", \\\"{x:1526,y:798,t:1526933780290};\\\", \\\"{x:1524,y:794,t:1526933780307};\\\", \\\"{x:1521,y:786,t:1526933780323};\\\", \\\"{x:1517,y:775,t:1526933780339};\\\", \\\"{x:1516,y:769,t:1526933780357};\\\", \\\"{x:1514,y:765,t:1526933780373};\\\", \\\"{x:1513,y:762,t:1526933780389};\\\", \\\"{x:1513,y:761,t:1526933780406};\\\", \\\"{x:1513,y:760,t:1526933780422};\\\", \\\"{x:1513,y:759,t:1526933780440};\\\", \\\"{x:1513,y:758,t:1526933780456};\\\", \\\"{x:1513,y:759,t:1526933781638};\\\", \\\"{x:1513,y:763,t:1526933781645};\\\", \\\"{x:1513,y:767,t:1526933781658};\\\", \\\"{x:1513,y:780,t:1526933781676};\\\", \\\"{x:1510,y:790,t:1526933781691};\\\", \\\"{x:1509,y:803,t:1526933781708};\\\", \\\"{x:1508,y:813,t:1526933781725};\\\", \\\"{x:1506,y:827,t:1526933781742};\\\", \\\"{x:1505,y:836,t:1526933781758};\\\", \\\"{x:1504,y:843,t:1526933781775};\\\", \\\"{x:1504,y:850,t:1526933781792};\\\", \\\"{x:1504,y:856,t:1526933781808};\\\", \\\"{x:1504,y:861,t:1526933781825};\\\", \\\"{x:1504,y:866,t:1526933781842};\\\", \\\"{x:1504,y:870,t:1526933781859};\\\", \\\"{x:1504,y:875,t:1526933781875};\\\", \\\"{x:1504,y:881,t:1526933781892};\\\", \\\"{x:1504,y:887,t:1526933781909};\\\", \\\"{x:1504,y:894,t:1526933781925};\\\", \\\"{x:1505,y:904,t:1526933781942};\\\", \\\"{x:1506,y:909,t:1526933781959};\\\", \\\"{x:1507,y:914,t:1526933781975};\\\", \\\"{x:1509,y:919,t:1526933781992};\\\", \\\"{x:1510,y:924,t:1526933782009};\\\", \\\"{x:1511,y:928,t:1526933782025};\\\", \\\"{x:1513,y:933,t:1526933782042};\\\", \\\"{x:1514,y:936,t:1526933782059};\\\", \\\"{x:1515,y:940,t:1526933782074};\\\", \\\"{x:1516,y:944,t:1526933782092};\\\", \\\"{x:1517,y:947,t:1526933782109};\\\", \\\"{x:1518,y:950,t:1526933782125};\\\", \\\"{x:1520,y:953,t:1526933782142};\\\", \\\"{x:1520,y:954,t:1526933782159};\\\", \\\"{x:1520,y:955,t:1526933782182};\\\", \\\"{x:1520,y:956,t:1526933782205};\\\", \\\"{x:1521,y:957,t:1526933782228};\\\", \\\"{x:1521,y:958,t:1526933782244};\\\", \\\"{x:1521,y:959,t:1526933782258};\\\", \\\"{x:1521,y:960,t:1526933782285};\\\", \\\"{x:1521,y:961,t:1526933782292};\\\", \\\"{x:1521,y:962,t:1526933782309};\\\", \\\"{x:1521,y:963,t:1526933782325};\\\", \\\"{x:1521,y:964,t:1526933782341};\\\", \\\"{x:1521,y:965,t:1526933782358};\\\", \\\"{x:1521,y:966,t:1526933782376};\\\", \\\"{x:1521,y:969,t:1526933782392};\\\", \\\"{x:1521,y:970,t:1526933782408};\\\", \\\"{x:1520,y:971,t:1526933782425};\\\", \\\"{x:1519,y:972,t:1526933782894};\\\", \\\"{x:1517,y:970,t:1526933782910};\\\", \\\"{x:1511,y:959,t:1526933782926};\\\", \\\"{x:1501,y:941,t:1526933782943};\\\", \\\"{x:1495,y:916,t:1526933782960};\\\", \\\"{x:1488,y:894,t:1526933782976};\\\", \\\"{x:1484,y:873,t:1526933782993};\\\", \\\"{x:1479,y:859,t:1526933783010};\\\", \\\"{x:1475,y:848,t:1526933783026};\\\", \\\"{x:1472,y:840,t:1526933783042};\\\", \\\"{x:1470,y:834,t:1526933783059};\\\", \\\"{x:1469,y:829,t:1526933783077};\\\", \\\"{x:1468,y:824,t:1526933783093};\\\", \\\"{x:1465,y:816,t:1526933783110};\\\", \\\"{x:1464,y:810,t:1526933783127};\\\", \\\"{x:1463,y:806,t:1526933783143};\\\", \\\"{x:1463,y:804,t:1526933783160};\\\", \\\"{x:1463,y:803,t:1526933783177};\\\", \\\"{x:1464,y:803,t:1526933783262};\\\", \\\"{x:1467,y:805,t:1526933783277};\\\", \\\"{x:1477,y:817,t:1526933783294};\\\", \\\"{x:1484,y:829,t:1526933783310};\\\", \\\"{x:1487,y:841,t:1526933783327};\\\", \\\"{x:1490,y:849,t:1526933783344};\\\", \\\"{x:1491,y:852,t:1526933783360};\\\", \\\"{x:1491,y:856,t:1526933783377};\\\", \\\"{x:1491,y:857,t:1526933783526};\\\", \\\"{x:1489,y:857,t:1526933783544};\\\", \\\"{x:1487,y:856,t:1526933783561};\\\", \\\"{x:1486,y:855,t:1526933783577};\\\", \\\"{x:1484,y:855,t:1526933783594};\\\", \\\"{x:1483,y:854,t:1526933783611};\\\", \\\"{x:1483,y:853,t:1526933783629};\\\", \\\"{x:1483,y:852,t:1526933783644};\\\", \\\"{x:1483,y:851,t:1526933783662};\\\", \\\"{x:1483,y:850,t:1526933783718};\\\", \\\"{x:1483,y:849,t:1526933783742};\\\", \\\"{x:1482,y:849,t:1526933783791};\\\", \\\"{x:1482,y:848,t:1526933784078};\\\", \\\"{x:1481,y:847,t:1526933784125};\\\", \\\"{x:1481,y:846,t:1526933784141};\\\", \\\"{x:1478,y:843,t:1526933787161};\\\", \\\"{x:1467,y:841,t:1526933787169};\\\", \\\"{x:1442,y:838,t:1526933787185};\\\", \\\"{x:1406,y:831,t:1526933787201};\\\", \\\"{x:1374,y:826,t:1526933787217};\\\", \\\"{x:1346,y:818,t:1526933787235};\\\", \\\"{x:1319,y:809,t:1526933787250};\\\", \\\"{x:1295,y:799,t:1526933787268};\\\", \\\"{x:1274,y:792,t:1526933787284};\\\", \\\"{x:1250,y:783,t:1526933787301};\\\", \\\"{x:1222,y:774,t:1526933787318};\\\", \\\"{x:1195,y:766,t:1526933787334};\\\", \\\"{x:1158,y:749,t:1526933787351};\\\", \\\"{x:1078,y:711,t:1526933787367};\\\", \\\"{x:1015,y:685,t:1526933787384};\\\", \\\"{x:952,y:658,t:1526933787401};\\\", \\\"{x:905,y:645,t:1526933787418};\\\", \\\"{x:863,y:634,t:1526933787435};\\\", \\\"{x:833,y:628,t:1526933787451};\\\", \\\"{x:804,y:622,t:1526933787467};\\\", \\\"{x:780,y:613,t:1526933787484};\\\", \\\"{x:764,y:605,t:1526933787493};\\\", \\\"{x:737,y:591,t:1526933787511};\\\", \\\"{x:699,y:574,t:1526933787528};\\\", \\\"{x:669,y:565,t:1526933787543};\\\", \\\"{x:640,y:560,t:1526933787561};\\\", \\\"{x:612,y:560,t:1526933787577};\\\", \\\"{x:587,y:560,t:1526933787595};\\\", \\\"{x:573,y:560,t:1526933787611};\\\", \\\"{x:567,y:559,t:1526933787627};\\\", \\\"{x:568,y:559,t:1526933787777};\\\", \\\"{x:568,y:560,t:1526933787784};\\\", \\\"{x:571,y:561,t:1526933787795};\\\", \\\"{x:579,y:565,t:1526933787813};\\\", \\\"{x:588,y:569,t:1526933787828};\\\", \\\"{x:598,y:573,t:1526933787845};\\\", \\\"{x:605,y:574,t:1526933787861};\\\", \\\"{x:610,y:576,t:1526933787878};\\\", \\\"{x:613,y:577,t:1526933787894};\\\", \\\"{x:617,y:577,t:1526933787911};\\\", \\\"{x:620,y:578,t:1526933787928};\\\", \\\"{x:620,y:579,t:1526933788152};\\\", \\\"{x:634,y:582,t:1526933788721};\\\", \\\"{x:654,y:590,t:1526933788729};\\\", \\\"{x:709,y:610,t:1526933788746};\\\", \\\"{x:761,y:631,t:1526933788761};\\\", \\\"{x:817,y:652,t:1526933788778};\\\", \\\"{x:879,y:670,t:1526933788795};\\\", \\\"{x:946,y:690,t:1526933788811};\\\", \\\"{x:1011,y:714,t:1526933788828};\\\", \\\"{x:1084,y:740,t:1526933788846};\\\", \\\"{x:1161,y:768,t:1526933788861};\\\", \\\"{x:1245,y:799,t:1526933788879};\\\", \\\"{x:1378,y:835,t:1526933788896};\\\", \\\"{x:1419,y:847,t:1526933788911};\\\", \\\"{x:1549,y:865,t:1526933788928};\\\", \\\"{x:1612,y:872,t:1526933788946};\\\", \\\"{x:1649,y:874,t:1526933788962};\\\", \\\"{x:1669,y:874,t:1526933788979};\\\", \\\"{x:1675,y:873,t:1526933788996};\\\", \\\"{x:1676,y:872,t:1526933789024};\\\", \\\"{x:1676,y:870,t:1526933789040};\\\", \\\"{x:1676,y:867,t:1526933789048};\\\", \\\"{x:1676,y:865,t:1526933789062};\\\", \\\"{x:1672,y:857,t:1526933789079};\\\", \\\"{x:1664,y:848,t:1526933789096};\\\", \\\"{x:1653,y:842,t:1526933789112};\\\", \\\"{x:1639,y:834,t:1526933789129};\\\", \\\"{x:1621,y:828,t:1526933789146};\\\", \\\"{x:1599,y:826,t:1526933789162};\\\", \\\"{x:1580,y:824,t:1526933789180};\\\", \\\"{x:1562,y:824,t:1526933789196};\\\", \\\"{x:1547,y:824,t:1526933789213};\\\", \\\"{x:1536,y:824,t:1526933789230};\\\", \\\"{x:1524,y:824,t:1526933789246};\\\", \\\"{x:1514,y:824,t:1526933789263};\\\", \\\"{x:1505,y:824,t:1526933789279};\\\", \\\"{x:1497,y:824,t:1526933789297};\\\", \\\"{x:1492,y:824,t:1526933789313};\\\", \\\"{x:1490,y:824,t:1526933789330};\\\", \\\"{x:1488,y:824,t:1526933789346};\\\", \\\"{x:1487,y:824,t:1526933789363};\\\", \\\"{x:1485,y:824,t:1526933789393};\\\", \\\"{x:1484,y:824,t:1526933789409};\\\", \\\"{x:1482,y:824,t:1526933789416};\\\", \\\"{x:1481,y:824,t:1526933789429};\\\", \\\"{x:1480,y:824,t:1526933789446};\\\", \\\"{x:1479,y:824,t:1526933789463};\\\", \\\"{x:1478,y:824,t:1526933789497};\\\", \\\"{x:1477,y:824,t:1526933789520};\\\", \\\"{x:1475,y:823,t:1526933793586};\\\", \\\"{x:1474,y:811,t:1526933793600};\\\", \\\"{x:1473,y:742,t:1526933793616};\\\", \\\"{x:1472,y:683,t:1526933793633};\\\", \\\"{x:1465,y:643,t:1526933793650};\\\", \\\"{x:1461,y:620,t:1526933793666};\\\", \\\"{x:1460,y:607,t:1526933793683};\\\", \\\"{x:1460,y:596,t:1526933793699};\\\", \\\"{x:1460,y:591,t:1526933793716};\\\", \\\"{x:1460,y:587,t:1526933793732};\\\", \\\"{x:1461,y:585,t:1526933793749};\\\", \\\"{x:1461,y:584,t:1526933793767};\\\", \\\"{x:1461,y:581,t:1526933793782};\\\", \\\"{x:1461,y:579,t:1526933793799};\\\", \\\"{x:1461,y:576,t:1526933793816};\\\", \\\"{x:1461,y:575,t:1526933793832};\\\", \\\"{x:1461,y:574,t:1526933793849};\\\", \\\"{x:1461,y:573,t:1526933793867};\\\", \\\"{x:1461,y:572,t:1526933793896};\\\", \\\"{x:1458,y:572,t:1526933793912};\\\", \\\"{x:1457,y:572,t:1526933793921};\\\", \\\"{x:1454,y:572,t:1526933793934};\\\", \\\"{x:1448,y:575,t:1526933793949};\\\", \\\"{x:1444,y:581,t:1526933793966};\\\", \\\"{x:1442,y:590,t:1526933793983};\\\", \\\"{x:1441,y:598,t:1526933794000};\\\", \\\"{x:1441,y:608,t:1526933794016};\\\", \\\"{x:1441,y:613,t:1526933794033};\\\", \\\"{x:1441,y:617,t:1526933794049};\\\", \\\"{x:1441,y:623,t:1526933794066};\\\", \\\"{x:1441,y:630,t:1526933794084};\\\", \\\"{x:1443,y:633,t:1526933794100};\\\", \\\"{x:1443,y:637,t:1526933794117};\\\", \\\"{x:1443,y:638,t:1526933794137};\\\", \\\"{x:1443,y:639,t:1526933794209};\\\", \\\"{x:1443,y:640,t:1526933794224};\\\", \\\"{x:1443,y:641,t:1526933794233};\\\", \\\"{x:1443,y:642,t:1526933794250};\\\", \\\"{x:1443,y:645,t:1526933794266};\\\", \\\"{x:1443,y:649,t:1526933794283};\\\", \\\"{x:1443,y:653,t:1526933794300};\\\", \\\"{x:1443,y:657,t:1526933794316};\\\", \\\"{x:1443,y:663,t:1526933794334};\\\", \\\"{x:1443,y:668,t:1526933794349};\\\", \\\"{x:1443,y:675,t:1526933794367};\\\", \\\"{x:1443,y:684,t:1526933794383};\\\", \\\"{x:1443,y:695,t:1526933794401};\\\", \\\"{x:1443,y:703,t:1526933794416};\\\", \\\"{x:1443,y:713,t:1526933794433};\\\", \\\"{x:1443,y:723,t:1526933794451};\\\", \\\"{x:1446,y:734,t:1526933794467};\\\", \\\"{x:1447,y:746,t:1526933794483};\\\", \\\"{x:1448,y:759,t:1526933794500};\\\", \\\"{x:1451,y:772,t:1526933794516};\\\", \\\"{x:1451,y:784,t:1526933794533};\\\", \\\"{x:1451,y:792,t:1526933794550};\\\", \\\"{x:1451,y:800,t:1526933794566};\\\", \\\"{x:1451,y:810,t:1526933794584};\\\", \\\"{x:1451,y:822,t:1526933794601};\\\", \\\"{x:1451,y:829,t:1526933794617};\\\", \\\"{x:1451,y:836,t:1526933794633};\\\", \\\"{x:1451,y:843,t:1526933794650};\\\", \\\"{x:1451,y:850,t:1526933794666};\\\", \\\"{x:1451,y:856,t:1526933794683};\\\", \\\"{x:1451,y:861,t:1526933794699};\\\", \\\"{x:1451,y:865,t:1526933794716};\\\", \\\"{x:1451,y:870,t:1526933794733};\\\", \\\"{x:1451,y:876,t:1526933794750};\\\", \\\"{x:1451,y:881,t:1526933794766};\\\", \\\"{x:1451,y:886,t:1526933794783};\\\", \\\"{x:1451,y:894,t:1526933794800};\\\", \\\"{x:1451,y:897,t:1526933794816};\\\", \\\"{x:1451,y:901,t:1526933794833};\\\", \\\"{x:1451,y:907,t:1526933794850};\\\", \\\"{x:1451,y:915,t:1526933794866};\\\", \\\"{x:1451,y:921,t:1526933794883};\\\", \\\"{x:1451,y:926,t:1526933794900};\\\", \\\"{x:1451,y:930,t:1526933794917};\\\", \\\"{x:1451,y:933,t:1526933794933};\\\", \\\"{x:1451,y:937,t:1526933794950};\\\", \\\"{x:1451,y:941,t:1526933794967};\\\", \\\"{x:1451,y:946,t:1526933794983};\\\", \\\"{x:1451,y:950,t:1526933795000};\\\", \\\"{x:1451,y:951,t:1526933795017};\\\", \\\"{x:1451,y:952,t:1526933795033};\\\", \\\"{x:1451,y:953,t:1526933795050};\\\", \\\"{x:1454,y:953,t:1526933795209};\\\", \\\"{x:1464,y:947,t:1526933795217};\\\", \\\"{x:1493,y:929,t:1526933795234};\\\", \\\"{x:1536,y:910,t:1526933795250};\\\", \\\"{x:1588,y:887,t:1526933795267};\\\", \\\"{x:1623,y:875,t:1526933795284};\\\", \\\"{x:1648,y:868,t:1526933795301};\\\", \\\"{x:1664,y:863,t:1526933795317};\\\", \\\"{x:1675,y:858,t:1526933795335};\\\", \\\"{x:1686,y:850,t:1526933795350};\\\", \\\"{x:1693,y:843,t:1526933795367};\\\", \\\"{x:1696,y:840,t:1526933795383};\\\", \\\"{x:1700,y:833,t:1526933795400};\\\", \\\"{x:1703,y:829,t:1526933795417};\\\", \\\"{x:1703,y:827,t:1526933795441};\\\", \\\"{x:1703,y:826,t:1526933795456};\\\", \\\"{x:1703,y:824,t:1526933795472};\\\", \\\"{x:1703,y:823,t:1526933795488};\\\", \\\"{x:1703,y:821,t:1526933795505};\\\", \\\"{x:1703,y:820,t:1526933795520};\\\", \\\"{x:1703,y:818,t:1526933795536};\\\", \\\"{x:1703,y:817,t:1526933795553};\\\", \\\"{x:1701,y:814,t:1526933795568};\\\", \\\"{x:1701,y:812,t:1526933795585};\\\", \\\"{x:1699,y:810,t:1526933795601};\\\", \\\"{x:1697,y:809,t:1526933795618};\\\", \\\"{x:1695,y:807,t:1526933795634};\\\", \\\"{x:1691,y:804,t:1526933795650};\\\", \\\"{x:1689,y:802,t:1526933795668};\\\", \\\"{x:1687,y:801,t:1526933795684};\\\", \\\"{x:1686,y:799,t:1526933795700};\\\", \\\"{x:1684,y:799,t:1526933795718};\\\", \\\"{x:1683,y:798,t:1526933795734};\\\", \\\"{x:1682,y:797,t:1526933795751};\\\", \\\"{x:1681,y:796,t:1526933796008};\\\", \\\"{x:1680,y:794,t:1526933796017};\\\", \\\"{x:1668,y:785,t:1526933796034};\\\", \\\"{x:1650,y:771,t:1526933796052};\\\", \\\"{x:1627,y:755,t:1526933796067};\\\", \\\"{x:1597,y:740,t:1526933796084};\\\", \\\"{x:1578,y:730,t:1526933796101};\\\", \\\"{x:1576,y:722,t:1526933796118};\\\", \\\"{x:1576,y:721,t:1526933796417};\\\", \\\"{x:1576,y:719,t:1526933796433};\\\", \\\"{x:1576,y:718,t:1526933796441};\\\", \\\"{x:1577,y:717,t:1526933796452};\\\", \\\"{x:1578,y:715,t:1526933796468};\\\", \\\"{x:1580,y:712,t:1526933796484};\\\", \\\"{x:1584,y:707,t:1526933796502};\\\", \\\"{x:1587,y:706,t:1526933796519};\\\", \\\"{x:1591,y:705,t:1526933796534};\\\", \\\"{x:1591,y:704,t:1526933796633};\\\", \\\"{x:1591,y:702,t:1526933796641};\\\", \\\"{x:1592,y:701,t:1526933796651};\\\", \\\"{x:1592,y:700,t:1526933796668};\\\", \\\"{x:1593,y:699,t:1526933796687};\\\", \\\"{x:1594,y:699,t:1526933796784};\\\", \\\"{x:1596,y:697,t:1526933796801};\\\", \\\"{x:1601,y:693,t:1526933796817};\\\", \\\"{x:1606,y:689,t:1526933796835};\\\", \\\"{x:1610,y:687,t:1526933796851};\\\", \\\"{x:1610,y:686,t:1526933796867};\\\", \\\"{x:1612,y:686,t:1526933798017};\\\", \\\"{x:1614,y:687,t:1526933798025};\\\", \\\"{x:1615,y:688,t:1526933798035};\\\", \\\"{x:1618,y:689,t:1526933798053};\\\", \\\"{x:1619,y:690,t:1526933798069};\\\", \\\"{x:1620,y:690,t:1526933798086};\\\", \\\"{x:1622,y:691,t:1526933798103};\\\", \\\"{x:1623,y:691,t:1526933798120};\\\", \\\"{x:1624,y:691,t:1526933798136};\\\", \\\"{x:1625,y:691,t:1526933798160};\\\", \\\"{x:1625,y:692,t:1526933798176};\\\", \\\"{x:1626,y:693,t:1526933798192};\\\", \\\"{x:1626,y:694,t:1526933798233};\\\", \\\"{x:1627,y:694,t:1526933798241};\\\", \\\"{x:1628,y:694,t:1526933798252};\\\", \\\"{x:1628,y:695,t:1526933798281};\\\", \\\"{x:1625,y:695,t:1526933798600};\\\", \\\"{x:1624,y:695,t:1526933798632};\\\", \\\"{x:1623,y:695,t:1526933798640};\\\", \\\"{x:1622,y:695,t:1526933798653};\\\", \\\"{x:1621,y:695,t:1526933798712};\\\", \\\"{x:1621,y:696,t:1526933799593};\\\", \\\"{x:1619,y:698,t:1526933799606};\\\", \\\"{x:1618,y:701,t:1526933799620};\\\", \\\"{x:1617,y:703,t:1526933799637};\\\", \\\"{x:1617,y:704,t:1526933799679};\\\", \\\"{x:1616,y:704,t:1526933799977};\\\", \\\"{x:1615,y:704,t:1526933800000};\\\", \\\"{x:1614,y:704,t:1526933800009};\\\", \\\"{x:1613,y:704,t:1526933800024};\\\", \\\"{x:1612,y:703,t:1526933800081};\\\", \\\"{x:1612,y:702,t:1526933800449};\\\", \\\"{x:1612,y:700,t:1526933800457};\\\", \\\"{x:1612,y:697,t:1526933800488};\\\", \\\"{x:1612,y:694,t:1526933800505};\\\", \\\"{x:1612,y:693,t:1526933800520};\\\", \\\"{x:1609,y:694,t:1526933802152};\\\", \\\"{x:1603,y:698,t:1526933802161};\\\", \\\"{x:1599,y:701,t:1526933802172};\\\", \\\"{x:1579,y:713,t:1526933802189};\\\", \\\"{x:1548,y:724,t:1526933802205};\\\", \\\"{x:1506,y:737,t:1526933802223};\\\", \\\"{x:1453,y:751,t:1526933802239};\\\", \\\"{x:1422,y:758,t:1526933802256};\\\", \\\"{x:1382,y:763,t:1526933802273};\\\", \\\"{x:1359,y:766,t:1526933802289};\\\", \\\"{x:1344,y:768,t:1526933802305};\\\", \\\"{x:1333,y:770,t:1526933802323};\\\", \\\"{x:1327,y:770,t:1526933802339};\\\", \\\"{x:1324,y:770,t:1526933802355};\\\", \\\"{x:1323,y:770,t:1526933802373};\\\", \\\"{x:1324,y:770,t:1526933802560};\\\", \\\"{x:1327,y:770,t:1526933802572};\\\", \\\"{x:1336,y:769,t:1526933802589};\\\", \\\"{x:1349,y:767,t:1526933802606};\\\", \\\"{x:1356,y:765,t:1526933802622};\\\", \\\"{x:1359,y:764,t:1526933802639};\\\", \\\"{x:1361,y:764,t:1526933804241};\\\", \\\"{x:1369,y:776,t:1526933804257};\\\", \\\"{x:1381,y:802,t:1526933804274};\\\", \\\"{x:1393,y:828,t:1526933804291};\\\", \\\"{x:1410,y:860,t:1526933804306};\\\", \\\"{x:1417,y:878,t:1526933804324};\\\", \\\"{x:1424,y:889,t:1526933804340};\\\", \\\"{x:1426,y:891,t:1526933804357};\\\", \\\"{x:1428,y:894,t:1526933804374};\\\", \\\"{x:1429,y:894,t:1526933804440};\\\", \\\"{x:1435,y:894,t:1526933804458};\\\", \\\"{x:1442,y:888,t:1526933804473};\\\", \\\"{x:1446,y:884,t:1526933804491};\\\", \\\"{x:1451,y:880,t:1526933804508};\\\", \\\"{x:1455,y:876,t:1526933804523};\\\", \\\"{x:1457,y:874,t:1526933804540};\\\", \\\"{x:1458,y:872,t:1526933804558};\\\", \\\"{x:1459,y:869,t:1526933804574};\\\", \\\"{x:1459,y:867,t:1526933804591};\\\", \\\"{x:1459,y:864,t:1526933804608};\\\", \\\"{x:1459,y:861,t:1526933804623};\\\", \\\"{x:1459,y:856,t:1526933804640};\\\", \\\"{x:1459,y:852,t:1526933804658};\\\", \\\"{x:1459,y:848,t:1526933804674};\\\", \\\"{x:1459,y:845,t:1526933804691};\\\", \\\"{x:1460,y:841,t:1526933804708};\\\", \\\"{x:1461,y:839,t:1526933804724};\\\", \\\"{x:1463,y:835,t:1526933804741};\\\", \\\"{x:1463,y:834,t:1526933804757};\\\", \\\"{x:1464,y:832,t:1526933804774};\\\", \\\"{x:1465,y:830,t:1526933804791};\\\", \\\"{x:1466,y:830,t:1526933804808};\\\", \\\"{x:1467,y:829,t:1526933804824};\\\", \\\"{x:1468,y:828,t:1526933804865};\\\", \\\"{x:1470,y:827,t:1526933804888};\\\", \\\"{x:1471,y:826,t:1526933804913};\\\", \\\"{x:1472,y:826,t:1526933804968};\\\", \\\"{x:1473,y:825,t:1526933804985};\\\", \\\"{x:1474,y:825,t:1526933805001};\\\", \\\"{x:1475,y:824,t:1526933805017};\\\", \\\"{x:1476,y:824,t:1526933805049};\\\", \\\"{x:1477,y:824,t:1526933805080};\\\", \\\"{x:1478,y:824,t:1526933805216};\\\", \\\"{x:1479,y:824,t:1526933805232};\\\", \\\"{x:1480,y:824,t:1526933805257};\\\", \\\"{x:1481,y:825,t:1526933805272};\\\", \\\"{x:1482,y:825,t:1526933805291};\\\", \\\"{x:1483,y:826,t:1526933805308};\\\", \\\"{x:1483,y:827,t:1526933805325};\\\", \\\"{x:1484,y:828,t:1526933805341};\\\", \\\"{x:1484,y:829,t:1526933805376};\\\", \\\"{x:1484,y:828,t:1526933805760};\\\", \\\"{x:1484,y:826,t:1526933805775};\\\", \\\"{x:1484,y:823,t:1526933805792};\\\", \\\"{x:1484,y:820,t:1526933805808};\\\", \\\"{x:1484,y:817,t:1526933805825};\\\", \\\"{x:1484,y:815,t:1526933805841};\\\", \\\"{x:1484,y:811,t:1526933805859};\\\", \\\"{x:1484,y:809,t:1526933805876};\\\", \\\"{x:1484,y:804,t:1526933805892};\\\", \\\"{x:1484,y:799,t:1526933805909};\\\", \\\"{x:1484,y:794,t:1526933805925};\\\", \\\"{x:1484,y:788,t:1526933805942};\\\", \\\"{x:1484,y:783,t:1526933805959};\\\", \\\"{x:1484,y:778,t:1526933805975};\\\", \\\"{x:1484,y:772,t:1526933805991};\\\", \\\"{x:1484,y:759,t:1526933806009};\\\", \\\"{x:1483,y:749,t:1526933806025};\\\", \\\"{x:1482,y:743,t:1526933806042};\\\", \\\"{x:1481,y:736,t:1526933806059};\\\", \\\"{x:1480,y:730,t:1526933806075};\\\", \\\"{x:1479,y:725,t:1526933806091};\\\", \\\"{x:1479,y:721,t:1526933806109};\\\", \\\"{x:1477,y:708,t:1526933806124};\\\", \\\"{x:1477,y:701,t:1526933806142};\\\", \\\"{x:1474,y:691,t:1526933806159};\\\", \\\"{x:1472,y:681,t:1526933806175};\\\", \\\"{x:1470,y:673,t:1526933806192};\\\", \\\"{x:1469,y:669,t:1526933806208};\\\", \\\"{x:1469,y:666,t:1526933806224};\\\", \\\"{x:1469,y:663,t:1526933806242};\\\", \\\"{x:1469,y:662,t:1526933806258};\\\", \\\"{x:1469,y:661,t:1526933806275};\\\", \\\"{x:1469,y:660,t:1526933806291};\\\", \\\"{x:1469,y:659,t:1526933806309};\\\", \\\"{x:1469,y:658,t:1526933806335};\\\", \\\"{x:1469,y:657,t:1526933806359};\\\", \\\"{x:1469,y:656,t:1526933806375};\\\", \\\"{x:1469,y:655,t:1526933806392};\\\", \\\"{x:1469,y:653,t:1526933806408};\\\", \\\"{x:1469,y:652,t:1526933806425};\\\", \\\"{x:1469,y:650,t:1526933806442};\\\", \\\"{x:1469,y:648,t:1526933806459};\\\", \\\"{x:1469,y:647,t:1526933806475};\\\", \\\"{x:1469,y:646,t:1526933806944};\\\", \\\"{x:1469,y:645,t:1526933806959};\\\", \\\"{x:1465,y:642,t:1526933806976};\\\", \\\"{x:1464,y:640,t:1526933806992};\\\", \\\"{x:1463,y:639,t:1526933807008};\\\", \\\"{x:1463,y:638,t:1526933807026};\\\", \\\"{x:1462,y:638,t:1526933807043};\\\", \\\"{x:1462,y:636,t:1526933807059};\\\", \\\"{x:1462,y:635,t:1526933807352};\\\", \\\"{x:1461,y:634,t:1526933807368};\\\", \\\"{x:1460,y:633,t:1526933807408};\\\", \\\"{x:1459,y:633,t:1526933807431};\\\", \\\"{x:1459,y:632,t:1526933807472};\\\", \\\"{x:1458,y:632,t:1526933807513};\\\", \\\"{x:1458,y:631,t:1526933807545};\\\", \\\"{x:1456,y:630,t:1526933807601};\\\", \\\"{x:1455,y:630,t:1526933807632};\\\", \\\"{x:1455,y:629,t:1526933807643};\\\", \\\"{x:1454,y:629,t:1526933807697};\\\", \\\"{x:1453,y:629,t:1526933807712};\\\", \\\"{x:1452,y:629,t:1526933807960};\\\", \\\"{x:1452,y:631,t:1526933807976};\\\", \\\"{x:1452,y:636,t:1526933807994};\\\", \\\"{x:1452,y:639,t:1526933808010};\\\", \\\"{x:1452,y:643,t:1526933808028};\\\", \\\"{x:1452,y:648,t:1526933808043};\\\", \\\"{x:1452,y:656,t:1526933808060};\\\", \\\"{x:1452,y:667,t:1526933808077};\\\", \\\"{x:1452,y:679,t:1526933808093};\\\", \\\"{x:1454,y:694,t:1526933808110};\\\", \\\"{x:1457,y:710,t:1526933808127};\\\", \\\"{x:1458,y:722,t:1526933808143};\\\", \\\"{x:1460,y:734,t:1526933808160};\\\", \\\"{x:1461,y:740,t:1526933808176};\\\", \\\"{x:1462,y:745,t:1526933808192};\\\", \\\"{x:1463,y:754,t:1526933808210};\\\", \\\"{x:1463,y:766,t:1526933808227};\\\", \\\"{x:1463,y:775,t:1526933808244};\\\", \\\"{x:1465,y:784,t:1526933808260};\\\", \\\"{x:1465,y:793,t:1526933808276};\\\", \\\"{x:1465,y:802,t:1526933808294};\\\", \\\"{x:1465,y:812,t:1526933808310};\\\", \\\"{x:1467,y:824,t:1526933808327};\\\", \\\"{x:1469,y:842,t:1526933808344};\\\", \\\"{x:1470,y:854,t:1526933808360};\\\", \\\"{x:1470,y:865,t:1526933808377};\\\", \\\"{x:1470,y:877,t:1526933808394};\\\", \\\"{x:1470,y:890,t:1526933808410};\\\", \\\"{x:1470,y:901,t:1526933808427};\\\", \\\"{x:1470,y:911,t:1526933808443};\\\", \\\"{x:1469,y:920,t:1526933808459};\\\", \\\"{x:1466,y:929,t:1526933808477};\\\", \\\"{x:1463,y:937,t:1526933808494};\\\", \\\"{x:1460,y:947,t:1526933808510};\\\", \\\"{x:1456,y:958,t:1526933808526};\\\", \\\"{x:1454,y:968,t:1526933808544};\\\", \\\"{x:1451,y:975,t:1526933808560};\\\", \\\"{x:1451,y:978,t:1526933808576};\\\", \\\"{x:1450,y:980,t:1526933808594};\\\", \\\"{x:1449,y:982,t:1526933808610};\\\", \\\"{x:1449,y:983,t:1526933808627};\\\", \\\"{x:1448,y:983,t:1526933808644};\\\", \\\"{x:1449,y:980,t:1526933808968};\\\", \\\"{x:1453,y:967,t:1526933808977};\\\", \\\"{x:1461,y:942,t:1526933808994};\\\", \\\"{x:1473,y:914,t:1526933809011};\\\", \\\"{x:1485,y:890,t:1526933809027};\\\", \\\"{x:1499,y:855,t:1526933809044};\\\", \\\"{x:1525,y:797,t:1526933809060};\\\", \\\"{x:1546,y:748,t:1526933809077};\\\", \\\"{x:1565,y:706,t:1526933809094};\\\", \\\"{x:1578,y:687,t:1526933809111};\\\", \\\"{x:1584,y:675,t:1526933809127};\\\", \\\"{x:1584,y:672,t:1526933809144};\\\", \\\"{x:1575,y:680,t:1526933809273};\\\", \\\"{x:1565,y:688,t:1526933809280};\\\", \\\"{x:1553,y:697,t:1526933809294};\\\", \\\"{x:1535,y:715,t:1526933809311};\\\", \\\"{x:1517,y:742,t:1526933809328};\\\", \\\"{x:1512,y:755,t:1526933809344};\\\", \\\"{x:1510,y:762,t:1526933809361};\\\", \\\"{x:1510,y:765,t:1526933809377};\\\", \\\"{x:1510,y:767,t:1526933809408};\\\", \\\"{x:1510,y:765,t:1526933809584};\\\", \\\"{x:1510,y:764,t:1526933809600};\\\", \\\"{x:1510,y:759,t:1526933825465};\\\", \\\"{x:1510,y:757,t:1526933825473};\\\", \\\"{x:1510,y:749,t:1526933825490};\\\", \\\"{x:1510,y:748,t:1526933825506};\\\", \\\"{x:1508,y:748,t:1526933826225};\\\", \\\"{x:1506,y:750,t:1526933826240};\\\", \\\"{x:1502,y:756,t:1526933826256};\\\", \\\"{x:1501,y:759,t:1526933826274};\\\", \\\"{x:1501,y:760,t:1526933826289};\\\", \\\"{x:1501,y:767,t:1526933826306};\\\", \\\"{x:1501,y:777,t:1526933826323};\\\", \\\"{x:1506,y:793,t:1526933826341};\\\", \\\"{x:1515,y:810,t:1526933826356};\\\", \\\"{x:1528,y:827,t:1526933826373};\\\", \\\"{x:1546,y:840,t:1526933826390};\\\", \\\"{x:1563,y:849,t:1526933826406};\\\", \\\"{x:1592,y:853,t:1526933826423};\\\", \\\"{x:1606,y:853,t:1526933826440};\\\", \\\"{x:1617,y:852,t:1526933826456};\\\", \\\"{x:1628,y:848,t:1526933826473};\\\", \\\"{x:1632,y:845,t:1526933826490};\\\", \\\"{x:1633,y:839,t:1526933826505};\\\", \\\"{x:1637,y:817,t:1526933826523};\\\", \\\"{x:1646,y:790,t:1526933826540};\\\", \\\"{x:1652,y:772,t:1526933826555};\\\", \\\"{x:1654,y:750,t:1526933826573};\\\", \\\"{x:1654,y:733,t:1526933826590};\\\", \\\"{x:1646,y:717,t:1526933826606};\\\", \\\"{x:1640,y:700,t:1526933826623};\\\", \\\"{x:1636,y:691,t:1526933826640};\\\", \\\"{x:1636,y:682,t:1526933826656};\\\", \\\"{x:1636,y:678,t:1526933826673};\\\", \\\"{x:1636,y:676,t:1526933826690};\\\", \\\"{x:1636,y:675,t:1526933826706};\\\", \\\"{x:1635,y:674,t:1526933826727};\\\", \\\"{x:1634,y:674,t:1526933826760};\\\", \\\"{x:1633,y:675,t:1526933826774};\\\", \\\"{x:1633,y:677,t:1526933826790};\\\", \\\"{x:1633,y:684,t:1526933826807};\\\", \\\"{x:1633,y:687,t:1526933826824};\\\", \\\"{x:1632,y:690,t:1526933826840};\\\", \\\"{x:1631,y:693,t:1526933826857};\\\", \\\"{x:1630,y:694,t:1526933826873};\\\", \\\"{x:1629,y:694,t:1526933826944};\\\", \\\"{x:1627,y:694,t:1526933826958};\\\", \\\"{x:1626,y:693,t:1526933826973};\\\", \\\"{x:1624,y:692,t:1526933826991};\\\", \\\"{x:1622,y:692,t:1526933827007};\\\", \\\"{x:1621,y:692,t:1526933827024};\\\", \\\"{x:1620,y:692,t:1526933827040};\\\", \\\"{x:1619,y:692,t:1526933827168};\\\", \\\"{x:1618,y:692,t:1526933827185};\\\", \\\"{x:1618,y:693,t:1526933827207};\\\", \\\"{x:1616,y:695,t:1526933827223};\\\", \\\"{x:1614,y:697,t:1526933827240};\\\", \\\"{x:1613,y:700,t:1526933827257};\\\", \\\"{x:1611,y:704,t:1526933827274};\\\", \\\"{x:1610,y:706,t:1526933827290};\\\", \\\"{x:1610,y:709,t:1526933827448};\\\", \\\"{x:1610,y:710,t:1526933827458};\\\", \\\"{x:1610,y:716,t:1526933827475};\\\", \\\"{x:1610,y:720,t:1526933827491};\\\", \\\"{x:1610,y:723,t:1526933827507};\\\", \\\"{x:1610,y:724,t:1526933827524};\\\", \\\"{x:1610,y:725,t:1526933827541};\\\", \\\"{x:1610,y:724,t:1526933827736};\\\", \\\"{x:1610,y:723,t:1526933827760};\\\", \\\"{x:1610,y:722,t:1526933827784};\\\", \\\"{x:1610,y:721,t:1526933827792};\\\", \\\"{x:1610,y:720,t:1526933827807};\\\", \\\"{x:1610,y:715,t:1526933827824};\\\", \\\"{x:1610,y:712,t:1526933827841};\\\", \\\"{x:1610,y:707,t:1526933827858};\\\", \\\"{x:1610,y:706,t:1526933827874};\\\", \\\"{x:1610,y:704,t:1526933827891};\\\", \\\"{x:1610,y:702,t:1526933827907};\\\", \\\"{x:1610,y:701,t:1526933827983};\\\", \\\"{x:1610,y:698,t:1526933828000};\\\", \\\"{x:1610,y:697,t:1526933828007};\\\", \\\"{x:1610,y:695,t:1526933828025};\\\", \\\"{x:1610,y:694,t:1526933828041};\\\", \\\"{x:1600,y:694,t:1526933829225};\\\", \\\"{x:1554,y:696,t:1526933829243};\\\", \\\"{x:1490,y:696,t:1526933829258};\\\", \\\"{x:1415,y:697,t:1526933829276};\\\", \\\"{x:1357,y:702,t:1526933829293};\\\", \\\"{x:1323,y:702,t:1526933829309};\\\", \\\"{x:1306,y:702,t:1526933829325};\\\", \\\"{x:1299,y:702,t:1526933829342};\\\", \\\"{x:1298,y:702,t:1526933829359};\\\", \\\"{x:1298,y:700,t:1526933829400};\\\", \\\"{x:1298,y:699,t:1526933829440};\\\", \\\"{x:1298,y:698,t:1526933829472};\\\", \\\"{x:1298,y:697,t:1526933829480};\\\", \\\"{x:1300,y:696,t:1526933829493};\\\", \\\"{x:1316,y:691,t:1526933829509};\\\", \\\"{x:1336,y:689,t:1526933829526};\\\", \\\"{x:1356,y:687,t:1526933829542};\\\", \\\"{x:1377,y:687,t:1526933829559};\\\", \\\"{x:1391,y:687,t:1526933829576};\\\", \\\"{x:1390,y:687,t:1526933829656};\\\", \\\"{x:1388,y:689,t:1526933829664};\\\", \\\"{x:1384,y:691,t:1526933829676};\\\", \\\"{x:1379,y:693,t:1526933829693};\\\", \\\"{x:1370,y:695,t:1526933829709};\\\", \\\"{x:1369,y:695,t:1526933829726};\\\", \\\"{x:1368,y:695,t:1526933829865};\\\", \\\"{x:1368,y:696,t:1526933829880};\\\", \\\"{x:1367,y:697,t:1526933829896};\\\", \\\"{x:1365,y:697,t:1526933829912};\\\", \\\"{x:1364,y:698,t:1526933829925};\\\", \\\"{x:1363,y:698,t:1526933829961};\\\", \\\"{x:1359,y:700,t:1526933829976};\\\", \\\"{x:1357,y:700,t:1526933829993};\\\", \\\"{x:1355,y:700,t:1526933830010};\\\", \\\"{x:1354,y:700,t:1526933830026};\\\", \\\"{x:1353,y:700,t:1526933830064};\\\", \\\"{x:1354,y:702,t:1526933830128};\\\", \\\"{x:1360,y:705,t:1526933830143};\\\", \\\"{x:1378,y:717,t:1526933830160};\\\", \\\"{x:1389,y:722,t:1526933830176};\\\", \\\"{x:1399,y:725,t:1526933830192};\\\", \\\"{x:1405,y:726,t:1526933830209};\\\", \\\"{x:1406,y:726,t:1526933830226};\\\", \\\"{x:1407,y:726,t:1526933830279};\\\", \\\"{x:1407,y:723,t:1526933830292};\\\", \\\"{x:1405,y:718,t:1526933830309};\\\", \\\"{x:1405,y:711,t:1526933830326};\\\", \\\"{x:1403,y:705,t:1526933830342};\\\", \\\"{x:1403,y:701,t:1526933830359};\\\", \\\"{x:1403,y:699,t:1526933830377};\\\", \\\"{x:1403,y:696,t:1526933830392};\\\", \\\"{x:1403,y:695,t:1526933830409};\\\", \\\"{x:1403,y:693,t:1526933830426};\\\", \\\"{x:1405,y:691,t:1526933830442};\\\", \\\"{x:1406,y:690,t:1526933830460};\\\", \\\"{x:1408,y:690,t:1526933830488};\\\", \\\"{x:1409,y:690,t:1526933830503};\\\", \\\"{x:1411,y:690,t:1526933830520};\\\", \\\"{x:1412,y:690,t:1526933830536};\\\", \\\"{x:1413,y:690,t:1526933830543};\\\", \\\"{x:1416,y:691,t:1526933830559};\\\", \\\"{x:1418,y:693,t:1526933830576};\\\", \\\"{x:1421,y:695,t:1526933830593};\\\", \\\"{x:1427,y:696,t:1526933830610};\\\", \\\"{x:1437,y:696,t:1526933830626};\\\", \\\"{x:1445,y:696,t:1526933830643};\\\", \\\"{x:1452,y:696,t:1526933830659};\\\", \\\"{x:1456,y:695,t:1526933830676};\\\", \\\"{x:1461,y:693,t:1526933830693};\\\", \\\"{x:1463,y:691,t:1526933830709};\\\", \\\"{x:1465,y:690,t:1526933830726};\\\", \\\"{x:1467,y:689,t:1526933830743};\\\", \\\"{x:1468,y:689,t:1526933830913};\\\", \\\"{x:1469,y:689,t:1526933830926};\\\", \\\"{x:1479,y:696,t:1526933830944};\\\", \\\"{x:1484,y:701,t:1526933830961};\\\", \\\"{x:1489,y:707,t:1526933830976};\\\", \\\"{x:1495,y:711,t:1526933830993};\\\", \\\"{x:1497,y:712,t:1526933831011};\\\", \\\"{x:1501,y:712,t:1526933831026};\\\", \\\"{x:1512,y:709,t:1526933831043};\\\", \\\"{x:1517,y:704,t:1526933831060};\\\", \\\"{x:1528,y:700,t:1526933831077};\\\", \\\"{x:1537,y:696,t:1526933831094};\\\", \\\"{x:1546,y:695,t:1526933831110};\\\", \\\"{x:1550,y:694,t:1526933831127};\\\", \\\"{x:1552,y:693,t:1526933831144};\\\", \\\"{x:1553,y:693,t:1526933831304};\\\", \\\"{x:1554,y:695,t:1526933831312};\\\", \\\"{x:1555,y:697,t:1526933831327};\\\", \\\"{x:1562,y:708,t:1526933831344};\\\", \\\"{x:1568,y:715,t:1526933831361};\\\", \\\"{x:1574,y:719,t:1526933831377};\\\", \\\"{x:1579,y:722,t:1526933831394};\\\", \\\"{x:1586,y:722,t:1526933831411};\\\", \\\"{x:1589,y:722,t:1526933831426};\\\", \\\"{x:1591,y:722,t:1526933831443};\\\", \\\"{x:1593,y:722,t:1526933831460};\\\", \\\"{x:1594,y:717,t:1526933831477};\\\", \\\"{x:1596,y:704,t:1526933831494};\\\", \\\"{x:1596,y:694,t:1526933831511};\\\", \\\"{x:1588,y:679,t:1526933831528};\\\", \\\"{x:1563,y:670,t:1526933831544};\\\", \\\"{x:1501,y:662,t:1526933831561};\\\", \\\"{x:1409,y:662,t:1526933831577};\\\", \\\"{x:1301,y:662,t:1526933831594};\\\", \\\"{x:1187,y:662,t:1526933831611};\\\", \\\"{x:1069,y:671,t:1526933831627};\\\", \\\"{x:953,y:687,t:1526933831644};\\\", \\\"{x:872,y:700,t:1526933831661};\\\", \\\"{x:824,y:708,t:1526933831678};\\\", \\\"{x:801,y:708,t:1526933831694};\\\", \\\"{x:790,y:708,t:1526933831711};\\\", \\\"{x:784,y:708,t:1526933831728};\\\", \\\"{x:780,y:708,t:1526933831743};\\\", \\\"{x:772,y:704,t:1526933831761};\\\", \\\"{x:758,y:698,t:1526933831778};\\\", \\\"{x:732,y:688,t:1526933831793};\\\", \\\"{x:688,y:676,t:1526933831811};\\\", \\\"{x:638,y:663,t:1526933831827};\\\", \\\"{x:592,y:652,t:1526933831844};\\\", \\\"{x:549,y:639,t:1526933831861};\\\", \\\"{x:517,y:629,t:1526933831879};\\\", \\\"{x:493,y:618,t:1526933831895};\\\", \\\"{x:477,y:607,t:1526933831910};\\\", \\\"{x:456,y:587,t:1526933831930};\\\", \\\"{x:448,y:580,t:1526933831946};\\\", \\\"{x:440,y:575,t:1526933831963};\\\", \\\"{x:437,y:572,t:1526933831980};\\\", \\\"{x:430,y:568,t:1526933831996};\\\", \\\"{x:423,y:566,t:1526933832013};\\\", \\\"{x:420,y:564,t:1526933832030};\\\", \\\"{x:418,y:564,t:1526933832046};\\\", \\\"{x:416,y:564,t:1526933832063};\\\", \\\"{x:414,y:563,t:1526933832080};\\\", \\\"{x:408,y:562,t:1526933832097};\\\", \\\"{x:391,y:558,t:1526933832113};\\\", \\\"{x:374,y:553,t:1526933832131};\\\", \\\"{x:352,y:551,t:1526933832146};\\\", \\\"{x:326,y:548,t:1526933832163};\\\", \\\"{x:303,y:548,t:1526933832180};\\\", \\\"{x:276,y:548,t:1526933832196};\\\", \\\"{x:253,y:548,t:1526933832214};\\\", \\\"{x:233,y:548,t:1526933832230};\\\", \\\"{x:218,y:546,t:1526933832247};\\\", \\\"{x:210,y:542,t:1526933832262};\\\", \\\"{x:209,y:542,t:1526933832280};\\\", \\\"{x:208,y:542,t:1526933832297};\\\", \\\"{x:206,y:541,t:1526933832313};\\\", \\\"{x:206,y:542,t:1526933832384};\\\", \\\"{x:206,y:543,t:1526933832397};\\\", \\\"{x:206,y:552,t:1526933832414};\\\", \\\"{x:207,y:561,t:1526933832432};\\\", \\\"{x:214,y:576,t:1526933832447};\\\", \\\"{x:218,y:587,t:1526933832463};\\\", \\\"{x:227,y:597,t:1526933832481};\\\", \\\"{x:239,y:602,t:1526933832498};\\\", \\\"{x:261,y:604,t:1526933832514};\\\", \\\"{x:288,y:604,t:1526933832531};\\\", \\\"{x:340,y:600,t:1526933832548};\\\", \\\"{x:392,y:588,t:1526933832564};\\\", \\\"{x:430,y:574,t:1526933832580};\\\", \\\"{x:457,y:566,t:1526933832597};\\\", \\\"{x:474,y:556,t:1526933832614};\\\", \\\"{x:490,y:547,t:1526933832630};\\\", \\\"{x:521,y:529,t:1526933832648};\\\", \\\"{x:543,y:519,t:1526933832664};\\\", \\\"{x:557,y:514,t:1526933832680};\\\", \\\"{x:560,y:513,t:1526933832697};\\\", \\\"{x:566,y:512,t:1526933832713};\\\", \\\"{x:575,y:510,t:1526933832730};\\\", \\\"{x:592,y:507,t:1526933832747};\\\", \\\"{x:605,y:507,t:1526933832764};\\\", \\\"{x:617,y:505,t:1526933832781};\\\", \\\"{x:630,y:505,t:1526933832797};\\\", \\\"{x:641,y:505,t:1526933832813};\\\", \\\"{x:653,y:505,t:1526933832831};\\\", \\\"{x:665,y:505,t:1526933832846};\\\", \\\"{x:688,y:505,t:1526933832864};\\\", \\\"{x:702,y:505,t:1526933832881};\\\", \\\"{x:718,y:504,t:1526933832898};\\\", \\\"{x:735,y:504,t:1526933832916};\\\", \\\"{x:750,y:504,t:1526933832931};\\\", \\\"{x:762,y:503,t:1526933832947};\\\", \\\"{x:769,y:502,t:1526933832964};\\\", \\\"{x:783,y:502,t:1526933832980};\\\", \\\"{x:785,y:500,t:1526933832998};\\\", \\\"{x:787,y:500,t:1526933833014};\\\", \\\"{x:791,y:500,t:1526933833031};\\\", \\\"{x:793,y:500,t:1526933833047};\\\", \\\"{x:793,y:498,t:1526933833065};\\\", \\\"{x:795,y:498,t:1526933833264};\\\", \\\"{x:799,y:500,t:1526933833281};\\\", \\\"{x:801,y:500,t:1526933833298};\\\", \\\"{x:803,y:500,t:1526933833314};\\\", \\\"{x:810,y:500,t:1526933833331};\\\", \\\"{x:812,y:500,t:1526933833348};\\\", \\\"{x:814,y:501,t:1526933833365};\\\", \\\"{x:817,y:502,t:1526933833381};\\\", \\\"{x:820,y:503,t:1526933833397};\\\", \\\"{x:821,y:503,t:1526933833414};\\\", \\\"{x:822,y:503,t:1526933833431};\\\", \\\"{x:823,y:503,t:1526933833456};\\\", \\\"{x:824,y:503,t:1526933833487};\\\", \\\"{x:825,y:503,t:1526933833503};\\\", \\\"{x:827,y:503,t:1526933833515};\\\", \\\"{x:828,y:503,t:1526933833560};\\\", \\\"{x:830,y:504,t:1526933833640};\\\", \\\"{x:829,y:507,t:1526933834032};\\\", \\\"{x:820,y:526,t:1526933834049};\\\", \\\"{x:802,y:557,t:1526933834066};\\\", \\\"{x:770,y:602,t:1526933834082};\\\", \\\"{x:729,y:658,t:1526933834099};\\\", \\\"{x:689,y:705,t:1526933834115};\\\", \\\"{x:659,y:729,t:1526933834132};\\\", \\\"{x:642,y:742,t:1526933834148};\\\", \\\"{x:624,y:751,t:1526933834165};\\\", \\\"{x:611,y:758,t:1526933834181};\\\", \\\"{x:600,y:763,t:1526933834198};\\\", \\\"{x:579,y:768,t:1526933834215};\\\", \\\"{x:563,y:772,t:1526933834231};\\\", \\\"{x:554,y:775,t:1526933834248};\\\", \\\"{x:546,y:776,t:1526933834266};\\\", \\\"{x:542,y:776,t:1526933834281};\\\", \\\"{x:539,y:776,t:1526933834298};\\\", \\\"{x:537,y:775,t:1526933834316};\\\", \\\"{x:533,y:772,t:1526933834332};\\\", \\\"{x:527,y:768,t:1526933834349};\\\", \\\"{x:519,y:761,t:1526933834366};\\\", \\\"{x:511,y:753,t:1526933834383};\\\", \\\"{x:508,y:749,t:1526933834399};\\\", \\\"{x:506,y:745,t:1526933834415};\\\", \\\"{x:505,y:743,t:1526933834432};\\\", \\\"{x:505,y:740,t:1526933834449};\\\", \\\"{x:505,y:738,t:1526933834465};\\\", \\\"{x:505,y:737,t:1526933834482};\\\", \\\"{x:504,y:737,t:1526933835032};\\\", \\\"{x:528,y:737,t:1526933835616};\\\", \\\"{x:611,y:744,t:1526933835633};\\\", \\\"{x:700,y:744,t:1526933835650};\\\", \\\"{x:827,y:744,t:1526933835675};\\\", \\\"{x:891,y:744,t:1526933835694};\\\", \\\"{x:911,y:744,t:1526933835699};\\\", \\\"{x:937,y:744,t:1526933835716};\\\", \\\"{x:950,y:744,t:1526933835733};\\\", \\\"{x:954,y:744,t:1526933835749};\\\", \\\"{x:955,y:744,t:1526933835766};\\\", \\\"{x:957,y:744,t:1526933835783};\\\", \\\"{x:958,y:744,t:1526933835799};\\\" ] }, { \\\"rt\\\": 47008, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 638235, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-03 PM-X -03 PM-F -F -B -B -F -F -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:961,y:744,t:1526933838384};\\\", \\\"{x:968,y:745,t:1526933838402};\\\", \\\"{x:980,y:748,t:1526933838419};\\\", \\\"{x:992,y:751,t:1526933838436};\\\", \\\"{x:1001,y:754,t:1526933838451};\\\", \\\"{x:1011,y:755,t:1526933838468};\\\", \\\"{x:1018,y:756,t:1526933838485};\\\", \\\"{x:1021,y:757,t:1526933838501};\\\", \\\"{x:1026,y:758,t:1526933838519};\\\", \\\"{x:1033,y:762,t:1526933838535};\\\", \\\"{x:1036,y:762,t:1526933838552};\\\", \\\"{x:1040,y:765,t:1526933838569};\\\", \\\"{x:1045,y:769,t:1526933838586};\\\", \\\"{x:1049,y:770,t:1526933838602};\\\", \\\"{x:1051,y:771,t:1526933838619};\\\", \\\"{x:1052,y:771,t:1526933839121};\\\", \\\"{x:1052,y:770,t:1526933839135};\\\", \\\"{x:1053,y:768,t:1526933839153};\\\", \\\"{x:1054,y:768,t:1526933839199};\\\", \\\"{x:1055,y:768,t:1526933839207};\\\", \\\"{x:1057,y:768,t:1526933839218};\\\", \\\"{x:1061,y:770,t:1526933839235};\\\", \\\"{x:1067,y:778,t:1526933839252};\\\", \\\"{x:1077,y:789,t:1526933839268};\\\", \\\"{x:1093,y:802,t:1526933839286};\\\", \\\"{x:1116,y:818,t:1526933839302};\\\", \\\"{x:1154,y:836,t:1526933839319};\\\", \\\"{x:1227,y:873,t:1526933839336};\\\", \\\"{x:1278,y:890,t:1526933839353};\\\", \\\"{x:1330,y:910,t:1526933839369};\\\", \\\"{x:1391,y:927,t:1526933839386};\\\", \\\"{x:1457,y:944,t:1526933839403};\\\", \\\"{x:1515,y:961,t:1526933839419};\\\", \\\"{x:1569,y:968,t:1526933839436};\\\", \\\"{x:1602,y:971,t:1526933839453};\\\", \\\"{x:1628,y:971,t:1526933839470};\\\", \\\"{x:1654,y:971,t:1526933839487};\\\", \\\"{x:1670,y:973,t:1526933839503};\\\", \\\"{x:1680,y:975,t:1526933839519};\\\", \\\"{x:1681,y:976,t:1526933839608};\\\", \\\"{x:1681,y:978,t:1526933839619};\\\", \\\"{x:1677,y:982,t:1526933839635};\\\", \\\"{x:1670,y:987,t:1526933839653};\\\", \\\"{x:1658,y:990,t:1526933839669};\\\", \\\"{x:1647,y:992,t:1526933839685};\\\", \\\"{x:1635,y:995,t:1526933839702};\\\", \\\"{x:1610,y:998,t:1526933839719};\\\", \\\"{x:1596,y:998,t:1526933839736};\\\", \\\"{x:1583,y:994,t:1526933839752};\\\", \\\"{x:1575,y:989,t:1526933839770};\\\", \\\"{x:1564,y:985,t:1526933839786};\\\", \\\"{x:1559,y:981,t:1526933839803};\\\", \\\"{x:1551,y:975,t:1526933839820};\\\", \\\"{x:1548,y:973,t:1526933839836};\\\", \\\"{x:1548,y:972,t:1526933839920};\\\", \\\"{x:1548,y:971,t:1526933839943};\\\", \\\"{x:1548,y:970,t:1526933839953};\\\", \\\"{x:1549,y:970,t:1526933845001};\\\", \\\"{x:1550,y:960,t:1526933845008};\\\", \\\"{x:1536,y:900,t:1526933845024};\\\", \\\"{x:1523,y:855,t:1526933845040};\\\", \\\"{x:1519,y:841,t:1526933845057};\\\", \\\"{x:1517,y:836,t:1526933845073};\\\", \\\"{x:1515,y:832,t:1526933845091};\\\", \\\"{x:1514,y:831,t:1526933845120};\\\", \\\"{x:1514,y:829,t:1526933845232};\\\", \\\"{x:1514,y:826,t:1526933845241};\\\", \\\"{x:1506,y:817,t:1526933845258};\\\", \\\"{x:1502,y:813,t:1526933845274};\\\", \\\"{x:1498,y:810,t:1526933845291};\\\", \\\"{x:1496,y:809,t:1526933845307};\\\", \\\"{x:1495,y:809,t:1526933845324};\\\", \\\"{x:1495,y:810,t:1526933845427};\\\", \\\"{x:1495,y:813,t:1526933845444};\\\", \\\"{x:1495,y:815,t:1526933845461};\\\", \\\"{x:1495,y:817,t:1526933845478};\\\", \\\"{x:1494,y:820,t:1526933845494};\\\", \\\"{x:1493,y:821,t:1526933845580};\\\", \\\"{x:1492,y:821,t:1526933845594};\\\", \\\"{x:1491,y:821,t:1526933845611};\\\", \\\"{x:1490,y:822,t:1526933845628};\\\", \\\"{x:1489,y:823,t:1526933845644};\\\", \\\"{x:1487,y:823,t:1526933845661};\\\", \\\"{x:1483,y:825,t:1526933845681};\\\", \\\"{x:1481,y:827,t:1526933845694};\\\", \\\"{x:1478,y:830,t:1526933845710};\\\", \\\"{x:1476,y:831,t:1526933845728};\\\", \\\"{x:1474,y:832,t:1526933845745};\\\", \\\"{x:1473,y:833,t:1526933845760};\\\", \\\"{x:1472,y:833,t:1526933845795};\\\", \\\"{x:1472,y:834,t:1526933845899};\\\", \\\"{x:1472,y:835,t:1526933845911};\\\", \\\"{x:1475,y:836,t:1526933845928};\\\", \\\"{x:1477,y:837,t:1526933845945};\\\", \\\"{x:1478,y:837,t:1526933845961};\\\", \\\"{x:1479,y:837,t:1526933845979};\\\", \\\"{x:1480,y:837,t:1526933846019};\\\", \\\"{x:1482,y:837,t:1526933846092};\\\", \\\"{x:1484,y:837,t:1526933846100};\\\", \\\"{x:1486,y:837,t:1526933846111};\\\", \\\"{x:1495,y:837,t:1526933846128};\\\", \\\"{x:1509,y:837,t:1526933846145};\\\", \\\"{x:1523,y:837,t:1526933846162};\\\", \\\"{x:1531,y:837,t:1526933846178};\\\", \\\"{x:1536,y:837,t:1526933846195};\\\", \\\"{x:1537,y:837,t:1526933846211};\\\", \\\"{x:1537,y:836,t:1526933846252};\\\", \\\"{x:1538,y:836,t:1526933846262};\\\", \\\"{x:1538,y:835,t:1526933846278};\\\", \\\"{x:1539,y:835,t:1526933846295};\\\", \\\"{x:1541,y:833,t:1526933846312};\\\", \\\"{x:1541,y:832,t:1526933846355};\\\", \\\"{x:1541,y:831,t:1526933846380};\\\", \\\"{x:1541,y:830,t:1526933846395};\\\", \\\"{x:1541,y:826,t:1526933846412};\\\", \\\"{x:1541,y:823,t:1526933846428};\\\", \\\"{x:1542,y:821,t:1526933846446};\\\", \\\"{x:1543,y:820,t:1526933846462};\\\", \\\"{x:1545,y:820,t:1526933846580};\\\", \\\"{x:1547,y:824,t:1526933846595};\\\", \\\"{x:1553,y:832,t:1526933846612};\\\", \\\"{x:1559,y:839,t:1526933846629};\\\", \\\"{x:1563,y:845,t:1526933846645};\\\", \\\"{x:1565,y:847,t:1526933846663};\\\", \\\"{x:1566,y:849,t:1526933846679};\\\", \\\"{x:1567,y:849,t:1526933846695};\\\", \\\"{x:1568,y:849,t:1526933846748};\\\", \\\"{x:1569,y:850,t:1526933846771};\\\", \\\"{x:1570,y:850,t:1526933846779};\\\", \\\"{x:1573,y:850,t:1526933846796};\\\", \\\"{x:1578,y:850,t:1526933846812};\\\", \\\"{x:1583,y:850,t:1526933846829};\\\", \\\"{x:1588,y:850,t:1526933846845};\\\", \\\"{x:1593,y:850,t:1526933846862};\\\", \\\"{x:1597,y:850,t:1526933846880};\\\", \\\"{x:1601,y:850,t:1526933846895};\\\", \\\"{x:1604,y:850,t:1526933846912};\\\", \\\"{x:1605,y:850,t:1526933846930};\\\", \\\"{x:1607,y:850,t:1526933846945};\\\", \\\"{x:1610,y:849,t:1526933846962};\\\", \\\"{x:1614,y:846,t:1526933846979};\\\", \\\"{x:1615,y:845,t:1526933846995};\\\", \\\"{x:1616,y:842,t:1526933847012};\\\", \\\"{x:1617,y:840,t:1526933847029};\\\", \\\"{x:1619,y:836,t:1526933847045};\\\", \\\"{x:1622,y:834,t:1526933847062};\\\", \\\"{x:1622,y:832,t:1526933847081};\\\", \\\"{x:1618,y:833,t:1526933847411};\\\", \\\"{x:1612,y:839,t:1526933847429};\\\", \\\"{x:1606,y:845,t:1526933847446};\\\", \\\"{x:1602,y:849,t:1526933847462};\\\", \\\"{x:1600,y:853,t:1526933847482};\\\", \\\"{x:1599,y:856,t:1526933847496};\\\", \\\"{x:1598,y:860,t:1526933847512};\\\", \\\"{x:1598,y:864,t:1526933847529};\\\", \\\"{x:1596,y:873,t:1526933847546};\\\", \\\"{x:1591,y:886,t:1526933847564};\\\", \\\"{x:1589,y:895,t:1526933847579};\\\", \\\"{x:1587,y:901,t:1526933847595};\\\", \\\"{x:1586,y:906,t:1526933847613};\\\", \\\"{x:1584,y:910,t:1526933847629};\\\", \\\"{x:1582,y:914,t:1526933847646};\\\", \\\"{x:1580,y:922,t:1526933847663};\\\", \\\"{x:1574,y:933,t:1526933847681};\\\", \\\"{x:1568,y:945,t:1526933847696};\\\", \\\"{x:1562,y:955,t:1526933847713};\\\", \\\"{x:1557,y:964,t:1526933847730};\\\", \\\"{x:1556,y:969,t:1526933847747};\\\", \\\"{x:1554,y:975,t:1526933847762};\\\", \\\"{x:1553,y:978,t:1526933847779};\\\", \\\"{x:1553,y:979,t:1526933847803};\\\", \\\"{x:1553,y:975,t:1526933847915};\\\", \\\"{x:1553,y:969,t:1526933847930};\\\", \\\"{x:1553,y:959,t:1526933847947};\\\", \\\"{x:1553,y:950,t:1526933847963};\\\", \\\"{x:1552,y:948,t:1526933847979};\\\", \\\"{x:1551,y:947,t:1526933847996};\\\", \\\"{x:1551,y:945,t:1526933848180};\\\", \\\"{x:1551,y:941,t:1526933848196};\\\", \\\"{x:1551,y:933,t:1526933848213};\\\", \\\"{x:1550,y:923,t:1526933848230};\\\", \\\"{x:1550,y:910,t:1526933848246};\\\", \\\"{x:1549,y:894,t:1526933848263};\\\", \\\"{x:1547,y:881,t:1526933848281};\\\", \\\"{x:1547,y:873,t:1526933848296};\\\", \\\"{x:1547,y:865,t:1526933848313};\\\", \\\"{x:1547,y:861,t:1526933848330};\\\", \\\"{x:1547,y:856,t:1526933848346};\\\", \\\"{x:1547,y:846,t:1526933848363};\\\", \\\"{x:1547,y:842,t:1526933848380};\\\", \\\"{x:1547,y:836,t:1526933848396};\\\", \\\"{x:1547,y:829,t:1526933848413};\\\", \\\"{x:1547,y:820,t:1526933848431};\\\", \\\"{x:1547,y:813,t:1526933848446};\\\", \\\"{x:1547,y:809,t:1526933848463};\\\", \\\"{x:1547,y:805,t:1526933848481};\\\", \\\"{x:1547,y:802,t:1526933848496};\\\", \\\"{x:1547,y:796,t:1526933848514};\\\", \\\"{x:1547,y:788,t:1526933848530};\\\", \\\"{x:1547,y:779,t:1526933848547};\\\", \\\"{x:1547,y:773,t:1526933848563};\\\", \\\"{x:1547,y:767,t:1526933848580};\\\", \\\"{x:1547,y:761,t:1526933848597};\\\", \\\"{x:1547,y:756,t:1526933848614};\\\", \\\"{x:1547,y:750,t:1526933848630};\\\", \\\"{x:1547,y:746,t:1526933848647};\\\", \\\"{x:1547,y:741,t:1526933848663};\\\", \\\"{x:1547,y:735,t:1526933848682};\\\", \\\"{x:1547,y:731,t:1526933848697};\\\", \\\"{x:1547,y:726,t:1526933848713};\\\", \\\"{x:1547,y:723,t:1526933848730};\\\", \\\"{x:1547,y:716,t:1526933848747};\\\", \\\"{x:1547,y:713,t:1526933848763};\\\", \\\"{x:1547,y:709,t:1526933848779};\\\", \\\"{x:1548,y:705,t:1526933848797};\\\", \\\"{x:1548,y:702,t:1526933848813};\\\", \\\"{x:1549,y:698,t:1526933848830};\\\", \\\"{x:1549,y:697,t:1526933848847};\\\", \\\"{x:1549,y:696,t:1526933848863};\\\", \\\"{x:1549,y:695,t:1526933848880};\\\", \\\"{x:1549,y:694,t:1526933848906};\\\", \\\"{x:1549,y:693,t:1526933848922};\\\", \\\"{x:1549,y:692,t:1526933848939};\\\", \\\"{x:1543,y:692,t:1526933849587};\\\", \\\"{x:1533,y:692,t:1526933849597};\\\", \\\"{x:1510,y:692,t:1526933849615};\\\", \\\"{x:1484,y:692,t:1526933849631};\\\", \\\"{x:1461,y:692,t:1526933849647};\\\", \\\"{x:1445,y:692,t:1526933849665};\\\", \\\"{x:1432,y:692,t:1526933849681};\\\", \\\"{x:1427,y:692,t:1526933849697};\\\", \\\"{x:1424,y:692,t:1526933849714};\\\", \\\"{x:1415,y:691,t:1526933849731};\\\", \\\"{x:1408,y:691,t:1526933849747};\\\", \\\"{x:1401,y:691,t:1526933849765};\\\", \\\"{x:1394,y:692,t:1526933849781};\\\", \\\"{x:1389,y:692,t:1526933849797};\\\", \\\"{x:1385,y:692,t:1526933849815};\\\", \\\"{x:1381,y:693,t:1526933849831};\\\", \\\"{x:1379,y:693,t:1526933849847};\\\", \\\"{x:1375,y:693,t:1526933849864};\\\", \\\"{x:1371,y:693,t:1526933849881};\\\", \\\"{x:1364,y:693,t:1526933849898};\\\", \\\"{x:1355,y:693,t:1526933849914};\\\", \\\"{x:1345,y:695,t:1526933849932};\\\", \\\"{x:1343,y:695,t:1526933849947};\\\", \\\"{x:1342,y:695,t:1526933849964};\\\", \\\"{x:1340,y:695,t:1526933849982};\\\", \\\"{x:1339,y:695,t:1526933849998};\\\", \\\"{x:1337,y:695,t:1526933850014};\\\", \\\"{x:1335,y:695,t:1526933850031};\\\", \\\"{x:1334,y:694,t:1526933850067};\\\", \\\"{x:1334,y:693,t:1526933850107};\\\", \\\"{x:1337,y:693,t:1526933850123};\\\", \\\"{x:1339,y:693,t:1526933850131};\\\", \\\"{x:1347,y:695,t:1526933850148};\\\", \\\"{x:1357,y:698,t:1526933850165};\\\", \\\"{x:1367,y:701,t:1526933850182};\\\", \\\"{x:1371,y:703,t:1526933850198};\\\", \\\"{x:1376,y:704,t:1526933850215};\\\", \\\"{x:1376,y:705,t:1526933850232};\\\", \\\"{x:1377,y:706,t:1526933850249};\\\", \\\"{x:1379,y:706,t:1526933850267};\\\", \\\"{x:1382,y:706,t:1526933850282};\\\", \\\"{x:1389,y:706,t:1526933850298};\\\", \\\"{x:1399,y:706,t:1526933850313};\\\", \\\"{x:1411,y:701,t:1526933850330};\\\", \\\"{x:1414,y:699,t:1526933850347};\\\", \\\"{x:1414,y:698,t:1526933850370};\\\", \\\"{x:1414,y:697,t:1526933850386};\\\", \\\"{x:1414,y:696,t:1526933850403};\\\", \\\"{x:1414,y:694,t:1526933850414};\\\", \\\"{x:1414,y:692,t:1526933850431};\\\", \\\"{x:1416,y:689,t:1526933850448};\\\", \\\"{x:1416,y:688,t:1526933850464};\\\", \\\"{x:1417,y:688,t:1526933850644};\\\", \\\"{x:1421,y:688,t:1526933850650};\\\", \\\"{x:1426,y:692,t:1526933850665};\\\", \\\"{x:1433,y:699,t:1526933850681};\\\", \\\"{x:1443,y:704,t:1526933850698};\\\", \\\"{x:1452,y:708,t:1526933850714};\\\", \\\"{x:1456,y:710,t:1526933850731};\\\", \\\"{x:1459,y:710,t:1526933850748};\\\", \\\"{x:1464,y:710,t:1526933850765};\\\", \\\"{x:1467,y:710,t:1526933850781};\\\", \\\"{x:1474,y:706,t:1526933850798};\\\", \\\"{x:1478,y:705,t:1526933850815};\\\", \\\"{x:1483,y:702,t:1526933850831};\\\", \\\"{x:1485,y:700,t:1526933850848};\\\", \\\"{x:1487,y:695,t:1526933850865};\\\", \\\"{x:1488,y:691,t:1526933850882};\\\", \\\"{x:1488,y:690,t:1526933850898};\\\", \\\"{x:1489,y:688,t:1526933850915};\\\", \\\"{x:1489,y:686,t:1526933850947};\\\", \\\"{x:1490,y:686,t:1526933851210};\\\", \\\"{x:1491,y:686,t:1526933851218};\\\", \\\"{x:1493,y:688,t:1526933851231};\\\", \\\"{x:1499,y:694,t:1526933851247};\\\", \\\"{x:1502,y:699,t:1526933851264};\\\", \\\"{x:1506,y:703,t:1526933851282};\\\", \\\"{x:1511,y:705,t:1526933851297};\\\", \\\"{x:1518,y:706,t:1526933851315};\\\", \\\"{x:1523,y:706,t:1526933851332};\\\", \\\"{x:1527,y:706,t:1526933851348};\\\", \\\"{x:1531,y:706,t:1526933851365};\\\", \\\"{x:1535,y:705,t:1526933851382};\\\", \\\"{x:1539,y:705,t:1526933851399};\\\", \\\"{x:1544,y:702,t:1526933851415};\\\", \\\"{x:1547,y:699,t:1526933851432};\\\", \\\"{x:1550,y:696,t:1526933851449};\\\", \\\"{x:1551,y:694,t:1526933851465};\\\", \\\"{x:1551,y:692,t:1526933851482};\\\", \\\"{x:1553,y:688,t:1526933851499};\\\", \\\"{x:1553,y:687,t:1526933851515};\\\", \\\"{x:1554,y:687,t:1526933851532};\\\", \\\"{x:1554,y:688,t:1526933851755};\\\", \\\"{x:1555,y:689,t:1526933851883};\\\", \\\"{x:1556,y:689,t:1526933851900};\\\", \\\"{x:1560,y:690,t:1526933851915};\\\", \\\"{x:1568,y:692,t:1526933851932};\\\", \\\"{x:1583,y:698,t:1526933851949};\\\", \\\"{x:1595,y:702,t:1526933851967};\\\", \\\"{x:1609,y:706,t:1526933851982};\\\", \\\"{x:1625,y:709,t:1526933851999};\\\", \\\"{x:1639,y:710,t:1526933852016};\\\", \\\"{x:1650,y:712,t:1526933852033};\\\", \\\"{x:1658,y:712,t:1526933852049};\\\", \\\"{x:1662,y:712,t:1526933852066};\\\", \\\"{x:1665,y:712,t:1526933852082};\\\", \\\"{x:1665,y:711,t:1526933852099};\\\", \\\"{x:1663,y:711,t:1526933852131};\\\", \\\"{x:1661,y:709,t:1526933852149};\\\", \\\"{x:1654,y:708,t:1526933852167};\\\", \\\"{x:1643,y:708,t:1526933852182};\\\", \\\"{x:1628,y:708,t:1526933852199};\\\", \\\"{x:1614,y:710,t:1526933852216};\\\", \\\"{x:1597,y:715,t:1526933852232};\\\", \\\"{x:1581,y:719,t:1526933852249};\\\", \\\"{x:1572,y:722,t:1526933852267};\\\", \\\"{x:1568,y:722,t:1526933852282};\\\", \\\"{x:1567,y:723,t:1526933852299};\\\", \\\"{x:1566,y:723,t:1526933852372};\\\", \\\"{x:1565,y:722,t:1526933852395};\\\", \\\"{x:1565,y:719,t:1526933852404};\\\", \\\"{x:1565,y:716,t:1526933852417};\\\", \\\"{x:1565,y:709,t:1526933852433};\\\", \\\"{x:1564,y:706,t:1526933852450};\\\", \\\"{x:1563,y:703,t:1526933852466};\\\", \\\"{x:1563,y:702,t:1526933852484};\\\", \\\"{x:1562,y:701,t:1526933852540};\\\", \\\"{x:1562,y:699,t:1526933852588};\\\", \\\"{x:1561,y:699,t:1526933852600};\\\", \\\"{x:1560,y:699,t:1526933852616};\\\", \\\"{x:1559,y:698,t:1526933852634};\\\", \\\"{x:1557,y:698,t:1526933852649};\\\", \\\"{x:1556,y:698,t:1526933852667};\\\", \\\"{x:1554,y:698,t:1526933852683};\\\", \\\"{x:1553,y:698,t:1526933852707};\\\", \\\"{x:1552,y:697,t:1526933852716};\\\", \\\"{x:1551,y:696,t:1526933852755};\\\", \\\"{x:1550,y:695,t:1526933852787};\\\", \\\"{x:1549,y:695,t:1526933852836};\\\", \\\"{x:1548,y:695,t:1526933852860};\\\", \\\"{x:1547,y:694,t:1526933853339};\\\", \\\"{x:1547,y:693,t:1526933853620};\\\", \\\"{x:1546,y:691,t:1526933853633};\\\", \\\"{x:1544,y:688,t:1526933853650};\\\", \\\"{x:1542,y:681,t:1526933853667};\\\", \\\"{x:1539,y:676,t:1526933853684};\\\", \\\"{x:1538,y:670,t:1526933853701};\\\", \\\"{x:1538,y:668,t:1526933853718};\\\", \\\"{x:1538,y:666,t:1526933853733};\\\", \\\"{x:1538,y:665,t:1526933853751};\\\", \\\"{x:1538,y:663,t:1526933853766};\\\", \\\"{x:1537,y:662,t:1526933853784};\\\", \\\"{x:1537,y:661,t:1526933853800};\\\", \\\"{x:1537,y:658,t:1526933853817};\\\", \\\"{x:1537,y:657,t:1526933853834};\\\", \\\"{x:1536,y:653,t:1526933853850};\\\", \\\"{x:1536,y:650,t:1526933853866};\\\", \\\"{x:1536,y:648,t:1526933853884};\\\", \\\"{x:1535,y:642,t:1526933853899};\\\", \\\"{x:1534,y:636,t:1526933853917};\\\", \\\"{x:1533,y:632,t:1526933853934};\\\", \\\"{x:1533,y:631,t:1526933853996};\\\", \\\"{x:1537,y:631,t:1526933854180};\\\", \\\"{x:1538,y:637,t:1526933854187};\\\", \\\"{x:1541,y:641,t:1526933854201};\\\", \\\"{x:1545,y:651,t:1526933854217};\\\", \\\"{x:1547,y:661,t:1526933854234};\\\", \\\"{x:1548,y:671,t:1526933854251};\\\", \\\"{x:1548,y:677,t:1526933854267};\\\", \\\"{x:1548,y:684,t:1526933854284};\\\", \\\"{x:1548,y:691,t:1526933854301};\\\", \\\"{x:1549,y:695,t:1526933854317};\\\", \\\"{x:1549,y:697,t:1526933854334};\\\", \\\"{x:1550,y:698,t:1526933854351};\\\", \\\"{x:1550,y:699,t:1526933854367};\\\", \\\"{x:1550,y:698,t:1526933854483};\\\", \\\"{x:1551,y:695,t:1526933854501};\\\", \\\"{x:1551,y:689,t:1526933854517};\\\", \\\"{x:1553,y:683,t:1526933854535};\\\", \\\"{x:1553,y:675,t:1526933854551};\\\", \\\"{x:1553,y:666,t:1526933854568};\\\", \\\"{x:1553,y:659,t:1526933854584};\\\", \\\"{x:1553,y:655,t:1526933854601};\\\", \\\"{x:1553,y:652,t:1526933854617};\\\", \\\"{x:1553,y:650,t:1526933854635};\\\", \\\"{x:1553,y:649,t:1526933854652};\\\", \\\"{x:1553,y:646,t:1526933854779};\\\", \\\"{x:1553,y:645,t:1526933854795};\\\", \\\"{x:1553,y:644,t:1526933854803};\\\", \\\"{x:1553,y:642,t:1526933854819};\\\", \\\"{x:1553,y:641,t:1526933854835};\\\", \\\"{x:1553,y:640,t:1526933854851};\\\", \\\"{x:1553,y:639,t:1526933854869};\\\", \\\"{x:1552,y:637,t:1526933854884};\\\", \\\"{x:1552,y:636,t:1526933854901};\\\", \\\"{x:1552,y:635,t:1526933854918};\\\", \\\"{x:1551,y:635,t:1526933854939};\\\", \\\"{x:1551,y:634,t:1526933854951};\\\", \\\"{x:1550,y:632,t:1526933855035};\\\", \\\"{x:1550,y:630,t:1526933855051};\\\", \\\"{x:1549,y:627,t:1526933855069};\\\", \\\"{x:1549,y:626,t:1526933855084};\\\", \\\"{x:1548,y:624,t:1526933855101};\\\", \\\"{x:1547,y:624,t:1526933855948};\\\", \\\"{x:1547,y:627,t:1526933855955};\\\", \\\"{x:1547,y:636,t:1526933855969};\\\", \\\"{x:1547,y:652,t:1526933855985};\\\", \\\"{x:1547,y:667,t:1526933856003};\\\", \\\"{x:1547,y:682,t:1526933856018};\\\", \\\"{x:1547,y:694,t:1526933856036};\\\", \\\"{x:1547,y:698,t:1526933856053};\\\", \\\"{x:1548,y:700,t:1526933856069};\\\", \\\"{x:1548,y:701,t:1526933856086};\\\", \\\"{x:1548,y:702,t:1526933856102};\\\", \\\"{x:1548,y:703,t:1526933856156};\\\", \\\"{x:1548,y:704,t:1526933856411};\\\", \\\"{x:1548,y:705,t:1526933856419};\\\", \\\"{x:1548,y:708,t:1526933856435};\\\", \\\"{x:1548,y:711,t:1526933856452};\\\", \\\"{x:1548,y:716,t:1526933856470};\\\", \\\"{x:1548,y:718,t:1526933856485};\\\", \\\"{x:1548,y:719,t:1526933856502};\\\", \\\"{x:1548,y:721,t:1526933856519};\\\", \\\"{x:1548,y:723,t:1526933857106};\\\", \\\"{x:1548,y:726,t:1526933857119};\\\", \\\"{x:1548,y:730,t:1526933857135};\\\", \\\"{x:1547,y:734,t:1526933857153};\\\", \\\"{x:1547,y:737,t:1526933857169};\\\", \\\"{x:1547,y:738,t:1526933857186};\\\", \\\"{x:1547,y:739,t:1526933857459};\\\", \\\"{x:1547,y:740,t:1526933857475};\\\", \\\"{x:1547,y:742,t:1526933857492};\\\", \\\"{x:1547,y:743,t:1526933857515};\\\", \\\"{x:1547,y:745,t:1526933857523};\\\", \\\"{x:1547,y:746,t:1526933857732};\\\", \\\"{x:1547,y:748,t:1526933857763};\\\", \\\"{x:1547,y:749,t:1526933857804};\\\", \\\"{x:1547,y:751,t:1526933863123};\\\", \\\"{x:1543,y:756,t:1526933863141};\\\", \\\"{x:1542,y:757,t:1526933863157};\\\", \\\"{x:1537,y:759,t:1526933863173};\\\", \\\"{x:1528,y:760,t:1526933863191};\\\", \\\"{x:1509,y:760,t:1526933863207};\\\", \\\"{x:1487,y:760,t:1526933863224};\\\", \\\"{x:1457,y:760,t:1526933863241};\\\", \\\"{x:1442,y:758,t:1526933863257};\\\", \\\"{x:1432,y:753,t:1526933863275};\\\", \\\"{x:1423,y:752,t:1526933863291};\\\", \\\"{x:1415,y:752,t:1526933863307};\\\", \\\"{x:1408,y:752,t:1526933863325};\\\", \\\"{x:1399,y:752,t:1526933863341};\\\", \\\"{x:1390,y:752,t:1526933863358};\\\", \\\"{x:1376,y:752,t:1526933863375};\\\", \\\"{x:1354,y:756,t:1526933863391};\\\", \\\"{x:1337,y:761,t:1526933863408};\\\", \\\"{x:1335,y:762,t:1526933863425};\\\", \\\"{x:1336,y:762,t:1526933863524};\\\", \\\"{x:1339,y:760,t:1526933863540};\\\", \\\"{x:1341,y:759,t:1526933863558};\\\", \\\"{x:1347,y:755,t:1526933863575};\\\", \\\"{x:1363,y:752,t:1526933863592};\\\", \\\"{x:1372,y:749,t:1526933863608};\\\", \\\"{x:1381,y:748,t:1526933863625};\\\", \\\"{x:1383,y:748,t:1526933863641};\\\", \\\"{x:1385,y:748,t:1526933863658};\\\", \\\"{x:1382,y:748,t:1526933863810};\\\", \\\"{x:1380,y:748,t:1526933863826};\\\", \\\"{x:1379,y:749,t:1526933863841};\\\", \\\"{x:1375,y:751,t:1526933863857};\\\", \\\"{x:1368,y:755,t:1526933863875};\\\", \\\"{x:1364,y:758,t:1526933863891};\\\", \\\"{x:1362,y:760,t:1526933863907};\\\", \\\"{x:1362,y:762,t:1526933863924};\\\", \\\"{x:1360,y:763,t:1526933863942};\\\", \\\"{x:1360,y:764,t:1526933864084};\\\", \\\"{x:1359,y:765,t:1526933864115};\\\", \\\"{x:1357,y:765,t:1526933864459};\\\", \\\"{x:1355,y:765,t:1526933864475};\\\", \\\"{x:1353,y:765,t:1526933864492};\\\", \\\"{x:1352,y:765,t:1526933864509};\\\", \\\"{x:1350,y:765,t:1526933864524};\\\", \\\"{x:1349,y:765,t:1526933864541};\\\", \\\"{x:1347,y:765,t:1526933864683};\\\", \\\"{x:1346,y:765,t:1526933864763};\\\", \\\"{x:1345,y:765,t:1526933864779};\\\", \\\"{x:1346,y:765,t:1526933864939};\\\", \\\"{x:1347,y:765,t:1526933864946};\\\", \\\"{x:1348,y:765,t:1526933864970};\\\", \\\"{x:1349,y:765,t:1526933864979};\\\", \\\"{x:1350,y:766,t:1526933864991};\\\", \\\"{x:1352,y:766,t:1526933865011};\\\", \\\"{x:1353,y:766,t:1526933865028};\\\", \\\"{x:1354,y:766,t:1526933865041};\\\", \\\"{x:1356,y:768,t:1526933865059};\\\", \\\"{x:1358,y:768,t:1526933865075};\\\", \\\"{x:1362,y:769,t:1526933865092};\\\", \\\"{x:1366,y:771,t:1526933865109};\\\", \\\"{x:1371,y:772,t:1526933865126};\\\", \\\"{x:1375,y:774,t:1526933865142};\\\", \\\"{x:1378,y:775,t:1526933865160};\\\", \\\"{x:1382,y:775,t:1526933865176};\\\", \\\"{x:1385,y:775,t:1526933865193};\\\", \\\"{x:1387,y:775,t:1526933865209};\\\", \\\"{x:1389,y:775,t:1526933865226};\\\", \\\"{x:1392,y:775,t:1526933865242};\\\", \\\"{x:1394,y:775,t:1526933865259};\\\", \\\"{x:1396,y:775,t:1526933865276};\\\", \\\"{x:1399,y:775,t:1526933865292};\\\", \\\"{x:1402,y:773,t:1526933865308};\\\", \\\"{x:1405,y:772,t:1526933865325};\\\", \\\"{x:1410,y:769,t:1526933865342};\\\", \\\"{x:1413,y:768,t:1526933865358};\\\", \\\"{x:1416,y:767,t:1526933865375};\\\", \\\"{x:1418,y:766,t:1526933865392};\\\", \\\"{x:1419,y:765,t:1526933865408};\\\", \\\"{x:1419,y:764,t:1526933865425};\\\", \\\"{x:1420,y:763,t:1526933865451};\\\", \\\"{x:1421,y:761,t:1526933865458};\\\", \\\"{x:1421,y:760,t:1526933865491};\\\", \\\"{x:1421,y:759,t:1526933865499};\\\", \\\"{x:1421,y:758,t:1526933865515};\\\", \\\"{x:1422,y:758,t:1526933865786};\\\", \\\"{x:1425,y:758,t:1526933865794};\\\", \\\"{x:1432,y:762,t:1526933865809};\\\", \\\"{x:1443,y:768,t:1526933865825};\\\", \\\"{x:1459,y:774,t:1526933865842};\\\", \\\"{x:1466,y:774,t:1526933865859};\\\", \\\"{x:1469,y:774,t:1526933865875};\\\", \\\"{x:1471,y:774,t:1526933865892};\\\", \\\"{x:1472,y:774,t:1526933865915};\\\", \\\"{x:1474,y:774,t:1526933865947};\\\", \\\"{x:1475,y:773,t:1526933865959};\\\", \\\"{x:1478,y:772,t:1526933865975};\\\", \\\"{x:1480,y:770,t:1526933865992};\\\", \\\"{x:1482,y:770,t:1526933866010};\\\", \\\"{x:1483,y:767,t:1526933866025};\\\", \\\"{x:1485,y:766,t:1526933866042};\\\", \\\"{x:1485,y:765,t:1526933866059};\\\", \\\"{x:1486,y:764,t:1526933866076};\\\", \\\"{x:1487,y:762,t:1526933866099};\\\", \\\"{x:1488,y:761,t:1526933866110};\\\", \\\"{x:1489,y:760,t:1526933866126};\\\", \\\"{x:1489,y:759,t:1526933866188};\\\", \\\"{x:1492,y:759,t:1526933866308};\\\", \\\"{x:1495,y:762,t:1526933866315};\\\", \\\"{x:1497,y:763,t:1526933866327};\\\", \\\"{x:1504,y:767,t:1526933866343};\\\", \\\"{x:1509,y:770,t:1526933866360};\\\", \\\"{x:1510,y:770,t:1526933866377};\\\", \\\"{x:1511,y:770,t:1526933866428};\\\", \\\"{x:1514,y:770,t:1526933866443};\\\", \\\"{x:1519,y:770,t:1526933866460};\\\", \\\"{x:1527,y:769,t:1526933866477};\\\", \\\"{x:1536,y:768,t:1526933866493};\\\", \\\"{x:1541,y:766,t:1526933866510};\\\", \\\"{x:1544,y:765,t:1526933866526};\\\", \\\"{x:1545,y:764,t:1526933866542};\\\", \\\"{x:1546,y:764,t:1526933866579};\\\", \\\"{x:1547,y:763,t:1526933866593};\\\", \\\"{x:1548,y:762,t:1526933866610};\\\", \\\"{x:1550,y:762,t:1526933866627};\\\", \\\"{x:1553,y:760,t:1526933866643};\\\", \\\"{x:1553,y:759,t:1526933866667};\\\", \\\"{x:1545,y:759,t:1526933867467};\\\", \\\"{x:1524,y:759,t:1526933867477};\\\", \\\"{x:1463,y:759,t:1526933867494};\\\", \\\"{x:1396,y:759,t:1526933867511};\\\", \\\"{x:1324,y:759,t:1526933867527};\\\", \\\"{x:1240,y:755,t:1526933867544};\\\", \\\"{x:1168,y:748,t:1526933867561};\\\", \\\"{x:1126,y:741,t:1526933867578};\\\", \\\"{x:1102,y:737,t:1526933867594};\\\", \\\"{x:1076,y:735,t:1526933867610};\\\", \\\"{x:1046,y:731,t:1526933867627};\\\", \\\"{x:995,y:728,t:1526933867644};\\\", \\\"{x:930,y:725,t:1526933867661};\\\", \\\"{x:860,y:725,t:1526933867678};\\\", \\\"{x:777,y:725,t:1526933867694};\\\", \\\"{x:732,y:723,t:1526933867711};\\\", \\\"{x:731,y:722,t:1526933867727};\\\", \\\"{x:731,y:721,t:1526933868011};\\\", \\\"{x:711,y:718,t:1526933868083};\\\", \\\"{x:682,y:720,t:1526933868095};\\\", \\\"{x:571,y:707,t:1526933868110};\\\", \\\"{x:459,y:679,t:1526933868128};\\\", \\\"{x:371,y:645,t:1526933868147};\\\", \\\"{x:315,y:616,t:1526933868162};\\\", \\\"{x:263,y:595,t:1526933868177};\\\", \\\"{x:207,y:579,t:1526933868209};\\\", \\\"{x:191,y:578,t:1526933868225};\\\", \\\"{x:179,y:578,t:1526933868247};\\\", \\\"{x:178,y:578,t:1526933868265};\\\", \\\"{x:178,y:577,t:1526933868362};\\\", \\\"{x:178,y:575,t:1526933868379};\\\", \\\"{x:177,y:574,t:1526933868397};\\\", \\\"{x:173,y:571,t:1526933868413};\\\", \\\"{x:170,y:567,t:1526933868430};\\\", \\\"{x:167,y:561,t:1526933868448};\\\", \\\"{x:163,y:555,t:1526933868464};\\\", \\\"{x:161,y:547,t:1526933868479};\\\", \\\"{x:157,y:538,t:1526933868496};\\\", \\\"{x:155,y:532,t:1526933868513};\\\", \\\"{x:154,y:529,t:1526933868530};\\\", \\\"{x:153,y:528,t:1526933868546};\\\", \\\"{x:154,y:531,t:1526933868938};\\\", \\\"{x:155,y:532,t:1526933868947};\\\", \\\"{x:155,y:533,t:1526933868963};\\\", \\\"{x:156,y:535,t:1526933868980};\\\", \\\"{x:156,y:536,t:1526933869691};\\\", \\\"{x:163,y:549,t:1526933869698};\\\", \\\"{x:175,y:568,t:1526933869715};\\\", \\\"{x:245,y:645,t:1526933869731};\\\", \\\"{x:322,y:693,t:1526933869748};\\\", \\\"{x:425,y:745,t:1526933869764};\\\", \\\"{x:549,y:791,t:1526933869780};\\\", \\\"{x:690,y:839,t:1526933869797};\\\", \\\"{x:844,y:877,t:1526933869814};\\\", \\\"{x:993,y:890,t:1526933869831};\\\", \\\"{x:1123,y:890,t:1526933869847};\\\", \\\"{x:1236,y:890,t:1526933869865};\\\", \\\"{x:1322,y:890,t:1526933869880};\\\", \\\"{x:1367,y:877,t:1526933869897};\\\", \\\"{x:1390,y:870,t:1526933869914};\\\", \\\"{x:1393,y:868,t:1526933869930};\\\", \\\"{x:1393,y:865,t:1526933869948};\\\", \\\"{x:1393,y:863,t:1526933869964};\\\", \\\"{x:1393,y:859,t:1526933869980};\\\", \\\"{x:1394,y:855,t:1526933869998};\\\", \\\"{x:1395,y:850,t:1526933870015};\\\", \\\"{x:1397,y:845,t:1526933870031};\\\", \\\"{x:1399,y:838,t:1526933870047};\\\", \\\"{x:1405,y:830,t:1526933870064};\\\", \\\"{x:1412,y:824,t:1526933870080};\\\", \\\"{x:1426,y:815,t:1526933870098};\\\", \\\"{x:1444,y:804,t:1526933870115};\\\", \\\"{x:1458,y:795,t:1526933870131};\\\", \\\"{x:1469,y:787,t:1526933870148};\\\", \\\"{x:1479,y:780,t:1526933870165};\\\", \\\"{x:1486,y:776,t:1526933870181};\\\", \\\"{x:1492,y:774,t:1526933870198};\\\", \\\"{x:1497,y:772,t:1526933870215};\\\", \\\"{x:1505,y:771,t:1526933870232};\\\", \\\"{x:1515,y:770,t:1526933870248};\\\", \\\"{x:1526,y:767,t:1526933870265};\\\", \\\"{x:1535,y:766,t:1526933870282};\\\", \\\"{x:1537,y:766,t:1526933870298};\\\", \\\"{x:1538,y:766,t:1526933870347};\\\", \\\"{x:1539,y:766,t:1526933870371};\\\", \\\"{x:1540,y:766,t:1526933870382};\\\", \\\"{x:1543,y:766,t:1526933870398};\\\", \\\"{x:1546,y:766,t:1526933870415};\\\", \\\"{x:1548,y:766,t:1526933870432};\\\", \\\"{x:1549,y:766,t:1526933870448};\\\", \\\"{x:1549,y:767,t:1526933870563};\\\", \\\"{x:1549,y:771,t:1526933870571};\\\", \\\"{x:1549,y:778,t:1526933870582};\\\", \\\"{x:1544,y:795,t:1526933870599};\\\", \\\"{x:1543,y:813,t:1526933870615};\\\", \\\"{x:1543,y:832,t:1526933870632};\\\", \\\"{x:1543,y:850,t:1526933870649};\\\", \\\"{x:1543,y:866,t:1526933870665};\\\", \\\"{x:1543,y:880,t:1526933870682};\\\", \\\"{x:1541,y:904,t:1526933870698};\\\", \\\"{x:1538,y:915,t:1526933870714};\\\", \\\"{x:1536,y:926,t:1526933870732};\\\", \\\"{x:1533,y:934,t:1526933870749};\\\", \\\"{x:1533,y:937,t:1526933870766};\\\", \\\"{x:1533,y:940,t:1526933870782};\\\", \\\"{x:1533,y:942,t:1526933870799};\\\", \\\"{x:1534,y:944,t:1526933870815};\\\", \\\"{x:1535,y:946,t:1526933870832};\\\", \\\"{x:1537,y:949,t:1526933870849};\\\", \\\"{x:1538,y:954,t:1526933870866};\\\", \\\"{x:1539,y:956,t:1526933870882};\\\", \\\"{x:1542,y:958,t:1526933870899};\\\", \\\"{x:1542,y:959,t:1526933870947};\\\", \\\"{x:1543,y:959,t:1526933870955};\\\", \\\"{x:1543,y:960,t:1526933870965};\\\", \\\"{x:1545,y:961,t:1526933870982};\\\", \\\"{x:1546,y:961,t:1526933870999};\\\", \\\"{x:1548,y:961,t:1526933871051};\\\", \\\"{x:1548,y:960,t:1526933871065};\\\", \\\"{x:1548,y:953,t:1526933871082};\\\", \\\"{x:1549,y:940,t:1526933871099};\\\", \\\"{x:1549,y:934,t:1526933871116};\\\", \\\"{x:1550,y:928,t:1526933871132};\\\", \\\"{x:1550,y:924,t:1526933871149};\\\", \\\"{x:1550,y:921,t:1526933871166};\\\", \\\"{x:1551,y:918,t:1526933871182};\\\", \\\"{x:1551,y:917,t:1526933871199};\\\", \\\"{x:1551,y:915,t:1526933871216};\\\", \\\"{x:1551,y:914,t:1526933871235};\\\", \\\"{x:1551,y:913,t:1526933871275};\\\", \\\"{x:1551,y:912,t:1526933871290};\\\", \\\"{x:1551,y:911,t:1526933871307};\\\", \\\"{x:1551,y:910,t:1526933871339};\\\", \\\"{x:1551,y:908,t:1526933871349};\\\", \\\"{x:1551,y:906,t:1526933871366};\\\", \\\"{x:1551,y:901,t:1526933871383};\\\", \\\"{x:1551,y:896,t:1526933871399};\\\", \\\"{x:1551,y:890,t:1526933871416};\\\", \\\"{x:1551,y:886,t:1526933871432};\\\", \\\"{x:1551,y:881,t:1526933871449};\\\", \\\"{x:1551,y:876,t:1526933871466};\\\", \\\"{x:1551,y:870,t:1526933871482};\\\", \\\"{x:1551,y:867,t:1526933871499};\\\", \\\"{x:1551,y:863,t:1526933871516};\\\", \\\"{x:1551,y:861,t:1526933871533};\\\", \\\"{x:1551,y:858,t:1526933871549};\\\", \\\"{x:1551,y:855,t:1526933871566};\\\", \\\"{x:1551,y:854,t:1526933871583};\\\", \\\"{x:1551,y:851,t:1526933871599};\\\", \\\"{x:1551,y:850,t:1526933871616};\\\", \\\"{x:1551,y:848,t:1526933871633};\\\", \\\"{x:1551,y:847,t:1526933871649};\\\", \\\"{x:1551,y:846,t:1526933871667};\\\", \\\"{x:1551,y:845,t:1526933871691};\\\", \\\"{x:1551,y:844,t:1526933871739};\\\", \\\"{x:1551,y:843,t:1526933871750};\\\", \\\"{x:1551,y:841,t:1526933871765};\\\", \\\"{x:1551,y:838,t:1526933871782};\\\", \\\"{x:1551,y:837,t:1526933871810};\\\", \\\"{x:1551,y:836,t:1526933871818};\\\", \\\"{x:1551,y:835,t:1526933871832};\\\", \\\"{x:1551,y:834,t:1526933871850};\\\", \\\"{x:1550,y:832,t:1526933871865};\\\", \\\"{x:1550,y:830,t:1526933871882};\\\", \\\"{x:1550,y:829,t:1526933871899};\\\", \\\"{x:1549,y:829,t:1526933872203};\\\", \\\"{x:1548,y:828,t:1526933872332};\\\", \\\"{x:1547,y:828,t:1526933872451};\\\", \\\"{x:1546,y:827,t:1526933872475};\\\", \\\"{x:1545,y:826,t:1526933876627};\\\", \\\"{x:1537,y:822,t:1526933876638};\\\", \\\"{x:1518,y:800,t:1526933876654};\\\", \\\"{x:1493,y:764,t:1526933876671};\\\", \\\"{x:1468,y:738,t:1526933876687};\\\", \\\"{x:1450,y:726,t:1526933876703};\\\", \\\"{x:1437,y:714,t:1526933876720};\\\", \\\"{x:1420,y:702,t:1526933876737};\\\", \\\"{x:1391,y:685,t:1526933876754};\\\", \\\"{x:1382,y:684,t:1526933876769};\\\", \\\"{x:1374,y:682,t:1526933876786};\\\", \\\"{x:1367,y:682,t:1526933876804};\\\", \\\"{x:1361,y:682,t:1526933876819};\\\", \\\"{x:1358,y:682,t:1526933876837};\\\", \\\"{x:1353,y:682,t:1526933876854};\\\", \\\"{x:1349,y:683,t:1526933876870};\\\", \\\"{x:1344,y:685,t:1526933876886};\\\", \\\"{x:1341,y:687,t:1526933876904};\\\", \\\"{x:1338,y:692,t:1526933876920};\\\", \\\"{x:1335,y:695,t:1526933876936};\\\", \\\"{x:1332,y:699,t:1526933876954};\\\", \\\"{x:1331,y:699,t:1526933876970};\\\", \\\"{x:1333,y:699,t:1526933877099};\\\", \\\"{x:1333,y:698,t:1526933877114};\\\", \\\"{x:1335,y:697,t:1526933877131};\\\", \\\"{x:1336,y:696,t:1526933877163};\\\", \\\"{x:1337,y:696,t:1526933877171};\\\", \\\"{x:1337,y:695,t:1526933877187};\\\", \\\"{x:1338,y:695,t:1526933877204};\\\", \\\"{x:1339,y:694,t:1526933877221};\\\", \\\"{x:1340,y:694,t:1526933877259};\\\", \\\"{x:1341,y:694,t:1526933877331};\\\", \\\"{x:1342,y:694,t:1526933877347};\\\", \\\"{x:1343,y:694,t:1526933877363};\\\", \\\"{x:1344,y:694,t:1526933877388};\\\", \\\"{x:1345,y:694,t:1526933877443};\\\", \\\"{x:1346,y:694,t:1526933877474};\\\", \\\"{x:1347,y:695,t:1526933877490};\\\", \\\"{x:1348,y:695,t:1526933877504};\\\", \\\"{x:1351,y:698,t:1526933877521};\\\", \\\"{x:1353,y:700,t:1526933877539};\\\", \\\"{x:1359,y:704,t:1526933877554};\\\", \\\"{x:1363,y:706,t:1526933877571};\\\", \\\"{x:1369,y:707,t:1526933877589};\\\", \\\"{x:1375,y:708,t:1526933877604};\\\", \\\"{x:1381,y:708,t:1526933877622};\\\", \\\"{x:1385,y:708,t:1526933877638};\\\", \\\"{x:1388,y:708,t:1526933877654};\\\", \\\"{x:1389,y:708,t:1526933877683};\\\", \\\"{x:1389,y:707,t:1526933877698};\\\", \\\"{x:1391,y:706,t:1526933877714};\\\", \\\"{x:1393,y:705,t:1526933877722};\\\", \\\"{x:1396,y:703,t:1526933877737};\\\", \\\"{x:1397,y:702,t:1526933877754};\\\", \\\"{x:1398,y:701,t:1526933877771};\\\", \\\"{x:1399,y:701,t:1526933877794};\\\", \\\"{x:1400,y:700,t:1526933877810};\\\", \\\"{x:1402,y:698,t:1526933877826};\\\", \\\"{x:1403,y:697,t:1526933877842};\\\", \\\"{x:1404,y:696,t:1526933877855};\\\", \\\"{x:1406,y:694,t:1526933877871};\\\", \\\"{x:1407,y:692,t:1526933877899};\\\", \\\"{x:1408,y:692,t:1526933877922};\\\", \\\"{x:1409,y:691,t:1526933877947};\\\", \\\"{x:1409,y:690,t:1526933877963};\\\", \\\"{x:1410,y:690,t:1526933877971};\\\", \\\"{x:1410,y:689,t:1526933877989};\\\", \\\"{x:1411,y:689,t:1526933878005};\\\", \\\"{x:1413,y:689,t:1526933878372};\\\", \\\"{x:1414,y:689,t:1526933878419};\\\", \\\"{x:1415,y:689,t:1526933878442};\\\", \\\"{x:1415,y:690,t:1526933878467};\\\", \\\"{x:1416,y:691,t:1526933878482};\\\", \\\"{x:1416,y:692,t:1526933878499};\\\", \\\"{x:1417,y:693,t:1526933878507};\\\", \\\"{x:1418,y:694,t:1526933878523};\\\", \\\"{x:1420,y:695,t:1526933878538};\\\", \\\"{x:1421,y:696,t:1526933878556};\\\", \\\"{x:1422,y:697,t:1526933878587};\\\", \\\"{x:1423,y:697,t:1526933878611};\\\", \\\"{x:1424,y:697,t:1526933878626};\\\", \\\"{x:1426,y:698,t:1526933878643};\\\", \\\"{x:1427,y:698,t:1526933878655};\\\", \\\"{x:1429,y:698,t:1526933878672};\\\", \\\"{x:1435,y:698,t:1526933878689};\\\", \\\"{x:1442,y:698,t:1526933878706};\\\", \\\"{x:1454,y:698,t:1526933878722};\\\", \\\"{x:1463,y:698,t:1526933878739};\\\", \\\"{x:1470,y:698,t:1526933878755};\\\", \\\"{x:1472,y:698,t:1526933878772};\\\", \\\"{x:1474,y:698,t:1526933878789};\\\", \\\"{x:1474,y:697,t:1526933878817};\\\", \\\"{x:1475,y:696,t:1526933878834};\\\", \\\"{x:1476,y:695,t:1526933878850};\\\", \\\"{x:1477,y:694,t:1526933878866};\\\", \\\"{x:1478,y:694,t:1526933878890};\\\", \\\"{x:1478,y:693,t:1526933878906};\\\", \\\"{x:1478,y:692,t:1526933878954};\\\", \\\"{x:1479,y:692,t:1526933879123};\\\", \\\"{x:1481,y:693,t:1526933879140};\\\", \\\"{x:1487,y:699,t:1526933879157};\\\", \\\"{x:1493,y:703,t:1526933879172};\\\", \\\"{x:1498,y:706,t:1526933879189};\\\", \\\"{x:1503,y:709,t:1526933879206};\\\", \\\"{x:1507,y:709,t:1526933879222};\\\", \\\"{x:1511,y:710,t:1526933879240};\\\", \\\"{x:1515,y:711,t:1526933879256};\\\", \\\"{x:1519,y:711,t:1526933879272};\\\", \\\"{x:1523,y:711,t:1526933879290};\\\", \\\"{x:1524,y:711,t:1526933879307};\\\", \\\"{x:1526,y:711,t:1526933879323};\\\", \\\"{x:1527,y:711,t:1526933879339};\\\", \\\"{x:1529,y:709,t:1526933879357};\\\", \\\"{x:1530,y:708,t:1526933879372};\\\", \\\"{x:1532,y:705,t:1526933879389};\\\", \\\"{x:1533,y:705,t:1526933879406};\\\", \\\"{x:1534,y:703,t:1526933879422};\\\", \\\"{x:1535,y:701,t:1526933879439};\\\", \\\"{x:1536,y:699,t:1526933879459};\\\", \\\"{x:1536,y:698,t:1526933879539};\\\", \\\"{x:1538,y:698,t:1526933879676};\\\", \\\"{x:1541,y:701,t:1526933879688};\\\", \\\"{x:1554,y:708,t:1526933879706};\\\", \\\"{x:1566,y:711,t:1526933879723};\\\", \\\"{x:1577,y:713,t:1526933879739};\\\", \\\"{x:1590,y:713,t:1526933879756};\\\", \\\"{x:1596,y:713,t:1526933879773};\\\", \\\"{x:1600,y:713,t:1526933879789};\\\", \\\"{x:1601,y:713,t:1526933879805};\\\", \\\"{x:1603,y:713,t:1526933879822};\\\", \\\"{x:1604,y:712,t:1526933879840};\\\", \\\"{x:1607,y:709,t:1526933879856};\\\", \\\"{x:1609,y:708,t:1526933879873};\\\", \\\"{x:1613,y:705,t:1526933879891};\\\", \\\"{x:1616,y:702,t:1526933879906};\\\", \\\"{x:1619,y:699,t:1526933879923};\\\", \\\"{x:1620,y:698,t:1526933879940};\\\", \\\"{x:1621,y:697,t:1526933880004};\\\", \\\"{x:1621,y:696,t:1526933880027};\\\", \\\"{x:1617,y:697,t:1526933880587};\\\", \\\"{x:1603,y:702,t:1526933880609};\\\", \\\"{x:1586,y:706,t:1526933880623};\\\", \\\"{x:1571,y:706,t:1526933880640};\\\", \\\"{x:1562,y:706,t:1526933880658};\\\", \\\"{x:1558,y:706,t:1526933880675};\\\", \\\"{x:1557,y:706,t:1526933880689};\\\", \\\"{x:1555,y:706,t:1526933880714};\\\", \\\"{x:1553,y:706,t:1526933880737};\\\", \\\"{x:1551,y:705,t:1526933880745};\\\", \\\"{x:1550,y:703,t:1526933880757};\\\", \\\"{x:1548,y:702,t:1526933880774};\\\", \\\"{x:1547,y:701,t:1526933880790};\\\", \\\"{x:1545,y:701,t:1526933880806};\\\", \\\"{x:1544,y:700,t:1526933880824};\\\", \\\"{x:1544,y:699,t:1526933880842};\\\", \\\"{x:1543,y:697,t:1526933880882};\\\", \\\"{x:1542,y:697,t:1526933880890};\\\", \\\"{x:1541,y:696,t:1526933880914};\\\", \\\"{x:1539,y:696,t:1526933882011};\\\", \\\"{x:1529,y:701,t:1526933882026};\\\", \\\"{x:1477,y:735,t:1526933882042};\\\", \\\"{x:1310,y:788,t:1526933882059};\\\", \\\"{x:1147,y:808,t:1526933882074};\\\", \\\"{x:975,y:810,t:1526933882091};\\\", \\\"{x:826,y:810,t:1526933882108};\\\", \\\"{x:718,y:810,t:1526933882125};\\\", \\\"{x:661,y:810,t:1526933882141};\\\", \\\"{x:633,y:807,t:1526933882159};\\\", \\\"{x:614,y:802,t:1526933882175};\\\", \\\"{x:611,y:801,t:1526933882191};\\\", \\\"{x:609,y:801,t:1526933882209};\\\", \\\"{x:609,y:800,t:1526933882259};\\\", \\\"{x:608,y:799,t:1526933882274};\\\", \\\"{x:606,y:798,t:1526933882292};\\\", \\\"{x:604,y:796,t:1526933882308};\\\", \\\"{x:598,y:791,t:1526933882325};\\\", \\\"{x:585,y:780,t:1526933882342};\\\", \\\"{x:566,y:766,t:1526933882358};\\\", \\\"{x:551,y:759,t:1526933882376};\\\", \\\"{x:541,y:756,t:1526933882392};\\\", \\\"{x:536,y:755,t:1526933882408};\\\", \\\"{x:533,y:754,t:1526933882427};\\\", \\\"{x:532,y:754,t:1526933882442};\\\", \\\"{x:530,y:754,t:1526933882538};\\\", \\\"{x:530,y:753,t:1526933882611};\\\", \\\"{x:530,y:752,t:1526933882626};\\\", \\\"{x:529,y:751,t:1526933882650};\\\", \\\"{x:529,y:750,t:1526933882675};\\\", \\\"{x:529,y:749,t:1526933882690};\\\", \\\"{x:529,y:748,t:1526933882706};\\\", \\\"{x:529,y:747,t:1526933882720};\\\", \\\"{x:529,y:745,t:1526933882737};\\\", \\\"{x:529,y:743,t:1526933882754};\\\", \\\"{x:529,y:741,t:1526933882770};\\\", \\\"{x:529,y:740,t:1526933882787};\\\" ] }, { \\\"rt\\\": 73133, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 712796, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -X -X -J -I -B -B -B -F -F -C -M -X -X -O -F -F -Z -B -B -B -B -B -B -B -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:740,t:1526933888155};\\\", \\\"{x:536,y:740,t:1526933888162};\\\", \\\"{x:570,y:738,t:1526933888181};\\\", \\\"{x:589,y:738,t:1526933888196};\\\", \\\"{x:615,y:738,t:1526933888212};\\\", \\\"{x:643,y:738,t:1526933888228};\\\", \\\"{x:675,y:736,t:1526933888245};\\\", \\\"{x:726,y:736,t:1526933888262};\\\", \\\"{x:751,y:736,t:1526933888279};\\\", \\\"{x:772,y:733,t:1526933888295};\\\", \\\"{x:798,y:733,t:1526933888312};\\\", \\\"{x:824,y:733,t:1526933888329};\\\", \\\"{x:862,y:733,t:1526933888345};\\\", \\\"{x:960,y:742,t:1526933888362};\\\", \\\"{x:1035,y:753,t:1526933888379};\\\", \\\"{x:1094,y:761,t:1526933888395};\\\", \\\"{x:1152,y:778,t:1526933888412};\\\", \\\"{x:1198,y:789,t:1526933888429};\\\", \\\"{x:1227,y:793,t:1526933888445};\\\", \\\"{x:1235,y:793,t:1526933888462};\\\", \\\"{x:1236,y:793,t:1526933888479};\\\", \\\"{x:1239,y:794,t:1526933888866};\\\", \\\"{x:1239,y:796,t:1526933888879};\\\", \\\"{x:1241,y:797,t:1526933888914};\\\", \\\"{x:1243,y:800,t:1526933888929};\\\", \\\"{x:1247,y:803,t:1526933888946};\\\", \\\"{x:1264,y:804,t:1526933888962};\\\", \\\"{x:1291,y:804,t:1526933888979};\\\", \\\"{x:1318,y:797,t:1526933888996};\\\", \\\"{x:1346,y:789,t:1526933889013};\\\", \\\"{x:1373,y:780,t:1526933889029};\\\", \\\"{x:1402,y:767,t:1526933889046};\\\", \\\"{x:1426,y:757,t:1526933889063};\\\", \\\"{x:1447,y:746,t:1526933889079};\\\", \\\"{x:1458,y:739,t:1526933889096};\\\", \\\"{x:1466,y:734,t:1526933889113};\\\", \\\"{x:1471,y:730,t:1526933889129};\\\", \\\"{x:1477,y:727,t:1526933889146};\\\", \\\"{x:1484,y:722,t:1526933889164};\\\", \\\"{x:1488,y:720,t:1526933889179};\\\", \\\"{x:1490,y:718,t:1526933889196};\\\", \\\"{x:1490,y:717,t:1526933889214};\\\", \\\"{x:1491,y:716,t:1526933889230};\\\", \\\"{x:1492,y:716,t:1526933889259};\\\", \\\"{x:1488,y:716,t:1526933889642};\\\", \\\"{x:1474,y:717,t:1526933889650};\\\", \\\"{x:1469,y:718,t:1526933889663};\\\", \\\"{x:1410,y:724,t:1526933889680};\\\", \\\"{x:1342,y:735,t:1526933889697};\\\", \\\"{x:1349,y:739,t:1526933890043};\\\", \\\"{x:1352,y:739,t:1526933890051};\\\", \\\"{x:1353,y:739,t:1526933890064};\\\", \\\"{x:1354,y:739,t:1526933890081};\\\", \\\"{x:1355,y:739,t:1526933890098};\\\", \\\"{x:1357,y:739,t:1526933890114};\\\", \\\"{x:1357,y:741,t:1526933890147};\\\", \\\"{x:1350,y:753,t:1526933890164};\\\", \\\"{x:1341,y:773,t:1526933890182};\\\", \\\"{x:1324,y:804,t:1526933890197};\\\", \\\"{x:1311,y:822,t:1526933890213};\\\", \\\"{x:1296,y:841,t:1526933890230};\\\", \\\"{x:1285,y:852,t:1526933890247};\\\", \\\"{x:1274,y:860,t:1526933890263};\\\", \\\"{x:1269,y:863,t:1526933890280};\\\", \\\"{x:1268,y:864,t:1526933890297};\\\", \\\"{x:1267,y:865,t:1526933890314};\\\", \\\"{x:1261,y:868,t:1526933890330};\\\", \\\"{x:1255,y:872,t:1526933890347};\\\", \\\"{x:1247,y:875,t:1526933890363};\\\", \\\"{x:1239,y:878,t:1526933890380};\\\", \\\"{x:1230,y:882,t:1526933890397};\\\", \\\"{x:1226,y:884,t:1526933890413};\\\", \\\"{x:1222,y:886,t:1526933890430};\\\", \\\"{x:1221,y:886,t:1526933890447};\\\", \\\"{x:1220,y:886,t:1526933890464};\\\", \\\"{x:1219,y:886,t:1526933890480};\\\", \\\"{x:1217,y:886,t:1526933890497};\\\", \\\"{x:1210,y:881,t:1526933890514};\\\", \\\"{x:1206,y:877,t:1526933890530};\\\", \\\"{x:1200,y:869,t:1526933890547};\\\", \\\"{x:1193,y:857,t:1526933890565};\\\", \\\"{x:1190,y:852,t:1526933890580};\\\", \\\"{x:1189,y:847,t:1526933890597};\\\", \\\"{x:1187,y:844,t:1526933890614};\\\", \\\"{x:1186,y:842,t:1526933890630};\\\", \\\"{x:1185,y:841,t:1526933890771};\\\", \\\"{x:1185,y:840,t:1526933890899};\\\", \\\"{x:1185,y:839,t:1526933891107};\\\", \\\"{x:1185,y:837,t:1526933891122};\\\", \\\"{x:1185,y:836,t:1526933891132};\\\", \\\"{x:1186,y:835,t:1526933891148};\\\", \\\"{x:1186,y:834,t:1526933891171};\\\", \\\"{x:1187,y:833,t:1526933891186};\\\", \\\"{x:1187,y:832,t:1526933891218};\\\", \\\"{x:1187,y:831,t:1526933891251};\\\", \\\"{x:1189,y:830,t:1526933891379};\\\", \\\"{x:1190,y:830,t:1526933891547};\\\", \\\"{x:1191,y:829,t:1526933891555};\\\", \\\"{x:1192,y:829,t:1526933891635};\\\", \\\"{x:1194,y:829,t:1526933891706};\\\", \\\"{x:1195,y:829,t:1526933891755};\\\", \\\"{x:1196,y:829,t:1526933891803};\\\", \\\"{x:1197,y:827,t:1526933891835};\\\", \\\"{x:1198,y:827,t:1526933891850};\\\", \\\"{x:1199,y:827,t:1526933891875};\\\", \\\"{x:1200,y:827,t:1526933891890};\\\", \\\"{x:1201,y:827,t:1526933891899};\\\", \\\"{x:1203,y:827,t:1526933891916};\\\", \\\"{x:1205,y:827,t:1526933891932};\\\", \\\"{x:1212,y:827,t:1526933891951};\\\", \\\"{x:1226,y:827,t:1526933891965};\\\", \\\"{x:1243,y:827,t:1526933891981};\\\", \\\"{x:1263,y:827,t:1526933891998};\\\", \\\"{x:1286,y:827,t:1526933892015};\\\", \\\"{x:1308,y:827,t:1526933892031};\\\", \\\"{x:1330,y:827,t:1526933892048};\\\", \\\"{x:1349,y:826,t:1526933892065};\\\", \\\"{x:1359,y:826,t:1526933892081};\\\", \\\"{x:1363,y:826,t:1526933892099};\\\", \\\"{x:1366,y:827,t:1526933892116};\\\", \\\"{x:1371,y:832,t:1526933892131};\\\", \\\"{x:1382,y:845,t:1526933892148};\\\", \\\"{x:1393,y:855,t:1526933892166};\\\", \\\"{x:1404,y:869,t:1526933892181};\\\", \\\"{x:1413,y:881,t:1526933892199};\\\", \\\"{x:1421,y:891,t:1526933892215};\\\", \\\"{x:1424,y:900,t:1526933892232};\\\", \\\"{x:1426,y:908,t:1526933892248};\\\", \\\"{x:1427,y:912,t:1526933892265};\\\", \\\"{x:1429,y:914,t:1526933892281};\\\", \\\"{x:1430,y:917,t:1526933892299};\\\", \\\"{x:1431,y:921,t:1526933892316};\\\", \\\"{x:1433,y:927,t:1526933892332};\\\", \\\"{x:1434,y:930,t:1526933892348};\\\", \\\"{x:1438,y:936,t:1526933892366};\\\", \\\"{x:1440,y:941,t:1526933892382};\\\", \\\"{x:1443,y:946,t:1526933892399};\\\", \\\"{x:1446,y:950,t:1526933892416};\\\", \\\"{x:1449,y:954,t:1526933892432};\\\", \\\"{x:1450,y:955,t:1526933892449};\\\", \\\"{x:1452,y:956,t:1526933892466};\\\", \\\"{x:1456,y:958,t:1526933892483};\\\", \\\"{x:1456,y:959,t:1526933892498};\\\", \\\"{x:1459,y:960,t:1526933892602};\\\", \\\"{x:1460,y:960,t:1526933892619};\\\", \\\"{x:1461,y:960,t:1526933892633};\\\", \\\"{x:1464,y:960,t:1526933892649};\\\", \\\"{x:1466,y:961,t:1526933892666};\\\", \\\"{x:1472,y:964,t:1526933892683};\\\", \\\"{x:1474,y:966,t:1526933892699};\\\", \\\"{x:1477,y:967,t:1526933892715};\\\", \\\"{x:1478,y:968,t:1526933892732};\\\", \\\"{x:1480,y:968,t:1526933892754};\\\", \\\"{x:1480,y:967,t:1526933894099};\\\", \\\"{x:1480,y:964,t:1526933894117};\\\", \\\"{x:1480,y:960,t:1526933894134};\\\", \\\"{x:1480,y:956,t:1526933894150};\\\", \\\"{x:1480,y:953,t:1526933894167};\\\", \\\"{x:1480,y:951,t:1526933894184};\\\", \\\"{x:1479,y:948,t:1526933894200};\\\", \\\"{x:1479,y:946,t:1526933894216};\\\", \\\"{x:1476,y:940,t:1526933894234};\\\", \\\"{x:1475,y:935,t:1526933894250};\\\", \\\"{x:1473,y:930,t:1526933894266};\\\", \\\"{x:1472,y:926,t:1526933894284};\\\", \\\"{x:1471,y:922,t:1526933894300};\\\", \\\"{x:1470,y:918,t:1526933894316};\\\", \\\"{x:1468,y:914,t:1526933894333};\\\", \\\"{x:1468,y:907,t:1526933894350};\\\", \\\"{x:1467,y:902,t:1526933894366};\\\", \\\"{x:1467,y:896,t:1526933894384};\\\", \\\"{x:1467,y:891,t:1526933894400};\\\", \\\"{x:1467,y:886,t:1526933894416};\\\", \\\"{x:1467,y:879,t:1526933894434};\\\", \\\"{x:1467,y:871,t:1526933894450};\\\", \\\"{x:1467,y:867,t:1526933894467};\\\", \\\"{x:1467,y:864,t:1526933894484};\\\", \\\"{x:1467,y:860,t:1526933894500};\\\", \\\"{x:1468,y:854,t:1526933894517};\\\", \\\"{x:1469,y:851,t:1526933894533};\\\", \\\"{x:1469,y:849,t:1526933894550};\\\", \\\"{x:1469,y:847,t:1526933894566};\\\", \\\"{x:1470,y:845,t:1526933894584};\\\", \\\"{x:1471,y:843,t:1526933894601};\\\", \\\"{x:1471,y:842,t:1526933894618};\\\", \\\"{x:1472,y:840,t:1526933894634};\\\", \\\"{x:1472,y:839,t:1526933894651};\\\", \\\"{x:1473,y:837,t:1526933894667};\\\", \\\"{x:1473,y:836,t:1526933894684};\\\", \\\"{x:1475,y:835,t:1526933894700};\\\", \\\"{x:1475,y:833,t:1526933894717};\\\", \\\"{x:1475,y:831,t:1526933894734};\\\", \\\"{x:1476,y:830,t:1526933894751};\\\", \\\"{x:1476,y:828,t:1526933894767};\\\", \\\"{x:1478,y:826,t:1526933894784};\\\", \\\"{x:1478,y:825,t:1526933894835};\\\", \\\"{x:1478,y:824,t:1526933894859};\\\", \\\"{x:1470,y:827,t:1526933897515};\\\", \\\"{x:1462,y:831,t:1526933897522};\\\", \\\"{x:1449,y:834,t:1526933897536};\\\", \\\"{x:1418,y:841,t:1526933897553};\\\", \\\"{x:1369,y:843,t:1526933897569};\\\", \\\"{x:1302,y:848,t:1526933897586};\\\", \\\"{x:1281,y:848,t:1526933897602};\\\", \\\"{x:1271,y:848,t:1526933897620};\\\", \\\"{x:1268,y:848,t:1526933897636};\\\", \\\"{x:1266,y:848,t:1526933897691};\\\", \\\"{x:1264,y:847,t:1526933897706};\\\", \\\"{x:1262,y:847,t:1526933897720};\\\", \\\"{x:1253,y:847,t:1526933897736};\\\", \\\"{x:1243,y:844,t:1526933897753};\\\", \\\"{x:1223,y:840,t:1526933897770};\\\", \\\"{x:1215,y:838,t:1526933897786};\\\", \\\"{x:1210,y:836,t:1526933897803};\\\", \\\"{x:1209,y:836,t:1526933897825};\\\", \\\"{x:1208,y:835,t:1526933897835};\\\", \\\"{x:1204,y:835,t:1526933897852};\\\", \\\"{x:1198,y:835,t:1526933897869};\\\", \\\"{x:1192,y:834,t:1526933897886};\\\", \\\"{x:1189,y:834,t:1526933897903};\\\", \\\"{x:1188,y:834,t:1526933897919};\\\", \\\"{x:1188,y:832,t:1526933897986};\\\", \\\"{x:1188,y:831,t:1526933898003};\\\", \\\"{x:1191,y:827,t:1526933898019};\\\", \\\"{x:1194,y:825,t:1526933898035};\\\", \\\"{x:1197,y:824,t:1526933898053};\\\", \\\"{x:1198,y:824,t:1526933898070};\\\", \\\"{x:1198,y:823,t:1526933898087};\\\", \\\"{x:1199,y:823,t:1526933898202};\\\", \\\"{x:1200,y:823,t:1526933898218};\\\", \\\"{x:1201,y:823,t:1526933898226};\\\", \\\"{x:1203,y:823,t:1526933898443};\\\", \\\"{x:1204,y:823,t:1526933898466};\\\", \\\"{x:1205,y:823,t:1526933898483};\\\", \\\"{x:1206,y:824,t:1526933898490};\\\", \\\"{x:1207,y:824,t:1526933898503};\\\", \\\"{x:1208,y:825,t:1526933898520};\\\", \\\"{x:1209,y:826,t:1526933898826};\\\", \\\"{x:1209,y:827,t:1526933898838};\\\", \\\"{x:1210,y:829,t:1526933898854};\\\", \\\"{x:1211,y:830,t:1526933898870};\\\", \\\"{x:1213,y:832,t:1526933898887};\\\", \\\"{x:1214,y:833,t:1526933898904};\\\", \\\"{x:1215,y:834,t:1526933898922};\\\", \\\"{x:1216,y:835,t:1526933898937};\\\", \\\"{x:1216,y:836,t:1526933898995};\\\", \\\"{x:1217,y:836,t:1526933899051};\\\", \\\"{x:1218,y:837,t:1526933899074};\\\", \\\"{x:1220,y:838,t:1526933899087};\\\", \\\"{x:1221,y:838,t:1526933899104};\\\", \\\"{x:1223,y:839,t:1526933899121};\\\", \\\"{x:1224,y:841,t:1526933899137};\\\", \\\"{x:1229,y:842,t:1526933899153};\\\", \\\"{x:1230,y:843,t:1526933899170};\\\", \\\"{x:1234,y:843,t:1526933899186};\\\", \\\"{x:1237,y:843,t:1526933899203};\\\", \\\"{x:1241,y:844,t:1526933899220};\\\", \\\"{x:1245,y:844,t:1526933899237};\\\", \\\"{x:1250,y:846,t:1526933899253};\\\", \\\"{x:1252,y:847,t:1526933899270};\\\", \\\"{x:1256,y:847,t:1526933899287};\\\", \\\"{x:1259,y:847,t:1526933899303};\\\", \\\"{x:1264,y:847,t:1526933899321};\\\", \\\"{x:1269,y:847,t:1526933899336};\\\", \\\"{x:1276,y:847,t:1526933899353};\\\", \\\"{x:1281,y:847,t:1526933899371};\\\", \\\"{x:1283,y:847,t:1526933899386};\\\", \\\"{x:1284,y:847,t:1526933899404};\\\", \\\"{x:1286,y:847,t:1526933899421};\\\", \\\"{x:1288,y:846,t:1526933899437};\\\", \\\"{x:1290,y:845,t:1526933899455};\\\", \\\"{x:1291,y:845,t:1526933899471};\\\", \\\"{x:1294,y:844,t:1526933899487};\\\", \\\"{x:1294,y:843,t:1526933899507};\\\", \\\"{x:1294,y:842,t:1526933899555};\\\", \\\"{x:1294,y:841,t:1526933899571};\\\", \\\"{x:1294,y:840,t:1526933899588};\\\", \\\"{x:1294,y:839,t:1526933899604};\\\", \\\"{x:1294,y:838,t:1526933899621};\\\", \\\"{x:1294,y:837,t:1526933899638};\\\", \\\"{x:1294,y:836,t:1526933899658};\\\", \\\"{x:1294,y:835,t:1526933899671};\\\", \\\"{x:1294,y:834,t:1526933899688};\\\", \\\"{x:1293,y:833,t:1526933899705};\\\", \\\"{x:1292,y:831,t:1526933899722};\\\", \\\"{x:1291,y:830,t:1526933899747};\\\", \\\"{x:1290,y:830,t:1526933899763};\\\", \\\"{x:1289,y:830,t:1526933899770};\\\", \\\"{x:1288,y:828,t:1526933899789};\\\", \\\"{x:1287,y:828,t:1526933899804};\\\", \\\"{x:1285,y:828,t:1526933899820};\\\", \\\"{x:1284,y:828,t:1526933899837};\\\", \\\"{x:1283,y:828,t:1526933900731};\\\", \\\"{x:1284,y:829,t:1526933900754};\\\", \\\"{x:1285,y:832,t:1526933900772};\\\", \\\"{x:1288,y:833,t:1526933900788};\\\", \\\"{x:1291,y:836,t:1526933900805};\\\", \\\"{x:1295,y:837,t:1526933900822};\\\", \\\"{x:1296,y:838,t:1526933900838};\\\", \\\"{x:1298,y:838,t:1526933900855};\\\", \\\"{x:1299,y:838,t:1526933900890};\\\", \\\"{x:1301,y:838,t:1526933900906};\\\", \\\"{x:1302,y:838,t:1526933900923};\\\", \\\"{x:1306,y:838,t:1526933900938};\\\", \\\"{x:1313,y:838,t:1526933900954};\\\", \\\"{x:1321,y:838,t:1526933900972};\\\", \\\"{x:1330,y:838,t:1526933900989};\\\", \\\"{x:1334,y:838,t:1526933901006};\\\", \\\"{x:1337,y:838,t:1526933901022};\\\", \\\"{x:1339,y:838,t:1526933901074};\\\", \\\"{x:1340,y:838,t:1526933901098};\\\", \\\"{x:1341,y:837,t:1526933901123};\\\", \\\"{x:1342,y:837,t:1526933901139};\\\", \\\"{x:1342,y:836,t:1526933901163};\\\", \\\"{x:1343,y:835,t:1526933901202};\\\", \\\"{x:1343,y:834,t:1526933901234};\\\", \\\"{x:1343,y:833,t:1526933901242};\\\", \\\"{x:1343,y:832,t:1526933901258};\\\", \\\"{x:1344,y:832,t:1526933901274};\\\", \\\"{x:1344,y:831,t:1526933901289};\\\", \\\"{x:1345,y:830,t:1526933901305};\\\", \\\"{x:1345,y:829,t:1526933901322};\\\", \\\"{x:1346,y:827,t:1526933901338};\\\", \\\"{x:1346,y:826,t:1526933901363};\\\", \\\"{x:1347,y:824,t:1526933901387};\\\", \\\"{x:1347,y:823,t:1526933901443};\\\", \\\"{x:1343,y:826,t:1526933902267};\\\", \\\"{x:1336,y:830,t:1526933902274};\\\", \\\"{x:1326,y:835,t:1526933902289};\\\", \\\"{x:1302,y:837,t:1526933902306};\\\", \\\"{x:1285,y:837,t:1526933902323};\\\", \\\"{x:1274,y:837,t:1526933902339};\\\", \\\"{x:1270,y:837,t:1526933902357};\\\", \\\"{x:1269,y:837,t:1526933902394};\\\", \\\"{x:1269,y:835,t:1526933902467};\\\", \\\"{x:1269,y:834,t:1526933902482};\\\", \\\"{x:1269,y:832,t:1526933902490};\\\", \\\"{x:1271,y:830,t:1526933902506};\\\", \\\"{x:1274,y:828,t:1526933902523};\\\", \\\"{x:1277,y:827,t:1526933902540};\\\", \\\"{x:1278,y:826,t:1526933902556};\\\", \\\"{x:1278,y:825,t:1526933903378};\\\", \\\"{x:1278,y:822,t:1526933903390};\\\", \\\"{x:1271,y:815,t:1526933903407};\\\", \\\"{x:1263,y:809,t:1526933903424};\\\", \\\"{x:1257,y:805,t:1526933903440};\\\", \\\"{x:1252,y:802,t:1526933903457};\\\", \\\"{x:1246,y:797,t:1526933903474};\\\", \\\"{x:1241,y:792,t:1526933903490};\\\", \\\"{x:1237,y:789,t:1526933903507};\\\", \\\"{x:1233,y:787,t:1526933903523};\\\", \\\"{x:1232,y:787,t:1526933903540};\\\", \\\"{x:1229,y:784,t:1526933903557};\\\", \\\"{x:1225,y:783,t:1526933903574};\\\", \\\"{x:1222,y:781,t:1526933903590};\\\", \\\"{x:1219,y:779,t:1526933903607};\\\", \\\"{x:1217,y:779,t:1526933903624};\\\", \\\"{x:1211,y:776,t:1526933903640};\\\", \\\"{x:1207,y:775,t:1526933903657};\\\", \\\"{x:1201,y:772,t:1526933903674};\\\", \\\"{x:1198,y:771,t:1526933903690};\\\", \\\"{x:1195,y:769,t:1526933903707};\\\", \\\"{x:1192,y:768,t:1526933903724};\\\", \\\"{x:1189,y:766,t:1526933903740};\\\", \\\"{x:1186,y:764,t:1526933903758};\\\", \\\"{x:1183,y:762,t:1526933903774};\\\", \\\"{x:1181,y:761,t:1526933903791};\\\", \\\"{x:1180,y:760,t:1526933903858};\\\", \\\"{x:1182,y:761,t:1526933904115};\\\", \\\"{x:1184,y:762,t:1526933904124};\\\", \\\"{x:1190,y:765,t:1526933904143};\\\", \\\"{x:1198,y:767,t:1526933904158};\\\", \\\"{x:1207,y:768,t:1526933904175};\\\", \\\"{x:1215,y:769,t:1526933904191};\\\", \\\"{x:1223,y:769,t:1526933904207};\\\", \\\"{x:1227,y:769,t:1526933904224};\\\", \\\"{x:1230,y:769,t:1526933904240};\\\", \\\"{x:1231,y:769,t:1526933904258};\\\", \\\"{x:1233,y:769,t:1526933904274};\\\", \\\"{x:1236,y:769,t:1526933904291};\\\", \\\"{x:1239,y:768,t:1526933904308};\\\", \\\"{x:1241,y:767,t:1526933904324};\\\", \\\"{x:1243,y:766,t:1526933904341};\\\", \\\"{x:1245,y:765,t:1526933904357};\\\", \\\"{x:1246,y:764,t:1526933904378};\\\", \\\"{x:1246,y:763,t:1526933904391};\\\", \\\"{x:1247,y:763,t:1526933904407};\\\", \\\"{x:1247,y:762,t:1526933904434};\\\", \\\"{x:1247,y:761,t:1526933904465};\\\", \\\"{x:1248,y:760,t:1526933904474};\\\", \\\"{x:1248,y:759,t:1526933904491};\\\", \\\"{x:1250,y:759,t:1526933904722};\\\", \\\"{x:1251,y:760,t:1526933904738};\\\", \\\"{x:1252,y:761,t:1526933904747};\\\", \\\"{x:1253,y:761,t:1526933904758};\\\", \\\"{x:1255,y:762,t:1526933904775};\\\", \\\"{x:1259,y:764,t:1526933904791};\\\", \\\"{x:1264,y:766,t:1526933904808};\\\", \\\"{x:1271,y:767,t:1526933904825};\\\", \\\"{x:1278,y:769,t:1526933904841};\\\", \\\"{x:1292,y:770,t:1526933904858};\\\", \\\"{x:1302,y:770,t:1526933904875};\\\", \\\"{x:1308,y:770,t:1526933904891};\\\", \\\"{x:1315,y:770,t:1526933904908};\\\", \\\"{x:1318,y:770,t:1526933904925};\\\", \\\"{x:1319,y:770,t:1526933904971};\\\", \\\"{x:1320,y:770,t:1526933904977};\\\", \\\"{x:1321,y:769,t:1526933905002};\\\", \\\"{x:1321,y:768,t:1526933905010};\\\", \\\"{x:1322,y:767,t:1526933905025};\\\", \\\"{x:1323,y:766,t:1526933905042};\\\", \\\"{x:1323,y:764,t:1526933905058};\\\", \\\"{x:1324,y:763,t:1526933905082};\\\", \\\"{x:1324,y:762,t:1526933905139};\\\", \\\"{x:1325,y:762,t:1526933905446};\\\", \\\"{x:1328,y:764,t:1526933905462};\\\", \\\"{x:1330,y:765,t:1526933905479};\\\", \\\"{x:1331,y:767,t:1526933905497};\\\", \\\"{x:1333,y:767,t:1526933905513};\\\", \\\"{x:1335,y:767,t:1526933905529};\\\", \\\"{x:1337,y:767,t:1526933905547};\\\", \\\"{x:1340,y:768,t:1526933905563};\\\", \\\"{x:1344,y:768,t:1526933905579};\\\", \\\"{x:1349,y:768,t:1526933905596};\\\", \\\"{x:1351,y:768,t:1526933905613};\\\", \\\"{x:1356,y:768,t:1526933905629};\\\", \\\"{x:1359,y:768,t:1526933905647};\\\", \\\"{x:1360,y:768,t:1526933905663};\\\", \\\"{x:1361,y:768,t:1526933905679};\\\", \\\"{x:1362,y:767,t:1526933905697};\\\", \\\"{x:1364,y:765,t:1526933905726};\\\", \\\"{x:1364,y:764,t:1526933905743};\\\", \\\"{x:1365,y:763,t:1526933905750};\\\", \\\"{x:1366,y:761,t:1526933905767};\\\", \\\"{x:1366,y:760,t:1526933905790};\\\", \\\"{x:1367,y:759,t:1526933905807};\\\", \\\"{x:1368,y:757,t:1526933905846};\\\", \\\"{x:1369,y:757,t:1526933905863};\\\", \\\"{x:1369,y:756,t:1526933905879};\\\", \\\"{x:1370,y:756,t:1526933905902};\\\", \\\"{x:1371,y:755,t:1526933905959};\\\", \\\"{x:1372,y:754,t:1526933905991};\\\", \\\"{x:1373,y:754,t:1526933907279};\\\", \\\"{x:1373,y:756,t:1526933907286};\\\", \\\"{x:1373,y:760,t:1526933907297};\\\", \\\"{x:1374,y:763,t:1526933907315};\\\", \\\"{x:1374,y:767,t:1526933907331};\\\", \\\"{x:1374,y:770,t:1526933907348};\\\", \\\"{x:1374,y:772,t:1526933907364};\\\", \\\"{x:1374,y:773,t:1526933907380};\\\", \\\"{x:1374,y:775,t:1526933907397};\\\", \\\"{x:1374,y:776,t:1526933907422};\\\", \\\"{x:1373,y:777,t:1526933907431};\\\", \\\"{x:1371,y:777,t:1526933907447};\\\", \\\"{x:1368,y:777,t:1526933907465};\\\", \\\"{x:1367,y:777,t:1526933907480};\\\", \\\"{x:1366,y:777,t:1526933907503};\\\", \\\"{x:1365,y:777,t:1526933907519};\\\", \\\"{x:1364,y:777,t:1526933907535};\\\", \\\"{x:1363,y:777,t:1526933907547};\\\", \\\"{x:1362,y:776,t:1526933907564};\\\", \\\"{x:1361,y:775,t:1526933907581};\\\", \\\"{x:1360,y:775,t:1526933907598};\\\", \\\"{x:1359,y:775,t:1526933907614};\\\", \\\"{x:1357,y:773,t:1526933907631};\\\", \\\"{x:1356,y:772,t:1526933907648};\\\", \\\"{x:1354,y:770,t:1526933907664};\\\", \\\"{x:1353,y:769,t:1526933907682};\\\", \\\"{x:1353,y:768,t:1526933907697};\\\", \\\"{x:1351,y:767,t:1526933907715};\\\", \\\"{x:1350,y:766,t:1526933907732};\\\", \\\"{x:1348,y:763,t:1526933907747};\\\", \\\"{x:1347,y:762,t:1526933907764};\\\", \\\"{x:1347,y:761,t:1526933907781};\\\", \\\"{x:1347,y:760,t:1526933907797};\\\", \\\"{x:1347,y:759,t:1526933907814};\\\", \\\"{x:1347,y:758,t:1526933907831};\\\", \\\"{x:1347,y:760,t:1526933910014};\\\", \\\"{x:1347,y:761,t:1526933910022};\\\", \\\"{x:1347,y:763,t:1526933910032};\\\", \\\"{x:1349,y:765,t:1526933910049};\\\", \\\"{x:1349,y:766,t:1526933910150};\\\", \\\"{x:1351,y:768,t:1526933910166};\\\", \\\"{x:1355,y:770,t:1526933910182};\\\", \\\"{x:1360,y:771,t:1526933910200};\\\", \\\"{x:1369,y:774,t:1526933910217};\\\", \\\"{x:1375,y:775,t:1526933910233};\\\", \\\"{x:1382,y:777,t:1526933910249};\\\", \\\"{x:1389,y:778,t:1526933910266};\\\", \\\"{x:1392,y:778,t:1526933910282};\\\", \\\"{x:1398,y:779,t:1526933910299};\\\", \\\"{x:1400,y:779,t:1526933910316};\\\", \\\"{x:1402,y:779,t:1526933910333};\\\", \\\"{x:1403,y:779,t:1526933910462};\\\", \\\"{x:1405,y:779,t:1526933910478};\\\", \\\"{x:1406,y:779,t:1526933910494};\\\", \\\"{x:1406,y:778,t:1526933910502};\\\", \\\"{x:1408,y:778,t:1526933910517};\\\", \\\"{x:1408,y:777,t:1526933910533};\\\", \\\"{x:1408,y:776,t:1526933910550};\\\", \\\"{x:1409,y:774,t:1526933910566};\\\", \\\"{x:1409,y:773,t:1526933910583};\\\", \\\"{x:1409,y:771,t:1526933910599};\\\", \\\"{x:1409,y:770,t:1526933910616};\\\", \\\"{x:1410,y:769,t:1526933910634};\\\", \\\"{x:1411,y:768,t:1526933910649};\\\", \\\"{x:1411,y:767,t:1526933910694};\\\", \\\"{x:1411,y:765,t:1526933910711};\\\", \\\"{x:1411,y:764,t:1526933910726};\\\", \\\"{x:1411,y:762,t:1526933910734};\\\", \\\"{x:1411,y:761,t:1526933910750};\\\", \\\"{x:1413,y:762,t:1526933910998};\\\", \\\"{x:1415,y:764,t:1526933911006};\\\", \\\"{x:1418,y:765,t:1526933911017};\\\", \\\"{x:1419,y:767,t:1526933911034};\\\", \\\"{x:1423,y:769,t:1526933911051};\\\", \\\"{x:1427,y:770,t:1526933911066};\\\", \\\"{x:1430,y:770,t:1526933911084};\\\", \\\"{x:1434,y:770,t:1526933911101};\\\", \\\"{x:1436,y:770,t:1526933911117};\\\", \\\"{x:1442,y:770,t:1526933911134};\\\", \\\"{x:1444,y:770,t:1526933911151};\\\", \\\"{x:1446,y:770,t:1526933911166};\\\", \\\"{x:1449,y:770,t:1526933911184};\\\", \\\"{x:1452,y:769,t:1526933911200};\\\", \\\"{x:1454,y:768,t:1526933911216};\\\", \\\"{x:1456,y:767,t:1526933911233};\\\", \\\"{x:1458,y:765,t:1526933911249};\\\", \\\"{x:1460,y:764,t:1526933911266};\\\", \\\"{x:1461,y:764,t:1526933911283};\\\", \\\"{x:1463,y:762,t:1526933911300};\\\", \\\"{x:1465,y:761,t:1526933911316};\\\", \\\"{x:1466,y:760,t:1526933911332};\\\", \\\"{x:1467,y:759,t:1526933911350};\\\", \\\"{x:1468,y:759,t:1526933911366};\\\", \\\"{x:1469,y:758,t:1526933911383};\\\", \\\"{x:1469,y:757,t:1526933911400};\\\", \\\"{x:1471,y:757,t:1526933911417};\\\", \\\"{x:1471,y:756,t:1526933911446};\\\", \\\"{x:1472,y:756,t:1526933912007};\\\", \\\"{x:1473,y:757,t:1526933912018};\\\", \\\"{x:1476,y:764,t:1526933912035};\\\", \\\"{x:1480,y:770,t:1526933912051};\\\", \\\"{x:1483,y:774,t:1526933912068};\\\", \\\"{x:1487,y:778,t:1526933912085};\\\", \\\"{x:1488,y:779,t:1526933912101};\\\", \\\"{x:1488,y:780,t:1526933912117};\\\", \\\"{x:1490,y:780,t:1526933912134};\\\", \\\"{x:1491,y:781,t:1526933912151};\\\", \\\"{x:1492,y:781,t:1526933912168};\\\", \\\"{x:1493,y:781,t:1526933912185};\\\", \\\"{x:1494,y:781,t:1526933912222};\\\", \\\"{x:1496,y:781,t:1526933912235};\\\", \\\"{x:1497,y:781,t:1526933912250};\\\", \\\"{x:1500,y:781,t:1526933912268};\\\", \\\"{x:1504,y:781,t:1526933912284};\\\", \\\"{x:1510,y:779,t:1526933912300};\\\", \\\"{x:1516,y:778,t:1526933912317};\\\", \\\"{x:1522,y:775,t:1526933912334};\\\", \\\"{x:1524,y:775,t:1526933912351};\\\", \\\"{x:1525,y:774,t:1526933912374};\\\", \\\"{x:1526,y:773,t:1526933912390};\\\", \\\"{x:1527,y:772,t:1526933912402};\\\", \\\"{x:1528,y:771,t:1526933912417};\\\", \\\"{x:1530,y:770,t:1526933912434};\\\", \\\"{x:1532,y:768,t:1526933912452};\\\", \\\"{x:1533,y:766,t:1526933912468};\\\", \\\"{x:1533,y:765,t:1526933912484};\\\", \\\"{x:1534,y:763,t:1526933912502};\\\", \\\"{x:1535,y:762,t:1526933912518};\\\", \\\"{x:1536,y:760,t:1526933912534};\\\", \\\"{x:1537,y:758,t:1526933912552};\\\", \\\"{x:1538,y:757,t:1526933912568};\\\", \\\"{x:1538,y:756,t:1526933912585};\\\", \\\"{x:1539,y:755,t:1526933912601};\\\", \\\"{x:1539,y:758,t:1526933914230};\\\", \\\"{x:1539,y:760,t:1526933914237};\\\", \\\"{x:1539,y:764,t:1526933914252};\\\", \\\"{x:1538,y:766,t:1526933914269};\\\", \\\"{x:1537,y:767,t:1526933914285};\\\", \\\"{x:1536,y:768,t:1526933914302};\\\", \\\"{x:1535,y:768,t:1526933914325};\\\", \\\"{x:1533,y:768,t:1526933914357};\\\", \\\"{x:1532,y:768,t:1526933914373};\\\", \\\"{x:1528,y:770,t:1526933914386};\\\", \\\"{x:1526,y:770,t:1526933914402};\\\", \\\"{x:1522,y:771,t:1526933914419};\\\", \\\"{x:1519,y:771,t:1526933914435};\\\", \\\"{x:1514,y:772,t:1526933914452};\\\", \\\"{x:1506,y:772,t:1526933914469};\\\", \\\"{x:1502,y:772,t:1526933914486};\\\", \\\"{x:1497,y:772,t:1526933914502};\\\", \\\"{x:1494,y:772,t:1526933914519};\\\", \\\"{x:1490,y:772,t:1526933914535};\\\", \\\"{x:1487,y:772,t:1526933914552};\\\", \\\"{x:1485,y:772,t:1526933914569};\\\", \\\"{x:1483,y:772,t:1526933914585};\\\", \\\"{x:1481,y:772,t:1526933914602};\\\", \\\"{x:1479,y:772,t:1526933914619};\\\", \\\"{x:1478,y:772,t:1526933914636};\\\", \\\"{x:1476,y:774,t:1526933914652};\\\", \\\"{x:1475,y:774,t:1526933914686};\\\", \\\"{x:1473,y:774,t:1526933914703};\\\", \\\"{x:1471,y:774,t:1526933914726};\\\", \\\"{x:1470,y:774,t:1526933914742};\\\", \\\"{x:1469,y:774,t:1526933914774};\\\", \\\"{x:1468,y:774,t:1526933916383};\\\", \\\"{x:1467,y:774,t:1526933916398};\\\", \\\"{x:1467,y:773,t:1526933916406};\\\", \\\"{x:1466,y:773,t:1526933916438};\\\", \\\"{x:1465,y:773,t:1526933916454};\\\", \\\"{x:1463,y:772,t:1526933916471};\\\", \\\"{x:1462,y:771,t:1526933916510};\\\", \\\"{x:1461,y:771,t:1526933916526};\\\", \\\"{x:1460,y:771,t:1526933916538};\\\", \\\"{x:1458,y:771,t:1526933916553};\\\", \\\"{x:1454,y:770,t:1526933916571};\\\", \\\"{x:1451,y:770,t:1526933916588};\\\", \\\"{x:1450,y:770,t:1526933916604};\\\", \\\"{x:1449,y:770,t:1526933916621};\\\", \\\"{x:1447,y:769,t:1526933916637};\\\", \\\"{x:1447,y:768,t:1526933916807};\\\", \\\"{x:1447,y:767,t:1526933916839};\\\", \\\"{x:1446,y:766,t:1526933916879};\\\", \\\"{x:1446,y:765,t:1526933916895};\\\", \\\"{x:1445,y:765,t:1526933916905};\\\", \\\"{x:1444,y:765,t:1526933916921};\\\", \\\"{x:1441,y:765,t:1526933916938};\\\", \\\"{x:1433,y:765,t:1526933916955};\\\", \\\"{x:1423,y:765,t:1526933916971};\\\", \\\"{x:1407,y:765,t:1526933916988};\\\", \\\"{x:1390,y:765,t:1526933917005};\\\", \\\"{x:1374,y:765,t:1526933917021};\\\", \\\"{x:1349,y:765,t:1526933917039};\\\", \\\"{x:1338,y:765,t:1526933917055};\\\", \\\"{x:1330,y:765,t:1526933917071};\\\", \\\"{x:1328,y:764,t:1526933917088};\\\", \\\"{x:1327,y:764,t:1526933917104};\\\", \\\"{x:1329,y:764,t:1526933917373};\\\", \\\"{x:1335,y:764,t:1526933917387};\\\", \\\"{x:1355,y:764,t:1526933917404};\\\", \\\"{x:1391,y:764,t:1526933917421};\\\", \\\"{x:1413,y:764,t:1526933917437};\\\", \\\"{x:1428,y:764,t:1526933917454};\\\", \\\"{x:1435,y:764,t:1526933917471};\\\", \\\"{x:1437,y:763,t:1526933917488};\\\", \\\"{x:1439,y:762,t:1526933917751};\\\", \\\"{x:1440,y:761,t:1526933917758};\\\", \\\"{x:1441,y:760,t:1526933917774};\\\", \\\"{x:1444,y:760,t:1526933917788};\\\", \\\"{x:1445,y:760,t:1526933917805};\\\", \\\"{x:1447,y:760,t:1526933917870};\\\", \\\"{x:1448,y:760,t:1526933917918};\\\", \\\"{x:1450,y:760,t:1526933917975};\\\", \\\"{x:1451,y:760,t:1526933918063};\\\", \\\"{x:1453,y:760,t:1526933918094};\\\", \\\"{x:1454,y:760,t:1526933918126};\\\", \\\"{x:1455,y:760,t:1526933918174};\\\", \\\"{x:1456,y:761,t:1526933918189};\\\", \\\"{x:1458,y:761,t:1526933918206};\\\", \\\"{x:1459,y:761,t:1526933918271};\\\", \\\"{x:1462,y:762,t:1526933918288};\\\", \\\"{x:1464,y:762,t:1526933918306};\\\", \\\"{x:1470,y:765,t:1526933918322};\\\", \\\"{x:1472,y:765,t:1526933918338};\\\", \\\"{x:1474,y:765,t:1526933918356};\\\", \\\"{x:1475,y:765,t:1526933918372};\\\", \\\"{x:1473,y:765,t:1526933920807};\\\", \\\"{x:1442,y:743,t:1526933920824};\\\", \\\"{x:1401,y:720,t:1526933920841};\\\", \\\"{x:1371,y:702,t:1526933920857};\\\", \\\"{x:1343,y:693,t:1526933920874};\\\", \\\"{x:1331,y:688,t:1526933920892};\\\", \\\"{x:1329,y:686,t:1526933920908};\\\", \\\"{x:1328,y:686,t:1526933921030};\\\", \\\"{x:1329,y:686,t:1526933921174};\\\", \\\"{x:1333,y:689,t:1526933921191};\\\", \\\"{x:1339,y:692,t:1526933921209};\\\", \\\"{x:1344,y:695,t:1526933921225};\\\", \\\"{x:1346,y:695,t:1526933921240};\\\", \\\"{x:1347,y:696,t:1526933921303};\\\", \\\"{x:1349,y:697,t:1526933922750};\\\", \\\"{x:1350,y:698,t:1526933922766};\\\", \\\"{x:1352,y:698,t:1526933922789};\\\", \\\"{x:1352,y:699,t:1526933922798};\\\", \\\"{x:1353,y:699,t:1526933922810};\\\", \\\"{x:1355,y:700,t:1526933922902};\\\", \\\"{x:1356,y:701,t:1526933922917};\\\", \\\"{x:1357,y:702,t:1526933922941};\\\", \\\"{x:1359,y:702,t:1526933922959};\\\", \\\"{x:1361,y:704,t:1526933922975};\\\", \\\"{x:1363,y:704,t:1526933922992};\\\", \\\"{x:1365,y:705,t:1526933923010};\\\", \\\"{x:1367,y:706,t:1526933923026};\\\", \\\"{x:1369,y:707,t:1526933923042};\\\", \\\"{x:1372,y:708,t:1526933923059};\\\", \\\"{x:1373,y:709,t:1526933923094};\\\", \\\"{x:1374,y:709,t:1526933923126};\\\", \\\"{x:1375,y:709,t:1526933923142};\\\", \\\"{x:1376,y:709,t:1526933923159};\\\", \\\"{x:1378,y:709,t:1526933923176};\\\", \\\"{x:1379,y:709,t:1526933923198};\\\", \\\"{x:1374,y:707,t:1526933923727};\\\", \\\"{x:1357,y:705,t:1526933923743};\\\", \\\"{x:1305,y:702,t:1526933923759};\\\", \\\"{x:1211,y:702,t:1526933923777};\\\", \\\"{x:1089,y:702,t:1526933923793};\\\", \\\"{x:937,y:702,t:1526933923811};\\\", \\\"{x:763,y:702,t:1526933923825};\\\", \\\"{x:614,y:702,t:1526933923843};\\\", \\\"{x:492,y:702,t:1526933923860};\\\", \\\"{x:397,y:700,t:1526933923876};\\\", \\\"{x:353,y:700,t:1526933923893};\\\", \\\"{x:317,y:695,t:1526933923910};\\\", \\\"{x:309,y:694,t:1526933923925};\\\", \\\"{x:305,y:691,t:1526933923943};\\\", \\\"{x:305,y:690,t:1526933924317};\\\", \\\"{x:306,y:686,t:1526933924357};\\\", \\\"{x:305,y:686,t:1526933924365};\\\", \\\"{x:305,y:683,t:1526933924377};\\\", \\\"{x:302,y:676,t:1526933924392};\\\", \\\"{x:297,y:671,t:1526933924409};\\\", \\\"{x:293,y:668,t:1526933924428};\\\", \\\"{x:284,y:664,t:1526933924444};\\\", \\\"{x:279,y:662,t:1526933924461};\\\", \\\"{x:275,y:660,t:1526933924478};\\\", \\\"{x:270,y:658,t:1526933924496};\\\", \\\"{x:265,y:655,t:1526933924512};\\\", \\\"{x:260,y:653,t:1526933924528};\\\", \\\"{x:254,y:650,t:1526933924546};\\\", \\\"{x:247,y:646,t:1526933924563};\\\", \\\"{x:240,y:643,t:1526933924579};\\\", \\\"{x:238,y:641,t:1526933924595};\\\", \\\"{x:237,y:641,t:1526933924612};\\\", \\\"{x:237,y:639,t:1526933924669};\\\", \\\"{x:237,y:636,t:1526933924678};\\\", \\\"{x:249,y:629,t:1526933924696};\\\", \\\"{x:275,y:620,t:1526933924714};\\\", \\\"{x:322,y:609,t:1526933924729};\\\", \\\"{x:383,y:601,t:1526933924747};\\\", \\\"{x:466,y:594,t:1526933924762};\\\", \\\"{x:541,y:592,t:1526933924779};\\\", \\\"{x:613,y:592,t:1526933924795};\\\", \\\"{x:660,y:588,t:1526933924812};\\\", \\\"{x:690,y:586,t:1526933924829};\\\", \\\"{x:695,y:585,t:1526933924846};\\\", \\\"{x:693,y:585,t:1526933925054};\\\", \\\"{x:692,y:585,t:1526933925069};\\\", \\\"{x:689,y:585,t:1526933925078};\\\", \\\"{x:686,y:585,t:1526933925096};\\\", \\\"{x:678,y:585,t:1526933925112};\\\", \\\"{x:668,y:585,t:1526933925128};\\\", \\\"{x:652,y:588,t:1526933925146};\\\", \\\"{x:640,y:589,t:1526933925162};\\\", \\\"{x:630,y:590,t:1526933925179};\\\", \\\"{x:624,y:592,t:1526933925195};\\\", \\\"{x:617,y:595,t:1526933925213};\\\", \\\"{x:613,y:597,t:1526933925229};\\\", \\\"{x:612,y:597,t:1526933925245};\\\", \\\"{x:611,y:597,t:1526933925262};\\\", \\\"{x:611,y:596,t:1526933925317};\\\", \\\"{x:615,y:592,t:1526933925329};\\\", \\\"{x:621,y:585,t:1526933925346};\\\", \\\"{x:627,y:578,t:1526933925363};\\\", \\\"{x:633,y:568,t:1526933925381};\\\", \\\"{x:634,y:561,t:1526933925396};\\\", \\\"{x:634,y:556,t:1526933925412};\\\", \\\"{x:634,y:552,t:1526933925429};\\\", \\\"{x:634,y:551,t:1526933925447};\\\", \\\"{x:634,y:550,t:1526933925462};\\\", \\\"{x:634,y:548,t:1526933925479};\\\", \\\"{x:636,y:547,t:1526933925502};\\\", \\\"{x:640,y:547,t:1526933925513};\\\", \\\"{x:655,y:547,t:1526933925530};\\\", \\\"{x:684,y:547,t:1526933925546};\\\", \\\"{x:725,y:544,t:1526933925563};\\\", \\\"{x:764,y:539,t:1526933925578};\\\", \\\"{x:786,y:535,t:1526933925596};\\\", \\\"{x:793,y:535,t:1526933925613};\\\", \\\"{x:795,y:535,t:1526933925629};\\\", \\\"{x:795,y:534,t:1526933925733};\\\", \\\"{x:796,y:534,t:1526933925746};\\\", \\\"{x:798,y:532,t:1526933925763};\\\", \\\"{x:799,y:530,t:1526933925780};\\\", \\\"{x:801,y:526,t:1526933925795};\\\", \\\"{x:805,y:521,t:1526933925813};\\\", \\\"{x:806,y:519,t:1526933925829};\\\", \\\"{x:807,y:517,t:1526933925847};\\\", \\\"{x:809,y:516,t:1526933925864};\\\", \\\"{x:810,y:516,t:1526933925880};\\\", \\\"{x:812,y:514,t:1526933925897};\\\", \\\"{x:813,y:514,t:1526933925914};\\\", \\\"{x:814,y:514,t:1526933925930};\\\", \\\"{x:816,y:514,t:1526933925947};\\\", \\\"{x:817,y:513,t:1526933925964};\\\", \\\"{x:818,y:513,t:1526933925981};\\\", \\\"{x:819,y:513,t:1526933926021};\\\", \\\"{x:820,y:513,t:1526933926037};\\\", \\\"{x:821,y:513,t:1526933926047};\\\", \\\"{x:822,y:513,t:1526933926064};\\\", \\\"{x:822,y:514,t:1526933926080};\\\", \\\"{x:824,y:514,t:1526933926097};\\\", \\\"{x:826,y:515,t:1526933926157};\\\", \\\"{x:827,y:515,t:1526933926197};\\\", \\\"{x:827,y:516,t:1526933926213};\\\", \\\"{x:828,y:516,t:1526933926278};\\\", \\\"{x:835,y:522,t:1526933926918};\\\", \\\"{x:845,y:529,t:1526933926932};\\\", \\\"{x:878,y:548,t:1526933926948};\\\", \\\"{x:934,y:573,t:1526933926964};\\\", \\\"{x:1000,y:590,t:1526933926981};\\\", \\\"{x:1120,y:626,t:1526933926998};\\\", \\\"{x:1189,y:645,t:1526933927013};\\\", \\\"{x:1257,y:670,t:1526933927031};\\\", \\\"{x:1326,y:688,t:1526933927048};\\\", \\\"{x:1377,y:704,t:1526933927064};\\\", \\\"{x:1419,y:717,t:1526933927081};\\\", \\\"{x:1455,y:726,t:1526933927098};\\\", \\\"{x:1480,y:736,t:1526933927114};\\\", \\\"{x:1504,y:741,t:1526933927131};\\\", \\\"{x:1522,y:747,t:1526933927148};\\\", \\\"{x:1535,y:750,t:1526933927165};\\\", \\\"{x:1544,y:753,t:1526933927181};\\\", \\\"{x:1549,y:754,t:1526933927198};\\\", \\\"{x:1549,y:753,t:1526933927678};\\\", \\\"{x:1546,y:750,t:1526933927686};\\\", \\\"{x:1542,y:748,t:1526933927698};\\\", \\\"{x:1532,y:743,t:1526933927715};\\\", \\\"{x:1529,y:742,t:1526933927733};\\\", \\\"{x:1528,y:739,t:1526933927748};\\\", \\\"{x:1528,y:737,t:1526933928238};\\\", \\\"{x:1528,y:736,t:1526933928254};\\\", \\\"{x:1528,y:734,t:1526933928286};\\\", \\\"{x:1528,y:733,t:1526933928310};\\\", \\\"{x:1527,y:733,t:1526933928318};\\\", \\\"{x:1526,y:731,t:1526933928334};\\\", \\\"{x:1525,y:730,t:1526933928350};\\\", \\\"{x:1525,y:728,t:1526933928366};\\\", \\\"{x:1523,y:727,t:1526933928382};\\\", \\\"{x:1521,y:725,t:1526933928399};\\\", \\\"{x:1518,y:721,t:1526933928416};\\\", \\\"{x:1513,y:719,t:1526933928432};\\\", \\\"{x:1509,y:716,t:1526933928449};\\\", \\\"{x:1504,y:713,t:1526933928465};\\\", \\\"{x:1503,y:712,t:1526933928482};\\\", \\\"{x:1498,y:708,t:1526933928499};\\\", \\\"{x:1496,y:706,t:1526933928516};\\\", \\\"{x:1492,y:702,t:1526933928533};\\\", \\\"{x:1490,y:699,t:1526933928549};\\\", \\\"{x:1488,y:694,t:1526933928566};\\\", \\\"{x:1485,y:691,t:1526933928582};\\\", \\\"{x:1485,y:690,t:1526933928599};\\\", \\\"{x:1484,y:687,t:1526933928617};\\\", \\\"{x:1482,y:684,t:1526933928631};\\\", \\\"{x:1481,y:678,t:1526933928649};\\\", \\\"{x:1479,y:675,t:1526933928666};\\\", \\\"{x:1478,y:672,t:1526933928681};\\\", \\\"{x:1476,y:668,t:1526933928699};\\\", \\\"{x:1473,y:665,t:1526933928716};\\\", \\\"{x:1471,y:661,t:1526933928732};\\\", \\\"{x:1468,y:657,t:1526933928748};\\\", \\\"{x:1464,y:652,t:1526933928765};\\\", \\\"{x:1460,y:648,t:1526933928782};\\\", \\\"{x:1456,y:644,t:1526933928798};\\\", \\\"{x:1453,y:641,t:1526933928816};\\\", \\\"{x:1450,y:638,t:1526933928833};\\\", \\\"{x:1449,y:637,t:1526933928849};\\\", \\\"{x:1448,y:635,t:1526933928867};\\\", \\\"{x:1446,y:632,t:1526933928881};\\\", \\\"{x:1445,y:631,t:1526933928898};\\\", \\\"{x:1445,y:630,t:1526933928915};\\\", \\\"{x:1444,y:629,t:1526933928933};\\\", \\\"{x:1444,y:627,t:1526933928949};\\\", \\\"{x:1443,y:627,t:1526933928965};\\\", \\\"{x:1443,y:626,t:1526933931398};\\\", \\\"{x:1444,y:626,t:1526933931462};\\\", \\\"{x:1445,y:627,t:1526933933798};\\\", \\\"{x:1446,y:630,t:1526933933806};\\\", \\\"{x:1446,y:631,t:1526933933820};\\\", \\\"{x:1447,y:637,t:1526933933837};\\\", \\\"{x:1448,y:646,t:1526933933853};\\\", \\\"{x:1449,y:653,t:1526933933869};\\\", \\\"{x:1450,y:660,t:1526933933887};\\\", \\\"{x:1450,y:670,t:1526933933903};\\\", \\\"{x:1450,y:684,t:1526933933920};\\\", \\\"{x:1451,y:702,t:1526933933936};\\\", \\\"{x:1452,y:722,t:1526933933953};\\\", \\\"{x:1455,y:742,t:1526933933970};\\\", \\\"{x:1456,y:762,t:1526933933986};\\\", \\\"{x:1457,y:779,t:1526933934003};\\\", \\\"{x:1457,y:795,t:1526933934019};\\\", \\\"{x:1457,y:808,t:1526933934036};\\\", \\\"{x:1457,y:826,t:1526933934053};\\\", \\\"{x:1455,y:840,t:1526933934069};\\\", \\\"{x:1454,y:854,t:1526933934086};\\\", \\\"{x:1453,y:870,t:1526933934103};\\\", \\\"{x:1449,y:886,t:1526933934120};\\\", \\\"{x:1448,y:900,t:1526933934135};\\\", \\\"{x:1446,y:910,t:1526933934153};\\\", \\\"{x:1446,y:918,t:1526933934170};\\\", \\\"{x:1446,y:922,t:1526933934187};\\\", \\\"{x:1445,y:926,t:1526933934203};\\\", \\\"{x:1444,y:931,t:1526933934220};\\\", \\\"{x:1443,y:944,t:1526933934236};\\\", \\\"{x:1443,y:952,t:1526933934253};\\\", \\\"{x:1441,y:961,t:1526933934270};\\\", \\\"{x:1440,y:971,t:1526933934287};\\\", \\\"{x:1439,y:976,t:1526933934303};\\\", \\\"{x:1439,y:977,t:1526933934320};\\\", \\\"{x:1439,y:979,t:1526933934341};\\\", \\\"{x:1437,y:977,t:1526933934742};\\\", \\\"{x:1437,y:973,t:1526933934754};\\\", \\\"{x:1436,y:964,t:1526933934771};\\\", \\\"{x:1433,y:956,t:1526933934788};\\\", \\\"{x:1432,y:951,t:1526933934804};\\\", \\\"{x:1431,y:947,t:1526933934820};\\\", \\\"{x:1428,y:942,t:1526933934838};\\\", \\\"{x:1426,y:940,t:1526933934854};\\\", \\\"{x:1425,y:937,t:1526933934870};\\\", \\\"{x:1422,y:935,t:1526933934888};\\\", \\\"{x:1421,y:933,t:1526933934904};\\\", \\\"{x:1418,y:931,t:1526933934920};\\\", \\\"{x:1415,y:927,t:1526933934937};\\\", \\\"{x:1410,y:924,t:1526933934954};\\\", \\\"{x:1405,y:920,t:1526933934970};\\\", \\\"{x:1400,y:917,t:1526933934987};\\\", \\\"{x:1395,y:914,t:1526933935004};\\\", \\\"{x:1391,y:911,t:1526933935021};\\\", \\\"{x:1388,y:908,t:1526933935038};\\\", \\\"{x:1386,y:906,t:1526933935054};\\\", \\\"{x:1384,y:904,t:1526933935070};\\\", \\\"{x:1382,y:904,t:1526933935087};\\\", \\\"{x:1380,y:901,t:1526933935105};\\\", \\\"{x:1380,y:900,t:1526933935122};\\\", \\\"{x:1379,y:899,t:1526933935137};\\\", \\\"{x:1378,y:898,t:1526933935155};\\\", \\\"{x:1377,y:897,t:1526933935189};\\\", \\\"{x:1377,y:896,t:1526933935734};\\\", \\\"{x:1378,y:896,t:1526933935749};\\\", \\\"{x:1379,y:896,t:1526933935757};\\\", \\\"{x:1380,y:896,t:1526933935771};\\\", \\\"{x:1381,y:896,t:1526933935788};\\\", \\\"{x:1382,y:896,t:1526933935805};\\\", \\\"{x:1383,y:896,t:1526933935926};\\\", \\\"{x:1384,y:896,t:1526933935941};\\\", \\\"{x:1386,y:895,t:1526933935954};\\\", \\\"{x:1389,y:891,t:1526933935972};\\\", \\\"{x:1393,y:886,t:1526933935988};\\\", \\\"{x:1397,y:879,t:1526933936006};\\\", \\\"{x:1401,y:874,t:1526933936022};\\\", \\\"{x:1408,y:869,t:1526933936039};\\\", \\\"{x:1418,y:863,t:1526933936055};\\\", \\\"{x:1430,y:856,t:1526933936071};\\\", \\\"{x:1442,y:852,t:1526933936088};\\\", \\\"{x:1448,y:850,t:1526933936105};\\\", \\\"{x:1453,y:846,t:1526933936121};\\\", \\\"{x:1456,y:846,t:1526933936138};\\\", \\\"{x:1456,y:845,t:1526933936155};\\\", \\\"{x:1457,y:845,t:1526933936171};\\\", \\\"{x:1458,y:844,t:1526933936212};\\\", \\\"{x:1459,y:844,t:1526933936221};\\\", \\\"{x:1459,y:843,t:1526933936244};\\\", \\\"{x:1460,y:843,t:1526933936255};\\\", \\\"{x:1461,y:842,t:1526933936271};\\\", \\\"{x:1463,y:839,t:1526933936288};\\\", \\\"{x:1464,y:839,t:1526933936305};\\\", \\\"{x:1466,y:837,t:1526933936321};\\\", \\\"{x:1467,y:835,t:1526933936338};\\\", \\\"{x:1467,y:834,t:1526933936355};\\\", \\\"{x:1468,y:834,t:1526933936371};\\\", \\\"{x:1469,y:832,t:1526933936388};\\\", \\\"{x:1469,y:830,t:1526933936420};\\\", \\\"{x:1470,y:830,t:1526933936428};\\\", \\\"{x:1470,y:829,t:1526933936437};\\\", \\\"{x:1472,y:829,t:1526933936455};\\\", \\\"{x:1473,y:827,t:1526933936471};\\\", \\\"{x:1477,y:825,t:1526933936488};\\\", \\\"{x:1479,y:823,t:1526933936505};\\\", \\\"{x:1481,y:822,t:1526933936521};\\\", \\\"{x:1484,y:821,t:1526933936538};\\\", \\\"{x:1485,y:821,t:1526933936555};\\\", \\\"{x:1487,y:821,t:1526933936572};\\\", \\\"{x:1488,y:821,t:1526933936588};\\\", \\\"{x:1489,y:821,t:1526933936604};\\\", \\\"{x:1491,y:821,t:1526933936622};\\\", \\\"{x:1493,y:821,t:1526933936716};\\\", \\\"{x:1493,y:822,t:1526933936981};\\\", \\\"{x:1493,y:823,t:1526933936988};\\\", \\\"{x:1493,y:824,t:1526933937004};\\\", \\\"{x:1491,y:824,t:1526933937022};\\\", \\\"{x:1490,y:824,t:1526933937038};\\\", \\\"{x:1490,y:825,t:1526933937055};\\\", \\\"{x:1488,y:825,t:1526933937072};\\\", \\\"{x:1487,y:826,t:1526933937089};\\\", \\\"{x:1486,y:826,t:1526933937105};\\\", \\\"{x:1485,y:826,t:1526933937121};\\\", \\\"{x:1483,y:826,t:1526933937138};\\\", \\\"{x:1482,y:826,t:1526933937155};\\\", \\\"{x:1480,y:826,t:1526933937172};\\\", \\\"{x:1477,y:826,t:1526933937188};\\\", \\\"{x:1474,y:825,t:1526933937206};\\\", \\\"{x:1471,y:824,t:1526933937222};\\\", \\\"{x:1468,y:823,t:1526933937239};\\\", \\\"{x:1467,y:823,t:1526933937256};\\\", \\\"{x:1465,y:822,t:1526933937272};\\\", \\\"{x:1465,y:821,t:1526933937289};\\\", \\\"{x:1465,y:818,t:1526933937306};\\\", \\\"{x:1465,y:813,t:1526933937322};\\\", \\\"{x:1466,y:806,t:1526933937339};\\\", \\\"{x:1471,y:796,t:1526933937356};\\\", \\\"{x:1479,y:789,t:1526933937372};\\\", \\\"{x:1484,y:783,t:1526933937389};\\\", \\\"{x:1489,y:778,t:1526933937406};\\\", \\\"{x:1494,y:775,t:1526933937422};\\\", \\\"{x:1497,y:771,t:1526933937440};\\\", \\\"{x:1503,y:768,t:1526933937456};\\\", \\\"{x:1506,y:766,t:1526933937472};\\\", \\\"{x:1509,y:764,t:1526933937490};\\\", \\\"{x:1510,y:763,t:1526933937506};\\\", \\\"{x:1512,y:763,t:1526933937522};\\\", \\\"{x:1512,y:762,t:1526933937539};\\\", \\\"{x:1512,y:761,t:1526933937742};\\\", \\\"{x:1511,y:761,t:1526933937773};\\\", \\\"{x:1510,y:760,t:1526933937789};\\\", \\\"{x:1509,y:760,t:1526933937807};\\\", \\\"{x:1507,y:759,t:1526933937823};\\\", \\\"{x:1505,y:759,t:1526933937846};\\\", \\\"{x:1505,y:758,t:1526933937857};\\\", \\\"{x:1503,y:758,t:1526933937873};\\\", \\\"{x:1502,y:757,t:1526933937890};\\\", \\\"{x:1499,y:755,t:1526933937907};\\\", \\\"{x:1494,y:751,t:1526933937924};\\\", \\\"{x:1490,y:747,t:1526933937939};\\\", \\\"{x:1485,y:742,t:1526933937957};\\\", \\\"{x:1477,y:734,t:1526933937973};\\\", \\\"{x:1473,y:730,t:1526933937989};\\\", \\\"{x:1468,y:726,t:1526933938007};\\\", \\\"{x:1461,y:717,t:1526933938024};\\\", \\\"{x:1455,y:711,t:1526933938039};\\\", \\\"{x:1452,y:707,t:1526933938057};\\\", \\\"{x:1448,y:700,t:1526933938074};\\\", \\\"{x:1444,y:694,t:1526933938090};\\\", \\\"{x:1442,y:690,t:1526933938106};\\\", \\\"{x:1439,y:685,t:1526933938123};\\\", \\\"{x:1437,y:680,t:1526933938140};\\\", \\\"{x:1435,y:676,t:1526933938157};\\\", \\\"{x:1433,y:671,t:1526933938174};\\\", \\\"{x:1431,y:669,t:1526933938189};\\\", \\\"{x:1431,y:667,t:1526933938207};\\\", \\\"{x:1430,y:665,t:1526933938224};\\\", \\\"{x:1429,y:665,t:1526933938350};\\\", \\\"{x:1428,y:665,t:1526933938358};\\\", \\\"{x:1426,y:665,t:1526933938382};\\\", \\\"{x:1425,y:665,t:1526933938390};\\\", \\\"{x:1421,y:666,t:1526933938407};\\\", \\\"{x:1415,y:666,t:1526933938424};\\\", \\\"{x:1410,y:666,t:1526933938440};\\\", \\\"{x:1408,y:667,t:1526933938457};\\\", \\\"{x:1406,y:667,t:1526933938474};\\\", \\\"{x:1405,y:667,t:1526933938491};\\\", \\\"{x:1404,y:668,t:1526933938507};\\\", \\\"{x:1401,y:668,t:1526933938523};\\\", \\\"{x:1400,y:670,t:1526933938541};\\\", \\\"{x:1398,y:670,t:1526933938557};\\\", \\\"{x:1397,y:671,t:1526933938573};\\\", \\\"{x:1395,y:673,t:1526933938591};\\\", \\\"{x:1394,y:674,t:1526933938608};\\\", \\\"{x:1393,y:674,t:1526933938623};\\\", \\\"{x:1390,y:676,t:1526933938640};\\\", \\\"{x:1387,y:680,t:1526933938657};\\\", \\\"{x:1385,y:681,t:1526933938673};\\\", \\\"{x:1383,y:683,t:1526933938690};\\\", \\\"{x:1380,y:684,t:1526933938707};\\\", \\\"{x:1376,y:687,t:1526933938723};\\\", \\\"{x:1374,y:687,t:1526933938740};\\\", \\\"{x:1373,y:688,t:1526933938758};\\\", \\\"{x:1370,y:688,t:1526933938773};\\\", \\\"{x:1368,y:690,t:1526933938791};\\\", \\\"{x:1363,y:690,t:1526933938807};\\\", \\\"{x:1358,y:691,t:1526933938824};\\\", \\\"{x:1353,y:691,t:1526933938841};\\\", \\\"{x:1349,y:691,t:1526933938858};\\\", \\\"{x:1346,y:691,t:1526933938873};\\\", \\\"{x:1343,y:691,t:1526933938890};\\\", \\\"{x:1341,y:691,t:1526933938908};\\\", \\\"{x:1338,y:691,t:1526933938924};\\\", \\\"{x:1335,y:691,t:1526933938941};\\\", \\\"{x:1336,y:691,t:1526933939206};\\\", \\\"{x:1338,y:691,t:1526933939214};\\\", \\\"{x:1339,y:692,t:1526933939224};\\\", \\\"{x:1342,y:692,t:1526933939241};\\\", \\\"{x:1344,y:692,t:1526933939258};\\\", \\\"{x:1345,y:694,t:1526933939274};\\\", \\\"{x:1346,y:694,t:1526933939293};\\\", \\\"{x:1347,y:694,t:1526933939307};\\\", \\\"{x:1348,y:694,t:1526933939366};\\\", \\\"{x:1349,y:695,t:1526933939694};\\\", \\\"{x:1350,y:695,t:1526933939717};\\\", \\\"{x:1351,y:696,t:1526933939725};\\\", \\\"{x:1355,y:699,t:1526933939742};\\\", \\\"{x:1359,y:704,t:1526933939757};\\\", \\\"{x:1366,y:709,t:1526933939775};\\\", \\\"{x:1371,y:713,t:1526933939791};\\\", \\\"{x:1374,y:715,t:1526933939808};\\\", \\\"{x:1375,y:715,t:1526933939824};\\\", \\\"{x:1377,y:717,t:1526933939841};\\\", \\\"{x:1378,y:717,t:1526933939895};\\\", \\\"{x:1380,y:717,t:1526933939959};\\\", \\\"{x:1381,y:717,t:1526933939975};\\\", \\\"{x:1383,y:717,t:1526933939991};\\\", \\\"{x:1385,y:717,t:1526933940010};\\\", \\\"{x:1386,y:717,t:1526933940024};\\\", \\\"{x:1390,y:717,t:1526933940041};\\\", \\\"{x:1394,y:717,t:1526933940058};\\\", \\\"{x:1400,y:717,t:1526933940074};\\\", \\\"{x:1407,y:716,t:1526933940091};\\\", \\\"{x:1412,y:716,t:1526933940108};\\\", \\\"{x:1414,y:715,t:1526933940124};\\\", \\\"{x:1417,y:714,t:1526933940141};\\\", \\\"{x:1419,y:713,t:1526933940158};\\\", \\\"{x:1420,y:712,t:1526933940189};\\\", \\\"{x:1421,y:712,t:1526933940213};\\\", \\\"{x:1421,y:711,t:1526933940224};\\\", \\\"{x:1423,y:709,t:1526933940241};\\\", \\\"{x:1424,y:707,t:1526933940259};\\\", \\\"{x:1424,y:705,t:1526933940275};\\\", \\\"{x:1424,y:704,t:1526933940292};\\\", \\\"{x:1424,y:703,t:1526933940309};\\\", \\\"{x:1424,y:700,t:1526933940326};\\\", \\\"{x:1424,y:697,t:1526933940342};\\\", \\\"{x:1424,y:696,t:1526933940359};\\\", \\\"{x:1424,y:694,t:1526933940375};\\\", \\\"{x:1425,y:693,t:1526933940493};\\\", \\\"{x:1429,y:695,t:1526933940509};\\\", \\\"{x:1450,y:711,t:1526933940526};\\\", \\\"{x:1462,y:717,t:1526933940541};\\\", \\\"{x:1474,y:724,t:1526933940559};\\\", \\\"{x:1481,y:726,t:1526933940576};\\\", \\\"{x:1487,y:727,t:1526933940591};\\\", \\\"{x:1491,y:727,t:1526933940610};\\\", \\\"{x:1492,y:727,t:1526933940626};\\\", \\\"{x:1493,y:727,t:1526933940653};\\\", \\\"{x:1495,y:727,t:1526933940670};\\\", \\\"{x:1495,y:725,t:1526933940686};\\\", \\\"{x:1495,y:722,t:1526933940694};\\\", \\\"{x:1495,y:721,t:1526933940709};\\\", \\\"{x:1495,y:715,t:1526933940726};\\\", \\\"{x:1495,y:712,t:1526933940742};\\\", \\\"{x:1495,y:708,t:1526933940759};\\\", \\\"{x:1494,y:706,t:1526933940775};\\\", \\\"{x:1493,y:704,t:1526933940793};\\\", \\\"{x:1491,y:701,t:1526933940810};\\\", \\\"{x:1491,y:698,t:1526933940826};\\\", \\\"{x:1490,y:697,t:1526933940843};\\\", \\\"{x:1489,y:695,t:1526933940859};\\\", \\\"{x:1489,y:694,t:1526933941062};\\\", \\\"{x:1491,y:694,t:1526933941076};\\\", \\\"{x:1497,y:697,t:1526933941092};\\\", \\\"{x:1505,y:703,t:1526933941109};\\\", \\\"{x:1515,y:710,t:1526933941125};\\\", \\\"{x:1520,y:712,t:1526933941142};\\\", \\\"{x:1523,y:713,t:1526933941159};\\\", \\\"{x:1525,y:713,t:1526933941175};\\\", \\\"{x:1526,y:713,t:1526933941192};\\\", \\\"{x:1528,y:713,t:1526933941211};\\\", \\\"{x:1529,y:713,t:1526933941225};\\\", \\\"{x:1531,y:713,t:1526933941241};\\\", \\\"{x:1534,y:710,t:1526933941259};\\\", \\\"{x:1537,y:706,t:1526933941275};\\\", \\\"{x:1540,y:703,t:1526933941292};\\\", \\\"{x:1542,y:700,t:1526933941309};\\\", \\\"{x:1543,y:698,t:1526933941325};\\\", \\\"{x:1544,y:695,t:1526933941342};\\\", \\\"{x:1544,y:693,t:1526933941359};\\\", \\\"{x:1546,y:691,t:1526933941375};\\\", \\\"{x:1546,y:690,t:1526933941430};\\\", \\\"{x:1546,y:689,t:1526933941518};\\\", \\\"{x:1549,y:689,t:1526933941526};\\\", \\\"{x:1556,y:690,t:1526933941543};\\\", \\\"{x:1561,y:694,t:1526933941559};\\\", \\\"{x:1573,y:701,t:1526933941576};\\\", \\\"{x:1582,y:706,t:1526933941593};\\\", \\\"{x:1595,y:711,t:1526933941610};\\\", \\\"{x:1604,y:712,t:1526933941626};\\\", \\\"{x:1610,y:712,t:1526933941643};\\\", \\\"{x:1616,y:712,t:1526933941660};\\\", \\\"{x:1618,y:712,t:1526933941677};\\\", \\\"{x:1620,y:712,t:1526933941693};\\\", \\\"{x:1625,y:711,t:1526933941709};\\\", \\\"{x:1627,y:708,t:1526933941727};\\\", \\\"{x:1627,y:705,t:1526933941743};\\\", \\\"{x:1627,y:703,t:1526933941760};\\\", \\\"{x:1627,y:700,t:1526933941777};\\\", \\\"{x:1627,y:697,t:1526933941793};\\\", \\\"{x:1626,y:693,t:1526933941810};\\\", \\\"{x:1618,y:690,t:1526933941827};\\\", \\\"{x:1614,y:687,t:1526933941843};\\\", \\\"{x:1610,y:687,t:1526933941859};\\\", \\\"{x:1604,y:687,t:1526933941877};\\\", \\\"{x:1598,y:687,t:1526933941893};\\\", \\\"{x:1588,y:687,t:1526933941909};\\\", \\\"{x:1582,y:689,t:1526933941926};\\\", \\\"{x:1574,y:691,t:1526933941943};\\\", \\\"{x:1570,y:692,t:1526933941959};\\\", \\\"{x:1566,y:693,t:1526933941977};\\\", \\\"{x:1564,y:693,t:1526933941993};\\\", \\\"{x:1559,y:693,t:1526933942010};\\\", \\\"{x:1551,y:693,t:1526933942026};\\\", \\\"{x:1538,y:693,t:1526933942043};\\\", \\\"{x:1527,y:693,t:1526933942059};\\\", \\\"{x:1514,y:691,t:1526933942076};\\\", \\\"{x:1503,y:689,t:1526933942093};\\\", \\\"{x:1498,y:688,t:1526933942109};\\\", \\\"{x:1494,y:688,t:1526933942126};\\\", \\\"{x:1490,y:688,t:1526933942143};\\\", \\\"{x:1488,y:688,t:1526933942160};\\\", \\\"{x:1487,y:688,t:1526933942177};\\\", \\\"{x:1486,y:688,t:1526933942357};\\\", \\\"{x:1486,y:689,t:1526933942381};\\\", \\\"{x:1486,y:690,t:1526933942405};\\\", \\\"{x:1486,y:692,t:1526933942413};\\\", \\\"{x:1486,y:693,t:1526933942426};\\\", \\\"{x:1486,y:694,t:1526933942446};\\\", \\\"{x:1486,y:695,t:1526933942460};\\\", \\\"{x:1486,y:696,t:1526933942477};\\\", \\\"{x:1486,y:699,t:1526933942494};\\\", \\\"{x:1486,y:701,t:1526933942510};\\\", \\\"{x:1486,y:705,t:1526933942527};\\\", \\\"{x:1486,y:707,t:1526933942544};\\\", \\\"{x:1486,y:709,t:1526933942561};\\\", \\\"{x:1486,y:711,t:1526933942576};\\\", \\\"{x:1486,y:712,t:1526933942593};\\\", \\\"{x:1486,y:714,t:1526933942611};\\\", \\\"{x:1487,y:716,t:1526933942626};\\\", \\\"{x:1487,y:717,t:1526933942644};\\\", \\\"{x:1487,y:721,t:1526933942661};\\\", \\\"{x:1488,y:721,t:1526933942676};\\\", \\\"{x:1488,y:724,t:1526933942694};\\\", \\\"{x:1488,y:725,t:1526933942710};\\\", \\\"{x:1488,y:726,t:1526933942734};\\\", \\\"{x:1487,y:727,t:1526933942838};\\\", \\\"{x:1480,y:727,t:1526933942845};\\\", \\\"{x:1471,y:728,t:1526933942861};\\\", \\\"{x:1447,y:728,t:1526933942876};\\\", \\\"{x:1408,y:728,t:1526933942894};\\\", \\\"{x:1383,y:728,t:1526933942911};\\\", \\\"{x:1361,y:725,t:1526933942927};\\\", \\\"{x:1346,y:721,t:1526933942944};\\\", \\\"{x:1324,y:713,t:1526933942961};\\\", \\\"{x:1303,y:704,t:1526933942977};\\\", \\\"{x:1279,y:696,t:1526933942994};\\\", \\\"{x:1255,y:687,t:1526933943011};\\\", \\\"{x:1227,y:680,t:1526933943027};\\\", \\\"{x:1190,y:669,t:1526933943043};\\\", \\\"{x:1159,y:661,t:1526933943061};\\\", \\\"{x:1103,y:646,t:1526933943077};\\\", \\\"{x:1067,y:635,t:1526933943093};\\\", \\\"{x:1043,y:628,t:1526933943110};\\\", \\\"{x:1019,y:619,t:1526933943128};\\\", \\\"{x:998,y:614,t:1526933943144};\\\", \\\"{x:975,y:608,t:1526933943161};\\\", \\\"{x:953,y:601,t:1526933943178};\\\", \\\"{x:931,y:595,t:1526933943195};\\\", \\\"{x:907,y:588,t:1526933943211};\\\", \\\"{x:887,y:583,t:1526933943226};\\\", \\\"{x:870,y:577,t:1526933943243};\\\", \\\"{x:851,y:572,t:1526933943258};\\\", \\\"{x:831,y:566,t:1526933943275};\\\", \\\"{x:804,y:558,t:1526933943293};\\\", \\\"{x:783,y:551,t:1526933943309};\\\", \\\"{x:769,y:546,t:1526933943327};\\\", \\\"{x:753,y:539,t:1526933943343};\\\", \\\"{x:737,y:535,t:1526933943361};\\\", \\\"{x:728,y:532,t:1526933943377};\\\", \\\"{x:726,y:531,t:1526933943395};\\\", \\\"{x:728,y:535,t:1526933943503};\\\", \\\"{x:739,y:547,t:1526933943512};\\\", \\\"{x:776,y:573,t:1526933943528};\\\", \\\"{x:835,y:618,t:1526933943545};\\\", \\\"{x:914,y:660,t:1526933943560};\\\", \\\"{x:1007,y:698,t:1526933943577};\\\", \\\"{x:1110,y:728,t:1526933943594};\\\", \\\"{x:1198,y:753,t:1526933943610};\\\", \\\"{x:1271,y:764,t:1526933943627};\\\", \\\"{x:1324,y:772,t:1526933943645};\\\", \\\"{x:1354,y:774,t:1526933943660};\\\", \\\"{x:1378,y:776,t:1526933943677};\\\", \\\"{x:1381,y:777,t:1526933943694};\\\", \\\"{x:1382,y:777,t:1526933943773};\\\", \\\"{x:1382,y:776,t:1526933943781};\\\", \\\"{x:1384,y:775,t:1526933943794};\\\", \\\"{x:1387,y:773,t:1526933943811};\\\", \\\"{x:1389,y:769,t:1526933943827};\\\", \\\"{x:1391,y:766,t:1526933943844};\\\", \\\"{x:1392,y:761,t:1526933943861};\\\", \\\"{x:1392,y:759,t:1526933943878};\\\", \\\"{x:1392,y:758,t:1526933943894};\\\", \\\"{x:1392,y:756,t:1526933943912};\\\", \\\"{x:1389,y:756,t:1526933943990};\\\", \\\"{x:1386,y:756,t:1526933943997};\\\", \\\"{x:1384,y:756,t:1526933944012};\\\", \\\"{x:1375,y:757,t:1526933944028};\\\", \\\"{x:1361,y:761,t:1526933944044};\\\", \\\"{x:1347,y:764,t:1526933944062};\\\", \\\"{x:1341,y:766,t:1526933944078};\\\", \\\"{x:1337,y:767,t:1526933944095};\\\", \\\"{x:1335,y:767,t:1526933944112};\\\", \\\"{x:1334,y:767,t:1526933944128};\\\", \\\"{x:1333,y:767,t:1526933944144};\\\", \\\"{x:1331,y:767,t:1526933944161};\\\", \\\"{x:1331,y:766,t:1526933944309};\\\", \\\"{x:1335,y:763,t:1526933944317};\\\", \\\"{x:1337,y:761,t:1526933944328};\\\", \\\"{x:1342,y:759,t:1526933944344};\\\", \\\"{x:1345,y:758,t:1526933944361};\\\", \\\"{x:1346,y:757,t:1526933944379};\\\", \\\"{x:1347,y:757,t:1526933944421};\\\", \\\"{x:1348,y:757,t:1526933944429};\\\", \\\"{x:1349,y:757,t:1526933944453};\\\", \\\"{x:1350,y:757,t:1526933944502};\\\", \\\"{x:1351,y:758,t:1526933944758};\\\", \\\"{x:1351,y:759,t:1526933945094};\\\", \\\"{x:1351,y:761,t:1526933945111};\\\", \\\"{x:1352,y:763,t:1526933945129};\\\", \\\"{x:1354,y:766,t:1526933945146};\\\", \\\"{x:1355,y:768,t:1526933945162};\\\", \\\"{x:1357,y:768,t:1526933945179};\\\", \\\"{x:1358,y:769,t:1526933945195};\\\", \\\"{x:1360,y:770,t:1526933945286};\\\", \\\"{x:1361,y:770,t:1526933945296};\\\", \\\"{x:1365,y:771,t:1526933945313};\\\", \\\"{x:1370,y:771,t:1526933945329};\\\", \\\"{x:1379,y:772,t:1526933945346};\\\", \\\"{x:1388,y:774,t:1526933945363};\\\", \\\"{x:1399,y:774,t:1526933945379};\\\", \\\"{x:1411,y:774,t:1526933945396};\\\", \\\"{x:1420,y:774,t:1526933945413};\\\", \\\"{x:1423,y:775,t:1526933945429};\\\", \\\"{x:1425,y:776,t:1526933945446};\\\", \\\"{x:1428,y:776,t:1526933945526};\\\", \\\"{x:1428,y:775,t:1526933945542};\\\", \\\"{x:1428,y:773,t:1526933945550};\\\", \\\"{x:1428,y:772,t:1526933945563};\\\", \\\"{x:1426,y:768,t:1526933945579};\\\", \\\"{x:1425,y:765,t:1526933945596};\\\", \\\"{x:1422,y:762,t:1526933945612};\\\", \\\"{x:1418,y:757,t:1526933945630};\\\", \\\"{x:1415,y:753,t:1526933945646};\\\", \\\"{x:1414,y:752,t:1526933945663};\\\", \\\"{x:1414,y:751,t:1526933945680};\\\", \\\"{x:1414,y:752,t:1526933945933};\\\", \\\"{x:1414,y:753,t:1526933945946};\\\", \\\"{x:1414,y:754,t:1526933945962};\\\", \\\"{x:1416,y:755,t:1526933945980};\\\", \\\"{x:1416,y:756,t:1526933945997};\\\", \\\"{x:1417,y:756,t:1526933946013};\\\", \\\"{x:1417,y:757,t:1526933946110};\\\", \\\"{x:1418,y:758,t:1526933946133};\\\", \\\"{x:1419,y:760,t:1526933946147};\\\", \\\"{x:1421,y:762,t:1526933946163};\\\", \\\"{x:1423,y:765,t:1526933946180};\\\", \\\"{x:1425,y:767,t:1526933946197};\\\", \\\"{x:1427,y:770,t:1526933946213};\\\", \\\"{x:1430,y:773,t:1526933946230};\\\", \\\"{x:1432,y:775,t:1526933946247};\\\", \\\"{x:1436,y:778,t:1526933946263};\\\", \\\"{x:1439,y:781,t:1526933946280};\\\", \\\"{x:1441,y:782,t:1526933946297};\\\", \\\"{x:1443,y:783,t:1526933946313};\\\", \\\"{x:1444,y:784,t:1526933946330};\\\", \\\"{x:1446,y:784,t:1526933946347};\\\", \\\"{x:1447,y:784,t:1526933946363};\\\", \\\"{x:1451,y:784,t:1526933946380};\\\", \\\"{x:1456,y:784,t:1526933946397};\\\", \\\"{x:1459,y:784,t:1526933946413};\\\", \\\"{x:1465,y:783,t:1526933946429};\\\", \\\"{x:1468,y:781,t:1526933946446};\\\", \\\"{x:1471,y:779,t:1526933946463};\\\", \\\"{x:1473,y:777,t:1526933946479};\\\", \\\"{x:1474,y:776,t:1526933946496};\\\", \\\"{x:1475,y:775,t:1526933946512};\\\", \\\"{x:1475,y:774,t:1526933946529};\\\", \\\"{x:1477,y:772,t:1526933946546};\\\", \\\"{x:1477,y:771,t:1526933946562};\\\", \\\"{x:1478,y:769,t:1526933946579};\\\", \\\"{x:1478,y:767,t:1526933946597};\\\", \\\"{x:1479,y:764,t:1526933946614};\\\", \\\"{x:1479,y:762,t:1526933946637};\\\", \\\"{x:1479,y:761,t:1526933946661};\\\", \\\"{x:1479,y:759,t:1526933946694};\\\", \\\"{x:1478,y:762,t:1526933946878};\\\", \\\"{x:1472,y:768,t:1526933946886};\\\", \\\"{x:1465,y:774,t:1526933946897};\\\", \\\"{x:1451,y:781,t:1526933946913};\\\", \\\"{x:1436,y:786,t:1526933946930};\\\", \\\"{x:1424,y:788,t:1526933946947};\\\", \\\"{x:1416,y:788,t:1526933946964};\\\", \\\"{x:1412,y:788,t:1526933946980};\\\", \\\"{x:1409,y:787,t:1526933946997};\\\", \\\"{x:1403,y:784,t:1526933947013};\\\", \\\"{x:1398,y:781,t:1526933947030};\\\", \\\"{x:1392,y:775,t:1526933947047};\\\", \\\"{x:1386,y:772,t:1526933947064};\\\", \\\"{x:1384,y:771,t:1526933947081};\\\", \\\"{x:1381,y:769,t:1526933947097};\\\", \\\"{x:1379,y:768,t:1526933947114};\\\", \\\"{x:1377,y:767,t:1526933947131};\\\", \\\"{x:1376,y:766,t:1526933947147};\\\", \\\"{x:1371,y:765,t:1526933947164};\\\", \\\"{x:1363,y:763,t:1526933947181};\\\", \\\"{x:1356,y:761,t:1526933947198};\\\", \\\"{x:1351,y:760,t:1526933947213};\\\", \\\"{x:1350,y:760,t:1526933947254};\\\", \\\"{x:1348,y:759,t:1526933947270};\\\", \\\"{x:1346,y:758,t:1526933947301};\\\", \\\"{x:1345,y:758,t:1526933947313};\\\", \\\"{x:1344,y:758,t:1526933947342};\\\", \\\"{x:1345,y:758,t:1526933947518};\\\", \\\"{x:1348,y:761,t:1526933947530};\\\", \\\"{x:1355,y:766,t:1526933947548};\\\", \\\"{x:1360,y:769,t:1526933947564};\\\", \\\"{x:1366,y:773,t:1526933947581};\\\", \\\"{x:1368,y:774,t:1526933947598};\\\", \\\"{x:1373,y:776,t:1526933947614};\\\", \\\"{x:1375,y:777,t:1526933947631};\\\", \\\"{x:1378,y:777,t:1526933947648};\\\", \\\"{x:1380,y:777,t:1526933947664};\\\", \\\"{x:1383,y:777,t:1526933947681};\\\", \\\"{x:1386,y:777,t:1526933947698};\\\", \\\"{x:1389,y:777,t:1526933947715};\\\", \\\"{x:1391,y:775,t:1526933947731};\\\", \\\"{x:1392,y:773,t:1526933947748};\\\", \\\"{x:1394,y:771,t:1526933947764};\\\", \\\"{x:1395,y:769,t:1526933947781};\\\", \\\"{x:1398,y:767,t:1526933947797};\\\", \\\"{x:1400,y:766,t:1526933947814};\\\", \\\"{x:1402,y:765,t:1526933947831};\\\", \\\"{x:1404,y:763,t:1526933947848};\\\", \\\"{x:1406,y:761,t:1526933947864};\\\", \\\"{x:1406,y:760,t:1526933947881};\\\", \\\"{x:1407,y:759,t:1526933947898};\\\", \\\"{x:1408,y:758,t:1526933947918};\\\", \\\"{x:1409,y:756,t:1526933947933};\\\", \\\"{x:1409,y:755,t:1526933947949};\\\", \\\"{x:1410,y:755,t:1526933947966};\\\", \\\"{x:1411,y:753,t:1526933947981};\\\", \\\"{x:1412,y:754,t:1526933948198};\\\", \\\"{x:1416,y:760,t:1526933948215};\\\", \\\"{x:1421,y:767,t:1526933948231};\\\", \\\"{x:1425,y:773,t:1526933948247};\\\", \\\"{x:1430,y:778,t:1526933948265};\\\", \\\"{x:1434,y:784,t:1526933948281};\\\", \\\"{x:1443,y:789,t:1526933948298};\\\", \\\"{x:1449,y:792,t:1526933948314};\\\", \\\"{x:1453,y:794,t:1526933948331};\\\", \\\"{x:1461,y:795,t:1526933948347};\\\", \\\"{x:1467,y:797,t:1526933948365};\\\", \\\"{x:1469,y:797,t:1526933948380};\\\", \\\"{x:1470,y:797,t:1526933948398};\\\", \\\"{x:1470,y:796,t:1526933948421};\\\", \\\"{x:1471,y:794,t:1526933948431};\\\", \\\"{x:1472,y:791,t:1526933948448};\\\", \\\"{x:1474,y:787,t:1526933948465};\\\", \\\"{x:1476,y:781,t:1526933948481};\\\", \\\"{x:1478,y:778,t:1526933948498};\\\", \\\"{x:1478,y:775,t:1526933948515};\\\", \\\"{x:1478,y:773,t:1526933948531};\\\", \\\"{x:1478,y:771,t:1526933948548};\\\", \\\"{x:1478,y:769,t:1526933948565};\\\", \\\"{x:1478,y:766,t:1526933948581};\\\", \\\"{x:1478,y:765,t:1526933948598};\\\", \\\"{x:1478,y:764,t:1526933948614};\\\", \\\"{x:1478,y:762,t:1526933948632};\\\", \\\"{x:1480,y:762,t:1526933948830};\\\", \\\"{x:1484,y:764,t:1526933948838};\\\", \\\"{x:1489,y:768,t:1526933948847};\\\", \\\"{x:1497,y:775,t:1526933948864};\\\", \\\"{x:1509,y:783,t:1526933948881};\\\", \\\"{x:1522,y:789,t:1526933948898};\\\", \\\"{x:1528,y:790,t:1526933948915};\\\", \\\"{x:1532,y:791,t:1526933948932};\\\", \\\"{x:1534,y:791,t:1526933948948};\\\", \\\"{x:1537,y:791,t:1526933948964};\\\", \\\"{x:1540,y:791,t:1526933948981};\\\", \\\"{x:1543,y:789,t:1526933948998};\\\", \\\"{x:1547,y:787,t:1526933949014};\\\", \\\"{x:1550,y:784,t:1526933949031};\\\", \\\"{x:1553,y:780,t:1526933949049};\\\", \\\"{x:1557,y:775,t:1526933949065};\\\", \\\"{x:1557,y:772,t:1526933949081};\\\", \\\"{x:1558,y:769,t:1526933949099};\\\", \\\"{x:1558,y:767,t:1526933949115};\\\", \\\"{x:1558,y:766,t:1526933949133};\\\", \\\"{x:1558,y:764,t:1526933949165};\\\", \\\"{x:1557,y:763,t:1526933949252};\\\", \\\"{x:1556,y:763,t:1526933949284};\\\", \\\"{x:1555,y:763,t:1526933949298};\\\", \\\"{x:1554,y:763,t:1526933949314};\\\", \\\"{x:1553,y:762,t:1526933949332};\\\", \\\"{x:1552,y:762,t:1526933949348};\\\", \\\"{x:1550,y:761,t:1526933949365};\\\", \\\"{x:1549,y:761,t:1526933949405};\\\", \\\"{x:1548,y:761,t:1526933949454};\\\", \\\"{x:1544,y:761,t:1526933950166};\\\", \\\"{x:1536,y:766,t:1526933950183};\\\", \\\"{x:1524,y:770,t:1526933950199};\\\", \\\"{x:1508,y:775,t:1526933950216};\\\", \\\"{x:1495,y:778,t:1526933950233};\\\", \\\"{x:1489,y:780,t:1526933950249};\\\", \\\"{x:1486,y:780,t:1526933950265};\\\", \\\"{x:1485,y:780,t:1526933950308};\\\", \\\"{x:1484,y:780,t:1526933950316};\\\", \\\"{x:1481,y:780,t:1526933950333};\\\", \\\"{x:1477,y:780,t:1526933950349};\\\", \\\"{x:1473,y:780,t:1526933950365};\\\", \\\"{x:1468,y:780,t:1526933950383};\\\", \\\"{x:1465,y:780,t:1526933950399};\\\", \\\"{x:1463,y:780,t:1526933950416};\\\", \\\"{x:1460,y:780,t:1526933950433};\\\", \\\"{x:1459,y:780,t:1526933950460};\\\", \\\"{x:1456,y:779,t:1526933950477};\\\", \\\"{x:1455,y:779,t:1526933950526};\\\", \\\"{x:1455,y:778,t:1526933950534};\\\", \\\"{x:1454,y:777,t:1526933950550};\\\", \\\"{x:1453,y:776,t:1526933950573};\\\", \\\"{x:1452,y:776,t:1526933950583};\\\", \\\"{x:1452,y:775,t:1526933950600};\\\", \\\"{x:1452,y:774,t:1526933950616};\\\", \\\"{x:1452,y:772,t:1526933950633};\\\", \\\"{x:1451,y:770,t:1526933950650};\\\", \\\"{x:1451,y:768,t:1526933950667};\\\", \\\"{x:1451,y:767,t:1526933950683};\\\", \\\"{x:1451,y:765,t:1526933950700};\\\", \\\"{x:1451,y:763,t:1526933950716};\\\", \\\"{x:1451,y:761,t:1526933950734};\\\", \\\"{x:1451,y:760,t:1526933950749};\\\", \\\"{x:1451,y:759,t:1526933950766};\\\", \\\"{x:1451,y:758,t:1526933950814};\\\", \\\"{x:1447,y:758,t:1526933951038};\\\", \\\"{x:1444,y:758,t:1526933951050};\\\", \\\"{x:1433,y:760,t:1526933951067};\\\", \\\"{x:1426,y:762,t:1526933951084};\\\", \\\"{x:1421,y:764,t:1526933951100};\\\", \\\"{x:1417,y:764,t:1526933951117};\\\", \\\"{x:1414,y:764,t:1526933951133};\\\", \\\"{x:1412,y:764,t:1526933951150};\\\", \\\"{x:1409,y:764,t:1526933951167};\\\", \\\"{x:1404,y:764,t:1526933951183};\\\", \\\"{x:1397,y:764,t:1526933951200};\\\", \\\"{x:1386,y:764,t:1526933951217};\\\", \\\"{x:1373,y:764,t:1526933951233};\\\", \\\"{x:1364,y:764,t:1526933951250};\\\", \\\"{x:1354,y:764,t:1526933951267};\\\", \\\"{x:1348,y:764,t:1526933951284};\\\", \\\"{x:1343,y:764,t:1526933951300};\\\", \\\"{x:1338,y:764,t:1526933951318};\\\", \\\"{x:1333,y:763,t:1526933951334};\\\", \\\"{x:1330,y:763,t:1526933951350};\\\", \\\"{x:1329,y:763,t:1526933951367};\\\", \\\"{x:1328,y:763,t:1526933951390};\\\", \\\"{x:1330,y:763,t:1526933951558};\\\", \\\"{x:1333,y:763,t:1526933951567};\\\", \\\"{x:1336,y:764,t:1526933951584};\\\", \\\"{x:1339,y:765,t:1526933951600};\\\", \\\"{x:1343,y:767,t:1526933951616};\\\", \\\"{x:1347,y:770,t:1526933951633};\\\", \\\"{x:1351,y:773,t:1526933951649};\\\", \\\"{x:1354,y:777,t:1526933951666};\\\", \\\"{x:1356,y:780,t:1526933951683};\\\", \\\"{x:1360,y:782,t:1526933951699};\\\", \\\"{x:1364,y:784,t:1526933951717};\\\", \\\"{x:1365,y:784,t:1526933951733};\\\", \\\"{x:1367,y:784,t:1526933951750};\\\", \\\"{x:1369,y:785,t:1526933951766};\\\", \\\"{x:1372,y:785,t:1526933951784};\\\", \\\"{x:1375,y:785,t:1526933951800};\\\", \\\"{x:1380,y:785,t:1526933951817};\\\", \\\"{x:1384,y:784,t:1526933951834};\\\", \\\"{x:1389,y:782,t:1526933951850};\\\", \\\"{x:1394,y:779,t:1526933951867};\\\", \\\"{x:1396,y:777,t:1526933951884};\\\", \\\"{x:1397,y:776,t:1526933951902};\\\", \\\"{x:1398,y:774,t:1526933951941};\\\", \\\"{x:1399,y:774,t:1526933951951};\\\", \\\"{x:1399,y:771,t:1526933951967};\\\", \\\"{x:1401,y:767,t:1526933951985};\\\", \\\"{x:1404,y:762,t:1526933952001};\\\", \\\"{x:1406,y:759,t:1526933952017};\\\", \\\"{x:1407,y:757,t:1526933952034};\\\", \\\"{x:1407,y:755,t:1526933952051};\\\", \\\"{x:1407,y:754,t:1526933952070};\\\", \\\"{x:1407,y:752,t:1526933952084};\\\", \\\"{x:1408,y:751,t:1526933952101};\\\", \\\"{x:1409,y:750,t:1526933952117};\\\", \\\"{x:1409,y:749,t:1526933952135};\\\", \\\"{x:1410,y:749,t:1526933952470};\\\", \\\"{x:1410,y:751,t:1526933952486};\\\", \\\"{x:1411,y:752,t:1526933952502};\\\", \\\"{x:1412,y:754,t:1526933952518};\\\", \\\"{x:1412,y:756,t:1526933952534};\\\", \\\"{x:1413,y:757,t:1526933952552};\\\", \\\"{x:1414,y:759,t:1526933952568};\\\", \\\"{x:1415,y:761,t:1526933952584};\\\", \\\"{x:1416,y:763,t:1526933952602};\\\", \\\"{x:1417,y:765,t:1526933952618};\\\", \\\"{x:1418,y:766,t:1526933952634};\\\", \\\"{x:1418,y:767,t:1526933952651};\\\", \\\"{x:1420,y:768,t:1526933952668};\\\", \\\"{x:1421,y:770,t:1526933952684};\\\", \\\"{x:1423,y:772,t:1526933952701};\\\", \\\"{x:1425,y:774,t:1526933952718};\\\", \\\"{x:1426,y:775,t:1526933952734};\\\", \\\"{x:1427,y:776,t:1526933952765};\\\", \\\"{x:1428,y:777,t:1526933952781};\\\", \\\"{x:1429,y:777,t:1526933952814};\\\", \\\"{x:1429,y:778,t:1526933952821};\\\", \\\"{x:1431,y:778,t:1526933952835};\\\", \\\"{x:1432,y:779,t:1526933952852};\\\", \\\"{x:1434,y:780,t:1526933952869};\\\", \\\"{x:1438,y:780,t:1526933952885};\\\", \\\"{x:1440,y:780,t:1526933952901};\\\", \\\"{x:1444,y:780,t:1526933952918};\\\", \\\"{x:1445,y:780,t:1526933952935};\\\", \\\"{x:1448,y:780,t:1526933952951};\\\", \\\"{x:1451,y:780,t:1526933952968};\\\", \\\"{x:1453,y:780,t:1526933952985};\\\", \\\"{x:1454,y:780,t:1526933953001};\\\", \\\"{x:1459,y:780,t:1526933953019};\\\", \\\"{x:1462,y:779,t:1526933953035};\\\", \\\"{x:1466,y:777,t:1526933953051};\\\", \\\"{x:1470,y:774,t:1526933953068};\\\", \\\"{x:1475,y:771,t:1526933953085};\\\", \\\"{x:1476,y:770,t:1526933953101};\\\", \\\"{x:1477,y:770,t:1526933953118};\\\", \\\"{x:1477,y:769,t:1526933953135};\\\", \\\"{x:1478,y:768,t:1526933953152};\\\", \\\"{x:1479,y:767,t:1526933953168};\\\", \\\"{x:1479,y:765,t:1526933953190};\\\", \\\"{x:1480,y:763,t:1526933953238};\\\", \\\"{x:1481,y:761,t:1526933953302};\\\", \\\"{x:1481,y:760,t:1526933953325};\\\", \\\"{x:1482,y:759,t:1526933953374};\\\", \\\"{x:1483,y:760,t:1526933953558};\\\", \\\"{x:1485,y:763,t:1526933953568};\\\", \\\"{x:1488,y:769,t:1526933953586};\\\", \\\"{x:1491,y:773,t:1526933953602};\\\", \\\"{x:1493,y:776,t:1526933953618};\\\", \\\"{x:1494,y:778,t:1526933953635};\\\", \\\"{x:1496,y:779,t:1526933953652};\\\", \\\"{x:1498,y:782,t:1526933953668};\\\", \\\"{x:1502,y:784,t:1526933953686};\\\", \\\"{x:1505,y:785,t:1526933953702};\\\", \\\"{x:1507,y:785,t:1526933953719};\\\", \\\"{x:1513,y:786,t:1526933953735};\\\", \\\"{x:1514,y:786,t:1526933953752};\\\", \\\"{x:1519,y:786,t:1526933953769};\\\", \\\"{x:1523,y:785,t:1526933953785};\\\", \\\"{x:1524,y:785,t:1526933953802};\\\", \\\"{x:1525,y:785,t:1526933953820};\\\", \\\"{x:1526,y:784,t:1526933953836};\\\", \\\"{x:1529,y:782,t:1526933953853};\\\", \\\"{x:1533,y:780,t:1526933953870};\\\", \\\"{x:1538,y:777,t:1526933953886};\\\", \\\"{x:1543,y:774,t:1526933953902};\\\", \\\"{x:1546,y:771,t:1526933953919};\\\", \\\"{x:1549,y:768,t:1526933953935};\\\", \\\"{x:1552,y:764,t:1526933953952};\\\", \\\"{x:1554,y:762,t:1526933953969};\\\", \\\"{x:1554,y:760,t:1526933953985};\\\", \\\"{x:1554,y:759,t:1526933954002};\\\", \\\"{x:1556,y:758,t:1526933954020};\\\", \\\"{x:1556,y:757,t:1526933954102};\\\", \\\"{x:1542,y:765,t:1526933954119};\\\", \\\"{x:1522,y:775,t:1526933954135};\\\", \\\"{x:1497,y:784,t:1526933954153};\\\", \\\"{x:1475,y:789,t:1526933954170};\\\", \\\"{x:1464,y:790,t:1526933954185};\\\", \\\"{x:1460,y:790,t:1526933954202};\\\", \\\"{x:1459,y:790,t:1526933954228};\\\", \\\"{x:1457,y:789,t:1526933954236};\\\", \\\"{x:1456,y:788,t:1526933954252};\\\", \\\"{x:1454,y:785,t:1526933954269};\\\", \\\"{x:1453,y:783,t:1526933954286};\\\", \\\"{x:1453,y:779,t:1526933954302};\\\", \\\"{x:1452,y:776,t:1526933954319};\\\", \\\"{x:1452,y:774,t:1526933954335};\\\", \\\"{x:1452,y:773,t:1526933954352};\\\", \\\"{x:1452,y:771,t:1526933954368};\\\", \\\"{x:1454,y:769,t:1526933954386};\\\", \\\"{x:1459,y:767,t:1526933954402};\\\", \\\"{x:1461,y:766,t:1526933954419};\\\", \\\"{x:1464,y:764,t:1526933954436};\\\", \\\"{x:1465,y:764,t:1526933954452};\\\", \\\"{x:1466,y:763,t:1526933954469};\\\", \\\"{x:1468,y:763,t:1526933954487};\\\", \\\"{x:1470,y:762,t:1526933954517};\\\", \\\"{x:1471,y:762,t:1526933954805};\\\", \\\"{x:1472,y:763,t:1526933954829};\\\", \\\"{x:1472,y:766,t:1526933954837};\\\", \\\"{x:1472,y:770,t:1526933954853};\\\", \\\"{x:1474,y:774,t:1526933954870};\\\", \\\"{x:1474,y:777,t:1526933954887};\\\", \\\"{x:1475,y:782,t:1526933954903};\\\", \\\"{x:1478,y:788,t:1526933954919};\\\", \\\"{x:1478,y:793,t:1526933954936};\\\", \\\"{x:1478,y:796,t:1526933954953};\\\", \\\"{x:1478,y:797,t:1526933954969};\\\", \\\"{x:1479,y:798,t:1526933954986};\\\", \\\"{x:1479,y:799,t:1526933955003};\\\", \\\"{x:1480,y:800,t:1526933955019};\\\", \\\"{x:1480,y:801,t:1526933955036};\\\", \\\"{x:1480,y:804,t:1526933955053};\\\", \\\"{x:1481,y:806,t:1526933955069};\\\", \\\"{x:1481,y:810,t:1526933955087};\\\", \\\"{x:1482,y:816,t:1526933955104};\\\", \\\"{x:1482,y:821,t:1526933955119};\\\", \\\"{x:1482,y:827,t:1526933955137};\\\", \\\"{x:1482,y:830,t:1526933955153};\\\", \\\"{x:1483,y:834,t:1526933955169};\\\", \\\"{x:1483,y:835,t:1526933955186};\\\", \\\"{x:1483,y:839,t:1526933955204};\\\", \\\"{x:1483,y:843,t:1526933955220};\\\", \\\"{x:1485,y:847,t:1526933955235};\\\", \\\"{x:1486,y:852,t:1526933955253};\\\", \\\"{x:1486,y:856,t:1526933955270};\\\", \\\"{x:1486,y:859,t:1526933955285};\\\", \\\"{x:1486,y:861,t:1526933955302};\\\", \\\"{x:1486,y:863,t:1526933955320};\\\", \\\"{x:1486,y:866,t:1526933955336};\\\", \\\"{x:1486,y:867,t:1526933955353};\\\", \\\"{x:1486,y:868,t:1526933955373};\\\", \\\"{x:1486,y:866,t:1526933955574};\\\", \\\"{x:1486,y:864,t:1526933955586};\\\", \\\"{x:1480,y:851,t:1526933955604};\\\", \\\"{x:1474,y:835,t:1526933955619};\\\", \\\"{x:1466,y:819,t:1526933955636};\\\", \\\"{x:1453,y:797,t:1526933955652};\\\", \\\"{x:1443,y:785,t:1526933955670};\\\", \\\"{x:1437,y:778,t:1526933955686};\\\", \\\"{x:1429,y:776,t:1526933955702};\\\", \\\"{x:1422,y:774,t:1526933955720};\\\", \\\"{x:1408,y:773,t:1526933955737};\\\", \\\"{x:1377,y:773,t:1526933955753};\\\", \\\"{x:1319,y:773,t:1526933955770};\\\", \\\"{x:1227,y:771,t:1526933955787};\\\", \\\"{x:1112,y:763,t:1526933955803};\\\", \\\"{x:991,y:753,t:1526933955820};\\\", \\\"{x:795,y:726,t:1526933955837};\\\", \\\"{x:676,y:709,t:1526933955853};\\\", \\\"{x:568,y:693,t:1526933955870};\\\", \\\"{x:480,y:674,t:1526933955888};\\\", \\\"{x:427,y:656,t:1526933955902};\\\", \\\"{x:392,y:638,t:1526933955920};\\\", \\\"{x:372,y:629,t:1526933955938};\\\", \\\"{x:360,y:622,t:1526933955954};\\\", \\\"{x:352,y:618,t:1526933955971};\\\", \\\"{x:342,y:612,t:1526933955988};\\\", \\\"{x:332,y:606,t:1526933956003};\\\", \\\"{x:318,y:598,t:1526933956020};\\\", \\\"{x:313,y:595,t:1526933956038};\\\", \\\"{x:308,y:590,t:1526933956053};\\\", \\\"{x:302,y:580,t:1526933956071};\\\", \\\"{x:296,y:569,t:1526933956089};\\\", \\\"{x:295,y:563,t:1526933956104};\\\", \\\"{x:294,y:558,t:1526933956121};\\\", \\\"{x:294,y:554,t:1526933956137};\\\", \\\"{x:294,y:552,t:1526933956153};\\\", \\\"{x:293,y:550,t:1526933956171};\\\", \\\"{x:293,y:549,t:1526933956187};\\\", \\\"{x:292,y:548,t:1526933956204};\\\", \\\"{x:291,y:548,t:1526933956262};\\\", \\\"{x:289,y:548,t:1526933956271};\\\", \\\"{x:284,y:548,t:1526933956288};\\\", \\\"{x:270,y:548,t:1526933956306};\\\", \\\"{x:256,y:550,t:1526933956321};\\\", \\\"{x:244,y:554,t:1526933956338};\\\", \\\"{x:237,y:556,t:1526933956355};\\\", \\\"{x:232,y:558,t:1526933956371};\\\", \\\"{x:225,y:558,t:1526933956387};\\\", \\\"{x:212,y:558,t:1526933956404};\\\", \\\"{x:204,y:558,t:1526933956420};\\\", \\\"{x:197,y:558,t:1526933956437};\\\", \\\"{x:194,y:558,t:1526933956455};\\\", \\\"{x:189,y:558,t:1526933956471};\\\", \\\"{x:184,y:558,t:1526933956488};\\\", \\\"{x:178,y:557,t:1526933956505};\\\", \\\"{x:173,y:556,t:1526933956521};\\\", \\\"{x:172,y:555,t:1526933956538};\\\", \\\"{x:171,y:554,t:1526933956555};\\\", \\\"{x:168,y:554,t:1526933956572};\\\", \\\"{x:167,y:554,t:1526933956588};\\\", \\\"{x:161,y:552,t:1526933956605};\\\", \\\"{x:161,y:553,t:1526933957109};\\\", \\\"{x:170,y:564,t:1526933957122};\\\", \\\"{x:195,y:595,t:1526933957138};\\\", \\\"{x:229,y:625,t:1526933957154};\\\", \\\"{x:269,y:654,t:1526933957172};\\\", \\\"{x:312,y:680,t:1526933957188};\\\", \\\"{x:324,y:687,t:1526933957205};\\\", \\\"{x:334,y:692,t:1526933957222};\\\", \\\"{x:338,y:695,t:1526933957238};\\\", \\\"{x:341,y:696,t:1526933957255};\\\", \\\"{x:345,y:698,t:1526933957271};\\\", \\\"{x:350,y:698,t:1526933957287};\\\", \\\"{x:356,y:700,t:1526933957305};\\\", \\\"{x:366,y:704,t:1526933957322};\\\", \\\"{x:382,y:712,t:1526933957338};\\\", \\\"{x:397,y:715,t:1526933957355};\\\", \\\"{x:414,y:724,t:1526933957372};\\\", \\\"{x:427,y:726,t:1526933957389};\\\", \\\"{x:449,y:733,t:1526933957405};\\\", \\\"{x:470,y:739,t:1526933957423};\\\", \\\"{x:488,y:744,t:1526933957438};\\\", \\\"{x:506,y:746,t:1526933957454};\\\", \\\"{x:513,y:747,t:1526933957471};\\\", \\\"{x:519,y:747,t:1526933957487};\\\", \\\"{x:521,y:747,t:1526933957504};\\\", \\\"{x:522,y:747,t:1526933957522};\\\", \\\"{x:523,y:747,t:1526933957548};\\\", \\\"{x:524,y:748,t:1526933958045};\\\", \\\"{x:524,y:750,t:1526933958056};\\\", \\\"{x:523,y:751,t:1526933958072};\\\", \\\"{x:523,y:752,t:1526933958661};\\\", \\\"{x:523,y:753,t:1526933958673};\\\", \\\"{x:532,y:755,t:1526933958689};\\\", \\\"{x:541,y:759,t:1526933958706};\\\", \\\"{x:549,y:763,t:1526933958723};\\\", \\\"{x:557,y:766,t:1526933958740};\\\", \\\"{x:565,y:770,t:1526933958770};\\\", \\\"{x:566,y:770,t:1526933958773};\\\" ] }, { \\\"rt\\\": 89710, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 804068, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the x-axis and then look at the point; the x-coordinate of the point. For example, look at 12 pm on the x-axis and then follow it straight up and once you reach the points those points start at 12 pm. So for 12 pm it would be shifts B and F.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12933, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 818008, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 10591, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 829609, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 28007, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 858933, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"FJV2A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"delta\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"FJV2A\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 345, dom: 928, initialDom: 1035",
  "javascriptErrors": []
}