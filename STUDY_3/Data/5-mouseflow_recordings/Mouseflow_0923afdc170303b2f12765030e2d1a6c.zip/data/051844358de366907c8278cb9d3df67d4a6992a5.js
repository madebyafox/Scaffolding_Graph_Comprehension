var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["051844358de366907c8278cb9d3df67d4a6992a5"] = {
  "startTime": "2018-05-18T18:28:44.177384Z",
  "websitePageUrl": "/15",
  "visitTime": 70994,
  "engagementTime": 69979,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "0923afdc170303b2f12765030e2d1a6c",
    "created": "2018-05-18T18:28:44.177384+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=FA0KM",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "cfae1f6bb244eb4faa77f9e21a6cc092",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0923afdc170303b2f12765030e2d1a6c/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 212,
      "e": 212,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 533,
      "y": 726
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 50789,
      "y": 16322,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 4254,
      "e": 4254,
      "ty": 41,
      "x": 55002,
      "y": 14356,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 4304,
      "e": 4304,
      "ty": 2,
      "x": 818,
      "y": 661
    },
    {
      "t": 4404,
      "e": 4404,
      "ty": 2,
      "x": 1433,
      "y": 698
    },
    {
      "t": 4503,
      "e": 4503,
      "ty": 2,
      "x": 1650,
      "y": 853
    },
    {
      "t": 4505,
      "e": 4505,
      "ty": 41,
      "x": 47142,
      "y": 51210,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4604,
      "e": 4604,
      "ty": 2,
      "x": 1734,
      "y": 983
    },
    {
      "t": 4704,
      "e": 4704,
      "ty": 2,
      "x": 1730,
      "y": 991
    },
    {
      "t": 4754,
      "e": 4754,
      "ty": 41,
      "x": 52075,
      "y": 61738,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4803,
      "e": 4803,
      "ty": 2,
      "x": 1695,
      "y": 1016
    },
    {
      "t": 4904,
      "e": 4904,
      "ty": 2,
      "x": 1569,
      "y": 1028
    },
    {
      "t": 5003,
      "e": 5003,
      "ty": 2,
      "x": 1533,
      "y": 1028
    },
    {
      "t": 5005,
      "e": 5005,
      "ty": 41,
      "x": 46477,
      "y": 3276,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 5103,
      "e": 5103,
      "ty": 2,
      "x": 1528,
      "y": 1022
    },
    {
      "t": 5203,
      "e": 5203,
      "ty": 2,
      "x": 1525,
      "y": 1019
    },
    {
      "t": 5254,
      "e": 5254,
      "ty": 41,
      "x": 37841,
      "y": 62884,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5303,
      "e": 5303,
      "ty": 2,
      "x": 1511,
      "y": 1011
    },
    {
      "t": 5404,
      "e": 5404,
      "ty": 2,
      "x": 1485,
      "y": 996
    },
    {
      "t": 5504,
      "e": 5504,
      "ty": 2,
      "x": 1477,
      "y": 989
    },
    {
      "t": 5504,
      "e": 5504,
      "ty": 41,
      "x": 25464,
      "y": 37119,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 5603,
      "e": 5603,
      "ty": 2,
      "x": 1474,
      "y": 979
    },
    {
      "t": 5703,
      "e": 5703,
      "ty": 2,
      "x": 1475,
      "y": 964
    },
    {
      "t": 5755,
      "e": 5755,
      "ty": 41,
      "x": 34952,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5803,
      "e": 5803,
      "ty": 2,
      "x": 1480,
      "y": 933
    },
    {
      "t": 5904,
      "e": 5904,
      "ty": 2,
      "x": 1486,
      "y": 889
    },
    {
      "t": 6004,
      "e": 6004,
      "ty": 2,
      "x": 1488,
      "y": 866
    },
    {
      "t": 6004,
      "e": 6004,
      "ty": 41,
      "x": 35727,
      "y": 52141,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6104,
      "e": 6104,
      "ty": 2,
      "x": 1489,
      "y": 857
    },
    {
      "t": 6204,
      "e": 6204,
      "ty": 2,
      "x": 1484,
      "y": 836
    },
    {
      "t": 6254,
      "e": 6254,
      "ty": 41,
      "x": 38228,
      "y": 29126,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[18] > circle"
    },
    {
      "t": 6304,
      "e": 6304,
      "ty": 2,
      "x": 1480,
      "y": 823
    },
    {
      "t": 6404,
      "e": 6404,
      "ty": 2,
      "x": 1478,
      "y": 821
    },
    {
      "t": 6504,
      "e": 6504,
      "ty": 41,
      "x": 19660,
      "y": 48419,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[18] > text"
    },
    {
      "t": 6904,
      "e": 6904,
      "ty": 2,
      "x": 1480,
      "y": 823
    },
    {
      "t": 7004,
      "e": 7004,
      "ty": 2,
      "x": 1490,
      "y": 878
    },
    {
      "t": 7004,
      "e": 7004,
      "ty": 41,
      "x": 35868,
      "y": 53000,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7103,
      "e": 7103,
      "ty": 2,
      "x": 1494,
      "y": 912
    },
    {
      "t": 7204,
      "e": 7204,
      "ty": 2,
      "x": 1499,
      "y": 945
    },
    {
      "t": 7254,
      "e": 7254,
      "ty": 41,
      "x": 36502,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7303,
      "e": 7303,
      "ty": 2,
      "x": 1496,
      "y": 960
    },
    {
      "t": 7404,
      "e": 7404,
      "ty": 2,
      "x": 1490,
      "y": 976
    },
    {
      "t": 7504,
      "e": 7504,
      "ty": 2,
      "x": 1483,
      "y": 982
    },
    {
      "t": 7504,
      "e": 7504,
      "ty": 41,
      "x": 35184,
      "y": 8447,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 7704,
      "e": 7704,
      "ty": 2,
      "x": 1494,
      "y": 943
    },
    {
      "t": 7755,
      "e": 7755,
      "ty": 41,
      "x": 36854,
      "y": 54934,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7804,
      "e": 7804,
      "ty": 2,
      "x": 1529,
      "y": 863
    },
    {
      "t": 7904,
      "e": 7904,
      "ty": 2,
      "x": 1563,
      "y": 796
    },
    {
      "t": 8004,
      "e": 8004,
      "ty": 2,
      "x": 1583,
      "y": 724
    },
    {
      "t": 8004,
      "e": 8004,
      "ty": 41,
      "x": 42421,
      "y": 41971,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8104,
      "e": 8104,
      "ty": 2,
      "x": 1588,
      "y": 697
    },
    {
      "t": 8203,
      "e": 8203,
      "ty": 2,
      "x": 1591,
      "y": 695
    },
    {
      "t": 8254,
      "e": 8254,
      "ty": 41,
      "x": 43267,
      "y": 39822,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8303,
      "e": 8303,
      "ty": 2,
      "x": 1597,
      "y": 693
    },
    {
      "t": 8404,
      "e": 8404,
      "ty": 2,
      "x": 1600,
      "y": 693
    },
    {
      "t": 8503,
      "e": 8503,
      "ty": 2,
      "x": 1600,
      "y": 692
    },
    {
      "t": 8503,
      "e": 8503,
      "ty": 41,
      "x": 43619,
      "y": 39679,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9004,
      "e": 9004,
      "ty": 2,
      "x": 1620,
      "y": 684
    },
    {
      "t": 9004,
      "e": 9004,
      "ty": 41,
      "x": 45546,
      "y": 19824,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[13]"
    },
    {
      "t": 9103,
      "e": 9103,
      "ty": 2,
      "x": 1621,
      "y": 683
    },
    {
      "t": 9254,
      "e": 9254,
      "ty": 41,
      "x": 45874,
      "y": 19660,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[13]"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10203,
      "e": 10203,
      "ty": 2,
      "x": 1604,
      "y": 688
    },
    {
      "t": 10266,
      "e": 10266,
      "ty": 41,
      "x": 41435,
      "y": 40538,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10304,
      "e": 10304,
      "ty": 2,
      "x": 1552,
      "y": 709
    },
    {
      "t": 10404,
      "e": 10404,
      "ty": 2,
      "x": 1421,
      "y": 718
    },
    {
      "t": 10504,
      "e": 10504,
      "ty": 2,
      "x": 1312,
      "y": 713
    },
    {
      "t": 10505,
      "e": 10505,
      "ty": 41,
      "x": 23324,
      "y": 41183,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10604,
      "e": 10604,
      "ty": 2,
      "x": 1300,
      "y": 709
    },
    {
      "t": 10704,
      "e": 10704,
      "ty": 2,
      "x": 1299,
      "y": 708
    },
    {
      "t": 10755,
      "e": 10755,
      "ty": 41,
      "x": 22408,
      "y": 40825,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11603,
      "e": 11603,
      "ty": 2,
      "x": 1309,
      "y": 703
    },
    {
      "t": 11704,
      "e": 11704,
      "ty": 2,
      "x": 1324,
      "y": 696
    },
    {
      "t": 11754,
      "e": 11754,
      "ty": 41,
      "x": 11007,
      "y": 45274,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[6] > text"
    },
    {
      "t": 11804,
      "e": 11804,
      "ty": 2,
      "x": 1373,
      "y": 682
    },
    {
      "t": 11904,
      "e": 11904,
      "ty": 2,
      "x": 1468,
      "y": 692
    },
    {
      "t": 12003,
      "e": 12003,
      "ty": 2,
      "x": 1600,
      "y": 776
    },
    {
      "t": 12004,
      "e": 12004,
      "ty": 41,
      "x": 43619,
      "y": 45695,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12104,
      "e": 12104,
      "ty": 2,
      "x": 1617,
      "y": 801
    },
    {
      "t": 12204,
      "e": 12204,
      "ty": 2,
      "x": 1617,
      "y": 812
    },
    {
      "t": 12255,
      "e": 12255,
      "ty": 41,
      "x": 44817,
      "y": 48273,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12504,
      "e": 12504,
      "ty": 2,
      "x": 1600,
      "y": 834
    },
    {
      "t": 12504,
      "e": 12504,
      "ty": 41,
      "x": 43619,
      "y": 49849,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12604,
      "e": 12604,
      "ty": 2,
      "x": 1537,
      "y": 923
    },
    {
      "t": 12704,
      "e": 12704,
      "ty": 2,
      "x": 1491,
      "y": 976
    },
    {
      "t": 12754,
      "e": 12754,
      "ty": 41,
      "x": 35868,
      "y": 60163,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12804,
      "e": 12804,
      "ty": 2,
      "x": 1490,
      "y": 978
    },
    {
      "t": 14204,
      "e": 14204,
      "ty": 2,
      "x": 1489,
      "y": 978
    },
    {
      "t": 14254,
      "e": 14254,
      "ty": 41,
      "x": 35797,
      "y": 60163,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 19704,
      "e": 19254,
      "ty": 2,
      "x": 1336,
      "y": 959
    },
    {
      "t": 19755,
      "e": 19305,
      "ty": 41,
      "x": 55499,
      "y": 45758,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 19804,
      "e": 19354,
      "ty": 2,
      "x": 501,
      "y": 727
    },
    {
      "t": 19836,
      "e": 19386,
      "ty": 6,
      "x": 408,
      "y": 667,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 19851,
      "e": 19401,
      "ty": 7,
      "x": 389,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 19851,
      "e": 19401,
      "ty": 6,
      "x": 389,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 19884,
      "e": 19434,
      "ty": 7,
      "x": 375,
      "y": 595,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 19884,
      "e": 19434,
      "ty": 6,
      "x": 375,
      "y": 595,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 19902,
      "e": 19452,
      "ty": 7,
      "x": 375,
      "y": 573,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 19904,
      "e": 19454,
      "ty": 2,
      "x": 375,
      "y": 573
    },
    {
      "t": 19918,
      "e": 19468,
      "ty": 6,
      "x": 378,
      "y": 551,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 19935,
      "e": 19485,
      "ty": 7,
      "x": 386,
      "y": 529,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 19935,
      "e": 19485,
      "ty": 6,
      "x": 386,
      "y": 529,
      "ta": "#bigset.midpoint > ul > li:[2]"
    },
    {
      "t": 19967,
      "e": 19517,
      "ty": 7,
      "x": 406,
      "y": 493,
      "ta": "#bigset.midpoint > ul > li:[2]"
    },
    {
      "t": 20004,
      "e": 19554,
      "ty": 2,
      "x": 427,
      "y": 474
    },
    {
      "t": 20004,
      "e": 19554,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20005,
      "e": 19555,
      "ty": 41,
      "x": 28221,
      "y": 54892,
      "ta": "#bigset.midpoint > p"
    },
    {
      "t": 20104,
      "e": 19654,
      "ty": 2,
      "x": 513,
      "y": 463
    },
    {
      "t": 20152,
      "e": 19702,
      "ty": 6,
      "x": 563,
      "y": 513,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 20168,
      "e": 19718,
      "ty": 7,
      "x": 592,
      "y": 542,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 20169,
      "e": 19719,
      "ty": 6,
      "x": 592,
      "y": 542,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 20185,
      "e": 19735,
      "ty": 7,
      "x": 626,
      "y": 570,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 20202,
      "e": 19752,
      "ty": 6,
      "x": 650,
      "y": 590,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 20203,
      "e": 19753,
      "ty": 2,
      "x": 650,
      "y": 590
    },
    {
      "t": 20254,
      "e": 19804,
      "ty": 41,
      "x": 51654,
      "y": 47854,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 20304,
      "e": 19854,
      "ty": 2,
      "x": 687,
      "y": 595
    },
    {
      "t": 20404,
      "e": 19954,
      "ty": 2,
      "x": 707,
      "y": 586
    },
    {
      "t": 20436,
      "e": 19986,
      "ty": 7,
      "x": 746,
      "y": 605,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 20437,
      "e": 19987,
      "ty": 6,
      "x": 746,
      "y": 605,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 20451,
      "e": 20001,
      "ty": 7,
      "x": 764,
      "y": 617,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 20451,
      "e": 20001,
      "ty": 6,
      "x": 764,
      "y": 617,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 20486,
      "e": 20036,
      "ty": 7,
      "x": 800,
      "y": 647,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 20504,
      "e": 20054,
      "ty": 2,
      "x": 821,
      "y": 662
    },
    {
      "t": 20505,
      "e": 20055,
      "ty": 41,
      "x": 54758,
      "y": 57084,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 20605,
      "e": 20155,
      "ty": 2,
      "x": 851,
      "y": 688
    },
    {
      "t": 20703,
      "e": 20253,
      "ty": 2,
      "x": 863,
      "y": 680
    },
    {
      "t": 20755,
      "e": 20305,
      "ty": 41,
      "x": 57654,
      "y": 60110,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 20804,
      "e": 20354,
      "ty": 2,
      "x": 864,
      "y": 667
    },
    {
      "t": 20886,
      "e": 20436,
      "ty": 6,
      "x": 864,
      "y": 644,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 20905,
      "e": 20455,
      "ty": 2,
      "x": 864,
      "y": 644
    },
    {
      "t": 20996,
      "e": 20546,
      "ty": 3,
      "x": 864,
      "y": 644,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 21004,
      "e": 20554,
      "ty": 41,
      "x": 40443,
      "y": 63145,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 21103,
      "e": 20653,
      "ty": 2,
      "x": 864,
      "y": 643
    },
    {
      "t": 21133,
      "e": 20683,
      "ty": 4,
      "x": 40443,
      "y": 56592,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 21203,
      "e": 20753,
      "ty": 2,
      "x": 864,
      "y": 626
    },
    {
      "t": 21252,
      "e": 20802,
      "ty": 7,
      "x": 860,
      "y": 603,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 21252,
      "e": 20802,
      "ty": 6,
      "x": 860,
      "y": 603,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 21254,
      "e": 20804,
      "ty": 41,
      "x": 39281,
      "y": 56592,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 21303,
      "e": 20853,
      "ty": 7,
      "x": 852,
      "y": 560,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 21303,
      "e": 20853,
      "ty": 6,
      "x": 852,
      "y": 560,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 21303,
      "e": 20853,
      "ty": 2,
      "x": 852,
      "y": 560
    },
    {
      "t": 21336,
      "e": 20886,
      "ty": 7,
      "x": 847,
      "y": 523,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 21336,
      "e": 20886,
      "ty": 6,
      "x": 847,
      "y": 523,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 21405,
      "e": 20955,
      "ty": 2,
      "x": 844,
      "y": 503
    },
    {
      "t": 21504,
      "e": 21054,
      "ty": 41,
      "x": 34633,
      "y": 4164,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 21580,
      "e": 21130,
      "ty": 3,
      "x": 844,
      "y": 503,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 21692,
      "e": 21242,
      "ty": 4,
      "x": 34633,
      "y": 4164,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 21754,
      "e": 21304,
      "ty": 41,
      "x": 47615,
      "y": 32460,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 21770,
      "e": 21320,
      "ty": 7,
      "x": 841,
      "y": 532,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 21786,
      "e": 21336,
      "ty": 6,
      "x": 841,
      "y": 547,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 21804,
      "e": 21354,
      "ty": 2,
      "x": 840,
      "y": 561
    },
    {
      "t": 21820,
      "e": 21370,
      "ty": 7,
      "x": 838,
      "y": 570,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 21836,
      "e": 21386,
      "ty": 6,
      "x": 838,
      "y": 581,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 21870,
      "e": 21420,
      "ty": 7,
      "x": 838,
      "y": 624,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 21870,
      "e": 21420,
      "ty": 6,
      "x": 838,
      "y": 624,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 21903,
      "e": 21453,
      "ty": 2,
      "x": 838,
      "y": 635
    },
    {
      "t": 22003,
      "e": 21553,
      "ty": 2,
      "x": 838,
      "y": 636
    },
    {
      "t": 22003,
      "e": 21553,
      "ty": 41,
      "x": 37785,
      "y": 48844,
      "ta": "#bigset.midpoint > ul > li:[16] > label > div"
    },
    {
      "t": 22103,
      "e": 21653,
      "ty": 2,
      "x": 838,
      "y": 637
    },
    {
      "t": 22134,
      "e": 21684,
      "ty": 3,
      "x": 838,
      "y": 637,
      "ta": "#bigset.midpoint > ul > li:[16] > label > div"
    },
    {
      "t": 22253,
      "e": 21803,
      "ty": 41,
      "x": 37785,
      "y": 52120,
      "ta": "#bigset.midpoint > ul > li:[16] > label > div"
    },
    {
      "t": 22261,
      "e": 21811,
      "ty": 4,
      "x": 37785,
      "y": 52120,
      "ta": "#bigset.midpoint > ul > li:[16] > label > div"
    },
    {
      "t": 22263,
      "e": 21813,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[16] > label > input"
    },
    {
      "t": 22272,
      "e": 21822,
      "ty": 5,
      "x": 838,
      "y": 637,
      "ta": "#bigset.midpoint > ul > li:[16] > label > input"
    },
    {
      "t": 22273,
      "e": 21823,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[16] > label > input",
      "v": "Z"
    },
    {
      "t": 22303,
      "e": 21853,
      "ty": 2,
      "x": 838,
      "y": 623
    },
    {
      "t": 22319,
      "e": 21869,
      "ty": 7,
      "x": 839,
      "y": 603,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 22320,
      "e": 21870,
      "ty": 6,
      "x": 839,
      "y": 603,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 22353,
      "e": 21903,
      "ty": 7,
      "x": 844,
      "y": 564,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 22353,
      "e": 21903,
      "ty": 6,
      "x": 844,
      "y": 564,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 22386,
      "e": 21936,
      "ty": 7,
      "x": 844,
      "y": 528,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 22387,
      "e": 21937,
      "ty": 6,
      "x": 844,
      "y": 528,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 22404,
      "e": 21954,
      "ty": 2,
      "x": 843,
      "y": 518
    },
    {
      "t": 22503,
      "e": 22053,
      "ty": 2,
      "x": 843,
      "y": 511
    },
    {
      "t": 22504,
      "e": 22054,
      "ty": 41,
      "x": 54168,
      "y": 12799,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 22604,
      "e": 22154,
      "ty": 2,
      "x": 839,
      "y": 510
    },
    {
      "t": 22645,
      "e": 22195,
      "ty": 3,
      "x": 839,
      "y": 510,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 22647,
      "e": 22197,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[16] > label > input"
    },
    {
      "t": 22748,
      "e": 22298,
      "ty": 4,
      "x": 41061,
      "y": 9523,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 22748,
      "e": 22298,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 22752,
      "e": 22302,
      "ty": 5,
      "x": 839,
      "y": 510,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 22752,
      "e": 22302,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input",
      "v": "F"
    },
    {
      "t": 22754,
      "e": 22304,
      "ty": 41,
      "x": 41061,
      "y": 9523,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 22837,
      "e": 22387,
      "ty": 7,
      "x": 813,
      "y": 538,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 22871,
      "e": 22421,
      "ty": 6,
      "x": 754,
      "y": 615,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 22887,
      "e": 22421,
      "ty": 7,
      "x": 709,
      "y": 664,
      "ta": "#bigset.midpoint > ul > li:[16]"
    },
    {
      "t": 22903,
      "e": 22437,
      "ty": 2,
      "x": 709,
      "y": 664
    },
    {
      "t": 23004,
      "e": 22538,
      "ty": 2,
      "x": 484,
      "y": 893
    },
    {
      "t": 23004,
      "e": 22538,
      "ty": 41,
      "x": 32060,
      "y": 49026,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 23104,
      "e": 22638,
      "ty": 2,
      "x": 481,
      "y": 886
    },
    {
      "t": 23203,
      "e": 22737,
      "ty": 2,
      "x": 478,
      "y": 844
    },
    {
      "t": 23253,
      "e": 22787,
      "ty": 41,
      "x": 31723,
      "y": 44594,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 23303,
      "e": 22837,
      "ty": 2,
      "x": 486,
      "y": 787
    },
    {
      "t": 23339,
      "e": 22873,
      "ty": 6,
      "x": 500,
      "y": 763,
      "ta": "#start"
    },
    {
      "t": 23403,
      "e": 22937,
      "ty": 2,
      "x": 505,
      "y": 754
    },
    {
      "t": 23477,
      "e": 23011,
      "ty": 3,
      "x": 506,
      "y": 753,
      "ta": "#start"
    },
    {
      "t": 23479,
      "e": 23013,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 23479,
      "e": 23013,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23503,
      "e": 23037,
      "ty": 2,
      "x": 506,
      "y": 753
    },
    {
      "t": 23504,
      "e": 23038,
      "ty": 41,
      "x": 33586,
      "y": 36441,
      "ta": "#start"
    },
    {
      "t": 23580,
      "e": 23114,
      "ty": 4,
      "x": 34132,
      "y": 36441,
      "ta": "#start"
    },
    {
      "t": 23590,
      "e": 23124,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23592,
      "e": 23126,
      "ty": 5,
      "x": 507,
      "y": 753,
      "ta": "#start"
    },
    {
      "t": 23601,
      "e": 23135,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 23604,
      "e": 23138,
      "ty": 2,
      "x": 507,
      "y": 753
    },
    {
      "t": 23754,
      "e": 23288,
      "ty": 41,
      "x": 17184,
      "y": 41270,
      "ta": "html > body"
    },
    {
      "t": 24404,
      "e": 23938,
      "ty": 2,
      "x": 504,
      "y": 754
    },
    {
      "t": 24504,
      "e": 24038,
      "ty": 2,
      "x": 503,
      "y": 754
    },
    {
      "t": 24504,
      "e": 24038,
      "ty": 41,
      "x": 17046,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 24599,
      "e": 24133,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 25704,
      "e": 25238,
      "ty": 2,
      "x": 590,
      "y": 717
    },
    {
      "t": 25754,
      "e": 25288,
      "ty": 41,
      "x": 22522,
      "y": 37559,
      "ta": "html > body"
    },
    {
      "t": 25803,
      "e": 25337,
      "ty": 2,
      "x": 731,
      "y": 666
    },
    {
      "t": 25903,
      "e": 25437,
      "ty": 2,
      "x": 794,
      "y": 645
    },
    {
      "t": 26004,
      "e": 25538,
      "ty": 2,
      "x": 822,
      "y": 614
    },
    {
      "t": 26004,
      "e": 25538,
      "ty": 41,
      "x": 3028,
      "y": 30426,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 26104,
      "e": 25638,
      "ty": 2,
      "x": 955,
      "y": 493
    },
    {
      "t": 26203,
      "e": 25737,
      "ty": 2,
      "x": 959,
      "y": 490
    },
    {
      "t": 26253,
      "e": 25787,
      "ty": 41,
      "x": 32659,
      "y": 5637,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26304,
      "e": 25838,
      "ty": 2,
      "x": 953,
      "y": 536
    },
    {
      "t": 26307,
      "e": 25841,
      "ty": 6,
      "x": 948,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26340,
      "e": 25874,
      "ty": 7,
      "x": 943,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26403,
      "e": 25937,
      "ty": 2,
      "x": 941,
      "y": 587
    },
    {
      "t": 26503,
      "e": 26037,
      "ty": 41,
      "x": 28766,
      "y": 2818,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 26704,
      "e": 26238,
      "ty": 2,
      "x": 951,
      "y": 581
    },
    {
      "t": 26754,
      "e": 26288,
      "ty": 41,
      "x": 31361,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26765,
      "e": 26299,
      "ty": 3,
      "x": 953,
      "y": 580,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26804,
      "e": 26338,
      "ty": 2,
      "x": 953,
      "y": 580
    },
    {
      "t": 26933,
      "e": 26467,
      "ty": 4,
      "x": 31361,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26934,
      "e": 26468,
      "ty": 5,
      "x": 953,
      "y": 580,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 27091,
      "e": 26625,
      "ty": 6,
      "x": 961,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27104,
      "e": 26638,
      "ty": 2,
      "x": 961,
      "y": 574
    },
    {
      "t": 27204,
      "e": 26738,
      "ty": 2,
      "x": 963,
      "y": 571
    },
    {
      "t": 27213,
      "e": 26747,
      "ty": 3,
      "x": 963,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27214,
      "e": 26748,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27254,
      "e": 26788,
      "ty": 41,
      "x": 33524,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27397,
      "e": 26931,
      "ty": 4,
      "x": 33524,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27397,
      "e": 26931,
      "ty": 5,
      "x": 963,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27704,
      "e": 27238,
      "ty": 2,
      "x": 961,
      "y": 570
    },
    {
      "t": 27753,
      "e": 27287,
      "ty": 41,
      "x": 33091,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28035,
      "e": 27569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 28035,
      "e": 27569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28203,
      "e": 27737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 28204,
      "e": 27738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28242,
      "e": 27776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 28314,
      "e": 27848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 28903,
      "e": 28437,
      "ty": 2,
      "x": 955,
      "y": 570
    },
    {
      "t": 28925,
      "e": 28459,
      "ty": 7,
      "x": 932,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29004,
      "e": 28538,
      "ty": 2,
      "x": 962,
      "y": 609
    },
    {
      "t": 29004,
      "e": 28538,
      "ty": 41,
      "x": 33308,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 29104,
      "e": 28638,
      "ty": 2,
      "x": 988,
      "y": 624
    },
    {
      "t": 29203,
      "e": 28737,
      "ty": 2,
      "x": 992,
      "y": 632
    },
    {
      "t": 29254,
      "e": 28788,
      "ty": 41,
      "x": 41094,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 29259,
      "e": 28793,
      "ty": 6,
      "x": 999,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29303,
      "e": 28837,
      "ty": 2,
      "x": 1000,
      "y": 649
    },
    {
      "t": 29404,
      "e": 28938,
      "ty": 2,
      "x": 1001,
      "y": 649
    },
    {
      "t": 29504,
      "e": 29038,
      "ty": 41,
      "x": 41743,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29597,
      "e": 29131,
      "ty": 3,
      "x": 1001,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29598,
      "e": 29132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 29599,
      "e": 29133,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29600,
      "e": 29134,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29741,
      "e": 29275,
      "ty": 4,
      "x": 41743,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29741,
      "e": 29275,
      "ty": 5,
      "x": 1001,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30004,
      "e": 29538,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30842,
      "e": 30376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "66"
    },
    {
      "t": 30843,
      "e": 30377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30979,
      "e": 30513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "b"
    },
    {
      "t": 31276,
      "e": 30810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 31394,
      "e": 30928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 31474,
      "e": 31008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "86"
    },
    {
      "t": 31476,
      "e": 31010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31605,
      "e": 31139,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "v"
    },
    {
      "t": 31642,
      "e": 31176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 31643,
      "e": 31177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31657,
      "e": 31191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "vi"
    },
    {
      "t": 31754,
      "e": 31288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "vi"
    },
    {
      "t": 31802,
      "e": 31336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 31802,
      "e": 31336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31883,
      "e": 31417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 31883,
      "e": 31417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31978,
      "e": 31512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "viet"
    },
    {
      "t": 32058,
      "e": 31592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 32259,
      "e": 31793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 32259,
      "e": 31793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32346,
      "e": 31880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 32410,
      "e": 31944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 32410,
      "e": 31944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32514,
      "e": 32048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 32515,
      "e": 32049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32530,
      "e": 32064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||am"
    },
    {
      "t": 32594,
      "e": 32128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 33804,
      "e": 33338,
      "ty": 2,
      "x": 1006,
      "y": 665
    },
    {
      "t": 33813,
      "e": 33347,
      "ty": 7,
      "x": 1006,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33847,
      "e": 33381,
      "ty": 6,
      "x": 1006,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33903,
      "e": 33437,
      "ty": 2,
      "x": 1003,
      "y": 688
    },
    {
      "t": 34004,
      "e": 33538,
      "ty": 2,
      "x": 1000,
      "y": 689
    },
    {
      "t": 34004,
      "e": 33538,
      "ty": 41,
      "x": 53640,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34103,
      "e": 33637,
      "ty": 2,
      "x": 987,
      "y": 698
    },
    {
      "t": 34204,
      "e": 33738,
      "ty": 2,
      "x": 987,
      "y": 699
    },
    {
      "t": 34254,
      "e": 33788,
      "ty": 41,
      "x": 46940,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34581,
      "e": 34115,
      "ty": 3,
      "x": 987,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34582,
      "e": 34116,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "vietnam"
    },
    {
      "t": 34583,
      "e": 34117,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34583,
      "e": 34117,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34692,
      "e": 34226,
      "ty": 4,
      "x": 46940,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34693,
      "e": 34227,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34693,
      "e": 34227,
      "ty": 5,
      "x": 987,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34693,
      "e": 34227,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 35004,
      "e": 34538,
      "ty": 2,
      "x": 987,
      "y": 738
    },
    {
      "t": 35004,
      "e": 34538,
      "ty": 41,
      "x": 33714,
      "y": 40440,
      "ta": "html > body"
    },
    {
      "t": 35104,
      "e": 34638,
      "ty": 2,
      "x": 989,
      "y": 813
    },
    {
      "t": 35204,
      "e": 34738,
      "ty": 2,
      "x": 995,
      "y": 854
    },
    {
      "t": 35254,
      "e": 34788,
      "ty": 41,
      "x": 34093,
      "y": 47309,
      "ta": "html > body"
    },
    {
      "t": 35304,
      "e": 34838,
      "ty": 2,
      "x": 998,
      "y": 864
    },
    {
      "t": 35504,
      "e": 35038,
      "ty": 41,
      "x": 34093,
      "y": 47420,
      "ta": "html > body"
    },
    {
      "t": 35708,
      "e": 35242,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 40004,
      "e": 39538,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40204,
      "e": 39738,
      "ty": 2,
      "x": 1223,
      "y": 335
    },
    {
      "t": 40254,
      "e": 39788,
      "ty": 41,
      "x": 58750,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 40304,
      "e": 39838,
      "ty": 2,
      "x": 1332,
      "y": 0
    },
    {
      "t": 40404,
      "e": 39938,
      "ty": 2,
      "x": 940,
      "y": 2
    },
    {
      "t": 40504,
      "e": 40038,
      "ty": 2,
      "x": 898,
      "y": 268
    },
    {
      "t": 40504,
      "e": 40038,
      "ty": 41,
      "x": 58323,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 40604,
      "e": 40138,
      "ty": 2,
      "x": 862,
      "y": 501
    },
    {
      "t": 40704,
      "e": 40238,
      "ty": 2,
      "x": 855,
      "y": 473
    },
    {
      "t": 40753,
      "e": 40287,
      "ty": 41,
      "x": 49841,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 40804,
      "e": 40338,
      "ty": 2,
      "x": 885,
      "y": 349
    },
    {
      "t": 40905,
      "e": 40439,
      "ty": 2,
      "x": 892,
      "y": 265
    },
    {
      "t": 41004,
      "e": 40538,
      "ty": 2,
      "x": 868,
      "y": 263
    },
    {
      "t": 41004,
      "e": 40538,
      "ty": 41,
      "x": 35474,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 41104,
      "e": 40638,
      "ty": 2,
      "x": 865,
      "y": 264
    },
    {
      "t": 41254,
      "e": 40788,
      "ty": 41,
      "x": 11528,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 41304,
      "e": 40838,
      "ty": 2,
      "x": 877,
      "y": 243
    },
    {
      "t": 41404,
      "e": 40938,
      "ty": 2,
      "x": 878,
      "y": 242
    },
    {
      "t": 41504,
      "e": 41038,
      "ty": 2,
      "x": 880,
      "y": 239
    },
    {
      "t": 41505,
      "e": 41039,
      "ty": 41,
      "x": 47967,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 41604,
      "e": 41138,
      "ty": 2,
      "x": 890,
      "y": 233
    },
    {
      "t": 41754,
      "e": 41288,
      "ty": 41,
      "x": 56156,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 41870,
      "e": 41404,
      "ty": 3,
      "x": 890,
      "y": 233,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 42012,
      "e": 41546,
      "ty": 4,
      "x": 56156,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 42013,
      "e": 41547,
      "ty": 5,
      "x": 890,
      "y": 233,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 42014,
      "e": 41548,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42016,
      "e": 41550,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 42254,
      "e": 41788,
      "ty": 41,
      "x": 58613,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 42305,
      "e": 41839,
      "ty": 2,
      "x": 902,
      "y": 268
    },
    {
      "t": 42404,
      "e": 41938,
      "ty": 2,
      "x": 914,
      "y": 299
    },
    {
      "t": 42505,
      "e": 42039,
      "ty": 2,
      "x": 917,
      "y": 307
    },
    {
      "t": 42505,
      "e": 42039,
      "ty": 41,
      "x": 22683,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 42604,
      "e": 42138,
      "ty": 2,
      "x": 917,
      "y": 308
    },
    {
      "t": 42755,
      "e": 42289,
      "ty": 41,
      "x": 22683,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 43304,
      "e": 42838,
      "ty": 2,
      "x": 910,
      "y": 309
    },
    {
      "t": 43403,
      "e": 42937,
      "ty": 2,
      "x": 895,
      "y": 301
    },
    {
      "t": 43505,
      "e": 43039,
      "ty": 2,
      "x": 892,
      "y": 282
    },
    {
      "t": 43505,
      "e": 43039,
      "ty": 41,
      "x": 16749,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 43604,
      "e": 43138,
      "ty": 2,
      "x": 892,
      "y": 280
    },
    {
      "t": 43704,
      "e": 43238,
      "ty": 2,
      "x": 871,
      "y": 289
    },
    {
      "t": 43755,
      "e": 43289,
      "ty": 41,
      "x": 14284,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 43806,
      "e": 43340,
      "ty": 2,
      "x": 864,
      "y": 314
    },
    {
      "t": 43905,
      "e": 43439,
      "ty": 2,
      "x": 863,
      "y": 315
    },
    {
      "t": 43932,
      "e": 43466,
      "ty": 3,
      "x": 863,
      "y": 315,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 43933,
      "e": 43467,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44004,
      "e": 43538,
      "ty": 41,
      "x": 41275,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 44053,
      "e": 43587,
      "ty": 4,
      "x": 41275,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 44053,
      "e": 43587,
      "ty": 5,
      "x": 863,
      "y": 315,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 44054,
      "e": 43588,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 44056,
      "e": 43590,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 44604,
      "e": 43590,
      "ty": 2,
      "x": 864,
      "y": 320
    },
    {
      "t": 44704,
      "e": 43690,
      "ty": 2,
      "x": 868,
      "y": 331
    },
    {
      "t": 44753,
      "e": 43739,
      "ty": 41,
      "x": 15325,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 44804,
      "e": 43790,
      "ty": 2,
      "x": 907,
      "y": 388
    },
    {
      "t": 44903,
      "e": 43889,
      "ty": 2,
      "x": 912,
      "y": 401
    },
    {
      "t": 45005,
      "e": 43991,
      "ty": 2,
      "x": 914,
      "y": 412
    },
    {
      "t": 45005,
      "e": 43991,
      "ty": 41,
      "x": 21971,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 45103,
      "e": 44089,
      "ty": 2,
      "x": 909,
      "y": 416
    },
    {
      "t": 45205,
      "e": 44191,
      "ty": 2,
      "x": 897,
      "y": 420
    },
    {
      "t": 45253,
      "e": 44239,
      "ty": 41,
      "x": 15800,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 45304,
      "e": 44290,
      "ty": 2,
      "x": 885,
      "y": 423
    },
    {
      "t": 45404,
      "e": 44390,
      "ty": 2,
      "x": 883,
      "y": 423
    },
    {
      "t": 45504,
      "e": 44490,
      "ty": 2,
      "x": 873,
      "y": 421
    },
    {
      "t": 45504,
      "e": 44490,
      "ty": 41,
      "x": 60377,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45604,
      "e": 44590,
      "ty": 2,
      "x": 861,
      "y": 412
    },
    {
      "t": 45636,
      "e": 44622,
      "ty": 3,
      "x": 861,
      "y": 412,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45636,
      "e": 44622,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 45753,
      "e": 44739,
      "ty": 41,
      "x": 46329,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45780,
      "e": 44766,
      "ty": 4,
      "x": 46329,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45780,
      "e": 44766,
      "ty": 5,
      "x": 861,
      "y": 412,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45781,
      "e": 44767,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45782,
      "e": 44768,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 46103,
      "e": 45089,
      "ty": 2,
      "x": 970,
      "y": 468
    },
    {
      "t": 46203,
      "e": 45189,
      "ty": 2,
      "x": 1018,
      "y": 498
    },
    {
      "t": 46254,
      "e": 45240,
      "ty": 41,
      "x": 46652,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 46304,
      "e": 45290,
      "ty": 2,
      "x": 1017,
      "y": 504
    },
    {
      "t": 46403,
      "e": 45389,
      "ty": 2,
      "x": 1000,
      "y": 526
    },
    {
      "t": 46503,
      "e": 45489,
      "ty": 2,
      "x": 982,
      "y": 543
    },
    {
      "t": 46503,
      "e": 45489,
      "ty": 41,
      "x": 38109,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 46604,
      "e": 45590,
      "ty": 2,
      "x": 977,
      "y": 553
    },
    {
      "t": 46704,
      "e": 45690,
      "ty": 2,
      "x": 976,
      "y": 554
    },
    {
      "t": 46754,
      "e": 45740,
      "ty": 41,
      "x": 36685,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 47704,
      "e": 46690,
      "ty": 2,
      "x": 976,
      "y": 556
    },
    {
      "t": 47753,
      "e": 46739,
      "ty": 41,
      "x": 37159,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 47803,
      "e": 46789,
      "ty": 2,
      "x": 980,
      "y": 563
    },
    {
      "t": 47903,
      "e": 46889,
      "ty": 2,
      "x": 985,
      "y": 572
    },
    {
      "t": 48004,
      "e": 46990,
      "ty": 2,
      "x": 1015,
      "y": 600
    },
    {
      "t": 48004,
      "e": 46990,
      "ty": 41,
      "x": 45940,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48104,
      "e": 47090,
      "ty": 2,
      "x": 1025,
      "y": 614
    },
    {
      "t": 48204,
      "e": 47190,
      "ty": 2,
      "x": 1027,
      "y": 623
    },
    {
      "t": 48254,
      "e": 47240,
      "ty": 41,
      "x": 48788,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 48303,
      "e": 47289,
      "ty": 2,
      "x": 1027,
      "y": 630
    },
    {
      "t": 48403,
      "e": 47389,
      "ty": 2,
      "x": 1029,
      "y": 635
    },
    {
      "t": 48504,
      "e": 47490,
      "ty": 2,
      "x": 1029,
      "y": 641
    },
    {
      "t": 48504,
      "e": 47490,
      "ty": 41,
      "x": 49263,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 48604,
      "e": 47590,
      "ty": 2,
      "x": 1029,
      "y": 642
    },
    {
      "t": 48754,
      "e": 47740,
      "ty": 41,
      "x": 49263,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 48903,
      "e": 47889,
      "ty": 2,
      "x": 1029,
      "y": 645
    },
    {
      "t": 49004,
      "e": 47990,
      "ty": 2,
      "x": 1036,
      "y": 678
    },
    {
      "t": 49004,
      "e": 47990,
      "ty": 41,
      "x": 57614,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 49103,
      "e": 48089,
      "ty": 2,
      "x": 1036,
      "y": 689
    },
    {
      "t": 49253,
      "e": 48239,
      "ty": 41,
      "x": 54069,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 49303,
      "e": 48289,
      "ty": 2,
      "x": 1036,
      "y": 702
    },
    {
      "t": 49404,
      "e": 48390,
      "ty": 2,
      "x": 1036,
      "y": 705
    },
    {
      "t": 49503,
      "e": 48489,
      "ty": 41,
      "x": 54069,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 49603,
      "e": 48589,
      "ty": 2,
      "x": 1053,
      "y": 696
    },
    {
      "t": 49704,
      "e": 48690,
      "ty": 2,
      "x": 1072,
      "y": 679
    },
    {
      "t": 49754,
      "e": 48740,
      "ty": 41,
      "x": 59468,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 49804,
      "e": 48790,
      "ty": 2,
      "x": 1072,
      "y": 677
    },
    {
      "t": 49903,
      "e": 48889,
      "ty": 2,
      "x": 1072,
      "y": 675
    },
    {
      "t": 50004,
      "e": 48990,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50006,
      "e": 48992,
      "ty": 41,
      "x": 59468,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 51204,
      "e": 50190,
      "ty": 2,
      "x": 1072,
      "y": 680
    },
    {
      "t": 51254,
      "e": 50240,
      "ty": 41,
      "x": 63897,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 51304,
      "e": 50290,
      "ty": 2,
      "x": 1077,
      "y": 707
    },
    {
      "t": 51403,
      "e": 50389,
      "ty": 2,
      "x": 1077,
      "y": 708
    },
    {
      "t": 51504,
      "e": 50490,
      "ty": 41,
      "x": 64401,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52254,
      "e": 51240,
      "ty": 41,
      "x": 64653,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52304,
      "e": 51290,
      "ty": 2,
      "x": 1078,
      "y": 718
    },
    {
      "t": 52404,
      "e": 51390,
      "ty": 2,
      "x": 1076,
      "y": 737
    },
    {
      "t": 52504,
      "e": 51490,
      "ty": 2,
      "x": 1070,
      "y": 752
    },
    {
      "t": 52504,
      "e": 51490,
      "ty": 41,
      "x": 58993,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 52604,
      "e": 51590,
      "ty": 2,
      "x": 1053,
      "y": 759
    },
    {
      "t": 52704,
      "e": 51690,
      "ty": 2,
      "x": 1017,
      "y": 774
    },
    {
      "t": 52754,
      "e": 51740,
      "ty": 41,
      "x": 43092,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 52804,
      "e": 51790,
      "ty": 2,
      "x": 995,
      "y": 780
    },
    {
      "t": 52904,
      "e": 51890,
      "ty": 2,
      "x": 980,
      "y": 785
    },
    {
      "t": 53003,
      "e": 51989,
      "ty": 2,
      "x": 968,
      "y": 792
    },
    {
      "t": 53004,
      "e": 51990,
      "ty": 41,
      "x": 34786,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 53104,
      "e": 52090,
      "ty": 2,
      "x": 956,
      "y": 798
    },
    {
      "t": 53204,
      "e": 52190,
      "ty": 2,
      "x": 944,
      "y": 805
    },
    {
      "t": 53254,
      "e": 52240,
      "ty": 41,
      "x": 61726,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53304,
      "e": 52290,
      "ty": 2,
      "x": 915,
      "y": 813
    },
    {
      "t": 53389,
      "e": 52375,
      "ty": 3,
      "x": 914,
      "y": 813,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53391,
      "e": 52377,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 53404,
      "e": 52390,
      "ty": 2,
      "x": 914,
      "y": 813
    },
    {
      "t": 53504,
      "e": 52490,
      "ty": 41,
      "x": 54643,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53547,
      "e": 52533,
      "ty": 4,
      "x": 54643,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53548,
      "e": 52534,
      "ty": 5,
      "x": 914,
      "y": 813,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53549,
      "e": 52535,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 53549,
      "e": 52535,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 55204,
      "e": 54190,
      "ty": 2,
      "x": 914,
      "y": 802
    },
    {
      "t": 55254,
      "e": 54240,
      "ty": 41,
      "x": 21971,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 55304,
      "e": 54290,
      "ty": 2,
      "x": 914,
      "y": 797
    },
    {
      "t": 55404,
      "e": 54390,
      "ty": 2,
      "x": 914,
      "y": 794
    },
    {
      "t": 55503,
      "e": 54489,
      "ty": 2,
      "x": 916,
      "y": 784
    },
    {
      "t": 55504,
      "e": 54490,
      "ty": 41,
      "x": 52947,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 55603,
      "e": 54589,
      "ty": 2,
      "x": 916,
      "y": 772
    },
    {
      "t": 55703,
      "e": 54689,
      "ty": 2,
      "x": 916,
      "y": 763
    },
    {
      "t": 55754,
      "e": 54740,
      "ty": 41,
      "x": 39463,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 55803,
      "e": 54789,
      "ty": 2,
      "x": 914,
      "y": 749
    },
    {
      "t": 55904,
      "e": 54890,
      "ty": 2,
      "x": 913,
      "y": 744
    },
    {
      "t": 56004,
      "e": 54990,
      "ty": 41,
      "x": 21733,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 56904,
      "e": 55890,
      "ty": 2,
      "x": 925,
      "y": 732
    },
    {
      "t": 57004,
      "e": 55990,
      "ty": 2,
      "x": 945,
      "y": 721
    },
    {
      "t": 57004,
      "e": 55990,
      "ty": 41,
      "x": 31016,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57104,
      "e": 56090,
      "ty": 2,
      "x": 958,
      "y": 714
    },
    {
      "t": 57204,
      "e": 56190,
      "ty": 2,
      "x": 973,
      "y": 704
    },
    {
      "t": 57254,
      "e": 56240,
      "ty": 41,
      "x": 39454,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57304,
      "e": 56290,
      "ty": 2,
      "x": 979,
      "y": 701
    },
    {
      "t": 57504,
      "e": 56490,
      "ty": 41,
      "x": 39706,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57541,
      "e": 56527,
      "ty": 3,
      "x": 979,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57541,
      "e": 56527,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 57724,
      "e": 56710,
      "ty": 4,
      "x": 39706,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57724,
      "e": 56710,
      "ty": 5,
      "x": 979,
      "y": 701,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57725,
      "e": 56711,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57726,
      "e": 56711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 58754,
      "e": 57739,
      "ty": 41,
      "x": 39454,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58804,
      "e": 57789,
      "ty": 2,
      "x": 967,
      "y": 709
    },
    {
      "t": 58904,
      "e": 57889,
      "ty": 2,
      "x": 940,
      "y": 729
    },
    {
      "t": 59004,
      "e": 57989,
      "ty": 2,
      "x": 932,
      "y": 752
    },
    {
      "t": 59004,
      "e": 57989,
      "ty": 41,
      "x": 46139,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59104,
      "e": 58089,
      "ty": 2,
      "x": 927,
      "y": 771
    },
    {
      "t": 59204,
      "e": 58189,
      "ty": 2,
      "x": 927,
      "y": 783
    },
    {
      "t": 59254,
      "e": 58239,
      "ty": 41,
      "x": 59105,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59304,
      "e": 58289,
      "ty": 2,
      "x": 927,
      "y": 785
    },
    {
      "t": 59373,
      "e": 58358,
      "ty": 3,
      "x": 927,
      "y": 785,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59374,
      "e": 58359,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59540,
      "e": 58525,
      "ty": 4,
      "x": 59105,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59540,
      "e": 58525,
      "ty": 5,
      "x": 927,
      "y": 785,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59541,
      "e": 58526,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 59542,
      "e": 58527,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 60604,
      "e": 59589,
      "ty": 2,
      "x": 918,
      "y": 795
    },
    {
      "t": 60704,
      "e": 59689,
      "ty": 2,
      "x": 914,
      "y": 800
    },
    {
      "t": 60755,
      "e": 59740,
      "ty": 41,
      "x": 54053,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 60804,
      "e": 59789,
      "ty": 2,
      "x": 913,
      "y": 808
    },
    {
      "t": 60904,
      "e": 59889,
      "ty": 2,
      "x": 909,
      "y": 814
    },
    {
      "t": 60989,
      "e": 59974,
      "ty": 3,
      "x": 909,
      "y": 814,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 60990,
      "e": 59975,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 61004,
      "e": 59989,
      "ty": 41,
      "x": 51692,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 61188,
      "e": 60173,
      "ty": 4,
      "x": 51692,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 61189,
      "e": 60174,
      "ty": 5,
      "x": 909,
      "y": 814,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 61189,
      "e": 60174,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 61191,
      "e": 60176,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 61604,
      "e": 60589,
      "ty": 2,
      "x": 934,
      "y": 849
    },
    {
      "t": 61704,
      "e": 60689,
      "ty": 2,
      "x": 948,
      "y": 907
    },
    {
      "t": 61754,
      "e": 60739,
      "ty": 41,
      "x": 29802,
      "y": 16635,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 61804,
      "e": 60789,
      "ty": 2,
      "x": 946,
      "y": 908
    },
    {
      "t": 61904,
      "e": 60889,
      "ty": 2,
      "x": 932,
      "y": 933
    },
    {
      "t": 62003,
      "e": 60988,
      "ty": 2,
      "x": 900,
      "y": 969
    },
    {
      "t": 62003,
      "e": 60988,
      "ty": 41,
      "x": 63563,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62104,
      "e": 61089,
      "ty": 2,
      "x": 895,
      "y": 975
    },
    {
      "t": 62254,
      "e": 61239,
      "ty": 41,
      "x": 17224,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62304,
      "e": 61289,
      "ty": 2,
      "x": 891,
      "y": 975
    },
    {
      "t": 62404,
      "e": 61389,
      "ty": 2,
      "x": 890,
      "y": 972
    },
    {
      "t": 62504,
      "e": 61489,
      "ty": 41,
      "x": 55474,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62549,
      "e": 61534,
      "ty": 3,
      "x": 890,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62550,
      "e": 61535,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62669,
      "e": 61654,
      "ty": 4,
      "x": 55474,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62669,
      "e": 61654,
      "ty": 5,
      "x": 890,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62670,
      "e": 61655,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62671,
      "e": 61656,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 63004,
      "e": 61989,
      "ty": 2,
      "x": 911,
      "y": 1003
    },
    {
      "t": 63004,
      "e": 61989,
      "ty": 41,
      "x": 21259,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 63021,
      "e": 62006,
      "ty": 6,
      "x": 914,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63105,
      "e": 62090,
      "ty": 2,
      "x": 915,
      "y": 1007
    },
    {
      "t": 63141,
      "e": 62126,
      "ty": 3,
      "x": 915,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63142,
      "e": 62127,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63142,
      "e": 62127,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63254,
      "e": 62239,
      "ty": 41,
      "x": 44106,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63284,
      "e": 62269,
      "ty": 4,
      "x": 44106,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63284,
      "e": 62269,
      "ty": 5,
      "x": 915,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63288,
      "e": 62273,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63290,
      "e": 62275,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63290,
      "e": 62275,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 64653,
      "e": 63638,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 66008,
      "e": 64993,
      "ty": 2,
      "x": 950,
      "y": 1066
    },
    {
      "t": 66009,
      "e": 64994,
      "ty": 41,
      "x": 32300,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66010,
      "e": 64995,
      "ty": 6,
      "x": 955,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 66108,
      "e": 65093,
      "ty": 2,
      "x": 963,
      "y": 1084
    },
    {
      "t": 66259,
      "e": 65244,
      "ty": 41,
      "x": 29217,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 68681,
      "e": 67666,
      "ty": 3,
      "x": 963,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 68682,
      "e": 67667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 68896,
      "e": 67881,
      "ty": 4,
      "x": 29217,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 68898,
      "e": 67883,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 68898,
      "e": 67883,
      "ty": 5,
      "x": 963,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 68899,
      "e": 67884,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 69933,
      "e": 68918,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 70492,
      "e": 69477,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70994,
      "e": 69979,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"nodeType\":3,\"id\":2593,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2590},{\"id\":2591},{\"nodeType\":3,\"id\":2594,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2592}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2595,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2596,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2595},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2597,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2596},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2598,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2597},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2596}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":2596}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2597}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2597}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2605,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2598}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2595},{\"id\":2596},{\"id\":2599},{\"id\":2601},{\"id\":2600},{\"id\":2597},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2598},{\"id\":2605}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2609},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2618,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2622,\"textContent\":\"English\",\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2632,\"textContent\":\"*\",\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2641,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2633}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2633}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":3,\"id\":2645,\"textContent\":\"First\",\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2635}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2664,\"textContent\":\"*\",\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2666},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2610}},{\"nodeType\":3,\"id\":2673,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2665}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2665}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":3,\"id\":2677,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2667}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2696,\"textContent\":\"*\",\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2698},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2701,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2697}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2697}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":3,\"id\":2705,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2699}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"*\",\"parentNode\":{\"id\":2702}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2608},{\"id\":2613},{\"id\":2618},{\"id\":2619},{\"id\":2632},{\"id\":2614},{\"id\":2620},{\"id\":2621},{\"id\":2622},{\"id\":2615},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2616},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2617},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2609},{\"id\":2633},{\"id\":2641},{\"id\":2642},{\"id\":2664},{\"id\":2634},{\"id\":2643},{\"id\":2644},{\"id\":2645},{\"id\":2635},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2636},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2637},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2638},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2639},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2640},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2610},{\"id\":2665},{\"id\":2673},{\"id\":2674},{\"id\":2696},{\"id\":2666},{\"id\":2675},{\"id\":2676},{\"id\":2677},{\"id\":2667},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2668},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2669},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2670},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2671},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2672},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2611},{\"id\":2697},{\"id\":2701},{\"id\":2702},{\"id\":2712},{\"id\":2698},{\"id\":2703},{\"id\":2704},{\"id\":2705},{\"id\":2699},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2700},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2612}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2714,\"textContent\":\" \",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2715,\"textContent\":\" \",\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2728,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"parentNode\":{\"id\":2718}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2740,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2744,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"parentNode\":{\"id\":2736}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2750}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2757,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" \",\"parentNode\":{\"id\":2720}},{\"nodeType\":1,\"id\":2759,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2758},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"previousSibling\":{\"id\":2759},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2759}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2713},{\"id\":2715},{\"id\":2716},{\"id\":2722},{\"id\":2723},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2727},{\"id\":2724},{\"id\":2717},{\"id\":2718},{\"id\":2729},{\"id\":2730},{\"id\":2732},{\"id\":2733},{\"id\":2744},{\"id\":2734},{\"id\":2745},{\"id\":2746},{\"id\":2748},{\"id\":2747},{\"id\":2735},{\"id\":2736},{\"id\":2749},{\"id\":2750},{\"id\":2752},{\"id\":2751},{\"id\":2737},{\"id\":2738},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2739},{\"id\":2740},{\"id\":2756},{\"id\":2741},{\"id\":2742},{\"id\":2757},{\"id\":2743},{\"id\":2731},{\"id\":2719},{\"id\":2720},{\"id\":2758},{\"id\":2759},{\"id\":2761},{\"id\":2760},{\"id\":2721},{\"id\":2714}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2762,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"[ { \\\"rt\\\": 7545, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 7551, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3311, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 11949, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 16385, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MEN\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 29341, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3628, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 34053, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 11939, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 46995, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 31329, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 79562, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -10 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:868,y:941,t:1526667819306};\\\", \\\"{x:749,y:877,t:1526667819321};\\\", \\\"{x:643,y:823,t:1526667819338};\\\", \\\"{x:565,y:789,t:1526667819354};\\\", \\\"{x:524,y:773,t:1526667819372};\\\", \\\"{x:509,y:762,t:1526667819388};\\\", \\\"{x:503,y:755,t:1526667819404};\\\", \\\"{x:503,y:750,t:1526667819422};\\\", \\\"{x:503,y:740,t:1526667819437};\\\", \\\"{x:512,y:725,t:1526667819455};\\\", \\\"{x:531,y:702,t:1526667819471};\\\", \\\"{x:567,y:670,t:1526667819487};\\\", \\\"{x:671,y:597,t:1526667819505};\\\", \\\"{x:761,y:545,t:1526667819522};\\\", \\\"{x:851,y:493,t:1526667819538};\\\", \\\"{x:946,y:444,t:1526667819554};\\\", \\\"{x:1020,y:398,t:1526667819571};\\\", \\\"{x:1095,y:367,t:1526667819588};\\\", \\\"{x:1161,y:338,t:1526667819605};\\\", \\\"{x:1221,y:316,t:1526667819621};\\\", \\\"{x:1266,y:302,t:1526667819638};\\\", \\\"{x:1301,y:292,t:1526667819655};\\\", \\\"{x:1326,y:283,t:1526667819672};\\\", \\\"{x:1344,y:273,t:1526667819688};\\\", \\\"{x:1364,y:265,t:1526667819705};\\\", \\\"{x:1372,y:262,t:1526667819721};\\\", \\\"{x:1378,y:259,t:1526667819739};\\\", \\\"{x:1380,y:259,t:1526667819761};\\\", \\\"{x:1381,y:258,t:1526667819771};\\\", \\\"{x:1382,y:257,t:1526667819787};\\\", \\\"{x:1383,y:256,t:1526667819809};\\\", \\\"{x:1384,y:256,t:1526667819843};\\\", \\\"{x:1385,y:255,t:1526667819888};\\\", \\\"{x:1387,y:254,t:1526667819905};\\\", \\\"{x:1389,y:253,t:1526667819921};\\\", \\\"{x:1391,y:252,t:1526667819938};\\\", \\\"{x:1393,y:252,t:1526667819954};\\\", \\\"{x:1394,y:251,t:1526667819970};\\\", \\\"{x:1395,y:251,t:1526667819988};\\\", \\\"{x:1399,y:250,t:1526667820008};\\\", \\\"{x:1406,y:250,t:1526667820020};\\\", \\\"{x:1429,y:250,t:1526667820038};\\\", \\\"{x:1458,y:249,t:1526667820054};\\\", \\\"{x:1491,y:249,t:1526667820071};\\\", \\\"{x:1520,y:249,t:1526667820088};\\\", \\\"{x:1561,y:250,t:1526667820105};\\\", \\\"{x:1587,y:254,t:1526667820120};\\\", \\\"{x:1606,y:260,t:1526667820139};\\\", \\\"{x:1619,y:264,t:1526667820154};\\\", \\\"{x:1624,y:269,t:1526667820171};\\\", \\\"{x:1625,y:272,t:1526667820187};\\\", \\\"{x:1627,y:278,t:1526667820205};\\\", \\\"{x:1628,y:290,t:1526667820221};\\\", \\\"{x:1628,y:304,t:1526667820237};\\\", \\\"{x:1626,y:321,t:1526667820254};\\\", \\\"{x:1621,y:339,t:1526667820271};\\\", \\\"{x:1616,y:359,t:1526667820288};\\\", \\\"{x:1608,y:380,t:1526667820304};\\\", \\\"{x:1592,y:419,t:1526667820321};\\\", \\\"{x:1578,y:450,t:1526667820338};\\\", \\\"{x:1559,y:480,t:1526667820354};\\\", \\\"{x:1542,y:506,t:1526667820372};\\\", \\\"{x:1525,y:525,t:1526667820388};\\\", \\\"{x:1510,y:543,t:1526667820404};\\\", \\\"{x:1495,y:561,t:1526667820421};\\\", \\\"{x:1479,y:577,t:1526667820438};\\\", \\\"{x:1457,y:594,t:1526667820454};\\\", \\\"{x:1439,y:607,t:1526667820471};\\\", \\\"{x:1420,y:619,t:1526667820487};\\\", \\\"{x:1400,y:630,t:1526667820503};\\\", \\\"{x:1380,y:641,t:1526667820520};\\\", \\\"{x:1372,y:643,t:1526667820538};\\\", \\\"{x:1370,y:644,t:1526667820554};\\\", \\\"{x:1369,y:644,t:1526667820570};\\\", \\\"{x:1367,y:644,t:1526667820674};\\\", \\\"{x:1366,y:644,t:1526667820730};\\\", \\\"{x:1365,y:644,t:1526667821330};\\\", \\\"{x:1363,y:643,t:1526667822434};\\\", \\\"{x:1363,y:642,t:1526667822442};\\\", \\\"{x:1362,y:641,t:1526667822452};\\\", \\\"{x:1359,y:637,t:1526667822469};\\\", \\\"{x:1358,y:637,t:1526667822485};\\\", \\\"{x:1357,y:635,t:1526667822502};\\\", \\\"{x:1357,y:634,t:1526667822519};\\\", \\\"{x:1356,y:634,t:1526667822535};\\\", \\\"{x:1356,y:633,t:1526667823602};\\\", \\\"{x:1355,y:628,t:1526667823618};\\\", \\\"{x:1355,y:626,t:1526667823634};\\\", \\\"{x:1354,y:623,t:1526667823651};\\\", \\\"{x:1354,y:622,t:1526667823668};\\\", \\\"{x:1354,y:621,t:1526667823697};\\\", \\\"{x:1353,y:621,t:1526667825465};\\\", \\\"{x:1347,y:662,t:1526667825482};\\\", \\\"{x:1336,y:737,t:1526667825499};\\\", \\\"{x:1331,y:803,t:1526667825516};\\\", \\\"{x:1327,y:863,t:1526667825531};\\\", \\\"{x:1316,y:907,t:1526667825548};\\\", \\\"{x:1310,y:928,t:1526667825566};\\\", \\\"{x:1303,y:941,t:1526667825582};\\\", \\\"{x:1301,y:945,t:1526667825598};\\\", \\\"{x:1301,y:946,t:1526667825616};\\\", \\\"{x:1301,y:947,t:1526667825818};\\\", \\\"{x:1301,y:949,t:1526667825832};\\\", \\\"{x:1298,y:953,t:1526667825849};\\\", \\\"{x:1294,y:955,t:1526667825865};\\\", \\\"{x:1289,y:958,t:1526667825882};\\\", \\\"{x:1285,y:961,t:1526667825899};\\\", \\\"{x:1283,y:962,t:1526667825915};\\\", \\\"{x:1281,y:963,t:1526667825934};\\\", \\\"{x:1280,y:964,t:1526667825949};\\\", \\\"{x:1280,y:965,t:1526667825964};\\\", \\\"{x:1279,y:965,t:1526667825992};\\\", \\\"{x:1278,y:965,t:1526667826024};\\\", \\\"{x:1278,y:959,t:1526667828533};\\\", \\\"{x:1278,y:945,t:1526667828550};\\\", \\\"{x:1278,y:936,t:1526667828566};\\\", \\\"{x:1278,y:921,t:1526667828582};\\\", \\\"{x:1276,y:905,t:1526667828599};\\\", \\\"{x:1275,y:891,t:1526667828615};\\\", \\\"{x:1275,y:881,t:1526667828632};\\\", \\\"{x:1275,y:866,t:1526667828649};\\\", \\\"{x:1274,y:846,t:1526667828664};\\\", \\\"{x:1269,y:824,t:1526667828682};\\\", \\\"{x:1262,y:794,t:1526667828699};\\\", \\\"{x:1259,y:783,t:1526667828715};\\\", \\\"{x:1258,y:769,t:1526667828732};\\\", \\\"{x:1258,y:762,t:1526667828749};\\\", \\\"{x:1258,y:758,t:1526667828765};\\\", \\\"{x:1258,y:756,t:1526667828783};\\\", \\\"{x:1258,y:755,t:1526667828800};\\\", \\\"{x:1258,y:756,t:1526667829141};\\\", \\\"{x:1258,y:759,t:1526667829148};\\\", \\\"{x:1258,y:763,t:1526667829166};\\\", \\\"{x:1259,y:769,t:1526667829182};\\\", \\\"{x:1259,y:773,t:1526667829199};\\\", \\\"{x:1260,y:778,t:1526667829215};\\\", \\\"{x:1263,y:784,t:1526667829231};\\\", \\\"{x:1264,y:789,t:1526667829248};\\\", \\\"{x:1267,y:799,t:1526667829265};\\\", \\\"{x:1270,y:810,t:1526667829281};\\\", \\\"{x:1272,y:817,t:1526667829298};\\\", \\\"{x:1274,y:826,t:1526667829315};\\\", \\\"{x:1276,y:829,t:1526667829333};\\\", \\\"{x:1276,y:830,t:1526667829348};\\\", \\\"{x:1276,y:831,t:1526667832917};\\\", \\\"{x:1275,y:834,t:1526667832931};\\\", \\\"{x:1236,y:837,t:1526667832945};\\\", \\\"{x:1139,y:826,t:1526667832962};\\\", \\\"{x:1009,y:811,t:1526667832979};\\\", \\\"{x:865,y:790,t:1526667832994};\\\", \\\"{x:694,y:763,t:1526667833012};\\\", \\\"{x:394,y:722,t:1526667833028};\\\", \\\"{x:173,y:689,t:1526667833044};\\\", \\\"{x:0,y:654,t:1526667833062};\\\", \\\"{x:0,y:629,t:1526667833078};\\\", \\\"{x:0,y:602,t:1526667833095};\\\", \\\"{x:0,y:568,t:1526667833112};\\\", \\\"{x:0,y:539,t:1526667833128};\\\", \\\"{x:0,y:522,t:1526667833144};\\\", \\\"{x:0,y:519,t:1526667833162};\\\", \\\"{x:0,y:518,t:1526667833177};\\\", \\\"{x:0,y:514,t:1526667833194};\\\", \\\"{x:0,y:511,t:1526667833212};\\\", \\\"{x:3,y:508,t:1526667833227};\\\", \\\"{x:17,y:498,t:1526667833244};\\\", \\\"{x:31,y:489,t:1526667833262};\\\", \\\"{x:44,y:484,t:1526667833278};\\\", \\\"{x:60,y:477,t:1526667833294};\\\", \\\"{x:76,y:474,t:1526667833311};\\\", \\\"{x:99,y:474,t:1526667833327};\\\", \\\"{x:129,y:474,t:1526667833344};\\\", \\\"{x:168,y:478,t:1526667833360};\\\", \\\"{x:208,y:484,t:1526667833377};\\\", \\\"{x:247,y:491,t:1526667833395};\\\", \\\"{x:305,y:504,t:1526667833411};\\\", \\\"{x:367,y:514,t:1526667833429};\\\", \\\"{x:443,y:523,t:1526667833444};\\\", \\\"{x:469,y:528,t:1526667833459};\\\", \\\"{x:475,y:529,t:1526667833469};\\\", \\\"{x:483,y:530,t:1526667833486};\\\", \\\"{x:484,y:530,t:1526667833502};\\\", \\\"{x:485,y:530,t:1526667833643};\\\", \\\"{x:484,y:532,t:1526667833653};\\\", \\\"{x:478,y:535,t:1526667833669};\\\", \\\"{x:472,y:537,t:1526667833686};\\\", \\\"{x:467,y:539,t:1526667833703};\\\", \\\"{x:465,y:540,t:1526667833719};\\\", \\\"{x:463,y:541,t:1526667833737};\\\", \\\"{x:461,y:541,t:1526667833752};\\\", \\\"{x:459,y:541,t:1526667833819};\\\", \\\"{x:453,y:540,t:1526667833835};\\\", \\\"{x:449,y:537,t:1526667833853};\\\", \\\"{x:446,y:536,t:1526667833870};\\\", \\\"{x:441,y:534,t:1526667833887};\\\", \\\"{x:432,y:531,t:1526667833903};\\\", \\\"{x:426,y:531,t:1526667833920};\\\", \\\"{x:423,y:529,t:1526667833936};\\\", \\\"{x:422,y:529,t:1526667833953};\\\", \\\"{x:420,y:528,t:1526667833969};\\\", \\\"{x:420,y:527,t:1526667833987};\\\", \\\"{x:419,y:527,t:1526667834076};\\\", \\\"{x:417,y:527,t:1526667834087};\\\", \\\"{x:416,y:527,t:1526667834103};\\\", \\\"{x:414,y:527,t:1526667834119};\\\", \\\"{x:413,y:527,t:1526667834136};\\\", \\\"{x:411,y:526,t:1526667834153};\\\", \\\"{x:410,y:526,t:1526667834555};\\\", \\\"{x:410,y:533,t:1526667834570};\\\", \\\"{x:415,y:550,t:1526667834587};\\\", \\\"{x:423,y:573,t:1526667834604};\\\", \\\"{x:426,y:582,t:1526667834621};\\\", \\\"{x:428,y:588,t:1526667834637};\\\", \\\"{x:431,y:595,t:1526667834653};\\\", \\\"{x:433,y:599,t:1526667834670};\\\", \\\"{x:438,y:610,t:1526667834686};\\\", \\\"{x:443,y:622,t:1526667834706};\\\", \\\"{x:447,y:632,t:1526667834720};\\\", \\\"{x:451,y:642,t:1526667834737};\\\", \\\"{x:455,y:651,t:1526667834754};\\\", \\\"{x:463,y:663,t:1526667834770};\\\", \\\"{x:470,y:676,t:1526667834787};\\\", \\\"{x:478,y:690,t:1526667834803};\\\", \\\"{x:488,y:705,t:1526667834821};\\\", \\\"{x:496,y:718,t:1526667834837};\\\", \\\"{x:503,y:732,t:1526667834853};\\\", \\\"{x:509,y:744,t:1526667834870};\\\", \\\"{x:515,y:754,t:1526667834887};\\\", \\\"{x:520,y:763,t:1526667834903};\\\", \\\"{x:526,y:773,t:1526667834920};\\\", \\\"{x:528,y:775,t:1526667834938};\\\", \\\"{x:528,y:776,t:1526667834953};\\\", \\\"{x:528,y:773,t:1526667836261};\\\", \\\"{x:528,y:769,t:1526667836273};\\\", \\\"{x:528,y:763,t:1526667836289};\\\", \\\"{x:528,y:760,t:1526667836305};\\\", \\\"{x:528,y:757,t:1526667836323};\\\", \\\"{x:528,y:754,t:1526667836338};\\\", \\\"{x:528,y:751,t:1526667836356};\\\", \\\"{x:528,y:748,t:1526667836372};\\\", \\\"{x:528,y:746,t:1526667836388};\\\", \\\"{x:528,y:741,t:1526667836405};\\\", \\\"{x:528,y:738,t:1526667836423};\\\", \\\"{x:528,y:736,t:1526667836440};\\\", \\\"{x:528,y:734,t:1526667836456};\\\", \\\"{x:528,y:733,t:1526667836472};\\\", \\\"{x:528,y:732,t:1526667836489};\\\", \\\"{x:528,y:731,t:1526667836505};\\\", \\\"{x:528,y:729,t:1526667836521};\\\", \\\"{x:529,y:725,t:1526667836538};\\\", \\\"{x:530,y:721,t:1526667836555};\\\", \\\"{x:532,y:717,t:1526667836571};\\\", \\\"{x:533,y:715,t:1526667836588};\\\", \\\"{x:534,y:712,t:1526667836605};\\\", \\\"{x:535,y:709,t:1526667836622};\\\", \\\"{x:535,y:707,t:1526667836638};\\\", \\\"{x:535,y:706,t:1526667836656};\\\", \\\"{x:539,y:703,t:1526667840332};\\\", \\\"{x:553,y:698,t:1526667840343};\\\", \\\"{x:613,y:695,t:1526667840359};\\\", \\\"{x:674,y:695,t:1526667840374};\\\", \\\"{x:738,y:695,t:1526667840391};\\\", \\\"{x:799,y:686,t:1526667840407};\\\", \\\"{x:871,y:677,t:1526667840425};\\\", \\\"{x:924,y:671,t:1526667840442};\\\", \\\"{x:969,y:665,t:1526667840457};\\\", \\\"{x:998,y:664,t:1526667840474};\\\", \\\"{x:1027,y:664,t:1526667840492};\\\", \\\"{x:1034,y:664,t:1526667840508};\\\", \\\"{x:1037,y:664,t:1526667840524};\\\", \\\"{x:1042,y:663,t:1526667840542};\\\", \\\"{x:1057,y:663,t:1526667840558};\\\", \\\"{x:1079,y:663,t:1526667840574};\\\", \\\"{x:1105,y:663,t:1526667840592};\\\", \\\"{x:1126,y:664,t:1526667840609};\\\", \\\"{x:1151,y:670,t:1526667840625};\\\", \\\"{x:1178,y:680,t:1526667840642};\\\", \\\"{x:1213,y:699,t:1526667840659};\\\", \\\"{x:1259,y:726,t:1526667840675};\\\", \\\"{x:1306,y:762,t:1526667840692};\\\", \\\"{x:1324,y:786,t:1526667840709};\\\", \\\"{x:1352,y:825,t:1526667840725};\\\", \\\"{x:1379,y:862,t:1526667840741};\\\", \\\"{x:1393,y:888,t:1526667840758};\\\", \\\"{x:1396,y:906,t:1526667840774};\\\", \\\"{x:1398,y:919,t:1526667840791};\\\", \\\"{x:1397,y:933,t:1526667840808};\\\", \\\"{x:1393,y:947,t:1526667840824};\\\", \\\"{x:1389,y:967,t:1526667840841};\\\", \\\"{x:1385,y:986,t:1526667840858};\\\", \\\"{x:1378,y:1003,t:1526667840874};\\\", \\\"{x:1367,y:1017,t:1526667840892};\\\", \\\"{x:1358,y:1022,t:1526667840909};\\\", \\\"{x:1346,y:1023,t:1526667840925};\\\", \\\"{x:1330,y:1023,t:1526667840942};\\\", \\\"{x:1315,y:1023,t:1526667840959};\\\", \\\"{x:1302,y:1021,t:1526667840975};\\\", \\\"{x:1289,y:1016,t:1526667840992};\\\", \\\"{x:1273,y:1008,t:1526667841008};\\\", \\\"{x:1257,y:1000,t:1526667841026};\\\", \\\"{x:1246,y:993,t:1526667841042};\\\", \\\"{x:1241,y:989,t:1526667841059};\\\", \\\"{x:1237,y:986,t:1526667841076};\\\", \\\"{x:1235,y:983,t:1526667841092};\\\", \\\"{x:1233,y:981,t:1526667841108};\\\", \\\"{x:1232,y:979,t:1526667841127};\\\", \\\"{x:1231,y:978,t:1526667841141};\\\", \\\"{x:1231,y:977,t:1526667841293};\\\", \\\"{x:1232,y:976,t:1526667841309};\\\", \\\"{x:1233,y:976,t:1526667841326};\\\", \\\"{x:1234,y:975,t:1526667841342};\\\", \\\"{x:1235,y:975,t:1526667841358};\\\", \\\"{x:1238,y:973,t:1526667841375};\\\", \\\"{x:1240,y:973,t:1526667841391};\\\", \\\"{x:1241,y:973,t:1526667841408};\\\", \\\"{x:1244,y:972,t:1526667841425};\\\", \\\"{x:1247,y:971,t:1526667841443};\\\", \\\"{x:1251,y:971,t:1526667841458};\\\", \\\"{x:1260,y:971,t:1526667841475};\\\", \\\"{x:1265,y:971,t:1526667841492};\\\", \\\"{x:1270,y:970,t:1526667841508};\\\", \\\"{x:1272,y:969,t:1526667841526};\\\", \\\"{x:1273,y:969,t:1526667841543};\\\", \\\"{x:1274,y:969,t:1526667841563};\\\", \\\"{x:1275,y:969,t:1526667843093};\\\", \\\"{x:1276,y:969,t:1526667843101};\\\", \\\"{x:1277,y:967,t:1526667843110};\\\", \\\"{x:1279,y:959,t:1526667843127};\\\", \\\"{x:1280,y:955,t:1526667843145};\\\", \\\"{x:1280,y:951,t:1526667843160};\\\", \\\"{x:1280,y:948,t:1526667843177};\\\", \\\"{x:1281,y:945,t:1526667843194};\\\", \\\"{x:1282,y:940,t:1526667843210};\\\", \\\"{x:1282,y:939,t:1526667843228};\\\", \\\"{x:1282,y:937,t:1526667843244};\\\", \\\"{x:1283,y:933,t:1526667843260};\\\", \\\"{x:1284,y:930,t:1526667843277};\\\", \\\"{x:1285,y:927,t:1526667843294};\\\", \\\"{x:1287,y:922,t:1526667843310};\\\", \\\"{x:1288,y:917,t:1526667843327};\\\", \\\"{x:1289,y:912,t:1526667843344};\\\", \\\"{x:1291,y:907,t:1526667843361};\\\", \\\"{x:1294,y:901,t:1526667843377};\\\", \\\"{x:1297,y:895,t:1526667843394};\\\", \\\"{x:1299,y:891,t:1526667843411};\\\", \\\"{x:1302,y:884,t:1526667843427};\\\", \\\"{x:1304,y:877,t:1526667843444};\\\", \\\"{x:1307,y:872,t:1526667843461};\\\", \\\"{x:1310,y:866,t:1526667843477};\\\", \\\"{x:1311,y:861,t:1526667843494};\\\", \\\"{x:1313,y:859,t:1526667843511};\\\", \\\"{x:1315,y:852,t:1526667843527};\\\", \\\"{x:1319,y:846,t:1526667843544};\\\", \\\"{x:1324,y:838,t:1526667843561};\\\", \\\"{x:1326,y:832,t:1526667843577};\\\", \\\"{x:1332,y:822,t:1526667843594};\\\", \\\"{x:1334,y:817,t:1526667843611};\\\", \\\"{x:1339,y:808,t:1526667843627};\\\", \\\"{x:1348,y:791,t:1526667843644};\\\", \\\"{x:1353,y:779,t:1526667843661};\\\", \\\"{x:1356,y:772,t:1526667843677};\\\", \\\"{x:1360,y:765,t:1526667843695};\\\", \\\"{x:1361,y:764,t:1526667843711};\\\", \\\"{x:1362,y:762,t:1526667843728};\\\", \\\"{x:1364,y:759,t:1526667843745};\\\", \\\"{x:1365,y:757,t:1526667843764};\\\", \\\"{x:1366,y:755,t:1526667843777};\\\", \\\"{x:1368,y:755,t:1526667843964};\\\", \\\"{x:1370,y:755,t:1526667843987};\\\", \\\"{x:1370,y:754,t:1526667843996};\\\", \\\"{x:1371,y:754,t:1526667844053};\\\", \\\"{x:1373,y:754,t:1526667844076};\\\", \\\"{x:1374,y:754,t:1526667844092};\\\", \\\"{x:1376,y:754,t:1526667844116};\\\", \\\"{x:1378,y:756,t:1526667844128};\\\", \\\"{x:1383,y:762,t:1526667844145};\\\", \\\"{x:1387,y:767,t:1526667844162};\\\", \\\"{x:1390,y:771,t:1526667844178};\\\", \\\"{x:1392,y:773,t:1526667844194};\\\", \\\"{x:1393,y:773,t:1526667844211};\\\", \\\"{x:1392,y:773,t:1526667844460};\\\", \\\"{x:1390,y:773,t:1526667844479};\\\", \\\"{x:1386,y:771,t:1526667844495};\\\", \\\"{x:1384,y:771,t:1526667844511};\\\", \\\"{x:1383,y:770,t:1526667844528};\\\", \\\"{x:1381,y:770,t:1526667844545};\\\", \\\"{x:1379,y:769,t:1526667844561};\\\", \\\"{x:1377,y:769,t:1526667844578};\\\", \\\"{x:1377,y:768,t:1526667844596};\\\", \\\"{x:1376,y:768,t:1526667844611};\\\", \\\"{x:1375,y:768,t:1526667844628};\\\", \\\"{x:1373,y:767,t:1526667844646};\\\", \\\"{x:1373,y:766,t:1526667844668};\\\", \\\"{x:1373,y:765,t:1526667844678};\\\", \\\"{x:1373,y:758,t:1526667844695};\\\", \\\"{x:1374,y:743,t:1526667844711};\\\", \\\"{x:1382,y:719,t:1526667844729};\\\", \\\"{x:1400,y:679,t:1526667844745};\\\", \\\"{x:1427,y:635,t:1526667844761};\\\", \\\"{x:1457,y:590,t:1526667844779};\\\", \\\"{x:1477,y:567,t:1526667844795};\\\", \\\"{x:1499,y:551,t:1526667844811};\\\", \\\"{x:1507,y:548,t:1526667844827};\\\", \\\"{x:1511,y:547,t:1526667844844};\\\", \\\"{x:1515,y:547,t:1526667844862};\\\", \\\"{x:1517,y:547,t:1526667844877};\\\", \\\"{x:1519,y:547,t:1526667844895};\\\", \\\"{x:1521,y:549,t:1526667844912};\\\", \\\"{x:1522,y:552,t:1526667844927};\\\", \\\"{x:1524,y:556,t:1526667844944};\\\", \\\"{x:1526,y:560,t:1526667844962};\\\", \\\"{x:1526,y:563,t:1526667844978};\\\", \\\"{x:1526,y:566,t:1526667844995};\\\", \\\"{x:1526,y:570,t:1526667845012};\\\", \\\"{x:1526,y:572,t:1526667845028};\\\", \\\"{x:1525,y:574,t:1526667845045};\\\", \\\"{x:1521,y:576,t:1526667845062};\\\", \\\"{x:1518,y:579,t:1526667845079};\\\", \\\"{x:1514,y:581,t:1526667845095};\\\", \\\"{x:1512,y:583,t:1526667845112};\\\", \\\"{x:1508,y:585,t:1526667845129};\\\", \\\"{x:1506,y:587,t:1526667845145};\\\", \\\"{x:1502,y:589,t:1526667845162};\\\", \\\"{x:1499,y:591,t:1526667845178};\\\", \\\"{x:1492,y:594,t:1526667845196};\\\", \\\"{x:1483,y:598,t:1526667845213};\\\", \\\"{x:1477,y:601,t:1526667845228};\\\", \\\"{x:1472,y:602,t:1526667845246};\\\", \\\"{x:1468,y:602,t:1526667845262};\\\", \\\"{x:1465,y:602,t:1526667845279};\\\", \\\"{x:1460,y:597,t:1526667845296};\\\", \\\"{x:1455,y:584,t:1526667845312};\\\", \\\"{x:1453,y:567,t:1526667845328};\\\", \\\"{x:1453,y:538,t:1526667845345};\\\", \\\"{x:1453,y:508,t:1526667845363};\\\", \\\"{x:1457,y:465,t:1526667845380};\\\", \\\"{x:1470,y:407,t:1526667845395};\\\", \\\"{x:1489,y:366,t:1526667845412};\\\", \\\"{x:1497,y:351,t:1526667845429};\\\", \\\"{x:1503,y:340,t:1526667845446};\\\", \\\"{x:1509,y:333,t:1526667845462};\\\", \\\"{x:1514,y:325,t:1526667845480};\\\", \\\"{x:1520,y:318,t:1526667845495};\\\", \\\"{x:1527,y:313,t:1526667845513};\\\", \\\"{x:1533,y:309,t:1526667845529};\\\", \\\"{x:1537,y:306,t:1526667845545};\\\", \\\"{x:1543,y:304,t:1526667845562};\\\", \\\"{x:1549,y:301,t:1526667845579};\\\", \\\"{x:1554,y:300,t:1526667845596};\\\", \\\"{x:1555,y:300,t:1526667845613};\\\", \\\"{x:1555,y:303,t:1526667845693};\\\", \\\"{x:1556,y:310,t:1526667845700};\\\", \\\"{x:1558,y:317,t:1526667845712};\\\", \\\"{x:1560,y:335,t:1526667845729};\\\", \\\"{x:1561,y:357,t:1526667845746};\\\", \\\"{x:1561,y:376,t:1526667845762};\\\", \\\"{x:1561,y:401,t:1526667845779};\\\", \\\"{x:1500,y:490,t:1526667845796};\\\", \\\"{x:1402,y:593,t:1526667845811};\\\", \\\"{x:1258,y:725,t:1526667845828};\\\", \\\"{x:1083,y:851,t:1526667845845};\\\", \\\"{x:885,y:974,t:1526667845861};\\\", \\\"{x:654,y:1071,t:1526667845878};\\\", \\\"{x:405,y:1148,t:1526667845896};\\\", \\\"{x:184,y:1183,t:1526667845912};\\\", \\\"{x:32,y:1185,t:1526667845928};\\\", \\\"{x:0,y:1172,t:1526667845946};\\\", \\\"{x:0,y:1155,t:1526667845963};\\\", \\\"{x:0,y:1146,t:1526667845978};\\\", \\\"{x:2,y:1127,t:1526667845996};\\\", \\\"{x:28,y:1092,t:1526667846013};\\\", \\\"{x:59,y:1051,t:1526667846029};\\\", \\\"{x:96,y:1010,t:1526667846046};\\\", \\\"{x:135,y:959,t:1526667846063};\\\", \\\"{x:174,y:900,t:1526667846080};\\\", \\\"{x:211,y:842,t:1526667846096};\\\", \\\"{x:246,y:782,t:1526667846113};\\\", \\\"{x:287,y:723,t:1526667846130};\\\", \\\"{x:327,y:672,t:1526667846146};\\\", \\\"{x:360,y:629,t:1526667846164};\\\", \\\"{x:415,y:565,t:1526667846181};\\\", \\\"{x:451,y:519,t:1526667846196};\\\", \\\"{x:490,y:483,t:1526667846213};\\\", \\\"{x:518,y:459,t:1526667846230};\\\", \\\"{x:536,y:443,t:1526667846245};\\\", \\\"{x:544,y:436,t:1526667846263};\\\", \\\"{x:546,y:434,t:1526667846280};\\\", \\\"{x:545,y:434,t:1526667846332};\\\", \\\"{x:541,y:434,t:1526667846346};\\\", \\\"{x:532,y:442,t:1526667846362};\\\", \\\"{x:515,y:461,t:1526667846380};\\\", \\\"{x:503,y:478,t:1526667846396};\\\", \\\"{x:486,y:497,t:1526667846414};\\\", \\\"{x:467,y:513,t:1526667846431};\\\", \\\"{x:448,y:524,t:1526667846447};\\\", \\\"{x:427,y:535,t:1526667846463};\\\", \\\"{x:414,y:543,t:1526667846481};\\\", \\\"{x:398,y:552,t:1526667846499};\\\", \\\"{x:382,y:559,t:1526667846513};\\\", \\\"{x:371,y:566,t:1526667846530};\\\", \\\"{x:360,y:572,t:1526667846547};\\\", \\\"{x:354,y:576,t:1526667846563};\\\", \\\"{x:347,y:580,t:1526667846579};\\\", \\\"{x:350,y:578,t:1526667846643};\\\", \\\"{x:356,y:575,t:1526667846651};\\\", \\\"{x:358,y:574,t:1526667846663};\\\", \\\"{x:364,y:563,t:1526667846680};\\\", \\\"{x:369,y:555,t:1526667846697};\\\", \\\"{x:372,y:548,t:1526667846713};\\\", \\\"{x:374,y:546,t:1526667846730};\\\", \\\"{x:377,y:543,t:1526667846746};\\\", \\\"{x:378,y:540,t:1526667846763};\\\", \\\"{x:379,y:540,t:1526667846780};\\\", \\\"{x:380,y:538,t:1526667846797};\\\", \\\"{x:381,y:536,t:1526667846814};\\\", \\\"{x:383,y:534,t:1526667846830};\\\", \\\"{x:383,y:533,t:1526667846846};\\\", \\\"{x:383,y:532,t:1526667846923};\\\", \\\"{x:383,y:531,t:1526667846931};\\\", \\\"{x:383,y:530,t:1526667846947};\\\", \\\"{x:383,y:529,t:1526667846962};\\\", \\\"{x:385,y:528,t:1526667846979};\\\", \\\"{x:387,y:525,t:1526667846997};\\\", \\\"{x:389,y:524,t:1526667847013};\\\", \\\"{x:391,y:522,t:1526667847030};\\\", \\\"{x:391,y:521,t:1526667847046};\\\", \\\"{x:392,y:521,t:1526667847063};\\\", \\\"{x:393,y:521,t:1526667847231};\\\", \\\"{x:394,y:525,t:1526667847246};\\\", \\\"{x:395,y:530,t:1526667847264};\\\", \\\"{x:396,y:536,t:1526667847280};\\\", \\\"{x:396,y:540,t:1526667847296};\\\", \\\"{x:397,y:542,t:1526667847313};\\\", \\\"{x:397,y:545,t:1526667847330};\\\", \\\"{x:397,y:548,t:1526667847346};\\\", \\\"{x:398,y:548,t:1526667847363};\\\", \\\"{x:398,y:551,t:1526667847642};\\\", \\\"{x:403,y:562,t:1526667847651};\\\", \\\"{x:408,y:568,t:1526667847663};\\\", \\\"{x:424,y:592,t:1526667847681};\\\", \\\"{x:440,y:615,t:1526667847698};\\\", \\\"{x:453,y:635,t:1526667847713};\\\", \\\"{x:464,y:652,t:1526667847731};\\\", \\\"{x:473,y:663,t:1526667847747};\\\", \\\"{x:485,y:675,t:1526667847764};\\\", \\\"{x:490,y:685,t:1526667847780};\\\", \\\"{x:494,y:689,t:1526667847798};\\\", \\\"{x:494,y:690,t:1526667847813};\\\", \\\"{x:494,y:692,t:1526667847947};\\\", \\\"{x:496,y:696,t:1526667847963};\\\", \\\"{x:497,y:700,t:1526667847981};\\\", \\\"{x:498,y:704,t:1526667847998};\\\", \\\"{x:499,y:706,t:1526667848014};\\\", \\\"{x:500,y:707,t:1526667848059};\\\", \\\"{x:500,y:708,t:1526667848066};\\\", \\\"{x:501,y:709,t:1526667848081};\\\", \\\"{x:501,y:710,t:1526667848097};\\\", \\\"{x:501,y:711,t:1526667848195};\\\", \\\"{x:502,y:711,t:1526667848203};\\\", \\\"{x:502,y:711,t:1526667848298};\\\", \\\"{x:501,y:709,t:1526667849004};\\\", \\\"{x:500,y:707,t:1526667849015};\\\", \\\"{x:498,y:705,t:1526667849032};\\\", \\\"{x:497,y:703,t:1526667849048};\\\", \\\"{x:495,y:701,t:1526667849065};\\\", \\\"{x:493,y:700,t:1526667849082};\\\", \\\"{x:492,y:699,t:1526667849099};\\\", \\\"{x:490,y:697,t:1526667849115};\\\", \\\"{x:489,y:696,t:1526667849212};\\\" ] }, { \\\"rt\\\": 12576, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 93465, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:693,t:1526667851629};\\\", \\\"{x:483,y:690,t:1526667851640};\\\", \\\"{x:476,y:685,t:1526667851650};\\\", \\\"{x:461,y:674,t:1526667851667};\\\", \\\"{x:448,y:667,t:1526667851684};\\\", \\\"{x:434,y:657,t:1526667851701};\\\", \\\"{x:419,y:646,t:1526667851718};\\\", \\\"{x:401,y:634,t:1526667851734};\\\", \\\"{x:387,y:622,t:1526667851751};\\\", \\\"{x:375,y:612,t:1526667851768};\\\", \\\"{x:364,y:599,t:1526667851783};\\\", \\\"{x:355,y:585,t:1526667851801};\\\", \\\"{x:351,y:579,t:1526667851817};\\\", \\\"{x:346,y:571,t:1526667851834};\\\", \\\"{x:341,y:560,t:1526667851851};\\\", \\\"{x:341,y:558,t:1526667851866};\\\", \\\"{x:335,y:541,t:1526667851884};\\\", \\\"{x:332,y:531,t:1526667851901};\\\", \\\"{x:329,y:515,t:1526667851916};\\\", \\\"{x:325,y:503,t:1526667851934};\\\", \\\"{x:323,y:493,t:1526667851950};\\\", \\\"{x:323,y:482,t:1526667851966};\\\", \\\"{x:323,y:479,t:1526667851984};\\\", \\\"{x:330,y:478,t:1526667852000};\\\", \\\"{x:341,y:477,t:1526667852017};\\\", \\\"{x:342,y:475,t:1526667852033};\\\", \\\"{x:342,y:473,t:1526667852188};\\\", \\\"{x:343,y:472,t:1526667852201};\\\", \\\"{x:345,y:472,t:1526667852218};\\\", \\\"{x:347,y:471,t:1526667852233};\\\", \\\"{x:350,y:470,t:1526667852251};\\\", \\\"{x:360,y:467,t:1526667852267};\\\", \\\"{x:383,y:460,t:1526667852284};\\\", \\\"{x:400,y:454,t:1526667852301};\\\", \\\"{x:410,y:453,t:1526667852318};\\\", \\\"{x:423,y:451,t:1526667852334};\\\", \\\"{x:432,y:450,t:1526667852351};\\\", \\\"{x:443,y:448,t:1526667852368};\\\", \\\"{x:449,y:446,t:1526667852384};\\\", \\\"{x:451,y:445,t:1526667852401};\\\", \\\"{x:452,y:445,t:1526667852428};\\\", \\\"{x:453,y:445,t:1526667852435};\\\", \\\"{x:456,y:445,t:1526667852452};\\\", \\\"{x:469,y:441,t:1526667852468};\\\", \\\"{x:490,y:433,t:1526667852484};\\\", \\\"{x:514,y:433,t:1526667852501};\\\", \\\"{x:537,y:444,t:1526667852518};\\\", \\\"{x:566,y:461,t:1526667852535};\\\", \\\"{x:596,y:478,t:1526667852552};\\\", \\\"{x:632,y:501,t:1526667852569};\\\", \\\"{x:657,y:518,t:1526667852586};\\\", \\\"{x:674,y:530,t:1526667852601};\\\", \\\"{x:690,y:541,t:1526667852618};\\\", \\\"{x:703,y:547,t:1526667852635};\\\", \\\"{x:711,y:550,t:1526667852651};\\\", \\\"{x:712,y:550,t:1526667852668};\\\", \\\"{x:714,y:550,t:1526667852748};\\\", \\\"{x:717,y:550,t:1526667852755};\\\", \\\"{x:720,y:550,t:1526667852768};\\\", \\\"{x:728,y:550,t:1526667852786};\\\", \\\"{x:734,y:550,t:1526667852801};\\\", \\\"{x:742,y:552,t:1526667852818};\\\", \\\"{x:752,y:558,t:1526667852835};\\\", \\\"{x:756,y:561,t:1526667852851};\\\", \\\"{x:757,y:564,t:1526667852868};\\\", \\\"{x:759,y:566,t:1526667852885};\\\", \\\"{x:759,y:570,t:1526667852901};\\\", \\\"{x:760,y:571,t:1526667852918};\\\", \\\"{x:761,y:572,t:1526667852934};\\\", \\\"{x:761,y:573,t:1526667853844};\\\", \\\"{x:761,y:576,t:1526667853853};\\\", \\\"{x:782,y:599,t:1526667853869};\\\", \\\"{x:831,y:637,t:1526667853887};\\\", \\\"{x:915,y:678,t:1526667853902};\\\", \\\"{x:1002,y:713,t:1526667853919};\\\", \\\"{x:1107,y:739,t:1526667853936};\\\", \\\"{x:1214,y:765,t:1526667853952};\\\", \\\"{x:1333,y:780,t:1526667853969};\\\", \\\"{x:1454,y:788,t:1526667853986};\\\", \\\"{x:1557,y:790,t:1526667854002};\\\", \\\"{x:1695,y:790,t:1526667854019};\\\", \\\"{x:1748,y:790,t:1526667854035};\\\", \\\"{x:1774,y:790,t:1526667854052};\\\", \\\"{x:1778,y:790,t:1526667854069};\\\", \\\"{x:1777,y:788,t:1526667854180};\\\", \\\"{x:1771,y:787,t:1526667854188};\\\", \\\"{x:1762,y:784,t:1526667854202};\\\", \\\"{x:1702,y:769,t:1526667854220};\\\", \\\"{x:1633,y:751,t:1526667854235};\\\", \\\"{x:1559,y:743,t:1526667854253};\\\", \\\"{x:1491,y:732,t:1526667854269};\\\", \\\"{x:1436,y:724,t:1526667854287};\\\", \\\"{x:1395,y:723,t:1526667854303};\\\", \\\"{x:1363,y:720,t:1526667854319};\\\", \\\"{x:1338,y:720,t:1526667854337};\\\", \\\"{x:1322,y:719,t:1526667854353};\\\", \\\"{x:1314,y:719,t:1526667854370};\\\", \\\"{x:1309,y:717,t:1526667854386};\\\", \\\"{x:1308,y:716,t:1526667854403};\\\", \\\"{x:1307,y:716,t:1526667854420};\\\", \\\"{x:1306,y:715,t:1526667854540};\\\", \\\"{x:1306,y:711,t:1526667854554};\\\", \\\"{x:1307,y:705,t:1526667854569};\\\", \\\"{x:1311,y:696,t:1526667854586};\\\", \\\"{x:1318,y:679,t:1526667854604};\\\", \\\"{x:1323,y:666,t:1526667854620};\\\", \\\"{x:1333,y:652,t:1526667854637};\\\", \\\"{x:1342,y:639,t:1526667854654};\\\", \\\"{x:1351,y:625,t:1526667854669};\\\", \\\"{x:1359,y:613,t:1526667854687};\\\", \\\"{x:1369,y:602,t:1526667854703};\\\", \\\"{x:1374,y:593,t:1526667854719};\\\", \\\"{x:1379,y:586,t:1526667854736};\\\", \\\"{x:1382,y:581,t:1526667854754};\\\", \\\"{x:1382,y:578,t:1526667854770};\\\", \\\"{x:1384,y:574,t:1526667854786};\\\", \\\"{x:1386,y:567,t:1526667854804};\\\", \\\"{x:1389,y:559,t:1526667854820};\\\", \\\"{x:1390,y:554,t:1526667854836};\\\", \\\"{x:1392,y:549,t:1526667854854};\\\", \\\"{x:1393,y:544,t:1526667854870};\\\", \\\"{x:1396,y:539,t:1526667854886};\\\", \\\"{x:1397,y:537,t:1526667854904};\\\", \\\"{x:1398,y:535,t:1526667854920};\\\", \\\"{x:1398,y:532,t:1526667854936};\\\", \\\"{x:1399,y:529,t:1526667854953};\\\", \\\"{x:1400,y:527,t:1526667854970};\\\", \\\"{x:1400,y:525,t:1526667854985};\\\", \\\"{x:1403,y:517,t:1526667855003};\\\", \\\"{x:1404,y:512,t:1526667855020};\\\", \\\"{x:1407,y:504,t:1526667855035};\\\", \\\"{x:1408,y:498,t:1526667855052};\\\", \\\"{x:1411,y:490,t:1526667855070};\\\", \\\"{x:1412,y:486,t:1526667855086};\\\", \\\"{x:1413,y:481,t:1526667855103};\\\", \\\"{x:1416,y:476,t:1526667855121};\\\", \\\"{x:1416,y:474,t:1526667855136};\\\", \\\"{x:1419,y:470,t:1526667855154};\\\", \\\"{x:1419,y:468,t:1526667855171};\\\", \\\"{x:1420,y:467,t:1526667855187};\\\", \\\"{x:1423,y:466,t:1526667855204};\\\", \\\"{x:1425,y:466,t:1526667855220};\\\", \\\"{x:1427,y:464,t:1526667855237};\\\", \\\"{x:1429,y:464,t:1526667855254};\\\", \\\"{x:1433,y:462,t:1526667855271};\\\", \\\"{x:1438,y:461,t:1526667855287};\\\", \\\"{x:1443,y:459,t:1526667855303};\\\", \\\"{x:1450,y:456,t:1526667855320};\\\", \\\"{x:1456,y:455,t:1526667855337};\\\", \\\"{x:1461,y:455,t:1526667855353};\\\", \\\"{x:1468,y:455,t:1526667855370};\\\", \\\"{x:1480,y:456,t:1526667855387};\\\", \\\"{x:1491,y:459,t:1526667855403};\\\", \\\"{x:1505,y:462,t:1526667855420};\\\", \\\"{x:1515,y:463,t:1526667855437};\\\", \\\"{x:1522,y:463,t:1526667855453};\\\", \\\"{x:1529,y:464,t:1526667855470};\\\", \\\"{x:1541,y:464,t:1526667855487};\\\", \\\"{x:1551,y:464,t:1526667855504};\\\", \\\"{x:1556,y:464,t:1526667855520};\\\", \\\"{x:1557,y:464,t:1526667855537};\\\", \\\"{x:1559,y:464,t:1526667855563};\\\", \\\"{x:1560,y:461,t:1526667855636};\\\", \\\"{x:1562,y:454,t:1526667855653};\\\", \\\"{x:1570,y:440,t:1526667855670};\\\", \\\"{x:1581,y:426,t:1526667855688};\\\", \\\"{x:1600,y:414,t:1526667855703};\\\", \\\"{x:1615,y:404,t:1526667855721};\\\", \\\"{x:1627,y:398,t:1526667855737};\\\", \\\"{x:1631,y:395,t:1526667855753};\\\", \\\"{x:1632,y:395,t:1526667855771};\\\", \\\"{x:1636,y:393,t:1526667855787};\\\", \\\"{x:1637,y:392,t:1526667855804};\\\", \\\"{x:1639,y:392,t:1526667855821};\\\", \\\"{x:1637,y:392,t:1526667855908};\\\", \\\"{x:1634,y:393,t:1526667855920};\\\", \\\"{x:1627,y:397,t:1526667855937};\\\", \\\"{x:1621,y:402,t:1526667855954};\\\", \\\"{x:1620,y:405,t:1526667855970};\\\", \\\"{x:1618,y:408,t:1526667855987};\\\", \\\"{x:1617,y:409,t:1526667856004};\\\", \\\"{x:1616,y:410,t:1526667856020};\\\", \\\"{x:1616,y:412,t:1526667856189};\\\", \\\"{x:1616,y:416,t:1526667856204};\\\", \\\"{x:1616,y:419,t:1526667856220};\\\", \\\"{x:1616,y:420,t:1526667856237};\\\", \\\"{x:1616,y:421,t:1526667856254};\\\", \\\"{x:1616,y:422,t:1526667856324};\\\", \\\"{x:1616,y:423,t:1526667856340};\\\", \\\"{x:1616,y:424,t:1526667856355};\\\", \\\"{x:1615,y:427,t:1526667856374};\\\", \\\"{x:1615,y:429,t:1526667856386};\\\", \\\"{x:1615,y:431,t:1526667856404};\\\", \\\"{x:1615,y:432,t:1526667856427};\\\", \\\"{x:1614,y:433,t:1526667857091};\\\", \\\"{x:1613,y:433,t:1526667857105};\\\", \\\"{x:1611,y:434,t:1526667857121};\\\", \\\"{x:1611,y:435,t:1526667857139};\\\", \\\"{x:1609,y:435,t:1526667857155};\\\", \\\"{x:1608,y:436,t:1526667857172};\\\", \\\"{x:1608,y:435,t:1526667857467};\\\", \\\"{x:1608,y:434,t:1526667857483};\\\", \\\"{x:1608,y:433,t:1526667857491};\\\", \\\"{x:1608,y:432,t:1526667857505};\\\", \\\"{x:1608,y:431,t:1526667857521};\\\", \\\"{x:1608,y:430,t:1526667857538};\\\", \\\"{x:1609,y:428,t:1526667857555};\\\", \\\"{x:1610,y:428,t:1526667857571};\\\", \\\"{x:1611,y:427,t:1526667857588};\\\", \\\"{x:1612,y:426,t:1526667857628};\\\", \\\"{x:1609,y:427,t:1526667858580};\\\", \\\"{x:1599,y:430,t:1526667858591};\\\", \\\"{x:1578,y:439,t:1526667858606};\\\", \\\"{x:1552,y:450,t:1526667858623};\\\", \\\"{x:1522,y:462,t:1526667858639};\\\", \\\"{x:1457,y:486,t:1526667858656};\\\", \\\"{x:1327,y:523,t:1526667858673};\\\", \\\"{x:1157,y:563,t:1526667858690};\\\", \\\"{x:992,y:601,t:1526667858706};\\\", \\\"{x:848,y:640,t:1526667858723};\\\", \\\"{x:627,y:703,t:1526667858740};\\\", \\\"{x:506,y:737,t:1526667858756};\\\", \\\"{x:417,y:760,t:1526667858773};\\\", \\\"{x:370,y:774,t:1526667858789};\\\", \\\"{x:338,y:780,t:1526667858806};\\\", \\\"{x:334,y:781,t:1526667858822};\\\", \\\"{x:333,y:780,t:1526667858892};\\\", \\\"{x:333,y:775,t:1526667858907};\\\", \\\"{x:328,y:762,t:1526667858922};\\\", \\\"{x:321,y:746,t:1526667858940};\\\", \\\"{x:321,y:736,t:1526667858956};\\\", \\\"{x:327,y:717,t:1526667858973};\\\", \\\"{x:337,y:701,t:1526667858990};\\\", \\\"{x:346,y:691,t:1526667859006};\\\", \\\"{x:352,y:682,t:1526667859022};\\\", \\\"{x:357,y:676,t:1526667859039};\\\", \\\"{x:362,y:670,t:1526667859056};\\\", \\\"{x:375,y:659,t:1526667859072};\\\", \\\"{x:386,y:652,t:1526667859089};\\\", \\\"{x:395,y:645,t:1526667859106};\\\", \\\"{x:411,y:631,t:1526667859123};\\\", \\\"{x:420,y:627,t:1526667859139};\\\", \\\"{x:430,y:621,t:1526667859156};\\\", \\\"{x:445,y:615,t:1526667859174};\\\", \\\"{x:452,y:611,t:1526667859190};\\\", \\\"{x:457,y:609,t:1526667859206};\\\", \\\"{x:465,y:606,t:1526667859223};\\\", \\\"{x:480,y:599,t:1526667859240};\\\", \\\"{x:499,y:594,t:1526667859257};\\\", \\\"{x:515,y:590,t:1526667859274};\\\", \\\"{x:526,y:585,t:1526667859290};\\\", \\\"{x:531,y:583,t:1526667859306};\\\", \\\"{x:535,y:582,t:1526667859322};\\\", \\\"{x:537,y:580,t:1526667859340};\\\", \\\"{x:539,y:580,t:1526667859356};\\\", \\\"{x:540,y:579,t:1526667859373};\\\", \\\"{x:541,y:578,t:1526667859390};\\\", \\\"{x:546,y:576,t:1526667859406};\\\", \\\"{x:549,y:575,t:1526667859423};\\\", \\\"{x:553,y:572,t:1526667859441};\\\", \\\"{x:556,y:569,t:1526667859456};\\\", \\\"{x:560,y:566,t:1526667859473};\\\", \\\"{x:566,y:563,t:1526667859490};\\\", \\\"{x:569,y:561,t:1526667859507};\\\", \\\"{x:572,y:558,t:1526667859523};\\\", \\\"{x:575,y:557,t:1526667859540};\\\", \\\"{x:578,y:556,t:1526667859557};\\\", \\\"{x:584,y:552,t:1526667859573};\\\", \\\"{x:591,y:550,t:1526667859590};\\\", \\\"{x:602,y:545,t:1526667859607};\\\", \\\"{x:610,y:541,t:1526667859624};\\\", \\\"{x:614,y:540,t:1526667859641};\\\", \\\"{x:621,y:538,t:1526667859657};\\\", \\\"{x:633,y:535,t:1526667859674};\\\", \\\"{x:646,y:532,t:1526667859690};\\\", \\\"{x:657,y:532,t:1526667859707};\\\", \\\"{x:666,y:532,t:1526667859723};\\\", \\\"{x:674,y:532,t:1526667859740};\\\", \\\"{x:690,y:534,t:1526667859757};\\\", \\\"{x:709,y:538,t:1526667859774};\\\", \\\"{x:730,y:543,t:1526667859790};\\\", \\\"{x:751,y:547,t:1526667859808};\\\", \\\"{x:768,y:549,t:1526667859823};\\\", \\\"{x:783,y:552,t:1526667859840};\\\", \\\"{x:798,y:555,t:1526667859858};\\\", \\\"{x:809,y:559,t:1526667859873};\\\", \\\"{x:816,y:562,t:1526667859890};\\\", \\\"{x:817,y:563,t:1526667859907};\\\", \\\"{x:817,y:565,t:1526667860260};\\\", \\\"{x:813,y:567,t:1526667860275};\\\", \\\"{x:801,y:573,t:1526667860291};\\\", \\\"{x:779,y:589,t:1526667860309};\\\", \\\"{x:768,y:599,t:1526667860324};\\\", \\\"{x:753,y:612,t:1526667860340};\\\", \\\"{x:739,y:624,t:1526667860358};\\\", \\\"{x:725,y:637,t:1526667860374};\\\", \\\"{x:712,y:650,t:1526667860390};\\\", \\\"{x:702,y:655,t:1526667860407};\\\", \\\"{x:692,y:661,t:1526667860424};\\\", \\\"{x:681,y:667,t:1526667860440};\\\", \\\"{x:673,y:671,t:1526667860457};\\\", \\\"{x:667,y:674,t:1526667860474};\\\", \\\"{x:661,y:678,t:1526667860490};\\\", \\\"{x:654,y:680,t:1526667860507};\\\", \\\"{x:651,y:681,t:1526667860524};\\\", \\\"{x:649,y:682,t:1526667860541};\\\", \\\"{x:648,y:683,t:1526667860580};\\\", \\\"{x:647,y:683,t:1526667860596};\\\", \\\"{x:646,y:683,t:1526667860607};\\\", \\\"{x:644,y:685,t:1526667860624};\\\", \\\"{x:638,y:685,t:1526667860641};\\\", \\\"{x:634,y:686,t:1526667860658};\\\", \\\"{x:626,y:690,t:1526667860674};\\\", \\\"{x:615,y:695,t:1526667860691};\\\", \\\"{x:607,y:699,t:1526667860708};\\\", \\\"{x:610,y:700,t:1526667860748};\\\", \\\"{x:624,y:696,t:1526667860757};\\\", \\\"{x:676,y:675,t:1526667860774};\\\", \\\"{x:730,y:646,t:1526667860790};\\\", \\\"{x:785,y:614,t:1526667860807};\\\", \\\"{x:833,y:581,t:1526667860824};\\\", \\\"{x:862,y:558,t:1526667860840};\\\", \\\"{x:878,y:546,t:1526667860858};\\\", \\\"{x:882,y:543,t:1526667860875};\\\", \\\"{x:881,y:543,t:1526667861004};\\\", \\\"{x:880,y:543,t:1526667861012};\\\", \\\"{x:879,y:543,t:1526667861024};\\\", \\\"{x:875,y:543,t:1526667861041};\\\", \\\"{x:869,y:543,t:1526667861058};\\\", \\\"{x:862,y:544,t:1526667861074};\\\", \\\"{x:854,y:550,t:1526667861091};\\\", \\\"{x:850,y:553,t:1526667861107};\\\", \\\"{x:848,y:554,t:1526667861124};\\\", \\\"{x:847,y:555,t:1526667861142};\\\", \\\"{x:847,y:556,t:1526667861427};\\\", \\\"{x:843,y:563,t:1526667861441};\\\", \\\"{x:826,y:582,t:1526667861459};\\\", \\\"{x:785,y:615,t:1526667861475};\\\", \\\"{x:737,y:648,t:1526667861491};\\\", \\\"{x:678,y:679,t:1526667861508};\\\", \\\"{x:626,y:711,t:1526667861525};\\\", \\\"{x:591,y:729,t:1526667861541};\\\", \\\"{x:574,y:736,t:1526667861558};\\\", \\\"{x:573,y:736,t:1526667861575};\\\", \\\"{x:572,y:736,t:1526667861756};\\\", \\\"{x:572,y:734,t:1526667861771};\\\", \\\"{x:572,y:733,t:1526667861779};\\\", \\\"{x:572,y:732,t:1526667861796};\\\", \\\"{x:572,y:731,t:1526667861809};\\\", \\\"{x:572,y:729,t:1526667861826};\\\", \\\"{x:572,y:727,t:1526667861842};\\\", \\\"{x:571,y:726,t:1526667861892};\\\", \\\"{x:564,y:726,t:1526667861910};\\\", \\\"{x:557,y:726,t:1526667861925};\\\", \\\"{x:554,y:726,t:1526667861942};\\\", \\\"{x:552,y:726,t:1526667861959};\\\", \\\"{x:551,y:726,t:1526667862060};\\\", \\\"{x:551,y:726,t:1526667862199};\\\" ] }, { \\\"rt\\\": 39226, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 134021, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:726,t:1526667864836};\\\", \\\"{x:529,y:728,t:1526667864845};\\\", \\\"{x:454,y:739,t:1526667864862};\\\", \\\"{x:386,y:744,t:1526667864879};\\\", \\\"{x:344,y:744,t:1526667864895};\\\", \\\"{x:288,y:744,t:1526667864912};\\\", \\\"{x:216,y:739,t:1526667864928};\\\", \\\"{x:150,y:730,t:1526667864944};\\\", \\\"{x:118,y:719,t:1526667864962};\\\", \\\"{x:109,y:713,t:1526667864979};\\\", \\\"{x:109,y:701,t:1526667864995};\\\", \\\"{x:132,y:671,t:1526667865011};\\\", \\\"{x:158,y:650,t:1526667865030};\\\", \\\"{x:182,y:628,t:1526667865045};\\\", \\\"{x:201,y:607,t:1526667865062};\\\", \\\"{x:230,y:584,t:1526667865078};\\\", \\\"{x:265,y:556,t:1526667865095};\\\", \\\"{x:311,y:531,t:1526667865111};\\\", \\\"{x:371,y:495,t:1526667865127};\\\", \\\"{x:428,y:473,t:1526667865144};\\\", \\\"{x:492,y:454,t:1526667865161};\\\", \\\"{x:563,y:440,t:1526667865179};\\\", \\\"{x:636,y:429,t:1526667865195};\\\", \\\"{x:747,y:429,t:1526667865211};\\\", \\\"{x:825,y:429,t:1526667865228};\\\", \\\"{x:902,y:429,t:1526667865245};\\\", \\\"{x:970,y:430,t:1526667865262};\\\", \\\"{x:1029,y:433,t:1526667865278};\\\", \\\"{x:1083,y:441,t:1526667865294};\\\", \\\"{x:1136,y:451,t:1526667865312};\\\", \\\"{x:1174,y:463,t:1526667865329};\\\", \\\"{x:1201,y:469,t:1526667865345};\\\", \\\"{x:1225,y:473,t:1526667865362};\\\", \\\"{x:1240,y:478,t:1526667865379};\\\", \\\"{x:1248,y:480,t:1526667865395};\\\", \\\"{x:1263,y:488,t:1526667865412};\\\", \\\"{x:1279,y:494,t:1526667865428};\\\", \\\"{x:1292,y:498,t:1526667865444};\\\", \\\"{x:1309,y:506,t:1526667865462};\\\", \\\"{x:1325,y:511,t:1526667865479};\\\", \\\"{x:1346,y:517,t:1526667865494};\\\", \\\"{x:1363,y:522,t:1526667865511};\\\", \\\"{x:1379,y:524,t:1526667865529};\\\", \\\"{x:1386,y:526,t:1526667865544};\\\", \\\"{x:1393,y:529,t:1526667865561};\\\", \\\"{x:1402,y:533,t:1526667865579};\\\", \\\"{x:1410,y:538,t:1526667865595};\\\", \\\"{x:1422,y:545,t:1526667865612};\\\", \\\"{x:1429,y:550,t:1526667865628};\\\", \\\"{x:1436,y:558,t:1526667865645};\\\", \\\"{x:1444,y:568,t:1526667865662};\\\", \\\"{x:1451,y:577,t:1526667865678};\\\", \\\"{x:1454,y:581,t:1526667865696};\\\", \\\"{x:1458,y:588,t:1526667865712};\\\", \\\"{x:1460,y:591,t:1526667865729};\\\", \\\"{x:1461,y:594,t:1526667865746};\\\", \\\"{x:1461,y:595,t:1526667865762};\\\", \\\"{x:1462,y:595,t:1526667865780};\\\", \\\"{x:1463,y:598,t:1526667865795};\\\", \\\"{x:1463,y:606,t:1526667865812};\\\", \\\"{x:1463,y:612,t:1526667865829};\\\", \\\"{x:1463,y:618,t:1526667865846};\\\", \\\"{x:1462,y:625,t:1526667865862};\\\", \\\"{x:1460,y:631,t:1526667865879};\\\", \\\"{x:1457,y:639,t:1526667865896};\\\", \\\"{x:1454,y:648,t:1526667865912};\\\", \\\"{x:1452,y:655,t:1526667865929};\\\", \\\"{x:1452,y:660,t:1526667865946};\\\", \\\"{x:1449,y:665,t:1526667865963};\\\", \\\"{x:1448,y:669,t:1526667865980};\\\", \\\"{x:1446,y:673,t:1526667865996};\\\", \\\"{x:1446,y:674,t:1526667866012};\\\", \\\"{x:1445,y:676,t:1526667866029};\\\", \\\"{x:1444,y:677,t:1526667866853};\\\", \\\"{x:1443,y:678,t:1526667866863};\\\", \\\"{x:1434,y:682,t:1526667866880};\\\", \\\"{x:1420,y:694,t:1526667866897};\\\", \\\"{x:1405,y:708,t:1526667866913};\\\", \\\"{x:1388,y:733,t:1526667866931};\\\", \\\"{x:1364,y:767,t:1526667866947};\\\", \\\"{x:1324,y:822,t:1526667866964};\\\", \\\"{x:1300,y:856,t:1526667866979};\\\", \\\"{x:1278,y:887,t:1526667866997};\\\", \\\"{x:1260,y:913,t:1526667867013};\\\", \\\"{x:1247,y:933,t:1526667867030};\\\", \\\"{x:1235,y:949,t:1526667867047};\\\", \\\"{x:1227,y:960,t:1526667867064};\\\", \\\"{x:1223,y:968,t:1526667867080};\\\", \\\"{x:1221,y:972,t:1526667867096};\\\", \\\"{x:1220,y:973,t:1526667867114};\\\", \\\"{x:1220,y:974,t:1526667867171};\\\", \\\"{x:1218,y:973,t:1526667867820};\\\", \\\"{x:1216,y:970,t:1526667867831};\\\", \\\"{x:1213,y:964,t:1526667867849};\\\", \\\"{x:1211,y:960,t:1526667867865};\\\", \\\"{x:1210,y:958,t:1526667867881};\\\", \\\"{x:1208,y:954,t:1526667867898};\\\", \\\"{x:1205,y:949,t:1526667867915};\\\", \\\"{x:1205,y:946,t:1526667867931};\\\", \\\"{x:1203,y:943,t:1526667867948};\\\", \\\"{x:1202,y:941,t:1526667867965};\\\", \\\"{x:1201,y:939,t:1526667867981};\\\", \\\"{x:1201,y:936,t:1526667867998};\\\", \\\"{x:1199,y:933,t:1526667868014};\\\", \\\"{x:1199,y:928,t:1526667868031};\\\", \\\"{x:1197,y:921,t:1526667868048};\\\", \\\"{x:1193,y:911,t:1526667868064};\\\", \\\"{x:1190,y:889,t:1526667868081};\\\", \\\"{x:1188,y:867,t:1526667868098};\\\", \\\"{x:1183,y:842,t:1526667868113};\\\", \\\"{x:1180,y:823,t:1526667868130};\\\", \\\"{x:1172,y:801,t:1526667868147};\\\", \\\"{x:1171,y:792,t:1526667868163};\\\", \\\"{x:1169,y:785,t:1526667868180};\\\", \\\"{x:1168,y:780,t:1526667868198};\\\", \\\"{x:1168,y:778,t:1526667868215};\\\", \\\"{x:1167,y:777,t:1526667868230};\\\", \\\"{x:1167,y:775,t:1526667868248};\\\", \\\"{x:1167,y:774,t:1526667868265};\\\", \\\"{x:1167,y:772,t:1526667868280};\\\", \\\"{x:1166,y:768,t:1526667868298};\\\", \\\"{x:1164,y:755,t:1526667868315};\\\", \\\"{x:1163,y:751,t:1526667868331};\\\", \\\"{x:1163,y:744,t:1526667868347};\\\", \\\"{x:1159,y:688,t:1526667868365};\\\", \\\"{x:1157,y:644,t:1526667868380};\\\", \\\"{x:1152,y:614,t:1526667868398};\\\", \\\"{x:1147,y:585,t:1526667868415};\\\", \\\"{x:1145,y:568,t:1526667868431};\\\", \\\"{x:1144,y:554,t:1526667868448};\\\", \\\"{x:1141,y:545,t:1526667868466};\\\", \\\"{x:1141,y:537,t:1526667868481};\\\", \\\"{x:1141,y:531,t:1526667868498};\\\", \\\"{x:1141,y:523,t:1526667868516};\\\", \\\"{x:1141,y:519,t:1526667868531};\\\", \\\"{x:1144,y:508,t:1526667868548};\\\", \\\"{x:1146,y:506,t:1526667868565};\\\", \\\"{x:1149,y:500,t:1526667868582};\\\", \\\"{x:1155,y:493,t:1526667868598};\\\", \\\"{x:1170,y:486,t:1526667868615};\\\", \\\"{x:1191,y:479,t:1526667868632};\\\", \\\"{x:1220,y:469,t:1526667868647};\\\", \\\"{x:1245,y:464,t:1526667868665};\\\", \\\"{x:1266,y:457,t:1526667868682};\\\", \\\"{x:1291,y:450,t:1526667868698};\\\", \\\"{x:1337,y:444,t:1526667868716};\\\", \\\"{x:1378,y:441,t:1526667868732};\\\", \\\"{x:1423,y:441,t:1526667868748};\\\", \\\"{x:1465,y:441,t:1526667868765};\\\", \\\"{x:1504,y:441,t:1526667868782};\\\", \\\"{x:1541,y:441,t:1526667868798};\\\", \\\"{x:1580,y:441,t:1526667868815};\\\", \\\"{x:1633,y:441,t:1526667868832};\\\", \\\"{x:1678,y:441,t:1526667868848};\\\", \\\"{x:1708,y:440,t:1526667868865};\\\", \\\"{x:1731,y:440,t:1526667868882};\\\", \\\"{x:1745,y:439,t:1526667868898};\\\", \\\"{x:1746,y:438,t:1526667868915};\\\", \\\"{x:1747,y:438,t:1526667868988};\\\", \\\"{x:1747,y:437,t:1526667868999};\\\", \\\"{x:1747,y:435,t:1526667869139};\\\", \\\"{x:1746,y:433,t:1526667869149};\\\", \\\"{x:1743,y:430,t:1526667869165};\\\", \\\"{x:1738,y:429,t:1526667869182};\\\", \\\"{x:1735,y:427,t:1526667869198};\\\", \\\"{x:1734,y:427,t:1526667869323};\\\", \\\"{x:1732,y:427,t:1526667869339};\\\", \\\"{x:1731,y:427,t:1526667869349};\\\", \\\"{x:1730,y:434,t:1526667869366};\\\", \\\"{x:1729,y:450,t:1526667869382};\\\", \\\"{x:1729,y:472,t:1526667869399};\\\", \\\"{x:1729,y:493,t:1526667869417};\\\", \\\"{x:1729,y:520,t:1526667869432};\\\", \\\"{x:1729,y:545,t:1526667869449};\\\", \\\"{x:1729,y:571,t:1526667869466};\\\", \\\"{x:1727,y:595,t:1526667869481};\\\", \\\"{x:1724,y:628,t:1526667869499};\\\", \\\"{x:1723,y:649,t:1526667869515};\\\", \\\"{x:1721,y:664,t:1526667869532};\\\", \\\"{x:1719,y:679,t:1526667869549};\\\", \\\"{x:1716,y:692,t:1526667869566};\\\", \\\"{x:1715,y:699,t:1526667869582};\\\", \\\"{x:1715,y:706,t:1526667869599};\\\", \\\"{x:1714,y:713,t:1526667869615};\\\", \\\"{x:1712,y:721,t:1526667869632};\\\", \\\"{x:1711,y:729,t:1526667869649};\\\", \\\"{x:1707,y:741,t:1526667869666};\\\", \\\"{x:1706,y:749,t:1526667869682};\\\", \\\"{x:1702,y:759,t:1526667869699};\\\", \\\"{x:1700,y:770,t:1526667869716};\\\", \\\"{x:1697,y:779,t:1526667869733};\\\", \\\"{x:1696,y:785,t:1526667869749};\\\", \\\"{x:1694,y:789,t:1526667869766};\\\", \\\"{x:1693,y:793,t:1526667869783};\\\", \\\"{x:1690,y:797,t:1526667869799};\\\", \\\"{x:1689,y:800,t:1526667869816};\\\", \\\"{x:1686,y:805,t:1526667869833};\\\", \\\"{x:1682,y:811,t:1526667869849};\\\", \\\"{x:1671,y:822,t:1526667869867};\\\", \\\"{x:1658,y:833,t:1526667869883};\\\", \\\"{x:1648,y:842,t:1526667869899};\\\", \\\"{x:1633,y:852,t:1526667869916};\\\", \\\"{x:1622,y:859,t:1526667869933};\\\", \\\"{x:1611,y:866,t:1526667869949};\\\", \\\"{x:1603,y:870,t:1526667869966};\\\", \\\"{x:1597,y:873,t:1526667869983};\\\", \\\"{x:1590,y:877,t:1526667869999};\\\", \\\"{x:1583,y:881,t:1526667870016};\\\", \\\"{x:1575,y:886,t:1526667870033};\\\", \\\"{x:1563,y:893,t:1526667870049};\\\", \\\"{x:1548,y:898,t:1526667870066};\\\", \\\"{x:1523,y:905,t:1526667870083};\\\", \\\"{x:1504,y:910,t:1526667870100};\\\", \\\"{x:1489,y:912,t:1526667870115};\\\", \\\"{x:1472,y:914,t:1526667870133};\\\", \\\"{x:1453,y:914,t:1526667870150};\\\", \\\"{x:1435,y:914,t:1526667870165};\\\", \\\"{x:1416,y:914,t:1526667870182};\\\", \\\"{x:1404,y:913,t:1526667870200};\\\", \\\"{x:1392,y:912,t:1526667870216};\\\", \\\"{x:1386,y:910,t:1526667870232};\\\", \\\"{x:1376,y:908,t:1526667870249};\\\", \\\"{x:1368,y:907,t:1526667870266};\\\", \\\"{x:1350,y:905,t:1526667870283};\\\", \\\"{x:1336,y:903,t:1526667870299};\\\", \\\"{x:1327,y:901,t:1526667870316};\\\", \\\"{x:1317,y:900,t:1526667870333};\\\", \\\"{x:1311,y:899,t:1526667870350};\\\", \\\"{x:1306,y:899,t:1526667870366};\\\", \\\"{x:1296,y:896,t:1526667870383};\\\", \\\"{x:1282,y:895,t:1526667870400};\\\", \\\"{x:1267,y:891,t:1526667870416};\\\", \\\"{x:1251,y:888,t:1526667870433};\\\", \\\"{x:1236,y:884,t:1526667870450};\\\", \\\"{x:1226,y:880,t:1526667870466};\\\", \\\"{x:1216,y:878,t:1526667870484};\\\", \\\"{x:1214,y:876,t:1526667870500};\\\", \\\"{x:1210,y:875,t:1526667870517};\\\", \\\"{x:1205,y:870,t:1526667870533};\\\", \\\"{x:1198,y:864,t:1526667870550};\\\", \\\"{x:1193,y:859,t:1526667870567};\\\", \\\"{x:1192,y:858,t:1526667870583};\\\", \\\"{x:1192,y:857,t:1526667870684};\\\", \\\"{x:1192,y:856,t:1526667870700};\\\", \\\"{x:1195,y:853,t:1526667870717};\\\", \\\"{x:1199,y:852,t:1526667870733};\\\", \\\"{x:1203,y:849,t:1526667870750};\\\", \\\"{x:1204,y:849,t:1526667870767};\\\", \\\"{x:1205,y:848,t:1526667870783};\\\", \\\"{x:1207,y:848,t:1526667870804};\\\", \\\"{x:1210,y:845,t:1526667870819};\\\", \\\"{x:1211,y:845,t:1526667870833};\\\", \\\"{x:1215,y:843,t:1526667870851};\\\", \\\"{x:1219,y:841,t:1526667870868};\\\", \\\"{x:1221,y:839,t:1526667870884};\\\", \\\"{x:1222,y:838,t:1526667871435};\\\", \\\"{x:1220,y:835,t:1526667871450};\\\", \\\"{x:1218,y:834,t:1526667871468};\\\", \\\"{x:1217,y:833,t:1526667871484};\\\", \\\"{x:1216,y:832,t:1526667871500};\\\", \\\"{x:1215,y:831,t:1526667871531};\\\", \\\"{x:1214,y:830,t:1526667871571};\\\", \\\"{x:1213,y:830,t:1526667871932};\\\", \\\"{x:1211,y:830,t:1526667871947};\\\", \\\"{x:1210,y:829,t:1526667871955};\\\", \\\"{x:1209,y:829,t:1526667871969};\\\", \\\"{x:1208,y:828,t:1526667871986};\\\", \\\"{x:1207,y:828,t:1526667872002};\\\", \\\"{x:1206,y:828,t:1526667872018};\\\", \\\"{x:1197,y:826,t:1526667898830};\\\", \\\"{x:1169,y:816,t:1526667898845};\\\", \\\"{x:1028,y:794,t:1526667898862};\\\", \\\"{x:922,y:776,t:1526667898879};\\\", \\\"{x:822,y:761,t:1526667898895};\\\", \\\"{x:722,y:749,t:1526667898912};\\\", \\\"{x:628,y:735,t:1526667898930};\\\", \\\"{x:536,y:720,t:1526667898945};\\\", \\\"{x:450,y:709,t:1526667898962};\\\", \\\"{x:364,y:698,t:1526667898979};\\\", \\\"{x:297,y:689,t:1526667898992};\\\", \\\"{x:252,y:681,t:1526667899008};\\\", \\\"{x:208,y:669,t:1526667899025};\\\", \\\"{x:165,y:656,t:1526667899042};\\\", \\\"{x:141,y:644,t:1526667899060};\\\", \\\"{x:125,y:633,t:1526667899075};\\\", \\\"{x:117,y:626,t:1526667899092};\\\", \\\"{x:111,y:619,t:1526667899110};\\\", \\\"{x:107,y:610,t:1526667899126};\\\", \\\"{x:107,y:606,t:1526667899142};\\\", \\\"{x:107,y:599,t:1526667899158};\\\", \\\"{x:109,y:595,t:1526667899176};\\\", \\\"{x:112,y:591,t:1526667899193};\\\", \\\"{x:116,y:589,t:1526667899208};\\\", \\\"{x:129,y:582,t:1526667899225};\\\", \\\"{x:147,y:572,t:1526667899243};\\\", \\\"{x:159,y:568,t:1526667899259};\\\", \\\"{x:171,y:563,t:1526667899276};\\\", \\\"{x:183,y:559,t:1526667899292};\\\", \\\"{x:203,y:557,t:1526667899309};\\\", \\\"{x:244,y:557,t:1526667899326};\\\", \\\"{x:280,y:557,t:1526667899343};\\\", \\\"{x:309,y:558,t:1526667899359};\\\", \\\"{x:332,y:563,t:1526667899375};\\\", \\\"{x:345,y:567,t:1526667899393};\\\", \\\"{x:351,y:568,t:1526667899409};\\\", \\\"{x:356,y:572,t:1526667899425};\\\", \\\"{x:358,y:573,t:1526667899442};\\\", \\\"{x:359,y:575,t:1526667899459};\\\", \\\"{x:362,y:581,t:1526667899475};\\\", \\\"{x:366,y:592,t:1526667899493};\\\", \\\"{x:371,y:602,t:1526667899509};\\\", \\\"{x:376,y:614,t:1526667899526};\\\", \\\"{x:377,y:617,t:1526667899542};\\\", \\\"{x:377,y:619,t:1526667899559};\\\", \\\"{x:379,y:621,t:1526667899576};\\\", \\\"{x:381,y:625,t:1526667899593};\\\", \\\"{x:387,y:631,t:1526667899610};\\\", \\\"{x:392,y:636,t:1526667899626};\\\", \\\"{x:396,y:639,t:1526667899642};\\\", \\\"{x:403,y:642,t:1526667899659};\\\", \\\"{x:414,y:646,t:1526667899677};\\\", \\\"{x:434,y:648,t:1526667899692};\\\", \\\"{x:454,y:648,t:1526667899709};\\\", \\\"{x:469,y:648,t:1526667899726};\\\", \\\"{x:492,y:646,t:1526667899743};\\\", \\\"{x:507,y:642,t:1526667899760};\\\", \\\"{x:522,y:639,t:1526667899775};\\\", \\\"{x:532,y:635,t:1526667899793};\\\", \\\"{x:539,y:633,t:1526667899809};\\\", \\\"{x:542,y:631,t:1526667899826};\\\", \\\"{x:543,y:630,t:1526667899843};\\\", \\\"{x:544,y:630,t:1526667899917};\\\", \\\"{x:544,y:626,t:1526667899926};\\\", \\\"{x:525,y:614,t:1526667899944};\\\", \\\"{x:481,y:596,t:1526667899960};\\\", \\\"{x:434,y:575,t:1526667899977};\\\", \\\"{x:396,y:561,t:1526667899993};\\\", \\\"{x:361,y:555,t:1526667900009};\\\", \\\"{x:332,y:554,t:1526667900026};\\\", \\\"{x:300,y:554,t:1526667900042};\\\", \\\"{x:272,y:554,t:1526667900060};\\\", \\\"{x:257,y:554,t:1526667900076};\\\", \\\"{x:250,y:555,t:1526667900092};\\\", \\\"{x:248,y:556,t:1526667900109};\\\", \\\"{x:243,y:559,t:1526667900126};\\\", \\\"{x:241,y:561,t:1526667900143};\\\", \\\"{x:236,y:567,t:1526667900160};\\\", \\\"{x:231,y:571,t:1526667900177};\\\", \\\"{x:224,y:580,t:1526667900193};\\\", \\\"{x:216,y:591,t:1526667900210};\\\", \\\"{x:208,y:602,t:1526667900226};\\\", \\\"{x:199,y:613,t:1526667900244};\\\", \\\"{x:193,y:620,t:1526667900260};\\\", \\\"{x:185,y:627,t:1526667900276};\\\", \\\"{x:184,y:629,t:1526667900293};\\\", \\\"{x:182,y:631,t:1526667900310};\\\", \\\"{x:180,y:632,t:1526667900326};\\\", \\\"{x:180,y:630,t:1526667900414};\\\", \\\"{x:180,y:626,t:1526667900426};\\\", \\\"{x:182,y:616,t:1526667900444};\\\", \\\"{x:187,y:605,t:1526667900460};\\\", \\\"{x:192,y:595,t:1526667900477};\\\", \\\"{x:196,y:587,t:1526667900493};\\\", \\\"{x:200,y:577,t:1526667900511};\\\", \\\"{x:207,y:556,t:1526667900527};\\\", \\\"{x:214,y:545,t:1526667900543};\\\", \\\"{x:218,y:539,t:1526667900560};\\\", \\\"{x:222,y:533,t:1526667900578};\\\", \\\"{x:223,y:530,t:1526667900593};\\\", \\\"{x:223,y:532,t:1526667900830};\\\", \\\"{x:223,y:535,t:1526667900843};\\\", \\\"{x:222,y:541,t:1526667900860};\\\", \\\"{x:221,y:544,t:1526667900876};\\\", \\\"{x:221,y:546,t:1526667900893};\\\", \\\"{x:221,y:547,t:1526667901143};\\\", \\\"{x:237,y:557,t:1526667901159};\\\", \\\"{x:261,y:571,t:1526667901175};\\\", \\\"{x:284,y:591,t:1526667901193};\\\", \\\"{x:311,y:615,t:1526667901209};\\\", \\\"{x:328,y:635,t:1526667901227};\\\", \\\"{x:340,y:649,t:1526667901245};\\\", \\\"{x:345,y:656,t:1526667901261};\\\", \\\"{x:347,y:659,t:1526667901277};\\\", \\\"{x:347,y:661,t:1526667901293};\\\", \\\"{x:348,y:662,t:1526667901382};\\\", \\\"{x:351,y:663,t:1526667901393};\\\", \\\"{x:359,y:667,t:1526667901411};\\\", \\\"{x:369,y:671,t:1526667901428};\\\", \\\"{x:378,y:675,t:1526667901444};\\\", \\\"{x:386,y:677,t:1526667901460};\\\", \\\"{x:392,y:680,t:1526667901477};\\\", \\\"{x:394,y:681,t:1526667901493};\\\", \\\"{x:392,y:681,t:1526667901534};\\\", \\\"{x:381,y:679,t:1526667901544};\\\", \\\"{x:320,y:660,t:1526667901561};\\\", \\\"{x:267,y:635,t:1526667901578};\\\", \\\"{x:237,y:620,t:1526667901594};\\\", \\\"{x:209,y:608,t:1526667901612};\\\", \\\"{x:173,y:591,t:1526667901628};\\\", \\\"{x:142,y:577,t:1526667901645};\\\", \\\"{x:123,y:567,t:1526667901662};\\\", \\\"{x:116,y:561,t:1526667901678};\\\", \\\"{x:114,y:555,t:1526667901694};\\\", \\\"{x:117,y:551,t:1526667901711};\\\", \\\"{x:119,y:549,t:1526667901728};\\\", \\\"{x:121,y:548,t:1526667901744};\\\", \\\"{x:122,y:547,t:1526667901815};\\\", \\\"{x:124,y:547,t:1526667901838};\\\", \\\"{x:126,y:547,t:1526667901847};\\\", \\\"{x:135,y:549,t:1526667901862};\\\", \\\"{x:138,y:551,t:1526667901878};\\\", \\\"{x:144,y:554,t:1526667901895};\\\", \\\"{x:146,y:555,t:1526667901912};\\\", \\\"{x:149,y:556,t:1526667901929};\\\", \\\"{x:154,y:559,t:1526667901944};\\\", \\\"{x:156,y:560,t:1526667901961};\\\", \\\"{x:157,y:561,t:1526667901977};\\\", \\\"{x:160,y:562,t:1526667902214};\\\", \\\"{x:170,y:565,t:1526667902229};\\\", \\\"{x:202,y:582,t:1526667902245};\\\", \\\"{x:263,y:612,t:1526667902261};\\\", \\\"{x:370,y:662,t:1526667902279};\\\", \\\"{x:417,y:682,t:1526667902295};\\\", \\\"{x:457,y:703,t:1526667902312};\\\", \\\"{x:483,y:715,t:1526667902328};\\\", \\\"{x:499,y:725,t:1526667902345};\\\", \\\"{x:507,y:730,t:1526667902362};\\\", \\\"{x:510,y:731,t:1526667902378};\\\", \\\"{x:511,y:731,t:1526667902394};\\\", \\\"{x:513,y:731,t:1526667902782};\\\", \\\"{x:515,y:731,t:1526667902796};\\\", \\\"{x:520,y:730,t:1526667902811};\\\", \\\"{x:525,y:727,t:1526667902829};\\\", \\\"{x:530,y:725,t:1526667902845};\\\", \\\"{x:530,y:724,t:1526667902862};\\\" ] }, { \\\"rt\\\": 16194, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 151492, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06:30-06 PM-05 PM-04 PM-B -B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:724,t:1526667908815};\\\", \\\"{x:545,y:726,t:1526667908829};\\\", \\\"{x:652,y:744,t:1526667908846};\\\", \\\"{x:787,y:779,t:1526667908862};\\\", \\\"{x:963,y:799,t:1526667908878};\\\", \\\"{x:1142,y:819,t:1526667908899};\\\", \\\"{x:1311,y:821,t:1526667908917};\\\", \\\"{x:1576,y:821,t:1526667908933};\\\", \\\"{x:1768,y:830,t:1526667908950};\\\", \\\"{x:1919,y:852,t:1526667908967};\\\", \\\"{x:1919,y:874,t:1526667908984};\\\", \\\"{x:1919,y:901,t:1526667909000};\\\", \\\"{x:1919,y:934,t:1526667909017};\\\", \\\"{x:1919,y:947,t:1526667909033};\\\", \\\"{x:1919,y:959,t:1526667909050};\\\", \\\"{x:1919,y:966,t:1526667909067};\\\", \\\"{x:1919,y:973,t:1526667909084};\\\", \\\"{x:1919,y:979,t:1526667909100};\\\", \\\"{x:1919,y:980,t:1526667909117};\\\", \\\"{x:1916,y:975,t:1526667909231};\\\", \\\"{x:1907,y:970,t:1526667909238};\\\", \\\"{x:1898,y:964,t:1526667909252};\\\", \\\"{x:1878,y:954,t:1526667909268};\\\", \\\"{x:1858,y:946,t:1526667909284};\\\", \\\"{x:1843,y:942,t:1526667909300};\\\", \\\"{x:1830,y:938,t:1526667909317};\\\", \\\"{x:1821,y:936,t:1526667909334};\\\", \\\"{x:1819,y:936,t:1526667909351};\\\", \\\"{x:1818,y:936,t:1526667909389};\\\", \\\"{x:1817,y:936,t:1526667909414};\\\", \\\"{x:1816,y:936,t:1526667909430};\\\", \\\"{x:1815,y:936,t:1526667909454};\\\", \\\"{x:1814,y:936,t:1526667909467};\\\", \\\"{x:1812,y:936,t:1526667909484};\\\", \\\"{x:1810,y:936,t:1526667909501};\\\", \\\"{x:1809,y:936,t:1526667909518};\\\", \\\"{x:1807,y:936,t:1526667909535};\\\", \\\"{x:1806,y:936,t:1526667909559};\\\", \\\"{x:1805,y:936,t:1526667909575};\\\", \\\"{x:1804,y:936,t:1526667909584};\\\", \\\"{x:1804,y:937,t:1526667909601};\\\", \\\"{x:1803,y:938,t:1526667909618};\\\", \\\"{x:1801,y:938,t:1526667909635};\\\", \\\"{x:1799,y:940,t:1526667909651};\\\", \\\"{x:1798,y:941,t:1526667909670};\\\", \\\"{x:1796,y:943,t:1526667909686};\\\", \\\"{x:1795,y:944,t:1526667909702};\\\", \\\"{x:1789,y:955,t:1526667909718};\\\", \\\"{x:1783,y:965,t:1526667909734};\\\", \\\"{x:1781,y:969,t:1526667909751};\\\", \\\"{x:1773,y:983,t:1526667909770};\\\", \\\"{x:1766,y:995,t:1526667909785};\\\", \\\"{x:1759,y:1008,t:1526667909802};\\\", \\\"{x:1752,y:1021,t:1526667909818};\\\", \\\"{x:1746,y:1028,t:1526667909834};\\\", \\\"{x:1741,y:1032,t:1526667909851};\\\", \\\"{x:1739,y:1034,t:1526667909868};\\\", \\\"{x:1737,y:1034,t:1526667909884};\\\", \\\"{x:1736,y:1034,t:1526667909967};\\\", \\\"{x:1734,y:1036,t:1526667909975};\\\", \\\"{x:1732,y:1036,t:1526667909985};\\\", \\\"{x:1722,y:1036,t:1526667910002};\\\", \\\"{x:1715,y:1036,t:1526667910018};\\\", \\\"{x:1708,y:1036,t:1526667910035};\\\", \\\"{x:1701,y:1036,t:1526667910051};\\\", \\\"{x:1697,y:1036,t:1526667910068};\\\", \\\"{x:1694,y:1036,t:1526667910084};\\\", \\\"{x:1693,y:1036,t:1526667910101};\\\", \\\"{x:1691,y:1036,t:1526667910118};\\\", \\\"{x:1690,y:1034,t:1526667910135};\\\", \\\"{x:1689,y:1034,t:1526667910152};\\\", \\\"{x:1687,y:1032,t:1526667910169};\\\", \\\"{x:1687,y:1031,t:1526667910186};\\\", \\\"{x:1687,y:1030,t:1526667910215};\\\", \\\"{x:1686,y:1029,t:1526667910246};\\\", \\\"{x:1686,y:1028,t:1526667910263};\\\", \\\"{x:1686,y:1027,t:1526667910295};\\\", \\\"{x:1686,y:1025,t:1526667910311};\\\", \\\"{x:1686,y:1024,t:1526667910319};\\\", \\\"{x:1686,y:1023,t:1526667910335};\\\", \\\"{x:1686,y:1021,t:1526667910352};\\\", \\\"{x:1686,y:1019,t:1526667910369};\\\", \\\"{x:1686,y:1017,t:1526667910386};\\\", \\\"{x:1686,y:1015,t:1526667910401};\\\", \\\"{x:1686,y:1014,t:1526667910419};\\\", \\\"{x:1686,y:1012,t:1526667910435};\\\", \\\"{x:1686,y:1011,t:1526667910452};\\\", \\\"{x:1686,y:1010,t:1526667910519};\\\", \\\"{x:1686,y:1009,t:1526667910536};\\\", \\\"{x:1686,y:1006,t:1526667910552};\\\", \\\"{x:1684,y:1005,t:1526667910569};\\\", \\\"{x:1684,y:1004,t:1526667910586};\\\", \\\"{x:1683,y:1001,t:1526667910602};\\\", \\\"{x:1681,y:998,t:1526667910618};\\\", \\\"{x:1679,y:996,t:1526667910635};\\\", \\\"{x:1673,y:993,t:1526667910652};\\\", \\\"{x:1671,y:991,t:1526667910669};\\\", \\\"{x:1665,y:990,t:1526667910686};\\\", \\\"{x:1660,y:988,t:1526667910703};\\\", \\\"{x:1658,y:987,t:1526667910719};\\\", \\\"{x:1655,y:987,t:1526667910735};\\\", \\\"{x:1653,y:987,t:1526667910753};\\\", \\\"{x:1649,y:986,t:1526667910769};\\\", \\\"{x:1646,y:986,t:1526667910785};\\\", \\\"{x:1644,y:986,t:1526667910803};\\\", \\\"{x:1642,y:986,t:1526667910818};\\\", \\\"{x:1641,y:986,t:1526667910835};\\\", \\\"{x:1640,y:986,t:1526667910852};\\\", \\\"{x:1639,y:986,t:1526667910868};\\\", \\\"{x:1636,y:986,t:1526667910885};\\\", \\\"{x:1632,y:987,t:1526667910903};\\\", \\\"{x:1629,y:987,t:1526667910919};\\\", \\\"{x:1625,y:988,t:1526667910935};\\\", \\\"{x:1622,y:988,t:1526667910952};\\\", \\\"{x:1619,y:989,t:1526667910970};\\\", \\\"{x:1618,y:989,t:1526667910985};\\\", \\\"{x:1616,y:989,t:1526667911003};\\\", \\\"{x:1615,y:989,t:1526667911095};\\\", \\\"{x:1613,y:989,t:1526667911119};\\\", \\\"{x:1612,y:989,t:1526667911136};\\\", \\\"{x:1611,y:989,t:1526667911182};\\\", \\\"{x:1611,y:988,t:1526667911190};\\\", \\\"{x:1609,y:984,t:1526667911202};\\\", \\\"{x:1608,y:976,t:1526667911220};\\\", \\\"{x:1607,y:964,t:1526667911236};\\\", \\\"{x:1607,y:951,t:1526667911253};\\\", \\\"{x:1609,y:940,t:1526667911270};\\\", \\\"{x:1618,y:924,t:1526667911285};\\\", \\\"{x:1629,y:906,t:1526667911303};\\\", \\\"{x:1636,y:894,t:1526667911319};\\\", \\\"{x:1642,y:880,t:1526667911336};\\\", \\\"{x:1646,y:870,t:1526667911353};\\\", \\\"{x:1649,y:861,t:1526667911370};\\\", \\\"{x:1650,y:853,t:1526667911386};\\\", \\\"{x:1651,y:847,t:1526667911403};\\\", \\\"{x:1651,y:842,t:1526667911419};\\\", \\\"{x:1651,y:836,t:1526667911436};\\\", \\\"{x:1651,y:829,t:1526667911452};\\\", \\\"{x:1651,y:823,t:1526667911469};\\\", \\\"{x:1652,y:820,t:1526667911485};\\\", \\\"{x:1652,y:818,t:1526667911502};\\\", \\\"{x:1653,y:818,t:1526667911519};\\\", \\\"{x:1654,y:817,t:1526667911536};\\\", \\\"{x:1656,y:815,t:1526667911552};\\\", \\\"{x:1660,y:814,t:1526667911569};\\\", \\\"{x:1662,y:812,t:1526667911586};\\\", \\\"{x:1668,y:811,t:1526667911602};\\\", \\\"{x:1671,y:808,t:1526667911619};\\\", \\\"{x:1673,y:808,t:1526667911636};\\\", \\\"{x:1675,y:807,t:1526667911652};\\\", \\\"{x:1676,y:807,t:1526667911669};\\\", \\\"{x:1677,y:807,t:1526667911686};\\\", \\\"{x:1680,y:807,t:1526667911703};\\\", \\\"{x:1681,y:807,t:1526667911719};\\\", \\\"{x:1682,y:806,t:1526667911737};\\\", \\\"{x:1682,y:805,t:1526667911753};\\\", \\\"{x:1683,y:805,t:1526667911769};\\\", \\\"{x:1683,y:806,t:1526667911943};\\\", \\\"{x:1683,y:808,t:1526667911954};\\\", \\\"{x:1683,y:811,t:1526667911970};\\\", \\\"{x:1680,y:815,t:1526667911986};\\\", \\\"{x:1680,y:820,t:1526667912004};\\\", \\\"{x:1679,y:821,t:1526667912020};\\\", \\\"{x:1678,y:823,t:1526667912036};\\\", \\\"{x:1678,y:825,t:1526667912056};\\\", \\\"{x:1678,y:826,t:1526667912094};\\\", \\\"{x:1677,y:827,t:1526667912118};\\\", \\\"{x:1677,y:828,t:1526667912165};\\\", \\\"{x:1674,y:830,t:1526667914456};\\\", \\\"{x:1655,y:839,t:1526667914472};\\\", \\\"{x:1634,y:845,t:1526667914489};\\\", \\\"{x:1616,y:847,t:1526667914505};\\\", \\\"{x:1597,y:850,t:1526667914521};\\\", \\\"{x:1576,y:850,t:1526667914539};\\\", \\\"{x:1539,y:850,t:1526667914556};\\\", \\\"{x:1440,y:843,t:1526667914571};\\\", \\\"{x:1315,y:822,t:1526667914588};\\\", \\\"{x:1148,y:793,t:1526667914606};\\\", \\\"{x:977,y:769,t:1526667914622};\\\", \\\"{x:751,y:752,t:1526667914638};\\\", \\\"{x:609,y:752,t:1526667914655};\\\", \\\"{x:468,y:752,t:1526667914672};\\\", \\\"{x:374,y:752,t:1526667914688};\\\", \\\"{x:323,y:750,t:1526667914705};\\\", \\\"{x:304,y:749,t:1526667914722};\\\", \\\"{x:303,y:749,t:1526667914739};\\\", \\\"{x:303,y:747,t:1526667914815};\\\", \\\"{x:306,y:745,t:1526667914830};\\\", \\\"{x:310,y:743,t:1526667914838};\\\", \\\"{x:318,y:739,t:1526667914856};\\\", \\\"{x:324,y:735,t:1526667914872};\\\", \\\"{x:331,y:731,t:1526667914888};\\\", \\\"{x:338,y:727,t:1526667914905};\\\", \\\"{x:350,y:720,t:1526667914923};\\\", \\\"{x:360,y:715,t:1526667914939};\\\", \\\"{x:368,y:711,t:1526667914956};\\\", \\\"{x:371,y:710,t:1526667914973};\\\", \\\"{x:372,y:708,t:1526667914988};\\\", \\\"{x:373,y:703,t:1526667915006};\\\", \\\"{x:374,y:692,t:1526667915022};\\\", \\\"{x:374,y:683,t:1526667915038};\\\", \\\"{x:371,y:670,t:1526667915055};\\\", \\\"{x:366,y:660,t:1526667915073};\\\", \\\"{x:365,y:658,t:1526667915088};\\\", \\\"{x:365,y:657,t:1526667915127};\\\", \\\"{x:365,y:656,t:1526667915151};\\\", \\\"{x:365,y:654,t:1526667915158};\\\", \\\"{x:365,y:653,t:1526667915172};\\\", \\\"{x:365,y:650,t:1526667915190};\\\", \\\"{x:369,y:643,t:1526667915206};\\\", \\\"{x:378,y:633,t:1526667915222};\\\", \\\"{x:383,y:625,t:1526667915239};\\\", \\\"{x:387,y:618,t:1526667915256};\\\", \\\"{x:392,y:610,t:1526667915273};\\\", \\\"{x:396,y:603,t:1526667915289};\\\", \\\"{x:399,y:597,t:1526667915305};\\\", \\\"{x:403,y:585,t:1526667915322};\\\", \\\"{x:405,y:573,t:1526667915339};\\\", \\\"{x:408,y:559,t:1526667915356};\\\", \\\"{x:408,y:543,t:1526667915373};\\\", \\\"{x:408,y:526,t:1526667915389};\\\", \\\"{x:408,y:519,t:1526667915404};\\\", \\\"{x:408,y:513,t:1526667915422};\\\", \\\"{x:407,y:512,t:1526667915439};\\\", \\\"{x:407,y:511,t:1526667915455};\\\", \\\"{x:406,y:510,t:1526667915551};\\\", \\\"{x:406,y:511,t:1526667915606};\\\", \\\"{x:417,y:522,t:1526667915623};\\\", \\\"{x:442,y:530,t:1526667915639};\\\", \\\"{x:481,y:540,t:1526667915656};\\\", \\\"{x:517,y:544,t:1526667915671};\\\", \\\"{x:551,y:544,t:1526667915688};\\\", \\\"{x:585,y:544,t:1526667915705};\\\", \\\"{x:615,y:544,t:1526667915722};\\\", \\\"{x:634,y:544,t:1526667915739};\\\", \\\"{x:648,y:544,t:1526667915755};\\\", \\\"{x:652,y:543,t:1526667915774};\\\", \\\"{x:652,y:542,t:1526667915789};\\\", \\\"{x:657,y:541,t:1526667915806};\\\", \\\"{x:661,y:539,t:1526667915823};\\\", \\\"{x:667,y:537,t:1526667915839};\\\", \\\"{x:674,y:534,t:1526667915857};\\\", \\\"{x:679,y:532,t:1526667915873};\\\", \\\"{x:685,y:530,t:1526667915889};\\\", \\\"{x:691,y:528,t:1526667915906};\\\", \\\"{x:696,y:526,t:1526667915922};\\\", \\\"{x:704,y:526,t:1526667915939};\\\", \\\"{x:718,y:524,t:1526667915956};\\\", \\\"{x:727,y:522,t:1526667915973};\\\", \\\"{x:736,y:522,t:1526667915989};\\\", \\\"{x:753,y:522,t:1526667916006};\\\", \\\"{x:764,y:522,t:1526667916023};\\\", \\\"{x:773,y:522,t:1526667916040};\\\", \\\"{x:778,y:522,t:1526667916056};\\\", \\\"{x:783,y:522,t:1526667916074};\\\", \\\"{x:791,y:522,t:1526667916089};\\\", \\\"{x:806,y:524,t:1526667916106};\\\", \\\"{x:816,y:528,t:1526667916123};\\\", \\\"{x:824,y:530,t:1526667916139};\\\", \\\"{x:829,y:532,t:1526667916156};\\\", \\\"{x:835,y:533,t:1526667916173};\\\", \\\"{x:839,y:533,t:1526667916189};\\\", \\\"{x:846,y:534,t:1526667916206};\\\", \\\"{x:848,y:535,t:1526667916223};\\\", \\\"{x:850,y:535,t:1526667916239};\\\", \\\"{x:851,y:535,t:1526667916366};\\\", \\\"{x:851,y:536,t:1526667916390};\\\", \\\"{x:849,y:537,t:1526667916407};\\\", \\\"{x:846,y:539,t:1526667916423};\\\", \\\"{x:843,y:539,t:1526667916439};\\\", \\\"{x:839,y:542,t:1526667916456};\\\", \\\"{x:831,y:545,t:1526667916473};\\\", \\\"{x:829,y:546,t:1526667916490};\\\", \\\"{x:827,y:546,t:1526667916506};\\\", \\\"{x:824,y:549,t:1526667916523};\\\", \\\"{x:822,y:549,t:1526667916539};\\\", \\\"{x:820,y:551,t:1526667916556};\\\", \\\"{x:813,y:553,t:1526667916573};\\\", \\\"{x:799,y:559,t:1526667916590};\\\", \\\"{x:785,y:563,t:1526667916606};\\\", \\\"{x:767,y:568,t:1526667916623};\\\", \\\"{x:747,y:574,t:1526667916640};\\\", \\\"{x:726,y:576,t:1526667916657};\\\", \\\"{x:698,y:579,t:1526667916673};\\\", \\\"{x:664,y:580,t:1526667916690};\\\", \\\"{x:624,y:582,t:1526667916708};\\\", \\\"{x:582,y:582,t:1526667916723};\\\", \\\"{x:548,y:585,t:1526667916740};\\\", \\\"{x:525,y:591,t:1526667916756};\\\", \\\"{x:506,y:596,t:1526667916773};\\\", \\\"{x:482,y:604,t:1526667916790};\\\", \\\"{x:470,y:608,t:1526667916807};\\\", \\\"{x:465,y:610,t:1526667916823};\\\", \\\"{x:461,y:612,t:1526667916840};\\\", \\\"{x:460,y:612,t:1526667916857};\\\", \\\"{x:457,y:612,t:1526667916873};\\\", \\\"{x:454,y:614,t:1526667916891};\\\", \\\"{x:453,y:614,t:1526667916907};\\\", \\\"{x:449,y:615,t:1526667916923};\\\", \\\"{x:447,y:616,t:1526667916940};\\\", \\\"{x:440,y:618,t:1526667916957};\\\", \\\"{x:434,y:618,t:1526667916974};\\\", \\\"{x:413,y:618,t:1526667916990};\\\", \\\"{x:386,y:618,t:1526667917007};\\\", \\\"{x:358,y:618,t:1526667917023};\\\", \\\"{x:329,y:618,t:1526667917040};\\\", \\\"{x:303,y:618,t:1526667917057};\\\", \\\"{x:274,y:618,t:1526667917073};\\\", \\\"{x:247,y:618,t:1526667917090};\\\", \\\"{x:219,y:618,t:1526667917107};\\\", \\\"{x:195,y:616,t:1526667917123};\\\", \\\"{x:177,y:613,t:1526667917140};\\\", \\\"{x:164,y:611,t:1526667917159};\\\", \\\"{x:158,y:609,t:1526667917173};\\\", \\\"{x:157,y:609,t:1526667917191};\\\", \\\"{x:157,y:608,t:1526667917223};\\\", \\\"{x:158,y:606,t:1526667917335};\\\", \\\"{x:161,y:604,t:1526667917342};\\\", \\\"{x:165,y:601,t:1526667917358};\\\", \\\"{x:174,y:596,t:1526667917374};\\\", \\\"{x:180,y:593,t:1526667917391};\\\", \\\"{x:185,y:591,t:1526667917407};\\\", \\\"{x:189,y:588,t:1526667917424};\\\", \\\"{x:197,y:583,t:1526667917441};\\\", \\\"{x:206,y:579,t:1526667917457};\\\", \\\"{x:211,y:575,t:1526667917473};\\\", \\\"{x:219,y:570,t:1526667917490};\\\", \\\"{x:222,y:568,t:1526667917507};\\\", \\\"{x:224,y:566,t:1526667917524};\\\", \\\"{x:226,y:564,t:1526667917540};\\\", \\\"{x:229,y:559,t:1526667917557};\\\", \\\"{x:231,y:551,t:1526667917573};\\\", \\\"{x:231,y:544,t:1526667917592};\\\", \\\"{x:231,y:537,t:1526667917608};\\\", \\\"{x:230,y:531,t:1526667917625};\\\", \\\"{x:228,y:525,t:1526667917640};\\\", \\\"{x:226,y:521,t:1526667917657};\\\", \\\"{x:225,y:519,t:1526667917673};\\\", \\\"{x:223,y:518,t:1526667917694};\\\", \\\"{x:221,y:517,t:1526667917710};\\\", \\\"{x:220,y:516,t:1526667917724};\\\", \\\"{x:218,y:515,t:1526667917740};\\\", \\\"{x:216,y:515,t:1526667917757};\\\", \\\"{x:215,y:515,t:1526667917774};\\\", \\\"{x:216,y:517,t:1526667917830};\\\", \\\"{x:223,y:522,t:1526667917841};\\\", \\\"{x:244,y:537,t:1526667917858};\\\", \\\"{x:265,y:550,t:1526667917873};\\\", \\\"{x:292,y:562,t:1526667917891};\\\", \\\"{x:321,y:572,t:1526667917907};\\\", \\\"{x:356,y:581,t:1526667917925};\\\", \\\"{x:382,y:587,t:1526667917942};\\\", \\\"{x:402,y:590,t:1526667917957};\\\", \\\"{x:414,y:590,t:1526667917973};\\\", \\\"{x:419,y:594,t:1526667918175};\\\", \\\"{x:440,y:605,t:1526667918191};\\\", \\\"{x:475,y:617,t:1526667918208};\\\", \\\"{x:505,y:625,t:1526667918224};\\\", \\\"{x:539,y:633,t:1526667918241};\\\", \\\"{x:565,y:641,t:1526667918257};\\\", \\\"{x:588,y:645,t:1526667918274};\\\", \\\"{x:602,y:647,t:1526667918291};\\\", \\\"{x:606,y:648,t:1526667918307};\\\", \\\"{x:607,y:648,t:1526667918534};\\\", \\\"{x:607,y:647,t:1526667918558};\\\", \\\"{x:607,y:648,t:1526667918759};\\\", \\\"{x:594,y:654,t:1526667918777};\\\", \\\"{x:582,y:661,t:1526667918791};\\\", \\\"{x:568,y:672,t:1526667918809};\\\", \\\"{x:559,y:679,t:1526667918826};\\\", \\\"{x:552,y:684,t:1526667918841};\\\", \\\"{x:547,y:687,t:1526667918858};\\\", \\\"{x:546,y:688,t:1526667918875};\\\", \\\"{x:545,y:689,t:1526667918891};\\\", \\\"{x:544,y:690,t:1526667918908};\\\", \\\"{x:541,y:691,t:1526667918925};\\\", \\\"{x:537,y:694,t:1526667918942};\\\", \\\"{x:536,y:694,t:1526667918958};\\\", \\\"{x:536,y:695,t:1526667918982};\\\", \\\"{x:535,y:696,t:1526667918992};\\\", \\\"{x:534,y:697,t:1526667919014};\\\", \\\"{x:534,y:699,t:1526667919025};\\\", \\\"{x:533,y:702,t:1526667919043};\\\", \\\"{x:531,y:706,t:1526667919058};\\\", \\\"{x:530,y:709,t:1526667919075};\\\", \\\"{x:530,y:710,t:1526667919091};\\\", \\\"{x:534,y:709,t:1526667919174};\\\", \\\"{x:555,y:698,t:1526667919193};\\\", \\\"{x:576,y:690,t:1526667919209};\\\", \\\"{x:592,y:681,t:1526667919226};\\\", \\\"{x:597,y:677,t:1526667919242};\\\", \\\"{x:599,y:674,t:1526667919258};\\\", \\\"{x:599,y:673,t:1526667919275};\\\", \\\"{x:600,y:673,t:1526667919292};\\\", \\\"{x:600,y:672,t:1526667919325};\\\", \\\"{x:600,y:668,t:1526667919342};\\\", \\\"{x:601,y:659,t:1526667919358};\\\", \\\"{x:603,y:651,t:1526667919375};\\\", \\\"{x:604,y:645,t:1526667919394};\\\", \\\"{x:604,y:639,t:1526667919408};\\\", \\\"{x:605,y:638,t:1526667919425};\\\", \\\"{x:605,y:637,t:1526667919692};\\\", \\\"{x:598,y:637,t:1526667919710};\\\", \\\"{x:581,y:647,t:1526667919725};\\\", \\\"{x:567,y:661,t:1526667919743};\\\", \\\"{x:554,y:672,t:1526667919760};\\\", \\\"{x:546,y:679,t:1526667919775};\\\", \\\"{x:537,y:688,t:1526667919793};\\\", \\\"{x:533,y:694,t:1526667919809};\\\", \\\"{x:530,y:698,t:1526667919825};\\\", \\\"{x:529,y:701,t:1526667919843};\\\", \\\"{x:526,y:705,t:1526667919860};\\\", \\\"{x:525,y:706,t:1526667919875};\\\", \\\"{x:524,y:707,t:1526667919892};\\\", \\\"{x:524,y:709,t:1526667920326};\\\", \\\"{x:524,y:720,t:1526667920342};\\\", \\\"{x:524,y:726,t:1526667920360};\\\", \\\"{x:524,y:732,t:1526667920376};\\\", \\\"{x:523,y:733,t:1526667920393};\\\", \\\"{x:522,y:734,t:1526667921286};\\\", \\\"{x:520,y:734,t:1526667921293};\\\", \\\"{x:519,y:734,t:1526667921309};\\\" ] }, { \\\"rt\\\": 12773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 165486, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:735,t:1526667921427};\\\", \\\"{x:498,y:729,t:1526667932271};\\\", \\\"{x:438,y:712,t:1526667932287};\\\", \\\"{x:195,y:677,t:1526667932302};\\\", \\\"{x:32,y:650,t:1526667932318};\\\", \\\"{x:0,y:632,t:1526667932336};\\\", \\\"{x:0,y:623,t:1526667932353};\\\", \\\"{x:0,y:622,t:1526667932369};\\\", \\\"{x:0,y:620,t:1526667932386};\\\", \\\"{x:0,y:618,t:1526667932402};\\\", \\\"{x:0,y:617,t:1526667932429};\\\", \\\"{x:1,y:615,t:1526667932446};\\\", \\\"{x:2,y:613,t:1526667932454};\\\", \\\"{x:4,y:613,t:1526667932469};\\\", \\\"{x:5,y:612,t:1526667932486};\\\", \\\"{x:6,y:611,t:1526667932509};\\\", \\\"{x:6,y:609,t:1526667932542};\\\", \\\"{x:6,y:608,t:1526667932553};\\\", \\\"{x:6,y:607,t:1526667932570};\\\", \\\"{x:10,y:603,t:1526667932586};\\\", \\\"{x:23,y:598,t:1526667932603};\\\", \\\"{x:42,y:597,t:1526667932620};\\\", \\\"{x:68,y:597,t:1526667932637};\\\", \\\"{x:113,y:608,t:1526667932652};\\\", \\\"{x:166,y:624,t:1526667932669};\\\", \\\"{x:232,y:633,t:1526667932686};\\\", \\\"{x:265,y:633,t:1526667932703};\\\", \\\"{x:294,y:633,t:1526667932719};\\\", \\\"{x:322,y:633,t:1526667932736};\\\", \\\"{x:344,y:633,t:1526667932752};\\\", \\\"{x:364,y:633,t:1526667932770};\\\", \\\"{x:382,y:635,t:1526667932787};\\\", \\\"{x:396,y:638,t:1526667932804};\\\", \\\"{x:412,y:640,t:1526667932818};\\\", \\\"{x:426,y:642,t:1526667932836};\\\", \\\"{x:440,y:644,t:1526667932853};\\\", \\\"{x:458,y:644,t:1526667932870};\\\", \\\"{x:470,y:644,t:1526667932886};\\\", \\\"{x:477,y:644,t:1526667932903};\\\", \\\"{x:478,y:644,t:1526667932919};\\\", \\\"{x:479,y:644,t:1526667932966};\\\", \\\"{x:480,y:644,t:1526667932974};\\\", \\\"{x:482,y:644,t:1526667932987};\\\", \\\"{x:485,y:642,t:1526667933003};\\\", \\\"{x:489,y:642,t:1526667933020};\\\", \\\"{x:493,y:642,t:1526667933037};\\\", \\\"{x:503,y:642,t:1526667933054};\\\", \\\"{x:512,y:642,t:1526667933070};\\\", \\\"{x:519,y:642,t:1526667933086};\\\", \\\"{x:528,y:641,t:1526667933103};\\\", \\\"{x:539,y:641,t:1526667933120};\\\", \\\"{x:552,y:641,t:1526667933136};\\\", \\\"{x:562,y:641,t:1526667933153};\\\", \\\"{x:567,y:640,t:1526667933170};\\\", \\\"{x:572,y:640,t:1526667933186};\\\", \\\"{x:577,y:639,t:1526667933203};\\\", \\\"{x:579,y:638,t:1526667933220};\\\", \\\"{x:582,y:637,t:1526667933237};\\\", \\\"{x:583,y:636,t:1526667933253};\\\", \\\"{x:585,y:635,t:1526667933271};\\\", \\\"{x:585,y:634,t:1526667933302};\\\", \\\"{x:586,y:634,t:1526667933320};\\\", \\\"{x:588,y:633,t:1526667933338};\\\", \\\"{x:590,y:631,t:1526667933353};\\\", \\\"{x:593,y:628,t:1526667933370};\\\", \\\"{x:598,y:625,t:1526667933387};\\\", \\\"{x:601,y:622,t:1526667933403};\\\", \\\"{x:604,y:620,t:1526667933420};\\\", \\\"{x:607,y:618,t:1526667933436};\\\", \\\"{x:609,y:617,t:1526667933452};\\\", \\\"{x:614,y:613,t:1526667933469};\\\", \\\"{x:616,y:611,t:1526667933487};\\\", \\\"{x:617,y:610,t:1526667933502};\\\", \\\"{x:618,y:610,t:1526667933519};\\\", \\\"{x:616,y:612,t:1526667933693};\\\", \\\"{x:609,y:618,t:1526667933704};\\\", \\\"{x:596,y:625,t:1526667933720};\\\", \\\"{x:586,y:640,t:1526667933737};\\\", \\\"{x:582,y:653,t:1526667933753};\\\", \\\"{x:578,y:664,t:1526667933769};\\\", \\\"{x:573,y:676,t:1526667933787};\\\", \\\"{x:569,y:685,t:1526667933803};\\\", \\\"{x:564,y:693,t:1526667933820};\\\", \\\"{x:560,y:700,t:1526667933837};\\\", \\\"{x:555,y:707,t:1526667933853};\\\", \\\"{x:551,y:710,t:1526667933870};\\\", \\\"{x:548,y:713,t:1526667933887};\\\", \\\"{x:547,y:715,t:1526667933904};\\\", \\\"{x:546,y:715,t:1526667933920};\\\", \\\"{x:545,y:716,t:1526667934286};\\\", \\\"{x:542,y:717,t:1526667934293};\\\", \\\"{x:541,y:719,t:1526667934303};\\\", \\\"{x:537,y:723,t:1526667934320};\\\", \\\"{x:535,y:726,t:1526667934336};\\\", \\\"{x:533,y:728,t:1526667934354};\\\" ] }, { \\\"rt\\\": 8561, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 175328, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:728,t:1526667938175};\\\", \\\"{x:511,y:723,t:1526667938190};\\\", \\\"{x:465,y:706,t:1526667938208};\\\", \\\"{x:402,y:682,t:1526667938224};\\\", \\\"{x:348,y:664,t:1526667938240};\\\", \\\"{x:288,y:640,t:1526667938257};\\\", \\\"{x:250,y:632,t:1526667938275};\\\", \\\"{x:229,y:628,t:1526667938291};\\\", \\\"{x:216,y:627,t:1526667938307};\\\", \\\"{x:213,y:626,t:1526667938324};\\\", \\\"{x:212,y:626,t:1526667938341};\\\", \\\"{x:209,y:626,t:1526667938631};\\\", \\\"{x:207,y:626,t:1526667938641};\\\", \\\"{x:202,y:626,t:1526667938657};\\\", \\\"{x:198,y:626,t:1526667938674};\\\", \\\"{x:196,y:626,t:1526667939135};\\\", \\\"{x:192,y:626,t:1526667939142};\\\", \\\"{x:174,y:617,t:1526667939159};\\\", \\\"{x:150,y:607,t:1526667939176};\\\", \\\"{x:133,y:600,t:1526667939191};\\\", \\\"{x:123,y:596,t:1526667939208};\\\", \\\"{x:120,y:594,t:1526667939224};\\\", \\\"{x:117,y:592,t:1526667939241};\\\", \\\"{x:117,y:591,t:1526667939258};\\\", \\\"{x:116,y:590,t:1526667939275};\\\", \\\"{x:116,y:587,t:1526667939326};\\\", \\\"{x:116,y:585,t:1526667939341};\\\", \\\"{x:116,y:581,t:1526667939357};\\\", \\\"{x:120,y:577,t:1526667939375};\\\", \\\"{x:126,y:573,t:1526667939391};\\\", \\\"{x:141,y:565,t:1526667939409};\\\", \\\"{x:156,y:559,t:1526667939426};\\\", \\\"{x:178,y:551,t:1526667939442};\\\", \\\"{x:211,y:541,t:1526667939458};\\\", \\\"{x:241,y:539,t:1526667939475};\\\", \\\"{x:279,y:529,t:1526667939492};\\\", \\\"{x:315,y:526,t:1526667939509};\\\", \\\"{x:365,y:517,t:1526667939527};\\\", \\\"{x:380,y:516,t:1526667939541};\\\", \\\"{x:412,y:508,t:1526667939559};\\\", \\\"{x:421,y:504,t:1526667939576};\\\", \\\"{x:424,y:503,t:1526667939591};\\\", \\\"{x:421,y:503,t:1526667939743};\\\", \\\"{x:412,y:511,t:1526667939759};\\\", \\\"{x:408,y:517,t:1526667939776};\\\", \\\"{x:404,y:522,t:1526667939792};\\\", \\\"{x:402,y:527,t:1526667939808};\\\", \\\"{x:399,y:531,t:1526667939825};\\\", \\\"{x:396,y:534,t:1526667939843};\\\", \\\"{x:396,y:536,t:1526667939858};\\\", \\\"{x:396,y:537,t:1526667939893};\\\", \\\"{x:405,y:539,t:1526667939908};\\\", \\\"{x:488,y:556,t:1526667939926};\\\", \\\"{x:523,y:560,t:1526667939943};\\\", \\\"{x:538,y:560,t:1526667939958};\\\", \\\"{x:547,y:559,t:1526667939975};\\\", \\\"{x:555,y:556,t:1526667939992};\\\", \\\"{x:560,y:553,t:1526667940010};\\\", \\\"{x:563,y:550,t:1526667940025};\\\", \\\"{x:565,y:547,t:1526667940042};\\\", \\\"{x:567,y:544,t:1526667940058};\\\", \\\"{x:571,y:539,t:1526667940075};\\\", \\\"{x:579,y:533,t:1526667940093};\\\", \\\"{x:586,y:529,t:1526667940108};\\\", \\\"{x:592,y:525,t:1526667940125};\\\", \\\"{x:592,y:524,t:1526667940159};\\\", \\\"{x:593,y:524,t:1526667940327};\\\", \\\"{x:595,y:523,t:1526667940343};\\\", \\\"{x:598,y:520,t:1526667940360};\\\", \\\"{x:603,y:514,t:1526667940377};\\\", \\\"{x:605,y:510,t:1526667940393};\\\", \\\"{x:607,y:507,t:1526667940409};\\\", \\\"{x:608,y:505,t:1526667940425};\\\", \\\"{x:610,y:504,t:1526667940442};\\\", \\\"{x:610,y:503,t:1526667940459};\\\", \\\"{x:610,y:502,t:1526667940685};\\\", \\\"{x:606,y:503,t:1526667940694};\\\", \\\"{x:597,y:508,t:1526667940710};\\\", \\\"{x:587,y:512,t:1526667940726};\\\", \\\"{x:579,y:516,t:1526667940742};\\\", \\\"{x:569,y:522,t:1526667940759};\\\", \\\"{x:557,y:529,t:1526667940777};\\\", \\\"{x:550,y:534,t:1526667940792};\\\", \\\"{x:544,y:542,t:1526667940809};\\\", \\\"{x:544,y:546,t:1526667940826};\\\", \\\"{x:551,y:551,t:1526667940842};\\\", \\\"{x:574,y:558,t:1526667940860};\\\", \\\"{x:602,y:565,t:1526667940877};\\\", \\\"{x:644,y:573,t:1526667940893};\\\", \\\"{x:675,y:576,t:1526667940909};\\\", \\\"{x:699,y:576,t:1526667940927};\\\", \\\"{x:720,y:576,t:1526667940942};\\\", \\\"{x:731,y:573,t:1526667940961};\\\", \\\"{x:738,y:569,t:1526667940977};\\\", \\\"{x:741,y:568,t:1526667940992};\\\", \\\"{x:744,y:565,t:1526667941009};\\\", \\\"{x:749,y:561,t:1526667941027};\\\", \\\"{x:754,y:558,t:1526667941044};\\\", \\\"{x:758,y:555,t:1526667941060};\\\", \\\"{x:763,y:550,t:1526667941076};\\\", \\\"{x:773,y:544,t:1526667941093};\\\", \\\"{x:789,y:537,t:1526667941109};\\\", \\\"{x:802,y:534,t:1526667941127};\\\", \\\"{x:816,y:531,t:1526667941144};\\\", \\\"{x:832,y:526,t:1526667941159};\\\", \\\"{x:844,y:525,t:1526667941176};\\\", \\\"{x:846,y:525,t:1526667941193};\\\", \\\"{x:843,y:525,t:1526667941477};\\\", \\\"{x:836,y:527,t:1526667941493};\\\", \\\"{x:829,y:531,t:1526667941510};\\\", \\\"{x:817,y:541,t:1526667941527};\\\", \\\"{x:801,y:557,t:1526667941544};\\\", \\\"{x:782,y:574,t:1526667941561};\\\", \\\"{x:760,y:597,t:1526667941577};\\\", \\\"{x:738,y:619,t:1526667941595};\\\", \\\"{x:716,y:646,t:1526667941610};\\\", \\\"{x:690,y:676,t:1526667941626};\\\", \\\"{x:671,y:697,t:1526667941644};\\\", \\\"{x:655,y:715,t:1526667941660};\\\", \\\"{x:646,y:726,t:1526667941676};\\\", \\\"{x:636,y:737,t:1526667941693};\\\", \\\"{x:633,y:741,t:1526667941709};\\\", \\\"{x:631,y:743,t:1526667941726};\\\", \\\"{x:631,y:744,t:1526667941750};\\\", \\\"{x:631,y:738,t:1526667941814};\\\", \\\"{x:634,y:732,t:1526667941826};\\\", \\\"{x:648,y:711,t:1526667941844};\\\", \\\"{x:666,y:689,t:1526667941861};\\\", \\\"{x:683,y:669,t:1526667941877};\\\", \\\"{x:702,y:651,t:1526667941893};\\\", \\\"{x:726,y:626,t:1526667941910};\\\", \\\"{x:741,y:612,t:1526667941927};\\\", \\\"{x:755,y:599,t:1526667941945};\\\", \\\"{x:764,y:591,t:1526667941961};\\\", \\\"{x:771,y:585,t:1526667941977};\\\", \\\"{x:775,y:580,t:1526667941994};\\\", \\\"{x:775,y:579,t:1526667942011};\\\", \\\"{x:776,y:577,t:1526667942028};\\\", \\\"{x:777,y:576,t:1526667942078};\\\", \\\"{x:778,y:575,t:1526667942151};\\\", \\\"{x:782,y:574,t:1526667942161};\\\", \\\"{x:787,y:571,t:1526667942177};\\\", \\\"{x:794,y:568,t:1526667942193};\\\", \\\"{x:798,y:566,t:1526667942211};\\\", \\\"{x:800,y:565,t:1526667942227};\\\", \\\"{x:801,y:565,t:1526667942244};\\\", \\\"{x:802,y:563,t:1526667942278};\\\", \\\"{x:803,y:559,t:1526667942295};\\\", \\\"{x:805,y:554,t:1526667942311};\\\", \\\"{x:807,y:550,t:1526667942327};\\\", \\\"{x:808,y:546,t:1526667942344};\\\", \\\"{x:809,y:542,t:1526667942361};\\\", \\\"{x:810,y:540,t:1526667942378};\\\", \\\"{x:812,y:535,t:1526667942394};\\\", \\\"{x:814,y:533,t:1526667942411};\\\", \\\"{x:815,y:532,t:1526667942427};\\\", \\\"{x:818,y:530,t:1526667942444};\\\", \\\"{x:826,y:527,t:1526667942461};\\\", \\\"{x:830,y:525,t:1526667942477};\\\", \\\"{x:832,y:524,t:1526667942495};\\\", \\\"{x:834,y:523,t:1526667942511};\\\", \\\"{x:834,y:526,t:1526667942712};\\\", \\\"{x:834,y:531,t:1526667942728};\\\", \\\"{x:834,y:537,t:1526667942744};\\\", \\\"{x:834,y:542,t:1526667942761};\\\", \\\"{x:834,y:545,t:1526667942777};\\\", \\\"{x:834,y:546,t:1526667942794};\\\", \\\"{x:827,y:546,t:1526667943043};\\\", \\\"{x:815,y:553,t:1526667943061};\\\", \\\"{x:803,y:560,t:1526667943078};\\\", \\\"{x:789,y:572,t:1526667943094};\\\", \\\"{x:773,y:591,t:1526667943111};\\\", \\\"{x:760,y:614,t:1526667943128};\\\", \\\"{x:735,y:649,t:1526667943145};\\\", \\\"{x:710,y:686,t:1526667943161};\\\", \\\"{x:690,y:716,t:1526667943178};\\\", \\\"{x:672,y:741,t:1526667943194};\\\", \\\"{x:660,y:763,t:1526667943212};\\\", \\\"{x:644,y:783,t:1526667943228};\\\", \\\"{x:629,y:801,t:1526667943244};\\\", \\\"{x:614,y:821,t:1526667943261};\\\", \\\"{x:604,y:828,t:1526667943277};\\\", \\\"{x:600,y:830,t:1526667943294};\\\", \\\"{x:596,y:830,t:1526667943334};\\\", \\\"{x:589,y:830,t:1526667943345};\\\", \\\"{x:579,y:827,t:1526667943362};\\\", \\\"{x:572,y:824,t:1526667943379};\\\", \\\"{x:569,y:822,t:1526667943395};\\\", \\\"{x:564,y:819,t:1526667943411};\\\", \\\"{x:559,y:816,t:1526667943429};\\\", \\\"{x:557,y:816,t:1526667943444};\\\", \\\"{x:553,y:811,t:1526667943462};\\\", \\\"{x:548,y:807,t:1526667943478};\\\", \\\"{x:544,y:802,t:1526667943494};\\\", \\\"{x:541,y:798,t:1526667943512};\\\", \\\"{x:537,y:792,t:1526667943528};\\\", \\\"{x:535,y:788,t:1526667943545};\\\", \\\"{x:534,y:783,t:1526667943562};\\\", \\\"{x:534,y:779,t:1526667943579};\\\", \\\"{x:533,y:775,t:1526667943595};\\\", \\\"{x:533,y:771,t:1526667943612};\\\", \\\"{x:533,y:768,t:1526667943629};\\\", \\\"{x:533,y:767,t:1526667943645};\\\", \\\"{x:532,y:765,t:1526667943661};\\\", \\\"{x:532,y:763,t:1526667943702};\\\", \\\"{x:532,y:762,t:1526667943712};\\\", \\\"{x:533,y:759,t:1526667943729};\\\", \\\"{x:534,y:757,t:1526667943745};\\\", \\\"{x:535,y:757,t:1526667943761};\\\", \\\"{x:536,y:755,t:1526667943778};\\\", \\\"{x:538,y:753,t:1526667943796};\\\", \\\"{x:538,y:752,t:1526667943814};\\\" ] }, { \\\"rt\\\": 34848, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 211517, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-P -7-7-X -O -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:748,t:1526667958810};\\\", \\\"{x:576,y:731,t:1526667958819};\\\", \\\"{x:701,y:664,t:1526667958833};\\\", \\\"{x:856,y:589,t:1526667958850};\\\", \\\"{x:927,y:556,t:1526667958860};\\\", \\\"{x:1105,y:485,t:1526667958877};\\\", \\\"{x:1267,y:427,t:1526667958893};\\\", \\\"{x:1448,y:354,t:1526667958910};\\\", \\\"{x:1609,y:295,t:1526667958927};\\\", \\\"{x:1747,y:259,t:1526667958943};\\\", \\\"{x:1869,y:236,t:1526667958961};\\\", \\\"{x:1888,y:236,t:1526667958976};\\\", \\\"{x:1889,y:236,t:1526667958993};\\\", \\\"{x:1885,y:236,t:1526667959032};\\\", \\\"{x:1880,y:240,t:1526667959043};\\\", \\\"{x:1867,y:245,t:1526667959060};\\\", \\\"{x:1850,y:250,t:1526667959077};\\\", \\\"{x:1825,y:254,t:1526667959093};\\\", \\\"{x:1796,y:257,t:1526667959110};\\\", \\\"{x:1765,y:263,t:1526667959128};\\\", \\\"{x:1723,y:269,t:1526667959143};\\\", \\\"{x:1657,y:293,t:1526667959160};\\\", \\\"{x:1618,y:316,t:1526667959177};\\\", \\\"{x:1580,y:347,t:1526667959193};\\\", \\\"{x:1538,y:386,t:1526667959211};\\\", \\\"{x:1504,y:420,t:1526667959228};\\\", \\\"{x:1477,y:457,t:1526667959244};\\\", \\\"{x:1466,y:485,t:1526667959261};\\\", \\\"{x:1461,y:514,t:1526667959278};\\\", \\\"{x:1459,y:548,t:1526667959294};\\\", \\\"{x:1459,y:571,t:1526667959310};\\\", \\\"{x:1462,y:586,t:1526667959328};\\\", \\\"{x:1463,y:596,t:1526667959345};\\\", \\\"{x:1466,y:613,t:1526667959361};\\\", \\\"{x:1468,y:636,t:1526667959378};\\\", \\\"{x:1472,y:659,t:1526667959394};\\\", \\\"{x:1472,y:674,t:1526667959411};\\\", \\\"{x:1472,y:680,t:1526667959427};\\\", \\\"{x:1471,y:683,t:1526667959445};\\\", \\\"{x:1470,y:684,t:1526667959586};\\\", \\\"{x:1467,y:682,t:1526667959595};\\\", \\\"{x:1463,y:675,t:1526667959611};\\\", \\\"{x:1459,y:669,t:1526667959628};\\\", \\\"{x:1457,y:665,t:1526667959645};\\\", \\\"{x:1455,y:662,t:1526667959661};\\\", \\\"{x:1453,y:660,t:1526667959678};\\\", \\\"{x:1452,y:657,t:1526667959695};\\\", \\\"{x:1451,y:656,t:1526667959711};\\\", \\\"{x:1450,y:654,t:1526667959728};\\\", \\\"{x:1449,y:652,t:1526667959745};\\\", \\\"{x:1448,y:650,t:1526667959762};\\\", \\\"{x:1447,y:649,t:1526667959777};\\\", \\\"{x:1447,y:648,t:1526667959794};\\\", \\\"{x:1451,y:646,t:1526667959986};\\\", \\\"{x:1456,y:644,t:1526667959994};\\\", \\\"{x:1462,y:641,t:1526667960012};\\\", \\\"{x:1470,y:637,t:1526667960027};\\\", \\\"{x:1477,y:634,t:1526667960045};\\\", \\\"{x:1485,y:632,t:1526667960062};\\\", \\\"{x:1489,y:631,t:1526667960078};\\\", \\\"{x:1492,y:630,t:1526667960095};\\\", \\\"{x:1494,y:629,t:1526667960112};\\\", \\\"{x:1495,y:629,t:1526667960128};\\\", \\\"{x:1504,y:629,t:1526667960145};\\\", \\\"{x:1512,y:630,t:1526667960162};\\\", \\\"{x:1519,y:630,t:1526667960177};\\\", \\\"{x:1528,y:632,t:1526667960196};\\\", \\\"{x:1535,y:633,t:1526667960211};\\\", \\\"{x:1546,y:637,t:1526667960228};\\\", \\\"{x:1557,y:639,t:1526667960245};\\\", \\\"{x:1564,y:639,t:1526667960262};\\\", \\\"{x:1569,y:642,t:1526667960279};\\\", \\\"{x:1572,y:643,t:1526667960295};\\\", \\\"{x:1574,y:643,t:1526667960312};\\\", \\\"{x:1575,y:643,t:1526667960329};\\\", \\\"{x:1577,y:643,t:1526667960346};\\\", \\\"{x:1581,y:643,t:1526667960362};\\\", \\\"{x:1585,y:643,t:1526667960379};\\\", \\\"{x:1587,y:643,t:1526667960409};\\\", \\\"{x:1583,y:644,t:1526667961233};\\\", \\\"{x:1577,y:647,t:1526667961246};\\\", \\\"{x:1569,y:651,t:1526667961263};\\\", \\\"{x:1561,y:655,t:1526667961279};\\\", \\\"{x:1554,y:659,t:1526667961296};\\\", \\\"{x:1543,y:665,t:1526667961314};\\\", \\\"{x:1536,y:670,t:1526667961329};\\\", \\\"{x:1529,y:673,t:1526667961346};\\\", \\\"{x:1523,y:677,t:1526667961363};\\\", \\\"{x:1517,y:680,t:1526667961379};\\\", \\\"{x:1509,y:683,t:1526667961396};\\\", \\\"{x:1505,y:685,t:1526667961412};\\\", \\\"{x:1499,y:689,t:1526667961429};\\\", \\\"{x:1493,y:690,t:1526667961445};\\\", \\\"{x:1487,y:691,t:1526667961462};\\\", \\\"{x:1481,y:694,t:1526667961479};\\\", \\\"{x:1474,y:697,t:1526667961496};\\\", \\\"{x:1459,y:700,t:1526667961512};\\\", \\\"{x:1449,y:702,t:1526667961528};\\\", \\\"{x:1438,y:702,t:1526667961546};\\\", \\\"{x:1432,y:703,t:1526667961563};\\\", \\\"{x:1424,y:704,t:1526667961579};\\\", \\\"{x:1415,y:707,t:1526667961596};\\\", \\\"{x:1410,y:707,t:1526667961612};\\\", \\\"{x:1406,y:707,t:1526667961629};\\\", \\\"{x:1403,y:708,t:1526667961646};\\\", \\\"{x:1401,y:708,t:1526667961663};\\\", \\\"{x:1398,y:708,t:1526667961680};\\\", \\\"{x:1397,y:710,t:1526667961696};\\\", \\\"{x:1394,y:710,t:1526667961713};\\\", \\\"{x:1391,y:710,t:1526667961729};\\\", \\\"{x:1387,y:710,t:1526667961746};\\\", \\\"{x:1385,y:711,t:1526667961763};\\\", \\\"{x:1383,y:711,t:1526667961780};\\\", \\\"{x:1382,y:711,t:1526667961801};\\\", \\\"{x:1380,y:711,t:1526667961813};\\\", \\\"{x:1379,y:711,t:1526667961833};\\\", \\\"{x:1378,y:711,t:1526667961849};\\\", \\\"{x:1377,y:711,t:1526667961865};\\\", \\\"{x:1376,y:711,t:1526667961897};\\\", \\\"{x:1374,y:711,t:1526667961913};\\\", \\\"{x:1372,y:711,t:1526667964649};\\\", \\\"{x:1371,y:711,t:1526667964673};\\\", \\\"{x:1370,y:711,t:1526667964690};\\\", \\\"{x:1368,y:711,t:1526667964698};\\\", \\\"{x:1368,y:706,t:1526667964890};\\\", \\\"{x:1368,y:700,t:1526667964898};\\\", \\\"{x:1362,y:683,t:1526667964916};\\\", \\\"{x:1358,y:669,t:1526667964932};\\\", \\\"{x:1356,y:662,t:1526667964949};\\\", \\\"{x:1356,y:658,t:1526667964965};\\\", \\\"{x:1354,y:654,t:1526667964982};\\\", \\\"{x:1354,y:653,t:1526667964998};\\\", \\\"{x:1354,y:652,t:1526667965017};\\\", \\\"{x:1354,y:651,t:1526667965032};\\\", \\\"{x:1353,y:651,t:1526667965066};\\\", \\\"{x:1351,y:647,t:1526667965082};\\\", \\\"{x:1347,y:642,t:1526667965099};\\\", \\\"{x:1340,y:631,t:1526667965114};\\\", \\\"{x:1335,y:619,t:1526667965132};\\\", \\\"{x:1330,y:602,t:1526667965148};\\\", \\\"{x:1321,y:582,t:1526667965164};\\\", \\\"{x:1318,y:568,t:1526667965181};\\\", \\\"{x:1313,y:553,t:1526667965198};\\\", \\\"{x:1304,y:539,t:1526667965214};\\\", \\\"{x:1298,y:524,t:1526667965231};\\\", \\\"{x:1292,y:512,t:1526667965249};\\\", \\\"{x:1287,y:507,t:1526667965264};\\\", \\\"{x:1283,y:504,t:1526667965281};\\\", \\\"{x:1282,y:502,t:1526667965298};\\\", \\\"{x:1278,y:500,t:1526667965315};\\\", \\\"{x:1277,y:499,t:1526667965332};\\\", \\\"{x:1273,y:495,t:1526667965348};\\\", \\\"{x:1275,y:488,t:1526667965401};\\\", \\\"{x:1276,y:481,t:1526667965414};\\\", \\\"{x:1277,y:475,t:1526667965432};\\\", \\\"{x:1277,y:469,t:1526667965449};\\\", \\\"{x:1278,y:469,t:1526667965729};\\\", \\\"{x:1279,y:473,t:1526667965736};\\\", \\\"{x:1281,y:479,t:1526667965748};\\\", \\\"{x:1286,y:492,t:1526667965766};\\\", \\\"{x:1290,y:507,t:1526667965782};\\\", \\\"{x:1296,y:521,t:1526667965798};\\\", \\\"{x:1303,y:539,t:1526667965816};\\\", \\\"{x:1309,y:554,t:1526667965832};\\\", \\\"{x:1320,y:578,t:1526667965849};\\\", \\\"{x:1331,y:598,t:1526667965866};\\\", \\\"{x:1345,y:618,t:1526667965882};\\\", \\\"{x:1362,y:638,t:1526667965899};\\\", \\\"{x:1378,y:652,t:1526667965916};\\\", \\\"{x:1396,y:666,t:1526667965932};\\\", \\\"{x:1410,y:677,t:1526667965949};\\\", \\\"{x:1419,y:688,t:1526667965966};\\\", \\\"{x:1432,y:706,t:1526667965983};\\\", \\\"{x:1444,y:724,t:1526667965999};\\\", \\\"{x:1457,y:740,t:1526667966016};\\\", \\\"{x:1473,y:758,t:1526667966033};\\\", \\\"{x:1483,y:768,t:1526667966049};\\\", \\\"{x:1495,y:777,t:1526667966066};\\\", \\\"{x:1503,y:783,t:1526667966083};\\\", \\\"{x:1505,y:785,t:1526667966099};\\\", \\\"{x:1507,y:786,t:1526667966116};\\\", \\\"{x:1507,y:787,t:1526667966133};\\\", \\\"{x:1504,y:788,t:1526667966194};\\\", \\\"{x:1502,y:788,t:1526667966202};\\\", \\\"{x:1498,y:788,t:1526667966217};\\\", \\\"{x:1485,y:788,t:1526667966233};\\\", \\\"{x:1477,y:788,t:1526667966250};\\\", \\\"{x:1467,y:788,t:1526667966266};\\\", \\\"{x:1449,y:788,t:1526667966284};\\\", \\\"{x:1431,y:788,t:1526667966299};\\\", \\\"{x:1414,y:788,t:1526667966316};\\\", \\\"{x:1395,y:788,t:1526667966333};\\\", \\\"{x:1383,y:788,t:1526667966349};\\\", \\\"{x:1377,y:788,t:1526667966366};\\\", \\\"{x:1373,y:788,t:1526667966383};\\\", \\\"{x:1371,y:788,t:1526667966399};\\\", \\\"{x:1369,y:788,t:1526667966417};\\\", \\\"{x:1367,y:788,t:1526667966433};\\\", \\\"{x:1366,y:788,t:1526667966450};\\\", \\\"{x:1365,y:788,t:1526667966626};\\\", \\\"{x:1365,y:786,t:1526667966698};\\\", \\\"{x:1364,y:784,t:1526667966705};\\\", \\\"{x:1364,y:783,t:1526667966715};\\\", \\\"{x:1364,y:781,t:1526667966733};\\\", \\\"{x:1364,y:780,t:1526667966750};\\\", \\\"{x:1365,y:780,t:1526667969529};\\\", \\\"{x:1370,y:780,t:1526667969537};\\\", \\\"{x:1378,y:781,t:1526667969552};\\\", \\\"{x:1402,y:787,t:1526667969568};\\\", \\\"{x:1427,y:798,t:1526667969585};\\\", \\\"{x:1442,y:802,t:1526667969602};\\\", \\\"{x:1455,y:805,t:1526667969618};\\\", \\\"{x:1468,y:809,t:1526667969635};\\\", \\\"{x:1483,y:813,t:1526667969653};\\\", \\\"{x:1501,y:817,t:1526667969669};\\\", \\\"{x:1519,y:823,t:1526667969685};\\\", \\\"{x:1540,y:829,t:1526667969702};\\\", \\\"{x:1558,y:836,t:1526667969719};\\\", \\\"{x:1571,y:839,t:1526667969736};\\\", \\\"{x:1576,y:841,t:1526667969752};\\\", \\\"{x:1577,y:841,t:1526667969769};\\\", \\\"{x:1577,y:842,t:1526667969785};\\\", \\\"{x:1575,y:842,t:1526667969865};\\\", \\\"{x:1571,y:842,t:1526667969873};\\\", \\\"{x:1567,y:842,t:1526667969885};\\\", \\\"{x:1551,y:841,t:1526667969902};\\\", \\\"{x:1529,y:838,t:1526667969919};\\\", \\\"{x:1501,y:836,t:1526667969936};\\\", \\\"{x:1471,y:833,t:1526667969952};\\\", \\\"{x:1441,y:830,t:1526667969969};\\\", \\\"{x:1435,y:829,t:1526667969986};\\\", \\\"{x:1430,y:828,t:1526667970003};\\\", \\\"{x:1430,y:827,t:1526667970273};\\\", \\\"{x:1432,y:826,t:1526667970285};\\\", \\\"{x:1439,y:822,t:1526667970302};\\\", \\\"{x:1443,y:820,t:1526667970319};\\\", \\\"{x:1445,y:819,t:1526667970336};\\\", \\\"{x:1448,y:819,t:1526667970352};\\\", \\\"{x:1450,y:817,t:1526667970369};\\\", \\\"{x:1451,y:817,t:1526667970386};\\\", \\\"{x:1452,y:816,t:1526667970449};\\\", \\\"{x:1454,y:816,t:1526667970457};\\\", \\\"{x:1455,y:815,t:1526667970470};\\\", \\\"{x:1459,y:813,t:1526667970486};\\\", \\\"{x:1461,y:813,t:1526667970503};\\\", \\\"{x:1463,y:812,t:1526667970519};\\\", \\\"{x:1464,y:811,t:1526667970536};\\\", \\\"{x:1466,y:810,t:1526667970552};\\\", \\\"{x:1469,y:809,t:1526667970569};\\\", \\\"{x:1473,y:807,t:1526667970587};\\\", \\\"{x:1475,y:806,t:1526667970602};\\\", \\\"{x:1478,y:805,t:1526667970620};\\\", \\\"{x:1481,y:802,t:1526667970636};\\\", \\\"{x:1482,y:802,t:1526667970653};\\\", \\\"{x:1483,y:801,t:1526667970670};\\\", \\\"{x:1484,y:801,t:1526667970753};\\\", \\\"{x:1484,y:800,t:1526667971808};\\\", \\\"{x:1483,y:801,t:1526667971820};\\\", \\\"{x:1479,y:808,t:1526667971837};\\\", \\\"{x:1475,y:816,t:1526667971853};\\\", \\\"{x:1471,y:824,t:1526667971869};\\\", \\\"{x:1470,y:829,t:1526667971887};\\\", \\\"{x:1467,y:836,t:1526667971903};\\\", \\\"{x:1467,y:838,t:1526667971920};\\\", \\\"{x:1466,y:840,t:1526667971937};\\\", \\\"{x:1466,y:842,t:1526667971953};\\\", \\\"{x:1466,y:843,t:1526667971970};\\\", \\\"{x:1465,y:846,t:1526667971987};\\\", \\\"{x:1465,y:847,t:1526667972186};\\\", \\\"{x:1468,y:847,t:1526667972201};\\\", \\\"{x:1470,y:847,t:1526667972209};\\\", \\\"{x:1471,y:845,t:1526667972394};\\\", \\\"{x:1471,y:844,t:1526667972404};\\\", \\\"{x:1471,y:841,t:1526667972421};\\\", \\\"{x:1471,y:836,t:1526667972438};\\\", \\\"{x:1471,y:831,t:1526667972454};\\\", \\\"{x:1471,y:826,t:1526667972470};\\\", \\\"{x:1472,y:822,t:1526667972487};\\\", \\\"{x:1472,y:821,t:1526667972503};\\\", \\\"{x:1472,y:819,t:1526667972519};\\\", \\\"{x:1474,y:813,t:1526667972537};\\\", \\\"{x:1475,y:807,t:1526667972554};\\\", \\\"{x:1475,y:801,t:1526667972570};\\\", \\\"{x:1475,y:796,t:1526667972587};\\\", \\\"{x:1476,y:793,t:1526667972604};\\\", \\\"{x:1476,y:792,t:1526667972620};\\\", \\\"{x:1477,y:790,t:1526667972637};\\\", \\\"{x:1478,y:789,t:1526667972653};\\\", \\\"{x:1480,y:786,t:1526667972671};\\\", \\\"{x:1481,y:785,t:1526667972688};\\\", \\\"{x:1482,y:785,t:1526667972703};\\\", \\\"{x:1486,y:783,t:1526667972720};\\\", \\\"{x:1487,y:782,t:1526667972737};\\\", \\\"{x:1488,y:781,t:1526667972753};\\\", \\\"{x:1490,y:781,t:1526667972771};\\\", \\\"{x:1492,y:779,t:1526667972787};\\\", \\\"{x:1495,y:778,t:1526667972804};\\\", \\\"{x:1497,y:778,t:1526667972821};\\\", \\\"{x:1498,y:777,t:1526667972838};\\\", \\\"{x:1500,y:777,t:1526667972986};\\\", \\\"{x:1501,y:776,t:1526667972993};\\\", \\\"{x:1503,y:775,t:1526667973004};\\\", \\\"{x:1506,y:773,t:1526667973022};\\\", \\\"{x:1509,y:772,t:1526667973037};\\\", \\\"{x:1512,y:771,t:1526667973055};\\\", \\\"{x:1513,y:771,t:1526667973433};\\\", \\\"{x:1513,y:773,t:1526667973441};\\\", \\\"{x:1513,y:774,t:1526667973455};\\\", \\\"{x:1513,y:777,t:1526667973472};\\\", \\\"{x:1513,y:779,t:1526667973490};\\\", \\\"{x:1513,y:781,t:1526667973505};\\\", \\\"{x:1513,y:782,t:1526667973521};\\\", \\\"{x:1513,y:785,t:1526667974984};\\\", \\\"{x:1513,y:788,t:1526667974991};\\\", \\\"{x:1510,y:793,t:1526667975006};\\\", \\\"{x:1509,y:803,t:1526667975022};\\\", \\\"{x:1504,y:817,t:1526667975038};\\\", \\\"{x:1501,y:829,t:1526667975055};\\\", \\\"{x:1500,y:836,t:1526667975071};\\\", \\\"{x:1499,y:842,t:1526667975088};\\\", \\\"{x:1499,y:846,t:1526667975105};\\\", \\\"{x:1497,y:851,t:1526667975122};\\\", \\\"{x:1496,y:855,t:1526667975139};\\\", \\\"{x:1496,y:859,t:1526667975155};\\\", \\\"{x:1495,y:862,t:1526667975172};\\\", \\\"{x:1494,y:863,t:1526667975188};\\\", \\\"{x:1494,y:862,t:1526667975352};\\\", \\\"{x:1494,y:857,t:1526667975360};\\\", \\\"{x:1494,y:853,t:1526667975372};\\\", \\\"{x:1498,y:838,t:1526667975389};\\\", \\\"{x:1502,y:820,t:1526667975406};\\\", \\\"{x:1507,y:799,t:1526667975422};\\\", \\\"{x:1510,y:785,t:1526667975439};\\\", \\\"{x:1510,y:764,t:1526667975456};\\\", \\\"{x:1507,y:747,t:1526667975473};\\\", \\\"{x:1493,y:723,t:1526667975489};\\\", \\\"{x:1482,y:714,t:1526667975505};\\\", \\\"{x:1462,y:708,t:1526667975522};\\\", \\\"{x:1425,y:701,t:1526667975539};\\\", \\\"{x:1345,y:696,t:1526667975556};\\\", \\\"{x:1246,y:696,t:1526667975573};\\\", \\\"{x:1118,y:696,t:1526667975589};\\\", \\\"{x:977,y:696,t:1526667975606};\\\", \\\"{x:819,y:702,t:1526667975623};\\\", \\\"{x:672,y:723,t:1526667975639};\\\", \\\"{x:512,y:749,t:1526667975656};\\\", \\\"{x:412,y:777,t:1526667975673};\\\", \\\"{x:343,y:797,t:1526667975691};\\\", \\\"{x:301,y:807,t:1526667975708};\\\", \\\"{x:287,y:812,t:1526667975724};\\\", \\\"{x:288,y:810,t:1526667975808};\\\", \\\"{x:298,y:800,t:1526667975825};\\\", \\\"{x:308,y:787,t:1526667975842};\\\", \\\"{x:320,y:772,t:1526667975858};\\\", \\\"{x:330,y:757,t:1526667975874};\\\", \\\"{x:339,y:742,t:1526667975891};\\\", \\\"{x:348,y:726,t:1526667975908};\\\", \\\"{x:354,y:711,t:1526667975924};\\\", \\\"{x:364,y:689,t:1526667975942};\\\", \\\"{x:372,y:670,t:1526667975959};\\\", \\\"{x:377,y:652,t:1526667975975};\\\", \\\"{x:393,y:635,t:1526667975992};\\\", \\\"{x:406,y:627,t:1526667976008};\\\", \\\"{x:419,y:617,t:1526667976024};\\\", \\\"{x:427,y:614,t:1526667976041};\\\", \\\"{x:430,y:612,t:1526667976058};\\\", \\\"{x:424,y:615,t:1526667976152};\\\", \\\"{x:418,y:617,t:1526667976159};\\\", \\\"{x:412,y:620,t:1526667976174};\\\", \\\"{x:406,y:623,t:1526667976191};\\\", \\\"{x:400,y:626,t:1526667976209};\\\", \\\"{x:398,y:630,t:1526667976224};\\\", \\\"{x:395,y:634,t:1526667976241};\\\", \\\"{x:394,y:636,t:1526667976257};\\\", \\\"{x:391,y:640,t:1526667976274};\\\", \\\"{x:389,y:644,t:1526667976291};\\\", \\\"{x:387,y:647,t:1526667976308};\\\", \\\"{x:382,y:652,t:1526667976325};\\\", \\\"{x:377,y:657,t:1526667976341};\\\", \\\"{x:371,y:662,t:1526667976358};\\\", \\\"{x:364,y:667,t:1526667976375};\\\", \\\"{x:359,y:669,t:1526667976391};\\\", \\\"{x:353,y:672,t:1526667976408};\\\", \\\"{x:346,y:673,t:1526667976424};\\\", \\\"{x:337,y:674,t:1526667976441};\\\", \\\"{x:331,y:674,t:1526667976458};\\\", \\\"{x:327,y:674,t:1526667976475};\\\", \\\"{x:322,y:674,t:1526667976491};\\\", \\\"{x:318,y:674,t:1526667976507};\\\", \\\"{x:308,y:674,t:1526667976525};\\\", \\\"{x:298,y:674,t:1526667976541};\\\", \\\"{x:286,y:674,t:1526667976558};\\\", \\\"{x:276,y:674,t:1526667976574};\\\", \\\"{x:268,y:674,t:1526667976590};\\\", \\\"{x:257,y:674,t:1526667976607};\\\", \\\"{x:251,y:674,t:1526667976625};\\\", \\\"{x:238,y:674,t:1526667976640};\\\", \\\"{x:223,y:674,t:1526667976658};\\\", \\\"{x:210,y:674,t:1526667976675};\\\", \\\"{x:201,y:674,t:1526667976691};\\\", \\\"{x:193,y:674,t:1526667976708};\\\", \\\"{x:188,y:674,t:1526667976725};\\\", \\\"{x:184,y:674,t:1526667976742};\\\", \\\"{x:181,y:674,t:1526667976757};\\\", \\\"{x:179,y:674,t:1526667976774};\\\", \\\"{x:178,y:673,t:1526667976809};\\\", \\\"{x:177,y:671,t:1526667976825};\\\", \\\"{x:175,y:669,t:1526667976842};\\\", \\\"{x:174,y:665,t:1526667976858};\\\", \\\"{x:174,y:661,t:1526667976875};\\\", \\\"{x:174,y:657,t:1526667976891};\\\", \\\"{x:174,y:654,t:1526667976908};\\\", \\\"{x:174,y:651,t:1526667976925};\\\", \\\"{x:178,y:647,t:1526667976942};\\\", \\\"{x:183,y:642,t:1526667976958};\\\", \\\"{x:187,y:639,t:1526667976975};\\\", \\\"{x:190,y:633,t:1526667976992};\\\", \\\"{x:191,y:631,t:1526667977009};\\\", \\\"{x:194,y:628,t:1526667977025};\\\", \\\"{x:197,y:626,t:1526667977041};\\\", \\\"{x:205,y:622,t:1526667977057};\\\", \\\"{x:215,y:617,t:1526667977074};\\\", \\\"{x:230,y:611,t:1526667977092};\\\", \\\"{x:246,y:606,t:1526667977108};\\\", \\\"{x:264,y:601,t:1526667977125};\\\", \\\"{x:292,y:597,t:1526667977143};\\\", \\\"{x:334,y:591,t:1526667977159};\\\", \\\"{x:391,y:588,t:1526667977175};\\\", \\\"{x:455,y:588,t:1526667977191};\\\", \\\"{x:553,y:586,t:1526667977209};\\\", \\\"{x:606,y:586,t:1526667977225};\\\", \\\"{x:642,y:586,t:1526667977242};\\\", \\\"{x:665,y:583,t:1526667977259};\\\", \\\"{x:673,y:583,t:1526667977275};\\\", \\\"{x:675,y:583,t:1526667977328};\\\", \\\"{x:677,y:583,t:1526667977344};\\\", \\\"{x:681,y:583,t:1526667977358};\\\", \\\"{x:691,y:583,t:1526667977375};\\\", \\\"{x:702,y:583,t:1526667977392};\\\", \\\"{x:709,y:583,t:1526667977408};\\\", \\\"{x:718,y:583,t:1526667977425};\\\", \\\"{x:734,y:583,t:1526667977442};\\\", \\\"{x:755,y:581,t:1526667977458};\\\", \\\"{x:772,y:575,t:1526667977476};\\\", \\\"{x:786,y:571,t:1526667977492};\\\", \\\"{x:799,y:566,t:1526667977509};\\\", \\\"{x:808,y:562,t:1526667977526};\\\", \\\"{x:813,y:559,t:1526667977542};\\\", \\\"{x:818,y:557,t:1526667977559};\\\", \\\"{x:820,y:555,t:1526667977576};\\\", \\\"{x:822,y:555,t:1526667977664};\\\", \\\"{x:824,y:557,t:1526667977676};\\\", \\\"{x:826,y:561,t:1526667977692};\\\", \\\"{x:830,y:567,t:1526667977709};\\\", \\\"{x:834,y:572,t:1526667977726};\\\", \\\"{x:835,y:576,t:1526667977741};\\\", \\\"{x:836,y:578,t:1526667977759};\\\", \\\"{x:837,y:579,t:1526667977775};\\\", \\\"{x:837,y:580,t:1526667977808};\\\", \\\"{x:837,y:581,t:1526667977816};\\\", \\\"{x:837,y:583,t:1526667978176};\\\", \\\"{x:825,y:589,t:1526667978192};\\\", \\\"{x:818,y:592,t:1526667978209};\\\", \\\"{x:810,y:595,t:1526667978227};\\\", \\\"{x:804,y:599,t:1526667978243};\\\", \\\"{x:796,y:601,t:1526667978260};\\\", \\\"{x:791,y:603,t:1526667978276};\\\", \\\"{x:787,y:606,t:1526667978293};\\\", \\\"{x:780,y:607,t:1526667978309};\\\", \\\"{x:774,y:609,t:1526667978326};\\\", \\\"{x:761,y:611,t:1526667978343};\\\", \\\"{x:742,y:613,t:1526667978359};\\\", \\\"{x:711,y:613,t:1526667978377};\\\", \\\"{x:684,y:613,t:1526667978393};\\\", \\\"{x:652,y:613,t:1526667978409};\\\", \\\"{x:621,y:613,t:1526667978426};\\\", \\\"{x:599,y:613,t:1526667978443};\\\", \\\"{x:587,y:611,t:1526667978460};\\\", \\\"{x:588,y:610,t:1526667978536};\\\", \\\"{x:590,y:609,t:1526667978552};\\\", \\\"{x:593,y:608,t:1526667978568};\\\", \\\"{x:594,y:607,t:1526667978576};\\\", \\\"{x:600,y:605,t:1526667978593};\\\", \\\"{x:606,y:602,t:1526667978609};\\\", \\\"{x:611,y:600,t:1526667978627};\\\", \\\"{x:616,y:598,t:1526667978642};\\\", \\\"{x:619,y:597,t:1526667978660};\\\", \\\"{x:619,y:595,t:1526667978800};\\\", \\\"{x:620,y:592,t:1526667978811};\\\", \\\"{x:620,y:591,t:1526667978826};\\\", \\\"{x:620,y:590,t:1526667978843};\\\", \\\"{x:620,y:589,t:1526667979049};\\\", \\\"{x:622,y:588,t:1526667979061};\\\", \\\"{x:622,y:587,t:1526667979089};\\\", \\\"{x:623,y:586,t:1526667979120};\\\", \\\"{x:621,y:588,t:1526667979344};\\\", \\\"{x:616,y:598,t:1526667979360};\\\", \\\"{x:609,y:612,t:1526667979378};\\\", \\\"{x:603,y:624,t:1526667979394};\\\", \\\"{x:600,y:631,t:1526667979410};\\\", \\\"{x:598,y:637,t:1526667979427};\\\", \\\"{x:596,y:643,t:1526667979444};\\\", \\\"{x:596,y:650,t:1526667979460};\\\", \\\"{x:594,y:660,t:1526667979476};\\\", \\\"{x:590,y:670,t:1526667979494};\\\", \\\"{x:586,y:681,t:1526667979510};\\\", \\\"{x:584,y:688,t:1526667979527};\\\", \\\"{x:584,y:690,t:1526667979544};\\\", \\\"{x:582,y:691,t:1526667979736};\\\", \\\"{x:580,y:691,t:1526667979752};\\\", \\\"{x:578,y:692,t:1526667979760};\\\", \\\"{x:570,y:696,t:1526667979777};\\\", \\\"{x:562,y:699,t:1526667979794};\\\", \\\"{x:558,y:701,t:1526667979810};\\\", \\\"{x:554,y:703,t:1526667979827};\\\", \\\"{x:551,y:704,t:1526667979844};\\\", \\\"{x:550,y:706,t:1526667979861};\\\", \\\"{x:549,y:707,t:1526667979877};\\\", \\\"{x:547,y:709,t:1526667979894};\\\", \\\"{x:547,y:711,t:1526667979910};\\\", \\\"{x:547,y:712,t:1526667979927};\\\", \\\"{x:547,y:714,t:1526667979944};\\\", \\\"{x:547,y:716,t:1526667979960};\\\", \\\"{x:547,y:719,t:1526667979977};\\\", \\\"{x:546,y:725,t:1526667979994};\\\", \\\"{x:544,y:730,t:1526667980011};\\\", \\\"{x:544,y:734,t:1526667980027};\\\", \\\"{x:544,y:736,t:1526667980044};\\\", \\\"{x:544,y:739,t:1526667980060};\\\", \\\"{x:544,y:741,t:1526667980077};\\\", \\\"{x:544,y:742,t:1526667980094};\\\", \\\"{x:543,y:743,t:1526667980176};\\\", \\\"{x:543,y:743,t:1526667980252};\\\", \\\"{x:542,y:743,t:1526667980673};\\\", \\\"{x:541,y:742,t:1526667980689};\\\", \\\"{x:541,y:741,t:1526667980696};\\\", \\\"{x:541,y:738,t:1526667980711};\\\", \\\"{x:540,y:727,t:1526667980728};\\\", \\\"{x:540,y:719,t:1526667980745};\\\", \\\"{x:540,y:712,t:1526667980761};\\\", \\\"{x:538,y:706,t:1526667980778};\\\", \\\"{x:537,y:702,t:1526667980795};\\\", \\\"{x:536,y:696,t:1526667980811};\\\", \\\"{x:536,y:692,t:1526667980828};\\\", \\\"{x:536,y:688,t:1526667980845};\\\", \\\"{x:536,y:680,t:1526667980861};\\\", \\\"{x:535,y:674,t:1526667980878};\\\", \\\"{x:534,y:663,t:1526667980895};\\\", \\\"{x:531,y:656,t:1526667980912};\\\", \\\"{x:531,y:641,t:1526667980928};\\\", \\\"{x:531,y:626,t:1526667980945};\\\", \\\"{x:531,y:624,t:1526667980961};\\\" ] }, { \\\"rt\\\": 16963, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 229832, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"K\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:622,t:1526667986352};\\\", \\\"{x:533,y:621,t:1526667986368};\\\", \\\"{x:537,y:620,t:1526667986376};\\\", \\\"{x:537,y:619,t:1526667986568};\\\", \\\"{x:537,y:616,t:1526667986583};\\\", \\\"{x:535,y:608,t:1526667986591};\\\", \\\"{x:529,y:595,t:1526667986604};\\\", \\\"{x:507,y:567,t:1526667986621};\\\", \\\"{x:487,y:553,t:1526667986638};\\\", \\\"{x:480,y:548,t:1526667986649};\\\", \\\"{x:479,y:547,t:1526667986688};\\\", \\\"{x:480,y:547,t:1526667986784};\\\", \\\"{x:483,y:547,t:1526667986800};\\\", \\\"{x:486,y:547,t:1526667986816};\\\", \\\"{x:486,y:544,t:1526667986897};\\\", \\\"{x:485,y:543,t:1526667986928};\\\", \\\"{x:484,y:542,t:1526667986944};\\\", \\\"{x:483,y:540,t:1526667986952};\\\", \\\"{x:481,y:538,t:1526667986967};\\\", \\\"{x:478,y:534,t:1526667986984};\\\", \\\"{x:467,y:525,t:1526667987000};\\\", \\\"{x:460,y:522,t:1526667987017};\\\", \\\"{x:444,y:518,t:1526667987033};\\\", \\\"{x:422,y:515,t:1526667987049};\\\", \\\"{x:399,y:515,t:1526667987066};\\\", \\\"{x:380,y:515,t:1526667987083};\\\", \\\"{x:363,y:515,t:1526667987100};\\\", \\\"{x:351,y:515,t:1526667987116};\\\", \\\"{x:347,y:515,t:1526667987133};\\\", \\\"{x:342,y:515,t:1526667987149};\\\", \\\"{x:335,y:515,t:1526667987166};\\\", \\\"{x:329,y:515,t:1526667987183};\\\", \\\"{x:325,y:515,t:1526667987199};\\\", \\\"{x:321,y:515,t:1526667987217};\\\", \\\"{x:316,y:515,t:1526667987233};\\\", \\\"{x:309,y:515,t:1526667987249};\\\", \\\"{x:300,y:515,t:1526667987267};\\\", \\\"{x:293,y:515,t:1526667987284};\\\", \\\"{x:291,y:515,t:1526667987301};\\\", \\\"{x:290,y:515,t:1526667987345};\\\", \\\"{x:289,y:515,t:1526667987361};\\\", \\\"{x:289,y:513,t:1526667987376};\\\", \\\"{x:289,y:510,t:1526667987385};\\\", \\\"{x:298,y:500,t:1526667987400};\\\", \\\"{x:317,y:487,t:1526667987417};\\\", \\\"{x:328,y:478,t:1526667987435};\\\", \\\"{x:340,y:470,t:1526667987450};\\\", \\\"{x:349,y:463,t:1526667987467};\\\", \\\"{x:360,y:455,t:1526667987483};\\\", \\\"{x:371,y:448,t:1526667987500};\\\", \\\"{x:384,y:434,t:1526667987517};\\\", \\\"{x:397,y:425,t:1526667987534};\\\", \\\"{x:410,y:418,t:1526667987550};\\\", \\\"{x:416,y:415,t:1526667987567};\\\", \\\"{x:422,y:412,t:1526667987584};\\\", \\\"{x:425,y:409,t:1526667987601};\\\", \\\"{x:432,y:406,t:1526667987618};\\\", \\\"{x:443,y:401,t:1526667987634};\\\", \\\"{x:450,y:398,t:1526667987651};\\\", \\\"{x:453,y:396,t:1526667987667};\\\", \\\"{x:458,y:394,t:1526667987685};\\\", \\\"{x:460,y:393,t:1526667987701};\\\", \\\"{x:462,y:393,t:1526667987718};\\\", \\\"{x:464,y:392,t:1526667987734};\\\", \\\"{x:465,y:392,t:1526667987752};\\\", \\\"{x:465,y:395,t:1526667992353};\\\", \\\"{x:461,y:407,t:1526667992363};\\\", \\\"{x:453,y:435,t:1526667992381};\\\", \\\"{x:440,y:477,t:1526667992396};\\\", \\\"{x:429,y:517,t:1526667992414};\\\", \\\"{x:416,y:556,t:1526667992430};\\\", \\\"{x:391,y:599,t:1526667992454};\\\", \\\"{x:379,y:613,t:1526667992471};\\\", \\\"{x:373,y:622,t:1526667992487};\\\", \\\"{x:373,y:625,t:1526667992505};\\\", \\\"{x:373,y:628,t:1526667992520};\\\", \\\"{x:373,y:632,t:1526667992537};\\\", \\\"{x:374,y:638,t:1526667992554};\\\", \\\"{x:377,y:643,t:1526667992571};\\\", \\\"{x:378,y:647,t:1526667992587};\\\", \\\"{x:379,y:648,t:1526667992604};\\\", \\\"{x:380,y:650,t:1526667992621};\\\", \\\"{x:381,y:652,t:1526667992637};\\\", \\\"{x:383,y:655,t:1526667992655};\\\", \\\"{x:385,y:656,t:1526667992671};\\\", \\\"{x:390,y:657,t:1526667992688};\\\", \\\"{x:394,y:657,t:1526667992704};\\\", \\\"{x:402,y:657,t:1526667992721};\\\", \\\"{x:407,y:657,t:1526667992738};\\\", \\\"{x:409,y:656,t:1526667992755};\\\", \\\"{x:411,y:655,t:1526667992771};\\\", \\\"{x:412,y:655,t:1526667992787};\\\", \\\"{x:413,y:654,t:1526667992804};\\\", \\\"{x:414,y:649,t:1526667992821};\\\", \\\"{x:415,y:642,t:1526667992838};\\\", \\\"{x:415,y:630,t:1526667992856};\\\", \\\"{x:405,y:614,t:1526667992872};\\\", \\\"{x:396,y:604,t:1526667992887};\\\", \\\"{x:394,y:599,t:1526667992905};\\\", \\\"{x:392,y:596,t:1526667992921};\\\", \\\"{x:391,y:594,t:1526667992937};\\\", \\\"{x:391,y:593,t:1526667992969};\\\", \\\"{x:391,y:592,t:1526667993033};\\\", \\\"{x:391,y:591,t:1526667993057};\\\", \\\"{x:391,y:589,t:1526667993098};\\\", \\\"{x:392,y:589,t:1526667993112};\\\", \\\"{x:394,y:588,t:1526667993121};\\\", \\\"{x:398,y:585,t:1526667993138};\\\", \\\"{x:402,y:582,t:1526667993155};\\\", \\\"{x:403,y:581,t:1526667993172};\\\", \\\"{x:405,y:581,t:1526667993188};\\\", \\\"{x:407,y:579,t:1526667993415};\\\", \\\"{x:409,y:579,t:1526667993424};\\\", \\\"{x:411,y:577,t:1526667993439};\\\", \\\"{x:417,y:575,t:1526667993455};\\\", \\\"{x:425,y:571,t:1526667993472};\\\", \\\"{x:430,y:569,t:1526667993488};\\\", \\\"{x:435,y:567,t:1526667993505};\\\", \\\"{x:448,y:561,t:1526667993522};\\\", \\\"{x:468,y:554,t:1526667993539};\\\", \\\"{x:485,y:545,t:1526667993554};\\\", \\\"{x:495,y:542,t:1526667993572};\\\", \\\"{x:500,y:539,t:1526667993590};\\\", \\\"{x:506,y:537,t:1526667993605};\\\", \\\"{x:511,y:535,t:1526667993622};\\\", \\\"{x:512,y:534,t:1526667993639};\\\", \\\"{x:513,y:534,t:1526667993655};\\\", \\\"{x:514,y:533,t:1526667993689};\\\", \\\"{x:517,y:533,t:1526667993705};\\\", \\\"{x:526,y:533,t:1526667993722};\\\", \\\"{x:534,y:533,t:1526667993739};\\\", \\\"{x:537,y:533,t:1526667993756};\\\", \\\"{x:539,y:533,t:1526667993772};\\\", \\\"{x:545,y:533,t:1526667993789};\\\", \\\"{x:553,y:533,t:1526667993806};\\\", \\\"{x:560,y:533,t:1526667993822};\\\", \\\"{x:565,y:533,t:1526667993839};\\\", \\\"{x:569,y:533,t:1526667993856};\\\", \\\"{x:580,y:537,t:1526667993872};\\\", \\\"{x:590,y:540,t:1526667993888};\\\", \\\"{x:600,y:543,t:1526667993907};\\\", \\\"{x:605,y:544,t:1526667993922};\\\", \\\"{x:608,y:544,t:1526667993939};\\\", \\\"{x:610,y:545,t:1526667993955};\\\", \\\"{x:611,y:546,t:1526667993971};\\\", \\\"{x:613,y:546,t:1526667993989};\\\", \\\"{x:614,y:546,t:1526667994005};\\\", \\\"{x:615,y:546,t:1526667994022};\\\", \\\"{x:616,y:547,t:1526667994263};\\\", \\\"{x:616,y:549,t:1526667994272};\\\", \\\"{x:616,y:553,t:1526667994289};\\\", \\\"{x:617,y:557,t:1526667994306};\\\", \\\"{x:619,y:564,t:1526667994323};\\\", \\\"{x:620,y:568,t:1526667994339};\\\", \\\"{x:621,y:572,t:1526667994356};\\\", \\\"{x:622,y:574,t:1526667994373};\\\", \\\"{x:622,y:576,t:1526667994389};\\\", \\\"{x:624,y:578,t:1526667994405};\\\", \\\"{x:624,y:581,t:1526667994423};\\\", \\\"{x:625,y:584,t:1526667994438};\\\", \\\"{x:627,y:588,t:1526667994456};\\\", \\\"{x:630,y:593,t:1526667994473};\\\", \\\"{x:635,y:598,t:1526667994489};\\\", \\\"{x:647,y:609,t:1526667994506};\\\", \\\"{x:665,y:620,t:1526667994523};\\\", \\\"{x:677,y:629,t:1526667994539};\\\", \\\"{x:692,y:634,t:1526667994556};\\\", \\\"{x:710,y:639,t:1526667994573};\\\", \\\"{x:724,y:640,t:1526667994589};\\\", \\\"{x:729,y:640,t:1526667994605};\\\", \\\"{x:737,y:637,t:1526667994623};\\\", \\\"{x:745,y:635,t:1526667994639};\\\", \\\"{x:755,y:630,t:1526667994657};\\\", \\\"{x:768,y:623,t:1526667994673};\\\", \\\"{x:774,y:620,t:1526667994690};\\\", \\\"{x:779,y:618,t:1526667994706};\\\", \\\"{x:781,y:616,t:1526667994723};\\\", \\\"{x:782,y:616,t:1526667994740};\\\", \\\"{x:784,y:616,t:1526667994756};\\\", \\\"{x:790,y:615,t:1526667994773};\\\", \\\"{x:794,y:615,t:1526667994790};\\\", \\\"{x:798,y:615,t:1526667994806};\\\", \\\"{x:807,y:615,t:1526667994823};\\\", \\\"{x:818,y:615,t:1526667994840};\\\", \\\"{x:821,y:615,t:1526667994857};\\\", \\\"{x:822,y:615,t:1526667994897};\\\", \\\"{x:824,y:616,t:1526667994912};\\\", \\\"{x:825,y:616,t:1526667994923};\\\", \\\"{x:827,y:616,t:1526667994941};\\\", \\\"{x:828,y:616,t:1526667995072};\\\", \\\"{x:828,y:616,t:1526667995102};\\\", \\\"{x:828,y:619,t:1526667995122};\\\", \\\"{x:828,y:623,t:1526667995140};\\\", \\\"{x:827,y:626,t:1526667995156};\\\", \\\"{x:824,y:633,t:1526667995173};\\\", \\\"{x:823,y:644,t:1526667995190};\\\", \\\"{x:818,y:654,t:1526667995207};\\\", \\\"{x:812,y:664,t:1526667995223};\\\", \\\"{x:809,y:673,t:1526667995239};\\\", \\\"{x:805,y:681,t:1526667995256};\\\", \\\"{x:797,y:691,t:1526667995273};\\\", \\\"{x:789,y:699,t:1526667995290};\\\", \\\"{x:773,y:707,t:1526667995307};\\\", \\\"{x:753,y:718,t:1526667995323};\\\", \\\"{x:726,y:734,t:1526667995340};\\\", \\\"{x:697,y:749,t:1526667995357};\\\", \\\"{x:668,y:761,t:1526667995373};\\\", \\\"{x:644,y:770,t:1526667995390};\\\", \\\"{x:623,y:777,t:1526667995406};\\\", \\\"{x:607,y:778,t:1526667995423};\\\", \\\"{x:587,y:782,t:1526667995440};\\\", \\\"{x:581,y:782,t:1526667995456};\\\", \\\"{x:579,y:782,t:1526667995473};\\\", \\\"{x:577,y:782,t:1526667995490};\\\", \\\"{x:576,y:780,t:1526667995507};\\\", \\\"{x:574,y:778,t:1526667995524};\\\", \\\"{x:571,y:775,t:1526667995540};\\\", \\\"{x:567,y:772,t:1526667995557};\\\", \\\"{x:565,y:771,t:1526667995574};\\\", \\\"{x:563,y:768,t:1526667995590};\\\", \\\"{x:560,y:766,t:1526667995607};\\\", \\\"{x:558,y:764,t:1526667995624};\\\", \\\"{x:557,y:763,t:1526667995665};\\\", \\\"{x:556,y:763,t:1526667995674};\\\", \\\"{x:556,y:761,t:1526667995696};\\\", \\\"{x:555,y:761,t:1526667995721};\\\", \\\"{x:555,y:760,t:1526667995728};\\\", \\\"{x:554,y:759,t:1526667995740};\\\", \\\"{x:553,y:758,t:1526667995761};\\\", \\\"{x:553,y:757,t:1526667995816};\\\", \\\"{x:552,y:756,t:1526667995833};\\\", \\\"{x:552,y:755,t:1526667995848};\\\", \\\"{x:551,y:754,t:1526667995859};\\\", \\\"{x:551,y:753,t:1526667995874};\\\", \\\"{x:550,y:753,t:1526667995891};\\\", \\\"{x:550,y:752,t:1526667995907};\\\", \\\"{x:550,y:751,t:1526667995924};\\\", \\\"{x:550,y:750,t:1526667995941};\\\", \\\"{x:550,y:749,t:1526667995968};\\\", \\\"{x:550,y:748,t:1526667995977};\\\", \\\"{x:550,y:747,t:1526667995990};\\\", \\\"{x:550,y:743,t:1526667996007};\\\", \\\"{x:552,y:728,t:1526667996024};\\\", \\\"{x:563,y:710,t:1526667996041};\\\", \\\"{x:589,y:687,t:1526667996056};\\\", \\\"{x:652,y:651,t:1526667996074};\\\", \\\"{x:740,y:614,t:1526667996091};\\\", \\\"{x:815,y:578,t:1526667996107};\\\", \\\"{x:876,y:552,t:1526667996124};\\\", \\\"{x:920,y:534,t:1526667996141};\\\", \\\"{x:939,y:525,t:1526667996156};\\\", \\\"{x:946,y:523,t:1526667996175};\\\", \\\"{x:947,y:522,t:1526667996191};\\\", \\\"{x:943,y:522,t:1526667996305};\\\", \\\"{x:937,y:524,t:1526667996312};\\\", \\\"{x:929,y:529,t:1526667996325};\\\", \\\"{x:909,y:538,t:1526667996341};\\\", \\\"{x:892,y:547,t:1526667996357};\\\", \\\"{x:880,y:553,t:1526667996374};\\\", \\\"{x:875,y:556,t:1526667996391};\\\", \\\"{x:873,y:558,t:1526667996408};\\\", \\\"{x:873,y:560,t:1526667996424};\\\", \\\"{x:872,y:561,t:1526667996441};\\\", \\\"{x:871,y:563,t:1526667996459};\\\", \\\"{x:869,y:566,t:1526667996474};\\\", \\\"{x:869,y:568,t:1526667996491};\\\", \\\"{x:867,y:569,t:1526667996508};\\\", \\\"{x:867,y:570,t:1526667996524};\\\", \\\"{x:867,y:571,t:1526667996541};\\\", \\\"{x:866,y:573,t:1526667996558};\\\", \\\"{x:864,y:577,t:1526667996574};\\\", \\\"{x:862,y:582,t:1526667996591};\\\", \\\"{x:860,y:590,t:1526667996609};\\\", \\\"{x:860,y:591,t:1526667996624};\\\", \\\"{x:860,y:592,t:1526667996672};\\\", \\\"{x:860,y:591,t:1526667997065};\\\", \\\"{x:860,y:589,t:1526667997076};\\\", \\\"{x:860,y:587,t:1526667997093};\\\", \\\"{x:860,y:586,t:1526667997107};\\\", \\\"{x:860,y:589,t:1526667997368};\\\", \\\"{x:859,y:592,t:1526667997376};\\\", \\\"{x:859,y:597,t:1526667997392};\\\", \\\"{x:858,y:603,t:1526667997408};\\\", \\\"{x:858,y:606,t:1526667997425};\\\", \\\"{x:858,y:608,t:1526667997442};\\\", \\\"{x:856,y:611,t:1526667997752};\\\", \\\"{x:854,y:613,t:1526667997760};\\\", \\\"{x:851,y:616,t:1526667997774};\\\", \\\"{x:840,y:627,t:1526667997792};\\\", \\\"{x:830,y:641,t:1526667997809};\\\", \\\"{x:813,y:661,t:1526667997824};\\\", \\\"{x:796,y:677,t:1526667997842};\\\", \\\"{x:779,y:691,t:1526667997859};\\\", \\\"{x:767,y:701,t:1526667997874};\\\", \\\"{x:754,y:711,t:1526667997892};\\\", \\\"{x:749,y:714,t:1526667997909};\\\", \\\"{x:744,y:716,t:1526667997925};\\\", \\\"{x:740,y:719,t:1526667997942};\\\", \\\"{x:733,y:719,t:1526667997960};\\\", \\\"{x:728,y:720,t:1526667997975};\\\", \\\"{x:720,y:723,t:1526667997992};\\\", \\\"{x:711,y:726,t:1526667998008};\\\", \\\"{x:698,y:729,t:1526667998026};\\\", \\\"{x:680,y:735,t:1526667998042};\\\", \\\"{x:661,y:742,t:1526667998059};\\\", \\\"{x:645,y:747,t:1526667998074};\\\", \\\"{x:633,y:752,t:1526667998091};\\\", \\\"{x:623,y:757,t:1526667998109};\\\", \\\"{x:618,y:759,t:1526667998125};\\\", \\\"{x:613,y:760,t:1526667998142};\\\", \\\"{x:609,y:760,t:1526667998159};\\\", \\\"{x:603,y:761,t:1526667998175};\\\", \\\"{x:596,y:761,t:1526667998192};\\\", \\\"{x:589,y:761,t:1526667998209};\\\", \\\"{x:579,y:761,t:1526667998225};\\\", \\\"{x:568,y:759,t:1526667998242};\\\", \\\"{x:562,y:758,t:1526667998260};\\\", \\\"{x:554,y:756,t:1526667998275};\\\", \\\"{x:549,y:753,t:1526667998293};\\\", \\\"{x:547,y:752,t:1526667998309};\\\", \\\"{x:545,y:751,t:1526667998326};\\\", \\\"{x:544,y:750,t:1526667998361};\\\" ] }, { \\\"rt\\\": 33425, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 264481, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01:30-01 PM-09 AM-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:747,t:1526668001609};\\\", \\\"{x:551,y:731,t:1526668001630};\\\", \\\"{x:564,y:703,t:1526668001643};\\\", \\\"{x:587,y:667,t:1526668001659};\\\", \\\"{x:613,y:634,t:1526668001674};\\\", \\\"{x:646,y:594,t:1526668001695};\\\", \\\"{x:717,y:525,t:1526668001712};\\\", \\\"{x:775,y:477,t:1526668001728};\\\", \\\"{x:840,y:427,t:1526668001744};\\\", \\\"{x:890,y:391,t:1526668001762};\\\", \\\"{x:919,y:370,t:1526668001778};\\\", \\\"{x:938,y:357,t:1526668001795};\\\", \\\"{x:945,y:351,t:1526668001812};\\\", \\\"{x:946,y:351,t:1526668001828};\\\", \\\"{x:944,y:351,t:1526668002009};\\\", \\\"{x:943,y:352,t:1526668002024};\\\", \\\"{x:942,y:352,t:1526668002041};\\\", \\\"{x:941,y:352,t:1526668002056};\\\", \\\"{x:940,y:352,t:1526668002073};\\\", \\\"{x:939,y:353,t:1526668002257};\\\", \\\"{x:938,y:354,t:1526668002265};\\\", \\\"{x:936,y:355,t:1526668002289};\\\", \\\"{x:935,y:357,t:1526668002841};\\\", \\\"{x:934,y:358,t:1526668002849};\\\", \\\"{x:933,y:359,t:1526668002865};\\\", \\\"{x:932,y:361,t:1526668002880};\\\", \\\"{x:930,y:363,t:1526668002969};\\\", \\\"{x:929,y:364,t:1526668003008};\\\", \\\"{x:929,y:365,t:1526668003025};\\\", \\\"{x:928,y:367,t:1526668003041};\\\", \\\"{x:926,y:369,t:1526668003048};\\\", \\\"{x:926,y:371,t:1526668003063};\\\", \\\"{x:920,y:379,t:1526668003080};\\\", \\\"{x:902,y:397,t:1526668003096};\\\", \\\"{x:886,y:409,t:1526668003114};\\\", \\\"{x:870,y:421,t:1526668003129};\\\", \\\"{x:848,y:432,t:1526668003147};\\\", \\\"{x:824,y:444,t:1526668003164};\\\", \\\"{x:791,y:457,t:1526668003179};\\\", \\\"{x:759,y:469,t:1526668003196};\\\", \\\"{x:723,y:478,t:1526668003213};\\\", \\\"{x:702,y:482,t:1526668003229};\\\", \\\"{x:685,y:486,t:1526668003247};\\\", \\\"{x:676,y:486,t:1526668003264};\\\", \\\"{x:674,y:486,t:1526668003280};\\\", \\\"{x:671,y:487,t:1526668003298};\\\", \\\"{x:668,y:487,t:1526668003313};\\\", \\\"{x:664,y:489,t:1526668003327};\\\", \\\"{x:646,y:491,t:1526668003344};\\\", \\\"{x:626,y:492,t:1526668003361};\\\", \\\"{x:602,y:492,t:1526668003377};\\\", \\\"{x:577,y:492,t:1526668003396};\\\", \\\"{x:547,y:488,t:1526668003413};\\\", \\\"{x:520,y:483,t:1526668003430};\\\", \\\"{x:509,y:482,t:1526668003446};\\\", \\\"{x:506,y:482,t:1526668003463};\\\", \\\"{x:505,y:481,t:1526668003641};\\\", \\\"{x:505,y:478,t:1526668003648};\\\", \\\"{x:518,y:471,t:1526668003664};\\\", \\\"{x:564,y:454,t:1526668003681};\\\", \\\"{x:586,y:450,t:1526668003696};\\\", \\\"{x:607,y:444,t:1526668003713};\\\", \\\"{x:627,y:442,t:1526668003730};\\\", \\\"{x:656,y:440,t:1526668003747};\\\", \\\"{x:715,y:440,t:1526668003764};\\\", \\\"{x:823,y:440,t:1526668003781};\\\", \\\"{x:970,y:440,t:1526668003797};\\\", \\\"{x:1144,y:440,t:1526668003815};\\\", \\\"{x:1348,y:440,t:1526668003831};\\\", \\\"{x:1558,y:440,t:1526668003848};\\\", \\\"{x:1762,y:440,t:1526668003864};\\\", \\\"{x:1919,y:440,t:1526668003881};\\\", \\\"{x:1919,y:442,t:1526668003913};\\\", \\\"{x:1919,y:446,t:1526668003960};\\\", \\\"{x:1917,y:453,t:1526668003968};\\\", \\\"{x:1912,y:463,t:1526668003981};\\\", \\\"{x:1900,y:486,t:1526668003999};\\\", \\\"{x:1886,y:509,t:1526668004014};\\\", \\\"{x:1869,y:530,t:1526668004030};\\\", \\\"{x:1845,y:565,t:1526668004047};\\\", \\\"{x:1805,y:621,t:1526668004063};\\\", \\\"{x:1719,y:727,t:1526668004079};\\\", \\\"{x:1656,y:801,t:1526668004097};\\\", \\\"{x:1609,y:854,t:1526668004113};\\\", \\\"{x:1564,y:893,t:1526668004131};\\\", \\\"{x:1531,y:922,t:1526668004147};\\\", \\\"{x:1509,y:942,t:1526668004164};\\\", \\\"{x:1485,y:959,t:1526668004180};\\\", \\\"{x:1448,y:976,t:1526668004198};\\\", \\\"{x:1404,y:992,t:1526668004214};\\\", \\\"{x:1366,y:1008,t:1526668004231};\\\", \\\"{x:1338,y:1020,t:1526668004247};\\\", \\\"{x:1279,y:1049,t:1526668004264};\\\", \\\"{x:1233,y:1064,t:1526668004281};\\\", \\\"{x:1178,y:1077,t:1526668004297};\\\", \\\"{x:1156,y:1079,t:1526668004314};\\\", \\\"{x:1149,y:1079,t:1526668004330};\\\", \\\"{x:1148,y:1079,t:1526668004401};\\\", \\\"{x:1146,y:1077,t:1526668004414};\\\", \\\"{x:1145,y:1071,t:1526668004431};\\\", \\\"{x:1142,y:1062,t:1526668004448};\\\", \\\"{x:1141,y:1037,t:1526668004465};\\\", \\\"{x:1140,y:1024,t:1526668004480};\\\", \\\"{x:1140,y:1010,t:1526668004497};\\\", \\\"{x:1140,y:997,t:1526668004514};\\\", \\\"{x:1140,y:981,t:1526668004531};\\\", \\\"{x:1143,y:968,t:1526668004548};\\\", \\\"{x:1148,y:950,t:1526668004565};\\\", \\\"{x:1153,y:933,t:1526668004581};\\\", \\\"{x:1158,y:917,t:1526668004597};\\\", \\\"{x:1163,y:900,t:1526668004615};\\\", \\\"{x:1168,y:886,t:1526668004631};\\\", \\\"{x:1172,y:873,t:1526668004648};\\\", \\\"{x:1175,y:858,t:1526668004665};\\\", \\\"{x:1179,y:847,t:1526668004682};\\\", \\\"{x:1183,y:834,t:1526668004697};\\\", \\\"{x:1187,y:821,t:1526668004715};\\\", \\\"{x:1194,y:808,t:1526668004732};\\\", \\\"{x:1199,y:796,t:1526668004747};\\\", \\\"{x:1204,y:787,t:1526668004764};\\\", \\\"{x:1209,y:772,t:1526668004782};\\\", \\\"{x:1214,y:763,t:1526668004798};\\\", \\\"{x:1220,y:753,t:1526668004816};\\\", \\\"{x:1222,y:749,t:1526668004832};\\\", \\\"{x:1223,y:749,t:1526668004848};\\\", \\\"{x:1225,y:743,t:1526668004865};\\\", \\\"{x:1227,y:741,t:1526668004882};\\\", \\\"{x:1230,y:737,t:1526668004898};\\\", \\\"{x:1232,y:734,t:1526668004915};\\\", \\\"{x:1234,y:732,t:1526668004932};\\\", \\\"{x:1236,y:729,t:1526668004948};\\\", \\\"{x:1237,y:728,t:1526668004965};\\\", \\\"{x:1239,y:726,t:1526668004984};\\\", \\\"{x:1240,y:725,t:1526668004998};\\\", \\\"{x:1246,y:722,t:1526668005014};\\\", \\\"{x:1250,y:719,t:1526668005032};\\\", \\\"{x:1255,y:716,t:1526668005048};\\\", \\\"{x:1269,y:710,t:1526668005065};\\\", \\\"{x:1277,y:707,t:1526668005082};\\\", \\\"{x:1286,y:702,t:1526668005098};\\\", \\\"{x:1295,y:699,t:1526668005115};\\\", \\\"{x:1304,y:698,t:1526668005132};\\\", \\\"{x:1315,y:694,t:1526668005149};\\\", \\\"{x:1325,y:690,t:1526668005165};\\\", \\\"{x:1337,y:686,t:1526668005182};\\\", \\\"{x:1343,y:684,t:1526668005199};\\\", \\\"{x:1350,y:680,t:1526668005216};\\\", \\\"{x:1357,y:677,t:1526668005233};\\\", \\\"{x:1361,y:673,t:1526668005249};\\\", \\\"{x:1362,y:673,t:1526668005264};\\\", \\\"{x:1363,y:672,t:1526668005281};\\\", \\\"{x:1364,y:672,t:1526668005329};\\\", \\\"{x:1364,y:671,t:1526668005369};\\\", \\\"{x:1364,y:670,t:1526668005381};\\\", \\\"{x:1365,y:670,t:1526668005399};\\\", \\\"{x:1365,y:668,t:1526668005415};\\\", \\\"{x:1366,y:667,t:1526668005432};\\\", \\\"{x:1366,y:665,t:1526668005449};\\\", \\\"{x:1366,y:664,t:1526668005489};\\\", \\\"{x:1366,y:662,t:1526668005498};\\\", \\\"{x:1366,y:659,t:1526668005515};\\\", \\\"{x:1366,y:655,t:1526668005532};\\\", \\\"{x:1366,y:651,t:1526668005549};\\\", \\\"{x:1366,y:646,t:1526668005565};\\\", \\\"{x:1366,y:634,t:1526668005582};\\\", \\\"{x:1366,y:619,t:1526668005599};\\\", \\\"{x:1366,y:604,t:1526668005616};\\\", \\\"{x:1366,y:587,t:1526668005632};\\\", \\\"{x:1366,y:567,t:1526668005649};\\\", \\\"{x:1366,y:554,t:1526668005666};\\\", \\\"{x:1366,y:543,t:1526668005682};\\\", \\\"{x:1366,y:531,t:1526668005699};\\\", \\\"{x:1366,y:519,t:1526668005716};\\\", \\\"{x:1366,y:508,t:1526668005732};\\\", \\\"{x:1368,y:498,t:1526668005749};\\\", \\\"{x:1369,y:488,t:1526668005765};\\\", \\\"{x:1370,y:478,t:1526668005781};\\\", \\\"{x:1373,y:466,t:1526668005799};\\\", \\\"{x:1375,y:456,t:1526668005816};\\\", \\\"{x:1379,y:444,t:1526668005832};\\\", \\\"{x:1383,y:431,t:1526668005849};\\\", \\\"{x:1385,y:424,t:1526668005866};\\\", \\\"{x:1387,y:417,t:1526668005882};\\\", \\\"{x:1388,y:415,t:1526668005899};\\\", \\\"{x:1389,y:413,t:1526668005916};\\\", \\\"{x:1389,y:412,t:1526668005932};\\\", \\\"{x:1390,y:411,t:1526668005949};\\\", \\\"{x:1391,y:410,t:1526668006001};\\\", \\\"{x:1392,y:410,t:1526668006033};\\\", \\\"{x:1393,y:410,t:1526668006193};\\\", \\\"{x:1394,y:412,t:1526668006249};\\\", \\\"{x:1394,y:424,t:1526668006266};\\\", \\\"{x:1394,y:442,t:1526668006283};\\\", \\\"{x:1394,y:458,t:1526668006299};\\\", \\\"{x:1390,y:475,t:1526668006316};\\\", \\\"{x:1385,y:496,t:1526668006333};\\\", \\\"{x:1379,y:513,t:1526668006349};\\\", \\\"{x:1374,y:531,t:1526668006365};\\\", \\\"{x:1367,y:547,t:1526668006383};\\\", \\\"{x:1362,y:559,t:1526668006399};\\\", \\\"{x:1357,y:569,t:1526668006416};\\\", \\\"{x:1353,y:579,t:1526668006433};\\\", \\\"{x:1351,y:587,t:1526668006449};\\\", \\\"{x:1347,y:595,t:1526668006466};\\\", \\\"{x:1343,y:604,t:1526668006482};\\\", \\\"{x:1339,y:613,t:1526668006499};\\\", \\\"{x:1333,y:624,t:1526668006515};\\\", \\\"{x:1329,y:633,t:1526668006533};\\\", \\\"{x:1326,y:639,t:1526668006549};\\\", \\\"{x:1321,y:647,t:1526668006565};\\\", \\\"{x:1318,y:653,t:1526668006583};\\\", \\\"{x:1312,y:661,t:1526668006600};\\\", \\\"{x:1310,y:665,t:1526668006616};\\\", \\\"{x:1306,y:672,t:1526668006633};\\\", \\\"{x:1303,y:678,t:1526668006650};\\\", \\\"{x:1300,y:687,t:1526668006666};\\\", \\\"{x:1295,y:696,t:1526668006683};\\\", \\\"{x:1290,y:707,t:1526668006701};\\\", \\\"{x:1284,y:717,t:1526668006716};\\\", \\\"{x:1281,y:722,t:1526668006733};\\\", \\\"{x:1278,y:729,t:1526668006750};\\\", \\\"{x:1276,y:732,t:1526668006766};\\\", \\\"{x:1272,y:742,t:1526668006783};\\\", \\\"{x:1271,y:745,t:1526668006800};\\\", \\\"{x:1269,y:751,t:1526668006816};\\\", \\\"{x:1266,y:763,t:1526668006833};\\\", \\\"{x:1265,y:769,t:1526668006850};\\\", \\\"{x:1263,y:773,t:1526668006866};\\\", \\\"{x:1261,y:780,t:1526668006883};\\\", \\\"{x:1260,y:784,t:1526668006900};\\\", \\\"{x:1259,y:785,t:1526668006916};\\\", \\\"{x:1259,y:789,t:1526668006934};\\\", \\\"{x:1259,y:790,t:1526668006950};\\\", \\\"{x:1257,y:792,t:1526668006966};\\\", \\\"{x:1257,y:794,t:1526668006983};\\\", \\\"{x:1256,y:796,t:1526668007000};\\\", \\\"{x:1255,y:802,t:1526668007017};\\\", \\\"{x:1253,y:806,t:1526668007033};\\\", \\\"{x:1252,y:810,t:1526668007050};\\\", \\\"{x:1251,y:816,t:1526668007067};\\\", \\\"{x:1249,y:821,t:1526668007083};\\\", \\\"{x:1249,y:825,t:1526668007100};\\\", \\\"{x:1248,y:833,t:1526668007116};\\\", \\\"{x:1247,y:843,t:1526668007133};\\\", \\\"{x:1245,y:852,t:1526668007150};\\\", \\\"{x:1245,y:859,t:1526668007167};\\\", \\\"{x:1244,y:866,t:1526668007183};\\\", \\\"{x:1244,y:870,t:1526668007200};\\\", \\\"{x:1244,y:873,t:1526668007217};\\\", \\\"{x:1244,y:874,t:1526668007233};\\\", \\\"{x:1244,y:875,t:1526668007250};\\\", \\\"{x:1245,y:876,t:1526668007267};\\\", \\\"{x:1245,y:877,t:1526668007283};\\\", \\\"{x:1251,y:877,t:1526668007300};\\\", \\\"{x:1261,y:880,t:1526668007317};\\\", \\\"{x:1276,y:883,t:1526668007333};\\\", \\\"{x:1297,y:888,t:1526668007350};\\\", \\\"{x:1317,y:891,t:1526668007367};\\\", \\\"{x:1341,y:893,t:1526668007383};\\\", \\\"{x:1363,y:897,t:1526668007399};\\\", \\\"{x:1389,y:898,t:1526668007417};\\\", \\\"{x:1399,y:898,t:1526668007432};\\\", \\\"{x:1406,y:898,t:1526668007450};\\\", \\\"{x:1410,y:898,t:1526668007467};\\\", \\\"{x:1413,y:897,t:1526668007483};\\\", \\\"{x:1417,y:896,t:1526668007500};\\\", \\\"{x:1423,y:892,t:1526668007516};\\\", \\\"{x:1426,y:892,t:1526668007533};\\\", \\\"{x:1430,y:889,t:1526668007549};\\\", \\\"{x:1433,y:889,t:1526668007566};\\\", \\\"{x:1438,y:886,t:1526668007584};\\\", \\\"{x:1444,y:883,t:1526668007600};\\\", \\\"{x:1449,y:880,t:1526668007616};\\\", \\\"{x:1455,y:877,t:1526668007634};\\\", \\\"{x:1457,y:875,t:1526668007650};\\\", \\\"{x:1458,y:875,t:1526668007666};\\\", \\\"{x:1460,y:873,t:1526668007684};\\\", \\\"{x:1461,y:872,t:1526668007699};\\\", \\\"{x:1465,y:869,t:1526668007717};\\\", \\\"{x:1467,y:867,t:1526668007734};\\\", \\\"{x:1469,y:863,t:1526668007749};\\\", \\\"{x:1474,y:857,t:1526668007767};\\\", \\\"{x:1479,y:852,t:1526668007784};\\\", \\\"{x:1487,y:842,t:1526668007800};\\\", \\\"{x:1492,y:835,t:1526668007816};\\\", \\\"{x:1499,y:824,t:1526668007834};\\\", \\\"{x:1503,y:818,t:1526668007849};\\\", \\\"{x:1507,y:811,t:1526668007866};\\\", \\\"{x:1509,y:808,t:1526668007883};\\\", \\\"{x:1510,y:804,t:1526668007899};\\\", \\\"{x:1512,y:799,t:1526668007916};\\\", \\\"{x:1513,y:797,t:1526668007934};\\\", \\\"{x:1515,y:793,t:1526668007949};\\\", \\\"{x:1516,y:790,t:1526668007966};\\\", \\\"{x:1517,y:789,t:1526668007984};\\\", \\\"{x:1517,y:787,t:1526668007999};\\\", \\\"{x:1518,y:784,t:1526668008016};\\\", \\\"{x:1519,y:782,t:1526668008034};\\\", \\\"{x:1519,y:781,t:1526668008057};\\\", \\\"{x:1519,y:780,t:1526668008067};\\\", \\\"{x:1519,y:779,t:1526668008084};\\\", \\\"{x:1519,y:778,t:1526668008108};\\\", \\\"{x:1519,y:777,t:1526668008132};\\\", \\\"{x:1520,y:777,t:1526668008181};\\\", \\\"{x:1520,y:776,t:1526668008205};\\\", \\\"{x:1521,y:775,t:1526668008236};\\\", \\\"{x:1521,y:774,t:1526668008293};\\\", \\\"{x:1522,y:774,t:1526668008500};\\\", \\\"{x:1524,y:772,t:1526668008508};\\\", \\\"{x:1525,y:771,t:1526668008522};\\\", \\\"{x:1528,y:768,t:1526668008537};\\\", \\\"{x:1531,y:765,t:1526668008555};\\\", \\\"{x:1533,y:764,t:1526668008571};\\\", \\\"{x:1535,y:763,t:1526668008588};\\\", \\\"{x:1539,y:760,t:1526668008604};\\\", \\\"{x:1544,y:758,t:1526668008621};\\\", \\\"{x:1546,y:758,t:1526668008637};\\\", \\\"{x:1548,y:757,t:1526668008654};\\\", \\\"{x:1549,y:756,t:1526668008672};\\\", \\\"{x:1550,y:755,t:1526668008687};\\\", \\\"{x:1550,y:756,t:1526668009427};\\\", \\\"{x:1544,y:757,t:1526668009438};\\\", \\\"{x:1535,y:763,t:1526668009455};\\\", \\\"{x:1527,y:766,t:1526668009471};\\\", \\\"{x:1512,y:773,t:1526668009488};\\\", \\\"{x:1499,y:779,t:1526668009505};\\\", \\\"{x:1489,y:783,t:1526668009522};\\\", \\\"{x:1482,y:788,t:1526668009538};\\\", \\\"{x:1477,y:791,t:1526668009556};\\\", \\\"{x:1471,y:794,t:1526668009571};\\\", \\\"{x:1460,y:799,t:1526668009588};\\\", \\\"{x:1450,y:803,t:1526668009605};\\\", \\\"{x:1435,y:807,t:1526668009621};\\\", \\\"{x:1423,y:810,t:1526668009638};\\\", \\\"{x:1417,y:811,t:1526668009655};\\\", \\\"{x:1410,y:812,t:1526668009671};\\\", \\\"{x:1403,y:812,t:1526668009688};\\\", \\\"{x:1398,y:812,t:1526668009705};\\\", \\\"{x:1394,y:812,t:1526668009721};\\\", \\\"{x:1386,y:812,t:1526668009738};\\\", \\\"{x:1374,y:809,t:1526668009755};\\\", \\\"{x:1363,y:806,t:1526668009771};\\\", \\\"{x:1362,y:805,t:1526668009788};\\\", \\\"{x:1360,y:805,t:1526668009805};\\\", \\\"{x:1359,y:804,t:1526668009821};\\\", \\\"{x:1357,y:803,t:1526668009838};\\\", \\\"{x:1357,y:802,t:1526668009916};\\\", \\\"{x:1356,y:800,t:1526668009924};\\\", \\\"{x:1356,y:798,t:1526668009940};\\\", \\\"{x:1354,y:797,t:1526668009955};\\\", \\\"{x:1353,y:793,t:1526668009972};\\\", \\\"{x:1349,y:784,t:1526668009989};\\\", \\\"{x:1346,y:780,t:1526668010005};\\\", \\\"{x:1345,y:777,t:1526668010022};\\\", \\\"{x:1344,y:776,t:1526668010038};\\\", \\\"{x:1343,y:773,t:1526668010055};\\\", \\\"{x:1342,y:770,t:1526668010072};\\\", \\\"{x:1342,y:769,t:1526668010348};\\\", \\\"{x:1344,y:766,t:1526668010359};\\\", \\\"{x:1357,y:759,t:1526668010371};\\\", \\\"{x:1364,y:756,t:1526668010389};\\\", \\\"{x:1365,y:755,t:1526668010405};\\\", \\\"{x:1363,y:755,t:1526668010604};\\\", \\\"{x:1360,y:756,t:1526668010611};\\\", \\\"{x:1359,y:757,t:1526668010622};\\\", \\\"{x:1355,y:758,t:1526668010639};\\\", \\\"{x:1353,y:760,t:1526668010655};\\\", \\\"{x:1352,y:760,t:1526668011045};\\\", \\\"{x:1349,y:760,t:1526668026861};\\\", \\\"{x:1307,y:753,t:1526668026869};\\\", \\\"{x:1141,y:753,t:1526668026885};\\\", \\\"{x:951,y:768,t:1526668026901};\\\", \\\"{x:745,y:793,t:1526668026918};\\\", \\\"{x:523,y:828,t:1526668026934};\\\", \\\"{x:313,y:861,t:1526668026951};\\\", \\\"{x:136,y:885,t:1526668026969};\\\", \\\"{x:3,y:904,t:1526668026984};\\\", \\\"{x:0,y:904,t:1526668027001};\\\", \\\"{x:1,y:898,t:1526668027036};\\\", \\\"{x:5,y:886,t:1526668027052};\\\", \\\"{x:34,y:836,t:1526668027068};\\\", \\\"{x:72,y:789,t:1526668027084};\\\", \\\"{x:120,y:743,t:1526668027101};\\\", \\\"{x:177,y:692,t:1526668027118};\\\", \\\"{x:227,y:650,t:1526668027136};\\\", \\\"{x:264,y:615,t:1526668027152};\\\", \\\"{x:285,y:590,t:1526668027168};\\\", \\\"{x:305,y:568,t:1526668027185};\\\", \\\"{x:326,y:550,t:1526668027203};\\\", \\\"{x:353,y:528,t:1526668027219};\\\", \\\"{x:356,y:526,t:1526668027236};\\\", \\\"{x:359,y:523,t:1526668027253};\\\", \\\"{x:362,y:522,t:1526668027269};\\\", \\\"{x:366,y:520,t:1526668027285};\\\", \\\"{x:372,y:516,t:1526668027303};\\\", \\\"{x:375,y:516,t:1526668027319};\\\", \\\"{x:377,y:515,t:1526668027336};\\\", \\\"{x:378,y:515,t:1526668027353};\\\", \\\"{x:379,y:514,t:1526668027369};\\\", \\\"{x:380,y:513,t:1526668027386};\\\", \\\"{x:381,y:513,t:1526668028068};\\\", \\\"{x:380,y:515,t:1526668028085};\\\", \\\"{x:378,y:518,t:1526668028103};\\\", \\\"{x:377,y:523,t:1526668028119};\\\", \\\"{x:377,y:528,t:1526668028137};\\\", \\\"{x:377,y:535,t:1526668028152};\\\", \\\"{x:377,y:541,t:1526668028170};\\\", \\\"{x:383,y:550,t:1526668028187};\\\", \\\"{x:387,y:553,t:1526668028203};\\\", \\\"{x:393,y:555,t:1526668028219};\\\", \\\"{x:398,y:556,t:1526668028237};\\\", \\\"{x:405,y:557,t:1526668028253};\\\", \\\"{x:409,y:558,t:1526668028270};\\\", \\\"{x:416,y:558,t:1526668028287};\\\", \\\"{x:423,y:558,t:1526668028304};\\\", \\\"{x:430,y:558,t:1526668028319};\\\", \\\"{x:440,y:558,t:1526668028337};\\\", \\\"{x:450,y:558,t:1526668028354};\\\", \\\"{x:461,y:558,t:1526668028370};\\\", \\\"{x:485,y:558,t:1526668028387};\\\", \\\"{x:495,y:557,t:1526668028404};\\\", \\\"{x:510,y:554,t:1526668028421};\\\", \\\"{x:520,y:553,t:1526668028437};\\\", \\\"{x:530,y:552,t:1526668028454};\\\", \\\"{x:536,y:551,t:1526668028469};\\\", \\\"{x:541,y:550,t:1526668028487};\\\", \\\"{x:546,y:549,t:1526668028503};\\\", \\\"{x:552,y:549,t:1526668028520};\\\", \\\"{x:564,y:547,t:1526668028537};\\\", \\\"{x:575,y:547,t:1526668028554};\\\", \\\"{x:584,y:547,t:1526668028571};\\\", \\\"{x:600,y:547,t:1526668028587};\\\", \\\"{x:615,y:547,t:1526668028604};\\\", \\\"{x:630,y:547,t:1526668028621};\\\", \\\"{x:642,y:547,t:1526668028637};\\\", \\\"{x:645,y:545,t:1526668028655};\\\", \\\"{x:648,y:545,t:1526668028670};\\\", \\\"{x:649,y:545,t:1526668028687};\\\", \\\"{x:648,y:548,t:1526668028756};\\\", \\\"{x:645,y:549,t:1526668028772};\\\", \\\"{x:621,y:559,t:1526668028789};\\\", \\\"{x:606,y:566,t:1526668028804};\\\", \\\"{x:595,y:572,t:1526668028821};\\\", \\\"{x:589,y:575,t:1526668028837};\\\", \\\"{x:588,y:575,t:1526668028854};\\\", \\\"{x:586,y:575,t:1526668028875};\\\", \\\"{x:585,y:575,t:1526668028891};\\\", \\\"{x:583,y:575,t:1526668028904};\\\", \\\"{x:575,y:575,t:1526668028920};\\\", \\\"{x:563,y:574,t:1526668028936};\\\", \\\"{x:550,y:571,t:1526668028953};\\\", \\\"{x:539,y:565,t:1526668028971};\\\", \\\"{x:535,y:563,t:1526668028987};\\\", \\\"{x:532,y:562,t:1526668029005};\\\", \\\"{x:523,y:561,t:1526668029021};\\\", \\\"{x:516,y:560,t:1526668029037};\\\", \\\"{x:513,y:560,t:1526668029053};\\\", \\\"{x:509,y:560,t:1526668029071};\\\", \\\"{x:506,y:560,t:1526668029087};\\\", \\\"{x:497,y:562,t:1526668029104};\\\", \\\"{x:488,y:564,t:1526668029122};\\\", \\\"{x:477,y:567,t:1526668029138};\\\", \\\"{x:464,y:571,t:1526668029154};\\\", \\\"{x:440,y:577,t:1526668029171};\\\", \\\"{x:419,y:582,t:1526668029187};\\\", \\\"{x:397,y:585,t:1526668029204};\\\", \\\"{x:368,y:589,t:1526668029221};\\\", \\\"{x:337,y:593,t:1526668029238};\\\", \\\"{x:301,y:599,t:1526668029255};\\\", \\\"{x:276,y:603,t:1526668029272};\\\", \\\"{x:248,y:606,t:1526668029289};\\\", \\\"{x:226,y:607,t:1526668029304};\\\", \\\"{x:209,y:607,t:1526668029321};\\\", \\\"{x:197,y:607,t:1526668029338};\\\", \\\"{x:193,y:607,t:1526668029354};\\\", \\\"{x:191,y:607,t:1526668029404};\\\", \\\"{x:191,y:606,t:1526668029421};\\\", \\\"{x:191,y:603,t:1526668029438};\\\", \\\"{x:190,y:600,t:1526668029455};\\\", \\\"{x:190,y:596,t:1526668029471};\\\", \\\"{x:189,y:590,t:1526668029488};\\\", \\\"{x:189,y:585,t:1526668029505};\\\", \\\"{x:188,y:578,t:1526668029520};\\\", \\\"{x:186,y:571,t:1526668029538};\\\", \\\"{x:186,y:557,t:1526668029555};\\\", \\\"{x:186,y:554,t:1526668029572};\\\", \\\"{x:186,y:546,t:1526668029588};\\\", \\\"{x:185,y:540,t:1526668029605};\\\", \\\"{x:184,y:537,t:1526668029621};\\\", \\\"{x:184,y:535,t:1526668029638};\\\", \\\"{x:184,y:533,t:1526668029654};\\\", \\\"{x:183,y:531,t:1526668029671};\\\", \\\"{x:183,y:529,t:1526668029688};\\\", \\\"{x:182,y:526,t:1526668029705};\\\", \\\"{x:182,y:522,t:1526668029722};\\\", \\\"{x:181,y:520,t:1526668029738};\\\", \\\"{x:181,y:517,t:1526668029755};\\\", \\\"{x:181,y:514,t:1526668029771};\\\", \\\"{x:182,y:512,t:1526668029789};\\\", \\\"{x:183,y:510,t:1526668029804};\\\", \\\"{x:183,y:509,t:1526668029821};\\\", \\\"{x:184,y:508,t:1526668029980};\\\", \\\"{x:185,y:508,t:1526668029988};\\\", \\\"{x:186,y:508,t:1526668029995};\\\", \\\"{x:188,y:508,t:1526668030005};\\\", \\\"{x:192,y:506,t:1526668030021};\\\", \\\"{x:198,y:504,t:1526668030037};\\\", \\\"{x:210,y:502,t:1526668030054};\\\", \\\"{x:238,y:502,t:1526668030071};\\\", \\\"{x:288,y:509,t:1526668030088};\\\", \\\"{x:350,y:519,t:1526668030105};\\\", \\\"{x:416,y:535,t:1526668030122};\\\", \\\"{x:481,y:556,t:1526668030138};\\\", \\\"{x:554,y:590,t:1526668030155};\\\", \\\"{x:582,y:609,t:1526668030173};\\\", \\\"{x:601,y:626,t:1526668030188};\\\", \\\"{x:621,y:643,t:1526668030205};\\\", \\\"{x:633,y:664,t:1526668030221};\\\", \\\"{x:638,y:677,t:1526668030238};\\\", \\\"{x:640,y:687,t:1526668030254};\\\", \\\"{x:644,y:695,t:1526668030272};\\\", \\\"{x:644,y:697,t:1526668030288};\\\", \\\"{x:643,y:699,t:1526668030340};\\\", \\\"{x:637,y:702,t:1526668030356};\\\", \\\"{x:627,y:706,t:1526668030372};\\\", \\\"{x:616,y:709,t:1526668030390};\\\", \\\"{x:607,y:711,t:1526668030406};\\\", \\\"{x:601,y:714,t:1526668030422};\\\", \\\"{x:594,y:715,t:1526668030439};\\\", \\\"{x:588,y:719,t:1526668030456};\\\", \\\"{x:587,y:719,t:1526668030472};\\\", \\\"{x:584,y:720,t:1526668030489};\\\", \\\"{x:581,y:722,t:1526668030506};\\\", \\\"{x:575,y:727,t:1526668030523};\\\", \\\"{x:568,y:732,t:1526668030540};\\\", \\\"{x:567,y:735,t:1526668030556};\\\", \\\"{x:566,y:735,t:1526668030572};\\\", \\\"{x:565,y:736,t:1526668030620};\\\", \\\"{x:559,y:737,t:1526668030637};\\\", \\\"{x:546,y:740,t:1526668030655};\\\", \\\"{x:531,y:741,t:1526668030672};\\\", \\\"{x:509,y:741,t:1526668030688};\\\", \\\"{x:479,y:733,t:1526668030706};\\\", \\\"{x:418,y:716,t:1526668030723};\\\", \\\"{x:283,y:667,t:1526668030739};\\\", \\\"{x:198,y:634,t:1526668030756};\\\", \\\"{x:140,y:609,t:1526668030772};\\\", \\\"{x:96,y:582,t:1526668030789};\\\", \\\"{x:69,y:562,t:1526668030806};\\\", \\\"{x:62,y:547,t:1526668030822};\\\", \\\"{x:62,y:533,t:1526668030838};\\\", \\\"{x:65,y:525,t:1526668030855};\\\", \\\"{x:72,y:520,t:1526668030872};\\\", \\\"{x:76,y:517,t:1526668030889};\\\", \\\"{x:78,y:517,t:1526668030906};\\\", \\\"{x:79,y:517,t:1526668030922};\\\", \\\"{x:83,y:515,t:1526668030939};\\\", \\\"{x:85,y:515,t:1526668030955};\\\", \\\"{x:89,y:515,t:1526668030972};\\\", \\\"{x:93,y:515,t:1526668030989};\\\", \\\"{x:97,y:517,t:1526668031006};\\\", \\\"{x:100,y:517,t:1526668031022};\\\", \\\"{x:101,y:518,t:1526668031040};\\\", \\\"{x:103,y:518,t:1526668031059};\\\", \\\"{x:106,y:518,t:1526668031076};\\\", \\\"{x:109,y:518,t:1526668031089};\\\", \\\"{x:117,y:516,t:1526668031108};\\\", \\\"{x:127,y:511,t:1526668031123};\\\", \\\"{x:132,y:508,t:1526668031139};\\\", \\\"{x:134,y:508,t:1526668031156};\\\", \\\"{x:135,y:508,t:1526668031172};\\\", \\\"{x:136,y:507,t:1526668031189};\\\", \\\"{x:136,y:506,t:1526668031206};\\\", \\\"{x:137,y:506,t:1526668031222};\\\", \\\"{x:138,y:505,t:1526668031240};\\\", \\\"{x:139,y:505,t:1526668031491};\\\", \\\"{x:140,y:505,t:1526668031505};\\\", \\\"{x:148,y:505,t:1526668031523};\\\", \\\"{x:161,y:505,t:1526668031539};\\\", \\\"{x:185,y:507,t:1526668031556};\\\", \\\"{x:203,y:512,t:1526668031573};\\\", \\\"{x:215,y:515,t:1526668031589};\\\", \\\"{x:218,y:517,t:1526668031605};\\\", \\\"{x:219,y:517,t:1526668031635};\\\", \\\"{x:220,y:517,t:1526668031643};\\\", \\\"{x:221,y:518,t:1526668031709};\\\", \\\"{x:219,y:518,t:1526668031748};\\\", \\\"{x:214,y:518,t:1526668031756};\\\", \\\"{x:202,y:518,t:1526668031774};\\\", \\\"{x:198,y:518,t:1526668031790};\\\", \\\"{x:196,y:518,t:1526668031806};\\\", \\\"{x:194,y:518,t:1526668031823};\\\", \\\"{x:194,y:517,t:1526668031842};\\\", \\\"{x:194,y:514,t:1526668031855};\\\", \\\"{x:192,y:511,t:1526668031873};\\\", \\\"{x:190,y:508,t:1526668031890};\\\", \\\"{x:185,y:506,t:1526668031906};\\\", \\\"{x:181,y:503,t:1526668031923};\\\", \\\"{x:180,y:502,t:1526668031940};\\\", \\\"{x:178,y:502,t:1526668032004};\\\", \\\"{x:177,y:502,t:1526668032019};\\\", \\\"{x:175,y:502,t:1526668032027};\\\", \\\"{x:173,y:502,t:1526668032044};\\\", \\\"{x:171,y:502,t:1526668032056};\\\", \\\"{x:169,y:502,t:1526668032073};\\\", \\\"{x:172,y:503,t:1526668032395};\\\", \\\"{x:179,y:509,t:1526668032407};\\\", \\\"{x:201,y:518,t:1526668032424};\\\", \\\"{x:231,y:534,t:1526668032440};\\\", \\\"{x:256,y:548,t:1526668032457};\\\", \\\"{x:273,y:559,t:1526668032474};\\\", \\\"{x:288,y:570,t:1526668032490};\\\", \\\"{x:313,y:591,t:1526668032507};\\\", \\\"{x:325,y:606,t:1526668032524};\\\", \\\"{x:335,y:617,t:1526668032540};\\\", \\\"{x:346,y:637,t:1526668032557};\\\", \\\"{x:352,y:644,t:1526668032574};\\\", \\\"{x:356,y:651,t:1526668032590};\\\", \\\"{x:357,y:656,t:1526668032607};\\\", \\\"{x:361,y:659,t:1526668032623};\\\", \\\"{x:369,y:661,t:1526668032642};\\\", \\\"{x:369,y:662,t:1526668032657};\\\", \\\"{x:370,y:662,t:1526668032673};\\\", \\\"{x:371,y:662,t:1526668032690};\\\", \\\"{x:374,y:662,t:1526668032707};\\\", \\\"{x:377,y:660,t:1526668032724};\\\", \\\"{x:379,y:657,t:1526668032740};\\\", \\\"{x:381,y:654,t:1526668032757};\\\", \\\"{x:382,y:653,t:1526668032774};\\\", \\\"{x:384,y:653,t:1526668032790};\\\", \\\"{x:385,y:653,t:1526668032807};\\\", \\\"{x:388,y:653,t:1526668032825};\\\", \\\"{x:391,y:653,t:1526668032840};\\\", \\\"{x:396,y:658,t:1526668032858};\\\", \\\"{x:405,y:667,t:1526668032875};\\\", \\\"{x:423,y:681,t:1526668032890};\\\", \\\"{x:453,y:709,t:1526668032907};\\\", \\\"{x:466,y:723,t:1526668032924};\\\", \\\"{x:472,y:727,t:1526668032941};\\\", \\\"{x:475,y:729,t:1526668032957};\\\", \\\"{x:480,y:732,t:1526668032974};\\\", \\\"{x:480,y:733,t:1526668033484};\\\", \\\"{x:480,y:735,t:1526668033492};\\\", \\\"{x:480,y:736,t:1526668033548};\\\", \\\"{x:480,y:737,t:1526668033564};\\\", \\\"{x:480,y:736,t:1526668033915};\\\", \\\"{x:481,y:736,t:1526668033925};\\\", \\\"{x:484,y:735,t:1526668033941};\\\", \\\"{x:490,y:732,t:1526668033958};\\\" ] }, { \\\"rt\\\": 22425, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 288161, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:732,t:1526668043444};\\\", \\\"{x:487,y:732,t:1526668043458};\\\", \\\"{x:486,y:733,t:1526668043466};\\\", \\\"{x:483,y:734,t:1526668043483};\\\", \\\"{x:480,y:735,t:1526668043501};\\\", \\\"{x:479,y:736,t:1526668043516};\\\", \\\"{x:475,y:738,t:1526668043533};\\\", \\\"{x:474,y:738,t:1526668043563};\\\", \\\"{x:473,y:739,t:1526668043611};\\\", \\\"{x:471,y:739,t:1526668043652};\\\", \\\"{x:469,y:739,t:1526668043679};\\\", \\\"{x:468,y:739,t:1526668043684};\\\", \\\"{x:465,y:739,t:1526668043717};\\\", \\\"{x:463,y:739,t:1526668043739};\\\", \\\"{x:462,y:739,t:1526668043750};\\\", \\\"{x:459,y:739,t:1526668043767};\\\", \\\"{x:454,y:739,t:1526668043783};\\\", \\\"{x:451,y:739,t:1526668043800};\\\", \\\"{x:445,y:737,t:1526668043817};\\\", \\\"{x:439,y:736,t:1526668043834};\\\", \\\"{x:434,y:734,t:1526668043850};\\\", \\\"{x:430,y:734,t:1526668043865};\\\", \\\"{x:429,y:734,t:1526668043882};\\\", \\\"{x:428,y:734,t:1526668044156};\\\", \\\"{x:427,y:734,t:1526668044166};\\\", \\\"{x:426,y:734,t:1526668044212};\\\", \\\"{x:425,y:734,t:1526668044220};\\\", \\\"{x:424,y:734,t:1526668044233};\\\", \\\"{x:422,y:735,t:1526668044249};\\\", \\\"{x:420,y:735,t:1526668044265};\\\", \\\"{x:415,y:738,t:1526668044283};\\\", \\\"{x:412,y:741,t:1526668044299};\\\", \\\"{x:408,y:741,t:1526668044317};\\\", \\\"{x:406,y:743,t:1526668044332};\\\", \\\"{x:403,y:744,t:1526668044349};\\\", \\\"{x:401,y:745,t:1526668044366};\\\", \\\"{x:398,y:745,t:1526668044383};\\\", \\\"{x:397,y:746,t:1526668044399};\\\", \\\"{x:394,y:746,t:1526668044416};\\\", \\\"{x:391,y:747,t:1526668044433};\\\", \\\"{x:388,y:748,t:1526668044449};\\\", \\\"{x:384,y:749,t:1526668044466};\\\", \\\"{x:383,y:749,t:1526668044483};\\\", \\\"{x:381,y:750,t:1526668044499};\\\", \\\"{x:380,y:750,t:1526668044517};\\\", \\\"{x:378,y:750,t:1526668049028};\\\", \\\"{x:374,y:750,t:1526668049036};\\\", \\\"{x:370,y:750,t:1526668049053};\\\", \\\"{x:362,y:750,t:1526668049071};\\\", \\\"{x:354,y:750,t:1526668049086};\\\", \\\"{x:344,y:750,t:1526668049102};\\\", \\\"{x:336,y:750,t:1526668049120};\\\", \\\"{x:332,y:751,t:1526668049136};\\\", \\\"{x:330,y:752,t:1526668049153};\\\", \\\"{x:328,y:753,t:1526668050796};\\\", \\\"{x:318,y:757,t:1526668050804};\\\", \\\"{x:270,y:772,t:1526668050821};\\\", \\\"{x:184,y:796,t:1526668050838};\\\", \\\"{x:99,y:817,t:1526668050854};\\\", \\\"{x:37,y:836,t:1526668050871};\\\", \\\"{x:0,y:854,t:1526668050889};\\\", \\\"{x:0,y:862,t:1526668050905};\\\", \\\"{x:0,y:869,t:1526668050921};\\\", \\\"{x:0,y:874,t:1526668050938};\\\", \\\"{x:0,y:879,t:1526668050954};\\\", \\\"{x:0,y:881,t:1526668050971};\\\", \\\"{x:0,y:882,t:1526668050988};\\\", \\\"{x:0,y:881,t:1526668051092};\\\", \\\"{x:8,y:869,t:1526668051105};\\\", \\\"{x:49,y:824,t:1526668051121};\\\", \\\"{x:113,y:770,t:1526668051138};\\\", \\\"{x:223,y:683,t:1526668051156};\\\", \\\"{x:285,y:640,t:1526668051173};\\\", \\\"{x:338,y:602,t:1526668051188};\\\", \\\"{x:371,y:583,t:1526668051206};\\\", \\\"{x:386,y:572,t:1526668051222};\\\", \\\"{x:392,y:569,t:1526668051239};\\\", \\\"{x:393,y:568,t:1526668051255};\\\", \\\"{x:393,y:567,t:1526668051272};\\\", \\\"{x:387,y:565,t:1526668051289};\\\", \\\"{x:370,y:565,t:1526668051305};\\\", \\\"{x:350,y:565,t:1526668051321};\\\", \\\"{x:322,y:571,t:1526668051339};\\\", \\\"{x:318,y:572,t:1526668051355};\\\", \\\"{x:318,y:569,t:1526668051451};\\\", \\\"{x:318,y:565,t:1526668051459};\\\", \\\"{x:323,y:560,t:1526668051474};\\\", \\\"{x:332,y:551,t:1526668051491};\\\", \\\"{x:346,y:541,t:1526668051506};\\\", \\\"{x:360,y:530,t:1526668051522};\\\", \\\"{x:378,y:519,t:1526668051539};\\\", \\\"{x:386,y:514,t:1526668051557};\\\", \\\"{x:394,y:511,t:1526668051573};\\\", \\\"{x:398,y:509,t:1526668051589};\\\", \\\"{x:400,y:509,t:1526668051606};\\\", \\\"{x:400,y:511,t:1526668051700};\\\", \\\"{x:398,y:515,t:1526668051708};\\\", \\\"{x:395,y:520,t:1526668051723};\\\", \\\"{x:388,y:527,t:1526668051740};\\\", \\\"{x:371,y:536,t:1526668051756};\\\", \\\"{x:348,y:546,t:1526668051772};\\\", \\\"{x:318,y:556,t:1526668051789};\\\", \\\"{x:298,y:561,t:1526668051805};\\\", \\\"{x:288,y:563,t:1526668051823};\\\", \\\"{x:285,y:563,t:1526668051839};\\\", \\\"{x:282,y:565,t:1526668051856};\\\", \\\"{x:280,y:566,t:1526668051873};\\\", \\\"{x:274,y:567,t:1526668051888};\\\", \\\"{x:266,y:570,t:1526668051907};\\\", \\\"{x:258,y:574,t:1526668051922};\\\", \\\"{x:254,y:575,t:1526668051939};\\\", \\\"{x:252,y:576,t:1526668051956};\\\", \\\"{x:251,y:577,t:1526668051973};\\\", \\\"{x:247,y:578,t:1526668051989};\\\", \\\"{x:245,y:580,t:1526668052006};\\\", \\\"{x:240,y:581,t:1526668052023};\\\", \\\"{x:237,y:582,t:1526668052040};\\\", \\\"{x:236,y:583,t:1526668052056};\\\", \\\"{x:237,y:585,t:1526668052124};\\\", \\\"{x:244,y:586,t:1526668052140};\\\", \\\"{x:253,y:588,t:1526668052156};\\\", \\\"{x:269,y:592,t:1526668052173};\\\", \\\"{x:284,y:596,t:1526668052191};\\\", \\\"{x:300,y:601,t:1526668052207};\\\", \\\"{x:319,y:605,t:1526668052223};\\\", \\\"{x:338,y:611,t:1526668052238};\\\", \\\"{x:358,y:617,t:1526668052256};\\\", \\\"{x:372,y:621,t:1526668052273};\\\", \\\"{x:385,y:626,t:1526668052289};\\\", \\\"{x:396,y:629,t:1526668052306};\\\", \\\"{x:409,y:637,t:1526668052323};\\\", \\\"{x:420,y:642,t:1526668052339};\\\", \\\"{x:428,y:646,t:1526668052355};\\\", \\\"{x:432,y:649,t:1526668052373};\\\", \\\"{x:434,y:650,t:1526668052390};\\\", \\\"{x:436,y:652,t:1526668052406};\\\", \\\"{x:443,y:657,t:1526668052423};\\\", \\\"{x:455,y:662,t:1526668052440};\\\", \\\"{x:462,y:666,t:1526668052456};\\\", \\\"{x:470,y:666,t:1526668052473};\\\", \\\"{x:480,y:666,t:1526668052490};\\\", \\\"{x:493,y:666,t:1526668052507};\\\", \\\"{x:516,y:664,t:1526668052524};\\\", \\\"{x:531,y:661,t:1526668052540};\\\", \\\"{x:547,y:656,t:1526668052557};\\\", \\\"{x:565,y:647,t:1526668052573};\\\", \\\"{x:575,y:642,t:1526668052591};\\\", \\\"{x:585,y:639,t:1526668052607};\\\", \\\"{x:595,y:633,t:1526668052623};\\\", \\\"{x:606,y:627,t:1526668052641};\\\", \\\"{x:618,y:621,t:1526668052656};\\\", \\\"{x:634,y:613,t:1526668052672};\\\", \\\"{x:654,y:607,t:1526668052690};\\\", \\\"{x:686,y:597,t:1526668052707};\\\", \\\"{x:714,y:590,t:1526668052724};\\\", \\\"{x:740,y:583,t:1526668052741};\\\", \\\"{x:762,y:580,t:1526668052756};\\\", \\\"{x:778,y:578,t:1526668052772};\\\", \\\"{x:787,y:576,t:1526668052790};\\\", \\\"{x:789,y:575,t:1526668052807};\\\", \\\"{x:791,y:574,t:1526668052823};\\\", \\\"{x:792,y:574,t:1526668052840};\\\", \\\"{x:796,y:574,t:1526668052856};\\\", \\\"{x:800,y:573,t:1526668052874};\\\", \\\"{x:807,y:571,t:1526668052891};\\\", \\\"{x:810,y:570,t:1526668052907};\\\", \\\"{x:813,y:569,t:1526668052924};\\\", \\\"{x:818,y:568,t:1526668052941};\\\", \\\"{x:823,y:566,t:1526668052958};\\\", \\\"{x:826,y:565,t:1526668052974};\\\", \\\"{x:831,y:564,t:1526668052991};\\\", \\\"{x:835,y:563,t:1526668053008};\\\", \\\"{x:840,y:562,t:1526668053025};\\\", \\\"{x:847,y:559,t:1526668053041};\\\", \\\"{x:855,y:556,t:1526668053057};\\\", \\\"{x:866,y:551,t:1526668053075};\\\", \\\"{x:871,y:549,t:1526668053090};\\\", \\\"{x:878,y:545,t:1526668053107};\\\", \\\"{x:880,y:543,t:1526668053123};\\\", \\\"{x:881,y:543,t:1526668053140};\\\", \\\"{x:881,y:542,t:1526668053157};\\\", \\\"{x:878,y:542,t:1526668053331};\\\", \\\"{x:877,y:543,t:1526668053347};\\\", \\\"{x:875,y:543,t:1526668053357};\\\", \\\"{x:872,y:544,t:1526668053374};\\\", \\\"{x:871,y:546,t:1526668053391};\\\", \\\"{x:870,y:546,t:1526668053428};\\\", \\\"{x:868,y:546,t:1526668053661};\\\", \\\"{x:864,y:548,t:1526668053674};\\\", \\\"{x:839,y:562,t:1526668053691};\\\", \\\"{x:821,y:570,t:1526668053708};\\\", \\\"{x:801,y:583,t:1526668053723};\\\", \\\"{x:775,y:598,t:1526668053741};\\\", \\\"{x:742,y:617,t:1526668053757};\\\", \\\"{x:707,y:636,t:1526668053774};\\\", \\\"{x:672,y:656,t:1526668053791};\\\", \\\"{x:637,y:675,t:1526668053807};\\\", \\\"{x:620,y:685,t:1526668053824};\\\", \\\"{x:616,y:686,t:1526668053841};\\\", \\\"{x:619,y:683,t:1526668053883};\\\", \\\"{x:631,y:676,t:1526668053891};\\\", \\\"{x:674,y:644,t:1526668053908};\\\", \\\"{x:747,y:590,t:1526668053925};\\\", \\\"{x:826,y:529,t:1526668053942};\\\", \\\"{x:886,y:482,t:1526668053957};\\\", \\\"{x:932,y:442,t:1526668053974};\\\", \\\"{x:949,y:425,t:1526668053991};\\\", \\\"{x:953,y:420,t:1526668054008};\\\", \\\"{x:953,y:419,t:1526668054024};\\\", \\\"{x:950,y:419,t:1526668054041};\\\", \\\"{x:944,y:423,t:1526668054058};\\\", \\\"{x:941,y:424,t:1526668054074};\\\", \\\"{x:935,y:427,t:1526668054091};\\\", \\\"{x:933,y:430,t:1526668054108};\\\", \\\"{x:933,y:434,t:1526668054124};\\\", \\\"{x:930,y:438,t:1526668054142};\\\", \\\"{x:928,y:442,t:1526668054158};\\\", \\\"{x:923,y:449,t:1526668054174};\\\", \\\"{x:912,y:458,t:1526668054191};\\\", \\\"{x:906,y:467,t:1526668054208};\\\", \\\"{x:898,y:475,t:1526668054225};\\\", \\\"{x:895,y:482,t:1526668054241};\\\", \\\"{x:890,y:487,t:1526668054260};\\\", \\\"{x:885,y:494,t:1526668054274};\\\", \\\"{x:874,y:509,t:1526668054290};\\\", \\\"{x:870,y:513,t:1526668054308};\\\", \\\"{x:868,y:518,t:1526668054325};\\\", \\\"{x:866,y:520,t:1526668054341};\\\", \\\"{x:865,y:522,t:1526668054358};\\\", \\\"{x:864,y:523,t:1526668054375};\\\", \\\"{x:862,y:526,t:1526668054392};\\\", \\\"{x:861,y:527,t:1526668054407};\\\", \\\"{x:858,y:530,t:1526668054425};\\\", \\\"{x:853,y:534,t:1526668054440};\\\", \\\"{x:851,y:535,t:1526668054457};\\\", \\\"{x:849,y:537,t:1526668054475};\\\", \\\"{x:849,y:538,t:1526668054547};\\\", \\\"{x:848,y:538,t:1526668054558};\\\", \\\"{x:846,y:540,t:1526668054575};\\\", \\\"{x:844,y:540,t:1526668054591};\\\", \\\"{x:843,y:541,t:1526668054608};\\\", \\\"{x:841,y:543,t:1526668054625};\\\", \\\"{x:839,y:546,t:1526668054641};\\\", \\\"{x:838,y:547,t:1526668054658};\\\", \\\"{x:837,y:548,t:1526668054732};\\\", \\\"{x:836,y:548,t:1526668054828};\\\", \\\"{x:835,y:548,t:1526668054852};\\\", \\\"{x:833,y:548,t:1526668054876};\\\", \\\"{x:832,y:548,t:1526668054907};\\\", \\\"{x:830,y:548,t:1526668054931};\\\", \\\"{x:828,y:549,t:1526668055451};\\\", \\\"{x:828,y:550,t:1526668055460};\\\", \\\"{x:825,y:558,t:1526668055477};\\\", \\\"{x:822,y:569,t:1526668055492};\\\", \\\"{x:816,y:581,t:1526668055509};\\\", \\\"{x:809,y:593,t:1526668055525};\\\", \\\"{x:801,y:605,t:1526668055542};\\\", \\\"{x:794,y:615,t:1526668055559};\\\", \\\"{x:784,y:627,t:1526668055576};\\\", \\\"{x:774,y:640,t:1526668055593};\\\", \\\"{x:764,y:652,t:1526668055609};\\\", \\\"{x:757,y:665,t:1526668055624};\\\", \\\"{x:747,y:682,t:1526668055642};\\\", \\\"{x:725,y:708,t:1526668055659};\\\", \\\"{x:713,y:722,t:1526668055674};\\\", \\\"{x:702,y:731,t:1526668055692};\\\", \\\"{x:692,y:736,t:1526668055709};\\\", \\\"{x:687,y:741,t:1526668055725};\\\", \\\"{x:677,y:747,t:1526668055742};\\\", \\\"{x:673,y:750,t:1526668055759};\\\", \\\"{x:669,y:753,t:1526668055775};\\\", \\\"{x:666,y:755,t:1526668055792};\\\", \\\"{x:663,y:756,t:1526668055809};\\\", \\\"{x:658,y:759,t:1526668055825};\\\", \\\"{x:650,y:764,t:1526668055842};\\\", \\\"{x:635,y:772,t:1526668055859};\\\", \\\"{x:624,y:778,t:1526668055875};\\\", \\\"{x:617,y:785,t:1526668055891};\\\", \\\"{x:611,y:789,t:1526668055909};\\\", \\\"{x:605,y:792,t:1526668055925};\\\", \\\"{x:602,y:794,t:1526668055942};\\\", \\\"{x:601,y:794,t:1526668056036};\\\", \\\"{x:600,y:794,t:1526668056042};\\\", \\\"{x:595,y:793,t:1526668056059};\\\", \\\"{x:592,y:791,t:1526668056075};\\\", \\\"{x:589,y:788,t:1526668056092};\\\", \\\"{x:585,y:783,t:1526668056109};\\\", \\\"{x:579,y:778,t:1526668056125};\\\", \\\"{x:568,y:772,t:1526668056143};\\\", \\\"{x:562,y:769,t:1526668056159};\\\", \\\"{x:558,y:768,t:1526668056176};\\\", \\\"{x:553,y:766,t:1526668056193};\\\", \\\"{x:542,y:764,t:1526668056210};\\\", \\\"{x:526,y:762,t:1526668056225};\\\", \\\"{x:510,y:762,t:1526668056243};\\\", \\\"{x:495,y:762,t:1526668056259};\\\", \\\"{x:488,y:762,t:1526668056275};\\\", \\\"{x:488,y:761,t:1526668056563};\\\", \\\"{x:488,y:759,t:1526668056576};\\\", \\\"{x:488,y:758,t:1526668056593};\\\", \\\"{x:487,y:755,t:1526668056609};\\\", \\\"{x:487,y:754,t:1526668056628};\\\", \\\"{x:487,y:753,t:1526668056658};\\\", \\\"{x:487,y:752,t:1526668056896};\\\", \\\"{x:490,y:750,t:1526668056910};\\\", \\\"{x:492,y:748,t:1526668056926};\\\", \\\"{x:493,y:747,t:1526668056943};\\\", \\\"{x:493,y:746,t:1526668056960};\\\", \\\"{x:493,y:744,t:1526668056977};\\\", \\\"{x:493,y:743,t:1526668056993};\\\", \\\"{x:493,y:742,t:1526668057010};\\\", \\\"{x:494,y:740,t:1526668057027};\\\" ] }, { \\\"rt\\\": 19234, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 308665, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-12 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:737,t:1526668059772};\\\", \\\"{x:499,y:729,t:1526668059782};\\\", \\\"{x:518,y:696,t:1526668059809};\\\", \\\"{x:529,y:679,t:1526668059816};\\\", \\\"{x:555,y:645,t:1526668059829};\\\", \\\"{x:577,y:614,t:1526668059845};\\\", \\\"{x:595,y:588,t:1526668059863};\\\", \\\"{x:610,y:569,t:1526668059879};\\\", \\\"{x:619,y:555,t:1526668059896};\\\", \\\"{x:625,y:545,t:1526668059912};\\\", \\\"{x:626,y:541,t:1526668059929};\\\", \\\"{x:628,y:538,t:1526668059945};\\\", \\\"{x:628,y:536,t:1526668059962};\\\", \\\"{x:628,y:531,t:1526668059978};\\\", \\\"{x:628,y:524,t:1526668059996};\\\", \\\"{x:616,y:513,t:1526668060013};\\\", \\\"{x:596,y:501,t:1526668060029};\\\", \\\"{x:579,y:489,t:1526668060045};\\\", \\\"{x:566,y:478,t:1526668060063};\\\", \\\"{x:553,y:470,t:1526668060079};\\\", \\\"{x:549,y:466,t:1526668060096};\\\", \\\"{x:546,y:461,t:1526668060113};\\\", \\\"{x:545,y:460,t:1526668060129};\\\", \\\"{x:545,y:458,t:1526668060276};\\\", \\\"{x:548,y:458,t:1526668060283};\\\", \\\"{x:554,y:455,t:1526668060297};\\\", \\\"{x:567,y:452,t:1526668060313};\\\", \\\"{x:580,y:448,t:1526668060331};\\\", \\\"{x:600,y:445,t:1526668060347};\\\", \\\"{x:619,y:445,t:1526668060365};\\\", \\\"{x:646,y:446,t:1526668060380};\\\", \\\"{x:694,y:456,t:1526668060397};\\\", \\\"{x:758,y:477,t:1526668060415};\\\", \\\"{x:841,y:499,t:1526668060432};\\\", \\\"{x:919,y:519,t:1526668060447};\\\", \\\"{x:1012,y:557,t:1526668060464};\\\", \\\"{x:1117,y:588,t:1526668060479};\\\", \\\"{x:1215,y:617,t:1526668060496};\\\", \\\"{x:1283,y:644,t:1526668060513};\\\", \\\"{x:1337,y:675,t:1526668060530};\\\", \\\"{x:1386,y:710,t:1526668060547};\\\", \\\"{x:1423,y:763,t:1526668060563};\\\", \\\"{x:1440,y:807,t:1526668060579};\\\", \\\"{x:1451,y:846,t:1526668060596};\\\", \\\"{x:1455,y:868,t:1526668060613};\\\", \\\"{x:1457,y:885,t:1526668060629};\\\", \\\"{x:1459,y:898,t:1526668060646};\\\", \\\"{x:1465,y:914,t:1526668060663};\\\", \\\"{x:1468,y:925,t:1526668060680};\\\", \\\"{x:1472,y:940,t:1526668060697};\\\", \\\"{x:1473,y:948,t:1526668060713};\\\", \\\"{x:1473,y:953,t:1526668060730};\\\", \\\"{x:1473,y:955,t:1526668060747};\\\", \\\"{x:1473,y:959,t:1526668060763};\\\", \\\"{x:1471,y:961,t:1526668060780};\\\", \\\"{x:1470,y:963,t:1526668060797};\\\", \\\"{x:1468,y:969,t:1526668060814};\\\", \\\"{x:1466,y:975,t:1526668060829};\\\", \\\"{x:1463,y:982,t:1526668060846};\\\", \\\"{x:1458,y:991,t:1526668060865};\\\", \\\"{x:1454,y:997,t:1526668060879};\\\", \\\"{x:1450,y:1004,t:1526668060897};\\\", \\\"{x:1443,y:1008,t:1526668060913};\\\", \\\"{x:1440,y:1010,t:1526668060931};\\\", \\\"{x:1437,y:1013,t:1526668060947};\\\", \\\"{x:1436,y:1014,t:1526668060963};\\\", \\\"{x:1434,y:1014,t:1526668060987};\\\", \\\"{x:1433,y:1014,t:1526668061003};\\\", \\\"{x:1431,y:1014,t:1526668061014};\\\", \\\"{x:1421,y:1014,t:1526668061031};\\\", \\\"{x:1405,y:1011,t:1526668061047};\\\", \\\"{x:1396,y:1011,t:1526668061063};\\\", \\\"{x:1387,y:1010,t:1526668061080};\\\", \\\"{x:1384,y:1010,t:1526668061097};\\\", \\\"{x:1381,y:1009,t:1526668061113};\\\", \\\"{x:1377,y:1009,t:1526668061131};\\\", \\\"{x:1375,y:1008,t:1526668061147};\\\", \\\"{x:1371,y:1008,t:1526668061163};\\\", \\\"{x:1366,y:1007,t:1526668061180};\\\", \\\"{x:1364,y:1007,t:1526668061196};\\\", \\\"{x:1360,y:1007,t:1526668061213};\\\", \\\"{x:1358,y:1007,t:1526668061231};\\\", \\\"{x:1357,y:1007,t:1526668061247};\\\", \\\"{x:1356,y:1007,t:1526668061263};\\\", \\\"{x:1355,y:1006,t:1526668061468};\\\", \\\"{x:1354,y:1006,t:1526668061481};\\\", \\\"{x:1352,y:1003,t:1526668061497};\\\", \\\"{x:1349,y:999,t:1526668061514};\\\", \\\"{x:1348,y:994,t:1526668061532};\\\", \\\"{x:1347,y:993,t:1526668061547};\\\", \\\"{x:1345,y:990,t:1526668061564};\\\", \\\"{x:1345,y:989,t:1526668061580};\\\", \\\"{x:1345,y:987,t:1526668061597};\\\", \\\"{x:1345,y:986,t:1526668061613};\\\", \\\"{x:1343,y:984,t:1526668061630};\\\", \\\"{x:1343,y:983,t:1526668061648};\\\", \\\"{x:1343,y:981,t:1526668061663};\\\", \\\"{x:1343,y:980,t:1526668061680};\\\", \\\"{x:1343,y:979,t:1526668061813};\\\", \\\"{x:1343,y:978,t:1526668061836};\\\", \\\"{x:1342,y:977,t:1526668061848};\\\", \\\"{x:1342,y:976,t:1526668061864};\\\", \\\"{x:1342,y:974,t:1526668061881};\\\", \\\"{x:1342,y:973,t:1526668061898};\\\", \\\"{x:1342,y:971,t:1526668061914};\\\", \\\"{x:1342,y:970,t:1526668061931};\\\", \\\"{x:1342,y:968,t:1526668061948};\\\", \\\"{x:1342,y:965,t:1526668061965};\\\", \\\"{x:1342,y:963,t:1526668061981};\\\", \\\"{x:1342,y:962,t:1526668061998};\\\", \\\"{x:1342,y:960,t:1526668062027};\\\", \\\"{x:1343,y:959,t:1526668062036};\\\", \\\"{x:1343,y:958,t:1526668062068};\\\", \\\"{x:1343,y:956,t:1526668062164};\\\", \\\"{x:1344,y:956,t:1526668062182};\\\", \\\"{x:1345,y:955,t:1526668062204};\\\", \\\"{x:1347,y:954,t:1526668062228};\\\", \\\"{x:1347,y:953,t:1526668062243};\\\", \\\"{x:1347,y:952,t:1526668062260};\\\", \\\"{x:1348,y:951,t:1526668062268};\\\", \\\"{x:1349,y:949,t:1526668062281};\\\", \\\"{x:1351,y:947,t:1526668062298};\\\", \\\"{x:1353,y:944,t:1526668062315};\\\", \\\"{x:1356,y:941,t:1526668062331};\\\", \\\"{x:1362,y:936,t:1526668062348};\\\", \\\"{x:1363,y:934,t:1526668062365};\\\", \\\"{x:1368,y:932,t:1526668062381};\\\", \\\"{x:1370,y:931,t:1526668062398};\\\", \\\"{x:1375,y:928,t:1526668062415};\\\", \\\"{x:1377,y:926,t:1526668062431};\\\", \\\"{x:1381,y:924,t:1526668062448};\\\", \\\"{x:1384,y:923,t:1526668062465};\\\", \\\"{x:1389,y:920,t:1526668062482};\\\", \\\"{x:1390,y:919,t:1526668062498};\\\", \\\"{x:1394,y:916,t:1526668062515};\\\", \\\"{x:1396,y:916,t:1526668062531};\\\", \\\"{x:1396,y:915,t:1526668062548};\\\", \\\"{x:1396,y:913,t:1526668062682};\\\", \\\"{x:1396,y:911,t:1526668062699};\\\", \\\"{x:1396,y:909,t:1526668062714};\\\", \\\"{x:1393,y:906,t:1526668062730};\\\", \\\"{x:1393,y:904,t:1526668062748};\\\", \\\"{x:1391,y:901,t:1526668062765};\\\", \\\"{x:1390,y:900,t:1526668062782};\\\", \\\"{x:1389,y:899,t:1526668062798};\\\", \\\"{x:1389,y:898,t:1526668062815};\\\", \\\"{x:1387,y:898,t:1526668065372};\\\", \\\"{x:1377,y:900,t:1526668065386};\\\", \\\"{x:1341,y:900,t:1526668065400};\\\", \\\"{x:1297,y:900,t:1526668065416};\\\", \\\"{x:1213,y:900,t:1526668065432};\\\", \\\"{x:1108,y:900,t:1526668065449};\\\", \\\"{x:925,y:900,t:1526668065466};\\\", \\\"{x:819,y:895,t:1526668065483};\\\", \\\"{x:733,y:886,t:1526668065499};\\\", \\\"{x:674,y:867,t:1526668065517};\\\", \\\"{x:618,y:840,t:1526668065532};\\\", \\\"{x:576,y:812,t:1526668065550};\\\", \\\"{x:549,y:788,t:1526668065567};\\\", \\\"{x:532,y:762,t:1526668065584};\\\", \\\"{x:519,y:736,t:1526668065600};\\\", \\\"{x:510,y:713,t:1526668065616};\\\", \\\"{x:505,y:691,t:1526668065633};\\\", \\\"{x:504,y:666,t:1526668065650};\\\", \\\"{x:504,y:656,t:1526668065668};\\\", \\\"{x:510,y:645,t:1526668065683};\\\", \\\"{x:519,y:637,t:1526668065700};\\\", \\\"{x:523,y:631,t:1526668065717};\\\", \\\"{x:528,y:625,t:1526668065734};\\\", \\\"{x:531,y:620,t:1526668065750};\\\", \\\"{x:533,y:617,t:1526668065766};\\\", \\\"{x:533,y:616,t:1526668065786};\\\", \\\"{x:533,y:615,t:1526668065800};\\\", \\\"{x:530,y:611,t:1526668065817};\\\", \\\"{x:522,y:608,t:1526668065834};\\\", \\\"{x:510,y:602,t:1526668065849};\\\", \\\"{x:481,y:593,t:1526668065869};\\\", \\\"{x:462,y:587,t:1526668065883};\\\", \\\"{x:445,y:582,t:1526668065901};\\\", \\\"{x:432,y:578,t:1526668065917};\\\", \\\"{x:417,y:573,t:1526668065935};\\\", \\\"{x:403,y:572,t:1526668065950};\\\", \\\"{x:389,y:569,t:1526668065968};\\\", \\\"{x:379,y:568,t:1526668065984};\\\", \\\"{x:370,y:566,t:1526668066001};\\\", \\\"{x:367,y:565,t:1526668066018};\\\", \\\"{x:365,y:564,t:1526668066034};\\\", \\\"{x:366,y:563,t:1526668066123};\\\", \\\"{x:367,y:562,t:1526668066141};\\\", \\\"{x:368,y:561,t:1526668066154};\\\", \\\"{x:369,y:561,t:1526668066167};\\\", \\\"{x:372,y:561,t:1526668066184};\\\", \\\"{x:374,y:560,t:1526668066200};\\\", \\\"{x:377,y:559,t:1526668066217};\\\", \\\"{x:384,y:558,t:1526668066234};\\\", \\\"{x:387,y:557,t:1526668066250};\\\", \\\"{x:389,y:556,t:1526668066267};\\\", \\\"{x:390,y:556,t:1526668066547};\\\", \\\"{x:392,y:556,t:1526668066563};\\\", \\\"{x:393,y:556,t:1526668066571};\\\", \\\"{x:394,y:556,t:1526668066584};\\\", \\\"{x:398,y:554,t:1526668066601};\\\", \\\"{x:404,y:553,t:1526668066618};\\\", \\\"{x:413,y:549,t:1526668066635};\\\", \\\"{x:418,y:546,t:1526668066651};\\\", \\\"{x:419,y:546,t:1526668066668};\\\", \\\"{x:422,y:545,t:1526668067140};\\\", \\\"{x:424,y:544,t:1526668067152};\\\", \\\"{x:434,y:542,t:1526668067169};\\\", \\\"{x:447,y:540,t:1526668067185};\\\", \\\"{x:463,y:536,t:1526668067202};\\\", \\\"{x:477,y:534,t:1526668067220};\\\", \\\"{x:483,y:533,t:1526668067235};\\\", \\\"{x:489,y:533,t:1526668067252};\\\", \\\"{x:496,y:533,t:1526668067269};\\\", \\\"{x:504,y:533,t:1526668067287};\\\", \\\"{x:514,y:533,t:1526668067301};\\\", \\\"{x:528,y:535,t:1526668067318};\\\", \\\"{x:543,y:540,t:1526668067336};\\\", \\\"{x:557,y:545,t:1526668067351};\\\", \\\"{x:569,y:549,t:1526668067368};\\\", \\\"{x:581,y:554,t:1526668067385};\\\", \\\"{x:596,y:557,t:1526668067402};\\\", \\\"{x:625,y:561,t:1526668067418};\\\", \\\"{x:646,y:563,t:1526668067436};\\\", \\\"{x:665,y:563,t:1526668067451};\\\", \\\"{x:682,y:563,t:1526668067468};\\\", \\\"{x:702,y:563,t:1526668067486};\\\", \\\"{x:721,y:563,t:1526668067501};\\\", \\\"{x:739,y:563,t:1526668067520};\\\", \\\"{x:754,y:563,t:1526668067535};\\\", \\\"{x:761,y:563,t:1526668067552};\\\", \\\"{x:763,y:563,t:1526668067569};\\\", \\\"{x:765,y:563,t:1526668067586};\\\", \\\"{x:768,y:562,t:1526668067603};\\\", \\\"{x:774,y:559,t:1526668067618};\\\", \\\"{x:777,y:558,t:1526668067635};\\\", \\\"{x:781,y:557,t:1526668067651};\\\", \\\"{x:785,y:555,t:1526668067669};\\\", \\\"{x:791,y:554,t:1526668067686};\\\", \\\"{x:796,y:554,t:1526668067702};\\\", \\\"{x:800,y:552,t:1526668067719};\\\", \\\"{x:801,y:552,t:1526668067736};\\\", \\\"{x:802,y:552,t:1526668067811};\\\", \\\"{x:802,y:554,t:1526668067827};\\\", \\\"{x:801,y:556,t:1526668067839};\\\", \\\"{x:796,y:561,t:1526668067852};\\\", \\\"{x:785,y:568,t:1526668067869};\\\", \\\"{x:773,y:573,t:1526668067885};\\\", \\\"{x:758,y:579,t:1526668067903};\\\", \\\"{x:742,y:585,t:1526668067918};\\\", \\\"{x:726,y:594,t:1526668067936};\\\", \\\"{x:711,y:603,t:1526668067953};\\\", \\\"{x:690,y:612,t:1526668067968};\\\", \\\"{x:669,y:617,t:1526668067985};\\\", \\\"{x:633,y:622,t:1526668068002};\\\", \\\"{x:617,y:624,t:1526668068018};\\\", \\\"{x:601,y:627,t:1526668068035};\\\", \\\"{x:586,y:627,t:1526668068052};\\\", \\\"{x:574,y:627,t:1526668068070};\\\", \\\"{x:557,y:627,t:1526668068086};\\\", \\\"{x:542,y:627,t:1526668068103};\\\", \\\"{x:524,y:628,t:1526668068122};\\\", \\\"{x:505,y:628,t:1526668068139};\\\", \\\"{x:487,y:628,t:1526668068157};\\\", \\\"{x:470,y:628,t:1526668068172};\\\", \\\"{x:458,y:629,t:1526668068189};\\\", \\\"{x:447,y:631,t:1526668068206};\\\", \\\"{x:446,y:631,t:1526668068222};\\\", \\\"{x:444,y:631,t:1526668068439};\\\", \\\"{x:443,y:631,t:1526668068551};\\\", \\\"{x:443,y:632,t:1526668069449};\\\", \\\"{x:441,y:632,t:1526668069502};\\\", \\\"{x:439,y:633,t:1526668069510};\\\", \\\"{x:438,y:635,t:1526668069524};\\\", \\\"{x:436,y:635,t:1526668069540};\\\", \\\"{x:431,y:637,t:1526668069557};\\\", \\\"{x:418,y:641,t:1526668069574};\\\", \\\"{x:408,y:644,t:1526668069590};\\\", \\\"{x:392,y:646,t:1526668069607};\\\", \\\"{x:373,y:650,t:1526668069624};\\\", \\\"{x:355,y:652,t:1526668069640};\\\", \\\"{x:337,y:654,t:1526668069657};\\\", \\\"{x:323,y:655,t:1526668069674};\\\", \\\"{x:316,y:655,t:1526668069690};\\\", \\\"{x:309,y:655,t:1526668069707};\\\", \\\"{x:302,y:655,t:1526668069724};\\\", \\\"{x:299,y:655,t:1526668069740};\\\", \\\"{x:297,y:655,t:1526668069757};\\\", \\\"{x:296,y:655,t:1526668069774};\\\", \\\"{x:295,y:655,t:1526668069799};\\\", \\\"{x:293,y:655,t:1526668069815};\\\", \\\"{x:292,y:655,t:1526668069824};\\\", \\\"{x:288,y:655,t:1526668069840};\\\", \\\"{x:281,y:655,t:1526668069857};\\\", \\\"{x:274,y:655,t:1526668069874};\\\", \\\"{x:265,y:655,t:1526668069893};\\\", \\\"{x:256,y:655,t:1526668069906};\\\", \\\"{x:240,y:655,t:1526668069924};\\\", \\\"{x:224,y:655,t:1526668069941};\\\", \\\"{x:209,y:655,t:1526668069956};\\\", \\\"{x:186,y:655,t:1526668069974};\\\", \\\"{x:169,y:655,t:1526668069990};\\\", \\\"{x:150,y:655,t:1526668070007};\\\", \\\"{x:134,y:655,t:1526668070024};\\\", \\\"{x:117,y:655,t:1526668070040};\\\", \\\"{x:107,y:655,t:1526668070056};\\\", \\\"{x:104,y:655,t:1526668070073};\\\", \\\"{x:103,y:655,t:1526668070151};\\\", \\\"{x:103,y:653,t:1526668070175};\\\", \\\"{x:109,y:650,t:1526668070191};\\\", \\\"{x:117,y:645,t:1526668070208};\\\", \\\"{x:127,y:640,t:1526668070224};\\\", \\\"{x:132,y:637,t:1526668070242};\\\", \\\"{x:139,y:633,t:1526668070257};\\\", \\\"{x:149,y:629,t:1526668070274};\\\", \\\"{x:153,y:627,t:1526668070291};\\\", \\\"{x:160,y:624,t:1526668070307};\\\", \\\"{x:165,y:621,t:1526668070324};\\\", \\\"{x:170,y:620,t:1526668070341};\\\", \\\"{x:177,y:620,t:1526668070358};\\\", \\\"{x:192,y:620,t:1526668070374};\\\", \\\"{x:206,y:623,t:1526668070391};\\\", \\\"{x:222,y:626,t:1526668070407};\\\", \\\"{x:243,y:628,t:1526668070424};\\\", \\\"{x:262,y:631,t:1526668070441};\\\", \\\"{x:283,y:633,t:1526668070458};\\\", \\\"{x:302,y:634,t:1526668070474};\\\", \\\"{x:316,y:634,t:1526668070491};\\\", \\\"{x:326,y:634,t:1526668070507};\\\", \\\"{x:333,y:634,t:1526668070524};\\\", \\\"{x:340,y:634,t:1526668070541};\\\", \\\"{x:348,y:634,t:1526668070557};\\\", \\\"{x:358,y:631,t:1526668070574};\\\", \\\"{x:364,y:630,t:1526668070590};\\\", \\\"{x:368,y:628,t:1526668070607};\\\", \\\"{x:370,y:627,t:1526668070624};\\\", \\\"{x:375,y:624,t:1526668070641};\\\", \\\"{x:377,y:623,t:1526668070658};\\\", \\\"{x:378,y:621,t:1526668070674};\\\", \\\"{x:379,y:621,t:1526668070691};\\\", \\\"{x:381,y:620,t:1526668070709};\\\", \\\"{x:383,y:618,t:1526668070725};\\\", \\\"{x:384,y:617,t:1526668070741};\\\", \\\"{x:393,y:606,t:1526668070758};\\\", \\\"{x:395,y:603,t:1526668070774};\\\", \\\"{x:396,y:600,t:1526668070791};\\\", \\\"{x:398,y:594,t:1526668070807};\\\", \\\"{x:398,y:591,t:1526668070825};\\\", \\\"{x:399,y:585,t:1526668070841};\\\", \\\"{x:400,y:582,t:1526668070858};\\\", \\\"{x:401,y:578,t:1526668070874};\\\", \\\"{x:402,y:575,t:1526668070891};\\\", \\\"{x:403,y:570,t:1526668070907};\\\", \\\"{x:405,y:565,t:1526668070924};\\\", \\\"{x:406,y:561,t:1526668070942};\\\", \\\"{x:407,y:557,t:1526668070957};\\\", \\\"{x:407,y:556,t:1526668070974};\\\", \\\"{x:408,y:555,t:1526668070991};\\\", \\\"{x:408,y:553,t:1526668071014};\\\", \\\"{x:409,y:552,t:1526668071024};\\\", \\\"{x:409,y:551,t:1526668071041};\\\", \\\"{x:409,y:550,t:1526668071059};\\\", \\\"{x:409,y:548,t:1526668071074};\\\", \\\"{x:409,y:547,t:1526668071094};\\\", \\\"{x:409,y:549,t:1526668071413};\\\", \\\"{x:408,y:551,t:1526668071425};\\\", \\\"{x:405,y:560,t:1526668071442};\\\", \\\"{x:405,y:571,t:1526668071458};\\\", \\\"{x:405,y:582,t:1526668071475};\\\", \\\"{x:405,y:591,t:1526668071492};\\\", \\\"{x:405,y:599,t:1526668071508};\\\", \\\"{x:405,y:603,t:1526668071526};\\\", \\\"{x:405,y:613,t:1526668071542};\\\", \\\"{x:405,y:620,t:1526668071558};\\\", \\\"{x:405,y:624,t:1526668071574};\\\", \\\"{x:405,y:626,t:1526668071591};\\\", \\\"{x:405,y:627,t:1526668071862};\\\", \\\"{x:406,y:627,t:1526668071877};\\\", \\\"{x:407,y:627,t:1526668071891};\\\", \\\"{x:411,y:629,t:1526668071909};\\\", \\\"{x:424,y:636,t:1526668071925};\\\", \\\"{x:438,y:648,t:1526668071942};\\\", \\\"{x:441,y:651,t:1526668071959};\\\", \\\"{x:446,y:651,t:1526668072151};\\\", \\\"{x:452,y:653,t:1526668072160};\\\", \\\"{x:464,y:660,t:1526668072176};\\\", \\\"{x:472,y:666,t:1526668072193};\\\", \\\"{x:479,y:674,t:1526668072211};\\\", \\\"{x:484,y:680,t:1526668072227};\\\", \\\"{x:488,y:685,t:1526668072242};\\\", \\\"{x:491,y:690,t:1526668072260};\\\", \\\"{x:492,y:691,t:1526668072276};\\\", \\\"{x:493,y:693,t:1526668072318};\\\", \\\"{x:493,y:694,t:1526668072399};\\\", \\\"{x:493,y:695,t:1526668072409};\\\", \\\"{x:494,y:698,t:1526668072427};\\\", \\\"{x:495,y:701,t:1526668072443};\\\", \\\"{x:498,y:707,t:1526668072459};\\\", \\\"{x:500,y:709,t:1526668072476};\\\", \\\"{x:502,y:711,t:1526668072493};\\\", \\\"{x:502,y:712,t:1526668072509};\\\", \\\"{x:502,y:713,t:1526668072527};\\\", \\\"{x:503,y:714,t:1526668072574};\\\", \\\"{x:503,y:715,t:1526668072598};\\\", \\\"{x:504,y:715,t:1526668072609};\\\", \\\"{x:504,y:716,t:1526668072626};\\\", \\\"{x:504,y:718,t:1526668072643};\\\", \\\"{x:504,y:719,t:1526668072659};\\\", \\\"{x:505,y:722,t:1526668072676};\\\", \\\"{x:507,y:724,t:1526668072693};\\\", \\\"{x:507,y:726,t:1526668072709};\\\", \\\"{x:507,y:729,t:1526668072726};\\\", \\\"{x:508,y:731,t:1526668072743};\\\", \\\"{x:508,y:732,t:1526668072759};\\\", \\\"{x:509,y:734,t:1526668072782};\\\", \\\"{x:509,y:735,t:1526668072806};\\\", \\\"{x:509,y:736,t:1526668072814};\\\", \\\"{x:509,y:737,t:1526668072826};\\\", \\\"{x:509,y:738,t:1526668072847};\\\", \\\"{x:509,y:739,t:1526668072862};\\\", \\\"{x:509,y:740,t:1526668072877};\\\", \\\"{x:509,y:742,t:1526668072894};\\\", \\\"{x:509,y:743,t:1526668072910};\\\", \\\"{x:509,y:744,t:1526668072927};\\\", \\\"{x:509,y:745,t:1526668072943};\\\", \\\"{x:509,y:746,t:1526668072960};\\\", \\\"{x:509,y:747,t:1526668072976};\\\", \\\"{x:509,y:748,t:1526668072993};\\\", \\\"{x:509,y:749,t:1526668073011};\\\", \\\"{x:509,y:750,t:1526668073027};\\\", \\\"{x:509,y:751,t:1526668073063};\\\", \\\"{x:509,y:752,t:1526668073111};\\\", \\\"{x:509,y:753,t:1526668073207};\\\", \\\"{x:509,y:754,t:1526668073263};\\\", \\\"{x:509,y:755,t:1526668073312};\\\", \\\"{x:509,y:754,t:1526668076992};\\\", \\\"{x:509,y:753,t:1526668077012};\\\", \\\"{x:509,y:750,t:1526668077029};\\\", \\\"{x:509,y:748,t:1526668077045};\\\", \\\"{x:509,y:747,t:1526668077064};\\\", \\\"{x:509,y:746,t:1526668077134};\\\", \\\"{x:509,y:745,t:1526668077150};\\\", \\\"{x:509,y:744,t:1526668077163};\\\", \\\"{x:509,y:743,t:1526668077179};\\\", \\\"{x:509,y:742,t:1526668077196};\\\" ] }, { \\\"rt\\\": 9185, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 319095, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:738,t:1526668085431};\\\", \\\"{x:496,y:714,t:1526668085439};\\\", \\\"{x:486,y:704,t:1526668085450};\\\", \\\"{x:460,y:667,t:1526668085475};\\\", \\\"{x:447,y:642,t:1526668085486};\\\", \\\"{x:431,y:617,t:1526668085504};\\\", \\\"{x:421,y:596,t:1526668085520};\\\", \\\"{x:416,y:575,t:1526668085537};\\\", \\\"{x:414,y:557,t:1526668085554};\\\", \\\"{x:410,y:538,t:1526668085570};\\\", \\\"{x:408,y:523,t:1526668085587};\\\", \\\"{x:408,y:511,t:1526668085603};\\\", \\\"{x:408,y:505,t:1526668085619};\\\", \\\"{x:410,y:496,t:1526668085636};\\\", \\\"{x:413,y:491,t:1526668085652};\\\", \\\"{x:418,y:487,t:1526668085669};\\\", \\\"{x:425,y:483,t:1526668085687};\\\", \\\"{x:435,y:479,t:1526668085704};\\\", \\\"{x:444,y:473,t:1526668085719};\\\", \\\"{x:448,y:472,t:1526668085736};\\\", \\\"{x:451,y:470,t:1526668085754};\\\", \\\"{x:457,y:469,t:1526668085769};\\\", \\\"{x:463,y:469,t:1526668085787};\\\", \\\"{x:467,y:469,t:1526668085804};\\\", \\\"{x:472,y:470,t:1526668085820};\\\", \\\"{x:480,y:478,t:1526668085837};\\\", \\\"{x:502,y:499,t:1526668085855};\\\", \\\"{x:519,y:516,t:1526668085870};\\\", \\\"{x:536,y:532,t:1526668085888};\\\", \\\"{x:546,y:542,t:1526668085903};\\\", \\\"{x:557,y:553,t:1526668085919};\\\", \\\"{x:570,y:562,t:1526668085937};\\\", \\\"{x:582,y:568,t:1526668085954};\\\", \\\"{x:590,y:571,t:1526668085970};\\\", \\\"{x:595,y:572,t:1526668085987};\\\", \\\"{x:600,y:572,t:1526668086004};\\\", \\\"{x:602,y:572,t:1526668086021};\\\", \\\"{x:606,y:572,t:1526668086037};\\\", \\\"{x:612,y:569,t:1526668086053};\\\", \\\"{x:617,y:567,t:1526668086070};\\\", \\\"{x:626,y:564,t:1526668086087};\\\", \\\"{x:629,y:562,t:1526668086105};\\\", \\\"{x:634,y:561,t:1526668086121};\\\", \\\"{x:638,y:558,t:1526668086137};\\\", \\\"{x:645,y:558,t:1526668086154};\\\", \\\"{x:656,y:556,t:1526668086171};\\\", \\\"{x:661,y:555,t:1526668086188};\\\", \\\"{x:665,y:554,t:1526668086204};\\\", \\\"{x:666,y:554,t:1526668086221};\\\", \\\"{x:668,y:554,t:1526668086238};\\\", \\\"{x:671,y:554,t:1526668086254};\\\", \\\"{x:684,y:554,t:1526668086271};\\\", \\\"{x:701,y:554,t:1526668086287};\\\", \\\"{x:725,y:554,t:1526668086305};\\\", \\\"{x:755,y:554,t:1526668086321};\\\", \\\"{x:785,y:554,t:1526668086337};\\\", \\\"{x:813,y:554,t:1526668086353};\\\", \\\"{x:835,y:553,t:1526668086371};\\\", \\\"{x:853,y:553,t:1526668086387};\\\", \\\"{x:867,y:551,t:1526668086404};\\\", \\\"{x:874,y:551,t:1526668086421};\\\", \\\"{x:879,y:551,t:1526668086437};\\\", \\\"{x:882,y:551,t:1526668086454};\\\", \\\"{x:880,y:551,t:1526668086599};\\\", \\\"{x:879,y:551,t:1526668086607};\\\", \\\"{x:878,y:551,t:1526668086621};\\\", \\\"{x:874,y:551,t:1526668086638};\\\", \\\"{x:870,y:551,t:1526668086654};\\\", \\\"{x:868,y:550,t:1526668086672};\\\", \\\"{x:867,y:548,t:1526668086687};\\\", \\\"{x:866,y:547,t:1526668086704};\\\", \\\"{x:864,y:546,t:1526668086721};\\\", \\\"{x:863,y:546,t:1526668086925};\\\", \\\"{x:860,y:546,t:1526668086938};\\\", \\\"{x:851,y:548,t:1526668086954};\\\", \\\"{x:838,y:554,t:1526668086971};\\\", \\\"{x:810,y:565,t:1526668086988};\\\", \\\"{x:765,y:580,t:1526668087005};\\\", \\\"{x:718,y:599,t:1526668087021};\\\", \\\"{x:667,y:626,t:1526668087038};\\\", \\\"{x:647,y:638,t:1526668087055};\\\", \\\"{x:628,y:649,t:1526668087071};\\\", \\\"{x:609,y:660,t:1526668087088};\\\", \\\"{x:598,y:668,t:1526668087105};\\\", \\\"{x:589,y:675,t:1526668087120};\\\", \\\"{x:582,y:681,t:1526668087138};\\\", \\\"{x:577,y:685,t:1526668087155};\\\", \\\"{x:573,y:689,t:1526668087171};\\\", \\\"{x:570,y:691,t:1526668087188};\\\", \\\"{x:567,y:693,t:1526668087204};\\\", \\\"{x:566,y:694,t:1526668087221};\\\", \\\"{x:564,y:696,t:1526668087238};\\\", \\\"{x:561,y:698,t:1526668087254};\\\", \\\"{x:558,y:701,t:1526668087271};\\\", \\\"{x:554,y:705,t:1526668087288};\\\", \\\"{x:550,y:708,t:1526668087305};\\\", \\\"{x:546,y:712,t:1526668087322};\\\", \\\"{x:546,y:713,t:1526668087338};\\\", \\\"{x:544,y:715,t:1526668087355};\\\", \\\"{x:542,y:715,t:1526668087371};\\\", \\\"{x:541,y:716,t:1526668087389};\\\", \\\"{x:540,y:718,t:1526668087405};\\\", \\\"{x:539,y:721,t:1526668087423};\\\", \\\"{x:536,y:728,t:1526668087438};\\\", \\\"{x:535,y:730,t:1526668087455};\\\" ] }, { \\\"rt\\\": 21766, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 342121, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:725,t:1526668104663};\\\", \\\"{x:510,y:697,t:1526668104671};\\\", \\\"{x:457,y:659,t:1526668104686};\\\", \\\"{x:404,y:622,t:1526668104702};\\\", \\\"{x:366,y:591,t:1526668104718};\\\", \\\"{x:346,y:568,t:1526668104735};\\\", \\\"{x:337,y:552,t:1526668104752};\\\", \\\"{x:337,y:541,t:1526668104768};\\\", \\\"{x:339,y:528,t:1526668104786};\\\", \\\"{x:349,y:517,t:1526668104803};\\\", \\\"{x:360,y:503,t:1526668104818};\\\", \\\"{x:373,y:491,t:1526668104835};\\\", \\\"{x:386,y:482,t:1526668104853};\\\", \\\"{x:395,y:474,t:1526668104869};\\\", \\\"{x:401,y:470,t:1526668104885};\\\", \\\"{x:404,y:468,t:1526668104903};\\\", \\\"{x:406,y:468,t:1526668104918};\\\", \\\"{x:409,y:467,t:1526668104935};\\\", \\\"{x:411,y:466,t:1526668104953};\\\", \\\"{x:413,y:465,t:1526668104969};\\\", \\\"{x:414,y:464,t:1526668104986};\\\", \\\"{x:415,y:464,t:1526668105003};\\\", \\\"{x:416,y:464,t:1526668105046};\\\", \\\"{x:415,y:464,t:1526668106431};\\\", \\\"{x:414,y:464,t:1526668106438};\\\", \\\"{x:412,y:465,t:1526668106662};\\\", \\\"{x:411,y:466,t:1526668106678};\\\", \\\"{x:409,y:467,t:1526668106687};\\\", \\\"{x:407,y:470,t:1526668106705};\\\", \\\"{x:403,y:476,t:1526668106721};\\\", \\\"{x:401,y:483,t:1526668106737};\\\", \\\"{x:396,y:490,t:1526668106755};\\\", \\\"{x:394,y:496,t:1526668106772};\\\", \\\"{x:393,y:497,t:1526668106786};\\\", \\\"{x:392,y:497,t:1526668106821};\\\", \\\"{x:392,y:498,t:1526668107614};\\\", \\\"{x:392,y:499,t:1526668107847};\\\", \\\"{x:394,y:506,t:1526668107855};\\\", \\\"{x:399,y:518,t:1526668107874};\\\", \\\"{x:403,y:525,t:1526668107888};\\\", \\\"{x:408,y:532,t:1526668107905};\\\", \\\"{x:417,y:543,t:1526668107922};\\\", \\\"{x:435,y:555,t:1526668107938};\\\", \\\"{x:454,y:569,t:1526668107955};\\\", \\\"{x:474,y:581,t:1526668107972};\\\", \\\"{x:506,y:592,t:1526668107988};\\\", \\\"{x:536,y:602,t:1526668108005};\\\", \\\"{x:595,y:619,t:1526668108021};\\\", \\\"{x:634,y:628,t:1526668108037};\\\", \\\"{x:667,y:637,t:1526668108055};\\\", \\\"{x:689,y:640,t:1526668108072};\\\", \\\"{x:703,y:641,t:1526668108088};\\\", \\\"{x:715,y:641,t:1526668108104};\\\", \\\"{x:724,y:639,t:1526668108121};\\\", \\\"{x:730,y:636,t:1526668108138};\\\", \\\"{x:735,y:630,t:1526668108156};\\\", \\\"{x:740,y:620,t:1526668108171};\\\", \\\"{x:745,y:609,t:1526668108188};\\\", \\\"{x:751,y:594,t:1526668108206};\\\", \\\"{x:758,y:574,t:1526668108223};\\\", \\\"{x:759,y:563,t:1526668108237};\\\", \\\"{x:760,y:553,t:1526668108255};\\\", \\\"{x:762,y:546,t:1526668108271};\\\", \\\"{x:763,y:540,t:1526668108289};\\\", \\\"{x:767,y:533,t:1526668108305};\\\", \\\"{x:770,y:527,t:1526668108321};\\\", \\\"{x:775,y:522,t:1526668108339};\\\", \\\"{x:787,y:514,t:1526668108356};\\\", \\\"{x:801,y:506,t:1526668108372};\\\", \\\"{x:812,y:498,t:1526668108388};\\\", \\\"{x:819,y:493,t:1526668108405};\\\", \\\"{x:826,y:489,t:1526668108422};\\\", \\\"{x:827,y:488,t:1526668108438};\\\", \\\"{x:824,y:488,t:1526668108758};\\\", \\\"{x:819,y:491,t:1526668108772};\\\", \\\"{x:804,y:503,t:1526668108788};\\\", \\\"{x:781,y:530,t:1526668108807};\\\", \\\"{x:747,y:572,t:1526668108822};\\\", \\\"{x:717,y:608,t:1526668108838};\\\", \\\"{x:697,y:630,t:1526668108854};\\\", \\\"{x:678,y:651,t:1526668108872};\\\", \\\"{x:652,y:674,t:1526668108888};\\\", \\\"{x:638,y:688,t:1526668108905};\\\", \\\"{x:623,y:702,t:1526668108923};\\\", \\\"{x:610,y:711,t:1526668108938};\\\", \\\"{x:601,y:719,t:1526668108955};\\\", \\\"{x:590,y:726,t:1526668108972};\\\", \\\"{x:581,y:732,t:1526668108989};\\\", \\\"{x:572,y:737,t:1526668109005};\\\", \\\"{x:568,y:739,t:1526668109022};\\\", \\\"{x:567,y:735,t:1526668109159};\\\", \\\"{x:567,y:729,t:1526668109174};\\\", \\\"{x:590,y:698,t:1526668109190};\\\", \\\"{x:606,y:679,t:1526668109207};\\\", \\\"{x:622,y:662,t:1526668109225};\\\", \\\"{x:639,y:643,t:1526668109240};\\\", \\\"{x:660,y:627,t:1526668109258};\\\", \\\"{x:677,y:613,t:1526668109273};\\\", \\\"{x:691,y:603,t:1526668109289};\\\", \\\"{x:703,y:596,t:1526668109306};\\\", \\\"{x:712,y:590,t:1526668109323};\\\", \\\"{x:718,y:587,t:1526668109338};\\\", \\\"{x:729,y:581,t:1526668109356};\\\", \\\"{x:737,y:577,t:1526668109372};\\\", \\\"{x:748,y:572,t:1526668109388};\\\", \\\"{x:759,y:567,t:1526668109405};\\\", \\\"{x:767,y:564,t:1526668109423};\\\", \\\"{x:770,y:562,t:1526668109440};\\\", \\\"{x:775,y:559,t:1526668109456};\\\", \\\"{x:783,y:555,t:1526668109474};\\\", \\\"{x:793,y:549,t:1526668109489};\\\", \\\"{x:801,y:544,t:1526668109505};\\\", \\\"{x:805,y:541,t:1526668109523};\\\", \\\"{x:807,y:540,t:1526668109538};\\\", \\\"{x:809,y:538,t:1526668109556};\\\", \\\"{x:810,y:537,t:1526668109572};\\\", \\\"{x:813,y:534,t:1526668109589};\\\", \\\"{x:818,y:529,t:1526668109605};\\\", \\\"{x:824,y:525,t:1526668109623};\\\", \\\"{x:827,y:521,t:1526668109640};\\\", \\\"{x:830,y:518,t:1526668109656};\\\", \\\"{x:832,y:516,t:1526668109674};\\\", \\\"{x:834,y:514,t:1526668109689};\\\", \\\"{x:834,y:513,t:1526668109706};\\\", \\\"{x:837,y:510,t:1526668109723};\\\", \\\"{x:840,y:507,t:1526668109740};\\\", \\\"{x:841,y:506,t:1526668109755};\\\", \\\"{x:843,y:505,t:1526668109773};\\\", \\\"{x:844,y:505,t:1526668109790};\\\", \\\"{x:844,y:504,t:1526668109806};\\\", \\\"{x:845,y:504,t:1526668109823};\\\", \\\"{x:844,y:504,t:1526668110157};\\\", \\\"{x:841,y:505,t:1526668110172};\\\", \\\"{x:838,y:507,t:1526668110189};\\\", \\\"{x:833,y:510,t:1526668110207};\\\", \\\"{x:828,y:512,t:1526668110223};\\\", \\\"{x:811,y:521,t:1526668110241};\\\", \\\"{x:788,y:534,t:1526668110257};\\\", \\\"{x:746,y:568,t:1526668110274};\\\", \\\"{x:706,y:611,t:1526668110290};\\\", \\\"{x:666,y:651,t:1526668110307};\\\", \\\"{x:637,y:684,t:1526668110322};\\\", \\\"{x:613,y:708,t:1526668110340};\\\", \\\"{x:601,y:717,t:1526668110357};\\\", \\\"{x:594,y:721,t:1526668110372};\\\", \\\"{x:588,y:724,t:1526668110390};\\\", \\\"{x:585,y:726,t:1526668110407};\\\", \\\"{x:581,y:728,t:1526668110423};\\\", \\\"{x:579,y:728,t:1526668110440};\\\", \\\"{x:577,y:729,t:1526668110457};\\\", \\\"{x:576,y:730,t:1526668110473};\\\", \\\"{x:572,y:731,t:1526668110566};\\\", \\\"{x:571,y:732,t:1526668110574};\\\", \\\"{x:568,y:733,t:1526668110590};\\\", \\\"{x:565,y:735,t:1526668110607};\\\", \\\"{x:563,y:735,t:1526668110625};\\\", \\\"{x:562,y:736,t:1526668110639};\\\", \\\"{x:561,y:736,t:1526668110662};\\\" ] }, { \\\"rt\\\": 11156, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 354493, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-03 PM-02 PM-01 PM-12 PM-Z -02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:561,y:737,t:1526668112389};\\\", \\\"{x:560,y:737,t:1526668112397};\\\", \\\"{x:557,y:739,t:1526668112499};\\\", \\\"{x:556,y:741,t:1526668112511};\\\", \\\"{x:555,y:741,t:1526668112533};\\\", \\\"{x:555,y:742,t:1526668112581};\\\", \\\"{x:554,y:742,t:1526668115487};\\\", \\\"{x:554,y:741,t:1526668115494};\\\", \\\"{x:556,y:734,t:1526668115506};\\\", \\\"{x:569,y:712,t:1526668115523};\\\", \\\"{x:591,y:684,t:1526668115539};\\\", \\\"{x:626,y:647,t:1526668115556};\\\", \\\"{x:739,y:562,t:1526668115577};\\\", \\\"{x:835,y:505,t:1526668115594};\\\", \\\"{x:938,y:449,t:1526668115611};\\\", \\\"{x:1046,y:401,t:1526668115627};\\\", \\\"{x:1131,y:366,t:1526668115644};\\\", \\\"{x:1201,y:338,t:1526668115661};\\\", \\\"{x:1225,y:332,t:1526668115677};\\\", \\\"{x:1234,y:331,t:1526668115694};\\\", \\\"{x:1243,y:331,t:1526668115711};\\\", \\\"{x:1251,y:336,t:1526668115727};\\\", \\\"{x:1262,y:343,t:1526668115744};\\\", \\\"{x:1276,y:351,t:1526668115761};\\\", \\\"{x:1293,y:362,t:1526668115778};\\\", \\\"{x:1312,y:375,t:1526668115794};\\\", \\\"{x:1334,y:392,t:1526668115811};\\\", \\\"{x:1355,y:413,t:1526668115828};\\\", \\\"{x:1375,y:433,t:1526668115845};\\\", \\\"{x:1393,y:451,t:1526668115861};\\\", \\\"{x:1420,y:488,t:1526668115878};\\\", \\\"{x:1451,y:535,t:1526668115894};\\\", \\\"{x:1484,y:580,t:1526668115911};\\\", \\\"{x:1511,y:629,t:1526668115928};\\\", \\\"{x:1534,y:665,t:1526668115945};\\\", \\\"{x:1559,y:709,t:1526668115962};\\\", \\\"{x:1596,y:753,t:1526668115978};\\\", \\\"{x:1617,y:793,t:1526668115994};\\\", \\\"{x:1629,y:820,t:1526668116011};\\\", \\\"{x:1640,y:847,t:1526668116028};\\\", \\\"{x:1650,y:876,t:1526668116044};\\\", \\\"{x:1665,y:916,t:1526668116062};\\\", \\\"{x:1671,y:938,t:1526668116078};\\\", \\\"{x:1676,y:957,t:1526668116095};\\\", \\\"{x:1678,y:972,t:1526668116112};\\\", \\\"{x:1678,y:980,t:1526668116129};\\\", \\\"{x:1678,y:986,t:1526668116145};\\\", \\\"{x:1678,y:989,t:1526668116161};\\\", \\\"{x:1678,y:990,t:1526668116178};\\\", \\\"{x:1677,y:991,t:1526668116295};\\\", \\\"{x:1676,y:991,t:1526668116503};\\\", \\\"{x:1674,y:991,t:1526668116526};\\\", \\\"{x:1671,y:991,t:1526668116534};\\\", \\\"{x:1665,y:990,t:1526668116545};\\\", \\\"{x:1657,y:990,t:1526668116563};\\\", \\\"{x:1648,y:989,t:1526668116578};\\\", \\\"{x:1645,y:989,t:1526668116596};\\\", \\\"{x:1644,y:989,t:1526668116614};\\\", \\\"{x:1642,y:989,t:1526668116654};\\\", \\\"{x:1641,y:989,t:1526668116670};\\\", \\\"{x:1639,y:989,t:1526668116679};\\\", \\\"{x:1633,y:989,t:1526668116696};\\\", \\\"{x:1620,y:989,t:1526668116713};\\\", \\\"{x:1611,y:989,t:1526668116729};\\\", \\\"{x:1602,y:989,t:1526668116746};\\\", \\\"{x:1595,y:988,t:1526668116762};\\\", \\\"{x:1591,y:988,t:1526668116779};\\\", \\\"{x:1589,y:988,t:1526668116796};\\\", \\\"{x:1587,y:986,t:1526668116813};\\\", \\\"{x:1583,y:985,t:1526668116829};\\\", \\\"{x:1571,y:985,t:1526668116846};\\\", \\\"{x:1557,y:983,t:1526668116863};\\\", \\\"{x:1542,y:983,t:1526668116879};\\\", \\\"{x:1525,y:983,t:1526668116896};\\\", \\\"{x:1511,y:983,t:1526668116912};\\\", \\\"{x:1495,y:983,t:1526668116929};\\\", \\\"{x:1477,y:983,t:1526668116946};\\\", \\\"{x:1461,y:983,t:1526668116963};\\\", \\\"{x:1443,y:983,t:1526668116979};\\\", \\\"{x:1424,y:983,t:1526668116996};\\\", \\\"{x:1406,y:983,t:1526668117013};\\\", \\\"{x:1390,y:983,t:1526668117029};\\\", \\\"{x:1370,y:983,t:1526668117046};\\\", \\\"{x:1363,y:982,t:1526668117062};\\\", \\\"{x:1360,y:982,t:1526668117079};\\\", \\\"{x:1359,y:982,t:1526668117095};\\\", \\\"{x:1357,y:982,t:1526668117286};\\\", \\\"{x:1356,y:982,t:1526668117295};\\\", \\\"{x:1354,y:982,t:1526668117312};\\\", \\\"{x:1353,y:982,t:1526668117329};\\\", \\\"{x:1351,y:982,t:1526668117345};\\\", \\\"{x:1348,y:982,t:1526668117362};\\\", \\\"{x:1346,y:982,t:1526668117379};\\\", \\\"{x:1344,y:982,t:1526668117396};\\\", \\\"{x:1349,y:980,t:1526668117717};\\\", \\\"{x:1358,y:976,t:1526668117730};\\\", \\\"{x:1373,y:970,t:1526668117747};\\\", \\\"{x:1391,y:962,t:1526668117762};\\\", \\\"{x:1408,y:955,t:1526668117779};\\\", \\\"{x:1424,y:947,t:1526668117796};\\\", \\\"{x:1439,y:942,t:1526668117812};\\\", \\\"{x:1454,y:936,t:1526668117830};\\\", \\\"{x:1466,y:931,t:1526668117846};\\\", \\\"{x:1472,y:928,t:1526668117862};\\\", \\\"{x:1479,y:925,t:1526668117879};\\\", \\\"{x:1483,y:924,t:1526668117896};\\\", \\\"{x:1492,y:923,t:1526668117913};\\\", \\\"{x:1500,y:920,t:1526668117929};\\\", \\\"{x:1506,y:920,t:1526668117946};\\\", \\\"{x:1511,y:919,t:1526668117964};\\\", \\\"{x:1514,y:918,t:1526668117979};\\\", \\\"{x:1517,y:918,t:1526668117996};\\\", \\\"{x:1518,y:917,t:1526668118014};\\\", \\\"{x:1519,y:917,t:1526668118102};\\\", \\\"{x:1521,y:916,t:1526668118115};\\\", \\\"{x:1523,y:915,t:1526668118130};\\\", \\\"{x:1526,y:913,t:1526668118147};\\\", \\\"{x:1532,y:912,t:1526668118164};\\\", \\\"{x:1533,y:910,t:1526668118180};\\\", \\\"{x:1536,y:909,t:1526668118197};\\\", \\\"{x:1542,y:906,t:1526668118214};\\\", \\\"{x:1543,y:906,t:1526668118230};\\\", \\\"{x:1545,y:905,t:1526668118246};\\\", \\\"{x:1550,y:903,t:1526668118264};\\\", \\\"{x:1551,y:902,t:1526668118280};\\\", \\\"{x:1554,y:902,t:1526668118297};\\\", \\\"{x:1555,y:901,t:1526668118314};\\\", \\\"{x:1556,y:901,t:1526668118330};\\\", \\\"{x:1557,y:901,t:1526668118406};\\\", \\\"{x:1557,y:905,t:1526668118414};\\\", \\\"{x:1557,y:911,t:1526668118430};\\\", \\\"{x:1553,y:919,t:1526668118447};\\\", \\\"{x:1551,y:924,t:1526668118463};\\\", \\\"{x:1548,y:929,t:1526668118481};\\\", \\\"{x:1545,y:933,t:1526668118496};\\\", \\\"{x:1542,y:935,t:1526668118514};\\\", \\\"{x:1538,y:937,t:1526668118530};\\\", \\\"{x:1536,y:939,t:1526668118546};\\\", \\\"{x:1534,y:940,t:1526668118564};\\\", \\\"{x:1530,y:942,t:1526668118580};\\\", \\\"{x:1527,y:943,t:1526668118596};\\\", \\\"{x:1525,y:945,t:1526668118613};\\\", \\\"{x:1528,y:942,t:1526668118759};\\\", \\\"{x:1534,y:939,t:1526668118767};\\\", \\\"{x:1538,y:937,t:1526668118781};\\\", \\\"{x:1554,y:916,t:1526668118799};\\\", \\\"{x:1559,y:907,t:1526668118814};\\\", \\\"{x:1575,y:869,t:1526668118831};\\\", \\\"{x:1589,y:831,t:1526668118848};\\\", \\\"{x:1601,y:781,t:1526668118864};\\\", \\\"{x:1614,y:711,t:1526668118881};\\\", \\\"{x:1622,y:639,t:1526668118897};\\\", \\\"{x:1634,y:582,t:1526668118913};\\\", \\\"{x:1656,y:519,t:1526668118930};\\\", \\\"{x:1671,y:486,t:1526668118948};\\\", \\\"{x:1684,y:462,t:1526668118963};\\\", \\\"{x:1689,y:446,t:1526668118980};\\\", \\\"{x:1692,y:436,t:1526668118998};\\\", \\\"{x:1692,y:435,t:1526668119014};\\\", \\\"{x:1690,y:435,t:1526668119143};\\\", \\\"{x:1688,y:435,t:1526668119150};\\\", \\\"{x:1687,y:436,t:1526668119163};\\\", \\\"{x:1683,y:437,t:1526668119181};\\\", \\\"{x:1679,y:440,t:1526668119198};\\\", \\\"{x:1677,y:441,t:1526668119215};\\\", \\\"{x:1675,y:443,t:1526668119230};\\\", \\\"{x:1674,y:448,t:1526668119248};\\\", \\\"{x:1674,y:455,t:1526668119265};\\\", \\\"{x:1673,y:465,t:1526668119281};\\\", \\\"{x:1671,y:478,t:1526668119298};\\\", \\\"{x:1670,y:493,t:1526668119315};\\\", \\\"{x:1668,y:511,t:1526668119331};\\\", \\\"{x:1665,y:533,t:1526668119348};\\\", \\\"{x:1658,y:556,t:1526668119365};\\\", \\\"{x:1653,y:580,t:1526668119381};\\\", \\\"{x:1639,y:621,t:1526668119398};\\\", \\\"{x:1631,y:647,t:1526668119414};\\\", \\\"{x:1621,y:678,t:1526668119431};\\\", \\\"{x:1611,y:702,t:1526668119448};\\\", \\\"{x:1601,y:724,t:1526668119465};\\\", \\\"{x:1590,y:746,t:1526668119481};\\\", \\\"{x:1578,y:767,t:1526668119498};\\\", \\\"{x:1566,y:789,t:1526668119515};\\\", \\\"{x:1550,y:811,t:1526668119530};\\\", \\\"{x:1533,y:830,t:1526668119548};\\\", \\\"{x:1519,y:846,t:1526668119566};\\\", \\\"{x:1505,y:859,t:1526668119581};\\\", \\\"{x:1486,y:880,t:1526668119598};\\\", \\\"{x:1479,y:885,t:1526668119614};\\\", \\\"{x:1470,y:893,t:1526668119631};\\\", \\\"{x:1465,y:901,t:1526668119648};\\\", \\\"{x:1458,y:912,t:1526668119665};\\\", \\\"{x:1451,y:922,t:1526668119682};\\\", \\\"{x:1445,y:936,t:1526668119698};\\\", \\\"{x:1437,y:955,t:1526668119715};\\\", \\\"{x:1427,y:976,t:1526668119732};\\\", \\\"{x:1410,y:1005,t:1526668119748};\\\", \\\"{x:1397,y:1028,t:1526668119765};\\\", \\\"{x:1382,y:1058,t:1526668119782};\\\", \\\"{x:1377,y:1074,t:1526668119798};\\\", \\\"{x:1372,y:1086,t:1526668119814};\\\", \\\"{x:1370,y:1095,t:1526668119832};\\\", \\\"{x:1368,y:1099,t:1526668119847};\\\", \\\"{x:1368,y:1098,t:1526668119934};\\\", \\\"{x:1370,y:1097,t:1526668119947};\\\", \\\"{x:1376,y:1092,t:1526668119964};\\\", \\\"{x:1386,y:1079,t:1526668119981};\\\", \\\"{x:1393,y:1067,t:1526668119998};\\\", \\\"{x:1402,y:1056,t:1526668120015};\\\", \\\"{x:1413,y:1040,t:1526668120032};\\\", \\\"{x:1427,y:1019,t:1526668120048};\\\", \\\"{x:1441,y:995,t:1526668120064};\\\", \\\"{x:1456,y:966,t:1526668120082};\\\", \\\"{x:1475,y:931,t:1526668120098};\\\", \\\"{x:1489,y:908,t:1526668120116};\\\", \\\"{x:1504,y:888,t:1526668120132};\\\", \\\"{x:1519,y:866,t:1526668120149};\\\", \\\"{x:1529,y:851,t:1526668120164};\\\", \\\"{x:1542,y:834,t:1526668120182};\\\", \\\"{x:1549,y:825,t:1526668120198};\\\", \\\"{x:1555,y:816,t:1526668120215};\\\", \\\"{x:1561,y:806,t:1526668120232};\\\", \\\"{x:1566,y:798,t:1526668120249};\\\", \\\"{x:1570,y:788,t:1526668120265};\\\", \\\"{x:1576,y:778,t:1526668120281};\\\", \\\"{x:1583,y:767,t:1526668120299};\\\", \\\"{x:1590,y:756,t:1526668120317};\\\", \\\"{x:1601,y:740,t:1526668120332};\\\", \\\"{x:1615,y:721,t:1526668120348};\\\", \\\"{x:1630,y:699,t:1526668120364};\\\", \\\"{x:1652,y:668,t:1526668120381};\\\", \\\"{x:1662,y:648,t:1526668120398};\\\", \\\"{x:1669,y:632,t:1526668120414};\\\", \\\"{x:1673,y:624,t:1526668120431};\\\", \\\"{x:1675,y:619,t:1526668120448};\\\", \\\"{x:1676,y:617,t:1526668120464};\\\", \\\"{x:1676,y:615,t:1526668120481};\\\", \\\"{x:1676,y:614,t:1526668120623};\\\", \\\"{x:1673,y:615,t:1526668120632};\\\", \\\"{x:1662,y:622,t:1526668120649};\\\", \\\"{x:1648,y:631,t:1526668120666};\\\", \\\"{x:1636,y:640,t:1526668120682};\\\", \\\"{x:1628,y:651,t:1526668120699};\\\", \\\"{x:1620,y:666,t:1526668120716};\\\", \\\"{x:1613,y:686,t:1526668120732};\\\", \\\"{x:1604,y:709,t:1526668120750};\\\", \\\"{x:1589,y:746,t:1526668120766};\\\", \\\"{x:1576,y:777,t:1526668120782};\\\", \\\"{x:1561,y:809,t:1526668120799};\\\", \\\"{x:1544,y:841,t:1526668120816};\\\", \\\"{x:1527,y:870,t:1526668120832};\\\", \\\"{x:1512,y:909,t:1526668120850};\\\", \\\"{x:1498,y:944,t:1526668120866};\\\", \\\"{x:1483,y:980,t:1526668120882};\\\", \\\"{x:1466,y:1019,t:1526668120899};\\\", \\\"{x:1453,y:1051,t:1526668120916};\\\", \\\"{x:1444,y:1075,t:1526668120932};\\\", \\\"{x:1439,y:1092,t:1526668120949};\\\", \\\"{x:1436,y:1109,t:1526668120966};\\\", \\\"{x:1436,y:1115,t:1526668120982};\\\", \\\"{x:1436,y:1116,t:1526668121054};\\\", \\\"{x:1438,y:1116,t:1526668121065};\\\", \\\"{x:1443,y:1116,t:1526668121083};\\\", \\\"{x:1454,y:1111,t:1526668121098};\\\", \\\"{x:1467,y:1106,t:1526668121115};\\\", \\\"{x:1479,y:1099,t:1526668121132};\\\", \\\"{x:1489,y:1092,t:1526668121149};\\\", \\\"{x:1506,y:1077,t:1526668121166};\\\", \\\"{x:1518,y:1064,t:1526668121182};\\\", \\\"{x:1527,y:1048,t:1526668121199};\\\", \\\"{x:1538,y:1029,t:1526668121216};\\\", \\\"{x:1546,y:1007,t:1526668121234};\\\", \\\"{x:1553,y:989,t:1526668121249};\\\", \\\"{x:1561,y:973,t:1526668121266};\\\", \\\"{x:1565,y:961,t:1526668121283};\\\", \\\"{x:1570,y:949,t:1526668121299};\\\", \\\"{x:1572,y:942,t:1526668121316};\\\", \\\"{x:1572,y:938,t:1526668121333};\\\", \\\"{x:1572,y:936,t:1526668121349};\\\", \\\"{x:1572,y:932,t:1526668121366};\\\", \\\"{x:1572,y:931,t:1526668121383};\\\", \\\"{x:1572,y:928,t:1526668121399};\\\", \\\"{x:1572,y:924,t:1526668121416};\\\", \\\"{x:1570,y:920,t:1526668121433};\\\", \\\"{x:1566,y:910,t:1526668121450};\\\", \\\"{x:1561,y:901,t:1526668121466};\\\", \\\"{x:1557,y:891,t:1526668121483};\\\", \\\"{x:1552,y:878,t:1526668121500};\\\", \\\"{x:1550,y:865,t:1526668121516};\\\", \\\"{x:1549,y:854,t:1526668121533};\\\", \\\"{x:1549,y:837,t:1526668121550};\\\", \\\"{x:1549,y:829,t:1526668121566};\\\", \\\"{x:1549,y:819,t:1526668121583};\\\", \\\"{x:1549,y:813,t:1526668121600};\\\", \\\"{x:1549,y:806,t:1526668121616};\\\", \\\"{x:1549,y:799,t:1526668121632};\\\", \\\"{x:1549,y:794,t:1526668121650};\\\", \\\"{x:1549,y:789,t:1526668121666};\\\", \\\"{x:1549,y:783,t:1526668121683};\\\", \\\"{x:1549,y:779,t:1526668121700};\\\", \\\"{x:1549,y:772,t:1526668121716};\\\", \\\"{x:1549,y:767,t:1526668121733};\\\", \\\"{x:1545,y:753,t:1526668121750};\\\", \\\"{x:1539,y:745,t:1526668121766};\\\", \\\"{x:1533,y:736,t:1526668121783};\\\", \\\"{x:1529,y:726,t:1526668121800};\\\", \\\"{x:1528,y:722,t:1526668121816};\\\", \\\"{x:1528,y:715,t:1526668121833};\\\", \\\"{x:1528,y:711,t:1526668121850};\\\", \\\"{x:1526,y:703,t:1526668121869};\\\", \\\"{x:1526,y:700,t:1526668121882};\\\", \\\"{x:1526,y:695,t:1526668121900};\\\", \\\"{x:1526,y:689,t:1526668121916};\\\", \\\"{x:1526,y:685,t:1526668121932};\\\", \\\"{x:1526,y:681,t:1526668121949};\\\", \\\"{x:1526,y:677,t:1526668121966};\\\", \\\"{x:1527,y:676,t:1526668121982};\\\", \\\"{x:1527,y:675,t:1526668122000};\\\", \\\"{x:1527,y:674,t:1526668122017};\\\", \\\"{x:1525,y:676,t:1526668122110};\\\", \\\"{x:1516,y:680,t:1526668122118};\\\", \\\"{x:1507,y:685,t:1526668122132};\\\", \\\"{x:1470,y:707,t:1526668122150};\\\", \\\"{x:1449,y:723,t:1526668122166};\\\", \\\"{x:1436,y:739,t:1526668122183};\\\", \\\"{x:1422,y:763,t:1526668122199};\\\", \\\"{x:1401,y:796,t:1526668122217};\\\", \\\"{x:1361,y:843,t:1526668122233};\\\", \\\"{x:1298,y:892,t:1526668122249};\\\", \\\"{x:1210,y:944,t:1526668122267};\\\", \\\"{x:1103,y:992,t:1526668122283};\\\", \\\"{x:1008,y:1024,t:1526668122299};\\\", \\\"{x:909,y:1045,t:1526668122316};\\\", \\\"{x:821,y:1057,t:1526668122332};\\\", \\\"{x:734,y:1057,t:1526668122349};\\\", \\\"{x:708,y:1052,t:1526668122366};\\\", \\\"{x:686,y:1039,t:1526668122384};\\\", \\\"{x:668,y:1025,t:1526668122399};\\\", \\\"{x:653,y:1007,t:1526668122416};\\\", \\\"{x:634,y:983,t:1526668122433};\\\", \\\"{x:610,y:957,t:1526668122449};\\\", \\\"{x:586,y:938,t:1526668122466};\\\", \\\"{x:567,y:926,t:1526668122484};\\\", \\\"{x:546,y:916,t:1526668122500};\\\", \\\"{x:513,y:901,t:1526668122516};\\\", \\\"{x:466,y:885,t:1526668122533};\\\", \\\"{x:460,y:881,t:1526668122549};\\\", \\\"{x:459,y:878,t:1526668122566};\\\", \\\"{x:459,y:871,t:1526668122584};\\\", \\\"{x:459,y:867,t:1526668122600};\\\", \\\"{x:459,y:860,t:1526668122617};\\\", \\\"{x:459,y:854,t:1526668122633};\\\", \\\"{x:459,y:848,t:1526668122650};\\\", \\\"{x:459,y:840,t:1526668122667};\\\", \\\"{x:459,y:824,t:1526668122683};\\\", \\\"{x:459,y:815,t:1526668122700};\\\", \\\"{x:459,y:809,t:1526668122717};\\\", \\\"{x:459,y:802,t:1526668122734};\\\", \\\"{x:459,y:800,t:1526668122750};\\\", \\\"{x:465,y:795,t:1526668122767};\\\", \\\"{x:474,y:789,t:1526668122784};\\\", \\\"{x:480,y:785,t:1526668122801};\\\", \\\"{x:492,y:776,t:1526668122816};\\\", \\\"{x:502,y:766,t:1526668122834};\\\", \\\"{x:510,y:756,t:1526668122851};\\\", \\\"{x:517,y:746,t:1526668122867};\\\", \\\"{x:524,y:738,t:1526668122883};\\\", \\\"{x:528,y:732,t:1526668122897};\\\", \\\"{x:530,y:729,t:1526668122913};\\\", \\\"{x:531,y:728,t:1526668122930};\\\", \\\"{x:531,y:727,t:1526668122947};\\\", \\\"{x:532,y:726,t:1526668123285};\\\" ] }, { \\\"rt\\\": 23372, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 379103, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-02 PM-X -X -X -02 PM-Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:726,t:1526668127102};\\\", \\\"{x:535,y:726,t:1526668128473};\\\", \\\"{x:542,y:723,t:1526668128481};\\\", \\\"{x:568,y:716,t:1526668128491};\\\", \\\"{x:687,y:682,t:1526668128508};\\\", \\\"{x:818,y:661,t:1526668128525};\\\", \\\"{x:932,y:655,t:1526668128541};\\\", \\\"{x:1032,y:655,t:1526668128559};\\\", \\\"{x:1126,y:655,t:1526668128576};\\\", \\\"{x:1218,y:655,t:1526668128592};\\\", \\\"{x:1303,y:660,t:1526668128608};\\\", \\\"{x:1433,y:698,t:1526668128625};\\\", \\\"{x:1493,y:722,t:1526668128643};\\\", \\\"{x:1531,y:744,t:1526668128658};\\\", \\\"{x:1560,y:763,t:1526668128676};\\\", \\\"{x:1582,y:782,t:1526668128692};\\\", \\\"{x:1611,y:811,t:1526668128709};\\\", \\\"{x:1650,y:853,t:1526668128726};\\\", \\\"{x:1688,y:900,t:1526668128742};\\\", \\\"{x:1711,y:932,t:1526668128759};\\\", \\\"{x:1727,y:958,t:1526668128775};\\\", \\\"{x:1733,y:970,t:1526668128792};\\\", \\\"{x:1734,y:976,t:1526668128809};\\\", \\\"{x:1734,y:983,t:1526668128825};\\\", \\\"{x:1734,y:985,t:1526668128843};\\\", \\\"{x:1734,y:986,t:1526668128859};\\\", \\\"{x:1733,y:987,t:1526668128875};\\\", \\\"{x:1733,y:988,t:1526668128892};\\\", \\\"{x:1732,y:989,t:1526668128908};\\\", \\\"{x:1730,y:991,t:1526668128926};\\\", \\\"{x:1727,y:995,t:1526668128943};\\\", \\\"{x:1723,y:998,t:1526668128958};\\\", \\\"{x:1720,y:1000,t:1526668128975};\\\", \\\"{x:1716,y:1004,t:1526668128993};\\\", \\\"{x:1711,y:1008,t:1526668129009};\\\", \\\"{x:1695,y:1016,t:1526668129026};\\\", \\\"{x:1681,y:1020,t:1526668129043};\\\", \\\"{x:1660,y:1024,t:1526668129058};\\\", \\\"{x:1637,y:1027,t:1526668129075};\\\", \\\"{x:1613,y:1028,t:1526668129092};\\\", \\\"{x:1588,y:1028,t:1526668129108};\\\", \\\"{x:1569,y:1028,t:1526668129125};\\\", \\\"{x:1552,y:1028,t:1526668129142};\\\", \\\"{x:1542,y:1028,t:1526668129159};\\\", \\\"{x:1537,y:1028,t:1526668129176};\\\", \\\"{x:1534,y:1028,t:1526668129193};\\\", \\\"{x:1533,y:1028,t:1526668129209};\\\", \\\"{x:1531,y:1028,t:1526668129290};\\\", \\\"{x:1530,y:1026,t:1526668129297};\\\", \\\"{x:1530,y:1025,t:1526668129309};\\\", \\\"{x:1528,y:1022,t:1526668129325};\\\", \\\"{x:1526,y:1020,t:1526668129343};\\\", \\\"{x:1525,y:1019,t:1526668129362};\\\", \\\"{x:1524,y:1019,t:1526668129442};\\\", \\\"{x:1521,y:1017,t:1526668129460};\\\", \\\"{x:1518,y:1016,t:1526668129476};\\\", \\\"{x:1515,y:1013,t:1526668129493};\\\", \\\"{x:1513,y:1013,t:1526668129509};\\\", \\\"{x:1511,y:1011,t:1526668129526};\\\", \\\"{x:1509,y:1010,t:1526668129543};\\\", \\\"{x:1506,y:1007,t:1526668129559};\\\", \\\"{x:1502,y:1005,t:1526668129576};\\\", \\\"{x:1497,y:1002,t:1526668129592};\\\", \\\"{x:1489,y:998,t:1526668129610};\\\", \\\"{x:1485,y:996,t:1526668129625};\\\", \\\"{x:1481,y:994,t:1526668129643};\\\", \\\"{x:1479,y:992,t:1526668129660};\\\", \\\"{x:1478,y:991,t:1526668129705};\\\", \\\"{x:1478,y:990,t:1526668129721};\\\", \\\"{x:1477,y:989,t:1526668129729};\\\", \\\"{x:1476,y:988,t:1526668129753};\\\", \\\"{x:1475,y:986,t:1526668129762};\\\", \\\"{x:1475,y:985,t:1526668129777};\\\", \\\"{x:1475,y:984,t:1526668129793};\\\", \\\"{x:1474,y:982,t:1526668129809};\\\", \\\"{x:1474,y:979,t:1526668129827};\\\", \\\"{x:1474,y:977,t:1526668129842};\\\", \\\"{x:1474,y:974,t:1526668129860};\\\", \\\"{x:1474,y:972,t:1526668129876};\\\", \\\"{x:1474,y:970,t:1526668129892};\\\", \\\"{x:1474,y:967,t:1526668129910};\\\", \\\"{x:1475,y:964,t:1526668129927};\\\", \\\"{x:1475,y:962,t:1526668129943};\\\", \\\"{x:1476,y:958,t:1526668129960};\\\", \\\"{x:1477,y:952,t:1526668129977};\\\", \\\"{x:1478,y:949,t:1526668129993};\\\", \\\"{x:1478,y:941,t:1526668130009};\\\", \\\"{x:1480,y:933,t:1526668130026};\\\", \\\"{x:1482,y:924,t:1526668130043};\\\", \\\"{x:1484,y:915,t:1526668130059};\\\", \\\"{x:1485,y:907,t:1526668130076};\\\", \\\"{x:1485,y:899,t:1526668130092};\\\", \\\"{x:1485,y:895,t:1526668130110};\\\", \\\"{x:1486,y:889,t:1526668130127};\\\", \\\"{x:1486,y:887,t:1526668130144};\\\", \\\"{x:1486,y:883,t:1526668130159};\\\", \\\"{x:1486,y:879,t:1526668130177};\\\", \\\"{x:1487,y:872,t:1526668130193};\\\", \\\"{x:1488,y:869,t:1526668130210};\\\", \\\"{x:1488,y:866,t:1526668130226};\\\", \\\"{x:1488,y:865,t:1526668130243};\\\", \\\"{x:1489,y:864,t:1526668130260};\\\", \\\"{x:1489,y:863,t:1526668130277};\\\", \\\"{x:1489,y:862,t:1526668130293};\\\", \\\"{x:1489,y:859,t:1526668130309};\\\", \\\"{x:1489,y:857,t:1526668130326};\\\", \\\"{x:1489,y:855,t:1526668130344};\\\", \\\"{x:1489,y:852,t:1526668130360};\\\", \\\"{x:1487,y:848,t:1526668130377};\\\", \\\"{x:1485,y:842,t:1526668130393};\\\", \\\"{x:1485,y:840,t:1526668130409};\\\", \\\"{x:1484,y:836,t:1526668130427};\\\", \\\"{x:1484,y:834,t:1526668130446};\\\", \\\"{x:1483,y:831,t:1526668130458};\\\", \\\"{x:1482,y:829,t:1526668130475};\\\", \\\"{x:1482,y:826,t:1526668130493};\\\", \\\"{x:1480,y:825,t:1526668130509};\\\", \\\"{x:1480,y:823,t:1526668130526};\\\", \\\"{x:1479,y:822,t:1526668130542};\\\", \\\"{x:1478,y:821,t:1526668130609};\\\", \\\"{x:1479,y:821,t:1526668131105};\\\", \\\"{x:1480,y:821,t:1526668131121};\\\", \\\"{x:1480,y:823,t:1526668131137};\\\", \\\"{x:1480,y:826,t:1526668131146};\\\", \\\"{x:1481,y:829,t:1526668131161};\\\", \\\"{x:1485,y:844,t:1526668131178};\\\", \\\"{x:1486,y:854,t:1526668131194};\\\", \\\"{x:1489,y:868,t:1526668131210};\\\", \\\"{x:1490,y:878,t:1526668131228};\\\", \\\"{x:1491,y:885,t:1526668131244};\\\", \\\"{x:1492,y:892,t:1526668131261};\\\", \\\"{x:1492,y:897,t:1526668131278};\\\", \\\"{x:1492,y:899,t:1526668131294};\\\", \\\"{x:1493,y:905,t:1526668131311};\\\", \\\"{x:1494,y:912,t:1526668131327};\\\", \\\"{x:1495,y:920,t:1526668131344};\\\", \\\"{x:1498,y:926,t:1526668131360};\\\", \\\"{x:1499,y:935,t:1526668131378};\\\", \\\"{x:1499,y:939,t:1526668131393};\\\", \\\"{x:1499,y:942,t:1526668131410};\\\", \\\"{x:1499,y:945,t:1526668131428};\\\", \\\"{x:1499,y:946,t:1526668131443};\\\", \\\"{x:1499,y:949,t:1526668131461};\\\", \\\"{x:1499,y:951,t:1526668131477};\\\", \\\"{x:1498,y:955,t:1526668131493};\\\", \\\"{x:1497,y:957,t:1526668131511};\\\", \\\"{x:1496,y:960,t:1526668131527};\\\", \\\"{x:1496,y:963,t:1526668131545};\\\", \\\"{x:1494,y:967,t:1526668131561};\\\", \\\"{x:1493,y:970,t:1526668131577};\\\", \\\"{x:1492,y:973,t:1526668131594};\\\", \\\"{x:1491,y:975,t:1526668131610};\\\", \\\"{x:1490,y:976,t:1526668131628};\\\", \\\"{x:1490,y:977,t:1526668131645};\\\", \\\"{x:1488,y:979,t:1526668131661};\\\", \\\"{x:1486,y:981,t:1526668131678};\\\", \\\"{x:1484,y:981,t:1526668131695};\\\", \\\"{x:1483,y:982,t:1526668131711};\\\", \\\"{x:1483,y:980,t:1526668131849};\\\", \\\"{x:1483,y:979,t:1526668131861};\\\", \\\"{x:1484,y:972,t:1526668131877};\\\", \\\"{x:1489,y:962,t:1526668131894};\\\", \\\"{x:1492,y:953,t:1526668131911};\\\", \\\"{x:1494,y:943,t:1526668131928};\\\", \\\"{x:1495,y:934,t:1526668131945};\\\", \\\"{x:1499,y:917,t:1526668131961};\\\", \\\"{x:1504,y:905,t:1526668131977};\\\", \\\"{x:1510,y:894,t:1526668131994};\\\", \\\"{x:1517,y:880,t:1526668132011};\\\", \\\"{x:1529,y:863,t:1526668132027};\\\", \\\"{x:1542,y:848,t:1526668132044};\\\", \\\"{x:1549,y:836,t:1526668132061};\\\", \\\"{x:1556,y:824,t:1526668132077};\\\", \\\"{x:1558,y:815,t:1526668132094};\\\", \\\"{x:1561,y:806,t:1526668132111};\\\", \\\"{x:1563,y:796,t:1526668132127};\\\", \\\"{x:1565,y:785,t:1526668132144};\\\", \\\"{x:1570,y:767,t:1526668132160};\\\", \\\"{x:1576,y:755,t:1526668132177};\\\", \\\"{x:1580,y:744,t:1526668132194};\\\", \\\"{x:1583,y:734,t:1526668132211};\\\", \\\"{x:1583,y:724,t:1526668132227};\\\", \\\"{x:1583,y:715,t:1526668132244};\\\", \\\"{x:1584,y:708,t:1526668132261};\\\", \\\"{x:1586,y:703,t:1526668132278};\\\", \\\"{x:1587,y:701,t:1526668132295};\\\", \\\"{x:1587,y:699,t:1526668132312};\\\", \\\"{x:1588,y:697,t:1526668132329};\\\", \\\"{x:1589,y:696,t:1526668132402};\\\", \\\"{x:1591,y:695,t:1526668132424};\\\", \\\"{x:1592,y:695,t:1526668132440};\\\", \\\"{x:1594,y:695,t:1526668132464};\\\", \\\"{x:1595,y:694,t:1526668132478};\\\", \\\"{x:1596,y:693,t:1526668132512};\\\", \\\"{x:1597,y:693,t:1526668132529};\\\", \\\"{x:1598,y:693,t:1526668132617};\\\", \\\"{x:1600,y:693,t:1526668132633};\\\", \\\"{x:1600,y:692,t:1526668132644};\\\", \\\"{x:1603,y:691,t:1526668133164};\\\", \\\"{x:1619,y:684,t:1526668133216};\\\", \\\"{x:1620,y:684,t:1526668133228};\\\", \\\"{x:1621,y:683,t:1526668133281};\\\", \\\"{x:1617,y:683,t:1526668134385};\\\", \\\"{x:1614,y:683,t:1526668134397};\\\", \\\"{x:1609,y:685,t:1526668134413};\\\", \\\"{x:1604,y:688,t:1526668134429};\\\", \\\"{x:1592,y:692,t:1526668134452};\\\", \\\"{x:1569,y:704,t:1526668134501};\\\", \\\"{x:1561,y:707,t:1526668134513};\\\", \\\"{x:1552,y:709,t:1526668134529};\\\", \\\"{x:1538,y:712,t:1526668134546};\\\", \\\"{x:1520,y:714,t:1526668134563};\\\", \\\"{x:1500,y:715,t:1526668134579};\\\", \\\"{x:1478,y:715,t:1526668134596};\\\", \\\"{x:1451,y:718,t:1526668134613};\\\", \\\"{x:1421,y:718,t:1526668134629};\\\", \\\"{x:1389,y:718,t:1526668134647};\\\", \\\"{x:1360,y:718,t:1526668134663};\\\", \\\"{x:1339,y:718,t:1526668134679};\\\", \\\"{x:1323,y:717,t:1526668134697};\\\", \\\"{x:1318,y:714,t:1526668134712};\\\", \\\"{x:1312,y:713,t:1526668134729};\\\", \\\"{x:1306,y:710,t:1526668134746};\\\", \\\"{x:1302,y:709,t:1526668134763};\\\", \\\"{x:1300,y:709,t:1526668134780};\\\", \\\"{x:1299,y:709,t:1526668134849};\\\", \\\"{x:1299,y:708,t:1526668134873};\\\", \\\"{x:1300,y:706,t:1526668135761};\\\", \\\"{x:1302,y:706,t:1526668135768};\\\", \\\"{x:1304,y:705,t:1526668135780};\\\", \\\"{x:1307,y:703,t:1526668135797};\\\", \\\"{x:1308,y:703,t:1526668135813};\\\", \\\"{x:1309,y:703,t:1526668135830};\\\", \\\"{x:1310,y:702,t:1526668135847};\\\", \\\"{x:1311,y:702,t:1526668135865};\\\", \\\"{x:1314,y:700,t:1526668135881};\\\", \\\"{x:1317,y:699,t:1526668135897};\\\", \\\"{x:1320,y:698,t:1526668135914};\\\", \\\"{x:1324,y:696,t:1526668135930};\\\", \\\"{x:1329,y:694,t:1526668135948};\\\", \\\"{x:1336,y:691,t:1526668135964};\\\", \\\"{x:1344,y:687,t:1526668135980};\\\", \\\"{x:1349,y:686,t:1526668135997};\\\", \\\"{x:1360,y:682,t:1526668136014};\\\", \\\"{x:1373,y:682,t:1526668136030};\\\", \\\"{x:1391,y:682,t:1526668136047};\\\", \\\"{x:1412,y:682,t:1526668136064};\\\", \\\"{x:1423,y:682,t:1526668136081};\\\", \\\"{x:1438,y:682,t:1526668136098};\\\", \\\"{x:1454,y:685,t:1526668136114};\\\", \\\"{x:1468,y:692,t:1526668136131};\\\", \\\"{x:1487,y:700,t:1526668136148};\\\", \\\"{x:1509,y:713,t:1526668136164};\\\", \\\"{x:1540,y:731,t:1526668136180};\\\", \\\"{x:1564,y:749,t:1526668136197};\\\", \\\"{x:1585,y:763,t:1526668136215};\\\", \\\"{x:1600,y:776,t:1526668136230};\\\", \\\"{x:1609,y:785,t:1526668136247};\\\", \\\"{x:1615,y:794,t:1526668136265};\\\", \\\"{x:1616,y:797,t:1526668136281};\\\", \\\"{x:1617,y:798,t:1526668136297};\\\", \\\"{x:1617,y:800,t:1526668136315};\\\", \\\"{x:1617,y:801,t:1526668136330};\\\", \\\"{x:1617,y:804,t:1526668136347};\\\", \\\"{x:1617,y:806,t:1526668136365};\\\", \\\"{x:1617,y:807,t:1526668136381};\\\", \\\"{x:1617,y:810,t:1526668136397};\\\", \\\"{x:1617,y:811,t:1526668136415};\\\", \\\"{x:1617,y:812,t:1526668136432};\\\", \\\"{x:1617,y:815,t:1526668136682};\\\", \\\"{x:1612,y:818,t:1526668136698};\\\", \\\"{x:1606,y:826,t:1526668136715};\\\", \\\"{x:1600,y:834,t:1526668136732};\\\", \\\"{x:1592,y:846,t:1526668136748};\\\", \\\"{x:1584,y:859,t:1526668136765};\\\", \\\"{x:1574,y:873,t:1526668136782};\\\", \\\"{x:1562,y:891,t:1526668136798};\\\", \\\"{x:1550,y:906,t:1526668136815};\\\", \\\"{x:1537,y:923,t:1526668136832};\\\", \\\"{x:1521,y:943,t:1526668136849};\\\", \\\"{x:1512,y:954,t:1526668136866};\\\", \\\"{x:1505,y:961,t:1526668136881};\\\", \\\"{x:1499,y:967,t:1526668136899};\\\", \\\"{x:1494,y:972,t:1526668136915};\\\", \\\"{x:1491,y:976,t:1526668136931};\\\", \\\"{x:1490,y:978,t:1526668136949};\\\", \\\"{x:1489,y:978,t:1526668138368};\\\", \\\"{x:1488,y:978,t:1526668143914};\\\", \\\"{x:1463,y:976,t:1526668143921};\\\", \\\"{x:1336,y:959,t:1526668143938};\\\", \\\"{x:1169,y:922,t:1526668143954};\\\", \\\"{x:989,y:869,t:1526668143971};\\\", \\\"{x:832,y:834,t:1526668143987};\\\", \\\"{x:697,y:793,t:1526668144003};\\\", \\\"{x:589,y:763,t:1526668144021};\\\", \\\"{x:501,y:727,t:1526668144037};\\\", \\\"{x:441,y:694,t:1526668144054};\\\", \\\"{x:408,y:667,t:1526668144073};\\\", \\\"{x:389,y:645,t:1526668144088};\\\", \\\"{x:379,y:627,t:1526668144104};\\\", \\\"{x:375,y:595,t:1526668144120};\\\", \\\"{x:375,y:573,t:1526668144138};\\\", \\\"{x:378,y:551,t:1526668144154};\\\", \\\"{x:386,y:529,t:1526668144172};\\\", \\\"{x:396,y:510,t:1526668144188};\\\", \\\"{x:406,y:493,t:1526668144204};\\\", \\\"{x:416,y:482,t:1526668144221};\\\", \\\"{x:427,y:474,t:1526668144237};\\\", \\\"{x:447,y:466,t:1526668144254};\\\", \\\"{x:465,y:458,t:1526668144271};\\\", \\\"{x:483,y:458,t:1526668144287};\\\", \\\"{x:497,y:458,t:1526668144303};\\\", \\\"{x:506,y:459,t:1526668144320};\\\", \\\"{x:513,y:463,t:1526668144338};\\\", \\\"{x:529,y:474,t:1526668144354};\\\", \\\"{x:544,y:490,t:1526668144371};\\\", \\\"{x:563,y:513,t:1526668144388};\\\", \\\"{x:592,y:542,t:1526668144405};\\\", \\\"{x:626,y:570,t:1526668144421};\\\", \\\"{x:650,y:590,t:1526668144438};\\\", \\\"{x:662,y:598,t:1526668144454};\\\", \\\"{x:669,y:599,t:1526668144470};\\\", \\\"{x:677,y:599,t:1526668144488};\\\", \\\"{x:682,y:598,t:1526668144504};\\\", \\\"{x:685,y:597,t:1526668144520};\\\", \\\"{x:687,y:595,t:1526668144538};\\\", \\\"{x:693,y:592,t:1526668144554};\\\", \\\"{x:700,y:588,t:1526668144571};\\\", \\\"{x:703,y:587,t:1526668144588};\\\", \\\"{x:705,y:586,t:1526668144604};\\\", \\\"{x:706,y:586,t:1526668144625};\\\", \\\"{x:707,y:586,t:1526668144638};\\\", \\\"{x:721,y:590,t:1526668144654};\\\", \\\"{x:746,y:605,t:1526668144673};\\\", \\\"{x:764,y:617,t:1526668144688};\\\", \\\"{x:785,y:633,t:1526668144705};\\\", \\\"{x:800,y:647,t:1526668144722};\\\", \\\"{x:821,y:662,t:1526668144737};\\\", \\\"{x:834,y:675,t:1526668144754};\\\", \\\"{x:843,y:684,t:1526668144771};\\\", \\\"{x:846,y:687,t:1526668144787};\\\", \\\"{x:847,y:688,t:1526668144805};\\\", \\\"{x:849,y:688,t:1526668144821};\\\", \\\"{x:851,y:688,t:1526668144838};\\\", \\\"{x:853,y:688,t:1526668144855};\\\", \\\"{x:855,y:687,t:1526668144870};\\\", \\\"{x:856,y:686,t:1526668144887};\\\", \\\"{x:859,y:684,t:1526668144905};\\\", \\\"{x:862,y:682,t:1526668144920};\\\", \\\"{x:863,y:680,t:1526668144937};\\\", \\\"{x:864,y:679,t:1526668144961};\\\", \\\"{x:864,y:677,t:1526668144977};\\\", \\\"{x:864,y:676,t:1526668144988};\\\", \\\"{x:864,y:674,t:1526668145005};\\\", \\\"{x:864,y:670,t:1526668145021};\\\", \\\"{x:864,y:667,t:1526668145038};\\\", \\\"{x:864,y:661,t:1526668145055};\\\", \\\"{x:864,y:655,t:1526668145071};\\\", \\\"{x:864,y:650,t:1526668145088};\\\", \\\"{x:864,y:646,t:1526668145104};\\\", \\\"{x:864,y:644,t:1526668145122};\\\", \\\"{x:864,y:643,t:1526668145297};\\\", \\\"{x:864,y:642,t:1526668145361};\\\", \\\"{x:864,y:641,t:1526668145368};\\\", \\\"{x:864,y:641,t:1526668145372};\\\", \\\"{x:864,y:638,t:1526668145388};\\\", \\\"{x:864,y:636,t:1526668145406};\\\", \\\"{x:864,y:631,t:1526668145421};\\\", \\\"{x:864,y:626,t:1526668145438};\\\", \\\"{x:864,y:621,t:1526668145455};\\\", \\\"{x:864,y:616,t:1526668145472};\\\", \\\"{x:860,y:603,t:1526668145488};\\\", \\\"{x:857,y:594,t:1526668145504};\\\", \\\"{x:855,y:578,t:1526668145522};\\\", \\\"{x:852,y:560,t:1526668145539};\\\", \\\"{x:850,y:540,t:1526668145554};\\\", \\\"{x:847,y:523,t:1526668145572};\\\", \\\"{x:845,y:511,t:1526668145588};\\\", \\\"{x:844,y:505,t:1526668145604};\\\", \\\"{x:844,y:503,t:1526668145621};\\\", \\\"{x:843,y:503,t:1526668145968};\\\", \\\"{x:841,y:510,t:1526668145976};\\\", \\\"{x:841,y:517,t:1526668145989};\\\", \\\"{x:841,y:532,t:1526668146006};\\\", \\\"{x:841,y:547,t:1526668146022};\\\", \\\"{x:840,y:561,t:1526668146038};\\\", \\\"{x:838,y:570,t:1526668146056};\\\", \\\"{x:838,y:581,t:1526668146072};\\\", \\\"{x:838,y:605,t:1526668146089};\\\", \\\"{x:838,y:624,t:1526668146107};\\\", \\\"{x:838,y:633,t:1526668146122};\\\", \\\"{x:838,y:635,t:1526668146139};\\\", \\\"{x:838,y:636,t:1526668146156};\\\", \\\"{x:838,y:637,t:1526668146256};\\\", \\\"{x:838,y:632,t:1526668146528};\\\", \\\"{x:838,y:623,t:1526668146538};\\\", \\\"{x:839,y:603,t:1526668146556};\\\", \\\"{x:840,y:584,t:1526668146572};\\\", \\\"{x:844,y:564,t:1526668146589};\\\", \\\"{x:844,y:543,t:1526668146606};\\\", \\\"{x:844,y:528,t:1526668146623};\\\", \\\"{x:843,y:518,t:1526668146639};\\\", \\\"{x:843,y:511,t:1526668146656};\\\", \\\"{x:842,y:510,t:1526668146761};\\\", \\\"{x:841,y:510,t:1526668146772};\\\", \\\"{x:840,y:510,t:1526668146790};\\\", \\\"{x:839,y:510,t:1526668146809};\\\", \\\"{x:834,y:514,t:1526668147048};\\\", \\\"{x:826,y:519,t:1526668147056};\\\", \\\"{x:813,y:538,t:1526668147073};\\\", \\\"{x:789,y:571,t:1526668147090};\\\", \\\"{x:754,y:615,t:1526668147107};\\\", \\\"{x:709,y:664,t:1526668147124};\\\", \\\"{x:660,y:725,t:1526668147139};\\\", \\\"{x:602,y:788,t:1526668147157};\\\", \\\"{x:554,y:841,t:1526668147172};\\\", \\\"{x:516,y:873,t:1526668147190};\\\", \\\"{x:493,y:889,t:1526668147207};\\\", \\\"{x:484,y:893,t:1526668147222};\\\", \\\"{x:482,y:893,t:1526668147272};\\\", \\\"{x:481,y:893,t:1526668147296};\\\", \\\"{x:481,y:891,t:1526668147307};\\\", \\\"{x:481,y:886,t:1526668147323};\\\", \\\"{x:480,y:881,t:1526668147340};\\\", \\\"{x:480,y:872,t:1526668147358};\\\", \\\"{x:478,y:865,t:1526668147373};\\\", \\\"{x:478,y:855,t:1526668147390};\\\", \\\"{x:478,y:851,t:1526668147407};\\\", \\\"{x:478,y:844,t:1526668147423};\\\", \\\"{x:478,y:837,t:1526668147441};\\\", \\\"{x:478,y:823,t:1526668147456};\\\", \\\"{x:479,y:813,t:1526668147473};\\\", \\\"{x:482,y:801,t:1526668147490};\\\", \\\"{x:483,y:794,t:1526668147507};\\\", \\\"{x:486,y:787,t:1526668147523};\\\", \\\"{x:491,y:777,t:1526668147540};\\\", \\\"{x:496,y:769,t:1526668147557};\\\", \\\"{x:500,y:763,t:1526668147575};\\\", \\\"{x:503,y:758,t:1526668147589};\\\", \\\"{x:504,y:756,t:1526668147607};\\\", \\\"{x:505,y:754,t:1526668147623};\\\", \\\"{x:506,y:753,t:1526668147649};\\\", \\\"{x:507,y:753,t:1526668147752};\\\", \\\"{x:507,y:753,t:1526668147839};\\\", \\\"{x:505,y:753,t:1526668148545};\\\", \\\"{x:504,y:754,t:1526668148585};\\\", \\\"{x:503,y:754,t:1526668148657};\\\", \\\"{x:504,y:754,t:1526668149865};\\\", \\\"{x:513,y:752,t:1526668149875};\\\", \\\"{x:536,y:742,t:1526668149892};\\\", \\\"{x:562,y:729,t:1526668149909};\\\", \\\"{x:590,y:717,t:1526668149925};\\\", \\\"{x:619,y:704,t:1526668149942};\\\", \\\"{x:642,y:695,t:1526668149959};\\\", \\\"{x:662,y:686,t:1526668149975};\\\", \\\"{x:682,y:680,t:1526668149992};\\\", \\\"{x:711,y:671,t:1526668150009};\\\", \\\"{x:731,y:666,t:1526668150025};\\\", \\\"{x:745,y:662,t:1526668150042};\\\", \\\"{x:760,y:657,t:1526668150059};\\\", \\\"{x:773,y:653,t:1526668150076};\\\", \\\"{x:783,y:649,t:1526668150092};\\\", \\\"{x:790,y:647,t:1526668150109};\\\", \\\"{x:794,y:645,t:1526668150125};\\\", \\\"{x:797,y:642,t:1526668150142};\\\", \\\"{x:799,y:641,t:1526668150159};\\\", \\\"{x:802,y:640,t:1526668150176};\\\", \\\"{x:806,y:635,t:1526668150192};\\\", \\\"{x:814,y:626,t:1526668150210};\\\", \\\"{x:822,y:614,t:1526668150226};\\\", \\\"{x:835,y:596,t:1526668150243};\\\", \\\"{x:855,y:576,t:1526668150260};\\\", \\\"{x:881,y:552,t:1526668150276};\\\", \\\"{x:914,y:525,t:1526668150292};\\\", \\\"{x:940,y:506,t:1526668150309};\\\", \\\"{x:955,y:493,t:1526668150326};\\\", \\\"{x:959,y:491,t:1526668150342};\\\", \\\"{x:959,y:490,t:1526668150359};\\\", \\\"{x:959,y:494,t:1526668150465};\\\", \\\"{x:959,y:498,t:1526668150476};\\\", \\\"{x:959,y:509,t:1526668150493};\\\", \\\"{x:957,y:522,t:1526668150510};\\\", \\\"{x:953,y:536,t:1526668150527};\\\", \\\"{x:948,y:555,t:1526668150544};\\\", \\\"{x:946,y:569,t:1526668150559};\\\", \\\"{x:943,y:578,t:1526668150576};\\\", \\\"{x:942,y:583,t:1526668150592};\\\", \\\"{x:941,y:586,t:1526668150608};\\\", \\\"{x:941,y:587,t:1526668150626};\\\", \\\"{x:943,y:586,t:1526668150874};\\\", \\\"{x:946,y:585,t:1526668150881};\\\", \\\"{x:947,y:583,t:1526668150893};\\\", \\\"{x:950,y:582,t:1526668150909};\\\", \\\"{x:951,y:581,t:1526668150926};\\\", \\\"{x:953,y:580,t:1526668150943};\\\", \\\"{x:953,y:579,t:1526668151273};\\\", \\\"{x:954,y:579,t:1526668151281};\\\", \\\"{x:957,y:577,t:1526668151293};\\\", \\\"{x:959,y:576,t:1526668151310};\\\", \\\"{x:961,y:574,t:1526668151327};\\\", \\\"{x:962,y:573,t:1526668151343};\\\", \\\"{x:962,y:572,t:1526668151361};\\\", \\\"{x:963,y:571,t:1526668151376};\\\", \\\"{x:961,y:570,t:1526668151873};\\\", \\\"{x:955,y:570,t:1526668153137};\\\", \\\"{x:945,y:573,t:1526668153145};\\\", \\\"{x:932,y:579,t:1526668153162};\\\", \\\"{x:930,y:581,t:1526668153178};\\\", \\\"{x:932,y:590,t:1526668153195};\\\", \\\"{x:949,y:601,t:1526668153211};\\\", \\\"{x:962,y:609,t:1526668153228};\\\", \\\"{x:973,y:617,t:1526668153245};\\\", \\\"{x:980,y:619,t:1526668153261};\\\", \\\"{x:984,y:622,t:1526668153278};\\\", \\\"{x:987,y:623,t:1526668153295};\\\", \\\"{x:988,y:624,t:1526668153311};\\\", \\\"{x:990,y:627,t:1526668153410};\\\", \\\"{x:991,y:629,t:1526668153417};\\\", \\\"{x:992,y:632,t:1526668153428};\\\", \\\"{x:995,y:638,t:1526668153445};\\\", \\\"{x:996,y:643,t:1526668153461};\\\", \\\"{x:998,y:646,t:1526668153478};\\\", \\\"{x:999,y:647,t:1526668153496};\\\", \\\"{x:1000,y:649,t:1526668153513};\\\", \\\"{x:1001,y:649,t:1526668153562};\\\", \\\"{x:1001,y:650,t:1526668158001};\\\", \\\"{x:1001,y:654,t:1526668158015};\\\", \\\"{x:1006,y:665,t:1526668158033};\\\", \\\"{x:1006,y:670,t:1526668158050};\\\", \\\"{x:1006,y:674,t:1526668158065};\\\", \\\"{x:1006,y:680,t:1526668158083};\\\", \\\"{x:1005,y:683,t:1526668158098};\\\", \\\"{x:1003,y:687,t:1526668158115};\\\", \\\"{x:1003,y:688,t:1526668158132};\\\", \\\"{x:1002,y:688,t:1526668158148};\\\", \\\"{x:1002,y:689,t:1526668158176};\\\", \\\"{x:1000,y:689,t:1526668158224};\\\", \\\"{x:997,y:691,t:1526668158257};\\\", \\\"{x:996,y:692,t:1526668158266};\\\", \\\"{x:991,y:694,t:1526668158283};\\\", \\\"{x:990,y:695,t:1526668158299};\\\", \\\"{x:989,y:697,t:1526668158315};\\\", \\\"{x:987,y:698,t:1526668158332};\\\", \\\"{x:987,y:699,t:1526668158348};\\\", \\\"{x:987,y:703,t:1526668159177};\\\", \\\"{x:987,y:707,t:1526668159185};\\\", \\\"{x:987,y:710,t:1526668159200};\\\", \\\"{x:987,y:727,t:1526668159216};\\\", \\\"{x:987,y:738,t:1526668159232};\\\", \\\"{x:987,y:754,t:1526668159249};\\\", \\\"{x:987,y:770,t:1526668159266};\\\", \\\"{x:987,y:781,t:1526668159282};\\\", \\\"{x:987,y:791,t:1526668159300};\\\", \\\"{x:989,y:799,t:1526668159317};\\\", \\\"{x:989,y:813,t:1526668159333};\\\", \\\"{x:990,y:823,t:1526668159349};\\\", \\\"{x:991,y:828,t:1526668159367};\\\", \\\"{x:991,y:835,t:1526668159383};\\\", \\\"{x:991,y:841,t:1526668159399};\\\", \\\"{x:994,y:850,t:1526668159416};\\\", \\\"{x:995,y:854,t:1526668159433};\\\", \\\"{x:997,y:858,t:1526668159449};\\\", \\\"{x:997,y:861,t:1526668159466};\\\", \\\"{x:998,y:862,t:1526668159483};\\\", \\\"{x:998,y:864,t:1526668159504};\\\", \\\"{x:999,y:865,t:1526668164401};\\\", \\\"{x:1033,y:834,t:1526668164409};\\\", \\\"{x:1114,y:702,t:1526668164420};\\\", \\\"{x:1223,y:335,t:1526668164436};\\\", \\\"{x:1354,y:0,t:1526668164453};\\\", \\\"{x:1539,y:0,t:1526668164470};\\\", \\\"{x:1706,y:0,t:1526668164485};\\\", \\\"{x:1691,y:0,t:1526668164503};\\\", \\\"{x:1546,y:0,t:1526668164520};\\\", \\\"{x:1332,y:0,t:1526668164536};\\\", \\\"{x:1110,y:0,t:1526668164553};\\\", \\\"{x:1023,y:0,t:1526668164570};\\\", \\\"{x:965,y:0,t:1526668164586};\\\", \\\"{x:948,y:0,t:1526668164603};\\\", \\\"{x:944,y:0,t:1526668164620};\\\", \\\"{x:940,y:2,t:1526668164637};\\\", \\\"{x:939,y:2,t:1526668164653};\\\", \\\"{x:938,y:2,t:1526668164669};\\\", \\\"{x:938,y:8,t:1526668164687};\\\", \\\"{x:937,y:57,t:1526668164703};\\\", \\\"{x:930,y:123,t:1526668164719};\\\", \\\"{x:898,y:268,t:1526668164737};\\\", \\\"{x:887,y:362,t:1526668164752};\\\", \\\"{x:876,y:435,t:1526668164770};\\\", \\\"{x:864,y:497,t:1526668164804};\\\", \\\"{x:862,y:501,t:1526668164820};\\\", \\\"{x:862,y:498,t:1526668164896};\\\", \\\"{x:860,y:492,t:1526668164904};\\\", \\\"{x:857,y:483,t:1526668164920};\\\", \\\"{x:855,y:473,t:1526668164937};\\\", \\\"{x:855,y:461,t:1526668164954};\\\", \\\"{x:855,y:443,t:1526668164971};\\\", \\\"{x:864,y:423,t:1526668164988};\\\", \\\"{x:870,y:399,t:1526668165004};\\\", \\\"{x:877,y:374,t:1526668165022};\\\", \\\"{x:885,y:349,t:1526668165038};\\\", \\\"{x:891,y:328,t:1526668165054};\\\", \\\"{x:893,y:307,t:1526668165071};\\\", \\\"{x:893,y:288,t:1526668165087};\\\", \\\"{x:892,y:270,t:1526668165103};\\\", \\\"{x:892,y:266,t:1526668165120};\\\", \\\"{x:892,y:265,t:1526668165138};\\\", \\\"{x:891,y:264,t:1526668165160};\\\", \\\"{x:888,y:262,t:1526668165176};\\\", \\\"{x:882,y:262,t:1526668165187};\\\", \\\"{x:874,y:262,t:1526668165204};\\\", \\\"{x:870,y:262,t:1526668165220};\\\", \\\"{x:868,y:263,t:1526668165237};\\\", \\\"{x:867,y:263,t:1526668165255};\\\", \\\"{x:866,y:264,t:1526668165270};\\\", \\\"{x:865,y:264,t:1526668165288};\\\", \\\"{x:864,y:264,t:1526668165449};\\\", \\\"{x:865,y:262,t:1526668165456};\\\", \\\"{x:867,y:259,t:1526668165472};\\\", \\\"{x:870,y:254,t:1526668165488};\\\", \\\"{x:874,y:247,t:1526668165504};\\\", \\\"{x:877,y:245,t:1526668165521};\\\", \\\"{x:877,y:243,t:1526668165538};\\\", \\\"{x:878,y:242,t:1526668165555};\\\", \\\"{x:878,y:240,t:1526668165705};\\\", \\\"{x:879,y:239,t:1526668165721};\\\", \\\"{x:880,y:239,t:1526668165738};\\\", \\\"{x:883,y:237,t:1526668165755};\\\", \\\"{x:885,y:236,t:1526668165772};\\\", \\\"{x:886,y:235,t:1526668165788};\\\", \\\"{x:888,y:235,t:1526668165805};\\\", \\\"{x:889,y:233,t:1526668165822};\\\", \\\"{x:890,y:233,t:1526668165838};\\\", \\\"{x:890,y:234,t:1526668166472};\\\", \\\"{x:893,y:239,t:1526668166488};\\\", \\\"{x:894,y:247,t:1526668166506};\\\", \\\"{x:897,y:258,t:1526668166521};\\\", \\\"{x:902,y:268,t:1526668166539};\\\", \\\"{x:906,y:276,t:1526668166556};\\\", \\\"{x:908,y:284,t:1526668166573};\\\", \\\"{x:912,y:291,t:1526668166589};\\\", \\\"{x:912,y:294,t:1526668166605};\\\", \\\"{x:913,y:298,t:1526668166621};\\\", \\\"{x:914,y:299,t:1526668166638};\\\", \\\"{x:914,y:301,t:1526668166655};\\\", \\\"{x:915,y:303,t:1526668166672};\\\", \\\"{x:915,y:304,t:1526668166688};\\\", \\\"{x:916,y:306,t:1526668166706};\\\", \\\"{x:917,y:306,t:1526668166722};\\\", \\\"{x:917,y:307,t:1526668166739};\\\", \\\"{x:917,y:308,t:1526668166756};\\\", \\\"{x:917,y:309,t:1526668167506};\\\", \\\"{x:914,y:309,t:1526668167522};\\\", \\\"{x:910,y:309,t:1526668167539};\\\", \\\"{x:906,y:309,t:1526668167556};\\\", \\\"{x:903,y:309,t:1526668167572};\\\", \\\"{x:900,y:309,t:1526668167589};\\\", \\\"{x:898,y:308,t:1526668167606};\\\", \\\"{x:895,y:304,t:1526668167622};\\\", \\\"{x:895,y:301,t:1526668167638};\\\", \\\"{x:892,y:295,t:1526668167656};\\\", \\\"{x:892,y:290,t:1526668167673};\\\", \\\"{x:892,y:288,t:1526668167690};\\\", \\\"{x:892,y:284,t:1526668167708};\\\", \\\"{x:892,y:283,t:1526668167728};\\\", \\\"{x:892,y:282,t:1526668167740};\\\", \\\"{x:892,y:281,t:1526668167757};\\\", \\\"{x:892,y:280,t:1526668167777};\\\", \\\"{x:891,y:279,t:1526668167841};\\\", \\\"{x:887,y:279,t:1526668167857};\\\", \\\"{x:883,y:279,t:1526668167873};\\\", \\\"{x:880,y:282,t:1526668167891};\\\", \\\"{x:875,y:284,t:1526668167907};\\\", \\\"{x:872,y:287,t:1526668167923};\\\", \\\"{x:871,y:289,t:1526668167940};\\\", \\\"{x:871,y:292,t:1526668167957};\\\", \\\"{x:869,y:296,t:1526668167973};\\\", \\\"{x:867,y:303,t:1526668167990};\\\", \\\"{x:866,y:307,t:1526668168007};\\\", \\\"{x:865,y:311,t:1526668168024};\\\", \\\"{x:864,y:314,t:1526668168041};\\\", \\\"{x:863,y:315,t:1526668168056};\\\", \\\"{x:863,y:316,t:1526668168753};\\\", \\\"{x:863,y:317,t:1526668168801};\\\", \\\"{x:864,y:319,t:1526668168809};\\\", \\\"{x:864,y:320,t:1526668168824};\\\", \\\"{x:865,y:321,t:1526668168842};\\\", \\\"{x:865,y:322,t:1526668168858};\\\", \\\"{x:865,y:323,t:1526668168889};\\\", \\\"{x:866,y:324,t:1526668168897};\\\", \\\"{x:867,y:325,t:1526668168908};\\\", \\\"{x:868,y:331,t:1526668168923};\\\", \\\"{x:872,y:337,t:1526668168941};\\\", \\\"{x:875,y:344,t:1526668168958};\\\", \\\"{x:886,y:357,t:1526668168973};\\\", \\\"{x:891,y:366,t:1526668168991};\\\", \\\"{x:897,y:374,t:1526668169006};\\\", \\\"{x:904,y:384,t:1526668169024};\\\", \\\"{x:907,y:388,t:1526668169040};\\\", \\\"{x:909,y:391,t:1526668169057};\\\", \\\"{x:910,y:394,t:1526668169074};\\\", \\\"{x:911,y:396,t:1526668169091};\\\", \\\"{x:912,y:398,t:1526668169106};\\\", \\\"{x:912,y:401,t:1526668169124};\\\", \\\"{x:914,y:403,t:1526668169141};\\\", \\\"{x:914,y:404,t:1526668169157};\\\", \\\"{x:914,y:406,t:1526668169173};\\\", \\\"{x:914,y:407,t:1526668169191};\\\", \\\"{x:914,y:408,t:1526668169207};\\\", \\\"{x:914,y:409,t:1526668169224};\\\", \\\"{x:914,y:412,t:1526668169241};\\\", \\\"{x:913,y:413,t:1526668169258};\\\", \\\"{x:911,y:414,t:1526668169274};\\\", \\\"{x:910,y:416,t:1526668169313};\\\", \\\"{x:909,y:416,t:1526668169324};\\\", \\\"{x:908,y:416,t:1526668169401};\\\", \\\"{x:907,y:417,t:1526668169409};\\\", \\\"{x:905,y:417,t:1526668169424};\\\", \\\"{x:897,y:420,t:1526668169441};\\\", \\\"{x:892,y:421,t:1526668169458};\\\", \\\"{x:888,y:422,t:1526668169474};\\\", \\\"{x:885,y:423,t:1526668169491};\\\", \\\"{x:883,y:423,t:1526668169625};\\\", \\\"{x:882,y:423,t:1526668169665};\\\", \\\"{x:880,y:423,t:1526668169680};\\\", \\\"{x:878,y:423,t:1526668169691};\\\", \\\"{x:876,y:423,t:1526668169708};\\\", \\\"{x:873,y:421,t:1526668169724};\\\", \\\"{x:869,y:419,t:1526668169740};\\\", \\\"{x:866,y:416,t:1526668169758};\\\", \\\"{x:863,y:414,t:1526668169775};\\\", \\\"{x:861,y:412,t:1526668169793};\\\", \\\"{x:866,y:414,t:1526668170257};\\\", \\\"{x:876,y:420,t:1526668170265};\\\", \\\"{x:889,y:427,t:1526668170275};\\\", \\\"{x:921,y:444,t:1526668170292};\\\", \\\"{x:946,y:457,t:1526668170310};\\\", \\\"{x:970,y:468,t:1526668170325};\\\", \\\"{x:992,y:480,t:1526668170342};\\\", \\\"{x:1008,y:490,t:1526668170359};\\\", \\\"{x:1017,y:497,t:1526668170375};\\\", \\\"{x:1018,y:498,t:1526668170392};\\\", \\\"{x:1018,y:500,t:1526668170505};\\\", \\\"{x:1018,y:501,t:1526668170513};\\\", \\\"{x:1017,y:504,t:1526668170525};\\\", \\\"{x:1016,y:507,t:1526668170542};\\\", \\\"{x:1013,y:511,t:1526668170559};\\\", \\\"{x:1010,y:516,t:1526668170575};\\\", \\\"{x:1005,y:522,t:1526668170592};\\\", \\\"{x:1003,y:523,t:1526668170607};\\\", \\\"{x:1000,y:526,t:1526668170625};\\\", \\\"{x:997,y:529,t:1526668170641};\\\", \\\"{x:993,y:532,t:1526668170659};\\\", \\\"{x:989,y:536,t:1526668170674};\\\", \\\"{x:986,y:539,t:1526668170691};\\\", \\\"{x:984,y:541,t:1526668170709};\\\", \\\"{x:982,y:543,t:1526668170725};\\\", \\\"{x:980,y:547,t:1526668170741};\\\", \\\"{x:980,y:548,t:1526668170759};\\\", \\\"{x:980,y:549,t:1526668170775};\\\", \\\"{x:979,y:551,t:1526668170792};\\\", \\\"{x:977,y:553,t:1526668170809};\\\", \\\"{x:976,y:554,t:1526668170848};\\\", \\\"{x:976,y:555,t:1526668171921};\\\", \\\"{x:976,y:556,t:1526668171928};\\\", \\\"{x:976,y:557,t:1526668171945};\\\", \\\"{x:977,y:559,t:1526668171959};\\\", \\\"{x:978,y:560,t:1526668171976};\\\", \\\"{x:979,y:561,t:1526668171993};\\\", \\\"{x:979,y:563,t:1526668172017};\\\", \\\"{x:980,y:563,t:1526668172026};\\\", \\\"{x:980,y:564,t:1526668172043};\\\", \\\"{x:980,y:565,t:1526668172064};\\\", \\\"{x:981,y:566,t:1526668172081};\\\", \\\"{x:982,y:567,t:1526668172096};\\\", \\\"{x:983,y:570,t:1526668172110};\\\", \\\"{x:985,y:572,t:1526668172126};\\\", \\\"{x:988,y:575,t:1526668172143};\\\", \\\"{x:996,y:583,t:1526668172160};\\\", \\\"{x:1003,y:590,t:1526668172176};\\\", \\\"{x:1010,y:595,t:1526668172193};\\\", \\\"{x:1013,y:598,t:1526668172209};\\\", \\\"{x:1015,y:600,t:1526668172226};\\\", \\\"{x:1017,y:602,t:1526668172243};\\\", \\\"{x:1020,y:606,t:1526668172260};\\\", \\\"{x:1021,y:608,t:1526668172276};\\\", \\\"{x:1023,y:610,t:1526668172293};\\\", \\\"{x:1024,y:613,t:1526668172310};\\\", \\\"{x:1025,y:614,t:1526668172326};\\\", \\\"{x:1025,y:615,t:1526668172344};\\\", \\\"{x:1026,y:616,t:1526668172361};\\\", \\\"{x:1027,y:617,t:1526668172385};\\\", \\\"{x:1027,y:618,t:1526668172393};\\\", \\\"{x:1027,y:620,t:1526668172410};\\\", \\\"{x:1027,y:623,t:1526668172426};\\\", \\\"{x:1027,y:625,t:1526668172443};\\\", \\\"{x:1027,y:627,t:1526668172460};\\\", \\\"{x:1027,y:629,t:1526668172476};\\\", \\\"{x:1027,y:630,t:1526668172493};\\\", \\\"{x:1027,y:632,t:1526668172585};\\\", \\\"{x:1027,y:633,t:1526668172593};\\\", \\\"{x:1029,y:635,t:1526668172624};\\\", \\\"{x:1029,y:636,t:1526668172649};\\\", \\\"{x:1029,y:637,t:1526668172664};\\\", \\\"{x:1029,y:638,t:1526668172675};\\\", \\\"{x:1029,y:639,t:1526668172695};\\\", \\\"{x:1029,y:640,t:1526668172709};\\\", \\\"{x:1029,y:641,t:1526668172726};\\\", \\\"{x:1029,y:642,t:1526668172744};\\\", \\\"{x:1029,y:645,t:1526668173129};\\\", \\\"{x:1029,y:650,t:1526668173143};\\\", \\\"{x:1033,y:660,t:1526668173161};\\\", \\\"{x:1033,y:665,t:1526668173177};\\\", \\\"{x:1035,y:669,t:1526668173193};\\\", \\\"{x:1035,y:673,t:1526668173210};\\\", \\\"{x:1036,y:678,t:1526668173227};\\\", \\\"{x:1036,y:681,t:1526668173244};\\\", \\\"{x:1036,y:683,t:1526668173261};\\\", \\\"{x:1036,y:686,t:1526668173278};\\\", \\\"{x:1036,y:687,t:1526668173296};\\\", \\\"{x:1036,y:688,t:1526668173312};\\\", \\\"{x:1036,y:689,t:1526668173328};\\\", \\\"{x:1036,y:690,t:1526668173441};\\\", \\\"{x:1036,y:691,t:1526668173449};\\\", \\\"{x:1036,y:692,t:1526668173461};\\\", \\\"{x:1036,y:696,t:1526668173478};\\\", \\\"{x:1036,y:697,t:1526668173494};\\\", \\\"{x:1036,y:700,t:1526668173511};\\\", \\\"{x:1036,y:702,t:1526668173527};\\\", \\\"{x:1036,y:705,t:1526668173544};\\\", \\\"{x:1037,y:706,t:1526668173769};\\\", \\\"{x:1039,y:706,t:1526668173792};\\\", \\\"{x:1041,y:705,t:1526668173800};\\\", \\\"{x:1044,y:704,t:1526668173811};\\\", \\\"{x:1053,y:696,t:1526668173828};\\\", \\\"{x:1062,y:688,t:1526668173845};\\\", \\\"{x:1068,y:683,t:1526668173861};\\\", \\\"{x:1071,y:680,t:1526668173878};\\\", \\\"{x:1072,y:679,t:1526668173896};\\\", \\\"{x:1072,y:677,t:1526668174024};\\\", \\\"{x:1072,y:676,t:1526668174048};\\\", \\\"{x:1072,y:675,t:1526668174064};\\\", \\\"{x:1072,y:676,t:1526668175417};\\\", \\\"{x:1072,y:680,t:1526668175429};\\\", \\\"{x:1073,y:689,t:1526668175447};\\\", \\\"{x:1074,y:695,t:1526668175463};\\\", \\\"{x:1075,y:701,t:1526668175479};\\\", \\\"{x:1076,y:705,t:1526668175496};\\\", \\\"{x:1076,y:707,t:1526668175513};\\\", \\\"{x:1077,y:707,t:1526668175529};\\\", \\\"{x:1077,y:708,t:1526668175552};\\\", \\\"{x:1078,y:708,t:1526668176472};\\\", \\\"{x:1078,y:710,t:1526668176480};\\\", \\\"{x:1078,y:711,t:1526668176497};\\\", \\\"{x:1078,y:714,t:1526668176514};\\\", \\\"{x:1078,y:718,t:1526668176530};\\\", \\\"{x:1078,y:721,t:1526668176547};\\\", \\\"{x:1078,y:726,t:1526668176562};\\\", \\\"{x:1078,y:729,t:1526668176579};\\\", \\\"{x:1078,y:732,t:1526668176597};\\\", \\\"{x:1077,y:734,t:1526668176614};\\\", \\\"{x:1076,y:737,t:1526668176630};\\\", \\\"{x:1076,y:738,t:1526668176647};\\\", \\\"{x:1075,y:743,t:1526668176665};\\\", \\\"{x:1073,y:745,t:1526668176681};\\\", \\\"{x:1073,y:747,t:1526668176698};\\\", \\\"{x:1071,y:749,t:1526668176713};\\\", \\\"{x:1070,y:752,t:1526668176731};\\\", \\\"{x:1068,y:753,t:1526668176748};\\\", \\\"{x:1065,y:755,t:1526668176764};\\\", \\\"{x:1063,y:756,t:1526668176780};\\\", \\\"{x:1061,y:756,t:1526668176797};\\\", \\\"{x:1058,y:758,t:1526668176815};\\\", \\\"{x:1053,y:759,t:1526668176831};\\\", \\\"{x:1048,y:762,t:1526668176847};\\\", \\\"{x:1042,y:765,t:1526668176865};\\\", \\\"{x:1035,y:768,t:1526668176881};\\\", \\\"{x:1029,y:770,t:1526668176897};\\\", \\\"{x:1022,y:772,t:1526668176914};\\\", \\\"{x:1017,y:774,t:1526668176931};\\\", \\\"{x:1013,y:775,t:1526668176947};\\\", \\\"{x:1009,y:776,t:1526668176965};\\\", \\\"{x:1003,y:778,t:1526668176980};\\\", \\\"{x:1002,y:778,t:1526668176997};\\\", \\\"{x:998,y:780,t:1526668177014};\\\", \\\"{x:995,y:780,t:1526668177031};\\\", \\\"{x:994,y:781,t:1526668177047};\\\", \\\"{x:992,y:781,t:1526668177064};\\\", \\\"{x:989,y:782,t:1526668177081};\\\", \\\"{x:986,y:783,t:1526668177097};\\\", \\\"{x:983,y:785,t:1526668177114};\\\", \\\"{x:980,y:785,t:1526668177130};\\\", \\\"{x:979,y:786,t:1526668177147};\\\", \\\"{x:975,y:788,t:1526668177165};\\\", \\\"{x:972,y:789,t:1526668177181};\\\", \\\"{x:970,y:790,t:1526668177197};\\\", \\\"{x:968,y:791,t:1526668177214};\\\", \\\"{x:968,y:792,t:1526668177232};\\\", \\\"{x:966,y:792,t:1526668177248};\\\", \\\"{x:965,y:793,t:1526668177265};\\\", \\\"{x:962,y:794,t:1526668177280};\\\", \\\"{x:961,y:795,t:1526668177298};\\\", \\\"{x:958,y:797,t:1526668177315};\\\", \\\"{x:956,y:798,t:1526668177331};\\\", \\\"{x:953,y:799,t:1526668177348};\\\", \\\"{x:951,y:801,t:1526668177365};\\\", \\\"{x:949,y:802,t:1526668177382};\\\", \\\"{x:948,y:803,t:1526668177397};\\\", \\\"{x:946,y:805,t:1526668177414};\\\", \\\"{x:944,y:805,t:1526668177431};\\\", \\\"{x:939,y:806,t:1526668177447};\\\", \\\"{x:931,y:809,t:1526668177465};\\\", \\\"{x:926,y:810,t:1526668177481};\\\", \\\"{x:921,y:812,t:1526668177498};\\\", \\\"{x:917,y:813,t:1526668177514};\\\", \\\"{x:915,y:813,t:1526668177531};\\\", \\\"{x:914,y:813,t:1526668177548};\\\", \\\"{x:914,y:812,t:1526668179369};\\\", \\\"{x:914,y:810,t:1526668179382};\\\", \\\"{x:914,y:808,t:1526668179400};\\\", \\\"{x:914,y:805,t:1526668179416};\\\", \\\"{x:914,y:802,t:1526668179432};\\\", \\\"{x:914,y:800,t:1526668179449};\\\", \\\"{x:914,y:799,t:1526668179466};\\\", \\\"{x:914,y:797,t:1526668179488};\\\", \\\"{x:914,y:796,t:1526668179545};\\\", \\\"{x:914,y:794,t:1526668179633};\\\", \\\"{x:914,y:792,t:1526668179664};\\\", \\\"{x:916,y:790,t:1526668179681};\\\", \\\"{x:916,y:788,t:1526668179704};\\\", \\\"{x:916,y:786,t:1526668179717};\\\", \\\"{x:916,y:784,t:1526668179732};\\\", \\\"{x:916,y:783,t:1526668179749};\\\", \\\"{x:916,y:781,t:1526668179766};\\\", \\\"{x:916,y:778,t:1526668179783};\\\", \\\"{x:916,y:776,t:1526668179799};\\\", \\\"{x:916,y:774,t:1526668179816};\\\", \\\"{x:916,y:772,t:1526668179833};\\\", \\\"{x:916,y:771,t:1526668179849};\\\", \\\"{x:916,y:769,t:1526668179866};\\\", \\\"{x:916,y:768,t:1526668179883};\\\", \\\"{x:916,y:766,t:1526668179900};\\\", \\\"{x:916,y:765,t:1526668179916};\\\", \\\"{x:916,y:763,t:1526668179933};\\\", \\\"{x:916,y:761,t:1526668179949};\\\", \\\"{x:916,y:759,t:1526668179967};\\\", \\\"{x:916,y:758,t:1526668179983};\\\", \\\"{x:915,y:755,t:1526668179999};\\\", \\\"{x:914,y:752,t:1526668180017};\\\", \\\"{x:914,y:749,t:1526668180033};\\\", \\\"{x:914,y:748,t:1526668180049};\\\", \\\"{x:914,y:746,t:1526668180066};\\\", \\\"{x:913,y:745,t:1526668180082};\\\", \\\"{x:913,y:744,t:1526668180100};\\\", \\\"{x:913,y:742,t:1526668181049};\\\", \\\"{x:913,y:741,t:1526668181057};\\\", \\\"{x:914,y:739,t:1526668181067};\\\", \\\"{x:917,y:738,t:1526668181084};\\\", \\\"{x:919,y:737,t:1526668181101};\\\", \\\"{x:922,y:735,t:1526668181117};\\\", \\\"{x:925,y:732,t:1526668181134};\\\", \\\"{x:928,y:731,t:1526668181151};\\\", \\\"{x:933,y:728,t:1526668181168};\\\", \\\"{x:937,y:725,t:1526668181184};\\\", \\\"{x:938,y:724,t:1526668181200};\\\", \\\"{x:942,y:723,t:1526668181217};\\\", \\\"{x:945,y:721,t:1526668181235};\\\", \\\"{x:948,y:719,t:1526668181251};\\\", \\\"{x:950,y:718,t:1526668181268};\\\", \\\"{x:952,y:717,t:1526668181285};\\\", \\\"{x:953,y:716,t:1526668181301};\\\", \\\"{x:956,y:715,t:1526668181318};\\\", \\\"{x:958,y:714,t:1526668181335};\\\", \\\"{x:962,y:712,t:1526668181351};\\\", \\\"{x:964,y:710,t:1526668181368};\\\", \\\"{x:968,y:708,t:1526668181384};\\\", \\\"{x:969,y:707,t:1526668181400};\\\", \\\"{x:972,y:706,t:1526668181417};\\\", \\\"{x:973,y:704,t:1526668181435};\\\", \\\"{x:975,y:703,t:1526668181451};\\\", \\\"{x:977,y:703,t:1526668181467};\\\", \\\"{x:978,y:703,t:1526668181484};\\\", \\\"{x:979,y:701,t:1526668181500};\\\", \\\"{x:978,y:702,t:1526668182985};\\\", \\\"{x:972,y:705,t:1526668183003};\\\", \\\"{x:970,y:706,t:1526668183019};\\\", \\\"{x:967,y:709,t:1526668183036};\\\", \\\"{x:962,y:712,t:1526668183052};\\\", \\\"{x:958,y:713,t:1526668183069};\\\", \\\"{x:955,y:716,t:1526668183086};\\\", \\\"{x:949,y:720,t:1526668183103};\\\", \\\"{x:944,y:725,t:1526668183119};\\\", \\\"{x:940,y:729,t:1526668183135};\\\", \\\"{x:936,y:734,t:1526668183152};\\\", \\\"{x:936,y:737,t:1526668183169};\\\", \\\"{x:935,y:739,t:1526668183185};\\\", \\\"{x:933,y:746,t:1526668183203};\\\", \\\"{x:933,y:749,t:1526668183219};\\\", \\\"{x:932,y:752,t:1526668183235};\\\", \\\"{x:932,y:755,t:1526668183252};\\\", \\\"{x:931,y:757,t:1526668183269};\\\", \\\"{x:930,y:761,t:1526668183285};\\\", \\\"{x:929,y:764,t:1526668183302};\\\", \\\"{x:928,y:767,t:1526668183319};\\\", \\\"{x:927,y:771,t:1526668183335};\\\", \\\"{x:927,y:775,t:1526668183351};\\\", \\\"{x:927,y:777,t:1526668183369};\\\", \\\"{x:927,y:780,t:1526668183385};\\\", \\\"{x:927,y:781,t:1526668183402};\\\", \\\"{x:927,y:783,t:1526668183420};\\\", \\\"{x:927,y:784,t:1526668183457};\\\", \\\"{x:927,y:785,t:1526668183481};\\\", \\\"{x:927,y:786,t:1526668184768};\\\", \\\"{x:926,y:787,t:1526668184776};\\\", \\\"{x:924,y:788,t:1526668184787};\\\", \\\"{x:922,y:791,t:1526668184804};\\\", \\\"{x:920,y:793,t:1526668184821};\\\", \\\"{x:918,y:795,t:1526668184837};\\\", \\\"{x:917,y:797,t:1526668184854};\\\", \\\"{x:915,y:799,t:1526668184870};\\\", \\\"{x:915,y:800,t:1526668184920};\\\", \\\"{x:914,y:800,t:1526668184937};\\\", \\\"{x:914,y:802,t:1526668184953};\\\", \\\"{x:914,y:803,t:1526668184970};\\\", \\\"{x:913,y:805,t:1526668184987};\\\", \\\"{x:913,y:806,t:1526668185003};\\\", \\\"{x:913,y:808,t:1526668185024};\\\", \\\"{x:912,y:810,t:1526668185040};\\\", \\\"{x:911,y:811,t:1526668185053};\\\", \\\"{x:909,y:814,t:1526668185070};\\\", \\\"{x:909,y:816,t:1526668185777};\\\", \\\"{x:916,y:817,t:1526668185788};\\\", \\\"{x:927,y:823,t:1526668185805};\\\", \\\"{x:931,y:832,t:1526668185821};\\\", \\\"{x:934,y:849,t:1526668185837};\\\", \\\"{x:942,y:868,t:1526668185854};\\\", \\\"{x:949,y:886,t:1526668185871};\\\", \\\"{x:953,y:901,t:1526668185888};\\\", \\\"{x:953,y:902,t:1526668185905};\\\", \\\"{x:952,y:906,t:1526668185921};\\\", \\\"{x:948,y:907,t:1526668185938};\\\", \\\"{x:947,y:908,t:1526668185954};\\\", \\\"{x:946,y:908,t:1526668186001};\\\", \\\"{x:946,y:909,t:1526668186081};\\\", \\\"{x:946,y:911,t:1526668186096};\\\", \\\"{x:944,y:915,t:1526668186105};\\\", \\\"{x:941,y:920,t:1526668186122};\\\", \\\"{x:932,y:933,t:1526668186138};\\\", \\\"{x:922,y:945,t:1526668186154};\\\", \\\"{x:917,y:952,t:1526668186172};\\\", \\\"{x:911,y:958,t:1526668186187};\\\", \\\"{x:907,y:962,t:1526668186205};\\\", \\\"{x:902,y:967,t:1526668186222};\\\", \\\"{x:900,y:969,t:1526668186238};\\\", \\\"{x:897,y:972,t:1526668186254};\\\", \\\"{x:896,y:974,t:1526668186271};\\\", \\\"{x:895,y:975,t:1526668186288};\\\", \\\"{x:894,y:975,t:1526668186489};\\\", \\\"{x:893,y:975,t:1526668186505};\\\", \\\"{x:892,y:975,t:1526668186521};\\\", \\\"{x:891,y:975,t:1526668186538};\\\", \\\"{x:890,y:975,t:1526668186561};\\\", \\\"{x:890,y:974,t:1526668186576};\\\", \\\"{x:890,y:973,t:1526668186592};\\\", \\\"{x:890,y:972,t:1526668186625};\\\", \\\"{x:891,y:972,t:1526668187169};\\\", \\\"{x:894,y:974,t:1526668187176};\\\", \\\"{x:896,y:980,t:1526668187189};\\\", \\\"{x:900,y:987,t:1526668187205};\\\", \\\"{x:906,y:996,t:1526668187222};\\\", \\\"{x:911,y:1003,t:1526668187239};\\\", \\\"{x:914,y:1007,t:1526668187257};\\\", \\\"{x:915,y:1007,t:1526668187272};\\\", \\\"{x:915,y:1008,t:1526668190148};\\\", \\\"{x:915,y:1010,t:1526668190162};\\\", \\\"{x:920,y:1022,t:1526668190179};\\\", \\\"{x:929,y:1035,t:1526668190194};\\\", \\\"{x:940,y:1049,t:1526668190211};\\\", \\\"{x:950,y:1066,t:1526668190228};\\\", \\\"{x:955,y:1074,t:1526668190246};\\\", \\\"{x:959,y:1079,t:1526668190261};\\\", \\\"{x:962,y:1083,t:1526668190278};\\\", \\\"{x:963,y:1084,t:1526668190295};\\\" ] }, { \\\"rt\\\": 10095, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"vietnam\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 390204, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 27581, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 418800, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 4251, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 424409, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"FA0KM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"FA0KM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2274},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2276},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2288,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2289,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2290,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2291,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2292,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2293,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2294,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2295,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2296,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2297,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2298,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2300,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2301,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2303,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2305,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2307,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2309,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2311,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2313,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2315,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2317,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2319,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2321,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2323,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2325,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2327,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2329,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2331,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2333,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2335,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2337,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2339,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2341,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2345,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2349,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2350,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2353,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2354,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2357,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2358,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2361,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2362,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2365,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2366,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2369,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2370,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2373,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2374,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2377,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2378,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2381,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2382,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2385,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2386,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2389,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2390,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2394,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2400,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2401,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2404,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2405,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2406,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2407,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2408,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2414,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2425,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2426,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2433,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2434,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2439,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2444,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2447,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2454,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2459,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2460,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2461,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2467,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2468,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2469,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2474,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2475,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2476,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2478,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2479,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2484,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2500,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2502,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2504,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2506,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2508,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2510,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2512,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2513,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2514,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2516,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2518,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2520,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2522,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2524,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2526,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2528,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2530,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2532,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2534,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2536,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2538,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2540,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2544,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2548,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2552,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2553,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2556,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2557,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2560,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2561,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2564,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2565,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2568,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2569,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2572,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2573,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2576,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2577,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2580,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2581,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2584,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2585,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2586,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2587},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2589,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2591,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2592,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 195, dom: 1255, initialDom: 1400",
  "javascriptErrors": []
}