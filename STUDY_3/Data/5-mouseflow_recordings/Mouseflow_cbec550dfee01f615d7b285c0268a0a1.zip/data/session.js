var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cbec550dfee01f615d7b285c0268a0a1",
  "created": "2018-06-01T11:09:56.1036859-07:00",
  "lastActivity": "2018-06-01T11:10:09.1886859-07:00",
  "pageViews": [
    {
      "id": "06015681d3d6c8f111d2343ef136d335af04dab1",
      "startTime": "2018-06-01T11:09:56.1036859-07:00",
      "endTime": "2018-06-01T11:10:09.1886859-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 13085,
      "engagementTime": 16170,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13085,
  "engagementTime": 16170,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=41Y1H",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c6fcf754b12cc04f89d4491b721c46e5",
  "gdpr": false
}