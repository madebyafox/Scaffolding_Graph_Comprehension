var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "42e0eb6e65a6c27224ed591daba958f4",
  "created": "2018-06-04T13:21:27.4290519-07:00",
  "lastActivity": "2018-06-04T13:21:50.5470519-07:00",
  "pageViews": [
    {
      "id": "06042752b0e9105b9a63480e874e1897a764366f",
      "startTime": "2018-06-04T13:21:27.4290519-07:00",
      "endTime": "2018-06-04T13:21:50.5470519-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 23118,
      "engagementTime": 22486,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 23118,
  "engagementTime": 22486,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TCTCN",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e6f5ebeff36d3c401cb50bb23b617d57",
  "gdpr": false
}