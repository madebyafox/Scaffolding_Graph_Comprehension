var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "215e1b1b308af5987f8ef0c0fad421b6",
  "created": "2018-05-19T13:01:57.8348067-07:00",
  "lastActivity": "2018-05-19T13:02:27.3346598-07:00",
  "pageViews": [
    {
      "id": "05195744d4fd50f06615c40ab30729bef243f5d6",
      "startTime": "2018-05-19T13:01:57.8666598-07:00",
      "endTime": "2018-05-19T13:02:27.3346598-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 29468,
      "engagementTime": 27890,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29468,
  "engagementTime": 27890,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93YLJ",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "45455136f36a3338e935e87c065365fa",
  "gdpr": false
}