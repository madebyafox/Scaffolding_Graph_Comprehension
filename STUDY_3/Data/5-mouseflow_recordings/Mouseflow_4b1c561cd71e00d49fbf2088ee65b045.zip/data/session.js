var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4b1c561cd71e00d49fbf2088ee65b045",
  "created": "2018-05-29T16:08:58.0142125-07:00",
  "lastActivity": "2018-05-29T16:10:21.1734066-07:00",
  "pageViews": [
    {
      "id": "05295703c572961981f33df9d18505074b559902",
      "startTime": "2018-05-29T16:08:58.108619-07:00",
      "endTime": "2018-05-29T16:10:21.1734066-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 83519,
      "engagementTime": 50796,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 83519,
  "engagementTime": 50796,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "03e46767fc6d2375a49f86591c3fd3b4",
  "gdpr": false
}