var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ba163e1c24a4ade4f07b0eaf35f61f84",
  "created": "2018-05-29T10:08:23.9064956-07:00",
  "lastActivity": "2018-05-29T10:08:34.2094956-07:00",
  "pageViews": [
    {
      "id": "052924778dde4ef9a75429860fb07d0aa5e3acfc",
      "startTime": "2018-05-29T10:08:23.9064956-07:00",
      "endTime": "2018-05-29T10:08:34.2094956-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 10303,
      "engagementTime": 12806,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10303,
  "engagementTime": 12806,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J80QC",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f4846810b704514bfe7f74a85de26d8c",
  "gdpr": false
}