var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525456712741ab348b555b8019818ad39249d1d"] = {
  "startTime": "2018-05-25T18:24:45.6077455Z",
  "websitePageUrl": "/16",
  "visitTime": 112126,
  "engagementTime": 111429,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a46458afb5632bdd50af79f246e04d92",
    "created": "2018-05-25T18:24:45.6077455+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=UV5LD",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b81043a4c6f254f41a4a749debc65586",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a46458afb5632bdd50af79f246e04d92/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 239,
      "e": 239,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 788,
      "y": 640
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 142,
      "y": 35954,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 691,
      "e": 691,
      "ty": 2,
      "x": 786,
      "y": 640
    },
    {
      "t": 708,
      "e": 708,
      "ty": 2,
      "x": 460,
      "y": 489
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 38995,
      "y": 3968,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 414,
      "y": 480
    },
    {
      "t": 891,
      "e": 891,
      "ty": 6,
      "x": 405,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 405,
      "y": 523
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 417,
      "y": 546
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 35960,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 417,
      "y": 547
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 35960,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 36073,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 419,
      "y": 558
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 419,
      "y": 563
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 417,
      "y": 564
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 35960,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3136,
      "e": 3136,
      "ty": 3,
      "x": 417,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3139,
      "e": 3139,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3279,
      "e": 3279,
      "ty": 4,
      "x": 35960,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3280,
      "e": 3280,
      "ty": 5,
      "x": 417,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 2,
      "x": 606,
      "y": 566
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 57206,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3602,
      "e": 3602,
      "ty": 2,
      "x": 658,
      "y": 578
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 635,
      "y": 589
    },
    {
      "t": 3726,
      "e": 3726,
      "ty": 7,
      "x": 593,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 55182,
      "y": 62026,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 3802,
      "e": 3802,
      "ty": 2,
      "x": 587,
      "y": 614
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 582,
      "y": 613
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 2,
      "x": 580,
      "y": 613
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 54283,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 5963,
      "e": 5963,
      "ty": 6,
      "x": 590,
      "y": 578,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5995,
      "e": 5995,
      "ty": 7,
      "x": 722,
      "y": 496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 722,
      "y": 496
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 2405,
      "y": 25418,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1352,
      "y": 529
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1342,
      "y": 611
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 36362,
      "y": 43331,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6302,
      "e": 6302,
      "ty": 2,
      "x": 1281,
      "y": 848
    },
    {
      "t": 6402,
      "e": 6402,
      "ty": 2,
      "x": 1229,
      "y": 981
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 2,
      "x": 1228,
      "y": 981
    },
    {
      "t": 6503,
      "e": 6503,
      "ty": 41,
      "x": 46010,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[11] > text"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1178,
      "y": 993
    },
    {
      "t": 6702,
      "e": 6702,
      "ty": 2,
      "x": 1162,
      "y": 994
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 26426,
      "y": 61309,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6802,
      "e": 6802,
      "ty": 2,
      "x": 1157,
      "y": 985
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1149,
      "y": 959
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1144,
      "y": 949
    },
    {
      "t": 7003,
      "e": 7003,
      "ty": 41,
      "x": 25228,
      "y": 58086,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7253,
      "e": 7253,
      "ty": 41,
      "x": 25228,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7302,
      "e": 7302,
      "ty": 2,
      "x": 1144,
      "y": 950
    },
    {
      "t": 7402,
      "e": 7402,
      "ty": 2,
      "x": 1144,
      "y": 952
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 2,
      "x": 1144,
      "y": 962
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 25228,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1145,
      "y": 962
    },
    {
      "t": 8753,
      "e": 8753,
      "ty": 41,
      "x": 25299,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9557,
      "e": 9557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 9636,
      "e": 9636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10147,
      "e": 10147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10147,
      "e": 10147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10218,
      "e": 10218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 10267,
      "e": 10267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10331,
      "e": 10331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 10435,
      "e": 10435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10435,
      "e": 10435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10522,
      "e": 10522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 10595,
      "e": 10595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 10595,
      "e": 10595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10667,
      "e": 10667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i G"
    },
    {
      "t": 10971,
      "e": 10971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11035,
      "e": 11035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 11131,
      "e": 11131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11186,
      "e": 11186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 11267,
      "e": 11267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11323,
      "e": 11323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11404,
      "e": 11404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11435,
      "e": 11435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11980,
      "e": 11980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 12131,
      "e": 12131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 12315,
      "e": 12315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 12316,
      "e": 12316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12394,
      "e": 12394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 12435,
      "e": 12435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 12498,
      "e": 12498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 12563,
      "e": 12563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12564,
      "e": 12564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12651,
      "e": 12651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 12651,
      "e": 12651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12763,
      "e": 12763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 12796,
      "e": 12796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 13147,
      "e": 13147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13251,
      "e": 13251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 13339,
      "e": 13339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13404,
      "e": 13404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 13491,
      "e": 13491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13539,
      "e": 13539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 14027,
      "e": 14027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 14030,
      "e": 14030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14090,
      "e": 14090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 14163,
      "e": 14163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 14219,
      "e": 14219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 14243,
      "e": 14243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14243,
      "e": 14243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14330,
      "e": 14330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14331,
      "e": 14331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14379,
      "e": 14379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 14435,
      "e": 14435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 14563,
      "e": 14563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14564,
      "e": 14564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14651,
      "e": 14651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 14723,
      "e": 14723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14723,
      "e": 14723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14811,
      "e": 14811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14811,
      "e": 14811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14819,
      "e": 14819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 14907,
      "e": 14907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14987,
      "e": 14987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14988,
      "e": 14988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15060,
      "e": 15060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15083,
      "e": 15083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15084,
      "e": 15084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15138,
      "e": 15138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15155,
      "e": 15155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15155,
      "e": 15155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15235,
      "e": 15235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15291,
      "e": 15291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15291,
      "e": 15291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15371,
      "e": 15371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16260,
      "e": 16260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16261,
      "e": 16261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16330,
      "e": 16330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16347,
      "e": 16347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16347,
      "e": 16347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16411,
      "e": 16411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16523,
      "e": 16523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16525,
      "e": 16525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16603,
      "e": 16603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16731,
      "e": 16731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16732,
      "e": 16732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16811,
      "e": 16811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17411,
      "e": 17411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17411,
      "e": 17411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17475,
      "e": 17475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17604,
      "e": 17604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x"
    },
    {
      "t": 17667,
      "e": 17667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17668,
      "e": 17668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17747,
      "e": 17747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18724,
      "e": 18724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18724,
      "e": 18724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18787,
      "e": 18787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19205,
      "e": 19205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19207,
      "e": 19207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19226,
      "e": 19226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19404,
      "e": 19404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x ax"
    },
    {
      "t": 19948,
      "e": 19948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19949,
      "e": 19949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20010,
      "e": 20010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20011,
      "e": 20011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20050,
      "e": 20050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 20058,
      "e": 20058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20204,
      "e": 20204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis"
    },
    {
      "t": 20316,
      "e": 20316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20316,
      "e": 20316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20387,
      "e": 20387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20595,
      "e": 20595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20595,
      "e": 20595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20658,
      "e": 20658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20724,
      "e": 20724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20724,
      "e": 20724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20778,
      "e": 20778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20818,
      "e": 20818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20819,
      "e": 20819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20891,
      "e": 20891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20907,
      "e": 20907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20907,
      "e": 20907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20971,
      "e": 20971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21083,
      "e": 21083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21084,
      "e": 21084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21162,
      "e": 21162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21267,
      "e": 21267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21268,
      "e": 21268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21356,
      "e": 21356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21419,
      "e": 21419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21420,
      "e": 21420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21498,
      "e": 21498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21562,
      "e": 21562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 21563,
      "e": 21563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21635,
      "e": 21635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 21763,
      "e": 21763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21764,
      "e": 21764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21818,
      "e": 21818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21890,
      "e": 21890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21891,
      "e": 21891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21962,
      "e": 21962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 21964,
      "e": 21964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21964,
      "e": 21964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22027,
      "e": 22027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22075,
      "e": 22075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22076,
      "e": 22076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22131,
      "e": 22131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22170,
      "e": 22170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22171,
      "e": 22171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22235,
      "e": 22235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22283,
      "e": 22283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22284,
      "e": 22284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22355,
      "e": 22355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 22355,
      "e": 22355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22355,
      "e": 22355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22419,
      "e": 22419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22483,
      "e": 22483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22483,
      "e": 22483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22595,
      "e": 22595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22595,
      "e": 22595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22618,
      "e": 22618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 22724,
      "e": 22724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22724,
      "e": 22724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22802,
      "e": 22802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22819,
      "e": 22819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22819,
      "e": 22819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22891,
      "e": 22891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22907,
      "e": 22907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22996,
      "e": 22996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22996,
      "e": 22996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23051,
      "e": 23051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23051,
      "e": 23051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23075,
      "e": 23075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 23123,
      "e": 23123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23194,
      "e": 23194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23195,
      "e": 23195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23267,
      "e": 23267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23267,
      "e": 23267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23268,
      "e": 23268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23395,
      "e": 23395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23402,
      "e": 23402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 23403,
      "e": 23403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23435,
      "e": 23435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23435,
      "e": 23435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23491,
      "e": 23491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ya"
    },
    {
      "t": 23555,
      "e": 23555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23556,
      "e": 23556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23602,
      "e": 23602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23627,
      "e": 23627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23627,
      "e": 23627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23674,
      "e": 23674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23714,
      "e": 23714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24355,
      "e": 24355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24410,
      "e": 24410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it syas"
    },
    {
      "t": 24490,
      "e": 24490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24538,
      "e": 24538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it sya"
    },
    {
      "t": 24635,
      "e": 24635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24683,
      "e": 24683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it sy"
    },
    {
      "t": 24747,
      "e": 24747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24795,
      "e": 24795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it s"
    },
    {
      "t": 24802,
      "e": 24802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24803,
      "e": 24803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24882,
      "e": 24882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25363,
      "e": 25363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25364,
      "e": 25364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25426,
      "e": 25426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 25515,
      "e": 25515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25515,
      "e": 25515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25582,
      "e": 25518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25699,
      "e": 25635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25699,
      "e": 25635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25763,
      "e": 25699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26059,
      "e": 25995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 26060,
      "e": 25996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26156,
      "e": 26092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 26156,
      "e": 26092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26203,
      "e": 26139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 26290,
      "e": 26226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27099,
      "e": 27035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27100,
      "e": 27036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27171,
      "e": 27107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27250,
      "e": 27186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27251,
      "e": 27187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27371,
      "e": 27307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27372,
      "e": 27308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27418,
      "e": 27354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 27499,
      "e": 27435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27964,
      "e": 27900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 27964,
      "e": 27900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28027,
      "e": 27963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 28180,
      "e": 28116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28180,
      "e": 28116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28250,
      "e": 28186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28315,
      "e": 28251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28315,
      "e": 28251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28379,
      "e": 28315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28387,
      "e": 28323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28387,
      "e": 28323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28451,
      "e": 28387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28491,
      "e": 28427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28494,
      "e": 28430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28563,
      "e": 28499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28594,
      "e": 28530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28595,
      "e": 28531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28666,
      "e": 28602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28795,
      "e": 28731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28796,
      "e": 28732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28875,
      "e": 28811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30372,
      "e": 30308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 30372,
      "e": 30308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30458,
      "e": 30394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 30587,
      "e": 30523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30588,
      "e": 30524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30651,
      "e": 30587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31805,
      "e": 31741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 31805,
      "e": 31741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31875,
      "e": 31811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 32003,
      "e": 31939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you"
    },
    {
      "t": 32044,
      "e": 31980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32044,
      "e": 31980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32124,
      "e": 32060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32539,
      "e": 32475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32540,
      "e": 32476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32604,
      "e": 32540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 32675,
      "e": 32611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32676,
      "e": 32612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32756,
      "e": 32692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32890,
      "e": 32826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32890,
      "e": 32826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32979,
      "e": 32915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33140,
      "e": 33076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 33140,
      "e": 33076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33195,
      "e": 33131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 33348,
      "e": 33284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33349,
      "e": 33285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33428,
      "e": 33364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33563,
      "e": 33499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33564,
      "e": 33500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33642,
      "e": 33578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33683,
      "e": 33619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33683,
      "e": 33619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33755,
      "e": 33691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33779,
      "e": 33715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33779,
      "e": 33715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33835,
      "e": 33771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33874,
      "e": 33810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33874,
      "e": 33810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33954,
      "e": 33890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33995,
      "e": 33931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33995,
      "e": 33931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34075,
      "e": 34011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35028,
      "e": 34964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 35028,
      "e": 34964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35090,
      "e": 35026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 35203,
      "e": 35139,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y"
    },
    {
      "t": 36372,
      "e": 36308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36372,
      "e": 36308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36443,
      "e": 36379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36499,
      "e": 36435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36499,
      "e": 36435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36579,
      "e": 36515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36739,
      "e": 36675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 36740,
      "e": 36676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36805,
      "e": 36741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 36891,
      "e": 36827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36892,
      "e": 36828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36955,
      "e": 36891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37011,
      "e": 36947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37012,
      "e": 36948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37083,
      "e": 37019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 37204,
      "e": 37019,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis"
    },
    {
      "t": 37851,
      "e": 37666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37852,
      "e": 37667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37923,
      "e": 37738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38171,
      "e": 37986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 38172,
      "e": 37987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38262,
      "e": 38077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38262,
      "e": 38077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38327,
      "e": 38142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 38335,
      "e": 38150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38335,
      "e": 38150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38408,
      "e": 38223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38415,
      "e": 38230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 38415,
      "e": 38230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38471,
      "e": 38286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 38519,
      "e": 38334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38687,
      "e": 38502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38688,
      "e": 38503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38775,
      "e": 38590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38999,
      "e": 38814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39000,
      "e": 38815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39087,
      "e": 38902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39103,
      "e": 38918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39103,
      "e": 38918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39175,
      "e": 38990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39223,
      "e": 39038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 39223,
      "e": 39038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39225,
      "e": 39040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39225,
      "e": 39040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39262,
      "e": 39077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||we"
    },
    {
      "t": 39286,
      "e": 39101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39334,
      "e": 39149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39335,
      "e": 39150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39398,
      "e": 39213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39967,
      "e": 39782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40046,
      "e": 39861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from thwe"
    },
    {
      "t": 40119,
      "e": 39934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40247,
      "e": 40062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from thw"
    },
    {
      "t": 40263,
      "e": 40078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40264,
      "e": 40079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40351,
      "e": 40166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40720,
      "e": 40535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40751,
      "e": 40566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from thw"
    },
    {
      "t": 40846,
      "e": 40661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40926,
      "e": 40741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from th"
    },
    {
      "t": 41006,
      "e": 40821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41007,
      "e": 40822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41046,
      "e": 40861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41287,
      "e": 41102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41288,
      "e": 41103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41383,
      "e": 41198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41471,
      "e": 41286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41471,
      "e": 41286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41559,
      "e": 41374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41583,
      "e": 41398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41584,
      "e": 41399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41655,
      "e": 41470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41694,
      "e": 41509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41694,
      "e": 41509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41766,
      "e": 41581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41767,
      "e": 41582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41774,
      "e": 41589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 41839,
      "e": 41654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41926,
      "e": 41741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41926,
      "e": 41741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41990,
      "e": 41805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42183,
      "e": 41998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42184,
      "e": 41999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42246,
      "e": 42061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42247,
      "e": 42062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42319,
      "e": 42134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 42367,
      "e": 42182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42374,
      "e": 42189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 42375,
      "e": 42190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42447,
      "e": 42262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 42520,
      "e": 42263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42521,
      "e": 42264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42608,
      "e": 42351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42808,
      "e": 42551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42809,
      "e": 42552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42894,
      "e": 42637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 43007,
      "e": 42750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43008,
      "e": 42751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43078,
      "e": 42821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43191,
      "e": 42934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43191,
      "e": 42934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43295,
      "e": 43038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43295,
      "e": 43038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43342,
      "e": 43085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 43399,
      "e": 43142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43439,
      "e": 43182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43439,
      "e": 43182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43502,
      "e": 43245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43550,
      "e": 43293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43551,
      "e": 43294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43614,
      "e": 43357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43735,
      "e": 43478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43735,
      "e": 43478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43815,
      "e": 43558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44263,
      "e": 44006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44264,
      "e": 44007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44326,
      "e": 44069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 44479,
      "e": 44222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44480,
      "e": 44223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44551,
      "e": 44294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44743,
      "e": 44486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 44744,
      "e": 44487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44823,
      "e": 44566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 45447,
      "e": 45190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 45447,
      "e": 45190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45526,
      "e": 45269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 45719,
      "e": 45462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45719,
      "e": 45462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45798,
      "e": 45541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46511,
      "e": 46254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46542,
      "e": 46285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 1p"
    },
    {
      "t": 46654,
      "e": 46397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46694,
      "e": 46437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 1"
    },
    {
      "t": 46807,
      "e": 46550,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 1"
    },
    {
      "t": 48719,
      "e": 48462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 48719,
      "e": 48462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48822,
      "e": 48565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 49031,
      "e": 48774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49031,
      "e": 48774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49103,
      "e": 48846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49207,
      "e": 48950,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 "
    },
    {
      "t": 49279,
      "e": 49022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 49280,
      "e": 49023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49374,
      "e": 49117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49375,
      "e": 49118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49422,
      "e": 49165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 49470,
      "e": 49213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49591,
      "e": 49334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49592,
      "e": 49335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49678,
      "e": 49421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49718,
      "e": 49461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49718,
      "e": 49461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49799,
      "e": 49542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49799,
      "e": 49542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49808,
      "e": 49551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 49863,
      "e": 49606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49951,
      "e": 49694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49952,
      "e": 49695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50006,
      "e": 49749,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50007,
      "e": 49750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50007,
      "e": 49750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50030,
      "e": 49773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 50087,
      "e": 49830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50174,
      "e": 49917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50175,
      "e": 49918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50263,
      "e": 50006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 50367,
      "e": 50110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50368,
      "e": 50111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50414,
      "e": 50157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50511,
      "e": 50254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50511,
      "e": 50254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50583,
      "e": 50326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50655,
      "e": 50398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50656,
      "e": 50399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50719,
      "e": 50462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52160,
      "e": 51903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 52161,
      "e": 51904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52206,
      "e": 51949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 52246,
      "e": 51989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52246,
      "e": 51989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52286,
      "e": 52029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52408,
      "e": 52151,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see wh"
    },
    {
      "t": 52423,
      "e": 52166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52424,
      "e": 52167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52486,
      "e": 52229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52519,
      "e": 52262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 52519,
      "e": 52262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52582,
      "e": 52325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 52622,
      "e": 52365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52623,
      "e": 52366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52686,
      "e": 52429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52775,
      "e": 52518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52777,
      "e": 52520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52846,
      "e": 52589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52911,
      "e": 52654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 52911,
      "e": 52654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52966,
      "e": 52709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 53007,
      "e": 52750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53008,
      "e": 52751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53086,
      "e": 52829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 53208,
      "e": 52951,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which do"
    },
    {
      "t": 53263,
      "e": 53006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53264,
      "e": 53007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53326,
      "e": 53069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53390,
      "e": 53133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 53390,
      "e": 53133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53462,
      "e": 53205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53519,
      "e": 53262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53520,
      "e": 53263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53591,
      "e": 53334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53694,
      "e": 53437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 53695,
      "e": 53438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53767,
      "e": 53510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 53871,
      "e": 53614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53872,
      "e": 53615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53958,
      "e": 53701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 53958,
      "e": 53701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53966,
      "e": 53709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 54022,
      "e": 53765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54119,
      "e": 53862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 54119,
      "e": 53862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54191,
      "e": 53934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 54319,
      "e": 54062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54319,
      "e": 54062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54407,
      "e": 54150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54543,
      "e": 54286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54544,
      "e": 54287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54630,
      "e": 54373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54630,
      "e": 54373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54662,
      "e": 54405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 54694,
      "e": 54437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54809,
      "e": 54552,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which dots fall in"
    },
    {
      "t": 54815,
      "e": 54558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54816,
      "e": 54559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54886,
      "e": 54629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54902,
      "e": 54645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54903,
      "e": 54646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54959,
      "e": 54702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55023,
      "e": 54702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 55024,
      "e": 54703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55086,
      "e": 54765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 55094,
      "e": 54773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 55094,
      "e": 54773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55166,
      "e": 54845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 55246,
      "e": 54925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55247,
      "e": 54926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55302,
      "e": 54981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55408,
      "e": 55087,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which dots fall in that"
    },
    {
      "t": 55479,
      "e": 55158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55479,
      "e": 55158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55543,
      "e": 55222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56126,
      "e": 55805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56127,
      "e": 55806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56230,
      "e": 55909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 56378,
      "e": 56057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56378,
      "e": 56057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56486,
      "e": 56165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56486,
      "e": 56165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56510,
      "e": 56189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 56583,
      "e": 56262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56598,
      "e": 56277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56599,
      "e": 56278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56663,
      "e": 56342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 57479,
      "e": 57158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 57481,
      "e": 57160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57550,
      "e": 57229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 59405,
      "e": 59084,
      "ty": 2,
      "x": 1239,
      "y": 1076
    },
    {
      "t": 59505,
      "e": 59184,
      "ty": 2,
      "x": 1274,
      "y": 1099
    },
    {
      "t": 59505,
      "e": 59184,
      "ty": 41,
      "x": 43598,
      "y": 60438,
      "ta": "> div.stimulus"
    },
    {
      "t": 59605,
      "e": 59284,
      "ty": 2,
      "x": 1272,
      "y": 1099
    },
    {
      "t": 59705,
      "e": 59384,
      "ty": 2,
      "x": 1124,
      "y": 988
    },
    {
      "t": 59755,
      "e": 59434,
      "ty": 41,
      "x": 24030,
      "y": 60879,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 59805,
      "e": 59484,
      "ty": 2,
      "x": 1138,
      "y": 990
    },
    {
      "t": 59905,
      "e": 59584,
      "ty": 2,
      "x": 1140,
      "y": 977
    },
    {
      "t": 60006,
      "e": 59685,
      "ty": 41,
      "x": 11449,
      "y": 33023,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 60105,
      "e": 59784,
      "ty": 2,
      "x": 1144,
      "y": 967
    },
    {
      "t": 60205,
      "e": 59884,
      "ty": 2,
      "x": 1148,
      "y": 956
    },
    {
      "t": 60255,
      "e": 59934,
      "ty": 41,
      "x": 25651,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 60305,
      "e": 59984,
      "ty": 2,
      "x": 1150,
      "y": 953
    },
    {
      "t": 60405,
      "e": 60084,
      "ty": 2,
      "x": 1153,
      "y": 951
    },
    {
      "t": 60506,
      "e": 60185,
      "ty": 41,
      "x": 25862,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 63805,
      "e": 63484,
      "ty": 2,
      "x": 1154,
      "y": 951
    },
    {
      "t": 63906,
      "e": 63585,
      "ty": 2,
      "x": 1162,
      "y": 960
    },
    {
      "t": 64006,
      "e": 63685,
      "ty": 41,
      "x": 26496,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 64105,
      "e": 63784,
      "ty": 2,
      "x": 1162,
      "y": 961
    },
    {
      "t": 64205,
      "e": 63884,
      "ty": 2,
      "x": 1158,
      "y": 974
    },
    {
      "t": 64256,
      "e": 63935,
      "ty": 41,
      "x": 40610,
      "y": 33023,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 64305,
      "e": 63984,
      "ty": 2,
      "x": 1158,
      "y": 977
    },
    {
      "t": 64405,
      "e": 64084,
      "ty": 2,
      "x": 1156,
      "y": 977
    },
    {
      "t": 64505,
      "e": 64184,
      "ty": 2,
      "x": 1155,
      "y": 971
    },
    {
      "t": 64506,
      "e": 64185,
      "ty": 41,
      "x": 35750,
      "y": 8447,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 64606,
      "e": 64285,
      "ty": 2,
      "x": 1155,
      "y": 940
    },
    {
      "t": 64705,
      "e": 64384,
      "ty": 2,
      "x": 1152,
      "y": 932
    },
    {
      "t": 64756,
      "e": 64435,
      "ty": 41,
      "x": 25792,
      "y": 56224,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 64806,
      "e": 64485,
      "ty": 2,
      "x": 1151,
      "y": 915
    },
    {
      "t": 64905,
      "e": 64584,
      "ty": 2,
      "x": 1153,
      "y": 896
    },
    {
      "t": 65005,
      "e": 64684,
      "ty": 2,
      "x": 1152,
      "y": 833
    },
    {
      "t": 65005,
      "e": 64684,
      "ty": 41,
      "x": 25792,
      "y": 49777,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65105,
      "e": 64784,
      "ty": 2,
      "x": 1135,
      "y": 754
    },
    {
      "t": 65205,
      "e": 64884,
      "ty": 2,
      "x": 1135,
      "y": 745
    },
    {
      "t": 65255,
      "e": 64934,
      "ty": 41,
      "x": 24946,
      "y": 42973,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65306,
      "e": 64985,
      "ty": 2,
      "x": 1141,
      "y": 733
    },
    {
      "t": 65405,
      "e": 65084,
      "ty": 2,
      "x": 1147,
      "y": 712
    },
    {
      "t": 65506,
      "e": 65185,
      "ty": 2,
      "x": 1147,
      "y": 694
    },
    {
      "t": 65506,
      "e": 65185,
      "ty": 41,
      "x": 25439,
      "y": 39822,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65606,
      "e": 65285,
      "ty": 2,
      "x": 1148,
      "y": 667
    },
    {
      "t": 65706,
      "e": 65385,
      "ty": 2,
      "x": 1129,
      "y": 607
    },
    {
      "t": 65756,
      "e": 65435,
      "ty": 41,
      "x": 15010,
      "y": 27216,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65806,
      "e": 65485,
      "ty": 2,
      "x": 902,
      "y": 499
    },
    {
      "t": 65905,
      "e": 65584,
      "ty": 2,
      "x": 851,
      "y": 538
    },
    {
      "t": 66005,
      "e": 65684,
      "ty": 2,
      "x": 747,
      "y": 584
    },
    {
      "t": 66006,
      "e": 65685,
      "ty": 41,
      "x": 3840,
      "y": 31666,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 66032,
      "e": 65711,
      "ty": 6,
      "x": 665,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66105,
      "e": 65784,
      "ty": 2,
      "x": 644,
      "y": 576
    },
    {
      "t": 66205,
      "e": 65884,
      "ty": 2,
      "x": 644,
      "y": 568
    },
    {
      "t": 66256,
      "e": 65935,
      "ty": 41,
      "x": 62039,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66306,
      "e": 65985,
      "ty": 2,
      "x": 652,
      "y": 559
    },
    {
      "t": 66406,
      "e": 66085,
      "ty": 2,
      "x": 652,
      "y": 558
    },
    {
      "t": 66505,
      "e": 66184,
      "ty": 41,
      "x": 62376,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67000,
      "e": 66679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67054,
      "e": 66733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which dots fall in that line"
    },
    {
      "t": 67599,
      "e": 67278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67600,
      "e": 67279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67679,
      "e": 67358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67831,
      "e": 67510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 67832,
      "e": 67511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67886,
      "e": 67565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 67918,
      "e": 67597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67918,
      "e": 67597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67990,
      "e": 67669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 68103,
      "e": 67782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68104,
      "e": 67783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68206,
      "e": 67885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 68207,
      "e": 67886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68271,
      "e": 67887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 68318,
      "e": 67934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68398,
      "e": 68014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 68399,
      "e": 68015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68478,
      "e": 68094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 68526,
      "e": 68142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68526,
      "e": 68142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68590,
      "e": 68206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68710,
      "e": 68326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 68712,
      "e": 68328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68766,
      "e": 68382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 68862,
      "e": 68478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 68862,
      "e": 68478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68943,
      "e": 68559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 69199,
      "e": 68815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 69199,
      "e": 68815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69294,
      "e": 68910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 70206,
      "e": 69822,
      "ty": 2,
      "x": 440,
      "y": 603
    },
    {
      "t": 70218,
      "e": 69834,
      "ty": 7,
      "x": 430,
      "y": 619,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70256,
      "e": 69872,
      "ty": 41,
      "x": 49341,
      "y": 3450,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 70306,
      "e": 69922,
      "ty": 2,
      "x": 424,
      "y": 627
    },
    {
      "t": 70386,
      "e": 70002,
      "ty": 6,
      "x": 402,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 70405,
      "e": 70021,
      "ty": 2,
      "x": 400,
      "y": 669
    },
    {
      "t": 70506,
      "e": 70122,
      "ty": 41,
      "x": 33535,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 70606,
      "e": 70222,
      "ty": 2,
      "x": 400,
      "y": 677
    },
    {
      "t": 70675,
      "e": 70291,
      "ty": 3,
      "x": 400,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 70677,
      "e": 70293,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which dots fall in that line going up."
    },
    {
      "t": 70678,
      "e": 70294,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70678,
      "e": 70294,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 70756,
      "e": 70372,
      "ty": 41,
      "x": 33535,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 70786,
      "e": 70402,
      "ty": 4,
      "x": 33535,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 70797,
      "e": 70413,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 70798,
      "e": 70414,
      "ty": 5,
      "x": 400,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 70804,
      "e": 70420,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 71205,
      "e": 70821,
      "ty": 2,
      "x": 405,
      "y": 679
    },
    {
      "t": 71256,
      "e": 70872,
      "ty": 41,
      "x": 14704,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 71306,
      "e": 70922,
      "ty": 2,
      "x": 461,
      "y": 682
    },
    {
      "t": 71406,
      "e": 71022,
      "ty": 2,
      "x": 689,
      "y": 744
    },
    {
      "t": 71506,
      "e": 71122,
      "ty": 2,
      "x": 869,
      "y": 821
    },
    {
      "t": 71506,
      "e": 71122,
      "ty": 41,
      "x": 29650,
      "y": 45038,
      "ta": "html > body"
    },
    {
      "t": 71606,
      "e": 71222,
      "ty": 2,
      "x": 945,
      "y": 854
    },
    {
      "t": 71706,
      "e": 71322,
      "ty": 2,
      "x": 953,
      "y": 857
    },
    {
      "t": 71756,
      "e": 71372,
      "ty": 41,
      "x": 32578,
      "y": 47143,
      "ta": "html > body"
    },
    {
      "t": 71805,
      "e": 71421,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 71811,
      "e": 71427,
      "ty": 2,
      "x": 954,
      "y": 859
    },
    {
      "t": 72004,
      "e": 71620,
      "ty": 2,
      "x": 956,
      "y": 852
    },
    {
      "t": 72005,
      "e": 71621,
      "ty": 41,
      "x": 32646,
      "y": 46755,
      "ta": "html > body"
    },
    {
      "t": 72105,
      "e": 71721,
      "ty": 2,
      "x": 962,
      "y": 791
    },
    {
      "t": 72206,
      "e": 71822,
      "ty": 2,
      "x": 969,
      "y": 771
    },
    {
      "t": 72253,
      "e": 71869,
      "ty": 6,
      "x": 997,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72255,
      "e": 71871,
      "ty": 41,
      "x": 52094,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72271,
      "e": 71887,
      "ty": 7,
      "x": 1001,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72314,
      "e": 71930,
      "ty": 2,
      "x": 1000,
      "y": 591
    },
    {
      "t": 72405,
      "e": 72021,
      "ty": 2,
      "x": 989,
      "y": 449
    },
    {
      "t": 72506,
      "e": 72122,
      "ty": 2,
      "x": 989,
      "y": 459
    },
    {
      "t": 72506,
      "e": 72122,
      "ty": 41,
      "x": 33783,
      "y": 24984,
      "ta": "html > body"
    },
    {
      "t": 72605,
      "e": 72221,
      "ty": 2,
      "x": 984,
      "y": 543
    },
    {
      "t": 72705,
      "e": 72321,
      "ty": 2,
      "x": 983,
      "y": 545
    },
    {
      "t": 72755,
      "e": 72371,
      "ty": 6,
      "x": 981,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72757,
      "e": 72373,
      "ty": 41,
      "x": 37417,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72806,
      "e": 72422,
      "ty": 2,
      "x": 977,
      "y": 562
    },
    {
      "t": 72906,
      "e": 72522,
      "ty": 2,
      "x": 974,
      "y": 568
    },
    {
      "t": 72963,
      "e": 72579,
      "ty": 3,
      "x": 974,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72964,
      "e": 72580,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73005,
      "e": 72621,
      "ty": 41,
      "x": 35903,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73050,
      "e": 72666,
      "ty": 4,
      "x": 35903,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73050,
      "e": 72666,
      "ty": 5,
      "x": 974,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73205,
      "e": 72821,
      "ty": 2,
      "x": 974,
      "y": 569
    },
    {
      "t": 73255,
      "e": 72871,
      "ty": 41,
      "x": 35903,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73990,
      "e": 73606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 73991,
      "e": 73607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74054,
      "e": 73670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 74118,
      "e": 73734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 74119,
      "e": 73735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74190,
      "e": 73806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 74518,
      "e": 74134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 74518,
      "e": 74134,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 74519,
      "e": 74135,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74519,
      "e": 74135,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74598,
      "e": 74214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 75623,
      "e": 75239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 75702,
      "e": 75318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 75750,
      "e": 75366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 75752,
      "e": 75368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75815,
      "e": 75431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 75816,
      "e": 75432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 75887,
      "e": 75503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 75942,
      "e": 75558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 75943,
      "e": 75559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75950,
      "e": 75566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 75951,
      "e": 75567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75974,
      "e": 75590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un "
    },
    {
      "t": 75998,
      "e": 75614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un "
    },
    {
      "t": 76086,
      "e": 75702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 76086,
      "e": 75702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76166,
      "e": 75782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un i"
    },
    {
      "t": 76303,
      "e": 75919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 76304,
      "e": 75920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76382,
      "e": 75998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 76438,
      "e": 76054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 76439,
      "e": 76055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76494,
      "e": 76110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 76494,
      "e": 76110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76535,
      "e": 76110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ed"
    },
    {
      "t": 76607,
      "e": 76182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 77166,
      "e": 76741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 77223,
      "e": 76798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un ite"
    },
    {
      "t": 77303,
      "e": 76878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 77367,
      "e": 76942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un it"
    },
    {
      "t": 77455,
      "e": 77030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 77518,
      "e": 77093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un i"
    },
    {
      "t": 77599,
      "e": 77174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 77662,
      "e": 77237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un "
    },
    {
      "t": 77742,
      "e": 77317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 77806,
      "e": 77381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 78522,
      "e": 78097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 78522,
      "e": 78097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78598,
      "e": 78173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 78726,
      "e": 78301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 78727,
      "e": 78302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78798,
      "e": 78373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 78879,
      "e": 78454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 78879,
      "e": 78454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78910,
      "e": 78485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 78910,
      "e": 78485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78942,
      "e": 78517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ed"
    },
    {
      "t": 79023,
      "e": 78598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 79110,
      "e": 78685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 79111,
      "e": 78686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79174,
      "e": 78749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 79222,
      "e": 78797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 79351,
      "e": 78926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 79351,
      "e": 78926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79382,
      "e": 78957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 79494,
      "e": 79069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 79526,
      "e": 79101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 79606,
      "e": 79181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 79608,
      "e": 79183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79630,
      "e": 79205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 79678,
      "e": 79253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 79807,
      "e": 79382,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United At"
    },
    {
      "t": 80182,
      "e": 79757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 80238,
      "e": 79813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United A"
    },
    {
      "t": 80344,
      "e": 79919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 80381,
      "e": 79956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United "
    },
    {
      "t": 80398,
      "e": 79973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 80550,
      "e": 80125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 80887,
      "e": 80462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 80887,
      "e": 80462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80950,
      "e": 80525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 81030,
      "e": 80605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 81119,
      "e": 80694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81143,
      "e": 80718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81143,
      "e": 80718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81198,
      "e": 80773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 81238,
      "e": 80813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 81239,
      "e": 80814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81302,
      "e": 80877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 81327,
      "e": 80902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81327,
      "e": 80902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81390,
      "e": 80965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 81455,
      "e": 81030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 81455,
      "e": 81030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81470,
      "e": 81045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "87"
    },
    {
      "t": 81470,
      "e": 81045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81502,
      "e": 81077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ew"
    },
    {
      "t": 81510,
      "e": 81085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81647,
      "e": 81222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 81647,
      "e": 81222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81734,
      "e": 81309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 82087,
      "e": 81662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 82143,
      "e": 81718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Statew"
    },
    {
      "t": 82222,
      "e": 81797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 82223,
      "e": 81798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82225,
      "e": 81800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 82254,
      "e": 81829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82279,
      "e": 81854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82855,
      "e": 82430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 82934,
      "e": 82509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United State"
    },
    {
      "t": 82950,
      "e": 82525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 82952,
      "e": 82527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83006,
      "e": 82581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 83271,
      "e": 82846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 83272,
      "e": 82847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83373,
      "e": 82948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 83574,
      "e": 83149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 83575,
      "e": 83150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83629,
      "e": 83204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 83758,
      "e": 83333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 83758,
      "e": 83333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83831,
      "e": 83406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 84151,
      "e": 83726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 84261,
      "e": 83836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States o"
    },
    {
      "t": 84294,
      "e": 83869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 84294,
      "e": 83869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84374,
      "e": 83949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 84647,
      "e": 84222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 84647,
      "e": 84222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84733,
      "e": 84308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 84782,
      "e": 84357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 84934,
      "e": 84509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 84936,
      "e": 84511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85110,
      "e": 84685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 85134,
      "e": 84709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 85390,
      "e": 84965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 85486,
      "e": 85061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 85750,
      "e": 85325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 85751,
      "e": 85326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85822,
      "e": 85397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 85838,
      "e": 85413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 85838,
      "e": 85413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85934,
      "e": 85509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 85935,
      "e": 85510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85991,
      "e": 85566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 86038,
      "e": 85613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 86111,
      "e": 85686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 86111,
      "e": 85686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86189,
      "e": 85764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 86222,
      "e": 85797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 86222,
      "e": 85797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86334,
      "e": 85909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 86375,
      "e": 85950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 86375,
      "e": 85950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86479,
      "e": 85951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 87306,
      "e": 86778,
      "ty": 2,
      "x": 976,
      "y": 569
    },
    {
      "t": 87317,
      "e": 86789,
      "ty": 7,
      "x": 1000,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87406,
      "e": 86878,
      "ty": 2,
      "x": 1328,
      "y": 664
    },
    {
      "t": 87505,
      "e": 86977,
      "ty": 2,
      "x": 1313,
      "y": 696
    },
    {
      "t": 87506,
      "e": 86978,
      "ty": 41,
      "x": 44941,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 87605,
      "e": 87077,
      "ty": 2,
      "x": 1151,
      "y": 742
    },
    {
      "t": 87705,
      "e": 87177,
      "ty": 2,
      "x": 1064,
      "y": 755
    },
    {
      "t": 87756,
      "e": 87228,
      "ty": 41,
      "x": 35436,
      "y": 41160,
      "ta": "html > body"
    },
    {
      "t": 87806,
      "e": 87278,
      "ty": 2,
      "x": 1009,
      "y": 742
    },
    {
      "t": 87905,
      "e": 87377,
      "ty": 2,
      "x": 978,
      "y": 717
    },
    {
      "t": 88005,
      "e": 87477,
      "ty": 41,
      "x": 33404,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 88105,
      "e": 87577,
      "ty": 2,
      "x": 977,
      "y": 716
    },
    {
      "t": 88206,
      "e": 87678,
      "ty": 2,
      "x": 975,
      "y": 709
    },
    {
      "t": 88217,
      "e": 87689,
      "ty": 6,
      "x": 974,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88256,
      "e": 87728,
      "ty": 41,
      "x": 40240,
      "y": 63549,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88305,
      "e": 87777,
      "ty": 2,
      "x": 973,
      "y": 707
    },
    {
      "t": 88505,
      "e": 87977,
      "ty": 2,
      "x": 967,
      "y": 704
    },
    {
      "t": 88506,
      "e": 87978,
      "ty": 41,
      "x": 36632,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88606,
      "e": 88078,
      "ty": 2,
      "x": 968,
      "y": 684
    },
    {
      "t": 88755,
      "e": 88227,
      "ty": 41,
      "x": 37148,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90180,
      "e": 89652,
      "ty": 3,
      "x": 968,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90181,
      "e": 89653,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 90181,
      "e": 89653,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90182,
      "e": 89654,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90298,
      "e": 89770,
      "ty": 4,
      "x": 37148,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90298,
      "e": 89770,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90299,
      "e": 89771,
      "ty": 5,
      "x": 968,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90299,
      "e": 89771,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 91006,
      "e": 90478,
      "ty": 2,
      "x": 1090,
      "y": 657
    },
    {
      "t": 91006,
      "e": 90478,
      "ty": 41,
      "x": 37261,
      "y": 35952,
      "ta": "html > body"
    },
    {
      "t": 91105,
      "e": 90577,
      "ty": 2,
      "x": 1721,
      "y": 632
    },
    {
      "t": 91206,
      "e": 90678,
      "ty": 2,
      "x": 1697,
      "y": 623
    },
    {
      "t": 91256,
      "e": 90728,
      "ty": 41,
      "x": 50692,
      "y": 32684,
      "ta": "html > body"
    },
    {
      "t": 91313,
      "e": 90785,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 91319,
      "e": 90791,
      "ty": 2,
      "x": 1205,
      "y": 635
    },
    {
      "t": 91405,
      "e": 90877,
      "ty": 2,
      "x": 1194,
      "y": 644
    },
    {
      "t": 91506,
      "e": 90978,
      "ty": 41,
      "x": 40843,
      "y": 35232,
      "ta": "html > body"
    },
    {
      "t": 91706,
      "e": 91178,
      "ty": 2,
      "x": 1182,
      "y": 627
    },
    {
      "t": 91755,
      "e": 91227,
      "ty": 41,
      "x": 58044,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 91809,
      "e": 91281,
      "ty": 2,
      "x": 988,
      "y": 399
    },
    {
      "t": 91905,
      "e": 91377,
      "ty": 2,
      "x": 982,
      "y": 287
    },
    {
      "t": 92005,
      "e": 91477,
      "ty": 2,
      "x": 900,
      "y": 233
    },
    {
      "t": 92005,
      "e": 91477,
      "ty": 41,
      "x": 64345,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 92106,
      "e": 91578,
      "ty": 2,
      "x": 844,
      "y": 209
    },
    {
      "t": 92256,
      "e": 91728,
      "ty": 41,
      "x": 5832,
      "y": 14102,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 92305,
      "e": 91777,
      "ty": 2,
      "x": 849,
      "y": 214
    },
    {
      "t": 92406,
      "e": 91878,
      "ty": 2,
      "x": 849,
      "y": 218
    },
    {
      "t": 92505,
      "e": 91977,
      "ty": 2,
      "x": 841,
      "y": 231
    },
    {
      "t": 92505,
      "e": 91977,
      "ty": 41,
      "x": 16031,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 92521,
      "e": 91993,
      "ty": 6,
      "x": 836,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92606,
      "e": 92078,
      "ty": 2,
      "x": 829,
      "y": 242
    },
    {
      "t": 92756,
      "e": 92228,
      "ty": 41,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92811,
      "e": 92283,
      "ty": 3,
      "x": 829,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92812,
      "e": 92284,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92921,
      "e": 92393,
      "ty": 4,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92922,
      "e": 92394,
      "ty": 5,
      "x": 829,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92923,
      "e": 92395,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 93406,
      "e": 92878,
      "ty": 2,
      "x": 829,
      "y": 244
    },
    {
      "t": 93506,
      "e": 92978,
      "ty": 41,
      "x": 12996,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94372,
      "e": 93844,
      "ty": 7,
      "x": 836,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94405,
      "e": 93877,
      "ty": 2,
      "x": 845,
      "y": 256
    },
    {
      "t": 94504,
      "e": 93976,
      "ty": 2,
      "x": 846,
      "y": 258
    },
    {
      "t": 94505,
      "e": 93977,
      "ty": 41,
      "x": 18719,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 94605,
      "e": 94077,
      "ty": 2,
      "x": 843,
      "y": 261
    },
    {
      "t": 94606,
      "e": 94078,
      "ty": 6,
      "x": 836,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 94657,
      "e": 94129,
      "ty": 7,
      "x": 825,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 94705,
      "e": 94177,
      "ty": 2,
      "x": 824,
      "y": 270
    },
    {
      "t": 94756,
      "e": 94228,
      "ty": 41,
      "x": 1963,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 94788,
      "e": 94260,
      "ty": 6,
      "x": 829,
      "y": 272,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 94805,
      "e": 94277,
      "ty": 2,
      "x": 829,
      "y": 272
    },
    {
      "t": 94806,
      "e": 94278,
      "ty": 7,
      "x": 835,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 94904,
      "e": 94376,
      "ty": 2,
      "x": 849,
      "y": 294
    },
    {
      "t": 95005,
      "e": 94477,
      "ty": 2,
      "x": 868,
      "y": 363
    },
    {
      "t": 95005,
      "e": 94477,
      "ty": 41,
      "x": 11054,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 95105,
      "e": 94577,
      "ty": 2,
      "x": 888,
      "y": 397
    },
    {
      "t": 95205,
      "e": 94677,
      "ty": 2,
      "x": 894,
      "y": 404
    },
    {
      "t": 95255,
      "e": 94727,
      "ty": 41,
      "x": 15325,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 95305,
      "e": 94777,
      "ty": 2,
      "x": 865,
      "y": 418
    },
    {
      "t": 95406,
      "e": 94779,
      "ty": 2,
      "x": 854,
      "y": 422
    },
    {
      "t": 95505,
      "e": 94878,
      "ty": 2,
      "x": 829,
      "y": 428
    },
    {
      "t": 95505,
      "e": 94878,
      "ty": 41,
      "x": 1798,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 95605,
      "e": 94978,
      "ty": 2,
      "x": 818,
      "y": 430
    },
    {
      "t": 95705,
      "e": 95078,
      "ty": 2,
      "x": 813,
      "y": 430
    },
    {
      "t": 95755,
      "e": 95128,
      "ty": 41,
      "x": 27756,
      "y": 23156,
      "ta": "html > body"
    },
    {
      "t": 95804,
      "e": 95177,
      "ty": 2,
      "x": 821,
      "y": 422
    },
    {
      "t": 95857,
      "e": 95230,
      "ty": 6,
      "x": 828,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 95905,
      "e": 95278,
      "ty": 2,
      "x": 834,
      "y": 414
    },
    {
      "t": 96005,
      "e": 95378,
      "ty": 2,
      "x": 835,
      "y": 414
    },
    {
      "t": 96005,
      "e": 95378,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96105,
      "e": 95478,
      "ty": 2,
      "x": 835,
      "y": 412
    },
    {
      "t": 96256,
      "e": 95629,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96505,
      "e": 95878,
      "ty": 2,
      "x": 834,
      "y": 412
    },
    {
      "t": 96505,
      "e": 95878,
      "ty": 41,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96955,
      "e": 96328,
      "ty": 3,
      "x": 834,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96956,
      "e": 96329,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 96956,
      "e": 96329,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97059,
      "e": 96432,
      "ty": 4,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97059,
      "e": 96432,
      "ty": 5,
      "x": 834,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97060,
      "e": 96433,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 97174,
      "e": 96547,
      "ty": 7,
      "x": 845,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97205,
      "e": 96578,
      "ty": 2,
      "x": 861,
      "y": 428
    },
    {
      "t": 97255,
      "e": 96628,
      "ty": 41,
      "x": 20547,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 97305,
      "e": 96678,
      "ty": 2,
      "x": 979,
      "y": 578
    },
    {
      "t": 97405,
      "e": 96778,
      "ty": 2,
      "x": 987,
      "y": 595
    },
    {
      "t": 97505,
      "e": 96878,
      "ty": 2,
      "x": 955,
      "y": 643
    },
    {
      "t": 97505,
      "e": 96878,
      "ty": 41,
      "x": 31701,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 97605,
      "e": 96978,
      "ty": 2,
      "x": 947,
      "y": 650
    },
    {
      "t": 97705,
      "e": 97078,
      "ty": 2,
      "x": 922,
      "y": 651
    },
    {
      "t": 97755,
      "e": 97128,
      "ty": 41,
      "x": 20072,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 97805,
      "e": 97178,
      "ty": 2,
      "x": 899,
      "y": 654
    },
    {
      "t": 97905,
      "e": 97278,
      "ty": 2,
      "x": 888,
      "y": 664
    },
    {
      "t": 98005,
      "e": 97378,
      "ty": 2,
      "x": 853,
      "y": 680
    },
    {
      "t": 98005,
      "e": 97378,
      "ty": 41,
      "x": 8478,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 98105,
      "e": 97478,
      "ty": 2,
      "x": 842,
      "y": 685
    },
    {
      "t": 98205,
      "e": 97578,
      "ty": 2,
      "x": 842,
      "y": 686
    },
    {
      "t": 98255,
      "e": 97628,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 98308,
      "e": 97681,
      "ty": 2,
      "x": 841,
      "y": 688
    },
    {
      "t": 98408,
      "e": 97781,
      "ty": 2,
      "x": 839,
      "y": 688
    },
    {
      "t": 98508,
      "e": 97881,
      "ty": 41,
      "x": 4171,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 98579,
      "e": 97952,
      "ty": 6,
      "x": 838,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 98608,
      "e": 97981,
      "ty": 2,
      "x": 837,
      "y": 703
    },
    {
      "t": 98686,
      "e": 98059,
      "ty": 7,
      "x": 836,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 98708,
      "e": 98081,
      "ty": 2,
      "x": 835,
      "y": 711
    },
    {
      "t": 98758,
      "e": 98131,
      "ty": 41,
      "x": 2510,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 98794,
      "e": 98167,
      "ty": 6,
      "x": 829,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98808,
      "e": 98181,
      "ty": 2,
      "x": 829,
      "y": 729
    },
    {
      "t": 98828,
      "e": 98201,
      "ty": 7,
      "x": 829,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98908,
      "e": 98281,
      "ty": 2,
      "x": 829,
      "y": 751
    },
    {
      "t": 98911,
      "e": 98284,
      "ty": 6,
      "x": 829,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 98979,
      "e": 98352,
      "ty": 7,
      "x": 829,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 99008,
      "e": 98381,
      "ty": 2,
      "x": 829,
      "y": 767
    },
    {
      "t": 99008,
      "e": 98381,
      "ty": 41,
      "x": 3162,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 99079,
      "e": 98382,
      "ty": 6,
      "x": 829,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 99108,
      "e": 98411,
      "ty": 2,
      "x": 829,
      "y": 784
    },
    {
      "t": 99145,
      "e": 98448,
      "ty": 7,
      "x": 829,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 99208,
      "e": 98511,
      "ty": 2,
      "x": 829,
      "y": 804
    },
    {
      "t": 99211,
      "e": 98514,
      "ty": 6,
      "x": 829,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 99258,
      "e": 98561,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 99308,
      "e": 98611,
      "ty": 2,
      "x": 829,
      "y": 820
    },
    {
      "t": 99509,
      "e": 98812,
      "ty": 41,
      "x": 12996,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 99726,
      "e": 99029,
      "ty": 7,
      "x": 829,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 99758,
      "e": 99061,
      "ty": 41,
      "x": 4472,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 99809,
      "e": 99112,
      "ty": 2,
      "x": 830,
      "y": 825
    },
    {
      "t": 99908,
      "e": 99211,
      "ty": 2,
      "x": 831,
      "y": 832
    },
    {
      "t": 100008,
      "e": 99311,
      "ty": 2,
      "x": 832,
      "y": 833
    },
    {
      "t": 100009,
      "e": 99312,
      "ty": 41,
      "x": 7452,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 100030,
      "e": 99333,
      "ty": 6,
      "x": 833,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100108,
      "e": 99411,
      "ty": 2,
      "x": 833,
      "y": 842
    },
    {
      "t": 100208,
      "e": 99511,
      "ty": 2,
      "x": 833,
      "y": 847
    },
    {
      "t": 100259,
      "e": 99562,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100508,
      "e": 99811,
      "ty": 2,
      "x": 831,
      "y": 847
    },
    {
      "t": 100509,
      "e": 99812,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100567,
      "e": 99870,
      "ty": 3,
      "x": 831,
      "y": 847,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100567,
      "e": 99870,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 100569,
      "e": 99872,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100653,
      "e": 99956,
      "ty": 4,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100653,
      "e": 99956,
      "ty": 5,
      "x": 831,
      "y": 847,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100654,
      "e": 99957,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf",
      "v": "Fine Arts"
    },
    {
      "t": 100847,
      "e": 100150,
      "ty": 7,
      "x": 845,
      "y": 861,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 100908,
      "e": 100211,
      "ty": 2,
      "x": 858,
      "y": 895
    },
    {
      "t": 101008,
      "e": 100311,
      "ty": 2,
      "x": 851,
      "y": 939
    },
    {
      "t": 101008,
      "e": 100311,
      "ty": 41,
      "x": 32306,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 101108,
      "e": 100411,
      "ty": 2,
      "x": 842,
      "y": 952
    },
    {
      "t": 101197,
      "e": 100500,
      "ty": 6,
      "x": 838,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 101208,
      "e": 100511,
      "ty": 2,
      "x": 838,
      "y": 957
    },
    {
      "t": 101258,
      "e": 100561,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 101308,
      "e": 100611,
      "ty": 2,
      "x": 838,
      "y": 961
    },
    {
      "t": 101381,
      "e": 100684,
      "ty": 7,
      "x": 840,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 101408,
      "e": 100711,
      "ty": 2,
      "x": 840,
      "y": 958
    },
    {
      "t": 101508,
      "e": 100811,
      "ty": 2,
      "x": 845,
      "y": 947
    },
    {
      "t": 101508,
      "e": 100811,
      "ty": 41,
      "x": 5595,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 101608,
      "e": 100911,
      "ty": 2,
      "x": 858,
      "y": 948
    },
    {
      "t": 101708,
      "e": 101011,
      "ty": 2,
      "x": 860,
      "y": 951
    },
    {
      "t": 101758,
      "e": 101061,
      "ty": 41,
      "x": 7494,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 101808,
      "e": 101111,
      "ty": 2,
      "x": 847,
      "y": 953
    },
    {
      "t": 101908,
      "e": 101211,
      "ty": 2,
      "x": 841,
      "y": 956
    },
    {
      "t": 101932,
      "e": 101235,
      "ty": 6,
      "x": 838,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102008,
      "e": 101311,
      "ty": 2,
      "x": 831,
      "y": 959
    },
    {
      "t": 102008,
      "e": 101311,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102109,
      "e": 101412,
      "ty": 3,
      "x": 831,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102109,
      "e": 101412,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 102109,
      "e": 101412,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102180,
      "e": 101483,
      "ty": 4,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102181,
      "e": 101484,
      "ty": 5,
      "x": 831,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102182,
      "e": 101485,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 102253,
      "e": 101556,
      "ty": 7,
      "x": 843,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102258,
      "e": 101561,
      "ty": 41,
      "x": 17454,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102308,
      "e": 101611,
      "ty": 2,
      "x": 984,
      "y": 1008
    },
    {
      "t": 102408,
      "e": 101711,
      "ty": 2,
      "x": 1016,
      "y": 1033
    },
    {
      "t": 102508,
      "e": 101811,
      "ty": 2,
      "x": 972,
      "y": 1036
    },
    {
      "t": 102509,
      "e": 101812,
      "ty": 41,
      "x": 35735,
      "y": 65385,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102608,
      "e": 101911,
      "ty": 2,
      "x": 937,
      "y": 1043
    },
    {
      "t": 102758,
      "e": 102061,
      "ty": 41,
      "x": 31923,
      "y": 57114,
      "ta": "html > body"
    },
    {
      "t": 102766,
      "e": 102069,
      "ty": 6,
      "x": 934,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102808,
      "e": 102111,
      "ty": 2,
      "x": 925,
      "y": 1024
    },
    {
      "t": 103009,
      "e": 102312,
      "ty": 41,
      "x": 49259,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104367,
      "e": 103670,
      "ty": 3,
      "x": 925,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104368,
      "e": 103671,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 104368,
      "e": 103671,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104470,
      "e": 103773,
      "ty": 4,
      "x": 49259,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104471,
      "e": 103774,
      "ty": 5,
      "x": 925,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104474,
      "e": 103777,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104475,
      "e": 103778,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 104475,
      "e": 103778,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 104608,
      "e": 103911,
      "ty": 2,
      "x": 925,
      "y": 1023
    },
    {
      "t": 104759,
      "e": 104062,
      "ty": 41,
      "x": 31579,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 105109,
      "e": 104412,
      "ty": 2,
      "x": 924,
      "y": 1023
    },
    {
      "t": 105259,
      "e": 104562,
      "ty": 41,
      "x": 31544,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 105758,
      "e": 105061,
      "ty": 41,
      "x": 31544,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 105808,
      "e": 105111,
      "ty": 2,
      "x": 924,
      "y": 1022
    },
    {
      "t": 105824,
      "e": 105127,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 105908,
      "e": 105211,
      "ty": 2,
      "x": 924,
      "y": 1021
    },
    {
      "t": 106009,
      "e": 105312,
      "ty": 2,
      "x": 988,
      "y": 977
    },
    {
      "t": 106009,
      "e": 105312,
      "ty": 41,
      "x": 34169,
      "y": 58908,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106109,
      "e": 105412,
      "ty": 2,
      "x": 1115,
      "y": 886
    },
    {
      "t": 106209,
      "e": 105512,
      "ty": 2,
      "x": 956,
      "y": 692
    },
    {
      "t": 106258,
      "e": 105561,
      "ty": 41,
      "x": 24772,
      "y": 44671,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106308,
      "e": 105611,
      "ty": 2,
      "x": 787,
      "y": 591
    },
    {
      "t": 106408,
      "e": 105711,
      "ty": 2,
      "x": 708,
      "y": 549
    },
    {
      "t": 106508,
      "e": 105811,
      "ty": 2,
      "x": 526,
      "y": 416
    },
    {
      "t": 106508,
      "e": 105811,
      "ty": 41,
      "x": 11440,
      "y": 27708,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 106609,
      "e": 105912,
      "ty": 2,
      "x": 423,
      "y": 369
    },
    {
      "t": 106708,
      "e": 106011,
      "ty": 2,
      "x": 355,
      "y": 331
    },
    {
      "t": 106759,
      "e": 106062,
      "ty": 41,
      "x": 6324,
      "y": 12651,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106809,
      "e": 106112,
      "ty": 2,
      "x": 589,
      "y": 330
    },
    {
      "t": 106908,
      "e": 106211,
      "ty": 2,
      "x": 719,
      "y": 357
    },
    {
      "t": 107008,
      "e": 106311,
      "ty": 2,
      "x": 717,
      "y": 357
    },
    {
      "t": 107008,
      "e": 106311,
      "ty": 41,
      "x": 20837,
      "y": 52698,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 107108,
      "e": 106411,
      "ty": 2,
      "x": 571,
      "y": 373
    },
    {
      "t": 107209,
      "e": 106512,
      "ty": 2,
      "x": 552,
      "y": 465
    },
    {
      "t": 107258,
      "e": 106561,
      "ty": 41,
      "x": 14490,
      "y": 4102,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 107308,
      "e": 106611,
      "ty": 2,
      "x": 607,
      "y": 506
    },
    {
      "t": 107409,
      "e": 106712,
      "ty": 2,
      "x": 628,
      "y": 481
    },
    {
      "t": 107509,
      "e": 106812,
      "ty": 2,
      "x": 590,
      "y": 453
    },
    {
      "t": 107509,
      "e": 106812,
      "ty": 41,
      "x": 14589,
      "y": 56575,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 107608,
      "e": 106911,
      "ty": 2,
      "x": 593,
      "y": 499
    },
    {
      "t": 107708,
      "e": 107011,
      "ty": 2,
      "x": 659,
      "y": 488
    },
    {
      "t": 107758,
      "e": 107061,
      "ty": 41,
      "x": 18672,
      "y": 63596,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 107808,
      "e": 107111,
      "ty": 2,
      "x": 669,
      "y": 454
    },
    {
      "t": 107908,
      "e": 107211,
      "ty": 2,
      "x": 642,
      "y": 432
    },
    {
      "t": 108009,
      "e": 107312,
      "ty": 2,
      "x": 753,
      "y": 403
    },
    {
      "t": 108009,
      "e": 107312,
      "ty": 41,
      "x": 22608,
      "y": 17566,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 108109,
      "e": 107412,
      "ty": 2,
      "x": 885,
      "y": 394
    },
    {
      "t": 108209,
      "e": 107512,
      "ty": 2,
      "x": 1004,
      "y": 469
    },
    {
      "t": 108259,
      "e": 107562,
      "ty": 41,
      "x": 33677,
      "y": 39505,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108309,
      "e": 107612,
      "ty": 2,
      "x": 912,
      "y": 995
    },
    {
      "t": 108408,
      "e": 107711,
      "ty": 2,
      "x": 875,
      "y": 1056
    },
    {
      "t": 108509,
      "e": 107812,
      "ty": 2,
      "x": 849,
      "y": 1108
    },
    {
      "t": 108509,
      "e": 107812,
      "ty": 41,
      "x": 28962,
      "y": 60937,
      "ta": "> div.masterdiv"
    },
    {
      "t": 108608,
      "e": 107911,
      "ty": 2,
      "x": 889,
      "y": 1127
    },
    {
      "t": 108708,
      "e": 108011,
      "ty": 2,
      "x": 936,
      "y": 1145
    },
    {
      "t": 108758,
      "e": 108061,
      "ty": 41,
      "x": 27852,
      "y": 36736,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 108808,
      "e": 108111,
      "ty": 2,
      "x": 957,
      "y": 1133
    },
    {
      "t": 108909,
      "e": 108212,
      "ty": 2,
      "x": 964,
      "y": 1115
    },
    {
      "t": 108954,
      "e": 108257,
      "ty": 6,
      "x": 964,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 109008,
      "e": 108311,
      "ty": 2,
      "x": 963,
      "y": 1090
    },
    {
      "t": 109008,
      "e": 108311,
      "ty": 41,
      "x": 29217,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 109109,
      "e": 108412,
      "ty": 2,
      "x": 963,
      "y": 1088
    },
    {
      "t": 109237,
      "e": 108540,
      "ty": 3,
      "x": 963,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 109237,
      "e": 108540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 109259,
      "e": 108562,
      "ty": 41,
      "x": 29217,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 109317,
      "e": 108620,
      "ty": 4,
      "x": 29217,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 109318,
      "e": 108621,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 109319,
      "e": 108622,
      "ty": 5,
      "x": 963,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 109320,
      "e": 108623,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 109608,
      "e": 108911,
      "ty": 2,
      "x": 1359,
      "y": 1008
    },
    {
      "t": 109708,
      "e": 109011,
      "ty": 2,
      "x": 1919,
      "y": 760
    },
    {
      "t": 109809,
      "e": 109112,
      "ty": 2,
      "x": 1840,
      "y": 540
    },
    {
      "t": 109909,
      "e": 109212,
      "ty": 2,
      "x": 1309,
      "y": 183
    },
    {
      "t": 110009,
      "e": 109312,
      "ty": 2,
      "x": 1193,
      "y": 250
    },
    {
      "t": 110009,
      "e": 109312,
      "ty": 41,
      "x": 40808,
      "y": 13406,
      "ta": "html > body"
    },
    {
      "t": 110009,
      "e": 109312,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110109,
      "e": 109412,
      "ty": 2,
      "x": 1257,
      "y": 368
    },
    {
      "t": 110259,
      "e": 109562,
      "ty": 41,
      "x": 43012,
      "y": 19943,
      "ta": "html > body"
    },
    {
      "t": 110361,
      "e": 109664,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 111317,
      "e": 110620,
      "ty": 2,
      "x": 567,
      "y": 557
    },
    {
      "t": 111317,
      "e": 110620,
      "ty": 41,
      "x": 24382,
      "y": 32759,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 111408,
      "e": 110711,
      "ty": 2,
      "x": 553,
      "y": 606
    },
    {
      "t": 111509,
      "e": 110812,
      "ty": 41,
      "x": 24083,
      "y": 32768,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 112126,
      "e": 111429,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 240135, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 240137, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 26193, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 267653, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12312, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 280972, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 25908, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 307969, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12768, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 321739, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 79667, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 402919, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-02 PM-11 AM-11 AM-11 AM-10 AM-A -A -11 AM-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:919,y:689,t:1527271797556};\\\", \\\"{x:917,y:689,t:1527271797563};\\\", \\\"{x:917,y:688,t:1527271797577};\\\", \\\"{x:916,y:688,t:1527271797594};\\\", \\\"{x:916,y:687,t:1527271798163};\\\", \\\"{x:917,y:687,t:1527271798660};\\\", \\\"{x:918,y:687,t:1527271798668};\\\", \\\"{x:919,y:687,t:1527271798684};\\\", \\\"{x:920,y:687,t:1527271798715};\\\", \\\"{x:921,y:687,t:1527271799147};\\\", \\\"{x:921,y:689,t:1527271799161};\\\", \\\"{x:934,y:713,t:1527271799178};\\\", \\\"{x:993,y:767,t:1527271799196};\\\", \\\"{x:1032,y:796,t:1527271799212};\\\", \\\"{x:1063,y:824,t:1527271799229};\\\", \\\"{x:1085,y:843,t:1527271799245};\\\", \\\"{x:1099,y:855,t:1527271799261};\\\", \\\"{x:1106,y:860,t:1527271799279};\\\", \\\"{x:1108,y:862,t:1527271799295};\\\", \\\"{x:1109,y:862,t:1527271799364};\\\", \\\"{x:1110,y:863,t:1527271799379};\\\", \\\"{x:1117,y:873,t:1527271799396};\\\", \\\"{x:1123,y:880,t:1527271799411};\\\", \\\"{x:1125,y:881,t:1527271799428};\\\", \\\"{x:1125,y:882,t:1527271799467};\\\", \\\"{x:1127,y:882,t:1527271799484};\\\", \\\"{x:1129,y:883,t:1527271799496};\\\", \\\"{x:1138,y:885,t:1527271799512};\\\", \\\"{x:1151,y:891,t:1527271799529};\\\", \\\"{x:1167,y:894,t:1527271799546};\\\", \\\"{x:1181,y:898,t:1527271799562};\\\", \\\"{x:1196,y:904,t:1527271799579};\\\", \\\"{x:1226,y:914,t:1527271799596};\\\", \\\"{x:1251,y:921,t:1527271799612};\\\", \\\"{x:1274,y:931,t:1527271799629};\\\", \\\"{x:1296,y:942,t:1527271799646};\\\", \\\"{x:1309,y:947,t:1527271799662};\\\", \\\"{x:1317,y:949,t:1527271799679};\\\", \\\"{x:1318,y:949,t:1527271799696};\\\", \\\"{x:1319,y:949,t:1527271799716};\\\", \\\"{x:1320,y:950,t:1527271799740};\\\", \\\"{x:1322,y:951,t:1527271799748};\\\", \\\"{x:1325,y:951,t:1527271799763};\\\", \\\"{x:1343,y:961,t:1527271799779};\\\", \\\"{x:1357,y:967,t:1527271799796};\\\", \\\"{x:1372,y:977,t:1527271799812};\\\", \\\"{x:1389,y:987,t:1527271799829};\\\", \\\"{x:1408,y:997,t:1527271799845};\\\", \\\"{x:1420,y:1003,t:1527271799862};\\\", \\\"{x:1427,y:1007,t:1527271799879};\\\", \\\"{x:1431,y:1007,t:1527271799895};\\\", \\\"{x:1434,y:1007,t:1527271799913};\\\", \\\"{x:1438,y:1008,t:1527271799930};\\\", \\\"{x:1443,y:1008,t:1527271799945};\\\", \\\"{x:1449,y:1008,t:1527271799962};\\\", \\\"{x:1458,y:1007,t:1527271799980};\\\", \\\"{x:1463,y:1004,t:1527271799996};\\\", \\\"{x:1467,y:1000,t:1527271800012};\\\", \\\"{x:1470,y:995,t:1527271800030};\\\", \\\"{x:1475,y:987,t:1527271800045};\\\", \\\"{x:1478,y:982,t:1527271800062};\\\", \\\"{x:1480,y:980,t:1527271800080};\\\", \\\"{x:1482,y:979,t:1527271800096};\\\", \\\"{x:1485,y:978,t:1527271800112};\\\", \\\"{x:1486,y:978,t:1527271800129};\\\", \\\"{x:1487,y:978,t:1527271800145};\\\", \\\"{x:1488,y:978,t:1527271800162};\\\", \\\"{x:1490,y:977,t:1527271800180};\\\", \\\"{x:1493,y:976,t:1527271800196};\\\", \\\"{x:1498,y:975,t:1527271800212};\\\", \\\"{x:1504,y:973,t:1527271800230};\\\", \\\"{x:1511,y:971,t:1527271800246};\\\", \\\"{x:1520,y:967,t:1527271800262};\\\", \\\"{x:1530,y:964,t:1527271800280};\\\", \\\"{x:1537,y:959,t:1527271800295};\\\", \\\"{x:1544,y:958,t:1527271800313};\\\", \\\"{x:1550,y:957,t:1527271800330};\\\", \\\"{x:1554,y:957,t:1527271800346};\\\", \\\"{x:1560,y:957,t:1527271800363};\\\", \\\"{x:1569,y:957,t:1527271800380};\\\", \\\"{x:1574,y:959,t:1527271800396};\\\", \\\"{x:1577,y:959,t:1527271800413};\\\", \\\"{x:1578,y:959,t:1527271800430};\\\", \\\"{x:1579,y:960,t:1527271800447};\\\", \\\"{x:1574,y:959,t:1527271800637};\\\", \\\"{x:1567,y:958,t:1527271800647};\\\", \\\"{x:1550,y:954,t:1527271800663};\\\", \\\"{x:1532,y:950,t:1527271800680};\\\", \\\"{x:1511,y:947,t:1527271800697};\\\", \\\"{x:1493,y:945,t:1527271800713};\\\", \\\"{x:1479,y:942,t:1527271800730};\\\", \\\"{x:1470,y:941,t:1527271800747};\\\", \\\"{x:1461,y:940,t:1527271800764};\\\", \\\"{x:1451,y:939,t:1527271800781};\\\", \\\"{x:1447,y:938,t:1527271800797};\\\", \\\"{x:1441,y:936,t:1527271800815};\\\", \\\"{x:1435,y:934,t:1527271800831};\\\", \\\"{x:1432,y:933,t:1527271800847};\\\", \\\"{x:1431,y:933,t:1527271800864};\\\", \\\"{x:1430,y:933,t:1527271800880};\\\", \\\"{x:1429,y:933,t:1527271800901};\\\", \\\"{x:1428,y:932,t:1527271800914};\\\", \\\"{x:1427,y:932,t:1527271800930};\\\", \\\"{x:1426,y:931,t:1527271800947};\\\", \\\"{x:1424,y:930,t:1527271800965};\\\", \\\"{x:1419,y:930,t:1527271800981};\\\", \\\"{x:1410,y:930,t:1527271800997};\\\", \\\"{x:1393,y:930,t:1527271801014};\\\", \\\"{x:1376,y:933,t:1527271801030};\\\", \\\"{x:1355,y:940,t:1527271801047};\\\", \\\"{x:1342,y:945,t:1527271801064};\\\", \\\"{x:1331,y:951,t:1527271801079};\\\", \\\"{x:1328,y:953,t:1527271801096};\\\", \\\"{x:1327,y:954,t:1527271801115};\\\", \\\"{x:1327,y:955,t:1527271801131};\\\", \\\"{x:1326,y:958,t:1527271801147};\\\", \\\"{x:1326,y:967,t:1527271801163};\\\", \\\"{x:1326,y:975,t:1527271801180};\\\", \\\"{x:1326,y:977,t:1527271801197};\\\", \\\"{x:1324,y:979,t:1527271801214};\\\", \\\"{x:1321,y:982,t:1527271801230};\\\", \\\"{x:1319,y:983,t:1527271801246};\\\", \\\"{x:1315,y:984,t:1527271801263};\\\", \\\"{x:1313,y:985,t:1527271801281};\\\", \\\"{x:1307,y:985,t:1527271801297};\\\", \\\"{x:1302,y:985,t:1527271801314};\\\", \\\"{x:1296,y:985,t:1527271801331};\\\", \\\"{x:1292,y:986,t:1527271801347};\\\", \\\"{x:1285,y:987,t:1527271801365};\\\", \\\"{x:1281,y:987,t:1527271801380};\\\", \\\"{x:1280,y:988,t:1527271801405};\\\", \\\"{x:1280,y:989,t:1527271801414};\\\", \\\"{x:1278,y:989,t:1527271801445};\\\", \\\"{x:1277,y:989,t:1527271801477};\\\", \\\"{x:1276,y:989,t:1527271801484};\\\", \\\"{x:1275,y:989,t:1527271801498};\\\", \\\"{x:1274,y:988,t:1527271801685};\\\", \\\"{x:1274,y:986,t:1527271801702};\\\", \\\"{x:1274,y:985,t:1527271801715};\\\", \\\"{x:1274,y:984,t:1527271801732};\\\", \\\"{x:1274,y:983,t:1527271801764};\\\", \\\"{x:1274,y:980,t:1527271801781};\\\", \\\"{x:1273,y:976,t:1527271801798};\\\", \\\"{x:1272,y:971,t:1527271801814};\\\", \\\"{x:1270,y:963,t:1527271801830};\\\", \\\"{x:1270,y:962,t:1527271801893};\\\", \\\"{x:1270,y:960,t:1527271801900};\\\", \\\"{x:1270,y:958,t:1527271801916};\\\", \\\"{x:1271,y:958,t:1527271801931};\\\", \\\"{x:1272,y:957,t:1527271801948};\\\", \\\"{x:1273,y:957,t:1527271801964};\\\", \\\"{x:1276,y:957,t:1527271801981};\\\", \\\"{x:1277,y:957,t:1527271801998};\\\", \\\"{x:1279,y:957,t:1527271802061};\\\", \\\"{x:1280,y:957,t:1527271802077};\\\", \\\"{x:1283,y:958,t:1527271802084};\\\", \\\"{x:1284,y:959,t:1527271802099};\\\", \\\"{x:1287,y:961,t:1527271802115};\\\", \\\"{x:1289,y:961,t:1527271802131};\\\", \\\"{x:1290,y:961,t:1527271802189};\\\", \\\"{x:1291,y:962,t:1527271802198};\\\", \\\"{x:1293,y:963,t:1527271802214};\\\", \\\"{x:1293,y:964,t:1527271802491};\\\", \\\"{x:1293,y:966,t:1527271802499};\\\", \\\"{x:1293,y:967,t:1527271802514};\\\", \\\"{x:1292,y:967,t:1527271802530};\\\", \\\"{x:1287,y:969,t:1527271802547};\\\", \\\"{x:1285,y:970,t:1527271802564};\\\", \\\"{x:1283,y:971,t:1527271802580};\\\", \\\"{x:1282,y:971,t:1527271802868};\\\", \\\"{x:1282,y:970,t:1527271805845};\\\", \\\"{x:1282,y:966,t:1527271805853};\\\", \\\"{x:1282,y:963,t:1527271805867};\\\", \\\"{x:1282,y:959,t:1527271805884};\\\", \\\"{x:1282,y:958,t:1527271805901};\\\", \\\"{x:1282,y:956,t:1527271805917};\\\", \\\"{x:1282,y:953,t:1527271805934};\\\", \\\"{x:1282,y:952,t:1527271806381};\\\", \\\"{x:1283,y:952,t:1527271806411};\\\", \\\"{x:1284,y:953,t:1527271806419};\\\", \\\"{x:1285,y:954,t:1527271806436};\\\", \\\"{x:1285,y:955,t:1527271806484};\\\", \\\"{x:1285,y:956,t:1527271806500};\\\", \\\"{x:1286,y:957,t:1527271806523};\\\", \\\"{x:1286,y:958,t:1527271806539};\\\", \\\"{x:1286,y:959,t:1527271806572};\\\", \\\"{x:1286,y:961,t:1527271806691};\\\", \\\"{x:1286,y:962,t:1527271806701};\\\", \\\"{x:1286,y:964,t:1527271806717};\\\", \\\"{x:1285,y:964,t:1527271807059};\\\", \\\"{x:1282,y:966,t:1527271808789};\\\", \\\"{x:1279,y:966,t:1527271808803};\\\", \\\"{x:1274,y:967,t:1527271808819};\\\", \\\"{x:1267,y:969,t:1527271808835};\\\", \\\"{x:1263,y:969,t:1527271808852};\\\", \\\"{x:1261,y:970,t:1527271808869};\\\", \\\"{x:1260,y:970,t:1527271808886};\\\", \\\"{x:1259,y:970,t:1527271808916};\\\", \\\"{x:1258,y:970,t:1527271808924};\\\", \\\"{x:1257,y:970,t:1527271808936};\\\", \\\"{x:1253,y:970,t:1527271808952};\\\", \\\"{x:1251,y:971,t:1527271808969};\\\", \\\"{x:1249,y:972,t:1527271808986};\\\", \\\"{x:1247,y:973,t:1527271809002};\\\", \\\"{x:1246,y:974,t:1527271809019};\\\", \\\"{x:1244,y:974,t:1527271809036};\\\", \\\"{x:1242,y:974,t:1527271809053};\\\", \\\"{x:1241,y:974,t:1527271809069};\\\", \\\"{x:1239,y:974,t:1527271809086};\\\", \\\"{x:1235,y:974,t:1527271809103};\\\", \\\"{x:1232,y:974,t:1527271809119};\\\", \\\"{x:1229,y:974,t:1527271809136};\\\", \\\"{x:1228,y:974,t:1527271809180};\\\", \\\"{x:1227,y:975,t:1527271809188};\\\", \\\"{x:1225,y:975,t:1527271809212};\\\", \\\"{x:1224,y:975,t:1527271809220};\\\", \\\"{x:1222,y:975,t:1527271809236};\\\", \\\"{x:1221,y:975,t:1527271809549};\\\", \\\"{x:1220,y:975,t:1527271809685};\\\", \\\"{x:1219,y:975,t:1527271809724};\\\", \\\"{x:1218,y:975,t:1527271809764};\\\", \\\"{x:1217,y:974,t:1527271809797};\\\", \\\"{x:1216,y:973,t:1527271809829};\\\", \\\"{x:1216,y:972,t:1527271809852};\\\", \\\"{x:1215,y:971,t:1527271809871};\\\", \\\"{x:1214,y:970,t:1527271810117};\\\", \\\"{x:1215,y:970,t:1527271810284};\\\", \\\"{x:1216,y:970,t:1527271810659};\\\", \\\"{x:1215,y:970,t:1527271810707};\\\", \\\"{x:1214,y:969,t:1527271810719};\\\", \\\"{x:1214,y:968,t:1527271810788};\\\", \\\"{x:1217,y:958,t:1527271810803};\\\", \\\"{x:1222,y:944,t:1527271810821};\\\", \\\"{x:1225,y:925,t:1527271810837};\\\", \\\"{x:1228,y:903,t:1527271810853};\\\", \\\"{x:1228,y:883,t:1527271810870};\\\", \\\"{x:1229,y:872,t:1527271810887};\\\", \\\"{x:1230,y:866,t:1527271810904};\\\", \\\"{x:1230,y:865,t:1527271810920};\\\", \\\"{x:1230,y:864,t:1527271810937};\\\", \\\"{x:1231,y:861,t:1527271810954};\\\", \\\"{x:1231,y:858,t:1527271810971};\\\", \\\"{x:1233,y:850,t:1527271810987};\\\", \\\"{x:1236,y:844,t:1527271811004};\\\", \\\"{x:1237,y:840,t:1527271811020};\\\", \\\"{x:1241,y:835,t:1527271811037};\\\", \\\"{x:1242,y:834,t:1527271811054};\\\", \\\"{x:1243,y:834,t:1527271811083};\\\", \\\"{x:1244,y:834,t:1527271811091};\\\", \\\"{x:1245,y:834,t:1527271811104};\\\", \\\"{x:1247,y:833,t:1527271811121};\\\", \\\"{x:1253,y:832,t:1527271811137};\\\", \\\"{x:1262,y:829,t:1527271811153};\\\", \\\"{x:1271,y:826,t:1527271811171};\\\", \\\"{x:1278,y:825,t:1527271811188};\\\", \\\"{x:1282,y:823,t:1527271811204};\\\", \\\"{x:1283,y:822,t:1527271811340};\\\", \\\"{x:1278,y:816,t:1527271835647};\\\", \\\"{x:1251,y:789,t:1527271835656};\\\", \\\"{x:1202,y:756,t:1527271835668};\\\", \\\"{x:1069,y:668,t:1527271835686};\\\", \\\"{x:922,y:569,t:1527271835702};\\\", \\\"{x:749,y:453,t:1527271835719};\\\", \\\"{x:452,y:279,t:1527271835735};\\\", \\\"{x:269,y:214,t:1527271835755};\\\", \\\"{x:125,y:170,t:1527271835773};\\\", \\\"{x:54,y:152,t:1527271835789};\\\", \\\"{x:36,y:152,t:1527271835806};\\\", \\\"{x:31,y:152,t:1527271835823};\\\", \\\"{x:26,y:157,t:1527271835840};\\\", \\\"{x:19,y:167,t:1527271835855};\\\", \\\"{x:11,y:188,t:1527271835872};\\\", \\\"{x:4,y:223,t:1527271835890};\\\", \\\"{x:4,y:260,t:1527271835905};\\\", \\\"{x:4,y:289,t:1527271835922};\\\", \\\"{x:24,y:329,t:1527271835939};\\\", \\\"{x:47,y:372,t:1527271835955};\\\", \\\"{x:86,y:409,t:1527271835973};\\\", \\\"{x:134,y:446,t:1527271835990};\\\", \\\"{x:182,y:479,t:1527271836006};\\\", \\\"{x:212,y:499,t:1527271836022};\\\", \\\"{x:242,y:515,t:1527271836040};\\\", \\\"{x:253,y:521,t:1527271836056};\\\", \\\"{x:267,y:529,t:1527271836073};\\\", \\\"{x:287,y:540,t:1527271836089};\\\", \\\"{x:308,y:549,t:1527271836106};\\\", \\\"{x:324,y:557,t:1527271836123};\\\", \\\"{x:329,y:557,t:1527271836139};\\\", \\\"{x:332,y:558,t:1527271836156};\\\", \\\"{x:337,y:558,t:1527271836172};\\\", \\\"{x:340,y:558,t:1527271836189};\\\", \\\"{x:342,y:558,t:1527271836206};\\\", \\\"{x:343,y:558,t:1527271836280};\\\", \\\"{x:344,y:558,t:1527271836320};\\\", \\\"{x:345,y:558,t:1527271836327};\\\", \\\"{x:346,y:557,t:1527271836339};\\\", \\\"{x:353,y:557,t:1527271836356};\\\", \\\"{x:359,y:554,t:1527271836372};\\\", \\\"{x:364,y:553,t:1527271836390};\\\", \\\"{x:370,y:548,t:1527271836407};\\\", \\\"{x:377,y:539,t:1527271836423};\\\", \\\"{x:379,y:536,t:1527271836440};\\\", \\\"{x:380,y:534,t:1527271836456};\\\", \\\"{x:380,y:533,t:1527271836473};\\\", \\\"{x:381,y:530,t:1527271836490};\\\", \\\"{x:381,y:528,t:1527271836507};\\\", \\\"{x:381,y:527,t:1527271836524};\\\", \\\"{x:383,y:526,t:1527271837201};\\\", \\\"{x:392,y:526,t:1527271837208};\\\", \\\"{x:425,y:526,t:1527271837225};\\\", \\\"{x:478,y:526,t:1527271837240};\\\", \\\"{x:518,y:526,t:1527271837258};\\\", \\\"{x:560,y:526,t:1527271837274};\\\", \\\"{x:589,y:527,t:1527271837291};\\\", \\\"{x:616,y:528,t:1527271837308};\\\", \\\"{x:627,y:529,t:1527271837324};\\\", \\\"{x:632,y:529,t:1527271837341};\\\", \\\"{x:633,y:529,t:1527271837464};\\\", \\\"{x:634,y:529,t:1527271837593};\\\", \\\"{x:634,y:532,t:1527271838592};\\\", \\\"{x:628,y:552,t:1527271838609};\\\", \\\"{x:624,y:567,t:1527271838625};\\\", \\\"{x:620,y:579,t:1527271838641};\\\", \\\"{x:618,y:589,t:1527271838658};\\\", \\\"{x:616,y:596,t:1527271838675};\\\", \\\"{x:612,y:603,t:1527271838692};\\\", \\\"{x:609,y:608,t:1527271838708};\\\", \\\"{x:605,y:612,t:1527271838725};\\\", \\\"{x:596,y:629,t:1527271838742};\\\", \\\"{x:583,y:646,t:1527271838758};\\\", \\\"{x:572,y:660,t:1527271838775};\\\", \\\"{x:561,y:674,t:1527271838791};\\\", \\\"{x:557,y:677,t:1527271838808};\\\", \\\"{x:554,y:680,t:1527271838825};\\\", \\\"{x:551,y:682,t:1527271838842};\\\", \\\"{x:547,y:684,t:1527271838859};\\\", \\\"{x:545,y:686,t:1527271838874};\\\", \\\"{x:537,y:698,t:1527271838891};\\\", \\\"{x:533,y:706,t:1527271838910};\\\", \\\"{x:526,y:717,t:1527271838925};\\\", \\\"{x:521,y:724,t:1527271838941};\\\", \\\"{x:520,y:726,t:1527271838958};\\\", \\\"{x:519,y:727,t:1527271839080};\\\", \\\"{x:525,y:727,t:1527271843304};\\\", \\\"{x:543,y:729,t:1527271843311};\\\", \\\"{x:585,y:745,t:1527271843324};\\\", \\\"{x:684,y:768,t:1527271843339};\\\", \\\"{x:781,y:796,t:1527271843357};\\\", \\\"{x:961,y:849,t:1527271843379};\\\", \\\"{x:1082,y:904,t:1527271843396};\\\", \\\"{x:1190,y:954,t:1527271843412};\\\", \\\"{x:1289,y:1014,t:1527271843429};\\\", \\\"{x:1385,y:1066,t:1527271843445};\\\", \\\"{x:1479,y:1115,t:1527271843462};\\\", \\\"{x:1532,y:1147,t:1527271843479};\\\", \\\"{x:1547,y:1160,t:1527271843495};\\\", \\\"{x:1549,y:1160,t:1527271843512};\\\", \\\"{x:1542,y:1160,t:1527271843551};\\\", \\\"{x:1528,y:1152,t:1527271843562};\\\", \\\"{x:1493,y:1132,t:1527271843579};\\\", \\\"{x:1452,y:1108,t:1527271843596};\\\", \\\"{x:1413,y:1089,t:1527271843612};\\\", \\\"{x:1394,y:1080,t:1527271843629};\\\", \\\"{x:1380,y:1074,t:1527271843645};\\\", \\\"{x:1372,y:1070,t:1527271843662};\\\", \\\"{x:1365,y:1066,t:1527271843678};\\\", \\\"{x:1353,y:1060,t:1527271843695};\\\", \\\"{x:1344,y:1054,t:1527271843712};\\\", \\\"{x:1337,y:1051,t:1527271843729};\\\", \\\"{x:1327,y:1044,t:1527271843746};\\\", \\\"{x:1316,y:1036,t:1527271843762};\\\", \\\"{x:1311,y:1033,t:1527271843779};\\\", \\\"{x:1308,y:1032,t:1527271843795};\\\", \\\"{x:1307,y:1031,t:1527271843824};\\\", \\\"{x:1305,y:1029,t:1527271843840};\\\", \\\"{x:1303,y:1027,t:1527271843847};\\\", \\\"{x:1302,y:1026,t:1527271843862};\\\", \\\"{x:1295,y:1019,t:1527271843879};\\\", \\\"{x:1289,y:1016,t:1527271843895};\\\", \\\"{x:1288,y:1015,t:1527271843912};\\\", \\\"{x:1288,y:1011,t:1527271843944};\\\", \\\"{x:1288,y:1008,t:1527271843952};\\\", \\\"{x:1288,y:1004,t:1527271843962};\\\", \\\"{x:1288,y:996,t:1527271843979};\\\", \\\"{x:1288,y:993,t:1527271843996};\\\", \\\"{x:1286,y:990,t:1527271844013};\\\", \\\"{x:1285,y:989,t:1527271844029};\\\", \\\"{x:1285,y:988,t:1527271844064};\\\", \\\"{x:1284,y:987,t:1527271844079};\\\", \\\"{x:1279,y:984,t:1527271844096};\\\", \\\"{x:1274,y:982,t:1527271844113};\\\", \\\"{x:1272,y:981,t:1527271844130};\\\", \\\"{x:1271,y:980,t:1527271844152};\\\", \\\"{x:1269,y:980,t:1527271844176};\\\", \\\"{x:1268,y:980,t:1527271844200};\\\", \\\"{x:1269,y:980,t:1527271844288};\\\", \\\"{x:1271,y:978,t:1527271844296};\\\", \\\"{x:1277,y:976,t:1527271844313};\\\", \\\"{x:1284,y:972,t:1527271844329};\\\", \\\"{x:1287,y:969,t:1527271844346};\\\", \\\"{x:1289,y:968,t:1527271844363};\\\", \\\"{x:1290,y:968,t:1527271844379};\\\", \\\"{x:1292,y:967,t:1527271844396};\\\", \\\"{x:1292,y:966,t:1527271844585};\\\", \\\"{x:1292,y:965,t:1527271844596};\\\", \\\"{x:1289,y:961,t:1527271844613};\\\", \\\"{x:1288,y:960,t:1527271844630};\\\", \\\"{x:1287,y:960,t:1527271844646};\\\", \\\"{x:1287,y:959,t:1527271844767};\\\", \\\"{x:1287,y:955,t:1527271845015};\\\", \\\"{x:1285,y:946,t:1527271845030};\\\", \\\"{x:1284,y:932,t:1527271845047};\\\", \\\"{x:1284,y:927,t:1527271845063};\\\", \\\"{x:1283,y:921,t:1527271845080};\\\", \\\"{x:1283,y:915,t:1527271845097};\\\", \\\"{x:1283,y:912,t:1527271845113};\\\", \\\"{x:1283,y:900,t:1527271845130};\\\", \\\"{x:1283,y:886,t:1527271845147};\\\", \\\"{x:1284,y:874,t:1527271845163};\\\", \\\"{x:1284,y:865,t:1527271845180};\\\", \\\"{x:1284,y:860,t:1527271845198};\\\", \\\"{x:1284,y:858,t:1527271845213};\\\", \\\"{x:1284,y:856,t:1527271845230};\\\", \\\"{x:1284,y:853,t:1527271845247};\\\", \\\"{x:1284,y:850,t:1527271845263};\\\", \\\"{x:1284,y:841,t:1527271845280};\\\", \\\"{x:1281,y:832,t:1527271845298};\\\", \\\"{x:1279,y:830,t:1527271845313};\\\", \\\"{x:1278,y:828,t:1527271845330};\\\", \\\"{x:1278,y:827,t:1527271845385};\\\", \\\"{x:1277,y:826,t:1527271845397};\\\", \\\"{x:1277,y:825,t:1527271845414};\\\", \\\"{x:1277,y:823,t:1527271845448};\\\", \\\"{x:1277,y:822,t:1527271845560};\\\", \\\"{x:1278,y:822,t:1527271845784};\\\", \\\"{x:1279,y:822,t:1527271845808};\\\", \\\"{x:1280,y:822,t:1527271845824};\\\", \\\"{x:1279,y:822,t:1527271862177};\\\", \\\"{x:1276,y:822,t:1527271862194};\\\", \\\"{x:1273,y:821,t:1527271862213};\\\", \\\"{x:1271,y:820,t:1527271862227};\\\", \\\"{x:1269,y:818,t:1527271862244};\\\", \\\"{x:1268,y:818,t:1527271862262};\\\", \\\"{x:1268,y:816,t:1527271862839};\\\", \\\"{x:1276,y:812,t:1527271862847};\\\", \\\"{x:1283,y:808,t:1527271862861};\\\", \\\"{x:1295,y:800,t:1527271862878};\\\", \\\"{x:1305,y:799,t:1527271862894};\\\", \\\"{x:1308,y:799,t:1527271862911};\\\", \\\"{x:1320,y:803,t:1527271862927};\\\", \\\"{x:1326,y:805,t:1527271862944};\\\", \\\"{x:1327,y:806,t:1527271862961};\\\", \\\"{x:1327,y:802,t:1527271863088};\\\", \\\"{x:1327,y:794,t:1527271863096};\\\", \\\"{x:1317,y:775,t:1527271863112};\\\", \\\"{x:1234,y:691,t:1527271863128};\\\", \\\"{x:1126,y:647,t:1527271863146};\\\", \\\"{x:1006,y:601,t:1527271863162};\\\", \\\"{x:873,y:565,t:1527271863179};\\\", \\\"{x:730,y:525,t:1527271863196};\\\", \\\"{x:599,y:504,t:1527271863211};\\\", \\\"{x:499,y:502,t:1527271863228};\\\", \\\"{x:429,y:536,t:1527271863245};\\\", \\\"{x:372,y:605,t:1527271863262};\\\", \\\"{x:329,y:673,t:1527271863278};\\\", \\\"{x:297,y:735,t:1527271863294};\\\", \\\"{x:290,y:795,t:1527271863311};\\\", \\\"{x:294,y:820,t:1527271863329};\\\", \\\"{x:305,y:843,t:1527271863345};\\\", \\\"{x:313,y:854,t:1527271863361};\\\", \\\"{x:315,y:856,t:1527271863379};\\\", \\\"{x:320,y:856,t:1527271863463};\\\", \\\"{x:331,y:856,t:1527271863479};\\\", \\\"{x:362,y:846,t:1527271863495};\\\", \\\"{x:440,y:803,t:1527271863511};\\\", \\\"{x:487,y:774,t:1527271863529};\\\", \\\"{x:520,y:760,t:1527271863545};\\\", \\\"{x:535,y:755,t:1527271863562};\\\", \\\"{x:543,y:754,t:1527271863579};\\\", \\\"{x:544,y:753,t:1527271863595};\\\", \\\"{x:547,y:748,t:1527271863656};\\\", \\\"{x:550,y:740,t:1527271863663};\\\", \\\"{x:555,y:730,t:1527271863680};\\\", \\\"{x:560,y:707,t:1527271863695};\\\", \\\"{x:561,y:707,t:1527271863711};\\\", \\\"{x:561,y:705,t:1527271863743};\\\", \\\"{x:560,y:705,t:1527271863752};\\\", \\\"{x:559,y:705,t:1527271863761};\\\", \\\"{x:555,y:705,t:1527271863778};\\\", \\\"{x:554,y:705,t:1527271863796};\\\", \\\"{x:553,y:705,t:1527271863810};\\\", \\\"{x:552,y:705,t:1527271863895};\\\", \\\"{x:551,y:705,t:1527271863911};\\\", \\\"{x:550,y:710,t:1527271863927};\\\", \\\"{x:549,y:714,t:1527271863945};\\\", \\\"{x:549,y:715,t:1527271863961};\\\", \\\"{x:549,y:716,t:1527271863978};\\\" ] }, { \\\"rt\\\": 22765, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 427286, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:700,t:1527271869026};\\\", \\\"{x:557,y:662,t:1527271869035};\\\", \\\"{x:573,y:551,t:1527271869049};\\\", \\\"{x:582,y:468,t:1527271869067};\\\", \\\"{x:589,y:436,t:1527271869083};\\\", \\\"{x:594,y:422,t:1527271869100};\\\", \\\"{x:596,y:419,t:1527271869116};\\\", \\\"{x:597,y:418,t:1527271869133};\\\", \\\"{x:597,y:416,t:1527271869175};\\\", \\\"{x:598,y:416,t:1527271869199};\\\", \\\"{x:598,y:415,t:1527271869216};\\\", \\\"{x:599,y:414,t:1527271869233};\\\", \\\"{x:599,y:416,t:1527271869344};\\\", \\\"{x:599,y:418,t:1527271869351};\\\", \\\"{x:598,y:419,t:1527271869367};\\\", \\\"{x:594,y:428,t:1527271869384};\\\", \\\"{x:590,y:439,t:1527271869400};\\\", \\\"{x:589,y:445,t:1527271869417};\\\", \\\"{x:586,y:451,t:1527271869433};\\\", \\\"{x:584,y:458,t:1527271869450};\\\", \\\"{x:584,y:461,t:1527271869467};\\\", \\\"{x:583,y:462,t:1527271869483};\\\", \\\"{x:583,y:463,t:1527271869500};\\\", \\\"{x:583,y:464,t:1527271869517};\\\", \\\"{x:583,y:466,t:1527271869533};\\\", \\\"{x:583,y:470,t:1527271869550};\\\", \\\"{x:582,y:475,t:1527271869568};\\\", \\\"{x:582,y:477,t:1527271869584};\\\", \\\"{x:582,y:484,t:1527271869600};\\\", \\\"{x:582,y:486,t:1527271869617};\\\", \\\"{x:581,y:487,t:1527271869647};\\\", \\\"{x:581,y:488,t:1527271874183};\\\", \\\"{x:583,y:488,t:1527271874191};\\\", \\\"{x:588,y:489,t:1527271874205};\\\", \\\"{x:596,y:490,t:1527271874220};\\\", \\\"{x:630,y:491,t:1527271874237};\\\", \\\"{x:682,y:503,t:1527271874255};\\\", \\\"{x:743,y:520,t:1527271874271};\\\", \\\"{x:869,y:547,t:1527271874287};\\\", \\\"{x:955,y:560,t:1527271874305};\\\", \\\"{x:1037,y:576,t:1527271874320};\\\", \\\"{x:1088,y:594,t:1527271874338};\\\", \\\"{x:1142,y:610,t:1527271874354};\\\", \\\"{x:1178,y:625,t:1527271874370};\\\", \\\"{x:1213,y:638,t:1527271874388};\\\", \\\"{x:1254,y:654,t:1527271874404};\\\", \\\"{x:1296,y:666,t:1527271874420};\\\", \\\"{x:1352,y:682,t:1527271874437};\\\", \\\"{x:1397,y:696,t:1527271874453};\\\", \\\"{x:1439,y:709,t:1527271874470};\\\", \\\"{x:1469,y:718,t:1527271874487};\\\", \\\"{x:1482,y:720,t:1527271874504};\\\", \\\"{x:1487,y:720,t:1527271874520};\\\", \\\"{x:1488,y:720,t:1527271874537};\\\", \\\"{x:1489,y:720,t:1527271874554};\\\", \\\"{x:1491,y:720,t:1527271874583};\\\", \\\"{x:1493,y:720,t:1527271874592};\\\", \\\"{x:1494,y:720,t:1527271874604};\\\", \\\"{x:1498,y:719,t:1527271874620};\\\", \\\"{x:1501,y:718,t:1527271874638};\\\", \\\"{x:1505,y:716,t:1527271874653};\\\", \\\"{x:1507,y:714,t:1527271874670};\\\", \\\"{x:1507,y:713,t:1527271874688};\\\", \\\"{x:1507,y:711,t:1527271874703};\\\", \\\"{x:1505,y:708,t:1527271874721};\\\", \\\"{x:1498,y:704,t:1527271874737};\\\", \\\"{x:1489,y:695,t:1527271874753};\\\", \\\"{x:1476,y:688,t:1527271874770};\\\", \\\"{x:1462,y:682,t:1527271874786};\\\", \\\"{x:1444,y:674,t:1527271874803};\\\", \\\"{x:1421,y:664,t:1527271874820};\\\", \\\"{x:1401,y:658,t:1527271874837};\\\", \\\"{x:1388,y:652,t:1527271874854};\\\", \\\"{x:1384,y:651,t:1527271874871};\\\", \\\"{x:1381,y:650,t:1527271874887};\\\", \\\"{x:1380,y:650,t:1527271874904};\\\", \\\"{x:1379,y:648,t:1527271874991};\\\", \\\"{x:1377,y:647,t:1527271875016};\\\", \\\"{x:1376,y:646,t:1527271875023};\\\", \\\"{x:1373,y:643,t:1527271875037};\\\", \\\"{x:1371,y:640,t:1527271875054};\\\", \\\"{x:1370,y:635,t:1527271875069};\\\", \\\"{x:1370,y:631,t:1527271875087};\\\", \\\"{x:1368,y:622,t:1527271875104};\\\", \\\"{x:1368,y:619,t:1527271875120};\\\", \\\"{x:1368,y:614,t:1527271875137};\\\", \\\"{x:1370,y:607,t:1527271875154};\\\", \\\"{x:1376,y:598,t:1527271875170};\\\", \\\"{x:1379,y:592,t:1527271875187};\\\", \\\"{x:1386,y:582,t:1527271875204};\\\", \\\"{x:1392,y:565,t:1527271875220};\\\", \\\"{x:1396,y:553,t:1527271875237};\\\", \\\"{x:1397,y:545,t:1527271875254};\\\", \\\"{x:1401,y:534,t:1527271875270};\\\", \\\"{x:1401,y:530,t:1527271875287};\\\", \\\"{x:1402,y:526,t:1527271875304};\\\", \\\"{x:1403,y:524,t:1527271875320};\\\", \\\"{x:1404,y:519,t:1527271875337};\\\", \\\"{x:1405,y:510,t:1527271875354};\\\", \\\"{x:1405,y:495,t:1527271875370};\\\", \\\"{x:1405,y:478,t:1527271875387};\\\", \\\"{x:1405,y:463,t:1527271875403};\\\", \\\"{x:1403,y:444,t:1527271875420};\\\", \\\"{x:1400,y:429,t:1527271875437};\\\", \\\"{x:1398,y:411,t:1527271875453};\\\", \\\"{x:1395,y:395,t:1527271875470};\\\", \\\"{x:1395,y:391,t:1527271875487};\\\", \\\"{x:1395,y:388,t:1527271875504};\\\", \\\"{x:1395,y:381,t:1527271875521};\\\", \\\"{x:1395,y:378,t:1527271875536};\\\", \\\"{x:1395,y:376,t:1527271875560};\\\", \\\"{x:1395,y:374,t:1527271875576};\\\", \\\"{x:1395,y:373,t:1527271875587};\\\", \\\"{x:1396,y:370,t:1527271875603};\\\", \\\"{x:1396,y:367,t:1527271875620};\\\", \\\"{x:1400,y:362,t:1527271875637};\\\", \\\"{x:1407,y:357,t:1527271875653};\\\", \\\"{x:1416,y:351,t:1527271875671};\\\", \\\"{x:1427,y:343,t:1527271875687};\\\", \\\"{x:1431,y:340,t:1527271875703};\\\", \\\"{x:1437,y:339,t:1527271875720};\\\", \\\"{x:1441,y:336,t:1527271875736};\\\", \\\"{x:1447,y:336,t:1527271875753};\\\", \\\"{x:1453,y:336,t:1527271875770};\\\", \\\"{x:1459,y:336,t:1527271875786};\\\", \\\"{x:1468,y:337,t:1527271875803};\\\", \\\"{x:1481,y:341,t:1527271875820};\\\", \\\"{x:1499,y:348,t:1527271875836};\\\", \\\"{x:1522,y:355,t:1527271875853};\\\", \\\"{x:1542,y:365,t:1527271875870};\\\", \\\"{x:1557,y:372,t:1527271875886};\\\", \\\"{x:1567,y:376,t:1527271875903};\\\", \\\"{x:1581,y:383,t:1527271875919};\\\", \\\"{x:1588,y:385,t:1527271875935};\\\", \\\"{x:1594,y:389,t:1527271875952};\\\", \\\"{x:1604,y:394,t:1527271875969};\\\", \\\"{x:1616,y:402,t:1527271875985};\\\", \\\"{x:1628,y:408,t:1527271876003};\\\", \\\"{x:1638,y:412,t:1527271876020};\\\", \\\"{x:1648,y:417,t:1527271876035};\\\", \\\"{x:1653,y:420,t:1527271876052};\\\", \\\"{x:1656,y:423,t:1527271876069};\\\", \\\"{x:1659,y:426,t:1527271876086};\\\", \\\"{x:1659,y:428,t:1527271876103};\\\", \\\"{x:1659,y:429,t:1527271876191};\\\", \\\"{x:1658,y:429,t:1527271876203};\\\", \\\"{x:1650,y:434,t:1527271876219};\\\", \\\"{x:1646,y:436,t:1527271876235};\\\", \\\"{x:1641,y:437,t:1527271876253};\\\", \\\"{x:1636,y:439,t:1527271876268};\\\", \\\"{x:1635,y:440,t:1527271876286};\\\", \\\"{x:1631,y:441,t:1527271876303};\\\", \\\"{x:1627,y:443,t:1527271876319};\\\", \\\"{x:1623,y:444,t:1527271876336};\\\", \\\"{x:1620,y:446,t:1527271876352};\\\", \\\"{x:1619,y:446,t:1527271876368};\\\", \\\"{x:1618,y:446,t:1527271876391};\\\", \\\"{x:1618,y:447,t:1527271876402};\\\", \\\"{x:1616,y:447,t:1527271876496};\\\", \\\"{x:1614,y:447,t:1527271876505};\\\", \\\"{x:1613,y:447,t:1527271876543};\\\", \\\"{x:1612,y:446,t:1527271876551};\\\", \\\"{x:1611,y:445,t:1527271876576};\\\", \\\"{x:1611,y:444,t:1527271876591};\\\", \\\"{x:1611,y:443,t:1527271876601};\\\", \\\"{x:1611,y:442,t:1527271876618};\\\", \\\"{x:1611,y:441,t:1527271876635};\\\", \\\"{x:1611,y:440,t:1527271876711};\\\", \\\"{x:1611,y:439,t:1527271876720};\\\", \\\"{x:1611,y:437,t:1527271876734};\\\", \\\"{x:1611,y:436,t:1527271876752};\\\", \\\"{x:1611,y:435,t:1527271876769};\\\", \\\"{x:1611,y:434,t:1527271881339};\\\", \\\"{x:1612,y:434,t:1527271881348};\\\", \\\"{x:1616,y:434,t:1527271881364};\\\", \\\"{x:1623,y:443,t:1527271881382};\\\", \\\"{x:1632,y:457,t:1527271881398};\\\", \\\"{x:1640,y:475,t:1527271881414};\\\", \\\"{x:1648,y:490,t:1527271881431};\\\", \\\"{x:1652,y:500,t:1527271881447};\\\", \\\"{x:1652,y:507,t:1527271881463};\\\", \\\"{x:1652,y:510,t:1527271881481};\\\", \\\"{x:1652,y:514,t:1527271881497};\\\", \\\"{x:1652,y:516,t:1527271881514};\\\", \\\"{x:1652,y:519,t:1527271881531};\\\", \\\"{x:1652,y:520,t:1527271881551};\\\", \\\"{x:1652,y:521,t:1527271881576};\\\", \\\"{x:1651,y:523,t:1527271881583};\\\", \\\"{x:1651,y:525,t:1527271881597};\\\", \\\"{x:1649,y:531,t:1527271881613};\\\", \\\"{x:1644,y:541,t:1527271881631};\\\", \\\"{x:1641,y:548,t:1527271881647};\\\", \\\"{x:1640,y:553,t:1527271881664};\\\", \\\"{x:1639,y:554,t:1527271881681};\\\", \\\"{x:1637,y:556,t:1527271881703};\\\", \\\"{x:1635,y:559,t:1527271881714};\\\", \\\"{x:1631,y:563,t:1527271881731};\\\", \\\"{x:1620,y:568,t:1527271881746};\\\", \\\"{x:1610,y:576,t:1527271881764};\\\", \\\"{x:1603,y:582,t:1527271881781};\\\", \\\"{x:1600,y:585,t:1527271881797};\\\", \\\"{x:1599,y:585,t:1527271882032};\\\", \\\"{x:1598,y:585,t:1527271882047};\\\", \\\"{x:1576,y:574,t:1527271882063};\\\", \\\"{x:1522,y:550,t:1527271882080};\\\", \\\"{x:1402,y:506,t:1527271882097};\\\", \\\"{x:1285,y:466,t:1527271882113};\\\", \\\"{x:1193,y:454,t:1527271882130};\\\", \\\"{x:1094,y:454,t:1527271882147};\\\", \\\"{x:999,y:454,t:1527271882162};\\\", \\\"{x:889,y:480,t:1527271882179};\\\", \\\"{x:792,y:507,t:1527271882197};\\\", \\\"{x:727,y:523,t:1527271882213};\\\", \\\"{x:691,y:527,t:1527271882227};\\\", \\\"{x:662,y:532,t:1527271882243};\\\", \\\"{x:627,y:537,t:1527271882260};\\\", \\\"{x:594,y:545,t:1527271882277};\\\", \\\"{x:575,y:552,t:1527271882293};\\\", \\\"{x:558,y:559,t:1527271882310};\\\", \\\"{x:538,y:573,t:1527271882327};\\\", \\\"{x:504,y:604,t:1527271882344};\\\", \\\"{x:490,y:618,t:1527271882361};\\\", \\\"{x:486,y:622,t:1527271882377};\\\", \\\"{x:484,y:622,t:1527271882414};\\\", \\\"{x:482,y:622,t:1527271882426};\\\", \\\"{x:470,y:615,t:1527271882445};\\\", \\\"{x:458,y:606,t:1527271882461};\\\", \\\"{x:444,y:598,t:1527271882477};\\\", \\\"{x:434,y:594,t:1527271882494};\\\", \\\"{x:431,y:591,t:1527271882510};\\\", \\\"{x:431,y:586,t:1527271882527};\\\", \\\"{x:431,y:582,t:1527271882544};\\\", \\\"{x:429,y:580,t:1527271882561};\\\", \\\"{x:429,y:578,t:1527271882577};\\\", \\\"{x:427,y:578,t:1527271882599};\\\", \\\"{x:426,y:578,t:1527271882623};\\\", \\\"{x:424,y:578,t:1527271882631};\\\", \\\"{x:421,y:578,t:1527271882644};\\\", \\\"{x:412,y:578,t:1527271882661};\\\", \\\"{x:393,y:585,t:1527271882677};\\\", \\\"{x:378,y:596,t:1527271882694};\\\", \\\"{x:372,y:601,t:1527271882711};\\\", \\\"{x:367,y:606,t:1527271882727};\\\", \\\"{x:367,y:609,t:1527271882743};\\\", \\\"{x:369,y:616,t:1527271882761};\\\", \\\"{x:371,y:625,t:1527271882778};\\\", \\\"{x:373,y:633,t:1527271882794};\\\", \\\"{x:375,y:637,t:1527271882810};\\\", \\\"{x:377,y:640,t:1527271882828};\\\", \\\"{x:377,y:641,t:1527271882844};\\\", \\\"{x:377,y:642,t:1527271882879};\\\", \\\"{x:369,y:642,t:1527271882896};\\\", \\\"{x:361,y:642,t:1527271882911};\\\", \\\"{x:329,y:636,t:1527271882927};\\\", \\\"{x:301,y:628,t:1527271882945};\\\", \\\"{x:277,y:622,t:1527271882961};\\\", \\\"{x:248,y:619,t:1527271882978};\\\", \\\"{x:219,y:613,t:1527271882995};\\\", \\\"{x:191,y:608,t:1527271883011};\\\", \\\"{x:170,y:603,t:1527271883028};\\\", \\\"{x:155,y:601,t:1527271883045};\\\", \\\"{x:136,y:598,t:1527271883061};\\\", \\\"{x:117,y:598,t:1527271883078};\\\", \\\"{x:109,y:598,t:1527271883095};\\\", \\\"{x:108,y:598,t:1527271883111};\\\", \\\"{x:107,y:598,t:1527271883184};\\\", \\\"{x:107,y:596,t:1527271883196};\\\", \\\"{x:108,y:593,t:1527271883209};\\\", \\\"{x:121,y:584,t:1527271883225};\\\", \\\"{x:140,y:569,t:1527271883243};\\\", \\\"{x:153,y:557,t:1527271883259};\\\", \\\"{x:160,y:546,t:1527271883275};\\\", \\\"{x:163,y:541,t:1527271883293};\\\", \\\"{x:163,y:540,t:1527271883309};\\\", \\\"{x:165,y:540,t:1527271883325};\\\", \\\"{x:175,y:542,t:1527271883342};\\\", \\\"{x:185,y:553,t:1527271883358};\\\", \\\"{x:187,y:567,t:1527271883375};\\\", \\\"{x:189,y:581,t:1527271883392};\\\", \\\"{x:189,y:591,t:1527271883408};\\\", \\\"{x:188,y:599,t:1527271883424};\\\", \\\"{x:185,y:605,t:1527271883442};\\\", \\\"{x:185,y:607,t:1527271883458};\\\", \\\"{x:184,y:608,t:1527271883565};\\\", \\\"{x:183,y:610,t:1527271883574};\\\", \\\"{x:174,y:616,t:1527271883591};\\\", \\\"{x:166,y:622,t:1527271883609};\\\", \\\"{x:160,y:628,t:1527271883625};\\\", \\\"{x:157,y:632,t:1527271883641};\\\", \\\"{x:156,y:635,t:1527271883659};\\\", \\\"{x:156,y:636,t:1527271883676};\\\", \\\"{x:155,y:636,t:1527271885621};\\\", \\\"{x:155,y:634,t:1527271885700};\\\", \\\"{x:159,y:625,t:1527271885710};\\\", \\\"{x:168,y:617,t:1527271885727};\\\", \\\"{x:173,y:614,t:1527271885744};\\\", \\\"{x:174,y:613,t:1527271885760};\\\", \\\"{x:176,y:610,t:1527271885777};\\\", \\\"{x:178,y:610,t:1527271885794};\\\", \\\"{x:178,y:609,t:1527271885810};\\\", \\\"{x:179,y:608,t:1527271885827};\\\", \\\"{x:181,y:605,t:1527271885844};\\\", \\\"{x:183,y:601,t:1527271885860};\\\", \\\"{x:191,y:597,t:1527271885877};\\\", \\\"{x:202,y:592,t:1527271885894};\\\", \\\"{x:212,y:591,t:1527271885910};\\\", \\\"{x:223,y:588,t:1527271885927};\\\", \\\"{x:233,y:587,t:1527271885943};\\\", \\\"{x:238,y:586,t:1527271885960};\\\", \\\"{x:241,y:585,t:1527271885977};\\\", \\\"{x:242,y:584,t:1527271885994};\\\", \\\"{x:244,y:584,t:1527271886010};\\\", \\\"{x:252,y:584,t:1527271886027};\\\", \\\"{x:263,y:584,t:1527271886044};\\\", \\\"{x:268,y:584,t:1527271886060};\\\", \\\"{x:285,y:584,t:1527271886077};\\\", \\\"{x:298,y:584,t:1527271886094};\\\", \\\"{x:313,y:584,t:1527271886110};\\\", \\\"{x:324,y:584,t:1527271886127};\\\", \\\"{x:331,y:584,t:1527271886144};\\\", \\\"{x:339,y:584,t:1527271886161};\\\", \\\"{x:344,y:584,t:1527271886176};\\\", \\\"{x:349,y:584,t:1527271886194};\\\", \\\"{x:350,y:584,t:1527271886211};\\\", \\\"{x:351,y:584,t:1527271886226};\\\", \\\"{x:354,y:584,t:1527271886244};\\\", \\\"{x:359,y:584,t:1527271886261};\\\", \\\"{x:363,y:584,t:1527271886276};\\\", \\\"{x:367,y:584,t:1527271886294};\\\", \\\"{x:370,y:584,t:1527271886310};\\\", \\\"{x:374,y:584,t:1527271886328};\\\", \\\"{x:377,y:585,t:1527271886344};\\\", \\\"{x:381,y:588,t:1527271886361};\\\", \\\"{x:385,y:591,t:1527271886376};\\\", \\\"{x:389,y:593,t:1527271886393};\\\", \\\"{x:393,y:596,t:1527271886411};\\\", \\\"{x:396,y:598,t:1527271886427};\\\", \\\"{x:398,y:600,t:1527271886444};\\\", \\\"{x:401,y:603,t:1527271886460};\\\", \\\"{x:405,y:605,t:1527271886477};\\\", \\\"{x:412,y:610,t:1527271886494};\\\", \\\"{x:423,y:619,t:1527271886512};\\\", \\\"{x:438,y:628,t:1527271886528};\\\", \\\"{x:449,y:635,t:1527271886544};\\\", \\\"{x:457,y:639,t:1527271886561};\\\", \\\"{x:465,y:644,t:1527271886578};\\\", \\\"{x:477,y:649,t:1527271886593};\\\", \\\"{x:485,y:651,t:1527271886611};\\\", \\\"{x:496,y:658,t:1527271886628};\\\", \\\"{x:508,y:662,t:1527271886644};\\\", \\\"{x:523,y:669,t:1527271886661};\\\", \\\"{x:541,y:677,t:1527271886678};\\\", \\\"{x:558,y:685,t:1527271886693};\\\", \\\"{x:567,y:689,t:1527271886711};\\\", \\\"{x:572,y:691,t:1527271886728};\\\", \\\"{x:574,y:693,t:1527271886744};\\\", \\\"{x:575,y:694,t:1527271886760};\\\", \\\"{x:577,y:696,t:1527271886778};\\\", \\\"{x:578,y:701,t:1527271886794};\\\", \\\"{x:584,y:709,t:1527271886811};\\\", \\\"{x:590,y:718,t:1527271886828};\\\", \\\"{x:592,y:722,t:1527271886844};\\\", \\\"{x:592,y:723,t:1527271886876};\\\", \\\"{x:592,y:724,t:1527271886884};\\\", \\\"{x:592,y:725,t:1527271886894};\\\", \\\"{x:592,y:726,t:1527271886911};\\\", \\\"{x:592,y:728,t:1527271886928};\\\", \\\"{x:592,y:729,t:1527271886945};\\\", \\\"{x:589,y:733,t:1527271886961};\\\", \\\"{x:583,y:734,t:1527271886978};\\\", \\\"{x:568,y:734,t:1527271886995};\\\", \\\"{x:552,y:734,t:1527271887012};\\\", \\\"{x:537,y:734,t:1527271887028};\\\", \\\"{x:531,y:734,t:1527271887044};\\\", \\\"{x:529,y:734,t:1527271887061};\\\", \\\"{x:528,y:734,t:1527271887078};\\\", \\\"{x:528,y:733,t:1527271887245};\\\", \\\"{x:528,y:732,t:1527271887284};\\\", \\\"{x:528,y:731,t:1527271887332};\\\", \\\"{x:528,y:730,t:1527271887345};\\\", \\\"{x:528,y:729,t:1527271887361};\\\", \\\"{x:528,y:728,t:1527271887378};\\\", \\\"{x:528,y:727,t:1527271887525};\\\", \\\"{x:528,y:726,t:1527271887621};\\\", \\\"{x:528,y:725,t:1527271887627};\\\", \\\"{x:528,y:723,t:1527271887645};\\\", \\\"{x:528,y:719,t:1527271887661};\\\", \\\"{x:528,y:718,t:1527271887700};\\\", \\\"{x:528,y:717,t:1527271887988};\\\", \\\"{x:528,y:716,t:1527271889621};\\\", \\\"{x:528,y:711,t:1527271891389};\\\", \\\"{x:525,y:702,t:1527271891399};\\\", \\\"{x:520,y:688,t:1527271891415};\\\", \\\"{x:515,y:673,t:1527271891431};\\\", \\\"{x:510,y:658,t:1527271891448};\\\", \\\"{x:505,y:635,t:1527271891465};\\\", \\\"{x:505,y:574,t:1527271891481};\\\", \\\"{x:533,y:500,t:1527271891498};\\\", \\\"{x:580,y:473,t:1527271891515};\\\", \\\"{x:633,y:465,t:1527271891531};\\\", \\\"{x:700,y:465,t:1527271891548};\\\", \\\"{x:753,y:465,t:1527271891565};\\\", \\\"{x:804,y:465,t:1527271891581};\\\", \\\"{x:832,y:465,t:1527271891598};\\\", \\\"{x:853,y:465,t:1527271891616};\\\", \\\"{x:862,y:465,t:1527271891631};\\\", \\\"{x:869,y:465,t:1527271891648};\\\", \\\"{x:870,y:464,t:1527271891804};\\\", \\\"{x:870,y:463,t:1527271891828};\\\", \\\"{x:867,y:462,t:1527271891836};\\\", \\\"{x:865,y:461,t:1527271891848};\\\", \\\"{x:860,y:460,t:1527271891865};\\\", \\\"{x:860,y:459,t:1527271891900};\\\", \\\"{x:859,y:459,t:1527271891916};\\\", \\\"{x:858,y:459,t:1527271891932};\\\", \\\"{x:858,y:458,t:1527271891958};\\\", \\\"{x:857,y:458,t:1527271892052};\\\" ] }, { \\\"rt\\\": 52785, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 481354, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-10 AM-C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:835,y:454,t:1527271892211};\\\", \\\"{x:818,y:454,t:1527271892219};\\\", \\\"{x:785,y:454,t:1527271892236};\\\", \\\"{x:775,y:454,t:1527271892249};\\\", \\\"{x:757,y:454,t:1527271892265};\\\", \\\"{x:743,y:454,t:1527271892282};\\\", \\\"{x:736,y:454,t:1527271892299};\\\", \\\"{x:733,y:454,t:1527271892325};\\\", \\\"{x:732,y:454,t:1527271892396};\\\", \\\"{x:682,y:454,t:1527271892627};\\\", \\\"{x:673,y:454,t:1527271892633};\\\", \\\"{x:658,y:454,t:1527271892649};\\\", \\\"{x:640,y:454,t:1527271892666};\\\", \\\"{x:631,y:454,t:1527271892683};\\\", \\\"{x:622,y:454,t:1527271892699};\\\", \\\"{x:606,y:452,t:1527271892716};\\\", \\\"{x:596,y:451,t:1527271892732};\\\", \\\"{x:578,y:448,t:1527271892749};\\\", \\\"{x:555,y:448,t:1527271892766};\\\", \\\"{x:536,y:448,t:1527271892783};\\\", \\\"{x:523,y:448,t:1527271892800};\\\", \\\"{x:513,y:450,t:1527271892816};\\\", \\\"{x:509,y:452,t:1527271892832};\\\", \\\"{x:507,y:455,t:1527271892849};\\\", \\\"{x:506,y:458,t:1527271892866};\\\", \\\"{x:505,y:462,t:1527271892882};\\\", \\\"{x:504,y:466,t:1527271892899};\\\", \\\"{x:503,y:471,t:1527271892916};\\\", \\\"{x:502,y:477,t:1527271892932};\\\", \\\"{x:502,y:482,t:1527271892949};\\\", \\\"{x:501,y:483,t:1527271892966};\\\", \\\"{x:500,y:484,t:1527271892982};\\\", \\\"{x:500,y:485,t:1527271892999};\\\", \\\"{x:499,y:486,t:1527271893016};\\\", \\\"{x:498,y:488,t:1527271893032};\\\", \\\"{x:496,y:490,t:1527271893049};\\\", \\\"{x:494,y:492,t:1527271893066};\\\", \\\"{x:491,y:494,t:1527271893083};\\\", \\\"{x:488,y:496,t:1527271893099};\\\", \\\"{x:483,y:498,t:1527271893116};\\\", \\\"{x:479,y:499,t:1527271893134};\\\", \\\"{x:478,y:500,t:1527271893149};\\\", \\\"{x:477,y:500,t:1527271893180};\\\", \\\"{x:476,y:500,t:1527271893212};\\\", \\\"{x:474,y:500,t:1527271893220};\\\", \\\"{x:472,y:500,t:1527271893236};\\\", \\\"{x:470,y:500,t:1527271893249};\\\", \\\"{x:469,y:500,t:1527271893268};\\\", \\\"{x:466,y:500,t:1527271893283};\\\", \\\"{x:462,y:500,t:1527271893299};\\\", \\\"{x:451,y:500,t:1527271893316};\\\", \\\"{x:434,y:496,t:1527271893333};\\\", \\\"{x:418,y:495,t:1527271893349};\\\", \\\"{x:409,y:493,t:1527271893366};\\\", \\\"{x:402,y:492,t:1527271893383};\\\", \\\"{x:401,y:491,t:1527271893404};\\\", \\\"{x:400,y:491,t:1527271893797};\\\", \\\"{x:398,y:491,t:1527271893805};\\\", \\\"{x:397,y:490,t:1527271893816};\\\", \\\"{x:395,y:489,t:1527271893833};\\\", \\\"{x:394,y:489,t:1527271893850};\\\", \\\"{x:392,y:488,t:1527271893866};\\\", \\\"{x:391,y:488,t:1527271893884};\\\", \\\"{x:390,y:488,t:1527271893900};\\\", \\\"{x:388,y:486,t:1527271893917};\\\", \\\"{x:382,y:485,t:1527271893933};\\\", \\\"{x:376,y:484,t:1527271893950};\\\", \\\"{x:374,y:482,t:1527271893966};\\\", \\\"{x:370,y:481,t:1527271893983};\\\", \\\"{x:368,y:481,t:1527271894000};\\\", \\\"{x:367,y:481,t:1527271894044};\\\", \\\"{x:365,y:479,t:1527271894061};\\\", \\\"{x:364,y:479,t:1527271894068};\\\", \\\"{x:359,y:478,t:1527271894084};\\\", \\\"{x:347,y:472,t:1527271894100};\\\", \\\"{x:341,y:469,t:1527271894117};\\\", \\\"{x:337,y:468,t:1527271894133};\\\", \\\"{x:336,y:468,t:1527271894164};\\\", \\\"{x:335,y:467,t:1527271894172};\\\", \\\"{x:333,y:466,t:1527271894197};\\\", \\\"{x:331,y:465,t:1527271894204};\\\", \\\"{x:328,y:463,t:1527271894217};\\\", \\\"{x:321,y:459,t:1527271894234};\\\", \\\"{x:314,y:453,t:1527271894250};\\\", \\\"{x:308,y:448,t:1527271894267};\\\", \\\"{x:304,y:446,t:1527271894283};\\\", \\\"{x:300,y:444,t:1527271894300};\\\", \\\"{x:298,y:442,t:1527271894317};\\\", \\\"{x:294,y:441,t:1527271894333};\\\", \\\"{x:290,y:439,t:1527271894351};\\\", \\\"{x:288,y:438,t:1527271894368};\\\", \\\"{x:286,y:437,t:1527271894383};\\\", \\\"{x:285,y:437,t:1527271894400};\\\", \\\"{x:280,y:435,t:1527271894417};\\\", \\\"{x:278,y:435,t:1527271894433};\\\", \\\"{x:277,y:435,t:1527271894451};\\\", \\\"{x:273,y:438,t:1527271894500};\\\", \\\"{x:266,y:470,t:1527271894518};\\\", \\\"{x:258,y:513,t:1527271894535};\\\", \\\"{x:258,y:558,t:1527271894551};\\\", \\\"{x:263,y:608,t:1527271894568};\\\", \\\"{x:290,y:661,t:1527271894585};\\\", \\\"{x:335,y:712,t:1527271894600};\\\", \\\"{x:376,y:747,t:1527271894618};\\\", \\\"{x:406,y:771,t:1527271894634};\\\", \\\"{x:422,y:781,t:1527271894650};\\\", \\\"{x:429,y:784,t:1527271894667};\\\", \\\"{x:430,y:785,t:1527271894684};\\\", \\\"{x:432,y:785,t:1527271894724};\\\", \\\"{x:433,y:785,t:1527271894735};\\\", \\\"{x:441,y:782,t:1527271894751};\\\", \\\"{x:448,y:777,t:1527271894767};\\\", \\\"{x:458,y:763,t:1527271894784};\\\", \\\"{x:469,y:741,t:1527271894801};\\\", \\\"{x:478,y:721,t:1527271894818};\\\", \\\"{x:484,y:704,t:1527271894834};\\\", \\\"{x:486,y:693,t:1527271894852};\\\", \\\"{x:486,y:688,t:1527271894868};\\\", \\\"{x:486,y:686,t:1527271894884};\\\", \\\"{x:486,y:684,t:1527271894901};\\\", \\\"{x:486,y:683,t:1527271894940};\\\", \\\"{x:486,y:681,t:1527271894956};\\\", \\\"{x:486,y:680,t:1527271894973};\\\", \\\"{x:486,y:677,t:1527271894985};\\\", \\\"{x:486,y:668,t:1527271895002};\\\", \\\"{x:485,y:661,t:1527271895018};\\\", \\\"{x:483,y:649,t:1527271895035};\\\", \\\"{x:480,y:636,t:1527271895052};\\\", \\\"{x:479,y:625,t:1527271895067};\\\", \\\"{x:480,y:605,t:1527271895084};\\\", \\\"{x:487,y:589,t:1527271895101};\\\", \\\"{x:497,y:574,t:1527271895118};\\\", \\\"{x:504,y:562,t:1527271895135};\\\", \\\"{x:506,y:559,t:1527271895152};\\\", \\\"{x:508,y:559,t:1527271895175};\\\", \\\"{x:510,y:557,t:1527271895190};\\\", \\\"{x:512,y:557,t:1527271895201};\\\", \\\"{x:521,y:554,t:1527271895218};\\\", \\\"{x:533,y:550,t:1527271895234};\\\", \\\"{x:552,y:540,t:1527271895252};\\\", \\\"{x:587,y:527,t:1527271895268};\\\", \\\"{x:604,y:518,t:1527271895284};\\\", \\\"{x:616,y:512,t:1527271895301};\\\", \\\"{x:620,y:511,t:1527271895318};\\\", \\\"{x:620,y:510,t:1527271895397};\\\", \\\"{x:620,y:509,t:1527271895420};\\\", \\\"{x:616,y:508,t:1527271895437};\\\", \\\"{x:613,y:508,t:1527271895452};\\\", \\\"{x:607,y:508,t:1527271895467};\\\", \\\"{x:595,y:508,t:1527271895484};\\\", \\\"{x:585,y:508,t:1527271895502};\\\", \\\"{x:576,y:508,t:1527271895517};\\\", \\\"{x:568,y:508,t:1527271895534};\\\", \\\"{x:564,y:508,t:1527271895551};\\\", \\\"{x:560,y:508,t:1527271895567};\\\", \\\"{x:559,y:507,t:1527271895584};\\\", \\\"{x:557,y:506,t:1527271895600};\\\", \\\"{x:556,y:505,t:1527271895669};\\\", \\\"{x:556,y:501,t:1527271895853};\\\", \\\"{x:558,y:491,t:1527271895868};\\\", \\\"{x:560,y:486,t:1527271895886};\\\", \\\"{x:560,y:485,t:1527271895902};\\\", \\\"{x:562,y:483,t:1527271895918};\\\", \\\"{x:562,y:482,t:1527271895936};\\\", \\\"{x:562,y:477,t:1527271895953};\\\", \\\"{x:562,y:472,t:1527271895969};\\\", \\\"{x:562,y:468,t:1527271895985};\\\", \\\"{x:562,y:465,t:1527271896002};\\\", \\\"{x:562,y:462,t:1527271896019};\\\", \\\"{x:562,y:457,t:1527271896036};\\\", \\\"{x:562,y:455,t:1527271896052};\\\", \\\"{x:562,y:454,t:1527271896069};\\\", \\\"{x:562,y:453,t:1527271896109};\\\", \\\"{x:562,y:454,t:1527271896868};\\\", \\\"{x:562,y:455,t:1527271896876};\\\", \\\"{x:562,y:457,t:1527271896887};\\\", \\\"{x:561,y:462,t:1527271896903};\\\", \\\"{x:559,y:466,t:1527271896920};\\\", \\\"{x:558,y:468,t:1527271896937};\\\", \\\"{x:558,y:471,t:1527271896953};\\\", \\\"{x:558,y:472,t:1527271896969};\\\", \\\"{x:557,y:473,t:1527271896986};\\\", \\\"{x:557,y:474,t:1527271897028};\\\", \\\"{x:557,y:475,t:1527271897052};\\\", \\\"{x:557,y:476,t:1527271897068};\\\", \\\"{x:557,y:477,t:1527271897076};\\\", \\\"{x:557,y:478,t:1527271897101};\\\", \\\"{x:557,y:479,t:1527271897108};\\\", \\\"{x:556,y:479,t:1527271897119};\\\", \\\"{x:556,y:480,t:1527271897137};\\\", \\\"{x:555,y:482,t:1527271897154};\\\", \\\"{x:555,y:485,t:1527271897169};\\\", \\\"{x:554,y:489,t:1527271897187};\\\", \\\"{x:554,y:492,t:1527271897203};\\\", \\\"{x:554,y:497,t:1527271897220};\\\", \\\"{x:554,y:501,t:1527271897236};\\\", \\\"{x:554,y:503,t:1527271897253};\\\", \\\"{x:554,y:506,t:1527271897271};\\\", \\\"{x:554,y:508,t:1527271897287};\\\", \\\"{x:554,y:510,t:1527271897308};\\\", \\\"{x:554,y:511,t:1527271897319};\\\", \\\"{x:554,y:516,t:1527271897336};\\\", \\\"{x:554,y:524,t:1527271897353};\\\", \\\"{x:558,y:534,t:1527271897369};\\\", \\\"{x:562,y:541,t:1527271897388};\\\", \\\"{x:568,y:549,t:1527271897404};\\\", \\\"{x:575,y:558,t:1527271897419};\\\", \\\"{x:595,y:581,t:1527271897437};\\\", \\\"{x:609,y:597,t:1527271897454};\\\", \\\"{x:623,y:612,t:1527271897470};\\\", \\\"{x:640,y:627,t:1527271897487};\\\", \\\"{x:653,y:638,t:1527271897504};\\\", \\\"{x:656,y:642,t:1527271897520};\\\", \\\"{x:658,y:645,t:1527271897536};\\\", \\\"{x:660,y:647,t:1527271897553};\\\", \\\"{x:660,y:648,t:1527271897572};\\\", \\\"{x:662,y:651,t:1527271897587};\\\", \\\"{x:667,y:657,t:1527271897604};\\\", \\\"{x:678,y:670,t:1527271897620};\\\", \\\"{x:700,y:692,t:1527271897636};\\\", \\\"{x:714,y:704,t:1527271897653};\\\", \\\"{x:728,y:716,t:1527271897669};\\\", \\\"{x:739,y:726,t:1527271897687};\\\", \\\"{x:752,y:736,t:1527271897704};\\\", \\\"{x:763,y:748,t:1527271897719};\\\", \\\"{x:773,y:757,t:1527271897736};\\\", \\\"{x:784,y:767,t:1527271897754};\\\", \\\"{x:792,y:773,t:1527271897770};\\\", \\\"{x:798,y:777,t:1527271897787};\\\", \\\"{x:801,y:779,t:1527271897804};\\\", \\\"{x:802,y:780,t:1527271897821};\\\", \\\"{x:802,y:781,t:1527271897836};\\\", \\\"{x:803,y:781,t:1527271897854};\\\", \\\"{x:804,y:781,t:1527271897893};\\\", \\\"{x:805,y:781,t:1527271897917};\\\", \\\"{x:805,y:782,t:1527271897925};\\\", \\\"{x:806,y:782,t:1527271897936};\\\", \\\"{x:807,y:784,t:1527271897954};\\\", \\\"{x:809,y:787,t:1527271897971};\\\", \\\"{x:812,y:790,t:1527271897987};\\\", \\\"{x:817,y:794,t:1527271898003};\\\", \\\"{x:825,y:800,t:1527271898020};\\\", \\\"{x:829,y:801,t:1527271898036};\\\", \\\"{x:829,y:802,t:1527271898054};\\\", \\\"{x:840,y:804,t:1527271898412};\\\", \\\"{x:860,y:810,t:1527271898420};\\\", \\\"{x:924,y:829,t:1527271898438};\\\", \\\"{x:1015,y:853,t:1527271898454};\\\", \\\"{x:1099,y:879,t:1527271898471};\\\", \\\"{x:1175,y:905,t:1527271898488};\\\", \\\"{x:1243,y:930,t:1527271898503};\\\", \\\"{x:1282,y:947,t:1527271898521};\\\", \\\"{x:1298,y:955,t:1527271898538};\\\", \\\"{x:1301,y:957,t:1527271898554};\\\", \\\"{x:1301,y:958,t:1527271898605};\\\", \\\"{x:1301,y:960,t:1527271898621};\\\", \\\"{x:1301,y:962,t:1527271898638};\\\", \\\"{x:1300,y:965,t:1527271898654};\\\", \\\"{x:1294,y:970,t:1527271898671};\\\", \\\"{x:1282,y:975,t:1527271898688};\\\", \\\"{x:1269,y:977,t:1527271898705};\\\", \\\"{x:1258,y:980,t:1527271898721};\\\", \\\"{x:1249,y:981,t:1527271898738};\\\", \\\"{x:1236,y:983,t:1527271898754};\\\", \\\"{x:1220,y:986,t:1527271898771};\\\", \\\"{x:1207,y:987,t:1527271898787};\\\", \\\"{x:1194,y:990,t:1527271898804};\\\", \\\"{x:1189,y:990,t:1527271898820};\\\", \\\"{x:1188,y:990,t:1527271898838};\\\", \\\"{x:1187,y:990,t:1527271898981};\\\", \\\"{x:1187,y:987,t:1527271899172};\\\", \\\"{x:1187,y:984,t:1527271899187};\\\", \\\"{x:1191,y:975,t:1527271899204};\\\", \\\"{x:1196,y:969,t:1527271899222};\\\", \\\"{x:1199,y:966,t:1527271899238};\\\", \\\"{x:1204,y:963,t:1527271899255};\\\", \\\"{x:1205,y:962,t:1527271899272};\\\", \\\"{x:1206,y:962,t:1527271899332};\\\", \\\"{x:1207,y:962,t:1527271899340};\\\", \\\"{x:1208,y:962,t:1527271899355};\\\", \\\"{x:1212,y:962,t:1527271899372};\\\", \\\"{x:1213,y:962,t:1527271899388};\\\", \\\"{x:1216,y:962,t:1527271899405};\\\", \\\"{x:1217,y:962,t:1527271899422};\\\", \\\"{x:1218,y:962,t:1527271899444};\\\", \\\"{x:1219,y:962,t:1527271899455};\\\", \\\"{x:1220,y:962,t:1527271899524};\\\", \\\"{x:1220,y:960,t:1527271899540};\\\", \\\"{x:1220,y:957,t:1527271899555};\\\", \\\"{x:1219,y:951,t:1527271899571};\\\", \\\"{x:1217,y:932,t:1527271899588};\\\", \\\"{x:1213,y:911,t:1527271899604};\\\", \\\"{x:1213,y:901,t:1527271899621};\\\", \\\"{x:1213,y:897,t:1527271899639};\\\", \\\"{x:1213,y:895,t:1527271899655};\\\", \\\"{x:1213,y:893,t:1527271899672};\\\", \\\"{x:1215,y:887,t:1527271899688};\\\", \\\"{x:1217,y:878,t:1527271899705};\\\", \\\"{x:1218,y:868,t:1527271899721};\\\", \\\"{x:1218,y:861,t:1527271899739};\\\", \\\"{x:1218,y:860,t:1527271899780};\\\", \\\"{x:1219,y:857,t:1527271899804};\\\", \\\"{x:1219,y:854,t:1527271899822};\\\", \\\"{x:1219,y:851,t:1527271899839};\\\", \\\"{x:1219,y:848,t:1527271899855};\\\", \\\"{x:1219,y:847,t:1527271899872};\\\", \\\"{x:1219,y:846,t:1527271899888};\\\", \\\"{x:1218,y:845,t:1527271900084};\\\", \\\"{x:1216,y:844,t:1527271900108};\\\", \\\"{x:1215,y:844,t:1527271900124};\\\", \\\"{x:1214,y:844,t:1527271900138};\\\", \\\"{x:1212,y:843,t:1527271900156};\\\", \\\"{x:1209,y:842,t:1527271900171};\\\", \\\"{x:1209,y:841,t:1527271900188};\\\", \\\"{x:1208,y:841,t:1527271900485};\\\", \\\"{x:1208,y:840,t:1527271900533};\\\", \\\"{x:1208,y:839,t:1527271900540};\\\", \\\"{x:1208,y:838,t:1527271900556};\\\", \\\"{x:1209,y:837,t:1527271900668};\\\", \\\"{x:1210,y:835,t:1527271900692};\\\", \\\"{x:1211,y:835,t:1527271900740};\\\", \\\"{x:1212,y:835,t:1527271900797};\\\", \\\"{x:1214,y:835,t:1527271917780};\\\", \\\"{x:1215,y:835,t:1527271917804};\\\", \\\"{x:1217,y:835,t:1527271917820};\\\", \\\"{x:1216,y:834,t:1527271920628};\\\", \\\"{x:1218,y:832,t:1527271922164};\\\", \\\"{x:1220,y:831,t:1527271922173};\\\", \\\"{x:1223,y:829,t:1527271922190};\\\", \\\"{x:1224,y:829,t:1527271922207};\\\", \\\"{x:1227,y:828,t:1527271922222};\\\", \\\"{x:1229,y:827,t:1527271922240};\\\", \\\"{x:1231,y:827,t:1527271922257};\\\", \\\"{x:1232,y:826,t:1527271922272};\\\", \\\"{x:1233,y:825,t:1527271922292};\\\", \\\"{x:1234,y:825,t:1527271922308};\\\", \\\"{x:1235,y:824,t:1527271922323};\\\", \\\"{x:1237,y:824,t:1527271922356};\\\", \\\"{x:1238,y:822,t:1527271922372};\\\", \\\"{x:1242,y:821,t:1527271922390};\\\", \\\"{x:1245,y:821,t:1527271922407};\\\", \\\"{x:1249,y:820,t:1527271922423};\\\", \\\"{x:1252,y:819,t:1527271922440};\\\", \\\"{x:1253,y:819,t:1527271922456};\\\", \\\"{x:1254,y:819,t:1527271922473};\\\", \\\"{x:1255,y:818,t:1527271922490};\\\", \\\"{x:1257,y:817,t:1527271922507};\\\", \\\"{x:1259,y:817,t:1527271922523};\\\", \\\"{x:1263,y:817,t:1527271922539};\\\", \\\"{x:1266,y:817,t:1527271922557};\\\", \\\"{x:1271,y:817,t:1527271922574};\\\", \\\"{x:1277,y:817,t:1527271922590};\\\", \\\"{x:1285,y:817,t:1527271922607};\\\", \\\"{x:1297,y:816,t:1527271922623};\\\", \\\"{x:1303,y:816,t:1527271922639};\\\", \\\"{x:1312,y:816,t:1527271922657};\\\", \\\"{x:1319,y:816,t:1527271922673};\\\", \\\"{x:1327,y:816,t:1527271922690};\\\", \\\"{x:1332,y:816,t:1527271922707};\\\", \\\"{x:1342,y:816,t:1527271922724};\\\", \\\"{x:1351,y:816,t:1527271922739};\\\", \\\"{x:1354,y:818,t:1527271922756};\\\", \\\"{x:1358,y:819,t:1527271922774};\\\", \\\"{x:1358,y:820,t:1527271922988};\\\", \\\"{x:1357,y:821,t:1527271922996};\\\", \\\"{x:1357,y:822,t:1527271923012};\\\", \\\"{x:1356,y:822,t:1527271923084};\\\", \\\"{x:1356,y:823,t:1527271923100};\\\", \\\"{x:1355,y:823,t:1527271923116};\\\", \\\"{x:1355,y:824,t:1527271923132};\\\", \\\"{x:1355,y:825,t:1527271923172};\\\", \\\"{x:1355,y:826,t:1527271923620};\\\", \\\"{x:1355,y:827,t:1527271923636};\\\", \\\"{x:1355,y:828,t:1527271923644};\\\", \\\"{x:1353,y:828,t:1527271924292};\\\", \\\"{x:1352,y:828,t:1527271924308};\\\", \\\"{x:1351,y:828,t:1527271924325};\\\", \\\"{x:1350,y:828,t:1527271924428};\\\", \\\"{x:1349,y:828,t:1527271924442};\\\", \\\"{x:1348,y:828,t:1527271924458};\\\", \\\"{x:1348,y:827,t:1527271924604};\\\", \\\"{x:1348,y:825,t:1527271924611};\\\", \\\"{x:1348,y:824,t:1527271924636};\\\", \\\"{x:1348,y:822,t:1527271924652};\\\", \\\"{x:1348,y:821,t:1527271924660};\\\", \\\"{x:1348,y:818,t:1527271924675};\\\", \\\"{x:1347,y:811,t:1527271924692};\\\", \\\"{x:1346,y:802,t:1527271924707};\\\", \\\"{x:1345,y:796,t:1527271924725};\\\", \\\"{x:1343,y:785,t:1527271924742};\\\", \\\"{x:1343,y:773,t:1527271924759};\\\", \\\"{x:1343,y:762,t:1527271924775};\\\", \\\"{x:1343,y:756,t:1527271924792};\\\", \\\"{x:1343,y:752,t:1527271924809};\\\", \\\"{x:1341,y:748,t:1527271924825};\\\", \\\"{x:1341,y:746,t:1527271924860};\\\", \\\"{x:1341,y:745,t:1527271924875};\\\", \\\"{x:1346,y:727,t:1527271924892};\\\", \\\"{x:1348,y:719,t:1527271924908};\\\", \\\"{x:1350,y:711,t:1527271924925};\\\", \\\"{x:1351,y:708,t:1527271924942};\\\", \\\"{x:1352,y:706,t:1527271924959};\\\", \\\"{x:1353,y:704,t:1527271924988};\\\", \\\"{x:1353,y:703,t:1527271924996};\\\", \\\"{x:1354,y:700,t:1527271925009};\\\", \\\"{x:1357,y:693,t:1527271925025};\\\", \\\"{x:1359,y:690,t:1527271925042};\\\", \\\"{x:1360,y:687,t:1527271925059};\\\", \\\"{x:1361,y:686,t:1527271925074};\\\", \\\"{x:1360,y:686,t:1527271925116};\\\", \\\"{x:1356,y:686,t:1527271925126};\\\", \\\"{x:1351,y:688,t:1527271925142};\\\", \\\"{x:1344,y:690,t:1527271925159};\\\", \\\"{x:1341,y:692,t:1527271925176};\\\", \\\"{x:1340,y:693,t:1527271925211};\\\", \\\"{x:1340,y:694,t:1527271925244};\\\", \\\"{x:1340,y:695,t:1527271925276};\\\", \\\"{x:1340,y:697,t:1527271925300};\\\", \\\"{x:1340,y:698,t:1527271925324};\\\", \\\"{x:1340,y:699,t:1527271925340};\\\", \\\"{x:1340,y:700,t:1527271925348};\\\", \\\"{x:1341,y:701,t:1527271925359};\\\", \\\"{x:1342,y:701,t:1527271925380};\\\", \\\"{x:1342,y:702,t:1527271925392};\\\", \\\"{x:1343,y:702,t:1527271941164};\\\", \\\"{x:1344,y:702,t:1527271941196};\\\", \\\"{x:1344,y:701,t:1527271941340};\\\", \\\"{x:1337,y:698,t:1527271941354};\\\", \\\"{x:1192,y:644,t:1527271941371};\\\", \\\"{x:972,y:587,t:1527271941388};\\\", \\\"{x:761,y:548,t:1527271941405};\\\", \\\"{x:584,y:548,t:1527271941422};\\\", \\\"{x:471,y:563,t:1527271941439};\\\", \\\"{x:418,y:565,t:1527271941455};\\\", \\\"{x:405,y:568,t:1527271941473};\\\", \\\"{x:396,y:569,t:1527271941490};\\\", \\\"{x:382,y:577,t:1527271941506};\\\", \\\"{x:366,y:587,t:1527271941523};\\\", \\\"{x:327,y:609,t:1527271941540};\\\", \\\"{x:311,y:619,t:1527271941556};\\\", \\\"{x:303,y:621,t:1527271941573};\\\", \\\"{x:300,y:622,t:1527271941589};\\\", \\\"{x:291,y:621,t:1527271941605};\\\", \\\"{x:284,y:620,t:1527271941622};\\\", \\\"{x:282,y:620,t:1527271941640};\\\", \\\"{x:283,y:620,t:1527271941676};\\\", \\\"{x:284,y:620,t:1527271941689};\\\", \\\"{x:289,y:620,t:1527271941706};\\\", \\\"{x:294,y:622,t:1527271941724};\\\", \\\"{x:294,y:618,t:1527271941798};\\\", \\\"{x:293,y:612,t:1527271941807};\\\", \\\"{x:281,y:599,t:1527271941823};\\\", \\\"{x:266,y:590,t:1527271941840};\\\", \\\"{x:251,y:585,t:1527271941856};\\\", \\\"{x:235,y:582,t:1527271941872};\\\", \\\"{x:209,y:582,t:1527271941890};\\\", \\\"{x:184,y:584,t:1527271941906};\\\", \\\"{x:168,y:586,t:1527271941924};\\\", \\\"{x:158,y:586,t:1527271941940};\\\", \\\"{x:153,y:586,t:1527271941956};\\\", \\\"{x:146,y:583,t:1527271941973};\\\", \\\"{x:142,y:580,t:1527271941990};\\\", \\\"{x:140,y:578,t:1527271942007};\\\", \\\"{x:138,y:574,t:1527271942024};\\\", \\\"{x:138,y:567,t:1527271942040};\\\", \\\"{x:138,y:561,t:1527271942056};\\\", \\\"{x:139,y:557,t:1527271942073};\\\", \\\"{x:139,y:556,t:1527271942090};\\\", \\\"{x:141,y:556,t:1527271942131};\\\", \\\"{x:143,y:556,t:1527271942139};\\\", \\\"{x:149,y:565,t:1527271942156};\\\", \\\"{x:152,y:570,t:1527271942173};\\\", \\\"{x:156,y:575,t:1527271942190};\\\", \\\"{x:159,y:579,t:1527271942206};\\\", \\\"{x:162,y:588,t:1527271942223};\\\", \\\"{x:166,y:597,t:1527271942239};\\\", \\\"{x:168,y:602,t:1527271942257};\\\", \\\"{x:173,y:608,t:1527271942273};\\\", \\\"{x:173,y:609,t:1527271942289};\\\", \\\"{x:174,y:610,t:1527271942307};\\\", \\\"{x:172,y:610,t:1527271942452};\\\", \\\"{x:166,y:609,t:1527271942460};\\\", \\\"{x:161,y:600,t:1527271942474};\\\", \\\"{x:159,y:593,t:1527271942489};\\\", \\\"{x:154,y:586,t:1527271942507};\\\", \\\"{x:150,y:580,t:1527271942524};\\\", \\\"{x:149,y:579,t:1527271942540};\\\", \\\"{x:149,y:578,t:1527271942556};\\\", \\\"{x:149,y:577,t:1527271942661};\\\", \\\"{x:149,y:576,t:1527271942676};\\\", \\\"{x:149,y:575,t:1527271942708};\\\", \\\"{x:149,y:572,t:1527271942765};\\\", \\\"{x:149,y:568,t:1527271942775};\\\", \\\"{x:149,y:564,t:1527271942790};\\\", \\\"{x:149,y:563,t:1527271942916};\\\", \\\"{x:152,y:564,t:1527271944123};\\\", \\\"{x:187,y:585,t:1527271944140};\\\", \\\"{x:262,y:622,t:1527271944157};\\\", \\\"{x:370,y:668,t:1527271944173};\\\", \\\"{x:493,y:715,t:1527271944190};\\\", \\\"{x:596,y:747,t:1527271944206};\\\", \\\"{x:688,y:781,t:1527271944223};\\\", \\\"{x:770,y:809,t:1527271944239};\\\", \\\"{x:804,y:825,t:1527271944256};\\\", \\\"{x:811,y:828,t:1527271944272};\\\", \\\"{x:812,y:829,t:1527271944289};\\\", \\\"{x:811,y:830,t:1527271944322};\\\", \\\"{x:803,y:831,t:1527271944340};\\\", \\\"{x:790,y:834,t:1527271944358};\\\", \\\"{x:766,y:834,t:1527271944374};\\\", \\\"{x:725,y:832,t:1527271944390};\\\", \\\"{x:672,y:814,t:1527271944407};\\\", \\\"{x:623,y:795,t:1527271944425};\\\", \\\"{x:576,y:777,t:1527271944440};\\\", \\\"{x:545,y:763,t:1527271944458};\\\", \\\"{x:511,y:749,t:1527271944474};\\\", \\\"{x:501,y:744,t:1527271944490};\\\", \\\"{x:493,y:743,t:1527271944507};\\\", \\\"{x:492,y:743,t:1527271944524};\\\", \\\"{x:492,y:740,t:1527271944586};\\\", \\\"{x:492,y:739,t:1527271944594};\\\", \\\"{x:492,y:738,t:1527271944608};\\\", \\\"{x:492,y:735,t:1527271944626};\\\", \\\"{x:492,y:734,t:1527271944640};\\\", \\\"{x:492,y:733,t:1527271944656};\\\", \\\"{x:492,y:731,t:1527271944672};\\\", \\\"{x:497,y:725,t:1527271944688};\\\", \\\"{x:503,y:717,t:1527271944705};\\\", \\\"{x:504,y:714,t:1527271944723};\\\", \\\"{x:505,y:714,t:1527271945225};\\\", \\\"{x:507,y:714,t:1527271945240};\\\", \\\"{x:518,y:714,t:1527271945257};\\\", \\\"{x:575,y:696,t:1527271945273};\\\", \\\"{x:628,y:680,t:1527271945290};\\\", \\\"{x:687,y:670,t:1527271945307};\\\", \\\"{x:751,y:662,t:1527271945323};\\\", \\\"{x:812,y:646,t:1527271945340};\\\", \\\"{x:850,y:637,t:1527271945356};\\\", \\\"{x:877,y:625,t:1527271945374};\\\", \\\"{x:897,y:615,t:1527271945391};\\\", \\\"{x:917,y:606,t:1527271945406};\\\", \\\"{x:923,y:603,t:1527271945424};\\\", \\\"{x:925,y:601,t:1527271945440};\\\", \\\"{x:926,y:600,t:1527271945456};\\\", \\\"{x:927,y:596,t:1527271945474};\\\", \\\"{x:927,y:594,t:1527271945491};\\\", \\\"{x:927,y:591,t:1527271945506};\\\", \\\"{x:927,y:589,t:1527271945524};\\\", \\\"{x:923,y:586,t:1527271945541};\\\", \\\"{x:915,y:582,t:1527271945556};\\\", \\\"{x:906,y:579,t:1527271945574};\\\", \\\"{x:893,y:576,t:1527271945591};\\\", \\\"{x:885,y:576,t:1527271945607};\\\", \\\"{x:872,y:576,t:1527271945624};\\\", \\\"{x:860,y:576,t:1527271945641};\\\", \\\"{x:851,y:576,t:1527271945657};\\\", \\\"{x:841,y:576,t:1527271945674};\\\", \\\"{x:834,y:579,t:1527271945691};\\\", \\\"{x:829,y:582,t:1527271945707};\\\", \\\"{x:825,y:585,t:1527271945724};\\\", \\\"{x:822,y:588,t:1527271945740};\\\", \\\"{x:817,y:592,t:1527271945757};\\\", \\\"{x:812,y:596,t:1527271945774};\\\", \\\"{x:808,y:599,t:1527271945790};\\\", \\\"{x:802,y:601,t:1527271945808};\\\", \\\"{x:791,y:606,t:1527271945823};\\\", \\\"{x:784,y:610,t:1527271945841};\\\", \\\"{x:772,y:616,t:1527271945858};\\\", \\\"{x:767,y:617,t:1527271945873};\\\", \\\"{x:761,y:620,t:1527271945891};\\\", \\\"{x:756,y:622,t:1527271945908};\\\", \\\"{x:755,y:623,t:1527271945924};\\\", \\\"{x:755,y:624,t:1527271945941};\\\", \\\"{x:753,y:624,t:1527271945958};\\\", \\\"{x:752,y:624,t:1527271945974};\\\", \\\"{x:746,y:626,t:1527271945990};\\\", \\\"{x:736,y:627,t:1527271946007};\\\", \\\"{x:725,y:627,t:1527271946027};\\\", \\\"{x:722,y:628,t:1527271946040};\\\", \\\"{x:712,y:630,t:1527271946058};\\\", \\\"{x:704,y:631,t:1527271946073};\\\", \\\"{x:699,y:632,t:1527271946091};\\\" ] }, { \\\"rt\\\": 22638, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 505215, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:683,y:634,t:1527271946221};\\\", \\\"{x:682,y:634,t:1527271946244};\\\", \\\"{x:673,y:634,t:1527271946694};\\\", \\\"{x:667,y:633,t:1527271946707};\\\", \\\"{x:660,y:632,t:1527271946724};\\\", \\\"{x:650,y:630,t:1527271946740};\\\", \\\"{x:640,y:628,t:1527271946758};\\\", \\\"{x:632,y:624,t:1527271946774};\\\", \\\"{x:621,y:620,t:1527271946792};\\\", \\\"{x:609,y:610,t:1527271946808};\\\", \\\"{x:595,y:598,t:1527271946825};\\\", \\\"{x:572,y:578,t:1527271946842};\\\", \\\"{x:546,y:558,t:1527271946858};\\\", \\\"{x:520,y:537,t:1527271946875};\\\", \\\"{x:505,y:522,t:1527271946892};\\\", \\\"{x:495,y:505,t:1527271946908};\\\", \\\"{x:489,y:491,t:1527271946925};\\\", \\\"{x:485,y:481,t:1527271946942};\\\", \\\"{x:483,y:477,t:1527271946958};\\\", \\\"{x:483,y:476,t:1527271946975};\\\", \\\"{x:486,y:476,t:1527271947218};\\\", \\\"{x:496,y:478,t:1527271947226};\\\", \\\"{x:518,y:484,t:1527271947243};\\\", \\\"{x:554,y:489,t:1527271947259};\\\", \\\"{x:578,y:491,t:1527271947276};\\\", \\\"{x:592,y:491,t:1527271947293};\\\", \\\"{x:593,y:491,t:1527271947310};\\\", \\\"{x:591,y:491,t:1527271947490};\\\", \\\"{x:584,y:491,t:1527271947497};\\\", \\\"{x:573,y:490,t:1527271947510};\\\", \\\"{x:553,y:488,t:1527271947527};\\\", \\\"{x:535,y:485,t:1527271947544};\\\", \\\"{x:517,y:483,t:1527271947560};\\\", \\\"{x:503,y:483,t:1527271947577};\\\", \\\"{x:499,y:483,t:1527271947594};\\\", \\\"{x:498,y:483,t:1527271947642};\\\", \\\"{x:498,y:487,t:1527271947649};\\\", \\\"{x:500,y:493,t:1527271947660};\\\", \\\"{x:509,y:509,t:1527271947678};\\\", \\\"{x:529,y:525,t:1527271947694};\\\", \\\"{x:570,y:551,t:1527271947709};\\\", \\\"{x:649,y:591,t:1527271947726};\\\", \\\"{x:774,y:661,t:1527271947742};\\\", \\\"{x:940,y:740,t:1527271947759};\\\", \\\"{x:1130,y:821,t:1527271947776};\\\", \\\"{x:1302,y:904,t:1527271947792};\\\", \\\"{x:1449,y:984,t:1527271947809};\\\", \\\"{x:1633,y:1070,t:1527271947825};\\\", \\\"{x:1722,y:1111,t:1527271947843};\\\", \\\"{x:1769,y:1133,t:1527271947859};\\\", \\\"{x:1784,y:1148,t:1527271947876};\\\", \\\"{x:1786,y:1151,t:1527271947893};\\\", \\\"{x:1786,y:1152,t:1527271947914};\\\", \\\"{x:1786,y:1154,t:1527271947929};\\\", \\\"{x:1786,y:1155,t:1527271947946};\\\", \\\"{x:1786,y:1157,t:1527271947959};\\\", \\\"{x:1786,y:1159,t:1527271947976};\\\", \\\"{x:1786,y:1160,t:1527271947993};\\\", \\\"{x:1786,y:1162,t:1527271948009};\\\", \\\"{x:1786,y:1165,t:1527271948026};\\\", \\\"{x:1786,y:1170,t:1527271948043};\\\", \\\"{x:1804,y:1186,t:1527271948060};\\\", \\\"{x:1830,y:1199,t:1527271948076};\\\", \\\"{x:1880,y:1199,t:1527271948093};\\\", \\\"{x:1917,y:1199,t:1527271948110};\\\", \\\"{x:1919,y:1199,t:1527271948125};\\\", \\\"{x:1919,y:1198,t:1527271948154};\\\", \\\"{x:1919,y:1196,t:1527271948162};\\\", \\\"{x:1919,y:1191,t:1527271948176};\\\", \\\"{x:1913,y:1174,t:1527271948193};\\\", \\\"{x:1892,y:1138,t:1527271948209};\\\", \\\"{x:1838,y:1077,t:1527271948226};\\\", \\\"{x:1805,y:1055,t:1527271948243};\\\", \\\"{x:1786,y:1046,t:1527271948259};\\\", \\\"{x:1769,y:1038,t:1527271948277};\\\", \\\"{x:1759,y:1035,t:1527271948292};\\\", \\\"{x:1754,y:1032,t:1527271948308};\\\", \\\"{x:1749,y:1030,t:1527271948326};\\\", \\\"{x:1744,y:1028,t:1527271948342};\\\", \\\"{x:1738,y:1026,t:1527271948358};\\\", \\\"{x:1731,y:1023,t:1527271948376};\\\", \\\"{x:1726,y:1022,t:1527271948391};\\\", \\\"{x:1719,y:1021,t:1527271948409};\\\", \\\"{x:1711,y:1021,t:1527271948425};\\\", \\\"{x:1710,y:1021,t:1527271948458};\\\", \\\"{x:1709,y:1021,t:1527271948466};\\\", \\\"{x:1708,y:1021,t:1527271948481};\\\", \\\"{x:1707,y:1021,t:1527271948514};\\\", \\\"{x:1704,y:1021,t:1527271948526};\\\", \\\"{x:1696,y:1022,t:1527271948542};\\\", \\\"{x:1683,y:1022,t:1527271948560};\\\", \\\"{x:1670,y:1022,t:1527271948576};\\\", \\\"{x:1655,y:1022,t:1527271948593};\\\", \\\"{x:1637,y:1022,t:1527271948609};\\\", \\\"{x:1618,y:1018,t:1527271948625};\\\", \\\"{x:1590,y:1010,t:1527271948642};\\\", \\\"{x:1580,y:1008,t:1527271948659};\\\", \\\"{x:1579,y:1007,t:1527271948675};\\\", \\\"{x:1579,y:1006,t:1527271948762};\\\", \\\"{x:1579,y:1004,t:1527271948775};\\\", \\\"{x:1584,y:996,t:1527271948792};\\\", \\\"{x:1595,y:989,t:1527271948809};\\\", \\\"{x:1607,y:985,t:1527271948825};\\\", \\\"{x:1615,y:982,t:1527271948842};\\\", \\\"{x:1615,y:981,t:1527271949187};\\\", \\\"{x:1615,y:977,t:1527271949194};\\\", \\\"{x:1614,y:976,t:1527271949211};\\\", \\\"{x:1614,y:974,t:1527271949226};\\\", \\\"{x:1611,y:971,t:1527271949242};\\\", \\\"{x:1610,y:970,t:1527271949259};\\\", \\\"{x:1609,y:969,t:1527271949282};\\\", \\\"{x:1608,y:967,t:1527271954186};\\\", \\\"{x:1599,y:961,t:1527271954203};\\\", \\\"{x:1582,y:941,t:1527271954219};\\\", \\\"{x:1564,y:929,t:1527271954236};\\\", \\\"{x:1545,y:920,t:1527271954253};\\\", \\\"{x:1528,y:911,t:1527271954270};\\\", \\\"{x:1516,y:905,t:1527271954286};\\\", \\\"{x:1510,y:902,t:1527271954303};\\\", \\\"{x:1510,y:901,t:1527271954319};\\\", \\\"{x:1509,y:901,t:1527271954378};\\\", \\\"{x:1508,y:899,t:1527271954385};\\\", \\\"{x:1506,y:897,t:1527271954402};\\\", \\\"{x:1504,y:893,t:1527271954419};\\\", \\\"{x:1503,y:892,t:1527271954449};\\\", \\\"{x:1503,y:889,t:1527271954465};\\\", \\\"{x:1503,y:886,t:1527271954473};\\\", \\\"{x:1502,y:882,t:1527271954486};\\\", \\\"{x:1500,y:873,t:1527271954502};\\\", \\\"{x:1496,y:862,t:1527271954519};\\\", \\\"{x:1488,y:853,t:1527271954536};\\\", \\\"{x:1482,y:847,t:1527271954552};\\\", \\\"{x:1478,y:842,t:1527271954569};\\\", \\\"{x:1476,y:840,t:1527271954586};\\\", \\\"{x:1476,y:838,t:1527271954634};\\\", \\\"{x:1475,y:836,t:1527271954642};\\\", \\\"{x:1474,y:834,t:1527271954652};\\\", \\\"{x:1471,y:829,t:1527271954669};\\\", \\\"{x:1470,y:828,t:1527271954685};\\\", \\\"{x:1471,y:828,t:1527271955090};\\\", \\\"{x:1472,y:828,t:1527271955114};\\\", \\\"{x:1474,y:828,t:1527271955642};\\\", \\\"{x:1475,y:826,t:1527271958011};\\\", \\\"{x:1463,y:818,t:1527271958019};\\\", \\\"{x:1421,y:805,t:1527271958032};\\\", \\\"{x:1295,y:762,t:1527271958049};\\\", \\\"{x:1036,y:688,t:1527271958065};\\\", \\\"{x:856,y:633,t:1527271958081};\\\", \\\"{x:716,y:598,t:1527271958099};\\\", \\\"{x:617,y:575,t:1527271958116};\\\", \\\"{x:578,y:565,t:1527271958133};\\\", \\\"{x:569,y:564,t:1527271958150};\\\", \\\"{x:568,y:564,t:1527271958185};\\\", \\\"{x:568,y:578,t:1527271958202};\\\", \\\"{x:568,y:588,t:1527271958217};\\\", \\\"{x:568,y:594,t:1527271958234};\\\", \\\"{x:569,y:598,t:1527271958250};\\\", \\\"{x:571,y:600,t:1527271958329};\\\", \\\"{x:574,y:601,t:1527271958337};\\\", \\\"{x:579,y:601,t:1527271958351};\\\", \\\"{x:584,y:602,t:1527271958367};\\\", \\\"{x:588,y:603,t:1527271958384};\\\", \\\"{x:591,y:602,t:1527271958481};\\\", \\\"{x:594,y:599,t:1527271958490};\\\", \\\"{x:599,y:598,t:1527271958501};\\\", \\\"{x:603,y:596,t:1527271958518};\\\", \\\"{x:607,y:595,t:1527271958534};\\\", \\\"{x:610,y:594,t:1527271958551};\\\", \\\"{x:612,y:594,t:1527271958618};\\\", \\\"{x:617,y:594,t:1527271958634};\\\", \\\"{x:621,y:594,t:1527271958652};\\\", \\\"{x:627,y:594,t:1527271958668};\\\", \\\"{x:628,y:594,t:1527271958684};\\\", \\\"{x:626,y:594,t:1527271958962};\\\", \\\"{x:627,y:593,t:1527271959554};\\\", \\\"{x:639,y:592,t:1527271959568};\\\", \\\"{x:709,y:590,t:1527271959586};\\\", \\\"{x:769,y:593,t:1527271959602};\\\", \\\"{x:836,y:601,t:1527271959619};\\\", \\\"{x:896,y:616,t:1527271959636};\\\", \\\"{x:927,y:620,t:1527271959651};\\\", \\\"{x:939,y:623,t:1527271959668};\\\", \\\"{x:940,y:624,t:1527271959850};\\\", \\\"{x:940,y:628,t:1527271959857};\\\", \\\"{x:940,y:632,t:1527271959868};\\\", \\\"{x:939,y:641,t:1527271959885};\\\", \\\"{x:935,y:651,t:1527271959902};\\\", \\\"{x:932,y:661,t:1527271959918};\\\", \\\"{x:926,y:669,t:1527271959936};\\\", \\\"{x:924,y:676,t:1527271959953};\\\", \\\"{x:924,y:679,t:1527271959969};\\\", \\\"{x:922,y:682,t:1527271959985};\\\", \\\"{x:922,y:683,t:1527271960009};\\\", \\\"{x:921,y:684,t:1527271960025};\\\", \\\"{x:921,y:685,t:1527271960049};\\\", \\\"{x:919,y:687,t:1527271960073};\\\", \\\"{x:919,y:689,t:1527271960085};\\\", \\\"{x:918,y:690,t:1527271960102};\\\", \\\"{x:913,y:694,t:1527271960119};\\\", \\\"{x:908,y:698,t:1527271960135};\\\", \\\"{x:901,y:700,t:1527271960153};\\\", \\\"{x:897,y:701,t:1527271960169};\\\", \\\"{x:896,y:701,t:1527271960186};\\\", \\\"{x:894,y:702,t:1527271960202};\\\", \\\"{x:892,y:703,t:1527271960225};\\\", \\\"{x:891,y:703,t:1527271960235};\\\", \\\"{x:891,y:704,t:1527271960252};\\\", \\\"{x:888,y:704,t:1527271960269};\\\", \\\"{x:887,y:704,t:1527271960289};\\\", \\\"{x:885,y:704,t:1527271960306};\\\", \\\"{x:884,y:705,t:1527271960319};\\\", \\\"{x:883,y:705,t:1527271960335};\\\", \\\"{x:882,y:705,t:1527271960353};\\\", \\\"{x:880,y:705,t:1527271960370};\\\", \\\"{x:876,y:704,t:1527271960385};\\\", \\\"{x:873,y:703,t:1527271960403};\\\", \\\"{x:872,y:702,t:1527271960433};\\\", \\\"{x:871,y:702,t:1527271960441};\\\", \\\"{x:870,y:702,t:1527271960452};\\\", \\\"{x:870,y:701,t:1527271960470};\\\", \\\"{x:869,y:701,t:1527271960486};\\\", \\\"{x:869,y:700,t:1527271960503};\\\", \\\"{x:869,y:698,t:1527271960519};\\\", \\\"{x:869,y:697,t:1527271960536};\\\", \\\"{x:869,y:695,t:1527271960553};\\\", \\\"{x:871,y:694,t:1527271960569};\\\", \\\"{x:878,y:693,t:1527271960585};\\\", \\\"{x:899,y:694,t:1527271960602};\\\", \\\"{x:924,y:701,t:1527271960620};\\\", \\\"{x:952,y:709,t:1527271960637};\\\", \\\"{x:976,y:717,t:1527271960652};\\\", \\\"{x:995,y:726,t:1527271960669};\\\", \\\"{x:1012,y:735,t:1527271960686};\\\", \\\"{x:1024,y:744,t:1527271960702};\\\", \\\"{x:1034,y:751,t:1527271960720};\\\", \\\"{x:1038,y:754,t:1527271960736};\\\", \\\"{x:1040,y:755,t:1527271960753};\\\", \\\"{x:1042,y:757,t:1527271960770};\\\", \\\"{x:1043,y:757,t:1527271960802};\\\", \\\"{x:1044,y:758,t:1527271960809};\\\", \\\"{x:1045,y:758,t:1527271960825};\\\", \\\"{x:1048,y:760,t:1527271960836};\\\", \\\"{x:1061,y:762,t:1527271961113};\\\", \\\"{x:1087,y:768,t:1527271961122};\\\", \\\"{x:1134,y:780,t:1527271961137};\\\", \\\"{x:1287,y:828,t:1527271961154};\\\", \\\"{x:1406,y:859,t:1527271961169};\\\", \\\"{x:1515,y:879,t:1527271961186};\\\", \\\"{x:1603,y:898,t:1527271961203};\\\", \\\"{x:1669,y:917,t:1527271961219};\\\", \\\"{x:1693,y:922,t:1527271961236};\\\", \\\"{x:1707,y:923,t:1527271961254};\\\", \\\"{x:1711,y:923,t:1527271961271};\\\", \\\"{x:1712,y:923,t:1527271961322};\\\", \\\"{x:1713,y:923,t:1527271961338};\\\", \\\"{x:1717,y:922,t:1527271961354};\\\", \\\"{x:1719,y:915,t:1527271961370};\\\", \\\"{x:1722,y:907,t:1527271961387};\\\", \\\"{x:1723,y:901,t:1527271961404};\\\", \\\"{x:1723,y:897,t:1527271961421};\\\", \\\"{x:1725,y:893,t:1527271961437};\\\", \\\"{x:1725,y:892,t:1527271961454};\\\", \\\"{x:1724,y:890,t:1527271961470};\\\", \\\"{x:1722,y:889,t:1527271961487};\\\", \\\"{x:1717,y:887,t:1527271961503};\\\", \\\"{x:1710,y:886,t:1527271961520};\\\", \\\"{x:1695,y:884,t:1527271961537};\\\", \\\"{x:1646,y:876,t:1527271961553};\\\", \\\"{x:1616,y:872,t:1527271961570};\\\", \\\"{x:1588,y:866,t:1527271961586};\\\", \\\"{x:1568,y:859,t:1527271961604};\\\", \\\"{x:1545,y:853,t:1527271961620};\\\", \\\"{x:1525,y:850,t:1527271961637};\\\", \\\"{x:1520,y:848,t:1527271961654};\\\", \\\"{x:1519,y:847,t:1527271961671};\\\", \\\"{x:1518,y:847,t:1527271961899};\\\", \\\"{x:1515,y:847,t:1527271961906};\\\", \\\"{x:1513,y:847,t:1527271961921};\\\", \\\"{x:1506,y:847,t:1527271961937};\\\", \\\"{x:1505,y:847,t:1527271961953};\\\", \\\"{x:1504,y:847,t:1527271961971};\\\", \\\"{x:1503,y:847,t:1527271961988};\\\", \\\"{x:1502,y:847,t:1527271962010};\\\", \\\"{x:1501,y:847,t:1527271962021};\\\", \\\"{x:1500,y:847,t:1527271962050};\\\", \\\"{x:1499,y:847,t:1527271962083};\\\", \\\"{x:1499,y:846,t:1527271962091};\\\", \\\"{x:1498,y:845,t:1527271962105};\\\", \\\"{x:1496,y:843,t:1527271962121};\\\", \\\"{x:1495,y:843,t:1527271962154};\\\", \\\"{x:1493,y:841,t:1527271962171};\\\", \\\"{x:1493,y:840,t:1527271962188};\\\", \\\"{x:1492,y:839,t:1527271962205};\\\", \\\"{x:1491,y:837,t:1527271962222};\\\", \\\"{x:1490,y:837,t:1527271962258};\\\", \\\"{x:1489,y:837,t:1527271962865};\\\", \\\"{x:1487,y:837,t:1527271963106};\\\", \\\"{x:1486,y:836,t:1527271963147};\\\", \\\"{x:1488,y:835,t:1527271963593};\\\", \\\"{x:1493,y:830,t:1527271963606};\\\", \\\"{x:1501,y:825,t:1527271963621};\\\", \\\"{x:1509,y:820,t:1527271963638};\\\", \\\"{x:1520,y:819,t:1527271963655};\\\", \\\"{x:1529,y:819,t:1527271963672};\\\", \\\"{x:1536,y:819,t:1527271963688};\\\", \\\"{x:1540,y:819,t:1527271963706};\\\", \\\"{x:1542,y:819,t:1527271963722};\\\", \\\"{x:1543,y:819,t:1527271963762};\\\", \\\"{x:1544,y:819,t:1527271963773};\\\", \\\"{x:1549,y:820,t:1527271963789};\\\", \\\"{x:1551,y:821,t:1527271963805};\\\", \\\"{x:1553,y:821,t:1527271963822};\\\", \\\"{x:1554,y:821,t:1527271963839};\\\", \\\"{x:1556,y:821,t:1527271963865};\\\", \\\"{x:1557,y:821,t:1527271963874};\\\", \\\"{x:1558,y:823,t:1527271963889};\\\", \\\"{x:1561,y:823,t:1527271963906};\\\", \\\"{x:1566,y:824,t:1527271964050};\\\", \\\"{x:1568,y:824,t:1527271964057};\\\", \\\"{x:1570,y:824,t:1527271964072};\\\", \\\"{x:1576,y:825,t:1527271964089};\\\", \\\"{x:1586,y:825,t:1527271964106};\\\", \\\"{x:1590,y:825,t:1527271964122};\\\", \\\"{x:1594,y:825,t:1527271964139};\\\", \\\"{x:1599,y:825,t:1527271964156};\\\", \\\"{x:1608,y:825,t:1527271964173};\\\", \\\"{x:1613,y:825,t:1527271964189};\\\", \\\"{x:1618,y:825,t:1527271964205};\\\", \\\"{x:1620,y:825,t:1527271964307};\\\", \\\"{x:1623,y:825,t:1527271964323};\\\", \\\"{x:1624,y:825,t:1527271964339};\\\", \\\"{x:1619,y:825,t:1527271966395};\\\", \\\"{x:1590,y:811,t:1527271966408};\\\", \\\"{x:1565,y:797,t:1527271966425};\\\", \\\"{x:1563,y:796,t:1527271966441};\\\", \\\"{x:1558,y:795,t:1527271966458};\\\", \\\"{x:1541,y:792,t:1527271966475};\\\", \\\"{x:1459,y:795,t:1527271966491};\\\", \\\"{x:1444,y:807,t:1527271966508};\\\", \\\"{x:1444,y:822,t:1527271966526};\\\", \\\"{x:1444,y:831,t:1527271966541};\\\", \\\"{x:1445,y:833,t:1527271966558};\\\", \\\"{x:1449,y:834,t:1527271966575};\\\", \\\"{x:1457,y:837,t:1527271966591};\\\", \\\"{x:1460,y:838,t:1527271966608};\\\", \\\"{x:1460,y:839,t:1527271966627};\\\", \\\"{x:1447,y:844,t:1527271966642};\\\", \\\"{x:1403,y:851,t:1527271966658};\\\", \\\"{x:1329,y:856,t:1527271966675};\\\", \\\"{x:1238,y:856,t:1527271966692};\\\", \\\"{x:1151,y:860,t:1527271966708};\\\", \\\"{x:1080,y:865,t:1527271966725};\\\", \\\"{x:1024,y:865,t:1527271966742};\\\", \\\"{x:951,y:865,t:1527271966758};\\\", \\\"{x:851,y:864,t:1527271966775};\\\", \\\"{x:735,y:849,t:1527271966792};\\\", \\\"{x:616,y:833,t:1527271966808};\\\", \\\"{x:492,y:816,t:1527271966825};\\\", \\\"{x:323,y:802,t:1527271966841};\\\", \\\"{x:269,y:799,t:1527271966858};\\\", \\\"{x:240,y:799,t:1527271966875};\\\", \\\"{x:233,y:799,t:1527271966892};\\\", \\\"{x:240,y:798,t:1527271966946};\\\", \\\"{x:246,y:794,t:1527271966958};\\\", \\\"{x:257,y:783,t:1527271966975};\\\", \\\"{x:262,y:776,t:1527271966992};\\\", \\\"{x:269,y:762,t:1527271967008};\\\", \\\"{x:280,y:745,t:1527271967025};\\\", \\\"{x:339,y:703,t:1527271967041};\\\", \\\"{x:379,y:681,t:1527271967058};\\\", \\\"{x:402,y:669,t:1527271967075};\\\", \\\"{x:408,y:667,t:1527271967092};\\\", \\\"{x:411,y:667,t:1527271967108};\\\", \\\"{x:412,y:667,t:1527271967124};\\\", \\\"{x:415,y:667,t:1527271967141};\\\", \\\"{x:420,y:667,t:1527271967159};\\\", \\\"{x:423,y:667,t:1527271967175};\\\", \\\"{x:429,y:670,t:1527271967192};\\\", \\\"{x:444,y:679,t:1527271967209};\\\", \\\"{x:470,y:697,t:1527271967225};\\\", \\\"{x:502,y:718,t:1527271967242};\\\", \\\"{x:514,y:724,t:1527271967259};\\\", \\\"{x:518,y:727,t:1527271967274};\\\", \\\"{x:517,y:727,t:1527271968113};\\\", \\\"{x:516,y:727,t:1527271968161};\\\", \\\"{x:515,y:726,t:1527271968226};\\\" ] }, { \\\"rt\\\": 321918, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 828374, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -08 PM-03 PM-11 AM-12 PM-02 PM-02 PM-03 PM-03 PM-12 PM-12 PM-11 AM-12 PM-01 PM-01 PM-02 PM-03 PM-04 PM-05 PM-04 PM-05 PM-06 PM-06 PM-07 PM-08 PM-07 PM-06 PM-05 PM-04 PM-O -O -12 PM-12 PM-01 PM-12 PM-11 AM-Z -O -12 PM-01 PM-02 PM-03 PM-04 PM-04 PM-03 PM-04 PM-02 PM-01 PM-12 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:724,t:1527271970162};\\\", \\\"{x:508,y:723,t:1527271970177};\\\", \\\"{x:495,y:719,t:1527271970193};\\\", \\\"{x:472,y:714,t:1527271970210};\\\", \\\"{x:450,y:711,t:1527271970235};\\\", \\\"{x:441,y:710,t:1527271970243};\\\", \\\"{x:428,y:708,t:1527271970261};\\\", \\\"{x:424,y:708,t:1527271970277};\\\", \\\"{x:420,y:708,t:1527271970293};\\\", \\\"{x:417,y:708,t:1527271970310};\\\", \\\"{x:416,y:708,t:1527271970434};\\\", \\\"{x:415,y:708,t:1527271970443};\\\", \\\"{x:407,y:708,t:1527271970541};\\\", \\\"{x:404,y:707,t:1527271970550};\\\", \\\"{x:400,y:703,t:1527271970561};\\\", \\\"{x:385,y:689,t:1527271970577};\\\", \\\"{x:370,y:671,t:1527271970593};\\\", \\\"{x:354,y:650,t:1527271970612};\\\", \\\"{x:331,y:621,t:1527271970628};\\\", \\\"{x:317,y:601,t:1527271970645};\\\", \\\"{x:303,y:584,t:1527271970661};\\\", \\\"{x:297,y:575,t:1527271970678};\\\", \\\"{x:292,y:566,t:1527271970694};\\\", \\\"{x:288,y:560,t:1527271970711};\\\", \\\"{x:288,y:554,t:1527271970728};\\\", \\\"{x:288,y:549,t:1527271970744};\\\", \\\"{x:289,y:545,t:1527271970760};\\\", \\\"{x:308,y:529,t:1527271970777};\\\", \\\"{x:334,y:513,t:1527271970794};\\\", \\\"{x:352,y:504,t:1527271970811};\\\", \\\"{x:364,y:494,t:1527271970827};\\\", \\\"{x:376,y:483,t:1527271970844};\\\", \\\"{x:381,y:476,t:1527271970861};\\\", \\\"{x:382,y:472,t:1527271970877};\\\", \\\"{x:382,y:470,t:1527271971073};\\\", \\\"{x:384,y:468,t:1527271971081};\\\", \\\"{x:384,y:467,t:1527271971097};\\\", \\\"{x:385,y:467,t:1527271971290};\\\", \\\"{x:386,y:467,t:1527271971339};\\\", \\\"{x:387,y:467,t:1527271971362};\\\", \\\"{x:388,y:467,t:1527271971376};\\\", \\\"{x:393,y:467,t:1527271971393};\\\", \\\"{x:398,y:467,t:1527271971409};\\\", \\\"{x:403,y:467,t:1527271971426};\\\", \\\"{x:406,y:467,t:1527271971443};\\\", \\\"{x:410,y:467,t:1527271971459};\\\", \\\"{x:412,y:467,t:1527271971476};\\\", \\\"{x:413,y:467,t:1527271971497};\\\", \\\"{x:415,y:467,t:1527271971509};\\\", \\\"{x:419,y:466,t:1527271971526};\\\", \\\"{x:428,y:465,t:1527271971542};\\\", \\\"{x:440,y:465,t:1527271971560};\\\", \\\"{x:451,y:465,t:1527271971575};\\\", \\\"{x:465,y:464,t:1527271971592};\\\", \\\"{x:474,y:464,t:1527271971610};\\\", \\\"{x:485,y:464,t:1527271971625};\\\", \\\"{x:503,y:461,t:1527271971642};\\\", \\\"{x:513,y:457,t:1527271971658};\\\", \\\"{x:519,y:457,t:1527271971675};\\\", \\\"{x:521,y:457,t:1527271971692};\\\", \\\"{x:523,y:457,t:1527271971708};\\\", \\\"{x:524,y:457,t:1527271971802};\\\", \\\"{x:526,y:457,t:1527271971810};\\\", \\\"{x:527,y:457,t:1527271971825};\\\", \\\"{x:533,y:456,t:1527271971841};\\\", \\\"{x:543,y:455,t:1527271971858};\\\", \\\"{x:552,y:455,t:1527271971875};\\\", \\\"{x:564,y:455,t:1527271971891};\\\", \\\"{x:574,y:455,t:1527271971908};\\\", \\\"{x:585,y:455,t:1527271971924};\\\", \\\"{x:588,y:455,t:1527271971941};\\\", \\\"{x:590,y:455,t:1527271972010};\\\", \\\"{x:591,y:455,t:1527271972026};\\\", \\\"{x:593,y:454,t:1527271972041};\\\", \\\"{x:597,y:454,t:1527271972057};\\\", \\\"{x:598,y:454,t:1527271972075};\\\", \\\"{x:601,y:453,t:1527271972092};\\\", \\\"{x:604,y:453,t:1527271972108};\\\", \\\"{x:610,y:451,t:1527271972124};\\\", \\\"{x:619,y:451,t:1527271972140};\\\", \\\"{x:625,y:449,t:1527271972157};\\\", \\\"{x:631,y:448,t:1527271972174};\\\", \\\"{x:632,y:448,t:1527271972402};\\\", \\\"{x:629,y:448,t:1527271972410};\\\", \\\"{x:616,y:449,t:1527271972423};\\\", \\\"{x:587,y:455,t:1527271972440};\\\", \\\"{x:549,y:465,t:1527271972456};\\\", \\\"{x:503,y:478,t:1527271972474};\\\", \\\"{x:483,y:481,t:1527271972489};\\\", \\\"{x:473,y:483,t:1527271972505};\\\", \\\"{x:468,y:485,t:1527271972523};\\\", \\\"{x:467,y:485,t:1527271972539};\\\", \\\"{x:466,y:485,t:1527271972556};\\\", \\\"{x:464,y:485,t:1527271972593};\\\", \\\"{x:461,y:485,t:1527271972606};\\\", \\\"{x:448,y:485,t:1527271972622};\\\", \\\"{x:434,y:485,t:1527271972639};\\\", \\\"{x:420,y:485,t:1527271972656};\\\", \\\"{x:406,y:486,t:1527271972672};\\\", \\\"{x:397,y:487,t:1527271972689};\\\", \\\"{x:395,y:487,t:1527271972705};\\\", \\\"{x:398,y:487,t:1527271972978};\\\", \\\"{x:404,y:487,t:1527271972988};\\\", \\\"{x:412,y:487,t:1527271973005};\\\", \\\"{x:422,y:487,t:1527271973021};\\\", \\\"{x:433,y:486,t:1527271973038};\\\", \\\"{x:439,y:486,t:1527271973053};\\\", \\\"{x:441,y:485,t:1527271973071};\\\", \\\"{x:442,y:484,t:1527271973088};\\\", \\\"{x:444,y:484,t:1527271973104};\\\", \\\"{x:445,y:484,t:1527271973120};\\\", \\\"{x:449,y:482,t:1527271973138};\\\", \\\"{x:453,y:480,t:1527271973154};\\\", \\\"{x:458,y:480,t:1527271973171};\\\", \\\"{x:467,y:477,t:1527271973187};\\\", \\\"{x:480,y:473,t:1527271973204};\\\", \\\"{x:490,y:471,t:1527271973221};\\\", \\\"{x:503,y:468,t:1527271973237};\\\", \\\"{x:516,y:467,t:1527271973254};\\\", \\\"{x:525,y:467,t:1527271973271};\\\", \\\"{x:534,y:466,t:1527271973287};\\\", \\\"{x:539,y:466,t:1527271973304};\\\", \\\"{x:542,y:466,t:1527271973320};\\\", \\\"{x:544,y:466,t:1527271973337};\\\", \\\"{x:546,y:466,t:1527271973353};\\\", \\\"{x:548,y:466,t:1527271973370};\\\", \\\"{x:551,y:466,t:1527271973387};\\\", \\\"{x:553,y:466,t:1527271973404};\\\", \\\"{x:554,y:466,t:1527271973420};\\\", \\\"{x:555,y:466,t:1527271973554};\\\", \\\"{x:553,y:466,t:1527271973890};\\\", \\\"{x:547,y:466,t:1527271973902};\\\", \\\"{x:537,y:466,t:1527271973919};\\\", \\\"{x:530,y:466,t:1527271973935};\\\", \\\"{x:526,y:466,t:1527271973952};\\\", \\\"{x:524,y:466,t:1527271973969};\\\", \\\"{x:523,y:466,t:1527271973986};\\\", \\\"{x:522,y:466,t:1527271974050};\\\", \\\"{x:521,y:466,t:1527271974066};\\\", \\\"{x:520,y:466,t:1527271974082};\\\", \\\"{x:519,y:466,t:1527271974089};\\\", \\\"{x:517,y:466,t:1527271974102};\\\", \\\"{x:511,y:466,t:1527271974118};\\\", \\\"{x:500,y:466,t:1527271974135};\\\", \\\"{x:487,y:466,t:1527271974151};\\\", \\\"{x:477,y:466,t:1527271974168};\\\", \\\"{x:460,y:466,t:1527271974185};\\\", \\\"{x:453,y:466,t:1527271974201};\\\", \\\"{x:449,y:466,t:1527271974218};\\\", \\\"{x:448,y:466,t:1527271974234};\\\", \\\"{x:446,y:466,t:1527271974297};\\\", \\\"{x:445,y:466,t:1527271974321};\\\", \\\"{x:444,y:466,t:1527271974386};\\\", \\\"{x:442,y:467,t:1527271974585};\\\", \\\"{x:442,y:468,t:1527271974609};\\\", \\\"{x:440,y:468,t:1527271974617};\\\", \\\"{x:439,y:468,t:1527271974649};\\\", \\\"{x:437,y:468,t:1527271974673};\\\", \\\"{x:436,y:468,t:1527271974689};\\\", \\\"{x:436,y:469,t:1527271974700};\\\", \\\"{x:435,y:469,t:1527271974716};\\\", \\\"{x:438,y:469,t:1527271975049};\\\", \\\"{x:452,y:470,t:1527271975065};\\\", \\\"{x:461,y:470,t:1527271975082};\\\", \\\"{x:473,y:472,t:1527271975099};\\\", \\\"{x:488,y:472,t:1527271975115};\\\", \\\"{x:500,y:475,t:1527271975132};\\\", \\\"{x:504,y:475,t:1527271975148};\\\", \\\"{x:508,y:475,t:1527271975165};\\\", \\\"{x:509,y:475,t:1527271975183};\\\", \\\"{x:512,y:475,t:1527271975198};\\\", \\\"{x:517,y:475,t:1527271975216};\\\", \\\"{x:534,y:477,t:1527271975232};\\\", \\\"{x:558,y:481,t:1527271975248};\\\", \\\"{x:581,y:485,t:1527271975266};\\\", \\\"{x:610,y:488,t:1527271975282};\\\", \\\"{x:620,y:490,t:1527271975298};\\\", \\\"{x:621,y:490,t:1527271975315};\\\", \\\"{x:622,y:490,t:1527271975371};\\\", \\\"{x:623,y:490,t:1527271975382};\\\", \\\"{x:623,y:491,t:1527271975399};\\\", \\\"{x:622,y:491,t:1527271975626};\\\", \\\"{x:620,y:491,t:1527271975634};\\\", \\\"{x:619,y:491,t:1527271975647};\\\", \\\"{x:616,y:491,t:1527271975664};\\\", \\\"{x:615,y:491,t:1527271975722};\\\", \\\"{x:614,y:491,t:1527271975755};\\\", \\\"{x:626,y:491,t:1527271975850};\\\", \\\"{x:659,y:491,t:1527271975863};\\\", \\\"{x:759,y:491,t:1527271975880};\\\", \\\"{x:884,y:495,t:1527271975897};\\\", \\\"{x:1094,y:495,t:1527271975914};\\\", \\\"{x:1244,y:495,t:1527271975930};\\\", \\\"{x:1349,y:495,t:1527271975947};\\\", \\\"{x:1399,y:495,t:1527271975963};\\\", \\\"{x:1433,y:495,t:1527271975980};\\\", \\\"{x:1457,y:495,t:1527271975997};\\\", \\\"{x:1475,y:495,t:1527271976013};\\\", \\\"{x:1495,y:495,t:1527271976029};\\\", \\\"{x:1514,y:495,t:1527271976047};\\\", \\\"{x:1537,y:495,t:1527271976064};\\\", \\\"{x:1566,y:495,t:1527271976079};\\\", \\\"{x:1589,y:497,t:1527271976097};\\\", \\\"{x:1595,y:498,t:1527271976113};\\\", \\\"{x:1591,y:498,t:1527271976210};\\\", \\\"{x:1581,y:498,t:1527271976219};\\\", \\\"{x:1573,y:498,t:1527271976230};\\\", \\\"{x:1555,y:499,t:1527271976246};\\\", \\\"{x:1525,y:500,t:1527271976263};\\\", \\\"{x:1475,y:500,t:1527271976280};\\\", \\\"{x:1422,y:500,t:1527271976296};\\\", \\\"{x:1369,y:500,t:1527271976313};\\\", \\\"{x:1327,y:500,t:1527271976328};\\\", \\\"{x:1303,y:503,t:1527271976346};\\\", \\\"{x:1302,y:503,t:1527271976363};\\\", \\\"{x:1301,y:503,t:1527271976411};\\\", \\\"{x:1300,y:504,t:1527271976418};\\\", \\\"{x:1297,y:505,t:1527271976429};\\\", \\\"{x:1286,y:508,t:1527271976446};\\\", \\\"{x:1277,y:512,t:1527271976462};\\\", \\\"{x:1274,y:513,t:1527271976479};\\\", \\\"{x:1277,y:513,t:1527271976554};\\\", \\\"{x:1279,y:513,t:1527271976562};\\\", \\\"{x:1284,y:511,t:1527271976578};\\\", \\\"{x:1285,y:511,t:1527271976594};\\\", \\\"{x:1289,y:510,t:1527271976612};\\\", \\\"{x:1292,y:508,t:1527271976629};\\\", \\\"{x:1300,y:504,t:1527271976644};\\\", \\\"{x:1307,y:502,t:1527271976662};\\\", \\\"{x:1316,y:498,t:1527271976680};\\\", \\\"{x:1325,y:494,t:1527271976694};\\\", \\\"{x:1328,y:493,t:1527271976711};\\\", \\\"{x:1327,y:493,t:1527271976922};\\\", \\\"{x:1326,y:493,t:1527271976937};\\\", \\\"{x:1324,y:493,t:1527271976945};\\\", \\\"{x:1321,y:493,t:1527271976960};\\\", \\\"{x:1315,y:493,t:1527271976978};\\\", \\\"{x:1314,y:493,t:1527271976993};\\\", \\\"{x:1313,y:493,t:1527271977121};\\\", \\\"{x:1311,y:493,t:1527271977234};\\\", \\\"{x:1310,y:493,t:1527271978714};\\\", \\\"{x:1310,y:494,t:1527271978850};\\\", \\\"{x:1311,y:494,t:1527271978938};\\\", \\\"{x:1312,y:495,t:1527271978977};\\\", \\\"{x:1313,y:495,t:1527271979009};\\\", \\\"{x:1314,y:495,t:1527271979058};\\\", \\\"{x:1316,y:495,t:1527271979073};\\\", \\\"{x:1317,y:496,t:1527271979088};\\\", \\\"{x:1318,y:497,t:1527271979106};\\\", \\\"{x:1325,y:498,t:1527271987522};\\\", \\\"{x:1355,y:504,t:1527271987530};\\\", \\\"{x:1463,y:518,t:1527271987547};\\\", \\\"{x:1606,y:551,t:1527271987563};\\\", \\\"{x:1745,y:599,t:1527271987580};\\\", \\\"{x:1879,y:646,t:1527271987597};\\\", \\\"{x:1919,y:690,t:1527271987613};\\\", \\\"{x:1919,y:717,t:1527271987630};\\\", \\\"{x:1919,y:725,t:1527271987642};\\\", \\\"{x:1919,y:726,t:1527271987657};\\\", \\\"{x:1919,y:732,t:1527271987675};\\\", \\\"{x:1919,y:753,t:1527271987692};\\\", \\\"{x:1919,y:806,t:1527271987709};\\\", \\\"{x:1919,y:875,t:1527271987725};\\\", \\\"{x:1919,y:924,t:1527271987742};\\\", \\\"{x:1919,y:952,t:1527271987758};\\\", \\\"{x:1919,y:963,t:1527271987775};\\\", \\\"{x:1919,y:965,t:1527271987792};\\\", \\\"{x:1917,y:970,t:1527271987808};\\\", \\\"{x:1911,y:981,t:1527271987825};\\\", \\\"{x:1906,y:993,t:1527271987841};\\\", \\\"{x:1904,y:997,t:1527271987859};\\\", \\\"{x:1903,y:999,t:1527271987874};\\\", \\\"{x:1903,y:1000,t:1527271987892};\\\", \\\"{x:1903,y:1003,t:1527271987909};\\\", \\\"{x:1903,y:1008,t:1527271987925};\\\", \\\"{x:1903,y:1014,t:1527271987941};\\\", \\\"{x:1902,y:1022,t:1527271987959};\\\", \\\"{x:1900,y:1027,t:1527271987975};\\\", \\\"{x:1900,y:1029,t:1527271987991};\\\", \\\"{x:1899,y:1030,t:1527271988009};\\\", \\\"{x:1897,y:1032,t:1527271988025};\\\", \\\"{x:1894,y:1032,t:1527271988041};\\\", \\\"{x:1891,y:1032,t:1527271988059};\\\", \\\"{x:1887,y:1031,t:1527271988075};\\\", \\\"{x:1880,y:1019,t:1527271988092};\\\", \\\"{x:1871,y:1005,t:1527271988108};\\\", \\\"{x:1867,y:996,t:1527271988125};\\\", \\\"{x:1866,y:993,t:1527271988141};\\\", \\\"{x:1866,y:991,t:1527271988159};\\\", \\\"{x:1865,y:987,t:1527271988174};\\\", \\\"{x:1865,y:984,t:1527271988191};\\\", \\\"{x:1865,y:983,t:1527271988209};\\\", \\\"{x:1865,y:981,t:1527271988225};\\\", \\\"{x:1866,y:979,t:1527271988242};\\\", \\\"{x:1866,y:975,t:1527271988259};\\\", \\\"{x:1867,y:973,t:1527271988276};\\\", \\\"{x:1867,y:972,t:1527271988292};\\\", \\\"{x:1867,y:971,t:1527271988313};\\\", \\\"{x:1868,y:970,t:1527271988324};\\\", \\\"{x:1869,y:970,t:1527271988342};\\\", \\\"{x:1872,y:968,t:1527271988360};\\\", \\\"{x:1874,y:967,t:1527271988378};\\\", \\\"{x:1875,y:967,t:1527271988426};\\\", \\\"{x:1877,y:967,t:1527271988441};\\\", \\\"{x:1882,y:967,t:1527271988459};\\\", \\\"{x:1884,y:967,t:1527271988476};\\\", \\\"{x:1886,y:967,t:1527271988492};\\\", \\\"{x:1886,y:966,t:1527271988746};\\\", \\\"{x:1885,y:966,t:1527271988914};\\\", \\\"{x:1884,y:965,t:1527271988954};\\\", \\\"{x:1884,y:964,t:1527271999361};\\\", \\\"{x:1874,y:963,t:1527271999369};\\\", \\\"{x:1854,y:963,t:1527271999384};\\\", \\\"{x:1792,y:963,t:1527271999401};\\\", \\\"{x:1750,y:957,t:1527271999417};\\\", \\\"{x:1723,y:953,t:1527271999434};\\\", \\\"{x:1701,y:951,t:1527271999451};\\\", \\\"{x:1688,y:947,t:1527271999467};\\\", \\\"{x:1684,y:946,t:1527271999486};\\\", \\\"{x:1682,y:946,t:1527271999502};\\\", \\\"{x:1678,y:946,t:1527271999518};\\\", \\\"{x:1668,y:946,t:1527271999534};\\\", \\\"{x:1651,y:946,t:1527271999551};\\\", \\\"{x:1625,y:946,t:1527271999568};\\\", \\\"{x:1603,y:944,t:1527271999585};\\\", \\\"{x:1573,y:942,t:1527271999601};\\\", \\\"{x:1563,y:942,t:1527271999617};\\\", \\\"{x:1559,y:942,t:1527271999634};\\\", \\\"{x:1557,y:945,t:1527271999651};\\\", \\\"{x:1553,y:954,t:1527271999668};\\\", \\\"{x:1543,y:968,t:1527271999685};\\\", \\\"{x:1531,y:978,t:1527271999702};\\\", \\\"{x:1518,y:988,t:1527271999718};\\\", \\\"{x:1506,y:990,t:1527271999735};\\\", \\\"{x:1497,y:993,t:1527271999751};\\\", \\\"{x:1494,y:994,t:1527271999767};\\\", \\\"{x:1493,y:994,t:1527271999793};\\\", \\\"{x:1492,y:994,t:1527271999801};\\\", \\\"{x:1482,y:994,t:1527271999818};\\\", \\\"{x:1461,y:997,t:1527271999834};\\\", \\\"{x:1433,y:1002,t:1527271999851};\\\", \\\"{x:1400,y:1003,t:1527271999869};\\\", \\\"{x:1374,y:1003,t:1527271999885};\\\", \\\"{x:1353,y:1003,t:1527271999901};\\\", \\\"{x:1340,y:1003,t:1527271999918};\\\", \\\"{x:1330,y:1003,t:1527271999934};\\\", \\\"{x:1320,y:1001,t:1527271999951};\\\", \\\"{x:1316,y:1001,t:1527271999969};\\\", \\\"{x:1309,y:1001,t:1527271999984};\\\", \\\"{x:1301,y:1001,t:1527272000001};\\\", \\\"{x:1298,y:999,t:1527272000018};\\\", \\\"{x:1295,y:999,t:1527272000034};\\\", \\\"{x:1294,y:998,t:1527272000052};\\\", \\\"{x:1294,y:997,t:1527272000121};\\\", \\\"{x:1294,y:995,t:1527272000134};\\\", \\\"{x:1294,y:992,t:1527272000151};\\\", \\\"{x:1296,y:987,t:1527272000168};\\\", \\\"{x:1298,y:985,t:1527272000185};\\\", \\\"{x:1300,y:982,t:1527272000201};\\\", \\\"{x:1302,y:978,t:1527272000218};\\\", \\\"{x:1306,y:974,t:1527272000234};\\\", \\\"{x:1307,y:971,t:1527272000252};\\\", \\\"{x:1309,y:966,t:1527272000268};\\\", \\\"{x:1310,y:963,t:1527272000285};\\\", \\\"{x:1310,y:962,t:1527272000314};\\\", \\\"{x:1310,y:961,t:1527272000665};\\\", \\\"{x:1312,y:961,t:1527272000673};\\\", \\\"{x:1313,y:961,t:1527272000685};\\\", \\\"{x:1315,y:961,t:1527272000703};\\\", \\\"{x:1319,y:962,t:1527272000719};\\\", \\\"{x:1320,y:963,t:1527272000735};\\\", \\\"{x:1323,y:964,t:1527272000752};\\\", \\\"{x:1326,y:964,t:1527272000768};\\\", \\\"{x:1327,y:964,t:1527272000785};\\\", \\\"{x:1330,y:966,t:1527272000803};\\\", \\\"{x:1331,y:966,t:1527272000819};\\\", \\\"{x:1335,y:966,t:1527272000835};\\\", \\\"{x:1343,y:967,t:1527272000853};\\\", \\\"{x:1350,y:968,t:1527272000868};\\\", \\\"{x:1354,y:970,t:1527272000885};\\\", \\\"{x:1360,y:971,t:1527272000903};\\\", \\\"{x:1363,y:972,t:1527272000919};\\\", \\\"{x:1368,y:974,t:1527272000935};\\\", \\\"{x:1375,y:975,t:1527272000953};\\\", \\\"{x:1381,y:976,t:1527272000968};\\\", \\\"{x:1386,y:978,t:1527272000985};\\\", \\\"{x:1386,y:976,t:1527272001169};\\\", \\\"{x:1386,y:974,t:1527272001185};\\\", \\\"{x:1385,y:973,t:1527272001202};\\\", \\\"{x:1384,y:972,t:1527272001249};\\\", \\\"{x:1384,y:971,t:1527272001257};\\\", \\\"{x:1383,y:971,t:1527272001273};\\\", \\\"{x:1383,y:970,t:1527272001530};\\\", \\\"{x:1381,y:969,t:1527272001546};\\\", \\\"{x:1381,y:968,t:1527272001570};\\\", \\\"{x:1384,y:968,t:1527272001633};\\\", \\\"{x:1388,y:968,t:1527272001641};\\\", \\\"{x:1391,y:968,t:1527272001652};\\\", \\\"{x:1402,y:968,t:1527272001669};\\\", \\\"{x:1421,y:968,t:1527272001686};\\\", \\\"{x:1440,y:968,t:1527272001703};\\\", \\\"{x:1458,y:968,t:1527272001719};\\\", \\\"{x:1468,y:969,t:1527272001737};\\\", \\\"{x:1473,y:969,t:1527272001752};\\\", \\\"{x:1472,y:969,t:1527272001937};\\\", \\\"{x:1471,y:968,t:1527272001953};\\\", \\\"{x:1468,y:968,t:1527272001969};\\\", \\\"{x:1467,y:968,t:1527272001993};\\\", \\\"{x:1466,y:968,t:1527272002002};\\\", \\\"{x:1461,y:968,t:1527272002019};\\\", \\\"{x:1459,y:968,t:1527272002036};\\\", \\\"{x:1458,y:968,t:1527272002053};\\\", \\\"{x:1455,y:968,t:1527272002106};\\\", \\\"{x:1451,y:967,t:1527272002119};\\\", \\\"{x:1449,y:966,t:1527272002136};\\\", \\\"{x:1447,y:965,t:1527272002154};\\\", \\\"{x:1446,y:965,t:1527272002185};\\\", \\\"{x:1448,y:965,t:1527272002345};\\\", \\\"{x:1451,y:965,t:1527272002353};\\\", \\\"{x:1456,y:966,t:1527272002369};\\\", \\\"{x:1463,y:967,t:1527272002387};\\\", \\\"{x:1467,y:967,t:1527272002404};\\\", \\\"{x:1468,y:967,t:1527272002420};\\\", \\\"{x:1469,y:967,t:1527272002505};\\\", \\\"{x:1471,y:967,t:1527272002521};\\\", \\\"{x:1473,y:967,t:1527272002537};\\\", \\\"{x:1478,y:967,t:1527272002553};\\\", \\\"{x:1480,y:967,t:1527272002571};\\\", \\\"{x:1483,y:967,t:1527272002586};\\\", \\\"{x:1492,y:969,t:1527272002604};\\\", \\\"{x:1497,y:971,t:1527272002620};\\\", \\\"{x:1507,y:974,t:1527272002637};\\\", \\\"{x:1515,y:975,t:1527272002653};\\\", \\\"{x:1517,y:976,t:1527272002670};\\\", \\\"{x:1518,y:976,t:1527272003001};\\\", \\\"{x:1518,y:975,t:1527272003033};\\\", \\\"{x:1518,y:974,t:1527272003154};\\\", \\\"{x:1518,y:973,t:1527272003171};\\\", \\\"{x:1518,y:972,t:1527272003188};\\\", \\\"{x:1517,y:971,t:1527272003228};\\\", \\\"{x:1516,y:971,t:1527272003245};\\\", \\\"{x:1516,y:970,t:1527272003748};\\\", \\\"{x:1516,y:969,t:1527272004220};\\\", \\\"{x:1515,y:968,t:1527272004300};\\\", \\\"{x:1514,y:968,t:1527272004372};\\\", \\\"{x:1514,y:967,t:1527272004485};\\\", \\\"{x:1516,y:967,t:1527272004788};\\\", \\\"{x:1518,y:967,t:1527272004796};\\\", \\\"{x:1519,y:967,t:1527272004940};\\\", \\\"{x:1520,y:967,t:1527272004971};\\\", \\\"{x:1521,y:967,t:1527272004987};\\\", \\\"{x:1523,y:967,t:1527272005004};\\\", \\\"{x:1526,y:967,t:1527272005011};\\\", \\\"{x:1531,y:967,t:1527272005024};\\\", \\\"{x:1540,y:967,t:1527272005042};\\\", \\\"{x:1546,y:967,t:1527272005058};\\\", \\\"{x:1555,y:967,t:1527272005074};\\\", \\\"{x:1561,y:966,t:1527272005091};\\\", \\\"{x:1562,y:966,t:1527272005108};\\\", \\\"{x:1563,y:965,t:1527272005276};\\\", \\\"{x:1561,y:965,t:1527272005308};\\\", \\\"{x:1555,y:965,t:1527272005325};\\\", \\\"{x:1554,y:965,t:1527272005341};\\\", \\\"{x:1552,y:965,t:1527272005358};\\\", \\\"{x:1551,y:965,t:1527272005620};\\\", \\\"{x:1550,y:965,t:1527272005669};\\\", \\\"{x:1549,y:965,t:1527272005676};\\\", \\\"{x:1548,y:965,t:1527272005692};\\\", \\\"{x:1553,y:965,t:1527272028932};\\\", \\\"{x:1556,y:965,t:1527272028943};\\\", \\\"{x:1559,y:965,t:1527272028960};\\\", \\\"{x:1562,y:965,t:1527272028977};\\\", \\\"{x:1566,y:965,t:1527272028993};\\\", \\\"{x:1572,y:966,t:1527272029011};\\\", \\\"{x:1576,y:966,t:1527272029028};\\\", \\\"{x:1580,y:966,t:1527272029043};\\\", \\\"{x:1585,y:966,t:1527272029060};\\\", \\\"{x:1592,y:966,t:1527272029078};\\\", \\\"{x:1597,y:966,t:1527272029095};\\\", \\\"{x:1600,y:966,t:1527272029110};\\\", \\\"{x:1601,y:966,t:1527272029127};\\\", \\\"{x:1601,y:967,t:1527272029252};\\\", \\\"{x:1599,y:967,t:1527272029260};\\\", \\\"{x:1593,y:968,t:1527272029277};\\\", \\\"{x:1585,y:970,t:1527272029294};\\\", \\\"{x:1573,y:971,t:1527272029310};\\\", \\\"{x:1559,y:973,t:1527272029327};\\\", \\\"{x:1548,y:975,t:1527272029344};\\\", \\\"{x:1542,y:976,t:1527272029360};\\\", \\\"{x:1539,y:976,t:1527272029377};\\\", \\\"{x:1540,y:976,t:1527272029524};\\\", \\\"{x:1542,y:976,t:1527272029531};\\\", \\\"{x:1543,y:976,t:1527272029545};\\\", \\\"{x:1547,y:975,t:1527272029561};\\\", \\\"{x:1550,y:974,t:1527272029578};\\\", \\\"{x:1553,y:974,t:1527272029595};\\\", \\\"{x:1555,y:972,t:1527272029612};\\\", \\\"{x:1556,y:972,t:1527272029627};\\\", \\\"{x:1557,y:972,t:1527272029724};\\\", \\\"{x:1558,y:972,t:1527272029740};\\\", \\\"{x:1560,y:972,t:1527272029788};\\\", \\\"{x:1561,y:972,t:1527272029796};\\\", \\\"{x:1567,y:972,t:1527272029812};\\\", \\\"{x:1572,y:972,t:1527272029827};\\\", \\\"{x:1577,y:972,t:1527272029844};\\\", \\\"{x:1579,y:971,t:1527272029867};\\\", \\\"{x:1577,y:971,t:1527272031140};\\\", \\\"{x:1575,y:971,t:1527272031147};\\\", \\\"{x:1568,y:971,t:1527272031163};\\\", \\\"{x:1549,y:979,t:1527272031179};\\\", \\\"{x:1487,y:1004,t:1527272031196};\\\", \\\"{x:1441,y:1019,t:1527272031212};\\\", \\\"{x:1400,y:1029,t:1527272031228};\\\", \\\"{x:1358,y:1036,t:1527272031245};\\\", \\\"{x:1338,y:1038,t:1527272031263};\\\", \\\"{x:1331,y:1039,t:1527272031279};\\\", \\\"{x:1330,y:1039,t:1527272031324};\\\", \\\"{x:1329,y:1039,t:1527272031340};\\\", \\\"{x:1328,y:1039,t:1527272031389};\\\", \\\"{x:1328,y:1037,t:1527272031396};\\\", \\\"{x:1328,y:1029,t:1527272031413};\\\", \\\"{x:1327,y:1021,t:1527272031430};\\\", \\\"{x:1327,y:1004,t:1527272031446};\\\", \\\"{x:1330,y:989,t:1527272031463};\\\", \\\"{x:1339,y:973,t:1527272031479};\\\", \\\"{x:1343,y:963,t:1527272031496};\\\", \\\"{x:1347,y:956,t:1527272031513};\\\", \\\"{x:1348,y:954,t:1527272031530};\\\", \\\"{x:1348,y:952,t:1527272031546};\\\", \\\"{x:1348,y:950,t:1527272031563};\\\", \\\"{x:1347,y:944,t:1527272031580};\\\", \\\"{x:1346,y:943,t:1527272031596};\\\", \\\"{x:1347,y:942,t:1527272031652};\\\", \\\"{x:1350,y:942,t:1527272031663};\\\", \\\"{x:1354,y:942,t:1527272031680};\\\", \\\"{x:1355,y:942,t:1527272031696};\\\", \\\"{x:1358,y:942,t:1527272031713};\\\", \\\"{x:1360,y:943,t:1527272031731};\\\", \\\"{x:1362,y:944,t:1527272031746};\\\", \\\"{x:1362,y:945,t:1527272031820};\\\", \\\"{x:1362,y:946,t:1527272031853};\\\", \\\"{x:1362,y:948,t:1527272031863};\\\", \\\"{x:1356,y:954,t:1527272031880};\\\", \\\"{x:1351,y:958,t:1527272031896};\\\", \\\"{x:1344,y:963,t:1527272031913};\\\", \\\"{x:1339,y:967,t:1527272031930};\\\", \\\"{x:1336,y:969,t:1527272031946};\\\", \\\"{x:1332,y:970,t:1527272031962};\\\", \\\"{x:1331,y:970,t:1527272031979};\\\", \\\"{x:1331,y:971,t:1527272032100};\\\", \\\"{x:1332,y:972,t:1527272032113};\\\", \\\"{x:1333,y:972,t:1527272032130};\\\", \\\"{x:1332,y:972,t:1527272032212};\\\", \\\"{x:1324,y:972,t:1527272032230};\\\", \\\"{x:1314,y:971,t:1527272032247};\\\", \\\"{x:1307,y:971,t:1527272032264};\\\", \\\"{x:1302,y:969,t:1527272032280};\\\", \\\"{x:1301,y:969,t:1527272032297};\\\", \\\"{x:1302,y:969,t:1527272032604};\\\", \\\"{x:1303,y:969,t:1527272032619};\\\", \\\"{x:1305,y:969,t:1527272032636};\\\", \\\"{x:1306,y:969,t:1527272032651};\\\", \\\"{x:1309,y:970,t:1527272032664};\\\", \\\"{x:1311,y:970,t:1527272032764};\\\", \\\"{x:1314,y:970,t:1527272032780};\\\", \\\"{x:1315,y:970,t:1527272032797};\\\", \\\"{x:1316,y:970,t:1527272032814};\\\", \\\"{x:1318,y:970,t:1527272033197};\\\", \\\"{x:1321,y:970,t:1527272033204};\\\", \\\"{x:1323,y:970,t:1527272033213};\\\", \\\"{x:1333,y:972,t:1527272033231};\\\", \\\"{x:1340,y:973,t:1527272033247};\\\", \\\"{x:1347,y:974,t:1527272033263};\\\", \\\"{x:1348,y:974,t:1527272033281};\\\", \\\"{x:1348,y:973,t:1527272033524};\\\", \\\"{x:1348,y:972,t:1527272033531};\\\", \\\"{x:1349,y:970,t:1527272033683};\\\", \\\"{x:1353,y:970,t:1527272033698};\\\", \\\"{x:1361,y:970,t:1527272033715};\\\", \\\"{x:1375,y:970,t:1527272033731};\\\", \\\"{x:1387,y:971,t:1527272033748};\\\", \\\"{x:1392,y:971,t:1527272033765};\\\", \\\"{x:1393,y:971,t:1527272033780};\\\", \\\"{x:1395,y:971,t:1527272033798};\\\", \\\"{x:1395,y:972,t:1527272033815};\\\", \\\"{x:1394,y:972,t:1527272033931};\\\", \\\"{x:1392,y:972,t:1527272033948};\\\", \\\"{x:1391,y:972,t:1527272033965};\\\", \\\"{x:1389,y:972,t:1527272034067};\\\", \\\"{x:1388,y:971,t:1527272034081};\\\", \\\"{x:1387,y:970,t:1527272034180};\\\", \\\"{x:1386,y:970,t:1527272034187};\\\", \\\"{x:1385,y:970,t:1527272034204};\\\", \\\"{x:1383,y:970,t:1527272034219};\\\", \\\"{x:1382,y:969,t:1527272034232};\\\", \\\"{x:1381,y:969,t:1527272034267};\\\", \\\"{x:1380,y:968,t:1527272034282};\\\", \\\"{x:1379,y:968,t:1527272034299};\\\", \\\"{x:1379,y:967,t:1527272034316};\\\", \\\"{x:1380,y:967,t:1527272034403};\\\", \\\"{x:1381,y:967,t:1527272034415};\\\", \\\"{x:1386,y:967,t:1527272034432};\\\", \\\"{x:1395,y:967,t:1527272034449};\\\", \\\"{x:1401,y:967,t:1527272034464};\\\", \\\"{x:1405,y:968,t:1527272034482};\\\", \\\"{x:1406,y:968,t:1527272034498};\\\", \\\"{x:1408,y:968,t:1527272034579};\\\", \\\"{x:1409,y:968,t:1527272034700};\\\", \\\"{x:1411,y:968,t:1527272034715};\\\", \\\"{x:1412,y:968,t:1527272034731};\\\", \\\"{x:1414,y:968,t:1527272034749};\\\", \\\"{x:1415,y:968,t:1527272034796};\\\", \\\"{x:1417,y:969,t:1527272035051};\\\", \\\"{x:1418,y:969,t:1527272035076};\\\", \\\"{x:1419,y:969,t:1527272035091};\\\", \\\"{x:1420,y:969,t:1527272035124};\\\", \\\"{x:1421,y:969,t:1527272035147};\\\", \\\"{x:1422,y:970,t:1527272035166};\\\", \\\"{x:1423,y:970,t:1527272035182};\\\", \\\"{x:1425,y:970,t:1527272035199};\\\", \\\"{x:1426,y:970,t:1527272035216};\\\", \\\"{x:1430,y:970,t:1527272035232};\\\", \\\"{x:1432,y:970,t:1527272035249};\\\", \\\"{x:1434,y:970,t:1527272035265};\\\", \\\"{x:1435,y:970,t:1527272035331};\\\", \\\"{x:1437,y:970,t:1527272035349};\\\", \\\"{x:1439,y:970,t:1527272035366};\\\", \\\"{x:1440,y:970,t:1527272035382};\\\", \\\"{x:1441,y:970,t:1527272035475};\\\", \\\"{x:1442,y:970,t:1527272035491};\\\", \\\"{x:1443,y:970,t:1527272035499};\\\", \\\"{x:1445,y:969,t:1527272035595};\\\", \\\"{x:1446,y:969,t:1527272035603};\\\", \\\"{x:1448,y:968,t:1527272035619};\\\", \\\"{x:1450,y:967,t:1527272035660};\\\", \\\"{x:1451,y:967,t:1527272035837};\\\", \\\"{x:1453,y:967,t:1527272035849};\\\", \\\"{x:1458,y:967,t:1527272035866};\\\", \\\"{x:1460,y:967,t:1527272035883};\\\", \\\"{x:1466,y:968,t:1527272035899};\\\", \\\"{x:1467,y:968,t:1527272035915};\\\", \\\"{x:1469,y:969,t:1527272035932};\\\", \\\"{x:1470,y:969,t:1527272035980};\\\", \\\"{x:1472,y:969,t:1527272035988};\\\", \\\"{x:1474,y:969,t:1527272036000};\\\", \\\"{x:1476,y:969,t:1527272036016};\\\", \\\"{x:1477,y:970,t:1527272036196};\\\", \\\"{x:1478,y:970,t:1527272036212};\\\", \\\"{x:1479,y:970,t:1527272036243};\\\", \\\"{x:1480,y:970,t:1527272036372};\\\", \\\"{x:1482,y:970,t:1527272036383};\\\", \\\"{x:1483,y:970,t:1527272036400};\\\", \\\"{x:1486,y:970,t:1527272036417};\\\", \\\"{x:1489,y:970,t:1527272036433};\\\", \\\"{x:1491,y:970,t:1527272036449};\\\", \\\"{x:1493,y:970,t:1527272036467};\\\", \\\"{x:1495,y:970,t:1527272036482};\\\", \\\"{x:1502,y:970,t:1527272036500};\\\", \\\"{x:1504,y:971,t:1527272036517};\\\", \\\"{x:1505,y:971,t:1527272036533};\\\", \\\"{x:1506,y:971,t:1527272036628};\\\", \\\"{x:1508,y:971,t:1527272036644};\\\", \\\"{x:1509,y:971,t:1527272036652};\\\", \\\"{x:1512,y:971,t:1527272036667};\\\", \\\"{x:1514,y:971,t:1527272036684};\\\", \\\"{x:1515,y:971,t:1527272036700};\\\", \\\"{x:1516,y:971,t:1527272036797};\\\", \\\"{x:1517,y:970,t:1527272036804};\\\", \\\"{x:1517,y:969,t:1527272036820};\\\", \\\"{x:1518,y:968,t:1527272037060};\\\", \\\"{x:1519,y:968,t:1527272037075};\\\", \\\"{x:1522,y:968,t:1527272037083};\\\", \\\"{x:1532,y:969,t:1527272037101};\\\", \\\"{x:1540,y:969,t:1527272037117};\\\", \\\"{x:1544,y:971,t:1527272037133};\\\", \\\"{x:1544,y:972,t:1527272037151};\\\", \\\"{x:1546,y:972,t:1527272037244};\\\", \\\"{x:1547,y:972,t:1527272037355};\\\", \\\"{x:1548,y:972,t:1527272037372};\\\", \\\"{x:1549,y:972,t:1527272037387};\\\", \\\"{x:1549,y:971,t:1527272037460};\\\", \\\"{x:1550,y:971,t:1527272037692};\\\", \\\"{x:1552,y:971,t:1527272037812};\\\", \\\"{x:1554,y:971,t:1527272037819};\\\", \\\"{x:1557,y:971,t:1527272037833};\\\", \\\"{x:1561,y:971,t:1527272037851};\\\", \\\"{x:1566,y:971,t:1527272037867};\\\", \\\"{x:1570,y:971,t:1527272037884};\\\", \\\"{x:1573,y:971,t:1527272037901};\\\", \\\"{x:1577,y:971,t:1527272037918};\\\", \\\"{x:1578,y:971,t:1527272037935};\\\", \\\"{x:1579,y:971,t:1527272037964};\\\", \\\"{x:1580,y:971,t:1527272037980};\\\", \\\"{x:1581,y:971,t:1527272038003};\\\", \\\"{x:1582,y:971,t:1527272038027};\\\", \\\"{x:1583,y:970,t:1527272038100};\\\", \\\"{x:1583,y:968,t:1527272038124};\\\", \\\"{x:1582,y:967,t:1527272038163};\\\", \\\"{x:1581,y:967,t:1527272038203};\\\", \\\"{x:1580,y:967,t:1527272038628};\\\", \\\"{x:1581,y:967,t:1527272039172};\\\", \\\"{x:1588,y:967,t:1527272039185};\\\", \\\"{x:1610,y:977,t:1527272039202};\\\", \\\"{x:1634,y:987,t:1527272039219};\\\", \\\"{x:1657,y:998,t:1527272039235};\\\", \\\"{x:1675,y:1009,t:1527272039252};\\\", \\\"{x:1677,y:1009,t:1527272039269};\\\", \\\"{x:1678,y:1009,t:1527272039323};\\\", \\\"{x:1678,y:1008,t:1527272039336};\\\", \\\"{x:1678,y:1006,t:1527272039351};\\\", \\\"{x:1678,y:1001,t:1527272039368};\\\", \\\"{x:1677,y:994,t:1527272039385};\\\", \\\"{x:1674,y:986,t:1527272039402};\\\", \\\"{x:1671,y:981,t:1527272039419};\\\", \\\"{x:1667,y:974,t:1527272039435};\\\", \\\"{x:1663,y:972,t:1527272039452};\\\", \\\"{x:1662,y:970,t:1527272039469};\\\", \\\"{x:1661,y:970,t:1527272039499};\\\", \\\"{x:1659,y:970,t:1527272039524};\\\", \\\"{x:1658,y:970,t:1527272039548};\\\", \\\"{x:1656,y:970,t:1527272039556};\\\", \\\"{x:1655,y:970,t:1527272039571};\\\", \\\"{x:1654,y:970,t:1527272039586};\\\", \\\"{x:1653,y:970,t:1527272039601};\\\", \\\"{x:1651,y:970,t:1527272039619};\\\", \\\"{x:1648,y:970,t:1527272039635};\\\", \\\"{x:1645,y:971,t:1527272039652};\\\", \\\"{x:1641,y:971,t:1527272039669};\\\", \\\"{x:1638,y:972,t:1527272039686};\\\", \\\"{x:1636,y:972,t:1527272039715};\\\", \\\"{x:1635,y:973,t:1527272039731};\\\", \\\"{x:1633,y:973,t:1527272039795};\\\", \\\"{x:1631,y:973,t:1527272039811};\\\", \\\"{x:1630,y:973,t:1527272039819};\\\", \\\"{x:1629,y:973,t:1527272039836};\\\", \\\"{x:1628,y:973,t:1527272039853};\\\", \\\"{x:1627,y:973,t:1527272039891};\\\", \\\"{x:1626,y:973,t:1527272039903};\\\", \\\"{x:1628,y:973,t:1527272040051};\\\", \\\"{x:1632,y:973,t:1527272040060};\\\", \\\"{x:1634,y:973,t:1527272040070};\\\", \\\"{x:1639,y:973,t:1527272040086};\\\", \\\"{x:1641,y:973,t:1527272040103};\\\", \\\"{x:1643,y:973,t:1527272040120};\\\", \\\"{x:1644,y:973,t:1527272040171};\\\", \\\"{x:1644,y:971,t:1527272040315};\\\", \\\"{x:1644,y:970,t:1527272040331};\\\", \\\"{x:1644,y:969,t:1527272040347};\\\", \\\"{x:1644,y:968,t:1527272040435};\\\", \\\"{x:1646,y:966,t:1527272040452};\\\", \\\"{x:1647,y:965,t:1527272040470};\\\", \\\"{x:1648,y:964,t:1527272040499};\\\", \\\"{x:1650,y:964,t:1527272040595};\\\", \\\"{x:1652,y:963,t:1527272040604};\\\", \\\"{x:1654,y:962,t:1527272040620};\\\", \\\"{x:1656,y:961,t:1527272040637};\\\", \\\"{x:1657,y:961,t:1527272040740};\\\", \\\"{x:1658,y:961,t:1527272040763};\\\", \\\"{x:1659,y:962,t:1527272040771};\\\", \\\"{x:1660,y:962,t:1527272040787};\\\", \\\"{x:1662,y:962,t:1527272040804};\\\", \\\"{x:1667,y:963,t:1527272040819};\\\", \\\"{x:1670,y:964,t:1527272040837};\\\", \\\"{x:1674,y:965,t:1527272040853};\\\", \\\"{x:1678,y:966,t:1527272040870};\\\", \\\"{x:1679,y:966,t:1527272040891};\\\", \\\"{x:1680,y:966,t:1527272040971};\\\", \\\"{x:1681,y:966,t:1527272040987};\\\", \\\"{x:1683,y:966,t:1527272041003};\\\", \\\"{x:1691,y:966,t:1527272041020};\\\", \\\"{x:1694,y:966,t:1527272041036};\\\", \\\"{x:1692,y:966,t:1527272041156};\\\", \\\"{x:1691,y:966,t:1527272041252};\\\", \\\"{x:1689,y:966,t:1527272041276};\\\", \\\"{x:1688,y:966,t:1527272041300};\\\", \\\"{x:1687,y:966,t:1527272041315};\\\", \\\"{x:1686,y:967,t:1527272041445};\\\", \\\"{x:1685,y:968,t:1527272041468};\\\", \\\"{x:1686,y:968,t:1527272041651};\\\", \\\"{x:1689,y:969,t:1527272041660};\\\", \\\"{x:1693,y:970,t:1527272041671};\\\", \\\"{x:1700,y:973,t:1527272041688};\\\", \\\"{x:1703,y:973,t:1527272041705};\\\", \\\"{x:1704,y:973,t:1527272041724};\\\", \\\"{x:1705,y:973,t:1527272041836};\\\", \\\"{x:1706,y:973,t:1527272041932};\\\", \\\"{x:1707,y:973,t:1527272042012};\\\", \\\"{x:1708,y:972,t:1527272042021};\\\", \\\"{x:1709,y:971,t:1527272042132};\\\", \\\"{x:1710,y:971,t:1527272042140};\\\", \\\"{x:1711,y:971,t:1527272042154};\\\", \\\"{x:1713,y:971,t:1527272042171};\\\", \\\"{x:1714,y:971,t:1527272042188};\\\", \\\"{x:1715,y:971,t:1527272042396};\\\", \\\"{x:1718,y:971,t:1527272042405};\\\", \\\"{x:1722,y:971,t:1527272042421};\\\", \\\"{x:1728,y:971,t:1527272042439};\\\", \\\"{x:1732,y:970,t:1527272042455};\\\", \\\"{x:1735,y:970,t:1527272042471};\\\", \\\"{x:1737,y:969,t:1527272042488};\\\", \\\"{x:1739,y:969,t:1527272042505};\\\", \\\"{x:1740,y:969,t:1527272042521};\\\", \\\"{x:1741,y:968,t:1527272042549};\\\", \\\"{x:1742,y:968,t:1527272042572};\\\", \\\"{x:1743,y:968,t:1527272042588};\\\", \\\"{x:1744,y:968,t:1527272042605};\\\", \\\"{x:1745,y:968,t:1527272042700};\\\", \\\"{x:1747,y:968,t:1527272042708};\\\", \\\"{x:1749,y:968,t:1527272042721};\\\", \\\"{x:1753,y:968,t:1527272042738};\\\", \\\"{x:1755,y:968,t:1527272042755};\\\", \\\"{x:1755,y:967,t:1527272042788};\\\", \\\"{x:1755,y:966,t:1527272042805};\\\", \\\"{x:1756,y:966,t:1527272043125};\\\", \\\"{x:1757,y:966,t:1527272043138};\\\", \\\"{x:1758,y:966,t:1527272043197};\\\", \\\"{x:1759,y:966,t:1527272043237};\\\", \\\"{x:1761,y:967,t:1527272043276};\\\", \\\"{x:1762,y:967,t:1527272043291};\\\", \\\"{x:1765,y:968,t:1527272043305};\\\", \\\"{x:1767,y:968,t:1527272043322};\\\", \\\"{x:1768,y:969,t:1527272043340};\\\", \\\"{x:1769,y:969,t:1527272043388};\\\", \\\"{x:1773,y:969,t:1527272043405};\\\", \\\"{x:1778,y:970,t:1527272043422};\\\", \\\"{x:1780,y:970,t:1527272043439};\\\", \\\"{x:1782,y:970,t:1527272043455};\\\", \\\"{x:1784,y:970,t:1527272043796};\\\", \\\"{x:1785,y:970,t:1527272043806};\\\", \\\"{x:1788,y:970,t:1527272043822};\\\", \\\"{x:1789,y:970,t:1527272043839};\\\", \\\"{x:1792,y:970,t:1527272043856};\\\", \\\"{x:1795,y:971,t:1527272043872};\\\", \\\"{x:1798,y:973,t:1527272043889};\\\", \\\"{x:1803,y:973,t:1527272043906};\\\", \\\"{x:1804,y:973,t:1527272043922};\\\", \\\"{x:1805,y:973,t:1527272043939};\\\", \\\"{x:1806,y:973,t:1527272043956};\\\", \\\"{x:1807,y:973,t:1527272043972};\\\", \\\"{x:1808,y:973,t:1527272043989};\\\", \\\"{x:1809,y:973,t:1527272044006};\\\", \\\"{x:1810,y:973,t:1527272044027};\\\", \\\"{x:1812,y:973,t:1527272044051};\\\", \\\"{x:1814,y:973,t:1527272044060};\\\", \\\"{x:1815,y:973,t:1527272044072};\\\", \\\"{x:1817,y:973,t:1527272044089};\\\", \\\"{x:1818,y:973,t:1527272044106};\\\", \\\"{x:1821,y:973,t:1527272044476};\\\", \\\"{x:1825,y:973,t:1527272044489};\\\", \\\"{x:1832,y:973,t:1527272044507};\\\", \\\"{x:1838,y:973,t:1527272044524};\\\", \\\"{x:1842,y:973,t:1527272044539};\\\", \\\"{x:1843,y:973,t:1527272044572};\\\", \\\"{x:1844,y:973,t:1527272044596};\\\", \\\"{x:1845,y:973,t:1527272044620};\\\", \\\"{x:1846,y:973,t:1527272044628};\\\", \\\"{x:1847,y:973,t:1527272044640};\\\", \\\"{x:1850,y:973,t:1527272044656};\\\", \\\"{x:1853,y:973,t:1527272044674};\\\", \\\"{x:1854,y:972,t:1527272044690};\\\", \\\"{x:1857,y:972,t:1527272045012};\\\", \\\"{x:1858,y:972,t:1527272045023};\\\", \\\"{x:1863,y:971,t:1527272045041};\\\", \\\"{x:1867,y:971,t:1527272045057};\\\", \\\"{x:1868,y:971,t:1527272045073};\\\", \\\"{x:1870,y:971,t:1527272045090};\\\", \\\"{x:1869,y:971,t:1527272045260};\\\", \\\"{x:1868,y:971,t:1527272045273};\\\", \\\"{x:1867,y:971,t:1527272045291};\\\", \\\"{x:1866,y:971,t:1527272045308};\\\", \\\"{x:1865,y:971,t:1527272045373};\\\", \\\"{x:1861,y:971,t:1527272045391};\\\", \\\"{x:1855,y:974,t:1527272045408};\\\", \\\"{x:1849,y:974,t:1527272045424};\\\", \\\"{x:1838,y:975,t:1527272045440};\\\", \\\"{x:1829,y:976,t:1527272045458};\\\", \\\"{x:1822,y:976,t:1527272045474};\\\", \\\"{x:1816,y:976,t:1527272045490};\\\", \\\"{x:1809,y:976,t:1527272045508};\\\", \\\"{x:1793,y:976,t:1527272045525};\\\", \\\"{x:1782,y:976,t:1527272045540};\\\", \\\"{x:1771,y:976,t:1527272045558};\\\", \\\"{x:1757,y:976,t:1527272045575};\\\", \\\"{x:1746,y:976,t:1527272045591};\\\", \\\"{x:1735,y:974,t:1527272045607};\\\", \\\"{x:1728,y:973,t:1527272045625};\\\", \\\"{x:1724,y:972,t:1527272045641};\\\", \\\"{x:1721,y:972,t:1527272045658};\\\", \\\"{x:1720,y:972,t:1527272045675};\\\", \\\"{x:1717,y:972,t:1527272045691};\\\", \\\"{x:1712,y:970,t:1527272045707};\\\", \\\"{x:1706,y:970,t:1527272045724};\\\", \\\"{x:1700,y:970,t:1527272045741};\\\", \\\"{x:1697,y:970,t:1527272045758};\\\", \\\"{x:1692,y:970,t:1527272045774};\\\", \\\"{x:1686,y:970,t:1527272045791};\\\", \\\"{x:1684,y:970,t:1527272045808};\\\", \\\"{x:1679,y:970,t:1527272045825};\\\", \\\"{x:1677,y:971,t:1527272045841};\\\", \\\"{x:1671,y:973,t:1527272045858};\\\", \\\"{x:1668,y:974,t:1527272045874};\\\", \\\"{x:1662,y:975,t:1527272045891};\\\", \\\"{x:1657,y:977,t:1527272045907};\\\", \\\"{x:1655,y:977,t:1527272045924};\\\", \\\"{x:1652,y:977,t:1527272045941};\\\", \\\"{x:1651,y:977,t:1527272045957};\\\", \\\"{x:1647,y:977,t:1527272045974};\\\", \\\"{x:1642,y:978,t:1527272045991};\\\", \\\"{x:1635,y:979,t:1527272046007};\\\", \\\"{x:1628,y:981,t:1527272046024};\\\", \\\"{x:1624,y:981,t:1527272046041};\\\", \\\"{x:1617,y:982,t:1527272046057};\\\", \\\"{x:1610,y:982,t:1527272046074};\\\", \\\"{x:1605,y:983,t:1527272046091};\\\", \\\"{x:1602,y:983,t:1527272046107};\\\", \\\"{x:1599,y:983,t:1527272046124};\\\", \\\"{x:1598,y:983,t:1527272046141};\\\", \\\"{x:1596,y:983,t:1527272046157};\\\", \\\"{x:1593,y:983,t:1527272046175};\\\", \\\"{x:1589,y:983,t:1527272046191};\\\", \\\"{x:1587,y:983,t:1527272046207};\\\", \\\"{x:1586,y:983,t:1527272046225};\\\", \\\"{x:1585,y:983,t:1527272046242};\\\", \\\"{x:1584,y:984,t:1527272046332};\\\", \\\"{x:1583,y:984,t:1527272046540};\\\", \\\"{x:1582,y:983,t:1527272046555};\\\", \\\"{x:1582,y:982,t:1527272046572};\\\", \\\"{x:1582,y:981,t:1527272046579};\\\", \\\"{x:1582,y:980,t:1527272046596};\\\", \\\"{x:1582,y:979,t:1527272046609};\\\", \\\"{x:1582,y:978,t:1527272046628};\\\", \\\"{x:1582,y:976,t:1527272046716};\\\", \\\"{x:1582,y:975,t:1527272046725};\\\", \\\"{x:1583,y:974,t:1527272046748};\\\", \\\"{x:1583,y:973,t:1527272046820};\\\", \\\"{x:1582,y:972,t:1527272046828};\\\", \\\"{x:1582,y:970,t:1527272046841};\\\", \\\"{x:1581,y:970,t:1527272046859};\\\", \\\"{x:1581,y:968,t:1527272047852};\\\", \\\"{x:1581,y:967,t:1527272047860};\\\", \\\"{x:1581,y:966,t:1527272047876};\\\", \\\"{x:1582,y:965,t:1527272047892};\\\", \\\"{x:1582,y:964,t:1527272047931};\\\", \\\"{x:1582,y:963,t:1527272048700};\\\", \\\"{x:1582,y:962,t:1527272048709};\\\", \\\"{x:1582,y:960,t:1527272048727};\\\", \\\"{x:1582,y:956,t:1527272048743};\\\", \\\"{x:1582,y:952,t:1527272048759};\\\", \\\"{x:1582,y:951,t:1527272048776};\\\", \\\"{x:1582,y:950,t:1527272048793};\\\", \\\"{x:1583,y:950,t:1527272048820};\\\", \\\"{x:1584,y:950,t:1527272049116};\\\", \\\"{x:1585,y:953,t:1527272049126};\\\", \\\"{x:1586,y:957,t:1527272049143};\\\", \\\"{x:1587,y:959,t:1527272049161};\\\", \\\"{x:1587,y:962,t:1527272049176};\\\", \\\"{x:1587,y:963,t:1527272049194};\\\", \\\"{x:1587,y:962,t:1527272050419};\\\", \\\"{x:1587,y:960,t:1527272050427};\\\", \\\"{x:1587,y:952,t:1527272050445};\\\", \\\"{x:1587,y:944,t:1527272050462};\\\", \\\"{x:1587,y:934,t:1527272050478};\\\", \\\"{x:1587,y:932,t:1527272050495};\\\", \\\"{x:1587,y:929,t:1527272050512};\\\", \\\"{x:1587,y:928,t:1527272050527};\\\", \\\"{x:1587,y:926,t:1527272050544};\\\", \\\"{x:1587,y:925,t:1527272050580};\\\", \\\"{x:1587,y:922,t:1527272050594};\\\", \\\"{x:1587,y:920,t:1527272050611};\\\", \\\"{x:1587,y:919,t:1527272050627};\\\", \\\"{x:1587,y:918,t:1527272050644};\\\", \\\"{x:1587,y:917,t:1527272050661};\\\", \\\"{x:1587,y:916,t:1527272050678};\\\", \\\"{x:1587,y:915,t:1527272050699};\\\", \\\"{x:1587,y:914,t:1527272050712};\\\", \\\"{x:1587,y:911,t:1527272050728};\\\", \\\"{x:1587,y:909,t:1527272050744};\\\", \\\"{x:1587,y:905,t:1527272050761};\\\", \\\"{x:1587,y:902,t:1527272050778};\\\", \\\"{x:1587,y:899,t:1527272050794};\\\", \\\"{x:1585,y:895,t:1527272050811};\\\", \\\"{x:1584,y:894,t:1527272050828};\\\", \\\"{x:1582,y:893,t:1527272050844};\\\", \\\"{x:1581,y:892,t:1527272050861};\\\", \\\"{x:1581,y:891,t:1527272050907};\\\", \\\"{x:1580,y:889,t:1527272050915};\\\", \\\"{x:1578,y:886,t:1527272050928};\\\", \\\"{x:1576,y:883,t:1527272050944};\\\", \\\"{x:1575,y:881,t:1527272050961};\\\", \\\"{x:1575,y:878,t:1527272050979};\\\", \\\"{x:1575,y:876,t:1527272050994};\\\", \\\"{x:1574,y:873,t:1527272051010};\\\", \\\"{x:1574,y:871,t:1527272051028};\\\", \\\"{x:1574,y:869,t:1527272051044};\\\", \\\"{x:1574,y:868,t:1527272051061};\\\", \\\"{x:1574,y:865,t:1527272051078};\\\", \\\"{x:1574,y:863,t:1527272051094};\\\", \\\"{x:1574,y:859,t:1527272051111};\\\", \\\"{x:1574,y:858,t:1527272051129};\\\", \\\"{x:1574,y:857,t:1527272051144};\\\", \\\"{x:1574,y:856,t:1527272051162};\\\", \\\"{x:1574,y:855,t:1527272051188};\\\", \\\"{x:1574,y:854,t:1527272051196};\\\", \\\"{x:1574,y:853,t:1527272051211};\\\", \\\"{x:1576,y:849,t:1527272051228};\\\", \\\"{x:1579,y:841,t:1527272051246};\\\", \\\"{x:1579,y:834,t:1527272051261};\\\", \\\"{x:1581,y:828,t:1527272051278};\\\", \\\"{x:1582,y:820,t:1527272051296};\\\", \\\"{x:1586,y:809,t:1527272051311};\\\", \\\"{x:1587,y:799,t:1527272051328};\\\", \\\"{x:1590,y:787,t:1527272051345};\\\", \\\"{x:1591,y:774,t:1527272051362};\\\", \\\"{x:1593,y:764,t:1527272051379};\\\", \\\"{x:1595,y:750,t:1527272051395};\\\", \\\"{x:1596,y:740,t:1527272051411};\\\", \\\"{x:1596,y:733,t:1527272051429};\\\", \\\"{x:1598,y:730,t:1527272051446};\\\", \\\"{x:1598,y:729,t:1527272051462};\\\", \\\"{x:1598,y:728,t:1527272051589};\\\", \\\"{x:1597,y:728,t:1527272051612};\\\", \\\"{x:1595,y:730,t:1527272051629};\\\", \\\"{x:1595,y:733,t:1527272051646};\\\", \\\"{x:1595,y:734,t:1527272051662};\\\", \\\"{x:1594,y:736,t:1527272051679};\\\", \\\"{x:1593,y:738,t:1527272051695};\\\", \\\"{x:1592,y:739,t:1527272051712};\\\", \\\"{x:1592,y:740,t:1527272051812};\\\", \\\"{x:1592,y:736,t:1527272051901};\\\", \\\"{x:1590,y:733,t:1527272051913};\\\", \\\"{x:1589,y:731,t:1527272051929};\\\", \\\"{x:1588,y:728,t:1527272051946};\\\", \\\"{x:1588,y:726,t:1527272051963};\\\", \\\"{x:1588,y:723,t:1527272051979};\\\", \\\"{x:1588,y:721,t:1527272051996};\\\", \\\"{x:1588,y:719,t:1527272052059};\\\", \\\"{x:1587,y:717,t:1527272052075};\\\", \\\"{x:1587,y:714,t:1527272052084};\\\", \\\"{x:1587,y:712,t:1527272052095};\\\", \\\"{x:1584,y:708,t:1527272052112};\\\", \\\"{x:1584,y:700,t:1527272052129};\\\", \\\"{x:1582,y:692,t:1527272052145};\\\", \\\"{x:1580,y:684,t:1527272052162};\\\", \\\"{x:1578,y:671,t:1527272052179};\\\", \\\"{x:1578,y:661,t:1527272052195};\\\", \\\"{x:1576,y:655,t:1527272052213};\\\", \\\"{x:1576,y:653,t:1527272052230};\\\", \\\"{x:1576,y:652,t:1527272052245};\\\", \\\"{x:1576,y:650,t:1527272052292};\\\", \\\"{x:1575,y:649,t:1527272052300};\\\", \\\"{x:1575,y:647,t:1527272052313};\\\", \\\"{x:1575,y:645,t:1527272052329};\\\", \\\"{x:1575,y:643,t:1527272052345};\\\", \\\"{x:1575,y:642,t:1527272052362};\\\", \\\"{x:1575,y:640,t:1527272052380};\\\", \\\"{x:1575,y:639,t:1527272052436};\\\", \\\"{x:1575,y:638,t:1527272052446};\\\", \\\"{x:1575,y:637,t:1527272052463};\\\", \\\"{x:1575,y:635,t:1527272052595};\\\", \\\"{x:1576,y:633,t:1527272052613};\\\", \\\"{x:1576,y:632,t:1527272052630};\\\", \\\"{x:1577,y:630,t:1527272052646};\\\", \\\"{x:1578,y:630,t:1527272052663};\\\", \\\"{x:1579,y:628,t:1527272052731};\\\", \\\"{x:1580,y:628,t:1527272052747};\\\", \\\"{x:1580,y:627,t:1527272052762};\\\", \\\"{x:1580,y:626,t:1527272052788};\\\", \\\"{x:1583,y:623,t:1527272053644};\\\", \\\"{x:1584,y:612,t:1527272053651};\\\", \\\"{x:1585,y:602,t:1527272053663};\\\", \\\"{x:1590,y:585,t:1527272053680};\\\", \\\"{x:1593,y:576,t:1527272053696};\\\", \\\"{x:1594,y:572,t:1527272053713};\\\", \\\"{x:1594,y:565,t:1527272053730};\\\", \\\"{x:1594,y:561,t:1527272053747};\\\", \\\"{x:1594,y:555,t:1527272053763};\\\", \\\"{x:1594,y:552,t:1527272053780};\\\", \\\"{x:1594,y:546,t:1527272053797};\\\", \\\"{x:1594,y:537,t:1527272053813};\\\", \\\"{x:1594,y:530,t:1527272053831};\\\", \\\"{x:1594,y:525,t:1527272053847};\\\", \\\"{x:1594,y:522,t:1527272053864};\\\", \\\"{x:1593,y:519,t:1527272053881};\\\", \\\"{x:1591,y:515,t:1527272053898};\\\", \\\"{x:1588,y:509,t:1527272053914};\\\", \\\"{x:1585,y:503,t:1527272053931};\\\", \\\"{x:1582,y:499,t:1527272053947};\\\", \\\"{x:1581,y:498,t:1527272053964};\\\", \\\"{x:1581,y:497,t:1527272054011};\\\", \\\"{x:1579,y:494,t:1527272054027};\\\", \\\"{x:1579,y:493,t:1527272054044};\\\", \\\"{x:1578,y:493,t:1527272054051};\\\", \\\"{x:1579,y:493,t:1527272055389};\\\", \\\"{x:1580,y:493,t:1527272055399};\\\", \\\"{x:1581,y:494,t:1527272055420};\\\", \\\"{x:1581,y:496,t:1527272055460};\\\", \\\"{x:1582,y:496,t:1527272055467};\\\", \\\"{x:1582,y:497,t:1527272055484};\\\", \\\"{x:1582,y:499,t:1527272134884};\\\", \\\"{x:1583,y:500,t:1527272134896};\\\", \\\"{x:1583,y:501,t:1527272134932};\\\", \\\"{x:1584,y:504,t:1527272134947};\\\", \\\"{x:1583,y:517,t:1527272134963};\\\", \\\"{x:1582,y:528,t:1527272134979};\\\", \\\"{x:1579,y:552,t:1527272134996};\\\", \\\"{x:1575,y:570,t:1527272135013};\\\", \\\"{x:1572,y:591,t:1527272135030};\\\", \\\"{x:1568,y:611,t:1527272135046};\\\", \\\"{x:1560,y:630,t:1527272135064};\\\", \\\"{x:1555,y:650,t:1527272135081};\\\", \\\"{x:1551,y:671,t:1527272135096};\\\", \\\"{x:1546,y:687,t:1527272135113};\\\", \\\"{x:1544,y:702,t:1527272135130};\\\", \\\"{x:1543,y:709,t:1527272135146};\\\", \\\"{x:1542,y:713,t:1527272135163};\\\", \\\"{x:1542,y:708,t:1527272135277};\\\", \\\"{x:1543,y:701,t:1527272135285};\\\", \\\"{x:1545,y:697,t:1527272135296};\\\", \\\"{x:1546,y:690,t:1527272135313};\\\", \\\"{x:1548,y:679,t:1527272135330};\\\", \\\"{x:1549,y:666,t:1527272135346};\\\", \\\"{x:1549,y:663,t:1527272135363};\\\", \\\"{x:1549,y:662,t:1527272135380};\\\", \\\"{x:1549,y:660,t:1527272135397};\\\", \\\"{x:1549,y:658,t:1527272135437};\\\", \\\"{x:1549,y:656,t:1527272135446};\\\", \\\"{x:1551,y:653,t:1527272135464};\\\", \\\"{x:1551,y:648,t:1527272135480};\\\", \\\"{x:1552,y:639,t:1527272135498};\\\", \\\"{x:1558,y:633,t:1527272135513};\\\", \\\"{x:1564,y:625,t:1527272135530};\\\", \\\"{x:1569,y:620,t:1527272135548};\\\", \\\"{x:1570,y:620,t:1527272135563};\\\", \\\"{x:1570,y:619,t:1527272135581};\\\", \\\"{x:1570,y:618,t:1527272135597};\\\", \\\"{x:1572,y:617,t:1527272135622};\\\", \\\"{x:1572,y:616,t:1527272135631};\\\", \\\"{x:1573,y:615,t:1527272135648};\\\", \\\"{x:1575,y:617,t:1527272135774};\\\", \\\"{x:1582,y:629,t:1527272135782};\\\", \\\"{x:1596,y:669,t:1527272135797};\\\", \\\"{x:1610,y:695,t:1527272135813};\\\", \\\"{x:1617,y:712,t:1527272135830};\\\", \\\"{x:1618,y:719,t:1527272135847};\\\", \\\"{x:1619,y:720,t:1527272135865};\\\", \\\"{x:1619,y:721,t:1527272135880};\\\", \\\"{x:1619,y:723,t:1527272135897};\\\", \\\"{x:1619,y:727,t:1527272135914};\\\", \\\"{x:1619,y:733,t:1527272135930};\\\", \\\"{x:1619,y:740,t:1527272135947};\\\", \\\"{x:1619,y:749,t:1527272135964};\\\", \\\"{x:1619,y:753,t:1527272135980};\\\", \\\"{x:1619,y:755,t:1527272136012};\\\", \\\"{x:1618,y:756,t:1527272136021};\\\", \\\"{x:1617,y:758,t:1527272136036};\\\", \\\"{x:1616,y:759,t:1527272136047};\\\", \\\"{x:1614,y:763,t:1527272136064};\\\", \\\"{x:1611,y:765,t:1527272136080};\\\", \\\"{x:1609,y:768,t:1527272136097};\\\", \\\"{x:1607,y:769,t:1527272136114};\\\", \\\"{x:1605,y:771,t:1527272136130};\\\", \\\"{x:1603,y:773,t:1527272136147};\\\", \\\"{x:1602,y:774,t:1527272136165};\\\", \\\"{x:1601,y:774,t:1527272136245};\\\", \\\"{x:1599,y:774,t:1527272136268};\\\", \\\"{x:1597,y:774,t:1527272136281};\\\", \\\"{x:1595,y:774,t:1527272136297};\\\", \\\"{x:1592,y:774,t:1527272136314};\\\", \\\"{x:1589,y:773,t:1527272136331};\\\", \\\"{x:1587,y:771,t:1527272136346};\\\", \\\"{x:1585,y:769,t:1527272136364};\\\", \\\"{x:1583,y:769,t:1527272136381};\\\", \\\"{x:1582,y:769,t:1527272136397};\\\", \\\"{x:1581,y:768,t:1527272136549};\\\", \\\"{x:1579,y:765,t:1527272136564};\\\", \\\"{x:1578,y:762,t:1527272136581};\\\", \\\"{x:1576,y:758,t:1527272136597};\\\", \\\"{x:1578,y:759,t:1527272136741};\\\", \\\"{x:1579,y:763,t:1527272136749};\\\", \\\"{x:1583,y:772,t:1527272136765};\\\", \\\"{x:1588,y:783,t:1527272136782};\\\", \\\"{x:1589,y:790,t:1527272136798};\\\", \\\"{x:1592,y:802,t:1527272136814};\\\", \\\"{x:1593,y:810,t:1527272136832};\\\", \\\"{x:1594,y:819,t:1527272136849};\\\", \\\"{x:1594,y:824,t:1527272136864};\\\", \\\"{x:1594,y:829,t:1527272136881};\\\", \\\"{x:1594,y:837,t:1527272136898};\\\", \\\"{x:1597,y:845,t:1527272136915};\\\", \\\"{x:1598,y:851,t:1527272136932};\\\", \\\"{x:1598,y:861,t:1527272136949};\\\", \\\"{x:1598,y:867,t:1527272136964};\\\", \\\"{x:1596,y:872,t:1527272136981};\\\", \\\"{x:1595,y:877,t:1527272136999};\\\", \\\"{x:1591,y:885,t:1527272137014};\\\", \\\"{x:1591,y:895,t:1527272137031};\\\", \\\"{x:1589,y:902,t:1527272137048};\\\", \\\"{x:1588,y:907,t:1527272137064};\\\", \\\"{x:1587,y:911,t:1527272137081};\\\", \\\"{x:1587,y:912,t:1527272137098};\\\", \\\"{x:1586,y:913,t:1527272137149};\\\", \\\"{x:1584,y:913,t:1527272137164};\\\", \\\"{x:1580,y:912,t:1527272137181};\\\", \\\"{x:1578,y:909,t:1527272137199};\\\", \\\"{x:1576,y:907,t:1527272137216};\\\", \\\"{x:1574,y:905,t:1527272137231};\\\", \\\"{x:1574,y:904,t:1527272137248};\\\", \\\"{x:1573,y:902,t:1527272137265};\\\", \\\"{x:1573,y:900,t:1527272137293};\\\", \\\"{x:1574,y:899,t:1527272137365};\\\", \\\"{x:1576,y:897,t:1527272137381};\\\", \\\"{x:1578,y:896,t:1527272137399};\\\", \\\"{x:1579,y:896,t:1527272137415};\\\", \\\"{x:1582,y:894,t:1527272137432};\\\", \\\"{x:1584,y:894,t:1527272137448};\\\", \\\"{x:1585,y:894,t:1527272137465};\\\", \\\"{x:1586,y:895,t:1527272137580};\\\", \\\"{x:1586,y:899,t:1527272137588};\\\", \\\"{x:1586,y:903,t:1527272137599};\\\", \\\"{x:1586,y:913,t:1527272137615};\\\", \\\"{x:1588,y:919,t:1527272137632};\\\", \\\"{x:1588,y:925,t:1527272137648};\\\", \\\"{x:1588,y:931,t:1527272137665};\\\", \\\"{x:1589,y:935,t:1527272137682};\\\", \\\"{x:1589,y:940,t:1527272137699};\\\", \\\"{x:1589,y:943,t:1527272137715};\\\", \\\"{x:1590,y:946,t:1527272137733};\\\", \\\"{x:1590,y:948,t:1527272137756};\\\", \\\"{x:1590,y:949,t:1527272137780};\\\", \\\"{x:1590,y:951,t:1527272137796};\\\", \\\"{x:1590,y:952,t:1527272137813};\\\", \\\"{x:1590,y:954,t:1527272137828};\\\", \\\"{x:1590,y:955,t:1527272137836};\\\", \\\"{x:1590,y:957,t:1527272137848};\\\", \\\"{x:1590,y:959,t:1527272137865};\\\", \\\"{x:1590,y:961,t:1527272137882};\\\", \\\"{x:1590,y:963,t:1527272137899};\\\", \\\"{x:1588,y:964,t:1527272137915};\\\", \\\"{x:1585,y:965,t:1527272137933};\\\", \\\"{x:1584,y:965,t:1527272137949};\\\", \\\"{x:1582,y:966,t:1527272137965};\\\", \\\"{x:1582,y:967,t:1527272137988};\\\", \\\"{x:1588,y:963,t:1527272138349};\\\", \\\"{x:1591,y:963,t:1527272138366};\\\", \\\"{x:1591,y:966,t:1527272146164};\\\", \\\"{x:1591,y:967,t:1527272146172};\\\", \\\"{x:1591,y:969,t:1527272146188};\\\", \\\"{x:1591,y:971,t:1527272146205};\\\", \\\"{x:1591,y:972,t:1527272146222};\\\", \\\"{x:1591,y:974,t:1527272146239};\\\", \\\"{x:1591,y:975,t:1527272146256};\\\", \\\"{x:1591,y:976,t:1527272146356};\\\", \\\"{x:1591,y:977,t:1527272146371};\\\", \\\"{x:1590,y:977,t:1527272146422};\\\", \\\"{x:1589,y:978,t:1527272146453};\\\", \\\"{x:1588,y:978,t:1527272146541};\\\", \\\"{x:1587,y:978,t:1527272146556};\\\", \\\"{x:1583,y:977,t:1527272146572};\\\", \\\"{x:1581,y:975,t:1527272146589};\\\", \\\"{x:1581,y:973,t:1527272146620};\\\", \\\"{x:1580,y:973,t:1527272146628};\\\", \\\"{x:1580,y:972,t:1527272146644};\\\", \\\"{x:1579,y:972,t:1527272146656};\\\", \\\"{x:1578,y:971,t:1527272146673};\\\", \\\"{x:1577,y:970,t:1527272147540};\\\", \\\"{x:1577,y:966,t:1527272148492};\\\", \\\"{x:1571,y:953,t:1527272148506};\\\", \\\"{x:1552,y:909,t:1527272148524};\\\", \\\"{x:1515,y:815,t:1527272148540};\\\", \\\"{x:1488,y:726,t:1527272148556};\\\", \\\"{x:1446,y:611,t:1527272148574};\\\", \\\"{x:1400,y:493,t:1527272148590};\\\", \\\"{x:1363,y:402,t:1527272148607};\\\", \\\"{x:1344,y:318,t:1527272148623};\\\", \\\"{x:1328,y:249,t:1527272148641};\\\", \\\"{x:1326,y:195,t:1527272148657};\\\", \\\"{x:1326,y:162,t:1527272148674};\\\", \\\"{x:1326,y:141,t:1527272148691};\\\", \\\"{x:1326,y:127,t:1527272148707};\\\", \\\"{x:1327,y:124,t:1527272148724};\\\", \\\"{x:1328,y:123,t:1527272148740};\\\", \\\"{x:1332,y:126,t:1527272148789};\\\", \\\"{x:1338,y:141,t:1527272148796};\\\", \\\"{x:1350,y:160,t:1527272148808};\\\", \\\"{x:1378,y:209,t:1527272148823};\\\", \\\"{x:1420,y:275,t:1527272148841};\\\", \\\"{x:1466,y:362,t:1527272148857};\\\", \\\"{x:1512,y:444,t:1527272148873};\\\", \\\"{x:1538,y:499,t:1527272148890};\\\", \\\"{x:1545,y:526,t:1527272148908};\\\", \\\"{x:1545,y:533,t:1527272148924};\\\", \\\"{x:1539,y:539,t:1527272148941};\\\", \\\"{x:1531,y:542,t:1527272148958};\\\", \\\"{x:1524,y:543,t:1527272148974};\\\", \\\"{x:1513,y:547,t:1527272148991};\\\", \\\"{x:1498,y:556,t:1527272149008};\\\", \\\"{x:1481,y:564,t:1527272149024};\\\", \\\"{x:1460,y:573,t:1527272149041};\\\", \\\"{x:1446,y:579,t:1527272149057};\\\", \\\"{x:1430,y:582,t:1527272149074};\\\", \\\"{x:1415,y:585,t:1527272149091};\\\", \\\"{x:1406,y:591,t:1527272149107};\\\", \\\"{x:1397,y:597,t:1527272149123};\\\", \\\"{x:1387,y:614,t:1527272149141};\\\", \\\"{x:1385,y:624,t:1527272149158};\\\", \\\"{x:1385,y:627,t:1527272149175};\\\", \\\"{x:1385,y:628,t:1527272149220};\\\", \\\"{x:1384,y:628,t:1527272149229};\\\", \\\"{x:1383,y:629,t:1527272149244};\\\", \\\"{x:1382,y:629,t:1527272149260};\\\", \\\"{x:1381,y:630,t:1527272149275};\\\", \\\"{x:1377,y:633,t:1527272149291};\\\", \\\"{x:1372,y:634,t:1527272149308};\\\", \\\"{x:1360,y:634,t:1527272149324};\\\", \\\"{x:1346,y:634,t:1527272149340};\\\", \\\"{x:1331,y:634,t:1527272149358};\\\", \\\"{x:1325,y:636,t:1527272149375};\\\", \\\"{x:1322,y:638,t:1527272149391};\\\", \\\"{x:1321,y:638,t:1527272149460};\\\", \\\"{x:1320,y:638,t:1527272149475};\\\", \\\"{x:1316,y:641,t:1527272149491};\\\", \\\"{x:1315,y:641,t:1527272149508};\\\", \\\"{x:1311,y:642,t:1527272149525};\\\", \\\"{x:1314,y:642,t:1527272149580};\\\", \\\"{x:1317,y:642,t:1527272149591};\\\", \\\"{x:1322,y:640,t:1527272149607};\\\", \\\"{x:1327,y:634,t:1527272149625};\\\", \\\"{x:1330,y:631,t:1527272149642};\\\", \\\"{x:1333,y:630,t:1527272149658};\\\", \\\"{x:1335,y:629,t:1527272149675};\\\", \\\"{x:1335,y:628,t:1527272149692};\\\", \\\"{x:1336,y:628,t:1527272149708};\\\", \\\"{x:1338,y:628,t:1527272149725};\\\", \\\"{x:1338,y:626,t:1527272149742};\\\", \\\"{x:1338,y:625,t:1527272149758};\\\", \\\"{x:1335,y:623,t:1527272149774};\\\", \\\"{x:1330,y:622,t:1527272149792};\\\", \\\"{x:1326,y:622,t:1527272149808};\\\", \\\"{x:1324,y:622,t:1527272149825};\\\", \\\"{x:1323,y:622,t:1527272149842};\\\", \\\"{x:1320,y:622,t:1527272149858};\\\", \\\"{x:1318,y:622,t:1527272150173};\\\", \\\"{x:1317,y:622,t:1527272150188};\\\", \\\"{x:1315,y:622,t:1527272150212};\\\", \\\"{x:1315,y:623,t:1527272151164};\\\", \\\"{x:1315,y:624,t:1527272151176};\\\", \\\"{x:1315,y:626,t:1527272151193};\\\", \\\"{x:1315,y:629,t:1527272151208};\\\", \\\"{x:1315,y:633,t:1527272151226};\\\", \\\"{x:1315,y:636,t:1527272151244};\\\", \\\"{x:1316,y:638,t:1527272151259};\\\", \\\"{x:1316,y:639,t:1527272151276};\\\", \\\"{x:1316,y:641,t:1527272151308};\\\", \\\"{x:1316,y:642,t:1527272151324};\\\", \\\"{x:1316,y:644,t:1527272151341};\\\", \\\"{x:1316,y:646,t:1527272151349};\\\", \\\"{x:1316,y:647,t:1527272151359};\\\", \\\"{x:1317,y:651,t:1527272151376};\\\", \\\"{x:1317,y:655,t:1527272151393};\\\", \\\"{x:1317,y:659,t:1527272151411};\\\", \\\"{x:1317,y:665,t:1527272151427};\\\", \\\"{x:1317,y:670,t:1527272151443};\\\", \\\"{x:1317,y:675,t:1527272151461};\\\", \\\"{x:1316,y:686,t:1527272151477};\\\", \\\"{x:1314,y:695,t:1527272151493};\\\", \\\"{x:1314,y:699,t:1527272151510};\\\", \\\"{x:1314,y:703,t:1527272151527};\\\", \\\"{x:1313,y:707,t:1527272151543};\\\", \\\"{x:1312,y:713,t:1527272151561};\\\", \\\"{x:1312,y:718,t:1527272151577};\\\", \\\"{x:1312,y:722,t:1527272151593};\\\", \\\"{x:1312,y:726,t:1527272151611};\\\", \\\"{x:1312,y:731,t:1527272151626};\\\", \\\"{x:1312,y:735,t:1527272151643};\\\", \\\"{x:1312,y:738,t:1527272151660};\\\", \\\"{x:1312,y:739,t:1527272151676};\\\", \\\"{x:1312,y:740,t:1527272151694};\\\", \\\"{x:1311,y:742,t:1527272151710};\\\", \\\"{x:1311,y:748,t:1527272151727};\\\", \\\"{x:1311,y:754,t:1527272151744};\\\", \\\"{x:1311,y:762,t:1527272151761};\\\", \\\"{x:1310,y:767,t:1527272151777};\\\", \\\"{x:1309,y:772,t:1527272151793};\\\", \\\"{x:1308,y:777,t:1527272151810};\\\", \\\"{x:1308,y:781,t:1527272151828};\\\", \\\"{x:1307,y:787,t:1527272151844};\\\", \\\"{x:1305,y:796,t:1527272151861};\\\", \\\"{x:1305,y:804,t:1527272151877};\\\", \\\"{x:1305,y:809,t:1527272151893};\\\", \\\"{x:1305,y:814,t:1527272151911};\\\", \\\"{x:1305,y:820,t:1527272151928};\\\", \\\"{x:1306,y:828,t:1527272151944};\\\", \\\"{x:1306,y:835,t:1527272151960};\\\", \\\"{x:1306,y:848,t:1527272151978};\\\", \\\"{x:1306,y:863,t:1527272151993};\\\", \\\"{x:1306,y:878,t:1527272152010};\\\", \\\"{x:1306,y:891,t:1527272152027};\\\", \\\"{x:1306,y:899,t:1527272152044};\\\", \\\"{x:1306,y:905,t:1527272152061};\\\", \\\"{x:1307,y:909,t:1527272152078};\\\", \\\"{x:1307,y:912,t:1527272152094};\\\", \\\"{x:1307,y:913,t:1527272152117};\\\", \\\"{x:1307,y:914,t:1527272152141};\\\", \\\"{x:1307,y:915,t:1527272152149};\\\", \\\"{x:1308,y:917,t:1527272152160};\\\", \\\"{x:1310,y:922,t:1527272152178};\\\", \\\"{x:1311,y:926,t:1527272152194};\\\", \\\"{x:1312,y:928,t:1527272152209};\\\", \\\"{x:1314,y:931,t:1527272152227};\\\", \\\"{x:1314,y:934,t:1527272152244};\\\", \\\"{x:1318,y:942,t:1527272152260};\\\", \\\"{x:1320,y:946,t:1527272152277};\\\", \\\"{x:1320,y:947,t:1527272152309};\\\", \\\"{x:1321,y:948,t:1527272152340};\\\", \\\"{x:1321,y:949,t:1527272152397};\\\", \\\"{x:1321,y:951,t:1527272152410};\\\", \\\"{x:1321,y:952,t:1527272152427};\\\", \\\"{x:1319,y:956,t:1527272152444};\\\", \\\"{x:1317,y:958,t:1527272152460};\\\", \\\"{x:1317,y:959,t:1527272152477};\\\", \\\"{x:1314,y:962,t:1527272152494};\\\", \\\"{x:1311,y:965,t:1527272152509};\\\", \\\"{x:1309,y:967,t:1527272152527};\\\", \\\"{x:1308,y:970,t:1527272152544};\\\", \\\"{x:1307,y:971,t:1527272152560};\\\", \\\"{x:1305,y:973,t:1527272152577};\\\", \\\"{x:1302,y:974,t:1527272152594};\\\", \\\"{x:1302,y:975,t:1527272152610};\\\", \\\"{x:1304,y:974,t:1527272152789};\\\", \\\"{x:1306,y:974,t:1527272152820};\\\", \\\"{x:1308,y:973,t:1527272152860};\\\", \\\"{x:1313,y:971,t:1527272152877};\\\", \\\"{x:1316,y:970,t:1527272152894};\\\", \\\"{x:1318,y:969,t:1527272152911};\\\", \\\"{x:1319,y:968,t:1527272152927};\\\", \\\"{x:1317,y:968,t:1527272153004};\\\", \\\"{x:1316,y:968,t:1527272153013};\\\", \\\"{x:1314,y:969,t:1527272153027};\\\", \\\"{x:1317,y:971,t:1527272153861};\\\", \\\"{x:1322,y:973,t:1527272153868};\\\", \\\"{x:1326,y:974,t:1527272153878};\\\", \\\"{x:1331,y:976,t:1527272153896};\\\", \\\"{x:1332,y:976,t:1527272153911};\\\", \\\"{x:1333,y:976,t:1527272154068};\\\", \\\"{x:1335,y:977,t:1527272154077};\\\", \\\"{x:1341,y:977,t:1527272154095};\\\", \\\"{x:1346,y:977,t:1527272154112};\\\", \\\"{x:1353,y:977,t:1527272154128};\\\", \\\"{x:1354,y:977,t:1527272154146};\\\", \\\"{x:1355,y:977,t:1527272154284};\\\", \\\"{x:1355,y:976,t:1527272154308};\\\", \\\"{x:1355,y:975,t:1527272154316};\\\", \\\"{x:1355,y:974,t:1527272154328};\\\", \\\"{x:1355,y:972,t:1527272154349};\\\", \\\"{x:1354,y:972,t:1527272154362};\\\", \\\"{x:1353,y:971,t:1527272154380};\\\", \\\"{x:1352,y:970,t:1527272154395};\\\", \\\"{x:1350,y:970,t:1527272154413};\\\", \\\"{x:1346,y:969,t:1527272154429};\\\", \\\"{x:1343,y:968,t:1527272154446};\\\", \\\"{x:1340,y:966,t:1527272154462};\\\", \\\"{x:1341,y:965,t:1527272154621};\\\", \\\"{x:1342,y:965,t:1527272154628};\\\", \\\"{x:1343,y:965,t:1527272154645};\\\", \\\"{x:1344,y:965,t:1527272154662};\\\", \\\"{x:1344,y:964,t:1527272154679};\\\", \\\"{x:1345,y:964,t:1527272154725};\\\", \\\"{x:1346,y:964,t:1527272154740};\\\", \\\"{x:1347,y:964,t:1527272154764};\\\", \\\"{x:1348,y:964,t:1527272154781};\\\", \\\"{x:1349,y:964,t:1527272154796};\\\", \\\"{x:1355,y:966,t:1527272154813};\\\", \\\"{x:1359,y:967,t:1527272154830};\\\", \\\"{x:1361,y:968,t:1527272154846};\\\", \\\"{x:1364,y:969,t:1527272154862};\\\", \\\"{x:1367,y:969,t:1527272154880};\\\", \\\"{x:1372,y:971,t:1527272154896};\\\", \\\"{x:1374,y:971,t:1527272154912};\\\", \\\"{x:1375,y:971,t:1527272154930};\\\", \\\"{x:1376,y:971,t:1527272155188};\\\", \\\"{x:1377,y:971,t:1527272155228};\\\", \\\"{x:1378,y:971,t:1527272155245};\\\", \\\"{x:1380,y:971,t:1527272155252};\\\", \\\"{x:1381,y:971,t:1527272155263};\\\", \\\"{x:1384,y:971,t:1527272155280};\\\", \\\"{x:1386,y:971,t:1527272155296};\\\", \\\"{x:1386,y:970,t:1527272155405};\\\", \\\"{x:1386,y:969,t:1527272155412};\\\", \\\"{x:1386,y:968,t:1527272155429};\\\", \\\"{x:1386,y:967,t:1527272155532};\\\", \\\"{x:1385,y:966,t:1527272155546};\\\", \\\"{x:1381,y:964,t:1527272155564};\\\", \\\"{x:1376,y:963,t:1527272155579};\\\", \\\"{x:1377,y:963,t:1527272155668};\\\", \\\"{x:1380,y:963,t:1527272155679};\\\", \\\"{x:1385,y:964,t:1527272155696};\\\", \\\"{x:1394,y:965,t:1527272155713};\\\", \\\"{x:1402,y:965,t:1527272155729};\\\", \\\"{x:1405,y:965,t:1527272155747};\\\", \\\"{x:1407,y:965,t:1527272155764};\\\", \\\"{x:1408,y:965,t:1527272155973};\\\", \\\"{x:1410,y:965,t:1527272155981};\\\", \\\"{x:1411,y:966,t:1527272156061};\\\", \\\"{x:1412,y:966,t:1527272156069};\\\", \\\"{x:1414,y:966,t:1527272156081};\\\", \\\"{x:1415,y:966,t:1527272156097};\\\", \\\"{x:1415,y:967,t:1527272156613};\\\", \\\"{x:1414,y:968,t:1527272156620};\\\", \\\"{x:1411,y:969,t:1527272156636};\\\", \\\"{x:1410,y:970,t:1527272156648};\\\", \\\"{x:1404,y:970,t:1527272156664};\\\", \\\"{x:1400,y:972,t:1527272156680};\\\", \\\"{x:1399,y:972,t:1527272156697};\\\", \\\"{x:1396,y:972,t:1527272156716};\\\", \\\"{x:1395,y:972,t:1527272156733};\\\", \\\"{x:1393,y:972,t:1527272156749};\\\", \\\"{x:1381,y:972,t:1527272156765};\\\", \\\"{x:1374,y:972,t:1527272156781};\\\", \\\"{x:1368,y:972,t:1527272156798};\\\", \\\"{x:1366,y:972,t:1527272156861};\\\", \\\"{x:1365,y:972,t:1527272156885};\\\", \\\"{x:1364,y:972,t:1527272156901};\\\", \\\"{x:1363,y:972,t:1527272156914};\\\", \\\"{x:1361,y:973,t:1527272156931};\\\", \\\"{x:1359,y:974,t:1527272156948};\\\", \\\"{x:1353,y:975,t:1527272156965};\\\", \\\"{x:1351,y:975,t:1527272156980};\\\", \\\"{x:1348,y:975,t:1527272156997};\\\", \\\"{x:1345,y:975,t:1527272157015};\\\", \\\"{x:1340,y:975,t:1527272157031};\\\", \\\"{x:1333,y:975,t:1527272157048};\\\", \\\"{x:1325,y:975,t:1527272157066};\\\", \\\"{x:1315,y:975,t:1527272157080};\\\", \\\"{x:1312,y:975,t:1527272157098};\\\", \\\"{x:1309,y:975,t:1527272157115};\\\", \\\"{x:1308,y:975,t:1527272157166};\\\", \\\"{x:1305,y:975,t:1527272157181};\\\", \\\"{x:1302,y:975,t:1527272157197};\\\", \\\"{x:1301,y:975,t:1527272157221};\\\", \\\"{x:1302,y:974,t:1527272157342};\\\", \\\"{x:1302,y:973,t:1527272157494};\\\", \\\"{x:1302,y:972,t:1527272157509};\\\", \\\"{x:1302,y:971,t:1527272157516};\\\", \\\"{x:1302,y:970,t:1527272157676};\\\", \\\"{x:1302,y:969,t:1527272157869};\\\", \\\"{x:1302,y:968,t:1527272157901};\\\", \\\"{x:1302,y:967,t:1527272158261};\\\", \\\"{x:1302,y:966,t:1527272158284};\\\", \\\"{x:1301,y:965,t:1527272158316};\\\", \\\"{x:1300,y:965,t:1527272158389};\\\", \\\"{x:1300,y:964,t:1527272158621};\\\", \\\"{x:1299,y:963,t:1527272158633};\\\", \\\"{x:1298,y:963,t:1527272158648};\\\", \\\"{x:1297,y:963,t:1527272158666};\\\", \\\"{x:1296,y:963,t:1527272158733};\\\", \\\"{x:1294,y:963,t:1527272158749};\\\", \\\"{x:1291,y:962,t:1527272158766};\\\", \\\"{x:1290,y:962,t:1527272158783};\\\", \\\"{x:1292,y:962,t:1527272158933};\\\", \\\"{x:1297,y:960,t:1527272158949};\\\", \\\"{x:1299,y:959,t:1527272158966};\\\", \\\"{x:1301,y:959,t:1527272158982};\\\", \\\"{x:1303,y:958,t:1527272159037};\\\", \\\"{x:1307,y:957,t:1527272159126};\\\", \\\"{x:1310,y:955,t:1527272159133};\\\", \\\"{x:1329,y:934,t:1527272159150};\\\", \\\"{x:1349,y:883,t:1527272159166};\\\", \\\"{x:1374,y:809,t:1527272159183};\\\", \\\"{x:1392,y:714,t:1527272159200};\\\", \\\"{x:1414,y:605,t:1527272159216};\\\", \\\"{x:1446,y:481,t:1527272159233};\\\", \\\"{x:1483,y:362,t:1527272159249};\\\", \\\"{x:1508,y:278,t:1527272159266};\\\", \\\"{x:1519,y:253,t:1527272159282};\\\", \\\"{x:1522,y:247,t:1527272159299};\\\", \\\"{x:1522,y:245,t:1527272159316};\\\", \\\"{x:1522,y:244,t:1527272159356};\\\", \\\"{x:1520,y:244,t:1527272159366};\\\", \\\"{x:1515,y:244,t:1527272159382};\\\", \\\"{x:1502,y:254,t:1527272159400};\\\", \\\"{x:1470,y:289,t:1527272159416};\\\", \\\"{x:1440,y:341,t:1527272159432};\\\", \\\"{x:1415,y:406,t:1527272159449};\\\", \\\"{x:1401,y:459,t:1527272159466};\\\", \\\"{x:1395,y:487,t:1527272159482};\\\", \\\"{x:1394,y:496,t:1527272159499};\\\", \\\"{x:1394,y:497,t:1527272159517};\\\", \\\"{x:1394,y:500,t:1527272159604};\\\", \\\"{x:1390,y:508,t:1527272159617};\\\", \\\"{x:1373,y:532,t:1527272159632};\\\", \\\"{x:1361,y:551,t:1527272159650};\\\", \\\"{x:1357,y:558,t:1527272159666};\\\", \\\"{x:1356,y:559,t:1527272159683};\\\", \\\"{x:1356,y:562,t:1527272159708};\\\", \\\"{x:1356,y:563,t:1527272159717};\\\", \\\"{x:1348,y:575,t:1527272159733};\\\", \\\"{x:1337,y:593,t:1527272159749};\\\", \\\"{x:1324,y:610,t:1527272159766};\\\", \\\"{x:1309,y:626,t:1527272159784};\\\", \\\"{x:1308,y:628,t:1527272159800};\\\", \\\"{x:1307,y:629,t:1527272159901};\\\", \\\"{x:1308,y:629,t:1527272160092};\\\", \\\"{x:1309,y:629,t:1527272160116};\\\", \\\"{x:1310,y:629,t:1527272160220};\\\", \\\"{x:1311,y:629,t:1527272160234};\\\", \\\"{x:1312,y:629,t:1527272160251};\\\", \\\"{x:1313,y:629,t:1527272160564};\\\", \\\"{x:1313,y:630,t:1527272160629};\\\", \\\"{x:1313,y:631,t:1527272160636};\\\", \\\"{x:1313,y:635,t:1527272160650};\\\", \\\"{x:1313,y:639,t:1527272160667};\\\", \\\"{x:1314,y:641,t:1527272160683};\\\", \\\"{x:1314,y:644,t:1527272160700};\\\", \\\"{x:1314,y:646,t:1527272160717};\\\", \\\"{x:1314,y:648,t:1527272160734};\\\", \\\"{x:1314,y:650,t:1527272160750};\\\", \\\"{x:1314,y:651,t:1527272160773};\\\", \\\"{x:1314,y:653,t:1527272160784};\\\", \\\"{x:1314,y:656,t:1527272160800};\\\", \\\"{x:1314,y:664,t:1527272160818};\\\", \\\"{x:1314,y:673,t:1527272160834};\\\", \\\"{x:1312,y:681,t:1527272160851};\\\", \\\"{x:1311,y:685,t:1527272160868};\\\", \\\"{x:1311,y:689,t:1527272160884};\\\", \\\"{x:1311,y:692,t:1527272160901};\\\", \\\"{x:1311,y:693,t:1527272160917};\\\", \\\"{x:1311,y:695,t:1527272160934};\\\", \\\"{x:1311,y:697,t:1527272160951};\\\", \\\"{x:1311,y:701,t:1527272160968};\\\", \\\"{x:1311,y:702,t:1527272160984};\\\", \\\"{x:1312,y:703,t:1527272161001};\\\", \\\"{x:1312,y:706,t:1527272161018};\\\", \\\"{x:1312,y:709,t:1527272161034};\\\", \\\"{x:1312,y:711,t:1527272161051};\\\", \\\"{x:1315,y:717,t:1527272161068};\\\", \\\"{x:1315,y:721,t:1527272161084};\\\", \\\"{x:1316,y:728,t:1527272161101};\\\", \\\"{x:1316,y:730,t:1527272161118};\\\", \\\"{x:1317,y:731,t:1527272161134};\\\", \\\"{x:1317,y:733,t:1527272161151};\\\", \\\"{x:1317,y:734,t:1527272161168};\\\", \\\"{x:1317,y:737,t:1527272161185};\\\", \\\"{x:1315,y:745,t:1527272161201};\\\", \\\"{x:1313,y:754,t:1527272161217};\\\", \\\"{x:1312,y:764,t:1527272161234};\\\", \\\"{x:1311,y:771,t:1527272161250};\\\", \\\"{x:1311,y:772,t:1527272161267};\\\", \\\"{x:1311,y:774,t:1527272161284};\\\", \\\"{x:1310,y:776,t:1527272161340};\\\", \\\"{x:1310,y:778,t:1527272161351};\\\", \\\"{x:1308,y:783,t:1527272161367};\\\", \\\"{x:1307,y:788,t:1527272161385};\\\", \\\"{x:1306,y:793,t:1527272161401};\\\", \\\"{x:1306,y:798,t:1527272161418};\\\", \\\"{x:1306,y:803,t:1527272161435};\\\", \\\"{x:1306,y:808,t:1527272161451};\\\", \\\"{x:1306,y:810,t:1527272161467};\\\", \\\"{x:1306,y:811,t:1527272161484};\\\", \\\"{x:1306,y:812,t:1527272161501};\\\", \\\"{x:1306,y:816,t:1527272161518};\\\", \\\"{x:1306,y:823,t:1527272161535};\\\", \\\"{x:1306,y:833,t:1527272161551};\\\", \\\"{x:1306,y:842,t:1527272161568};\\\", \\\"{x:1306,y:848,t:1527272161584};\\\", \\\"{x:1307,y:853,t:1527272161602};\\\", \\\"{x:1307,y:857,t:1527272161617};\\\", \\\"{x:1307,y:859,t:1527272161634};\\\", \\\"{x:1307,y:862,t:1527272161652};\\\", \\\"{x:1307,y:865,t:1527272161667};\\\", \\\"{x:1307,y:869,t:1527272161685};\\\", \\\"{x:1307,y:874,t:1527272161702};\\\", \\\"{x:1307,y:877,t:1527272161717};\\\", \\\"{x:1307,y:878,t:1527272161735};\\\", \\\"{x:1307,y:879,t:1527272161751};\\\", \\\"{x:1307,y:880,t:1527272161772};\\\", \\\"{x:1307,y:882,t:1527272161797};\\\", \\\"{x:1307,y:883,t:1527272161812};\\\", \\\"{x:1307,y:885,t:1527272161837};\\\", \\\"{x:1307,y:886,t:1527272161851};\\\", \\\"{x:1307,y:888,t:1527272161909};\\\", \\\"{x:1308,y:890,t:1527272161924};\\\", \\\"{x:1308,y:891,t:1527272161948};\\\", \\\"{x:1310,y:892,t:1527272161956};\\\", \\\"{x:1310,y:893,t:1527272161979};\\\", \\\"{x:1310,y:894,t:1527272161988};\\\", \\\"{x:1310,y:895,t:1527272162001};\\\", \\\"{x:1310,y:896,t:1527272162018};\\\", \\\"{x:1310,y:900,t:1527272162034};\\\", \\\"{x:1311,y:903,t:1527272162052};\\\", \\\"{x:1312,y:907,t:1527272162069};\\\", \\\"{x:1312,y:909,t:1527272162084};\\\", \\\"{x:1312,y:913,t:1527272162101};\\\", \\\"{x:1312,y:916,t:1527272162119};\\\", \\\"{x:1312,y:920,t:1527272162134};\\\", \\\"{x:1312,y:923,t:1527272162152};\\\", \\\"{x:1312,y:925,t:1527272162168};\\\", \\\"{x:1312,y:930,t:1527272162184};\\\", \\\"{x:1310,y:933,t:1527272162202};\\\", \\\"{x:1309,y:938,t:1527272162219};\\\", \\\"{x:1309,y:939,t:1527272162235};\\\", \\\"{x:1309,y:941,t:1527272162252};\\\", \\\"{x:1309,y:942,t:1527272162268};\\\", \\\"{x:1309,y:943,t:1527272162285};\\\", \\\"{x:1309,y:944,t:1527272162302};\\\", \\\"{x:1309,y:947,t:1527272162319};\\\", \\\"{x:1309,y:950,t:1527272162335};\\\", \\\"{x:1308,y:952,t:1527272162352};\\\", \\\"{x:1308,y:953,t:1527272162368};\\\", \\\"{x:1308,y:954,t:1527272162385};\\\", \\\"{x:1308,y:955,t:1527272162401};\\\", \\\"{x:1308,y:956,t:1527272162418};\\\", \\\"{x:1308,y:959,t:1527272162435};\\\", \\\"{x:1308,y:960,t:1527272162451};\\\", \\\"{x:1308,y:963,t:1527272162468};\\\", \\\"{x:1308,y:964,t:1527272162486};\\\", \\\"{x:1308,y:965,t:1527272162501};\\\", \\\"{x:1308,y:967,t:1527272162519};\\\", \\\"{x:1308,y:968,t:1527272162535};\\\", \\\"{x:1308,y:969,t:1527272162572};\\\", \\\"{x:1309,y:969,t:1527272162981};\\\", \\\"{x:1310,y:968,t:1527272162988};\\\", \\\"{x:1311,y:967,t:1527272163002};\\\", \\\"{x:1311,y:966,t:1527272163116};\\\", \\\"{x:1310,y:965,t:1527272163132};\\\", \\\"{x:1309,y:965,t:1527272163172};\\\", \\\"{x:1308,y:965,t:1527272163186};\\\", \\\"{x:1307,y:965,t:1527272163202};\\\", \\\"{x:1306,y:964,t:1527272163219};\\\", \\\"{x:1306,y:965,t:1527272164813};\\\", \\\"{x:1308,y:966,t:1527272164893};\\\", \\\"{x:1310,y:967,t:1527272164904};\\\", \\\"{x:1315,y:969,t:1527272164921};\\\", \\\"{x:1317,y:969,t:1527272164937};\\\", \\\"{x:1324,y:969,t:1527272164954};\\\", \\\"{x:1333,y:971,t:1527272164971};\\\", \\\"{x:1345,y:974,t:1527272164987};\\\", \\\"{x:1360,y:978,t:1527272165004};\\\", \\\"{x:1371,y:980,t:1527272165021};\\\", \\\"{x:1375,y:980,t:1527272165037};\\\", \\\"{x:1376,y:980,t:1527272165054};\\\", \\\"{x:1378,y:980,t:1527272165333};\\\", \\\"{x:1379,y:980,t:1527272165340};\\\", \\\"{x:1379,y:979,t:1527272165532};\\\", \\\"{x:1379,y:978,t:1527272165541};\\\", \\\"{x:1379,y:977,t:1527272165554};\\\", \\\"{x:1380,y:976,t:1527272165571};\\\", \\\"{x:1380,y:975,t:1527272165588};\\\", \\\"{x:1380,y:974,t:1527272165620};\\\", \\\"{x:1380,y:973,t:1527272165638};\\\", \\\"{x:1380,y:972,t:1527272165655};\\\", \\\"{x:1380,y:971,t:1527272165670};\\\", \\\"{x:1380,y:970,t:1527272166516};\\\", \\\"{x:1383,y:970,t:1527272166524};\\\", \\\"{x:1388,y:971,t:1527272166538};\\\", \\\"{x:1400,y:977,t:1527272166555};\\\", \\\"{x:1415,y:982,t:1527272166571};\\\", \\\"{x:1432,y:986,t:1527272166588};\\\", \\\"{x:1438,y:986,t:1527272166605};\\\", \\\"{x:1440,y:986,t:1527272166622};\\\", \\\"{x:1441,y:986,t:1527272166708};\\\", \\\"{x:1443,y:985,t:1527272166788};\\\", \\\"{x:1443,y:983,t:1527272166804};\\\", \\\"{x:1443,y:981,t:1527272166821};\\\", \\\"{x:1443,y:979,t:1527272166839};\\\", \\\"{x:1445,y:972,t:1527272166854};\\\", \\\"{x:1446,y:967,t:1527272166872};\\\", \\\"{x:1447,y:965,t:1527272166889};\\\", \\\"{x:1449,y:962,t:1527272166906};\\\", \\\"{x:1449,y:960,t:1527272166921};\\\", \\\"{x:1450,y:960,t:1527272166938};\\\", \\\"{x:1450,y:961,t:1527272167260};\\\", \\\"{x:1451,y:961,t:1527272174957};\\\", \\\"{x:1452,y:961,t:1527272174965};\\\", \\\"{x:1453,y:961,t:1527272174996};\\\", \\\"{x:1453,y:962,t:1527272175011};\\\", \\\"{x:1455,y:963,t:1527272175028};\\\", \\\"{x:1470,y:963,t:1527272175045};\\\", \\\"{x:1486,y:966,t:1527272175062};\\\", \\\"{x:1500,y:970,t:1527272175078};\\\", \\\"{x:1506,y:971,t:1527272175096};\\\", \\\"{x:1507,y:972,t:1527272175112};\\\", \\\"{x:1508,y:972,t:1527272175949};\\\", \\\"{x:1509,y:972,t:1527272175963};\\\", \\\"{x:1511,y:972,t:1527272175979};\\\", \\\"{x:1511,y:971,t:1527272176236};\\\", \\\"{x:1512,y:970,t:1527272176356};\\\", \\\"{x:1512,y:969,t:1527272176364};\\\", \\\"{x:1512,y:967,t:1527272176380};\\\", \\\"{x:1512,y:966,t:1527272176404};\\\", \\\"{x:1512,y:965,t:1527272176444};\\\", \\\"{x:1512,y:964,t:1527272176460};\\\", \\\"{x:1512,y:963,t:1527272176468};\\\", \\\"{x:1512,y:961,t:1527272176516};\\\", \\\"{x:1513,y:961,t:1527272176532};\\\", \\\"{x:1514,y:960,t:1527272176660};\\\", \\\"{x:1514,y:958,t:1527272176708};\\\", \\\"{x:1514,y:957,t:1527272177324};\\\", \\\"{x:1518,y:959,t:1527272177331};\\\", \\\"{x:1526,y:963,t:1527272177348};\\\", \\\"{x:1540,y:969,t:1527272177363};\\\", \\\"{x:1568,y:981,t:1527272177379};\\\", \\\"{x:1575,y:986,t:1527272177397};\\\", \\\"{x:1576,y:986,t:1527272177500};\\\", \\\"{x:1577,y:987,t:1527272177524};\\\", \\\"{x:1578,y:987,t:1527272177540};\\\", \\\"{x:1579,y:987,t:1527272177547};\\\", \\\"{x:1583,y:987,t:1527272177564};\\\", \\\"{x:1585,y:987,t:1527272177581};\\\", \\\"{x:1587,y:987,t:1527272177597};\\\", \\\"{x:1588,y:987,t:1527272177614};\\\", \\\"{x:1588,y:986,t:1527272177643};\\\", \\\"{x:1588,y:984,t:1527272177652};\\\", \\\"{x:1588,y:982,t:1527272177668};\\\", \\\"{x:1588,y:981,t:1527272177692};\\\", \\\"{x:1588,y:980,t:1527272177708};\\\", \\\"{x:1586,y:979,t:1527272177724};\\\", \\\"{x:1585,y:978,t:1527272177732};\\\", \\\"{x:1585,y:977,t:1527272177748};\\\", \\\"{x:1583,y:977,t:1527272177764};\\\", \\\"{x:1582,y:976,t:1527272177797};\\\", \\\"{x:1581,y:976,t:1527272177812};\\\", \\\"{x:1581,y:975,t:1527272178012};\\\", \\\"{x:1581,y:974,t:1527272178100};\\\", \\\"{x:1581,y:973,t:1527272178140};\\\", \\\"{x:1581,y:972,t:1527272178196};\\\", \\\"{x:1581,y:971,t:1527272178212};\\\", \\\"{x:1581,y:970,t:1527272178236};\\\", \\\"{x:1581,y:969,t:1527272178365};\\\", \\\"{x:1582,y:969,t:1527272179653};\\\", \\\"{x:1583,y:971,t:1527272179669};\\\", \\\"{x:1585,y:974,t:1527272179683};\\\", \\\"{x:1587,y:976,t:1527272179698};\\\", \\\"{x:1589,y:978,t:1527272179715};\\\", \\\"{x:1590,y:980,t:1527272179732};\\\", \\\"{x:1591,y:980,t:1527272179750};\\\", \\\"{x:1592,y:982,t:1527272179765};\\\", \\\"{x:1593,y:983,t:1527272179805};\\\", \\\"{x:1594,y:983,t:1527272179829};\\\", \\\"{x:1595,y:983,t:1527272179845};\\\", \\\"{x:1596,y:983,t:1527272179861};\\\", \\\"{x:1597,y:983,t:1527272179877};\\\", \\\"{x:1599,y:983,t:1527272179884};\\\", \\\"{x:1600,y:983,t:1527272179900};\\\", \\\"{x:1602,y:983,t:1527272179915};\\\", \\\"{x:1604,y:984,t:1527272179932};\\\", \\\"{x:1605,y:984,t:1527272179949};\\\", \\\"{x:1607,y:985,t:1527272179965};\\\", \\\"{x:1609,y:985,t:1527272179982};\\\", \\\"{x:1614,y:987,t:1527272179999};\\\", \\\"{x:1618,y:987,t:1527272180015};\\\", \\\"{x:1623,y:988,t:1527272180033};\\\", \\\"{x:1625,y:988,t:1527272180049};\\\", \\\"{x:1627,y:989,t:1527272180066};\\\", \\\"{x:1628,y:989,t:1527272180084};\\\", \\\"{x:1629,y:989,t:1527272180099};\\\", \\\"{x:1630,y:989,t:1527272180115};\\\", \\\"{x:1632,y:989,t:1527272180132};\\\", \\\"{x:1633,y:989,t:1527272180156};\\\", \\\"{x:1634,y:989,t:1527272180172};\\\", \\\"{x:1635,y:989,t:1527272180188};\\\", \\\"{x:1636,y:988,t:1527272180199};\\\", \\\"{x:1637,y:987,t:1527272180217};\\\", \\\"{x:1637,y:986,t:1527272180233};\\\", \\\"{x:1638,y:984,t:1527272180249};\\\", \\\"{x:1638,y:983,t:1527272180267};\\\", \\\"{x:1638,y:982,t:1527272180284};\\\", \\\"{x:1638,y:981,t:1527272180308};\\\", \\\"{x:1639,y:980,t:1527272180340};\\\", \\\"{x:1640,y:979,t:1527272180356};\\\", \\\"{x:1640,y:977,t:1527272180366};\\\", \\\"{x:1642,y:976,t:1527272180382};\\\", \\\"{x:1642,y:975,t:1527272180399};\\\", \\\"{x:1643,y:974,t:1527272180416};\\\", \\\"{x:1645,y:971,t:1527272180432};\\\", \\\"{x:1645,y:970,t:1527272180450};\\\", \\\"{x:1646,y:969,t:1527272180467};\\\", \\\"{x:1647,y:967,t:1527272180482};\\\", \\\"{x:1648,y:967,t:1527272180500};\\\", \\\"{x:1648,y:966,t:1527272180533};\\\", \\\"{x:1649,y:965,t:1527272180589};\\\", \\\"{x:1650,y:964,t:1527272180600};\\\", \\\"{x:1650,y:963,t:1527272180617};\\\", \\\"{x:1649,y:963,t:1527272188429};\\\", \\\"{x:1646,y:963,t:1527272188437};\\\", \\\"{x:1642,y:964,t:1527272188447};\\\", \\\"{x:1640,y:964,t:1527272188464};\\\", \\\"{x:1639,y:964,t:1527272188482};\\\", \\\"{x:1636,y:965,t:1527272188498};\\\", \\\"{x:1633,y:965,t:1527272188515};\\\", \\\"{x:1630,y:965,t:1527272188531};\\\", \\\"{x:1629,y:966,t:1527272188547};\\\", \\\"{x:1626,y:966,t:1527272188565};\\\", \\\"{x:1624,y:966,t:1527272188582};\\\", \\\"{x:1623,y:966,t:1527272188599};\\\", \\\"{x:1621,y:966,t:1527272188615};\\\", \\\"{x:1619,y:968,t:1527272188631};\\\", \\\"{x:1614,y:969,t:1527272188649};\\\", \\\"{x:1604,y:969,t:1527272188665};\\\", \\\"{x:1594,y:969,t:1527272188682};\\\", \\\"{x:1589,y:969,t:1527272188699};\\\", \\\"{x:1588,y:969,t:1527272188715};\\\", \\\"{x:1585,y:969,t:1527272188732};\\\", \\\"{x:1576,y:969,t:1527272188749};\\\", \\\"{x:1563,y:969,t:1527272188765};\\\", \\\"{x:1557,y:969,t:1527272188782};\\\", \\\"{x:1551,y:969,t:1527272188799};\\\", \\\"{x:1547,y:969,t:1527272188815};\\\", \\\"{x:1543,y:969,t:1527272188832};\\\", \\\"{x:1537,y:969,t:1527272188848};\\\", \\\"{x:1533,y:969,t:1527272188865};\\\", \\\"{x:1535,y:969,t:1527272189038};\\\", \\\"{x:1536,y:969,t:1527272189049};\\\", \\\"{x:1540,y:969,t:1527272189066};\\\", \\\"{x:1542,y:969,t:1527272189109};\\\", \\\"{x:1543,y:969,t:1527272189125};\\\", \\\"{x:1545,y:969,t:1527272189453};\\\", \\\"{x:1547,y:969,t:1527272189465};\\\", \\\"{x:1550,y:969,t:1527272189483};\\\", \\\"{x:1552,y:969,t:1527272189499};\\\", \\\"{x:1554,y:969,t:1527272189516};\\\", \\\"{x:1560,y:969,t:1527272189533};\\\", \\\"{x:1566,y:969,t:1527272189549};\\\", \\\"{x:1575,y:970,t:1527272189567};\\\", \\\"{x:1587,y:974,t:1527272189583};\\\", \\\"{x:1601,y:978,t:1527272189599};\\\", \\\"{x:1610,y:982,t:1527272189616};\\\", \\\"{x:1611,y:982,t:1527272189633};\\\", \\\"{x:1612,y:982,t:1527272189653};\\\", \\\"{x:1613,y:982,t:1527272189733};\\\", \\\"{x:1616,y:982,t:1527272189749};\\\", \\\"{x:1617,y:982,t:1527272189766};\\\", \\\"{x:1618,y:982,t:1527272189861};\\\", \\\"{x:1618,y:981,t:1527272189893};\\\", \\\"{x:1618,y:980,t:1527272189909};\\\", \\\"{x:1618,y:979,t:1527272189917};\\\", \\\"{x:1618,y:976,t:1527272189933};\\\", \\\"{x:1618,y:975,t:1527272189949};\\\", \\\"{x:1618,y:973,t:1527272189966};\\\", \\\"{x:1617,y:972,t:1527272189982};\\\", \\\"{x:1617,y:971,t:1527272190886};\\\", \\\"{x:1617,y:970,t:1527272193997};\\\", \\\"{x:1616,y:970,t:1527272194004};\\\", \\\"{x:1614,y:970,t:1527272194019};\\\", \\\"{x:1611,y:970,t:1527272194036};\\\", \\\"{x:1603,y:970,t:1527272194052};\\\", \\\"{x:1592,y:969,t:1527272194069};\\\", \\\"{x:1586,y:969,t:1527272194086};\\\", \\\"{x:1585,y:969,t:1527272194103};\\\", \\\"{x:1583,y:969,t:1527272194119};\\\", \\\"{x:1582,y:969,t:1527272194277};\\\", \\\"{x:1580,y:969,t:1527272194286};\\\", \\\"{x:1579,y:968,t:1527272194303};\\\", \\\"{x:1576,y:968,t:1527272194319};\\\", \\\"{x:1574,y:967,t:1527272194336};\\\", \\\"{x:1572,y:967,t:1527272194352};\\\", \\\"{x:1566,y:966,t:1527272194370};\\\", \\\"{x:1562,y:965,t:1527272194386};\\\", \\\"{x:1559,y:965,t:1527272194403};\\\", \\\"{x:1558,y:965,t:1527272194533};\\\", \\\"{x:1556,y:965,t:1527272194557};\\\", \\\"{x:1555,y:965,t:1527272194645};\\\", \\\"{x:1553,y:965,t:1527272194661};\\\", \\\"{x:1551,y:965,t:1527272194676};\\\", \\\"{x:1550,y:965,t:1527272194693};\\\", \\\"{x:1549,y:965,t:1527272194703};\\\", \\\"{x:1548,y:965,t:1527272194757};\\\", \\\"{x:1547,y:965,t:1527272194797};\\\", \\\"{x:1545,y:965,t:1527272205847};\\\", \\\"{x:1532,y:965,t:1527272205862};\\\", \\\"{x:1511,y:965,t:1527272205880};\\\", \\\"{x:1498,y:965,t:1527272205896};\\\", \\\"{x:1494,y:965,t:1527272205913};\\\", \\\"{x:1491,y:965,t:1527272205929};\\\", \\\"{x:1489,y:966,t:1527272205946};\\\", \\\"{x:1487,y:966,t:1527272205998};\\\", \\\"{x:1485,y:967,t:1527272206013};\\\", \\\"{x:1483,y:967,t:1527272206029};\\\", \\\"{x:1471,y:969,t:1527272206046};\\\", \\\"{x:1463,y:971,t:1527272206063};\\\", \\\"{x:1454,y:971,t:1527272206080};\\\", \\\"{x:1443,y:971,t:1527272206096};\\\", \\\"{x:1437,y:971,t:1527272206112};\\\", \\\"{x:1436,y:971,t:1527272206129};\\\", \\\"{x:1434,y:972,t:1527272206205};\\\", \\\"{x:1431,y:973,t:1527272206213};\\\", \\\"{x:1427,y:974,t:1527272206229};\\\", \\\"{x:1422,y:975,t:1527272206245};\\\", \\\"{x:1418,y:976,t:1527272206262};\\\", \\\"{x:1414,y:977,t:1527272206279};\\\", \\\"{x:1410,y:977,t:1527272206296};\\\", \\\"{x:1404,y:979,t:1527272206312};\\\", \\\"{x:1397,y:981,t:1527272206330};\\\", \\\"{x:1383,y:983,t:1527272206346};\\\", \\\"{x:1366,y:986,t:1527272206362};\\\", \\\"{x:1351,y:987,t:1527272206379};\\\", \\\"{x:1345,y:988,t:1527272206396};\\\", \\\"{x:1349,y:988,t:1527272206535};\\\", \\\"{x:1352,y:987,t:1527272206546};\\\", \\\"{x:1357,y:984,t:1527272206563};\\\", \\\"{x:1368,y:981,t:1527272206580};\\\", \\\"{x:1377,y:977,t:1527272206596};\\\", \\\"{x:1381,y:974,t:1527272206613};\\\", \\\"{x:1382,y:974,t:1527272206637};\\\", \\\"{x:1381,y:973,t:1527272206829};\\\", \\\"{x:1379,y:972,t:1527272206845};\\\", \\\"{x:1378,y:972,t:1527272206861};\\\", \\\"{x:1378,y:970,t:1527272207125};\\\", \\\"{x:1380,y:970,t:1527272207141};\\\", \\\"{x:1384,y:967,t:1527272207149};\\\", \\\"{x:1385,y:966,t:1527272207163};\\\", \\\"{x:1388,y:966,t:1527272207180};\\\", \\\"{x:1388,y:965,t:1527272207237};\\\", \\\"{x:1390,y:964,t:1527272207247};\\\", \\\"{x:1393,y:962,t:1527272207264};\\\", \\\"{x:1396,y:960,t:1527272207280};\\\", \\\"{x:1398,y:960,t:1527272207541};\\\", \\\"{x:1403,y:960,t:1527272207549};\\\", \\\"{x:1412,y:960,t:1527272207564};\\\", \\\"{x:1432,y:962,t:1527272207579};\\\", \\\"{x:1462,y:967,t:1527272207597};\\\", \\\"{x:1474,y:967,t:1527272207614};\\\", \\\"{x:1482,y:967,t:1527272207631};\\\", \\\"{x:1484,y:967,t:1527272207647};\\\", \\\"{x:1483,y:967,t:1527272207766};\\\", \\\"{x:1482,y:966,t:1527272207781};\\\", \\\"{x:1477,y:966,t:1527272207797};\\\", \\\"{x:1470,y:966,t:1527272207814};\\\", \\\"{x:1460,y:966,t:1527272207831};\\\", \\\"{x:1454,y:966,t:1527272207847};\\\", \\\"{x:1452,y:966,t:1527272207865};\\\", \\\"{x:1451,y:966,t:1527272207957};\\\", \\\"{x:1450,y:966,t:1527272207981};\\\", \\\"{x:1454,y:971,t:1527272208766};\\\", \\\"{x:1471,y:980,t:1527272208782};\\\", \\\"{x:1483,y:986,t:1527272208799};\\\", \\\"{x:1498,y:992,t:1527272208816};\\\", \\\"{x:1507,y:996,t:1527272208831};\\\", \\\"{x:1509,y:996,t:1527272208849};\\\", \\\"{x:1510,y:996,t:1527272208949};\\\", \\\"{x:1512,y:996,t:1527272208965};\\\", \\\"{x:1513,y:996,t:1527272208989};\\\", \\\"{x:1514,y:996,t:1527272209014};\\\", \\\"{x:1514,y:995,t:1527272209054};\\\", \\\"{x:1514,y:994,t:1527272209102};\\\", \\\"{x:1514,y:992,t:1527272209117};\\\", \\\"{x:1514,y:990,t:1527272209133};\\\", \\\"{x:1514,y:989,t:1527272209149};\\\", \\\"{x:1514,y:986,t:1527272209165};\\\", \\\"{x:1514,y:984,t:1527272209182};\\\", \\\"{x:1513,y:982,t:1527272209199};\\\", \\\"{x:1512,y:981,t:1527272209215};\\\", \\\"{x:1510,y:980,t:1527272209232};\\\", \\\"{x:1510,y:979,t:1527272209286};\\\", \\\"{x:1510,y:978,t:1527272209299};\\\", \\\"{x:1510,y:976,t:1527272209316};\\\", \\\"{x:1510,y:973,t:1527272209332};\\\", \\\"{x:1510,y:971,t:1527272209349};\\\", \\\"{x:1510,y:970,t:1527272209397};\\\", \\\"{x:1510,y:969,t:1527272209725};\\\", \\\"{x:1512,y:969,t:1527272209740};\\\", \\\"{x:1513,y:969,t:1527272209925};\\\", \\\"{x:1515,y:969,t:1527272209933};\\\", \\\"{x:1520,y:969,t:1527272209949};\\\", \\\"{x:1524,y:969,t:1527272209965};\\\", \\\"{x:1530,y:971,t:1527272209982};\\\", \\\"{x:1537,y:975,t:1527272209999};\\\", \\\"{x:1540,y:976,t:1527272210016};\\\", \\\"{x:1543,y:977,t:1527272210032};\\\", \\\"{x:1544,y:978,t:1527272210049};\\\", \\\"{x:1545,y:978,t:1527272210067};\\\", \\\"{x:1546,y:978,t:1527272210082};\\\", \\\"{x:1550,y:979,t:1527272210099};\\\", \\\"{x:1556,y:979,t:1527272210116};\\\", \\\"{x:1559,y:980,t:1527272210132};\\\", \\\"{x:1564,y:982,t:1527272210149};\\\", \\\"{x:1567,y:982,t:1527272210166};\\\", \\\"{x:1570,y:983,t:1527272210183};\\\", \\\"{x:1571,y:983,t:1527272210278};\\\", \\\"{x:1573,y:983,t:1527272210301};\\\", \\\"{x:1574,y:983,t:1527272210374};\\\", \\\"{x:1576,y:983,t:1527272210421};\\\", \\\"{x:1579,y:982,t:1527272210433};\\\", \\\"{x:1581,y:982,t:1527272210449};\\\", \\\"{x:1583,y:981,t:1527272210466};\\\", \\\"{x:1584,y:981,t:1527272210483};\\\", \\\"{x:1584,y:980,t:1527272210499};\\\", \\\"{x:1586,y:980,t:1527272210516};\\\", \\\"{x:1589,y:978,t:1527272210533};\\\", \\\"{x:1590,y:978,t:1527272210549};\\\", \\\"{x:1590,y:976,t:1527272210925};\\\", \\\"{x:1589,y:975,t:1527272210932};\\\", \\\"{x:1586,y:971,t:1527272210949};\\\", \\\"{x:1585,y:969,t:1527272210966};\\\", \\\"{x:1584,y:968,t:1527272211573};\\\", \\\"{x:1583,y:968,t:1527272211621};\\\", \\\"{x:1582,y:968,t:1527272211758};\\\", \\\"{x:1582,y:967,t:1527272218421};\\\", \\\"{x:1581,y:967,t:1527272285815};\\\", \\\"{x:1578,y:967,t:1527272285822};\\\", \\\"{x:1571,y:954,t:1527272285836};\\\", \\\"{x:1557,y:891,t:1527272285853};\\\", \\\"{x:1541,y:848,t:1527272285869};\\\", \\\"{x:1529,y:831,t:1527272285886};\\\", \\\"{x:1525,y:822,t:1527272285902};\\\", \\\"{x:1519,y:814,t:1527272285920};\\\", \\\"{x:1519,y:810,t:1527272285936};\\\", \\\"{x:1519,y:806,t:1527272285952};\\\", \\\"{x:1519,y:804,t:1527272285970};\\\", \\\"{x:1519,y:803,t:1527272285990};\\\", \\\"{x:1518,y:803,t:1527272286002};\\\", \\\"{x:1519,y:802,t:1527272286055};\\\", \\\"{x:1522,y:802,t:1527272286069};\\\", \\\"{x:1536,y:806,t:1527272286087};\\\", \\\"{x:1539,y:808,t:1527272286103};\\\", \\\"{x:1544,y:809,t:1527272286119};\\\", \\\"{x:1545,y:810,t:1527272286137};\\\", \\\"{x:1546,y:811,t:1527272286247};\\\", \\\"{x:1546,y:812,t:1527272286263};\\\", \\\"{x:1546,y:814,t:1527272286311};\\\", \\\"{x:1546,y:815,t:1527272286319};\\\", \\\"{x:1544,y:819,t:1527272286336};\\\", \\\"{x:1543,y:827,t:1527272286352};\\\", \\\"{x:1542,y:833,t:1527272286368};\\\", \\\"{x:1540,y:836,t:1527272286386};\\\", \\\"{x:1540,y:838,t:1527272286403};\\\", \\\"{x:1539,y:838,t:1527272286418};\\\", \\\"{x:1538,y:839,t:1527272286436};\\\", \\\"{x:1538,y:840,t:1527272286453};\\\", \\\"{x:1536,y:841,t:1527272286469};\\\", \\\"{x:1527,y:841,t:1527272286485};\\\", \\\"{x:1522,y:841,t:1527272286503};\\\", \\\"{x:1521,y:842,t:1527272286521};\\\", \\\"{x:1524,y:842,t:1527272286623};\\\", \\\"{x:1525,y:842,t:1527272286637};\\\", \\\"{x:1526,y:842,t:1527272286734};\\\", \\\"{x:1528,y:842,t:1527272286743};\\\", \\\"{x:1529,y:842,t:1527272286758};\\\", \\\"{x:1530,y:842,t:1527272286770};\\\", \\\"{x:1532,y:841,t:1527272286786};\\\", \\\"{x:1534,y:841,t:1527272286823};\\\", \\\"{x:1537,y:841,t:1527272286836};\\\", \\\"{x:1543,y:838,t:1527272286854};\\\", \\\"{x:1546,y:837,t:1527272286871};\\\", \\\"{x:1547,y:837,t:1527272286887};\\\", \\\"{x:1549,y:837,t:1527272287767};\\\", \\\"{x:1551,y:837,t:1527272287783};\\\", \\\"{x:1553,y:837,t:1527272287791};\\\", \\\"{x:1557,y:836,t:1527272287804};\\\", \\\"{x:1564,y:834,t:1527272287821};\\\", \\\"{x:1569,y:834,t:1527272287837};\\\", \\\"{x:1581,y:833,t:1527272287854};\\\", \\\"{x:1590,y:832,t:1527272287871};\\\", \\\"{x:1596,y:830,t:1527272287888};\\\", \\\"{x:1601,y:829,t:1527272287905};\\\", \\\"{x:1606,y:828,t:1527272287921};\\\", \\\"{x:1613,y:825,t:1527272287937};\\\", \\\"{x:1618,y:824,t:1527272287955};\\\", \\\"{x:1619,y:823,t:1527272287974};\\\", \\\"{x:1619,y:822,t:1527272287991};\\\", \\\"{x:1620,y:822,t:1527272288005};\\\", \\\"{x:1621,y:822,t:1527272288022};\\\", \\\"{x:1622,y:821,t:1527272288037};\\\", \\\"{x:1621,y:821,t:1527272288639};\\\", \\\"{x:1608,y:818,t:1527272288655};\\\", \\\"{x:1550,y:783,t:1527272288671};\\\", \\\"{x:1435,y:717,t:1527272288688};\\\", \\\"{x:1310,y:650,t:1527272288705};\\\", \\\"{x:1164,y:588,t:1527272288721};\\\", \\\"{x:980,y:517,t:1527272288739};\\\", \\\"{x:800,y:458,t:1527272288755};\\\", \\\"{x:645,y:413,t:1527272288772};\\\", \\\"{x:526,y:378,t:1527272288788};\\\", \\\"{x:445,y:365,t:1527272288805};\\\", \\\"{x:403,y:358,t:1527272288822};\\\", \\\"{x:382,y:356,t:1527272288838};\\\", \\\"{x:384,y:357,t:1527272288902};\\\", \\\"{x:385,y:359,t:1527272288910};\\\", \\\"{x:388,y:363,t:1527272288921};\\\", \\\"{x:392,y:366,t:1527272288938};\\\", \\\"{x:400,y:373,t:1527272288956};\\\", \\\"{x:415,y:380,t:1527272288972};\\\", \\\"{x:442,y:388,t:1527272288988};\\\", \\\"{x:472,y:401,t:1527272289005};\\\", \\\"{x:508,y:416,t:1527272289021};\\\", \\\"{x:581,y:446,t:1527272289038};\\\", \\\"{x:641,y:471,t:1527272289056};\\\", \\\"{x:708,y:490,t:1527272289071};\\\", \\\"{x:778,y:501,t:1527272289089};\\\", \\\"{x:828,y:508,t:1527272289105};\\\", \\\"{x:846,y:511,t:1527272289121};\\\", \\\"{x:854,y:514,t:1527272289138};\\\", \\\"{x:857,y:515,t:1527272289155};\\\", \\\"{x:861,y:518,t:1527272289172};\\\", \\\"{x:865,y:520,t:1527272289190};\\\", \\\"{x:885,y:530,t:1527272289205};\\\", \\\"{x:956,y:567,t:1527272289222};\\\", \\\"{x:997,y:586,t:1527272289235};\\\", \\\"{x:1088,y:628,t:1527272289252};\\\", \\\"{x:1207,y:678,t:1527272289267};\\\", \\\"{x:1322,y:727,t:1527272289285};\\\", \\\"{x:1516,y:806,t:1527272289301};\\\", \\\"{x:1641,y:844,t:1527272289318};\\\", \\\"{x:1750,y:881,t:1527272289335};\\\", \\\"{x:1828,y:910,t:1527272289352};\\\", \\\"{x:1879,y:924,t:1527272289369};\\\", \\\"{x:1905,y:930,t:1527272289385};\\\", \\\"{x:1910,y:931,t:1527272289402};\\\", \\\"{x:1909,y:931,t:1527272289429};\\\", \\\"{x:1905,y:931,t:1527272289444};\\\", \\\"{x:1894,y:933,t:1527272289461};\\\", \\\"{x:1870,y:937,t:1527272289477};\\\", \\\"{x:1772,y:944,t:1527272289493};\\\", \\\"{x:1655,y:941,t:1527272289510};\\\", \\\"{x:1511,y:902,t:1527272289527};\\\", \\\"{x:1332,y:850,t:1527272289544};\\\", \\\"{x:1124,y:789,t:1527272289560};\\\", \\\"{x:901,y:723,t:1527272289577};\\\", \\\"{x:699,y:658,t:1527272289594};\\\", \\\"{x:530,y:607,t:1527272289610};\\\", \\\"{x:435,y:579,t:1527272289627};\\\", \\\"{x:418,y:574,t:1527272289643};\\\", \\\"{x:421,y:574,t:1527272289669};\\\", \\\"{x:434,y:579,t:1527272289677};\\\", \\\"{x:474,y:594,t:1527272289694};\\\", \\\"{x:508,y:609,t:1527272289710};\\\", \\\"{x:529,y:619,t:1527272289727};\\\", \\\"{x:552,y:621,t:1527272289744};\\\", \\\"{x:573,y:623,t:1527272289761};\\\", \\\"{x:591,y:622,t:1527272289777};\\\", \\\"{x:608,y:617,t:1527272289795};\\\", \\\"{x:629,y:610,t:1527272289811};\\\", \\\"{x:656,y:607,t:1527272289827};\\\", \\\"{x:674,y:605,t:1527272289844};\\\", \\\"{x:682,y:601,t:1527272289860};\\\", \\\"{x:683,y:599,t:1527272289877};\\\", \\\"{x:678,y:593,t:1527272289895};\\\", \\\"{x:662,y:585,t:1527272289913};\\\", \\\"{x:635,y:577,t:1527272289927};\\\", \\\"{x:601,y:573,t:1527272289944};\\\", \\\"{x:550,y:572,t:1527272289960};\\\", \\\"{x:494,y:572,t:1527272289977};\\\", \\\"{x:458,y:572,t:1527272289994};\\\", \\\"{x:453,y:572,t:1527272290011};\\\", \\\"{x:451,y:573,t:1527272290027};\\\", \\\"{x:458,y:577,t:1527272290044};\\\", \\\"{x:474,y:587,t:1527272290061};\\\", \\\"{x:490,y:594,t:1527272290078};\\\", \\\"{x:511,y:603,t:1527272290093};\\\", \\\"{x:519,y:604,t:1527272290109};\\\", \\\"{x:524,y:604,t:1527272290127};\\\", \\\"{x:526,y:604,t:1527272290144};\\\", \\\"{x:527,y:606,t:1527272290160};\\\", \\\"{x:530,y:606,t:1527272290177};\\\", \\\"{x:535,y:606,t:1527272290193};\\\", \\\"{x:551,y:608,t:1527272290210};\\\", \\\"{x:577,y:613,t:1527272290227};\\\", \\\"{x:604,y:617,t:1527272290244};\\\", \\\"{x:616,y:619,t:1527272290260};\\\", \\\"{x:617,y:619,t:1527272290277};\\\", \\\"{x:616,y:619,t:1527272290318};\\\", \\\"{x:615,y:619,t:1527272290328};\\\", \\\"{x:612,y:617,t:1527272290344};\\\", \\\"{x:610,y:615,t:1527272290361};\\\", \\\"{x:610,y:632,t:1527272290838};\\\", \\\"{x:607,y:680,t:1527272290846};\\\", \\\"{x:603,y:728,t:1527272290861};\\\", \\\"{x:587,y:800,t:1527272290878};\\\", \\\"{x:578,y:823,t:1527272290894};\\\", \\\"{x:574,y:841,t:1527272290911};\\\", \\\"{x:572,y:846,t:1527272290928};\\\", \\\"{x:571,y:846,t:1527272290966};\\\", \\\"{x:569,y:846,t:1527272290978};\\\", \\\"{x:566,y:846,t:1527272290996};\\\", \\\"{x:561,y:846,t:1527272291011};\\\", \\\"{x:561,y:845,t:1527272291029};\\\", \\\"{x:551,y:831,t:1527272291046};\\\", \\\"{x:547,y:825,t:1527272291061};\\\", \\\"{x:536,y:802,t:1527272291078};\\\", \\\"{x:531,y:783,t:1527272291095};\\\", \\\"{x:530,y:763,t:1527272291111};\\\", \\\"{x:530,y:741,t:1527272291130};\\\", \\\"{x:529,y:723,t:1527272291145};\\\", \\\"{x:529,y:720,t:1527272291161};\\\", \\\"{x:529,y:715,t:1527272291178};\\\", \\\"{x:529,y:712,t:1527272291195};\\\", \\\"{x:528,y:712,t:1527272291710};\\\", \\\"{x:527,y:714,t:1527272291717};\\\", \\\"{x:527,y:717,t:1527272291729};\\\", \\\"{x:527,y:723,t:1527272291745};\\\", \\\"{x:523,y:733,t:1527272291762};\\\", \\\"{x:521,y:740,t:1527272291779};\\\", \\\"{x:520,y:742,t:1527272291795};\\\" ] }, { \\\"rt\\\": 8662, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 838565, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:743,t:1527272294470};\\\", \\\"{x:549,y:746,t:1527272294489};\\\", \\\"{x:572,y:746,t:1527272294501};\\\", \\\"{x:648,y:710,t:1527272294517};\\\", \\\"{x:669,y:692,t:1527272294531};\\\", \\\"{x:681,y:643,t:1527272294547};\\\", \\\"{x:681,y:592,t:1527272294565};\\\", \\\"{x:684,y:575,t:1527272294581};\\\", \\\"{x:684,y:574,t:1527272294597};\\\", \\\"{x:684,y:567,t:1527272294614};\\\", \\\"{x:679,y:559,t:1527272294631};\\\", \\\"{x:667,y:546,t:1527272294648};\\\", \\\"{x:652,y:531,t:1527272294664};\\\", \\\"{x:639,y:515,t:1527272294682};\\\", \\\"{x:622,y:499,t:1527272294698};\\\", \\\"{x:611,y:489,t:1527272294714};\\\", \\\"{x:609,y:487,t:1527272294731};\\\", \\\"{x:608,y:487,t:1527272294822};\\\", \\\"{x:608,y:486,t:1527272294832};\\\", \\\"{x:606,y:486,t:1527272294849};\\\", \\\"{x:605,y:484,t:1527272294864};\\\", \\\"{x:603,y:483,t:1527272294881};\\\", \\\"{x:603,y:479,t:1527272294899};\\\", \\\"{x:601,y:472,t:1527272294914};\\\", \\\"{x:597,y:462,t:1527272294932};\\\", \\\"{x:595,y:458,t:1527272294948};\\\", \\\"{x:593,y:454,t:1527272294964};\\\", \\\"{x:591,y:450,t:1527272294982};\\\", \\\"{x:590,y:450,t:1527272295430};\\\", \\\"{x:589,y:450,t:1527272295510};\\\", \\\"{x:588,y:450,t:1527272295727};\\\", \\\"{x:588,y:449,t:1527272295846};\\\", \\\"{x:587,y:449,t:1527272295862};\\\", \\\"{x:586,y:448,t:1527272295918};\\\", \\\"{x:589,y:448,t:1527272296703};\\\", \\\"{x:597,y:448,t:1527272296715};\\\", \\\"{x:643,y:461,t:1527272296731};\\\", \\\"{x:700,y:474,t:1527272296749};\\\", \\\"{x:747,y:487,t:1527272296767};\\\", \\\"{x:782,y:492,t:1527272296781};\\\", \\\"{x:789,y:492,t:1527272296798};\\\", \\\"{x:790,y:492,t:1527272296816};\\\", \\\"{x:793,y:492,t:1527272296910};\\\", \\\"{x:797,y:492,t:1527272296917};\\\", \\\"{x:808,y:493,t:1527272296934};\\\", \\\"{x:822,y:494,t:1527272296950};\\\", \\\"{x:837,y:497,t:1527272296968};\\\", \\\"{x:851,y:499,t:1527272296984};\\\", \\\"{x:863,y:500,t:1527272296999};\\\", \\\"{x:877,y:502,t:1527272297017};\\\", \\\"{x:893,y:502,t:1527272297032};\\\", \\\"{x:915,y:502,t:1527272297050};\\\", \\\"{x:939,y:502,t:1527272297067};\\\", \\\"{x:976,y:502,t:1527272297084};\\\", \\\"{x:1027,y:504,t:1527272297100};\\\", \\\"{x:1079,y:507,t:1527272297116};\\\", \\\"{x:1136,y:516,t:1527272297134};\\\", \\\"{x:1157,y:523,t:1527272297150};\\\", \\\"{x:1177,y:533,t:1527272297167};\\\", \\\"{x:1189,y:540,t:1527272297184};\\\", \\\"{x:1193,y:543,t:1527272297200};\\\", \\\"{x:1195,y:544,t:1527272297217};\\\", \\\"{x:1197,y:546,t:1527272297234};\\\", \\\"{x:1199,y:547,t:1527272297251};\\\", \\\"{x:1199,y:550,t:1527272297267};\\\", \\\"{x:1200,y:554,t:1527272297284};\\\", \\\"{x:1200,y:557,t:1527272297299};\\\", \\\"{x:1200,y:559,t:1527272297317};\\\", \\\"{x:1200,y:560,t:1527272297333};\\\", \\\"{x:1200,y:561,t:1527272297350};\\\", \\\"{x:1200,y:562,t:1527272297374};\\\", \\\"{x:1200,y:564,t:1527272297384};\\\", \\\"{x:1204,y:569,t:1527272297400};\\\", \\\"{x:1207,y:572,t:1527272297417};\\\", \\\"{x:1212,y:575,t:1527272297434};\\\", \\\"{x:1214,y:575,t:1527272297451};\\\", \\\"{x:1216,y:575,t:1527272297467};\\\", \\\"{x:1217,y:575,t:1527272297484};\\\", \\\"{x:1218,y:575,t:1527272297502};\\\", \\\"{x:1219,y:575,t:1527272297517};\\\", \\\"{x:1223,y:573,t:1527272297535};\\\", \\\"{x:1229,y:570,t:1527272297550};\\\", \\\"{x:1232,y:570,t:1527272297566};\\\", \\\"{x:1234,y:570,t:1527272297584};\\\", \\\"{x:1236,y:570,t:1527272297600};\\\", \\\"{x:1239,y:570,t:1527272297617};\\\", \\\"{x:1242,y:570,t:1527272297634};\\\", \\\"{x:1251,y:570,t:1527272297650};\\\", \\\"{x:1267,y:570,t:1527272297667};\\\", \\\"{x:1280,y:570,t:1527272297684};\\\", \\\"{x:1287,y:570,t:1527272297700};\\\", \\\"{x:1288,y:570,t:1527272297717};\\\", \\\"{x:1288,y:568,t:1527272297783};\\\", \\\"{x:1288,y:566,t:1527272297800};\\\", \\\"{x:1287,y:566,t:1527272297822};\\\", \\\"{x:1287,y:565,t:1527272297902};\\\", \\\"{x:1286,y:564,t:1527272297921};\\\", \\\"{x:1285,y:564,t:1527272298743};\\\", \\\"{x:1283,y:560,t:1527272298750};\\\", \\\"{x:1252,y:539,t:1527272298768};\\\", \\\"{x:1205,y:512,t:1527272298783};\\\", \\\"{x:1144,y:483,t:1527272298799};\\\", \\\"{x:1064,y:450,t:1527272298816};\\\", \\\"{x:978,y:411,t:1527272298833};\\\", \\\"{x:891,y:376,t:1527272298850};\\\", \\\"{x:803,y:343,t:1527272298866};\\\", \\\"{x:763,y:331,t:1527272298883};\\\", \\\"{x:739,y:327,t:1527272298900};\\\", \\\"{x:723,y:328,t:1527272298917};\\\", \\\"{x:714,y:338,t:1527272298933};\\\", \\\"{x:704,y:369,t:1527272298950};\\\", \\\"{x:703,y:394,t:1527272298966};\\\", \\\"{x:703,y:420,t:1527272298983};\\\", \\\"{x:704,y:436,t:1527272299000};\\\", \\\"{x:709,y:446,t:1527272299017};\\\", \\\"{x:716,y:457,t:1527272299033};\\\", \\\"{x:720,y:463,t:1527272299050};\\\", \\\"{x:720,y:466,t:1527272299067};\\\", \\\"{x:719,y:469,t:1527272299083};\\\", \\\"{x:716,y:471,t:1527272299100};\\\", \\\"{x:711,y:476,t:1527272299117};\\\", \\\"{x:702,y:485,t:1527272299133};\\\", \\\"{x:687,y:494,t:1527272299151};\\\", \\\"{x:679,y:497,t:1527272299167};\\\", \\\"{x:672,y:503,t:1527272299182};\\\", \\\"{x:658,y:510,t:1527272299201};\\\", \\\"{x:642,y:518,t:1527272299219};\\\", \\\"{x:627,y:525,t:1527272299235};\\\", \\\"{x:611,y:530,t:1527272299252};\\\", \\\"{x:606,y:531,t:1527272299268};\\\", \\\"{x:604,y:531,t:1527272299284};\\\", \\\"{x:601,y:525,t:1527272299317};\\\", \\\"{x:596,y:516,t:1527272299335};\\\", \\\"{x:595,y:515,t:1527272299351};\\\", \\\"{x:594,y:514,t:1527272299368};\\\", \\\"{x:595,y:514,t:1527272299453};\\\", \\\"{x:597,y:514,t:1527272299468};\\\", \\\"{x:601,y:514,t:1527272299485};\\\", \\\"{x:602,y:514,t:1527272299502};\\\", \\\"{x:603,y:513,t:1527272299542};\\\", \\\"{x:603,y:512,t:1527272299551};\\\", \\\"{x:605,y:508,t:1527272299569};\\\", \\\"{x:606,y:503,t:1527272299585};\\\", \\\"{x:606,y:498,t:1527272299601};\\\", \\\"{x:606,y:497,t:1527272299618};\\\", \\\"{x:606,y:496,t:1527272299636};\\\", \\\"{x:606,y:495,t:1527272299711};\\\", \\\"{x:609,y:494,t:1527272299845};\\\", \\\"{x:618,y:494,t:1527272299853};\\\", \\\"{x:646,y:491,t:1527272299868};\\\", \\\"{x:775,y:484,t:1527272299886};\\\", \\\"{x:820,y:484,t:1527272299902};\\\", \\\"{x:844,y:484,t:1527272299919};\\\", \\\"{x:851,y:482,t:1527272299935};\\\", \\\"{x:854,y:481,t:1527272299952};\\\", \\\"{x:855,y:481,t:1527272299982};\\\", \\\"{x:857,y:481,t:1527272299997};\\\", \\\"{x:861,y:481,t:1527272300005};\\\", \\\"{x:867,y:482,t:1527272300019};\\\", \\\"{x:874,y:487,t:1527272300036};\\\", \\\"{x:876,y:488,t:1527272300052};\\\", \\\"{x:876,y:489,t:1527272300069};\\\", \\\"{x:876,y:496,t:1527272300085};\\\", \\\"{x:874,y:505,t:1527272300103};\\\", \\\"{x:868,y:520,t:1527272300118};\\\", \\\"{x:862,y:542,t:1527272300135};\\\", \\\"{x:857,y:559,t:1527272300153};\\\", \\\"{x:854,y:567,t:1527272300169};\\\", \\\"{x:853,y:569,t:1527272300185};\\\", \\\"{x:852,y:569,t:1527272300262};\\\", \\\"{x:850,y:569,t:1527272300270};\\\", \\\"{x:842,y:568,t:1527272300285};\\\", \\\"{x:836,y:561,t:1527272300303};\\\", \\\"{x:829,y:551,t:1527272300319};\\\", \\\"{x:827,y:542,t:1527272300336};\\\", \\\"{x:827,y:537,t:1527272300352};\\\", \\\"{x:827,y:532,t:1527272300369};\\\", \\\"{x:825,y:529,t:1527272300386};\\\", \\\"{x:824,y:527,t:1527272300403};\\\", \\\"{x:823,y:527,t:1527272300419};\\\", \\\"{x:824,y:527,t:1527272300573};\\\", \\\"{x:826,y:527,t:1527272300589};\\\", \\\"{x:827,y:528,t:1527272300687};\\\", \\\"{x:827,y:529,t:1527272300703};\\\", \\\"{x:828,y:530,t:1527272300719};\\\", \\\"{x:819,y:531,t:1527272301222};\\\", \\\"{x:805,y:534,t:1527272301236};\\\", \\\"{x:752,y:543,t:1527272301252};\\\", \\\"{x:682,y:563,t:1527272301270};\\\", \\\"{x:632,y:584,t:1527272301287};\\\", \\\"{x:606,y:601,t:1527272301304};\\\", \\\"{x:596,y:611,t:1527272301320};\\\", \\\"{x:592,y:624,t:1527272301337};\\\", \\\"{x:589,y:638,t:1527272301354};\\\", \\\"{x:589,y:645,t:1527272301369};\\\", \\\"{x:584,y:654,t:1527272301387};\\\", \\\"{x:579,y:661,t:1527272301403};\\\", \\\"{x:568,y:668,t:1527272301420};\\\", \\\"{x:555,y:677,t:1527272301436};\\\", \\\"{x:544,y:688,t:1527272301454};\\\", \\\"{x:536,y:698,t:1527272301469};\\\", \\\"{x:531,y:705,t:1527272301486};\\\", \\\"{x:522,y:715,t:1527272301504};\\\", \\\"{x:517,y:722,t:1527272301519};\\\", \\\"{x:514,y:726,t:1527272301537};\\\", \\\"{x:512,y:729,t:1527272301553};\\\", \\\"{x:512,y:730,t:1527272301569};\\\" ] }, { \\\"rt\\\": 63227, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 903052, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:700,t:1527272303898};\\\", \\\"{x:499,y:700,t:1527272303911};\\\", \\\"{x:499,y:698,t:1527272304051};\\\", \\\"{x:499,y:694,t:1527272304062};\\\", \\\"{x:497,y:680,t:1527272304078};\\\", \\\"{x:493,y:656,t:1527272304096};\\\", \\\"{x:492,y:624,t:1527272304113};\\\", \\\"{x:491,y:596,t:1527272304128};\\\", \\\"{x:491,y:578,t:1527272304145};\\\", \\\"{x:494,y:565,t:1527272304162};\\\", \\\"{x:495,y:560,t:1527272304178};\\\", \\\"{x:498,y:554,t:1527272304196};\\\", \\\"{x:503,y:539,t:1527272304212};\\\", \\\"{x:504,y:536,t:1527272304227};\\\", \\\"{x:506,y:534,t:1527272304245};\\\", \\\"{x:507,y:533,t:1527272304268};\\\", \\\"{x:508,y:532,t:1527272304279};\\\", \\\"{x:519,y:527,t:1527272304295};\\\", \\\"{x:542,y:517,t:1527272304313};\\\", \\\"{x:565,y:508,t:1527272304329};\\\", \\\"{x:582,y:499,t:1527272304345};\\\", \\\"{x:589,y:495,t:1527272304362};\\\", \\\"{x:591,y:492,t:1527272304378};\\\", \\\"{x:591,y:491,t:1527272304396};\\\", \\\"{x:589,y:489,t:1527272304412};\\\", \\\"{x:575,y:482,t:1527272304429};\\\", \\\"{x:552,y:470,t:1527272304445};\\\", \\\"{x:515,y:450,t:1527272304462};\\\", \\\"{x:484,y:435,t:1527272304479};\\\", \\\"{x:462,y:425,t:1527272304494};\\\", \\\"{x:454,y:421,t:1527272304512};\\\", \\\"{x:450,y:421,t:1527272304529};\\\", \\\"{x:446,y:420,t:1527272304545};\\\", \\\"{x:443,y:420,t:1527272304562};\\\", \\\"{x:438,y:420,t:1527272304579};\\\", \\\"{x:425,y:420,t:1527272304595};\\\", \\\"{x:407,y:420,t:1527272304612};\\\", \\\"{x:397,y:423,t:1527272304629};\\\", \\\"{x:385,y:428,t:1527272304645};\\\", \\\"{x:381,y:431,t:1527272304662};\\\", \\\"{x:379,y:434,t:1527272304679};\\\", \\\"{x:377,y:436,t:1527272304696};\\\", \\\"{x:376,y:439,t:1527272304712};\\\", \\\"{x:374,y:441,t:1527272304729};\\\", \\\"{x:374,y:442,t:1527272304747};\\\", \\\"{x:374,y:443,t:1527272304837};\\\", \\\"{x:374,y:444,t:1527272304853};\\\", \\\"{x:374,y:445,t:1527272304862};\\\", \\\"{x:374,y:446,t:1527272304880};\\\", \\\"{x:374,y:448,t:1527272304896};\\\", \\\"{x:374,y:450,t:1527272304913};\\\", \\\"{x:374,y:453,t:1527272304929};\\\", \\\"{x:373,y:454,t:1527272304946};\\\", \\\"{x:373,y:455,t:1527272304964};\\\", \\\"{x:373,y:456,t:1527272304979};\\\", \\\"{x:371,y:457,t:1527272304996};\\\", \\\"{x:369,y:458,t:1527272305012};\\\", \\\"{x:366,y:460,t:1527272305029};\\\", \\\"{x:362,y:461,t:1527272305046};\\\", \\\"{x:359,y:461,t:1527272305062};\\\", \\\"{x:358,y:461,t:1527272305080};\\\", \\\"{x:357,y:462,t:1527272305097};\\\", \\\"{x:356,y:463,t:1527272305112};\\\", \\\"{x:355,y:463,t:1527272305141};\\\", \\\"{x:354,y:464,t:1527272305189};\\\", \\\"{x:353,y:464,t:1527272305580};\\\", \\\"{x:352,y:464,t:1527272306132};\\\", \\\"{x:349,y:464,t:1527272306146};\\\", \\\"{x:345,y:464,t:1527272306163};\\\", \\\"{x:344,y:464,t:1527272306180};\\\", \\\"{x:345,y:463,t:1527272306660};\\\", \\\"{x:347,y:463,t:1527272306676};\\\", \\\"{x:349,y:463,t:1527272306684};\\\", \\\"{x:352,y:462,t:1527272306697};\\\", \\\"{x:361,y:461,t:1527272306715};\\\", \\\"{x:368,y:461,t:1527272306730};\\\", \\\"{x:376,y:461,t:1527272306748};\\\", \\\"{x:383,y:461,t:1527272306765};\\\", \\\"{x:384,y:461,t:1527272306780};\\\", \\\"{x:386,y:461,t:1527272306798};\\\", \\\"{x:388,y:461,t:1527272306815};\\\", \\\"{x:389,y:461,t:1527272306831};\\\", \\\"{x:394,y:461,t:1527272306847};\\\", \\\"{x:401,y:459,t:1527272306865};\\\", \\\"{x:409,y:459,t:1527272306881};\\\", \\\"{x:423,y:459,t:1527272306897};\\\", \\\"{x:430,y:459,t:1527272306915};\\\", \\\"{x:438,y:459,t:1527272306932};\\\", \\\"{x:439,y:459,t:1527272306948};\\\", \\\"{x:440,y:459,t:1527272306972};\\\", \\\"{x:445,y:456,t:1527272307076};\\\", \\\"{x:452,y:453,t:1527272307085};\\\", \\\"{x:462,y:449,t:1527272307097};\\\", \\\"{x:480,y:445,t:1527272307115};\\\", \\\"{x:490,y:444,t:1527272307132};\\\", \\\"{x:502,y:442,t:1527272307148};\\\", \\\"{x:519,y:442,t:1527272307165};\\\", \\\"{x:522,y:442,t:1527272307182};\\\", \\\"{x:526,y:442,t:1527272307197};\\\", \\\"{x:530,y:442,t:1527272307214};\\\", \\\"{x:533,y:441,t:1527272307231};\\\", \\\"{x:536,y:441,t:1527272307247};\\\", \\\"{x:541,y:440,t:1527272307265};\\\", \\\"{x:548,y:439,t:1527272307282};\\\", \\\"{x:557,y:437,t:1527272307298};\\\", \\\"{x:575,y:436,t:1527272307314};\\\", \\\"{x:589,y:436,t:1527272307332};\\\", \\\"{x:596,y:436,t:1527272307347};\\\", \\\"{x:597,y:436,t:1527272307365};\\\", \\\"{x:600,y:436,t:1527272307404};\\\", \\\"{x:604,y:436,t:1527272307415};\\\", \\\"{x:623,y:436,t:1527272307431};\\\", \\\"{x:640,y:436,t:1527272307449};\\\", \\\"{x:645,y:436,t:1527272307465};\\\", \\\"{x:649,y:436,t:1527272307482};\\\", \\\"{x:653,y:436,t:1527272307498};\\\", \\\"{x:658,y:437,t:1527272307514};\\\", \\\"{x:659,y:437,t:1527272307531};\\\", \\\"{x:666,y:439,t:1527272307547};\\\", \\\"{x:667,y:439,t:1527272307676};\\\", \\\"{x:667,y:440,t:1527272309405};\\\", \\\"{x:667,y:442,t:1527272309417};\\\", \\\"{x:667,y:445,t:1527272309432};\\\", \\\"{x:667,y:447,t:1527272309450};\\\", \\\"{x:667,y:448,t:1527272309466};\\\", \\\"{x:667,y:450,t:1527272309482};\\\", \\\"{x:667,y:452,t:1527272309500};\\\", \\\"{x:667,y:454,t:1527272309516};\\\", \\\"{x:668,y:456,t:1527272309533};\\\", \\\"{x:669,y:459,t:1527272309550};\\\", \\\"{x:670,y:461,t:1527272309567};\\\", \\\"{x:674,y:466,t:1527272309583};\\\", \\\"{x:678,y:472,t:1527272309600};\\\", \\\"{x:681,y:476,t:1527272309616};\\\", \\\"{x:681,y:478,t:1527272309634};\\\", \\\"{x:684,y:481,t:1527272309650};\\\", \\\"{x:685,y:482,t:1527272309692};\\\", \\\"{x:687,y:482,t:1527272309700};\\\", \\\"{x:689,y:482,t:1527272309717};\\\", \\\"{x:695,y:485,t:1527272309733};\\\", \\\"{x:705,y:487,t:1527272309751};\\\", \\\"{x:718,y:492,t:1527272309766};\\\", \\\"{x:736,y:500,t:1527272309784};\\\", \\\"{x:745,y:507,t:1527272309799};\\\", \\\"{x:757,y:516,t:1527272309816};\\\", \\\"{x:767,y:527,t:1527272309833};\\\", \\\"{x:778,y:539,t:1527272309849};\\\", \\\"{x:787,y:554,t:1527272309866};\\\", \\\"{x:795,y:569,t:1527272309883};\\\", \\\"{x:799,y:582,t:1527272309899};\\\", \\\"{x:801,y:597,t:1527272309916};\\\", \\\"{x:801,y:608,t:1527272309933};\\\", \\\"{x:800,y:624,t:1527272309950};\\\", \\\"{x:799,y:637,t:1527272309967};\\\", \\\"{x:796,y:650,t:1527272309983};\\\", \\\"{x:796,y:654,t:1527272310000};\\\", \\\"{x:795,y:656,t:1527272310016};\\\", \\\"{x:793,y:658,t:1527272310033};\\\", \\\"{x:793,y:659,t:1527272310051};\\\", \\\"{x:793,y:660,t:1527272310164};\\\", \\\"{x:793,y:661,t:1527272310172};\\\", \\\"{x:793,y:662,t:1527272310188};\\\", \\\"{x:793,y:665,t:1527272310200};\\\", \\\"{x:793,y:669,t:1527272310217};\\\", \\\"{x:794,y:672,t:1527272310235};\\\", \\\"{x:794,y:675,t:1527272310250};\\\", \\\"{x:794,y:679,t:1527272310268};\\\", \\\"{x:794,y:683,t:1527272310285};\\\", \\\"{x:794,y:684,t:1527272310301};\\\", \\\"{x:794,y:687,t:1527272310318};\\\", \\\"{x:794,y:689,t:1527272310335};\\\", \\\"{x:794,y:690,t:1527272310352};\\\", \\\"{x:794,y:691,t:1527272310988};\\\", \\\"{x:797,y:686,t:1527272313917};\\\", \\\"{x:803,y:675,t:1527272313930};\\\", \\\"{x:812,y:654,t:1527272313946};\\\", \\\"{x:817,y:647,t:1527272313963};\\\", \\\"{x:817,y:646,t:1527272314020};\\\", \\\"{x:817,y:645,t:1527272314030};\\\", \\\"{x:815,y:638,t:1527272314046};\\\", \\\"{x:801,y:625,t:1527272314064};\\\", \\\"{x:756,y:594,t:1527272314081};\\\", \\\"{x:678,y:538,t:1527272314102};\\\", \\\"{x:622,y:501,t:1527272314118};\\\", \\\"{x:581,y:475,t:1527272314135};\\\", \\\"{x:541,y:455,t:1527272314153};\\\", \\\"{x:515,y:440,t:1527272314169};\\\", \\\"{x:506,y:437,t:1527272314187};\\\", \\\"{x:507,y:437,t:1527272314267};\\\", \\\"{x:509,y:437,t:1527272314275};\\\", \\\"{x:511,y:437,t:1527272314286};\\\", \\\"{x:517,y:440,t:1527272314303};\\\", \\\"{x:529,y:449,t:1527272314320};\\\", \\\"{x:538,y:454,t:1527272314336};\\\", \\\"{x:541,y:458,t:1527272314352};\\\", \\\"{x:542,y:458,t:1527272314412};\\\", \\\"{x:539,y:458,t:1527272314468};\\\", \\\"{x:533,y:458,t:1527272314476};\\\", \\\"{x:526,y:458,t:1527272314486};\\\", \\\"{x:516,y:458,t:1527272314503};\\\", \\\"{x:514,y:458,t:1527272314520};\\\", \\\"{x:513,y:458,t:1527272314535};\\\", \\\"{x:510,y:458,t:1527272314553};\\\", \\\"{x:508,y:458,t:1527272314572};\\\", \\\"{x:506,y:459,t:1527272314586};\\\", \\\"{x:502,y:461,t:1527272314603};\\\", \\\"{x:496,y:464,t:1527272314620};\\\", \\\"{x:495,y:465,t:1527272314636};\\\", \\\"{x:491,y:466,t:1527272314652};\\\", \\\"{x:484,y:466,t:1527272314670};\\\", \\\"{x:478,y:466,t:1527272314686};\\\", \\\"{x:473,y:466,t:1527272314703};\\\", \\\"{x:469,y:468,t:1527272314719};\\\", \\\"{x:467,y:468,t:1527272314736};\\\", \\\"{x:466,y:468,t:1527272314756};\\\", \\\"{x:465,y:468,t:1527272314769};\\\", \\\"{x:458,y:468,t:1527272314786};\\\", \\\"{x:448,y:468,t:1527272314803};\\\", \\\"{x:439,y:468,t:1527272314819};\\\", \\\"{x:438,y:468,t:1527272314941};\\\", \\\"{x:436,y:468,t:1527272314965};\\\", \\\"{x:432,y:468,t:1527272314972};\\\", \\\"{x:429,y:468,t:1527272314986};\\\", \\\"{x:425,y:468,t:1527272315002};\\\", \\\"{x:424,y:468,t:1527272315019};\\\", \\\"{x:423,y:468,t:1527272315077};\\\", \\\"{x:422,y:468,t:1527272315092};\\\", \\\"{x:421,y:468,t:1527272315116};\\\", \\\"{x:420,y:468,t:1527272315140};\\\", \\\"{x:419,y:468,t:1527272315172};\\\", \\\"{x:416,y:468,t:1527272315188};\\\", \\\"{x:412,y:468,t:1527272315202};\\\", \\\"{x:407,y:468,t:1527272315219};\\\", \\\"{x:404,y:468,t:1527272315235};\\\", \\\"{x:401,y:467,t:1527272315252};\\\", \\\"{x:399,y:466,t:1527272315549};\\\", \\\"{x:398,y:465,t:1527272315556};\\\", \\\"{x:397,y:465,t:1527272315568};\\\", \\\"{x:393,y:463,t:1527272315585};\\\", \\\"{x:391,y:463,t:1527272315601};\\\", \\\"{x:389,y:462,t:1527272315618};\\\", \\\"{x:387,y:462,t:1527272315635};\\\", \\\"{x:386,y:462,t:1527272315717};\\\", \\\"{x:384,y:461,t:1527272315724};\\\", \\\"{x:382,y:461,t:1527272315740};\\\", \\\"{x:381,y:460,t:1527272315751};\\\", \\\"{x:379,y:460,t:1527272315768};\\\", \\\"{x:378,y:459,t:1527272315784};\\\", \\\"{x:376,y:458,t:1527272315801};\\\", \\\"{x:375,y:458,t:1527272315820};\\\", \\\"{x:373,y:458,t:1527272315868};\\\", \\\"{x:372,y:458,t:1527272315909};\\\", \\\"{x:372,y:456,t:1527272316188};\\\", \\\"{x:373,y:456,t:1527272316200};\\\", \\\"{x:374,y:455,t:1527272316217};\\\", \\\"{x:378,y:454,t:1527272316234};\\\", \\\"{x:382,y:454,t:1527272316250};\\\", \\\"{x:387,y:451,t:1527272316266};\\\", \\\"{x:393,y:450,t:1527272316283};\\\", \\\"{x:394,y:450,t:1527272316299};\\\", \\\"{x:399,y:448,t:1527272316317};\\\", \\\"{x:401,y:448,t:1527272316334};\\\", \\\"{x:403,y:448,t:1527272316350};\\\", \\\"{x:407,y:446,t:1527272316366};\\\", \\\"{x:411,y:445,t:1527272316384};\\\", \\\"{x:413,y:444,t:1527272316400};\\\", \\\"{x:414,y:444,t:1527272316436};\\\", \\\"{x:415,y:444,t:1527272316452};\\\", \\\"{x:417,y:444,t:1527272316466};\\\", \\\"{x:419,y:444,t:1527272316483};\\\", \\\"{x:424,y:444,t:1527272316500};\\\", \\\"{x:426,y:444,t:1527272316516};\\\", \\\"{x:427,y:444,t:1527272316533};\\\", \\\"{x:429,y:444,t:1527272316564};\\\", \\\"{x:431,y:444,t:1527272316572};\\\", \\\"{x:434,y:444,t:1527272316583};\\\", \\\"{x:435,y:444,t:1527272316600};\\\", \\\"{x:436,y:444,t:1527272316617};\\\", \\\"{x:437,y:444,t:1527272316749};\\\", \\\"{x:438,y:444,t:1527272316765};\\\", \\\"{x:440,y:445,t:1527272316772};\\\", \\\"{x:441,y:446,t:1527272316813};\\\", \\\"{x:441,y:447,t:1527272316844};\\\", \\\"{x:441,y:448,t:1527272316852};\\\", \\\"{x:441,y:450,t:1527272316956};\\\", \\\"{x:441,y:451,t:1527272316965};\\\", \\\"{x:441,y:453,t:1527272316983};\\\", \\\"{x:441,y:454,t:1527272316999};\\\", \\\"{x:441,y:455,t:1527272317101};\\\", \\\"{x:441,y:456,t:1527272317116};\\\", \\\"{x:441,y:457,t:1527272317132};\\\", \\\"{x:443,y:457,t:1527272317589};\\\", \\\"{x:444,y:457,t:1527272317598};\\\", \\\"{x:445,y:456,t:1527272317615};\\\", \\\"{x:449,y:454,t:1527272317632};\\\", \\\"{x:453,y:453,t:1527272317648};\\\", \\\"{x:459,y:450,t:1527272317665};\\\", \\\"{x:465,y:449,t:1527272317682};\\\", \\\"{x:469,y:448,t:1527272317698};\\\", \\\"{x:470,y:448,t:1527272317813};\\\", \\\"{x:472,y:448,t:1527272317820};\\\", \\\"{x:473,y:448,t:1527272317831};\\\", \\\"{x:476,y:448,t:1527272317848};\\\", \\\"{x:478,y:448,t:1527272317865};\\\", \\\"{x:479,y:448,t:1527272317881};\\\", \\\"{x:480,y:448,t:1527272317898};\\\", \\\"{x:481,y:448,t:1527272317924};\\\", \\\"{x:482,y:448,t:1527272317972};\\\", \\\"{x:479,y:448,t:1527272318068};\\\", \\\"{x:475,y:448,t:1527272318081};\\\", \\\"{x:469,y:450,t:1527272318098};\\\", \\\"{x:463,y:451,t:1527272318114};\\\", \\\"{x:461,y:451,t:1527272318131};\\\", \\\"{x:459,y:453,t:1527272318148};\\\", \\\"{x:457,y:455,t:1527272318180};\\\", \\\"{x:459,y:455,t:1527272318364};\\\", \\\"{x:460,y:455,t:1527272318382};\\\", \\\"{x:463,y:455,t:1527272318397};\\\", \\\"{x:465,y:455,t:1527272318414};\\\", \\\"{x:466,y:455,t:1527272318430};\\\", \\\"{x:469,y:455,t:1527272318447};\\\", \\\"{x:470,y:455,t:1527272318464};\\\", \\\"{x:472,y:455,t:1527272318480};\\\", \\\"{x:477,y:455,t:1527272318498};\\\", \\\"{x:478,y:455,t:1527272318514};\\\", \\\"{x:479,y:455,t:1527272318530};\\\", \\\"{x:480,y:456,t:1527272318547};\\\", \\\"{x:481,y:456,t:1527272318564};\\\", \\\"{x:482,y:456,t:1527272318669};\\\", \\\"{x:483,y:456,t:1527272318684};\\\", \\\"{x:484,y:456,t:1527272318697};\\\", \\\"{x:485,y:456,t:1527272318713};\\\", \\\"{x:488,y:456,t:1527272318730};\\\", \\\"{x:489,y:456,t:1527272318747};\\\", \\\"{x:492,y:456,t:1527272318763};\\\", \\\"{x:503,y:453,t:1527272318781};\\\", \\\"{x:511,y:453,t:1527272318796};\\\", \\\"{x:521,y:451,t:1527272318813};\\\", \\\"{x:526,y:450,t:1527272318830};\\\", \\\"{x:530,y:449,t:1527272318846};\\\", \\\"{x:534,y:447,t:1527272318863};\\\", \\\"{x:539,y:445,t:1527272318881};\\\", \\\"{x:543,y:443,t:1527272318897};\\\", \\\"{x:545,y:443,t:1527272318913};\\\", \\\"{x:548,y:441,t:1527272318930};\\\", \\\"{x:552,y:439,t:1527272318947};\\\", \\\"{x:557,y:437,t:1527272318963};\\\", \\\"{x:562,y:434,t:1527272318980};\\\", \\\"{x:565,y:433,t:1527272318996};\\\", \\\"{x:566,y:433,t:1527272319189};\\\", \\\"{x:569,y:433,t:1527272319197};\\\", \\\"{x:582,y:433,t:1527272319212};\\\", \\\"{x:600,y:434,t:1527272319229};\\\", \\\"{x:618,y:437,t:1527272319246};\\\", \\\"{x:637,y:441,t:1527272319263};\\\", \\\"{x:657,y:444,t:1527272319279};\\\", \\\"{x:663,y:445,t:1527272319296};\\\", \\\"{x:664,y:445,t:1527272319381};\\\", \\\"{x:661,y:448,t:1527272319396};\\\", \\\"{x:653,y:453,t:1527272319413};\\\", \\\"{x:639,y:458,t:1527272319429};\\\", \\\"{x:622,y:462,t:1527272319446};\\\", \\\"{x:609,y:465,t:1527272319462};\\\", \\\"{x:602,y:468,t:1527272319479};\\\", \\\"{x:597,y:468,t:1527272319496};\\\", \\\"{x:596,y:468,t:1527272319512};\\\", \\\"{x:595,y:468,t:1527272319589};\\\", \\\"{x:593,y:468,t:1527272319613};\\\", \\\"{x:592,y:468,t:1527272319630};\\\", \\\"{x:590,y:468,t:1527272319660};\\\", \\\"{x:589,y:468,t:1527272319740};\\\", \\\"{x:589,y:467,t:1527272319821};\\\", \\\"{x:591,y:467,t:1527272319828};\\\", \\\"{x:597,y:464,t:1527272319846};\\\", \\\"{x:602,y:463,t:1527272319862};\\\", \\\"{x:604,y:462,t:1527272319884};\\\", \\\"{x:606,y:462,t:1527272320108};\\\", \\\"{x:607,y:462,t:1527272320116};\\\", \\\"{x:608,y:462,t:1527272320129};\\\", \\\"{x:614,y:462,t:1527272320144};\\\", \\\"{x:620,y:462,t:1527272320161};\\\", \\\"{x:624,y:461,t:1527272320178};\\\", \\\"{x:626,y:461,t:1527272320194};\\\", \\\"{x:627,y:461,t:1527272320211};\\\", \\\"{x:625,y:461,t:1527272320388};\\\", \\\"{x:621,y:461,t:1527272320396};\\\", \\\"{x:613,y:461,t:1527272320411};\\\", \\\"{x:603,y:461,t:1527272320428};\\\", \\\"{x:587,y:461,t:1527272320444};\\\", \\\"{x:583,y:461,t:1527272320460};\\\", \\\"{x:582,y:461,t:1527272320478};\\\", \\\"{x:581,y:461,t:1527272320495};\\\", \\\"{x:579,y:462,t:1527272320511};\\\", \\\"{x:577,y:463,t:1527272320527};\\\", \\\"{x:571,y:463,t:1527272320544};\\\", \\\"{x:564,y:463,t:1527272320561};\\\", \\\"{x:556,y:463,t:1527272320577};\\\", \\\"{x:551,y:463,t:1527272320594};\\\", \\\"{x:545,y:463,t:1527272320610};\\\", \\\"{x:542,y:464,t:1527272320627};\\\", \\\"{x:539,y:464,t:1527272320644};\\\", \\\"{x:538,y:464,t:1527272320660};\\\", \\\"{x:536,y:464,t:1527272320692};\\\", \\\"{x:533,y:465,t:1527272320708};\\\", \\\"{x:532,y:465,t:1527272320724};\\\", \\\"{x:529,y:465,t:1527272320732};\\\", \\\"{x:527,y:465,t:1527272320744};\\\", \\\"{x:520,y:467,t:1527272320760};\\\", \\\"{x:517,y:467,t:1527272320778};\\\", \\\"{x:513,y:468,t:1527272320794};\\\", \\\"{x:512,y:468,t:1527272320810};\\\", \\\"{x:510,y:468,t:1527272320827};\\\", \\\"{x:508,y:468,t:1527272320843};\\\", \\\"{x:503,y:468,t:1527272320860};\\\", \\\"{x:498,y:468,t:1527272320877};\\\", \\\"{x:495,y:468,t:1527272320893};\\\", \\\"{x:492,y:468,t:1527272320910};\\\", \\\"{x:491,y:468,t:1527272320981};\\\", \\\"{x:489,y:468,t:1527272321004};\\\", \\\"{x:488,y:468,t:1527272321013};\\\", \\\"{x:486,y:468,t:1527272321028};\\\", \\\"{x:485,y:468,t:1527272321043};\\\", \\\"{x:483,y:468,t:1527272321060};\\\", \\\"{x:482,y:468,t:1527272321076};\\\", \\\"{x:480,y:468,t:1527272321099};\\\", \\\"{x:479,y:468,t:1527272321131};\\\", \\\"{x:477,y:468,t:1527272321147};\\\", \\\"{x:476,y:468,t:1527272321160};\\\", \\\"{x:474,y:468,t:1527272321203};\\\", \\\"{x:473,y:468,t:1527272321244};\\\", \\\"{x:472,y:468,t:1527272321259};\\\", \\\"{x:469,y:469,t:1527272321276};\\\", \\\"{x:466,y:469,t:1527272321293};\\\", \\\"{x:460,y:469,t:1527272321309};\\\", \\\"{x:456,y:469,t:1527272321327};\\\", \\\"{x:454,y:469,t:1527272321343};\\\", \\\"{x:450,y:469,t:1527272321359};\\\", \\\"{x:448,y:468,t:1527272321376};\\\", \\\"{x:445,y:466,t:1527272321393};\\\", \\\"{x:444,y:466,t:1527272321409};\\\", \\\"{x:444,y:465,t:1527272321492};\\\", \\\"{x:445,y:465,t:1527272321516};\\\", \\\"{x:446,y:465,t:1527272321532};\\\", \\\"{x:447,y:465,t:1527272321548};\\\", \\\"{x:448,y:465,t:1527272321564};\\\", \\\"{x:448,y:464,t:1527272321604};\\\", \\\"{x:449,y:463,t:1527272321612};\\\", \\\"{x:451,y:462,t:1527272321628};\\\", \\\"{x:451,y:461,t:1527272321642};\\\", \\\"{x:453,y:459,t:1527272321659};\\\", \\\"{x:454,y:457,t:1527272321675};\\\", \\\"{x:453,y:457,t:1527272321781};\\\", \\\"{x:452,y:457,t:1527272321793};\\\", \\\"{x:451,y:457,t:1527272321861};\\\", \\\"{x:451,y:456,t:1527272321941};\\\", \\\"{x:452,y:456,t:1527272321949};\\\", \\\"{x:455,y:455,t:1527272321959};\\\", \\\"{x:460,y:454,t:1527272321976};\\\", \\\"{x:463,y:453,t:1527272321993};\\\", \\\"{x:465,y:453,t:1527272322008};\\\", \\\"{x:465,y:452,t:1527272322029};\\\", \\\"{x:465,y:451,t:1527272322077};\\\", \\\"{x:465,y:450,t:1527272322100};\\\", \\\"{x:465,y:449,t:1527272322180};\\\", \\\"{x:466,y:448,t:1527272322309};\\\", \\\"{x:470,y:448,t:1527272322324};\\\", \\\"{x:474,y:449,t:1527272322341};\\\", \\\"{x:475,y:449,t:1527272322358};\\\", \\\"{x:477,y:449,t:1527272322374};\\\", \\\"{x:478,y:449,t:1527272322404};\\\", \\\"{x:480,y:449,t:1527272322589};\\\", \\\"{x:484,y:449,t:1527272322596};\\\", \\\"{x:488,y:449,t:1527272322608};\\\", \\\"{x:495,y:452,t:1527272322624};\\\", \\\"{x:498,y:453,t:1527272322641};\\\", \\\"{x:500,y:453,t:1527272322657};\\\", \\\"{x:501,y:453,t:1527272322684};\\\", \\\"{x:502,y:453,t:1527272322692};\\\", \\\"{x:505,y:453,t:1527272322707};\\\", \\\"{x:514,y:453,t:1527272322725};\\\", \\\"{x:521,y:453,t:1527272322740};\\\", \\\"{x:522,y:453,t:1527272322757};\\\", \\\"{x:523,y:453,t:1527272322774};\\\", \\\"{x:525,y:453,t:1527272322837};\\\", \\\"{x:527,y:453,t:1527272322853};\\\", \\\"{x:529,y:453,t:1527272322860};\\\", \\\"{x:532,y:453,t:1527272322874};\\\", \\\"{x:532,y:452,t:1527272362036};\\\", \\\"{x:532,y:448,t:1527272362049};\\\", \\\"{x:532,y:405,t:1527272362066};\\\", \\\"{x:532,y:370,t:1527272362082};\\\", \\\"{x:527,y:348,t:1527272362100};\\\", \\\"{x:521,y:336,t:1527272362115};\\\", \\\"{x:516,y:324,t:1527272362133};\\\", \\\"{x:515,y:313,t:1527272362149};\\\", \\\"{x:514,y:306,t:1527272362166};\\\", \\\"{x:514,y:305,t:1527272362182};\\\", \\\"{x:514,y:307,t:1527272362236};\\\", \\\"{x:519,y:320,t:1527272362249};\\\", \\\"{x:537,y:349,t:1527272362265};\\\", \\\"{x:551,y:367,t:1527272362282};\\\", \\\"{x:570,y:387,t:1527272362299};\\\", \\\"{x:591,y:401,t:1527272362316};\\\", \\\"{x:613,y:418,t:1527272362332};\\\", \\\"{x:637,y:432,t:1527272362350};\\\", \\\"{x:648,y:440,t:1527272362365};\\\", \\\"{x:657,y:447,t:1527272362383};\\\", \\\"{x:666,y:453,t:1527272362400};\\\", \\\"{x:691,y:470,t:1527272362416};\\\", \\\"{x:710,y:480,t:1527272362432};\\\", \\\"{x:713,y:481,t:1527272362448};\\\", \\\"{x:710,y:481,t:1527272362500};\\\", \\\"{x:706,y:481,t:1527272362516};\\\", \\\"{x:699,y:484,t:1527272362531};\\\", \\\"{x:692,y:485,t:1527272362548};\\\", \\\"{x:687,y:486,t:1527272362565};\\\", \\\"{x:674,y:491,t:1527272362584};\\\", \\\"{x:662,y:497,t:1527272362597};\\\", \\\"{x:657,y:503,t:1527272362615};\\\", \\\"{x:654,y:508,t:1527272362625};\\\", \\\"{x:653,y:515,t:1527272362642};\\\", \\\"{x:651,y:519,t:1527272362660};\\\", \\\"{x:651,y:520,t:1527272362675};\\\", \\\"{x:650,y:519,t:1527272362747};\\\", \\\"{x:647,y:519,t:1527272362760};\\\", \\\"{x:645,y:519,t:1527272362776};\\\", \\\"{x:643,y:519,t:1527272362793};\\\", \\\"{x:640,y:519,t:1527272362810};\\\", \\\"{x:636,y:524,t:1527272362826};\\\", \\\"{x:632,y:529,t:1527272362844};\\\", \\\"{x:622,y:537,t:1527272362860};\\\", \\\"{x:618,y:541,t:1527272362877};\\\", \\\"{x:618,y:543,t:1527272362893};\\\", \\\"{x:618,y:544,t:1527272362909};\\\", \\\"{x:623,y:545,t:1527272362927};\\\", \\\"{x:640,y:547,t:1527272362943};\\\", \\\"{x:662,y:547,t:1527272362961};\\\", \\\"{x:703,y:541,t:1527272362977};\\\", \\\"{x:760,y:538,t:1527272362994};\\\", \\\"{x:826,y:532,t:1527272363011};\\\", \\\"{x:877,y:530,t:1527272363027};\\\", \\\"{x:908,y:530,t:1527272363043};\\\", \\\"{x:922,y:530,t:1527272363060};\\\", \\\"{x:923,y:530,t:1527272363091};\\\", \\\"{x:923,y:527,t:1527272363148};\\\", \\\"{x:922,y:527,t:1527272363161};\\\", \\\"{x:917,y:523,t:1527272363178};\\\", \\\"{x:911,y:517,t:1527272363193};\\\", \\\"{x:896,y:505,t:1527272363210};\\\", \\\"{x:883,y:497,t:1527272363226};\\\", \\\"{x:867,y:491,t:1527272363243};\\\", \\\"{x:852,y:487,t:1527272363259};\\\", \\\"{x:845,y:485,t:1527272363278};\\\", \\\"{x:844,y:485,t:1527272363293};\\\", \\\"{x:843,y:485,t:1527272363364};\\\", \\\"{x:843,y:487,t:1527272363380};\\\", \\\"{x:843,y:488,t:1527272363394};\\\", \\\"{x:843,y:492,t:1527272363411};\\\", \\\"{x:843,y:496,t:1527272363427};\\\", \\\"{x:846,y:502,t:1527272363443};\\\", \\\"{x:846,y:506,t:1527272363459};\\\", \\\"{x:846,y:507,t:1527272363998};\\\", \\\"{x:843,y:507,t:1527272364070};\\\", \\\"{x:837,y:507,t:1527272364081};\\\", \\\"{x:818,y:502,t:1527272364097};\\\", \\\"{x:808,y:500,t:1527272364114};\\\", \\\"{x:803,y:499,t:1527272364131};\\\", \\\"{x:799,y:498,t:1527272364146};\\\", \\\"{x:796,y:498,t:1527272364164};\\\", \\\"{x:794,y:498,t:1527272364198};\\\", \\\"{x:791,y:498,t:1527272364214};\\\", \\\"{x:777,y:499,t:1527272364231};\\\", \\\"{x:769,y:501,t:1527272364247};\\\", \\\"{x:755,y:504,t:1527272364264};\\\", \\\"{x:745,y:505,t:1527272364281};\\\", \\\"{x:734,y:505,t:1527272364297};\\\", \\\"{x:724,y:506,t:1527272364314};\\\", \\\"{x:708,y:509,t:1527272364331};\\\", \\\"{x:697,y:510,t:1527272364347};\\\", \\\"{x:682,y:510,t:1527272364364};\\\", \\\"{x:668,y:512,t:1527272364381};\\\", \\\"{x:657,y:516,t:1527272364397};\\\", \\\"{x:654,y:518,t:1527272364415};\\\", \\\"{x:649,y:522,t:1527272364431};\\\", \\\"{x:642,y:525,t:1527272364447};\\\", \\\"{x:630,y:531,t:1527272364465};\\\", \\\"{x:617,y:534,t:1527272364480};\\\", \\\"{x:596,y:539,t:1527272364497};\\\", \\\"{x:580,y:543,t:1527272364514};\\\", \\\"{x:565,y:545,t:1527272364531};\\\", \\\"{x:551,y:548,t:1527272364548};\\\", \\\"{x:536,y:548,t:1527272364564};\\\", \\\"{x:521,y:548,t:1527272364581};\\\", \\\"{x:498,y:548,t:1527272364599};\\\", \\\"{x:490,y:548,t:1527272364614};\\\", \\\"{x:472,y:548,t:1527272364630};\\\", \\\"{x:466,y:548,t:1527272364648};\\\", \\\"{x:460,y:548,t:1527272364663};\\\", \\\"{x:452,y:548,t:1527272364681};\\\", \\\"{x:442,y:549,t:1527272364698};\\\", \\\"{x:433,y:551,t:1527272364713};\\\", \\\"{x:424,y:552,t:1527272364731};\\\", \\\"{x:420,y:553,t:1527272364747};\\\", \\\"{x:417,y:554,t:1527272364764};\\\", \\\"{x:414,y:555,t:1527272364781};\\\", \\\"{x:411,y:557,t:1527272364799};\\\", \\\"{x:408,y:560,t:1527272364814};\\\", \\\"{x:402,y:566,t:1527272364831};\\\", \\\"{x:399,y:568,t:1527272364847};\\\", \\\"{x:396,y:571,t:1527272364864};\\\", \\\"{x:392,y:572,t:1527272364881};\\\", \\\"{x:386,y:575,t:1527272364898};\\\", \\\"{x:378,y:576,t:1527272364915};\\\", \\\"{x:362,y:579,t:1527272364931};\\\", \\\"{x:346,y:579,t:1527272364948};\\\", \\\"{x:332,y:577,t:1527272364964};\\\", \\\"{x:315,y:571,t:1527272364981};\\\", \\\"{x:297,y:569,t:1527272364998};\\\", \\\"{x:272,y:567,t:1527272365015};\\\", \\\"{x:257,y:567,t:1527272365031};\\\", \\\"{x:237,y:571,t:1527272365048};\\\", \\\"{x:220,y:579,t:1527272365065};\\\", \\\"{x:208,y:584,t:1527272365081};\\\", \\\"{x:202,y:589,t:1527272365098};\\\", \\\"{x:194,y:593,t:1527272365115};\\\", \\\"{x:186,y:598,t:1527272365132};\\\", \\\"{x:175,y:604,t:1527272365148};\\\", \\\"{x:162,y:612,t:1527272365165};\\\", \\\"{x:153,y:621,t:1527272365180};\\\", \\\"{x:145,y:628,t:1527272365198};\\\", \\\"{x:139,y:631,t:1527272365214};\\\", \\\"{x:133,y:634,t:1527272365231};\\\", \\\"{x:122,y:638,t:1527272365247};\\\", \\\"{x:119,y:639,t:1527272365265};\\\", \\\"{x:118,y:639,t:1527272365294};\\\", \\\"{x:116,y:639,t:1527272365310};\\\", \\\"{x:116,y:637,t:1527272365318};\\\", \\\"{x:114,y:635,t:1527272365331};\\\", \\\"{x:113,y:633,t:1527272365347};\\\", \\\"{x:114,y:631,t:1527272365365};\\\", \\\"{x:128,y:623,t:1527272365381};\\\", \\\"{x:158,y:607,t:1527272365398};\\\", \\\"{x:171,y:593,t:1527272365416};\\\", \\\"{x:179,y:581,t:1527272365431};\\\", \\\"{x:180,y:573,t:1527272365447};\\\", \\\"{x:180,y:569,t:1527272365465};\\\", \\\"{x:180,y:564,t:1527272365481};\\\", \\\"{x:179,y:560,t:1527272365499};\\\", \\\"{x:178,y:560,t:1527272365515};\\\", \\\"{x:178,y:559,t:1527272365532};\\\", \\\"{x:177,y:559,t:1527272365547};\\\", \\\"{x:177,y:558,t:1527272365565};\\\", \\\"{x:174,y:556,t:1527272365582};\\\", \\\"{x:172,y:555,t:1527272365599};\\\", \\\"{x:167,y:551,t:1527272365615};\\\", \\\"{x:164,y:550,t:1527272365630};\\\", \\\"{x:161,y:547,t:1527272365647};\\\", \\\"{x:161,y:545,t:1527272365726};\\\", \\\"{x:161,y:544,t:1527272365742};\\\", \\\"{x:165,y:543,t:1527272365966};\\\", \\\"{x:257,y:546,t:1527272365982};\\\", \\\"{x:392,y:581,t:1527272366000};\\\", \\\"{x:497,y:609,t:1527272366015};\\\", \\\"{x:554,y:629,t:1527272366032};\\\", \\\"{x:563,y:634,t:1527272366049};\\\", \\\"{x:566,y:636,t:1527272366099};\\\", \\\"{x:575,y:646,t:1527272366115};\\\", \\\"{x:583,y:656,t:1527272366131};\\\", \\\"{x:587,y:664,t:1527272366149};\\\", \\\"{x:587,y:672,t:1527272366165};\\\", \\\"{x:560,y:683,t:1527272366182};\\\", \\\"{x:537,y:690,t:1527272366198};\\\", \\\"{x:521,y:695,t:1527272366215};\\\", \\\"{x:515,y:698,t:1527272366232};\\\", \\\"{x:512,y:702,t:1527272366249};\\\", \\\"{x:512,y:706,t:1527272366265};\\\", \\\"{x:510,y:708,t:1527272366282};\\\", \\\"{x:508,y:710,t:1527272366300};\\\", \\\"{x:508,y:713,t:1527272366316};\\\", \\\"{x:507,y:716,t:1527272366332};\\\", \\\"{x:506,y:721,t:1527272366351};\\\", \\\"{x:506,y:730,t:1527272366365};\\\", \\\"{x:506,y:731,t:1527272366381};\\\", \\\"{x:507,y:735,t:1527272366398};\\\", \\\"{x:507,y:736,t:1527272366422};\\\", \\\"{x:507,y:737,t:1527272366446};\\\", \\\"{x:507,y:738,t:1527272366454};\\\", \\\"{x:507,y:739,t:1527272366478};\\\", \\\"{x:507,y:741,t:1527272366486};\\\", \\\"{x:507,y:742,t:1527272366498};\\\", \\\"{x:507,y:743,t:1527272366514};\\\", \\\"{x:507,y:744,t:1527272366542};\\\", \\\"{x:506,y:744,t:1527272366734};\\\", \\\"{x:505,y:743,t:1527272366748};\\\", \\\"{x:504,y:742,t:1527272367007};\\\", \\\"{x:503,y:740,t:1527272367023};\\\", \\\"{x:503,y:737,t:1527272367033};\\\", \\\"{x:504,y:733,t:1527272367050};\\\", \\\"{x:523,y:723,t:1527272367067};\\\", \\\"{x:577,y:714,t:1527272367084};\\\", \\\"{x:682,y:714,t:1527272367100};\\\", \\\"{x:813,y:719,t:1527272367116};\\\", \\\"{x:966,y:743,t:1527272367133};\\\", \\\"{x:1147,y:766,t:1527272367150};\\\", \\\"{x:1180,y:766,t:1527272367166};\\\", \\\"{x:1205,y:769,t:1527272367182};\\\", \\\"{x:1206,y:770,t:1527272367199};\\\", \\\"{x:1204,y:770,t:1527272367239};\\\", \\\"{x:1203,y:770,t:1527272367250};\\\", \\\"{x:1201,y:770,t:1527272367266};\\\", \\\"{x:1199,y:770,t:1527272367283};\\\", \\\"{x:1196,y:770,t:1527272367300};\\\", \\\"{x:1193,y:770,t:1527272367316};\\\", \\\"{x:1190,y:770,t:1527272367333};\\\", \\\"{x:1189,y:769,t:1527272367351};\\\", \\\"{x:1189,y:768,t:1527272367367};\\\", \\\"{x:1184,y:768,t:1527272367383};\\\", \\\"{x:1179,y:768,t:1527272367400};\\\", \\\"{x:1175,y:765,t:1527272367416};\\\", \\\"{x:1171,y:765,t:1527272367433};\\\", \\\"{x:1170,y:765,t:1527272367450};\\\", \\\"{x:1170,y:764,t:1527272367502};\\\", \\\"{x:1169,y:764,t:1527272367559};\\\", \\\"{x:1169,y:763,t:1527272367567};\\\", \\\"{x:1167,y:761,t:1527272367583};\\\", \\\"{x:1167,y:758,t:1527272367600};\\\", \\\"{x:1163,y:756,t:1527272367617};\\\", \\\"{x:1158,y:755,t:1527272367633};\\\", \\\"{x:1156,y:753,t:1527272367650};\\\", \\\"{x:1149,y:750,t:1527272367667};\\\", \\\"{x:1141,y:748,t:1527272367683};\\\", \\\"{x:1135,y:743,t:1527272367700};\\\", \\\"{x:1119,y:730,t:1527272367760};\\\", \\\"{x:1119,y:728,t:1527272367767};\\\", \\\"{x:1118,y:727,t:1527272367910};\\\", \\\"{x:1117,y:726,t:1527272367926};\\\", \\\"{x:1117,y:725,t:1527272367942};\\\", \\\"{x:1117,y:724,t:1527272367966};\\\", \\\"{x:1116,y:724,t:1527272367974};\\\", \\\"{x:1116,y:723,t:1527272367998};\\\", \\\"{x:1116,y:722,t:1527272368014};\\\", \\\"{x:1116,y:720,t:1527272368022};\\\", \\\"{x:1117,y:718,t:1527272368033};\\\", \\\"{x:1118,y:715,t:1527272368050};\\\" ] }, { \\\"rt\\\": 62909, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 967511, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -C -X -B -J -J -J -E -X -X -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1141,y:700,t:1527272368246};\\\", \\\"{x:1141,y:697,t:1527272368480};\\\", \\\"{x:1141,y:696,t:1527272368486};\\\", \\\"{x:1140,y:695,t:1527272368518};\\\", \\\"{x:1117,y:691,t:1527272368534};\\\", \\\"{x:1090,y:685,t:1527272368551};\\\", \\\"{x:1061,y:676,t:1527272368567};\\\", \\\"{x:1030,y:667,t:1527272368584};\\\", \\\"{x:1004,y:661,t:1527272368601};\\\", \\\"{x:982,y:654,t:1527272368617};\\\", \\\"{x:963,y:649,t:1527272368634};\\\", \\\"{x:956,y:643,t:1527272368651};\\\", \\\"{x:956,y:638,t:1527272368667};\\\", \\\"{x:963,y:624,t:1527272368684};\\\", \\\"{x:982,y:595,t:1527272368701};\\\", \\\"{x:1006,y:557,t:1527272368717};\\\", \\\"{x:1047,y:513,t:1527272368734};\\\", \\\"{x:1076,y:505,t:1527272368751};\\\", \\\"{x:1104,y:504,t:1527272368767};\\\", \\\"{x:1139,y:501,t:1527272368785};\\\", \\\"{x:1196,y:498,t:1527272368801};\\\", \\\"{x:1299,y:498,t:1527272368818};\\\", \\\"{x:1422,y:524,t:1527272368834};\\\", \\\"{x:1514,y:566,t:1527272368851};\\\", \\\"{x:1581,y:612,t:1527272368867};\\\", \\\"{x:1622,y:640,t:1527272368885};\\\", \\\"{x:1643,y:651,t:1527272368902};\\\", \\\"{x:1663,y:659,t:1527272368918};\\\", \\\"{x:1666,y:659,t:1527272368935};\\\", \\\"{x:1667,y:659,t:1527272368952};\\\", \\\"{x:1676,y:649,t:1527272368968};\\\", \\\"{x:1683,y:629,t:1527272368984};\\\", \\\"{x:1685,y:611,t:1527272369002};\\\", \\\"{x:1685,y:605,t:1527272369018};\\\", \\\"{x:1683,y:600,t:1527272369034};\\\", \\\"{x:1667,y:592,t:1527272369052};\\\", \\\"{x:1593,y:568,t:1527272369069};\\\", \\\"{x:1480,y:537,t:1527272369084};\\\", \\\"{x:1399,y:524,t:1527272369102};\\\", \\\"{x:1361,y:524,t:1527272369119};\\\", \\\"{x:1353,y:525,t:1527272369134};\\\", \\\"{x:1332,y:541,t:1527272369151};\\\", \\\"{x:1316,y:560,t:1527272369169};\\\", \\\"{x:1305,y:582,t:1527272369185};\\\", \\\"{x:1303,y:592,t:1527272369202};\\\", \\\"{x:1303,y:600,t:1527272369219};\\\", \\\"{x:1303,y:604,t:1527272369235};\\\", \\\"{x:1304,y:604,t:1527272369327};\\\", \\\"{x:1306,y:603,t:1527272369343};\\\", \\\"{x:1308,y:594,t:1527272369351};\\\", \\\"{x:1314,y:577,t:1527272369368};\\\", \\\"{x:1315,y:571,t:1527272369385};\\\", \\\"{x:1317,y:567,t:1527272369402};\\\", \\\"{x:1318,y:566,t:1527272369418};\\\", \\\"{x:1319,y:565,t:1527272369436};\\\", \\\"{x:1319,y:564,t:1527272369452};\\\", \\\"{x:1320,y:563,t:1527272369469};\\\", \\\"{x:1321,y:563,t:1527272369551};\\\", \\\"{x:1325,y:563,t:1527272370119};\\\", \\\"{x:1359,y:576,t:1527272370136};\\\", \\\"{x:1447,y:615,t:1527272370153};\\\", \\\"{x:1571,y:666,t:1527272370169};\\\", \\\"{x:1709,y:725,t:1527272370185};\\\", \\\"{x:1859,y:776,t:1527272370202};\\\", \\\"{x:1919,y:816,t:1527272370220};\\\", \\\"{x:1919,y:830,t:1527272370235};\\\", \\\"{x:1919,y:833,t:1527272370252};\\\", \\\"{x:1919,y:832,t:1527272370268};\\\", \\\"{x:1919,y:831,t:1527272370285};\\\", \\\"{x:1919,y:829,t:1527272370407};\\\", \\\"{x:1919,y:828,t:1527272370417};\\\", \\\"{x:1919,y:826,t:1527272370434};\\\", \\\"{x:1919,y:822,t:1527272370451};\\\", \\\"{x:1919,y:817,t:1527272370468};\\\", \\\"{x:1919,y:815,t:1527272370485};\\\", \\\"{x:1919,y:811,t:1527272370501};\\\", \\\"{x:1919,y:810,t:1527272370517};\\\", \\\"{x:1919,y:809,t:1527272370534};\\\", \\\"{x:1919,y:808,t:1527272370559};\\\", \\\"{x:1919,y:807,t:1527272370590};\\\", \\\"{x:1919,y:805,t:1527272370602};\\\", \\\"{x:1918,y:802,t:1527272370618};\\\", \\\"{x:1913,y:798,t:1527272370634};\\\", \\\"{x:1904,y:792,t:1527272370652};\\\", \\\"{x:1889,y:783,t:1527272370668};\\\", \\\"{x:1873,y:776,t:1527272370684};\\\", \\\"{x:1852,y:766,t:1527272370703};\\\", \\\"{x:1849,y:764,t:1527272370720};\\\", \\\"{x:1848,y:764,t:1527272370823};\\\", \\\"{x:1847,y:764,t:1527272370839};\\\", \\\"{x:1846,y:764,t:1527272370855};\\\", \\\"{x:1844,y:762,t:1527272370871};\\\", \\\"{x:1843,y:762,t:1527272370975};\\\", \\\"{x:1843,y:761,t:1527272371007};\\\", \\\"{x:1842,y:761,t:1527272371020};\\\", \\\"{x:1839,y:759,t:1527272371036};\\\", \\\"{x:1836,y:757,t:1527272371054};\\\", \\\"{x:1835,y:757,t:1527272371070};\\\", \\\"{x:1835,y:756,t:1527272371086};\\\", \\\"{x:1835,y:755,t:1527272371111};\\\", \\\"{x:1836,y:755,t:1527272371119};\\\", \\\"{x:1836,y:753,t:1527272371137};\\\", \\\"{x:1836,y:751,t:1527272371159};\\\", \\\"{x:1836,y:750,t:1527272371170};\\\", \\\"{x:1836,y:749,t:1527272371186};\\\", \\\"{x:1837,y:748,t:1527272371222};\\\", \\\"{x:1838,y:747,t:1527272371246};\\\", \\\"{x:1839,y:746,t:1527272371254};\\\", \\\"{x:1839,y:745,t:1527272372143};\\\", \\\"{x:1838,y:745,t:1527272372159};\\\", \\\"{x:1837,y:745,t:1527272372183};\\\", \\\"{x:1836,y:744,t:1527272378319};\\\", \\\"{x:1836,y:743,t:1527272378391};\\\", \\\"{x:1835,y:742,t:1527272378431};\\\", \\\"{x:1831,y:740,t:1527272378442};\\\", \\\"{x:1826,y:738,t:1527272378459};\\\", \\\"{x:1818,y:736,t:1527272378476};\\\", \\\"{x:1817,y:736,t:1527272378491};\\\", \\\"{x:1816,y:736,t:1527272378527};\\\", \\\"{x:1815,y:740,t:1527272378542};\\\", \\\"{x:1815,y:763,t:1527272378559};\\\", \\\"{x:1815,y:784,t:1527272378576};\\\", \\\"{x:1815,y:796,t:1527272378593};\\\", \\\"{x:1815,y:801,t:1527272378609};\\\", \\\"{x:1814,y:801,t:1527272378687};\\\", \\\"{x:1812,y:801,t:1527272378694};\\\", \\\"{x:1808,y:801,t:1527272378709};\\\", \\\"{x:1789,y:800,t:1527272378726};\\\", \\\"{x:1737,y:800,t:1527272378742};\\\", \\\"{x:1711,y:801,t:1527272378759};\\\", \\\"{x:1693,y:807,t:1527272378776};\\\", \\\"{x:1668,y:812,t:1527272378793};\\\", \\\"{x:1658,y:815,t:1527272378808};\\\", \\\"{x:1653,y:815,t:1527272378826};\\\", \\\"{x:1651,y:815,t:1527272378842};\\\", \\\"{x:1649,y:815,t:1527272378859};\\\", \\\"{x:1646,y:816,t:1527272378876};\\\", \\\"{x:1635,y:817,t:1527272378893};\\\", \\\"{x:1624,y:818,t:1527272378908};\\\", \\\"{x:1613,y:821,t:1527272378925};\\\", \\\"{x:1586,y:821,t:1527272378942};\\\", \\\"{x:1554,y:821,t:1527272378958};\\\", \\\"{x:1518,y:821,t:1527272378976};\\\", \\\"{x:1484,y:821,t:1527272378992};\\\", \\\"{x:1451,y:821,t:1527272379010};\\\", \\\"{x:1419,y:819,t:1527272379025};\\\", \\\"{x:1363,y:809,t:1527272379043};\\\", \\\"{x:1301,y:790,t:1527272379060};\\\", \\\"{x:1230,y:772,t:1527272379076};\\\", \\\"{x:1184,y:757,t:1527272379092};\\\", \\\"{x:1173,y:753,t:1527272379110};\\\", \\\"{x:1174,y:753,t:1527272379223};\\\", \\\"{x:1183,y:753,t:1527272379231};\\\", \\\"{x:1200,y:753,t:1527272379243};\\\", \\\"{x:1230,y:753,t:1527272379260};\\\", \\\"{x:1248,y:753,t:1527272379276};\\\", \\\"{x:1263,y:752,t:1527272379293};\\\", \\\"{x:1282,y:749,t:1527272379310};\\\", \\\"{x:1290,y:747,t:1527272379326};\\\", \\\"{x:1292,y:745,t:1527272379343};\\\", \\\"{x:1294,y:745,t:1527272379360};\\\", \\\"{x:1296,y:745,t:1527272379511};\\\", \\\"{x:1306,y:747,t:1527272379527};\\\", \\\"{x:1319,y:757,t:1527272379544};\\\", \\\"{x:1330,y:765,t:1527272379560};\\\", \\\"{x:1337,y:771,t:1527272379577};\\\", \\\"{x:1342,y:771,t:1527272379593};\\\", \\\"{x:1343,y:772,t:1527272379609};\\\", \\\"{x:1343,y:770,t:1527272380271};\\\", \\\"{x:1344,y:766,t:1527272380281};\\\", \\\"{x:1347,y:765,t:1527272380293};\\\", \\\"{x:1348,y:763,t:1527272380310};\\\", \\\"{x:1348,y:765,t:1527272388054};\\\", \\\"{x:1344,y:775,t:1527272388067};\\\", \\\"{x:1339,y:784,t:1527272388083};\\\", \\\"{x:1335,y:788,t:1527272388101};\\\", \\\"{x:1331,y:793,t:1527272388117};\\\", \\\"{x:1328,y:796,t:1527272388133};\\\", \\\"{x:1326,y:798,t:1527272388150};\\\", \\\"{x:1324,y:799,t:1527272388167};\\\", \\\"{x:1322,y:801,t:1527272388183};\\\", \\\"{x:1321,y:802,t:1527272388201};\\\", \\\"{x:1321,y:803,t:1527272388216};\\\", \\\"{x:1320,y:804,t:1527272388234};\\\", \\\"{x:1318,y:805,t:1527272388250};\\\", \\\"{x:1315,y:807,t:1527272388267};\\\", \\\"{x:1313,y:808,t:1527272388283};\\\", \\\"{x:1312,y:808,t:1527272388300};\\\", \\\"{x:1309,y:808,t:1527272388317};\\\", \\\"{x:1308,y:809,t:1527272388334};\\\", \\\"{x:1300,y:812,t:1527272388351};\\\", \\\"{x:1297,y:813,t:1527272388368};\\\", \\\"{x:1297,y:814,t:1527272388384};\\\", \\\"{x:1297,y:817,t:1527272388401};\\\", \\\"{x:1300,y:819,t:1527272388418};\\\", \\\"{x:1304,y:820,t:1527272388433};\\\", \\\"{x:1303,y:820,t:1527272388559};\\\", \\\"{x:1300,y:820,t:1527272388567};\\\", \\\"{x:1296,y:820,t:1527272388583};\\\", \\\"{x:1289,y:820,t:1527272388599};\\\", \\\"{x:1285,y:820,t:1527272388617};\\\", \\\"{x:1282,y:821,t:1527272388633};\\\", \\\"{x:1277,y:823,t:1527272388649};\\\", \\\"{x:1270,y:826,t:1527272388667};\\\", \\\"{x:1267,y:827,t:1527272388683};\\\", \\\"{x:1263,y:828,t:1527272388700};\\\", \\\"{x:1262,y:830,t:1527272388717};\\\", \\\"{x:1261,y:830,t:1527272388734};\\\", \\\"{x:1258,y:832,t:1527272388751};\\\", \\\"{x:1257,y:832,t:1527272388775};\\\", \\\"{x:1254,y:832,t:1527272388799};\\\", \\\"{x:1253,y:832,t:1527272388807};\\\", \\\"{x:1249,y:832,t:1527272388839};\\\", \\\"{x:1248,y:833,t:1527272388895};\\\", \\\"{x:1246,y:833,t:1527272388911};\\\", \\\"{x:1245,y:833,t:1527272388927};\\\", \\\"{x:1244,y:833,t:1527272389263};\\\", \\\"{x:1242,y:834,t:1527272389271};\\\", \\\"{x:1238,y:836,t:1527272389284};\\\", \\\"{x:1231,y:837,t:1527272389302};\\\", \\\"{x:1228,y:840,t:1527272389317};\\\", \\\"{x:1228,y:843,t:1527272389335};\\\", \\\"{x:1228,y:850,t:1527272389351};\\\", \\\"{x:1232,y:855,t:1527272389367};\\\", \\\"{x:1235,y:865,t:1527272389384};\\\", \\\"{x:1237,y:873,t:1527272389401};\\\", \\\"{x:1241,y:885,t:1527272389417};\\\", \\\"{x:1247,y:902,t:1527272389434};\\\", \\\"{x:1254,y:915,t:1527272389452};\\\", \\\"{x:1269,y:936,t:1527272389468};\\\", \\\"{x:1282,y:950,t:1527272389485};\\\", \\\"{x:1289,y:959,t:1527272389502};\\\", \\\"{x:1290,y:961,t:1527272389517};\\\", \\\"{x:1292,y:962,t:1527272389535};\\\", \\\"{x:1292,y:958,t:1527272389591};\\\", \\\"{x:1287,y:948,t:1527272389602};\\\", \\\"{x:1265,y:908,t:1527272389618};\\\", \\\"{x:1238,y:877,t:1527272389635};\\\", \\\"{x:1212,y:859,t:1527272389652};\\\", \\\"{x:1194,y:848,t:1527272389667};\\\", \\\"{x:1185,y:839,t:1527272389685};\\\", \\\"{x:1175,y:834,t:1527272389702};\\\", \\\"{x:1170,y:831,t:1527272389719};\\\", \\\"{x:1169,y:831,t:1527272389775};\\\", \\\"{x:1169,y:824,t:1527272389785};\\\", \\\"{x:1167,y:807,t:1527272389801};\\\", \\\"{x:1166,y:799,t:1527272389819};\\\", \\\"{x:1166,y:798,t:1527272389834};\\\", \\\"{x:1168,y:798,t:1527272389852};\\\", \\\"{x:1179,y:798,t:1527272389868};\\\", \\\"{x:1187,y:801,t:1527272389884};\\\", \\\"{x:1191,y:804,t:1527272389901};\\\", \\\"{x:1194,y:805,t:1527272389918};\\\", \\\"{x:1195,y:805,t:1527272389958};\\\", \\\"{x:1196,y:805,t:1527272389982};\\\", \\\"{x:1199,y:809,t:1527272389991};\\\", \\\"{x:1201,y:810,t:1527272390001};\\\", \\\"{x:1207,y:815,t:1527272390018};\\\", \\\"{x:1210,y:818,t:1527272390035};\\\", \\\"{x:1212,y:820,t:1527272390051};\\\", \\\"{x:1213,y:821,t:1527272390068};\\\", \\\"{x:1214,y:821,t:1527272390085};\\\", \\\"{x:1216,y:822,t:1527272390125};\\\", \\\"{x:1217,y:823,t:1527272390135};\\\", \\\"{x:1220,y:823,t:1527272390150};\\\", \\\"{x:1221,y:824,t:1527272390168};\\\", \\\"{x:1222,y:824,t:1527272390185};\\\", \\\"{x:1223,y:825,t:1527272390201};\\\", \\\"{x:1221,y:825,t:1527272391871};\\\", \\\"{x:1219,y:827,t:1527272391887};\\\", \\\"{x:1217,y:828,t:1527272391902};\\\", \\\"{x:1213,y:830,t:1527272391920};\\\", \\\"{x:1208,y:832,t:1527272391937};\\\", \\\"{x:1205,y:833,t:1527272391954};\\\", \\\"{x:1205,y:834,t:1527272391969};\\\", \\\"{x:1206,y:834,t:1527272392399};\\\", \\\"{x:1207,y:834,t:1527272392407};\\\", \\\"{x:1211,y:826,t:1527272393831};\\\", \\\"{x:1219,y:783,t:1527272393855};\\\", \\\"{x:1221,y:762,t:1527272393872};\\\", \\\"{x:1223,y:752,t:1527272393888};\\\", \\\"{x:1224,y:744,t:1527272393905};\\\", \\\"{x:1224,y:743,t:1527272393921};\\\", \\\"{x:1224,y:742,t:1527272393951};\\\", \\\"{x:1225,y:740,t:1527272393974};\\\", \\\"{x:1225,y:735,t:1527272393987};\\\", \\\"{x:1226,y:722,t:1527272394005};\\\", \\\"{x:1228,y:704,t:1527272394022};\\\", \\\"{x:1228,y:687,t:1527272394038};\\\", \\\"{x:1229,y:670,t:1527272394055};\\\", \\\"{x:1230,y:664,t:1527272394072};\\\", \\\"{x:1234,y:654,t:1527272394089};\\\", \\\"{x:1238,y:648,t:1527272394105};\\\", \\\"{x:1244,y:640,t:1527272394122};\\\", \\\"{x:1249,y:630,t:1527272394139};\\\", \\\"{x:1252,y:624,t:1527272394155};\\\", \\\"{x:1253,y:618,t:1527272394172};\\\", \\\"{x:1257,y:609,t:1527272394189};\\\", \\\"{x:1262,y:598,t:1527272394205};\\\", \\\"{x:1263,y:592,t:1527272394221};\\\", \\\"{x:1265,y:587,t:1527272394238};\\\", \\\"{x:1265,y:586,t:1527272394263};\\\", \\\"{x:1266,y:585,t:1527272394272};\\\", \\\"{x:1268,y:582,t:1527272394289};\\\", \\\"{x:1271,y:574,t:1527272394305};\\\", \\\"{x:1276,y:565,t:1527272394322};\\\", \\\"{x:1279,y:559,t:1527272394339};\\\", \\\"{x:1280,y:559,t:1527272394355};\\\", \\\"{x:1281,y:558,t:1527272394372};\\\", \\\"{x:1280,y:558,t:1527272395246};\\\", \\\"{x:1280,y:559,t:1527272400782};\\\", \\\"{x:1280,y:560,t:1527272400793};\\\", \\\"{x:1288,y:564,t:1527272400811};\\\", \\\"{x:1294,y:567,t:1527272400827};\\\", \\\"{x:1298,y:568,t:1527272400844};\\\", \\\"{x:1299,y:568,t:1527272400860};\\\", \\\"{x:1300,y:568,t:1527272400911};\\\", \\\"{x:1301,y:568,t:1527272400927};\\\", \\\"{x:1306,y:568,t:1527272400944};\\\", \\\"{x:1313,y:568,t:1527272400960};\\\", \\\"{x:1321,y:568,t:1527272400978};\\\", \\\"{x:1326,y:568,t:1527272400994};\\\", \\\"{x:1327,y:568,t:1527272401011};\\\", \\\"{x:1328,y:568,t:1527272401031};\\\", \\\"{x:1331,y:568,t:1527272401047};\\\", \\\"{x:1334,y:568,t:1527272401063};\\\", \\\"{x:1335,y:568,t:1527272401077};\\\", \\\"{x:1339,y:567,t:1527272401094};\\\", \\\"{x:1345,y:566,t:1527272401111};\\\", \\\"{x:1346,y:566,t:1527272401415};\\\", \\\"{x:1348,y:565,t:1527272401427};\\\", \\\"{x:1349,y:564,t:1527272401444};\\\", \\\"{x:1350,y:564,t:1527272401461};\\\", \\\"{x:1351,y:563,t:1527272401478};\\\", \\\"{x:1352,y:563,t:1527272401494};\\\", \\\"{x:1355,y:563,t:1527272401511};\\\", \\\"{x:1357,y:561,t:1527272401527};\\\", \\\"{x:1362,y:561,t:1527272401544};\\\", \\\"{x:1364,y:560,t:1527272401563};\\\", \\\"{x:1365,y:560,t:1527272401578};\\\", \\\"{x:1364,y:562,t:1527272405143};\\\", \\\"{x:1363,y:572,t:1527272405151};\\\", \\\"{x:1360,y:583,t:1527272405164};\\\", \\\"{x:1361,y:600,t:1527272405180};\\\", \\\"{x:1368,y:616,t:1527272405197};\\\", \\\"{x:1378,y:639,t:1527272405215};\\\", \\\"{x:1384,y:650,t:1527272405230};\\\", \\\"{x:1389,y:656,t:1527272405247};\\\", \\\"{x:1397,y:666,t:1527272405265};\\\", \\\"{x:1408,y:679,t:1527272405280};\\\", \\\"{x:1419,y:697,t:1527272405298};\\\", \\\"{x:1430,y:715,t:1527272405314};\\\", \\\"{x:1440,y:736,t:1527272405330};\\\", \\\"{x:1458,y:759,t:1527272405348};\\\", \\\"{x:1472,y:777,t:1527272405364};\\\", \\\"{x:1481,y:787,t:1527272405380};\\\", \\\"{x:1486,y:793,t:1527272405398};\\\", \\\"{x:1488,y:796,t:1527272405414};\\\", \\\"{x:1489,y:797,t:1527272405431};\\\", \\\"{x:1490,y:798,t:1527272405448};\\\", \\\"{x:1492,y:801,t:1527272405465};\\\", \\\"{x:1493,y:804,t:1527272405481};\\\", \\\"{x:1494,y:809,t:1527272405498};\\\", \\\"{x:1496,y:816,t:1527272405514};\\\", \\\"{x:1499,y:826,t:1527272405530};\\\", \\\"{x:1502,y:830,t:1527272405547};\\\", \\\"{x:1502,y:831,t:1527272405565};\\\", \\\"{x:1502,y:832,t:1527272405647};\\\", \\\"{x:1502,y:833,t:1527272405664};\\\", \\\"{x:1499,y:833,t:1527272405682};\\\", \\\"{x:1496,y:833,t:1527272405718};\\\", \\\"{x:1495,y:833,t:1527272405735};\\\", \\\"{x:1493,y:833,t:1527272405747};\\\", \\\"{x:1492,y:833,t:1527272405774};\\\", \\\"{x:1490,y:833,t:1527272405799};\\\", \\\"{x:1489,y:833,t:1527272405814};\\\", \\\"{x:1486,y:833,t:1527272405831};\\\", \\\"{x:1482,y:832,t:1527272405848};\\\", \\\"{x:1481,y:832,t:1527272405943};\\\", \\\"{x:1480,y:832,t:1527272405951};\\\", \\\"{x:1478,y:831,t:1527272405964};\\\", \\\"{x:1477,y:830,t:1527272405981};\\\", \\\"{x:1477,y:829,t:1527272406510};\\\", \\\"{x:1477,y:828,t:1527272406517};\\\", \\\"{x:1477,y:827,t:1527272406530};\\\", \\\"{x:1477,y:826,t:1527272406548};\\\", \\\"{x:1477,y:825,t:1527272406565};\\\", \\\"{x:1478,y:823,t:1527272406581};\\\", \\\"{x:1480,y:822,t:1527272406597};\\\", \\\"{x:1481,y:822,t:1527272407046};\\\", \\\"{x:1482,y:822,t:1527272407119};\\\", \\\"{x:1483,y:822,t:1527272407134};\\\", \\\"{x:1484,y:822,t:1527272407148};\\\", \\\"{x:1485,y:822,t:1527272407207};\\\", \\\"{x:1486,y:822,t:1527272407216};\\\", \\\"{x:1487,y:822,t:1527272407232};\\\", \\\"{x:1489,y:823,t:1527272407249};\\\", \\\"{x:1490,y:823,t:1527272407265};\\\", \\\"{x:1491,y:823,t:1527272407282};\\\", \\\"{x:1494,y:823,t:1527272407299};\\\", \\\"{x:1495,y:823,t:1527272407315};\\\", \\\"{x:1499,y:823,t:1527272407332};\\\", \\\"{x:1502,y:823,t:1527272407349};\\\", \\\"{x:1504,y:823,t:1527272407365};\\\", \\\"{x:1507,y:823,t:1527272407382};\\\", \\\"{x:1513,y:823,t:1527272407399};\\\", \\\"{x:1519,y:823,t:1527272407416};\\\", \\\"{x:1523,y:823,t:1527272407432};\\\", \\\"{x:1528,y:823,t:1527272407450};\\\", \\\"{x:1530,y:823,t:1527272407465};\\\", \\\"{x:1533,y:823,t:1527272407482};\\\", \\\"{x:1536,y:823,t:1527272407499};\\\", \\\"{x:1539,y:824,t:1527272407516};\\\", \\\"{x:1543,y:824,t:1527272407532};\\\", \\\"{x:1544,y:824,t:1527272407549};\\\", \\\"{x:1546,y:825,t:1527272407566};\\\", \\\"{x:1547,y:825,t:1527272407582};\\\", \\\"{x:1549,y:825,t:1527272407606};\\\", \\\"{x:1550,y:826,t:1527272407783};\\\", \\\"{x:1550,y:827,t:1527272409679};\\\", \\\"{x:1560,y:828,t:1527272409686};\\\", \\\"{x:1571,y:829,t:1527272409701};\\\", \\\"{x:1592,y:837,t:1527272409718};\\\", \\\"{x:1615,y:843,t:1527272409734};\\\", \\\"{x:1620,y:844,t:1527272409750};\\\", \\\"{x:1618,y:844,t:1527272409951};\\\", \\\"{x:1616,y:844,t:1527272409968};\\\", \\\"{x:1615,y:842,t:1527272409985};\\\", \\\"{x:1614,y:840,t:1527272410001};\\\", \\\"{x:1614,y:839,t:1527272410079};\\\", \\\"{x:1614,y:838,t:1527272410086};\\\", \\\"{x:1614,y:837,t:1527272410101};\\\", \\\"{x:1614,y:835,t:1527272410117};\\\", \\\"{x:1614,y:834,t:1527272410135};\\\", \\\"{x:1614,y:833,t:1527272410198};\\\", \\\"{x:1614,y:832,t:1527272410207};\\\", \\\"{x:1614,y:831,t:1527272410218};\\\", \\\"{x:1614,y:829,t:1527272410235};\\\", \\\"{x:1614,y:828,t:1527272410251};\\\", \\\"{x:1613,y:828,t:1527272410295};\\\", \\\"{x:1612,y:827,t:1527272411239};\\\", \\\"{x:1612,y:826,t:1527272413904};\\\", \\\"{x:1611,y:811,t:1527272413921};\\\", \\\"{x:1599,y:752,t:1527272413938};\\\", \\\"{x:1575,y:687,t:1527272413954};\\\", \\\"{x:1557,y:659,t:1527272413970};\\\", \\\"{x:1539,y:638,t:1527272413988};\\\", \\\"{x:1525,y:623,t:1527272414005};\\\", \\\"{x:1517,y:616,t:1527272414021};\\\", \\\"{x:1515,y:615,t:1527272414038};\\\", \\\"{x:1509,y:614,t:1527272414055};\\\", \\\"{x:1507,y:613,t:1527272414070};\\\", \\\"{x:1504,y:610,t:1527272414088};\\\", \\\"{x:1502,y:608,t:1527272414105};\\\", \\\"{x:1497,y:607,t:1527272414121};\\\", \\\"{x:1486,y:603,t:1527272414138};\\\", \\\"{x:1467,y:595,t:1527272414154};\\\", \\\"{x:1453,y:589,t:1527272414171};\\\", \\\"{x:1445,y:586,t:1527272414188};\\\", \\\"{x:1436,y:583,t:1527272414205};\\\", \\\"{x:1430,y:582,t:1527272414220};\\\", \\\"{x:1429,y:582,t:1527272414237};\\\", \\\"{x:1419,y:582,t:1527272414254};\\\", \\\"{x:1406,y:578,t:1527272414271};\\\", \\\"{x:1394,y:573,t:1527272414288};\\\", \\\"{x:1389,y:572,t:1527272414305};\\\", \\\"{x:1387,y:572,t:1527272414321};\\\", \\\"{x:1386,y:572,t:1527272414338};\\\", \\\"{x:1384,y:572,t:1527272414355};\\\", \\\"{x:1377,y:572,t:1527272414371};\\\", \\\"{x:1365,y:568,t:1527272414388};\\\", \\\"{x:1364,y:568,t:1527272414405};\\\", \\\"{x:1363,y:568,t:1527272414462};\\\", \\\"{x:1362,y:568,t:1527272414479};\\\", \\\"{x:1360,y:568,t:1527272414503};\\\", \\\"{x:1358,y:568,t:1527272414511};\\\", \\\"{x:1355,y:568,t:1527272414526};\\\", \\\"{x:1354,y:568,t:1527272414538};\\\", \\\"{x:1350,y:567,t:1527272414555};\\\", \\\"{x:1349,y:567,t:1527272414573};\\\", \\\"{x:1348,y:567,t:1527272414623};\\\", \\\"{x:1345,y:566,t:1527272414638};\\\", \\\"{x:1338,y:562,t:1527272414654};\\\", \\\"{x:1339,y:562,t:1527272415166};\\\", \\\"{x:1340,y:562,t:1527272415175};\\\", \\\"{x:1341,y:562,t:1527272415188};\\\", \\\"{x:1344,y:562,t:1527272415204};\\\", \\\"{x:1346,y:562,t:1527272415221};\\\", \\\"{x:1347,y:562,t:1527272415551};\\\", \\\"{x:1349,y:563,t:1527272415558};\\\", \\\"{x:1350,y:564,t:1527272415572};\\\", \\\"{x:1356,y:565,t:1527272415588};\\\", \\\"{x:1361,y:566,t:1527272415606};\\\", \\\"{x:1366,y:568,t:1527272415622};\\\", \\\"{x:1378,y:572,t:1527272415638};\\\", \\\"{x:1380,y:572,t:1527272415656};\\\", \\\"{x:1384,y:573,t:1527272415672};\\\", \\\"{x:1386,y:573,t:1527272415688};\\\", \\\"{x:1387,y:573,t:1527272415718};\\\", \\\"{x:1388,y:573,t:1527272415806};\\\", \\\"{x:1391,y:573,t:1527272415823};\\\", \\\"{x:1394,y:573,t:1527272415839};\\\", \\\"{x:1396,y:573,t:1527272415855};\\\", \\\"{x:1397,y:573,t:1527272415873};\\\", \\\"{x:1399,y:573,t:1527272415889};\\\", \\\"{x:1401,y:573,t:1527272415906};\\\", \\\"{x:1404,y:573,t:1527272415923};\\\", \\\"{x:1405,y:572,t:1527272415943};\\\", \\\"{x:1406,y:572,t:1527272415956};\\\", \\\"{x:1411,y:572,t:1527272415972};\\\", \\\"{x:1416,y:570,t:1527272415989};\\\", \\\"{x:1418,y:569,t:1527272416006};\\\", \\\"{x:1416,y:568,t:1527272416263};\\\", \\\"{x:1415,y:568,t:1527272416290};\\\", \\\"{x:1413,y:568,t:1527272416527};\\\", \\\"{x:1413,y:567,t:1527272416670};\\\", \\\"{x:1412,y:567,t:1527272416679};\\\", \\\"{x:1414,y:567,t:1527272418359};\\\", \\\"{x:1415,y:567,t:1527272418374};\\\", \\\"{x:1416,y:567,t:1527272418479};\\\", \\\"{x:1417,y:567,t:1527272418494};\\\", \\\"{x:1418,y:567,t:1527272418519};\\\", \\\"{x:1419,y:568,t:1527272418527};\\\", \\\"{x:1422,y:568,t:1527272418541};\\\", \\\"{x:1430,y:568,t:1527272418558};\\\", \\\"{x:1434,y:569,t:1527272418574};\\\", \\\"{x:1440,y:569,t:1527272418591};\\\", \\\"{x:1445,y:569,t:1527272418607};\\\", \\\"{x:1452,y:570,t:1527272418624};\\\", \\\"{x:1453,y:570,t:1527272418640};\\\", \\\"{x:1455,y:570,t:1527272418657};\\\", \\\"{x:1456,y:570,t:1527272418839};\\\", \\\"{x:1459,y:570,t:1527272418846};\\\", \\\"{x:1463,y:568,t:1527272418858};\\\", \\\"{x:1471,y:566,t:1527272418875};\\\", \\\"{x:1477,y:565,t:1527272418892};\\\", \\\"{x:1482,y:565,t:1527272418908};\\\", \\\"{x:1484,y:565,t:1527272418925};\\\", \\\"{x:1486,y:565,t:1527272418999};\\\", \\\"{x:1485,y:564,t:1527272419423};\\\", \\\"{x:1484,y:563,t:1527272419471};\\\", \\\"{x:1483,y:563,t:1527272419478};\\\", \\\"{x:1482,y:562,t:1527272419551};\\\", \\\"{x:1483,y:562,t:1527272423850};\\\", \\\"{x:1484,y:562,t:1527272423889};\\\", \\\"{x:1487,y:562,t:1527272423898};\\\", \\\"{x:1492,y:562,t:1527272423915};\\\", \\\"{x:1495,y:562,t:1527272423932};\\\", \\\"{x:1498,y:562,t:1527272423948};\\\", \\\"{x:1500,y:562,t:1527272423966};\\\", \\\"{x:1501,y:562,t:1527272423982};\\\", \\\"{x:1504,y:562,t:1527272423998};\\\", \\\"{x:1511,y:562,t:1527272424015};\\\", \\\"{x:1517,y:563,t:1527272424033};\\\", \\\"{x:1525,y:566,t:1527272424049};\\\", \\\"{x:1527,y:566,t:1527272424162};\\\", \\\"{x:1528,y:566,t:1527272424178};\\\", \\\"{x:1530,y:566,t:1527272424193};\\\", \\\"{x:1532,y:566,t:1527272424202};\\\", \\\"{x:1534,y:566,t:1527272424215};\\\", \\\"{x:1537,y:566,t:1527272424233};\\\", \\\"{x:1539,y:566,t:1527272424249};\\\", \\\"{x:1540,y:566,t:1527272424354};\\\", \\\"{x:1541,y:566,t:1527272424366};\\\", \\\"{x:1542,y:566,t:1527272424418};\\\", \\\"{x:1543,y:566,t:1527272424450};\\\", \\\"{x:1545,y:566,t:1527272424466};\\\", \\\"{x:1547,y:566,t:1527272424482};\\\", \\\"{x:1548,y:566,t:1527272424499};\\\", \\\"{x:1549,y:566,t:1527272424554};\\\", \\\"{x:1551,y:566,t:1527272424570};\\\", \\\"{x:1552,y:566,t:1527272424978};\\\", \\\"{x:1553,y:566,t:1527272424986};\\\", \\\"{x:1554,y:566,t:1527272425490};\\\", \\\"{x:1556,y:567,t:1527272425500};\\\", \\\"{x:1564,y:568,t:1527272425516};\\\", \\\"{x:1577,y:571,t:1527272425533};\\\", \\\"{x:1585,y:572,t:1527272425550};\\\", \\\"{x:1591,y:572,t:1527272425567};\\\", \\\"{x:1593,y:572,t:1527272425769};\\\", \\\"{x:1600,y:572,t:1527272425784};\\\", \\\"{x:1608,y:571,t:1527272425800};\\\", \\\"{x:1609,y:571,t:1527272425816};\\\", \\\"{x:1613,y:570,t:1527272425834};\\\", \\\"{x:1617,y:569,t:1527272425851};\\\", \\\"{x:1617,y:568,t:1527272426122};\\\", \\\"{x:1617,y:567,t:1527272426138};\\\", \\\"{x:1616,y:567,t:1527272426150};\\\", \\\"{x:1615,y:565,t:1527272426167};\\\", \\\"{x:1614,y:564,t:1527272426184};\\\", \\\"{x:1613,y:563,t:1527272426201};\\\", \\\"{x:1613,y:562,t:1527272426218};\\\", \\\"{x:1614,y:562,t:1527272426514};\\\", \\\"{x:1617,y:562,t:1527272426522};\\\", \\\"{x:1622,y:561,t:1527272426534};\\\", \\\"{x:1626,y:561,t:1527272426550};\\\", \\\"{x:1632,y:561,t:1527272426567};\\\", \\\"{x:1640,y:561,t:1527272426585};\\\", \\\"{x:1642,y:561,t:1527272426601};\\\", \\\"{x:1643,y:561,t:1527272426625};\\\", \\\"{x:1644,y:561,t:1527272426682};\\\", \\\"{x:1648,y:561,t:1527272426690};\\\", \\\"{x:1653,y:561,t:1527272426701};\\\", \\\"{x:1661,y:561,t:1527272426718};\\\", \\\"{x:1665,y:561,t:1527272426734};\\\", \\\"{x:1667,y:561,t:1527272426778};\\\", \\\"{x:1668,y:561,t:1527272426785};\\\", \\\"{x:1671,y:561,t:1527272426800};\\\", \\\"{x:1679,y:561,t:1527272426817};\\\", \\\"{x:1681,y:561,t:1527272426834};\\\", \\\"{x:1683,y:561,t:1527272426852};\\\", \\\"{x:1684,y:561,t:1527272426868};\\\", \\\"{x:1685,y:561,t:1527272426885};\\\", \\\"{x:1686,y:561,t:1527272426901};\\\", \\\"{x:1676,y:552,t:1527272428554};\\\", \\\"{x:1604,y:503,t:1527272428569};\\\", \\\"{x:1297,y:362,t:1527272428585};\\\", \\\"{x:1100,y:290,t:1527272428602};\\\", \\\"{x:943,y:250,t:1527272428619};\\\", \\\"{x:833,y:238,t:1527272428635};\\\", \\\"{x:764,y:241,t:1527272428652};\\\", \\\"{x:719,y:272,t:1527272428670};\\\", \\\"{x:697,y:298,t:1527272428685};\\\", \\\"{x:682,y:321,t:1527272428702};\\\", \\\"{x:677,y:332,t:1527272428719};\\\", \\\"{x:673,y:341,t:1527272428735};\\\", \\\"{x:672,y:345,t:1527272428752};\\\", \\\"{x:664,y:358,t:1527272428769};\\\", \\\"{x:656,y:378,t:1527272428785};\\\", \\\"{x:648,y:404,t:1527272428802};\\\", \\\"{x:647,y:418,t:1527272428820};\\\", \\\"{x:645,y:428,t:1527272428835};\\\", \\\"{x:641,y:442,t:1527272428853};\\\", \\\"{x:632,y:454,t:1527272428869};\\\", \\\"{x:613,y:473,t:1527272428885};\\\", \\\"{x:595,y:493,t:1527272428904};\\\", \\\"{x:582,y:506,t:1527272428919};\\\", \\\"{x:581,y:510,t:1527272428935};\\\", \\\"{x:580,y:512,t:1527272428951};\\\", \\\"{x:581,y:512,t:1527272429072};\\\", \\\"{x:586,y:515,t:1527272429086};\\\", \\\"{x:590,y:516,t:1527272429103};\\\", \\\"{x:597,y:516,t:1527272429119};\\\", \\\"{x:601,y:515,t:1527272429136};\\\", \\\"{x:602,y:512,t:1527272429153};\\\", \\\"{x:602,y:511,t:1527272429169};\\\", \\\"{x:604,y:508,t:1527272429186};\\\", \\\"{x:606,y:506,t:1527272429204};\\\", \\\"{x:612,y:502,t:1527272429220};\\\", \\\"{x:613,y:501,t:1527272429237};\\\", \\\"{x:615,y:501,t:1527272429253};\\\", \\\"{x:619,y:502,t:1527272429593};\\\", \\\"{x:625,y:511,t:1527272429604};\\\", \\\"{x:634,y:534,t:1527272429621};\\\", \\\"{x:648,y:570,t:1527272429638};\\\", \\\"{x:652,y:599,t:1527272429655};\\\", \\\"{x:652,y:621,t:1527272429671};\\\", \\\"{x:652,y:629,t:1527272429687};\\\", \\\"{x:652,y:633,t:1527272429705};\\\", \\\"{x:650,y:638,t:1527272429720};\\\", \\\"{x:643,y:656,t:1527272429737};\\\", \\\"{x:636,y:673,t:1527272429754};\\\", \\\"{x:628,y:691,t:1527272429770};\\\", \\\"{x:619,y:711,t:1527272429787};\\\", \\\"{x:615,y:729,t:1527272429804};\\\", \\\"{x:613,y:748,t:1527272429820};\\\", \\\"{x:613,y:771,t:1527272429837};\\\", \\\"{x:613,y:800,t:1527272429854};\\\", \\\"{x:613,y:830,t:1527272429870};\\\", \\\"{x:613,y:862,t:1527272429887};\\\", \\\"{x:613,y:879,t:1527272429904};\\\", \\\"{x:613,y:883,t:1527272429920};\\\", \\\"{x:613,y:885,t:1527272429937};\\\", \\\"{x:613,y:887,t:1527272429953};\\\", \\\"{x:611,y:889,t:1527272429971};\\\", \\\"{x:609,y:889,t:1527272429987};\\\", \\\"{x:603,y:889,t:1527272430004};\\\", \\\"{x:594,y:887,t:1527272430020};\\\", \\\"{x:589,y:884,t:1527272430037};\\\", \\\"{x:585,y:880,t:1527272430055};\\\", \\\"{x:579,y:871,t:1527272430070};\\\", \\\"{x:571,y:862,t:1527272430087};\\\", \\\"{x:558,y:849,t:1527272430103};\\\", \\\"{x:549,y:841,t:1527272430121};\\\", \\\"{x:540,y:836,t:1527272430137};\\\", \\\"{x:539,y:836,t:1527272430154};\\\", \\\"{x:538,y:837,t:1527272430241};\\\", \\\"{x:538,y:838,t:1527272430257};\\\", \\\"{x:538,y:839,t:1527272430270};\\\", \\\"{x:538,y:840,t:1527272430287};\\\", \\\"{x:538,y:841,t:1527272430303};\\\", \\\"{x:536,y:843,t:1527272430320};\\\", \\\"{x:535,y:843,t:1527272430345};\\\", \\\"{x:532,y:843,t:1527272430353};\\\", \\\"{x:528,y:843,t:1527272430370};\\\", \\\"{x:519,y:841,t:1527272430387};\\\", \\\"{x:509,y:837,t:1527272430403};\\\", \\\"{x:500,y:834,t:1527272430420};\\\", \\\"{x:498,y:832,t:1527272430438};\\\", \\\"{x:498,y:831,t:1527272430473};\\\", \\\"{x:498,y:830,t:1527272430487};\\\", \\\"{x:498,y:826,t:1527272430504};\\\", \\\"{x:499,y:820,t:1527272430520};\\\", \\\"{x:504,y:797,t:1527272430537};\\\", \\\"{x:512,y:782,t:1527272430553};\\\", \\\"{x:522,y:771,t:1527272430571};\\\", \\\"{x:529,y:763,t:1527272430588};\\\", \\\"{x:534,y:754,t:1527272430605};\\\", \\\"{x:536,y:747,t:1527272430621};\\\", \\\"{x:537,y:740,t:1527272430637};\\\", \\\"{x:537,y:738,t:1527272430654};\\\", \\\"{x:537,y:737,t:1527272430669};\\\", \\\"{x:537,y:736,t:1527272431410};\\\", \\\"{x:536,y:736,t:1527272431425};\\\", \\\"{x:534,y:736,t:1527272431438};\\\", \\\"{x:531,y:736,t:1527272431455};\\\", \\\"{x:546,y:734,t:1527272431761};\\\", \\\"{x:611,y:730,t:1527272431773};\\\", \\\"{x:741,y:713,t:1527272431790};\\\", \\\"{x:843,y:726,t:1527272431806};\\\", \\\"{x:937,y:754,t:1527272431822};\\\", \\\"{x:1034,y:777,t:1527272431840};\\\", \\\"{x:1118,y:792,t:1527272431855};\\\", \\\"{x:1215,y:804,t:1527272431872};\\\", \\\"{x:1312,y:806,t:1527272431888};\\\", \\\"{x:1408,y:806,t:1527272431906};\\\", \\\"{x:1430,y:800,t:1527272431922};\\\", \\\"{x:1446,y:790,t:1527272431939};\\\", \\\"{x:1450,y:786,t:1527272431957};\\\", \\\"{x:1452,y:780,t:1527272431972};\\\", \\\"{x:1454,y:776,t:1527272431989};\\\", \\\"{x:1454,y:772,t:1527272432006};\\\", \\\"{x:1454,y:768,t:1527272432022};\\\", \\\"{x:1454,y:764,t:1527272432039};\\\", \\\"{x:1453,y:757,t:1527272432055};\\\", \\\"{x:1447,y:747,t:1527272432072};\\\", \\\"{x:1438,y:737,t:1527272432089};\\\", \\\"{x:1429,y:728,t:1527272432106};\\\", \\\"{x:1410,y:713,t:1527272432123};\\\", \\\"{x:1375,y:687,t:1527272432139};\\\", \\\"{x:1319,y:643,t:1527272432156};\\\", \\\"{x:1144,y:504,t:1527272432184};\\\", \\\"{x:1115,y:479,t:1527272432192};\\\", \\\"{x:1091,y:457,t:1527272432206};\\\", \\\"{x:1065,y:430,t:1527272432222};\\\", \\\"{x:1055,y:420,t:1527272432239};\\\", \\\"{x:1050,y:416,t:1527272432256};\\\", \\\"{x:1048,y:416,t:1527272432272};\\\" ] }, { \\\"rt\\\": 39526, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 1008533, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1047,y:415,t:1527272433232};\\\", \\\"{x:1043,y:413,t:1527272433240};\\\", \\\"{x:1035,y:408,t:1527272433256};\\\", \\\"{x:923,y:359,t:1527272433273};\\\", \\\"{x:820,y:329,t:1527272433290};\\\", \\\"{x:765,y:323,t:1527272433306};\\\", \\\"{x:738,y:323,t:1527272433323};\\\", \\\"{x:713,y:324,t:1527272433340};\\\", \\\"{x:690,y:336,t:1527272433356};\\\", \\\"{x:678,y:348,t:1527272433373};\\\", \\\"{x:664,y:364,t:1527272433391};\\\", \\\"{x:652,y:381,t:1527272433406};\\\", \\\"{x:643,y:396,t:1527272433424};\\\", \\\"{x:639,y:402,t:1527272433440};\\\", \\\"{x:635,y:408,t:1527272433457};\\\", \\\"{x:631,y:414,t:1527272433474};\\\", \\\"{x:629,y:421,t:1527272433491};\\\", \\\"{x:627,y:428,t:1527272433508};\\\", \\\"{x:627,y:433,t:1527272433523};\\\", \\\"{x:625,y:439,t:1527272433540};\\\", \\\"{x:623,y:445,t:1527272433557};\\\", \\\"{x:622,y:447,t:1527272433574};\\\", \\\"{x:620,y:448,t:1527272433591};\\\", \\\"{x:615,y:452,t:1527272433607};\\\", \\\"{x:607,y:456,t:1527272433623};\\\", \\\"{x:588,y:464,t:1527272433641};\\\", \\\"{x:579,y:466,t:1527272433657};\\\", \\\"{x:570,y:469,t:1527272433674};\\\", \\\"{x:561,y:470,t:1527272433691};\\\", \\\"{x:553,y:473,t:1527272433707};\\\", \\\"{x:546,y:473,t:1527272433723};\\\", \\\"{x:537,y:474,t:1527272433740};\\\", \\\"{x:526,y:475,t:1527272433757};\\\", \\\"{x:514,y:475,t:1527272433773};\\\", \\\"{x:503,y:475,t:1527272433790};\\\", \\\"{x:491,y:478,t:1527272433807};\\\", \\\"{x:485,y:478,t:1527272433823};\\\", \\\"{x:479,y:479,t:1527272433840};\\\", \\\"{x:476,y:480,t:1527272433857};\\\", \\\"{x:475,y:480,t:1527272433874};\\\", \\\"{x:474,y:480,t:1527272433891};\\\", \\\"{x:473,y:480,t:1527272433908};\\\", \\\"{x:472,y:480,t:1527272433993};\\\", \\\"{x:471,y:480,t:1527272434007};\\\", \\\"{x:470,y:480,t:1527272434105};\\\", \\\"{x:470,y:479,t:1527272434129};\\\", \\\"{x:470,y:477,t:1527272434140};\\\", \\\"{x:469,y:472,t:1527272434158};\\\", \\\"{x:469,y:469,t:1527272434175};\\\", \\\"{x:468,y:466,t:1527272434191};\\\", \\\"{x:467,y:464,t:1527272434207};\\\", \\\"{x:467,y:463,t:1527272434225};\\\", \\\"{x:466,y:462,t:1527272434240};\\\", \\\"{x:464,y:456,t:1527272434257};\\\", \\\"{x:463,y:456,t:1527272434275};\\\", \\\"{x:462,y:454,t:1527272434474};\\\", \\\"{x:467,y:454,t:1527272434593};\\\", \\\"{x:473,y:454,t:1527272434607};\\\", \\\"{x:488,y:454,t:1527272434624};\\\", \\\"{x:499,y:455,t:1527272434641};\\\", \\\"{x:501,y:455,t:1527272434658};\\\", \\\"{x:502,y:455,t:1527272434675};\\\", \\\"{x:504,y:455,t:1527272434929};\\\", \\\"{x:506,y:455,t:1527272434942};\\\", \\\"{x:508,y:455,t:1527272434959};\\\", \\\"{x:510,y:455,t:1527272435106};\\\", \\\"{x:512,y:456,t:1527272435129};\\\", \\\"{x:514,y:457,t:1527272435142};\\\", \\\"{x:522,y:457,t:1527272435159};\\\", \\\"{x:537,y:457,t:1527272435174};\\\", \\\"{x:559,y:457,t:1527272435192};\\\", \\\"{x:586,y:459,t:1527272435209};\\\", \\\"{x:625,y:466,t:1527272435225};\\\", \\\"{x:636,y:469,t:1527272435242};\\\", \\\"{x:638,y:469,t:1527272435259};\\\", \\\"{x:637,y:469,t:1527272435546};\\\", \\\"{x:636,y:469,t:1527272435609};\\\", \\\"{x:634,y:468,t:1527272435625};\\\", \\\"{x:629,y:465,t:1527272435642};\\\", \\\"{x:628,y:464,t:1527272435659};\\\", \\\"{x:628,y:463,t:1527272435676};\\\", \\\"{x:626,y:463,t:1527272435697};\\\", \\\"{x:625,y:462,t:1527272435709};\\\", \\\"{x:622,y:462,t:1527272435725};\\\", \\\"{x:619,y:461,t:1527272435743};\\\", \\\"{x:617,y:460,t:1527272435758};\\\", \\\"{x:612,y:460,t:1527272435776};\\\", \\\"{x:607,y:460,t:1527272435793};\\\", \\\"{x:605,y:460,t:1527272435809};\\\", \\\"{x:599,y:460,t:1527272435825};\\\", \\\"{x:597,y:460,t:1527272435842};\\\", \\\"{x:594,y:460,t:1527272435858};\\\", \\\"{x:592,y:460,t:1527272435875};\\\", \\\"{x:589,y:460,t:1527272435893};\\\", \\\"{x:588,y:459,t:1527272436306};\\\", \\\"{x:586,y:459,t:1527272436394};\\\", \\\"{x:586,y:458,t:1527272436546};\\\", \\\"{x:588,y:458,t:1527272436561};\\\", \\\"{x:593,y:455,t:1527272436577};\\\", \\\"{x:600,y:454,t:1527272436593};\\\", \\\"{x:604,y:454,t:1527272436609};\\\", \\\"{x:607,y:453,t:1527272436627};\\\", \\\"{x:610,y:452,t:1527272436643};\\\", \\\"{x:612,y:451,t:1527272436660};\\\", \\\"{x:612,y:449,t:1527272436802};\\\", \\\"{x:618,y:447,t:1527272436809};\\\", \\\"{x:628,y:447,t:1527272436827};\\\", \\\"{x:635,y:447,t:1527272436843};\\\", \\\"{x:638,y:447,t:1527272436860};\\\", \\\"{x:642,y:447,t:1527272436877};\\\", \\\"{x:646,y:447,t:1527272436893};\\\", \\\"{x:652,y:447,t:1527272436909};\\\", \\\"{x:665,y:447,t:1527272436927};\\\", \\\"{x:679,y:448,t:1527272436942};\\\", \\\"{x:689,y:450,t:1527272436960};\\\", \\\"{x:692,y:450,t:1527272436977};\\\", \\\"{x:692,y:451,t:1527272436993};\\\", \\\"{x:693,y:451,t:1527272437106};\\\", \\\"{x:695,y:452,t:1527272437138};\\\", \\\"{x:696,y:452,t:1527272437153};\\\", \\\"{x:696,y:453,t:1527272437194};\\\", \\\"{x:698,y:453,t:1527272437209};\\\", \\\"{x:702,y:453,t:1527272437227};\\\", \\\"{x:704,y:455,t:1527272437244};\\\", \\\"{x:705,y:455,t:1527272437346};\\\", \\\"{x:705,y:454,t:1527272437425};\\\", \\\"{x:705,y:453,t:1527272437441};\\\", \\\"{x:705,y:452,t:1527272437538};\\\", \\\"{x:703,y:451,t:1527272437561};\\\", \\\"{x:701,y:451,t:1527272437587};\\\", \\\"{x:699,y:450,t:1527272437601};\\\", \\\"{x:699,y:449,t:1527272437611};\\\", \\\"{x:698,y:449,t:1527272437627};\\\", \\\"{x:697,y:449,t:1527272437665};\\\", \\\"{x:699,y:449,t:1527272437793};\\\", \\\"{x:703,y:449,t:1527272437811};\\\", \\\"{x:706,y:449,t:1527272437827};\\\", \\\"{x:708,y:449,t:1527272437843};\\\", \\\"{x:709,y:449,t:1527272437861};\\\", \\\"{x:710,y:449,t:1527272437896};\\\", \\\"{x:711,y:449,t:1527272437910};\\\", \\\"{x:713,y:449,t:1527272438097};\\\", \\\"{x:717,y:449,t:1527272438111};\\\", \\\"{x:725,y:449,t:1527272438127};\\\", \\\"{x:731,y:449,t:1527272438144};\\\", \\\"{x:737,y:449,t:1527272438161};\\\", \\\"{x:738,y:449,t:1527272438177};\\\", \\\"{x:739,y:450,t:1527272438194};\\\", \\\"{x:737,y:450,t:1527272438313};\\\", \\\"{x:734,y:450,t:1527272438328};\\\", \\\"{x:716,y:453,t:1527272438345};\\\", \\\"{x:709,y:454,t:1527272438361};\\\", \\\"{x:690,y:458,t:1527272438378};\\\", \\\"{x:681,y:459,t:1527272438395};\\\", \\\"{x:678,y:459,t:1527272438411};\\\", \\\"{x:676,y:459,t:1527272438427};\\\", \\\"{x:673,y:460,t:1527272438473};\\\", \\\"{x:668,y:460,t:1527272438481};\\\", \\\"{x:663,y:460,t:1527272438495};\\\", \\\"{x:653,y:460,t:1527272438511};\\\", \\\"{x:650,y:458,t:1527272438527};\\\", \\\"{x:648,y:458,t:1527272438544};\\\", \\\"{x:646,y:458,t:1527272438587};\\\", \\\"{x:643,y:458,t:1527272438595};\\\", \\\"{x:635,y:457,t:1527272438611};\\\", \\\"{x:627,y:454,t:1527272438628};\\\", \\\"{x:624,y:453,t:1527272438645};\\\", \\\"{x:622,y:452,t:1527272438661};\\\", \\\"{x:621,y:452,t:1527272438754};\\\", \\\"{x:620,y:452,t:1527272438769};\\\", \\\"{x:619,y:452,t:1527272438778};\\\", \\\"{x:618,y:452,t:1527272438834};\\\", \\\"{x:617,y:452,t:1527272438849};\\\", \\\"{x:616,y:452,t:1527272438861};\\\", \\\"{x:612,y:452,t:1527272438878};\\\", \\\"{x:607,y:453,t:1527272438895};\\\", \\\"{x:602,y:454,t:1527272438912};\\\", \\\"{x:598,y:454,t:1527272438928};\\\", \\\"{x:594,y:455,t:1527272438945};\\\", \\\"{x:592,y:455,t:1527272438962};\\\", \\\"{x:591,y:456,t:1527272438977};\\\", \\\"{x:589,y:456,t:1527272438995};\\\", \\\"{x:588,y:457,t:1527272439011};\\\", \\\"{x:587,y:457,t:1527272439028};\\\", \\\"{x:585,y:458,t:1527272439045};\\\", \\\"{x:583,y:458,t:1527272439073};\\\", \\\"{x:581,y:458,t:1527272439089};\\\", \\\"{x:579,y:458,t:1527272439105};\\\", \\\"{x:578,y:458,t:1527272439129};\\\", \\\"{x:577,y:458,t:1527272439146};\\\", \\\"{x:576,y:458,t:1527272439162};\\\", \\\"{x:575,y:458,t:1527272439187};\\\", \\\"{x:574,y:458,t:1527272439195};\\\", \\\"{x:572,y:458,t:1527272439212};\\\", \\\"{x:566,y:458,t:1527272439229};\\\", \\\"{x:561,y:458,t:1527272439244};\\\", \\\"{x:556,y:458,t:1527272439262};\\\", \\\"{x:555,y:458,t:1527272439279};\\\", \\\"{x:553,y:458,t:1527272439330};\\\", \\\"{x:544,y:458,t:1527272439345};\\\", \\\"{x:533,y:458,t:1527272439361};\\\", \\\"{x:525,y:458,t:1527272439379};\\\", \\\"{x:521,y:458,t:1527272439395};\\\", \\\"{x:518,y:458,t:1527272439412};\\\", \\\"{x:517,y:458,t:1527272439761};\\\", \\\"{x:516,y:458,t:1527272439793};\\\", \\\"{x:515,y:458,t:1527272439801};\\\", \\\"{x:514,y:457,t:1527272439817};\\\", \\\"{x:513,y:457,t:1527272439841};\\\", \\\"{x:514,y:457,t:1527272440082};\\\", \\\"{x:515,y:457,t:1527272440329};\\\", \\\"{x:519,y:455,t:1527272440345};\\\", \\\"{x:531,y:453,t:1527272440363};\\\", \\\"{x:534,y:453,t:1527272440379};\\\", \\\"{x:536,y:453,t:1527272440396};\\\", \\\"{x:539,y:452,t:1527272440413};\\\", \\\"{x:539,y:451,t:1527272440428};\\\", \\\"{x:540,y:451,t:1527272440445};\\\", \\\"{x:541,y:451,t:1527272440463};\\\", \\\"{x:542,y:451,t:1527272440479};\\\", \\\"{x:542,y:450,t:1527272440497};\\\", \\\"{x:545,y:450,t:1527272440513};\\\", \\\"{x:552,y:449,t:1527272440529};\\\", \\\"{x:562,y:449,t:1527272440546};\\\", \\\"{x:578,y:447,t:1527272440563};\\\", \\\"{x:597,y:447,t:1527272440580};\\\", \\\"{x:620,y:447,t:1527272440596};\\\", \\\"{x:650,y:447,t:1527272440613};\\\", \\\"{x:695,y:447,t:1527272440630};\\\", \\\"{x:754,y:447,t:1527272440646};\\\", \\\"{x:807,y:447,t:1527272440663};\\\", \\\"{x:856,y:451,t:1527272440680};\\\", \\\"{x:892,y:455,t:1527272440696};\\\", \\\"{x:918,y:460,t:1527272440713};\\\", \\\"{x:923,y:463,t:1527272440729};\\\", \\\"{x:924,y:463,t:1527272440746};\\\", \\\"{x:925,y:463,t:1527272440769};\\\", \\\"{x:926,y:463,t:1527272440779};\\\", \\\"{x:929,y:465,t:1527272440796};\\\", \\\"{x:937,y:468,t:1527272440813};\\\", \\\"{x:951,y:471,t:1527272440830};\\\", \\\"{x:968,y:472,t:1527272440846};\\\", \\\"{x:987,y:476,t:1527272440864};\\\", \\\"{x:1012,y:478,t:1527272440880};\\\", \\\"{x:1041,y:484,t:1527272440896};\\\", \\\"{x:1086,y:494,t:1527272440913};\\\", \\\"{x:1103,y:501,t:1527272440930};\\\", \\\"{x:1119,y:507,t:1527272440946};\\\", \\\"{x:1128,y:510,t:1527272440963};\\\", \\\"{x:1131,y:510,t:1527272440980};\\\", \\\"{x:1132,y:510,t:1527272441001};\\\", \\\"{x:1132,y:511,t:1527272441025};\\\", \\\"{x:1134,y:511,t:1527272441034};\\\", \\\"{x:1136,y:513,t:1527272441047};\\\", \\\"{x:1143,y:515,t:1527272441063};\\\", \\\"{x:1151,y:519,t:1527272441080};\\\", \\\"{x:1163,y:522,t:1527272441096};\\\", \\\"{x:1168,y:523,t:1527272441112};\\\", \\\"{x:1171,y:524,t:1527272441130};\\\", \\\"{x:1173,y:524,t:1527272441147};\\\", \\\"{x:1178,y:526,t:1527272441163};\\\", \\\"{x:1188,y:531,t:1527272441179};\\\", \\\"{x:1203,y:537,t:1527272441196};\\\", \\\"{x:1216,y:543,t:1527272441212};\\\", \\\"{x:1228,y:548,t:1527272441229};\\\", \\\"{x:1238,y:552,t:1527272441247};\\\", \\\"{x:1248,y:556,t:1527272441263};\\\", \\\"{x:1253,y:558,t:1527272441280};\\\", \\\"{x:1253,y:559,t:1527272441297};\\\", \\\"{x:1254,y:560,t:1527272441313};\\\", \\\"{x:1256,y:561,t:1527272441330};\\\", \\\"{x:1261,y:565,t:1527272441347};\\\", \\\"{x:1268,y:570,t:1527272441363};\\\", \\\"{x:1271,y:574,t:1527272441380};\\\", \\\"{x:1276,y:580,t:1527272441396};\\\", \\\"{x:1278,y:585,t:1527272441413};\\\", \\\"{x:1279,y:589,t:1527272441430};\\\", \\\"{x:1279,y:590,t:1527272441447};\\\", \\\"{x:1279,y:594,t:1527272441463};\\\", \\\"{x:1279,y:596,t:1527272441480};\\\", \\\"{x:1274,y:604,t:1527272441497};\\\", \\\"{x:1267,y:611,t:1527272441513};\\\", \\\"{x:1257,y:619,t:1527272441530};\\\", \\\"{x:1251,y:625,t:1527272441547};\\\", \\\"{x:1246,y:629,t:1527272441564};\\\", \\\"{x:1245,y:630,t:1527272441658};\\\", \\\"{x:1243,y:630,t:1527272441689};\\\", \\\"{x:1241,y:630,t:1527272441697};\\\", \\\"{x:1238,y:630,t:1527272441714};\\\", \\\"{x:1233,y:632,t:1527272441730};\\\", \\\"{x:1228,y:636,t:1527272441747};\\\", \\\"{x:1223,y:640,t:1527272441764};\\\", \\\"{x:1219,y:649,t:1527272441780};\\\", \\\"{x:1216,y:658,t:1527272441797};\\\", \\\"{x:1214,y:661,t:1527272441814};\\\", \\\"{x:1214,y:663,t:1527272441830};\\\", \\\"{x:1213,y:666,t:1527272441847};\\\", \\\"{x:1213,y:667,t:1527272441864};\\\", \\\"{x:1213,y:668,t:1527272441881};\\\", \\\"{x:1212,y:671,t:1527272441897};\\\", \\\"{x:1212,y:674,t:1527272441914};\\\", \\\"{x:1212,y:676,t:1527272441930};\\\", \\\"{x:1212,y:678,t:1527272441946};\\\", \\\"{x:1212,y:680,t:1527272441964};\\\", \\\"{x:1212,y:681,t:1527272441980};\\\", \\\"{x:1212,y:683,t:1527272441997};\\\", \\\"{x:1212,y:684,t:1527272442014};\\\", \\\"{x:1212,y:686,t:1527272442049};\\\", \\\"{x:1213,y:686,t:1527272442064};\\\", \\\"{x:1213,y:687,t:1527272442241};\\\", \\\"{x:1214,y:687,t:1527272442248};\\\", \\\"{x:1216,y:687,t:1527272442264};\\\", \\\"{x:1222,y:687,t:1527272442280};\\\", \\\"{x:1226,y:687,t:1527272442297};\\\", \\\"{x:1228,y:687,t:1527272442314};\\\", \\\"{x:1230,y:686,t:1527272442330};\\\", \\\"{x:1232,y:685,t:1527272442347};\\\", \\\"{x:1233,y:684,t:1527272442364};\\\", \\\"{x:1234,y:683,t:1527272442381};\\\", \\\"{x:1234,y:682,t:1527272442442};\\\", \\\"{x:1234,y:681,t:1527272442449};\\\", \\\"{x:1234,y:680,t:1527272442465};\\\", \\\"{x:1233,y:679,t:1527272442521};\\\", \\\"{x:1232,y:679,t:1527272442753};\\\", \\\"{x:1232,y:678,t:1527272442993};\\\", \\\"{x:1233,y:676,t:1527272443002};\\\", \\\"{x:1235,y:676,t:1527272443016};\\\", \\\"{x:1236,y:674,t:1527272443031};\\\", \\\"{x:1237,y:674,t:1527272443048};\\\", \\\"{x:1238,y:673,t:1527272443065};\\\", \\\"{x:1239,y:673,t:1527272443089};\\\", \\\"{x:1239,y:672,t:1527272443098};\\\", \\\"{x:1240,y:671,t:1527272443115};\\\", \\\"{x:1240,y:670,t:1527272443131};\\\", \\\"{x:1240,y:669,t:1527272443153};\\\", \\\"{x:1241,y:668,t:1527272443202};\\\", \\\"{x:1242,y:667,t:1527272443216};\\\", \\\"{x:1243,y:665,t:1527272443232};\\\", \\\"{x:1244,y:664,t:1527272443249};\\\", \\\"{x:1246,y:663,t:1527272443265};\\\", \\\"{x:1246,y:662,t:1527272443282};\\\", \\\"{x:1247,y:661,t:1527272443298};\\\", \\\"{x:1249,y:658,t:1527272443315};\\\", \\\"{x:1252,y:657,t:1527272443332};\\\", \\\"{x:1253,y:656,t:1527272443347};\\\", \\\"{x:1255,y:655,t:1527272443365};\\\", \\\"{x:1256,y:655,t:1527272443382};\\\", \\\"{x:1257,y:655,t:1527272443398};\\\", \\\"{x:1258,y:655,t:1527272443417};\\\", \\\"{x:1259,y:654,t:1527272443433};\\\", \\\"{x:1260,y:654,t:1527272443448};\\\", \\\"{x:1262,y:653,t:1527272443465};\\\", \\\"{x:1263,y:652,t:1527272443481};\\\", \\\"{x:1264,y:652,t:1527272443498};\\\", \\\"{x:1265,y:651,t:1527272443515};\\\", \\\"{x:1266,y:651,t:1527272443537};\\\", \\\"{x:1267,y:649,t:1527272443548};\\\", \\\"{x:1268,y:647,t:1527272443570};\\\", \\\"{x:1269,y:646,t:1527272443586};\\\", \\\"{x:1270,y:645,t:1527272443598};\\\", \\\"{x:1271,y:643,t:1527272443615};\\\", \\\"{x:1273,y:643,t:1527272443632};\\\", \\\"{x:1275,y:643,t:1527272443648};\\\", \\\"{x:1280,y:644,t:1527272443666};\\\", \\\"{x:1286,y:650,t:1527272443682};\\\", \\\"{x:1292,y:656,t:1527272443699};\\\", \\\"{x:1298,y:665,t:1527272443716};\\\", \\\"{x:1304,y:673,t:1527272443732};\\\", \\\"{x:1308,y:679,t:1527272443749};\\\", \\\"{x:1310,y:683,t:1527272443765};\\\", \\\"{x:1311,y:684,t:1527272443782};\\\", \\\"{x:1312,y:686,t:1527272443799};\\\", \\\"{x:1314,y:691,t:1527272443815};\\\", \\\"{x:1317,y:698,t:1527272443832};\\\", \\\"{x:1320,y:709,t:1527272443849};\\\", \\\"{x:1321,y:714,t:1527272443865};\\\", \\\"{x:1323,y:721,t:1527272443882};\\\", \\\"{x:1323,y:726,t:1527272443899};\\\", \\\"{x:1325,y:733,t:1527272443915};\\\", \\\"{x:1327,y:739,t:1527272443932};\\\", \\\"{x:1327,y:747,t:1527272443949};\\\", \\\"{x:1332,y:756,t:1527272443965};\\\", \\\"{x:1336,y:766,t:1527272443982};\\\", \\\"{x:1337,y:769,t:1527272443999};\\\", \\\"{x:1340,y:774,t:1527272444016};\\\", \\\"{x:1341,y:776,t:1527272444032};\\\", \\\"{x:1343,y:778,t:1527272444050};\\\", \\\"{x:1347,y:781,t:1527272444066};\\\", \\\"{x:1352,y:786,t:1527272444082};\\\", \\\"{x:1358,y:792,t:1527272444099};\\\", \\\"{x:1361,y:795,t:1527272444116};\\\", \\\"{x:1362,y:796,t:1527272444133};\\\", \\\"{x:1362,y:797,t:1527272444169};\\\", \\\"{x:1358,y:799,t:1527272444186};\\\", \\\"{x:1347,y:802,t:1527272444200};\\\", \\\"{x:1320,y:809,t:1527272444216};\\\", \\\"{x:1291,y:815,t:1527272444232};\\\", \\\"{x:1258,y:822,t:1527272444249};\\\", \\\"{x:1239,y:825,t:1527272444266};\\\", \\\"{x:1230,y:826,t:1527272444282};\\\", \\\"{x:1228,y:827,t:1527272444299};\\\", \\\"{x:1227,y:828,t:1527272444330};\\\", \\\"{x:1227,y:830,t:1527272444337};\\\", \\\"{x:1229,y:833,t:1527272444349};\\\", \\\"{x:1233,y:839,t:1527272444366};\\\", \\\"{x:1233,y:841,t:1527272444382};\\\", \\\"{x:1232,y:841,t:1527272444482};\\\", \\\"{x:1228,y:841,t:1527272444499};\\\", \\\"{x:1222,y:839,t:1527272444516};\\\", \\\"{x:1217,y:836,t:1527272444533};\\\", \\\"{x:1216,y:836,t:1527272444549};\\\", \\\"{x:1214,y:834,t:1527272444596};\\\", \\\"{x:1210,y:833,t:1527272444616};\\\", \\\"{x:1201,y:817,t:1527272444633};\\\", \\\"{x:1199,y:815,t:1527272444648};\\\", \\\"{x:1199,y:814,t:1527272444672};\\\", \\\"{x:1201,y:812,t:1527272444696};\\\", \\\"{x:1204,y:811,t:1527272444705};\\\", \\\"{x:1206,y:811,t:1527272444716};\\\", \\\"{x:1209,y:809,t:1527272444733};\\\", \\\"{x:1210,y:808,t:1527272444748};\\\", \\\"{x:1210,y:807,t:1527272444765};\\\", \\\"{x:1211,y:807,t:1527272444793};\\\", \\\"{x:1212,y:807,t:1527272444801};\\\", \\\"{x:1214,y:807,t:1527272444815};\\\", \\\"{x:1214,y:808,t:1527272444834};\\\", \\\"{x:1215,y:808,t:1527272444849};\\\", \\\"{x:1213,y:808,t:1527272444898};\\\", \\\"{x:1207,y:805,t:1527272444905};\\\", \\\"{x:1201,y:801,t:1527272444916};\\\", \\\"{x:1196,y:797,t:1527272444933};\\\", \\\"{x:1195,y:795,t:1527272444949};\\\", \\\"{x:1194,y:794,t:1527272445057};\\\", \\\"{x:1194,y:793,t:1527272445098};\\\", \\\"{x:1194,y:792,t:1527272445113};\\\", \\\"{x:1194,y:791,t:1527272445122};\\\", \\\"{x:1193,y:789,t:1527272445134};\\\", \\\"{x:1190,y:783,t:1527272445150};\\\", \\\"{x:1187,y:777,t:1527272445166};\\\", \\\"{x:1186,y:775,t:1527272445184};\\\", \\\"{x:1186,y:774,t:1527272445200};\\\", \\\"{x:1185,y:774,t:1527272445217};\\\", \\\"{x:1184,y:773,t:1527272445233};\\\", \\\"{x:1183,y:771,t:1527272445265};\\\", \\\"{x:1183,y:768,t:1527272445283};\\\", \\\"{x:1183,y:764,t:1527272445301};\\\", \\\"{x:1181,y:762,t:1527272445317};\\\", \\\"{x:1180,y:759,t:1527272445333};\\\", \\\"{x:1179,y:759,t:1527272445369};\\\", \\\"{x:1180,y:760,t:1527272446842};\\\", \\\"{x:1181,y:761,t:1527272449464};\\\", \\\"{x:1181,y:762,t:1527272449472};\\\", \\\"{x:1183,y:762,t:1527272449488};\\\", \\\"{x:1184,y:763,t:1527272449503};\\\", \\\"{x:1188,y:764,t:1527272449520};\\\", \\\"{x:1191,y:766,t:1527272449536};\\\", \\\"{x:1200,y:766,t:1527272449553};\\\", \\\"{x:1208,y:766,t:1527272449570};\\\", \\\"{x:1216,y:766,t:1527272449586};\\\", \\\"{x:1222,y:766,t:1527272449603};\\\", \\\"{x:1230,y:766,t:1527272449620};\\\", \\\"{x:1237,y:766,t:1527272449636};\\\", \\\"{x:1241,y:766,t:1527272449653};\\\", \\\"{x:1243,y:766,t:1527272449670};\\\", \\\"{x:1244,y:766,t:1527272449687};\\\", \\\"{x:1245,y:766,t:1527272449703};\\\", \\\"{x:1246,y:766,t:1527272449720};\\\", \\\"{x:1252,y:766,t:1527272449737};\\\", \\\"{x:1255,y:766,t:1527272449753};\\\", \\\"{x:1256,y:766,t:1527272449770};\\\", \\\"{x:1263,y:766,t:1527272450026};\\\", \\\"{x:1274,y:766,t:1527272450038};\\\", \\\"{x:1295,y:766,t:1527272450054};\\\", \\\"{x:1310,y:766,t:1527272450071};\\\", \\\"{x:1319,y:766,t:1527272450088};\\\", \\\"{x:1320,y:766,t:1527272450104};\\\", \\\"{x:1322,y:766,t:1527272450409};\\\", \\\"{x:1327,y:766,t:1527272450420};\\\", \\\"{x:1334,y:765,t:1527272450437};\\\", \\\"{x:1337,y:765,t:1527272450454};\\\", \\\"{x:1338,y:765,t:1527272450470};\\\", \\\"{x:1339,y:765,t:1527272450745};\\\", \\\"{x:1340,y:765,t:1527272450755};\\\", \\\"{x:1341,y:765,t:1527272450771};\\\", \\\"{x:1342,y:765,t:1527272460282};\\\", \\\"{x:1346,y:765,t:1527272460295};\\\", \\\"{x:1396,y:757,t:1527272460313};\\\", \\\"{x:1502,y:745,t:1527272460329};\\\", \\\"{x:1547,y:745,t:1527272460345};\\\", \\\"{x:1594,y:745,t:1527272460362};\\\", \\\"{x:1620,y:745,t:1527272460379};\\\", \\\"{x:1627,y:745,t:1527272460395};\\\", \\\"{x:1628,y:745,t:1527272460457};\\\", \\\"{x:1630,y:745,t:1527272460465};\\\", \\\"{x:1632,y:745,t:1527272460479};\\\", \\\"{x:1639,y:746,t:1527272460495};\\\", \\\"{x:1651,y:749,t:1527272460512};\\\", \\\"{x:1666,y:753,t:1527272460528};\\\", \\\"{x:1670,y:754,t:1527272460545};\\\", \\\"{x:1672,y:755,t:1527272460561};\\\", \\\"{x:1675,y:757,t:1527272460579};\\\", \\\"{x:1677,y:758,t:1527272460595};\\\", \\\"{x:1685,y:762,t:1527272460612};\\\", \\\"{x:1696,y:767,t:1527272460628};\\\", \\\"{x:1711,y:772,t:1527272460645};\\\", \\\"{x:1720,y:777,t:1527272460662};\\\", \\\"{x:1727,y:777,t:1527272460679};\\\", \\\"{x:1730,y:778,t:1527272460696};\\\", \\\"{x:1731,y:778,t:1527272460712};\\\", \\\"{x:1733,y:778,t:1527272460729};\\\", \\\"{x:1738,y:780,t:1527272460746};\\\", \\\"{x:1747,y:782,t:1527272460762};\\\", \\\"{x:1756,y:783,t:1527272460779};\\\", \\\"{x:1762,y:785,t:1527272460796};\\\", \\\"{x:1770,y:787,t:1527272460812};\\\", \\\"{x:1773,y:788,t:1527272460829};\\\", \\\"{x:1776,y:789,t:1527272460846};\\\", \\\"{x:1776,y:790,t:1527272460937};\\\", \\\"{x:1779,y:791,t:1527272460953};\\\", \\\"{x:1780,y:792,t:1527272460963};\\\", \\\"{x:1781,y:792,t:1527272460987};\\\", \\\"{x:1783,y:794,t:1527272460995};\\\", \\\"{x:1784,y:795,t:1527272461012};\\\", \\\"{x:1787,y:801,t:1527272461029};\\\", \\\"{x:1792,y:810,t:1527272461046};\\\", \\\"{x:1796,y:819,t:1527272461063};\\\", \\\"{x:1798,y:822,t:1527272461079};\\\", \\\"{x:1799,y:824,t:1527272461096};\\\", \\\"{x:1800,y:824,t:1527272461113};\\\", \\\"{x:1800,y:825,t:1527272461137};\\\", \\\"{x:1800,y:826,t:1527272461170};\\\", \\\"{x:1800,y:827,t:1527272461179};\\\", \\\"{x:1801,y:829,t:1527272461196};\\\", \\\"{x:1802,y:829,t:1527272461213};\\\", \\\"{x:1803,y:830,t:1527272461230};\\\", \\\"{x:1803,y:831,t:1527272461247};\\\", \\\"{x:1804,y:831,t:1527272461729};\\\", \\\"{x:1805,y:831,t:1527272461793};\\\", \\\"{x:1806,y:831,t:1527272461801};\\\", \\\"{x:1807,y:831,t:1527272461850};\\\", \\\"{x:1808,y:831,t:1527272462001};\\\", \\\"{x:1809,y:831,t:1527272462050};\\\", \\\"{x:1809,y:830,t:1527272462065};\\\", \\\"{x:1803,y:827,t:1527272465930};\\\", \\\"{x:1788,y:825,t:1527272465937};\\\", \\\"{x:1770,y:820,t:1527272465950};\\\", \\\"{x:1713,y:805,t:1527272465966};\\\", \\\"{x:1654,y:786,t:1527272465983};\\\", \\\"{x:1604,y:774,t:1527272466001};\\\", \\\"{x:1560,y:769,t:1527272466016};\\\", \\\"{x:1492,y:766,t:1527272466033};\\\", \\\"{x:1451,y:764,t:1527272466050};\\\", \\\"{x:1419,y:764,t:1527272466066};\\\", \\\"{x:1396,y:763,t:1527272466084};\\\", \\\"{x:1378,y:763,t:1527272466100};\\\", \\\"{x:1359,y:763,t:1527272466117};\\\", \\\"{x:1327,y:763,t:1527272466133};\\\", \\\"{x:1271,y:763,t:1527272466150};\\\", \\\"{x:1207,y:763,t:1527272466166};\\\", \\\"{x:1155,y:766,t:1527272466184};\\\", \\\"{x:1132,y:768,t:1527272466201};\\\", \\\"{x:1125,y:769,t:1527272466217};\\\", \\\"{x:1122,y:770,t:1527272466233};\\\", \\\"{x:1120,y:770,t:1527272466289};\\\", \\\"{x:1118,y:770,t:1527272466305};\\\", \\\"{x:1117,y:770,t:1527272466321};\\\", \\\"{x:1117,y:771,t:1527272466449};\\\", \\\"{x:1119,y:771,t:1527272466467};\\\", \\\"{x:1124,y:771,t:1527272466483};\\\", \\\"{x:1129,y:771,t:1527272466500};\\\", \\\"{x:1133,y:771,t:1527272466517};\\\", \\\"{x:1141,y:771,t:1527272466533};\\\", \\\"{x:1148,y:771,t:1527272466551};\\\", \\\"{x:1154,y:771,t:1527272466567};\\\", \\\"{x:1157,y:771,t:1527272466583};\\\", \\\"{x:1158,y:771,t:1527272466697};\\\", \\\"{x:1158,y:768,t:1527272466705};\\\", \\\"{x:1158,y:758,t:1527272466718};\\\", \\\"{x:1148,y:731,t:1527272466735};\\\", \\\"{x:1089,y:656,t:1527272466750};\\\", \\\"{x:981,y:553,t:1527272466767};\\\", \\\"{x:850,y:463,t:1527272466784};\\\", \\\"{x:724,y:389,t:1527272466801};\\\", \\\"{x:574,y:322,t:1527272466817};\\\", \\\"{x:507,y:302,t:1527272466834};\\\", \\\"{x:461,y:299,t:1527272466850};\\\", \\\"{x:437,y:299,t:1527272466866};\\\", \\\"{x:423,y:307,t:1527272466884};\\\", \\\"{x:412,y:319,t:1527272466900};\\\", \\\"{x:404,y:336,t:1527272466917};\\\", \\\"{x:400,y:356,t:1527272466935};\\\", \\\"{x:400,y:378,t:1527272466950};\\\", \\\"{x:400,y:398,t:1527272466967};\\\", \\\"{x:403,y:415,t:1527272466985};\\\", \\\"{x:405,y:425,t:1527272467001};\\\", \\\"{x:405,y:430,t:1527272467016};\\\", \\\"{x:405,y:431,t:1527272467034};\\\", \\\"{x:407,y:434,t:1527272467050};\\\", \\\"{x:408,y:438,t:1527272467067};\\\", \\\"{x:410,y:444,t:1527272467084};\\\", \\\"{x:412,y:450,t:1527272467100};\\\", \\\"{x:412,y:452,t:1527272467117};\\\", \\\"{x:412,y:455,t:1527272467134};\\\", \\\"{x:412,y:460,t:1527272467151};\\\", \\\"{x:416,y:478,t:1527272467168};\\\", \\\"{x:422,y:507,t:1527272467186};\\\", \\\"{x:422,y:519,t:1527272467201};\\\", \\\"{x:418,y:527,t:1527272467218};\\\", \\\"{x:408,y:532,t:1527272467229};\\\", \\\"{x:390,y:539,t:1527272467246};\\\", \\\"{x:356,y:541,t:1527272467267};\\\", \\\"{x:340,y:543,t:1527272467283};\\\", \\\"{x:333,y:543,t:1527272467300};\\\", \\\"{x:332,y:543,t:1527272467318};\\\", \\\"{x:332,y:544,t:1527272467360};\\\", \\\"{x:333,y:544,t:1527272467409};\\\", \\\"{x:337,y:544,t:1527272467418};\\\", \\\"{x:355,y:540,t:1527272467435};\\\", \\\"{x:370,y:531,t:1527272467450};\\\", \\\"{x:374,y:528,t:1527272467469};\\\", \\\"{x:375,y:527,t:1527272467485};\\\", \\\"{x:369,y:522,t:1527272467503};\\\", \\\"{x:359,y:519,t:1527272467518};\\\", \\\"{x:348,y:517,t:1527272467536};\\\", \\\"{x:339,y:514,t:1527272467551};\\\", \\\"{x:321,y:514,t:1527272467568};\\\", \\\"{x:289,y:514,t:1527272467584};\\\", \\\"{x:264,y:520,t:1527272467602};\\\", \\\"{x:247,y:522,t:1527272467618};\\\", \\\"{x:232,y:525,t:1527272467635};\\\", \\\"{x:220,y:526,t:1527272467650};\\\", \\\"{x:202,y:526,t:1527272467668};\\\", \\\"{x:185,y:526,t:1527272467684};\\\", \\\"{x:171,y:525,t:1527272467702};\\\", \\\"{x:166,y:523,t:1527272467718};\\\", \\\"{x:164,y:522,t:1527272467734};\\\", \\\"{x:163,y:522,t:1527272467760};\\\", \\\"{x:161,y:521,t:1527272467768};\\\", \\\"{x:152,y:517,t:1527272467784};\\\", \\\"{x:147,y:516,t:1527272467802};\\\", \\\"{x:147,y:515,t:1527272467818};\\\", \\\"{x:151,y:514,t:1527272468009};\\\", \\\"{x:155,y:512,t:1527272468019};\\\", \\\"{x:167,y:508,t:1527272468035};\\\", \\\"{x:182,y:502,t:1527272468052};\\\", \\\"{x:190,y:498,t:1527272468069};\\\", \\\"{x:193,y:497,t:1527272468085};\\\", \\\"{x:193,y:495,t:1527272468192};\\\", \\\"{x:192,y:495,t:1527272468224};\\\", \\\"{x:191,y:495,t:1527272468264};\\\", \\\"{x:190,y:495,t:1527272468281};\\\", \\\"{x:189,y:495,t:1527272468305};\\\", \\\"{x:188,y:495,t:1527272468319};\\\", \\\"{x:183,y:495,t:1527272468336};\\\", \\\"{x:174,y:495,t:1527272468352};\\\", \\\"{x:164,y:496,t:1527272468369};\\\", \\\"{x:162,y:496,t:1527272468385};\\\", \\\"{x:161,y:497,t:1527272468537};\\\", \\\"{x:161,y:498,t:1527272468569};\\\", \\\"{x:162,y:499,t:1527272468586};\\\", \\\"{x:163,y:499,t:1527272468641};\\\", \\\"{x:163,y:500,t:1527272468656};\\\", \\\"{x:174,y:500,t:1527272469129};\\\", \\\"{x:209,y:500,t:1527272469137};\\\", \\\"{x:271,y:500,t:1527272469152};\\\", \\\"{x:297,y:506,t:1527272469169};\\\", \\\"{x:315,y:509,t:1527272469186};\\\", \\\"{x:325,y:511,t:1527272469202};\\\", \\\"{x:334,y:513,t:1527272469219};\\\", \\\"{x:340,y:515,t:1527272469236};\\\", \\\"{x:344,y:519,t:1527272469254};\\\", \\\"{x:350,y:526,t:1527272469270};\\\", \\\"{x:357,y:540,t:1527272469286};\\\", \\\"{x:366,y:556,t:1527272469304};\\\", \\\"{x:375,y:571,t:1527272469319};\\\", \\\"{x:386,y:589,t:1527272469336};\\\", \\\"{x:391,y:600,t:1527272469353};\\\", \\\"{x:394,y:609,t:1527272469369};\\\", \\\"{x:394,y:614,t:1527272469385};\\\", \\\"{x:395,y:623,t:1527272469403};\\\", \\\"{x:400,y:635,t:1527272469419};\\\", \\\"{x:407,y:649,t:1527272469438};\\\", \\\"{x:417,y:663,t:1527272469452};\\\", \\\"{x:433,y:678,t:1527272469470};\\\", \\\"{x:442,y:690,t:1527272469487};\\\", \\\"{x:447,y:700,t:1527272469502};\\\", \\\"{x:452,y:711,t:1527272469518};\\\", \\\"{x:458,y:721,t:1527272469536};\\\", \\\"{x:471,y:737,t:1527272469552};\\\", \\\"{x:478,y:744,t:1527272469570};\\\", \\\"{x:481,y:749,t:1527272469587};\\\", \\\"{x:484,y:753,t:1527272469602};\\\", \\\"{x:485,y:754,t:1527272469620};\\\", \\\"{x:485,y:755,t:1527272469637};\\\", \\\"{x:487,y:756,t:1527272469653};\\\", \\\"{x:488,y:758,t:1527272469669};\\\", \\\"{x:490,y:760,t:1527272469686};\\\", \\\"{x:495,y:764,t:1527272469703};\\\", \\\"{x:502,y:768,t:1527272469720};\\\", \\\"{x:512,y:773,t:1527272469736};\\\", \\\"{x:518,y:776,t:1527272469752};\\\", \\\"{x:519,y:777,t:1527272469770};\\\", \\\"{x:519,y:776,t:1527272469865};\\\", \\\"{x:519,y:774,t:1527272469873};\\\", \\\"{x:518,y:771,t:1527272469886};\\\", \\\"{x:517,y:769,t:1527272469903};\\\", \\\"{x:515,y:764,t:1527272469920};\\\", \\\"{x:515,y:762,t:1527272469936};\\\", \\\"{x:514,y:761,t:1527272469953};\\\", \\\"{x:513,y:759,t:1527272469970};\\\", \\\"{x:513,y:757,t:1527272469986};\\\", \\\"{x:513,y:754,t:1527272470004};\\\", \\\"{x:512,y:752,t:1527272470020};\\\", \\\"{x:512,y:751,t:1527272470041};\\\", \\\"{x:512,y:750,t:1527272470065};\\\", \\\"{x:512,y:749,t:1527272470073};\\\", \\\"{x:512,y:748,t:1527272470087};\\\", \\\"{x:512,y:746,t:1527272470104};\\\", \\\"{x:512,y:745,t:1527272470120};\\\", \\\"{x:512,y:744,t:1527272470137};\\\", \\\"{x:512,y:743,t:1527272470155};\\\", \\\"{x:512,y:741,t:1527272470170};\\\", \\\"{x:513,y:737,t:1527272470188};\\\", \\\"{x:514,y:736,t:1527272470204};\\\", \\\"{x:515,y:735,t:1527272470221};\\\", \\\"{x:515,y:734,t:1527272470641};\\\", \\\"{x:513,y:734,t:1527272470654};\\\", \\\"{x:511,y:734,t:1527272470673};\\\", \\\"{x:510,y:734,t:1527272470689};\\\", \\\"{x:508,y:734,t:1527272470834};\\\", \\\"{x:507,y:734,t:1527272470897};\\\", \\\"{x:505,y:734,t:1527272470937};\\\", \\\"{x:504,y:734,t:1527272470993};\\\", \\\"{x:502,y:734,t:1527272471009};\\\", \\\"{x:501,y:734,t:1527272471025};\\\", \\\"{x:499,y:734,t:1527272471038};\\\", \\\"{x:495,y:734,t:1527272471055};\\\", \\\"{x:493,y:734,t:1527272471072};\\\", \\\"{x:491,y:734,t:1527272471088};\\\", \\\"{x:490,y:734,t:1527272471105};\\\", \\\"{x:491,y:734,t:1527272471353};\\\", \\\"{x:492,y:734,t:1527272472232};\\\", \\\"{x:495,y:734,t:1527272472248};\\\", \\\"{x:500,y:732,t:1527272472256};\\\", \\\"{x:512,y:732,t:1527272472272};\\\", \\\"{x:519,y:732,t:1527272472287};\\\", \\\"{x:530,y:730,t:1527272472305};\\\", \\\"{x:545,y:730,t:1527272472322};\\\", \\\"{x:562,y:725,t:1527272472338};\\\", \\\"{x:591,y:721,t:1527272472354};\\\", \\\"{x:644,y:721,t:1527272472372};\\\", \\\"{x:696,y:718,t:1527272472388};\\\", \\\"{x:752,y:717,t:1527272472405};\\\", \\\"{x:795,y:710,t:1527272472422};\\\", \\\"{x:825,y:701,t:1527272472438};\\\", \\\"{x:859,y:691,t:1527272472455};\\\", \\\"{x:898,y:682,t:1527272472472};\\\", \\\"{x:915,y:680,t:1527272472488};\\\", \\\"{x:921,y:680,t:1527272472505};\\\", \\\"{x:923,y:678,t:1527272472522};\\\", \\\"{x:923,y:676,t:1527272472729};\\\", \\\"{x:920,y:675,t:1527272472739};\\\", \\\"{x:920,y:674,t:1527272472921};\\\" ] }, { \\\"rt\\\": 24512, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 1034266, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -Z -Z -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:917,y:674,t:1527272475505};\\\", \\\"{x:901,y:662,t:1527272475529};\\\", \\\"{x:889,y:648,t:1527272475541};\\\", \\\"{x:853,y:606,t:1527272475557};\\\", \\\"{x:821,y:570,t:1527272475575};\\\", \\\"{x:804,y:552,t:1527272475592};\\\", \\\"{x:794,y:535,t:1527272475608};\\\", \\\"{x:790,y:521,t:1527272475624};\\\", \\\"{x:786,y:505,t:1527272475642};\\\", \\\"{x:786,y:489,t:1527272475658};\\\", \\\"{x:787,y:469,t:1527272475674};\\\", \\\"{x:799,y:453,t:1527272475691};\\\", \\\"{x:814,y:439,t:1527272475708};\\\", \\\"{x:836,y:423,t:1527272475724};\\\", \\\"{x:862,y:405,t:1527272475742};\\\", \\\"{x:880,y:394,t:1527272475758};\\\", \\\"{x:896,y:385,t:1527272475774};\\\", \\\"{x:904,y:380,t:1527272475791};\\\", \\\"{x:909,y:378,t:1527272475808};\\\", \\\"{x:910,y:378,t:1527272475824};\\\", \\\"{x:913,y:378,t:1527272475841};\\\", \\\"{x:919,y:376,t:1527272475858};\\\", \\\"{x:930,y:375,t:1527272475875};\\\", \\\"{x:945,y:373,t:1527272475892};\\\", \\\"{x:962,y:370,t:1527272475909};\\\", \\\"{x:979,y:368,t:1527272475924};\\\", \\\"{x:1001,y:364,t:1527272475942};\\\", \\\"{x:1026,y:354,t:1527272475959};\\\", \\\"{x:1062,y:345,t:1527272475975};\\\", \\\"{x:1091,y:338,t:1527272475991};\\\", \\\"{x:1132,y:321,t:1527272476010};\\\", \\\"{x:1154,y:315,t:1527272476025};\\\", \\\"{x:1170,y:311,t:1527272476041};\\\", \\\"{x:1177,y:309,t:1527272476058};\\\", \\\"{x:1182,y:309,t:1527272476075};\\\", \\\"{x:1185,y:309,t:1527272476092};\\\", \\\"{x:1186,y:309,t:1527272476109};\\\", \\\"{x:1187,y:309,t:1527272476125};\\\", \\\"{x:1192,y:310,t:1527272476141};\\\", \\\"{x:1198,y:313,t:1527272476159};\\\", \\\"{x:1217,y:326,t:1527272476175};\\\", \\\"{x:1247,y:349,t:1527272476192};\\\", \\\"{x:1309,y:403,t:1527272476210};\\\", \\\"{x:1344,y:431,t:1527272476225};\\\", \\\"{x:1367,y:448,t:1527272476241};\\\", \\\"{x:1385,y:460,t:1527272476259};\\\", \\\"{x:1397,y:469,t:1527272476274};\\\", \\\"{x:1403,y:472,t:1527272476291};\\\", \\\"{x:1405,y:474,t:1527272476309};\\\", \\\"{x:1406,y:474,t:1527272476368};\\\", \\\"{x:1410,y:479,t:1527272476384};\\\", \\\"{x:1413,y:486,t:1527272476393};\\\", \\\"{x:1420,y:500,t:1527272476408};\\\", \\\"{x:1426,y:508,t:1527272476424};\\\", \\\"{x:1429,y:513,t:1527272476441};\\\", \\\"{x:1432,y:518,t:1527272476458};\\\", \\\"{x:1434,y:523,t:1527272476474};\\\", \\\"{x:1436,y:529,t:1527272476491};\\\", \\\"{x:1440,y:544,t:1527272476509};\\\", \\\"{x:1442,y:555,t:1527272476524};\\\", \\\"{x:1445,y:568,t:1527272476541};\\\", \\\"{x:1446,y:581,t:1527272476559};\\\", \\\"{x:1448,y:590,t:1527272476574};\\\", \\\"{x:1451,y:597,t:1527272476592};\\\", \\\"{x:1452,y:605,t:1527272476609};\\\", \\\"{x:1454,y:611,t:1527272476625};\\\", \\\"{x:1456,y:619,t:1527272476641};\\\", \\\"{x:1460,y:630,t:1527272476659};\\\", \\\"{x:1464,y:644,t:1527272476675};\\\", \\\"{x:1466,y:652,t:1527272476692};\\\", \\\"{x:1468,y:657,t:1527272476708};\\\", \\\"{x:1472,y:667,t:1527272476724};\\\", \\\"{x:1479,y:675,t:1527272476741};\\\", \\\"{x:1484,y:685,t:1527272476759};\\\", \\\"{x:1492,y:696,t:1527272476775};\\\", \\\"{x:1502,y:708,t:1527272476792};\\\", \\\"{x:1521,y:730,t:1527272476809};\\\", \\\"{x:1536,y:742,t:1527272476825};\\\", \\\"{x:1552,y:749,t:1527272476842};\\\", \\\"{x:1568,y:756,t:1527272476859};\\\", \\\"{x:1576,y:760,t:1527272476876};\\\", \\\"{x:1586,y:764,t:1527272476892};\\\", \\\"{x:1591,y:767,t:1527272476909};\\\", \\\"{x:1602,y:773,t:1527272476926};\\\", \\\"{x:1615,y:781,t:1527272476942};\\\", \\\"{x:1629,y:789,t:1527272476958};\\\", \\\"{x:1640,y:796,t:1527272476976};\\\", \\\"{x:1649,y:802,t:1527272476992};\\\", \\\"{x:1655,y:806,t:1527272477009};\\\", \\\"{x:1656,y:807,t:1527272477026};\\\", \\\"{x:1656,y:808,t:1527272477042};\\\", \\\"{x:1656,y:810,t:1527272477058};\\\", \\\"{x:1653,y:814,t:1527272477075};\\\", \\\"{x:1645,y:821,t:1527272477091};\\\", \\\"{x:1640,y:826,t:1527272477109};\\\", \\\"{x:1630,y:830,t:1527272477126};\\\", \\\"{x:1625,y:833,t:1527272477142};\\\", \\\"{x:1621,y:837,t:1527272477158};\\\", \\\"{x:1619,y:839,t:1527272477177};\\\", \\\"{x:1617,y:842,t:1527272477192};\\\", \\\"{x:1615,y:847,t:1527272477210};\\\", \\\"{x:1614,y:851,t:1527272477225};\\\", \\\"{x:1612,y:856,t:1527272477242};\\\", \\\"{x:1611,y:859,t:1527272477259};\\\", \\\"{x:1610,y:861,t:1527272477276};\\\", \\\"{x:1610,y:863,t:1527272477292};\\\", \\\"{x:1608,y:864,t:1527272477309};\\\", \\\"{x:1604,y:865,t:1527272477326};\\\", \\\"{x:1602,y:865,t:1527272477342};\\\", \\\"{x:1602,y:866,t:1527272477369};\\\", \\\"{x:1601,y:866,t:1527272477401};\\\", \\\"{x:1598,y:866,t:1527272477410};\\\", \\\"{x:1592,y:866,t:1527272477425};\\\", \\\"{x:1580,y:865,t:1527272477442};\\\", \\\"{x:1558,y:863,t:1527272477459};\\\", \\\"{x:1538,y:860,t:1527272477476};\\\", \\\"{x:1520,y:857,t:1527272477492};\\\", \\\"{x:1493,y:852,t:1527272477509};\\\", \\\"{x:1457,y:838,t:1527272477525};\\\", \\\"{x:1436,y:825,t:1527272477542};\\\", \\\"{x:1415,y:812,t:1527272477558};\\\", \\\"{x:1398,y:799,t:1527272477575};\\\", \\\"{x:1386,y:791,t:1527272477591};\\\", \\\"{x:1382,y:789,t:1527272477608};\\\", \\\"{x:1382,y:786,t:1527272477712};\\\", \\\"{x:1382,y:784,t:1527272477725};\\\", \\\"{x:1382,y:779,t:1527272477741};\\\", \\\"{x:1383,y:771,t:1527272477758};\\\", \\\"{x:1383,y:763,t:1527272477776};\\\", \\\"{x:1383,y:753,t:1527272477792};\\\", \\\"{x:1381,y:747,t:1527272477809};\\\", \\\"{x:1380,y:747,t:1527272477898};\\\", \\\"{x:1380,y:746,t:1527272477945};\\\", \\\"{x:1380,y:745,t:1527272477958};\\\", \\\"{x:1379,y:742,t:1527272477976};\\\", \\\"{x:1378,y:740,t:1527272477992};\\\", \\\"{x:1376,y:736,t:1527272478010};\\\", \\\"{x:1376,y:734,t:1527272478025};\\\", \\\"{x:1374,y:733,t:1527272478042};\\\", \\\"{x:1372,y:731,t:1527272478082};\\\", \\\"{x:1371,y:730,t:1527272478091};\\\", \\\"{x:1369,y:727,t:1527272478109};\\\", \\\"{x:1368,y:726,t:1527272478126};\\\", \\\"{x:1365,y:722,t:1527272478142};\\\", \\\"{x:1360,y:716,t:1527272478158};\\\", \\\"{x:1352,y:712,t:1527272478176};\\\", \\\"{x:1348,y:709,t:1527272478191};\\\", \\\"{x:1345,y:707,t:1527272478209};\\\", \\\"{x:1344,y:706,t:1527272478226};\\\", \\\"{x:1344,y:704,t:1527272478537};\\\", \\\"{x:1344,y:703,t:1527272478553};\\\", \\\"{x:1344,y:702,t:1527272478594};\\\", \\\"{x:1344,y:701,t:1527272478612};\\\", \\\"{x:1345,y:699,t:1527272478626};\\\", \\\"{x:1346,y:699,t:1527272478647};\\\", \\\"{x:1346,y:698,t:1527272478664};\\\", \\\"{x:1347,y:698,t:1527272478680};\\\", \\\"{x:1348,y:697,t:1527272478768};\\\", \\\"{x:1350,y:695,t:1527272478784};\\\", \\\"{x:1351,y:694,t:1527272478792};\\\", \\\"{x:1353,y:693,t:1527272478809};\\\", \\\"{x:1355,y:691,t:1527272478825};\\\", \\\"{x:1356,y:691,t:1527272478842};\\\", \\\"{x:1357,y:690,t:1527272478859};\\\", \\\"{x:1358,y:689,t:1527272478888};\\\", \\\"{x:1359,y:689,t:1527272478897};\\\", \\\"{x:1360,y:689,t:1527272478909};\\\", \\\"{x:1361,y:688,t:1527272478926};\\\", \\\"{x:1361,y:689,t:1527272479097};\\\", \\\"{x:1361,y:690,t:1527272479113};\\\", \\\"{x:1360,y:690,t:1527272479137};\\\", \\\"{x:1359,y:691,t:1527272479153};\\\", \\\"{x:1358,y:691,t:1527272479169};\\\", \\\"{x:1357,y:692,t:1527272479576};\\\", \\\"{x:1356,y:693,t:1527272479656};\\\", \\\"{x:1355,y:694,t:1527272479672};\\\", \\\"{x:1354,y:695,t:1527272479681};\\\", \\\"{x:1353,y:695,t:1527272479697};\\\", \\\"{x:1352,y:696,t:1527272479728};\\\", \\\"{x:1351,y:696,t:1527272481345};\\\", \\\"{x:1350,y:696,t:1527272481360};\\\", \\\"{x:1348,y:696,t:1527272481376};\\\", \\\"{x:1350,y:696,t:1527272481512};\\\", \\\"{x:1352,y:697,t:1527272481528};\\\", \\\"{x:1353,y:697,t:1527272481553};\\\", \\\"{x:1354,y:698,t:1527272481570};\\\", \\\"{x:1356,y:698,t:1527272481585};\\\", \\\"{x:1359,y:698,t:1527272481593};\\\", \\\"{x:1367,y:698,t:1527272481610};\\\", \\\"{x:1379,y:698,t:1527272481625};\\\", \\\"{x:1386,y:698,t:1527272481643};\\\", \\\"{x:1393,y:698,t:1527272481660};\\\", \\\"{x:1398,y:698,t:1527272481676};\\\", \\\"{x:1400,y:698,t:1527272481693};\\\", \\\"{x:1401,y:697,t:1527272481710};\\\", \\\"{x:1402,y:697,t:1527272481762};\\\", \\\"{x:1405,y:697,t:1527272481776};\\\", \\\"{x:1413,y:697,t:1527272481793};\\\", \\\"{x:1415,y:697,t:1527272481810};\\\", \\\"{x:1416,y:696,t:1527272481826};\\\", \\\"{x:1418,y:696,t:1527272482057};\\\", \\\"{x:1425,y:696,t:1527272482064};\\\", \\\"{x:1435,y:693,t:1527272482077};\\\", \\\"{x:1475,y:691,t:1527272482133};\\\", \\\"{x:1478,y:691,t:1527272482346};\\\", \\\"{x:1479,y:691,t:1527272482360};\\\", \\\"{x:1482,y:691,t:1527272482376};\\\", \\\"{x:1485,y:692,t:1527272482393};\\\", \\\"{x:1486,y:692,t:1527272482410};\\\", \\\"{x:1488,y:693,t:1527272482490};\\\", \\\"{x:1490,y:694,t:1527272482514};\\\", \\\"{x:1492,y:695,t:1527272482569};\\\", \\\"{x:1495,y:696,t:1527272482577};\\\", \\\"{x:1507,y:700,t:1527272482593};\\\", \\\"{x:1516,y:702,t:1527272482610};\\\", \\\"{x:1519,y:703,t:1527272482626};\\\", \\\"{x:1521,y:704,t:1527272482643};\\\", \\\"{x:1522,y:704,t:1527272482660};\\\", \\\"{x:1523,y:704,t:1527272482767};\\\", \\\"{x:1526,y:704,t:1527272482775};\\\", \\\"{x:1529,y:704,t:1527272482793};\\\", \\\"{x:1531,y:704,t:1527272482809};\\\", \\\"{x:1532,y:704,t:1527272482832};\\\", \\\"{x:1533,y:704,t:1527272482848};\\\", \\\"{x:1534,y:704,t:1527272482860};\\\", \\\"{x:1536,y:703,t:1527272482876};\\\", \\\"{x:1537,y:702,t:1527272482893};\\\", \\\"{x:1538,y:701,t:1527272483065};\\\", \\\"{x:1539,y:700,t:1527272483105};\\\", \\\"{x:1539,y:699,t:1527272483137};\\\", \\\"{x:1541,y:698,t:1527272483145};\\\", \\\"{x:1542,y:697,t:1527272483161};\\\", \\\"{x:1543,y:695,t:1527272483176};\\\", \\\"{x:1544,y:694,t:1527272483193};\\\", \\\"{x:1544,y:693,t:1527272483272};\\\", \\\"{x:1545,y:692,t:1527272483288};\\\", \\\"{x:1546,y:692,t:1527272483345};\\\", \\\"{x:1547,y:692,t:1527272483361};\\\", \\\"{x:1548,y:692,t:1527272483377};\\\", \\\"{x:1550,y:692,t:1527272483393};\\\", \\\"{x:1552,y:692,t:1527272483411};\\\", \\\"{x:1555,y:692,t:1527272483426};\\\", \\\"{x:1560,y:693,t:1527272483444};\\\", \\\"{x:1570,y:697,t:1527272483460};\\\", \\\"{x:1587,y:698,t:1527272483477};\\\", \\\"{x:1612,y:698,t:1527272483494};\\\", \\\"{x:1626,y:699,t:1527272483511};\\\", \\\"{x:1631,y:699,t:1527272483527};\\\", \\\"{x:1632,y:699,t:1527272483585};\\\", \\\"{x:1634,y:699,t:1527272483610};\\\", \\\"{x:1635,y:699,t:1527272483627};\\\", \\\"{x:1637,y:699,t:1527272483643};\\\", \\\"{x:1637,y:698,t:1527272483729};\\\", \\\"{x:1637,y:697,t:1527272483761};\\\", \\\"{x:1636,y:696,t:1527272483789};\\\", \\\"{x:1635,y:696,t:1527272483813};\\\", \\\"{x:1634,y:696,t:1527272483844};\\\", \\\"{x:1633,y:696,t:1527272483869};\\\", \\\"{x:1632,y:696,t:1527272483893};\\\", \\\"{x:1631,y:696,t:1527272483901};\\\", \\\"{x:1628,y:696,t:1527272483916};\\\", \\\"{x:1625,y:696,t:1527272483931};\\\", \\\"{x:1622,y:696,t:1527272483947};\\\", \\\"{x:1621,y:696,t:1527272483964};\\\", \\\"{x:1620,y:696,t:1527272483981};\\\", \\\"{x:1619,y:696,t:1527272483996};\\\", \\\"{x:1618,y:696,t:1527272484013};\\\", \\\"{x:1615,y:696,t:1527272484031};\\\", \\\"{x:1614,y:696,t:1527272493061};\\\", \\\"{x:1614,y:704,t:1527272493175};\\\", \\\"{x:1611,y:712,t:1527272493182};\\\", \\\"{x:1611,y:727,t:1527272493200};\\\", \\\"{x:1611,y:742,t:1527272493215};\\\", \\\"{x:1611,y:760,t:1527272493231};\\\", \\\"{x:1611,y:779,t:1527272493249};\\\", \\\"{x:1611,y:801,t:1527272493264};\\\", \\\"{x:1614,y:816,t:1527272493281};\\\", \\\"{x:1614,y:825,t:1527272493299};\\\", \\\"{x:1614,y:829,t:1527272493315};\\\", \\\"{x:1616,y:830,t:1527272493332};\\\", \\\"{x:1616,y:831,t:1527272493364};\\\", \\\"{x:1616,y:832,t:1527272493380};\\\", \\\"{x:1616,y:833,t:1527272493387};\\\", \\\"{x:1616,y:835,t:1527272493399};\\\", \\\"{x:1616,y:840,t:1527272493415};\\\", \\\"{x:1616,y:842,t:1527272493432};\\\", \\\"{x:1616,y:843,t:1527272493448};\\\", \\\"{x:1615,y:843,t:1527272493644};\\\", \\\"{x:1613,y:842,t:1527272493677};\\\", \\\"{x:1613,y:841,t:1527272493692};\\\", \\\"{x:1613,y:840,t:1527272493701};\\\", \\\"{x:1613,y:839,t:1527272493716};\\\", \\\"{x:1613,y:836,t:1527272493732};\\\", \\\"{x:1613,y:834,t:1527272493749};\\\", \\\"{x:1613,y:833,t:1527272493765};\\\", \\\"{x:1613,y:831,t:1527272493783};\\\", \\\"{x:1613,y:830,t:1527272493886};\\\", \\\"{x:1613,y:829,t:1527272493997};\\\", \\\"{x:1614,y:829,t:1527272494093};\\\", \\\"{x:1615,y:829,t:1527272494101};\\\", \\\"{x:1616,y:829,t:1527272494117};\\\", \\\"{x:1615,y:829,t:1527272494837};\\\", \\\"{x:1614,y:829,t:1527272494849};\\\", \\\"{x:1609,y:828,t:1527272494866};\\\", \\\"{x:1600,y:826,t:1527272494883};\\\", \\\"{x:1582,y:825,t:1527272494899};\\\", \\\"{x:1559,y:822,t:1527272494916};\\\", \\\"{x:1549,y:822,t:1527272494933};\\\", \\\"{x:1542,y:822,t:1527272494950};\\\", \\\"{x:1541,y:822,t:1527272494967};\\\", \\\"{x:1542,y:823,t:1527272495229};\\\", \\\"{x:1542,y:824,t:1527272495237};\\\", \\\"{x:1540,y:825,t:1527272495249};\\\", \\\"{x:1527,y:826,t:1527272495267};\\\", \\\"{x:1513,y:826,t:1527272495282};\\\", \\\"{x:1496,y:826,t:1527272495300};\\\", \\\"{x:1470,y:826,t:1527272495317};\\\", \\\"{x:1463,y:829,t:1527272495333};\\\", \\\"{x:1463,y:830,t:1527272495350};\\\", \\\"{x:1462,y:831,t:1527272495373};\\\", \\\"{x:1462,y:832,t:1527272495404};\\\", \\\"{x:1463,y:832,t:1527272495461};\\\", \\\"{x:1464,y:832,t:1527272495485};\\\", \\\"{x:1465,y:832,t:1527272495509};\\\", \\\"{x:1466,y:832,t:1527272495557};\\\", \\\"{x:1468,y:832,t:1527272495606};\\\", \\\"{x:1469,y:832,t:1527272495617};\\\", \\\"{x:1473,y:832,t:1527272495632};\\\", \\\"{x:1475,y:832,t:1527272495649};\\\", \\\"{x:1472,y:832,t:1527272495741};\\\", \\\"{x:1469,y:832,t:1527272495749};\\\", \\\"{x:1457,y:832,t:1527272495767};\\\", \\\"{x:1431,y:825,t:1527272495783};\\\", \\\"{x:1391,y:813,t:1527272495800};\\\", \\\"{x:1325,y:799,t:1527272495816};\\\", \\\"{x:1242,y:786,t:1527272495833};\\\", \\\"{x:1179,y:763,t:1527272495850};\\\", \\\"{x:1105,y:730,t:1527272495867};\\\", \\\"{x:1016,y:690,t:1527272495883};\\\", \\\"{x:940,y:665,t:1527272495900};\\\", \\\"{x:884,y:641,t:1527272495917};\\\", \\\"{x:862,y:631,t:1527272495934};\\\", \\\"{x:842,y:620,t:1527272495949};\\\", \\\"{x:824,y:612,t:1527272495966};\\\", \\\"{x:806,y:604,t:1527272495987};\\\", \\\"{x:798,y:602,t:1527272496003};\\\", \\\"{x:783,y:594,t:1527272496020};\\\", \\\"{x:768,y:587,t:1527272496037};\\\", \\\"{x:734,y:567,t:1527272496061};\\\", \\\"{x:714,y:559,t:1527272496078};\\\", \\\"{x:710,y:559,t:1527272496094};\\\", \\\"{x:709,y:559,t:1527272496115};\\\", \\\"{x:708,y:559,t:1527272496129};\\\", \\\"{x:705,y:560,t:1527272496145};\\\", \\\"{x:702,y:561,t:1527272496162};\\\", \\\"{x:700,y:561,t:1527272496179};\\\", \\\"{x:696,y:562,t:1527272496195};\\\", \\\"{x:691,y:566,t:1527272496214};\\\", \\\"{x:686,y:574,t:1527272496228};\\\", \\\"{x:679,y:584,t:1527272496245};\\\", \\\"{x:674,y:589,t:1527272496262};\\\", \\\"{x:671,y:592,t:1527272496277};\\\", \\\"{x:667,y:592,t:1527272496295};\\\", \\\"{x:657,y:592,t:1527272496312};\\\", \\\"{x:648,y:592,t:1527272496327};\\\", \\\"{x:643,y:592,t:1527272496344};\\\", \\\"{x:641,y:594,t:1527272496362};\\\", \\\"{x:638,y:594,t:1527272496388};\\\", \\\"{x:635,y:594,t:1527272496396};\\\", \\\"{x:629,y:590,t:1527272496412};\\\", \\\"{x:626,y:587,t:1527272496429};\\\", \\\"{x:626,y:586,t:1527272496452};\\\", \\\"{x:625,y:586,t:1527272496573};\\\", \\\"{x:624,y:586,t:1527272496876};\\\", \\\"{x:621,y:584,t:1527272496884};\\\", \\\"{x:619,y:583,t:1527272496896};\\\", \\\"{x:617,y:582,t:1527272496912};\\\", \\\"{x:611,y:581,t:1527272496929};\\\", \\\"{x:608,y:580,t:1527272496946};\\\", \\\"{x:607,y:580,t:1527272496964};\\\", \\\"{x:606,y:580,t:1527272496979};\\\", \\\"{x:605,y:580,t:1527272496996};\\\", \\\"{x:601,y:581,t:1527272497013};\\\", \\\"{x:590,y:599,t:1527272497030};\\\", \\\"{x:574,y:618,t:1527272497047};\\\", \\\"{x:565,y:634,t:1527272497063};\\\", \\\"{x:558,y:651,t:1527272497079};\\\", \\\"{x:555,y:666,t:1527272497095};\\\", \\\"{x:555,y:669,t:1527272497113};\\\", \\\"{x:555,y:670,t:1527272497163};\\\", \\\"{x:555,y:672,t:1527272497179};\\\", \\\"{x:552,y:680,t:1527272497196};\\\", \\\"{x:552,y:688,t:1527272497213};\\\", \\\"{x:551,y:695,t:1527272497229};\\\", \\\"{x:550,y:702,t:1527272497246};\\\", \\\"{x:548,y:713,t:1527272497263};\\\", \\\"{x:547,y:724,t:1527272497280};\\\", \\\"{x:543,y:738,t:1527272497296};\\\", \\\"{x:538,y:753,t:1527272497313};\\\", \\\"{x:533,y:763,t:1527272497330};\\\", \\\"{x:532,y:768,t:1527272497346};\\\", \\\"{x:529,y:771,t:1527272497363};\\\", \\\"{x:529,y:772,t:1527272497379};\\\", \\\"{x:527,y:772,t:1527272497428};\\\", \\\"{x:526,y:772,t:1527272497447};\\\", \\\"{x:525,y:771,t:1527272497533};\\\", \\\"{x:525,y:768,t:1527272497546};\\\", \\\"{x:525,y:753,t:1527272497564};\\\", \\\"{x:525,y:738,t:1527272497579};\\\", \\\"{x:525,y:723,t:1527272497596};\\\", \\\"{x:525,y:721,t:1527272497614};\\\", \\\"{x:524,y:719,t:1527272497979};\\\", \\\"{x:523,y:719,t:1527272497997};\\\", \\\"{x:528,y:717,t:1527272498164};\\\", \\\"{x:556,y:716,t:1527272498180};\\\", \\\"{x:585,y:716,t:1527272498196};\\\", \\\"{x:619,y:716,t:1527272498213};\\\", \\\"{x:668,y:719,t:1527272498230};\\\", \\\"{x:706,y:722,t:1527272498247};\\\", \\\"{x:732,y:726,t:1527272498263};\\\", \\\"{x:742,y:726,t:1527272498281};\\\", \\\"{x:744,y:726,t:1527272498297};\\\", \\\"{x:745,y:726,t:1527272498573};\\\", \\\"{x:745,y:725,t:1527272498588};\\\", \\\"{x:745,y:723,t:1527272498597};\\\", \\\"{x:745,y:722,t:1527272498614};\\\", \\\"{x:745,y:720,t:1527272498630};\\\", \\\"{x:745,y:719,t:1527272498676};\\\", \\\"{x:745,y:717,t:1527272498821};\\\", \\\"{x:745,y:716,t:1527272498836};\\\", \\\"{x:746,y:715,t:1527272498847};\\\", \\\"{x:747,y:714,t:1527272498864};\\\", \\\"{x:747,y:713,t:1527272498880};\\\", \\\"{x:748,y:712,t:1527272498898};\\\", \\\"{x:750,y:710,t:1527272498914};\\\", \\\"{x:753,y:707,t:1527272498974};\\\", \\\"{x:754,y:706,t:1527272498995};\\\", \\\"{x:755,y:706,t:1527272499052};\\\" ] }, { \\\"rt\\\": 10991, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 1046537, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:768,y:706,t:1527272499184};\\\", \\\"{x:774,y:706,t:1527272499214};\\\", \\\"{x:780,y:704,t:1527272499231};\\\", \\\"{x:784,y:704,t:1527272499247};\\\", \\\"{x:785,y:703,t:1527272499264};\\\", \\\"{x:790,y:700,t:1527272499281};\\\", \\\"{x:794,y:697,t:1527272499317};\\\", \\\"{x:797,y:695,t:1527272499444};\\\", \\\"{x:798,y:693,t:1527272499452};\\\", \\\"{x:800,y:691,t:1527272499464};\\\", \\\"{x:804,y:688,t:1527272499481};\\\", \\\"{x:810,y:683,t:1527272499498};\\\", \\\"{x:815,y:679,t:1527272499514};\\\", \\\"{x:818,y:677,t:1527272499531};\\\", \\\"{x:821,y:677,t:1527272499548};\\\", \\\"{x:830,y:679,t:1527272500965};\\\", \\\"{x:928,y:718,t:1527272500983};\\\", \\\"{x:1047,y:780,t:1527272501000};\\\", \\\"{x:1176,y:852,t:1527272501016};\\\", \\\"{x:1306,y:913,t:1527272501033};\\\", \\\"{x:1416,y:963,t:1527272501050};\\\", \\\"{x:1487,y:997,t:1527272501066};\\\", \\\"{x:1510,y:1010,t:1527272501083};\\\", \\\"{x:1512,y:1013,t:1527272501100};\\\", \\\"{x:1511,y:1015,t:1527272501117};\\\", \\\"{x:1506,y:1020,t:1527272501133};\\\", \\\"{x:1503,y:1025,t:1527272501149};\\\", \\\"{x:1497,y:1041,t:1527272501167};\\\", \\\"{x:1497,y:1066,t:1527272501183};\\\", \\\"{x:1505,y:1094,t:1527272501199};\\\", \\\"{x:1518,y:1119,t:1527272501216};\\\", \\\"{x:1528,y:1131,t:1527272501233};\\\", \\\"{x:1529,y:1131,t:1527272501250};\\\", \\\"{x:1529,y:1129,t:1527272501266};\\\", \\\"{x:1527,y:1111,t:1527272501282};\\\", \\\"{x:1520,y:1088,t:1527272501299};\\\", \\\"{x:1494,y:1073,t:1527272501317};\\\", \\\"{x:1477,y:1064,t:1527272501332};\\\", \\\"{x:1460,y:1056,t:1527272501350};\\\", \\\"{x:1444,y:1050,t:1527272501367};\\\", \\\"{x:1435,y:1047,t:1527272501382};\\\", \\\"{x:1434,y:1046,t:1527272501405};\\\", \\\"{x:1433,y:1046,t:1527272501416};\\\", \\\"{x:1431,y:1046,t:1527272501432};\\\", \\\"{x:1427,y:1043,t:1527272501449};\\\", \\\"{x:1425,y:1042,t:1527272501466};\\\", \\\"{x:1424,y:1040,t:1527272501483};\\\", \\\"{x:1421,y:1038,t:1527272501500};\\\", \\\"{x:1412,y:1030,t:1527272501516};\\\", \\\"{x:1399,y:1019,t:1527272501532};\\\", \\\"{x:1388,y:1009,t:1527272501549};\\\", \\\"{x:1381,y:1004,t:1527272501566};\\\", \\\"{x:1381,y:1003,t:1527272501620};\\\", \\\"{x:1381,y:1002,t:1527272501633};\\\", \\\"{x:1381,y:999,t:1527272501649};\\\", \\\"{x:1381,y:997,t:1527272501667};\\\", \\\"{x:1380,y:997,t:1527272501684};\\\", \\\"{x:1379,y:995,t:1527272501699};\\\", \\\"{x:1374,y:983,t:1527272501717};\\\", \\\"{x:1370,y:975,t:1527272501733};\\\", \\\"{x:1368,y:972,t:1527272501750};\\\", \\\"{x:1367,y:970,t:1527272501767};\\\", \\\"{x:1366,y:970,t:1527272501877};\\\", \\\"{x:1365,y:970,t:1527272501884};\\\", \\\"{x:1364,y:969,t:1527272501901};\\\", \\\"{x:1363,y:968,t:1527272501917};\\\", \\\"{x:1361,y:968,t:1527272501981};\\\", \\\"{x:1358,y:968,t:1527272501988};\\\", \\\"{x:1354,y:968,t:1527272502001};\\\", \\\"{x:1344,y:968,t:1527272502017};\\\", \\\"{x:1337,y:968,t:1527272502034};\\\", \\\"{x:1334,y:968,t:1527272502051};\\\", \\\"{x:1335,y:968,t:1527272502133};\\\", \\\"{x:1336,y:967,t:1527272502150};\\\", \\\"{x:1338,y:967,t:1527272502166};\\\", \\\"{x:1341,y:967,t:1527272502184};\\\", \\\"{x:1343,y:966,t:1527272502201};\\\", \\\"{x:1346,y:964,t:1527272502217};\\\", \\\"{x:1347,y:963,t:1527272502236};\\\", \\\"{x:1348,y:963,t:1527272502251};\\\", \\\"{x:1349,y:961,t:1527272502266};\\\", \\\"{x:1349,y:958,t:1527272502284};\\\", \\\"{x:1349,y:955,t:1527272502300};\\\", \\\"{x:1349,y:954,t:1527272502317};\\\", \\\"{x:1348,y:948,t:1527272502334};\\\", \\\"{x:1348,y:944,t:1527272502351};\\\", \\\"{x:1348,y:939,t:1527272502367};\\\", \\\"{x:1348,y:931,t:1527272502384};\\\", \\\"{x:1348,y:927,t:1527272502401};\\\", \\\"{x:1348,y:922,t:1527272502418};\\\", \\\"{x:1348,y:917,t:1527272502434};\\\", \\\"{x:1348,y:912,t:1527272502451};\\\", \\\"{x:1348,y:905,t:1527272502468};\\\", \\\"{x:1348,y:896,t:1527272502484};\\\", \\\"{x:1348,y:890,t:1527272502501};\\\", \\\"{x:1348,y:889,t:1527272502518};\\\", \\\"{x:1348,y:887,t:1527272502534};\\\", \\\"{x:1348,y:882,t:1527272502551};\\\", \\\"{x:1350,y:879,t:1527272502568};\\\", \\\"{x:1351,y:874,t:1527272502583};\\\", \\\"{x:1353,y:868,t:1527272502601};\\\", \\\"{x:1353,y:863,t:1527272502618};\\\", \\\"{x:1353,y:859,t:1527272502634};\\\", \\\"{x:1353,y:856,t:1527272502650};\\\", \\\"{x:1353,y:853,t:1527272502668};\\\", \\\"{x:1353,y:851,t:1527272502684};\\\", \\\"{x:1353,y:847,t:1527272502701};\\\", \\\"{x:1353,y:844,t:1527272502718};\\\", \\\"{x:1353,y:840,t:1527272502734};\\\", \\\"{x:1353,y:839,t:1527272502751};\\\", \\\"{x:1353,y:836,t:1527272502768};\\\", \\\"{x:1353,y:831,t:1527272502784};\\\", \\\"{x:1353,y:825,t:1527272502801};\\\", \\\"{x:1353,y:816,t:1527272502818};\\\", \\\"{x:1353,y:806,t:1527272502834};\\\", \\\"{x:1353,y:801,t:1527272502851};\\\", \\\"{x:1353,y:798,t:1527272502868};\\\", \\\"{x:1353,y:794,t:1527272502884};\\\", \\\"{x:1353,y:791,t:1527272502901};\\\", \\\"{x:1353,y:786,t:1527272502918};\\\", \\\"{x:1353,y:783,t:1527272502935};\\\", \\\"{x:1353,y:780,t:1527272502951};\\\", \\\"{x:1353,y:777,t:1527272502968};\\\", \\\"{x:1352,y:776,t:1527272503077};\\\", \\\"{x:1351,y:775,t:1527272503156};\\\", \\\"{x:1350,y:774,t:1527272503168};\\\", \\\"{x:1349,y:773,t:1527272503185};\\\", \\\"{x:1349,y:771,t:1527272503245};\\\", \\\"{x:1349,y:770,t:1527272503268};\\\", \\\"{x:1349,y:769,t:1527272503363};\\\", \\\"{x:1348,y:769,t:1527272503372};\\\", \\\"{x:1348,y:768,t:1527272503386};\\\", \\\"{x:1348,y:766,t:1527272503629};\\\", \\\"{x:1347,y:765,t:1527272503636};\\\", \\\"{x:1347,y:764,t:1527272504125};\\\", \\\"{x:1347,y:763,t:1527272506765};\\\", \\\"{x:1341,y:747,t:1527272506774};\\\", \\\"{x:1315,y:713,t:1527272506786};\\\", \\\"{x:1152,y:612,t:1527272506804};\\\", \\\"{x:1028,y:556,t:1527272506820};\\\", \\\"{x:926,y:509,t:1527272506837};\\\", \\\"{x:842,y:468,t:1527272506853};\\\", \\\"{x:782,y:444,t:1527272506867};\\\", \\\"{x:736,y:435,t:1527272506884};\\\", \\\"{x:689,y:429,t:1527272506900};\\\", \\\"{x:632,y:438,t:1527272506917};\\\", \\\"{x:605,y:449,t:1527272506934};\\\", \\\"{x:590,y:459,t:1527272506950};\\\", \\\"{x:582,y:466,t:1527272506967};\\\", \\\"{x:576,y:473,t:1527272506984};\\\", \\\"{x:575,y:482,t:1527272507001};\\\", \\\"{x:575,y:493,t:1527272507018};\\\", \\\"{x:578,y:505,t:1527272507033};\\\", \\\"{x:581,y:509,t:1527272507053};\\\", \\\"{x:582,y:511,t:1527272507071};\\\", \\\"{x:583,y:511,t:1527272507088};\\\", \\\"{x:584,y:511,t:1527272507104};\\\", \\\"{x:585,y:511,t:1527272507120};\\\", \\\"{x:589,y:511,t:1527272507138};\\\", \\\"{x:595,y:511,t:1527272507155};\\\", \\\"{x:599,y:508,t:1527272507171};\\\", \\\"{x:599,y:504,t:1527272507188};\\\", \\\"{x:599,y:503,t:1527272507204};\\\", \\\"{x:599,y:501,t:1527272507220};\\\", \\\"{x:600,y:501,t:1527272507310};\\\", \\\"{x:603,y:504,t:1527272507321};\\\", \\\"{x:613,y:512,t:1527272507337};\\\", \\\"{x:629,y:515,t:1527272507354};\\\", \\\"{x:664,y:519,t:1527272507372};\\\", \\\"{x:696,y:518,t:1527272507388};\\\", \\\"{x:752,y:510,t:1527272507404};\\\", \\\"{x:806,y:509,t:1527272507420};\\\", \\\"{x:839,y:509,t:1527272507437};\\\", \\\"{x:844,y:508,t:1527272507454};\\\", \\\"{x:843,y:508,t:1527272507868};\\\", \\\"{x:837,y:506,t:1527272507875};\\\", \\\"{x:816,y:504,t:1527272507888};\\\", \\\"{x:735,y:491,t:1527272507904};\\\", \\\"{x:692,y:488,t:1527272507922};\\\", \\\"{x:669,y:488,t:1527272507938};\\\", \\\"{x:647,y:494,t:1527272507954};\\\", \\\"{x:625,y:509,t:1527272507972};\\\", \\\"{x:608,y:519,t:1527272507988};\\\", \\\"{x:592,y:524,t:1527272508004};\\\", \\\"{x:575,y:527,t:1527272508023};\\\", \\\"{x:564,y:530,t:1527272508039};\\\", \\\"{x:549,y:535,t:1527272508054};\\\", \\\"{x:541,y:540,t:1527272508072};\\\", \\\"{x:537,y:543,t:1527272508089};\\\", \\\"{x:535,y:544,t:1527272508149};\\\", \\\"{x:530,y:544,t:1527272508156};\\\", \\\"{x:510,y:545,t:1527272508172};\\\", \\\"{x:489,y:550,t:1527272508190};\\\", \\\"{x:475,y:557,t:1527272508205};\\\", \\\"{x:459,y:565,t:1527272508222};\\\", \\\"{x:442,y:575,t:1527272508238};\\\", \\\"{x:420,y:589,t:1527272508255};\\\", \\\"{x:398,y:604,t:1527272508272};\\\", \\\"{x:379,y:617,t:1527272508288};\\\", \\\"{x:368,y:624,t:1527272508305};\\\", \\\"{x:360,y:628,t:1527272508321};\\\", \\\"{x:353,y:631,t:1527272508338};\\\", \\\"{x:351,y:631,t:1527272508355};\\\", \\\"{x:342,y:630,t:1527272508371};\\\", \\\"{x:316,y:614,t:1527272508389};\\\", \\\"{x:277,y:589,t:1527272508406};\\\", \\\"{x:236,y:563,t:1527272508422};\\\", \\\"{x:199,y:542,t:1527272508439};\\\", \\\"{x:178,y:535,t:1527272508456};\\\", \\\"{x:173,y:533,t:1527272508472};\\\", \\\"{x:172,y:533,t:1527272508488};\\\", \\\"{x:171,y:533,t:1527272508597};\\\", \\\"{x:172,y:533,t:1527272508740};\\\", \\\"{x:186,y:536,t:1527272508996};\\\", \\\"{x:219,y:543,t:1527272509006};\\\", \\\"{x:317,y:562,t:1527272509023};\\\", \\\"{x:419,y:592,t:1527272509038};\\\", \\\"{x:479,y:617,t:1527272509056};\\\", \\\"{x:497,y:631,t:1527272509072};\\\", \\\"{x:511,y:640,t:1527272509089};\\\", \\\"{x:520,y:645,t:1527272509105};\\\", \\\"{x:521,y:645,t:1527272509122};\\\", \\\"{x:521,y:646,t:1527272509163};\\\", \\\"{x:521,y:648,t:1527272509180};\\\", \\\"{x:522,y:650,t:1527272509196};\\\", \\\"{x:523,y:651,t:1527272509206};\\\", \\\"{x:523,y:652,t:1527272509222};\\\", \\\"{x:523,y:654,t:1527272509238};\\\", \\\"{x:522,y:658,t:1527272509255};\\\", \\\"{x:521,y:661,t:1527272509273};\\\", \\\"{x:519,y:667,t:1527272509290};\\\", \\\"{x:518,y:672,t:1527272509306};\\\", \\\"{x:517,y:677,t:1527272509323};\\\", \\\"{x:517,y:684,t:1527272509339};\\\", \\\"{x:517,y:691,t:1527272509357};\\\", \\\"{x:517,y:705,t:1527272509373};\\\", \\\"{x:517,y:712,t:1527272509390};\\\", \\\"{x:517,y:720,t:1527272509408};\\\", \\\"{x:517,y:726,t:1527272509423};\\\", \\\"{x:516,y:729,t:1527272509440};\\\", \\\"{x:515,y:731,t:1527272509456};\\\", \\\"{x:515,y:732,t:1527272509472};\\\", \\\"{x:515,y:734,t:1527272509491};\\\", \\\"{x:515,y:735,t:1527272509508};\\\", \\\"{x:515,y:737,t:1527272509523};\\\", \\\"{x:513,y:746,t:1527272509539};\\\", \\\"{x:512,y:750,t:1527272509556};\\\", \\\"{x:512,y:752,t:1527272509573};\\\", \\\"{x:512,y:755,t:1527272509590};\\\", \\\"{x:512,y:756,t:1527272509612};\\\", \\\"{x:511,y:756,t:1527272509764};\\\", \\\"{x:509,y:756,t:1527272509869};\\\", \\\"{x:509,y:753,t:1527272509886};\\\", \\\"{x:506,y:748,t:1527272509905};\\\", \\\"{x:506,y:746,t:1527272509922};\\\", \\\"{x:506,y:743,t:1527272509939};\\\", \\\"{x:506,y:742,t:1527272509957};\\\", \\\"{x:506,y:740,t:1527272509974};\\\", \\\"{x:506,y:739,t:1527272510291};\\\", \\\"{x:506,y:738,t:1527272510307};\\\", \\\"{x:506,y:737,t:1527272510323};\\\", \\\"{x:507,y:735,t:1527272510340};\\\", \\\"{x:509,y:732,t:1527272510356};\\\", \\\"{x:518,y:723,t:1527272510374};\\\", \\\"{x:543,y:710,t:1527272510389};\\\", \\\"{x:592,y:701,t:1527272510406};\\\", \\\"{x:687,y:698,t:1527272510424};\\\", \\\"{x:801,y:701,t:1527272510439};\\\", \\\"{x:913,y:721,t:1527272510456};\\\", \\\"{x:1003,y:738,t:1527272510474};\\\", \\\"{x:1057,y:750,t:1527272510490};\\\", \\\"{x:1084,y:753,t:1527272510506};\\\", \\\"{x:1092,y:753,t:1527272510523};\\\", \\\"{x:1093,y:753,t:1527272510539};\\\", \\\"{x:1094,y:753,t:1527272510612};\\\", \\\"{x:1091,y:753,t:1527272510644};\\\", \\\"{x:1087,y:752,t:1527272510657};\\\", \\\"{x:1076,y:751,t:1527272510674};\\\", \\\"{x:1059,y:747,t:1527272510690};\\\", \\\"{x:1032,y:744,t:1527272510707};\\\", \\\"{x:989,y:735,t:1527272510724};\\\", \\\"{x:963,y:732,t:1527272510740};\\\", \\\"{x:946,y:730,t:1527272510756};\\\", \\\"{x:938,y:730,t:1527272510774};\\\", \\\"{x:934,y:730,t:1527272510789};\\\", \\\"{x:933,y:730,t:1527272510948};\\\", \\\"{x:933,y:731,t:1527272510980};\\\", \\\"{x:933,y:733,t:1527272511028};\\\", \\\"{x:933,y:734,t:1527272511044};\\\", \\\"{x:933,y:736,t:1527272511057};\\\", \\\"{x:934,y:739,t:1527272511073};\\\", \\\"{x:935,y:740,t:1527272511091};\\\", \\\"{x:935,y:741,t:1527272511107};\\\", \\\"{x:935,y:746,t:1527272511124};\\\", \\\"{x:930,y:750,t:1527272511140};\\\", \\\"{x:922,y:753,t:1527272511157};\\\", \\\"{x:908,y:757,t:1527272511173};\\\", \\\"{x:875,y:763,t:1527272511209};\\\", \\\"{x:859,y:764,t:1527272511224};\\\", \\\"{x:844,y:764,t:1527272511240};\\\", \\\"{x:827,y:764,t:1527272511256};\\\", \\\"{x:814,y:764,t:1527272511273};\\\" ] }, { \\\"rt\\\": 16626, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 1064394, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:774,y:748,t:1527272511410};\\\", \\\"{x:773,y:748,t:1527272511451};\\\", \\\"{x:773,y:747,t:1527272511460};\\\", \\\"{x:772,y:745,t:1527272511474};\\\", \\\"{x:770,y:742,t:1527272511498};\\\", \\\"{x:769,y:741,t:1527272511508};\\\", \\\"{x:767,y:739,t:1527272511525};\\\", \\\"{x:764,y:738,t:1527272511540};\\\", \\\"{x:760,y:737,t:1527272511558};\\\", \\\"{x:755,y:736,t:1527272511575};\\\", \\\"{x:751,y:735,t:1527272511591};\\\", \\\"{x:748,y:735,t:1527272511608};\\\", \\\"{x:747,y:735,t:1527272511624};\\\", \\\"{x:746,y:735,t:1527272511651};\\\", \\\"{x:745,y:735,t:1527272511660};\\\", \\\"{x:744,y:733,t:1527272511675};\\\", \\\"{x:742,y:730,t:1527272511692};\\\", \\\"{x:740,y:723,t:1527272511708};\\\", \\\"{x:735,y:711,t:1527272511724};\\\", \\\"{x:731,y:701,t:1527272511740};\\\", \\\"{x:726,y:690,t:1527272511758};\\\", \\\"{x:721,y:682,t:1527272511775};\\\", \\\"{x:672,y:556,t:1527272511860};\\\", \\\"{x:663,y:540,t:1527272511877};\\\", \\\"{x:659,y:523,t:1527272511892};\\\", \\\"{x:658,y:505,t:1527272511908};\\\", \\\"{x:658,y:494,t:1527272511931};\\\", \\\"{x:662,y:483,t:1527272511941};\\\", \\\"{x:666,y:480,t:1527272511958};\\\", \\\"{x:671,y:479,t:1527272511974};\\\", \\\"{x:672,y:478,t:1527272511991};\\\", \\\"{x:674,y:477,t:1527272512008};\\\", \\\"{x:675,y:477,t:1527272512025};\\\", \\\"{x:677,y:477,t:1527272512068};\\\", \\\"{x:677,y:476,t:1527272512277};\\\", \\\"{x:674,y:473,t:1527272512292};\\\", \\\"{x:669,y:470,t:1527272512308};\\\", \\\"{x:666,y:469,t:1527272512326};\\\", \\\"{x:660,y:468,t:1527272512342};\\\", \\\"{x:654,y:466,t:1527272512359};\\\", \\\"{x:647,y:464,t:1527272512376};\\\", \\\"{x:644,y:463,t:1527272512392};\\\", \\\"{x:643,y:461,t:1527272512411};\\\", \\\"{x:642,y:461,t:1527272512426};\\\", \\\"{x:641,y:461,t:1527272512452};\\\", \\\"{x:640,y:461,t:1527272512493};\\\", \\\"{x:639,y:461,t:1527272512510};\\\", \\\"{x:640,y:461,t:1527272512661};\\\", \\\"{x:645,y:459,t:1527272512676};\\\", \\\"{x:651,y:458,t:1527272512693};\\\", \\\"{x:660,y:457,t:1527272512709};\\\", \\\"{x:670,y:455,t:1527272512726};\\\", \\\"{x:690,y:454,t:1527272512743};\\\", \\\"{x:709,y:454,t:1527272512760};\\\", \\\"{x:729,y:454,t:1527272512776};\\\", \\\"{x:746,y:454,t:1527272512793};\\\", \\\"{x:766,y:454,t:1527272512811};\\\", \\\"{x:781,y:454,t:1527272512826};\\\", \\\"{x:821,y:457,t:1527272512843};\\\", \\\"{x:920,y:481,t:1527272512860};\\\", \\\"{x:1015,y:511,t:1527272512877};\\\", \\\"{x:1127,y:555,t:1527272512893};\\\", \\\"{x:1229,y:602,t:1527272512910};\\\", \\\"{x:1320,y:642,t:1527272512927};\\\", \\\"{x:1390,y:672,t:1527272512944};\\\", \\\"{x:1442,y:695,t:1527272512960};\\\", \\\"{x:1473,y:708,t:1527272512977};\\\", \\\"{x:1482,y:714,t:1527272512994};\\\", \\\"{x:1484,y:716,t:1527272513010};\\\", \\\"{x:1485,y:716,t:1527272513092};\\\", \\\"{x:1486,y:717,t:1527272513221};\\\", \\\"{x:1486,y:719,t:1527272513228};\\\", \\\"{x:1486,y:726,t:1527272513245};\\\", \\\"{x:1488,y:737,t:1527272513259};\\\", \\\"{x:1500,y:750,t:1527272513276};\\\", \\\"{x:1515,y:765,t:1527272513295};\\\", \\\"{x:1525,y:774,t:1527272513310};\\\", \\\"{x:1531,y:779,t:1527272513327};\\\", \\\"{x:1533,y:780,t:1527272513344};\\\", \\\"{x:1535,y:780,t:1527272513404};\\\", \\\"{x:1538,y:780,t:1527272513412};\\\", \\\"{x:1542,y:780,t:1527272513427};\\\", \\\"{x:1562,y:780,t:1527272513444};\\\", \\\"{x:1576,y:782,t:1527272513461};\\\", \\\"{x:1596,y:785,t:1527272513477};\\\", \\\"{x:1618,y:787,t:1527272513494};\\\", \\\"{x:1640,y:787,t:1527272513511};\\\", \\\"{x:1666,y:785,t:1527272513527};\\\", \\\"{x:1705,y:774,t:1527272513544};\\\", \\\"{x:1746,y:772,t:1527272513562};\\\", \\\"{x:1769,y:771,t:1527272513578};\\\", \\\"{x:1777,y:772,t:1527272513594};\\\", \\\"{x:1779,y:772,t:1527272513611};\\\", \\\"{x:1780,y:772,t:1527272513685};\\\", \\\"{x:1784,y:770,t:1527272513694};\\\", \\\"{x:1793,y:760,t:1527272513712};\\\", \\\"{x:1797,y:749,t:1527272513728};\\\", \\\"{x:1799,y:736,t:1527272513746};\\\", \\\"{x:1799,y:713,t:1527272513762};\\\", \\\"{x:1799,y:648,t:1527272513778};\\\", \\\"{x:1766,y:569,t:1527272513795};\\\", \\\"{x:1737,y:519,t:1527272513812};\\\", \\\"{x:1703,y:490,t:1527272513828};\\\", \\\"{x:1682,y:483,t:1527272513845};\\\", \\\"{x:1666,y:478,t:1527272513862};\\\", \\\"{x:1662,y:478,t:1527272513878};\\\", \\\"{x:1660,y:478,t:1527272513895};\\\", \\\"{x:1658,y:488,t:1527272513911};\\\", \\\"{x:1658,y:512,t:1527272513928};\\\", \\\"{x:1660,y:537,t:1527272513945};\\\", \\\"{x:1665,y:553,t:1527272513962};\\\", \\\"{x:1667,y:557,t:1527272513978};\\\", \\\"{x:1669,y:564,t:1527272513995};\\\", \\\"{x:1674,y:574,t:1527272514012};\\\", \\\"{x:1675,y:578,t:1527272514028};\\\", \\\"{x:1675,y:580,t:1527272514044};\\\", \\\"{x:1675,y:584,t:1527272514062};\\\", \\\"{x:1675,y:591,t:1527272514078};\\\", \\\"{x:1671,y:604,t:1527272514095};\\\", \\\"{x:1663,y:624,t:1527272514112};\\\", \\\"{x:1658,y:639,t:1527272514127};\\\", \\\"{x:1653,y:652,t:1527272514145};\\\", \\\"{x:1645,y:668,t:1527272514162};\\\", \\\"{x:1637,y:683,t:1527272514179};\\\", \\\"{x:1626,y:699,t:1527272514195};\\\", \\\"{x:1611,y:720,t:1527272514212};\\\", \\\"{x:1600,y:735,t:1527272514229};\\\", \\\"{x:1589,y:748,t:1527272514245};\\\", \\\"{x:1581,y:759,t:1527272514262};\\\", \\\"{x:1579,y:764,t:1527272514279};\\\", \\\"{x:1578,y:765,t:1527272514295};\\\", \\\"{x:1577,y:766,t:1527272514356};\\\", \\\"{x:1577,y:767,t:1527272514373};\\\", \\\"{x:1576,y:767,t:1527272514380};\\\", \\\"{x:1573,y:767,t:1527272514396};\\\", \\\"{x:1572,y:768,t:1527272514412};\\\", \\\"{x:1571,y:768,t:1527272514453};\\\", \\\"{x:1569,y:768,t:1527272514462};\\\", \\\"{x:1552,y:742,t:1527272514479};\\\", \\\"{x:1514,y:689,t:1527272514496};\\\", \\\"{x:1495,y:664,t:1527272514512};\\\", \\\"{x:1486,y:651,t:1527272514529};\\\", \\\"{x:1482,y:639,t:1527272514546};\\\", \\\"{x:1482,y:626,t:1527272514564};\\\", \\\"{x:1486,y:617,t:1527272514580};\\\", \\\"{x:1507,y:601,t:1527272514597};\\\", \\\"{x:1522,y:593,t:1527272514612};\\\", \\\"{x:1535,y:590,t:1527272514629};\\\", \\\"{x:1544,y:586,t:1527272514646};\\\", \\\"{x:1548,y:583,t:1527272514662};\\\", \\\"{x:1554,y:579,t:1527272514679};\\\", \\\"{x:1557,y:578,t:1527272514696};\\\", \\\"{x:1559,y:577,t:1527272514712};\\\", \\\"{x:1560,y:580,t:1527272514837};\\\", \\\"{x:1560,y:590,t:1527272514846};\\\", \\\"{x:1561,y:612,t:1527272514863};\\\", \\\"{x:1564,y:630,t:1527272514881};\\\", \\\"{x:1566,y:644,t:1527272514896};\\\", \\\"{x:1566,y:650,t:1527272514914};\\\", \\\"{x:1566,y:656,t:1527272514930};\\\", \\\"{x:1563,y:666,t:1527272514947};\\\", \\\"{x:1559,y:674,t:1527272514963};\\\", \\\"{x:1551,y:690,t:1527272514980};\\\", \\\"{x:1543,y:701,t:1527272514997};\\\", \\\"{x:1536,y:708,t:1527272515013};\\\", \\\"{x:1524,y:712,t:1527272515031};\\\", \\\"{x:1506,y:715,t:1527272515048};\\\", \\\"{x:1484,y:718,t:1527272515063};\\\", \\\"{x:1463,y:724,t:1527272515081};\\\", \\\"{x:1433,y:731,t:1527272515097};\\\", \\\"{x:1402,y:741,t:1527272515114};\\\", \\\"{x:1382,y:746,t:1527272515130};\\\", \\\"{x:1375,y:747,t:1527272515148};\\\", \\\"{x:1372,y:748,t:1527272515163};\\\", \\\"{x:1368,y:750,t:1527272515181};\\\", \\\"{x:1363,y:751,t:1527272515197};\\\", \\\"{x:1357,y:755,t:1527272515214};\\\", \\\"{x:1353,y:755,t:1527272515231};\\\", \\\"{x:1350,y:755,t:1527272515247};\\\", \\\"{x:1349,y:755,t:1527272515265};\\\", \\\"{x:1346,y:754,t:1527272515281};\\\", \\\"{x:1344,y:752,t:1527272515297};\\\", \\\"{x:1343,y:750,t:1527272515314};\\\", \\\"{x:1343,y:748,t:1527272515331};\\\", \\\"{x:1343,y:745,t:1527272515348};\\\", \\\"{x:1343,y:736,t:1527272515365};\\\", \\\"{x:1343,y:727,t:1527272515381};\\\", \\\"{x:1343,y:714,t:1527272515397};\\\", \\\"{x:1344,y:710,t:1527272515415};\\\", \\\"{x:1346,y:709,t:1527272515509};\\\", \\\"{x:1347,y:709,t:1527272515516};\\\", \\\"{x:1349,y:708,t:1527272515532};\\\", \\\"{x:1352,y:705,t:1527272515548};\\\", \\\"{x:1353,y:704,t:1527272515565};\\\", \\\"{x:1353,y:703,t:1527272515621};\\\", \\\"{x:1353,y:702,t:1527272515637};\\\", \\\"{x:1353,y:701,t:1527272515717};\\\", \\\"{x:1353,y:700,t:1527272515733};\\\", \\\"{x:1353,y:699,t:1527272515749};\\\", \\\"{x:1353,y:698,t:1527272515765};\\\", \\\"{x:1351,y:698,t:1527272515781};\\\", \\\"{x:1348,y:696,t:1527272515798};\\\", \\\"{x:1347,y:696,t:1527272515815};\\\", \\\"{x:1345,y:693,t:1527272519725};\\\", \\\"{x:1338,y:692,t:1527272519739};\\\", \\\"{x:1323,y:689,t:1527272519755};\\\", \\\"{x:1313,y:687,t:1527272519771};\\\", \\\"{x:1309,y:687,t:1527272519788};\\\", \\\"{x:1305,y:687,t:1527272519806};\\\", \\\"{x:1303,y:687,t:1527272519822};\\\", \\\"{x:1300,y:687,t:1527272519839};\\\", \\\"{x:1297,y:687,t:1527272519855};\\\", \\\"{x:1296,y:687,t:1527272519872};\\\", \\\"{x:1294,y:687,t:1527272519889};\\\", \\\"{x:1292,y:687,t:1527272519906};\\\", \\\"{x:1290,y:687,t:1527272519922};\\\", \\\"{x:1285,y:687,t:1527272519939};\\\", \\\"{x:1279,y:687,t:1527272519956};\\\", \\\"{x:1273,y:687,t:1527272519972};\\\", \\\"{x:1261,y:681,t:1527272519988};\\\", \\\"{x:1247,y:672,t:1527272520006};\\\", \\\"{x:1229,y:662,t:1527272520023};\\\", \\\"{x:1208,y:651,t:1527272520038};\\\", \\\"{x:1183,y:640,t:1527272520055};\\\", \\\"{x:1153,y:627,t:1527272520072};\\\", \\\"{x:1133,y:617,t:1527272520089};\\\", \\\"{x:1121,y:611,t:1527272520105};\\\", \\\"{x:1112,y:607,t:1527272520123};\\\", \\\"{x:1105,y:605,t:1527272520138};\\\", \\\"{x:1097,y:602,t:1527272520155};\\\", \\\"{x:1088,y:598,t:1527272520172};\\\", \\\"{x:1083,y:597,t:1527272520188};\\\", \\\"{x:1074,y:592,t:1527272520205};\\\", \\\"{x:1066,y:588,t:1527272520223};\\\", \\\"{x:1056,y:583,t:1527272520240};\\\", \\\"{x:1043,y:578,t:1527272520256};\\\", \\\"{x:1034,y:571,t:1527272520273};\\\", \\\"{x:1021,y:568,t:1527272520290};\\\", \\\"{x:1006,y:564,t:1527272520306};\\\", \\\"{x:990,y:561,t:1527272520323};\\\", \\\"{x:980,y:561,t:1527272520340};\\\", \\\"{x:967,y:561,t:1527272520355};\\\", \\\"{x:949,y:561,t:1527272520372};\\\", \\\"{x:934,y:561,t:1527272520389};\\\", \\\"{x:921,y:562,t:1527272520406};\\\", \\\"{x:914,y:564,t:1527272520423};\\\", \\\"{x:909,y:568,t:1527272520439};\\\", \\\"{x:903,y:574,t:1527272520456};\\\", \\\"{x:899,y:580,t:1527272520465};\\\", \\\"{x:888,y:596,t:1527272520482};\\\", \\\"{x:877,y:615,t:1527272520498};\\\", \\\"{x:870,y:629,t:1527272520514};\\\", \\\"{x:864,y:641,t:1527272520532};\\\", \\\"{x:860,y:651,t:1527272520548};\\\", \\\"{x:857,y:654,t:1527272520565};\\\", \\\"{x:852,y:659,t:1527272520582};\\\", \\\"{x:843,y:665,t:1527272520598};\\\", \\\"{x:834,y:671,t:1527272520615};\\\", \\\"{x:823,y:678,t:1527272520632};\\\", \\\"{x:819,y:684,t:1527272520648};\\\", \\\"{x:818,y:689,t:1527272520665};\\\", \\\"{x:816,y:694,t:1527272520682};\\\", \\\"{x:816,y:699,t:1527272520698};\\\", \\\"{x:817,y:709,t:1527272520715};\\\", \\\"{x:825,y:724,t:1527272520732};\\\", \\\"{x:831,y:738,t:1527272520748};\\\", \\\"{x:842,y:754,t:1527272520766};\\\", \\\"{x:853,y:772,t:1527272520783};\\\", \\\"{x:865,y:791,t:1527272520798};\\\", \\\"{x:880,y:813,t:1527272520815};\\\", \\\"{x:899,y:832,t:1527272520832};\\\", \\\"{x:921,y:848,t:1527272520848};\\\", \\\"{x:951,y:865,t:1527272520865};\\\", \\\"{x:999,y:880,t:1527272520883};\\\", \\\"{x:1051,y:893,t:1527272520898};\\\", \\\"{x:1098,y:899,t:1527272520916};\\\", \\\"{x:1142,y:893,t:1527272520932};\\\", \\\"{x:1167,y:876,t:1527272520948};\\\", \\\"{x:1194,y:850,t:1527272520966};\\\", \\\"{x:1221,y:807,t:1527272520983};\\\", \\\"{x:1244,y:754,t:1527272520998};\\\", \\\"{x:1256,y:689,t:1527272521016};\\\", \\\"{x:1260,y:619,t:1527272521033};\\\", \\\"{x:1246,y:576,t:1527272521049};\\\", \\\"{x:1198,y:514,t:1527272521065};\\\", \\\"{x:1116,y:448,t:1527272521082};\\\", \\\"{x:1011,y:385,t:1527272521098};\\\", \\\"{x:889,y:323,t:1527272521116};\\\", \\\"{x:734,y:276,t:1527272521132};\\\", \\\"{x:657,y:271,t:1527272521148};\\\", \\\"{x:607,y:271,t:1527272521165};\\\", \\\"{x:572,y:290,t:1527272521182};\\\", \\\"{x:550,y:313,t:1527272521198};\\\", \\\"{x:525,y:363,t:1527272521215};\\\", \\\"{x:513,y:418,t:1527272521232};\\\", \\\"{x:508,y:476,t:1527272521248};\\\", \\\"{x:508,y:515,t:1527272521265};\\\", \\\"{x:510,y:547,t:1527272521282};\\\", \\\"{x:524,y:582,t:1527272521300};\\\", \\\"{x:529,y:593,t:1527272521315};\\\", \\\"{x:532,y:597,t:1527272521332};\\\", \\\"{x:533,y:599,t:1527272521349};\\\", \\\"{x:533,y:600,t:1527272521540};\\\", \\\"{x:531,y:600,t:1527272521549};\\\", \\\"{x:526,y:603,t:1527272521568};\\\", \\\"{x:522,y:603,t:1527272521583};\\\", \\\"{x:521,y:603,t:1527272521599};\\\", \\\"{x:518,y:603,t:1527272521616};\\\", \\\"{x:509,y:601,t:1527272521633};\\\", \\\"{x:502,y:597,t:1527272521649};\\\", \\\"{x:500,y:597,t:1527272521666};\\\", \\\"{x:492,y:594,t:1527272521682};\\\", \\\"{x:476,y:592,t:1527272521700};\\\", \\\"{x:464,y:588,t:1527272521716};\\\", \\\"{x:462,y:588,t:1527272521732};\\\", \\\"{x:459,y:588,t:1527272521749};\\\", \\\"{x:454,y:585,t:1527272521766};\\\", \\\"{x:444,y:581,t:1527272521782};\\\", \\\"{x:435,y:578,t:1527272521800};\\\", \\\"{x:431,y:576,t:1527272521816};\\\", \\\"{x:428,y:576,t:1527272521833};\\\", \\\"{x:427,y:575,t:1527272521849};\\\", \\\"{x:422,y:573,t:1527272521866};\\\", \\\"{x:412,y:568,t:1527272521884};\\\", \\\"{x:389,y:556,t:1527272521899};\\\", \\\"{x:345,y:529,t:1527272521916};\\\", \\\"{x:332,y:524,t:1527272521933};\\\", \\\"{x:326,y:521,t:1527272521949};\\\", \\\"{x:321,y:519,t:1527272521966};\\\", \\\"{x:319,y:518,t:1527272521983};\\\", \\\"{x:318,y:517,t:1527272522052};\\\", \\\"{x:318,y:516,t:1527272522067};\\\", \\\"{x:323,y:513,t:1527272522084};\\\", \\\"{x:336,y:513,t:1527272522099};\\\", \\\"{x:346,y:513,t:1527272522117};\\\", \\\"{x:368,y:515,t:1527272522133};\\\", \\\"{x:404,y:515,t:1527272522149};\\\", \\\"{x:487,y:515,t:1527272522166};\\\", \\\"{x:582,y:517,t:1527272522185};\\\", \\\"{x:648,y:525,t:1527272522199};\\\", \\\"{x:672,y:529,t:1527272522216};\\\", \\\"{x:675,y:530,t:1527272522233};\\\", \\\"{x:677,y:530,t:1527272522420};\\\", \\\"{x:684,y:530,t:1527272522433};\\\", \\\"{x:713,y:530,t:1527272522450};\\\", \\\"{x:749,y:530,t:1527272522468};\\\", \\\"{x:779,y:530,t:1527272522483};\\\", \\\"{x:813,y:528,t:1527272522499};\\\", \\\"{x:822,y:525,t:1527272522516};\\\", \\\"{x:829,y:522,t:1527272522534};\\\", \\\"{x:831,y:520,t:1527272522550};\\\", \\\"{x:831,y:519,t:1527272522567};\\\", \\\"{x:832,y:518,t:1527272522596};\\\", \\\"{x:833,y:518,t:1527272522604};\\\", \\\"{x:833,y:517,t:1527272522629};\\\", \\\"{x:834,y:515,t:1527272522644};\\\", \\\"{x:835,y:514,t:1527272522652};\\\", \\\"{x:838,y:513,t:1527272522666};\\\", \\\"{x:844,y:509,t:1527272522683};\\\", \\\"{x:850,y:504,t:1527272522700};\\\", \\\"{x:851,y:503,t:1527272522724};\\\", \\\"{x:852,y:502,t:1527272522733};\\\", \\\"{x:852,y:501,t:1527272522884};\\\", \\\"{x:851,y:499,t:1527272522900};\\\", \\\"{x:846,y:498,t:1527272522918};\\\", \\\"{x:841,y:498,t:1527272522933};\\\", \\\"{x:840,y:498,t:1527272522950};\\\", \\\"{x:835,y:498,t:1527272523325};\\\", \\\"{x:828,y:498,t:1527272523334};\\\", \\\"{x:810,y:498,t:1527272523352};\\\", \\\"{x:790,y:498,t:1527272523367};\\\", \\\"{x:772,y:498,t:1527272523384};\\\", \\\"{x:752,y:501,t:1527272523400};\\\", \\\"{x:730,y:505,t:1527272523416};\\\", \\\"{x:711,y:509,t:1527272523435};\\\", \\\"{x:687,y:511,t:1527272523449};\\\", \\\"{x:665,y:512,t:1527272523467};\\\", \\\"{x:638,y:512,t:1527272523484};\\\", \\\"{x:624,y:512,t:1527272523500};\\\", \\\"{x:612,y:511,t:1527272523517};\\\", \\\"{x:595,y:507,t:1527272523534};\\\", \\\"{x:570,y:500,t:1527272523550};\\\", \\\"{x:533,y:493,t:1527272523567};\\\", \\\"{x:499,y:487,t:1527272523585};\\\", \\\"{x:477,y:485,t:1527272523602};\\\", \\\"{x:465,y:485,t:1527272523617};\\\", \\\"{x:461,y:485,t:1527272523634};\\\", \\\"{x:455,y:488,t:1527272523651};\\\", \\\"{x:442,y:493,t:1527272523667};\\\", \\\"{x:409,y:498,t:1527272523684};\\\", \\\"{x:383,y:503,t:1527272523701};\\\", \\\"{x:345,y:507,t:1527272523717};\\\", \\\"{x:309,y:512,t:1527272523734};\\\", \\\"{x:276,y:517,t:1527272523751};\\\", \\\"{x:238,y:523,t:1527272523768};\\\", \\\"{x:208,y:528,t:1527272523785};\\\", \\\"{x:180,y:531,t:1527272523802};\\\", \\\"{x:150,y:534,t:1527272523817};\\\", \\\"{x:120,y:534,t:1527272523835};\\\", \\\"{x:88,y:535,t:1527272523851};\\\", \\\"{x:54,y:539,t:1527272523867};\\\", \\\"{x:26,y:547,t:1527272523886};\\\", \\\"{x:25,y:547,t:1527272523901};\\\", \\\"{x:27,y:547,t:1527272523988};\\\", \\\"{x:33,y:549,t:1527272524001};\\\", \\\"{x:51,y:550,t:1527272524020};\\\", \\\"{x:74,y:550,t:1527272524034};\\\", \\\"{x:89,y:550,t:1527272524051};\\\", \\\"{x:99,y:550,t:1527272524067};\\\", \\\"{x:100,y:550,t:1527272524085};\\\", \\\"{x:101,y:548,t:1527272524101};\\\", \\\"{x:103,y:546,t:1527272524131};\\\", \\\"{x:104,y:546,t:1527272524139};\\\", \\\"{x:106,y:545,t:1527272524152};\\\", \\\"{x:112,y:542,t:1527272524168};\\\", \\\"{x:115,y:542,t:1527272524184};\\\", \\\"{x:119,y:541,t:1527272524202};\\\", \\\"{x:122,y:539,t:1527272524218};\\\", \\\"{x:127,y:537,t:1527272524235};\\\", \\\"{x:131,y:536,t:1527272524251};\\\", \\\"{x:135,y:536,t:1527272524268};\\\", \\\"{x:139,y:536,t:1527272524285};\\\", \\\"{x:144,y:536,t:1527272524301};\\\", \\\"{x:147,y:536,t:1527272524318};\\\", \\\"{x:153,y:536,t:1527272524336};\\\", \\\"{x:155,y:536,t:1527272524351};\\\", \\\"{x:156,y:537,t:1527272524368};\\\", \\\"{x:159,y:538,t:1527272524384};\\\", \\\"{x:161,y:539,t:1527272524401};\\\", \\\"{x:163,y:539,t:1527272524419};\\\", \\\"{x:179,y:539,t:1527272524859};\\\", \\\"{x:226,y:539,t:1527272524868};\\\", \\\"{x:360,y:550,t:1527272524885};\\\", \\\"{x:489,y:579,t:1527272524903};\\\", \\\"{x:581,y:609,t:1527272524919};\\\", \\\"{x:631,y:628,t:1527272524935};\\\", \\\"{x:660,y:637,t:1527272524953};\\\", \\\"{x:677,y:643,t:1527272524968};\\\", \\\"{x:692,y:650,t:1527272524985};\\\", \\\"{x:698,y:654,t:1527272525001};\\\", \\\"{x:701,y:658,t:1527272525018};\\\", \\\"{x:706,y:667,t:1527272525035};\\\", \\\"{x:711,y:678,t:1527272525052};\\\", \\\"{x:713,y:683,t:1527272525068};\\\", \\\"{x:713,y:687,t:1527272525085};\\\", \\\"{x:711,y:691,t:1527272525102};\\\", \\\"{x:695,y:696,t:1527272525118};\\\", \\\"{x:662,y:705,t:1527272525136};\\\", \\\"{x:617,y:713,t:1527272525151};\\\", \\\"{x:567,y:720,t:1527272525169};\\\", \\\"{x:554,y:724,t:1527272525185};\\\", \\\"{x:544,y:730,t:1527272525201};\\\", \\\"{x:530,y:734,t:1527272525219};\\\", \\\"{x:530,y:733,t:1527272525275};\\\", \\\"{x:530,y:734,t:1527272527436};\\\", \\\"{x:542,y:731,t:1527272528363};\\\", \\\"{x:572,y:715,t:1527272528371};\\\", \\\"{x:648,y:703,t:1527272528387};\\\", \\\"{x:735,y:697,t:1527272528405};\\\", \\\"{x:824,y:697,t:1527272528422};\\\", \\\"{x:918,y:697,t:1527272528438};\\\", \\\"{x:1021,y:697,t:1527272528454};\\\", \\\"{x:1107,y:697,t:1527272528472};\\\", \\\"{x:1182,y:697,t:1527272528488};\\\", \\\"{x:1234,y:694,t:1527272528505};\\\", \\\"{x:1270,y:689,t:1527272528522};\\\", \\\"{x:1299,y:684,t:1527272528538};\\\", \\\"{x:1325,y:684,t:1527272528554};\\\", \\\"{x:1343,y:684,t:1527272528571};\\\", \\\"{x:1346,y:684,t:1527272528588};\\\", \\\"{x:1347,y:684,t:1527272528604};\\\", \\\"{x:1350,y:684,t:1527272528622};\\\", \\\"{x:1352,y:684,t:1527272528638};\\\", \\\"{x:1354,y:682,t:1527272528654};\\\", \\\"{x:1355,y:681,t:1527272528672};\\\", \\\"{x:1361,y:680,t:1527272528688};\\\", \\\"{x:1371,y:677,t:1527272528705};\\\", \\\"{x:1374,y:677,t:1527272528721};\\\", \\\"{x:1376,y:677,t:1527272528868};\\\", \\\"{x:1377,y:674,t:1527272528876};\\\", \\\"{x:1378,y:674,t:1527272528889};\\\", \\\"{x:1378,y:673,t:1527272528906};\\\", \\\"{x:1380,y:672,t:1527272528922};\\\", \\\"{x:1381,y:670,t:1527272528957};\\\", \\\"{x:1381,y:669,t:1527272528996};\\\", \\\"{x:1382,y:668,t:1527272529036};\\\" ] }, { \\\"rt\\\": 61781, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 1127413, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -3-B -B -B -E -Z -Z -04 PM-Z -H -H -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1388,y:643,t:1527272529275};\\\", \\\"{x:1388,y:637,t:1527272529289};\\\", \\\"{x:1388,y:629,t:1527272529306};\\\", \\\"{x:1388,y:620,t:1527272529323};\\\", \\\"{x:1388,y:610,t:1527272529338};\\\", \\\"{x:1387,y:590,t:1527272529355};\\\", \\\"{x:1386,y:583,t:1527272529372};\\\", \\\"{x:1383,y:575,t:1527272529402};\\\", \\\"{x:1383,y:574,t:1527272529405};\\\", \\\"{x:1383,y:573,t:1527272529423};\\\", \\\"{x:1382,y:573,t:1527272529733};\\\", \\\"{x:1381,y:571,t:1527272529740};\\\", \\\"{x:1351,y:546,t:1527272529756};\\\", \\\"{x:1267,y:486,t:1527272529773};\\\", \\\"{x:1142,y:421,t:1527272529789};\\\", \\\"{x:993,y:359,t:1527272529805};\\\", \\\"{x:852,y:316,t:1527272529823};\\\", \\\"{x:754,y:298,t:1527272529839};\\\", \\\"{x:705,y:297,t:1527272529856};\\\", \\\"{x:689,y:298,t:1527272529873};\\\", \\\"{x:684,y:307,t:1527272529890};\\\", \\\"{x:679,y:335,t:1527272529906};\\\", \\\"{x:679,y:365,t:1527272529922};\\\", \\\"{x:681,y:405,t:1527272529940};\\\", \\\"{x:707,y:470,t:1527272530027};\\\", \\\"{x:711,y:473,t:1527272530042};\\\", \\\"{x:712,y:474,t:1527272530056};\\\", \\\"{x:713,y:475,t:1527272530072};\\\", \\\"{x:708,y:475,t:1527272530123};\\\", \\\"{x:684,y:485,t:1527272530140};\\\", \\\"{x:655,y:496,t:1527272530156};\\\", \\\"{x:624,y:503,t:1527272530173};\\\", \\\"{x:588,y:514,t:1527272530190};\\\", \\\"{x:557,y:516,t:1527272530206};\\\", \\\"{x:534,y:517,t:1527272530223};\\\", \\\"{x:508,y:517,t:1527272530240};\\\", \\\"{x:490,y:517,t:1527272530258};\\\", \\\"{x:475,y:517,t:1527272530273};\\\", \\\"{x:467,y:517,t:1527272530290};\\\", \\\"{x:464,y:517,t:1527272530307};\\\", \\\"{x:463,y:517,t:1527272530324};\\\", \\\"{x:462,y:517,t:1527272530364};\\\", \\\"{x:461,y:517,t:1527272530374};\\\", \\\"{x:458,y:510,t:1527272530390};\\\", \\\"{x:454,y:495,t:1527272530406};\\\", \\\"{x:453,y:479,t:1527272530426};\\\", \\\"{x:453,y:468,t:1527272530440};\\\", \\\"{x:453,y:464,t:1527272530456};\\\", \\\"{x:453,y:460,t:1527272530473};\\\", \\\"{x:454,y:458,t:1527272530489};\\\", \\\"{x:457,y:458,t:1527272530532};\\\", \\\"{x:458,y:458,t:1527272530539};\\\", \\\"{x:467,y:459,t:1527272530556};\\\", \\\"{x:475,y:462,t:1527272530573};\\\", \\\"{x:479,y:464,t:1527272530590};\\\", \\\"{x:480,y:464,t:1527272530607};\\\", \\\"{x:480,y:465,t:1527272530624};\\\", \\\"{x:481,y:465,t:1527272530640};\\\", \\\"{x:485,y:463,t:1527272530781};\\\", \\\"{x:488,y:461,t:1527272530790};\\\", \\\"{x:494,y:454,t:1527272530807};\\\", \\\"{x:499,y:449,t:1527272530824};\\\", \\\"{x:503,y:442,t:1527272530840};\\\", \\\"{x:508,y:436,t:1527272530857};\\\", \\\"{x:510,y:434,t:1527272530874};\\\", \\\"{x:511,y:433,t:1527272530891};\\\", \\\"{x:516,y:431,t:1527272530906};\\\", \\\"{x:523,y:431,t:1527272530923};\\\", \\\"{x:529,y:431,t:1527272530941};\\\", \\\"{x:539,y:435,t:1527272530957};\\\", \\\"{x:548,y:441,t:1527272530974};\\\", \\\"{x:553,y:445,t:1527272530991};\\\", \\\"{x:558,y:447,t:1527272531007};\\\", \\\"{x:560,y:447,t:1527272531024};\\\", \\\"{x:562,y:447,t:1527272531041};\\\", \\\"{x:563,y:447,t:1527272531057};\\\", \\\"{x:567,y:447,t:1527272531074};\\\", \\\"{x:579,y:447,t:1527272531091};\\\", \\\"{x:600,y:446,t:1527272531107};\\\", \\\"{x:663,y:445,t:1527272531124};\\\", \\\"{x:743,y:445,t:1527272531140};\\\", \\\"{x:854,y:445,t:1527272531157};\\\", \\\"{x:978,y:457,t:1527272531174};\\\", \\\"{x:1116,y:476,t:1527272531192};\\\", \\\"{x:1239,y:497,t:1527272531207};\\\", \\\"{x:1353,y:515,t:1527272531224};\\\", \\\"{x:1447,y:527,t:1527272531241};\\\", \\\"{x:1537,y:546,t:1527272531257};\\\", \\\"{x:1603,y:563,t:1527272531275};\\\", \\\"{x:1646,y:576,t:1527272531292};\\\", \\\"{x:1686,y:591,t:1527272531308};\\\", \\\"{x:1700,y:596,t:1527272531324};\\\", \\\"{x:1704,y:598,t:1527272531341};\\\", \\\"{x:1705,y:599,t:1527272531357};\\\", \\\"{x:1706,y:599,t:1527272531413};\\\", \\\"{x:1709,y:602,t:1527272531424};\\\", \\\"{x:1710,y:610,t:1527272531441};\\\", \\\"{x:1710,y:620,t:1527272531459};\\\", \\\"{x:1710,y:635,t:1527272531474};\\\", \\\"{x:1710,y:649,t:1527272531490};\\\", \\\"{x:1705,y:657,t:1527272531507};\\\", \\\"{x:1701,y:658,t:1527272531523};\\\", \\\"{x:1699,y:659,t:1527272531541};\\\", \\\"{x:1698,y:659,t:1527272531558};\\\", \\\"{x:1692,y:659,t:1527272531574};\\\", \\\"{x:1684,y:659,t:1527272531590};\\\", \\\"{x:1667,y:659,t:1527272531608};\\\", \\\"{x:1643,y:659,t:1527272531624};\\\", \\\"{x:1606,y:654,t:1527272531641};\\\", \\\"{x:1555,y:644,t:1527272531657};\\\", \\\"{x:1500,y:633,t:1527272531675};\\\", \\\"{x:1454,y:622,t:1527272531691};\\\", \\\"{x:1416,y:615,t:1527272531708};\\\", \\\"{x:1402,y:615,t:1527272531724};\\\", \\\"{x:1398,y:615,t:1527272531742};\\\", \\\"{x:1395,y:616,t:1527272531758};\\\", \\\"{x:1391,y:617,t:1527272531775};\\\", \\\"{x:1387,y:619,t:1527272531791};\\\", \\\"{x:1378,y:619,t:1527272531808};\\\", \\\"{x:1373,y:619,t:1527272531825};\\\", \\\"{x:1365,y:620,t:1527272531841};\\\", \\\"{x:1352,y:621,t:1527272531858};\\\", \\\"{x:1339,y:627,t:1527272531875};\\\", \\\"{x:1333,y:630,t:1527272531891};\\\", \\\"{x:1328,y:634,t:1527272531909};\\\", \\\"{x:1327,y:635,t:1527272531925};\\\", \\\"{x:1327,y:636,t:1527272531973};\\\", \\\"{x:1327,y:637,t:1527272532107};\\\", \\\"{x:1321,y:636,t:1527272532124};\\\", \\\"{x:1318,y:634,t:1527272532142};\\\", \\\"{x:1316,y:632,t:1527272532157};\\\", \\\"{x:1314,y:632,t:1527272532174};\\\", \\\"{x:1314,y:631,t:1527272532191};\\\", \\\"{x:1313,y:631,t:1527272532211};\\\", \\\"{x:1313,y:630,t:1527272532225};\\\", \\\"{x:1312,y:628,t:1527272532242};\\\", \\\"{x:1311,y:626,t:1527272532257};\\\", \\\"{x:1310,y:623,t:1527272532274};\\\", \\\"{x:1310,y:620,t:1527272532291};\\\", \\\"{x:1310,y:619,t:1527272532307};\\\", \\\"{x:1310,y:617,t:1527272532332};\\\", \\\"{x:1310,y:616,t:1527272532363};\\\", \\\"{x:1310,y:614,t:1527272532420};\\\", \\\"{x:1310,y:613,t:1527272532436};\\\", \\\"{x:1311,y:612,t:1527272532443};\\\", \\\"{x:1312,y:612,t:1527272532458};\\\", \\\"{x:1317,y:608,t:1527272532475};\\\", \\\"{x:1328,y:601,t:1527272532492};\\\", \\\"{x:1344,y:592,t:1527272532508};\\\", \\\"{x:1372,y:583,t:1527272532525};\\\", \\\"{x:1400,y:579,t:1527272532542};\\\", \\\"{x:1431,y:574,t:1527272532558};\\\", \\\"{x:1472,y:571,t:1527272532575};\\\", \\\"{x:1525,y:571,t:1527272532592};\\\", \\\"{x:1581,y:571,t:1527272532609};\\\", \\\"{x:1636,y:571,t:1527272532625};\\\", \\\"{x:1676,y:571,t:1527272532642};\\\", \\\"{x:1714,y:573,t:1527272532660};\\\", \\\"{x:1738,y:576,t:1527272532675};\\\", \\\"{x:1768,y:579,t:1527272532692};\\\", \\\"{x:1775,y:581,t:1527272532709};\\\", \\\"{x:1778,y:582,t:1527272532725};\\\", \\\"{x:1779,y:583,t:1527272532813};\\\", \\\"{x:1778,y:588,t:1527272532825};\\\", \\\"{x:1744,y:612,t:1527272532842};\\\", \\\"{x:1687,y:634,t:1527272532860};\\\", \\\"{x:1623,y:655,t:1527272532876};\\\", \\\"{x:1526,y:679,t:1527272532892};\\\", \\\"{x:1464,y:691,t:1527272532909};\\\", \\\"{x:1409,y:698,t:1527272532926};\\\", \\\"{x:1377,y:698,t:1527272532942};\\\", \\\"{x:1356,y:698,t:1527272532959};\\\", \\\"{x:1351,y:698,t:1527272532978};\\\", \\\"{x:1349,y:698,t:1527272532992};\\\", \\\"{x:1348,y:698,t:1527272533011};\\\", \\\"{x:1345,y:697,t:1527272533035};\\\", \\\"{x:1341,y:695,t:1527272533044};\\\", \\\"{x:1335,y:693,t:1527272533059};\\\", \\\"{x:1307,y:686,t:1527272533076};\\\", \\\"{x:1285,y:683,t:1527272533092};\\\", \\\"{x:1264,y:682,t:1527272533108};\\\", \\\"{x:1244,y:682,t:1527272533126};\\\", \\\"{x:1228,y:682,t:1527272533142};\\\", \\\"{x:1212,y:684,t:1527272533159};\\\", \\\"{x:1198,y:686,t:1527272533176};\\\", \\\"{x:1181,y:690,t:1527272533193};\\\", \\\"{x:1165,y:695,t:1527272533209};\\\", \\\"{x:1150,y:697,t:1527272533226};\\\", \\\"{x:1132,y:704,t:1527272533243};\\\", \\\"{x:1116,y:712,t:1527272533259};\\\", \\\"{x:1090,y:730,t:1527272533276};\\\", \\\"{x:1074,y:743,t:1527272533292};\\\", \\\"{x:1064,y:755,t:1527272533309};\\\", \\\"{x:1061,y:760,t:1527272533326};\\\", \\\"{x:1060,y:762,t:1527272533343};\\\", \\\"{x:1062,y:765,t:1527272533359};\\\", \\\"{x:1067,y:769,t:1527272533377};\\\", \\\"{x:1072,y:772,t:1527272533393};\\\", \\\"{x:1077,y:776,t:1527272533409};\\\", \\\"{x:1085,y:781,t:1527272533426};\\\", \\\"{x:1098,y:784,t:1527272533444};\\\", \\\"{x:1108,y:788,t:1527272533459};\\\", \\\"{x:1129,y:794,t:1527272533476};\\\", \\\"{x:1135,y:795,t:1527272533493};\\\", \\\"{x:1140,y:796,t:1527272533510};\\\", \\\"{x:1145,y:796,t:1527272533527};\\\", \\\"{x:1160,y:796,t:1527272533543};\\\", \\\"{x:1167,y:796,t:1527272533560};\\\", \\\"{x:1172,y:796,t:1527272533576};\\\", \\\"{x:1179,y:795,t:1527272533593};\\\", \\\"{x:1184,y:791,t:1527272533609};\\\", \\\"{x:1195,y:785,t:1527272533626};\\\", \\\"{x:1210,y:775,t:1527272533643};\\\", \\\"{x:1231,y:768,t:1527272533660};\\\", \\\"{x:1256,y:765,t:1527272533677};\\\", \\\"{x:1264,y:764,t:1527272533694};\\\", \\\"{x:1267,y:764,t:1527272533710};\\\", \\\"{x:1268,y:764,t:1527272533727};\\\", \\\"{x:1274,y:764,t:1527272533743};\\\", \\\"{x:1284,y:764,t:1527272533760};\\\", \\\"{x:1303,y:764,t:1527272533776};\\\", \\\"{x:1322,y:764,t:1527272533793};\\\", \\\"{x:1338,y:766,t:1527272533810};\\\", \\\"{x:1348,y:767,t:1527272533827};\\\", \\\"{x:1355,y:767,t:1527272533844};\\\", \\\"{x:1363,y:767,t:1527272533861};\\\", \\\"{x:1366,y:767,t:1527272533876};\\\", \\\"{x:1368,y:767,t:1527272534053};\\\", \\\"{x:1370,y:767,t:1527272534062};\\\", \\\"{x:1374,y:768,t:1527272534076};\\\", \\\"{x:1382,y:770,t:1527272534092};\\\", \\\"{x:1389,y:770,t:1527272534109};\\\", \\\"{x:1392,y:770,t:1527272534126};\\\", \\\"{x:1396,y:770,t:1527272534143};\\\", \\\"{x:1399,y:771,t:1527272534160};\\\", \\\"{x:1402,y:771,t:1527272534177};\\\", \\\"{x:1404,y:771,t:1527272534193};\\\", \\\"{x:1406,y:771,t:1527272534210};\\\", \\\"{x:1407,y:771,t:1527272534227};\\\", \\\"{x:1402,y:771,t:1527272534421};\\\", \\\"{x:1395,y:771,t:1527272534428};\\\", \\\"{x:1389,y:771,t:1527272534443};\\\", \\\"{x:1360,y:769,t:1527272534462};\\\", \\\"{x:1340,y:767,t:1527272534478};\\\", \\\"{x:1328,y:765,t:1527272534493};\\\", \\\"{x:1324,y:765,t:1527272534510};\\\", \\\"{x:1323,y:764,t:1527272534662};\\\", \\\"{x:1323,y:761,t:1527272534678};\\\", \\\"{x:1323,y:758,t:1527272534694};\\\", \\\"{x:1323,y:754,t:1527272534710};\\\", \\\"{x:1325,y:752,t:1527272534727};\\\", \\\"{x:1326,y:749,t:1527272534745};\\\", \\\"{x:1330,y:746,t:1527272534760};\\\", \\\"{x:1333,y:743,t:1527272534777};\\\", \\\"{x:1336,y:740,t:1527272534794};\\\", \\\"{x:1337,y:740,t:1527272534810};\\\", \\\"{x:1337,y:739,t:1527272534828};\\\", \\\"{x:1339,y:738,t:1527272534844};\\\", \\\"{x:1340,y:737,t:1527272534861};\\\", \\\"{x:1346,y:734,t:1527272534878};\\\", \\\"{x:1363,y:729,t:1527272534894};\\\", \\\"{x:1385,y:729,t:1527272534910};\\\", \\\"{x:1399,y:729,t:1527272534928};\\\", \\\"{x:1407,y:729,t:1527272534944};\\\", \\\"{x:1408,y:729,t:1527272534960};\\\", \\\"{x:1409,y:729,t:1527272535028};\\\", \\\"{x:1415,y:729,t:1527272535044};\\\", \\\"{x:1426,y:729,t:1527272535061};\\\", \\\"{x:1439,y:729,t:1527272535077};\\\", \\\"{x:1454,y:729,t:1527272535094};\\\", \\\"{x:1475,y:731,t:1527272535111};\\\", \\\"{x:1497,y:736,t:1527272535127};\\\", \\\"{x:1513,y:740,t:1527272535143};\\\", \\\"{x:1520,y:741,t:1527272535161};\\\", \\\"{x:1521,y:741,t:1527272535177};\\\", \\\"{x:1520,y:741,t:1527272535411};\\\", \\\"{x:1519,y:741,t:1527272535467};\\\", \\\"{x:1517,y:741,t:1527272535483};\\\", \\\"{x:1514,y:741,t:1527272535579};\\\", \\\"{x:1510,y:741,t:1527272535594};\\\", \\\"{x:1503,y:742,t:1527272535611};\\\", \\\"{x:1497,y:745,t:1527272535627};\\\", \\\"{x:1493,y:746,t:1527272535643};\\\", \\\"{x:1490,y:748,t:1527272535661};\\\", \\\"{x:1488,y:749,t:1527272535678};\\\", \\\"{x:1487,y:749,t:1527272535694};\\\", \\\"{x:1483,y:752,t:1527272535711};\\\", \\\"{x:1481,y:752,t:1527272535731};\\\", \\\"{x:1481,y:753,t:1527272535745};\\\", \\\"{x:1476,y:757,t:1527272535760};\\\", \\\"{x:1474,y:759,t:1527272535778};\\\", \\\"{x:1470,y:760,t:1527272535795};\\\", \\\"{x:1465,y:762,t:1527272535811};\\\", \\\"{x:1454,y:762,t:1527272535827};\\\", \\\"{x:1446,y:762,t:1527272535845};\\\", \\\"{x:1438,y:762,t:1527272535861};\\\", \\\"{x:1426,y:762,t:1527272535878};\\\", \\\"{x:1412,y:760,t:1527272535895};\\\", \\\"{x:1396,y:753,t:1527272535911};\\\", \\\"{x:1381,y:751,t:1527272535928};\\\", \\\"{x:1367,y:749,t:1527272535945};\\\", \\\"{x:1355,y:747,t:1527272535961};\\\", \\\"{x:1348,y:747,t:1527272535978};\\\", \\\"{x:1345,y:747,t:1527272535995};\\\", \\\"{x:1344,y:747,t:1527272536010};\\\", \\\"{x:1343,y:747,t:1527272536043};\\\", \\\"{x:1342,y:747,t:1527272536052};\\\", \\\"{x:1342,y:748,t:1527272536061};\\\", \\\"{x:1341,y:748,t:1527272536077};\\\", \\\"{x:1340,y:750,t:1527272536095};\\\", \\\"{x:1340,y:752,t:1527272536111};\\\", \\\"{x:1339,y:755,t:1527272536128};\\\", \\\"{x:1339,y:757,t:1527272536145};\\\", \\\"{x:1339,y:761,t:1527272536161};\\\", \\\"{x:1339,y:764,t:1527272536177};\\\", \\\"{x:1339,y:766,t:1527272536195};\\\", \\\"{x:1339,y:767,t:1527272536212};\\\", \\\"{x:1340,y:767,t:1527272536292};\\\", \\\"{x:1341,y:767,t:1527272536301};\\\", \\\"{x:1342,y:766,t:1527272536312};\\\", \\\"{x:1350,y:763,t:1527272536328};\\\", \\\"{x:1354,y:760,t:1527272536346};\\\", \\\"{x:1359,y:754,t:1527272536362};\\\", \\\"{x:1363,y:751,t:1527272536378};\\\", \\\"{x:1365,y:749,t:1527272536395};\\\", \\\"{x:1367,y:744,t:1527272536411};\\\", \\\"{x:1369,y:742,t:1527272536428};\\\", \\\"{x:1370,y:740,t:1527272536445};\\\", \\\"{x:1372,y:740,t:1527272536463};\\\", \\\"{x:1376,y:740,t:1527272536479};\\\", \\\"{x:1378,y:740,t:1527272536496};\\\", \\\"{x:1379,y:740,t:1527272536512};\\\", \\\"{x:1381,y:740,t:1527272536528};\\\", \\\"{x:1383,y:740,t:1527272536545};\\\", \\\"{x:1391,y:740,t:1527272536562};\\\", \\\"{x:1410,y:740,t:1527272536579};\\\", \\\"{x:1435,y:742,t:1527272536596};\\\", \\\"{x:1464,y:751,t:1527272536612};\\\", \\\"{x:1471,y:756,t:1527272536628};\\\", \\\"{x:1475,y:759,t:1527272536646};\\\", \\\"{x:1479,y:763,t:1527272536663};\\\", \\\"{x:1486,y:772,t:1527272536680};\\\", \\\"{x:1489,y:780,t:1527272536696};\\\", \\\"{x:1493,y:787,t:1527272536712};\\\", \\\"{x:1498,y:796,t:1527272536730};\\\", \\\"{x:1501,y:804,t:1527272536746};\\\", \\\"{x:1504,y:808,t:1527272536763};\\\", \\\"{x:1506,y:813,t:1527272536779};\\\", \\\"{x:1508,y:816,t:1527272536796};\\\", \\\"{x:1509,y:818,t:1527272536813};\\\", \\\"{x:1510,y:820,t:1527272536830};\\\", \\\"{x:1511,y:824,t:1527272536846};\\\", \\\"{x:1512,y:828,t:1527272536863};\\\", \\\"{x:1513,y:831,t:1527272536880};\\\", \\\"{x:1515,y:838,t:1527272536895};\\\", \\\"{x:1520,y:846,t:1527272536912};\\\", \\\"{x:1529,y:851,t:1527272536929};\\\", \\\"{x:1539,y:856,t:1527272536945};\\\", \\\"{x:1553,y:860,t:1527272536963};\\\", \\\"{x:1577,y:865,t:1527272536980};\\\", \\\"{x:1597,y:865,t:1527272536995};\\\", \\\"{x:1644,y:856,t:1527272537012};\\\", \\\"{x:1678,y:856,t:1527272537029};\\\", \\\"{x:1702,y:856,t:1527272537046};\\\", \\\"{x:1722,y:861,t:1527272537062};\\\", \\\"{x:1736,y:865,t:1527272537079};\\\", \\\"{x:1745,y:866,t:1527272537096};\\\", \\\"{x:1746,y:866,t:1527272537112};\\\", \\\"{x:1747,y:866,t:1527272537140};\\\", \\\"{x:1746,y:868,t:1527272537212};\\\", \\\"{x:1738,y:868,t:1527272537229};\\\", \\\"{x:1721,y:869,t:1527272537247};\\\", \\\"{x:1699,y:869,t:1527272537262};\\\", \\\"{x:1680,y:868,t:1527272537279};\\\", \\\"{x:1663,y:868,t:1527272537296};\\\", \\\"{x:1648,y:868,t:1527272537312};\\\", \\\"{x:1639,y:870,t:1527272537330};\\\", \\\"{x:1632,y:874,t:1527272537346};\\\", \\\"{x:1629,y:876,t:1527272537363};\\\", \\\"{x:1626,y:879,t:1527272537379};\\\", \\\"{x:1622,y:887,t:1527272537396};\\\", \\\"{x:1620,y:895,t:1527272537412};\\\", \\\"{x:1620,y:901,t:1527272537430};\\\", \\\"{x:1620,y:905,t:1527272537446};\\\", \\\"{x:1620,y:910,t:1527272537463};\\\", \\\"{x:1622,y:917,t:1527272537479};\\\", \\\"{x:1624,y:921,t:1527272537497};\\\", \\\"{x:1625,y:924,t:1527272537513};\\\", \\\"{x:1624,y:924,t:1527272537597};\\\", \\\"{x:1611,y:917,t:1527272537613};\\\", \\\"{x:1588,y:904,t:1527272537629};\\\", \\\"{x:1555,y:883,t:1527272537646};\\\", \\\"{x:1517,y:853,t:1527272537663};\\\", \\\"{x:1487,y:823,t:1527272537680};\\\", \\\"{x:1464,y:791,t:1527272537697};\\\", \\\"{x:1449,y:758,t:1527272537714};\\\", \\\"{x:1444,y:730,t:1527272537730};\\\", \\\"{x:1443,y:708,t:1527272537747};\\\", \\\"{x:1452,y:685,t:1527272537764};\\\", \\\"{x:1483,y:658,t:1527272537779};\\\", \\\"{x:1563,y:611,t:1527272537797};\\\", \\\"{x:1591,y:593,t:1527272537813};\\\", \\\"{x:1606,y:579,t:1527272537830};\\\", \\\"{x:1617,y:564,t:1527272537847};\\\", \\\"{x:1630,y:544,t:1527272537863};\\\", \\\"{x:1643,y:519,t:1527272537879};\\\", \\\"{x:1655,y:498,t:1527272537897};\\\", \\\"{x:1658,y:483,t:1527272537913};\\\", \\\"{x:1659,y:465,t:1527272537930};\\\", \\\"{x:1659,y:443,t:1527272537947};\\\", \\\"{x:1658,y:423,t:1527272537965};\\\", \\\"{x:1640,y:385,t:1527272537980};\\\", \\\"{x:1622,y:360,t:1527272537997};\\\", \\\"{x:1605,y:348,t:1527272538014};\\\", \\\"{x:1583,y:337,t:1527272538030};\\\", \\\"{x:1562,y:333,t:1527272538047};\\\", \\\"{x:1549,y:332,t:1527272538064};\\\", \\\"{x:1547,y:332,t:1527272538080};\\\", \\\"{x:1546,y:332,t:1527272538124};\\\", \\\"{x:1544,y:332,t:1527272538148};\\\", \\\"{x:1542,y:332,t:1527272538163};\\\", \\\"{x:1534,y:333,t:1527272538179};\\\", \\\"{x:1532,y:340,t:1527272538196};\\\", \\\"{x:1530,y:347,t:1527272538213};\\\", \\\"{x:1530,y:361,t:1527272538230};\\\", \\\"{x:1531,y:383,t:1527272538246};\\\", \\\"{x:1537,y:398,t:1527272538263};\\\", \\\"{x:1548,y:415,t:1527272538280};\\\", \\\"{x:1557,y:427,t:1527272538296};\\\", \\\"{x:1563,y:437,t:1527272538313};\\\", \\\"{x:1563,y:438,t:1527272538330};\\\", \\\"{x:1563,y:439,t:1527272538356};\\\", \\\"{x:1562,y:441,t:1527272538380};\\\", \\\"{x:1552,y:441,t:1527272538397};\\\", \\\"{x:1537,y:441,t:1527272538413};\\\", \\\"{x:1517,y:441,t:1527272538430};\\\", \\\"{x:1497,y:439,t:1527272538447};\\\", \\\"{x:1484,y:437,t:1527272538463};\\\", \\\"{x:1477,y:437,t:1527272538480};\\\", \\\"{x:1470,y:437,t:1527272538497};\\\", \\\"{x:1464,y:441,t:1527272538513};\\\", \\\"{x:1453,y:446,t:1527272538530};\\\", \\\"{x:1446,y:451,t:1527272538547};\\\", \\\"{x:1441,y:456,t:1527272538563};\\\", \\\"{x:1437,y:463,t:1527272538580};\\\", \\\"{x:1433,y:474,t:1527272538597};\\\", \\\"{x:1426,y:487,t:1527272538613};\\\", \\\"{x:1417,y:502,t:1527272538630};\\\", \\\"{x:1411,y:514,t:1527272538648};\\\", \\\"{x:1404,y:525,t:1527272538664};\\\", \\\"{x:1402,y:531,t:1527272538680};\\\", \\\"{x:1396,y:536,t:1527272538697};\\\", \\\"{x:1385,y:541,t:1527272538714};\\\", \\\"{x:1372,y:544,t:1527272538730};\\\", \\\"{x:1356,y:545,t:1527272538747};\\\", \\\"{x:1336,y:547,t:1527272538765};\\\", \\\"{x:1324,y:550,t:1527272538780};\\\", \\\"{x:1314,y:552,t:1527272538797};\\\", \\\"{x:1307,y:556,t:1527272538814};\\\", \\\"{x:1300,y:558,t:1527272538831};\\\", \\\"{x:1294,y:559,t:1527272538847};\\\", \\\"{x:1292,y:560,t:1527272538865};\\\", \\\"{x:1290,y:561,t:1527272538880};\\\", \\\"{x:1289,y:562,t:1527272538898};\\\", \\\"{x:1288,y:563,t:1527272538914};\\\", \\\"{x:1285,y:566,t:1527272538931};\\\", \\\"{x:1285,y:567,t:1527272538947};\\\", \\\"{x:1285,y:568,t:1527272538973};\\\", \\\"{x:1285,y:569,t:1527272538988};\\\", \\\"{x:1285,y:570,t:1527272539004};\\\", \\\"{x:1285,y:571,t:1527272539028};\\\", \\\"{x:1285,y:572,t:1527272539036};\\\", \\\"{x:1286,y:572,t:1527272539047};\\\", \\\"{x:1288,y:572,t:1527272539065};\\\", \\\"{x:1293,y:572,t:1527272539080};\\\", \\\"{x:1304,y:574,t:1527272539097};\\\", \\\"{x:1315,y:576,t:1527272539114};\\\", \\\"{x:1323,y:577,t:1527272539131};\\\", \\\"{x:1328,y:577,t:1527272539147};\\\", \\\"{x:1334,y:578,t:1527272539163};\\\", \\\"{x:1342,y:579,t:1527272539181};\\\", \\\"{x:1349,y:584,t:1527272539197};\\\", \\\"{x:1358,y:585,t:1527272539214};\\\", \\\"{x:1367,y:590,t:1527272539231};\\\", \\\"{x:1376,y:598,t:1527272539247};\\\", \\\"{x:1380,y:605,t:1527272539264};\\\", \\\"{x:1384,y:611,t:1527272539281};\\\", \\\"{x:1385,y:614,t:1527272539297};\\\", \\\"{x:1388,y:617,t:1527272539314};\\\", \\\"{x:1388,y:618,t:1527272539331};\\\", \\\"{x:1389,y:620,t:1527272539347};\\\", \\\"{x:1389,y:622,t:1527272539364};\\\", \\\"{x:1391,y:624,t:1527272539381};\\\", \\\"{x:1392,y:628,t:1527272539398};\\\", \\\"{x:1398,y:635,t:1527272539415};\\\", \\\"{x:1409,y:644,t:1527272539431};\\\", \\\"{x:1420,y:652,t:1527272539448};\\\", \\\"{x:1429,y:656,t:1527272539464};\\\", \\\"{x:1433,y:658,t:1527272539481};\\\", \\\"{x:1437,y:660,t:1527272539498};\\\", \\\"{x:1439,y:661,t:1527272539515};\\\", \\\"{x:1442,y:662,t:1527272539532};\\\", \\\"{x:1448,y:665,t:1527272539548};\\\", \\\"{x:1458,y:669,t:1527272539565};\\\", \\\"{x:1463,y:670,t:1527272539582};\\\", \\\"{x:1465,y:671,t:1527272539599};\\\", \\\"{x:1467,y:671,t:1527272539615};\\\", \\\"{x:1470,y:671,t:1527272539632};\\\", \\\"{x:1474,y:672,t:1527272539649};\\\", \\\"{x:1481,y:673,t:1527272539665};\\\", \\\"{x:1485,y:675,t:1527272539682};\\\", \\\"{x:1496,y:680,t:1527272539699};\\\", \\\"{x:1507,y:687,t:1527272539714};\\\", \\\"{x:1515,y:692,t:1527272539731};\\\", \\\"{x:1524,y:699,t:1527272539748};\\\", \\\"{x:1527,y:702,t:1527272539764};\\\", \\\"{x:1531,y:704,t:1527272539781};\\\", \\\"{x:1539,y:710,t:1527272539799};\\\", \\\"{x:1550,y:721,t:1527272539814};\\\", \\\"{x:1564,y:732,t:1527272539831};\\\", \\\"{x:1578,y:744,t:1527272539849};\\\", \\\"{x:1588,y:752,t:1527272539864};\\\", \\\"{x:1595,y:759,t:1527272539881};\\\", \\\"{x:1605,y:764,t:1527272539899};\\\", \\\"{x:1608,y:766,t:1527272539915};\\\", \\\"{x:1611,y:767,t:1527272539932};\\\", \\\"{x:1614,y:767,t:1527272539948};\\\", \\\"{x:1617,y:767,t:1527272539966};\\\", \\\"{x:1619,y:767,t:1527272539981};\\\", \\\"{x:1621,y:767,t:1527272539998};\\\", \\\"{x:1622,y:765,t:1527272540016};\\\", \\\"{x:1622,y:763,t:1527272540032};\\\", \\\"{x:1622,y:758,t:1527272540049};\\\", \\\"{x:1620,y:749,t:1527272540066};\\\", \\\"{x:1620,y:741,t:1527272540081};\\\", \\\"{x:1614,y:730,t:1527272540099};\\\", \\\"{x:1609,y:712,t:1527272540116};\\\", \\\"{x:1609,y:710,t:1527272540132};\\\", \\\"{x:1609,y:709,t:1527272540148};\\\", \\\"{x:1609,y:708,t:1527272540245};\\\", \\\"{x:1609,y:707,t:1527272540292};\\\", \\\"{x:1610,y:706,t:1527272540364};\\\", \\\"{x:1611,y:706,t:1527272540383};\\\", \\\"{x:1613,y:704,t:1527272540399};\\\", \\\"{x:1613,y:703,t:1527272540415};\\\", \\\"{x:1614,y:703,t:1527272540433};\\\", \\\"{x:1614,y:702,t:1527272540453};\\\", \\\"{x:1616,y:701,t:1527272540465};\\\", \\\"{x:1617,y:699,t:1527272540482};\\\", \\\"{x:1620,y:695,t:1527272540498};\\\", \\\"{x:1623,y:691,t:1527272540517};\\\", \\\"{x:1621,y:691,t:1527272540749};\\\", \\\"{x:1619,y:691,t:1527272541141};\\\", \\\"{x:1618,y:692,t:1527272541172};\\\", \\\"{x:1617,y:692,t:1527272541200};\\\", \\\"{x:1616,y:693,t:1527272541216};\\\", \\\"{x:1616,y:694,t:1527272542924};\\\", \\\"{x:1616,y:695,t:1527272542934};\\\", \\\"{x:1616,y:698,t:1527272542996};\\\", \\\"{x:1616,y:703,t:1527272543005};\\\", \\\"{x:1616,y:706,t:1527272543018};\\\", \\\"{x:1616,y:714,t:1527272543035};\\\", \\\"{x:1616,y:722,t:1527272543050};\\\", \\\"{x:1616,y:727,t:1527272543067};\\\", \\\"{x:1616,y:733,t:1527272543084};\\\", \\\"{x:1616,y:738,t:1527272543100};\\\", \\\"{x:1615,y:742,t:1527272543118};\\\", \\\"{x:1615,y:751,t:1527272543135};\\\", \\\"{x:1613,y:757,t:1527272543150};\\\", \\\"{x:1613,y:762,t:1527272543167};\\\", \\\"{x:1613,y:769,t:1527272543184};\\\", \\\"{x:1613,y:774,t:1527272543201};\\\", \\\"{x:1613,y:777,t:1527272543217};\\\", \\\"{x:1613,y:780,t:1527272543235};\\\", \\\"{x:1613,y:782,t:1527272543252};\\\", \\\"{x:1613,y:784,t:1527272543268};\\\", \\\"{x:1613,y:790,t:1527272543284};\\\", \\\"{x:1613,y:797,t:1527272543301};\\\", \\\"{x:1613,y:803,t:1527272543317};\\\", \\\"{x:1615,y:807,t:1527272543334};\\\", \\\"{x:1615,y:809,t:1527272543351};\\\", \\\"{x:1615,y:810,t:1527272543367};\\\", \\\"{x:1616,y:811,t:1527272543384};\\\", \\\"{x:1616,y:812,t:1527272543402};\\\", \\\"{x:1616,y:813,t:1527272543417};\\\", \\\"{x:1616,y:814,t:1527272543435};\\\", \\\"{x:1616,y:815,t:1527272543461};\\\", \\\"{x:1616,y:818,t:1527272543476};\\\", \\\"{x:1616,y:819,t:1527272543524};\\\", \\\"{x:1616,y:821,t:1527272543548};\\\", \\\"{x:1616,y:823,t:1527272543588};\\\", \\\"{x:1616,y:824,t:1527272543602};\\\", \\\"{x:1615,y:826,t:1527272543618};\\\", \\\"{x:1614,y:831,t:1527272543635};\\\", \\\"{x:1614,y:834,t:1527272543652};\\\", \\\"{x:1614,y:835,t:1527272543669};\\\", \\\"{x:1614,y:840,t:1527272543847};\\\", \\\"{x:1614,y:844,t:1527272543855};\\\", \\\"{x:1619,y:867,t:1527272543871};\\\", \\\"{x:1623,y:884,t:1527272543887};\\\", \\\"{x:1625,y:903,t:1527272543904};\\\", \\\"{x:1628,y:924,t:1527272543922};\\\", \\\"{x:1628,y:935,t:1527272543938};\\\", \\\"{x:1629,y:943,t:1527272543955};\\\", \\\"{x:1629,y:946,t:1527272543972};\\\", \\\"{x:1629,y:949,t:1527272543988};\\\", \\\"{x:1629,y:951,t:1527272544004};\\\", \\\"{x:1629,y:953,t:1527272544022};\\\", \\\"{x:1629,y:959,t:1527272544039};\\\", \\\"{x:1629,y:963,t:1527272544055};\\\", \\\"{x:1629,y:967,t:1527272544071};\\\", \\\"{x:1628,y:971,t:1527272544089};\\\", \\\"{x:1627,y:974,t:1527272544104};\\\", \\\"{x:1626,y:976,t:1527272544121};\\\", \\\"{x:1625,y:976,t:1527272544207};\\\", \\\"{x:1625,y:977,t:1527272544222};\\\", \\\"{x:1623,y:977,t:1527272544400};\\\", \\\"{x:1622,y:977,t:1527272544406};\\\", \\\"{x:1619,y:975,t:1527272544422};\\\", \\\"{x:1614,y:969,t:1527272544439};\\\", \\\"{x:1611,y:963,t:1527272544455};\\\", \\\"{x:1610,y:962,t:1527272544472};\\\", \\\"{x:1611,y:961,t:1527272544767};\\\", \\\"{x:1613,y:961,t:1527272545208};\\\", \\\"{x:1614,y:961,t:1527272549416};\\\", \\\"{x:1616,y:961,t:1527272549895};\\\", \\\"{x:1616,y:960,t:1527272550648};\\\", \\\"{x:1616,y:959,t:1527272550664};\\\", \\\"{x:1616,y:953,t:1527272550677};\\\", \\\"{x:1616,y:942,t:1527272550693};\\\", \\\"{x:1616,y:933,t:1527272550710};\\\", \\\"{x:1616,y:929,t:1527272550727};\\\", \\\"{x:1616,y:925,t:1527272550744};\\\", \\\"{x:1616,y:922,t:1527272550761};\\\", \\\"{x:1616,y:918,t:1527272550777};\\\", \\\"{x:1615,y:915,t:1527272550793};\\\", \\\"{x:1615,y:912,t:1527272550811};\\\", \\\"{x:1615,y:909,t:1527272550827};\\\", \\\"{x:1614,y:905,t:1527272550843};\\\", \\\"{x:1613,y:901,t:1527272550860};\\\", \\\"{x:1612,y:896,t:1527272550877};\\\", \\\"{x:1612,y:893,t:1527272550894};\\\", \\\"{x:1612,y:886,t:1527272550911};\\\", \\\"{x:1612,y:882,t:1527272550927};\\\", \\\"{x:1612,y:876,t:1527272550944};\\\", \\\"{x:1612,y:871,t:1527272550961};\\\", \\\"{x:1612,y:867,t:1527272550977};\\\", \\\"{x:1611,y:859,t:1527272550994};\\\", \\\"{x:1609,y:853,t:1527272551011};\\\", \\\"{x:1609,y:848,t:1527272551028};\\\", \\\"{x:1609,y:843,t:1527272551044};\\\", \\\"{x:1609,y:836,t:1527272551061};\\\", \\\"{x:1609,y:832,t:1527272551078};\\\", \\\"{x:1609,y:830,t:1527272551094};\\\", \\\"{x:1609,y:825,t:1527272551111};\\\", \\\"{x:1611,y:820,t:1527272551127};\\\", \\\"{x:1611,y:818,t:1527272551144};\\\", \\\"{x:1611,y:817,t:1527272551161};\\\", \\\"{x:1611,y:816,t:1527272551178};\\\", \\\"{x:1611,y:815,t:1527272551194};\\\", \\\"{x:1612,y:815,t:1527272551287};\\\", \\\"{x:1613,y:815,t:1527272551295};\\\", \\\"{x:1615,y:815,t:1527272551310};\\\", \\\"{x:1616,y:815,t:1527272551328};\\\", \\\"{x:1616,y:816,t:1527272551343};\\\", \\\"{x:1619,y:818,t:1527272551360};\\\", \\\"{x:1619,y:819,t:1527272551377};\\\", \\\"{x:1619,y:820,t:1527272551393};\\\", \\\"{x:1619,y:821,t:1527272551410};\\\", \\\"{x:1619,y:822,t:1527272551463};\\\", \\\"{x:1619,y:825,t:1527272551478};\\\", \\\"{x:1619,y:827,t:1527272551494};\\\", \\\"{x:1619,y:828,t:1527272551511};\\\", \\\"{x:1619,y:829,t:1527272551671};\\\", \\\"{x:1618,y:829,t:1527272551799};\\\", \\\"{x:1617,y:829,t:1527272551847};\\\", \\\"{x:1617,y:828,t:1527272551871};\\\", \\\"{x:1616,y:828,t:1527272551887};\\\", \\\"{x:1614,y:828,t:1527272552192};\\\", \\\"{x:1613,y:828,t:1527272552311};\\\", \\\"{x:1613,y:827,t:1527272554007};\\\", \\\"{x:1614,y:825,t:1527272559671};\\\", \\\"{x:1614,y:821,t:1527272559684};\\\", \\\"{x:1617,y:818,t:1527272559701};\\\", \\\"{x:1618,y:818,t:1527272559718};\\\", \\\"{x:1618,y:815,t:1527272559975};\\\", \\\"{x:1618,y:808,t:1527272559985};\\\", \\\"{x:1615,y:788,t:1527272560001};\\\", \\\"{x:1609,y:770,t:1527272560018};\\\", \\\"{x:1605,y:759,t:1527272560036};\\\", \\\"{x:1605,y:754,t:1527272560051};\\\", \\\"{x:1605,y:750,t:1527272560068};\\\", \\\"{x:1605,y:746,t:1527272560085};\\\", \\\"{x:1605,y:742,t:1527272560103};\\\", \\\"{x:1605,y:740,t:1527272560118};\\\", \\\"{x:1605,y:738,t:1527272560135};\\\", \\\"{x:1605,y:736,t:1527272560153};\\\", \\\"{x:1604,y:734,t:1527272560168};\\\", \\\"{x:1603,y:733,t:1527272560185};\\\", \\\"{x:1603,y:732,t:1527272560202};\\\", \\\"{x:1603,y:731,t:1527272560239};\\\", \\\"{x:1603,y:729,t:1527272560252};\\\", \\\"{x:1604,y:726,t:1527272560268};\\\", \\\"{x:1605,y:723,t:1527272560286};\\\", \\\"{x:1606,y:719,t:1527272560303};\\\", \\\"{x:1607,y:717,t:1527272560318};\\\", \\\"{x:1610,y:712,t:1527272560335};\\\", \\\"{x:1611,y:710,t:1527272560353};\\\", \\\"{x:1612,y:709,t:1527272560368};\\\", \\\"{x:1613,y:708,t:1527272560391};\\\", \\\"{x:1613,y:706,t:1527272560407};\\\", \\\"{x:1614,y:706,t:1527272560418};\\\", \\\"{x:1615,y:703,t:1527272560435};\\\", \\\"{x:1616,y:700,t:1527272560452};\\\", \\\"{x:1616,y:699,t:1527272560469};\\\", \\\"{x:1617,y:699,t:1527272560494};\\\", \\\"{x:1617,y:697,t:1527272560526};\\\", \\\"{x:1617,y:696,t:1527272560550};\\\", \\\"{x:1618,y:695,t:1527272560573};\\\", \\\"{x:1618,y:694,t:1527272560584};\\\", \\\"{x:1618,y:693,t:1527272560743};\\\", \\\"{x:1618,y:691,t:1527272560753};\\\", \\\"{x:1618,y:689,t:1527272560769};\\\", \\\"{x:1618,y:686,t:1527272560785};\\\", \\\"{x:1619,y:681,t:1527272560801};\\\", \\\"{x:1620,y:675,t:1527272560819};\\\", \\\"{x:1623,y:666,t:1527272560835};\\\", \\\"{x:1626,y:656,t:1527272560852};\\\", \\\"{x:1627,y:651,t:1527272560869};\\\", \\\"{x:1628,y:646,t:1527272560885};\\\", \\\"{x:1628,y:642,t:1527272560902};\\\", \\\"{x:1629,y:638,t:1527272560919};\\\", \\\"{x:1629,y:636,t:1527272560936};\\\", \\\"{x:1631,y:633,t:1527272560952};\\\", \\\"{x:1631,y:632,t:1527272560969};\\\", \\\"{x:1631,y:629,t:1527272560986};\\\", \\\"{x:1631,y:628,t:1527272561002};\\\", \\\"{x:1632,y:627,t:1527272561019};\\\", \\\"{x:1632,y:625,t:1527272561037};\\\", \\\"{x:1632,y:624,t:1527272561053};\\\", \\\"{x:1632,y:619,t:1527272561069};\\\", \\\"{x:1632,y:612,t:1527272561087};\\\", \\\"{x:1631,y:608,t:1527272561103};\\\", \\\"{x:1630,y:604,t:1527272561120};\\\", \\\"{x:1628,y:598,t:1527272561136};\\\", \\\"{x:1627,y:595,t:1527272561153};\\\", \\\"{x:1626,y:591,t:1527272561169};\\\", \\\"{x:1626,y:589,t:1527272561186};\\\", \\\"{x:1626,y:588,t:1527272561202};\\\", \\\"{x:1626,y:585,t:1527272561220};\\\", \\\"{x:1626,y:583,t:1527272561236};\\\", \\\"{x:1626,y:582,t:1527272561252};\\\", \\\"{x:1626,y:580,t:1527272561295};\\\", \\\"{x:1626,y:579,t:1527272561303};\\\", \\\"{x:1626,y:577,t:1527272561319};\\\", \\\"{x:1626,y:576,t:1527272561336};\\\", \\\"{x:1626,y:575,t:1527272561358};\\\", \\\"{x:1625,y:575,t:1527272561369};\\\", \\\"{x:1624,y:573,t:1527272561386};\\\", \\\"{x:1623,y:572,t:1527272561403};\\\", \\\"{x:1622,y:569,t:1527272561419};\\\", \\\"{x:1619,y:566,t:1527272561436};\\\", \\\"{x:1618,y:565,t:1527272561463};\\\", \\\"{x:1617,y:565,t:1527272561494};\\\", \\\"{x:1616,y:565,t:1527272561502};\\\", \\\"{x:1615,y:565,t:1527272561519};\\\", \\\"{x:1614,y:564,t:1527272561575};\\\", \\\"{x:1613,y:564,t:1527272561586};\\\", \\\"{x:1611,y:564,t:1527272561603};\\\", \\\"{x:1610,y:563,t:1527272561619};\\\", \\\"{x:1610,y:564,t:1527272564735};\\\", \\\"{x:1610,y:565,t:1527272564791};\\\", \\\"{x:1611,y:566,t:1527272564823};\\\", \\\"{x:1611,y:567,t:1527272564839};\\\", \\\"{x:1611,y:569,t:1527272564856};\\\", \\\"{x:1612,y:571,t:1527272564873};\\\", \\\"{x:1612,y:572,t:1527272564903};\\\", \\\"{x:1612,y:574,t:1527272564983};\\\", \\\"{x:1612,y:575,t:1527272564990};\\\", \\\"{x:1614,y:578,t:1527272565006};\\\", \\\"{x:1615,y:582,t:1527272565023};\\\", \\\"{x:1615,y:585,t:1527272565039};\\\", \\\"{x:1615,y:587,t:1527272565057};\\\", \\\"{x:1616,y:590,t:1527272565072};\\\", \\\"{x:1616,y:593,t:1527272565089};\\\", \\\"{x:1617,y:595,t:1527272565107};\\\", \\\"{x:1617,y:599,t:1527272565123};\\\", \\\"{x:1617,y:603,t:1527272565140};\\\", \\\"{x:1617,y:608,t:1527272565156};\\\", \\\"{x:1618,y:610,t:1527272565172};\\\", \\\"{x:1618,y:611,t:1527272565223};\\\", \\\"{x:1618,y:613,t:1527272565239};\\\", \\\"{x:1618,y:614,t:1527272565264};\\\", \\\"{x:1618,y:616,t:1527272565272};\\\", \\\"{x:1618,y:617,t:1527272565303};\\\", \\\"{x:1618,y:618,t:1527272565311};\\\", \\\"{x:1618,y:620,t:1527272565327};\\\", \\\"{x:1618,y:622,t:1527272565343};\\\", \\\"{x:1618,y:624,t:1527272565359};\\\", \\\"{x:1618,y:625,t:1527272565374};\\\", \\\"{x:1618,y:627,t:1527272565390};\\\", \\\"{x:1616,y:630,t:1527272565407};\\\", \\\"{x:1616,y:631,t:1527272565423};\\\", \\\"{x:1615,y:632,t:1527272565440};\\\", \\\"{x:1615,y:633,t:1527272565456};\\\", \\\"{x:1614,y:633,t:1527272566287};\\\", \\\"{x:1608,y:633,t:1527272566295};\\\", \\\"{x:1604,y:633,t:1527272566307};\\\", \\\"{x:1596,y:633,t:1527272566323};\\\", \\\"{x:1588,y:633,t:1527272566340};\\\", \\\"{x:1584,y:632,t:1527272566358};\\\", \\\"{x:1582,y:632,t:1527272566373};\\\", \\\"{x:1581,y:632,t:1527272566431};\\\", \\\"{x:1580,y:632,t:1527272566441};\\\", \\\"{x:1577,y:632,t:1527272566458};\\\", \\\"{x:1573,y:632,t:1527272566475};\\\", \\\"{x:1569,y:632,t:1527272566490};\\\", \\\"{x:1566,y:633,t:1527272566508};\\\", \\\"{x:1563,y:633,t:1527272566523};\\\", \\\"{x:1559,y:633,t:1527272566541};\\\", \\\"{x:1552,y:634,t:1527272566558};\\\", \\\"{x:1547,y:634,t:1527272566574};\\\", \\\"{x:1532,y:634,t:1527272566590};\\\", \\\"{x:1524,y:634,t:1527272566607};\\\", \\\"{x:1522,y:634,t:1527272566625};\\\", \\\"{x:1521,y:634,t:1527272566640};\\\", \\\"{x:1519,y:634,t:1527272566703};\\\", \\\"{x:1518,y:634,t:1527272566710};\\\", \\\"{x:1516,y:634,t:1527272566725};\\\", \\\"{x:1513,y:633,t:1527272566740};\\\", \\\"{x:1512,y:633,t:1527272566758};\\\", \\\"{x:1511,y:633,t:1527272566903};\\\", \\\"{x:1511,y:632,t:1527272566911};\\\", \\\"{x:1509,y:632,t:1527272566935};\\\", \\\"{x:1511,y:632,t:1527272567543};\\\", \\\"{x:1518,y:631,t:1527272567558};\\\", \\\"{x:1528,y:629,t:1527272567575};\\\", \\\"{x:1534,y:628,t:1527272567592};\\\", \\\"{x:1541,y:628,t:1527272567608};\\\", \\\"{x:1544,y:628,t:1527272567625};\\\", \\\"{x:1546,y:627,t:1527272567641};\\\", \\\"{x:1547,y:627,t:1527272567659};\\\", \\\"{x:1548,y:627,t:1527272567694};\\\", \\\"{x:1550,y:627,t:1527272567710};\\\", \\\"{x:1552,y:627,t:1527272567725};\\\", \\\"{x:1555,y:627,t:1527272567742};\\\", \\\"{x:1557,y:627,t:1527272567759};\\\", \\\"{x:1558,y:627,t:1527272567951};\\\", \\\"{x:1560,y:628,t:1527272567958};\\\", \\\"{x:1564,y:629,t:1527272567975};\\\", \\\"{x:1569,y:632,t:1527272567991};\\\", \\\"{x:1570,y:632,t:1527272568009};\\\", \\\"{x:1571,y:632,t:1527272568271};\\\", \\\"{x:1572,y:632,t:1527272568279};\\\", \\\"{x:1573,y:633,t:1527272568302};\\\", \\\"{x:1576,y:633,t:1527272568319};\\\", \\\"{x:1578,y:634,t:1527272568333};\\\", \\\"{x:1580,y:635,t:1527272568358};\\\", \\\"{x:1582,y:635,t:1527272568414};\\\", \\\"{x:1583,y:635,t:1527272572831};\\\", \\\"{x:1585,y:635,t:1527272574192};\\\", \\\"{x:1587,y:635,t:1527272574199};\\\", \\\"{x:1589,y:636,t:1527272574214};\\\", \\\"{x:1590,y:637,t:1527272574231};\\\", \\\"{x:1592,y:637,t:1527272574247};\\\", \\\"{x:1595,y:639,t:1527272574264};\\\", \\\"{x:1600,y:644,t:1527272574281};\\\", \\\"{x:1603,y:651,t:1527272574297};\\\", \\\"{x:1608,y:660,t:1527272574314};\\\", \\\"{x:1611,y:666,t:1527272574331};\\\", \\\"{x:1618,y:677,t:1527272574347};\\\", \\\"{x:1622,y:684,t:1527272574363};\\\", \\\"{x:1623,y:686,t:1527272574381};\\\", \\\"{x:1623,y:687,t:1527272574464};\\\", \\\"{x:1624,y:687,t:1527272574480};\\\", \\\"{x:1624,y:688,t:1527272574743};\\\", \\\"{x:1623,y:688,t:1527272575311};\\\", \\\"{x:1622,y:689,t:1527272575318};\\\", \\\"{x:1620,y:690,t:1527272575332};\\\", \\\"{x:1619,y:691,t:1527272575348};\\\", \\\"{x:1617,y:691,t:1527272575365};\\\", \\\"{x:1616,y:691,t:1527272575382};\\\", \\\"{x:1614,y:692,t:1527272575399};\\\", \\\"{x:1613,y:693,t:1527272575414};\\\", \\\"{x:1612,y:693,t:1527272578727};\\\", \\\"{x:1612,y:697,t:1527272582143};\\\", \\\"{x:1612,y:701,t:1527272582154};\\\", \\\"{x:1613,y:705,t:1527272582171};\\\", \\\"{x:1615,y:711,t:1527272582187};\\\", \\\"{x:1615,y:713,t:1527272582204};\\\", \\\"{x:1617,y:714,t:1527272582220};\\\", \\\"{x:1617,y:715,t:1527272582237};\\\", \\\"{x:1617,y:717,t:1527272582478};\\\", \\\"{x:1617,y:718,t:1527272582487};\\\", \\\"{x:1617,y:719,t:1527272582503};\\\", \\\"{x:1617,y:722,t:1527272582521};\\\", \\\"{x:1617,y:727,t:1527272582537};\\\", \\\"{x:1617,y:731,t:1527272582554};\\\", \\\"{x:1617,y:736,t:1527272582571};\\\", \\\"{x:1617,y:741,t:1527272582587};\\\", \\\"{x:1617,y:747,t:1527272582603};\\\", \\\"{x:1617,y:752,t:1527272582621};\\\", \\\"{x:1617,y:763,t:1527272582638};\\\", \\\"{x:1617,y:769,t:1527272582654};\\\", \\\"{x:1617,y:773,t:1527272582671};\\\", \\\"{x:1617,y:775,t:1527272582688};\\\", \\\"{x:1617,y:777,t:1527272582704};\\\", \\\"{x:1617,y:781,t:1527272582721};\\\", \\\"{x:1617,y:785,t:1527272582738};\\\", \\\"{x:1617,y:790,t:1527272582754};\\\", \\\"{x:1617,y:793,t:1527272582771};\\\", \\\"{x:1617,y:795,t:1527272582788};\\\", \\\"{x:1617,y:797,t:1527272582804};\\\", \\\"{x:1617,y:801,t:1527272582821};\\\", \\\"{x:1617,y:804,t:1527272582838};\\\", \\\"{x:1617,y:807,t:1527272582855};\\\", \\\"{x:1617,y:809,t:1527272582871};\\\", \\\"{x:1617,y:812,t:1527272582888};\\\", \\\"{x:1617,y:815,t:1527272582905};\\\", \\\"{x:1617,y:817,t:1527272582921};\\\", \\\"{x:1617,y:818,t:1527272582942};\\\", \\\"{x:1617,y:820,t:1527272583327};\\\", \\\"{x:1616,y:821,t:1527272583351};\\\", \\\"{x:1615,y:822,t:1527272583383};\\\", \\\"{x:1614,y:823,t:1527272583399};\\\", \\\"{x:1614,y:824,t:1527272583439};\\\", \\\"{x:1614,y:825,t:1527272583456};\\\", \\\"{x:1607,y:825,t:1527272588327};\\\", \\\"{x:1558,y:792,t:1527272588341};\\\", \\\"{x:1440,y:728,t:1527272588358};\\\", \\\"{x:1301,y:653,t:1527272588376};\\\", \\\"{x:1165,y:585,t:1527272588392};\\\", \\\"{x:1046,y:528,t:1527272588408};\\\", \\\"{x:961,y:509,t:1527272588426};\\\", \\\"{x:925,y:509,t:1527272588443};\\\", \\\"{x:907,y:514,t:1527272588458};\\\", \\\"{x:894,y:531,t:1527272588477};\\\", \\\"{x:889,y:544,t:1527272588487};\\\", \\\"{x:887,y:551,t:1527272588504};\\\", \\\"{x:887,y:553,t:1527272588521};\\\", \\\"{x:886,y:554,t:1527272588541};\\\", \\\"{x:880,y:554,t:1527272588554};\\\", \\\"{x:864,y:555,t:1527272588571};\\\", \\\"{x:853,y:560,t:1527272588588};\\\", \\\"{x:843,y:567,t:1527272588605};\\\", \\\"{x:827,y:573,t:1527272588623};\\\", \\\"{x:801,y:574,t:1527272588640};\\\", \\\"{x:762,y:571,t:1527272588657};\\\", \\\"{x:689,y:559,t:1527272588674};\\\", \\\"{x:621,y:551,t:1527272588690};\\\", \\\"{x:575,y:548,t:1527272588707};\\\", \\\"{x:554,y:548,t:1527272588723};\\\", \\\"{x:548,y:548,t:1527272588741};\\\", \\\"{x:547,y:548,t:1527272588758};\\\", \\\"{x:543,y:548,t:1527272588790};\\\", \\\"{x:527,y:546,t:1527272588807};\\\", \\\"{x:515,y:546,t:1527272588823};\\\", \\\"{x:513,y:546,t:1527272588841};\\\", \\\"{x:519,y:547,t:1527272588870};\\\", \\\"{x:526,y:554,t:1527272588878};\\\", \\\"{x:535,y:559,t:1527272588891};\\\", \\\"{x:545,y:567,t:1527272588908};\\\", \\\"{x:553,y:570,t:1527272588924};\\\", \\\"{x:564,y:575,t:1527272588940};\\\", \\\"{x:576,y:580,t:1527272588957};\\\", \\\"{x:587,y:586,t:1527272588974};\\\", \\\"{x:589,y:586,t:1527272588990};\\\", \\\"{x:590,y:586,t:1527272589174};\\\", \\\"{x:587,y:589,t:1527272589390};\\\", \\\"{x:584,y:593,t:1527272589398};\\\", \\\"{x:580,y:599,t:1527272589411};\\\", \\\"{x:576,y:611,t:1527272589425};\\\", \\\"{x:570,y:624,t:1527272589440};\\\", \\\"{x:562,y:642,t:1527272589458};\\\", \\\"{x:547,y:670,t:1527272589474};\\\", \\\"{x:542,y:695,t:1527272589490};\\\", \\\"{x:537,y:709,t:1527272589507};\\\", \\\"{x:533,y:716,t:1527272589524};\\\", \\\"{x:532,y:716,t:1527272589541};\\\", \\\"{x:543,y:711,t:1527272589782};\\\", \\\"{x:578,y:702,t:1527272589792};\\\", \\\"{x:613,y:688,t:1527272589807};\\\", \\\"{x:625,y:673,t:1527272589825};\\\", \\\"{x:629,y:666,t:1527272589841};\\\", \\\"{x:629,y:663,t:1527272589858};\\\", \\\"{x:629,y:660,t:1527272589875};\\\", \\\"{x:629,y:658,t:1527272589892};\\\", \\\"{x:628,y:654,t:1527272589907};\\\", \\\"{x:622,y:644,t:1527272589925};\\\", \\\"{x:616,y:632,t:1527272589941};\\\", \\\"{x:613,y:624,t:1527272589958};\\\", \\\"{x:610,y:618,t:1527272589973};\\\", \\\"{x:610,y:615,t:1527272589990};\\\", \\\"{x:607,y:613,t:1527272590007};\\\", \\\"{x:603,y:608,t:1527272590023};\\\", \\\"{x:599,y:599,t:1527272590041};\\\", \\\"{x:595,y:593,t:1527272590057};\\\", \\\"{x:595,y:588,t:1527272590074};\\\", \\\"{x:595,y:584,t:1527272590091};\\\", \\\"{x:596,y:576,t:1527272590108};\\\", \\\"{x:598,y:574,t:1527272590124};\\\", \\\"{x:599,y:572,t:1527272590141};\\\", \\\"{x:600,y:572,t:1527272590231};\\\", \\\"{x:600,y:571,t:1527272590241};\\\", \\\"{x:601,y:571,t:1527272590258};\\\", \\\"{x:601,y:580,t:1527272590502};\\\", \\\"{x:600,y:591,t:1527272590510};\\\", \\\"{x:600,y:597,t:1527272590525};\\\", \\\"{x:598,y:612,t:1527272590541};\\\", \\\"{x:592,y:634,t:1527272590558};\\\", \\\"{x:587,y:646,t:1527272590575};\\\", \\\"{x:582,y:660,t:1527272590591};\\\", \\\"{x:579,y:680,t:1527272590608};\\\", \\\"{x:576,y:702,t:1527272590625};\\\", \\\"{x:570,y:719,t:1527272590641};\\\", \\\"{x:561,y:736,t:1527272590659};\\\", \\\"{x:551,y:745,t:1527272590675};\\\", \\\"{x:541,y:750,t:1527272590691};\\\", \\\"{x:540,y:751,t:1527272590708};\\\", \\\"{x:539,y:751,t:1527272590830};\\\", \\\"{x:538,y:751,t:1527272590887};\\\", \\\"{x:537,y:751,t:1527272590894};\\\", \\\"{x:535,y:750,t:1527272591092};\\\", \\\"{x:532,y:747,t:1527272591108};\\\", \\\"{x:532,y:746,t:1527272591125};\\\", \\\"{x:532,y:745,t:1527272591173};\\\", \\\"{x:532,y:744,t:1527272591181};\\\", \\\"{x:532,y:743,t:1527272591192};\\\", \\\"{x:532,y:742,t:1527272591209};\\\", \\\"{x:532,y:740,t:1527272591319};\\\", \\\"{x:533,y:739,t:1527272591326};\\\", \\\"{x:534,y:737,t:1527272591342};\\\", \\\"{x:536,y:735,t:1527272591359};\\\", \\\"{x:539,y:732,t:1527272591375};\\\", \\\"{x:556,y:723,t:1527272591392};\\\", \\\"{x:594,y:713,t:1527272591409};\\\", \\\"{x:670,y:696,t:1527272591425};\\\", \\\"{x:752,y:691,t:1527272591442};\\\", \\\"{x:799,y:691,t:1527272591460};\\\", \\\"{x:828,y:692,t:1527272591475};\\\", \\\"{x:850,y:692,t:1527272591493};\\\", \\\"{x:864,y:692,t:1527272591509};\\\", \\\"{x:878,y:691,t:1527272591525};\\\", \\\"{x:905,y:692,t:1527272591542};\\\", \\\"{x:917,y:695,t:1527272591559};\\\", \\\"{x:919,y:696,t:1527272591575};\\\", \\\"{x:920,y:697,t:1527272591638};\\\", \\\"{x:922,y:697,t:1527272591671};\\\", \\\"{x:923,y:697,t:1527272591694};\\\", \\\"{x:925,y:697,t:1527272591709};\\\", \\\"{x:927,y:697,t:1527272591725};\\\", \\\"{x:950,y:697,t:1527272591743};\\\", \\\"{x:977,y:697,t:1527272591760};\\\", \\\"{x:1017,y:700,t:1527272591776};\\\", \\\"{x:1079,y:708,t:1527272591792};\\\", \\\"{x:1157,y:719,t:1527272591810};\\\", \\\"{x:1235,y:730,t:1527272591826};\\\", \\\"{x:1304,y:740,t:1527272591842};\\\", \\\"{x:1359,y:752,t:1527272591859};\\\", \\\"{x:1384,y:757,t:1527272591876};\\\", \\\"{x:1396,y:759,t:1527272591892};\\\", \\\"{x:1403,y:760,t:1527272591909};\\\", \\\"{x:1406,y:760,t:1527272591926};\\\", \\\"{x:1407,y:760,t:1527272592015};\\\", \\\"{x:1409,y:760,t:1527272592026};\\\", \\\"{x:1410,y:759,t:1527272592054};\\\", \\\"{x:1413,y:756,t:1527272592062};\\\", \\\"{x:1414,y:751,t:1527272592077};\\\", \\\"{x:1415,y:724,t:1527272592105};\\\", \\\"{x:1410,y:709,t:1527272592109};\\\", \\\"{x:1368,y:635,t:1527272592126};\\\", \\\"{x:1312,y:569,t:1527272592143};\\\", \\\"{x:1233,y:512,t:1527272592159};\\\", \\\"{x:1154,y:482,t:1527272592176};\\\", \\\"{x:1094,y:466,t:1527272592193};\\\", \\\"{x:1065,y:462,t:1527272592209};\\\", \\\"{x:1051,y:462,t:1527272592226};\\\", \\\"{x:1039,y:469,t:1527272592243};\\\", \\\"{x:1031,y:482,t:1527272592259};\\\", \\\"{x:1023,y:500,t:1527272592276};\\\", \\\"{x:1015,y:516,t:1527272592293};\\\", \\\"{x:1015,y:529,t:1527272592309};\\\", \\\"{x:1021,y:543,t:1527272592325};\\\", \\\"{x:1031,y:557,t:1527272592343};\\\", \\\"{x:1036,y:569,t:1527272592360};\\\", \\\"{x:1038,y:581,t:1527272592376};\\\", \\\"{x:1042,y:590,t:1527272592394};\\\" ] }, { \\\"rt\\\": 58465, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 1187406, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-01 PM-03 PM-01 PM-03 PM-03 PM-03 PM-X -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1049,y:560,t:1527272592584};\\\", \\\"{x:1048,y:551,t:1527272592593};\\\", \\\"{x:1043,y:537,t:1527272592610};\\\", \\\"{x:1037,y:524,t:1527272592626};\\\", \\\"{x:1030,y:506,t:1527272592643};\\\", \\\"{x:1019,y:491,t:1527272592660};\\\", \\\"{x:1005,y:481,t:1527272592676};\\\", \\\"{x:984,y:473,t:1527272592693};\\\", \\\"{x:951,y:467,t:1527272592710};\\\", \\\"{x:918,y:466,t:1527272592738};\\\", \\\"{x:909,y:466,t:1527272592742};\\\", \\\"{x:895,y:469,t:1527272592760};\\\", \\\"{x:877,y:486,t:1527272592776};\\\", \\\"{x:863,y:508,t:1527272592794};\\\", \\\"{x:850,y:531,t:1527272592810};\\\", \\\"{x:831,y:611,t:1527272592901};\\\", \\\"{x:831,y:612,t:1527272592910};\\\", \\\"{x:829,y:612,t:1527272592965};\\\", \\\"{x:824,y:610,t:1527272592976};\\\", \\\"{x:810,y:598,t:1527272592993};\\\", \\\"{x:790,y:587,t:1527272593010};\\\", \\\"{x:749,y:565,t:1527272593027};\\\", \\\"{x:705,y:538,t:1527272593044};\\\", \\\"{x:650,y:504,t:1527272593061};\\\", \\\"{x:600,y:479,t:1527272593077};\\\", \\\"{x:566,y:462,t:1527272593093};\\\", \\\"{x:532,y:451,t:1527272593110};\\\", \\\"{x:516,y:448,t:1527272593127};\\\", \\\"{x:509,y:448,t:1527272593143};\\\", \\\"{x:506,y:446,t:1527272593160};\\\", \\\"{x:505,y:446,t:1527272593222};\\\", \\\"{x:503,y:446,t:1527272593238};\\\", \\\"{x:502,y:446,t:1527272593286};\\\", \\\"{x:500,y:446,t:1527272593311};\\\", \\\"{x:496,y:446,t:1527272593327};\\\", \\\"{x:496,y:447,t:1527272593344};\\\", \\\"{x:495,y:447,t:1527272593365};\\\", \\\"{x:494,y:448,t:1527272593376};\\\", \\\"{x:494,y:449,t:1527272593393};\\\", \\\"{x:494,y:454,t:1527272593410};\\\", \\\"{x:494,y:458,t:1527272593427};\\\", \\\"{x:494,y:459,t:1527272593443};\\\", \\\"{x:494,y:462,t:1527272593460};\\\", \\\"{x:495,y:466,t:1527272593477};\\\", \\\"{x:496,y:468,t:1527272593493};\\\", \\\"{x:497,y:469,t:1527272593510};\\\", \\\"{x:496,y:469,t:1527272593583};\\\", \\\"{x:495,y:467,t:1527272593594};\\\", \\\"{x:494,y:467,t:1527272593611};\\\", \\\"{x:494,y:466,t:1527272593679};\\\", \\\"{x:494,y:465,t:1527272593693};\\\", \\\"{x:494,y:460,t:1527272593710};\\\", \\\"{x:494,y:459,t:1527272593734};\\\", \\\"{x:494,y:458,t:1527272593743};\\\", \\\"{x:500,y:458,t:1527272593760};\\\", \\\"{x:516,y:455,t:1527272593777};\\\", \\\"{x:549,y:448,t:1527272593794};\\\", \\\"{x:640,y:436,t:1527272593811};\\\", \\\"{x:759,y:436,t:1527272593827};\\\", \\\"{x:869,y:443,t:1527272593844};\\\", \\\"{x:969,y:473,t:1527272593861};\\\", \\\"{x:1057,y:513,t:1527272593878};\\\", \\\"{x:1148,y:552,t:1527272593894};\\\", \\\"{x:1263,y:619,t:1527272593910};\\\", \\\"{x:1320,y:659,t:1527272593927};\\\", \\\"{x:1354,y:705,t:1527272593944};\\\", \\\"{x:1373,y:736,t:1527272593960};\\\", \\\"{x:1388,y:782,t:1527272593977};\\\", \\\"{x:1397,y:830,t:1527272593994};\\\", \\\"{x:1403,y:878,t:1527272594010};\\\", \\\"{x:1410,y:930,t:1527272594027};\\\", \\\"{x:1429,y:982,t:1527272594044};\\\", \\\"{x:1458,y:1029,t:1527272594061};\\\", \\\"{x:1483,y:1083,t:1527272594078};\\\", \\\"{x:1484,y:1094,t:1527272594093};\\\", \\\"{x:1484,y:1110,t:1527272594109};\\\", \\\"{x:1480,y:1116,t:1527272594126};\\\", \\\"{x:1478,y:1118,t:1527272594143};\\\", \\\"{x:1477,y:1118,t:1527272594174};\\\", \\\"{x:1475,y:1118,t:1527272594222};\\\", \\\"{x:1473,y:1118,t:1527272594230};\\\", \\\"{x:1468,y:1115,t:1527272594244};\\\", \\\"{x:1455,y:1105,t:1527272594260};\\\", \\\"{x:1433,y:1092,t:1527272594277};\\\", \\\"{x:1416,y:1079,t:1527272594293};\\\", \\\"{x:1397,y:1068,t:1527272594309};\\\", \\\"{x:1388,y:1063,t:1527272594326};\\\", \\\"{x:1388,y:1062,t:1527272594350};\\\", \\\"{x:1388,y:1060,t:1527272594360};\\\", \\\"{x:1388,y:1057,t:1527272594377};\\\", \\\"{x:1388,y:1044,t:1527272594394};\\\", \\\"{x:1388,y:1026,t:1527272594410};\\\", \\\"{x:1392,y:1004,t:1527272594426};\\\", \\\"{x:1398,y:995,t:1527272594444};\\\", \\\"{x:1401,y:991,t:1527272594459};\\\", \\\"{x:1402,y:991,t:1527272594477};\\\", \\\"{x:1403,y:989,t:1527272594494};\\\", \\\"{x:1404,y:988,t:1527272594510};\\\", \\\"{x:1405,y:985,t:1527272594527};\\\", \\\"{x:1406,y:984,t:1527272594567};\\\", \\\"{x:1408,y:982,t:1527272594578};\\\", \\\"{x:1413,y:980,t:1527272594593};\\\", \\\"{x:1427,y:975,t:1527272594609};\\\", \\\"{x:1444,y:967,t:1527272594626};\\\", \\\"{x:1458,y:964,t:1527272594643};\\\", \\\"{x:1465,y:964,t:1527272594659};\\\", \\\"{x:1470,y:964,t:1527272594676};\\\", \\\"{x:1477,y:964,t:1527272594692};\\\", \\\"{x:1485,y:964,t:1527272594709};\\\", \\\"{x:1496,y:964,t:1527272594726};\\\", \\\"{x:1507,y:964,t:1527272594743};\\\", \\\"{x:1520,y:966,t:1527272594760};\\\", \\\"{x:1528,y:969,t:1527272594776};\\\", \\\"{x:1534,y:970,t:1527272594792};\\\", \\\"{x:1540,y:971,t:1527272594809};\\\", \\\"{x:1545,y:972,t:1527272594827};\\\", \\\"{x:1548,y:972,t:1527272594843};\\\", \\\"{x:1549,y:972,t:1527272594860};\\\", \\\"{x:1549,y:971,t:1527272594975};\\\", \\\"{x:1548,y:971,t:1527272594982};\\\", \\\"{x:1547,y:971,t:1527272594993};\\\", \\\"{x:1545,y:971,t:1527272595010};\\\", \\\"{x:1543,y:970,t:1527272595026};\\\", \\\"{x:1541,y:970,t:1527272595086};\\\", \\\"{x:1539,y:970,t:1527272595094};\\\", \\\"{x:1536,y:970,t:1527272595109};\\\", \\\"{x:1535,y:970,t:1527272595126};\\\", \\\"{x:1536,y:970,t:1527272595174};\\\", \\\"{x:1538,y:970,t:1527272595182};\\\", \\\"{x:1540,y:970,t:1527272595193};\\\", \\\"{x:1546,y:968,t:1527272595211};\\\", \\\"{x:1550,y:967,t:1527272595226};\\\", \\\"{x:1551,y:967,t:1527272595242};\\\", \\\"{x:1553,y:967,t:1527272595375};\\\", \\\"{x:1553,y:966,t:1527272595599};\\\", \\\"{x:1552,y:966,t:1527272595614};\\\", \\\"{x:1550,y:965,t:1527272595626};\\\", \\\"{x:1550,y:964,t:1527272595644};\\\", \\\"{x:1549,y:961,t:1527272595783};\\\", \\\"{x:1547,y:955,t:1527272595793};\\\", \\\"{x:1547,y:952,t:1527272595810};\\\", \\\"{x:1547,y:951,t:1527272595826};\\\", \\\"{x:1547,y:949,t:1527272595919};\\\", \\\"{x:1547,y:946,t:1527272595927};\\\", \\\"{x:1547,y:940,t:1527272595942};\\\", \\\"{x:1548,y:935,t:1527272595959};\\\", \\\"{x:1548,y:933,t:1527272595976};\\\", \\\"{x:1548,y:930,t:1527272595992};\\\", \\\"{x:1550,y:927,t:1527272596009};\\\", \\\"{x:1551,y:922,t:1527272596026};\\\", \\\"{x:1551,y:919,t:1527272596043};\\\", \\\"{x:1551,y:914,t:1527272596059};\\\", \\\"{x:1552,y:907,t:1527272596077};\\\", \\\"{x:1553,y:903,t:1527272596094};\\\", \\\"{x:1554,y:900,t:1527272596109};\\\", \\\"{x:1554,y:895,t:1527272596126};\\\", \\\"{x:1556,y:890,t:1527272596143};\\\", \\\"{x:1557,y:887,t:1527272596159};\\\", \\\"{x:1558,y:885,t:1527272596176};\\\", \\\"{x:1558,y:883,t:1527272596193};\\\", \\\"{x:1558,y:881,t:1527272596209};\\\", \\\"{x:1559,y:879,t:1527272596226};\\\", \\\"{x:1559,y:877,t:1527272596243};\\\", \\\"{x:1559,y:874,t:1527272596259};\\\", \\\"{x:1559,y:873,t:1527272596279};\\\", \\\"{x:1559,y:872,t:1527272596303};\\\", \\\"{x:1559,y:871,t:1527272596319};\\\", \\\"{x:1559,y:870,t:1527272596327};\\\", \\\"{x:1559,y:864,t:1527272596342};\\\", \\\"{x:1556,y:855,t:1527272596359};\\\", \\\"{x:1553,y:847,t:1527272596376};\\\", \\\"{x:1553,y:845,t:1527272596393};\\\", \\\"{x:1553,y:843,t:1527272596409};\\\", \\\"{x:1553,y:842,t:1527272596438};\\\", \\\"{x:1553,y:841,t:1527272596447};\\\", \\\"{x:1553,y:840,t:1527272596458};\\\", \\\"{x:1553,y:837,t:1527272596476};\\\", \\\"{x:1553,y:836,t:1527272596518};\\\", \\\"{x:1552,y:835,t:1527272596575};\\\", \\\"{x:1550,y:833,t:1527272596592};\\\", \\\"{x:1547,y:830,t:1527272596609};\\\", \\\"{x:1545,y:829,t:1527272596627};\\\", \\\"{x:1544,y:829,t:1527272596718};\\\", \\\"{x:1543,y:829,t:1527272596759};\\\", \\\"{x:1545,y:829,t:1527272599711};\\\", \\\"{x:1547,y:829,t:1527272600415};\\\", \\\"{x:1551,y:830,t:1527272600431};\\\", \\\"{x:1554,y:832,t:1527272600441};\\\", \\\"{x:1555,y:832,t:1527272600457};\\\", \\\"{x:1557,y:833,t:1527272600474};\\\", \\\"{x:1560,y:836,t:1527272600490};\\\", \\\"{x:1561,y:844,t:1527272600508};\\\", \\\"{x:1562,y:849,t:1527272600524};\\\", \\\"{x:1562,y:851,t:1527272600540};\\\", \\\"{x:1562,y:852,t:1527272600557};\\\", \\\"{x:1562,y:853,t:1527272600574};\\\", \\\"{x:1562,y:855,t:1527272600590};\\\", \\\"{x:1562,y:856,t:1527272600608};\\\", \\\"{x:1562,y:858,t:1527272600625};\\\", \\\"{x:1561,y:864,t:1527272600641};\\\", \\\"{x:1561,y:870,t:1527272600657};\\\", \\\"{x:1559,y:874,t:1527272600675};\\\", \\\"{x:1557,y:879,t:1527272600690};\\\", \\\"{x:1557,y:881,t:1527272600707};\\\", \\\"{x:1554,y:884,t:1527272600725};\\\", \\\"{x:1554,y:885,t:1527272600740};\\\", \\\"{x:1552,y:888,t:1527272600757};\\\", \\\"{x:1551,y:895,t:1527272600774};\\\", \\\"{x:1550,y:898,t:1527272600791};\\\", \\\"{x:1549,y:903,t:1527272600807};\\\", \\\"{x:1547,y:908,t:1527272600824};\\\", \\\"{x:1547,y:911,t:1527272600840};\\\", \\\"{x:1547,y:914,t:1527272600856};\\\", \\\"{x:1546,y:915,t:1527272600874};\\\", \\\"{x:1546,y:916,t:1527272600893};\\\", \\\"{x:1546,y:917,t:1527272600907};\\\", \\\"{x:1546,y:920,t:1527272600923};\\\", \\\"{x:1546,y:926,t:1527272600940};\\\", \\\"{x:1546,y:932,t:1527272600957};\\\", \\\"{x:1546,y:938,t:1527272600973};\\\", \\\"{x:1546,y:941,t:1527272600990};\\\", \\\"{x:1546,y:944,t:1527272601007};\\\", \\\"{x:1546,y:947,t:1527272601024};\\\", \\\"{x:1546,y:950,t:1527272601040};\\\", \\\"{x:1546,y:953,t:1527272601058};\\\", \\\"{x:1546,y:956,t:1527272601073};\\\", \\\"{x:1546,y:958,t:1527272601090};\\\", \\\"{x:1546,y:959,t:1527272601107};\\\", \\\"{x:1546,y:960,t:1527272601123};\\\", \\\"{x:1546,y:961,t:1527272601140};\\\", \\\"{x:1546,y:962,t:1527272602534};\\\", \\\"{x:1546,y:959,t:1527272602550};\\\", \\\"{x:1546,y:956,t:1527272602558};\\\", \\\"{x:1546,y:955,t:1527272602573};\\\", \\\"{x:1546,y:951,t:1527272602588};\\\", \\\"{x:1548,y:949,t:1527272602606};\\\", \\\"{x:1548,y:946,t:1527272602623};\\\", \\\"{x:1548,y:945,t:1527272602639};\\\", \\\"{x:1549,y:943,t:1527272602678};\\\", \\\"{x:1550,y:943,t:1527272602689};\\\", \\\"{x:1550,y:941,t:1527272602706};\\\", \\\"{x:1550,y:937,t:1527272602724};\\\", \\\"{x:1551,y:931,t:1527272602739};\\\", \\\"{x:1551,y:926,t:1527272602756};\\\", \\\"{x:1551,y:921,t:1527272602773};\\\", \\\"{x:1551,y:917,t:1527272602789};\\\", \\\"{x:1551,y:915,t:1527272602806};\\\", \\\"{x:1551,y:914,t:1527272602823};\\\", \\\"{x:1551,y:913,t:1527272602839};\\\", \\\"{x:1552,y:913,t:1527272602857};\\\", \\\"{x:1552,y:912,t:1527272602879};\\\", \\\"{x:1553,y:911,t:1527272602889};\\\", \\\"{x:1553,y:909,t:1527272602906};\\\", \\\"{x:1553,y:903,t:1527272602923};\\\", \\\"{x:1553,y:898,t:1527272602939};\\\", \\\"{x:1553,y:894,t:1527272602956};\\\", \\\"{x:1553,y:892,t:1527272602973};\\\", \\\"{x:1553,y:890,t:1527272602988};\\\", \\\"{x:1553,y:886,t:1527272603006};\\\", \\\"{x:1552,y:882,t:1527272603023};\\\", \\\"{x:1552,y:875,t:1527272603039};\\\", \\\"{x:1552,y:873,t:1527272603057};\\\", \\\"{x:1552,y:871,t:1527272603073};\\\", \\\"{x:1552,y:867,t:1527272603089};\\\", \\\"{x:1552,y:866,t:1527272603106};\\\", \\\"{x:1552,y:862,t:1527272603123};\\\", \\\"{x:1552,y:861,t:1527272603139};\\\", \\\"{x:1552,y:859,t:1527272603156};\\\", \\\"{x:1552,y:858,t:1527272603173};\\\", \\\"{x:1552,y:855,t:1527272603190};\\\", \\\"{x:1552,y:853,t:1527272603206};\\\", \\\"{x:1552,y:848,t:1527272603222};\\\", \\\"{x:1552,y:845,t:1527272603240};\\\", \\\"{x:1552,y:842,t:1527272603256};\\\", \\\"{x:1552,y:840,t:1527272603271};\\\", \\\"{x:1552,y:839,t:1527272603289};\\\", \\\"{x:1552,y:838,t:1527272603306};\\\", \\\"{x:1552,y:837,t:1527272603322};\\\", \\\"{x:1552,y:835,t:1527272603339};\\\", \\\"{x:1552,y:834,t:1527272603356};\\\", \\\"{x:1552,y:831,t:1527272603372};\\\", \\\"{x:1552,y:830,t:1527272603389};\\\", \\\"{x:1552,y:829,t:1527272603406};\\\", \\\"{x:1552,y:828,t:1527272603430};\\\", \\\"{x:1552,y:827,t:1527272603480};\\\", \\\"{x:1550,y:825,t:1527272603488};\\\", \\\"{x:1549,y:824,t:1527272603598};\\\", \\\"{x:1548,y:822,t:1527272604250};\\\", \\\"{x:1548,y:818,t:1527272604259};\\\", \\\"{x:1548,y:808,t:1527272604275};\\\", \\\"{x:1551,y:796,t:1527272604292};\\\", \\\"{x:1555,y:786,t:1527272604308};\\\", \\\"{x:1557,y:778,t:1527272604325};\\\", \\\"{x:1557,y:775,t:1527272604342};\\\", \\\"{x:1559,y:773,t:1527272604358};\\\", \\\"{x:1560,y:770,t:1527272604376};\\\", \\\"{x:1560,y:769,t:1527272604393};\\\", \\\"{x:1560,y:768,t:1527272604409};\\\", \\\"{x:1560,y:766,t:1527272604425};\\\", \\\"{x:1560,y:765,t:1527272604442};\\\", \\\"{x:1560,y:763,t:1527272604459};\\\", \\\"{x:1562,y:759,t:1527272604476};\\\", \\\"{x:1563,y:756,t:1527272604492};\\\", \\\"{x:1564,y:752,t:1527272604509};\\\", \\\"{x:1564,y:751,t:1527272604526};\\\", \\\"{x:1564,y:750,t:1527272604541};\\\", \\\"{x:1564,y:748,t:1527272604558};\\\", \\\"{x:1564,y:747,t:1527272604576};\\\", \\\"{x:1564,y:745,t:1527272604591};\\\", \\\"{x:1564,y:744,t:1527272604609};\\\", \\\"{x:1564,y:742,t:1527272604625};\\\", \\\"{x:1563,y:738,t:1527272604641};\\\", \\\"{x:1560,y:735,t:1527272604659};\\\", \\\"{x:1556,y:728,t:1527272604675};\\\", \\\"{x:1553,y:724,t:1527272604691};\\\", \\\"{x:1549,y:720,t:1527272604709};\\\", \\\"{x:1548,y:717,t:1527272604726};\\\", \\\"{x:1548,y:715,t:1527272604794};\\\", \\\"{x:1548,y:713,t:1527272604809};\\\", \\\"{x:1548,y:711,t:1527272604825};\\\", \\\"{x:1551,y:705,t:1527272604841};\\\", \\\"{x:1552,y:700,t:1527272604858};\\\", \\\"{x:1553,y:699,t:1527272604876};\\\", \\\"{x:1553,y:697,t:1527272604892};\\\", \\\"{x:1553,y:695,t:1527272604908};\\\", \\\"{x:1554,y:695,t:1527272604926};\\\", \\\"{x:1553,y:693,t:1527272605074};\\\", \\\"{x:1551,y:693,t:1527272605082};\\\", \\\"{x:1549,y:693,t:1527272605092};\\\", \\\"{x:1543,y:691,t:1527272605109};\\\", \\\"{x:1540,y:690,t:1527272605124};\\\", \\\"{x:1538,y:689,t:1527272605141};\\\", \\\"{x:1538,y:683,t:1527272605314};\\\", \\\"{x:1544,y:672,t:1527272605325};\\\", \\\"{x:1549,y:655,t:1527272605342};\\\", \\\"{x:1552,y:638,t:1527272605359};\\\", \\\"{x:1552,y:630,t:1527272605374};\\\", \\\"{x:1552,y:627,t:1527272605392};\\\", \\\"{x:1552,y:626,t:1527272605409};\\\", \\\"{x:1552,y:624,t:1527272605458};\\\", \\\"{x:1552,y:618,t:1527272605474};\\\", \\\"{x:1551,y:611,t:1527272605492};\\\", \\\"{x:1550,y:598,t:1527272605508};\\\", \\\"{x:1547,y:591,t:1527272605525};\\\", \\\"{x:1547,y:586,t:1527272605542};\\\", \\\"{x:1547,y:585,t:1527272605559};\\\", \\\"{x:1546,y:582,t:1527272605574};\\\", \\\"{x:1546,y:581,t:1527272605592};\\\", \\\"{x:1545,y:580,t:1527272605608};\\\", \\\"{x:1545,y:579,t:1527272605625};\\\", \\\"{x:1545,y:576,t:1527272605642};\\\", \\\"{x:1544,y:575,t:1527272605659};\\\", \\\"{x:1544,y:573,t:1527272605674};\\\", \\\"{x:1544,y:572,t:1527272605721};\\\", \\\"{x:1544,y:571,t:1527272605729};\\\", \\\"{x:1544,y:569,t:1527272605742};\\\", \\\"{x:1544,y:566,t:1527272605757};\\\", \\\"{x:1544,y:564,t:1527272605774};\\\", \\\"{x:1544,y:563,t:1527272605792};\\\", \\\"{x:1544,y:561,t:1527272605986};\\\", \\\"{x:1544,y:558,t:1527272605993};\\\", \\\"{x:1544,y:555,t:1527272606008};\\\", \\\"{x:1544,y:547,t:1527272606025};\\\", \\\"{x:1544,y:537,t:1527272606040};\\\", \\\"{x:1546,y:523,t:1527272606058};\\\", \\\"{x:1547,y:520,t:1527272606074};\\\", \\\"{x:1549,y:518,t:1527272606092};\\\", \\\"{x:1549,y:517,t:1527272606137};\\\", \\\"{x:1550,y:513,t:1527272606154};\\\", \\\"{x:1551,y:511,t:1527272606161};\\\", \\\"{x:1552,y:509,t:1527272606175};\\\", \\\"{x:1555,y:501,t:1527272606192};\\\", \\\"{x:1558,y:493,t:1527272606207};\\\", \\\"{x:1558,y:489,t:1527272606225};\\\", \\\"{x:1560,y:484,t:1527272606242};\\\", \\\"{x:1562,y:480,t:1527272606258};\\\", \\\"{x:1562,y:479,t:1527272606282};\\\", \\\"{x:1562,y:478,t:1527272606330};\\\", \\\"{x:1564,y:477,t:1527272606340};\\\", \\\"{x:1564,y:476,t:1527272606358};\\\", \\\"{x:1564,y:474,t:1527272606375};\\\", \\\"{x:1564,y:473,t:1527272606391};\\\", \\\"{x:1564,y:472,t:1527272606408};\\\", \\\"{x:1564,y:471,t:1527272606425};\\\", \\\"{x:1564,y:470,t:1527272606441};\\\", \\\"{x:1564,y:468,t:1527272606458};\\\", \\\"{x:1563,y:467,t:1527272606482};\\\", \\\"{x:1562,y:466,t:1527272606490};\\\", \\\"{x:1560,y:464,t:1527272606508};\\\", \\\"{x:1557,y:461,t:1527272606524};\\\", \\\"{x:1554,y:458,t:1527272606540};\\\", \\\"{x:1552,y:457,t:1527272606558};\\\", \\\"{x:1551,y:456,t:1527272606575};\\\", \\\"{x:1551,y:455,t:1527272606590};\\\", \\\"{x:1550,y:453,t:1527272606607};\\\", \\\"{x:1546,y:449,t:1527272606625};\\\", \\\"{x:1544,y:447,t:1527272606641};\\\", \\\"{x:1544,y:446,t:1527272606722};\\\", \\\"{x:1544,y:444,t:1527272606842};\\\", \\\"{x:1544,y:441,t:1527272606858};\\\", \\\"{x:1545,y:439,t:1527272606875};\\\", \\\"{x:1545,y:436,t:1527272606891};\\\", \\\"{x:1545,y:434,t:1527272606908};\\\", \\\"{x:1547,y:431,t:1527272606925};\\\", \\\"{x:1547,y:430,t:1527272606941};\\\", \\\"{x:1548,y:430,t:1527272606985};\\\", \\\"{x:1548,y:426,t:1527272608050};\\\", \\\"{x:1548,y:423,t:1527272608057};\\\", \\\"{x:1548,y:419,t:1527272608074};\\\", \\\"{x:1547,y:411,t:1527272608091};\\\", \\\"{x:1546,y:406,t:1527272608107};\\\", \\\"{x:1545,y:401,t:1527272608124};\\\", \\\"{x:1545,y:399,t:1527272608140};\\\", \\\"{x:1545,y:397,t:1527272608157};\\\", \\\"{x:1544,y:395,t:1527272608173};\\\", \\\"{x:1544,y:392,t:1527272608191};\\\", \\\"{x:1542,y:386,t:1527272608207};\\\", \\\"{x:1541,y:379,t:1527272608224};\\\", \\\"{x:1539,y:368,t:1527272608240};\\\", \\\"{x:1539,y:363,t:1527272608257};\\\", \\\"{x:1539,y:358,t:1527272608274};\\\", \\\"{x:1540,y:357,t:1527272608313};\\\", \\\"{x:1542,y:356,t:1527272608330};\\\", \\\"{x:1543,y:356,t:1527272608354};\\\", \\\"{x:1544,y:356,t:1527272608369};\\\", \\\"{x:1545,y:356,t:1527272608376};\\\", \\\"{x:1546,y:356,t:1527272608392};\\\", \\\"{x:1547,y:356,t:1527272608406};\\\", \\\"{x:1548,y:356,t:1527272608423};\\\", \\\"{x:1549,y:356,t:1527272608439};\\\", \\\"{x:1550,y:356,t:1527272608610};\\\", \\\"{x:1551,y:354,t:1527272608624};\\\", \\\"{x:1551,y:346,t:1527272608639};\\\", \\\"{x:1552,y:332,t:1527272608657};\\\", \\\"{x:1553,y:321,t:1527272608674};\\\", \\\"{x:1553,y:319,t:1527272608690};\\\", \\\"{x:1553,y:318,t:1527272608794};\\\", \\\"{x:1553,y:316,t:1527272608807};\\\", \\\"{x:1553,y:315,t:1527272608823};\\\", \\\"{x:1552,y:313,t:1527272608850};\\\", \\\"{x:1552,y:312,t:1527272608874};\\\", \\\"{x:1551,y:312,t:1527272608889};\\\", \\\"{x:1548,y:311,t:1527272608906};\\\", \\\"{x:1547,y:310,t:1527272608923};\\\", \\\"{x:1546,y:309,t:1527272608940};\\\", \\\"{x:1546,y:308,t:1527272609082};\\\", \\\"{x:1546,y:307,t:1527272609090};\\\", \\\"{x:1546,y:306,t:1527272609107};\\\", \\\"{x:1546,y:305,t:1527272609162};\\\", \\\"{x:1546,y:303,t:1527272609178};\\\", \\\"{x:1546,y:302,t:1527272609193};\\\", \\\"{x:1547,y:301,t:1527272609207};\\\", \\\"{x:1547,y:300,t:1527272609222};\\\", \\\"{x:1547,y:299,t:1527272609239};\\\", \\\"{x:1548,y:298,t:1527272609273};\\\", \\\"{x:1548,y:297,t:1527272609289};\\\", \\\"{x:1548,y:296,t:1527272609321};\\\", \\\"{x:1548,y:295,t:1527272609331};\\\", \\\"{x:1548,y:294,t:1527272609346};\\\", \\\"{x:1548,y:301,t:1527272614018};\\\", \\\"{x:1547,y:322,t:1527272614025};\\\", \\\"{x:1538,y:355,t:1527272614038};\\\", \\\"{x:1521,y:442,t:1527272614054};\\\", \\\"{x:1507,y:542,t:1527272614071};\\\", \\\"{x:1491,y:642,t:1527272614088};\\\", \\\"{x:1474,y:735,t:1527272614104};\\\", \\\"{x:1460,y:803,t:1527272614121};\\\", \\\"{x:1437,y:879,t:1527272614138};\\\", \\\"{x:1428,y:907,t:1527272614154};\\\", \\\"{x:1425,y:931,t:1527272614171};\\\", \\\"{x:1422,y:957,t:1527272614188};\\\", \\\"{x:1423,y:977,t:1527272614204};\\\", \\\"{x:1428,y:991,t:1527272614221};\\\", \\\"{x:1434,y:1005,t:1527272614237};\\\", \\\"{x:1443,y:1018,t:1527272614254};\\\", \\\"{x:1453,y:1027,t:1527272614271};\\\", \\\"{x:1464,y:1033,t:1527272614287};\\\", \\\"{x:1473,y:1036,t:1527272614304};\\\", \\\"{x:1484,y:1037,t:1527272614321};\\\", \\\"{x:1499,y:1030,t:1527272614337};\\\", \\\"{x:1518,y:1016,t:1527272614355};\\\", \\\"{x:1534,y:1003,t:1527272614371};\\\", \\\"{x:1548,y:995,t:1527272614387};\\\", \\\"{x:1555,y:990,t:1527272614404};\\\", \\\"{x:1559,y:988,t:1527272614421};\\\", \\\"{x:1561,y:986,t:1527272614437};\\\", \\\"{x:1561,y:985,t:1527272614454};\\\", \\\"{x:1561,y:984,t:1527272614538};\\\", \\\"{x:1561,y:983,t:1527272614554};\\\", \\\"{x:1559,y:981,t:1527272614571};\\\", \\\"{x:1555,y:980,t:1527272614586};\\\", \\\"{x:1553,y:980,t:1527272614604};\\\", \\\"{x:1550,y:977,t:1527272614621};\\\", \\\"{x:1549,y:977,t:1527272614637};\\\", \\\"{x:1548,y:971,t:1527272614654};\\\", \\\"{x:1548,y:970,t:1527272614671};\\\", \\\"{x:1548,y:966,t:1527272614687};\\\", \\\"{x:1548,y:963,t:1527272614705};\\\", \\\"{x:1547,y:958,t:1527272614721};\\\", \\\"{x:1547,y:956,t:1527272614737};\\\", \\\"{x:1547,y:955,t:1527272615066};\\\", \\\"{x:1549,y:955,t:1527272615098};\\\", \\\"{x:1549,y:956,t:1527272615106};\\\", \\\"{x:1550,y:957,t:1527272615122};\\\", \\\"{x:1551,y:957,t:1527272615434};\\\", \\\"{x:1551,y:958,t:1527272615842};\\\", \\\"{x:1551,y:959,t:1527272615853};\\\", \\\"{x:1550,y:964,t:1527272615871};\\\", \\\"{x:1549,y:966,t:1527272615888};\\\", \\\"{x:1549,y:967,t:1527272615902};\\\", \\\"{x:1548,y:967,t:1527272615919};\\\", \\\"{x:1548,y:968,t:1527272615936};\\\", \\\"{x:1548,y:969,t:1527272616114};\\\", \\\"{x:1547,y:969,t:1527272616162};\\\", \\\"{x:1547,y:966,t:1527272616186};\\\", \\\"{x:1547,y:962,t:1527272616203};\\\", \\\"{x:1547,y:959,t:1527272616220};\\\", \\\"{x:1548,y:956,t:1527272616236};\\\", \\\"{x:1549,y:952,t:1527272616253};\\\", \\\"{x:1550,y:951,t:1527272616270};\\\", \\\"{x:1552,y:952,t:1527272616586};\\\", \\\"{x:1555,y:957,t:1527272616603};\\\", \\\"{x:1555,y:959,t:1527272616620};\\\", \\\"{x:1557,y:961,t:1527272616636};\\\", \\\"{x:1558,y:963,t:1527272616653};\\\", \\\"{x:1559,y:963,t:1527272616670};\\\", \\\"{x:1558,y:964,t:1527272616778};\\\", \\\"{x:1556,y:964,t:1527272616786};\\\", \\\"{x:1553,y:963,t:1527272616803};\\\", \\\"{x:1550,y:962,t:1527272616821};\\\", \\\"{x:1549,y:962,t:1527272616836};\\\", \\\"{x:1547,y:962,t:1527272616854};\\\", \\\"{x:1546,y:961,t:1527272617986};\\\", \\\"{x:1545,y:961,t:1527272619578};\\\", \\\"{x:1542,y:959,t:1527272619586};\\\", \\\"{x:1539,y:955,t:1527272619601};\\\", \\\"{x:1539,y:945,t:1527272619619};\\\", \\\"{x:1539,y:939,t:1527272619635};\\\", \\\"{x:1539,y:932,t:1527272619652};\\\", \\\"{x:1539,y:927,t:1527272619668};\\\", \\\"{x:1539,y:924,t:1527272619685};\\\", \\\"{x:1539,y:921,t:1527272619701};\\\", \\\"{x:1539,y:920,t:1527272619721};\\\", \\\"{x:1539,y:918,t:1527272619745};\\\", \\\"{x:1539,y:916,t:1527272619753};\\\", \\\"{x:1539,y:914,t:1527272619769};\\\", \\\"{x:1539,y:911,t:1527272619786};\\\", \\\"{x:1539,y:907,t:1527272619801};\\\", \\\"{x:1539,y:901,t:1527272619819};\\\", \\\"{x:1539,y:894,t:1527272619835};\\\", \\\"{x:1539,y:888,t:1527272619851};\\\", \\\"{x:1540,y:881,t:1527272619868};\\\", \\\"{x:1542,y:875,t:1527272619885};\\\", \\\"{x:1543,y:871,t:1527272619901};\\\", \\\"{x:1544,y:869,t:1527272619918};\\\", \\\"{x:1545,y:863,t:1527272619935};\\\", \\\"{x:1547,y:860,t:1527272619951};\\\", \\\"{x:1547,y:855,t:1527272619968};\\\", \\\"{x:1548,y:850,t:1527272619985};\\\", \\\"{x:1548,y:847,t:1527272620001};\\\", \\\"{x:1548,y:846,t:1527272620018};\\\", \\\"{x:1548,y:845,t:1527272620036};\\\", \\\"{x:1549,y:843,t:1527272620052};\\\", \\\"{x:1549,y:841,t:1527272620068};\\\", \\\"{x:1549,y:837,t:1527272620085};\\\", \\\"{x:1550,y:833,t:1527272620101};\\\", \\\"{x:1550,y:830,t:1527272620119};\\\", \\\"{x:1550,y:829,t:1527272620136};\\\", \\\"{x:1550,y:827,t:1527272620169};\\\", \\\"{x:1551,y:827,t:1527272622945};\\\", \\\"{x:1552,y:828,t:1527272622986};\\\", \\\"{x:1553,y:828,t:1527272623000};\\\", \\\"{x:1554,y:829,t:1527272623033};\\\", \\\"{x:1556,y:830,t:1527272625378};\\\", \\\"{x:1558,y:831,t:1527272625393};\\\", \\\"{x:1558,y:834,t:1527272625401};\\\", \\\"{x:1561,y:842,t:1527272625415};\\\", \\\"{x:1566,y:859,t:1527272625432};\\\", \\\"{x:1568,y:870,t:1527272625449};\\\", \\\"{x:1571,y:882,t:1527272625466};\\\", \\\"{x:1571,y:884,t:1527272625482};\\\", \\\"{x:1571,y:886,t:1527272625498};\\\", \\\"{x:1571,y:887,t:1527272625516};\\\", \\\"{x:1571,y:889,t:1527272625545};\\\", \\\"{x:1571,y:891,t:1527272625554};\\\", \\\"{x:1571,y:895,t:1527272625565};\\\", \\\"{x:1573,y:905,t:1527272625582};\\\", \\\"{x:1575,y:918,t:1527272625598};\\\", \\\"{x:1577,y:924,t:1527272625616};\\\", \\\"{x:1577,y:928,t:1527272625633};\\\", \\\"{x:1578,y:932,t:1527272625649};\\\", \\\"{x:1578,y:937,t:1527272625665};\\\", \\\"{x:1578,y:946,t:1527272625682};\\\", \\\"{x:1578,y:960,t:1527272625698};\\\", \\\"{x:1578,y:975,t:1527272625716};\\\", \\\"{x:1578,y:985,t:1527272625732};\\\", \\\"{x:1578,y:989,t:1527272625749};\\\", \\\"{x:1578,y:991,t:1527272625766};\\\", \\\"{x:1576,y:991,t:1527272625889};\\\", \\\"{x:1571,y:990,t:1527272625898};\\\", \\\"{x:1559,y:985,t:1527272625916};\\\", \\\"{x:1544,y:979,t:1527272625933};\\\", \\\"{x:1533,y:970,t:1527272625949};\\\", \\\"{x:1523,y:962,t:1527272625966};\\\", \\\"{x:1515,y:955,t:1527272625983};\\\", \\\"{x:1506,y:948,t:1527272625998};\\\", \\\"{x:1504,y:947,t:1527272626015};\\\", \\\"{x:1501,y:944,t:1527272626033};\\\", \\\"{x:1496,y:939,t:1527272626048};\\\", \\\"{x:1483,y:928,t:1527272626065};\\\", \\\"{x:1479,y:925,t:1527272626083};\\\", \\\"{x:1478,y:925,t:1527272626098};\\\", \\\"{x:1476,y:923,t:1527272626116};\\\", \\\"{x:1474,y:921,t:1527272626137};\\\", \\\"{x:1473,y:919,t:1527272626149};\\\", \\\"{x:1468,y:913,t:1527272626166};\\\", \\\"{x:1465,y:910,t:1527272626182};\\\", \\\"{x:1458,y:904,t:1527272626198};\\\", \\\"{x:1457,y:903,t:1527272626215};\\\", \\\"{x:1456,y:903,t:1527272626232};\\\", \\\"{x:1455,y:903,t:1527272626248};\\\", \\\"{x:1454,y:903,t:1527272626322};\\\", \\\"{x:1453,y:903,t:1527272626336};\\\", \\\"{x:1452,y:903,t:1527272626441};\\\", \\\"{x:1451,y:902,t:1527272626448};\\\", \\\"{x:1450,y:902,t:1527272626464};\\\", \\\"{x:1445,y:899,t:1527272626482};\\\", \\\"{x:1441,y:897,t:1527272626498};\\\", \\\"{x:1440,y:897,t:1527272626515};\\\", \\\"{x:1439,y:897,t:1527272626531};\\\", \\\"{x:1438,y:896,t:1527272626549};\\\", \\\"{x:1439,y:896,t:1527272626745};\\\", \\\"{x:1442,y:897,t:1527272626753};\\\", \\\"{x:1448,y:898,t:1527272626765};\\\", \\\"{x:1460,y:901,t:1527272626781};\\\", \\\"{x:1477,y:901,t:1527272626798};\\\", \\\"{x:1492,y:901,t:1527272626814};\\\", \\\"{x:1499,y:901,t:1527272626832};\\\", \\\"{x:1502,y:901,t:1527272626848};\\\", \\\"{x:1503,y:901,t:1527272626864};\\\", \\\"{x:1505,y:901,t:1527272626953};\\\", \\\"{x:1506,y:901,t:1527272626965};\\\", \\\"{x:1507,y:901,t:1527272626993};\\\", \\\"{x:1508,y:901,t:1527272627122};\\\", \\\"{x:1511,y:898,t:1527272627361};\\\", \\\"{x:1511,y:897,t:1527272627369};\\\", \\\"{x:1511,y:895,t:1527272627385};\\\", \\\"{x:1511,y:894,t:1527272627398};\\\", \\\"{x:1511,y:893,t:1527272627417};\\\", \\\"{x:1511,y:892,t:1527272627432};\\\", \\\"{x:1511,y:891,t:1527272627449};\\\", \\\"{x:1512,y:891,t:1527272627498};\\\", \\\"{x:1514,y:891,t:1527272627690};\\\", \\\"{x:1515,y:891,t:1527272627698};\\\", \\\"{x:1520,y:891,t:1527272627714};\\\", \\\"{x:1524,y:892,t:1527272627732};\\\", \\\"{x:1531,y:895,t:1527272627748};\\\", \\\"{x:1536,y:896,t:1527272627765};\\\", \\\"{x:1537,y:897,t:1527272627782};\\\", \\\"{x:1539,y:897,t:1527272627857};\\\", \\\"{x:1540,y:898,t:1527272627865};\\\", \\\"{x:1540,y:899,t:1527272627889};\\\", \\\"{x:1542,y:899,t:1527272627954};\\\", \\\"{x:1541,y:899,t:1527272628258};\\\", \\\"{x:1539,y:899,t:1527272628354};\\\", \\\"{x:1536,y:898,t:1527272628377};\\\", \\\"{x:1533,y:897,t:1527272628385};\\\", \\\"{x:1530,y:897,t:1527272628397};\\\", \\\"{x:1525,y:894,t:1527272628414};\\\", \\\"{x:1523,y:894,t:1527272628430};\\\", \\\"{x:1522,y:893,t:1527272628447};\\\", \\\"{x:1521,y:893,t:1527272628464};\\\", \\\"{x:1518,y:893,t:1527272628481};\\\", \\\"{x:1514,y:893,t:1527272628497};\\\", \\\"{x:1509,y:893,t:1527272628514};\\\", \\\"{x:1506,y:892,t:1527272628530};\\\", \\\"{x:1505,y:892,t:1527272628547};\\\", \\\"{x:1506,y:892,t:1527272628889};\\\", \\\"{x:1507,y:892,t:1527272628921};\\\", \\\"{x:1509,y:892,t:1527272628937};\\\", \\\"{x:1511,y:893,t:1527272628953};\\\", \\\"{x:1514,y:894,t:1527272628964};\\\", \\\"{x:1518,y:895,t:1527272628981};\\\", \\\"{x:1523,y:896,t:1527272628998};\\\", \\\"{x:1526,y:897,t:1527272629014};\\\", \\\"{x:1529,y:897,t:1527272629031};\\\", \\\"{x:1530,y:897,t:1527272629048};\\\", \\\"{x:1531,y:897,t:1527272629084};\\\", \\\"{x:1532,y:897,t:1527272629240};\\\", \\\"{x:1533,y:898,t:1527272629256};\\\", \\\"{x:1534,y:898,t:1527272629265};\\\", \\\"{x:1537,y:898,t:1527272629281};\\\", \\\"{x:1540,y:898,t:1527272629296};\\\", \\\"{x:1548,y:896,t:1527272629314};\\\", \\\"{x:1553,y:895,t:1527272629331};\\\", \\\"{x:1554,y:894,t:1527272629346};\\\", \\\"{x:1555,y:894,t:1527272629410};\\\", \\\"{x:1555,y:892,t:1527272629793};\\\", \\\"{x:1555,y:886,t:1527272629801};\\\", \\\"{x:1554,y:876,t:1527272629813};\\\", \\\"{x:1553,y:869,t:1527272629831};\\\", \\\"{x:1552,y:863,t:1527272629847};\\\", \\\"{x:1552,y:860,t:1527272629863};\\\", \\\"{x:1552,y:854,t:1527272629882};\\\", \\\"{x:1551,y:852,t:1527272629897};\\\", \\\"{x:1551,y:851,t:1527272629921};\\\", \\\"{x:1549,y:849,t:1527272630105};\\\", \\\"{x:1548,y:846,t:1527272630113};\\\", \\\"{x:1546,y:844,t:1527272630130};\\\", \\\"{x:1545,y:841,t:1527272630146};\\\", \\\"{x:1544,y:839,t:1527272630163};\\\", \\\"{x:1542,y:837,t:1527272630179};\\\", \\\"{x:1542,y:836,t:1527272630196};\\\", \\\"{x:1542,y:835,t:1527272630601};\\\", \\\"{x:1542,y:834,t:1527272630616};\\\", \\\"{x:1542,y:832,t:1527272630629};\\\", \\\"{x:1543,y:832,t:1527272630646};\\\", \\\"{x:1545,y:830,t:1527272630663};\\\", \\\"{x:1546,y:829,t:1527272630678};\\\", \\\"{x:1546,y:828,t:1527272633137};\\\", \\\"{x:1547,y:828,t:1527272633154};\\\", \\\"{x:1549,y:828,t:1527272633169};\\\", \\\"{x:1548,y:828,t:1527272633337};\\\", \\\"{x:1540,y:828,t:1527272633346};\\\", \\\"{x:1513,y:827,t:1527272633362};\\\", \\\"{x:1477,y:818,t:1527272633379};\\\", \\\"{x:1450,y:811,t:1527272633395};\\\", \\\"{x:1431,y:803,t:1527272633412};\\\", \\\"{x:1423,y:798,t:1527272633429};\\\", \\\"{x:1421,y:797,t:1527272633445};\\\", \\\"{x:1420,y:796,t:1527272633601};\\\", \\\"{x:1420,y:794,t:1527272633612};\\\", \\\"{x:1421,y:789,t:1527272633628};\\\", \\\"{x:1422,y:784,t:1527272633644};\\\", \\\"{x:1425,y:778,t:1527272633662};\\\", \\\"{x:1425,y:771,t:1527272633679};\\\", \\\"{x:1426,y:766,t:1527272633695};\\\", \\\"{x:1426,y:763,t:1527272633712};\\\", \\\"{x:1426,y:762,t:1527272633729};\\\", \\\"{x:1425,y:761,t:1527272633833};\\\", \\\"{x:1425,y:760,t:1527272633845};\\\", \\\"{x:1423,y:759,t:1527272633861};\\\", \\\"{x:1421,y:758,t:1527272633878};\\\", \\\"{x:1419,y:757,t:1527272633895};\\\", \\\"{x:1418,y:756,t:1527272633912};\\\", \\\"{x:1417,y:756,t:1527272633929};\\\", \\\"{x:1417,y:757,t:1527272634225};\\\", \\\"{x:1417,y:760,t:1527272634233};\\\", \\\"{x:1417,y:762,t:1527272634245};\\\", \\\"{x:1419,y:766,t:1527272634262};\\\", \\\"{x:1419,y:767,t:1527272634278};\\\", \\\"{x:1419,y:768,t:1527272634295};\\\", \\\"{x:1421,y:769,t:1527272634560};\\\", \\\"{x:1424,y:770,t:1527272634577};\\\", \\\"{x:1429,y:771,t:1527272634594};\\\", \\\"{x:1441,y:771,t:1527272634611};\\\", \\\"{x:1447,y:771,t:1527272634628};\\\", \\\"{x:1449,y:771,t:1527272634645};\\\", \\\"{x:1450,y:771,t:1527272634661};\\\", \\\"{x:1451,y:772,t:1527272634678};\\\", \\\"{x:1453,y:772,t:1527272634695};\\\", \\\"{x:1455,y:772,t:1527272634711};\\\", \\\"{x:1460,y:772,t:1527272634728};\\\", \\\"{x:1467,y:775,t:1527272634745};\\\", \\\"{x:1471,y:775,t:1527272634761};\\\", \\\"{x:1476,y:775,t:1527272634778};\\\", \\\"{x:1480,y:774,t:1527272634795};\\\", \\\"{x:1482,y:774,t:1527272634811};\\\", \\\"{x:1482,y:773,t:1527272634828};\\\", \\\"{x:1483,y:773,t:1527272634873};\\\", \\\"{x:1484,y:773,t:1527272634897};\\\", \\\"{x:1485,y:772,t:1527272634911};\\\", \\\"{x:1485,y:771,t:1527272634928};\\\", \\\"{x:1485,y:769,t:1527272634978};\\\", \\\"{x:1485,y:768,t:1527272634995};\\\", \\\"{x:1485,y:766,t:1527272635011};\\\", \\\"{x:1485,y:765,t:1527272635057};\\\", \\\"{x:1484,y:764,t:1527272635594};\\\", \\\"{x:1483,y:764,t:1527272635785};\\\", \\\"{x:1484,y:764,t:1527272637713};\\\", \\\"{x:1485,y:764,t:1527272637753};\\\", \\\"{x:1487,y:764,t:1527272637777};\\\", \\\"{x:1488,y:765,t:1527272637793};\\\", \\\"{x:1489,y:766,t:1527272637825};\\\", \\\"{x:1491,y:766,t:1527272637841};\\\", \\\"{x:1494,y:768,t:1527272637858};\\\", \\\"{x:1496,y:768,t:1527272637865};\\\", \\\"{x:1498,y:768,t:1527272637877};\\\", \\\"{x:1500,y:769,t:1527272637893};\\\", \\\"{x:1501,y:770,t:1527272637938};\\\", \\\"{x:1502,y:770,t:1527272638033};\\\", \\\"{x:1505,y:770,t:1527272638050};\\\", \\\"{x:1507,y:770,t:1527272638060};\\\", \\\"{x:1511,y:768,t:1527272638077};\\\", \\\"{x:1513,y:768,t:1527272638096};\\\", \\\"{x:1515,y:767,t:1527272638109};\\\", \\\"{x:1518,y:766,t:1527272638126};\\\", \\\"{x:1521,y:765,t:1527272638143};\\\", \\\"{x:1524,y:763,t:1527272638160};\\\", \\\"{x:1526,y:763,t:1527272638176};\\\", \\\"{x:1527,y:762,t:1527272638193};\\\", \\\"{x:1527,y:761,t:1527272638338};\\\", \\\"{x:1526,y:760,t:1527272638345};\\\", \\\"{x:1524,y:760,t:1527272638370};\\\", \\\"{x:1523,y:760,t:1527272638537};\\\", \\\"{x:1522,y:760,t:1527272638602};\\\", \\\"{x:1521,y:760,t:1527272638625};\\\", \\\"{x:1520,y:760,t:1527272638642};\\\", \\\"{x:1519,y:760,t:1527272638659};\\\", \\\"{x:1518,y:760,t:1527272638675};\\\", \\\"{x:1515,y:761,t:1527272638693};\\\", \\\"{x:1514,y:762,t:1527272638729};\\\", \\\"{x:1515,y:762,t:1527272643273};\\\", \\\"{x:1516,y:762,t:1527272643296};\\\", \\\"{x:1517,y:763,t:1527272643307};\\\", \\\"{x:1520,y:764,t:1527272643324};\\\", \\\"{x:1521,y:765,t:1527272643362};\\\", \\\"{x:1522,y:765,t:1527272643424};\\\", \\\"{x:1524,y:765,t:1527272643441};\\\", \\\"{x:1525,y:765,t:1527272643456};\\\", \\\"{x:1526,y:765,t:1527272643473};\\\", \\\"{x:1527,y:765,t:1527272643496};\\\", \\\"{x:1529,y:765,t:1527272643506};\\\", \\\"{x:1532,y:764,t:1527272643523};\\\", \\\"{x:1533,y:764,t:1527272643540};\\\", \\\"{x:1535,y:763,t:1527272643557};\\\", \\\"{x:1537,y:762,t:1527272643601};\\\", \\\"{x:1538,y:762,t:1527272643618};\\\", \\\"{x:1538,y:761,t:1527272643625};\\\", \\\"{x:1539,y:761,t:1527272643658};\\\", \\\"{x:1540,y:761,t:1527272643673};\\\", \\\"{x:1542,y:760,t:1527272643690};\\\", \\\"{x:1544,y:760,t:1527272643707};\\\", \\\"{x:1546,y:759,t:1527272643724};\\\", \\\"{x:1547,y:759,t:1527272643778};\\\", \\\"{x:1548,y:759,t:1527272643801};\\\", \\\"{x:1549,y:759,t:1527272643817};\\\", \\\"{x:1550,y:759,t:1527272643833};\\\", \\\"{x:1550,y:757,t:1527272646474};\\\", \\\"{x:1487,y:714,t:1527272646489};\\\", \\\"{x:1375,y:646,t:1527272646505};\\\", \\\"{x:1249,y:582,t:1527272646523};\\\", \\\"{x:1154,y:529,t:1527272646540};\\\", \\\"{x:1095,y:501,t:1527272646555};\\\", \\\"{x:1075,y:497,t:1527272646573};\\\", \\\"{x:1065,y:496,t:1527272646590};\\\", \\\"{x:1051,y:497,t:1527272646606};\\\", \\\"{x:1029,y:500,t:1527272646622};\\\", \\\"{x:991,y:500,t:1527272646639};\\\", \\\"{x:939,y:496,t:1527272646656};\\\", \\\"{x:888,y:488,t:1527272646672};\\\", \\\"{x:824,y:485,t:1527272646689};\\\", \\\"{x:765,y:484,t:1527272646704};\\\", \\\"{x:734,y:484,t:1527272646718};\\\", \\\"{x:669,y:496,t:1527272646736};\\\", \\\"{x:616,y:509,t:1527272646752};\\\", \\\"{x:546,y:523,t:1527272646774};\\\", \\\"{x:517,y:523,t:1527272646790};\\\", \\\"{x:488,y:523,t:1527272646807};\\\", \\\"{x:464,y:523,t:1527272646823};\\\", \\\"{x:427,y:523,t:1527272646841};\\\", \\\"{x:405,y:523,t:1527272646857};\\\", \\\"{x:388,y:524,t:1527272646874};\\\", \\\"{x:372,y:527,t:1527272646892};\\\", \\\"{x:358,y:530,t:1527272646908};\\\", \\\"{x:351,y:532,t:1527272646924};\\\", \\\"{x:343,y:532,t:1527272646941};\\\", \\\"{x:338,y:532,t:1527272646957};\\\", \\\"{x:329,y:533,t:1527272646974};\\\", \\\"{x:326,y:533,t:1527272646991};\\\", \\\"{x:325,y:533,t:1527272647089};\\\", \\\"{x:324,y:533,t:1527272647137};\\\", \\\"{x:323,y:533,t:1527272647145};\\\", \\\"{x:320,y:533,t:1527272647159};\\\", \\\"{x:319,y:533,t:1527272647174};\\\", \\\"{x:314,y:533,t:1527272647283};\\\", \\\"{x:300,y:533,t:1527272647292};\\\", \\\"{x:254,y:530,t:1527272647310};\\\", \\\"{x:197,y:525,t:1527272647323};\\\", \\\"{x:155,y:520,t:1527272647341};\\\", \\\"{x:127,y:520,t:1527272647357};\\\", \\\"{x:105,y:523,t:1527272647374};\\\", \\\"{x:90,y:528,t:1527272647391};\\\", \\\"{x:88,y:529,t:1527272647408};\\\", \\\"{x:86,y:530,t:1527272647424};\\\", \\\"{x:86,y:532,t:1527272647521};\\\", \\\"{x:90,y:533,t:1527272647528};\\\", \\\"{x:97,y:536,t:1527272647541};\\\", \\\"{x:113,y:541,t:1527272647558};\\\", \\\"{x:130,y:545,t:1527272647575};\\\", \\\"{x:148,y:551,t:1527272647591};\\\", \\\"{x:157,y:554,t:1527272647608};\\\", \\\"{x:167,y:556,t:1527272647626};\\\", \\\"{x:168,y:557,t:1527272647641};\\\", \\\"{x:168,y:558,t:1527272647658};\\\", \\\"{x:167,y:558,t:1527272647865};\\\", \\\"{x:166,y:558,t:1527272647883};\\\", \\\"{x:166,y:557,t:1527272647892};\\\", \\\"{x:165,y:556,t:1527272648026};\\\", \\\"{x:163,y:555,t:1527272648050};\\\", \\\"{x:162,y:554,t:1527272648153};\\\", \\\"{x:162,y:553,t:1527272648257};\\\", \\\"{x:164,y:553,t:1527272648706};\\\", \\\"{x:175,y:555,t:1527272648713};\\\", \\\"{x:190,y:563,t:1527272648728};\\\", \\\"{x:248,y:588,t:1527272648743};\\\", \\\"{x:340,y:632,t:1527272648760};\\\", \\\"{x:437,y:681,t:1527272648775};\\\", \\\"{x:546,y:727,t:1527272648792};\\\", \\\"{x:591,y:747,t:1527272648810};\\\", \\\"{x:619,y:756,t:1527272648825};\\\", \\\"{x:630,y:759,t:1527272648842};\\\", \\\"{x:629,y:759,t:1527272648888};\\\", \\\"{x:627,y:758,t:1527272648912};\\\", \\\"{x:627,y:757,t:1527272648929};\\\", \\\"{x:625,y:757,t:1527272648942};\\\", \\\"{x:621,y:756,t:1527272648959};\\\", \\\"{x:612,y:751,t:1527272648976};\\\", \\\"{x:598,y:738,t:1527272648992};\\\", \\\"{x:542,y:691,t:1527272649009};\\\", \\\"{x:502,y:658,t:1527272649027};\\\", \\\"{x:454,y:625,t:1527272649043};\\\", \\\"{x:403,y:599,t:1527272649060};\\\", \\\"{x:357,y:582,t:1527272649076};\\\", \\\"{x:313,y:564,t:1527272649093};\\\", \\\"{x:260,y:548,t:1527272649110};\\\", \\\"{x:225,y:541,t:1527272649126};\\\", \\\"{x:193,y:541,t:1527272649142};\\\", \\\"{x:173,y:541,t:1527272649160};\\\", \\\"{x:146,y:541,t:1527272649177};\\\", \\\"{x:121,y:541,t:1527272649193};\\\", \\\"{x:110,y:541,t:1527272649209};\\\", \\\"{x:109,y:541,t:1527272649241};\\\", \\\"{x:110,y:543,t:1527272649256};\\\", \\\"{x:111,y:543,t:1527272649273};\\\", \\\"{x:112,y:544,t:1527272649289};\\\", \\\"{x:113,y:544,t:1527272649297};\\\", \\\"{x:115,y:545,t:1527272649313};\\\", \\\"{x:116,y:545,t:1527272649330};\\\", \\\"{x:117,y:545,t:1527272649343};\\\", \\\"{x:121,y:546,t:1527272649360};\\\", \\\"{x:123,y:547,t:1527272649376};\\\", \\\"{x:126,y:547,t:1527272649393};\\\", \\\"{x:128,y:548,t:1527272649409};\\\", \\\"{x:134,y:548,t:1527272649426};\\\", \\\"{x:141,y:548,t:1527272649443};\\\", \\\"{x:151,y:546,t:1527272649460};\\\", \\\"{x:154,y:546,t:1527272649476};\\\", \\\"{x:155,y:546,t:1527272649493};\\\", \\\"{x:157,y:546,t:1527272649513};\\\", \\\"{x:158,y:545,t:1527272649527};\\\", \\\"{x:162,y:543,t:1527272649543};\\\", \\\"{x:168,y:540,t:1527272649560};\\\", \\\"{x:171,y:538,t:1527272649577};\\\", \\\"{x:173,y:537,t:1527272649594};\\\", \\\"{x:173,y:536,t:1527272649611};\\\", \\\"{x:173,y:535,t:1527272649705};\\\", \\\"{x:172,y:535,t:1527272649713};\\\", \\\"{x:170,y:534,t:1527272649727};\\\", \\\"{x:167,y:533,t:1527272649745};\\\", \\\"{x:165,y:533,t:1527272649761};\\\", \\\"{x:164,y:533,t:1527272649779};\\\", \\\"{x:163,y:533,t:1527272649795};\\\", \\\"{x:165,y:533,t:1527272650144};\\\", \\\"{x:204,y:540,t:1527272650161};\\\", \\\"{x:299,y:556,t:1527272650177};\\\", \\\"{x:400,y:592,t:1527272650193};\\\", \\\"{x:468,y:621,t:1527272650210};\\\", \\\"{x:509,y:644,t:1527272650231};\\\", \\\"{x:543,y:662,t:1527272650243};\\\", \\\"{x:555,y:669,t:1527272650260};\\\", \\\"{x:565,y:676,t:1527272650277};\\\", \\\"{x:571,y:682,t:1527272650293};\\\", \\\"{x:577,y:693,t:1527272650310};\\\", \\\"{x:586,y:708,t:1527272650327};\\\", \\\"{x:591,y:723,t:1527272650343};\\\", \\\"{x:595,y:745,t:1527272650360};\\\", \\\"{x:595,y:753,t:1527272650376};\\\", \\\"{x:595,y:757,t:1527272650393};\\\", \\\"{x:594,y:759,t:1527272650424};\\\", \\\"{x:592,y:760,t:1527272650432};\\\", \\\"{x:590,y:760,t:1527272650448};\\\", \\\"{x:587,y:760,t:1527272650460};\\\", \\\"{x:581,y:760,t:1527272650477};\\\", \\\"{x:575,y:763,t:1527272650493};\\\", \\\"{x:570,y:765,t:1527272650510};\\\", \\\"{x:563,y:767,t:1527272650527};\\\", \\\"{x:557,y:768,t:1527272650543};\\\", \\\"{x:553,y:768,t:1527272650561};\\\", \\\"{x:552,y:768,t:1527272650657};\\\", \\\"{x:550,y:768,t:1527272650664};\\\", \\\"{x:544,y:762,t:1527272650677};\\\", \\\"{x:533,y:740,t:1527272650694};\\\", \\\"{x:528,y:731,t:1527272650710};\\\", \\\"{x:528,y:730,t:1527272650727};\\\", \\\"{x:527,y:728,t:1527272650744};\\\", \\\"{x:526,y:726,t:1527272650761};\\\", \\\"{x:524,y:726,t:1527272651096};\\\", \\\"{x:525,y:725,t:1527272651160};\\\", \\\"{x:549,y:723,t:1527272651177};\\\", \\\"{x:614,y:721,t:1527272651194};\\\", \\\"{x:736,y:721,t:1527272651211};\\\", \\\"{x:888,y:721,t:1527272651227};\\\", \\\"{x:1057,y:749,t:1527272651244};\\\", \\\"{x:1253,y:797,t:1527272651261};\\\", \\\"{x:1460,y:858,t:1527272651277};\\\", \\\"{x:1633,y:929,t:1527272651295};\\\", \\\"{x:1784,y:993,t:1527272651311};\\\", \\\"{x:1876,y:1035,t:1527272651327};\\\", \\\"{x:1919,y:1055,t:1527272651345};\\\", \\\"{x:1919,y:1054,t:1527272651521};\\\", \\\"{x:1918,y:1047,t:1527272651528};\\\", \\\"{x:1918,y:1040,t:1527272651545};\\\", \\\"{x:1912,y:1021,t:1527272651561};\\\", \\\"{x:1908,y:1000,t:1527272651578};\\\", \\\"{x:1904,y:976,t:1527272651594};\\\", \\\"{x:1896,y:935,t:1527272651611};\\\", \\\"{x:1890,y:877,t:1527272651628};\\\", \\\"{x:1876,y:827,t:1527272651644};\\\", \\\"{x:1863,y:796,t:1527272651661};\\\", \\\"{x:1846,y:771,t:1527272651678};\\\", \\\"{x:1825,y:745,t:1527272651694};\\\", \\\"{x:1800,y:709,t:1527272651711};\\\", \\\"{x:1745,y:648,t:1527272651729};\\\", \\\"{x:1686,y:608,t:1527272651745};\\\", \\\"{x:1611,y:576,t:1527272651761};\\\", \\\"{x:1523,y:549,t:1527272651779};\\\", \\\"{x:1438,y:545,t:1527272651795};\\\", \\\"{x:1385,y:545,t:1527272651811};\\\", \\\"{x:1332,y:545,t:1527272651829};\\\", \\\"{x:1292,y:559,t:1527272651846};\\\", \\\"{x:1273,y:573,t:1527272651862};\\\", \\\"{x:1260,y:595,t:1527272651878};\\\", \\\"{x:1242,y:635,t:1527272651895};\\\", \\\"{x:1229,y:680,t:1527272651911};\\\", \\\"{x:1214,y:744,t:1527272651928};\\\", \\\"{x:1213,y:770,t:1527272651944};\\\", \\\"{x:1213,y:785,t:1527272651961};\\\", \\\"{x:1213,y:786,t:1527272651978};\\\", \\\"{x:1212,y:786,t:1527272652000};\\\", \\\"{x:1210,y:786,t:1527272652016};\\\", \\\"{x:1205,y:786,t:1527272652028};\\\", \\\"{x:1187,y:775,t:1527272652046};\\\", \\\"{x:1170,y:750,t:1527272652078};\\\", \\\"{x:1168,y:744,t:1527272652095};\\\", \\\"{x:1162,y:722,t:1527272652112};\\\", \\\"{x:1150,y:699,t:1527272652128};\\\", \\\"{x:1127,y:661,t:1527272652145};\\\" ] }, { \\\"rt\\\": 32173, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1220966, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-02 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1021,y:692,t:1527272652434};\\\", \\\"{x:1022,y:692,t:1527272652841};\\\", \\\"{x:1031,y:695,t:1527272652849};\\\", \\\"{x:1046,y:698,t:1527272652862};\\\", \\\"{x:1092,y:700,t:1527272652879};\\\", \\\"{x:1105,y:698,t:1527272652896};\\\", \\\"{x:1122,y:687,t:1527272652913};\\\", \\\"{x:1149,y:656,t:1527272652929};\\\", \\\"{x:1099,y:244,t:1527272653019};\\\", \\\"{x:1051,y:209,t:1527272653030};\\\", \\\"{x:913,y:141,t:1527272653045};\\\", \\\"{x:785,y:98,t:1527272653062};\\\", \\\"{x:676,y:76,t:1527272653079};\\\", \\\"{x:590,y:66,t:1527272653095};\\\", \\\"{x:479,y:66,t:1527272653112};\\\", \\\"{x:417,y:66,t:1527272653129};\\\", \\\"{x:381,y:69,t:1527272653145};\\\", \\\"{x:361,y:77,t:1527272653162};\\\", \\\"{x:349,y:91,t:1527272653180};\\\", \\\"{x:340,y:112,t:1527272653196};\\\", \\\"{x:331,y:142,t:1527272653212};\\\", \\\"{x:323,y:170,t:1527272653229};\\\", \\\"{x:320,y:196,t:1527272653245};\\\", \\\"{x:320,y:238,t:1527272653262};\\\", \\\"{x:320,y:297,t:1527272653279};\\\", \\\"{x:336,y:373,t:1527272653297};\\\", \\\"{x:345,y:398,t:1527272653313};\\\", \\\"{x:348,y:408,t:1527272653329};\\\", \\\"{x:349,y:409,t:1527272653346};\\\", \\\"{x:350,y:411,t:1527272653436};\\\", \\\"{x:354,y:412,t:1527272653446};\\\", \\\"{x:362,y:418,t:1527272653462};\\\", \\\"{x:372,y:431,t:1527272653479};\\\", \\\"{x:377,y:437,t:1527272653496};\\\", \\\"{x:377,y:438,t:1527272653561};\\\", \\\"{x:378,y:438,t:1527272653568};\\\", \\\"{x:381,y:439,t:1527272653579};\\\", \\\"{x:386,y:442,t:1527272653596};\\\", \\\"{x:391,y:445,t:1527272653612};\\\", \\\"{x:394,y:446,t:1527272653630};\\\", \\\"{x:394,y:447,t:1527272653647};\\\", \\\"{x:395,y:446,t:1527272653680};\\\", \\\"{x:398,y:446,t:1527272653696};\\\", \\\"{x:407,y:446,t:1527272653712};\\\", \\\"{x:423,y:446,t:1527272653729};\\\", \\\"{x:438,y:446,t:1527272653746};\\\", \\\"{x:453,y:446,t:1527272653763};\\\", \\\"{x:473,y:450,t:1527272653780};\\\", \\\"{x:491,y:456,t:1527272653796};\\\", \\\"{x:500,y:459,t:1527272653814};\\\", \\\"{x:503,y:459,t:1527272653829};\\\", \\\"{x:504,y:459,t:1527272653905};\\\", \\\"{x:506,y:460,t:1527272653913};\\\", \\\"{x:514,y:460,t:1527272653930};\\\", \\\"{x:524,y:460,t:1527272653946};\\\", \\\"{x:532,y:460,t:1527272653964};\\\", \\\"{x:537,y:460,t:1527272653979};\\\", \\\"{x:541,y:457,t:1527272653997};\\\", \\\"{x:545,y:451,t:1527272654013};\\\", \\\"{x:545,y:448,t:1527272654030};\\\", \\\"{x:547,y:446,t:1527272654047};\\\", \\\"{x:547,y:445,t:1527272654113};\\\", \\\"{x:549,y:443,t:1527272654145};\\\", \\\"{x:550,y:443,t:1527272654169};\\\", \\\"{x:550,y:441,t:1527272654192};\\\", \\\"{x:550,y:440,t:1527272654201};\\\", \\\"{x:550,y:439,t:1527272654213};\\\", \\\"{x:551,y:436,t:1527272654231};\\\", \\\"{x:551,y:428,t:1527272654246};\\\", \\\"{x:551,y:426,t:1527272654263};\\\", \\\"{x:550,y:425,t:1527272654433};\\\", \\\"{x:541,y:425,t:1527272654446};\\\", \\\"{x:527,y:436,t:1527272654464};\\\", \\\"{x:522,y:440,t:1527272654480};\\\", \\\"{x:521,y:440,t:1527272654513};\\\", \\\"{x:521,y:442,t:1527272654531};\\\", \\\"{x:521,y:446,t:1527272654546};\\\", \\\"{x:520,y:447,t:1527272654563};\\\", \\\"{x:520,y:448,t:1527272654657};\\\", \\\"{x:517,y:451,t:1527272654665};\\\", \\\"{x:511,y:460,t:1527272654681};\\\", \\\"{x:507,y:467,t:1527272654696};\\\", \\\"{x:504,y:470,t:1527272654714};\\\", \\\"{x:500,y:476,t:1527272654731};\\\", \\\"{x:497,y:483,t:1527272654747};\\\", \\\"{x:496,y:484,t:1527272654764};\\\", \\\"{x:496,y:485,t:1527272654781};\\\", \\\"{x:495,y:486,t:1527272654865};\\\", \\\"{x:491,y:486,t:1527272654881};\\\", \\\"{x:488,y:486,t:1527272654897};\\\", \\\"{x:487,y:486,t:1527272655001};\\\", \\\"{x:484,y:486,t:1527272655013};\\\", \\\"{x:480,y:484,t:1527272655031};\\\", \\\"{x:475,y:484,t:1527272655048};\\\", \\\"{x:469,y:484,t:1527272655064};\\\", \\\"{x:466,y:484,t:1527272655081};\\\", \\\"{x:463,y:483,t:1527272655097};\\\", \\\"{x:457,y:482,t:1527272655114};\\\", \\\"{x:450,y:482,t:1527272655131};\\\", \\\"{x:446,y:482,t:1527272655147};\\\", \\\"{x:442,y:482,t:1527272655164};\\\", \\\"{x:436,y:482,t:1527272655180};\\\", \\\"{x:433,y:482,t:1527272655197};\\\", \\\"{x:431,y:482,t:1527272655215};\\\", \\\"{x:429,y:482,t:1527272655231};\\\", \\\"{x:428,y:481,t:1527272655248};\\\", \\\"{x:426,y:480,t:1527272655273};\\\", \\\"{x:425,y:480,t:1527272655297};\\\", \\\"{x:424,y:480,t:1527272655321};\\\", \\\"{x:423,y:479,t:1527272655330};\\\", \\\"{x:421,y:477,t:1527272655347};\\\", \\\"{x:420,y:474,t:1527272655365};\\\", \\\"{x:419,y:472,t:1527272655380};\\\", \\\"{x:419,y:471,t:1527272655409};\\\", \\\"{x:419,y:470,t:1527272655425};\\\", \\\"{x:425,y:469,t:1527272655432};\\\", \\\"{x:431,y:467,t:1527272655447};\\\", \\\"{x:446,y:467,t:1527272655465};\\\", \\\"{x:453,y:467,t:1527272655480};\\\", \\\"{x:462,y:469,t:1527272655497};\\\", \\\"{x:466,y:471,t:1527272655514};\\\", \\\"{x:467,y:471,t:1527272655530};\\\", \\\"{x:468,y:472,t:1527272655547};\\\", \\\"{x:469,y:472,t:1527272655592};\\\", \\\"{x:470,y:472,t:1527272655600};\\\", \\\"{x:474,y:472,t:1527272655614};\\\", \\\"{x:477,y:472,t:1527272655630};\\\", \\\"{x:486,y:474,t:1527272655648};\\\", \\\"{x:503,y:476,t:1527272655665};\\\", \\\"{x:505,y:476,t:1527272655681};\\\", \\\"{x:503,y:476,t:1527272655745};\\\", \\\"{x:500,y:475,t:1527272655753};\\\", \\\"{x:496,y:473,t:1527272655765};\\\", \\\"{x:495,y:473,t:1527272655858};\\\", \\\"{x:498,y:471,t:1527272655969};\\\", \\\"{x:500,y:471,t:1527272655982};\\\", \\\"{x:501,y:471,t:1527272655998};\\\", \\\"{x:503,y:469,t:1527272656014};\\\", \\\"{x:504,y:468,t:1527272656032};\\\", \\\"{x:505,y:467,t:1527272656048};\\\", \\\"{x:507,y:467,t:1527272656610};\\\", \\\"{x:512,y:467,t:1527272656617};\\\", \\\"{x:521,y:467,t:1527272656632};\\\", \\\"{x:547,y:470,t:1527272656649};\\\", \\\"{x:561,y:476,t:1527272656665};\\\", \\\"{x:567,y:480,t:1527272656682};\\\", \\\"{x:571,y:482,t:1527272656699};\\\", \\\"{x:572,y:482,t:1527272656715};\\\", \\\"{x:574,y:482,t:1527272656731};\\\", \\\"{x:581,y:484,t:1527272656749};\\\", \\\"{x:596,y:488,t:1527272656766};\\\", \\\"{x:615,y:495,t:1527272656782};\\\", \\\"{x:645,y:504,t:1527272656800};\\\", \\\"{x:673,y:512,t:1527272656815};\\\", \\\"{x:709,y:523,t:1527272656831};\\\", \\\"{x:776,y:541,t:1527272656849};\\\", \\\"{x:840,y:551,t:1527272656866};\\\", \\\"{x:918,y:574,t:1527272656883};\\\", \\\"{x:996,y:596,t:1527272656898};\\\", \\\"{x:1065,y:629,t:1527272656915};\\\", \\\"{x:1124,y:656,t:1527272656932};\\\", \\\"{x:1162,y:678,t:1527272656949};\\\", \\\"{x:1187,y:695,t:1527272656965};\\\", \\\"{x:1209,y:709,t:1527272656982};\\\", \\\"{x:1232,y:719,t:1527272656998};\\\", \\\"{x:1254,y:725,t:1527272657016};\\\", \\\"{x:1280,y:734,t:1527272657032};\\\", \\\"{x:1289,y:739,t:1527272657050};\\\", \\\"{x:1293,y:740,t:1527272657066};\\\", \\\"{x:1294,y:742,t:1527272657082};\\\", \\\"{x:1295,y:742,t:1527272657100};\\\", \\\"{x:1295,y:743,t:1527272657138};\\\", \\\"{x:1296,y:743,t:1527272657150};\\\", \\\"{x:1297,y:744,t:1527272657193};\\\", \\\"{x:1296,y:744,t:1527272657274};\\\", \\\"{x:1293,y:744,t:1527272657289};\\\", \\\"{x:1292,y:744,t:1527272657300};\\\", \\\"{x:1283,y:744,t:1527272657316};\\\", \\\"{x:1265,y:741,t:1527272657333};\\\", \\\"{x:1238,y:730,t:1527272657350};\\\", \\\"{x:1188,y:708,t:1527272657366};\\\", \\\"{x:1105,y:671,t:1527272657382};\\\", \\\"{x:1015,y:614,t:1527272657400};\\\", \\\"{x:863,y:539,t:1527272657418};\\\", \\\"{x:774,y:514,t:1527272657432};\\\", \\\"{x:688,y:500,t:1527272657450};\\\", \\\"{x:607,y:487,t:1527272657465};\\\", \\\"{x:549,y:482,t:1527272657483};\\\", \\\"{x:523,y:480,t:1527272657499};\\\", \\\"{x:515,y:480,t:1527272657516};\\\", \\\"{x:514,y:480,t:1527272657532};\\\", \\\"{x:512,y:480,t:1527272657549};\\\", \\\"{x:512,y:481,t:1527272657625};\\\", \\\"{x:515,y:482,t:1527272657632};\\\", \\\"{x:527,y:486,t:1527272657649};\\\", \\\"{x:537,y:491,t:1527272657666};\\\", \\\"{x:553,y:494,t:1527272657683};\\\", \\\"{x:562,y:495,t:1527272657700};\\\", \\\"{x:567,y:495,t:1527272657716};\\\", \\\"{x:572,y:495,t:1527272657732};\\\", \\\"{x:577,y:493,t:1527272657749};\\\", \\\"{x:580,y:492,t:1527272657767};\\\", \\\"{x:590,y:490,t:1527272657782};\\\", \\\"{x:618,y:490,t:1527272657800};\\\", \\\"{x:714,y:501,t:1527272657818};\\\", \\\"{x:833,y:535,t:1527272657832};\\\", \\\"{x:978,y:590,t:1527272657850};\\\", \\\"{x:1150,y:670,t:1527272657866};\\\", \\\"{x:1331,y:774,t:1527272657882};\\\", \\\"{x:1496,y:877,t:1527272657900};\\\", \\\"{x:1616,y:973,t:1527272657915};\\\", \\\"{x:1679,y:1025,t:1527272657933};\\\", \\\"{x:1701,y:1053,t:1527272657950};\\\", \\\"{x:1705,y:1062,t:1527272657966};\\\", \\\"{x:1705,y:1066,t:1527272657982};\\\", \\\"{x:1705,y:1069,t:1527272658000};\\\", \\\"{x:1705,y:1073,t:1527272658016};\\\", \\\"{x:1705,y:1084,t:1527272658033};\\\", \\\"{x:1705,y:1090,t:1527272658050};\\\", \\\"{x:1705,y:1092,t:1527272658066};\\\", \\\"{x:1706,y:1093,t:1527272658083};\\\", \\\"{x:1700,y:1093,t:1527272658105};\\\", \\\"{x:1688,y:1093,t:1527272658116};\\\", \\\"{x:1656,y:1088,t:1527272658133};\\\", \\\"{x:1614,y:1075,t:1527272658150};\\\", \\\"{x:1574,y:1056,t:1527272658166};\\\", \\\"{x:1545,y:1043,t:1527272658183};\\\", \\\"{x:1527,y:1035,t:1527272658200};\\\", \\\"{x:1524,y:1033,t:1527272658216};\\\", \\\"{x:1523,y:1028,t:1527272658386};\\\", \\\"{x:1521,y:1021,t:1527272658401};\\\", \\\"{x:1515,y:1004,t:1527272658416};\\\", \\\"{x:1508,y:991,t:1527272658433};\\\", \\\"{x:1507,y:991,t:1527272658450};\\\", \\\"{x:1507,y:989,t:1527272658488};\\\", \\\"{x:1506,y:985,t:1527272658505};\\\", \\\"{x:1505,y:982,t:1527272658516};\\\", \\\"{x:1505,y:979,t:1527272658533};\\\", \\\"{x:1504,y:979,t:1527272658561};\\\", \\\"{x:1503,y:979,t:1527272658601};\\\", \\\"{x:1500,y:977,t:1527272658617};\\\", \\\"{x:1496,y:976,t:1527272658633};\\\", \\\"{x:1496,y:975,t:1527272658650};\\\", \\\"{x:1495,y:975,t:1527272658745};\\\", \\\"{x:1494,y:975,t:1527272658785};\\\", \\\"{x:1493,y:975,t:1527272658800};\\\", \\\"{x:1486,y:971,t:1527272658816};\\\", \\\"{x:1476,y:966,t:1527272658834};\\\", \\\"{x:1475,y:965,t:1527272658850};\\\", \\\"{x:1474,y:964,t:1527272658881};\\\", \\\"{x:1473,y:964,t:1527272658913};\\\", \\\"{x:1471,y:963,t:1527272659010};\\\", \\\"{x:1470,y:962,t:1527272659017};\\\", \\\"{x:1469,y:960,t:1527272659033};\\\", \\\"{x:1468,y:959,t:1527272659081};\\\", \\\"{x:1469,y:959,t:1527272659137};\\\", \\\"{x:1470,y:959,t:1527272659150};\\\", \\\"{x:1472,y:959,t:1527272659166};\\\", \\\"{x:1473,y:959,t:1527272659241};\\\", \\\"{x:1473,y:958,t:1527272659545};\\\", \\\"{x:1474,y:956,t:1527272659553};\\\", \\\"{x:1474,y:955,t:1527272659566};\\\", \\\"{x:1476,y:953,t:1527272659584};\\\", \\\"{x:1477,y:950,t:1527272659600};\\\", \\\"{x:1480,y:947,t:1527272659616};\\\", \\\"{x:1483,y:944,t:1527272659633};\\\", \\\"{x:1484,y:943,t:1527272659706};\\\", \\\"{x:1483,y:942,t:1527272659721};\\\", \\\"{x:1483,y:937,t:1527272659733};\\\", \\\"{x:1481,y:923,t:1527272659750};\\\", \\\"{x:1478,y:907,t:1527272659766};\\\", \\\"{x:1478,y:897,t:1527272659783};\\\", \\\"{x:1478,y:889,t:1527272659799};\\\", \\\"{x:1478,y:884,t:1527272659816};\\\", \\\"{x:1478,y:879,t:1527272659833};\\\", \\\"{x:1478,y:878,t:1527272659849};\\\", \\\"{x:1479,y:877,t:1527272659921};\\\", \\\"{x:1479,y:876,t:1527272659932};\\\", \\\"{x:1480,y:876,t:1527272659950};\\\", \\\"{x:1483,y:876,t:1527272659966};\\\", \\\"{x:1485,y:876,t:1527272659983};\\\", \\\"{x:1488,y:876,t:1527272660000};\\\", \\\"{x:1490,y:876,t:1527272660016};\\\", \\\"{x:1493,y:875,t:1527272660058};\\\", \\\"{x:1493,y:869,t:1527272660066};\\\", \\\"{x:1493,y:861,t:1527272660083};\\\", \\\"{x:1493,y:851,t:1527272660100};\\\", \\\"{x:1491,y:845,t:1527272660116};\\\", \\\"{x:1491,y:844,t:1527272660133};\\\", \\\"{x:1491,y:842,t:1527272660234};\\\", \\\"{x:1490,y:841,t:1527272660250};\\\", \\\"{x:1489,y:840,t:1527272660346};\\\", \\\"{x:1487,y:839,t:1527272660353};\\\", \\\"{x:1484,y:838,t:1527272660369};\\\", \\\"{x:1483,y:837,t:1527272660383};\\\", \\\"{x:1481,y:836,t:1527272660400};\\\", \\\"{x:1480,y:835,t:1527272660660};\\\", \\\"{x:1480,y:833,t:1527272660666};\\\", \\\"{x:1480,y:831,t:1527272660682};\\\", \\\"{x:1480,y:830,t:1527272660700};\\\", \\\"{x:1480,y:828,t:1527272660715};\\\", \\\"{x:1481,y:828,t:1527272661401};\\\", \\\"{x:1481,y:829,t:1527272661415};\\\", \\\"{x:1485,y:838,t:1527272661433};\\\", \\\"{x:1487,y:848,t:1527272661450};\\\", \\\"{x:1491,y:862,t:1527272661466};\\\", \\\"{x:1493,y:879,t:1527272661484};\\\", \\\"{x:1493,y:887,t:1527272661500};\\\", \\\"{x:1494,y:890,t:1527272661516};\\\", \\\"{x:1494,y:891,t:1527272661533};\\\", \\\"{x:1494,y:892,t:1527272661585};\\\", \\\"{x:1494,y:893,t:1527272661600};\\\", \\\"{x:1494,y:895,t:1527272661617};\\\", \\\"{x:1494,y:896,t:1527272661634};\\\", \\\"{x:1494,y:897,t:1527272661651};\\\", \\\"{x:1493,y:896,t:1527272661706};\\\", \\\"{x:1490,y:895,t:1527272661717};\\\", \\\"{x:1485,y:893,t:1527272661733};\\\", \\\"{x:1484,y:893,t:1527272661750};\\\", \\\"{x:1483,y:893,t:1527272661766};\\\", \\\"{x:1484,y:888,t:1527272662905};\\\", \\\"{x:1484,y:880,t:1527272662917};\\\", \\\"{x:1484,y:871,t:1527272662933};\\\", \\\"{x:1484,y:869,t:1527272662951};\\\", \\\"{x:1485,y:869,t:1527272662966};\\\", \\\"{x:1485,y:867,t:1527272663009};\\\", \\\"{x:1485,y:866,t:1527272663017};\\\", \\\"{x:1485,y:865,t:1527272663033};\\\", \\\"{x:1485,y:863,t:1527272663050};\\\", \\\"{x:1487,y:862,t:1527272663066};\\\", \\\"{x:1487,y:861,t:1527272663083};\\\", \\\"{x:1487,y:858,t:1527272663101};\\\", \\\"{x:1487,y:856,t:1527272663116};\\\", \\\"{x:1487,y:852,t:1527272663133};\\\", \\\"{x:1487,y:850,t:1527272663150};\\\", \\\"{x:1487,y:845,t:1527272663166};\\\", \\\"{x:1487,y:840,t:1527272663183};\\\", \\\"{x:1487,y:838,t:1527272663200};\\\", \\\"{x:1487,y:837,t:1527272663216};\\\", \\\"{x:1487,y:835,t:1527272663233};\\\", \\\"{x:1486,y:835,t:1527272663313};\\\", \\\"{x:1485,y:835,t:1527272663409};\\\", \\\"{x:1484,y:835,t:1527272663417};\\\", \\\"{x:1483,y:835,t:1527272663522};\\\", \\\"{x:1482,y:835,t:1527272663533};\\\", \\\"{x:1481,y:834,t:1527272663550};\\\", \\\"{x:1480,y:834,t:1527272663566};\\\", \\\"{x:1479,y:834,t:1527272663585};\\\", \\\"{x:1478,y:833,t:1527272663600};\\\", \\\"{x:1477,y:832,t:1527272663616};\\\", \\\"{x:1476,y:832,t:1527272663633};\\\", \\\"{x:1475,y:831,t:1527272663652};\\\", \\\"{x:1476,y:831,t:1527272664853};\\\", \\\"{x:1480,y:828,t:1527272664869};\\\", \\\"{x:1481,y:827,t:1527272664886};\\\", \\\"{x:1482,y:827,t:1527272664903};\\\", \\\"{x:1482,y:826,t:1527272664956};\\\", \\\"{x:1483,y:825,t:1527272665220};\\\", \\\"{x:1485,y:825,t:1527272665237};\\\", \\\"{x:1486,y:825,t:1527272665820};\\\", \\\"{x:1487,y:819,t:1527272665917};\\\", \\\"{x:1489,y:811,t:1527272665924};\\\", \\\"{x:1491,y:809,t:1527272665936};\\\", \\\"{x:1493,y:798,t:1527272665954};\\\", \\\"{x:1494,y:789,t:1527272665969};\\\", \\\"{x:1495,y:778,t:1527272665986};\\\", \\\"{x:1495,y:774,t:1527272666003};\\\", \\\"{x:1495,y:771,t:1527272666020};\\\", \\\"{x:1495,y:770,t:1527272666036};\\\", \\\"{x:1494,y:769,t:1527272666068};\\\", \\\"{x:1494,y:768,t:1527272666076};\\\", \\\"{x:1493,y:768,t:1527272666085};\\\", \\\"{x:1489,y:765,t:1527272666102};\\\", \\\"{x:1487,y:764,t:1527272666119};\\\", \\\"{x:1486,y:763,t:1527272666147};\\\", \\\"{x:1485,y:763,t:1527272666219};\\\", \\\"{x:1484,y:762,t:1527272666244};\\\", \\\"{x:1483,y:756,t:1527272666484};\\\", \\\"{x:1483,y:748,t:1527272666492};\\\", \\\"{x:1481,y:737,t:1527272666503};\\\", \\\"{x:1479,y:724,t:1527272666519};\\\", \\\"{x:1475,y:715,t:1527272666536};\\\", \\\"{x:1474,y:709,t:1527272666554};\\\", \\\"{x:1474,y:707,t:1527272666569};\\\", \\\"{x:1474,y:706,t:1527272666587};\\\", \\\"{x:1475,y:706,t:1527272666748};\\\", \\\"{x:1476,y:705,t:1527272666756};\\\", \\\"{x:1477,y:705,t:1527272666780};\\\", \\\"{x:1478,y:704,t:1527272666788};\\\", \\\"{x:1478,y:703,t:1527272666949};\\\", \\\"{x:1478,y:701,t:1527272667069};\\\", \\\"{x:1478,y:699,t:1527272667087};\\\", \\\"{x:1478,y:698,t:1527272670469};\\\", \\\"{x:1479,y:698,t:1527272670492};\\\", \\\"{x:1480,y:697,t:1527272670502};\\\", \\\"{x:1480,y:696,t:1527272670520};\\\", \\\"{x:1481,y:696,t:1527272670548};\\\", \\\"{x:1482,y:695,t:1527272676669};\\\", \\\"{x:1482,y:694,t:1527272676740};\\\", \\\"{x:1482,y:688,t:1527272676753};\\\", \\\"{x:1486,y:668,t:1527272676770};\\\", \\\"{x:1487,y:663,t:1527272676787};\\\", \\\"{x:1490,y:657,t:1527272676803};\\\", \\\"{x:1491,y:650,t:1527272676820};\\\", \\\"{x:1494,y:646,t:1527272676837};\\\", \\\"{x:1494,y:645,t:1527272676853};\\\", \\\"{x:1494,y:643,t:1527272676870};\\\", \\\"{x:1495,y:641,t:1527272676887};\\\", \\\"{x:1495,y:639,t:1527272676903};\\\", \\\"{x:1495,y:636,t:1527272676920};\\\", \\\"{x:1495,y:631,t:1527272676937};\\\", \\\"{x:1494,y:628,t:1527272676952};\\\", \\\"{x:1494,y:625,t:1527272676970};\\\", \\\"{x:1494,y:622,t:1527272676987};\\\", \\\"{x:1492,y:617,t:1527272677003};\\\", \\\"{x:1491,y:608,t:1527272677020};\\\", \\\"{x:1489,y:602,t:1527272677037};\\\", \\\"{x:1488,y:598,t:1527272677052};\\\", \\\"{x:1487,y:594,t:1527272677070};\\\", \\\"{x:1487,y:592,t:1527272677087};\\\", \\\"{x:1486,y:590,t:1527272677103};\\\", \\\"{x:1486,y:588,t:1527272677120};\\\", \\\"{x:1486,y:587,t:1527272677137};\\\", \\\"{x:1486,y:584,t:1527272677153};\\\", \\\"{x:1486,y:576,t:1527272677170};\\\", \\\"{x:1485,y:571,t:1527272677187};\\\", \\\"{x:1485,y:568,t:1527272677203};\\\", \\\"{x:1485,y:567,t:1527272677220};\\\", \\\"{x:1485,y:565,t:1527272677237};\\\", \\\"{x:1485,y:564,t:1527272677253};\\\", \\\"{x:1483,y:562,t:1527272677270};\\\", \\\"{x:1483,y:560,t:1527272677287};\\\", \\\"{x:1482,y:559,t:1527272677372};\\\", \\\"{x:1482,y:558,t:1527272677428};\\\", \\\"{x:1474,y:552,t:1527272681332};\\\", \\\"{x:1400,y:522,t:1527272681339};\\\", \\\"{x:1295,y:484,t:1527272681354};\\\", \\\"{x:1091,y:429,t:1527272681370};\\\", \\\"{x:922,y:384,t:1527272681387};\\\", \\\"{x:777,y:322,t:1527272681403};\\\", \\\"{x:602,y:253,t:1527272681420};\\\", \\\"{x:530,y:229,t:1527272681437};\\\", \\\"{x:509,y:228,t:1527272681453};\\\", \\\"{x:504,y:233,t:1527272681470};\\\", \\\"{x:503,y:255,t:1527272681487};\\\", \\\"{x:511,y:298,t:1527272681503};\\\", \\\"{x:520,y:329,t:1527272681520};\\\", \\\"{x:529,y:349,t:1527272681537};\\\", \\\"{x:533,y:356,t:1527272681553};\\\", \\\"{x:536,y:360,t:1527272681570};\\\", \\\"{x:545,y:366,t:1527272681587};\\\", \\\"{x:552,y:370,t:1527272681602};\\\", \\\"{x:600,y:396,t:1527272681619};\\\", \\\"{x:668,y:423,t:1527272681637};\\\", \\\"{x:737,y:443,t:1527272681654};\\\", \\\"{x:791,y:459,t:1527272681670};\\\", \\\"{x:821,y:466,t:1527272681687};\\\", \\\"{x:836,y:470,t:1527272681703};\\\", \\\"{x:846,y:475,t:1527272681720};\\\", \\\"{x:856,y:482,t:1527272681737};\\\", \\\"{x:868,y:490,t:1527272681753};\\\", \\\"{x:882,y:501,t:1527272681772};\\\", \\\"{x:890,y:506,t:1527272681786};\\\", \\\"{x:895,y:513,t:1527272681802};\\\", \\\"{x:895,y:516,t:1527272681821};\\\", \\\"{x:895,y:519,t:1527272681838};\\\", \\\"{x:895,y:520,t:1527272681867};\\\", \\\"{x:892,y:520,t:1527272681875};\\\", \\\"{x:888,y:520,t:1527272681888};\\\", \\\"{x:881,y:520,t:1527272681906};\\\", \\\"{x:874,y:520,t:1527272681921};\\\", \\\"{x:866,y:520,t:1527272681938};\\\", \\\"{x:861,y:522,t:1527272681955};\\\", \\\"{x:855,y:524,t:1527272681972};\\\", \\\"{x:851,y:524,t:1527272681989};\\\", \\\"{x:849,y:524,t:1527272682005};\\\", \\\"{x:848,y:524,t:1527272682022};\\\", \\\"{x:845,y:524,t:1527272682038};\\\", \\\"{x:843,y:524,t:1527272682056};\\\", \\\"{x:841,y:524,t:1527272682072};\\\", \\\"{x:840,y:524,t:1527272682088};\\\", \\\"{x:838,y:524,t:1527272682306};\\\", \\\"{x:739,y:524,t:1527272682323};\\\", \\\"{x:616,y:535,t:1527272682340};\\\", \\\"{x:546,y:535,t:1527272682355};\\\", \\\"{x:530,y:535,t:1527272682373};\\\", \\\"{x:527,y:536,t:1527272682390};\\\", \\\"{x:526,y:536,t:1527272682406};\\\", \\\"{x:525,y:536,t:1527272682423};\\\", \\\"{x:524,y:536,t:1527272682524};\\\", \\\"{x:523,y:537,t:1527272682540};\\\", \\\"{x:526,y:537,t:1527272682572};\\\", \\\"{x:554,y:528,t:1527272682591};\\\", \\\"{x:591,y:515,t:1527272682607};\\\", \\\"{x:608,y:510,t:1527272682622};\\\", \\\"{x:613,y:508,t:1527272682639};\\\", \\\"{x:616,y:506,t:1527272682656};\\\", \\\"{x:614,y:510,t:1527272682979};\\\", \\\"{x:610,y:529,t:1527272682990};\\\", \\\"{x:609,y:583,t:1527272683007};\\\", \\\"{x:609,y:652,t:1527272683023};\\\", \\\"{x:602,y:716,t:1527272683040};\\\", \\\"{x:591,y:755,t:1527272683057};\\\", \\\"{x:584,y:770,t:1527272683074};\\\", \\\"{x:583,y:770,t:1527272683089};\\\", \\\"{x:582,y:772,t:1527272683106};\\\", \\\"{x:581,y:773,t:1527272683131};\\\", \\\"{x:579,y:775,t:1527272683139};\\\", \\\"{x:575,y:777,t:1527272683156};\\\", \\\"{x:574,y:778,t:1527272683173};\\\", \\\"{x:573,y:778,t:1527272683190};\\\", \\\"{x:572,y:778,t:1527272683219};\\\", \\\"{x:570,y:775,t:1527272683227};\\\", \\\"{x:568,y:772,t:1527272683241};\\\", \\\"{x:562,y:761,t:1527272683258};\\\", \\\"{x:556,y:752,t:1527272683273};\\\", \\\"{x:551,y:746,t:1527272683290};\\\", \\\"{x:549,y:743,t:1527272683307};\\\", \\\"{x:547,y:740,t:1527272683324};\\\", \\\"{x:546,y:739,t:1527272683340};\\\", \\\"{x:545,y:738,t:1527272684642};\\\", \\\"{x:546,y:734,t:1527272684900};\\\", \\\"{x:565,y:720,t:1527272684908};\\\", \\\"{x:614,y:694,t:1527272684924};\\\", \\\"{x:667,y:676,t:1527272684942};\\\", \\\"{x:746,y:663,t:1527272684958};\\\", \\\"{x:842,y:652,t:1527272684975};\\\", \\\"{x:948,y:638,t:1527272684992};\\\", \\\"{x:1034,y:625,t:1527272685007};\\\", \\\"{x:1100,y:620,t:1527272685025};\\\", \\\"{x:1134,y:613,t:1527272685042};\\\", \\\"{x:1153,y:610,t:1527272685057};\\\", \\\"{x:1167,y:610,t:1527272685074};\\\", \\\"{x:1177,y:610,t:1527272685091};\\\", \\\"{x:1178,y:610,t:1527272685108};\\\", \\\"{x:1179,y:610,t:1527272685125};\\\", \\\"{x:1181,y:610,t:1527272685142};\\\", \\\"{x:1182,y:609,t:1527272685252};\\\", \\\"{x:1176,y:607,t:1527272685259};\\\", \\\"{x:1121,y:599,t:1527272685275};\\\", \\\"{x:1031,y:594,t:1527272685291};\\\", \\\"{x:942,y:578,t:1527272685309};\\\", \\\"{x:877,y:568,t:1527272685325};\\\", \\\"{x:840,y:561,t:1527272685342};\\\", \\\"{x:821,y:560,t:1527272685359};\\\", \\\"{x:814,y:560,t:1527272685375};\\\", \\\"{x:807,y:565,t:1527272685392};\\\", \\\"{x:799,y:579,t:1527272685409};\\\", \\\"{x:795,y:589,t:1527272685425};\\\", \\\"{x:794,y:601,t:1527272685442};\\\", \\\"{x:791,y:613,t:1527272685459};\\\", \\\"{x:790,y:632,t:1527272685476};\\\", \\\"{x:790,y:638,t:1527272685491};\\\", \\\"{x:790,y:640,t:1527272685509};\\\" ] }, { \\\"rt\\\": 70550, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1292813, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You go to the x axis and look for where it says 12 pm, then you go up the y axis from the starting point of 12 pm and see which dots fall in that line going up.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 18495, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1312315, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13163, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Fine Arts\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1326490, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3502, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1331335, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"UV5LD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"UV5LD\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 461, dom: 950, initialDom: 1141",
  "javascriptErrors": []
}