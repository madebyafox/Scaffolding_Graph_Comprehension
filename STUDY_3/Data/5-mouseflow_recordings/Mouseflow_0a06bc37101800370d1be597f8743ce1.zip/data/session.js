var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0a06bc37101800370d1be597f8743ce1",
  "created": "2018-06-01T09:22:05.3344599-07:00",
  "lastActivity": "2018-06-01T09:24:16.7278276-07:00",
  "pageViews": [
    {
      "id": "06010556d8cdbd2fdef4510e64ad9e6b72c4b8a9",
      "startTime": "2018-06-01T09:22:05.4598276-07:00",
      "endTime": "2018-06-01T09:24:16.7278276-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 131268,
      "engagementTime": 125662,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 131268,
  "engagementTime": 125662,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=LBHUP",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3d7e2dbe113444fda0310bd53006e493",
  "gdpr": false
}