var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dafc4224db41963cb00de9845814b69c",
  "created": "2018-05-29T16:12:02.6834388-07:00",
  "lastActivity": "2018-05-29T16:12:51.4354388-07:00",
  "pageViews": [
    {
      "id": "052902167e0dfc21c45aabb6dfffbda2cba9a715",
      "startTime": "2018-05-29T16:12:02.6834388-07:00",
      "endTime": "2018-05-29T16:12:51.4354388-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 48752,
      "engagementTime": 38701,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48752,
  "engagementTime": 38701,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CSU5Z",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c4ea0dc2a94fcf472543d77d79c7f2f0",
  "gdpr": false
}