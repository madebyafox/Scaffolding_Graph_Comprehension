var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "36239f0dc2bfcdf57be4e2ae29946d55",
  "created": "2018-05-14T13:10:40.6072529-07:00",
  "lastActivity": "2018-05-14T13:12:41.2092529-07:00",
  "pageViews": [
    {
      "id": "05144000ee0413102ea9a96dc603469639c44401",
      "startTime": "2018-05-14T13:10:40.6072529-07:00",
      "endTime": "2018-05-14T13:12:41.2092529-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 120602,
      "engagementTime": 96197,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 120602,
  "engagementTime": 96197,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4FETN",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d8df304168df10c5ae1c9a1dd34ec113",
  "gdpr": false
}