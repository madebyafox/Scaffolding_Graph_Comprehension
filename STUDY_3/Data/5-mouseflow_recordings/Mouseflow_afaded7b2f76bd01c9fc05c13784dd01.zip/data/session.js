var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "afaded7b2f76bd01c9fc05c13784dd01",
  "created": "2018-05-24T12:05:58.8725936-07:00",
  "lastActivity": "2018-05-24T12:06:16.2102541-07:00",
  "pageViews": [
    {
      "id": "0524585222ea260baa189468e0b2b63f173971af",
      "startTime": "2018-05-24T12:05:58.8748274-07:00",
      "endTime": "2018-05-24T12:06:16.2102541-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 17524,
      "engagementTime": 17524,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17524,
  "engagementTime": 17524,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=3Z8ZL",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d2aeeb98e825549719cd5eb63be10a18",
  "gdpr": false
}