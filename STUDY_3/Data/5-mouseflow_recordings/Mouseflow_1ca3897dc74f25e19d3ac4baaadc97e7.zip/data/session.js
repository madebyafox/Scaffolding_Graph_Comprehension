var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1ca3897dc74f25e19d3ac4baaadc97e7",
  "created": "2018-05-29T10:09:33.1360644-07:00",
  "lastActivity": "2018-05-29T10:10:00.4150644-07:00",
  "pageViews": [
    {
      "id": "052933775147585d06766586d35bf93a57e690b1",
      "startTime": "2018-05-29T10:09:33.1360644-07:00",
      "endTime": "2018-05-29T10:10:00.4150644-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 27279,
      "engagementTime": 27279,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27279,
  "engagementTime": 27279,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AZKMW",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d61cf730e7da4379612823dfa9951e64",
  "gdpr": false
}