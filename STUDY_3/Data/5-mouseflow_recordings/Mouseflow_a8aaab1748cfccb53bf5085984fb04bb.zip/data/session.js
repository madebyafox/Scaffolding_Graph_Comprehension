var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a8aaab1748cfccb53bf5085984fb04bb",
  "created": "2018-05-29T16:04:50.4956692-07:00",
  "lastActivity": "2018-05-29T16:06:35.9979623-07:00",
  "pageViews": [
    {
      "id": "052950651c05ac0bbfd734c5f3aa05c26ea684fe",
      "startTime": "2018-05-29T16:04:50.4956692-07:00",
      "endTime": "2018-05-29T16:06:35.9979623-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 105764,
      "engagementTime": 90255,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 105764,
  "engagementTime": 90255,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "048b689c55517cfbe2c0ca5a2711a78d",
  "gdpr": false
}