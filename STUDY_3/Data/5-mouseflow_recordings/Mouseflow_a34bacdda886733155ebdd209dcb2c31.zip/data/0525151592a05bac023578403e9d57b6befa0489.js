var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0525151592a05bac023578403e9d57b6befa0489"] = {
  "startTime": "2018-05-25T17:18:15.4763162Z",
  "websitePageUrl": "/16",
  "visitTime": 98382,
  "engagementTime": 80239,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a34bacdda886733155ebdd209dcb2c31",
    "created": "2018-05-25T17:18:15.4446232+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=5QCE3",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "eb101fb08e5dd9c4776b77c3cad08240",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a34bacdda886733155ebdd209dcb2c31/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 195,
      "e": 195,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 489,
      "y": 736
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 44054,
      "y": 40329,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 491,
      "y": 728
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 493,
      "y": 701
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 44503,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 488,
      "y": 662
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 484,
      "y": 635
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 481,
      "y": 607
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 43154,
      "y": 62883,
      "ta": "#.strategy"
    },
    {
      "t": 1518,
      "e": 1518,
      "ty": 6,
      "x": 481,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 481,
      "y": 590
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 2,
      "x": 485,
      "y": 579
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 43604,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 487,
      "y": 576
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 488,
      "y": 576
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 43941,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 490,
      "y": 575
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 44166,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6169,
      "e": 6169,
      "ty": 3,
      "x": 490,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6172,
      "e": 6172,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6385,
      "e": 6385,
      "ty": 4,
      "x": 44166,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6386,
      "e": 6386,
      "ty": 5,
      "x": 490,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7510,
      "e": 7510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7758,
      "e": 7758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 7759,
      "e": 7759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7861,
      "e": 7861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7917,
      "e": 7917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 8029,
      "e": 8029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 8070,
      "e": 8070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8070,
      "e": 8070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8202,
      "e": 8202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 8204,
      "e": 8204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8205,
      "e": 8205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8236,
      "e": 8236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go t"
    },
    {
      "t": 8309,
      "e": 8309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8309,
      "e": 8309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8356,
      "e": 8356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 8445,
      "e": 8445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8509,
      "e": 8509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8510,
      "e": 8510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8676,
      "e": 8676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10685,
      "e": 10685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10685,
      "e": 10685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10772,
      "e": 10772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10829,
      "e": 10829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10829,
      "e": 10829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10901,
      "e": 10901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 10997,
      "e": 10997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10998,
      "e": 10998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11077,
      "e": 11077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11149,
      "e": 11149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11149,
      "e": 11149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11270,
      "e": 11270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11309,
      "e": 11309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11310,
      "e": 11310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11460,
      "e": 11460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 11550,
      "e": 11550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11550,
      "e": 11550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11653,
      "e": 11653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 11885,
      "e": 11885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11886,
      "e": 11886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11957,
      "e": 11957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 12117,
      "e": 12117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12118,
      "e": 12118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12173,
      "e": 12173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12293,
      "e": 12293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12293,
      "e": 12293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12372,
      "e": 12372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12613,
      "e": 12613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12614,
      "e": 12614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12668,
      "e": 12668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12803,
      "e": 12803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm m"
    },
    {
      "t": 12861,
      "e": 12861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12862,
      "e": 12862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12980,
      "e": 12980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13133,
      "e": 13133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13134,
      "e": 13134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13221,
      "e": 13221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 13477,
      "e": 13477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13478,
      "e": 13478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13549,
      "e": 13549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 13637,
      "e": 13637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13638,
      "e": 13638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13757,
      "e": 13757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13765,
      "e": 13765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13765,
      "e": 13765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13876,
      "e": 13876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 13957,
      "e": 13957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13958,
      "e": 13958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14028,
      "e": 14028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14093,
      "e": 14093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14093,
      "e": 14093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14204,
      "e": 14204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker a"
    },
    {
      "t": 14214,
      "e": 14214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14301,
      "e": 14301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14302,
      "e": 14302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14389,
      "e": 14389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14453,
      "e": 14453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14454,
      "e": 14454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14541,
      "e": 14541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14813,
      "e": 14813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 14814,
      "e": 14814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14885,
      "e": 14885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 14989,
      "e": 14989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14989,
      "e": 14989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15045,
      "e": 15045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15141,
      "e": 15141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15142,
      "e": 15142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15189,
      "e": 15189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15309,
      "e": 15309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15309,
      "e": 15309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15357,
      "e": 15357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15429,
      "e": 15429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15430,
      "e": 15430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15501,
      "e": 15501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at botto"
    },
    {
      "t": 15613,
      "e": 15613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15614,
      "e": 15614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15685,
      "e": 15685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 15781,
      "e": 15781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15781,
      "e": 15781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15853,
      "e": 15853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16286,
      "e": 16286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16286,
      "e": 16286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16357,
      "e": 16357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16453,
      "e": 16453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16454,
      "e": 16454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16508,
      "e": 16508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16604,
      "e": 16604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16605,
      "e": 16605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16684,
      "e": 16684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16796,
      "e": 16796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16797,
      "e": 16797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16853,
      "e": 16853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16956,
      "e": 16956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16956,
      "e": 16956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17012,
      "e": 17012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17117,
      "e": 17117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17120,
      "e": 17120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17197,
      "e": 17197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 17557,
      "e": 17557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17558,
      "e": 17558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17604,
      "e": 17604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17757,
      "e": 17757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17757,
      "e": 17757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17805,
      "e": 17805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18213,
      "e": 18213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18213,
      "e": 18213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18268,
      "e": 18268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18403,
      "e": 18403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at bottom then foll"
    },
    {
      "t": 18404,
      "e": 18404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18405,
      "e": 18405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18468,
      "e": 18468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18597,
      "e": 18597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 18597,
      "e": 18597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18668,
      "e": 18668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 18855,
      "e": 18669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18856,
      "e": 18670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18957,
      "e": 18771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21893,
      "e": 21707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21894,
      "e": 21708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21972,
      "e": 21786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22133,
      "e": 21947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22133,
      "e": 21947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22230,
      "e": 22044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22278,
      "e": 22092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22278,
      "e": 22092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22372,
      "e": 22186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22509,
      "e": 22323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 22510,
      "e": 22324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22598,
      "e": 22412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 22789,
      "e": 22603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22790,
      "e": 22604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22941,
      "e": 22755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23005,
      "e": 22819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23006,
      "e": 22820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23093,
      "e": 22907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23164,
      "e": 22978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23165,
      "e": 22979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23261,
      "e": 23075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23324,
      "e": 23138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23324,
      "e": 23138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23396,
      "e": 23210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23445,
      "e": 23259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23446,
      "e": 23260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23557,
      "e": 23371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23612,
      "e": 23426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23613,
      "e": 23427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23717,
      "e": 23531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24437,
      "e": 24251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 24438,
      "e": 24252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24509,
      "e": 24323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 24685,
      "e": 24499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24686,
      "e": 24500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24749,
      "e": 24563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 24949,
      "e": 24763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24949,
      "e": 24763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25021,
      "e": 24835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25197,
      "e": 25011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25198,
      "e": 25012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25260,
      "e": 25074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25372,
      "e": 25186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25373,
      "e": 25187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25437,
      "e": 25251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27101,
      "e": 26915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27101,
      "e": 26915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27197,
      "e": 27011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27285,
      "e": 27099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27286,
      "e": 27100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27373,
      "e": 27187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27469,
      "e": 27283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27469,
      "e": 27283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27540,
      "e": 27354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27677,
      "e": 27491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27678,
      "e": 27492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27764,
      "e": 27578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 27901,
      "e": 27715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27901,
      "e": 27715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27972,
      "e": 27786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28133,
      "e": 27947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28135,
      "e": 27949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28245,
      "e": 28059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28286,
      "e": 28100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28286,
      "e": 28100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28404,
      "e": 28218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at bottom then follow it up the cross sectio"
    },
    {
      "t": 28413,
      "e": 28227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28549,
      "e": 28363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28550,
      "e": 28364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28612,
      "e": 28426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28709,
      "e": 28523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28709,
      "e": 28523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28772,
      "e": 28586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28981,
      "e": 28795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28982,
      "e": 28796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29012,
      "e": 28826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29261,
      "e": 29075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29262,
      "e": 29076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29332,
      "e": 29146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29469,
      "e": 29283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29470,
      "e": 29284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29557,
      "e": 29371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30002,
      "e": 29816,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30197,
      "e": 30011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30197,
      "e": 30011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30260,
      "e": 30074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30397,
      "e": 30211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30397,
      "e": 30211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30445,
      "e": 30259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30565,
      "e": 30379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30566,
      "e": 30380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30613,
      "e": 30427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30693,
      "e": 30507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30693,
      "e": 30507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30764,
      "e": 30578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30853,
      "e": 30667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30853,
      "e": 30667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30917,
      "e": 30731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30997,
      "e": 30811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30998,
      "e": 30812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31061,
      "e": 30875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31117,
      "e": 30931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31118,
      "e": 30932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31190,
      "e": 31004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31269,
      "e": 31083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31269,
      "e": 31083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31349,
      "e": 31163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31437,
      "e": 31251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31438,
      "e": 31252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31516,
      "e": 31330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31596,
      "e": 31410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31597,
      "e": 31411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31652,
      "e": 31466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31765,
      "e": 31579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31766,
      "e": 31580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31845,
      "e": 31659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31980,
      "e": 31794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31980,
      "e": 31794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32084,
      "e": 31898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32367,
      "e": 32181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32368,
      "e": 32182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32452,
      "e": 32266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32524,
      "e": 32338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32525,
      "e": 32339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32605,
      "e": 32419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32685,
      "e": 32499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32686,
      "e": 32500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32732,
      "e": 32546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32804,
      "e": 32618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32805,
      "e": 32619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32909,
      "e": 32723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33365,
      "e": 33179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33365,
      "e": 33179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33460,
      "e": 33274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33564,
      "e": 33378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33565,
      "e": 33379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33669,
      "e": 33483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35397,
      "e": 35211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 35398,
      "e": 35212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35533,
      "e": 35347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 35580,
      "e": 35394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35581,
      "e": 35395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35709,
      "e": 35523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36405,
      "e": 36219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36405,
      "e": 36219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36452,
      "e": 36266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36556,
      "e": 36370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36557,
      "e": 36371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36637,
      "e": 36451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36749,
      "e": 36563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36751,
      "e": 36565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36877,
      "e": 36691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37206,
      "e": 37020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37208,
      "e": 37022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37300,
      "e": 37114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37403,
      "e": 37217,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at bottom then follow it up the cross section to see the dots that fall o"
    },
    {
      "t": 37444,
      "e": 37258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37446,
      "e": 37260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37500,
      "e": 37314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37602,
      "e": 37416,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at bottom then follow it up the cross section to see the dots that fall on"
    },
    {
      "t": 37677,
      "e": 37491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37678,
      "e": 37492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37748,
      "e": 37562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37820,
      "e": 37634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37820,
      "e": 37634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37885,
      "e": 37699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37973,
      "e": 37787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37974,
      "e": 37788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38061,
      "e": 37875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38124,
      "e": 37938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38124,
      "e": 37938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38197,
      "e": 38011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38261,
      "e": 38075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38262,
      "e": 38076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38333,
      "e": 38147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38389,
      "e": 38203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38390,
      "e": 38204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38476,
      "e": 38290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38549,
      "e": 38363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38549,
      "e": 38363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38628,
      "e": 38442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39317,
      "e": 39131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39318,
      "e": 39132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39396,
      "e": 39210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39508,
      "e": 39322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39510,
      "e": 39324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39572,
      "e": 39386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39709,
      "e": 39523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 39710,
      "e": 39524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39764,
      "e": 39578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 39844,
      "e": 39658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39844,
      "e": 39658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39917,
      "e": 39731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39997,
      "e": 39811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39997,
      "e": 39811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40069,
      "e": 39883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40800,
      "e": 40614,
      "ty": 7,
      "x": 479,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40801,
      "e": 40615,
      "ty": 2,
      "x": 479,
      "y": 520
    },
    {
      "t": 40853,
      "e": 40667,
      "ty": 6,
      "x": 436,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40905,
      "e": 40719,
      "ty": 2,
      "x": 389,
      "y": 553
    },
    {
      "t": 41005,
      "e": 40819,
      "ty": 2,
      "x": 355,
      "y": 574
    },
    {
      "t": 41005,
      "e": 40819,
      "ty": 41,
      "x": 28991,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41053,
      "e": 40867,
      "ty": 7,
      "x": 347,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41105,
      "e": 40919,
      "ty": 2,
      "x": 349,
      "y": 640
    },
    {
      "t": 41137,
      "e": 40951,
      "ty": 6,
      "x": 359,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 41204,
      "e": 41018,
      "ty": 7,
      "x": 381,
      "y": 691,
      "ta": "#strategyButton"
    },
    {
      "t": 41205,
      "e": 41019,
      "ty": 2,
      "x": 381,
      "y": 691
    },
    {
      "t": 41255,
      "e": 41069,
      "ty": 41,
      "x": 32957,
      "y": 48014,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 41305,
      "e": 41119,
      "ty": 2,
      "x": 390,
      "y": 695
    },
    {
      "t": 41404,
      "e": 41218,
      "ty": 6,
      "x": 397,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 41406,
      "e": 41220,
      "ty": 2,
      "x": 397,
      "y": 687
    },
    {
      "t": 41505,
      "e": 41319,
      "ty": 2,
      "x": 404,
      "y": 676
    },
    {
      "t": 41505,
      "e": 41319,
      "ty": 41,
      "x": 35719,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 41548,
      "e": 41362,
      "ty": 3,
      "x": 404,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 41549,
      "e": 41363,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the 12pm marker at bottom then follow it up the cross section to see the dots that fall onto the time "
    },
    {
      "t": 41549,
      "e": 41363,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41550,
      "e": 41364,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 41637,
      "e": 41451,
      "ty": 4,
      "x": 35719,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 41648,
      "e": 41462,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 41649,
      "e": 41463,
      "ty": 5,
      "x": 404,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 41656,
      "e": 41470,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 41705,
      "e": 41519,
      "ty": 2,
      "x": 405,
      "y": 675
    },
    {
      "t": 41755,
      "e": 41569,
      "ty": 41,
      "x": 13671,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 42005,
      "e": 41819,
      "ty": 2,
      "x": 406,
      "y": 675
    },
    {
      "t": 42005,
      "e": 41819,
      "ty": 41,
      "x": 13706,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 42105,
      "e": 41919,
      "ty": 2,
      "x": 411,
      "y": 676
    },
    {
      "t": 42205,
      "e": 42019,
      "ty": 2,
      "x": 428,
      "y": 674
    },
    {
      "t": 42256,
      "e": 42070,
      "ty": 41,
      "x": 14773,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 42305,
      "e": 42119,
      "ty": 2,
      "x": 442,
      "y": 668
    },
    {
      "t": 42406,
      "e": 42220,
      "ty": 2,
      "x": 445,
      "y": 666
    },
    {
      "t": 42505,
      "e": 42319,
      "ty": 41,
      "x": 15049,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 42656,
      "e": 42470,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 42805,
      "e": 42619,
      "ty": 2,
      "x": 446,
      "y": 665
    },
    {
      "t": 42905,
      "e": 42719,
      "ty": 2,
      "x": 449,
      "y": 664
    },
    {
      "t": 43005,
      "e": 42819,
      "ty": 2,
      "x": 450,
      "y": 661
    },
    {
      "t": 43005,
      "e": 42819,
      "ty": 41,
      "x": 15221,
      "y": 36174,
      "ta": "html > body"
    },
    {
      "t": 43106,
      "e": 42920,
      "ty": 2,
      "x": 512,
      "y": 657
    },
    {
      "t": 43208,
      "e": 43022,
      "ty": 2,
      "x": 794,
      "y": 650
    },
    {
      "t": 43255,
      "e": 43069,
      "ty": 41,
      "x": 7786,
      "y": 44470,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 43305,
      "e": 43119,
      "ty": 2,
      "x": 874,
      "y": 605
    },
    {
      "t": 43388,
      "e": 43202,
      "ty": 6,
      "x": 911,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43405,
      "e": 43219,
      "ty": 2,
      "x": 912,
      "y": 567
    },
    {
      "t": 43505,
      "e": 43319,
      "ty": 2,
      "x": 912,
      "y": 566
    },
    {
      "t": 43506,
      "e": 43320,
      "ty": 41,
      "x": 22493,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43773,
      "e": 43587,
      "ty": 3,
      "x": 912,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43774,
      "e": 43588,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43884,
      "e": 43698,
      "ty": 4,
      "x": 22493,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43884,
      "e": 43698,
      "ty": 5,
      "x": 912,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44561,
      "e": 44375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 44561,
      "e": 44375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44664,
      "e": 44478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 44897,
      "e": 44711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 44898,
      "e": 44712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44968,
      "e": 44782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 45605,
      "e": 45419,
      "ty": 2,
      "x": 866,
      "y": 556
    },
    {
      "t": 45641,
      "e": 45455,
      "ty": 7,
      "x": 839,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45706,
      "e": 45520,
      "ty": 2,
      "x": 828,
      "y": 605
    },
    {
      "t": 45756,
      "e": 45570,
      "ty": 41,
      "x": 3460,
      "y": 35108,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 45805,
      "e": 45619,
      "ty": 2,
      "x": 823,
      "y": 617
    },
    {
      "t": 45905,
      "e": 45719,
      "ty": 2,
      "x": 817,
      "y": 622
    },
    {
      "t": 46005,
      "e": 45819,
      "ty": 2,
      "x": 811,
      "y": 631
    },
    {
      "t": 46005,
      "e": 45819,
      "ty": 41,
      "x": 648,
      "y": 33824,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 46105,
      "e": 45919,
      "ty": 2,
      "x": 811,
      "y": 635
    },
    {
      "t": 46205,
      "e": 46019,
      "ty": 2,
      "x": 811,
      "y": 642
    },
    {
      "t": 46225,
      "e": 46039,
      "ty": 6,
      "x": 814,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46255,
      "e": 46069,
      "ty": 41,
      "x": 1514,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46305,
      "e": 46119,
      "ty": 2,
      "x": 816,
      "y": 651
    },
    {
      "t": 46405,
      "e": 46219,
      "ty": 2,
      "x": 818,
      "y": 655
    },
    {
      "t": 46429,
      "e": 46243,
      "ty": 3,
      "x": 818,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46430,
      "e": 46244,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 46431,
      "e": 46245,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46432,
      "e": 46246,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46505,
      "e": 46319,
      "ty": 41,
      "x": 2162,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46556,
      "e": 46370,
      "ty": 4,
      "x": 2162,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46556,
      "e": 46370,
      "ty": 5,
      "x": 818,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46658,
      "e": 46472,
      "ty": 7,
      "x": 801,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46705,
      "e": 46519,
      "ty": 2,
      "x": 800,
      "y": 655
    },
    {
      "t": 46756,
      "e": 46570,
      "ty": 41,
      "x": 27274,
      "y": 35842,
      "ta": "html > body"
    },
    {
      "t": 47096,
      "e": 46910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 47344,
      "e": 47158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 47345,
      "e": 47159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47376,
      "e": 47190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 47665,
      "e": 47479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 47665,
      "e": 47479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47800,
      "e": 47614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 47993,
      "e": 47807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 47994,
      "e": 47808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48128,
      "e": 47942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 48184,
      "e": 47998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 48561,
      "e": 48375,
      "ty": 6,
      "x": 820,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48605,
      "e": 48419,
      "ty": 2,
      "x": 821,
      "y": 647
    },
    {
      "t": 48705,
      "e": 48519,
      "ty": 2,
      "x": 861,
      "y": 661
    },
    {
      "t": 48710,
      "e": 48524,
      "ty": 7,
      "x": 885,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48727,
      "e": 48541,
      "ty": 6,
      "x": 900,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48756,
      "e": 48570,
      "ty": 41,
      "x": 3647,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48806,
      "e": 48620,
      "ty": 2,
      "x": 926,
      "y": 703
    },
    {
      "t": 48810,
      "e": 48621,
      "ty": 7,
      "x": 942,
      "y": 715,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48905,
      "e": 48716,
      "ty": 2,
      "x": 957,
      "y": 723
    },
    {
      "t": 49005,
      "e": 48816,
      "ty": 2,
      "x": 967,
      "y": 713
    },
    {
      "t": 49006,
      "e": 48817,
      "ty": 41,
      "x": 33025,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 49094,
      "e": 48905,
      "ty": 6,
      "x": 968,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49105,
      "e": 48916,
      "ty": 2,
      "x": 968,
      "y": 707
    },
    {
      "t": 49205,
      "e": 49016,
      "ty": 2,
      "x": 970,
      "y": 703
    },
    {
      "t": 49246,
      "e": 49057,
      "ty": 3,
      "x": 970,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49246,
      "e": 49057,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 49247,
      "e": 49058,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49248,
      "e": 49059,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49256,
      "e": 49067,
      "ty": 41,
      "x": 38179,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49348,
      "e": 49159,
      "ty": 4,
      "x": 38179,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49349,
      "e": 49160,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49349,
      "e": 49160,
      "ty": 5,
      "x": 970,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49349,
      "e": 49160,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 50363,
      "e": 50174,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 50905,
      "e": 50716,
      "ty": 2,
      "x": 963,
      "y": 690
    },
    {
      "t": 51006,
      "e": 50817,
      "ty": 2,
      "x": 857,
      "y": 377
    },
    {
      "t": 51006,
      "e": 50817,
      "ty": 41,
      "x": 8443,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 51105,
      "e": 50916,
      "ty": 2,
      "x": 782,
      "y": 89
    },
    {
      "t": 51205,
      "e": 51016,
      "ty": 2,
      "x": 816,
      "y": 81
    },
    {
      "t": 51256,
      "e": 51067,
      "ty": 41,
      "x": 29375,
      "y": 4653,
      "ta": "html > body"
    },
    {
      "t": 51306,
      "e": 51117,
      "ty": 2,
      "x": 923,
      "y": 128
    },
    {
      "t": 51406,
      "e": 51217,
      "ty": 2,
      "x": 965,
      "y": 153
    },
    {
      "t": 51506,
      "e": 51317,
      "ty": 2,
      "x": 948,
      "y": 207
    },
    {
      "t": 51506,
      "e": 51317,
      "ty": 41,
      "x": 30040,
      "y": 11613,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 51605,
      "e": 51416,
      "ty": 2,
      "x": 922,
      "y": 224
    },
    {
      "t": 51706,
      "e": 51517,
      "ty": 2,
      "x": 885,
      "y": 224
    },
    {
      "t": 51756,
      "e": 51567,
      "ty": 41,
      "x": 10816,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 51806,
      "e": 51617,
      "ty": 2,
      "x": 852,
      "y": 232
    },
    {
      "t": 51906,
      "e": 51717,
      "ty": 2,
      "x": 843,
      "y": 234
    },
    {
      "t": 51930,
      "e": 51741,
      "ty": 6,
      "x": 838,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52006,
      "e": 51817,
      "ty": 2,
      "x": 838,
      "y": 236
    },
    {
      "t": 52006,
      "e": 51817,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52106,
      "e": 51917,
      "ty": 2,
      "x": 837,
      "y": 236
    },
    {
      "t": 52157,
      "e": 51968,
      "ty": 3,
      "x": 837,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52158,
      "e": 51969,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52256,
      "e": 52067,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52284,
      "e": 52095,
      "ty": 4,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52285,
      "e": 52096,
      "ty": 5,
      "x": 837,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52285,
      "e": 52096,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 52480,
      "e": 52291,
      "ty": 7,
      "x": 840,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52505,
      "e": 52316,
      "ty": 2,
      "x": 841,
      "y": 247
    },
    {
      "t": 52506,
      "e": 52317,
      "ty": 41,
      "x": 16031,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 52605,
      "e": 52416,
      "ty": 2,
      "x": 857,
      "y": 262
    },
    {
      "t": 52706,
      "e": 52517,
      "ty": 2,
      "x": 911,
      "y": 299
    },
    {
      "t": 52756,
      "e": 52567,
      "ty": 41,
      "x": 23632,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 52806,
      "e": 52617,
      "ty": 2,
      "x": 926,
      "y": 327
    },
    {
      "t": 52905,
      "e": 52716,
      "ty": 2,
      "x": 926,
      "y": 347
    },
    {
      "t": 53006,
      "e": 52817,
      "ty": 2,
      "x": 925,
      "y": 371
    },
    {
      "t": 53006,
      "e": 52817,
      "ty": 41,
      "x": 24581,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 53105,
      "e": 52916,
      "ty": 2,
      "x": 908,
      "y": 398
    },
    {
      "t": 53205,
      "e": 53016,
      "ty": 2,
      "x": 892,
      "y": 417
    },
    {
      "t": 53256,
      "e": 53067,
      "ty": 41,
      "x": 14614,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 53306,
      "e": 53117,
      "ty": 2,
      "x": 878,
      "y": 427
    },
    {
      "t": 53405,
      "e": 53216,
      "ty": 2,
      "x": 857,
      "y": 436
    },
    {
      "t": 53480,
      "e": 53291,
      "ty": 6,
      "x": 837,
      "y": 441,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53506,
      "e": 53317,
      "ty": 2,
      "x": 835,
      "y": 442
    },
    {
      "t": 53506,
      "e": 53317,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53606,
      "e": 53417,
      "ty": 2,
      "x": 833,
      "y": 444
    },
    {
      "t": 53749,
      "e": 53560,
      "ty": 3,
      "x": 833,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53750,
      "e": 53561,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53751,
      "e": 53562,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53754,
      "e": 53565,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53851,
      "e": 53662,
      "ty": 4,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53852,
      "e": 53663,
      "ty": 5,
      "x": 833,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53852,
      "e": 53663,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 54082,
      "e": 53893,
      "ty": 7,
      "x": 836,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 54105,
      "e": 53916,
      "ty": 2,
      "x": 843,
      "y": 454
    },
    {
      "t": 54205,
      "e": 54016,
      "ty": 2,
      "x": 877,
      "y": 481
    },
    {
      "t": 54255,
      "e": 54066,
      "ty": 41,
      "x": 65142,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 54305,
      "e": 54116,
      "ty": 2,
      "x": 901,
      "y": 511
    },
    {
      "t": 54405,
      "e": 54216,
      "ty": 2,
      "x": 904,
      "y": 518
    },
    {
      "t": 54507,
      "e": 54217,
      "ty": 41,
      "x": 19597,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 54605,
      "e": 54315,
      "ty": 2,
      "x": 905,
      "y": 523
    },
    {
      "t": 54705,
      "e": 54415,
      "ty": 2,
      "x": 906,
      "y": 526
    },
    {
      "t": 54755,
      "e": 54465,
      "ty": 41,
      "x": 20547,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 54805,
      "e": 54515,
      "ty": 2,
      "x": 911,
      "y": 547
    },
    {
      "t": 54906,
      "e": 54616,
      "ty": 2,
      "x": 913,
      "y": 573
    },
    {
      "t": 55005,
      "e": 54715,
      "ty": 2,
      "x": 907,
      "y": 605
    },
    {
      "t": 55005,
      "e": 54715,
      "ty": 41,
      "x": 20309,
      "y": 33178,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 55105,
      "e": 54815,
      "ty": 2,
      "x": 899,
      "y": 622
    },
    {
      "t": 55206,
      "e": 54916,
      "ty": 2,
      "x": 892,
      "y": 633
    },
    {
      "t": 55256,
      "e": 54966,
      "ty": 41,
      "x": 15088,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 55306,
      "e": 55016,
      "ty": 2,
      "x": 881,
      "y": 648
    },
    {
      "t": 55406,
      "e": 55116,
      "ty": 2,
      "x": 874,
      "y": 658
    },
    {
      "t": 55505,
      "e": 55215,
      "ty": 2,
      "x": 873,
      "y": 659
    },
    {
      "t": 55506,
      "e": 55216,
      "ty": 41,
      "x": 12240,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 55606,
      "e": 55316,
      "ty": 2,
      "x": 870,
      "y": 662
    },
    {
      "t": 55756,
      "e": 55466,
      "ty": 41,
      "x": 11528,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 55806,
      "e": 55516,
      "ty": 2,
      "x": 870,
      "y": 663
    },
    {
      "t": 57005,
      "e": 56715,
      "ty": 2,
      "x": 870,
      "y": 670
    },
    {
      "t": 57005,
      "e": 56715,
      "ty": 41,
      "x": 13043,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57105,
      "e": 56815,
      "ty": 2,
      "x": 868,
      "y": 672
    },
    {
      "t": 57204,
      "e": 56914,
      "ty": 2,
      "x": 859,
      "y": 676
    },
    {
      "t": 57255,
      "e": 56965,
      "ty": 41,
      "x": 9552,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57305,
      "e": 57015,
      "ty": 2,
      "x": 854,
      "y": 678
    },
    {
      "t": 57404,
      "e": 57114,
      "ty": 2,
      "x": 849,
      "y": 681
    },
    {
      "t": 57505,
      "e": 57215,
      "ty": 2,
      "x": 845,
      "y": 683
    },
    {
      "t": 57505,
      "e": 57215,
      "ty": 41,
      "x": 6330,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57605,
      "e": 57315,
      "ty": 2,
      "x": 844,
      "y": 690
    },
    {
      "t": 57705,
      "e": 57415,
      "ty": 2,
      "x": 845,
      "y": 697
    },
    {
      "t": 57755,
      "e": 57465,
      "ty": 41,
      "x": 6193,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57805,
      "e": 57515,
      "ty": 2,
      "x": 846,
      "y": 702
    },
    {
      "t": 57904,
      "e": 57614,
      "ty": 2,
      "x": 848,
      "y": 713
    },
    {
      "t": 58005,
      "e": 57715,
      "ty": 2,
      "x": 847,
      "y": 731
    },
    {
      "t": 58005,
      "e": 57715,
      "ty": 41,
      "x": 6419,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 58104,
      "e": 57814,
      "ty": 2,
      "x": 844,
      "y": 743
    },
    {
      "t": 58204,
      "e": 57914,
      "ty": 2,
      "x": 840,
      "y": 759
    },
    {
      "t": 58254,
      "e": 57964,
      "ty": 41,
      "x": 7751,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 58305,
      "e": 58015,
      "ty": 2,
      "x": 840,
      "y": 762
    },
    {
      "t": 58309,
      "e": 58019,
      "ty": 6,
      "x": 839,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 58364,
      "e": 58074,
      "ty": 7,
      "x": 838,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 58405,
      "e": 58115,
      "ty": 2,
      "x": 837,
      "y": 767
    },
    {
      "t": 58505,
      "e": 58215,
      "ty": 2,
      "x": 834,
      "y": 775
    },
    {
      "t": 58505,
      "e": 58215,
      "ty": 41,
      "x": 2985,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 58569,
      "e": 58216,
      "ty": 6,
      "x": 834,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 58605,
      "e": 58252,
      "ty": 2,
      "x": 834,
      "y": 784
    },
    {
      "t": 58701,
      "e": 58348,
      "ty": 7,
      "x": 834,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 58705,
      "e": 58352,
      "ty": 2,
      "x": 834,
      "y": 793
    },
    {
      "t": 58754,
      "e": 58401,
      "ty": 41,
      "x": 2985,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 58805,
      "e": 58452,
      "ty": 2,
      "x": 834,
      "y": 801
    },
    {
      "t": 58905,
      "e": 58552,
      "ty": 2,
      "x": 834,
      "y": 802
    },
    {
      "t": 59006,
      "e": 58653,
      "ty": 41,
      "x": 2985,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 59105,
      "e": 58752,
      "ty": 2,
      "x": 950,
      "y": 737
    },
    {
      "t": 59205,
      "e": 58852,
      "ty": 2,
      "x": 1068,
      "y": 700
    },
    {
      "t": 59255,
      "e": 58902,
      "ty": 41,
      "x": 62133,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 59404,
      "e": 59051,
      "ty": 2,
      "x": 1058,
      "y": 701
    },
    {
      "t": 59505,
      "e": 59152,
      "ty": 41,
      "x": 59613,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 59605,
      "e": 59252,
      "ty": 2,
      "x": 1051,
      "y": 702
    },
    {
      "t": 59705,
      "e": 59352,
      "ty": 2,
      "x": 1018,
      "y": 700
    },
    {
      "t": 59755,
      "e": 59402,
      "ty": 41,
      "x": 44998,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 59805,
      "e": 59452,
      "ty": 2,
      "x": 979,
      "y": 703
    },
    {
      "t": 59905,
      "e": 59552,
      "ty": 2,
      "x": 948,
      "y": 706
    },
    {
      "t": 60005,
      "e": 59652,
      "ty": 2,
      "x": 912,
      "y": 706
    },
    {
      "t": 60006,
      "e": 59653,
      "ty": 41,
      "x": 22824,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60105,
      "e": 59752,
      "ty": 2,
      "x": 888,
      "y": 706
    },
    {
      "t": 60205,
      "e": 59852,
      "ty": 2,
      "x": 858,
      "y": 706
    },
    {
      "t": 60253,
      "e": 59900,
      "ty": 6,
      "x": 838,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60255,
      "e": 59902,
      "ty": 41,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60305,
      "e": 59952,
      "ty": 2,
      "x": 833,
      "y": 706
    },
    {
      "t": 60505,
      "e": 60152,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60598,
      "e": 60245,
      "ty": 3,
      "x": 833,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60599,
      "e": 60246,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60599,
      "e": 60246,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60708,
      "e": 60355,
      "ty": 4,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60708,
      "e": 60355,
      "ty": 5,
      "x": 833,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60708,
      "e": 60355,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 61071,
      "e": 60718,
      "ty": 7,
      "x": 847,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61104,
      "e": 60751,
      "ty": 2,
      "x": 871,
      "y": 724
    },
    {
      "t": 61205,
      "e": 60852,
      "ty": 2,
      "x": 923,
      "y": 772
    },
    {
      "t": 61255,
      "e": 60902,
      "ty": 41,
      "x": 62464,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 61305,
      "e": 60952,
      "ty": 2,
      "x": 934,
      "y": 802
    },
    {
      "t": 61405,
      "e": 61052,
      "ty": 2,
      "x": 930,
      "y": 840
    },
    {
      "t": 61504,
      "e": 61151,
      "ty": 2,
      "x": 916,
      "y": 883
    },
    {
      "t": 61505,
      "e": 61152,
      "ty": 41,
      "x": 22445,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 61605,
      "e": 61252,
      "ty": 2,
      "x": 904,
      "y": 918
    },
    {
      "t": 61705,
      "e": 61352,
      "ty": 2,
      "x": 896,
      "y": 941
    },
    {
      "t": 61755,
      "e": 61402,
      "ty": 41,
      "x": 17461,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61805,
      "e": 61452,
      "ty": 2,
      "x": 895,
      "y": 942
    },
    {
      "t": 62004,
      "e": 61651,
      "ty": 2,
      "x": 894,
      "y": 921
    },
    {
      "t": 62005,
      "e": 61652,
      "ty": 41,
      "x": 17224,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 62105,
      "e": 61752,
      "ty": 2,
      "x": 894,
      "y": 917
    },
    {
      "t": 62205,
      "e": 61852,
      "ty": 2,
      "x": 894,
      "y": 911
    },
    {
      "t": 62255,
      "e": 61902,
      "ty": 41,
      "x": 17224,
      "y": 18148,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 63105,
      "e": 62752,
      "ty": 2,
      "x": 892,
      "y": 904
    },
    {
      "t": 63205,
      "e": 62852,
      "ty": 2,
      "x": 874,
      "y": 893
    },
    {
      "t": 63256,
      "e": 62903,
      "ty": 41,
      "x": 11766,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 63304,
      "e": 62951,
      "ty": 2,
      "x": 868,
      "y": 893
    },
    {
      "t": 63405,
      "e": 63052,
      "ty": 2,
      "x": 866,
      "y": 901
    },
    {
      "t": 63505,
      "e": 63152,
      "ty": 2,
      "x": 864,
      "y": 915
    },
    {
      "t": 63506,
      "e": 63153,
      "ty": 41,
      "x": 10104,
      "y": 20164,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 63605,
      "e": 63252,
      "ty": 2,
      "x": 862,
      "y": 927
    },
    {
      "t": 63705,
      "e": 63352,
      "ty": 2,
      "x": 858,
      "y": 933
    },
    {
      "t": 63755,
      "e": 63402,
      "ty": 41,
      "x": 33398,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 63805,
      "e": 63452,
      "ty": 2,
      "x": 843,
      "y": 944
    },
    {
      "t": 63904,
      "e": 63551,
      "ty": 2,
      "x": 833,
      "y": 953
    },
    {
      "t": 64005,
      "e": 63652,
      "ty": 2,
      "x": 832,
      "y": 955
    },
    {
      "t": 64005,
      "e": 63652,
      "ty": 41,
      "x": 8556,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64048,
      "e": 63654,
      "ty": 6,
      "x": 832,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64105,
      "e": 63711,
      "ty": 2,
      "x": 830,
      "y": 958
    },
    {
      "t": 64180,
      "e": 63786,
      "ty": 3,
      "x": 830,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64180,
      "e": 63786,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64180,
      "e": 63786,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64205,
      "e": 63811,
      "ty": 2,
      "x": 830,
      "y": 960
    },
    {
      "t": 64255,
      "e": 63861,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64305,
      "e": 63911,
      "ty": 2,
      "x": 830,
      "y": 963
    },
    {
      "t": 64308,
      "e": 63914,
      "ty": 4,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64308,
      "e": 63914,
      "ty": 5,
      "x": 830,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64308,
      "e": 63914,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 64340,
      "e": 63946,
      "ty": 7,
      "x": 832,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64405,
      "e": 64011,
      "ty": 2,
      "x": 842,
      "y": 978
    },
    {
      "t": 64473,
      "e": 64079,
      "ty": 6,
      "x": 855,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64505,
      "e": 64111,
      "ty": 2,
      "x": 861,
      "y": 1014
    },
    {
      "t": 64505,
      "e": 64111,
      "ty": 41,
      "x": 16275,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64605,
      "e": 64211,
      "ty": 2,
      "x": 868,
      "y": 1026
    },
    {
      "t": 64708,
      "e": 64314,
      "ty": 3,
      "x": 868,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64708,
      "e": 64314,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64708,
      "e": 64314,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64755,
      "e": 64361,
      "ty": 41,
      "x": 19882,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64812,
      "e": 64418,
      "ty": 4,
      "x": 19882,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64812,
      "e": 64418,
      "ty": 5,
      "x": 868,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64816,
      "e": 64422,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64817,
      "e": 64423,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64817,
      "e": 64423,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 64905,
      "e": 64511,
      "ty": 2,
      "x": 872,
      "y": 1026
    },
    {
      "t": 65005,
      "e": 64611,
      "ty": 41,
      "x": 29754,
      "y": 56394,
      "ta": "html > body"
    },
    {
      "t": 65705,
      "e": 65311,
      "ty": 2,
      "x": 876,
      "y": 1019
    },
    {
      "t": 65755,
      "e": 65361,
      "ty": 41,
      "x": 29960,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 65805,
      "e": 65411,
      "ty": 2,
      "x": 879,
      "y": 1004
    },
    {
      "t": 65905,
      "e": 65511,
      "ty": 2,
      "x": 879,
      "y": 999
    },
    {
      "t": 66005,
      "e": 65611,
      "ty": 2,
      "x": 880,
      "y": 992
    },
    {
      "t": 66005,
      "e": 65611,
      "ty": 41,
      "x": 30029,
      "y": 54510,
      "ta": "html > body"
    },
    {
      "t": 66105,
      "e": 65711,
      "ty": 2,
      "x": 881,
      "y": 989
    },
    {
      "t": 66136,
      "e": 65742,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 66255,
      "e": 65861,
      "ty": 41,
      "x": 28905,
      "y": 59739,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66405,
      "e": 66011,
      "ty": 2,
      "x": 881,
      "y": 984
    },
    {
      "t": 66505,
      "e": 66111,
      "ty": 2,
      "x": 878,
      "y": 971
    },
    {
      "t": 66506,
      "e": 66112,
      "ty": 41,
      "x": 28757,
      "y": 58493,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66606,
      "e": 66212,
      "ty": 2,
      "x": 877,
      "y": 964
    },
    {
      "t": 66755,
      "e": 66361,
      "ty": 41,
      "x": 28708,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66805,
      "e": 66411,
      "ty": 2,
      "x": 877,
      "y": 981
    },
    {
      "t": 67005,
      "e": 66611,
      "ty": 41,
      "x": 28708,
      "y": 59185,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 67405,
      "e": 67011,
      "ty": 2,
      "x": 877,
      "y": 983
    },
    {
      "t": 67505,
      "e": 67111,
      "ty": 2,
      "x": 881,
      "y": 991
    },
    {
      "t": 67506,
      "e": 67112,
      "ty": 41,
      "x": 28905,
      "y": 59878,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 67905,
      "e": 67511,
      "ty": 2,
      "x": 881,
      "y": 995
    },
    {
      "t": 68006,
      "e": 67612,
      "ty": 2,
      "x": 881,
      "y": 993
    },
    {
      "t": 68006,
      "e": 67612,
      "ty": 41,
      "x": 28905,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68405,
      "e": 68011,
      "ty": 2,
      "x": 882,
      "y": 990
    },
    {
      "t": 68505,
      "e": 68111,
      "ty": 2,
      "x": 883,
      "y": 987
    },
    {
      "t": 68505,
      "e": 68111,
      "ty": 41,
      "x": 29003,
      "y": 59601,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68805,
      "e": 68411,
      "ty": 2,
      "x": 885,
      "y": 984
    },
    {
      "t": 69005,
      "e": 68611,
      "ty": 2,
      "x": 886,
      "y": 983
    },
    {
      "t": 69005,
      "e": 68611,
      "ty": 41,
      "x": 29151,
      "y": 59324,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69105,
      "e": 68711,
      "ty": 2,
      "x": 886,
      "y": 982
    },
    {
      "t": 69255,
      "e": 68861,
      "ty": 41,
      "x": 29151,
      "y": 59255,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69405,
      "e": 69011,
      "ty": 2,
      "x": 886,
      "y": 981
    },
    {
      "t": 69505,
      "e": 69111,
      "ty": 2,
      "x": 890,
      "y": 978
    },
    {
      "t": 69505,
      "e": 69111,
      "ty": 41,
      "x": 29348,
      "y": 58978,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69605,
      "e": 69211,
      "ty": 2,
      "x": 891,
      "y": 970
    },
    {
      "t": 69705,
      "e": 69311,
      "ty": 2,
      "x": 908,
      "y": 955
    },
    {
      "t": 69756,
      "e": 69362,
      "ty": 41,
      "x": 30233,
      "y": 57385,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70005,
      "e": 69611,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 92505,
      "e": 74362,
      "ty": 2,
      "x": 910,
      "y": 956
    },
    {
      "t": 92505,
      "e": 74362,
      "ty": 41,
      "x": 30332,
      "y": 57454,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92605,
      "e": 74462,
      "ty": 2,
      "x": 909,
      "y": 965
    },
    {
      "t": 92705,
      "e": 74562,
      "ty": 2,
      "x": 909,
      "y": 980
    },
    {
      "t": 92755,
      "e": 74612,
      "ty": 41,
      "x": 30283,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92805,
      "e": 74662,
      "ty": 2,
      "x": 915,
      "y": 990
    },
    {
      "t": 92905,
      "e": 74762,
      "ty": 2,
      "x": 935,
      "y": 1011
    },
    {
      "t": 93005,
      "e": 74862,
      "ty": 2,
      "x": 943,
      "y": 1019
    },
    {
      "t": 93005,
      "e": 74862,
      "ty": 41,
      "x": 31955,
      "y": 61817,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93105,
      "e": 74962,
      "ty": 2,
      "x": 954,
      "y": 1026
    },
    {
      "t": 93205,
      "e": 75062,
      "ty": 2,
      "x": 969,
      "y": 1032
    },
    {
      "t": 93255,
      "e": 75112,
      "ty": 41,
      "x": 33431,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93306,
      "e": 75163,
      "ty": 2,
      "x": 973,
      "y": 1034
    },
    {
      "t": 93405,
      "e": 75262,
      "ty": 2,
      "x": 974,
      "y": 1034
    },
    {
      "t": 93505,
      "e": 75362,
      "ty": 2,
      "x": 977,
      "y": 1034
    },
    {
      "t": 93505,
      "e": 75362,
      "ty": 41,
      "x": 33628,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93605,
      "e": 75462,
      "ty": 2,
      "x": 982,
      "y": 1036
    },
    {
      "t": 93705,
      "e": 75562,
      "ty": 2,
      "x": 983,
      "y": 1037
    },
    {
      "t": 93755,
      "e": 75612,
      "ty": 41,
      "x": 33923,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93905,
      "e": 75762,
      "ty": 2,
      "x": 987,
      "y": 1038
    },
    {
      "t": 94005,
      "e": 75862,
      "ty": 2,
      "x": 989,
      "y": 1042
    },
    {
      "t": 94005,
      "e": 75862,
      "ty": 41,
      "x": 34218,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94105,
      "e": 75962,
      "ty": 2,
      "x": 991,
      "y": 1047
    },
    {
      "t": 94206,
      "e": 76063,
      "ty": 2,
      "x": 992,
      "y": 1051
    },
    {
      "t": 94255,
      "e": 76112,
      "ty": 41,
      "x": 34366,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94305,
      "e": 76162,
      "ty": 2,
      "x": 992,
      "y": 1055
    },
    {
      "t": 94405,
      "e": 76262,
      "ty": 2,
      "x": 990,
      "y": 1060
    },
    {
      "t": 94505,
      "e": 76362,
      "ty": 2,
      "x": 985,
      "y": 1065
    },
    {
      "t": 94506,
      "e": 76363,
      "ty": 41,
      "x": 34022,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94605,
      "e": 76462,
      "ty": 2,
      "x": 976,
      "y": 1067
    },
    {
      "t": 94705,
      "e": 76562,
      "ty": 2,
      "x": 971,
      "y": 1070
    },
    {
      "t": 94755,
      "e": 76612,
      "ty": 41,
      "x": 33185,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94805,
      "e": 76662,
      "ty": 6,
      "x": 965,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 94806,
      "e": 76663,
      "ty": 2,
      "x": 965,
      "y": 1072
    },
    {
      "t": 94906,
      "e": 76763,
      "ty": 2,
      "x": 941,
      "y": 1074
    },
    {
      "t": 95005,
      "e": 76862,
      "ty": 2,
      "x": 921,
      "y": 1075
    },
    {
      "t": 95005,
      "e": 76862,
      "ty": 41,
      "x": 6280,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 95405,
      "e": 77262,
      "ty": 2,
      "x": 920,
      "y": 1080
    },
    {
      "t": 95505,
      "e": 77362,
      "ty": 2,
      "x": 920,
      "y": 1086
    },
    {
      "t": 95505,
      "e": 77362,
      "ty": 41,
      "x": 5734,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 95606,
      "e": 77463,
      "ty": 2,
      "x": 922,
      "y": 1089
    },
    {
      "t": 95755,
      "e": 77612,
      "ty": 41,
      "x": 6826,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 95781,
      "e": 77638,
      "ty": 3,
      "x": 922,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 95782,
      "e": 77639,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95940,
      "e": 77797,
      "ty": 4,
      "x": 6826,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 95940,
      "e": 77797,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95941,
      "e": 77798,
      "ty": 5,
      "x": 922,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 95942,
      "e": 77799,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 96983,
      "e": 78840,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 97761,
      "e": 79618,
      "ty": 2,
      "x": 933,
      "y": 1085
    },
    {
      "t": 97761,
      "e": 79618,
      "ty": 41,
      "x": 31340,
      "y": 32877,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 98382,
      "e": 80239,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 101166, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 101172, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4483, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 106979, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 7872, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MIKE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 115859, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 6735, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 123681, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15735, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 140418, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 52233, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 194018, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1174,y:1013,t:1527268129701};\\\", \\\"{x:1177,y:998,t:1527268129708};\\\", \\\"{x:1186,y:934,t:1527268129725};\\\", \\\"{x:1195,y:900,t:1527268129741};\\\", \\\"{x:1211,y:876,t:1527268129758};\\\", \\\"{x:1226,y:855,t:1527268129775};\\\", \\\"{x:1241,y:840,t:1527268129792};\\\", \\\"{x:1255,y:826,t:1527268129808};\\\", \\\"{x:1265,y:816,t:1527268129825};\\\", \\\"{x:1269,y:807,t:1527268129842};\\\", \\\"{x:1270,y:799,t:1527268129858};\\\", \\\"{x:1270,y:794,t:1527268129876};\\\", \\\"{x:1271,y:793,t:1527268129995};\\\", \\\"{x:1271,y:794,t:1527268130008};\\\", \\\"{x:1271,y:799,t:1527268130025};\\\", \\\"{x:1271,y:807,t:1527268130041};\\\", \\\"{x:1271,y:815,t:1527268130058};\\\", \\\"{x:1272,y:836,t:1527268130074};\\\", \\\"{x:1273,y:847,t:1527268130091};\\\", \\\"{x:1274,y:852,t:1527268130108};\\\", \\\"{x:1276,y:859,t:1527268130125};\\\", \\\"{x:1278,y:863,t:1527268130141};\\\", \\\"{x:1278,y:866,t:1527268130158};\\\", \\\"{x:1279,y:867,t:1527268130175};\\\", \\\"{x:1280,y:867,t:1527268130316};\\\", \\\"{x:1280,y:864,t:1527268130325};\\\", \\\"{x:1280,y:859,t:1527268130342};\\\", \\\"{x:1280,y:853,t:1527268130358};\\\", \\\"{x:1280,y:849,t:1527268130375};\\\", \\\"{x:1280,y:848,t:1527268130392};\\\", \\\"{x:1280,y:846,t:1527268130408};\\\", \\\"{x:1280,y:844,t:1527268130426};\\\", \\\"{x:1280,y:843,t:1527268130443};\\\", \\\"{x:1280,y:842,t:1527268130476};\\\", \\\"{x:1279,y:841,t:1527268130491};\\\", \\\"{x:1279,y:840,t:1527268130509};\\\", \\\"{x:1279,y:839,t:1527268130526};\\\", \\\"{x:1279,y:837,t:1527268130543};\\\", \\\"{x:1279,y:835,t:1527268130561};\\\", \\\"{x:1278,y:833,t:1527268130574};\\\", \\\"{x:1278,y:830,t:1527268130591};\\\", \\\"{x:1277,y:828,t:1527268130608};\\\", \\\"{x:1277,y:826,t:1527268130627};\\\", \\\"{x:1279,y:826,t:1527268137030};\\\", \\\"{x:1280,y:826,t:1527268137046};\\\", \\\"{x:1282,y:827,t:1527268137062};\\\", \\\"{x:1283,y:828,t:1527268137078};\\\", \\\"{x:1283,y:829,t:1527268137102};\\\", \\\"{x:1283,y:830,t:1527268137116};\\\", \\\"{x:1268,y:831,t:1527268137134};\\\", \\\"{x:1245,y:831,t:1527268137149};\\\", \\\"{x:1212,y:831,t:1527268137166};\\\", \\\"{x:1188,y:831,t:1527268137184};\\\", \\\"{x:1166,y:831,t:1527268137200};\\\", \\\"{x:1141,y:828,t:1527268137217};\\\", \\\"{x:1114,y:824,t:1527268137233};\\\", \\\"{x:1082,y:816,t:1527268137249};\\\", \\\"{x:1052,y:809,t:1527268137267};\\\", \\\"{x:1013,y:798,t:1527268137283};\\\", \\\"{x:971,y:788,t:1527268137300};\\\", \\\"{x:932,y:776,t:1527268137316};\\\", \\\"{x:906,y:770,t:1527268137334};\\\", \\\"{x:875,y:760,t:1527268137350};\\\", \\\"{x:859,y:754,t:1527268137366};\\\", \\\"{x:851,y:753,t:1527268137384};\\\", \\\"{x:841,y:751,t:1527268137400};\\\", \\\"{x:831,y:749,t:1527268137417};\\\", \\\"{x:818,y:745,t:1527268137433};\\\", \\\"{x:797,y:741,t:1527268137451};\\\", \\\"{x:772,y:733,t:1527268137467};\\\", \\\"{x:735,y:723,t:1527268137484};\\\", \\\"{x:680,y:708,t:1527268137501};\\\", \\\"{x:618,y:689,t:1527268137517};\\\", \\\"{x:554,y:668,t:1527268137534};\\\", \\\"{x:485,y:644,t:1527268137553};\\\", \\\"{x:454,y:630,t:1527268137566};\\\", \\\"{x:432,y:615,t:1527268137584};\\\", \\\"{x:413,y:600,t:1527268137603};\\\", \\\"{x:394,y:587,t:1527268137620};\\\", \\\"{x:379,y:569,t:1527268137637};\\\", \\\"{x:365,y:556,t:1527268137653};\\\", \\\"{x:345,y:536,t:1527268137670};\\\", \\\"{x:338,y:528,t:1527268137686};\\\", \\\"{x:337,y:527,t:1527268137703};\\\", \\\"{x:336,y:523,t:1527268137720};\\\", \\\"{x:336,y:521,t:1527268137737};\\\", \\\"{x:336,y:519,t:1527268137753};\\\", \\\"{x:336,y:518,t:1527268137770};\\\", \\\"{x:336,y:514,t:1527268137787};\\\", \\\"{x:340,y:513,t:1527268137804};\\\", \\\"{x:344,y:511,t:1527268137820};\\\", \\\"{x:346,y:511,t:1527268137837};\\\", \\\"{x:347,y:511,t:1527268137862};\\\", \\\"{x:349,y:511,t:1527268137933};\\\", \\\"{x:351,y:511,t:1527268137950};\\\", \\\"{x:353,y:511,t:1527268137958};\\\", \\\"{x:355,y:511,t:1527268137974};\\\", \\\"{x:356,y:511,t:1527268137990};\\\", \\\"{x:357,y:510,t:1527268138004};\\\", \\\"{x:359,y:510,t:1527268138021};\\\", \\\"{x:362,y:509,t:1527268138037};\\\", \\\"{x:367,y:508,t:1527268138054};\\\", \\\"{x:372,y:507,t:1527268138071};\\\", \\\"{x:373,y:507,t:1527268138087};\\\", \\\"{x:375,y:507,t:1527268138104};\\\", \\\"{x:376,y:507,t:1527268138121};\\\", \\\"{x:376,y:506,t:1527268138150};\\\", \\\"{x:378,y:506,t:1527268138270};\\\", \\\"{x:378,y:506,t:1527268138273};\\\", \\\"{x:387,y:507,t:1527268138289};\\\", \\\"{x:388,y:507,t:1527268138310};\\\", \\\"{x:389,y:508,t:1527268138321};\\\", \\\"{x:396,y:511,t:1527268138339};\\\", \\\"{x:399,y:512,t:1527268138355};\\\", \\\"{x:401,y:513,t:1527268138511};\\\", \\\"{x:404,y:516,t:1527268138520};\\\", \\\"{x:409,y:520,t:1527268138536};\\\", \\\"{x:415,y:525,t:1527268138554};\\\", \\\"{x:416,y:526,t:1527268138571};\\\", \\\"{x:416,y:527,t:1527268138586};\\\", \\\"{x:416,y:528,t:1527268138655};\\\", \\\"{x:414,y:528,t:1527268138671};\\\", \\\"{x:409,y:531,t:1527268138686};\\\", \\\"{x:404,y:532,t:1527268138704};\\\", \\\"{x:401,y:532,t:1527268138720};\\\", \\\"{x:397,y:532,t:1527268138738};\\\", \\\"{x:395,y:534,t:1527268138754};\\\", \\\"{x:394,y:534,t:1527268138771};\\\", \\\"{x:393,y:534,t:1527268138788};\\\", \\\"{x:392,y:534,t:1527268138830};\\\", \\\"{x:391,y:534,t:1527268138846};\\\", \\\"{x:390,y:534,t:1527268138854};\\\", \\\"{x:389,y:534,t:1527268139007};\\\", \\\"{x:389,y:532,t:1527268139040};\\\", \\\"{x:389,y:531,t:1527268139061};\\\", \\\"{x:389,y:529,t:1527268139086};\\\", \\\"{x:389,y:528,t:1527268139109};\\\", \\\"{x:389,y:526,t:1527268139150};\\\", \\\"{x:389,y:525,t:1527268139182};\\\", \\\"{x:389,y:524,t:1527268139198};\\\", \\\"{x:389,y:523,t:1527268139214};\\\", \\\"{x:390,y:522,t:1527268139398};\\\", \\\"{x:392,y:520,t:1527268139405};\\\", \\\"{x:393,y:520,t:1527268139421};\\\", \\\"{x:396,y:519,t:1527268139438};\\\", \\\"{x:397,y:519,t:1527268139687};\\\", \\\"{x:399,y:519,t:1527268139696};\\\", \\\"{x:407,y:521,t:1527268139705};\\\", \\\"{x:421,y:532,t:1527268139722};\\\", \\\"{x:437,y:545,t:1527268139739};\\\", \\\"{x:458,y:563,t:1527268139755};\\\", \\\"{x:481,y:582,t:1527268139773};\\\", \\\"{x:502,y:607,t:1527268139789};\\\", \\\"{x:511,y:619,t:1527268139806};\\\", \\\"{x:515,y:626,t:1527268139823};\\\", \\\"{x:518,y:640,t:1527268139838};\\\", \\\"{x:521,y:648,t:1527268139855};\\\", \\\"{x:525,y:661,t:1527268139872};\\\", \\\"{x:530,y:672,t:1527268139888};\\\", \\\"{x:532,y:682,t:1527268139905};\\\", \\\"{x:536,y:689,t:1527268139922};\\\", \\\"{x:538,y:695,t:1527268139938};\\\", \\\"{x:539,y:697,t:1527268139955};\\\", \\\"{x:539,y:699,t:1527268139972};\\\", \\\"{x:539,y:700,t:1527268139988};\\\", \\\"{x:539,y:701,t:1527268140006};\\\", \\\"{x:539,y:702,t:1527268140022};\\\", \\\"{x:539,y:703,t:1527268140038};\\\", \\\"{x:539,y:705,t:1527268140056};\\\", \\\"{x:539,y:706,t:1527268140073};\\\", \\\"{x:539,y:707,t:1527268140094};\\\", \\\"{x:539,y:708,t:1527268140105};\\\", \\\"{x:539,y:709,t:1527268141117};\\\" ] }, { \\\"rt\\\": 29352, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 224698, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-D -D -E -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:710,t:1527268158631};\\\", \\\"{x:553,y:710,t:1527268158642};\\\", \\\"{x:583,y:710,t:1527268158654};\\\", \\\"{x:624,y:716,t:1527268158670};\\\", \\\"{x:671,y:726,t:1527268158686};\\\", \\\"{x:718,y:738,t:1527268158703};\\\", \\\"{x:751,y:747,t:1527268158721};\\\", \\\"{x:785,y:758,t:1527268158737};\\\", \\\"{x:823,y:770,t:1527268158754};\\\", \\\"{x:859,y:779,t:1527268158771};\\\", \\\"{x:902,y:793,t:1527268158787};\\\", \\\"{x:942,y:801,t:1527268158804};\\\", \\\"{x:971,y:812,t:1527268158821};\\\", \\\"{x:1011,y:824,t:1527268158838};\\\", \\\"{x:1037,y:831,t:1527268158853};\\\", \\\"{x:1059,y:836,t:1527268158871};\\\", \\\"{x:1084,y:842,t:1527268158889};\\\", \\\"{x:1110,y:849,t:1527268158904};\\\", \\\"{x:1133,y:856,t:1527268158921};\\\", \\\"{x:1153,y:862,t:1527268158938};\\\", \\\"{x:1178,y:868,t:1527268158954};\\\", \\\"{x:1204,y:874,t:1527268158971};\\\", \\\"{x:1229,y:881,t:1527268158988};\\\", \\\"{x:1257,y:889,t:1527268159004};\\\", \\\"{x:1285,y:897,t:1527268159021};\\\", \\\"{x:1321,y:906,t:1527268159038};\\\", \\\"{x:1348,y:916,t:1527268159054};\\\", \\\"{x:1372,y:920,t:1527268159071};\\\", \\\"{x:1394,y:923,t:1527268159088};\\\", \\\"{x:1413,y:927,t:1527268159103};\\\", \\\"{x:1428,y:929,t:1527268159120};\\\", \\\"{x:1444,y:932,t:1527268159138};\\\", \\\"{x:1457,y:933,t:1527268159155};\\\", \\\"{x:1468,y:936,t:1527268159171};\\\", \\\"{x:1478,y:938,t:1527268159188};\\\", \\\"{x:1490,y:938,t:1527268159204};\\\", \\\"{x:1499,y:941,t:1527268159221};\\\", \\\"{x:1512,y:942,t:1527268159237};\\\", \\\"{x:1523,y:943,t:1527268159255};\\\", \\\"{x:1536,y:946,t:1527268159271};\\\", \\\"{x:1547,y:948,t:1527268159288};\\\", \\\"{x:1557,y:951,t:1527268159305};\\\", \\\"{x:1571,y:952,t:1527268159321};\\\", \\\"{x:1585,y:955,t:1527268159338};\\\", \\\"{x:1595,y:956,t:1527268159355};\\\", \\\"{x:1604,y:956,t:1527268159371};\\\", \\\"{x:1612,y:956,t:1527268159388};\\\", \\\"{x:1619,y:956,t:1527268159405};\\\", \\\"{x:1624,y:956,t:1527268159422};\\\", \\\"{x:1631,y:956,t:1527268159438};\\\", \\\"{x:1637,y:956,t:1527268159455};\\\", \\\"{x:1645,y:956,t:1527268159471};\\\", \\\"{x:1655,y:957,t:1527268159488};\\\", \\\"{x:1664,y:957,t:1527268159505};\\\", \\\"{x:1671,y:957,t:1527268159521};\\\", \\\"{x:1675,y:957,t:1527268159538};\\\", \\\"{x:1679,y:957,t:1527268159556};\\\", \\\"{x:1680,y:957,t:1527268159571};\\\", \\\"{x:1682,y:957,t:1527268159588};\\\", \\\"{x:1684,y:957,t:1527268159605};\\\", \\\"{x:1686,y:957,t:1527268159621};\\\", \\\"{x:1689,y:957,t:1527268159638};\\\", \\\"{x:1686,y:957,t:1527268159750};\\\", \\\"{x:1681,y:957,t:1527268159758};\\\", \\\"{x:1676,y:957,t:1527268159772};\\\", \\\"{x:1666,y:956,t:1527268159788};\\\", \\\"{x:1657,y:954,t:1527268159805};\\\", \\\"{x:1643,y:951,t:1527268159822};\\\", \\\"{x:1635,y:950,t:1527268159838};\\\", \\\"{x:1625,y:949,t:1527268159855};\\\", \\\"{x:1610,y:946,t:1527268159873};\\\", \\\"{x:1595,y:945,t:1527268159888};\\\", \\\"{x:1579,y:943,t:1527268159906};\\\", \\\"{x:1571,y:943,t:1527268159922};\\\", \\\"{x:1564,y:943,t:1527268159939};\\\", \\\"{x:1560,y:943,t:1527268159955};\\\", \\\"{x:1558,y:943,t:1527268159973};\\\", \\\"{x:1556,y:943,t:1527268159988};\\\", \\\"{x:1553,y:943,t:1527268160005};\\\", \\\"{x:1547,y:942,t:1527268160023};\\\", \\\"{x:1542,y:942,t:1527268160039};\\\", \\\"{x:1538,y:942,t:1527268160056};\\\", \\\"{x:1535,y:942,t:1527268160073};\\\", \\\"{x:1533,y:942,t:1527268160088};\\\", \\\"{x:1532,y:942,t:1527268160105};\\\", \\\"{x:1530,y:942,t:1527268160123};\\\", \\\"{x:1527,y:941,t:1527268160139};\\\", \\\"{x:1526,y:941,t:1527268160155};\\\", \\\"{x:1523,y:941,t:1527268160172};\\\", \\\"{x:1520,y:941,t:1527268160189};\\\", \\\"{x:1514,y:939,t:1527268160206};\\\", \\\"{x:1506,y:938,t:1527268160222};\\\", \\\"{x:1501,y:938,t:1527268160240};\\\", \\\"{x:1496,y:936,t:1527268160255};\\\", \\\"{x:1489,y:936,t:1527268160272};\\\", \\\"{x:1484,y:934,t:1527268160290};\\\", \\\"{x:1478,y:933,t:1527268160305};\\\", \\\"{x:1473,y:933,t:1527268160322};\\\", \\\"{x:1470,y:933,t:1527268160340};\\\", \\\"{x:1469,y:933,t:1527268160356};\\\", \\\"{x:1466,y:932,t:1527268160373};\\\", \\\"{x:1464,y:932,t:1527268160390};\\\", \\\"{x:1463,y:932,t:1527268160407};\\\", \\\"{x:1461,y:931,t:1527268160422};\\\", \\\"{x:1460,y:931,t:1527268160463};\\\", \\\"{x:1458,y:931,t:1527268160502};\\\", \\\"{x:1457,y:930,t:1527268160519};\\\", \\\"{x:1456,y:930,t:1527268160527};\\\", \\\"{x:1453,y:930,t:1527268160540};\\\", \\\"{x:1451,y:929,t:1527268160556};\\\", \\\"{x:1450,y:929,t:1527268160573};\\\", \\\"{x:1448,y:929,t:1527268160589};\\\", \\\"{x:1447,y:929,t:1527268160614};\\\", \\\"{x:1451,y:929,t:1527268160822};\\\", \\\"{x:1461,y:929,t:1527268160840};\\\", \\\"{x:1474,y:925,t:1527268160857};\\\", \\\"{x:1485,y:922,t:1527268160873};\\\", \\\"{x:1493,y:919,t:1527268160890};\\\", \\\"{x:1497,y:918,t:1527268160907};\\\", \\\"{x:1502,y:917,t:1527268160922};\\\", \\\"{x:1505,y:916,t:1527268160940};\\\", \\\"{x:1511,y:913,t:1527268160956};\\\", \\\"{x:1521,y:904,t:1527268160973};\\\", \\\"{x:1530,y:894,t:1527268160990};\\\", \\\"{x:1543,y:875,t:1527268161006};\\\", \\\"{x:1555,y:856,t:1527268161023};\\\", \\\"{x:1570,y:836,t:1527268161039};\\\", \\\"{x:1579,y:811,t:1527268161057};\\\", \\\"{x:1591,y:777,t:1527268161073};\\\", \\\"{x:1598,y:734,t:1527268161090};\\\", \\\"{x:1607,y:667,t:1527268161106};\\\", \\\"{x:1607,y:612,t:1527268161124};\\\", \\\"{x:1593,y:554,t:1527268161140};\\\", \\\"{x:1582,y:520,t:1527268161157};\\\", \\\"{x:1566,y:479,t:1527268161174};\\\", \\\"{x:1561,y:471,t:1527268161190};\\\", \\\"{x:1547,y:448,t:1527268161206};\\\", \\\"{x:1546,y:444,t:1527268161223};\\\", \\\"{x:1544,y:442,t:1527268161240};\\\", \\\"{x:1544,y:440,t:1527268161256};\\\", \\\"{x:1545,y:438,t:1527268161273};\\\", \\\"{x:1548,y:435,t:1527268161289};\\\", \\\"{x:1555,y:433,t:1527268161307};\\\", \\\"{x:1568,y:430,t:1527268161324};\\\", \\\"{x:1582,y:424,t:1527268161340};\\\", \\\"{x:1595,y:421,t:1527268161356};\\\", \\\"{x:1604,y:417,t:1527268161374};\\\", \\\"{x:1605,y:417,t:1527268161390};\\\", \\\"{x:1607,y:417,t:1527268161406};\\\", \\\"{x:1608,y:417,t:1527268161424};\\\", \\\"{x:1610,y:416,t:1527268161441};\\\", \\\"{x:1612,y:416,t:1527268161457};\\\", \\\"{x:1614,y:415,t:1527268161473};\\\", \\\"{x:1616,y:414,t:1527268161490};\\\", \\\"{x:1617,y:414,t:1527268161506};\\\", \\\"{x:1618,y:413,t:1527268161525};\\\", \\\"{x:1618,y:414,t:1527268161727};\\\", \\\"{x:1618,y:417,t:1527268161742};\\\", \\\"{x:1618,y:418,t:1527268161757};\\\", \\\"{x:1618,y:421,t:1527268161774};\\\", \\\"{x:1618,y:425,t:1527268161791};\\\", \\\"{x:1618,y:428,t:1527268161806};\\\", \\\"{x:1618,y:432,t:1527268161823};\\\", \\\"{x:1618,y:437,t:1527268161841};\\\", \\\"{x:1621,y:442,t:1527268161856};\\\", \\\"{x:1621,y:445,t:1527268161873};\\\", \\\"{x:1622,y:449,t:1527268161890};\\\", \\\"{x:1623,y:453,t:1527268161907};\\\", \\\"{x:1625,y:456,t:1527268161923};\\\", \\\"{x:1626,y:460,t:1527268161940};\\\", \\\"{x:1627,y:464,t:1527268161958};\\\", \\\"{x:1628,y:468,t:1527268161974};\\\", \\\"{x:1629,y:475,t:1527268161990};\\\", \\\"{x:1629,y:478,t:1527268162007};\\\", \\\"{x:1629,y:482,t:1527268162023};\\\", \\\"{x:1631,y:485,t:1527268162040};\\\", \\\"{x:1631,y:489,t:1527268162057};\\\", \\\"{x:1631,y:492,t:1527268162073};\\\", \\\"{x:1631,y:496,t:1527268162090};\\\", \\\"{x:1631,y:500,t:1527268162107};\\\", \\\"{x:1631,y:506,t:1527268162123};\\\", \\\"{x:1631,y:511,t:1527268162140};\\\", \\\"{x:1631,y:516,t:1527268162157};\\\", \\\"{x:1631,y:521,t:1527268162174};\\\", \\\"{x:1631,y:529,t:1527268162190};\\\", \\\"{x:1631,y:534,t:1527268162207};\\\", \\\"{x:1631,y:536,t:1527268162223};\\\", \\\"{x:1631,y:539,t:1527268162241};\\\", \\\"{x:1631,y:540,t:1527268162258};\\\", \\\"{x:1631,y:541,t:1527268162273};\\\", \\\"{x:1631,y:543,t:1527268162290};\\\", \\\"{x:1631,y:544,t:1527268162334};\\\", \\\"{x:1630,y:545,t:1527268162342};\\\", \\\"{x:1630,y:547,t:1527268162358};\\\", \\\"{x:1628,y:549,t:1527268162374};\\\", \\\"{x:1628,y:550,t:1527268162391};\\\", \\\"{x:1627,y:551,t:1527268162407};\\\", \\\"{x:1624,y:554,t:1527268162424};\\\", \\\"{x:1623,y:556,t:1527268162446};\\\", \\\"{x:1622,y:557,t:1527268162479};\\\", \\\"{x:1621,y:557,t:1527268162494};\\\", \\\"{x:1621,y:558,t:1527268162511};\\\", \\\"{x:1620,y:558,t:1527268162534};\\\", \\\"{x:1620,y:559,t:1527268162542};\\\", \\\"{x:1619,y:560,t:1527268162559};\\\", \\\"{x:1618,y:560,t:1527268162598};\\\", \\\"{x:1615,y:561,t:1527268162630};\\\", \\\"{x:1615,y:562,t:1527268162646};\\\", \\\"{x:1614,y:562,t:1527268162662};\\\", \\\"{x:1613,y:562,t:1527268162678};\\\", \\\"{x:1612,y:563,t:1527268162690};\\\", \\\"{x:1610,y:565,t:1527268162726};\\\", \\\"{x:1610,y:564,t:1527268164494};\\\", \\\"{x:1610,y:562,t:1527268164518};\\\", \\\"{x:1610,y:559,t:1527268169349};\\\", \\\"{x:1611,y:551,t:1527268169363};\\\", \\\"{x:1619,y:532,t:1527268169380};\\\", \\\"{x:1625,y:511,t:1527268169397};\\\", \\\"{x:1630,y:489,t:1527268169413};\\\", \\\"{x:1630,y:465,t:1527268169430};\\\", \\\"{x:1630,y:458,t:1527268169446};\\\", \\\"{x:1628,y:454,t:1527268169463};\\\", \\\"{x:1627,y:451,t:1527268169480};\\\", \\\"{x:1626,y:448,t:1527268169497};\\\", \\\"{x:1623,y:443,t:1527268169513};\\\", \\\"{x:1623,y:441,t:1527268169530};\\\", \\\"{x:1622,y:438,t:1527268169547};\\\", \\\"{x:1621,y:437,t:1527268169563};\\\", \\\"{x:1620,y:437,t:1527268169806};\\\", \\\"{x:1619,y:437,t:1527268170134};\\\", \\\"{x:1618,y:437,t:1527268170271};\\\", \\\"{x:1617,y:437,t:1527268170281};\\\", \\\"{x:1616,y:437,t:1527268170297};\\\", \\\"{x:1613,y:436,t:1527268170314};\\\", \\\"{x:1610,y:436,t:1527268170331};\\\", \\\"{x:1606,y:435,t:1527268170347};\\\", \\\"{x:1595,y:435,t:1527268170364};\\\", \\\"{x:1577,y:435,t:1527268170381};\\\", \\\"{x:1555,y:434,t:1527268170397};\\\", \\\"{x:1526,y:432,t:1527268170414};\\\", \\\"{x:1507,y:431,t:1527268170431};\\\", \\\"{x:1490,y:429,t:1527268170447};\\\", \\\"{x:1482,y:428,t:1527268170464};\\\", \\\"{x:1474,y:428,t:1527268170482};\\\", \\\"{x:1467,y:427,t:1527268170497};\\\", \\\"{x:1457,y:425,t:1527268170514};\\\", \\\"{x:1447,y:423,t:1527268170531};\\\", \\\"{x:1431,y:423,t:1527268170548};\\\", \\\"{x:1416,y:420,t:1527268170564};\\\", \\\"{x:1403,y:418,t:1527268170581};\\\", \\\"{x:1385,y:415,t:1527268170597};\\\", \\\"{x:1380,y:415,t:1527268170613};\\\", \\\"{x:1379,y:415,t:1527268170630};\\\", \\\"{x:1380,y:414,t:1527268173918};\\\", \\\"{x:1383,y:414,t:1527268173933};\\\", \\\"{x:1386,y:413,t:1527268173949};\\\", \\\"{x:1389,y:412,t:1527268173967};\\\", \\\"{x:1389,y:411,t:1527268173983};\\\", \\\"{x:1390,y:411,t:1527268174000};\\\", \\\"{x:1392,y:411,t:1527268174017};\\\", \\\"{x:1393,y:411,t:1527268174032};\\\", \\\"{x:1394,y:411,t:1527268174050};\\\", \\\"{x:1396,y:410,t:1527268174067};\\\", \\\"{x:1397,y:410,t:1527268174083};\\\", \\\"{x:1398,y:410,t:1527268174102};\\\", \\\"{x:1399,y:410,t:1527268174159};\\\", \\\"{x:1407,y:410,t:1527268175886};\\\", \\\"{x:1426,y:410,t:1527268175901};\\\", \\\"{x:1533,y:426,t:1527268175918};\\\", \\\"{x:1616,y:437,t:1527268175935};\\\", \\\"{x:1675,y:445,t:1527268175952};\\\", \\\"{x:1714,y:447,t:1527268175968};\\\", \\\"{x:1726,y:447,t:1527268175985};\\\", \\\"{x:1727,y:447,t:1527268176002};\\\", \\\"{x:1723,y:447,t:1527268176135};\\\", \\\"{x:1713,y:447,t:1527268176152};\\\", \\\"{x:1707,y:446,t:1527268176168};\\\", \\\"{x:1703,y:446,t:1527268176185};\\\", \\\"{x:1701,y:446,t:1527268176202};\\\", \\\"{x:1697,y:445,t:1527268176218};\\\", \\\"{x:1693,y:445,t:1527268176235};\\\", \\\"{x:1689,y:445,t:1527268176252};\\\", \\\"{x:1685,y:445,t:1527268176268};\\\", \\\"{x:1681,y:446,t:1527268176286};\\\", \\\"{x:1677,y:452,t:1527268176302};\\\", \\\"{x:1673,y:463,t:1527268176319};\\\", \\\"{x:1669,y:478,t:1527268176335};\\\", \\\"{x:1663,y:499,t:1527268176352};\\\", \\\"{x:1656,y:526,t:1527268176369};\\\", \\\"{x:1647,y:557,t:1527268176386};\\\", \\\"{x:1641,y:582,t:1527268176402};\\\", \\\"{x:1636,y:613,t:1527268176419};\\\", \\\"{x:1636,y:632,t:1527268176435};\\\", \\\"{x:1636,y:641,t:1527268176452};\\\", \\\"{x:1637,y:644,t:1527268176469};\\\", \\\"{x:1638,y:644,t:1527268176485};\\\", \\\"{x:1638,y:638,t:1527268176534};\\\", \\\"{x:1639,y:625,t:1527268176552};\\\", \\\"{x:1640,y:613,t:1527268176569};\\\", \\\"{x:1642,y:600,t:1527268176584};\\\", \\\"{x:1642,y:585,t:1527268176602};\\\", \\\"{x:1641,y:572,t:1527268176618};\\\", \\\"{x:1640,y:567,t:1527268176635};\\\", \\\"{x:1638,y:561,t:1527268176652};\\\", \\\"{x:1638,y:560,t:1527268176668};\\\", \\\"{x:1638,y:559,t:1527268176684};\\\", \\\"{x:1637,y:559,t:1527268176782};\\\", \\\"{x:1635,y:559,t:1527268176789};\\\", \\\"{x:1633,y:558,t:1527268176802};\\\", \\\"{x:1630,y:557,t:1527268176818};\\\", \\\"{x:1627,y:556,t:1527268176836};\\\", \\\"{x:1626,y:556,t:1527268176854};\\\", \\\"{x:1625,y:556,t:1527268176869};\\\", \\\"{x:1624,y:556,t:1527268176982};\\\", \\\"{x:1623,y:556,t:1527268176990};\\\", \\\"{x:1622,y:556,t:1527268177002};\\\", \\\"{x:1621,y:556,t:1527268177018};\\\", \\\"{x:1617,y:557,t:1527268177036};\\\", \\\"{x:1615,y:558,t:1527268177052};\\\", \\\"{x:1612,y:558,t:1527268177069};\\\", \\\"{x:1611,y:559,t:1527268177085};\\\", \\\"{x:1611,y:561,t:1527268177742};\\\", \\\"{x:1611,y:562,t:1527268177754};\\\", \\\"{x:1611,y:566,t:1527268177770};\\\", \\\"{x:1611,y:568,t:1527268177787};\\\", \\\"{x:1609,y:568,t:1527268178703};\\\", \\\"{x:1595,y:568,t:1527268178710};\\\", \\\"{x:1574,y:564,t:1527268178720};\\\", \\\"{x:1507,y:557,t:1527268178737};\\\", \\\"{x:1438,y:547,t:1527268178754};\\\", \\\"{x:1341,y:537,t:1527268178770};\\\", \\\"{x:1241,y:519,t:1527268178787};\\\", \\\"{x:1101,y:493,t:1527268178804};\\\", \\\"{x:958,y:459,t:1527268178820};\\\", \\\"{x:818,y:422,t:1527268178838};\\\", \\\"{x:646,y:387,t:1527268178853};\\\", \\\"{x:548,y:372,t:1527268178870};\\\", \\\"{x:462,y:360,t:1527268178887};\\\", \\\"{x:396,y:354,t:1527268178904};\\\", \\\"{x:345,y:352,t:1527268178919};\\\", \\\"{x:317,y:352,t:1527268178937};\\\", \\\"{x:288,y:358,t:1527268178954};\\\", \\\"{x:266,y:366,t:1527268178971};\\\", \\\"{x:247,y:375,t:1527268178987};\\\", \\\"{x:233,y:386,t:1527268179004};\\\", \\\"{x:227,y:395,t:1527268179021};\\\", \\\"{x:225,y:407,t:1527268179037};\\\", \\\"{x:225,y:425,t:1527268179054};\\\", \\\"{x:239,y:438,t:1527268179071};\\\", \\\"{x:261,y:448,t:1527268179087};\\\", \\\"{x:290,y:459,t:1527268179104};\\\", \\\"{x:311,y:469,t:1527268179122};\\\", \\\"{x:331,y:477,t:1527268179137};\\\", \\\"{x:337,y:481,t:1527268179154};\\\", \\\"{x:339,y:482,t:1527268179171};\\\", \\\"{x:340,y:483,t:1527268179187};\\\", \\\"{x:340,y:485,t:1527268179206};\\\", \\\"{x:339,y:491,t:1527268179222};\\\", \\\"{x:339,y:494,t:1527268179237};\\\", \\\"{x:337,y:503,t:1527268179254};\\\", \\\"{x:337,y:511,t:1527268179273};\\\", \\\"{x:335,y:515,t:1527268179287};\\\", \\\"{x:334,y:521,t:1527268179304};\\\", \\\"{x:334,y:528,t:1527268179321};\\\", \\\"{x:334,y:534,t:1527268179337};\\\", \\\"{x:334,y:537,t:1527268179355};\\\", \\\"{x:333,y:540,t:1527268179370};\\\", \\\"{x:331,y:544,t:1527268179388};\\\", \\\"{x:324,y:549,t:1527268179405};\\\", \\\"{x:318,y:552,t:1527268179421};\\\", \\\"{x:304,y:554,t:1527268179438};\\\", \\\"{x:290,y:556,t:1527268179455};\\\", \\\"{x:273,y:558,t:1527268179472};\\\", \\\"{x:259,y:559,t:1527268179488};\\\", \\\"{x:249,y:562,t:1527268179504};\\\", \\\"{x:244,y:563,t:1527268179520};\\\", \\\"{x:242,y:563,t:1527268179537};\\\", \\\"{x:241,y:563,t:1527268179554};\\\", \\\"{x:240,y:563,t:1527268179570};\\\", \\\"{x:239,y:563,t:1527268179589};\\\", \\\"{x:238,y:563,t:1527268179605};\\\", \\\"{x:235,y:563,t:1527268179621};\\\", \\\"{x:232,y:565,t:1527268179637};\\\", \\\"{x:228,y:566,t:1527268179655};\\\", \\\"{x:223,y:570,t:1527268179670};\\\", \\\"{x:218,y:574,t:1527268179688};\\\", \\\"{x:209,y:580,t:1527268179706};\\\", \\\"{x:201,y:588,t:1527268179722};\\\", \\\"{x:192,y:595,t:1527268179737};\\\", \\\"{x:187,y:602,t:1527268179756};\\\", \\\"{x:183,y:608,t:1527268179772};\\\", \\\"{x:181,y:614,t:1527268179789};\\\", \\\"{x:180,y:617,t:1527268179805};\\\", \\\"{x:178,y:623,t:1527268179822};\\\", \\\"{x:176,y:626,t:1527268179838};\\\", \\\"{x:176,y:628,t:1527268179854};\\\", \\\"{x:173,y:631,t:1527268179871};\\\", \\\"{x:172,y:633,t:1527268179887};\\\", \\\"{x:171,y:635,t:1527268179904};\\\", \\\"{x:171,y:636,t:1527268179941};\\\", \\\"{x:172,y:636,t:1527268180189};\\\", \\\"{x:177,y:636,t:1527268180205};\\\", \\\"{x:182,y:638,t:1527268180221};\\\", \\\"{x:188,y:638,t:1527268180239};\\\", \\\"{x:189,y:638,t:1527268180255};\\\", \\\"{x:190,y:638,t:1527268180301};\\\", \\\"{x:192,y:638,t:1527268180309};\\\", \\\"{x:195,y:638,t:1527268180322};\\\", \\\"{x:210,y:641,t:1527268180338};\\\", \\\"{x:227,y:645,t:1527268180355};\\\", \\\"{x:248,y:656,t:1527268180372};\\\", \\\"{x:273,y:667,t:1527268180389};\\\", \\\"{x:325,y:690,t:1527268180405};\\\", \\\"{x:357,y:705,t:1527268180422};\\\", \\\"{x:379,y:714,t:1527268180439};\\\", \\\"{x:404,y:726,t:1527268180456};\\\", \\\"{x:425,y:736,t:1527268180472};\\\", \\\"{x:442,y:740,t:1527268180489};\\\", \\\"{x:456,y:745,t:1527268180506};\\\", \\\"{x:468,y:747,t:1527268180522};\\\", \\\"{x:481,y:751,t:1527268180539};\\\", \\\"{x:499,y:757,t:1527268180555};\\\", \\\"{x:515,y:761,t:1527268180572};\\\", \\\"{x:550,y:770,t:1527268180589};\\\", \\\"{x:576,y:778,t:1527268180605};\\\", \\\"{x:597,y:780,t:1527268180622};\\\", \\\"{x:607,y:782,t:1527268180639};\\\", \\\"{x:608,y:782,t:1527268180656};\\\", \\\"{x:609,y:780,t:1527268180672};\\\", \\\"{x:610,y:776,t:1527268180689};\\\", \\\"{x:610,y:771,t:1527268180706};\\\", \\\"{x:610,y:766,t:1527268180722};\\\", \\\"{x:610,y:761,t:1527268180739};\\\", \\\"{x:610,y:754,t:1527268180756};\\\", \\\"{x:605,y:749,t:1527268180772};\\\", \\\"{x:599,y:743,t:1527268180789};\\\", \\\"{x:588,y:733,t:1527268180806};\\\", \\\"{x:580,y:728,t:1527268180823};\\\", \\\"{x:573,y:723,t:1527268180839};\\\", \\\"{x:566,y:720,t:1527268180856};\\\", \\\"{x:560,y:716,t:1527268180874};\\\", \\\"{x:557,y:714,t:1527268180889};\\\", \\\"{x:557,y:713,t:1527268181725};\\\", \\\"{x:557,y:712,t:1527268181748};\\\", \\\"{x:557,y:711,t:1527268181781};\\\", \\\"{x:557,y:710,t:1527268181829};\\\", \\\"{x:557,y:709,t:1527268181910};\\\", \\\"{x:557,y:708,t:1527268181925};\\\", \\\"{x:557,y:707,t:1527268182029};\\\" ] }, { \\\"rt\\\": 16869, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 242839, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:707,t:1527268183726};\\\", \\\"{x:560,y:707,t:1527268183740};\\\", \\\"{x:562,y:707,t:1527268183757};\\\", \\\"{x:565,y:706,t:1527268183775};\\\", \\\"{x:567,y:705,t:1527268183790};\\\", \\\"{x:568,y:704,t:1527268183808};\\\", \\\"{x:570,y:704,t:1527268183825};\\\", \\\"{x:571,y:704,t:1527268183842};\\\", \\\"{x:572,y:704,t:1527268183858};\\\", \\\"{x:573,y:703,t:1527268183875};\\\", \\\"{x:576,y:702,t:1527268183892};\\\", \\\"{x:578,y:702,t:1527268183908};\\\", \\\"{x:583,y:702,t:1527268183926};\\\", \\\"{x:585,y:702,t:1527268183942};\\\", \\\"{x:587,y:702,t:1527268183959};\\\", \\\"{x:589,y:702,t:1527268183975};\\\", \\\"{x:590,y:702,t:1527268183992};\\\", \\\"{x:591,y:702,t:1527268184009};\\\", \\\"{x:592,y:702,t:1527268184025};\\\", \\\"{x:594,y:702,t:1527268184043};\\\", \\\"{x:595,y:702,t:1527268184059};\\\", \\\"{x:598,y:702,t:1527268184075};\\\", \\\"{x:599,y:702,t:1527268184092};\\\", \\\"{x:603,y:702,t:1527268184110};\\\", \\\"{x:604,y:702,t:1527268184126};\\\", \\\"{x:605,y:702,t:1527268184143};\\\", \\\"{x:608,y:702,t:1527268184160};\\\", \\\"{x:609,y:702,t:1527268184175};\\\", \\\"{x:611,y:702,t:1527268184193};\\\", \\\"{x:614,y:702,t:1527268184209};\\\", \\\"{x:616,y:702,t:1527268184226};\\\", \\\"{x:618,y:702,t:1527268184242};\\\", \\\"{x:621,y:702,t:1527268184259};\\\", \\\"{x:625,y:702,t:1527268184277};\\\", \\\"{x:630,y:703,t:1527268184292};\\\", \\\"{x:638,y:705,t:1527268184310};\\\", \\\"{x:642,y:707,t:1527268184326};\\\", \\\"{x:648,y:709,t:1527268184342};\\\", \\\"{x:656,y:713,t:1527268184359};\\\", \\\"{x:668,y:718,t:1527268184376};\\\", \\\"{x:678,y:723,t:1527268184392};\\\", \\\"{x:688,y:726,t:1527268184410};\\\", \\\"{x:693,y:729,t:1527268184426};\\\", \\\"{x:702,y:733,t:1527268184442};\\\", \\\"{x:714,y:738,t:1527268184460};\\\", \\\"{x:729,y:748,t:1527268184477};\\\", \\\"{x:755,y:759,t:1527268184493};\\\", \\\"{x:793,y:774,t:1527268184509};\\\", \\\"{x:819,y:789,t:1527268184526};\\\", \\\"{x:834,y:797,t:1527268184543};\\\", \\\"{x:850,y:807,t:1527268184559};\\\", \\\"{x:861,y:813,t:1527268184577};\\\", \\\"{x:871,y:820,t:1527268184593};\\\", \\\"{x:882,y:827,t:1527268184609};\\\", \\\"{x:897,y:835,t:1527268184626};\\\", \\\"{x:913,y:844,t:1527268184643};\\\", \\\"{x:934,y:856,t:1527268184660};\\\", \\\"{x:955,y:864,t:1527268184676};\\\", \\\"{x:977,y:871,t:1527268184693};\\\", \\\"{x:981,y:873,t:1527268184710};\\\", \\\"{x:982,y:873,t:1527268184726};\\\", \\\"{x:983,y:873,t:1527268185694};\\\", \\\"{x:986,y:874,t:1527268185711};\\\", \\\"{x:998,y:874,t:1527268185727};\\\", \\\"{x:1016,y:875,t:1527268185744};\\\", \\\"{x:1042,y:875,t:1527268185760};\\\", \\\"{x:1072,y:875,t:1527268185777};\\\", \\\"{x:1098,y:877,t:1527268185795};\\\", \\\"{x:1121,y:880,t:1527268185812};\\\", \\\"{x:1138,y:884,t:1527268185827};\\\", \\\"{x:1156,y:887,t:1527268185844};\\\", \\\"{x:1187,y:895,t:1527268185862};\\\", \\\"{x:1206,y:899,t:1527268185878};\\\", \\\"{x:1234,y:907,t:1527268185894};\\\", \\\"{x:1261,y:914,t:1527268185911};\\\", \\\"{x:1286,y:920,t:1527268185928};\\\", \\\"{x:1305,y:925,t:1527268185945};\\\", \\\"{x:1321,y:931,t:1527268185962};\\\", \\\"{x:1331,y:936,t:1527268185977};\\\", \\\"{x:1334,y:937,t:1527268185994};\\\", \\\"{x:1337,y:938,t:1527268186011};\\\", \\\"{x:1338,y:939,t:1527268186028};\\\", \\\"{x:1341,y:942,t:1527268186045};\\\", \\\"{x:1347,y:945,t:1527268186062};\\\", \\\"{x:1350,y:948,t:1527268186078};\\\", \\\"{x:1354,y:949,t:1527268186095};\\\", \\\"{x:1355,y:950,t:1527268186206};\\\", \\\"{x:1355,y:951,t:1527268186271};\\\", \\\"{x:1354,y:951,t:1527268186279};\\\", \\\"{x:1349,y:952,t:1527268186295};\\\", \\\"{x:1340,y:953,t:1527268186311};\\\", \\\"{x:1330,y:953,t:1527268186329};\\\", \\\"{x:1315,y:953,t:1527268186345};\\\", \\\"{x:1289,y:950,t:1527268186362};\\\", \\\"{x:1268,y:944,t:1527268186379};\\\", \\\"{x:1256,y:943,t:1527268186395};\\\", \\\"{x:1251,y:940,t:1527268186411};\\\", \\\"{x:1245,y:935,t:1527268186429};\\\", \\\"{x:1226,y:921,t:1527268186446};\\\", \\\"{x:1216,y:914,t:1527268186461};\\\", \\\"{x:1210,y:908,t:1527268186478};\\\", \\\"{x:1208,y:903,t:1527268186495};\\\", \\\"{x:1206,y:896,t:1527268186511};\\\", \\\"{x:1205,y:890,t:1527268186528};\\\", \\\"{x:1205,y:884,t:1527268186546};\\\", \\\"{x:1204,y:876,t:1527268186562};\\\", \\\"{x:1203,y:867,t:1527268186578};\\\", \\\"{x:1202,y:860,t:1527268186596};\\\", \\\"{x:1200,y:854,t:1527268186611};\\\", \\\"{x:1200,y:853,t:1527268186629};\\\", \\\"{x:1199,y:849,t:1527268186645};\\\", \\\"{x:1199,y:848,t:1527268186661};\\\", \\\"{x:1198,y:848,t:1527268186678};\\\", \\\"{x:1198,y:847,t:1527268186695};\\\", \\\"{x:1198,y:846,t:1527268186717};\\\", \\\"{x:1198,y:845,t:1527268186733};\\\", \\\"{x:1198,y:844,t:1527268186837};\\\", \\\"{x:1198,y:843,t:1527268186885};\\\", \\\"{x:1198,y:842,t:1527268186909};\\\", \\\"{x:1199,y:841,t:1527268186925};\\\", \\\"{x:1200,y:841,t:1527268186941};\\\", \\\"{x:1201,y:841,t:1527268186958};\\\", \\\"{x:1203,y:840,t:1527268186966};\\\", \\\"{x:1205,y:839,t:1527268186989};\\\", \\\"{x:1206,y:838,t:1527268187014};\\\", \\\"{x:1208,y:837,t:1527268187045};\\\", \\\"{x:1209,y:837,t:1527268187077};\\\", \\\"{x:1210,y:836,t:1527268187133};\\\", \\\"{x:1211,y:835,t:1527268187614};\\\", \\\"{x:1212,y:835,t:1527268187632};\\\", \\\"{x:1216,y:835,t:1527268187646};\\\", \\\"{x:1219,y:835,t:1527268187662};\\\", \\\"{x:1223,y:835,t:1527268187679};\\\", \\\"{x:1225,y:835,t:1527268187696};\\\", \\\"{x:1226,y:835,t:1527268187713};\\\", \\\"{x:1229,y:835,t:1527268187729};\\\", \\\"{x:1232,y:835,t:1527268187747};\\\", \\\"{x:1236,y:835,t:1527268187763};\\\", \\\"{x:1238,y:835,t:1527268187779};\\\", \\\"{x:1239,y:835,t:1527268187796};\\\", \\\"{x:1240,y:835,t:1527268187918};\\\", \\\"{x:1242,y:835,t:1527268187934};\\\", \\\"{x:1244,y:835,t:1527268187947};\\\", \\\"{x:1244,y:836,t:1527268187963};\\\", \\\"{x:1246,y:838,t:1527268187979};\\\", \\\"{x:1248,y:841,t:1527268187996};\\\", \\\"{x:1249,y:844,t:1527268188013};\\\", \\\"{x:1249,y:845,t:1527268188030};\\\", \\\"{x:1250,y:848,t:1527268188046};\\\", \\\"{x:1251,y:851,t:1527268188063};\\\", \\\"{x:1253,y:855,t:1527268188080};\\\", \\\"{x:1254,y:857,t:1527268188096};\\\", \\\"{x:1254,y:861,t:1527268188113};\\\", \\\"{x:1254,y:863,t:1527268188131};\\\", \\\"{x:1254,y:865,t:1527268188147};\\\", \\\"{x:1254,y:869,t:1527268188164};\\\", \\\"{x:1256,y:873,t:1527268188180};\\\", \\\"{x:1256,y:876,t:1527268188197};\\\", \\\"{x:1256,y:881,t:1527268188214};\\\", \\\"{x:1256,y:885,t:1527268188230};\\\", \\\"{x:1256,y:888,t:1527268188246};\\\", \\\"{x:1256,y:892,t:1527268188263};\\\", \\\"{x:1256,y:894,t:1527268188281};\\\", \\\"{x:1256,y:896,t:1527268188297};\\\", \\\"{x:1256,y:899,t:1527268188313};\\\", \\\"{x:1256,y:902,t:1527268188331};\\\", \\\"{x:1256,y:903,t:1527268188348};\\\", \\\"{x:1256,y:905,t:1527268188363};\\\", \\\"{x:1256,y:906,t:1527268188381};\\\", \\\"{x:1256,y:907,t:1527268188397};\\\", \\\"{x:1254,y:907,t:1527268188686};\\\", \\\"{x:1253,y:910,t:1527268188702};\\\", \\\"{x:1251,y:910,t:1527268188717};\\\", \\\"{x:1250,y:911,t:1527268188733};\\\", \\\"{x:1249,y:912,t:1527268188748};\\\", \\\"{x:1246,y:914,t:1527268188765};\\\", \\\"{x:1246,y:915,t:1527268188782};\\\", \\\"{x:1246,y:916,t:1527268188806};\\\", \\\"{x:1245,y:916,t:1527268188814};\\\", \\\"{x:1243,y:919,t:1527268188831};\\\", \\\"{x:1243,y:922,t:1527268188848};\\\", \\\"{x:1243,y:924,t:1527268188865};\\\", \\\"{x:1242,y:928,t:1527268188881};\\\", \\\"{x:1242,y:931,t:1527268188897};\\\", \\\"{x:1242,y:933,t:1527268188914};\\\", \\\"{x:1242,y:934,t:1527268188931};\\\", \\\"{x:1242,y:935,t:1527268188948};\\\", \\\"{x:1242,y:937,t:1527268189222};\\\", \\\"{x:1242,y:938,t:1527268189245};\\\", \\\"{x:1242,y:939,t:1527268189382};\\\", \\\"{x:1242,y:940,t:1527268189399};\\\", \\\"{x:1242,y:941,t:1527268189422};\\\", \\\"{x:1242,y:942,t:1527268189470};\\\", \\\"{x:1241,y:944,t:1527268189494};\\\", \\\"{x:1239,y:945,t:1527268189502};\\\", \\\"{x:1238,y:945,t:1527268189515};\\\", \\\"{x:1233,y:946,t:1527268189532};\\\", \\\"{x:1230,y:948,t:1527268189549};\\\", \\\"{x:1227,y:949,t:1527268189566};\\\", \\\"{x:1225,y:951,t:1527268189582};\\\", \\\"{x:1223,y:951,t:1527268189606};\\\", \\\"{x:1222,y:952,t:1527268189616};\\\", \\\"{x:1221,y:952,t:1527268189632};\\\", \\\"{x:1218,y:953,t:1527268189648};\\\", \\\"{x:1217,y:953,t:1527268189665};\\\", \\\"{x:1216,y:954,t:1527268189682};\\\", \\\"{x:1215,y:954,t:1527268189698};\\\", \\\"{x:1213,y:955,t:1527268189715};\\\", \\\"{x:1212,y:955,t:1527268189741};\\\", \\\"{x:1211,y:956,t:1527268189758};\\\", \\\"{x:1210,y:956,t:1527268189774};\\\", \\\"{x:1209,y:956,t:1527268189789};\\\", \\\"{x:1208,y:957,t:1527268189821};\\\", \\\"{x:1207,y:957,t:1527268189862};\\\", \\\"{x:1208,y:957,t:1527268190070};\\\", \\\"{x:1209,y:957,t:1527268190094};\\\", \\\"{x:1210,y:958,t:1527268190102};\\\", \\\"{x:1211,y:958,t:1527268190134};\\\", \\\"{x:1212,y:958,t:1527268190149};\\\", \\\"{x:1213,y:958,t:1527268190463};\\\", \\\"{x:1213,y:957,t:1527268190469};\\\", \\\"{x:1213,y:953,t:1527268190482};\\\", \\\"{x:1213,y:949,t:1527268190500};\\\", \\\"{x:1213,y:946,t:1527268190516};\\\", \\\"{x:1213,y:943,t:1527268190532};\\\", \\\"{x:1212,y:934,t:1527268190550};\\\", \\\"{x:1212,y:932,t:1527268190566};\\\", \\\"{x:1211,y:929,t:1527268190583};\\\", \\\"{x:1210,y:926,t:1527268190600};\\\", \\\"{x:1209,y:922,t:1527268190617};\\\", \\\"{x:1209,y:919,t:1527268190633};\\\", \\\"{x:1208,y:917,t:1527268190650};\\\", \\\"{x:1207,y:914,t:1527268190666};\\\", \\\"{x:1207,y:912,t:1527268190686};\\\", \\\"{x:1207,y:911,t:1527268190700};\\\", \\\"{x:1207,y:909,t:1527268190717};\\\", \\\"{x:1207,y:905,t:1527268190733};\\\", \\\"{x:1207,y:900,t:1527268190750};\\\", \\\"{x:1207,y:898,t:1527268190766};\\\", \\\"{x:1207,y:894,t:1527268190783};\\\", \\\"{x:1207,y:890,t:1527268190799};\\\", \\\"{x:1207,y:886,t:1527268190816};\\\", \\\"{x:1207,y:878,t:1527268190833};\\\", \\\"{x:1207,y:870,t:1527268190849};\\\", \\\"{x:1207,y:863,t:1527268190867};\\\", \\\"{x:1207,y:855,t:1527268190884};\\\", \\\"{x:1207,y:850,t:1527268190900};\\\", \\\"{x:1209,y:845,t:1527268190916};\\\", \\\"{x:1209,y:842,t:1527268190934};\\\", \\\"{x:1209,y:841,t:1527268190950};\\\", \\\"{x:1209,y:840,t:1527268190973};\\\", \\\"{x:1209,y:839,t:1527268190998};\\\", \\\"{x:1209,y:838,t:1527268191070};\\\", \\\"{x:1209,y:837,t:1527268191118};\\\", \\\"{x:1209,y:836,t:1527268191141};\\\", \\\"{x:1209,y:835,t:1527268191150};\\\", \\\"{x:1210,y:835,t:1527268191167};\\\", \\\"{x:1210,y:834,t:1527268191206};\\\", \\\"{x:1210,y:833,t:1527268191223};\\\", \\\"{x:1210,y:832,t:1527268192325};\\\", \\\"{x:1211,y:830,t:1527268195818};\\\", \\\"{x:1211,y:829,t:1527268195977};\\\", \\\"{x:1211,y:828,t:1527268196073};\\\", \\\"{x:1212,y:827,t:1527268196113};\\\", \\\"{x:1213,y:825,t:1527268196425};\\\", \\\"{x:1216,y:825,t:1527268196443};\\\", \\\"{x:1223,y:823,t:1527268196461};\\\", \\\"{x:1228,y:821,t:1527268196477};\\\", \\\"{x:1232,y:821,t:1527268196493};\\\", \\\"{x:1236,y:820,t:1527268196510};\\\", \\\"{x:1239,y:820,t:1527268196526};\\\", \\\"{x:1241,y:819,t:1527268196544};\\\", \\\"{x:1244,y:818,t:1527268196561};\\\", \\\"{x:1250,y:818,t:1527268196577};\\\", \\\"{x:1258,y:818,t:1527268196593};\\\", \\\"{x:1266,y:818,t:1527268196609};\\\", \\\"{x:1275,y:818,t:1527268196627};\\\", \\\"{x:1279,y:818,t:1527268196644};\\\", \\\"{x:1282,y:818,t:1527268196659};\\\", \\\"{x:1284,y:818,t:1527268196714};\\\", \\\"{x:1285,y:817,t:1527268196727};\\\", \\\"{x:1289,y:817,t:1527268196744};\\\", \\\"{x:1296,y:817,t:1527268196760};\\\", \\\"{x:1302,y:819,t:1527268196776};\\\", \\\"{x:1304,y:819,t:1527268196793};\\\", \\\"{x:1302,y:819,t:1527268197112};\\\", \\\"{x:1301,y:819,t:1527268197127};\\\", \\\"{x:1300,y:819,t:1527268197143};\\\", \\\"{x:1299,y:819,t:1527268197160};\\\", \\\"{x:1298,y:820,t:1527268197185};\\\", \\\"{x:1297,y:821,t:1527268197201};\\\", \\\"{x:1296,y:821,t:1527268197241};\\\", \\\"{x:1295,y:821,t:1527268197265};\\\", \\\"{x:1294,y:821,t:1527268197337};\\\", \\\"{x:1293,y:821,t:1527268197386};\\\", \\\"{x:1292,y:821,t:1527268197401};\\\", \\\"{x:1291,y:821,t:1527268197426};\\\", \\\"{x:1290,y:821,t:1527268197434};\\\", \\\"{x:1289,y:821,t:1527268197449};\\\", \\\"{x:1288,y:821,t:1527268197521};\\\", \\\"{x:1287,y:821,t:1527268197545};\\\", \\\"{x:1286,y:821,t:1527268197577};\\\", \\\"{x:1285,y:821,t:1527268197634};\\\", \\\"{x:1284,y:821,t:1527268197697};\\\", \\\"{x:1283,y:821,t:1527268197833};\\\", \\\"{x:1282,y:820,t:1527268197845};\\\", \\\"{x:1281,y:820,t:1527268197862};\\\", \\\"{x:1279,y:820,t:1527268197878};\\\", \\\"{x:1278,y:820,t:1527268197897};\\\", \\\"{x:1277,y:820,t:1527268197921};\\\", \\\"{x:1275,y:818,t:1527268197929};\\\", \\\"{x:1272,y:817,t:1527268197945};\\\", \\\"{x:1257,y:809,t:1527268197960};\\\", \\\"{x:1239,y:800,t:1527268197977};\\\", \\\"{x:1207,y:785,t:1527268197994};\\\", \\\"{x:1147,y:763,t:1527268198011};\\\", \\\"{x:1061,y:736,t:1527268198028};\\\", \\\"{x:971,y:701,t:1527268198044};\\\", \\\"{x:882,y:676,t:1527268198061};\\\", \\\"{x:795,y:649,t:1527268198079};\\\", \\\"{x:722,y:623,t:1527268198096};\\\", \\\"{x:663,y:604,t:1527268198112};\\\", \\\"{x:609,y:587,t:1527268198128};\\\", \\\"{x:561,y:572,t:1527268198158};\\\", \\\"{x:534,y:565,t:1527268198174};\\\", \\\"{x:508,y:558,t:1527268198189};\\\", \\\"{x:483,y:550,t:1527268198208};\\\", \\\"{x:456,y:538,t:1527268198224};\\\", \\\"{x:437,y:534,t:1527268198240};\\\", \\\"{x:418,y:528,t:1527268198257};\\\", \\\"{x:409,y:524,t:1527268198274};\\\", \\\"{x:402,y:522,t:1527268198290};\\\", \\\"{x:397,y:520,t:1527268198307};\\\", \\\"{x:393,y:519,t:1527268198324};\\\", \\\"{x:390,y:519,t:1527268198340};\\\", \\\"{x:388,y:519,t:1527268198360};\\\", \\\"{x:387,y:519,t:1527268198473};\\\", \\\"{x:386,y:518,t:1527268198503};\\\", \\\"{x:396,y:518,t:1527268198674};\\\", \\\"{x:404,y:518,t:1527268198691};\\\", \\\"{x:414,y:520,t:1527268198707};\\\", \\\"{x:421,y:520,t:1527268198724};\\\", \\\"{x:425,y:521,t:1527268198740};\\\", \\\"{x:430,y:523,t:1527268198757};\\\", \\\"{x:442,y:536,t:1527268198774};\\\", \\\"{x:466,y:563,t:1527268198792};\\\", \\\"{x:483,y:592,t:1527268198807};\\\", \\\"{x:500,y:622,t:1527268198824};\\\", \\\"{x:507,y:637,t:1527268198841};\\\", \\\"{x:511,y:647,t:1527268198857};\\\", \\\"{x:513,y:654,t:1527268198874};\\\", \\\"{x:517,y:665,t:1527268198891};\\\", \\\"{x:522,y:678,t:1527268198908};\\\", \\\"{x:527,y:691,t:1527268198924};\\\", \\\"{x:531,y:700,t:1527268198941};\\\", \\\"{x:534,y:708,t:1527268198958};\\\", \\\"{x:536,y:711,t:1527268198975};\\\", \\\"{x:536,y:712,t:1527268198991};\\\", \\\"{x:537,y:712,t:1527268200137};\\\", \\\"{x:538,y:712,t:1527268200145};\\\", \\\"{x:538,y:711,t:1527268200158};\\\", \\\"{x:538,y:707,t:1527268200175};\\\", \\\"{x:538,y:701,t:1527268200193};\\\", \\\"{x:538,y:697,t:1527268200208};\\\", \\\"{x:538,y:695,t:1527268200225};\\\", \\\"{x:539,y:695,t:1527268200242};\\\", \\\"{x:539,y:694,t:1527268200264};\\\", \\\"{x:539,y:692,t:1527268200360};\\\" ] }, { \\\"rt\\\": 45927, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 289982, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-04 PM-05 PM-04 PM-04 PM-E -F -4-04 PM-04 PM-04 PM-K -K -K -K -U -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:688,t:1527268200482};\\\", \\\"{x:539,y:686,t:1527268200509};\\\", \\\"{x:539,y:685,t:1527268200593};\\\", \\\"{x:539,y:683,t:1527268201000};\\\", \\\"{x:540,y:683,t:1527268201401};\\\", \\\"{x:541,y:682,t:1527268201409};\\\", \\\"{x:544,y:681,t:1527268201426};\\\", \\\"{x:548,y:681,t:1527268201443};\\\", \\\"{x:553,y:679,t:1527268201460};\\\", \\\"{x:559,y:679,t:1527268201476};\\\", \\\"{x:574,y:679,t:1527268201493};\\\", \\\"{x:598,y:679,t:1527268201510};\\\", \\\"{x:637,y:689,t:1527268201526};\\\", \\\"{x:696,y:705,t:1527268201544};\\\", \\\"{x:827,y:748,t:1527268201560};\\\", \\\"{x:918,y:773,t:1527268201577};\\\", \\\"{x:1004,y:800,t:1527268201593};\\\", \\\"{x:1074,y:820,t:1527268201610};\\\", \\\"{x:1122,y:835,t:1527268201627};\\\", \\\"{x:1146,y:843,t:1527268201644};\\\", \\\"{x:1161,y:849,t:1527268201661};\\\", \\\"{x:1170,y:853,t:1527268201677};\\\", \\\"{x:1174,y:855,t:1527268201693};\\\", \\\"{x:1178,y:856,t:1527268201711};\\\", \\\"{x:1180,y:857,t:1527268201726};\\\", \\\"{x:1182,y:857,t:1527268201743};\\\", \\\"{x:1183,y:857,t:1527268201761};\\\", \\\"{x:1187,y:862,t:1527268203026};\\\", \\\"{x:1217,y:884,t:1527268203033};\\\", \\\"{x:1275,y:916,t:1527268203045};\\\", \\\"{x:1387,y:980,t:1527268203062};\\\", \\\"{x:1502,y:1026,t:1527268203078};\\\", \\\"{x:1595,y:1064,t:1527268203095};\\\", \\\"{x:1673,y:1088,t:1527268203112};\\\", \\\"{x:1703,y:1092,t:1527268203128};\\\", \\\"{x:1708,y:1094,t:1527268203144};\\\", \\\"{x:1709,y:1094,t:1527268203226};\\\", \\\"{x:1708,y:1092,t:1527268203233};\\\", \\\"{x:1706,y:1090,t:1527268203244};\\\", \\\"{x:1700,y:1086,t:1527268203261};\\\", \\\"{x:1691,y:1083,t:1527268203279};\\\", \\\"{x:1679,y:1081,t:1527268203294};\\\", \\\"{x:1669,y:1077,t:1527268203311};\\\", \\\"{x:1652,y:1072,t:1527268203329};\\\", \\\"{x:1635,y:1067,t:1527268203345};\\\", \\\"{x:1612,y:1061,t:1527268203361};\\\", \\\"{x:1582,y:1053,t:1527268203379};\\\", \\\"{x:1553,y:1043,t:1527268203395};\\\", \\\"{x:1525,y:1035,t:1527268203412};\\\", \\\"{x:1504,y:1028,t:1527268203428};\\\", \\\"{x:1488,y:1024,t:1527268203445};\\\", \\\"{x:1482,y:1021,t:1527268203461};\\\", \\\"{x:1479,y:1021,t:1527268203479};\\\", \\\"{x:1478,y:1021,t:1527268203505};\\\", \\\"{x:1477,y:1021,t:1527268203513};\\\", \\\"{x:1475,y:1020,t:1527268203529};\\\", \\\"{x:1473,y:1020,t:1527268203545};\\\", \\\"{x:1468,y:1018,t:1527268203562};\\\", \\\"{x:1465,y:1018,t:1527268203579};\\\", \\\"{x:1458,y:1016,t:1527268203595};\\\", \\\"{x:1452,y:1014,t:1527268203612};\\\", \\\"{x:1447,y:1012,t:1527268203629};\\\", \\\"{x:1443,y:1011,t:1527268203646};\\\", \\\"{x:1439,y:1010,t:1527268203662};\\\", \\\"{x:1435,y:1009,t:1527268203679};\\\", \\\"{x:1431,y:1008,t:1527268203696};\\\", \\\"{x:1429,y:1008,t:1527268203712};\\\", \\\"{x:1427,y:1008,t:1527268203729};\\\", \\\"{x:1427,y:1007,t:1527268203873};\\\", \\\"{x:1427,y:1006,t:1527268203891};\\\", \\\"{x:1427,y:1005,t:1527268203897};\\\", \\\"{x:1427,y:1004,t:1527268203912};\\\", \\\"{x:1429,y:1002,t:1527268203928};\\\", \\\"{x:1432,y:999,t:1527268203945};\\\", \\\"{x:1435,y:997,t:1527268203961};\\\", \\\"{x:1439,y:997,t:1527268203978};\\\", \\\"{x:1441,y:996,t:1527268203995};\\\", \\\"{x:1446,y:995,t:1527268204012};\\\", \\\"{x:1449,y:993,t:1527268204028};\\\", \\\"{x:1450,y:993,t:1527268204046};\\\", \\\"{x:1452,y:993,t:1527268204064};\\\", \\\"{x:1453,y:993,t:1527268204079};\\\", \\\"{x:1457,y:990,t:1527268204096};\\\", \\\"{x:1462,y:989,t:1527268204112};\\\", \\\"{x:1464,y:988,t:1527268204129};\\\", \\\"{x:1468,y:988,t:1527268204145};\\\", \\\"{x:1473,y:988,t:1527268204162};\\\", \\\"{x:1483,y:988,t:1527268204179};\\\", \\\"{x:1494,y:988,t:1527268204196};\\\", \\\"{x:1507,y:988,t:1527268204213};\\\", \\\"{x:1520,y:988,t:1527268204228};\\\", \\\"{x:1528,y:988,t:1527268204246};\\\", \\\"{x:1535,y:987,t:1527268204263};\\\", \\\"{x:1540,y:986,t:1527268204279};\\\", \\\"{x:1544,y:985,t:1527268204296};\\\", \\\"{x:1547,y:985,t:1527268204313};\\\", \\\"{x:1549,y:985,t:1527268204329};\\\", \\\"{x:1552,y:984,t:1527268204346};\\\", \\\"{x:1557,y:982,t:1527268204362};\\\", \\\"{x:1559,y:982,t:1527268204379};\\\", \\\"{x:1562,y:982,t:1527268204396};\\\", \\\"{x:1564,y:982,t:1527268204412};\\\", \\\"{x:1565,y:981,t:1527268204429};\\\", \\\"{x:1567,y:981,t:1527268204446};\\\", \\\"{x:1569,y:980,t:1527268204464};\\\", \\\"{x:1571,y:980,t:1527268204480};\\\", \\\"{x:1572,y:978,t:1527268204496};\\\", \\\"{x:1576,y:978,t:1527268204513};\\\", \\\"{x:1578,y:978,t:1527268204529};\\\", \\\"{x:1581,y:978,t:1527268204553};\\\", \\\"{x:1583,y:977,t:1527268204563};\\\", \\\"{x:1596,y:973,t:1527268204580};\\\", \\\"{x:1610,y:969,t:1527268204596};\\\", \\\"{x:1626,y:965,t:1527268204613};\\\", \\\"{x:1644,y:962,t:1527268204630};\\\", \\\"{x:1658,y:959,t:1527268204645};\\\", \\\"{x:1664,y:958,t:1527268204663};\\\", \\\"{x:1665,y:958,t:1527268204679};\\\", \\\"{x:1666,y:957,t:1527268204793};\\\", \\\"{x:1664,y:957,t:1527268204874};\\\", \\\"{x:1662,y:957,t:1527268204881};\\\", \\\"{x:1660,y:957,t:1527268204896};\\\", \\\"{x:1650,y:957,t:1527268204913};\\\", \\\"{x:1647,y:959,t:1527268204930};\\\", \\\"{x:1646,y:959,t:1527268204946};\\\", \\\"{x:1645,y:960,t:1527268204969};\\\", \\\"{x:1644,y:960,t:1527268204993};\\\", \\\"{x:1643,y:960,t:1527268205009};\\\", \\\"{x:1641,y:961,t:1527268205017};\\\", \\\"{x:1640,y:961,t:1527268205029};\\\", \\\"{x:1636,y:962,t:1527268205047};\\\", \\\"{x:1633,y:963,t:1527268205063};\\\", \\\"{x:1632,y:963,t:1527268205080};\\\", \\\"{x:1631,y:963,t:1527268205097};\\\", \\\"{x:1630,y:964,t:1527268205113};\\\", \\\"{x:1628,y:964,t:1527268205130};\\\", \\\"{x:1626,y:965,t:1527268205147};\\\", \\\"{x:1625,y:965,t:1527268205986};\\\", \\\"{x:1624,y:964,t:1527268206009};\\\", \\\"{x:1624,y:963,t:1527268206025};\\\", \\\"{x:1624,y:962,t:1527268206057};\\\", \\\"{x:1624,y:961,t:1527268206098};\\\", \\\"{x:1624,y:960,t:1527268206162};\\\", \\\"{x:1623,y:959,t:1527268206537};\\\", \\\"{x:1621,y:959,t:1527268206577};\\\", \\\"{x:1620,y:959,t:1527268206625};\\\", \\\"{x:1619,y:959,t:1527268206633};\\\", \\\"{x:1618,y:960,t:1527268206648};\\\", \\\"{x:1617,y:960,t:1527268206665};\\\", \\\"{x:1615,y:963,t:1527268206682};\\\", \\\"{x:1614,y:963,t:1527268206698};\\\", \\\"{x:1613,y:966,t:1527268206715};\\\", \\\"{x:1613,y:968,t:1527268206731};\\\", \\\"{x:1612,y:969,t:1527268206749};\\\", \\\"{x:1612,y:970,t:1527268206764};\\\", \\\"{x:1612,y:969,t:1527268206897};\\\", \\\"{x:1608,y:960,t:1527268206915};\\\", \\\"{x:1604,y:952,t:1527268206931};\\\", \\\"{x:1603,y:945,t:1527268206948};\\\", \\\"{x:1600,y:936,t:1527268206966};\\\", \\\"{x:1600,y:927,t:1527268206982};\\\", \\\"{x:1599,y:923,t:1527268206998};\\\", \\\"{x:1599,y:915,t:1527268207015};\\\", \\\"{x:1598,y:912,t:1527268207031};\\\", \\\"{x:1598,y:910,t:1527268207048};\\\", \\\"{x:1598,y:904,t:1527268207064};\\\", \\\"{x:1598,y:899,t:1527268207080};\\\", \\\"{x:1598,y:894,t:1527268207097};\\\", \\\"{x:1598,y:887,t:1527268207114};\\\", \\\"{x:1596,y:880,t:1527268207131};\\\", \\\"{x:1596,y:875,t:1527268207148};\\\", \\\"{x:1596,y:872,t:1527268207165};\\\", \\\"{x:1596,y:869,t:1527268207182};\\\", \\\"{x:1596,y:865,t:1527268207198};\\\", \\\"{x:1596,y:858,t:1527268207215};\\\", \\\"{x:1597,y:851,t:1527268207231};\\\", \\\"{x:1597,y:845,t:1527268207248};\\\", \\\"{x:1600,y:829,t:1527268207265};\\\", \\\"{x:1601,y:820,t:1527268207282};\\\", \\\"{x:1602,y:814,t:1527268207297};\\\", \\\"{x:1604,y:807,t:1527268207314};\\\", \\\"{x:1604,y:803,t:1527268207331};\\\", \\\"{x:1605,y:797,t:1527268207348};\\\", \\\"{x:1606,y:791,t:1527268207365};\\\", \\\"{x:1606,y:787,t:1527268207381};\\\", \\\"{x:1608,y:783,t:1527268207398};\\\", \\\"{x:1608,y:780,t:1527268207414};\\\", \\\"{x:1608,y:778,t:1527268207432};\\\", \\\"{x:1608,y:777,t:1527268207448};\\\", \\\"{x:1608,y:772,t:1527268207465};\\\", \\\"{x:1608,y:771,t:1527268207481};\\\", \\\"{x:1608,y:768,t:1527268207498};\\\", \\\"{x:1608,y:766,t:1527268207515};\\\", \\\"{x:1608,y:760,t:1527268207532};\\\", \\\"{x:1608,y:756,t:1527268207548};\\\", \\\"{x:1608,y:745,t:1527268207565};\\\", \\\"{x:1608,y:737,t:1527268207582};\\\", \\\"{x:1608,y:731,t:1527268207599};\\\", \\\"{x:1608,y:727,t:1527268207615};\\\", \\\"{x:1609,y:723,t:1527268207632};\\\", \\\"{x:1610,y:717,t:1527268207648};\\\", \\\"{x:1610,y:712,t:1527268207665};\\\", \\\"{x:1610,y:707,t:1527268207682};\\\", \\\"{x:1610,y:703,t:1527268207699};\\\", \\\"{x:1610,y:698,t:1527268207715};\\\", \\\"{x:1610,y:693,t:1527268207731};\\\", \\\"{x:1610,y:686,t:1527268207748};\\\", \\\"{x:1610,y:676,t:1527268207764};\\\", \\\"{x:1608,y:665,t:1527268207781};\\\", \\\"{x:1608,y:652,t:1527268207799};\\\", \\\"{x:1608,y:639,t:1527268207815};\\\", \\\"{x:1608,y:621,t:1527268207831};\\\", \\\"{x:1608,y:594,t:1527268207848};\\\", \\\"{x:1608,y:573,t:1527268207864};\\\", \\\"{x:1608,y:554,t:1527268207882};\\\", \\\"{x:1608,y:535,t:1527268207899};\\\", \\\"{x:1608,y:522,t:1527268207914};\\\", \\\"{x:1608,y:516,t:1527268207931};\\\", \\\"{x:1607,y:511,t:1527268207949};\\\", \\\"{x:1607,y:509,t:1527268207965};\\\", \\\"{x:1606,y:508,t:1527268207982};\\\", \\\"{x:1607,y:507,t:1527268208097};\\\", \\\"{x:1610,y:507,t:1527268208104};\\\", \\\"{x:1614,y:507,t:1527268208115};\\\", \\\"{x:1621,y:507,t:1527268208132};\\\", \\\"{x:1630,y:510,t:1527268208149};\\\", \\\"{x:1639,y:514,t:1527268208166};\\\", \\\"{x:1642,y:515,t:1527268208183};\\\", \\\"{x:1645,y:516,t:1527268208199};\\\", \\\"{x:1646,y:518,t:1527268208216};\\\", \\\"{x:1648,y:521,t:1527268208232};\\\", \\\"{x:1649,y:526,t:1527268208249};\\\", \\\"{x:1650,y:530,t:1527268208266};\\\", \\\"{x:1650,y:532,t:1527268208282};\\\", \\\"{x:1652,y:533,t:1527268208299};\\\", \\\"{x:1653,y:534,t:1527268208316};\\\", \\\"{x:1656,y:536,t:1527268208332};\\\", \\\"{x:1657,y:539,t:1527268208349};\\\", \\\"{x:1660,y:547,t:1527268208366};\\\", \\\"{x:1660,y:559,t:1527268208382};\\\", \\\"{x:1657,y:583,t:1527268208399};\\\", \\\"{x:1654,y:606,t:1527268208416};\\\", \\\"{x:1655,y:628,t:1527268208432};\\\", \\\"{x:1661,y:667,t:1527268208449};\\\", \\\"{x:1666,y:701,t:1527268208466};\\\", \\\"{x:1672,y:739,t:1527268208483};\\\", \\\"{x:1672,y:784,t:1527268208499};\\\", \\\"{x:1672,y:834,t:1527268208516};\\\", \\\"{x:1672,y:871,t:1527268208533};\\\", \\\"{x:1677,y:899,t:1527268208549};\\\", \\\"{x:1679,y:909,t:1527268208566};\\\", \\\"{x:1679,y:914,t:1527268208583};\\\", \\\"{x:1679,y:916,t:1527268208599};\\\", \\\"{x:1679,y:917,t:1527268208616};\\\", \\\"{x:1679,y:919,t:1527268208633};\\\", \\\"{x:1679,y:920,t:1527268208738};\\\", \\\"{x:1679,y:922,t:1527268208777};\\\", \\\"{x:1679,y:925,t:1527268208785};\\\", \\\"{x:1679,y:926,t:1527268208800};\\\", \\\"{x:1678,y:934,t:1527268208816};\\\", \\\"{x:1675,y:947,t:1527268208833};\\\", \\\"{x:1672,y:955,t:1527268208849};\\\", \\\"{x:1664,y:969,t:1527268208866};\\\", \\\"{x:1657,y:977,t:1527268208883};\\\", \\\"{x:1648,y:987,t:1527268208899};\\\", \\\"{x:1637,y:996,t:1527268208916};\\\", \\\"{x:1627,y:1005,t:1527268208933};\\\", \\\"{x:1618,y:1014,t:1527268208950};\\\", \\\"{x:1608,y:1021,t:1527268208966};\\\", \\\"{x:1603,y:1025,t:1527268208983};\\\", \\\"{x:1600,y:1027,t:1527268209001};\\\", \\\"{x:1599,y:1027,t:1527268209057};\\\", \\\"{x:1599,y:1025,t:1527268209066};\\\", \\\"{x:1599,y:1015,t:1527268209083};\\\", \\\"{x:1599,y:1003,t:1527268209100};\\\", \\\"{x:1599,y:983,t:1527268209117};\\\", \\\"{x:1599,y:966,t:1527268209133};\\\", \\\"{x:1599,y:952,t:1527268209150};\\\", \\\"{x:1599,y:943,t:1527268209166};\\\", \\\"{x:1601,y:933,t:1527268209183};\\\", \\\"{x:1601,y:929,t:1527268209200};\\\", \\\"{x:1602,y:922,t:1527268209216};\\\", \\\"{x:1603,y:914,t:1527268209233};\\\", \\\"{x:1603,y:912,t:1527268209250};\\\", \\\"{x:1603,y:908,t:1527268209267};\\\", \\\"{x:1603,y:905,t:1527268209283};\\\", \\\"{x:1605,y:901,t:1527268209300};\\\", \\\"{x:1605,y:897,t:1527268209316};\\\", \\\"{x:1605,y:890,t:1527268209333};\\\", \\\"{x:1605,y:880,t:1527268209350};\\\", \\\"{x:1605,y:869,t:1527268209368};\\\", \\\"{x:1605,y:855,t:1527268209383};\\\", \\\"{x:1605,y:843,t:1527268209400};\\\", \\\"{x:1605,y:826,t:1527268209417};\\\", \\\"{x:1605,y:820,t:1527268209433};\\\", \\\"{x:1605,y:814,t:1527268209450};\\\", \\\"{x:1605,y:809,t:1527268209468};\\\", \\\"{x:1605,y:804,t:1527268209483};\\\", \\\"{x:1605,y:801,t:1527268209500};\\\", \\\"{x:1605,y:797,t:1527268209517};\\\", \\\"{x:1604,y:794,t:1527268209533};\\\", \\\"{x:1604,y:792,t:1527268209550};\\\", \\\"{x:1604,y:790,t:1527268209567};\\\", \\\"{x:1604,y:788,t:1527268209583};\\\", \\\"{x:1604,y:787,t:1527268209600};\\\", \\\"{x:1603,y:784,t:1527268209617};\\\", \\\"{x:1602,y:782,t:1527268209633};\\\", \\\"{x:1602,y:781,t:1527268209650};\\\", \\\"{x:1602,y:780,t:1527268209666};\\\", \\\"{x:1602,y:779,t:1527268209682};\\\", \\\"{x:1602,y:778,t:1527268209703};\\\", \\\"{x:1602,y:777,t:1527268209768};\\\", \\\"{x:1602,y:776,t:1527268209784};\\\", \\\"{x:1602,y:775,t:1527268209800};\\\", \\\"{x:1602,y:774,t:1527268209816};\\\", \\\"{x:1602,y:772,t:1527268209834};\\\", \\\"{x:1602,y:770,t:1527268209849};\\\", \\\"{x:1602,y:768,t:1527268209866};\\\", \\\"{x:1602,y:765,t:1527268209883};\\\", \\\"{x:1603,y:763,t:1527268209900};\\\", \\\"{x:1603,y:762,t:1527268209916};\\\", \\\"{x:1603,y:760,t:1527268209934};\\\", \\\"{x:1603,y:759,t:1527268209949};\\\", \\\"{x:1603,y:758,t:1527268209967};\\\", \\\"{x:1603,y:757,t:1527268209984};\\\", \\\"{x:1603,y:756,t:1527268210008};\\\", \\\"{x:1603,y:755,t:1527268210025};\\\", \\\"{x:1605,y:754,t:1527268210041};\\\", \\\"{x:1605,y:753,t:1527268210090};\\\", \\\"{x:1605,y:752,t:1527268210100};\\\", \\\"{x:1605,y:751,t:1527268210117};\\\", \\\"{x:1605,y:750,t:1527268210137};\\\", \\\"{x:1605,y:749,t:1527268210150};\\\", \\\"{x:1605,y:748,t:1527268210177};\\\", \\\"{x:1605,y:747,t:1527268210217};\\\", \\\"{x:1605,y:746,t:1527268210234};\\\", \\\"{x:1605,y:745,t:1527268210257};\\\", \\\"{x:1606,y:743,t:1527268210320};\\\", \\\"{x:1609,y:748,t:1527268210465};\\\", \\\"{x:1611,y:755,t:1527268210472};\\\", \\\"{x:1616,y:765,t:1527268210484};\\\", \\\"{x:1619,y:779,t:1527268210501};\\\", \\\"{x:1622,y:793,t:1527268210516};\\\", \\\"{x:1624,y:806,t:1527268210533};\\\", \\\"{x:1626,y:824,t:1527268210551};\\\", \\\"{x:1631,y:843,t:1527268210566};\\\", \\\"{x:1632,y:858,t:1527268210584};\\\", \\\"{x:1636,y:879,t:1527268210600};\\\", \\\"{x:1640,y:897,t:1527268210618};\\\", \\\"{x:1643,y:915,t:1527268210634};\\\", \\\"{x:1647,y:930,t:1527268210650};\\\", \\\"{x:1651,y:941,t:1527268210667};\\\", \\\"{x:1652,y:947,t:1527268210683};\\\", \\\"{x:1653,y:950,t:1527268210700};\\\", \\\"{x:1653,y:952,t:1527268210717};\\\", \\\"{x:1653,y:955,t:1527268210733};\\\", \\\"{x:1653,y:958,t:1527268210751};\\\", \\\"{x:1648,y:964,t:1527268210768};\\\", \\\"{x:1646,y:965,t:1527268210784};\\\", \\\"{x:1640,y:970,t:1527268210801};\\\", \\\"{x:1635,y:972,t:1527268210818};\\\", \\\"{x:1632,y:973,t:1527268210834};\\\", \\\"{x:1627,y:975,t:1527268210851};\\\", \\\"{x:1624,y:977,t:1527268210868};\\\", \\\"{x:1622,y:977,t:1527268210884};\\\", \\\"{x:1621,y:978,t:1527268210901};\\\", \\\"{x:1620,y:978,t:1527268210993};\\\", \\\"{x:1620,y:976,t:1527268211008};\\\", \\\"{x:1618,y:975,t:1527268211018};\\\", \\\"{x:1618,y:971,t:1527268211034};\\\", \\\"{x:1618,y:968,t:1527268211052};\\\", \\\"{x:1618,y:963,t:1527268211068};\\\", \\\"{x:1618,y:960,t:1527268211085};\\\", \\\"{x:1618,y:957,t:1527268211101};\\\", \\\"{x:1618,y:954,t:1527268211119};\\\", \\\"{x:1618,y:950,t:1527268211135};\\\", \\\"{x:1618,y:947,t:1527268211151};\\\", \\\"{x:1618,y:946,t:1527268211168};\\\", \\\"{x:1616,y:942,t:1527268211185};\\\", \\\"{x:1616,y:939,t:1527268211201};\\\", \\\"{x:1616,y:938,t:1527268211225};\\\", \\\"{x:1616,y:937,t:1527268211236};\\\", \\\"{x:1616,y:936,t:1527268211251};\\\", \\\"{x:1616,y:935,t:1527268211268};\\\", \\\"{x:1616,y:933,t:1527268211285};\\\", \\\"{x:1616,y:932,t:1527268211304};\\\", \\\"{x:1615,y:931,t:1527268211329};\\\", \\\"{x:1615,y:930,t:1527268211344};\\\", \\\"{x:1615,y:928,t:1527268211353};\\\", \\\"{x:1615,y:927,t:1527268211369};\\\", \\\"{x:1615,y:925,t:1527268211385};\\\", \\\"{x:1615,y:924,t:1527268211401};\\\", \\\"{x:1615,y:921,t:1527268211418};\\\", \\\"{x:1615,y:920,t:1527268211436};\\\", \\\"{x:1615,y:917,t:1527268211452};\\\", \\\"{x:1615,y:916,t:1527268211469};\\\", \\\"{x:1615,y:914,t:1527268211485};\\\", \\\"{x:1615,y:912,t:1527268211502};\\\", \\\"{x:1615,y:909,t:1527268211518};\\\", \\\"{x:1615,y:906,t:1527268211535};\\\", \\\"{x:1615,y:901,t:1527268211552};\\\", \\\"{x:1615,y:899,t:1527268211568};\\\", \\\"{x:1615,y:891,t:1527268211584};\\\", \\\"{x:1615,y:880,t:1527268211603};\\\", \\\"{x:1615,y:867,t:1527268211618};\\\", \\\"{x:1615,y:856,t:1527268211635};\\\", \\\"{x:1614,y:847,t:1527268211652};\\\", \\\"{x:1614,y:843,t:1527268211668};\\\", \\\"{x:1614,y:841,t:1527268211685};\\\", \\\"{x:1614,y:838,t:1527268211702};\\\", \\\"{x:1614,y:837,t:1527268211720};\\\", \\\"{x:1614,y:836,t:1527268211735};\\\", \\\"{x:1614,y:835,t:1527268211752};\\\", \\\"{x:1614,y:834,t:1527268211768};\\\", \\\"{x:1614,y:833,t:1527268211785};\\\", \\\"{x:1614,y:832,t:1527268211816};\\\", \\\"{x:1614,y:831,t:1527268211840};\\\", \\\"{x:1614,y:830,t:1527268211856};\\\", \\\"{x:1614,y:829,t:1527268211873};\\\", \\\"{x:1614,y:828,t:1527268211897};\\\", \\\"{x:1614,y:827,t:1527268211904};\\\", \\\"{x:1614,y:826,t:1527268211918};\\\", \\\"{x:1614,y:823,t:1527268211934};\\\", \\\"{x:1614,y:819,t:1527268211952};\\\", \\\"{x:1613,y:817,t:1527268211969};\\\", \\\"{x:1613,y:815,t:1527268211986};\\\", \\\"{x:1613,y:812,t:1527268212003};\\\", \\\"{x:1613,y:810,t:1527268212019};\\\", \\\"{x:1613,y:809,t:1527268212036};\\\", \\\"{x:1613,y:807,t:1527268212052};\\\", \\\"{x:1613,y:806,t:1527268212069};\\\", \\\"{x:1613,y:804,t:1527268212086};\\\", \\\"{x:1613,y:801,t:1527268212102};\\\", \\\"{x:1613,y:799,t:1527268212119};\\\", \\\"{x:1613,y:796,t:1527268212135};\\\", \\\"{x:1613,y:792,t:1527268212152};\\\", \\\"{x:1613,y:785,t:1527268212169};\\\", \\\"{x:1613,y:780,t:1527268212185};\\\", \\\"{x:1613,y:775,t:1527268212202};\\\", \\\"{x:1613,y:770,t:1527268212219};\\\", \\\"{x:1613,y:767,t:1527268212235};\\\", \\\"{x:1613,y:764,t:1527268212252};\\\", \\\"{x:1613,y:763,t:1527268212269};\\\", \\\"{x:1613,y:761,t:1527268212285};\\\", \\\"{x:1613,y:760,t:1527268212302};\\\", \\\"{x:1613,y:758,t:1527268212319};\\\", \\\"{x:1613,y:757,t:1527268212335};\\\", \\\"{x:1613,y:756,t:1527268212377};\\\", \\\"{x:1613,y:755,t:1527268212417};\\\", \\\"{x:1613,y:754,t:1527268212458};\\\", \\\"{x:1613,y:753,t:1527268212473};\\\", \\\"{x:1613,y:752,t:1527268212497};\\\", \\\"{x:1613,y:751,t:1527268212545};\\\", \\\"{x:1613,y:749,t:1527268212561};\\\", \\\"{x:1613,y:748,t:1527268212577};\\\", \\\"{x:1613,y:746,t:1527268212586};\\\", \\\"{x:1613,y:745,t:1527268212602};\\\", \\\"{x:1613,y:741,t:1527268212619};\\\", \\\"{x:1613,y:735,t:1527268212636};\\\", \\\"{x:1613,y:730,t:1527268212652};\\\", \\\"{x:1612,y:729,t:1527268212669};\\\", \\\"{x:1612,y:727,t:1527268212687};\\\", \\\"{x:1612,y:724,t:1527268212703};\\\", \\\"{x:1612,y:721,t:1527268212719};\\\", \\\"{x:1610,y:718,t:1527268212737};\\\", \\\"{x:1610,y:717,t:1527268212752};\\\", \\\"{x:1610,y:715,t:1527268212777};\\\", \\\"{x:1610,y:714,t:1527268212809};\\\", \\\"{x:1610,y:712,t:1527268212825};\\\", \\\"{x:1610,y:711,t:1527268212841};\\\", \\\"{x:1610,y:709,t:1527268212857};\\\", \\\"{x:1610,y:708,t:1527268212897};\\\", \\\"{x:1610,y:706,t:1527268212945};\\\", \\\"{x:1610,y:705,t:1527268212961};\\\", \\\"{x:1610,y:703,t:1527268212985};\\\", \\\"{x:1610,y:702,t:1527268213003};\\\", \\\"{x:1610,y:700,t:1527268213019};\\\", \\\"{x:1610,y:699,t:1527268213036};\\\", \\\"{x:1610,y:697,t:1527268213056};\\\", \\\"{x:1610,y:696,t:1527268213081};\\\", \\\"{x:1610,y:694,t:1527268213113};\\\", \\\"{x:1610,y:693,t:1527268213121};\\\", \\\"{x:1610,y:692,t:1527268213137};\\\", \\\"{x:1610,y:691,t:1527268213153};\\\", \\\"{x:1610,y:689,t:1527268213169};\\\", \\\"{x:1610,y:688,t:1527268213187};\\\", \\\"{x:1610,y:685,t:1527268213203};\\\", \\\"{x:1610,y:680,t:1527268213219};\\\", \\\"{x:1610,y:674,t:1527268213237};\\\", \\\"{x:1611,y:665,t:1527268213253};\\\", \\\"{x:1611,y:654,t:1527268213270};\\\", \\\"{x:1612,y:644,t:1527268213287};\\\", \\\"{x:1613,y:635,t:1527268213303};\\\", \\\"{x:1616,y:622,t:1527268213321};\\\", \\\"{x:1616,y:618,t:1527268213337};\\\", \\\"{x:1617,y:606,t:1527268213352};\\\", \\\"{x:1618,y:598,t:1527268213370};\\\", \\\"{x:1620,y:587,t:1527268213386};\\\", \\\"{x:1621,y:574,t:1527268213402};\\\", \\\"{x:1621,y:557,t:1527268213420};\\\", \\\"{x:1621,y:535,t:1527268213436};\\\", \\\"{x:1620,y:526,t:1527268213453};\\\", \\\"{x:1619,y:519,t:1527268213470};\\\", \\\"{x:1618,y:514,t:1527268213486};\\\", \\\"{x:1617,y:514,t:1527268213503};\\\", \\\"{x:1617,y:513,t:1527268213520};\\\", \\\"{x:1616,y:515,t:1527268213745};\\\", \\\"{x:1616,y:517,t:1527268213754};\\\", \\\"{x:1613,y:520,t:1527268213770};\\\", \\\"{x:1613,y:526,t:1527268213787};\\\", \\\"{x:1613,y:533,t:1527268213803};\\\", \\\"{x:1613,y:538,t:1527268213820};\\\", \\\"{x:1613,y:541,t:1527268213837};\\\", \\\"{x:1613,y:545,t:1527268213853};\\\", \\\"{x:1613,y:546,t:1527268213870};\\\", \\\"{x:1612,y:545,t:1527268214225};\\\", \\\"{x:1611,y:545,t:1527268214281};\\\", \\\"{x:1610,y:545,t:1527268214291};\\\", \\\"{x:1608,y:545,t:1527268214312};\\\", \\\"{x:1607,y:545,t:1527268214319};\\\", \\\"{x:1602,y:546,t:1527268214336};\\\", \\\"{x:1594,y:552,t:1527268214353};\\\", \\\"{x:1588,y:557,t:1527268214370};\\\", \\\"{x:1582,y:564,t:1527268214386};\\\", \\\"{x:1577,y:569,t:1527268214404};\\\", \\\"{x:1576,y:570,t:1527268214420};\\\", \\\"{x:1577,y:570,t:1527268214857};\\\", \\\"{x:1577,y:569,t:1527268214880};\\\", \\\"{x:1579,y:568,t:1527268214913};\\\", \\\"{x:1580,y:567,t:1527268214929};\\\", \\\"{x:1581,y:565,t:1527268215002};\\\", \\\"{x:1582,y:565,t:1527268215016};\\\", \\\"{x:1582,y:564,t:1527268215025};\\\", \\\"{x:1583,y:564,t:1527268216297};\\\", \\\"{x:1584,y:564,t:1527268216306};\\\", \\\"{x:1585,y:569,t:1527268216322};\\\", \\\"{x:1585,y:574,t:1527268216339};\\\", \\\"{x:1584,y:584,t:1527268216355};\\\", \\\"{x:1569,y:601,t:1527268216372};\\\", \\\"{x:1523,y:631,t:1527268216389};\\\", \\\"{x:1435,y:657,t:1527268216406};\\\", \\\"{x:1323,y:675,t:1527268216422};\\\", \\\"{x:1186,y:685,t:1527268216439};\\\", \\\"{x:1052,y:691,t:1527268216455};\\\", \\\"{x:939,y:691,t:1527268216473};\\\", \\\"{x:843,y:693,t:1527268216488};\\\", \\\"{x:829,y:693,t:1527268216505};\\\", \\\"{x:828,y:693,t:1527268216522};\\\", \\\"{x:827,y:693,t:1527268216690};\\\", \\\"{x:819,y:687,t:1527268216705};\\\", \\\"{x:808,y:681,t:1527268216722};\\\", \\\"{x:784,y:673,t:1527268216739};\\\", \\\"{x:762,y:668,t:1527268216755};\\\", \\\"{x:740,y:664,t:1527268216772};\\\", \\\"{x:720,y:662,t:1527268216789};\\\", \\\"{x:704,y:660,t:1527268216806};\\\", \\\"{x:684,y:659,t:1527268216822};\\\", \\\"{x:667,y:659,t:1527268216839};\\\", \\\"{x:630,y:659,t:1527268216856};\\\", \\\"{x:603,y:659,t:1527268216872};\\\", \\\"{x:573,y:659,t:1527268216890};\\\", \\\"{x:542,y:659,t:1527268216906};\\\", \\\"{x:510,y:657,t:1527268216922};\\\", \\\"{x:484,y:657,t:1527268216939};\\\", \\\"{x:462,y:655,t:1527268216956};\\\", \\\"{x:448,y:654,t:1527268216972};\\\", \\\"{x:438,y:652,t:1527268216989};\\\", \\\"{x:429,y:651,t:1527268217006};\\\", \\\"{x:422,y:650,t:1527268217024};\\\", \\\"{x:415,y:647,t:1527268217038};\\\", \\\"{x:404,y:645,t:1527268217056};\\\", \\\"{x:397,y:642,t:1527268217071};\\\", \\\"{x:387,y:638,t:1527268217089};\\\", \\\"{x:382,y:634,t:1527268217105};\\\", \\\"{x:378,y:627,t:1527268217123};\\\", \\\"{x:375,y:620,t:1527268217139};\\\", \\\"{x:371,y:612,t:1527268217156};\\\", \\\"{x:369,y:606,t:1527268217173};\\\", \\\"{x:369,y:601,t:1527268217190};\\\", \\\"{x:366,y:598,t:1527268217206};\\\", \\\"{x:366,y:596,t:1527268217222};\\\", \\\"{x:366,y:593,t:1527268217240};\\\", \\\"{x:366,y:592,t:1527268217256};\\\", \\\"{x:366,y:591,t:1527268217273};\\\", \\\"{x:365,y:591,t:1527268217921};\\\", \\\"{x:364,y:592,t:1527268217953};\\\", \\\"{x:364,y:593,t:1527268218016};\\\", \\\"{x:363,y:594,t:1527268218056};\\\", \\\"{x:362,y:595,t:1527268218081};\\\", \\\"{x:362,y:596,t:1527268218097};\\\", \\\"{x:361,y:597,t:1527268218120};\\\", \\\"{x:361,y:598,t:1527268218136};\\\", \\\"{x:360,y:598,t:1527268218161};\\\", \\\"{x:360,y:599,t:1527268218177};\\\", \\\"{x:360,y:600,t:1527268218200};\\\", \\\"{x:360,y:602,t:1527268218232};\\\", \\\"{x:360,y:604,t:1527268218242};\\\", \\\"{x:380,y:615,t:1527268218261};\\\", \\\"{x:415,y:622,t:1527268218276};\\\", \\\"{x:473,y:630,t:1527268218289};\\\", \\\"{x:531,y:645,t:1527268218306};\\\", \\\"{x:571,y:656,t:1527268218323};\\\", \\\"{x:589,y:659,t:1527268218340};\\\", \\\"{x:607,y:665,t:1527268218356};\\\", \\\"{x:625,y:668,t:1527268218373};\\\", \\\"{x:630,y:668,t:1527268218389};\\\", \\\"{x:639,y:668,t:1527268218407};\\\", \\\"{x:656,y:668,t:1527268218423};\\\", \\\"{x:704,y:668,t:1527268218439};\\\", \\\"{x:752,y:677,t:1527268218456};\\\", \\\"{x:808,y:685,t:1527268218473};\\\", \\\"{x:875,y:696,t:1527268218490};\\\", \\\"{x:951,y:708,t:1527268218506};\\\", \\\"{x:1026,y:717,t:1527268218524};\\\", \\\"{x:1090,y:726,t:1527268218540};\\\", \\\"{x:1168,y:729,t:1527268218556};\\\", \\\"{x:1227,y:736,t:1527268218573};\\\", \\\"{x:1278,y:739,t:1527268218590};\\\", \\\"{x:1333,y:745,t:1527268218606};\\\", \\\"{x:1380,y:750,t:1527268218624};\\\", \\\"{x:1417,y:750,t:1527268218640};\\\", \\\"{x:1487,y:757,t:1527268218657};\\\", \\\"{x:1548,y:757,t:1527268218672};\\\", \\\"{x:1601,y:757,t:1527268218690};\\\", \\\"{x:1652,y:757,t:1527268218707};\\\", \\\"{x:1687,y:757,t:1527268218723};\\\", \\\"{x:1712,y:753,t:1527268218740};\\\", \\\"{x:1727,y:745,t:1527268218755};\\\", \\\"{x:1733,y:741,t:1527268218772};\\\", \\\"{x:1735,y:737,t:1527268218789};\\\", \\\"{x:1736,y:730,t:1527268218806};\\\", \\\"{x:1736,y:719,t:1527268218822};\\\", \\\"{x:1736,y:712,t:1527268218839};\\\", \\\"{x:1736,y:703,t:1527268218855};\\\", \\\"{x:1736,y:687,t:1527268218873};\\\", \\\"{x:1736,y:676,t:1527268218890};\\\", \\\"{x:1734,y:660,t:1527268218905};\\\", \\\"{x:1730,y:651,t:1527268218922};\\\", \\\"{x:1725,y:642,t:1527268218938};\\\", \\\"{x:1717,y:633,t:1527268218955};\\\", \\\"{x:1707,y:625,t:1527268218972};\\\", \\\"{x:1699,y:617,t:1527268218989};\\\", \\\"{x:1684,y:609,t:1527268219006};\\\", \\\"{x:1676,y:606,t:1527268219021};\\\", \\\"{x:1674,y:605,t:1527268219039};\\\", \\\"{x:1672,y:604,t:1527268219055};\\\", \\\"{x:1672,y:603,t:1527268219072};\\\", \\\"{x:1669,y:603,t:1527268219090};\\\", \\\"{x:1668,y:602,t:1527268219104};\\\", \\\"{x:1663,y:599,t:1527268219121};\\\", \\\"{x:1658,y:597,t:1527268219138};\\\", \\\"{x:1651,y:594,t:1527268219154};\\\", \\\"{x:1645,y:591,t:1527268219172};\\\", \\\"{x:1637,y:588,t:1527268219188};\\\", \\\"{x:1632,y:586,t:1527268219205};\\\", \\\"{x:1628,y:585,t:1527268219220};\\\", \\\"{x:1624,y:584,t:1527268219237};\\\", \\\"{x:1623,y:584,t:1527268219255};\\\", \\\"{x:1622,y:584,t:1527268219270};\\\", \\\"{x:1621,y:584,t:1527268219287};\\\", \\\"{x:1621,y:586,t:1527268219336};\\\", \\\"{x:1621,y:594,t:1527268219353};\\\", \\\"{x:1622,y:604,t:1527268219370};\\\", \\\"{x:1625,y:615,t:1527268219387};\\\", \\\"{x:1629,y:621,t:1527268219402};\\\", \\\"{x:1629,y:624,t:1527268219420};\\\", \\\"{x:1630,y:628,t:1527268219436};\\\", \\\"{x:1630,y:631,t:1527268219453};\\\", \\\"{x:1630,y:635,t:1527268219470};\\\", \\\"{x:1627,y:640,t:1527268219486};\\\", \\\"{x:1625,y:645,t:1527268219502};\\\", \\\"{x:1621,y:650,t:1527268219519};\\\", \\\"{x:1617,y:654,t:1527268219536};\\\", \\\"{x:1616,y:656,t:1527268219569};\\\", \\\"{x:1616,y:657,t:1527268219586};\\\", \\\"{x:1615,y:660,t:1527268219602};\\\", \\\"{x:1614,y:661,t:1527268219619};\\\", \\\"{x:1613,y:663,t:1527268219636};\\\", \\\"{x:1611,y:666,t:1527268219652};\\\", \\\"{x:1609,y:669,t:1527268219668};\\\", \\\"{x:1602,y:675,t:1527268219685};\\\", \\\"{x:1594,y:680,t:1527268219701};\\\", \\\"{x:1582,y:689,t:1527268219718};\\\", \\\"{x:1559,y:700,t:1527268219735};\\\", \\\"{x:1497,y:723,t:1527268219752};\\\", \\\"{x:1440,y:733,t:1527268219768};\\\", \\\"{x:1373,y:741,t:1527268219785};\\\", \\\"{x:1294,y:747,t:1527268219802};\\\", \\\"{x:1215,y:752,t:1527268219818};\\\", \\\"{x:1137,y:752,t:1527268219835};\\\", \\\"{x:1076,y:752,t:1527268219851};\\\", \\\"{x:1049,y:752,t:1527268219868};\\\", \\\"{x:1034,y:754,t:1527268219885};\\\", \\\"{x:1029,y:756,t:1527268219901};\\\", \\\"{x:1027,y:757,t:1527268219919};\\\", \\\"{x:1026,y:758,t:1527268219935};\\\", \\\"{x:1026,y:759,t:1527268219985};\\\", \\\"{x:1027,y:759,t:1527268220057};\\\", \\\"{x:1028,y:759,t:1527268220068};\\\", \\\"{x:1033,y:758,t:1527268220084};\\\", \\\"{x:1034,y:757,t:1527268220101};\\\", \\\"{x:1035,y:756,t:1527268220117};\\\", \\\"{x:1036,y:751,t:1527268220134};\\\", \\\"{x:1037,y:750,t:1527268220150};\\\", \\\"{x:1038,y:749,t:1527268220168};\\\", \\\"{x:1039,y:747,t:1527268220184};\\\", \\\"{x:1039,y:744,t:1527268220200};\\\", \\\"{x:1039,y:743,t:1527268220233};\\\", \\\"{x:1039,y:742,t:1527268220250};\\\", \\\"{x:1039,y:741,t:1527268220267};\\\", \\\"{x:1041,y:738,t:1527268220284};\\\", \\\"{x:1041,y:737,t:1527268220299};\\\", \\\"{x:1042,y:735,t:1527268220316};\\\", \\\"{x:1042,y:734,t:1527268220332};\\\", \\\"{x:1044,y:730,t:1527268220349};\\\", \\\"{x:1045,y:728,t:1527268220366};\\\", \\\"{x:1045,y:727,t:1527268220382};\\\", \\\"{x:1046,y:724,t:1527268220399};\\\", \\\"{x:1047,y:721,t:1527268220416};\\\", \\\"{x:1048,y:719,t:1527268220433};\\\", \\\"{x:1049,y:716,t:1527268220449};\\\", \\\"{x:1051,y:713,t:1527268220466};\\\", \\\"{x:1052,y:709,t:1527268220483};\\\", \\\"{x:1054,y:706,t:1527268220499};\\\", \\\"{x:1055,y:705,t:1527268220516};\\\", \\\"{x:1056,y:703,t:1527268220532};\\\", \\\"{x:1056,y:702,t:1527268220584};\\\", \\\"{x:1056,y:701,t:1527268220599};\\\", \\\"{x:1058,y:701,t:1527268220615};\\\", \\\"{x:1069,y:699,t:1527268220632};\\\", \\\"{x:1089,y:699,t:1527268220649};\\\", \\\"{x:1116,y:699,t:1527268220665};\\\", \\\"{x:1160,y:708,t:1527268220682};\\\", \\\"{x:1224,y:727,t:1527268220698};\\\", \\\"{x:1302,y:749,t:1527268220715};\\\", \\\"{x:1399,y:779,t:1527268220732};\\\", \\\"{x:1481,y:808,t:1527268220748};\\\", \\\"{x:1566,y:842,t:1527268220765};\\\", \\\"{x:1627,y:868,t:1527268220782};\\\", \\\"{x:1665,y:884,t:1527268220798};\\\", \\\"{x:1683,y:897,t:1527268220815};\\\", \\\"{x:1691,y:906,t:1527268220832};\\\", \\\"{x:1693,y:918,t:1527268220848};\\\", \\\"{x:1695,y:933,t:1527268220864};\\\", \\\"{x:1704,y:957,t:1527268220882};\\\", \\\"{x:1721,y:987,t:1527268220898};\\\", \\\"{x:1740,y:1012,t:1527268220915};\\\", \\\"{x:1758,y:1031,t:1527268220931};\\\", \\\"{x:1769,y:1041,t:1527268220949};\\\", \\\"{x:1771,y:1043,t:1527268220964};\\\", \\\"{x:1768,y:1042,t:1527268221049};\\\", \\\"{x:1749,y:1037,t:1527268221065};\\\", \\\"{x:1727,y:1031,t:1527268221080};\\\", \\\"{x:1704,y:1025,t:1527268221097};\\\", \\\"{x:1694,y:1024,t:1527268221114};\\\", \\\"{x:1692,y:1023,t:1527268221131};\\\", \\\"{x:1691,y:1023,t:1527268221201};\\\", \\\"{x:1690,y:1023,t:1527268221213};\\\", \\\"{x:1687,y:1022,t:1527268221230};\\\", \\\"{x:1681,y:1018,t:1527268221246};\\\", \\\"{x:1676,y:1015,t:1527268221263};\\\", \\\"{x:1665,y:1008,t:1527268221281};\\\", \\\"{x:1660,y:1004,t:1527268221296};\\\", \\\"{x:1654,y:1000,t:1527268221313};\\\", \\\"{x:1646,y:995,t:1527268221329};\\\", \\\"{x:1634,y:990,t:1527268221346};\\\", \\\"{x:1628,y:987,t:1527268221363};\\\", \\\"{x:1624,y:985,t:1527268221379};\\\", \\\"{x:1622,y:985,t:1527268221449};\\\", \\\"{x:1618,y:984,t:1527268221463};\\\", \\\"{x:1608,y:983,t:1527268221479};\\\", \\\"{x:1594,y:981,t:1527268221496};\\\", \\\"{x:1591,y:981,t:1527268221512};\\\", \\\"{x:1590,y:980,t:1527268221529};\\\", \\\"{x:1595,y:980,t:1527268221777};\\\", \\\"{x:1601,y:979,t:1527268221794};\\\", \\\"{x:1612,y:978,t:1527268221811};\\\", \\\"{x:1614,y:978,t:1527268221828};\\\", \\\"{x:1615,y:977,t:1527268221913};\\\", \\\"{x:1615,y:974,t:1527268221927};\\\", \\\"{x:1585,y:954,t:1527268221945};\\\", \\\"{x:1538,y:921,t:1527268221961};\\\", \\\"{x:1476,y:878,t:1527268221978};\\\", \\\"{x:1412,y:832,t:1527268221995};\\\", \\\"{x:1337,y:780,t:1527268222011};\\\", \\\"{x:1283,y:742,t:1527268222028};\\\", \\\"{x:1250,y:715,t:1527268222044};\\\", \\\"{x:1238,y:700,t:1527268222060};\\\", \\\"{x:1232,y:686,t:1527268222077};\\\", \\\"{x:1228,y:671,t:1527268222093};\\\", \\\"{x:1223,y:655,t:1527268222110};\\\", \\\"{x:1217,y:634,t:1527268222127};\\\", \\\"{x:1210,y:617,t:1527268222143};\\\", \\\"{x:1196,y:593,t:1527268222160};\\\", \\\"{x:1188,y:580,t:1527268222176};\\\", \\\"{x:1180,y:570,t:1527268222193};\\\", \\\"{x:1173,y:558,t:1527268222210};\\\", \\\"{x:1168,y:543,t:1527268222226};\\\", \\\"{x:1160,y:524,t:1527268222243};\\\", \\\"{x:1151,y:501,t:1527268222260};\\\", \\\"{x:1138,y:481,t:1527268222276};\\\", \\\"{x:1127,y:466,t:1527268222293};\\\", \\\"{x:1117,y:454,t:1527268222309};\\\", \\\"{x:1109,y:442,t:1527268222327};\\\", \\\"{x:1098,y:428,t:1527268222342};\\\", \\\"{x:1089,y:416,t:1527268222359};\\\", \\\"{x:1080,y:405,t:1527268222376};\\\", \\\"{x:1074,y:401,t:1527268222393};\\\", \\\"{x:1072,y:400,t:1527268222410};\\\", \\\"{x:1071,y:402,t:1527268222521};\\\", \\\"{x:1071,y:407,t:1527268222529};\\\", \\\"{x:1071,y:411,t:1527268222543};\\\", \\\"{x:1072,y:421,t:1527268222559};\\\", \\\"{x:1075,y:428,t:1527268222575};\\\", \\\"{x:1077,y:431,t:1527268222593};\\\", \\\"{x:1077,y:432,t:1527268222841};\\\", \\\"{x:1077,y:433,t:1527268222858};\\\", \\\"{x:1078,y:434,t:1527268226353};\\\", \\\"{x:1087,y:436,t:1527268226362};\\\", \\\"{x:1128,y:450,t:1527268226378};\\\", \\\"{x:1178,y:472,t:1527268226395};\\\", \\\"{x:1239,y:502,t:1527268226412};\\\", \\\"{x:1284,y:531,t:1527268226428};\\\", \\\"{x:1322,y:571,t:1527268226445};\\\", \\\"{x:1363,y:632,t:1527268226462};\\\", \\\"{x:1404,y:698,t:1527268226478};\\\", \\\"{x:1447,y:772,t:1527268226495};\\\", \\\"{x:1501,y:847,t:1527268226512};\\\", \\\"{x:1543,y:901,t:1527268226527};\\\", \\\"{x:1565,y:935,t:1527268226545};\\\", \\\"{x:1571,y:946,t:1527268226561};\\\", \\\"{x:1574,y:953,t:1527268226577};\\\", \\\"{x:1575,y:960,t:1527268226594};\\\", \\\"{x:1575,y:965,t:1527268226611};\\\", \\\"{x:1578,y:970,t:1527268226628};\\\", \\\"{x:1578,y:975,t:1527268226644};\\\", \\\"{x:1578,y:978,t:1527268226661};\\\", \\\"{x:1578,y:979,t:1527268226678};\\\", \\\"{x:1578,y:980,t:1527268226694};\\\", \\\"{x:1579,y:981,t:1527268226711};\\\", \\\"{x:1580,y:985,t:1527268226728};\\\", \\\"{x:1581,y:986,t:1527268226744};\\\", \\\"{x:1582,y:987,t:1527268226760};\\\", \\\"{x:1583,y:987,t:1527268226833};\\\", \\\"{x:1585,y:987,t:1527268226844};\\\", \\\"{x:1587,y:985,t:1527268226860};\\\", \\\"{x:1589,y:984,t:1527268226877};\\\", \\\"{x:1592,y:981,t:1527268226893};\\\", \\\"{x:1594,y:980,t:1527268226909};\\\", \\\"{x:1596,y:978,t:1527268226926};\\\", \\\"{x:1598,y:977,t:1527268226943};\\\", \\\"{x:1600,y:976,t:1527268226960};\\\", \\\"{x:1605,y:973,t:1527268226977};\\\", \\\"{x:1610,y:969,t:1527268226993};\\\", \\\"{x:1614,y:966,t:1527268227010};\\\", \\\"{x:1616,y:966,t:1527268227026};\\\", \\\"{x:1618,y:965,t:1527268227043};\\\", \\\"{x:1616,y:964,t:1527268229208};\\\", \\\"{x:1614,y:964,t:1527268229218};\\\", \\\"{x:1612,y:964,t:1527268229234};\\\", \\\"{x:1611,y:964,t:1527268229255};\\\", \\\"{x:1611,y:963,t:1527268231665};\\\", \\\"{x:1610,y:962,t:1527268231676};\\\", \\\"{x:1609,y:962,t:1527268231693};\\\", \\\"{x:1607,y:961,t:1527268231709};\\\", \\\"{x:1605,y:960,t:1527268231726};\\\", \\\"{x:1604,y:960,t:1527268231743};\\\", \\\"{x:1603,y:959,t:1527268231759};\\\", \\\"{x:1602,y:959,t:1527268231785};\\\", \\\"{x:1601,y:959,t:1527268231809};\\\", \\\"{x:1600,y:958,t:1527268231826};\\\", \\\"{x:1599,y:958,t:1527268231842};\\\", \\\"{x:1598,y:957,t:1527268231873};\\\", \\\"{x:1598,y:956,t:1527268231897};\\\", \\\"{x:1597,y:956,t:1527268231912};\\\", \\\"{x:1596,y:955,t:1527268231936};\\\", \\\"{x:1595,y:951,t:1527268235585};\\\", \\\"{x:1592,y:928,t:1527268235595};\\\", \\\"{x:1581,y:834,t:1527268235612};\\\", \\\"{x:1554,y:710,t:1527268235630};\\\", \\\"{x:1523,y:589,t:1527268235646};\\\", \\\"{x:1500,y:508,t:1527268235662};\\\", \\\"{x:1492,y:487,t:1527268235678};\\\", \\\"{x:1490,y:477,t:1527268235695};\\\", \\\"{x:1490,y:470,t:1527268235711};\\\", \\\"{x:1490,y:473,t:1527268235807};\\\", \\\"{x:1490,y:486,t:1527268235816};\\\", \\\"{x:1490,y:500,t:1527268235828};\\\", \\\"{x:1490,y:539,t:1527268235844};\\\", \\\"{x:1499,y:583,t:1527268235861};\\\", \\\"{x:1510,y:619,t:1527268235878};\\\", \\\"{x:1518,y:642,t:1527268235894};\\\", \\\"{x:1523,y:652,t:1527268235911};\\\", \\\"{x:1524,y:655,t:1527268235927};\\\", \\\"{x:1524,y:657,t:1527268235944};\\\", \\\"{x:1524,y:658,t:1527268235961};\\\", \\\"{x:1524,y:659,t:1527268235977};\\\", \\\"{x:1522,y:653,t:1527268236121};\\\", \\\"{x:1521,y:649,t:1527268236128};\\\", \\\"{x:1519,y:643,t:1527268236144};\\\", \\\"{x:1513,y:629,t:1527268236162};\\\", \\\"{x:1510,y:623,t:1527268236176};\\\", \\\"{x:1510,y:622,t:1527268236193};\\\", \\\"{x:1509,y:623,t:1527268236449};\\\", \\\"{x:1509,y:625,t:1527268236459};\\\", \\\"{x:1509,y:627,t:1527268236475};\\\", \\\"{x:1509,y:628,t:1527268236509};\\\", \\\"{x:1509,y:631,t:1527268237873};\\\", \\\"{x:1509,y:637,t:1527268237888};\\\", \\\"{x:1505,y:663,t:1527268237904};\\\", \\\"{x:1504,y:684,t:1527268237920};\\\", \\\"{x:1503,y:706,t:1527268237937};\\\", \\\"{x:1500,y:728,t:1527268237953};\\\", \\\"{x:1497,y:751,t:1527268237970};\\\", \\\"{x:1493,y:772,t:1527268237988};\\\", \\\"{x:1492,y:790,t:1527268238003};\\\", \\\"{x:1492,y:808,t:1527268238021};\\\", \\\"{x:1492,y:819,t:1527268238037};\\\", \\\"{x:1492,y:825,t:1527268238053};\\\", \\\"{x:1492,y:829,t:1527268238070};\\\", \\\"{x:1492,y:830,t:1527268238086};\\\", \\\"{x:1493,y:834,t:1527268238103};\\\", \\\"{x:1493,y:836,t:1527268238120};\\\", \\\"{x:1493,y:838,t:1527268238136};\\\", \\\"{x:1493,y:839,t:1527268238153};\\\", \\\"{x:1493,y:840,t:1527268238353};\\\", \\\"{x:1492,y:840,t:1527268238400};\\\", \\\"{x:1491,y:840,t:1527268238408};\\\", \\\"{x:1490,y:840,t:1527268238425};\\\", \\\"{x:1490,y:839,t:1527268238440};\\\", \\\"{x:1489,y:839,t:1527268238472};\\\", \\\"{x:1489,y:838,t:1527268238504};\\\", \\\"{x:1488,y:838,t:1527268238520};\\\", \\\"{x:1487,y:837,t:1527268238536};\\\", \\\"{x:1486,y:836,t:1527268238551};\\\", \\\"{x:1484,y:833,t:1527268238569};\\\", \\\"{x:1483,y:830,t:1527268238584};\\\", \\\"{x:1483,y:826,t:1527268238601};\\\", \\\"{x:1480,y:823,t:1527268238619};\\\", \\\"{x:1479,y:823,t:1527268238984};\\\", \\\"{x:1479,y:824,t:1527268239008};\\\", \\\"{x:1479,y:825,t:1527268239025};\\\", \\\"{x:1478,y:826,t:1527268239049};\\\", \\\"{x:1478,y:827,t:1527268239177};\\\", \\\"{x:1477,y:828,t:1527268239184};\\\", \\\"{x:1477,y:826,t:1527268241865};\\\", \\\"{x:1477,y:825,t:1527268242074};\\\", \\\"{x:1477,y:823,t:1527268242088};\\\", \\\"{x:1477,y:822,t:1527268242106};\\\", \\\"{x:1477,y:820,t:1527268242122};\\\", \\\"{x:1477,y:819,t:1527268242138};\\\", \\\"{x:1477,y:817,t:1527268242155};\\\", \\\"{x:1477,y:816,t:1527268242172};\\\", \\\"{x:1477,y:813,t:1527268242188};\\\", \\\"{x:1477,y:809,t:1527268242206};\\\", \\\"{x:1477,y:806,t:1527268242222};\\\", \\\"{x:1477,y:802,t:1527268242238};\\\", \\\"{x:1477,y:799,t:1527268242254};\\\", \\\"{x:1477,y:796,t:1527268242272};\\\", \\\"{x:1477,y:790,t:1527268242289};\\\", \\\"{x:1477,y:786,t:1527268242304};\\\", \\\"{x:1477,y:782,t:1527268242321};\\\", \\\"{x:1477,y:777,t:1527268242338};\\\", \\\"{x:1477,y:775,t:1527268242354};\\\", \\\"{x:1477,y:770,t:1527268242371};\\\", \\\"{x:1477,y:768,t:1527268242387};\\\", \\\"{x:1477,y:764,t:1527268242403};\\\", \\\"{x:1477,y:761,t:1527268242421};\\\", \\\"{x:1477,y:757,t:1527268242437};\\\", \\\"{x:1477,y:754,t:1527268242454};\\\", \\\"{x:1477,y:753,t:1527268242470};\\\", \\\"{x:1477,y:750,t:1527268242486};\\\", \\\"{x:1477,y:747,t:1527268242504};\\\", \\\"{x:1477,y:745,t:1527268242520};\\\", \\\"{x:1477,y:744,t:1527268242537};\\\", \\\"{x:1477,y:742,t:1527268242553};\\\", \\\"{x:1477,y:738,t:1527268242570};\\\", \\\"{x:1477,y:735,t:1527268242587};\\\", \\\"{x:1477,y:732,t:1527268242603};\\\", \\\"{x:1477,y:729,t:1527268242621};\\\", \\\"{x:1477,y:726,t:1527268242636};\\\", \\\"{x:1477,y:721,t:1527268242653};\\\", \\\"{x:1477,y:719,t:1527268242670};\\\", \\\"{x:1477,y:716,t:1527268242686};\\\", \\\"{x:1477,y:712,t:1527268242702};\\\", \\\"{x:1477,y:711,t:1527268242718};\\\", \\\"{x:1477,y:710,t:1527268242736};\\\", \\\"{x:1477,y:709,t:1527268242753};\\\", \\\"{x:1477,y:711,t:1527268243913};\\\", \\\"{x:1478,y:720,t:1527268243921};\\\", \\\"{x:1479,y:728,t:1527268243932};\\\", \\\"{x:1479,y:740,t:1527268243948};\\\", \\\"{x:1482,y:756,t:1527268243965};\\\", \\\"{x:1483,y:767,t:1527268243982};\\\", \\\"{x:1484,y:773,t:1527268243998};\\\", \\\"{x:1485,y:776,t:1527268244016};\\\", \\\"{x:1485,y:777,t:1527268244040};\\\", \\\"{x:1485,y:778,t:1527268244048};\\\", \\\"{x:1485,y:779,t:1527268244065};\\\", \\\"{x:1485,y:780,t:1527268244082};\\\", \\\"{x:1485,y:781,t:1527268244098};\\\", \\\"{x:1485,y:782,t:1527268244128};\\\", \\\"{x:1485,y:783,t:1527268244209};\\\", \\\"{x:1485,y:785,t:1527268244216};\\\", \\\"{x:1485,y:786,t:1527268244232};\\\", \\\"{x:1483,y:790,t:1527268244248};\\\", \\\"{x:1482,y:796,t:1527268244264};\\\", \\\"{x:1482,y:797,t:1527268244280};\\\", \\\"{x:1481,y:800,t:1527268244296};\\\", \\\"{x:1480,y:804,t:1527268244313};\\\", \\\"{x:1480,y:806,t:1527268244330};\\\", \\\"{x:1479,y:810,t:1527268244347};\\\", \\\"{x:1479,y:813,t:1527268244363};\\\", \\\"{x:1478,y:815,t:1527268244380};\\\", \\\"{x:1478,y:817,t:1527268244397};\\\", \\\"{x:1478,y:818,t:1527268244413};\\\", \\\"{x:1478,y:820,t:1527268244429};\\\", \\\"{x:1478,y:822,t:1527268244446};\\\", \\\"{x:1476,y:823,t:1527268244463};\\\", \\\"{x:1475,y:825,t:1527268244504};\\\", \\\"{x:1475,y:827,t:1527268244520};\\\", \\\"{x:1473,y:827,t:1527268244530};\\\", \\\"{x:1468,y:831,t:1527268244546};\\\", \\\"{x:1454,y:836,t:1527268244563};\\\", \\\"{x:1421,y:836,t:1527268244579};\\\", \\\"{x:1330,y:836,t:1527268244596};\\\", \\\"{x:1204,y:827,t:1527268244613};\\\", \\\"{x:1062,y:805,t:1527268244629};\\\", \\\"{x:918,y:782,t:1527268244647};\\\", \\\"{x:789,y:756,t:1527268244662};\\\", \\\"{x:708,y:743,t:1527268244679};\\\", \\\"{x:666,y:734,t:1527268244696};\\\", \\\"{x:661,y:732,t:1527268244712};\\\", \\\"{x:660,y:730,t:1527268244744};\\\", \\\"{x:657,y:727,t:1527268244753};\\\", \\\"{x:656,y:721,t:1527268244763};\\\", \\\"{x:651,y:710,t:1527268244779};\\\", \\\"{x:641,y:698,t:1527268244796};\\\", \\\"{x:637,y:687,t:1527268244813};\\\", \\\"{x:631,y:676,t:1527268244828};\\\", \\\"{x:628,y:668,t:1527268244846};\\\", \\\"{x:628,y:659,t:1527268244862};\\\", \\\"{x:627,y:647,t:1527268244879};\\\", \\\"{x:627,y:636,t:1527268244895};\\\", \\\"{x:626,y:622,t:1527268244911};\\\", \\\"{x:625,y:615,t:1527268244929};\\\", \\\"{x:623,y:609,t:1527268244947};\\\", \\\"{x:622,y:603,t:1527268244962};\\\", \\\"{x:621,y:599,t:1527268244979};\\\", \\\"{x:621,y:595,t:1527268244996};\\\", \\\"{x:621,y:593,t:1527268245013};\\\", \\\"{x:621,y:592,t:1527268245029};\\\", \\\"{x:621,y:591,t:1527268245045};\\\", \\\"{x:621,y:590,t:1527268245063};\\\", \\\"{x:621,y:589,t:1527268245079};\\\", \\\"{x:618,y:590,t:1527268245336};\\\", \\\"{x:613,y:594,t:1527268245346};\\\", \\\"{x:609,y:603,t:1527268245362};\\\", \\\"{x:604,y:618,t:1527268245380};\\\", \\\"{x:599,y:641,t:1527268245397};\\\", \\\"{x:594,y:667,t:1527268245414};\\\", \\\"{x:591,y:691,t:1527268245430};\\\", \\\"{x:588,y:707,t:1527268245446};\\\", \\\"{x:586,y:722,t:1527268245463};\\\", \\\"{x:584,y:734,t:1527268245480};\\\", \\\"{x:584,y:738,t:1527268245495};\\\", \\\"{x:584,y:739,t:1527268245513};\\\", \\\"{x:583,y:743,t:1527268245530};\\\", \\\"{x:582,y:745,t:1527268245545};\\\", \\\"{x:582,y:746,t:1527268245563};\\\", \\\"{x:581,y:749,t:1527268245580};\\\", \\\"{x:578,y:750,t:1527268245595};\\\", \\\"{x:576,y:752,t:1527268245613};\\\", \\\"{x:573,y:753,t:1527268245630};\\\", \\\"{x:569,y:753,t:1527268245646};\\\", \\\"{x:562,y:753,t:1527268245663};\\\", \\\"{x:542,y:745,t:1527268245680};\\\", \\\"{x:533,y:740,t:1527268245697};\\\", \\\"{x:526,y:733,t:1527268245715};\\\", \\\"{x:521,y:728,t:1527268245729};\\\", \\\"{x:518,y:724,t:1527268245747};\\\", \\\"{x:515,y:720,t:1527268245764};\\\", \\\"{x:512,y:715,t:1527268245779};\\\", \\\"{x:510,y:713,t:1527268245797};\\\", \\\"{x:510,y:710,t:1527268245813};\\\", \\\"{x:508,y:707,t:1527268245830};\\\", \\\"{x:508,y:708,t:1527268247040};\\\" ] }, { \\\"rt\\\": 99016, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 390224, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -01 PM-02 PM-03 PM-03 PM-U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:708,t:1527268248205};\\\", \\\"{x:516,y:708,t:1527268248215};\\\", \\\"{x:529,y:710,t:1527268248231};\\\", \\\"{x:539,y:711,t:1527268248248};\\\", \\\"{x:549,y:712,t:1527268248265};\\\", \\\"{x:560,y:715,t:1527268248282};\\\", \\\"{x:570,y:716,t:1527268248298};\\\", \\\"{x:580,y:717,t:1527268248315};\\\", \\\"{x:589,y:717,t:1527268248331};\\\", \\\"{x:598,y:717,t:1527268248348};\\\", \\\"{x:611,y:717,t:1527268248365};\\\", \\\"{x:628,y:720,t:1527268248382};\\\", \\\"{x:648,y:722,t:1527268248398};\\\", \\\"{x:666,y:726,t:1527268248415};\\\", \\\"{x:694,y:731,t:1527268248431};\\\", \\\"{x:712,y:732,t:1527268248449};\\\", \\\"{x:730,y:735,t:1527268248465};\\\", \\\"{x:748,y:741,t:1527268248482};\\\", \\\"{x:755,y:742,t:1527268248499};\\\", \\\"{x:764,y:745,t:1527268248516};\\\", \\\"{x:773,y:747,t:1527268248532};\\\", \\\"{x:785,y:752,t:1527268248549};\\\", \\\"{x:799,y:756,t:1527268248565};\\\", \\\"{x:820,y:761,t:1527268248582};\\\", \\\"{x:836,y:766,t:1527268248599};\\\", \\\"{x:852,y:771,t:1527268248615};\\\", \\\"{x:874,y:777,t:1527268248632};\\\", \\\"{x:888,y:781,t:1527268248650};\\\", \\\"{x:899,y:783,t:1527268248665};\\\", \\\"{x:913,y:788,t:1527268248682};\\\", \\\"{x:926,y:791,t:1527268248699};\\\", \\\"{x:935,y:794,t:1527268248715};\\\", \\\"{x:939,y:795,t:1527268248733};\\\", \\\"{x:941,y:796,t:1527268248749};\\\", \\\"{x:941,y:797,t:1527268249185};\\\", \\\"{x:943,y:796,t:1527268253152};\\\", \\\"{x:947,y:794,t:1527268253168};\\\", \\\"{x:950,y:792,t:1527268253185};\\\", \\\"{x:951,y:791,t:1527268253202};\\\", \\\"{x:953,y:791,t:1527268253220};\\\", \\\"{x:955,y:789,t:1527268253237};\\\", \\\"{x:957,y:789,t:1527268253253};\\\", \\\"{x:958,y:788,t:1527268253269};\\\", \\\"{x:961,y:787,t:1527268253286};\\\", \\\"{x:963,y:786,t:1527268253303};\\\", \\\"{x:966,y:785,t:1527268253320};\\\", \\\"{x:970,y:781,t:1527268253336};\\\", \\\"{x:979,y:779,t:1527268253353};\\\", \\\"{x:998,y:771,t:1527268253370};\\\", \\\"{x:1023,y:760,t:1527268253385};\\\", \\\"{x:1061,y:744,t:1527268253403};\\\", \\\"{x:1122,y:704,t:1527268253420};\\\", \\\"{x:1208,y:646,t:1527268253436};\\\", \\\"{x:1305,y:580,t:1527268253453};\\\", \\\"{x:1392,y:520,t:1527268253470};\\\", \\\"{x:1464,y:469,t:1527268253485};\\\", \\\"{x:1501,y:442,t:1527268253502};\\\", \\\"{x:1527,y:422,t:1527268253520};\\\", \\\"{x:1533,y:412,t:1527268253536};\\\", \\\"{x:1539,y:404,t:1527268253553};\\\", \\\"{x:1543,y:397,t:1527268253570};\\\", \\\"{x:1547,y:391,t:1527268253586};\\\", \\\"{x:1548,y:386,t:1527268253603};\\\", \\\"{x:1550,y:383,t:1527268253620};\\\", \\\"{x:1550,y:381,t:1527268253637};\\\", \\\"{x:1550,y:380,t:1527268253656};\\\", \\\"{x:1550,y:379,t:1527268253670};\\\", \\\"{x:1545,y:378,t:1527268253687};\\\", \\\"{x:1525,y:378,t:1527268253703};\\\", \\\"{x:1472,y:378,t:1527268253720};\\\", \\\"{x:1417,y:389,t:1527268253736};\\\", \\\"{x:1360,y:411,t:1527268253753};\\\", \\\"{x:1319,y:436,t:1527268253770};\\\", \\\"{x:1292,y:457,t:1527268253787};\\\", \\\"{x:1277,y:473,t:1527268253803};\\\", \\\"{x:1267,y:488,t:1527268253820};\\\", \\\"{x:1263,y:497,t:1527268253838};\\\", \\\"{x:1260,y:506,t:1527268253853};\\\", \\\"{x:1260,y:513,t:1527268253870};\\\", \\\"{x:1259,y:523,t:1527268253886};\\\", \\\"{x:1259,y:532,t:1527268253903};\\\", \\\"{x:1259,y:537,t:1527268253921};\\\", \\\"{x:1259,y:540,t:1527268253936};\\\", \\\"{x:1260,y:540,t:1527268253960};\\\", \\\"{x:1261,y:540,t:1527268254016};\\\", \\\"{x:1264,y:536,t:1527268254024};\\\", \\\"{x:1267,y:530,t:1527268254037};\\\", \\\"{x:1272,y:524,t:1527268254053};\\\", \\\"{x:1282,y:513,t:1527268254070};\\\", \\\"{x:1287,y:505,t:1527268254087};\\\", \\\"{x:1290,y:500,t:1527268254102};\\\", \\\"{x:1292,y:498,t:1527268254120};\\\", \\\"{x:1294,y:497,t:1527268254137};\\\", \\\"{x:1294,y:496,t:1527268254154};\\\", \\\"{x:1295,y:495,t:1527268254170};\\\", \\\"{x:1297,y:494,t:1527268254187};\\\", \\\"{x:1298,y:494,t:1527268254224};\\\", \\\"{x:1299,y:494,t:1527268254264};\\\", \\\"{x:1300,y:494,t:1527268254296};\\\", \\\"{x:1301,y:494,t:1527268254312};\\\", \\\"{x:1303,y:494,t:1527268254369};\\\", \\\"{x:1304,y:495,t:1527268254387};\\\", \\\"{x:1305,y:496,t:1527268254404};\\\", \\\"{x:1305,y:497,t:1527268254713};\\\", \\\"{x:1306,y:497,t:1527268254720};\\\", \\\"{x:1307,y:497,t:1527268254737};\\\", \\\"{x:1309,y:497,t:1527268254756};\\\", \\\"{x:1311,y:497,t:1527268254977};\\\", \\\"{x:1311,y:496,t:1527268254987};\\\", \\\"{x:1313,y:495,t:1527268255004};\\\", \\\"{x:1315,y:493,t:1527268255020};\\\", \\\"{x:1316,y:492,t:1527268255037};\\\", \\\"{x:1317,y:492,t:1527268255054};\\\", \\\"{x:1318,y:492,t:1527268255070};\\\", \\\"{x:1317,y:492,t:1527268257340};\\\", \\\"{x:1315,y:492,t:1527268258900};\\\", \\\"{x:1313,y:494,t:1527268258911};\\\", \\\"{x:1312,y:495,t:1527268258928};\\\", \\\"{x:1312,y:496,t:1527268258947};\\\", \\\"{x:1312,y:498,t:1527268259020};\\\", \\\"{x:1312,y:499,t:1527268259044};\\\", \\\"{x:1311,y:501,t:1527268259084};\\\", \\\"{x:1310,y:505,t:1527268259565};\\\", \\\"{x:1309,y:507,t:1527268259577};\\\", \\\"{x:1307,y:516,t:1527268259594};\\\", \\\"{x:1303,y:531,t:1527268259611};\\\", \\\"{x:1293,y:584,t:1527268259628};\\\", \\\"{x:1284,y:628,t:1527268259644};\\\", \\\"{x:1282,y:660,t:1527268259661};\\\", \\\"{x:1282,y:680,t:1527268259677};\\\", \\\"{x:1282,y:695,t:1527268259695};\\\", \\\"{x:1282,y:702,t:1527268259711};\\\", \\\"{x:1282,y:708,t:1527268259728};\\\", \\\"{x:1284,y:711,t:1527268259745};\\\", \\\"{x:1284,y:713,t:1527268259761};\\\", \\\"{x:1285,y:714,t:1527268259778};\\\", \\\"{x:1286,y:715,t:1527268259812};\\\", \\\"{x:1286,y:707,t:1527268259860};\\\", \\\"{x:1287,y:699,t:1527268259868};\\\", \\\"{x:1289,y:688,t:1527268259877};\\\", \\\"{x:1293,y:662,t:1527268259895};\\\", \\\"{x:1294,y:633,t:1527268259912};\\\", \\\"{x:1294,y:604,t:1527268259927};\\\", \\\"{x:1294,y:584,t:1527268259945};\\\", \\\"{x:1294,y:573,t:1527268259962};\\\", \\\"{x:1294,y:565,t:1527268259977};\\\", \\\"{x:1294,y:562,t:1527268259995};\\\", \\\"{x:1294,y:571,t:1527268260084};\\\", \\\"{x:1294,y:583,t:1527268260094};\\\", \\\"{x:1294,y:603,t:1527268260112};\\\", \\\"{x:1295,y:621,t:1527268260128};\\\", \\\"{x:1297,y:634,t:1527268260145};\\\", \\\"{x:1298,y:640,t:1527268260162};\\\", \\\"{x:1298,y:643,t:1527268260178};\\\", \\\"{x:1299,y:646,t:1527268260195};\\\", \\\"{x:1299,y:648,t:1527268260212};\\\", \\\"{x:1299,y:649,t:1527268260228};\\\", \\\"{x:1299,y:652,t:1527268260245};\\\", \\\"{x:1299,y:654,t:1527268260268};\\\", \\\"{x:1299,y:655,t:1527268260292};\\\", \\\"{x:1299,y:657,t:1527268260356};\\\", \\\"{x:1301,y:659,t:1527268260364};\\\", \\\"{x:1302,y:660,t:1527268260380};\\\", \\\"{x:1302,y:661,t:1527268260395};\\\", \\\"{x:1304,y:665,t:1527268260411};\\\", \\\"{x:1305,y:666,t:1527268260436};\\\", \\\"{x:1305,y:667,t:1527268260445};\\\", \\\"{x:1306,y:668,t:1527268260462};\\\", \\\"{x:1308,y:670,t:1527268260479};\\\", \\\"{x:1308,y:671,t:1527268260495};\\\", \\\"{x:1309,y:673,t:1527268260512};\\\", \\\"{x:1311,y:676,t:1527268260529};\\\", \\\"{x:1312,y:678,t:1527268260544};\\\", \\\"{x:1315,y:682,t:1527268260562};\\\", \\\"{x:1317,y:687,t:1527268260579};\\\", \\\"{x:1320,y:695,t:1527268260594};\\\", \\\"{x:1324,y:705,t:1527268260612};\\\", \\\"{x:1327,y:710,t:1527268260629};\\\", \\\"{x:1329,y:717,t:1527268260645};\\\", \\\"{x:1333,y:723,t:1527268260662};\\\", \\\"{x:1333,y:729,t:1527268260679};\\\", \\\"{x:1336,y:733,t:1527268260694};\\\", \\\"{x:1337,y:737,t:1527268260712};\\\", \\\"{x:1338,y:739,t:1527268260729};\\\", \\\"{x:1339,y:743,t:1527268260745};\\\", \\\"{x:1340,y:745,t:1527268260761};\\\", \\\"{x:1341,y:748,t:1527268260778};\\\", \\\"{x:1342,y:750,t:1527268260795};\\\", \\\"{x:1343,y:753,t:1527268260811};\\\", \\\"{x:1343,y:757,t:1527268260829};\\\", \\\"{x:1343,y:761,t:1527268260846};\\\", \\\"{x:1343,y:766,t:1527268260862};\\\", \\\"{x:1343,y:772,t:1527268260879};\\\", \\\"{x:1343,y:777,t:1527268260896};\\\", \\\"{x:1343,y:783,t:1527268260911};\\\", \\\"{x:1343,y:788,t:1527268260928};\\\", \\\"{x:1342,y:792,t:1527268260946};\\\", \\\"{x:1341,y:797,t:1527268260961};\\\", \\\"{x:1338,y:804,t:1527268260979};\\\", \\\"{x:1337,y:812,t:1527268260996};\\\", \\\"{x:1335,y:815,t:1527268261012};\\\", \\\"{x:1334,y:817,t:1527268261028};\\\", \\\"{x:1334,y:818,t:1527268261045};\\\", \\\"{x:1334,y:821,t:1527268261062};\\\", \\\"{x:1334,y:824,t:1527268261078};\\\", \\\"{x:1334,y:827,t:1527268261096};\\\", \\\"{x:1333,y:832,t:1527268261112};\\\", \\\"{x:1331,y:836,t:1527268261128};\\\", \\\"{x:1329,y:840,t:1527268261146};\\\", \\\"{x:1329,y:844,t:1527268261162};\\\", \\\"{x:1328,y:846,t:1527268261179};\\\", \\\"{x:1327,y:846,t:1527268261196};\\\", \\\"{x:1327,y:842,t:1527268261394};\\\", \\\"{x:1327,y:827,t:1527268261412};\\\", \\\"{x:1327,y:808,t:1527268261428};\\\", \\\"{x:1327,y:786,t:1527268261445};\\\", \\\"{x:1327,y:764,t:1527268261462};\\\", \\\"{x:1327,y:747,t:1527268261479};\\\", \\\"{x:1327,y:732,t:1527268261495};\\\", \\\"{x:1328,y:718,t:1527268261512};\\\", \\\"{x:1330,y:702,t:1527268261528};\\\", \\\"{x:1333,y:693,t:1527268261545};\\\", \\\"{x:1336,y:684,t:1527268261562};\\\", \\\"{x:1337,y:682,t:1527268261578};\\\", \\\"{x:1337,y:680,t:1527268261596};\\\", \\\"{x:1338,y:678,t:1527268261613};\\\", \\\"{x:1338,y:679,t:1527268261756};\\\", \\\"{x:1338,y:685,t:1527268261763};\\\", \\\"{x:1338,y:695,t:1527268261779};\\\", \\\"{x:1338,y:700,t:1527268261796};\\\", \\\"{x:1338,y:706,t:1527268261813};\\\", \\\"{x:1338,y:711,t:1527268261830};\\\", \\\"{x:1337,y:713,t:1527268261846};\\\", \\\"{x:1337,y:716,t:1527268261863};\\\", \\\"{x:1337,y:717,t:1527268261880};\\\", \\\"{x:1337,y:718,t:1527268261896};\\\", \\\"{x:1337,y:719,t:1527268261913};\\\", \\\"{x:1337,y:721,t:1527268261930};\\\", \\\"{x:1338,y:723,t:1527268261946};\\\", \\\"{x:1338,y:726,t:1527268261962};\\\", \\\"{x:1338,y:733,t:1527268261980};\\\", \\\"{x:1336,y:741,t:1527268261995};\\\", \\\"{x:1335,y:747,t:1527268262012};\\\", \\\"{x:1333,y:754,t:1527268262030};\\\", \\\"{x:1331,y:758,t:1527268262046};\\\", \\\"{x:1328,y:766,t:1527268262063};\\\", \\\"{x:1328,y:772,t:1527268262080};\\\", \\\"{x:1326,y:776,t:1527268262095};\\\", \\\"{x:1326,y:777,t:1527268262113};\\\", \\\"{x:1325,y:779,t:1527268262131};\\\", \\\"{x:1325,y:780,t:1527268262180};\\\", \\\"{x:1325,y:781,t:1527268262196};\\\", \\\"{x:1324,y:784,t:1527268262213};\\\", \\\"{x:1323,y:789,t:1527268262230};\\\", \\\"{x:1321,y:796,t:1527268262247};\\\", \\\"{x:1319,y:802,t:1527268262263};\\\", \\\"{x:1318,y:806,t:1527268262280};\\\", \\\"{x:1316,y:812,t:1527268262297};\\\", \\\"{x:1315,y:818,t:1527268262313};\\\", \\\"{x:1315,y:823,t:1527268262329};\\\", \\\"{x:1314,y:830,t:1527268262347};\\\", \\\"{x:1313,y:835,t:1527268262363};\\\", \\\"{x:1312,y:841,t:1527268262380};\\\", \\\"{x:1312,y:845,t:1527268262397};\\\", \\\"{x:1312,y:846,t:1527268262413};\\\", \\\"{x:1312,y:853,t:1527268262430};\\\", \\\"{x:1312,y:858,t:1527268262447};\\\", \\\"{x:1312,y:865,t:1527268262463};\\\", \\\"{x:1312,y:872,t:1527268262480};\\\", \\\"{x:1312,y:878,t:1527268262497};\\\", \\\"{x:1312,y:884,t:1527268262513};\\\", \\\"{x:1312,y:886,t:1527268262530};\\\", \\\"{x:1312,y:890,t:1527268262547};\\\", \\\"{x:1311,y:894,t:1527268262563};\\\", \\\"{x:1311,y:902,t:1527268262580};\\\", \\\"{x:1311,y:909,t:1527268262597};\\\", \\\"{x:1311,y:913,t:1527268262613};\\\", \\\"{x:1312,y:918,t:1527268262630};\\\", \\\"{x:1312,y:922,t:1527268262647};\\\", \\\"{x:1313,y:925,t:1527268262663};\\\", \\\"{x:1313,y:928,t:1527268262680};\\\", \\\"{x:1314,y:930,t:1527268262697};\\\", \\\"{x:1314,y:931,t:1527268262713};\\\", \\\"{x:1314,y:934,t:1527268262730};\\\", \\\"{x:1314,y:935,t:1527268262747};\\\", \\\"{x:1316,y:942,t:1527268262764};\\\", \\\"{x:1316,y:944,t:1527268262779};\\\", \\\"{x:1316,y:947,t:1527268262797};\\\", \\\"{x:1316,y:948,t:1527268262814};\\\", \\\"{x:1317,y:949,t:1527268262830};\\\", \\\"{x:1317,y:950,t:1527268262847};\\\", \\\"{x:1317,y:952,t:1527268262864};\\\", \\\"{x:1318,y:955,t:1527268262880};\\\", \\\"{x:1318,y:958,t:1527268262897};\\\", \\\"{x:1318,y:962,t:1527268262914};\\\", \\\"{x:1318,y:966,t:1527268262930};\\\", \\\"{x:1318,y:969,t:1527268262947};\\\", \\\"{x:1318,y:972,t:1527268262963};\\\", \\\"{x:1318,y:974,t:1527268263004};\\\", \\\"{x:1318,y:975,t:1527268263043};\\\", \\\"{x:1318,y:976,t:1527268263068};\\\", \\\"{x:1318,y:977,t:1527268263080};\\\", \\\"{x:1318,y:978,t:1527268263140};\\\", \\\"{x:1317,y:979,t:1527268263156};\\\", \\\"{x:1315,y:981,t:1527268263172};\\\", \\\"{x:1315,y:980,t:1527268263372};\\\", \\\"{x:1315,y:979,t:1527268263404};\\\", \\\"{x:1315,y:978,t:1527268263452};\\\", \\\"{x:1315,y:977,t:1527268263468};\\\", \\\"{x:1315,y:976,t:1527268263483};\\\", \\\"{x:1315,y:975,t:1527268263524};\\\", \\\"{x:1315,y:974,t:1527268263539};\\\", \\\"{x:1315,y:973,t:1527268263868};\\\", \\\"{x:1315,y:972,t:1527268263900};\\\", \\\"{x:1315,y:971,t:1527268263923};\\\", \\\"{x:1315,y:970,t:1527268263940};\\\", \\\"{x:1315,y:969,t:1527268263972};\\\", \\\"{x:1315,y:968,t:1527268263981};\\\", \\\"{x:1315,y:967,t:1527268263998};\\\", \\\"{x:1315,y:966,t:1527268264035};\\\", \\\"{x:1315,y:965,t:1527268264060};\\\", \\\"{x:1316,y:965,t:1527268267651};\\\", \\\"{x:1317,y:965,t:1527268267675};\\\", \\\"{x:1318,y:965,t:1527268268821};\\\", \\\"{x:1320,y:965,t:1527268268835};\\\", \\\"{x:1324,y:965,t:1527268268851};\\\", \\\"{x:1347,y:965,t:1527268268867};\\\", \\\"{x:1367,y:965,t:1527268268884};\\\", \\\"{x:1394,y:970,t:1527268268901};\\\", \\\"{x:1429,y:975,t:1527268268918};\\\", \\\"{x:1454,y:980,t:1527268268935};\\\", \\\"{x:1469,y:980,t:1527268268951};\\\", \\\"{x:1479,y:980,t:1527268268968};\\\", \\\"{x:1487,y:980,t:1527268268985};\\\", \\\"{x:1500,y:980,t:1527268269001};\\\", \\\"{x:1507,y:980,t:1527268269019};\\\", \\\"{x:1518,y:980,t:1527268269035};\\\", \\\"{x:1525,y:980,t:1527268269051};\\\", \\\"{x:1534,y:980,t:1527268269068};\\\", \\\"{x:1537,y:980,t:1527268269085};\\\", \\\"{x:1540,y:980,t:1527268269101};\\\", \\\"{x:1541,y:980,t:1527268269118};\\\", \\\"{x:1542,y:980,t:1527268269135};\\\", \\\"{x:1543,y:980,t:1527268269155};\\\", \\\"{x:1544,y:980,t:1527268269168};\\\", \\\"{x:1546,y:980,t:1527268269185};\\\", \\\"{x:1549,y:980,t:1527268269201};\\\", \\\"{x:1551,y:980,t:1527268269218};\\\", \\\"{x:1552,y:980,t:1527268269235};\\\", \\\"{x:1552,y:979,t:1527268269691};\\\", \\\"{x:1552,y:978,t:1527268269702};\\\", \\\"{x:1552,y:977,t:1527268269731};\\\", \\\"{x:1552,y:976,t:1527268269746};\\\", \\\"{x:1552,y:975,t:1527268269778};\\\", \\\"{x:1552,y:974,t:1527268269835};\\\", \\\"{x:1552,y:973,t:1527268269858};\\\", \\\"{x:1552,y:972,t:1527268269915};\\\", \\\"{x:1552,y:971,t:1527268269964};\\\", \\\"{x:1552,y:970,t:1527268269980};\\\", \\\"{x:1551,y:970,t:1527268269995};\\\", \\\"{x:1550,y:970,t:1527268270035};\\\", \\\"{x:1549,y:970,t:1527268270052};\\\", \\\"{x:1548,y:969,t:1527268270069};\\\", \\\"{x:1547,y:969,t:1527268270099};\\\", \\\"{x:1546,y:969,t:1527268270116};\\\", \\\"{x:1545,y:969,t:1527268270132};\\\", \\\"{x:1544,y:969,t:1527268270139};\\\", \\\"{x:1543,y:969,t:1527268270152};\\\", \\\"{x:1542,y:969,t:1527268270169};\\\", \\\"{x:1540,y:968,t:1527268270186};\\\", \\\"{x:1537,y:968,t:1527268270202};\\\", \\\"{x:1534,y:967,t:1527268270219};\\\", \\\"{x:1533,y:967,t:1527268271188};\\\", \\\"{x:1532,y:967,t:1527268272932};\\\", \\\"{x:1532,y:965,t:1527268273091};\\\", \\\"{x:1532,y:964,t:1527268273164};\\\", \\\"{x:1532,y:963,t:1527268273179};\\\", \\\"{x:1532,y:962,t:1527268273188};\\\", \\\"{x:1532,y:960,t:1527268273204};\\\", \\\"{x:1532,y:959,t:1527268273222};\\\", \\\"{x:1532,y:956,t:1527268273260};\\\", \\\"{x:1533,y:955,t:1527268273271};\\\", \\\"{x:1534,y:951,t:1527268273288};\\\", \\\"{x:1536,y:945,t:1527268273304};\\\", \\\"{x:1538,y:935,t:1527268273321};\\\", \\\"{x:1538,y:924,t:1527268273338};\\\", \\\"{x:1538,y:917,t:1527268273354};\\\", \\\"{x:1537,y:902,t:1527268273371};\\\", \\\"{x:1537,y:891,t:1527268273387};\\\", \\\"{x:1537,y:882,t:1527268273405};\\\", \\\"{x:1537,y:873,t:1527268273422};\\\", \\\"{x:1537,y:866,t:1527268273438};\\\", \\\"{x:1537,y:858,t:1527268273454};\\\", \\\"{x:1537,y:845,t:1527268273471};\\\", \\\"{x:1537,y:831,t:1527268273488};\\\", \\\"{x:1537,y:824,t:1527268273504};\\\", \\\"{x:1537,y:813,t:1527268273521};\\\", \\\"{x:1539,y:800,t:1527268273538};\\\", \\\"{x:1541,y:788,t:1527268273555};\\\", \\\"{x:1543,y:769,t:1527268273571};\\\", \\\"{x:1544,y:761,t:1527268273588};\\\", \\\"{x:1545,y:752,t:1527268273604};\\\", \\\"{x:1545,y:743,t:1527268273621};\\\", \\\"{x:1547,y:740,t:1527268273638};\\\", \\\"{x:1547,y:738,t:1527268273654};\\\", \\\"{x:1548,y:733,t:1527268273672};\\\", \\\"{x:1548,y:730,t:1527268273688};\\\", \\\"{x:1548,y:726,t:1527268273705};\\\", \\\"{x:1548,y:724,t:1527268273721};\\\", \\\"{x:1549,y:721,t:1527268273738};\\\", \\\"{x:1549,y:717,t:1527268273756};\\\", \\\"{x:1549,y:714,t:1527268273771};\\\", \\\"{x:1549,y:709,t:1527268273789};\\\", \\\"{x:1548,y:705,t:1527268273805};\\\", \\\"{x:1547,y:700,t:1527268273821};\\\", \\\"{x:1546,y:694,t:1527268273838};\\\", \\\"{x:1543,y:685,t:1527268273856};\\\", \\\"{x:1542,y:681,t:1527268273872};\\\", \\\"{x:1541,y:678,t:1527268273889};\\\", \\\"{x:1541,y:675,t:1527268273905};\\\", \\\"{x:1540,y:672,t:1527268273921};\\\", \\\"{x:1540,y:668,t:1527268273938};\\\", \\\"{x:1539,y:661,t:1527268273956};\\\", \\\"{x:1539,y:658,t:1527268273971};\\\", \\\"{x:1539,y:656,t:1527268273989};\\\", \\\"{x:1539,y:654,t:1527268274006};\\\", \\\"{x:1538,y:650,t:1527268274021};\\\", \\\"{x:1538,y:647,t:1527268274038};\\\", \\\"{x:1538,y:644,t:1527268274055};\\\", \\\"{x:1537,y:642,t:1527268274072};\\\", \\\"{x:1536,y:640,t:1527268274089};\\\", \\\"{x:1536,y:637,t:1527268274106};\\\", \\\"{x:1536,y:635,t:1527268274122};\\\", \\\"{x:1536,y:633,t:1527268274139};\\\", \\\"{x:1536,y:631,t:1527268274156};\\\", \\\"{x:1536,y:630,t:1527268274284};\\\", \\\"{x:1535,y:630,t:1527268274291};\\\", \\\"{x:1533,y:635,t:1527268274306};\\\", \\\"{x:1531,y:646,t:1527268274323};\\\", \\\"{x:1531,y:661,t:1527268274339};\\\", \\\"{x:1531,y:690,t:1527268274355};\\\", \\\"{x:1533,y:712,t:1527268274372};\\\", \\\"{x:1536,y:731,t:1527268274388};\\\", \\\"{x:1539,y:745,t:1527268274406};\\\", \\\"{x:1541,y:758,t:1527268274422};\\\", \\\"{x:1543,y:770,t:1527268274438};\\\", \\\"{x:1543,y:778,t:1527268274455};\\\", \\\"{x:1544,y:787,t:1527268274472};\\\", \\\"{x:1545,y:794,t:1527268274489};\\\", \\\"{x:1545,y:803,t:1527268274505};\\\", \\\"{x:1548,y:813,t:1527268274522};\\\", \\\"{x:1549,y:823,t:1527268274538};\\\", \\\"{x:1549,y:836,t:1527268274555};\\\", \\\"{x:1549,y:843,t:1527268274571};\\\", \\\"{x:1549,y:851,t:1527268274588};\\\", \\\"{x:1549,y:860,t:1527268274606};\\\", \\\"{x:1549,y:867,t:1527268274622};\\\", \\\"{x:1550,y:872,t:1527268274642};\\\", \\\"{x:1550,y:879,t:1527268274655};\\\", \\\"{x:1550,y:883,t:1527268274673};\\\", \\\"{x:1551,y:889,t:1527268274690};\\\", \\\"{x:1553,y:896,t:1527268274706};\\\", \\\"{x:1553,y:901,t:1527268274722};\\\", \\\"{x:1554,y:906,t:1527268274739};\\\", \\\"{x:1554,y:909,t:1527268274755};\\\", \\\"{x:1554,y:913,t:1527268274773};\\\", \\\"{x:1554,y:916,t:1527268274789};\\\", \\\"{x:1554,y:920,t:1527268274806};\\\", \\\"{x:1554,y:922,t:1527268274823};\\\", \\\"{x:1554,y:925,t:1527268274840};\\\", \\\"{x:1554,y:927,t:1527268274855};\\\", \\\"{x:1554,y:929,t:1527268274873};\\\", \\\"{x:1554,y:932,t:1527268274889};\\\", \\\"{x:1554,y:936,t:1527268274905};\\\", \\\"{x:1554,y:939,t:1527268274923};\\\", \\\"{x:1554,y:943,t:1527268274940};\\\", \\\"{x:1554,y:947,t:1527268274955};\\\", \\\"{x:1554,y:948,t:1527268274980};\\\", \\\"{x:1554,y:944,t:1527268275147};\\\", \\\"{x:1549,y:928,t:1527268275155};\\\", \\\"{x:1542,y:904,t:1527268275172};\\\", \\\"{x:1537,y:881,t:1527268275190};\\\", \\\"{x:1533,y:860,t:1527268275207};\\\", \\\"{x:1532,y:841,t:1527268275223};\\\", \\\"{x:1531,y:822,t:1527268275241};\\\", \\\"{x:1531,y:802,t:1527268275256};\\\", \\\"{x:1531,y:783,t:1527268275273};\\\", \\\"{x:1531,y:766,t:1527268275289};\\\", \\\"{x:1531,y:749,t:1527268275306};\\\", \\\"{x:1531,y:731,t:1527268275322};\\\", \\\"{x:1531,y:703,t:1527268275339};\\\", \\\"{x:1528,y:687,t:1527268275356};\\\", \\\"{x:1526,y:680,t:1527268275372};\\\", \\\"{x:1526,y:676,t:1527268275390};\\\", \\\"{x:1525,y:672,t:1527268275406};\\\", \\\"{x:1525,y:669,t:1527268275422};\\\", \\\"{x:1525,y:665,t:1527268275441};\\\", \\\"{x:1525,y:664,t:1527268275456};\\\", \\\"{x:1525,y:662,t:1527268275473};\\\", \\\"{x:1525,y:661,t:1527268275532};\\\", \\\"{x:1525,y:658,t:1527268275572};\\\", \\\"{x:1526,y:658,t:1527268275588};\\\", \\\"{x:1527,y:656,t:1527268275596};\\\", \\\"{x:1528,y:656,t:1527268275606};\\\", \\\"{x:1529,y:654,t:1527268275624};\\\", \\\"{x:1532,y:649,t:1527268275641};\\\", \\\"{x:1535,y:644,t:1527268275656};\\\", \\\"{x:1537,y:639,t:1527268275674};\\\", \\\"{x:1541,y:634,t:1527268275689};\\\", \\\"{x:1544,y:630,t:1527268275707};\\\", \\\"{x:1546,y:627,t:1527268275724};\\\", \\\"{x:1547,y:625,t:1527268275739};\\\", \\\"{x:1548,y:624,t:1527268275771};\\\", \\\"{x:1546,y:633,t:1527268275876};\\\", \\\"{x:1546,y:641,t:1527268275890};\\\", \\\"{x:1546,y:663,t:1527268275907};\\\", \\\"{x:1548,y:697,t:1527268275923};\\\", \\\"{x:1552,y:716,t:1527268275941};\\\", \\\"{x:1558,y:731,t:1527268275957};\\\", \\\"{x:1562,y:745,t:1527268275973};\\\", \\\"{x:1564,y:755,t:1527268275989};\\\", \\\"{x:1567,y:761,t:1527268276007};\\\", \\\"{x:1567,y:771,t:1527268276023};\\\", \\\"{x:1567,y:782,t:1527268276041};\\\", \\\"{x:1567,y:796,t:1527268276056};\\\", \\\"{x:1567,y:809,t:1527268276073};\\\", \\\"{x:1567,y:820,t:1527268276090};\\\", \\\"{x:1566,y:835,t:1527268276107};\\\", \\\"{x:1561,y:853,t:1527268276123};\\\", \\\"{x:1560,y:865,t:1527268276140};\\\", \\\"{x:1556,y:876,t:1527268276156};\\\", \\\"{x:1553,y:890,t:1527268276174};\\\", \\\"{x:1549,y:900,t:1527268276190};\\\", \\\"{x:1547,y:910,t:1527268276206};\\\", \\\"{x:1545,y:922,t:1527268276223};\\\", \\\"{x:1542,y:933,t:1527268276240};\\\", \\\"{x:1540,y:938,t:1527268276256};\\\", \\\"{x:1539,y:942,t:1527268276274};\\\", \\\"{x:1539,y:944,t:1527268276291};\\\", \\\"{x:1539,y:947,t:1527268276306};\\\", \\\"{x:1539,y:950,t:1527268276323};\\\", \\\"{x:1539,y:953,t:1527268276339};\\\", \\\"{x:1539,y:955,t:1527268276356};\\\", \\\"{x:1539,y:957,t:1527268276373};\\\", \\\"{x:1539,y:960,t:1527268276391};\\\", \\\"{x:1539,y:964,t:1527268276407};\\\", \\\"{x:1539,y:965,t:1527268276424};\\\", \\\"{x:1539,y:966,t:1527268276476};\\\", \\\"{x:1541,y:967,t:1527268276628};\\\", \\\"{x:1542,y:967,t:1527268276644};\\\", \\\"{x:1543,y:967,t:1527268276657};\\\", \\\"{x:1547,y:966,t:1527268276673};\\\", \\\"{x:1549,y:966,t:1527268276691};\\\", \\\"{x:1553,y:964,t:1527268276708};\\\", \\\"{x:1555,y:963,t:1527268276723};\\\", \\\"{x:1557,y:963,t:1527268276741};\\\", \\\"{x:1558,y:963,t:1527268276757};\\\", \\\"{x:1561,y:962,t:1527268276774};\\\", \\\"{x:1563,y:962,t:1527268276791};\\\", \\\"{x:1565,y:961,t:1527268276807};\\\", \\\"{x:1567,y:960,t:1527268276823};\\\", \\\"{x:1565,y:960,t:1527268277044};\\\", \\\"{x:1564,y:960,t:1527268277057};\\\", \\\"{x:1562,y:960,t:1527268277075};\\\", \\\"{x:1561,y:960,t:1527268277090};\\\", \\\"{x:1560,y:961,t:1527268277148};\\\", \\\"{x:1559,y:961,t:1527268277188};\\\", \\\"{x:1557,y:962,t:1527268277195};\\\", \\\"{x:1556,y:962,t:1527268277211};\\\", \\\"{x:1555,y:962,t:1527268277225};\\\", \\\"{x:1554,y:962,t:1527268277316};\\\", \\\"{x:1554,y:963,t:1527268277324};\\\", \\\"{x:1553,y:963,t:1527268277474};\\\", \\\"{x:1539,y:960,t:1527268289044};\\\", \\\"{x:1517,y:953,t:1527268289051};\\\", \\\"{x:1476,y:934,t:1527268289066};\\\", \\\"{x:1340,y:879,t:1527268289084};\\\", \\\"{x:1235,y:825,t:1527268289099};\\\", \\\"{x:1123,y:763,t:1527268289116};\\\", \\\"{x:1044,y:721,t:1527268289133};\\\", \\\"{x:1009,y:702,t:1527268289150};\\\", \\\"{x:993,y:696,t:1527268289165};\\\", \\\"{x:986,y:694,t:1527268289182};\\\", \\\"{x:985,y:694,t:1527268289200};\\\", \\\"{x:978,y:694,t:1527268289215};\\\", \\\"{x:958,y:694,t:1527268289232};\\\", \\\"{x:933,y:686,t:1527268289249};\\\", \\\"{x:907,y:679,t:1527268289265};\\\", \\\"{x:895,y:677,t:1527268289283};\\\", \\\"{x:894,y:677,t:1527268289299};\\\", \\\"{x:893,y:677,t:1527268289315};\\\", \\\"{x:889,y:677,t:1527268289332};\\\", \\\"{x:871,y:675,t:1527268289349};\\\", \\\"{x:839,y:670,t:1527268289366};\\\", \\\"{x:794,y:656,t:1527268289382};\\\", \\\"{x:744,y:632,t:1527268289399};\\\", \\\"{x:681,y:606,t:1527268289418};\\\", \\\"{x:598,y:571,t:1527268289432};\\\", \\\"{x:526,y:540,t:1527268289450};\\\", \\\"{x:467,y:517,t:1527268289469};\\\", \\\"{x:453,y:510,t:1527268289487};\\\", \\\"{x:448,y:510,t:1527268289503};\\\", \\\"{x:449,y:512,t:1527268289635};\\\", \\\"{x:451,y:516,t:1527268289642};\\\", \\\"{x:454,y:519,t:1527268289653};\\\", \\\"{x:458,y:525,t:1527268289670};\\\", \\\"{x:465,y:535,t:1527268289687};\\\", \\\"{x:471,y:542,t:1527268289703};\\\", \\\"{x:475,y:548,t:1527268289720};\\\", \\\"{x:481,y:555,t:1527268289737};\\\", \\\"{x:491,y:564,t:1527268289754};\\\", \\\"{x:503,y:573,t:1527268289770};\\\", \\\"{x:519,y:584,t:1527268289787};\\\", \\\"{x:530,y:592,t:1527268289804};\\\", \\\"{x:534,y:595,t:1527268289820};\\\", \\\"{x:538,y:597,t:1527268289837};\\\", \\\"{x:539,y:598,t:1527268289853};\\\", \\\"{x:540,y:598,t:1527268289906};\\\", \\\"{x:541,y:598,t:1527268289920};\\\", \\\"{x:546,y:598,t:1527268289936};\\\", \\\"{x:551,y:600,t:1527268289954};\\\", \\\"{x:554,y:600,t:1527268289970};\\\", \\\"{x:555,y:601,t:1527268289986};\\\", \\\"{x:555,y:602,t:1527268290003};\\\", \\\"{x:557,y:602,t:1527268290027};\\\", \\\"{x:560,y:604,t:1527268290038};\\\", \\\"{x:572,y:610,t:1527268290054};\\\", \\\"{x:587,y:618,t:1527268290071};\\\", \\\"{x:599,y:624,t:1527268290087};\\\", \\\"{x:612,y:628,t:1527268290104};\\\", \\\"{x:615,y:628,t:1527268290120};\\\", \\\"{x:616,y:628,t:1527268290332};\\\", \\\"{x:617,y:626,t:1527268290340};\\\", \\\"{x:617,y:625,t:1527268290353};\\\", \\\"{x:618,y:620,t:1527268290370};\\\", \\\"{x:618,y:618,t:1527268290387};\\\", \\\"{x:618,y:616,t:1527268290403};\\\", \\\"{x:622,y:616,t:1527268290620};\\\", \\\"{x:623,y:616,t:1527268290637};\\\", \\\"{x:627,y:616,t:1527268290653};\\\", \\\"{x:636,y:619,t:1527268290670};\\\", \\\"{x:642,y:622,t:1527268290688};\\\", \\\"{x:645,y:623,t:1527268290704};\\\", \\\"{x:650,y:624,t:1527268290720};\\\", \\\"{x:654,y:626,t:1527268290737};\\\", \\\"{x:672,y:635,t:1527268290755};\\\", \\\"{x:690,y:642,t:1527268290770};\\\", \\\"{x:708,y:649,t:1527268290787};\\\", \\\"{x:726,y:658,t:1527268290805};\\\", \\\"{x:750,y:670,t:1527268290821};\\\", \\\"{x:786,y:685,t:1527268290837};\\\", \\\"{x:851,y:719,t:1527268290854};\\\", \\\"{x:938,y:752,t:1527268290870};\\\", \\\"{x:1037,y:790,t:1527268290887};\\\", \\\"{x:1128,y:832,t:1527268290904};\\\", \\\"{x:1213,y:867,t:1527268290921};\\\", \\\"{x:1287,y:892,t:1527268290938};\\\", \\\"{x:1340,y:907,t:1527268290954};\\\", \\\"{x:1362,y:914,t:1527268290970};\\\", \\\"{x:1377,y:919,t:1527268290987};\\\", \\\"{x:1390,y:925,t:1527268291004};\\\", \\\"{x:1403,y:935,t:1527268291020};\\\", \\\"{x:1416,y:944,t:1527268291037};\\\", \\\"{x:1426,y:953,t:1527268291054};\\\", \\\"{x:1434,y:962,t:1527268291071};\\\", \\\"{x:1439,y:970,t:1527268291088};\\\", \\\"{x:1444,y:975,t:1527268291104};\\\", \\\"{x:1444,y:977,t:1527268291121};\\\", \\\"{x:1446,y:979,t:1527268291137};\\\", \\\"{x:1451,y:982,t:1527268291155};\\\", \\\"{x:1457,y:984,t:1527268291171};\\\", \\\"{x:1468,y:986,t:1527268291188};\\\", \\\"{x:1482,y:990,t:1527268291205};\\\", \\\"{x:1500,y:995,t:1527268291222};\\\", \\\"{x:1517,y:999,t:1527268291238};\\\", \\\"{x:1529,y:1001,t:1527268291254};\\\", \\\"{x:1534,y:1001,t:1527268291271};\\\", \\\"{x:1535,y:1001,t:1527268291288};\\\", \\\"{x:1537,y:1001,t:1527268291308};\\\", \\\"{x:1537,y:1000,t:1527268291331};\\\", \\\"{x:1538,y:999,t:1527268291347};\\\", \\\"{x:1538,y:997,t:1527268291379};\\\", \\\"{x:1539,y:997,t:1527268291403};\\\", \\\"{x:1539,y:996,t:1527268291410};\\\", \\\"{x:1540,y:994,t:1527268291427};\\\", \\\"{x:1540,y:993,t:1527268291442};\\\", \\\"{x:1541,y:992,t:1527268291455};\\\", \\\"{x:1541,y:991,t:1527268291472};\\\", \\\"{x:1541,y:989,t:1527268291488};\\\", \\\"{x:1541,y:987,t:1527268291505};\\\", \\\"{x:1542,y:986,t:1527268291522};\\\", \\\"{x:1542,y:985,t:1527268291539};\\\", \\\"{x:1542,y:984,t:1527268291572};\\\", \\\"{x:1542,y:983,t:1527268291589};\\\", \\\"{x:1542,y:982,t:1527268291627};\\\", \\\"{x:1543,y:980,t:1527268291667};\\\", \\\"{x:1543,y:979,t:1527268291683};\\\", \\\"{x:1544,y:979,t:1527268291699};\\\", \\\"{x:1544,y:977,t:1527268291715};\\\", \\\"{x:1544,y:976,t:1527268291723};\\\", \\\"{x:1546,y:973,t:1527268291739};\\\", \\\"{x:1547,y:972,t:1527268291755};\\\", \\\"{x:1548,y:971,t:1527268291779};\\\", \\\"{x:1548,y:970,t:1527268291828};\\\", \\\"{x:1549,y:969,t:1527268291867};\\\", \\\"{x:1549,y:968,t:1527268291940};\\\", \\\"{x:1550,y:968,t:1527268291979};\\\", \\\"{x:1550,y:964,t:1527268292276};\\\", \\\"{x:1554,y:958,t:1527268292289};\\\", \\\"{x:1554,y:957,t:1527268292305};\\\", \\\"{x:1554,y:944,t:1527268341838};\\\", \\\"{x:1543,y:914,t:1527268341856};\\\", \\\"{x:1531,y:890,t:1527268341872};\\\", \\\"{x:1518,y:870,t:1527268341888};\\\", \\\"{x:1505,y:852,t:1527268341905};\\\", \\\"{x:1499,y:845,t:1527268341922};\\\", \\\"{x:1499,y:844,t:1527268341939};\\\", \\\"{x:1498,y:844,t:1527268342190};\\\", \\\"{x:1496,y:840,t:1527268342206};\\\", \\\"{x:1493,y:837,t:1527268342222};\\\", \\\"{x:1487,y:834,t:1527268342238};\\\", \\\"{x:1480,y:832,t:1527268342256};\\\", \\\"{x:1471,y:830,t:1527268342274};\\\", \\\"{x:1462,y:829,t:1527268342289};\\\", \\\"{x:1459,y:828,t:1527268342306};\\\", \\\"{x:1459,y:827,t:1527268342399};\\\", \\\"{x:1459,y:826,t:1527268342414};\\\", \\\"{x:1459,y:825,t:1527268342430};\\\", \\\"{x:1460,y:824,t:1527268342439};\\\", \\\"{x:1462,y:822,t:1527268342455};\\\", \\\"{x:1467,y:822,t:1527268342472};\\\", \\\"{x:1472,y:822,t:1527268342488};\\\", \\\"{x:1477,y:821,t:1527268342505};\\\", \\\"{x:1479,y:821,t:1527268342523};\\\", \\\"{x:1480,y:821,t:1527268342539};\\\", \\\"{x:1482,y:821,t:1527268342556};\\\", \\\"{x:1483,y:821,t:1527268342606};\\\", \\\"{x:1485,y:821,t:1527268342630};\\\", \\\"{x:1486,y:821,t:1527268342687};\\\", \\\"{x:1486,y:820,t:1527268342718};\\\", \\\"{x:1487,y:820,t:1527268342775};\\\", \\\"{x:1489,y:819,t:1527268342806};\\\", \\\"{x:1489,y:817,t:1527268342998};\\\", \\\"{x:1489,y:816,t:1527268343047};\\\", \\\"{x:1489,y:814,t:1527268343151};\\\", \\\"{x:1490,y:814,t:1527268343182};\\\", \\\"{x:1490,y:818,t:1527268344893};\\\", \\\"{x:1487,y:823,t:1527268344907};\\\", \\\"{x:1481,y:831,t:1527268344924};\\\", \\\"{x:1474,y:841,t:1527268344942};\\\", \\\"{x:1468,y:849,t:1527268344957};\\\", \\\"{x:1466,y:852,t:1527268344974};\\\", \\\"{x:1465,y:853,t:1527268344991};\\\", \\\"{x:1463,y:855,t:1527268345046};\\\", \\\"{x:1462,y:857,t:1527268345057};\\\", \\\"{x:1457,y:860,t:1527268345075};\\\", \\\"{x:1446,y:862,t:1527268345091};\\\", \\\"{x:1430,y:864,t:1527268345108};\\\", \\\"{x:1410,y:865,t:1527268345124};\\\", \\\"{x:1340,y:865,t:1527268345141};\\\", \\\"{x:1269,y:859,t:1527268345157};\\\", \\\"{x:1165,y:839,t:1527268345174};\\\", \\\"{x:1058,y:813,t:1527268345191};\\\", \\\"{x:952,y:782,t:1527268345209};\\\", \\\"{x:862,y:761,t:1527268345224};\\\", \\\"{x:775,y:734,t:1527268345241};\\\", \\\"{x:693,y:715,t:1527268345258};\\\", \\\"{x:619,y:697,t:1527268345274};\\\", \\\"{x:549,y:687,t:1527268345291};\\\", \\\"{x:488,y:679,t:1527268345308};\\\", \\\"{x:448,y:673,t:1527268345324};\\\", \\\"{x:403,y:667,t:1527268345341};\\\", \\\"{x:385,y:664,t:1527268345359};\\\", \\\"{x:368,y:662,t:1527268345374};\\\", \\\"{x:357,y:660,t:1527268345391};\\\", \\\"{x:353,y:658,t:1527268345413};\\\", \\\"{x:351,y:658,t:1527268345453};\\\", \\\"{x:350,y:658,t:1527268345463};\\\", \\\"{x:344,y:658,t:1527268345479};\\\", \\\"{x:337,y:662,t:1527268345496};\\\", \\\"{x:333,y:666,t:1527268345514};\\\", \\\"{x:333,y:668,t:1527268345530};\\\", \\\"{x:333,y:672,t:1527268345553};\\\", \\\"{x:337,y:676,t:1527268345569};\\\", \\\"{x:346,y:682,t:1527268345586};\\\", \\\"{x:362,y:690,t:1527268345603};\\\", \\\"{x:380,y:698,t:1527268345619};\\\", \\\"{x:401,y:706,t:1527268345636};\\\", \\\"{x:425,y:715,t:1527268345653};\\\", \\\"{x:435,y:715,t:1527268345670};\\\", \\\"{x:436,y:715,t:1527268345686};\\\", \\\"{x:438,y:715,t:1527268345716};\\\", \\\"{x:440,y:715,t:1527268345725};\\\", \\\"{x:441,y:714,t:1527268345736};\\\", \\\"{x:447,y:713,t:1527268345753};\\\", \\\"{x:454,y:713,t:1527268345770};\\\", \\\"{x:458,y:713,t:1527268345786};\\\", \\\"{x:462,y:713,t:1527268345803};\\\", \\\"{x:465,y:713,t:1527268345820};\\\", \\\"{x:466,y:712,t:1527268345836};\\\", \\\"{x:467,y:711,t:1527268345853};\\\", \\\"{x:468,y:711,t:1527268345870};\\\", \\\"{x:469,y:711,t:1527268345886};\\\", \\\"{x:472,y:711,t:1527268345903};\\\", \\\"{x:475,y:711,t:1527268345920};\\\", \\\"{x:477,y:711,t:1527268345936};\\\", \\\"{x:478,y:711,t:1527268345981};\\\", \\\"{x:479,y:711,t:1527268345997};\\\", \\\"{x:479,y:713,t:1527268346005};\\\", \\\"{x:479,y:714,t:1527268346021};\\\", \\\"{x:479,y:716,t:1527268346037};\\\", \\\"{x:479,y:717,t:1527268346069};\\\", \\\"{x:480,y:718,t:1527268346093};\\\", \\\"{x:480,y:719,t:1527268346103};\\\", \\\"{x:480,y:723,t:1527268346120};\\\", \\\"{x:480,y:726,t:1527268346136};\\\", \\\"{x:481,y:732,t:1527268346153};\\\", \\\"{x:482,y:734,t:1527268346170};\\\", \\\"{x:482,y:737,t:1527268346186};\\\", \\\"{x:482,y:738,t:1527268346203};\\\", \\\"{x:483,y:738,t:1527268346236};\\\", \\\"{x:484,y:738,t:1527268346269};\\\", \\\"{x:484,y:738,t:1527268346535};\\\", \\\"{x:485,y:738,t:1527268346701};\\\", \\\"{x:487,y:737,t:1527268346708};\\\", \\\"{x:488,y:736,t:1527268346725};\\\", \\\"{x:488,y:735,t:1527268346749};\\\" ] }, { \\\"rt\\\": 15025, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 406767, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:735,t:1527268351085};\\\", \\\"{x:499,y:737,t:1527268351099};\\\", \\\"{x:513,y:746,t:1527268351115};\\\", \\\"{x:530,y:755,t:1527268351133};\\\", \\\"{x:550,y:766,t:1527268351149};\\\", \\\"{x:556,y:768,t:1527268351165};\\\", \\\"{x:557,y:769,t:1527268351174};\\\", \\\"{x:558,y:769,t:1527268351205};\\\", \\\"{x:558,y:770,t:1527268351236};\\\", \\\"{x:559,y:771,t:1527268351244};\\\", \\\"{x:561,y:771,t:1527268351257};\\\", \\\"{x:565,y:773,t:1527268351274};\\\", \\\"{x:570,y:775,t:1527268351291};\\\", \\\"{x:574,y:777,t:1527268351308};\\\", \\\"{x:579,y:779,t:1527268351324};\\\", \\\"{x:582,y:781,t:1527268351340};\\\", \\\"{x:587,y:782,t:1527268351358};\\\", \\\"{x:593,y:786,t:1527268351374};\\\", \\\"{x:603,y:790,t:1527268351391};\\\", \\\"{x:620,y:800,t:1527268351408};\\\", \\\"{x:646,y:813,t:1527268351424};\\\", \\\"{x:681,y:825,t:1527268351441};\\\", \\\"{x:710,y:842,t:1527268351458};\\\", \\\"{x:730,y:851,t:1527268351474};\\\", \\\"{x:755,y:864,t:1527268351491};\\\", \\\"{x:770,y:872,t:1527268351508};\\\", \\\"{x:790,y:882,t:1527268351524};\\\", \\\"{x:836,y:904,t:1527268351541};\\\", \\\"{x:878,y:925,t:1527268351558};\\\", \\\"{x:924,y:949,t:1527268351574};\\\", \\\"{x:956,y:967,t:1527268351591};\\\", \\\"{x:990,y:985,t:1527268351609};\\\", \\\"{x:1020,y:1004,t:1527268351625};\\\", \\\"{x:1067,y:1024,t:1527268351641};\\\", \\\"{x:1113,y:1039,t:1527268351658};\\\", \\\"{x:1147,y:1048,t:1527268351675};\\\", \\\"{x:1173,y:1057,t:1527268351691};\\\", \\\"{x:1193,y:1059,t:1527268351708};\\\", \\\"{x:1227,y:1060,t:1527268351724};\\\", \\\"{x:1249,y:1052,t:1527268351742};\\\", \\\"{x:1278,y:1034,t:1527268351758};\\\", \\\"{x:1303,y:1006,t:1527268351775};\\\", \\\"{x:1316,y:978,t:1527268351792};\\\", \\\"{x:1318,y:941,t:1527268351808};\\\", \\\"{x:1312,y:904,t:1527268351826};\\\", \\\"{x:1301,y:864,t:1527268351842};\\\", \\\"{x:1285,y:826,t:1527268351859};\\\", \\\"{x:1273,y:794,t:1527268351876};\\\", \\\"{x:1264,y:770,t:1527268351892};\\\", \\\"{x:1259,y:754,t:1527268351909};\\\", \\\"{x:1256,y:741,t:1527268351925};\\\", \\\"{x:1256,y:737,t:1527268351942};\\\", \\\"{x:1256,y:733,t:1527268351958};\\\", \\\"{x:1256,y:731,t:1527268351975};\\\", \\\"{x:1256,y:730,t:1527268351997};\\\", \\\"{x:1256,y:729,t:1527268352008};\\\", \\\"{x:1256,y:724,t:1527268352025};\\\", \\\"{x:1256,y:715,t:1527268352042};\\\", \\\"{x:1257,y:699,t:1527268352058};\\\", \\\"{x:1262,y:684,t:1527268352075};\\\", \\\"{x:1268,y:670,t:1527268352092};\\\", \\\"{x:1274,y:658,t:1527268352108};\\\", \\\"{x:1279,y:636,t:1527268352125};\\\", \\\"{x:1280,y:618,t:1527268352142};\\\", \\\"{x:1284,y:601,t:1527268352159};\\\", \\\"{x:1287,y:580,t:1527268352175};\\\", \\\"{x:1290,y:562,t:1527268352192};\\\", \\\"{x:1291,y:541,t:1527268352209};\\\", \\\"{x:1293,y:527,t:1527268352225};\\\", \\\"{x:1293,y:520,t:1527268352242};\\\", \\\"{x:1293,y:516,t:1527268352259};\\\", \\\"{x:1293,y:515,t:1527268352317};\\\", \\\"{x:1291,y:515,t:1527268352332};\\\", \\\"{x:1289,y:515,t:1527268352342};\\\", \\\"{x:1281,y:522,t:1527268352359};\\\", \\\"{x:1272,y:531,t:1527268352375};\\\", \\\"{x:1268,y:536,t:1527268352392};\\\", \\\"{x:1266,y:540,t:1527268352410};\\\", \\\"{x:1264,y:544,t:1527268352426};\\\", \\\"{x:1263,y:545,t:1527268352442};\\\", \\\"{x:1263,y:546,t:1527268352460};\\\", \\\"{x:1262,y:547,t:1527268352477};\\\", \\\"{x:1262,y:548,t:1527268352549};\\\", \\\"{x:1262,y:549,t:1527268352565};\\\", \\\"{x:1262,y:550,t:1527268352577};\\\", \\\"{x:1266,y:554,t:1527268352592};\\\", \\\"{x:1269,y:558,t:1527268352609};\\\", \\\"{x:1271,y:559,t:1527268352626};\\\", \\\"{x:1272,y:560,t:1527268352653};\\\", \\\"{x:1273,y:560,t:1527268352709};\\\", \\\"{x:1274,y:560,t:1527268352726};\\\", \\\"{x:1275,y:560,t:1527268352743};\\\", \\\"{x:1276,y:560,t:1527268352760};\\\", \\\"{x:1278,y:562,t:1527268352776};\\\", \\\"{x:1279,y:562,t:1527268352821};\\\", \\\"{x:1280,y:562,t:1527268352828};\\\", \\\"{x:1281,y:562,t:1527268352861};\\\", \\\"{x:1282,y:562,t:1527268352876};\\\", \\\"{x:1280,y:562,t:1527268353205};\\\", \\\"{x:1279,y:562,t:1527268353212};\\\", \\\"{x:1278,y:562,t:1527268353226};\\\", \\\"{x:1276,y:562,t:1527268354141};\\\", \\\"{x:1273,y:563,t:1527268354149};\\\", \\\"{x:1267,y:563,t:1527268354161};\\\", \\\"{x:1255,y:563,t:1527268354178};\\\", \\\"{x:1245,y:563,t:1527268354194};\\\", \\\"{x:1234,y:564,t:1527268354211};\\\", \\\"{x:1221,y:567,t:1527268354228};\\\", \\\"{x:1207,y:568,t:1527268354244};\\\", \\\"{x:1173,y:574,t:1527268354262};\\\", \\\"{x:1144,y:574,t:1527268354278};\\\", \\\"{x:1114,y:574,t:1527268354295};\\\", \\\"{x:1087,y:575,t:1527268354311};\\\", \\\"{x:1062,y:575,t:1527268354328};\\\", \\\"{x:1039,y:575,t:1527268354344};\\\", \\\"{x:1016,y:575,t:1527268354362};\\\", \\\"{x:994,y:575,t:1527268354378};\\\", \\\"{x:973,y:575,t:1527268354395};\\\", \\\"{x:952,y:575,t:1527268354412};\\\", \\\"{x:930,y:575,t:1527268354429};\\\", \\\"{x:903,y:570,t:1527268354445};\\\", \\\"{x:892,y:569,t:1527268354460};\\\", \\\"{x:867,y:565,t:1527268354476};\\\", \\\"{x:832,y:553,t:1527268354494};\\\", \\\"{x:812,y:548,t:1527268354510};\\\", \\\"{x:793,y:541,t:1527268354526};\\\", \\\"{x:778,y:533,t:1527268354543};\\\", \\\"{x:764,y:527,t:1527268354560};\\\", \\\"{x:751,y:523,t:1527268354578};\\\", \\\"{x:738,y:521,t:1527268354594};\\\", \\\"{x:724,y:518,t:1527268354610};\\\", \\\"{x:714,y:516,t:1527268354627};\\\", \\\"{x:702,y:514,t:1527268354643};\\\", \\\"{x:693,y:513,t:1527268354660};\\\", \\\"{x:678,y:513,t:1527268354676};\\\", \\\"{x:668,y:513,t:1527268354693};\\\", \\\"{x:661,y:513,t:1527268354710};\\\", \\\"{x:657,y:513,t:1527268354727};\\\", \\\"{x:655,y:513,t:1527268354744};\\\", \\\"{x:654,y:512,t:1527268354760};\\\", \\\"{x:653,y:512,t:1527268354796};\\\", \\\"{x:652,y:512,t:1527268354811};\\\", \\\"{x:649,y:510,t:1527268354828};\\\", \\\"{x:643,y:509,t:1527268354843};\\\", \\\"{x:634,y:506,t:1527268354860};\\\", \\\"{x:626,y:504,t:1527268354877};\\\", \\\"{x:622,y:503,t:1527268354893};\\\", \\\"{x:619,y:502,t:1527268354910};\\\", \\\"{x:616,y:501,t:1527268354927};\\\", \\\"{x:615,y:501,t:1527268354944};\\\", \\\"{x:613,y:501,t:1527268354961};\\\", \\\"{x:611,y:501,t:1527268354978};\\\", \\\"{x:609,y:501,t:1527268354994};\\\", \\\"{x:606,y:501,t:1527268355010};\\\", \\\"{x:606,y:500,t:1527268355052};\\\", \\\"{x:608,y:502,t:1527268355381};\\\", \\\"{x:626,y:510,t:1527268355394};\\\", \\\"{x:687,y:536,t:1527268355412};\\\", \\\"{x:784,y:566,t:1527268355428};\\\", \\\"{x:915,y:605,t:1527268355445};\\\", \\\"{x:971,y:614,t:1527268355461};\\\", \\\"{x:991,y:617,t:1527268355478};\\\", \\\"{x:992,y:617,t:1527268355549};\\\", \\\"{x:992,y:616,t:1527268355562};\\\", \\\"{x:992,y:611,t:1527268355577};\\\", \\\"{x:991,y:606,t:1527268355594};\\\", \\\"{x:980,y:600,t:1527268355611};\\\", \\\"{x:966,y:592,t:1527268355628};\\\", \\\"{x:947,y:584,t:1527268355645};\\\", \\\"{x:910,y:568,t:1527268355662};\\\", \\\"{x:893,y:561,t:1527268355678};\\\", \\\"{x:886,y:558,t:1527268355695};\\\", \\\"{x:884,y:557,t:1527268355712};\\\", \\\"{x:883,y:556,t:1527268355773};\\\", \\\"{x:882,y:556,t:1527268355780};\\\", \\\"{x:880,y:556,t:1527268355794};\\\", \\\"{x:877,y:555,t:1527268355812};\\\", \\\"{x:874,y:554,t:1527268355828};\\\", \\\"{x:873,y:553,t:1527268355844};\\\", \\\"{x:872,y:552,t:1527268355861};\\\", \\\"{x:869,y:550,t:1527268355877};\\\", \\\"{x:867,y:550,t:1527268355900};\\\", \\\"{x:866,y:550,t:1527268355911};\\\", \\\"{x:862,y:547,t:1527268355929};\\\", \\\"{x:858,y:546,t:1527268355944};\\\", \\\"{x:857,y:545,t:1527268355962};\\\", \\\"{x:856,y:544,t:1527268355978};\\\", \\\"{x:855,y:544,t:1527268355994};\\\", \\\"{x:853,y:543,t:1527268356011};\\\", \\\"{x:848,y:541,t:1527268356028};\\\", \\\"{x:845,y:540,t:1527268356044};\\\", \\\"{x:839,y:538,t:1527268356062};\\\", \\\"{x:836,y:537,t:1527268356078};\\\", \\\"{x:835,y:537,t:1527268356094};\\\", \\\"{x:834,y:536,t:1527268356116};\\\", \\\"{x:833,y:536,t:1527268356429};\\\", \\\"{x:832,y:536,t:1527268356444};\\\", \\\"{x:832,y:537,t:1527268356496};\\\", \\\"{x:830,y:539,t:1527268356511};\\\", \\\"{x:828,y:541,t:1527268356528};\\\", \\\"{x:824,y:544,t:1527268356545};\\\", \\\"{x:817,y:549,t:1527268356561};\\\", \\\"{x:813,y:551,t:1527268356579};\\\", \\\"{x:802,y:555,t:1527268356596};\\\", \\\"{x:786,y:559,t:1527268356612};\\\", \\\"{x:777,y:562,t:1527268356628};\\\", \\\"{x:767,y:566,t:1527268356646};\\\", \\\"{x:755,y:569,t:1527268356662};\\\", \\\"{x:742,y:573,t:1527268356679};\\\", \\\"{x:731,y:574,t:1527268356696};\\\", \\\"{x:716,y:577,t:1527268356713};\\\", \\\"{x:704,y:579,t:1527268356728};\\\", \\\"{x:693,y:583,t:1527268356745};\\\", \\\"{x:681,y:586,t:1527268356762};\\\", \\\"{x:673,y:587,t:1527268356778};\\\", \\\"{x:664,y:589,t:1527268356795};\\\", \\\"{x:650,y:595,t:1527268356813};\\\", \\\"{x:639,y:600,t:1527268356829};\\\", \\\"{x:632,y:604,t:1527268356845};\\\", \\\"{x:626,y:606,t:1527268356863};\\\", \\\"{x:622,y:611,t:1527268356879};\\\", \\\"{x:617,y:613,t:1527268356895};\\\", \\\"{x:614,y:615,t:1527268356912};\\\", \\\"{x:609,y:618,t:1527268356929};\\\", \\\"{x:604,y:621,t:1527268356945};\\\", \\\"{x:598,y:624,t:1527268356963};\\\", \\\"{x:594,y:626,t:1527268356979};\\\", \\\"{x:590,y:629,t:1527268356996};\\\", \\\"{x:586,y:632,t:1527268357012};\\\", \\\"{x:585,y:632,t:1527268357028};\\\", \\\"{x:583,y:633,t:1527268357045};\\\", \\\"{x:581,y:635,t:1527268357063};\\\", \\\"{x:580,y:636,t:1527268357080};\\\", \\\"{x:579,y:639,t:1527268357110};\\\", \\\"{x:578,y:641,t:1527268357125};\\\", \\\"{x:577,y:642,t:1527268357132};\\\", \\\"{x:577,y:643,t:1527268357145};\\\", \\\"{x:576,y:645,t:1527268357162};\\\", \\\"{x:576,y:648,t:1527268357179};\\\", \\\"{x:575,y:650,t:1527268357195};\\\", \\\"{x:574,y:652,t:1527268357212};\\\", \\\"{x:572,y:655,t:1527268357229};\\\", \\\"{x:571,y:657,t:1527268357245};\\\", \\\"{x:569,y:661,t:1527268357262};\\\", \\\"{x:568,y:663,t:1527268357279};\\\", \\\"{x:566,y:666,t:1527268357295};\\\", \\\"{x:564,y:669,t:1527268357312};\\\", \\\"{x:562,y:673,t:1527268357329};\\\", \\\"{x:559,y:677,t:1527268357345};\\\", \\\"{x:555,y:682,t:1527268357362};\\\", \\\"{x:550,y:690,t:1527268357380};\\\", \\\"{x:546,y:695,t:1527268357395};\\\", \\\"{x:540,y:702,t:1527268357413};\\\", \\\"{x:539,y:703,t:1527268357429};\\\", \\\"{x:537,y:705,t:1527268357445};\\\", \\\"{x:537,y:706,t:1527268357477};\\\", \\\"{x:537,y:707,t:1527268357525};\\\", \\\"{x:537,y:708,t:1527268357540};\\\", \\\"{x:537,y:709,t:1527268357557};\\\", \\\"{x:536,y:709,t:1527268357613};\\\", \\\"{x:536,y:710,t:1527268357861};\\\", \\\"{x:536,y:712,t:1527268357965};\\\", \\\"{x:536,y:714,t:1527268357979};\\\", \\\"{x:536,y:721,t:1527268357997};\\\", \\\"{x:536,y:726,t:1527268358014};\\\", \\\"{x:537,y:730,t:1527268358029};\\\", \\\"{x:537,y:734,t:1527268358046};\\\", \\\"{x:537,y:736,t:1527268358063};\\\", \\\"{x:537,y:737,t:1527268358080};\\\", \\\"{x:537,y:738,t:1527268358097};\\\", \\\"{x:537,y:739,t:1527268358113};\\\", \\\"{x:537,y:740,t:1527268358197};\\\", \\\"{x:533,y:740,t:1527268361629};\\\", \\\"{x:531,y:740,t:1527268361637};\\\", \\\"{x:529,y:740,t:1527268361648};\\\", \\\"{x:526,y:740,t:1527268361666};\\\", \\\"{x:525,y:740,t:1527268361716};\\\", \\\"{x:524,y:740,t:1527268361740};\\\", \\\"{x:523,y:740,t:1527268361749};\\\", \\\"{x:521,y:740,t:1527268361772};\\\", \\\"{x:519,y:740,t:1527268361788};\\\", \\\"{x:518,y:740,t:1527268361836};\\\", \\\"{x:517,y:741,t:1527268361860};\\\", \\\"{x:517,y:742,t:1527268361876};\\\", \\\"{x:515,y:742,t:1527268361900};\\\", \\\"{x:514,y:742,t:1527268362076};\\\", \\\"{x:513,y:742,t:1527268362084};\\\", \\\"{x:512,y:742,t:1527268362098};\\\", \\\"{x:511,y:742,t:1527268362332};\\\", \\\"{x:508,y:741,t:1527268362350};\\\", \\\"{x:503,y:738,t:1527268362365};\\\", \\\"{x:494,y:732,t:1527268362383};\\\", \\\"{x:482,y:727,t:1527268362400};\\\", \\\"{x:469,y:721,t:1527268362415};\\\", \\\"{x:462,y:718,t:1527268362433};\\\", \\\"{x:460,y:718,t:1527268362450};\\\", \\\"{x:459,y:717,t:1527268362466};\\\", \\\"{x:460,y:720,t:1527268362652};\\\", \\\"{x:461,y:722,t:1527268362667};\\\", \\\"{x:463,y:724,t:1527268362683};\\\", \\\"{x:465,y:726,t:1527268362700};\\\" ] }, { \\\"rt\\\": 25799, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 433812, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:726,t:1527268365452};\\\", \\\"{x:490,y:726,t:1527268365469};\\\", \\\"{x:513,y:727,t:1527268365486};\\\", \\\"{x:553,y:738,t:1527268365503};\\\", \\\"{x:590,y:751,t:1527268365520};\\\", \\\"{x:623,y:764,t:1527268365535};\\\", \\\"{x:656,y:777,t:1527268365553};\\\", \\\"{x:682,y:789,t:1527268365569};\\\", \\\"{x:707,y:799,t:1527268365585};\\\", \\\"{x:731,y:809,t:1527268365602};\\\", \\\"{x:753,y:819,t:1527268365619};\\\", \\\"{x:777,y:830,t:1527268365636};\\\", \\\"{x:827,y:851,t:1527268365652};\\\", \\\"{x:858,y:865,t:1527268365668};\\\", \\\"{x:881,y:874,t:1527268365686};\\\", \\\"{x:899,y:880,t:1527268365702};\\\", \\\"{x:906,y:884,t:1527268365719};\\\", \\\"{x:907,y:885,t:1527268365736};\\\", \\\"{x:887,y:880,t:1527268371044};\\\", \\\"{x:851,y:871,t:1527268371055};\\\", \\\"{x:753,y:837,t:1527268371071};\\\", \\\"{x:647,y:780,t:1527268371088};\\\", \\\"{x:537,y:715,t:1527268371106};\\\", \\\"{x:436,y:657,t:1527268371122};\\\", \\\"{x:347,y:599,t:1527268371139};\\\", \\\"{x:286,y:558,t:1527268371155};\\\", \\\"{x:244,y:526,t:1527268371174};\\\", \\\"{x:239,y:522,t:1527268371191};\\\", \\\"{x:239,y:521,t:1527268371237};\\\", \\\"{x:239,y:518,t:1527268371244};\\\", \\\"{x:239,y:515,t:1527268371257};\\\", \\\"{x:240,y:510,t:1527268371274};\\\", \\\"{x:245,y:503,t:1527268371291};\\\", \\\"{x:249,y:499,t:1527268371306};\\\", \\\"{x:253,y:495,t:1527268371324};\\\", \\\"{x:260,y:492,t:1527268371341};\\\", \\\"{x:263,y:489,t:1527268371358};\\\", \\\"{x:269,y:487,t:1527268371374};\\\", \\\"{x:271,y:486,t:1527268371391};\\\", \\\"{x:273,y:486,t:1527268371407};\\\", \\\"{x:276,y:486,t:1527268371424};\\\", \\\"{x:277,y:486,t:1527268371440};\\\", \\\"{x:278,y:486,t:1527268371458};\\\", \\\"{x:280,y:484,t:1527268371474};\\\", \\\"{x:282,y:484,t:1527268371490};\\\", \\\"{x:283,y:484,t:1527268371524};\\\", \\\"{x:285,y:484,t:1527268371548};\\\", \\\"{x:286,y:484,t:1527268371564};\\\", \\\"{x:287,y:484,t:1527268371574};\\\", \\\"{x:290,y:484,t:1527268371591};\\\", \\\"{x:292,y:484,t:1527268371607};\\\", \\\"{x:295,y:484,t:1527268371623};\\\", \\\"{x:298,y:484,t:1527268371641};\\\", \\\"{x:299,y:484,t:1527268371658};\\\", \\\"{x:301,y:484,t:1527268371674};\\\", \\\"{x:303,y:484,t:1527268371691};\\\", \\\"{x:305,y:484,t:1527268371708};\\\", \\\"{x:308,y:483,t:1527268371724};\\\", \\\"{x:314,y:482,t:1527268371741};\\\", \\\"{x:319,y:481,t:1527268371758};\\\", \\\"{x:323,y:479,t:1527268371774};\\\", \\\"{x:328,y:479,t:1527268371791};\\\", \\\"{x:333,y:476,t:1527268371808};\\\", \\\"{x:337,y:475,t:1527268371823};\\\", \\\"{x:339,y:475,t:1527268371841};\\\", \\\"{x:343,y:473,t:1527268371858};\\\", \\\"{x:346,y:472,t:1527268371875};\\\", \\\"{x:349,y:472,t:1527268371891};\\\", \\\"{x:352,y:471,t:1527268371908};\\\", \\\"{x:355,y:469,t:1527268371924};\\\", \\\"{x:356,y:469,t:1527268371941};\\\", \\\"{x:358,y:469,t:1527268371958};\\\", \\\"{x:359,y:469,t:1527268371975};\\\", \\\"{x:360,y:468,t:1527268371991};\\\", \\\"{x:361,y:468,t:1527268372008};\\\", \\\"{x:362,y:468,t:1527268372036};\\\", \\\"{x:363,y:468,t:1527268372148};\\\", \\\"{x:364,y:468,t:1527268372172};\\\", \\\"{x:365,y:467,t:1527268372188};\\\", \\\"{x:365,y:466,t:1527268372196};\\\", \\\"{x:366,y:466,t:1527268372236};\\\", \\\"{x:367,y:466,t:1527268372244};\\\", \\\"{x:368,y:466,t:1527268372258};\\\", \\\"{x:370,y:465,t:1527268372283};\\\", \\\"{x:371,y:465,t:1527268372308};\\\", \\\"{x:372,y:465,t:1527268372332};\\\", \\\"{x:373,y:465,t:1527268372372};\\\", \\\"{x:374,y:465,t:1527268372388};\\\", \\\"{x:375,y:464,t:1527268372412};\\\", \\\"{x:375,y:463,t:1527268372425};\\\", \\\"{x:376,y:463,t:1527268372442};\\\", \\\"{x:377,y:463,t:1527268372458};\\\", \\\"{x:378,y:463,t:1527268372475};\\\", \\\"{x:379,y:463,t:1527268372516};\\\", \\\"{x:380,y:463,t:1527268372531};\\\", \\\"{x:381,y:463,t:1527268372564};\\\", \\\"{x:382,y:463,t:1527268372574};\\\", \\\"{x:383,y:462,t:1527268372591};\\\", \\\"{x:384,y:462,t:1527268372612};\\\", \\\"{x:385,y:462,t:1527268372625};\\\", \\\"{x:386,y:462,t:1527268372644};\\\", \\\"{x:387,y:462,t:1527268372692};\\\", \\\"{x:388,y:462,t:1527268372748};\\\", \\\"{x:389,y:462,t:1527268372758};\\\", \\\"{x:390,y:462,t:1527268372812};\\\", \\\"{x:391,y:462,t:1527268372843};\\\", \\\"{x:392,y:462,t:1527268372884};\\\", \\\"{x:393,y:462,t:1527268373468};\\\", \\\"{x:395,y:461,t:1527268373476};\\\", \\\"{x:395,y:460,t:1527268373492};\\\", \\\"{x:396,y:460,t:1527268373508};\\\", \\\"{x:398,y:460,t:1527268373526};\\\", \\\"{x:399,y:460,t:1527268373556};\\\", \\\"{x:400,y:460,t:1527268373564};\\\", \\\"{x:401,y:460,t:1527268373576};\\\", \\\"{x:404,y:460,t:1527268373591};\\\", \\\"{x:409,y:460,t:1527268373609};\\\", \\\"{x:412,y:460,t:1527268373626};\\\", \\\"{x:417,y:460,t:1527268373642};\\\", \\\"{x:423,y:461,t:1527268373658};\\\", \\\"{x:429,y:461,t:1527268373676};\\\", \\\"{x:436,y:463,t:1527268373692};\\\", \\\"{x:441,y:464,t:1527268373708};\\\", \\\"{x:446,y:466,t:1527268373726};\\\", \\\"{x:452,y:468,t:1527268373743};\\\", \\\"{x:455,y:468,t:1527268373759};\\\", \\\"{x:458,y:468,t:1527268373776};\\\", \\\"{x:460,y:468,t:1527268373793};\\\", \\\"{x:461,y:468,t:1527268373809};\\\", \\\"{x:463,y:469,t:1527268373826};\\\", \\\"{x:468,y:470,t:1527268373842};\\\", \\\"{x:473,y:472,t:1527268373859};\\\", \\\"{x:485,y:476,t:1527268373876};\\\", \\\"{x:490,y:478,t:1527268373893};\\\", \\\"{x:493,y:478,t:1527268373909};\\\", \\\"{x:494,y:480,t:1527268373926};\\\", \\\"{x:495,y:480,t:1527268373996};\\\", \\\"{x:496,y:480,t:1527268374068};\\\", \\\"{x:497,y:480,t:1527268374108};\\\", \\\"{x:498,y:480,t:1527268374124};\\\", \\\"{x:499,y:480,t:1527268374164};\\\", \\\"{x:500,y:480,t:1527268374204};\\\", \\\"{x:501,y:480,t:1527268374316};\\\", \\\"{x:502,y:480,t:1527268374332};\\\", \\\"{x:503,y:480,t:1527268374343};\\\", \\\"{x:507,y:480,t:1527268374360};\\\", \\\"{x:509,y:480,t:1527268374375};\\\", \\\"{x:514,y:480,t:1527268374393};\\\", \\\"{x:516,y:479,t:1527268374410};\\\", \\\"{x:521,y:479,t:1527268374426};\\\", \\\"{x:524,y:479,t:1527268374442};\\\", \\\"{x:530,y:477,t:1527268374460};\\\", \\\"{x:533,y:477,t:1527268374476};\\\", \\\"{x:537,y:476,t:1527268374493};\\\", \\\"{x:539,y:476,t:1527268374509};\\\", \\\"{x:541,y:476,t:1527268374526};\\\", \\\"{x:543,y:476,t:1527268374543};\\\", \\\"{x:545,y:475,t:1527268374560};\\\", \\\"{x:549,y:475,t:1527268374576};\\\", \\\"{x:552,y:474,t:1527268374593};\\\", \\\"{x:553,y:474,t:1527268374610};\\\", \\\"{x:555,y:474,t:1527268374626};\\\", \\\"{x:556,y:474,t:1527268374643};\\\", \\\"{x:557,y:473,t:1527268374660};\\\", \\\"{x:559,y:473,t:1527268374675};\\\", \\\"{x:560,y:473,t:1527268374692};\\\", \\\"{x:561,y:473,t:1527268374710};\\\", \\\"{x:563,y:473,t:1527268374727};\\\", \\\"{x:564,y:473,t:1527268374742};\\\", \\\"{x:565,y:473,t:1527268374771};\\\", \\\"{x:566,y:473,t:1527268374780};\\\", \\\"{x:567,y:473,t:1527268374793};\\\", \\\"{x:569,y:473,t:1527268374810};\\\", \\\"{x:573,y:473,t:1527268374827};\\\", \\\"{x:579,y:473,t:1527268374843};\\\", \\\"{x:586,y:473,t:1527268374860};\\\", \\\"{x:592,y:473,t:1527268374877};\\\", \\\"{x:597,y:473,t:1527268374893};\\\", \\\"{x:604,y:473,t:1527268374910};\\\", \\\"{x:612,y:473,t:1527268374927};\\\", \\\"{x:627,y:475,t:1527268374943};\\\", \\\"{x:646,y:480,t:1527268374960};\\\", \\\"{x:673,y:489,t:1527268374977};\\\", \\\"{x:714,y:503,t:1527268374993};\\\", \\\"{x:748,y:513,t:1527268375010};\\\", \\\"{x:771,y:521,t:1527268375027};\\\", \\\"{x:807,y:538,t:1527268375044};\\\", \\\"{x:829,y:550,t:1527268375060};\\\", \\\"{x:852,y:562,t:1527268375077};\\\", \\\"{x:873,y:576,t:1527268375095};\\\", \\\"{x:900,y:604,t:1527268375110};\\\", \\\"{x:940,y:648,t:1527268375127};\\\", \\\"{x:988,y:696,t:1527268375144};\\\", \\\"{x:1033,y:746,t:1527268375160};\\\", \\\"{x:1071,y:786,t:1527268375177};\\\", \\\"{x:1100,y:819,t:1527268375194};\\\", \\\"{x:1119,y:842,t:1527268375211};\\\", \\\"{x:1128,y:855,t:1527268375227};\\\", \\\"{x:1133,y:863,t:1527268375243};\\\", \\\"{x:1136,y:869,t:1527268375261};\\\", \\\"{x:1137,y:874,t:1527268375277};\\\", \\\"{x:1137,y:881,t:1527268375294};\\\", \\\"{x:1138,y:888,t:1527268375311};\\\", \\\"{x:1138,y:896,t:1527268375327};\\\", \\\"{x:1138,y:904,t:1527268375344};\\\", \\\"{x:1138,y:911,t:1527268375361};\\\", \\\"{x:1138,y:914,t:1527268375377};\\\", \\\"{x:1138,y:918,t:1527268375394};\\\", \\\"{x:1138,y:919,t:1527268375411};\\\", \\\"{x:1137,y:920,t:1527268375427};\\\", \\\"{x:1133,y:920,t:1527268375443};\\\", \\\"{x:1129,y:920,t:1527268375460};\\\", \\\"{x:1123,y:920,t:1527268375477};\\\", \\\"{x:1122,y:920,t:1527268375494};\\\", \\\"{x:1119,y:920,t:1527268375511};\\\", \\\"{x:1117,y:920,t:1527268375527};\\\", \\\"{x:1115,y:920,t:1527268375544};\\\", \\\"{x:1111,y:920,t:1527268375561};\\\", \\\"{x:1105,y:917,t:1527268375577};\\\", \\\"{x:1097,y:910,t:1527268375594};\\\", \\\"{x:1090,y:906,t:1527268375611};\\\", \\\"{x:1087,y:904,t:1527268375627};\\\", \\\"{x:1087,y:903,t:1527268375804};\\\", \\\"{x:1087,y:902,t:1527268375812};\\\", \\\"{x:1087,y:899,t:1527268375828};\\\", \\\"{x:1087,y:898,t:1527268375844};\\\", \\\"{x:1087,y:896,t:1527268375866};\\\", \\\"{x:1087,y:892,t:1527268375882};\\\", \\\"{x:1087,y:891,t:1527268375898};\\\", \\\"{x:1087,y:889,t:1527268375915};\\\", \\\"{x:1087,y:887,t:1527268375933};\\\", \\\"{x:1087,y:886,t:1527268375948};\\\", \\\"{x:1087,y:883,t:1527268375965};\\\", \\\"{x:1087,y:880,t:1527268375982};\\\", \\\"{x:1087,y:877,t:1527268375999};\\\", \\\"{x:1087,y:873,t:1527268376015};\\\", \\\"{x:1087,y:859,t:1527268376032};\\\", \\\"{x:1087,y:846,t:1527268376048};\\\", \\\"{x:1084,y:833,t:1527268376065};\\\", \\\"{x:1083,y:823,t:1527268376082};\\\", \\\"{x:1082,y:815,t:1527268376098};\\\", \\\"{x:1081,y:808,t:1527268376116};\\\", \\\"{x:1079,y:800,t:1527268376132};\\\", \\\"{x:1078,y:793,t:1527268376150};\\\", \\\"{x:1077,y:786,t:1527268376166};\\\", \\\"{x:1075,y:777,t:1527268376183};\\\", \\\"{x:1074,y:771,t:1527268376200};\\\", \\\"{x:1073,y:762,t:1527268376216};\\\", \\\"{x:1072,y:753,t:1527268376233};\\\", \\\"{x:1071,y:748,t:1527268376249};\\\", \\\"{x:1070,y:744,t:1527268376265};\\\", \\\"{x:1070,y:741,t:1527268376283};\\\", \\\"{x:1070,y:738,t:1527268376299};\\\", \\\"{x:1070,y:733,t:1527268376316};\\\", \\\"{x:1070,y:730,t:1527268376332};\\\", \\\"{x:1070,y:726,t:1527268376349};\\\", \\\"{x:1070,y:722,t:1527268376365};\\\", \\\"{x:1070,y:718,t:1527268376383};\\\", \\\"{x:1070,y:716,t:1527268376399};\\\", \\\"{x:1070,y:714,t:1527268376416};\\\", \\\"{x:1070,y:713,t:1527268376433};\\\", \\\"{x:1070,y:712,t:1527268376520};\\\", \\\"{x:1070,y:711,t:1527268376533};\\\", \\\"{x:1070,y:709,t:1527268376549};\\\", \\\"{x:1070,y:702,t:1527268376566};\\\", \\\"{x:1070,y:694,t:1527268376582};\\\", \\\"{x:1070,y:687,t:1527268376600};\\\", \\\"{x:1070,y:682,t:1527268376616};\\\", \\\"{x:1071,y:679,t:1527268376633};\\\", \\\"{x:1079,y:678,t:1527268377816};\\\", \\\"{x:1103,y:683,t:1527268377834};\\\", \\\"{x:1126,y:693,t:1527268377850};\\\", \\\"{x:1154,y:703,t:1527268377866};\\\", \\\"{x:1187,y:710,t:1527268377883};\\\", \\\"{x:1205,y:716,t:1527268377900};\\\", \\\"{x:1212,y:719,t:1527268377917};\\\", \\\"{x:1214,y:720,t:1527268377933};\\\", \\\"{x:1220,y:720,t:1527268377951};\\\", \\\"{x:1229,y:721,t:1527268377966};\\\", \\\"{x:1240,y:723,t:1527268377983};\\\", \\\"{x:1269,y:729,t:1527268378000};\\\", \\\"{x:1296,y:731,t:1527268378016};\\\", \\\"{x:1312,y:735,t:1527268378034};\\\", \\\"{x:1320,y:735,t:1527268378050};\\\", \\\"{x:1322,y:736,t:1527268378097};\\\", \\\"{x:1325,y:737,t:1527268378105};\\\", \\\"{x:1328,y:737,t:1527268378117};\\\", \\\"{x:1333,y:740,t:1527268378133};\\\", \\\"{x:1345,y:748,t:1527268378150};\\\", \\\"{x:1360,y:754,t:1527268378168};\\\", \\\"{x:1368,y:759,t:1527268378184};\\\", \\\"{x:1371,y:760,t:1527268378201};\\\", \\\"{x:1371,y:761,t:1527268378232};\\\", \\\"{x:1371,y:762,t:1527268378248};\\\", \\\"{x:1371,y:763,t:1527268378257};\\\", \\\"{x:1371,y:764,t:1527268378273};\\\", \\\"{x:1371,y:765,t:1527268378289};\\\", \\\"{x:1371,y:767,t:1527268378304};\\\", \\\"{x:1371,y:768,t:1527268378337};\\\", \\\"{x:1370,y:769,t:1527268378369};\\\", \\\"{x:1369,y:769,t:1527268378384};\\\", \\\"{x:1368,y:769,t:1527268378408};\\\", \\\"{x:1367,y:769,t:1527268378417};\\\", \\\"{x:1367,y:770,t:1527268378433};\\\", \\\"{x:1366,y:770,t:1527268378451};\\\", \\\"{x:1365,y:770,t:1527268378468};\\\", \\\"{x:1363,y:770,t:1527268378483};\\\", \\\"{x:1362,y:770,t:1527268378500};\\\", \\\"{x:1360,y:770,t:1527268378517};\\\", \\\"{x:1358,y:770,t:1527268378535};\\\", \\\"{x:1357,y:770,t:1527268378553};\\\", \\\"{x:1356,y:770,t:1527268378664};\\\", \\\"{x:1355,y:770,t:1527268378672};\\\", \\\"{x:1354,y:770,t:1527268378792};\\\", \\\"{x:1352,y:770,t:1527268378808};\\\", \\\"{x:1350,y:770,t:1527268378817};\\\", \\\"{x:1348,y:770,t:1527268378834};\\\", \\\"{x:1347,y:770,t:1527268378850};\\\", \\\"{x:1346,y:770,t:1527268378868};\\\", \\\"{x:1346,y:769,t:1527268378889};\\\", \\\"{x:1346,y:768,t:1527268378901};\\\", \\\"{x:1346,y:765,t:1527268378918};\\\", \\\"{x:1346,y:764,t:1527268378935};\\\", \\\"{x:1345,y:762,t:1527268378950};\\\", \\\"{x:1345,y:761,t:1527268378967};\\\", \\\"{x:1345,y:759,t:1527268379112};\\\", \\\"{x:1345,y:758,t:1527268381576};\\\", \\\"{x:1345,y:756,t:1527268381608};\\\", \\\"{x:1345,y:755,t:1527268381689};\\\", \\\"{x:1345,y:753,t:1527268381704};\\\", \\\"{x:1345,y:752,t:1527268381720};\\\", \\\"{x:1345,y:750,t:1527268381760};\\\", \\\"{x:1345,y:749,t:1527268381792};\\\", \\\"{x:1345,y:747,t:1527268381864};\\\", \\\"{x:1347,y:746,t:1527268383577};\\\", \\\"{x:1351,y:746,t:1527268383588};\\\", \\\"{x:1356,y:746,t:1527268383604};\\\", \\\"{x:1356,y:743,t:1527268386480};\\\", \\\"{x:1356,y:738,t:1527268386490};\\\", \\\"{x:1346,y:720,t:1527268386507};\\\", \\\"{x:1324,y:694,t:1527268386523};\\\", \\\"{x:1286,y:665,t:1527268386539};\\\", \\\"{x:1247,y:648,t:1527268386556};\\\", \\\"{x:1200,y:634,t:1527268386573};\\\", \\\"{x:1147,y:622,t:1527268386590};\\\", \\\"{x:1104,y:619,t:1527268386607};\\\", \\\"{x:1075,y:619,t:1527268386624};\\\", \\\"{x:1049,y:620,t:1527268386640};\\\", \\\"{x:1019,y:628,t:1527268386657};\\\", \\\"{x:995,y:631,t:1527268386674};\\\", \\\"{x:970,y:631,t:1527268386689};\\\", \\\"{x:942,y:631,t:1527268386707};\\\", \\\"{x:913,y:631,t:1527268386724};\\\", \\\"{x:898,y:631,t:1527268386736};\\\", \\\"{x:860,y:629,t:1527268386753};\\\", \\\"{x:836,y:626,t:1527268386770};\\\", \\\"{x:814,y:621,t:1527268386787};\\\", \\\"{x:791,y:619,t:1527268386808};\\\", \\\"{x:759,y:614,t:1527268386824};\\\", \\\"{x:743,y:612,t:1527268386841};\\\", \\\"{x:727,y:610,t:1527268386857};\\\", \\\"{x:706,y:608,t:1527268386876};\\\", \\\"{x:683,y:607,t:1527268386890};\\\", \\\"{x:660,y:607,t:1527268386908};\\\", \\\"{x:641,y:609,t:1527268386925};\\\", \\\"{x:623,y:611,t:1527268386941};\\\", \\\"{x:607,y:612,t:1527268386957};\\\", \\\"{x:594,y:612,t:1527268386975};\\\", \\\"{x:577,y:612,t:1527268386990};\\\", \\\"{x:546,y:601,t:1527268387008};\\\", \\\"{x:478,y:572,t:1527268387025};\\\", \\\"{x:426,y:549,t:1527268387043};\\\", \\\"{x:375,y:533,t:1527268387058};\\\", \\\"{x:329,y:523,t:1527268387076};\\\", \\\"{x:291,y:514,t:1527268387092};\\\", \\\"{x:265,y:508,t:1527268387108};\\\", \\\"{x:249,y:506,t:1527268387124};\\\", \\\"{x:246,y:506,t:1527268387142};\\\", \\\"{x:245,y:506,t:1527268387192};\\\", \\\"{x:243,y:506,t:1527268387217};\\\", \\\"{x:241,y:507,t:1527268387225};\\\", \\\"{x:237,y:511,t:1527268387242};\\\", \\\"{x:230,y:517,t:1527268387258};\\\", \\\"{x:221,y:524,t:1527268387275};\\\", \\\"{x:211,y:530,t:1527268387293};\\\", \\\"{x:204,y:534,t:1527268387308};\\\", \\\"{x:198,y:537,t:1527268387325};\\\", \\\"{x:194,y:537,t:1527268387342};\\\", \\\"{x:193,y:537,t:1527268387359};\\\", \\\"{x:191,y:537,t:1527268387375};\\\", \\\"{x:188,y:537,t:1527268387391};\\\", \\\"{x:182,y:537,t:1527268387408};\\\", \\\"{x:178,y:537,t:1527268387425};\\\", \\\"{x:174,y:536,t:1527268387442};\\\", \\\"{x:173,y:536,t:1527268387459};\\\", \\\"{x:175,y:535,t:1527268388216};\\\", \\\"{x:186,y:534,t:1527268388226};\\\", \\\"{x:214,y:534,t:1527268388242};\\\", \\\"{x:262,y:534,t:1527268388259};\\\", \\\"{x:331,y:534,t:1527268388277};\\\", \\\"{x:414,y:543,t:1527268388292};\\\", \\\"{x:502,y:562,t:1527268388309};\\\", \\\"{x:600,y:584,t:1527268388326};\\\", \\\"{x:687,y:610,t:1527268388343};\\\", \\\"{x:766,y:627,t:1527268388360};\\\", \\\"{x:810,y:633,t:1527268388376};\\\", \\\"{x:843,y:635,t:1527268388392};\\\", \\\"{x:848,y:635,t:1527268388409};\\\", \\\"{x:853,y:635,t:1527268388426};\\\", \\\"{x:857,y:634,t:1527268388443};\\\", \\\"{x:859,y:632,t:1527268388459};\\\", \\\"{x:862,y:629,t:1527268388476};\\\", \\\"{x:863,y:629,t:1527268388493};\\\", \\\"{x:863,y:626,t:1527268388509};\\\", \\\"{x:863,y:619,t:1527268388526};\\\", \\\"{x:856,y:604,t:1527268388543};\\\", \\\"{x:835,y:587,t:1527268388559};\\\", \\\"{x:813,y:572,t:1527268388576};\\\", \\\"{x:803,y:564,t:1527268388593};\\\", \\\"{x:802,y:564,t:1527268388609};\\\", \\\"{x:802,y:563,t:1527268388626};\\\", \\\"{x:802,y:561,t:1527268388644};\\\", \\\"{x:809,y:556,t:1527268388660};\\\", \\\"{x:821,y:551,t:1527268388676};\\\", \\\"{x:837,y:545,t:1527268388694};\\\", \\\"{x:856,y:535,t:1527268388710};\\\", \\\"{x:870,y:526,t:1527268388726};\\\", \\\"{x:882,y:519,t:1527268388743};\\\", \\\"{x:889,y:512,t:1527268388760};\\\", \\\"{x:893,y:507,t:1527268388776};\\\", \\\"{x:895,y:501,t:1527268388792};\\\", \\\"{x:895,y:500,t:1527268388810};\\\", \\\"{x:895,y:499,t:1527268388826};\\\", \\\"{x:895,y:498,t:1527268388843};\\\", \\\"{x:891,y:497,t:1527268388864};\\\", \\\"{x:885,y:496,t:1527268388876};\\\", \\\"{x:882,y:496,t:1527268388893};\\\", \\\"{x:881,y:496,t:1527268388910};\\\", \\\"{x:878,y:496,t:1527268388925};\\\", \\\"{x:874,y:496,t:1527268388943};\\\", \\\"{x:867,y:496,t:1527268388960};\\\", \\\"{x:865,y:496,t:1527268388975};\\\", \\\"{x:858,y:497,t:1527268388993};\\\", \\\"{x:853,y:498,t:1527268389010};\\\", \\\"{x:848,y:498,t:1527268389026};\\\", \\\"{x:845,y:498,t:1527268389042};\\\", \\\"{x:843,y:500,t:1527268389060};\\\", \\\"{x:841,y:500,t:1527268389353};\\\", \\\"{x:837,y:502,t:1527268389360};\\\", \\\"{x:820,y:508,t:1527268389377};\\\", \\\"{x:801,y:517,t:1527268389393};\\\", \\\"{x:779,y:526,t:1527268389410};\\\", \\\"{x:746,y:540,t:1527268389427};\\\", \\\"{x:719,y:553,t:1527268389444};\\\", \\\"{x:683,y:568,t:1527268389461};\\\", \\\"{x:649,y:584,t:1527268389477};\\\", \\\"{x:612,y:601,t:1527268389494};\\\", \\\"{x:577,y:616,t:1527268389510};\\\", \\\"{x:544,y:630,t:1527268389527};\\\", \\\"{x:513,y:644,t:1527268389543};\\\", \\\"{x:483,y:660,t:1527268389560};\\\", \\\"{x:447,y:682,t:1527268389577};\\\", \\\"{x:430,y:694,t:1527268389594};\\\", \\\"{x:411,y:708,t:1527268389610};\\\", \\\"{x:392,y:721,t:1527268389627};\\\", \\\"{x:383,y:728,t:1527268389644};\\\", \\\"{x:378,y:735,t:1527268389659};\\\", \\\"{x:377,y:739,t:1527268389677};\\\", \\\"{x:377,y:747,t:1527268389694};\\\", \\\"{x:380,y:753,t:1527268389709};\\\", \\\"{x:392,y:761,t:1527268389727};\\\", \\\"{x:416,y:768,t:1527268389744};\\\", \\\"{x:443,y:772,t:1527268389760};\\\", \\\"{x:473,y:774,t:1527268389777};\\\", \\\"{x:481,y:773,t:1527268389794};\\\", \\\"{x:484,y:771,t:1527268389810};\\\", \\\"{x:487,y:767,t:1527268389827};\\\", \\\"{x:489,y:765,t:1527268389844};\\\", \\\"{x:492,y:760,t:1527268389860};\\\", \\\"{x:494,y:756,t:1527268389877};\\\", \\\"{x:497,y:753,t:1527268389894};\\\", \\\"{x:499,y:750,t:1527268389910};\\\", \\\"{x:500,y:749,t:1527268389927};\\\", \\\"{x:502,y:747,t:1527268389944};\\\", \\\"{x:503,y:745,t:1527268389960};\\\", \\\"{x:503,y:744,t:1527268389976};\\\", \\\"{x:505,y:741,t:1527268389993};\\\", \\\"{x:507,y:739,t:1527268390010};\\\", \\\"{x:511,y:736,t:1527268390027};\\\", \\\"{x:518,y:732,t:1527268390044};\\\", \\\"{x:522,y:730,t:1527268390060};\\\", \\\"{x:522,y:729,t:1527268390077};\\\", \\\"{x:524,y:728,t:1527268390277};\\\", \\\"{x:524,y:727,t:1527268390294};\\\", \\\"{x:525,y:727,t:1527268390311};\\\", \\\"{x:526,y:727,t:1527268390327};\\\", \\\"{x:527,y:727,t:1527268390392};\\\", \\\"{x:527,y:726,t:1527268390400};\\\", \\\"{x:528,y:726,t:1527268390411};\\\", \\\"{x:528,y:725,t:1527268390544};\\\", \\\"{x:528,y:724,t:1527268390672};\\\", \\\"{x:529,y:723,t:1527268390680};\\\", \\\"{x:530,y:723,t:1527268390704};\\\", \\\"{x:530,y:722,t:1527268390744};\\\", \\\"{x:530,y:721,t:1527268390761};\\\", \\\"{x:530,y:720,t:1527268390848};\\\", \\\"{x:531,y:720,t:1527268390860};\\\", \\\"{x:531,y:719,t:1527268390920};\\\", \\\"{x:531,y:718,t:1527268390960};\\\", \\\"{x:531,y:717,t:1527268391016};\\\", \\\"{x:531,y:716,t:1527268391241};\\\", \\\"{x:533,y:714,t:1527268391294};\\\" ] }, { \\\"rt\\\": 21080, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 456115, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:711,t:1527268391466};\\\", \\\"{x:536,y:710,t:1527268391512};\\\", \\\"{x:537,y:709,t:1527268391712};\\\", \\\"{x:537,y:708,t:1527268391744};\\\", \\\"{x:539,y:708,t:1527268391784};\\\", \\\"{x:539,y:707,t:1527268391840};\\\", \\\"{x:539,y:706,t:1527268392449};\\\", \\\"{x:540,y:706,t:1527268392472};\\\", \\\"{x:540,y:705,t:1527268392552};\\\", \\\"{x:541,y:705,t:1527268392568};\\\", \\\"{x:542,y:705,t:1527268392579};\\\", \\\"{x:542,y:704,t:1527268392596};\\\", \\\"{x:543,y:703,t:1527268392624};\\\", \\\"{x:544,y:703,t:1527268392664};\\\", \\\"{x:545,y:702,t:1527268392696};\\\", \\\"{x:546,y:701,t:1527268392745};\\\", \\\"{x:547,y:701,t:1527268392888};\\\", \\\"{x:548,y:701,t:1527268392976};\\\", \\\"{x:549,y:701,t:1527268393016};\\\", \\\"{x:550,y:701,t:1527268393040};\\\", \\\"{x:551,y:701,t:1527268393080};\\\", \\\"{x:551,y:700,t:1527268393104};\\\", \\\"{x:552,y:700,t:1527268393113};\\\", \\\"{x:552,y:699,t:1527268393160};\\\", \\\"{x:553,y:699,t:1527268393176};\\\", \\\"{x:554,y:699,t:1527268393224};\\\", \\\"{x:555,y:699,t:1527268393264};\\\", \\\"{x:556,y:699,t:1527268393280};\\\", \\\"{x:557,y:698,t:1527268393296};\\\", \\\"{x:559,y:698,t:1527268393313};\\\", \\\"{x:561,y:698,t:1527268393330};\\\", \\\"{x:565,y:698,t:1527268393346};\\\", \\\"{x:570,y:698,t:1527268393363};\\\", \\\"{x:578,y:698,t:1527268393380};\\\", \\\"{x:591,y:698,t:1527268393397};\\\", \\\"{x:612,y:702,t:1527268393413};\\\", \\\"{x:640,y:707,t:1527268393430};\\\", \\\"{x:675,y:715,t:1527268393447};\\\", \\\"{x:715,y:722,t:1527268393463};\\\", \\\"{x:750,y:727,t:1527268393480};\\\", \\\"{x:773,y:731,t:1527268393497};\\\", \\\"{x:791,y:731,t:1527268393513};\\\", \\\"{x:807,y:731,t:1527268393530};\\\", \\\"{x:823,y:730,t:1527268393547};\\\", \\\"{x:845,y:724,t:1527268393563};\\\", \\\"{x:873,y:718,t:1527268393580};\\\", \\\"{x:906,y:711,t:1527268393597};\\\", \\\"{x:934,y:700,t:1527268393613};\\\", \\\"{x:952,y:688,t:1527268393630};\\\", \\\"{x:963,y:682,t:1527268393648};\\\", \\\"{x:972,y:674,t:1527268393663};\\\", \\\"{x:991,y:658,t:1527268393680};\\\", \\\"{x:1003,y:647,t:1527268393697};\\\", \\\"{x:1017,y:634,t:1527268393713};\\\", \\\"{x:1030,y:626,t:1527268393730};\\\", \\\"{x:1044,y:618,t:1527268393747};\\\", \\\"{x:1054,y:614,t:1527268393763};\\\", \\\"{x:1068,y:607,t:1527268393780};\\\", \\\"{x:1076,y:604,t:1527268393797};\\\", \\\"{x:1086,y:598,t:1527268393813};\\\", \\\"{x:1096,y:594,t:1527268393830};\\\", \\\"{x:1104,y:589,t:1527268393847};\\\", \\\"{x:1117,y:580,t:1527268393864};\\\", \\\"{x:1120,y:578,t:1527268393880};\\\", \\\"{x:1124,y:575,t:1527268393897};\\\", \\\"{x:1125,y:574,t:1527268393914};\\\", \\\"{x:1126,y:573,t:1527268393930};\\\", \\\"{x:1126,y:572,t:1527268393952};\\\", \\\"{x:1126,y:571,t:1527268393984};\\\", \\\"{x:1126,y:570,t:1527268393997};\\\", \\\"{x:1126,y:568,t:1527268394014};\\\", \\\"{x:1126,y:563,t:1527268394030};\\\", \\\"{x:1126,y:561,t:1527268394047};\\\", \\\"{x:1123,y:556,t:1527268394064};\\\", \\\"{x:1123,y:554,t:1527268394088};\\\", \\\"{x:1122,y:553,t:1527268394097};\\\", \\\"{x:1121,y:552,t:1527268394114};\\\", \\\"{x:1120,y:551,t:1527268394130};\\\", \\\"{x:1118,y:550,t:1527268394147};\\\", \\\"{x:1117,y:549,t:1527268394164};\\\", \\\"{x:1116,y:549,t:1527268394180};\\\", \\\"{x:1114,y:549,t:1527268394197};\\\", \\\"{x:1110,y:549,t:1527268394214};\\\", \\\"{x:1108,y:549,t:1527268394231};\\\", \\\"{x:1104,y:550,t:1527268394247};\\\", \\\"{x:1102,y:552,t:1527268394264};\\\", \\\"{x:1100,y:553,t:1527268394376};\\\", \\\"{x:1101,y:553,t:1527268399713};\\\", \\\"{x:1103,y:554,t:1527268399720};\\\", \\\"{x:1106,y:554,t:1527268399735};\\\", \\\"{x:1115,y:557,t:1527268399751};\\\", \\\"{x:1126,y:561,t:1527268399768};\\\", \\\"{x:1134,y:565,t:1527268399786};\\\", \\\"{x:1148,y:574,t:1527268399802};\\\", \\\"{x:1169,y:595,t:1527268399818};\\\", \\\"{x:1210,y:630,t:1527268399835};\\\", \\\"{x:1251,y:664,t:1527268399852};\\\", \\\"{x:1277,y:687,t:1527268399868};\\\", \\\"{x:1289,y:699,t:1527268399886};\\\", \\\"{x:1289,y:702,t:1527268399901};\\\", \\\"{x:1290,y:702,t:1527268399918};\\\", \\\"{x:1290,y:703,t:1527268399944};\\\", \\\"{x:1290,y:704,t:1527268399960};\\\", \\\"{x:1290,y:706,t:1527268399968};\\\", \\\"{x:1289,y:707,t:1527268399986};\\\", \\\"{x:1288,y:708,t:1527268400001};\\\", \\\"{x:1287,y:709,t:1527268400024};\\\", \\\"{x:1287,y:710,t:1527268400035};\\\", \\\"{x:1284,y:714,t:1527268400051};\\\", \\\"{x:1282,y:722,t:1527268400069};\\\", \\\"{x:1278,y:731,t:1527268400085};\\\", \\\"{x:1275,y:741,t:1527268400103};\\\", \\\"{x:1269,y:757,t:1527268400119};\\\", \\\"{x:1260,y:772,t:1527268400136};\\\", \\\"{x:1240,y:800,t:1527268400152};\\\", \\\"{x:1224,y:818,t:1527268400168};\\\", \\\"{x:1215,y:831,t:1527268400186};\\\", \\\"{x:1208,y:847,t:1527268400203};\\\", \\\"{x:1205,y:859,t:1527268400218};\\\", \\\"{x:1204,y:865,t:1527268400235};\\\", \\\"{x:1204,y:867,t:1527268400252};\\\", \\\"{x:1204,y:868,t:1527268400269};\\\", \\\"{x:1203,y:869,t:1527268400369};\\\", \\\"{x:1203,y:866,t:1527268400386};\\\", \\\"{x:1202,y:852,t:1527268400403};\\\", \\\"{x:1199,y:834,t:1527268400419};\\\", \\\"{x:1194,y:813,t:1527268400436};\\\", \\\"{x:1187,y:788,t:1527268400452};\\\", \\\"{x:1182,y:767,t:1527268400470};\\\", \\\"{x:1180,y:753,t:1527268400485};\\\", \\\"{x:1177,y:745,t:1527268400503};\\\", \\\"{x:1176,y:742,t:1527268400520};\\\", \\\"{x:1176,y:741,t:1527268402569};\\\", \\\"{x:1180,y:741,t:1527268402576};\\\", \\\"{x:1184,y:741,t:1527268402587};\\\", \\\"{x:1189,y:741,t:1527268402604};\\\", \\\"{x:1194,y:741,t:1527268402620};\\\", \\\"{x:1197,y:741,t:1527268402638};\\\", \\\"{x:1198,y:741,t:1527268402654};\\\", \\\"{x:1199,y:741,t:1527268402670};\\\", \\\"{x:1200,y:741,t:1527268402712};\\\", \\\"{x:1201,y:744,t:1527268404801};\\\", \\\"{x:1204,y:751,t:1527268404809};\\\", \\\"{x:1210,y:760,t:1527268404823};\\\", \\\"{x:1216,y:771,t:1527268404839};\\\", \\\"{x:1220,y:779,t:1527268404856};\\\", \\\"{x:1222,y:783,t:1527268404873};\\\", \\\"{x:1222,y:784,t:1527268404890};\\\", \\\"{x:1221,y:784,t:1527268405040};\\\", \\\"{x:1220,y:784,t:1527268405055};\\\", \\\"{x:1219,y:784,t:1527268405073};\\\", \\\"{x:1217,y:784,t:1527268405089};\\\", \\\"{x:1214,y:784,t:1527268405105};\\\", \\\"{x:1209,y:784,t:1527268405123};\\\", \\\"{x:1206,y:783,t:1527268405140};\\\", \\\"{x:1202,y:782,t:1527268405156};\\\", \\\"{x:1198,y:782,t:1527268405173};\\\", \\\"{x:1196,y:782,t:1527268405190};\\\", \\\"{x:1195,y:782,t:1527268405206};\\\", \\\"{x:1193,y:782,t:1527268405222};\\\", \\\"{x:1192,y:782,t:1527268405272};\\\", \\\"{x:1188,y:779,t:1527268405290};\\\", \\\"{x:1184,y:776,t:1527268405306};\\\", \\\"{x:1180,y:772,t:1527268405323};\\\", \\\"{x:1179,y:771,t:1527268405339};\\\", \\\"{x:1179,y:770,t:1527268405360};\\\", \\\"{x:1178,y:769,t:1527268405464};\\\", \\\"{x:1178,y:767,t:1527268405473};\\\", \\\"{x:1177,y:765,t:1527268405490};\\\", \\\"{x:1177,y:763,t:1527268405506};\\\", \\\"{x:1177,y:762,t:1527268405523};\\\", \\\"{x:1177,y:763,t:1527268408992};\\\", \\\"{x:1177,y:764,t:1527268409009};\\\", \\\"{x:1174,y:764,t:1527268409104};\\\", \\\"{x:1171,y:764,t:1527268409113};\\\", \\\"{x:1166,y:764,t:1527268409126};\\\", \\\"{x:1147,y:764,t:1527268409142};\\\", \\\"{x:1129,y:764,t:1527268409159};\\\", \\\"{x:1114,y:764,t:1527268409176};\\\", \\\"{x:1095,y:764,t:1527268409192};\\\", \\\"{x:1087,y:763,t:1527268409209};\\\", \\\"{x:1078,y:761,t:1527268409226};\\\", \\\"{x:1068,y:760,t:1527268409243};\\\", \\\"{x:1052,y:755,t:1527268409260};\\\", \\\"{x:1030,y:745,t:1527268409276};\\\", \\\"{x:995,y:728,t:1527268409293};\\\", \\\"{x:949,y:705,t:1527268409310};\\\", \\\"{x:906,y:680,t:1527268409325};\\\", \\\"{x:875,y:660,t:1527268409342};\\\", \\\"{x:847,y:636,t:1527268409360};\\\", \\\"{x:841,y:629,t:1527268409377};\\\", \\\"{x:824,y:596,t:1527268409394};\\\", \\\"{x:808,y:566,t:1527268409411};\\\", \\\"{x:785,y:534,t:1527268409428};\\\", \\\"{x:759,y:507,t:1527268409444};\\\", \\\"{x:725,y:481,t:1527268409460};\\\", \\\"{x:684,y:455,t:1527268409477};\\\", \\\"{x:647,y:436,t:1527268409494};\\\", \\\"{x:619,y:428,t:1527268409510};\\\", \\\"{x:598,y:424,t:1527268409527};\\\", \\\"{x:581,y:423,t:1527268409543};\\\", \\\"{x:556,y:432,t:1527268409560};\\\", \\\"{x:537,y:443,t:1527268409577};\\\", \\\"{x:519,y:453,t:1527268409593};\\\", \\\"{x:498,y:464,t:1527268409610};\\\", \\\"{x:483,y:476,t:1527268409627};\\\", \\\"{x:471,y:486,t:1527268409643};\\\", \\\"{x:466,y:495,t:1527268409661};\\\", \\\"{x:463,y:498,t:1527268409677};\\\", \\\"{x:461,y:503,t:1527268409694};\\\", \\\"{x:459,y:508,t:1527268409710};\\\", \\\"{x:456,y:515,t:1527268409727};\\\", \\\"{x:449,y:528,t:1527268409745};\\\", \\\"{x:443,y:534,t:1527268409760};\\\", \\\"{x:437,y:542,t:1527268409777};\\\", \\\"{x:432,y:551,t:1527268409794};\\\", \\\"{x:429,y:554,t:1527268409809};\\\", \\\"{x:426,y:558,t:1527268409827};\\\", \\\"{x:424,y:562,t:1527268409844};\\\", \\\"{x:422,y:563,t:1527268409861};\\\", \\\"{x:418,y:564,t:1527268409877};\\\", \\\"{x:417,y:564,t:1527268409912};\\\", \\\"{x:415,y:563,t:1527268409927};\\\", \\\"{x:407,y:550,t:1527268409945};\\\", \\\"{x:394,y:539,t:1527268409961};\\\", \\\"{x:372,y:526,t:1527268409977};\\\", \\\"{x:354,y:516,t:1527268409994};\\\", \\\"{x:334,y:512,t:1527268410010};\\\", \\\"{x:324,y:511,t:1527268410026};\\\", \\\"{x:321,y:511,t:1527268410043};\\\", \\\"{x:318,y:511,t:1527268410061};\\\", \\\"{x:314,y:511,t:1527268410076};\\\", \\\"{x:309,y:514,t:1527268410094};\\\", \\\"{x:303,y:517,t:1527268410110};\\\", \\\"{x:299,y:517,t:1527268410127};\\\", \\\"{x:292,y:517,t:1527268410144};\\\", \\\"{x:288,y:517,t:1527268410161};\\\", \\\"{x:280,y:517,t:1527268410177};\\\", \\\"{x:265,y:510,t:1527268410194};\\\", \\\"{x:250,y:505,t:1527268410211};\\\", \\\"{x:231,y:497,t:1527268410227};\\\", \\\"{x:207,y:487,t:1527268410243};\\\", \\\"{x:183,y:477,t:1527268410261};\\\", \\\"{x:159,y:470,t:1527268410278};\\\", \\\"{x:142,y:465,t:1527268410294};\\\", \\\"{x:129,y:462,t:1527268410311};\\\", \\\"{x:123,y:461,t:1527268410328};\\\", \\\"{x:122,y:461,t:1527268410392};\\\", \\\"{x:121,y:461,t:1527268410400};\\\", \\\"{x:120,y:461,t:1527268410423};\\\", \\\"{x:118,y:461,t:1527268410440};\\\", \\\"{x:118,y:463,t:1527268410464};\\\", \\\"{x:118,y:464,t:1527268410478};\\\", \\\"{x:118,y:467,t:1527268410493};\\\", \\\"{x:119,y:472,t:1527268410511};\\\", \\\"{x:125,y:480,t:1527268410528};\\\", \\\"{x:129,y:481,t:1527268410544};\\\", \\\"{x:131,y:483,t:1527268410561};\\\", \\\"{x:132,y:483,t:1527268410632};\\\", \\\"{x:133,y:483,t:1527268410643};\\\", \\\"{x:135,y:483,t:1527268410660};\\\", \\\"{x:137,y:483,t:1527268410744};\\\", \\\"{x:140,y:485,t:1527268410761};\\\", \\\"{x:144,y:488,t:1527268410779};\\\", \\\"{x:148,y:490,t:1527268410795};\\\", \\\"{x:152,y:493,t:1527268410811};\\\", \\\"{x:154,y:495,t:1527268410828};\\\", \\\"{x:155,y:495,t:1527268411312};\\\", \\\"{x:156,y:495,t:1527268411327};\\\", \\\"{x:165,y:500,t:1527268411345};\\\", \\\"{x:184,y:508,t:1527268411362};\\\", \\\"{x:205,y:520,t:1527268411378};\\\", \\\"{x:238,y:536,t:1527268411396};\\\", \\\"{x:271,y:555,t:1527268411412};\\\", \\\"{x:298,y:568,t:1527268411428};\\\", \\\"{x:334,y:589,t:1527268411445};\\\", \\\"{x:368,y:612,t:1527268411463};\\\", \\\"{x:402,y:635,t:1527268411479};\\\", \\\"{x:423,y:650,t:1527268411496};\\\", \\\"{x:441,y:668,t:1527268411512};\\\", \\\"{x:447,y:680,t:1527268411529};\\\", \\\"{x:451,y:689,t:1527268411545};\\\", \\\"{x:455,y:702,t:1527268411562};\\\", \\\"{x:456,y:712,t:1527268411578};\\\", \\\"{x:456,y:726,t:1527268411595};\\\", \\\"{x:456,y:743,t:1527268411612};\\\", \\\"{x:460,y:760,t:1527268411629};\\\", \\\"{x:461,y:763,t:1527268411644};\\\", \\\"{x:464,y:764,t:1527268411662};\\\", \\\"{x:473,y:773,t:1527268411678};\\\", \\\"{x:474,y:774,t:1527268411695};\\\", \\\"{x:475,y:772,t:1527268411744};\\\", \\\"{x:479,y:762,t:1527268411752};\\\", \\\"{x:480,y:749,t:1527268411762};\\\", \\\"{x:480,y:728,t:1527268411779};\\\", \\\"{x:479,y:718,t:1527268411795};\\\", \\\"{x:478,y:714,t:1527268411811};\\\", \\\"{x:478,y:713,t:1527268411832};\\\", \\\"{x:478,y:714,t:1527268412168};\\\", \\\"{x:478,y:715,t:1527268412192};\\\", \\\"{x:478,y:717,t:1527268412200};\\\", \\\"{x:478,y:718,t:1527268412212};\\\", \\\"{x:478,y:719,t:1527268412241};\\\", \\\"{x:478,y:720,t:1527268412249};\\\", \\\"{x:478,y:721,t:1527268412264};\\\", \\\"{x:478,y:723,t:1527268412279};\\\", \\\"{x:479,y:730,t:1527268412296};\\\", \\\"{x:481,y:734,t:1527268412312};\\\", \\\"{x:482,y:735,t:1527268412329};\\\", \\\"{x:483,y:737,t:1527268412346};\\\", \\\"{x:483,y:738,t:1527268412362};\\\", \\\"{x:484,y:738,t:1527268412703};\\\", \\\"{x:486,y:738,t:1527268412928};\\\", \\\"{x:487,y:738,t:1527268413008};\\\", \\\"{x:488,y:738,t:1527268413024};\\\", \\\"{x:489,y:738,t:1527268413056};\\\", \\\"{x:491,y:736,t:1527268413080};\\\", \\\"{x:491,y:735,t:1527268413112};\\\" ] }, { \\\"rt\\\": 54481, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 511790, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -J -J -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:734,t:1527268413739};\\\", \\\"{x:495,y:734,t:1527268413747};\\\", \\\"{x:508,y:734,t:1527268413765};\\\", \\\"{x:525,y:739,t:1527268413780};\\\", \\\"{x:552,y:749,t:1527268413797};\\\", \\\"{x:577,y:754,t:1527268413814};\\\", \\\"{x:615,y:760,t:1527268413842};\\\", \\\"{x:620,y:761,t:1527268413848};\\\", \\\"{x:627,y:762,t:1527268413864};\\\", \\\"{x:630,y:762,t:1527268413880};\\\", \\\"{x:632,y:763,t:1527268413897};\\\", \\\"{x:633,y:763,t:1527268413914};\\\", \\\"{x:634,y:763,t:1527268413944};\\\", \\\"{x:636,y:763,t:1527268414056};\\\", \\\"{x:638,y:763,t:1527268414063};\\\", \\\"{x:642,y:760,t:1527268414080};\\\", \\\"{x:649,y:758,t:1527268414097};\\\", \\\"{x:653,y:754,t:1527268414114};\\\", \\\"{x:657,y:751,t:1527268414130};\\\", \\\"{x:659,y:751,t:1527268414147};\\\", \\\"{x:660,y:750,t:1527268414164};\\\", \\\"{x:661,y:750,t:1527268414180};\\\", \\\"{x:662,y:747,t:1527268414464};\\\", \\\"{x:665,y:742,t:1527268414481};\\\", \\\"{x:666,y:738,t:1527268414497};\\\", \\\"{x:667,y:736,t:1527268414514};\\\", \\\"{x:668,y:734,t:1527268414531};\\\", \\\"{x:668,y:736,t:1527268415232};\\\", \\\"{x:668,y:737,t:1527268415424};\\\", \\\"{x:668,y:738,t:1527268415432};\\\", \\\"{x:668,y:739,t:1527268415448};\\\", \\\"{x:668,y:741,t:1527268415465};\\\", \\\"{x:667,y:743,t:1527268415480};\\\", \\\"{x:667,y:747,t:1527268415498};\\\", \\\"{x:667,y:753,t:1527268415515};\\\", \\\"{x:667,y:757,t:1527268415531};\\\", \\\"{x:670,y:765,t:1527268415548};\\\", \\\"{x:674,y:771,t:1527268415565};\\\", \\\"{x:677,y:776,t:1527268415581};\\\", \\\"{x:681,y:781,t:1527268415597};\\\", \\\"{x:684,y:787,t:1527268415615};\\\", \\\"{x:686,y:792,t:1527268415630};\\\", \\\"{x:690,y:800,t:1527268415647};\\\", \\\"{x:692,y:803,t:1527268415664};\\\", \\\"{x:692,y:805,t:1527268415681};\\\", \\\"{x:693,y:805,t:1527268415744};\\\", \\\"{x:696,y:805,t:1527268415752};\\\", \\\"{x:698,y:804,t:1527268415765};\\\", \\\"{x:702,y:803,t:1527268415781};\\\", \\\"{x:707,y:800,t:1527268415798};\\\", \\\"{x:710,y:800,t:1527268415815};\\\", \\\"{x:711,y:800,t:1527268415872};\\\", \\\"{x:712,y:800,t:1527268415881};\\\", \\\"{x:714,y:804,t:1527268415898};\\\", \\\"{x:715,y:809,t:1527268415915};\\\", \\\"{x:718,y:818,t:1527268415932};\\\", \\\"{x:719,y:827,t:1527268415948};\\\", \\\"{x:722,y:836,t:1527268415965};\\\", \\\"{x:726,y:844,t:1527268415982};\\\", \\\"{x:730,y:850,t:1527268415998};\\\", \\\"{x:736,y:856,t:1527268416015};\\\", \\\"{x:755,y:866,t:1527268416032};\\\", \\\"{x:773,y:873,t:1527268416048};\\\", \\\"{x:800,y:883,t:1527268416065};\\\", \\\"{x:834,y:893,t:1527268416082};\\\", \\\"{x:874,y:908,t:1527268416098};\\\", \\\"{x:913,y:925,t:1527268416115};\\\", \\\"{x:936,y:934,t:1527268416132};\\\", \\\"{x:952,y:943,t:1527268416148};\\\", \\\"{x:971,y:958,t:1527268416165};\\\", \\\"{x:992,y:973,t:1527268416182};\\\", \\\"{x:1018,y:996,t:1527268416198};\\\", \\\"{x:1052,y:1020,t:1527268416215};\\\", \\\"{x:1124,y:1065,t:1527268416232};\\\", \\\"{x:1193,y:1094,t:1527268416248};\\\", \\\"{x:1266,y:1118,t:1527268416264};\\\", \\\"{x:1321,y:1133,t:1527268416282};\\\", \\\"{x:1358,y:1138,t:1527268416298};\\\", \\\"{x:1379,y:1138,t:1527268416315};\\\", \\\"{x:1397,y:1138,t:1527268416332};\\\", \\\"{x:1412,y:1138,t:1527268416348};\\\", \\\"{x:1438,y:1138,t:1527268416365};\\\", \\\"{x:1474,y:1138,t:1527268416382};\\\", \\\"{x:1527,y:1138,t:1527268416398};\\\", \\\"{x:1590,y:1132,t:1527268416415};\\\", \\\"{x:1662,y:1130,t:1527268416432};\\\", \\\"{x:1679,y:1120,t:1527268416448};\\\", \\\"{x:1688,y:1111,t:1527268416465};\\\", \\\"{x:1689,y:1099,t:1527268416482};\\\", \\\"{x:1689,y:1086,t:1527268416498};\\\", \\\"{x:1686,y:1074,t:1527268416515};\\\", \\\"{x:1682,y:1067,t:1527268416532};\\\", \\\"{x:1679,y:1062,t:1527268416549};\\\", \\\"{x:1678,y:1060,t:1527268416565};\\\", \\\"{x:1677,y:1060,t:1527268416582};\\\", \\\"{x:1676,y:1059,t:1527268416599};\\\", \\\"{x:1675,y:1059,t:1527268416623};\\\", \\\"{x:1674,y:1059,t:1527268416632};\\\", \\\"{x:1673,y:1059,t:1527268416649};\\\", \\\"{x:1672,y:1058,t:1527268416665};\\\", \\\"{x:1670,y:1058,t:1527268416682};\\\", \\\"{x:1667,y:1058,t:1527268416699};\\\", \\\"{x:1664,y:1058,t:1527268416715};\\\", \\\"{x:1663,y:1057,t:1527268416732};\\\", \\\"{x:1661,y:1057,t:1527268416749};\\\", \\\"{x:1658,y:1057,t:1527268416765};\\\", \\\"{x:1655,y:1056,t:1527268416782};\\\", \\\"{x:1649,y:1054,t:1527268416799};\\\", \\\"{x:1647,y:1054,t:1527268416815};\\\", \\\"{x:1639,y:1054,t:1527268416832};\\\", \\\"{x:1631,y:1053,t:1527268416849};\\\", \\\"{x:1619,y:1051,t:1527268416865};\\\", \\\"{x:1602,y:1047,t:1527268416882};\\\", \\\"{x:1577,y:1041,t:1527268416899};\\\", \\\"{x:1537,y:1028,t:1527268416915};\\\", \\\"{x:1479,y:1013,t:1527268416932};\\\", \\\"{x:1403,y:988,t:1527268416950};\\\", \\\"{x:1324,y:957,t:1527268416965};\\\", \\\"{x:1230,y:920,t:1527268416982};\\\", \\\"{x:1144,y:879,t:1527268416999};\\\", \\\"{x:1102,y:857,t:1527268417015};\\\", \\\"{x:1084,y:847,t:1527268417031};\\\", \\\"{x:1081,y:845,t:1527268417049};\\\", \\\"{x:1081,y:844,t:1527268417066};\\\", \\\"{x:1081,y:842,t:1527268417082};\\\", \\\"{x:1081,y:840,t:1527268417099};\\\", \\\"{x:1081,y:838,t:1527268417116};\\\", \\\"{x:1081,y:837,t:1527268417132};\\\", \\\"{x:1081,y:835,t:1527268417149};\\\", \\\"{x:1081,y:831,t:1527268417166};\\\", \\\"{x:1084,y:829,t:1527268417182};\\\", \\\"{x:1088,y:827,t:1527268417199};\\\", \\\"{x:1096,y:826,t:1527268417216};\\\", \\\"{x:1106,y:824,t:1527268417232};\\\", \\\"{x:1121,y:824,t:1527268417250};\\\", \\\"{x:1136,y:824,t:1527268417266};\\\", \\\"{x:1149,y:822,t:1527268417283};\\\", \\\"{x:1153,y:822,t:1527268417299};\\\", \\\"{x:1154,y:821,t:1527268417316};\\\", \\\"{x:1156,y:821,t:1527268417332};\\\", \\\"{x:1159,y:821,t:1527268417349};\\\", \\\"{x:1163,y:821,t:1527268417367};\\\", \\\"{x:1170,y:821,t:1527268417382};\\\", \\\"{x:1173,y:820,t:1527268417399};\\\", \\\"{x:1178,y:818,t:1527268417416};\\\", \\\"{x:1180,y:818,t:1527268417432};\\\", \\\"{x:1181,y:817,t:1527268417449};\\\", \\\"{x:1183,y:815,t:1527268417466};\\\", \\\"{x:1185,y:815,t:1527268417482};\\\", \\\"{x:1187,y:814,t:1527268417520};\\\", \\\"{x:1188,y:813,t:1527268417552};\\\", \\\"{x:1188,y:812,t:1527268417566};\\\", \\\"{x:1188,y:809,t:1527268417582};\\\", \\\"{x:1188,y:802,t:1527268417599};\\\", \\\"{x:1188,y:797,t:1527268417616};\\\", \\\"{x:1188,y:792,t:1527268417633};\\\", \\\"{x:1188,y:790,t:1527268417649};\\\", \\\"{x:1188,y:788,t:1527268417666};\\\", \\\"{x:1188,y:787,t:1527268417683};\\\", \\\"{x:1188,y:785,t:1527268417699};\\\", \\\"{x:1188,y:784,t:1527268417716};\\\", \\\"{x:1188,y:780,t:1527268417733};\\\", \\\"{x:1188,y:779,t:1527268417749};\\\", \\\"{x:1188,y:777,t:1527268417766};\\\", \\\"{x:1187,y:777,t:1527268417783};\\\", \\\"{x:1184,y:773,t:1527268417800};\\\", \\\"{x:1177,y:769,t:1527268417816};\\\", \\\"{x:1172,y:768,t:1527268417834};\\\", \\\"{x:1171,y:767,t:1527268417850};\\\", \\\"{x:1170,y:766,t:1527268417866};\\\", \\\"{x:1169,y:766,t:1527268417883};\\\", \\\"{x:1168,y:766,t:1527268417900};\\\", \\\"{x:1168,y:765,t:1527268419953};\\\", \\\"{x:1168,y:764,t:1527268419968};\\\", \\\"{x:1167,y:762,t:1527268419984};\\\", \\\"{x:1166,y:762,t:1527268420001};\\\", \\\"{x:1166,y:761,t:1527268420017};\\\", \\\"{x:1166,y:760,t:1527268420537};\\\", \\\"{x:1167,y:760,t:1527268420551};\\\", \\\"{x:1169,y:760,t:1527268420568};\\\", \\\"{x:1170,y:760,t:1527268420584};\\\", \\\"{x:1171,y:760,t:1527268420602};\\\", \\\"{x:1172,y:760,t:1527268421001};\\\", \\\"{x:1174,y:759,t:1527268421008};\\\", \\\"{x:1175,y:759,t:1527268421032};\\\", \\\"{x:1176,y:759,t:1527268421072};\\\", \\\"{x:1177,y:759,t:1527268421086};\\\", \\\"{x:1178,y:759,t:1527268421118};\\\", \\\"{x:1179,y:759,t:1527268421135};\\\", \\\"{x:1180,y:759,t:1527268421168};\\\", \\\"{x:1181,y:759,t:1527268421186};\\\", \\\"{x:1183,y:759,t:1527268421202};\\\", \\\"{x:1185,y:757,t:1527268421219};\\\", \\\"{x:1188,y:757,t:1527268421236};\\\", \\\"{x:1190,y:757,t:1527268421251};\\\", \\\"{x:1191,y:757,t:1527268421268};\\\", \\\"{x:1191,y:756,t:1527268421673};\\\", \\\"{x:1190,y:756,t:1527268421685};\\\", \\\"{x:1188,y:756,t:1527268421702};\\\", \\\"{x:1187,y:756,t:1527268421718};\\\", \\\"{x:1185,y:755,t:1527268421736};\\\", \\\"{x:1182,y:755,t:1527268421752};\\\", \\\"{x:1179,y:755,t:1527268421769};\\\", \\\"{x:1176,y:754,t:1527268421786};\\\", \\\"{x:1173,y:753,t:1527268421802};\\\", \\\"{x:1172,y:753,t:1527268421824};\\\", \\\"{x:1171,y:753,t:1527268424808};\\\", \\\"{x:1170,y:753,t:1527268427784};\\\", \\\"{x:1170,y:757,t:1527268427791};\\\", \\\"{x:1170,y:766,t:1527268427805};\\\", \\\"{x:1172,y:777,t:1527268427823};\\\", \\\"{x:1173,y:785,t:1527268427838};\\\", \\\"{x:1174,y:788,t:1527268427856};\\\", \\\"{x:1174,y:786,t:1527268431232};\\\", \\\"{x:1174,y:784,t:1527268431241};\\\", \\\"{x:1174,y:781,t:1527268431258};\\\", \\\"{x:1174,y:778,t:1527268431275};\\\", \\\"{x:1174,y:775,t:1527268431291};\\\", \\\"{x:1174,y:772,t:1527268431308};\\\", \\\"{x:1174,y:771,t:1527268431325};\\\", \\\"{x:1174,y:769,t:1527268431340};\\\", \\\"{x:1175,y:766,t:1527268431567};\\\", \\\"{x:1175,y:765,t:1527268431591};\\\", \\\"{x:1175,y:764,t:1527268431624};\\\", \\\"{x:1170,y:764,t:1527268447931};\\\", \\\"{x:1155,y:764,t:1527268447939};\\\", \\\"{x:1106,y:764,t:1527268447955};\\\", \\\"{x:1026,y:755,t:1527268447971};\\\", \\\"{x:934,y:738,t:1527268447988};\\\", \\\"{x:816,y:713,t:1527268448005};\\\", \\\"{x:687,y:683,t:1527268448021};\\\", \\\"{x:545,y:660,t:1527268448038};\\\", \\\"{x:363,y:637,t:1527268448055};\\\", \\\"{x:161,y:605,t:1527268448072};\\\", \\\"{x:0,y:564,t:1527268448089};\\\", \\\"{x:0,y:539,t:1527268448104};\\\", \\\"{x:0,y:519,t:1527268448129};\\\", \\\"{x:0,y:513,t:1527268448146};\\\", \\\"{x:1,y:512,t:1527268448250};\\\", \\\"{x:4,y:512,t:1527268448263};\\\", \\\"{x:21,y:506,t:1527268448279};\\\", \\\"{x:51,y:495,t:1527268448296};\\\", \\\"{x:90,y:484,t:1527268448313};\\\", \\\"{x:115,y:477,t:1527268448328};\\\", \\\"{x:136,y:471,t:1527268448346};\\\", \\\"{x:145,y:467,t:1527268448362};\\\", \\\"{x:146,y:466,t:1527268448378};\\\", \\\"{x:146,y:465,t:1527268448507};\\\", \\\"{x:146,y:464,t:1527268448530};\\\", \\\"{x:147,y:463,t:1527268448562};\\\", \\\"{x:149,y:463,t:1527268448579};\\\", \\\"{x:151,y:463,t:1527268448596};\\\", \\\"{x:153,y:464,t:1527268448618};\\\", \\\"{x:153,y:467,t:1527268448634};\\\", \\\"{x:156,y:472,t:1527268448646};\\\", \\\"{x:158,y:482,t:1527268448662};\\\", \\\"{x:163,y:493,t:1527268448679};\\\", \\\"{x:168,y:502,t:1527268448696};\\\", \\\"{x:172,y:510,t:1527268448713};\\\", \\\"{x:172,y:513,t:1527268448730};\\\", \\\"{x:172,y:516,t:1527268448746};\\\", \\\"{x:174,y:518,t:1527268448763};\\\", \\\"{x:171,y:517,t:1527268449276};\\\", \\\"{x:165,y:515,t:1527268449282};\\\", \\\"{x:161,y:513,t:1527268449296};\\\", \\\"{x:155,y:511,t:1527268449313};\\\", \\\"{x:151,y:508,t:1527268449330};\\\", \\\"{x:149,y:507,t:1527268449346};\\\", \\\"{x:148,y:505,t:1527268450867};\\\", \\\"{x:148,y:504,t:1527268450881};\\\", \\\"{x:148,y:503,t:1527268450897};\\\", \\\"{x:148,y:501,t:1527268450913};\\\", \\\"{x:150,y:499,t:1527268450930};\\\", \\\"{x:150,y:498,t:1527268450946};\\\", \\\"{x:151,y:496,t:1527268452091};\\\", \\\"{x:152,y:495,t:1527268452098};\\\", \\\"{x:155,y:495,t:1527268452114};\\\", \\\"{x:176,y:495,t:1527268452131};\\\", \\\"{x:227,y:512,t:1527268452149};\\\", \\\"{x:332,y:557,t:1527268452167};\\\", \\\"{x:467,y:614,t:1527268452182};\\\", \\\"{x:635,y:691,t:1527268452199};\\\", \\\"{x:817,y:774,t:1527268452215};\\\", \\\"{x:994,y:854,t:1527268452231};\\\", \\\"{x:1149,y:926,t:1527268452249};\\\", \\\"{x:1247,y:962,t:1527268452265};\\\", \\\"{x:1290,y:985,t:1527268452281};\\\", \\\"{x:1299,y:991,t:1527268452299};\\\", \\\"{x:1296,y:989,t:1527268452371};\\\", \\\"{x:1289,y:985,t:1527268452381};\\\", \\\"{x:1267,y:968,t:1527268452399};\\\", \\\"{x:1232,y:940,t:1527268452415};\\\", \\\"{x:1175,y:898,t:1527268452433};\\\", \\\"{x:1108,y:851,t:1527268452449};\\\", \\\"{x:1045,y:814,t:1527268452466};\\\", \\\"{x:1001,y:784,t:1527268452483};\\\", \\\"{x:990,y:776,t:1527268452499};\\\", \\\"{x:989,y:775,t:1527268452515};\\\", \\\"{x:991,y:775,t:1527268452651};\\\", \\\"{x:993,y:775,t:1527268452666};\\\", \\\"{x:1003,y:775,t:1527268452683};\\\", \\\"{x:1007,y:775,t:1527268452700};\\\", \\\"{x:1010,y:775,t:1527268452716};\\\", \\\"{x:1011,y:775,t:1527268452733};\\\", \\\"{x:1013,y:775,t:1527268452749};\\\", \\\"{x:1014,y:775,t:1527268452770};\\\", \\\"{x:1016,y:775,t:1527268452783};\\\", \\\"{x:1018,y:775,t:1527268452799};\\\", \\\"{x:1021,y:776,t:1527268452816};\\\", \\\"{x:1025,y:776,t:1527268452832};\\\", \\\"{x:1028,y:777,t:1527268452850};\\\", \\\"{x:1037,y:778,t:1527268452865};\\\", \\\"{x:1059,y:784,t:1527268452882};\\\", \\\"{x:1083,y:789,t:1527268452899};\\\", \\\"{x:1108,y:797,t:1527268452917};\\\", \\\"{x:1137,y:806,t:1527268452933};\\\", \\\"{x:1158,y:811,t:1527268452950};\\\", \\\"{x:1168,y:814,t:1527268452966};\\\", \\\"{x:1173,y:816,t:1527268452982};\\\", \\\"{x:1175,y:816,t:1527268452999};\\\", \\\"{x:1176,y:816,t:1527268453017};\\\", \\\"{x:1180,y:817,t:1527268453033};\\\", \\\"{x:1185,y:818,t:1527268453050};\\\", \\\"{x:1199,y:822,t:1527268453066};\\\", \\\"{x:1217,y:827,t:1527268453083};\\\", \\\"{x:1234,y:832,t:1527268453100};\\\", \\\"{x:1246,y:835,t:1527268453116};\\\", \\\"{x:1250,y:835,t:1527268453133};\\\", \\\"{x:1250,y:836,t:1527268454627};\\\", \\\"{x:1251,y:836,t:1527268454843};\\\", \\\"{x:1253,y:836,t:1527268454852};\\\", \\\"{x:1256,y:836,t:1527268454869};\\\", \\\"{x:1258,y:836,t:1527268454886};\\\", \\\"{x:1261,y:837,t:1527268454902};\\\", \\\"{x:1264,y:838,t:1527268454919};\\\", \\\"{x:1266,y:839,t:1527268454936};\\\", \\\"{x:1267,y:839,t:1527268454953};\\\", \\\"{x:1270,y:839,t:1527268454969};\\\", \\\"{x:1273,y:840,t:1527268454986};\\\", \\\"{x:1276,y:840,t:1527268455002};\\\", \\\"{x:1277,y:840,t:1527268455019};\\\", \\\"{x:1281,y:840,t:1527268455036};\\\", \\\"{x:1283,y:840,t:1527268455052};\\\", \\\"{x:1284,y:840,t:1527268455069};\\\", \\\"{x:1286,y:840,t:1527268455085};\\\", \\\"{x:1288,y:840,t:1527268455102};\\\", \\\"{x:1292,y:839,t:1527268455119};\\\", \\\"{x:1295,y:838,t:1527268455136};\\\", \\\"{x:1300,y:834,t:1527268455153};\\\", \\\"{x:1305,y:833,t:1527268455169};\\\", \\\"{x:1308,y:831,t:1527268455185};\\\", \\\"{x:1315,y:828,t:1527268455202};\\\", \\\"{x:1319,y:826,t:1527268455219};\\\", \\\"{x:1320,y:826,t:1527268455242};\\\", \\\"{x:1321,y:825,t:1527268455315};\\\", \\\"{x:1320,y:824,t:1527268455322};\\\", \\\"{x:1313,y:824,t:1527268455336};\\\", \\\"{x:1298,y:827,t:1527268455353};\\\", \\\"{x:1287,y:834,t:1527268455369};\\\", \\\"{x:1281,y:837,t:1527268455386};\\\", \\\"{x:1278,y:839,t:1527268455403};\\\", \\\"{x:1277,y:839,t:1527268455459};\\\", \\\"{x:1275,y:839,t:1527268455474};\\\", \\\"{x:1274,y:839,t:1527268455487};\\\", \\\"{x:1271,y:839,t:1527268455503};\\\", \\\"{x:1268,y:839,t:1527268455520};\\\", \\\"{x:1267,y:839,t:1527268455536};\\\", \\\"{x:1265,y:839,t:1527268455552};\\\", \\\"{x:1264,y:839,t:1527268455570};\\\", \\\"{x:1261,y:839,t:1527268455586};\\\", \\\"{x:1257,y:839,t:1527268455603};\\\", \\\"{x:1248,y:839,t:1527268455620};\\\", \\\"{x:1240,y:839,t:1527268455637};\\\", \\\"{x:1229,y:839,t:1527268455653};\\\", \\\"{x:1222,y:839,t:1527268455670};\\\", \\\"{x:1218,y:839,t:1527268455687};\\\", \\\"{x:1217,y:839,t:1527268455923};\\\", \\\"{x:1216,y:838,t:1527268455939};\\\", \\\"{x:1215,y:837,t:1527268455962};\\\", \\\"{x:1215,y:836,t:1527268455986};\\\", \\\"{x:1214,y:835,t:1527268456003};\\\", \\\"{x:1213,y:835,t:1527268456021};\\\", \\\"{x:1213,y:834,t:1527268456266};\\\", \\\"{x:1212,y:833,t:1527268456803};\\\", \\\"{x:1212,y:832,t:1527268456810};\\\", \\\"{x:1212,y:830,t:1527268456822};\\\", \\\"{x:1209,y:827,t:1527268456838};\\\", \\\"{x:1208,y:824,t:1527268456855};\\\", \\\"{x:1206,y:821,t:1527268456872};\\\", \\\"{x:1204,y:818,t:1527268456888};\\\", \\\"{x:1203,y:814,t:1527268456905};\\\", \\\"{x:1202,y:812,t:1527268456922};\\\", \\\"{x:1199,y:807,t:1527268456938};\\\", \\\"{x:1196,y:803,t:1527268456955};\\\", \\\"{x:1195,y:802,t:1527268456972};\\\", \\\"{x:1194,y:801,t:1527268456988};\\\", \\\"{x:1193,y:799,t:1527268457005};\\\", \\\"{x:1192,y:798,t:1527268457043};\\\", \\\"{x:1192,y:797,t:1527268457058};\\\", \\\"{x:1192,y:796,t:1527268457072};\\\", \\\"{x:1190,y:791,t:1527268457088};\\\", \\\"{x:1188,y:786,t:1527268457105};\\\", \\\"{x:1183,y:774,t:1527268457121};\\\", \\\"{x:1175,y:760,t:1527268457138};\\\", \\\"{x:1173,y:754,t:1527268457155};\\\", \\\"{x:1170,y:750,t:1527268457172};\\\", \\\"{x:1169,y:749,t:1527268457189};\\\", \\\"{x:1172,y:750,t:1527268457467};\\\", \\\"{x:1172,y:751,t:1527268457474};\\\", \\\"{x:1174,y:752,t:1527268457489};\\\", \\\"{x:1177,y:755,t:1527268457506};\\\", \\\"{x:1180,y:758,t:1527268457522};\\\", \\\"{x:1175,y:758,t:1527268466707};\\\", \\\"{x:1161,y:758,t:1527268466718};\\\", \\\"{x:1138,y:758,t:1527268466735};\\\", \\\"{x:1122,y:758,t:1527268466751};\\\", \\\"{x:1107,y:758,t:1527268466768};\\\", \\\"{x:1088,y:758,t:1527268466785};\\\", \\\"{x:1065,y:758,t:1527268466802};\\\", \\\"{x:1014,y:755,t:1527268466818};\\\", \\\"{x:966,y:747,t:1527268466835};\\\", \\\"{x:899,y:737,t:1527268466852};\\\", \\\"{x:816,y:726,t:1527268466869};\\\", \\\"{x:721,y:706,t:1527268466885};\\\", \\\"{x:615,y:676,t:1527268466901};\\\", \\\"{x:532,y:651,t:1527268466918};\\\", \\\"{x:472,y:631,t:1527268466936};\\\", \\\"{x:428,y:613,t:1527268466951};\\\", \\\"{x:387,y:600,t:1527268466971};\\\", \\\"{x:375,y:596,t:1527268466987};\\\", \\\"{x:368,y:594,t:1527268467003};\\\", \\\"{x:364,y:593,t:1527268467021};\\\", \\\"{x:359,y:591,t:1527268467038};\\\", \\\"{x:342,y:587,t:1527268467061};\\\", \\\"{x:322,y:580,t:1527268467078};\\\", \\\"{x:300,y:575,t:1527268467094};\\\", \\\"{x:281,y:567,t:1527268467111};\\\", \\\"{x:263,y:558,t:1527268467129};\\\", \\\"{x:249,y:553,t:1527268467146};\\\", \\\"{x:239,y:547,t:1527268467162};\\\", \\\"{x:234,y:544,t:1527268467177};\\\", \\\"{x:223,y:536,t:1527268467194};\\\", \\\"{x:212,y:529,t:1527268467212};\\\", \\\"{x:196,y:519,t:1527268467228};\\\", \\\"{x:185,y:513,t:1527268467244};\\\", \\\"{x:180,y:510,t:1527268467262};\\\", \\\"{x:178,y:508,t:1527268467278};\\\", \\\"{x:177,y:507,t:1527268467295};\\\", \\\"{x:174,y:504,t:1527268467311};\\\", \\\"{x:171,y:502,t:1527268467327};\\\", \\\"{x:166,y:499,t:1527268467345};\\\", \\\"{x:165,y:498,t:1527268467361};\\\", \\\"{x:171,y:498,t:1527268467611};\\\", \\\"{x:182,y:498,t:1527268467619};\\\", \\\"{x:196,y:501,t:1527268467629};\\\", \\\"{x:221,y:513,t:1527268467644};\\\", \\\"{x:251,y:532,t:1527268467662};\\\", \\\"{x:287,y:565,t:1527268467679};\\\", \\\"{x:321,y:602,t:1527268467694};\\\", \\\"{x:356,y:643,t:1527268467712};\\\", \\\"{x:382,y:680,t:1527268467729};\\\", \\\"{x:404,y:703,t:1527268467744};\\\", \\\"{x:422,y:721,t:1527268467761};\\\", \\\"{x:428,y:724,t:1527268467778};\\\", \\\"{x:429,y:725,t:1527268467794};\\\", \\\"{x:430,y:725,t:1527268467858};\\\", \\\"{x:432,y:727,t:1527268467882};\\\", \\\"{x:435,y:727,t:1527268467898};\\\", \\\"{x:437,y:727,t:1527268467911};\\\", \\\"{x:442,y:727,t:1527268467929};\\\", \\\"{x:447,y:727,t:1527268467946};\\\", \\\"{x:452,y:727,t:1527268467962};\\\", \\\"{x:459,y:727,t:1527268467978};\\\", \\\"{x:463,y:727,t:1527268467994};\\\", \\\"{x:466,y:727,t:1527268468011};\\\", \\\"{x:469,y:727,t:1527268468028};\\\", \\\"{x:472,y:728,t:1527268468044};\\\", \\\"{x:479,y:729,t:1527268468061};\\\", \\\"{x:481,y:730,t:1527268468078};\\\", \\\"{x:483,y:731,t:1527268468094};\\\" ] }, { \\\"rt\\\": 60079, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 573064, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -H -F -F -F -F -F -F -B -F -F -04 PM-F -04 PM-05 PM-05 PM-04 PM-04 PM-I -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:729,t:1527268470075};\\\", \\\"{x:486,y:711,t:1527268470095};\\\", \\\"{x:486,y:695,t:1527268470114};\\\", \\\"{x:486,y:682,t:1527268470130};\\\", \\\"{x:483,y:668,t:1527268470147};\\\", \\\"{x:482,y:663,t:1527268470163};\\\", \\\"{x:480,y:658,t:1527268470180};\\\", \\\"{x:480,y:657,t:1527268470202};\\\", \\\"{x:480,y:656,t:1527268470213};\\\", \\\"{x:480,y:655,t:1527268470242};\\\", \\\"{x:480,y:653,t:1527268470250};\\\", \\\"{x:480,y:651,t:1527268470267};\\\", \\\"{x:480,y:650,t:1527268470280};\\\", \\\"{x:480,y:646,t:1527268470296};\\\", \\\"{x:479,y:642,t:1527268470313};\\\", \\\"{x:476,y:633,t:1527268470330};\\\", \\\"{x:474,y:622,t:1527268470347};\\\", \\\"{x:473,y:612,t:1527268470363};\\\", \\\"{x:472,y:602,t:1527268470381};\\\", \\\"{x:472,y:592,t:1527268470397};\\\", \\\"{x:472,y:585,t:1527268470414};\\\", \\\"{x:472,y:576,t:1527268470430};\\\", \\\"{x:473,y:571,t:1527268470447};\\\", \\\"{x:476,y:566,t:1527268470463};\\\", \\\"{x:480,y:561,t:1527268470481};\\\", \\\"{x:484,y:556,t:1527268470498};\\\", \\\"{x:489,y:550,t:1527268470514};\\\", \\\"{x:493,y:544,t:1527268470530};\\\", \\\"{x:495,y:542,t:1527268470547};\\\", \\\"{x:496,y:541,t:1527268470563};\\\", \\\"{x:496,y:540,t:1527268470581};\\\", \\\"{x:497,y:538,t:1527268470690};\\\", \\\"{x:498,y:538,t:1527268470699};\\\", \\\"{x:500,y:537,t:1527268470723};\\\", \\\"{x:501,y:537,t:1527268470738};\\\", \\\"{x:501,y:536,t:1527268470747};\\\", \\\"{x:503,y:535,t:1527268470764};\\\", \\\"{x:507,y:533,t:1527268470781};\\\", \\\"{x:510,y:530,t:1527268470798};\\\", \\\"{x:512,y:528,t:1527268470813};\\\", \\\"{x:514,y:528,t:1527268470831};\\\", \\\"{x:514,y:527,t:1527268470848};\\\", \\\"{x:515,y:527,t:1527268471042};\\\", \\\"{x:517,y:527,t:1527268471074};\\\", \\\"{x:518,y:527,t:1527268471099};\\\", \\\"{x:520,y:527,t:1527268471115};\\\", \\\"{x:521,y:527,t:1527268471130};\\\", \\\"{x:523,y:527,t:1527268471147};\\\", \\\"{x:528,y:529,t:1527268471164};\\\", \\\"{x:534,y:537,t:1527268471180};\\\", \\\"{x:542,y:549,t:1527268471198};\\\", \\\"{x:550,y:565,t:1527268471215};\\\", \\\"{x:560,y:585,t:1527268471230};\\\", \\\"{x:569,y:604,t:1527268471248};\\\", \\\"{x:577,y:624,t:1527268471265};\\\", \\\"{x:582,y:643,t:1527268471282};\\\", \\\"{x:588,y:664,t:1527268471298};\\\", \\\"{x:602,y:694,t:1527268471314};\\\", \\\"{x:615,y:716,t:1527268471331};\\\", \\\"{x:628,y:735,t:1527268471347};\\\", \\\"{x:650,y:752,t:1527268471365};\\\", \\\"{x:676,y:766,t:1527268471380};\\\", \\\"{x:704,y:777,t:1527268471398};\\\", \\\"{x:729,y:785,t:1527268471415};\\\", \\\"{x:749,y:793,t:1527268471431};\\\", \\\"{x:765,y:799,t:1527268471447};\\\", \\\"{x:780,y:806,t:1527268471465};\\\", \\\"{x:794,y:814,t:1527268471481};\\\", \\\"{x:809,y:822,t:1527268471498};\\\", \\\"{x:832,y:830,t:1527268471515};\\\", \\\"{x:846,y:832,t:1527268471531};\\\", \\\"{x:862,y:835,t:1527268471547};\\\", \\\"{x:879,y:839,t:1527268471564};\\\", \\\"{x:897,y:844,t:1527268471581};\\\", \\\"{x:921,y:847,t:1527268471598};\\\", \\\"{x:979,y:843,t:1527268471615};\\\", \\\"{x:1083,y:820,t:1527268471630};\\\", \\\"{x:1211,y:782,t:1527268471648};\\\", \\\"{x:1349,y:746,t:1527268471664};\\\", \\\"{x:1483,y:716,t:1527268471681};\\\", \\\"{x:1594,y:697,t:1527268471697};\\\", \\\"{x:1698,y:695,t:1527268471714};\\\", \\\"{x:1724,y:698,t:1527268471730};\\\", \\\"{x:1742,y:704,t:1527268471748};\\\", \\\"{x:1751,y:713,t:1527268471765};\\\", \\\"{x:1753,y:722,t:1527268471780};\\\", \\\"{x:1753,y:738,t:1527268471798};\\\", \\\"{x:1751,y:759,t:1527268471813};\\\", \\\"{x:1741,y:779,t:1527268471831};\\\", \\\"{x:1731,y:797,t:1527268471848};\\\", \\\"{x:1727,y:801,t:1527268471864};\\\", \\\"{x:1728,y:802,t:1527268471930};\\\", \\\"{x:1737,y:805,t:1527268471948};\\\", \\\"{x:1741,y:806,t:1527268471963};\\\", \\\"{x:1744,y:805,t:1527268471981};\\\", \\\"{x:1744,y:804,t:1527268472010};\\\", \\\"{x:1739,y:802,t:1527268472018};\\\", \\\"{x:1724,y:802,t:1527268472030};\\\", \\\"{x:1673,y:802,t:1527268472048};\\\", \\\"{x:1644,y:806,t:1527268472063};\\\", \\\"{x:1615,y:816,t:1527268472080};\\\", \\\"{x:1593,y:829,t:1527268472096};\\\", \\\"{x:1574,y:841,t:1527268472114};\\\", \\\"{x:1570,y:844,t:1527268472130};\\\", \\\"{x:1570,y:845,t:1527268472148};\\\", \\\"{x:1570,y:846,t:1527268472171};\\\", \\\"{x:1574,y:847,t:1527268472181};\\\", \\\"{x:1577,y:848,t:1527268472197};\\\", \\\"{x:1579,y:846,t:1527268472214};\\\", \\\"{x:1579,y:831,t:1527268472231};\\\", \\\"{x:1579,y:812,t:1527268472247};\\\", \\\"{x:1579,y:791,t:1527268472264};\\\", \\\"{x:1585,y:768,t:1527268472281};\\\", \\\"{x:1591,y:740,t:1527268472297};\\\", \\\"{x:1599,y:709,t:1527268472314};\\\", \\\"{x:1602,y:674,t:1527268472331};\\\", \\\"{x:1602,y:658,t:1527268472347};\\\", \\\"{x:1596,y:648,t:1527268472364};\\\", \\\"{x:1590,y:642,t:1527268472381};\\\", \\\"{x:1584,y:636,t:1527268472397};\\\", \\\"{x:1579,y:633,t:1527268472415};\\\", \\\"{x:1578,y:633,t:1527268472431};\\\", \\\"{x:1576,y:634,t:1527268472563};\\\", \\\"{x:1554,y:657,t:1527268472579};\\\", \\\"{x:1523,y:687,t:1527268472597};\\\", \\\"{x:1483,y:716,t:1527268472614};\\\", \\\"{x:1457,y:732,t:1527268472630};\\\", \\\"{x:1442,y:744,t:1527268472647};\\\", \\\"{x:1428,y:751,t:1527268472664};\\\", \\\"{x:1419,y:754,t:1527268472680};\\\", \\\"{x:1413,y:759,t:1527268472696};\\\", \\\"{x:1410,y:761,t:1527268472714};\\\", \\\"{x:1405,y:764,t:1527268472730};\\\", \\\"{x:1398,y:771,t:1527268472746};\\\", \\\"{x:1391,y:775,t:1527268472763};\\\", \\\"{x:1378,y:779,t:1527268472779};\\\", \\\"{x:1359,y:783,t:1527268472797};\\\", \\\"{x:1338,y:783,t:1527268472814};\\\", \\\"{x:1313,y:783,t:1527268472829};\\\", \\\"{x:1288,y:783,t:1527268472847};\\\", \\\"{x:1265,y:781,t:1527268472864};\\\", \\\"{x:1248,y:776,t:1527268472880};\\\", \\\"{x:1235,y:770,t:1527268472897};\\\", \\\"{x:1228,y:763,t:1527268472914};\\\", \\\"{x:1227,y:757,t:1527268472930};\\\", \\\"{x:1224,y:740,t:1527268472946};\\\", \\\"{x:1218,y:727,t:1527268472963};\\\", \\\"{x:1214,y:716,t:1527268472980};\\\", \\\"{x:1213,y:711,t:1527268472996};\\\", \\\"{x:1213,y:708,t:1527268473012};\\\", \\\"{x:1213,y:707,t:1527268473030};\\\", \\\"{x:1217,y:702,t:1527268473047};\\\", \\\"{x:1226,y:695,t:1527268473063};\\\", \\\"{x:1245,y:688,t:1527268473080};\\\", \\\"{x:1263,y:684,t:1527268473097};\\\", \\\"{x:1288,y:681,t:1527268473113};\\\", \\\"{x:1303,y:679,t:1527268473130};\\\", \\\"{x:1316,y:678,t:1527268473146};\\\", \\\"{x:1326,y:678,t:1527268473163};\\\", \\\"{x:1333,y:678,t:1527268473179};\\\", \\\"{x:1337,y:678,t:1527268473196};\\\", \\\"{x:1341,y:678,t:1527268473213};\\\", \\\"{x:1342,y:678,t:1527268473230};\\\", \\\"{x:1343,y:678,t:1527268473274};\\\", \\\"{x:1343,y:679,t:1527268473290};\\\", \\\"{x:1343,y:680,t:1527268473306};\\\", \\\"{x:1343,y:682,t:1527268473314};\\\", \\\"{x:1343,y:684,t:1527268473330};\\\", \\\"{x:1343,y:691,t:1527268473346};\\\", \\\"{x:1344,y:693,t:1527268473363};\\\", \\\"{x:1344,y:695,t:1527268474554};\\\", \\\"{x:1345,y:696,t:1527268474858};\\\", \\\"{x:1346,y:696,t:1527268474874};\\\", \\\"{x:1347,y:696,t:1527268474923};\\\", \\\"{x:1347,y:697,t:1527268476586};\\\", \\\"{x:1347,y:698,t:1527268476594};\\\", \\\"{x:1348,y:699,t:1527268476610};\\\", \\\"{x:1348,y:701,t:1527268476627};\\\", \\\"{x:1349,y:703,t:1527268476644};\\\", \\\"{x:1349,y:704,t:1527268476660};\\\", \\\"{x:1349,y:706,t:1527268476676};\\\", \\\"{x:1349,y:708,t:1527268476694};\\\", \\\"{x:1349,y:709,t:1527268476710};\\\", \\\"{x:1350,y:709,t:1527268476727};\\\", \\\"{x:1350,y:711,t:1527268476743};\\\", \\\"{x:1350,y:712,t:1527268477338};\\\", \\\"{x:1349,y:712,t:1527268477354};\\\", \\\"{x:1348,y:710,t:1527268477378};\\\", \\\"{x:1347,y:709,t:1527268477393};\\\", \\\"{x:1345,y:705,t:1527268477410};\\\", \\\"{x:1344,y:705,t:1527268477426};\\\", \\\"{x:1344,y:704,t:1527268477443};\\\", \\\"{x:1344,y:703,t:1527268477618};\\\", \\\"{x:1344,y:702,t:1527268477626};\\\", \\\"{x:1344,y:701,t:1527268477642};\\\", \\\"{x:1344,y:700,t:1527268477659};\\\", \\\"{x:1344,y:699,t:1527268477675};\\\", \\\"{x:1344,y:698,t:1527268477698};\\\", \\\"{x:1344,y:697,t:1527268477708};\\\", \\\"{x:1344,y:696,t:1527268477730};\\\", \\\"{x:1343,y:696,t:1527268478410};\\\", \\\"{x:1340,y:696,t:1527268478425};\\\", \\\"{x:1330,y:700,t:1527268478442};\\\", \\\"{x:1325,y:704,t:1527268478458};\\\", \\\"{x:1324,y:704,t:1527268478474};\\\", \\\"{x:1323,y:705,t:1527268478492};\\\", \\\"{x:1322,y:706,t:1527268478514};\\\", \\\"{x:1322,y:707,t:1527268478554};\\\", \\\"{x:1324,y:707,t:1527268478730};\\\", \\\"{x:1327,y:707,t:1527268478742};\\\", \\\"{x:1331,y:705,t:1527268478759};\\\", \\\"{x:1337,y:703,t:1527268478775};\\\", \\\"{x:1338,y:702,t:1527268478792};\\\", \\\"{x:1340,y:702,t:1527268478810};\\\", \\\"{x:1341,y:701,t:1527268478826};\\\", \\\"{x:1341,y:700,t:1527268478859};\\\", \\\"{x:1342,y:699,t:1527268478875};\\\", \\\"{x:1342,y:698,t:1527268478892};\\\", \\\"{x:1343,y:696,t:1527268478908};\\\", \\\"{x:1345,y:693,t:1527268478925};\\\", \\\"{x:1345,y:692,t:1527268478941};\\\", \\\"{x:1346,y:690,t:1527268478958};\\\", \\\"{x:1347,y:687,t:1527268478975};\\\", \\\"{x:1348,y:686,t:1527268478992};\\\", \\\"{x:1348,y:685,t:1527268479010};\\\", \\\"{x:1349,y:684,t:1527268479042};\\\", \\\"{x:1349,y:685,t:1527268479306};\\\", \\\"{x:1349,y:686,t:1527268479314};\\\", \\\"{x:1349,y:687,t:1527268479325};\\\", \\\"{x:1348,y:688,t:1527268479340};\\\", \\\"{x:1347,y:690,t:1527268479358};\\\", \\\"{x:1347,y:691,t:1527268479402};\\\", \\\"{x:1347,y:692,t:1527268479419};\\\", \\\"{x:1347,y:693,t:1527268479441};\\\", \\\"{x:1347,y:694,t:1527268479458};\\\", \\\"{x:1347,y:697,t:1527268481298};\\\", \\\"{x:1347,y:704,t:1527268481306};\\\", \\\"{x:1345,y:710,t:1527268481323};\\\", \\\"{x:1344,y:717,t:1527268481339};\\\", \\\"{x:1343,y:724,t:1527268481355};\\\", \\\"{x:1343,y:731,t:1527268481373};\\\", \\\"{x:1341,y:733,t:1527268481390};\\\", \\\"{x:1341,y:737,t:1527268481406};\\\", \\\"{x:1341,y:740,t:1527268481423};\\\", \\\"{x:1341,y:743,t:1527268481439};\\\", \\\"{x:1341,y:748,t:1527268481456};\\\", \\\"{x:1341,y:751,t:1527268481473};\\\", \\\"{x:1341,y:758,t:1527268481490};\\\", \\\"{x:1343,y:764,t:1527268481506};\\\", \\\"{x:1346,y:770,t:1527268481523};\\\", \\\"{x:1348,y:776,t:1527268481539};\\\", \\\"{x:1349,y:778,t:1527268481556};\\\", \\\"{x:1349,y:782,t:1527268481573};\\\", \\\"{x:1349,y:785,t:1527268481589};\\\", \\\"{x:1349,y:790,t:1527268481606};\\\", \\\"{x:1349,y:796,t:1527268481622};\\\", \\\"{x:1349,y:802,t:1527268481639};\\\", \\\"{x:1349,y:807,t:1527268481656};\\\", \\\"{x:1349,y:813,t:1527268481673};\\\", \\\"{x:1349,y:819,t:1527268481689};\\\", \\\"{x:1350,y:827,t:1527268481706};\\\", \\\"{x:1350,y:830,t:1527268481722};\\\", \\\"{x:1351,y:833,t:1527268481739};\\\", \\\"{x:1351,y:836,t:1527268481756};\\\", \\\"{x:1351,y:839,t:1527268481773};\\\", \\\"{x:1351,y:842,t:1527268481789};\\\", \\\"{x:1351,y:847,t:1527268481806};\\\", \\\"{x:1351,y:851,t:1527268481823};\\\", \\\"{x:1351,y:856,t:1527268481839};\\\", \\\"{x:1351,y:863,t:1527268481856};\\\", \\\"{x:1351,y:870,t:1527268481872};\\\", \\\"{x:1351,y:878,t:1527268481889};\\\", \\\"{x:1351,y:889,t:1527268481906};\\\", \\\"{x:1351,y:899,t:1527268481922};\\\", \\\"{x:1351,y:907,t:1527268481939};\\\", \\\"{x:1353,y:918,t:1527268481956};\\\", \\\"{x:1353,y:926,t:1527268481972};\\\", \\\"{x:1354,y:933,t:1527268481989};\\\", \\\"{x:1354,y:941,t:1527268482006};\\\", \\\"{x:1356,y:945,t:1527268482022};\\\", \\\"{x:1356,y:948,t:1527268482039};\\\", \\\"{x:1356,y:952,t:1527268482056};\\\", \\\"{x:1354,y:956,t:1527268482072};\\\", \\\"{x:1354,y:958,t:1527268482088};\\\", \\\"{x:1353,y:962,t:1527268482106};\\\", \\\"{x:1353,y:963,t:1527268482171};\\\", \\\"{x:1353,y:965,t:1527268482187};\\\", \\\"{x:1352,y:965,t:1527268482194};\\\", \\\"{x:1352,y:966,t:1527268482210};\\\", \\\"{x:1352,y:967,t:1527268482227};\\\", \\\"{x:1352,y:968,t:1527268482243};\\\", \\\"{x:1351,y:968,t:1527268482258};\\\", \\\"{x:1351,y:967,t:1527268482386};\\\", \\\"{x:1351,y:961,t:1527268482394};\\\", \\\"{x:1349,y:955,t:1527268482405};\\\", \\\"{x:1348,y:940,t:1527268482422};\\\", \\\"{x:1348,y:918,t:1527268482439};\\\", \\\"{x:1348,y:894,t:1527268482455};\\\", \\\"{x:1348,y:867,t:1527268482472};\\\", \\\"{x:1347,y:845,t:1527268482489};\\\", \\\"{x:1344,y:828,t:1527268482505};\\\", \\\"{x:1342,y:806,t:1527268482522};\\\", \\\"{x:1341,y:796,t:1527268482538};\\\", \\\"{x:1341,y:784,t:1527268482555};\\\", \\\"{x:1341,y:777,t:1527268482572};\\\", \\\"{x:1341,y:770,t:1527268482588};\\\", \\\"{x:1341,y:765,t:1527268482605};\\\", \\\"{x:1341,y:759,t:1527268482622};\\\", \\\"{x:1341,y:753,t:1527268482638};\\\", \\\"{x:1341,y:747,t:1527268482655};\\\", \\\"{x:1341,y:743,t:1527268482673};\\\", \\\"{x:1341,y:738,t:1527268482688};\\\", \\\"{x:1341,y:735,t:1527268482705};\\\", \\\"{x:1341,y:730,t:1527268482722};\\\", \\\"{x:1342,y:726,t:1527268482738};\\\", \\\"{x:1342,y:724,t:1527268482755};\\\", \\\"{x:1343,y:720,t:1527268482772};\\\", \\\"{x:1343,y:719,t:1527268482788};\\\", \\\"{x:1343,y:717,t:1527268482805};\\\", \\\"{x:1344,y:716,t:1527268482822};\\\", \\\"{x:1344,y:714,t:1527268482839};\\\", \\\"{x:1345,y:713,t:1527268482855};\\\", \\\"{x:1346,y:712,t:1527268482874};\\\", \\\"{x:1346,y:711,t:1527268482907};\\\", \\\"{x:1347,y:710,t:1527268482922};\\\", \\\"{x:1348,y:710,t:1527268482939};\\\", \\\"{x:1349,y:708,t:1527268482955};\\\", \\\"{x:1350,y:707,t:1527268482971};\\\", \\\"{x:1352,y:704,t:1527268482988};\\\", \\\"{x:1352,y:701,t:1527268483005};\\\", \\\"{x:1353,y:698,t:1527268483021};\\\", \\\"{x:1353,y:696,t:1527268483039};\\\", \\\"{x:1353,y:693,t:1527268483056};\\\", \\\"{x:1353,y:691,t:1527268483071};\\\", \\\"{x:1353,y:689,t:1527268483088};\\\", \\\"{x:1355,y:689,t:1527268483539};\\\", \\\"{x:1357,y:689,t:1527268483554};\\\", \\\"{x:1361,y:689,t:1527268483571};\\\", \\\"{x:1363,y:690,t:1527268483588};\\\", \\\"{x:1365,y:690,t:1527268483604};\\\", \\\"{x:1365,y:691,t:1527268483626};\\\", \\\"{x:1365,y:692,t:1527268483786};\\\", \\\"{x:1365,y:693,t:1527268483818};\\\", \\\"{x:1365,y:694,t:1527268483867};\\\", \\\"{x:1364,y:694,t:1527268483890};\\\", \\\"{x:1363,y:694,t:1527268483914};\\\", \\\"{x:1361,y:694,t:1527268483938};\\\", \\\"{x:1359,y:695,t:1527268483954};\\\", \\\"{x:1359,y:696,t:1527268483972};\\\", \\\"{x:1355,y:696,t:1527268483987};\\\", \\\"{x:1352,y:697,t:1527268484004};\\\", \\\"{x:1348,y:698,t:1527268484021};\\\", \\\"{x:1346,y:699,t:1527268484037};\\\", \\\"{x:1344,y:700,t:1527268484054};\\\", \\\"{x:1342,y:701,t:1527268484072};\\\", \\\"{x:1340,y:701,t:1527268484090};\\\", \\\"{x:1339,y:701,t:1527268484106};\\\", \\\"{x:1339,y:702,t:1527268484121};\\\", \\\"{x:1338,y:702,t:1527268484137};\\\", \\\"{x:1337,y:703,t:1527268484170};\\\", \\\"{x:1336,y:703,t:1527268484210};\\\", \\\"{x:1335,y:704,t:1527268484234};\\\", \\\"{x:1335,y:705,t:1527268484258};\\\", \\\"{x:1337,y:708,t:1527268484270};\\\", \\\"{x:1350,y:715,t:1527268484287};\\\", \\\"{x:1366,y:724,t:1527268484304};\\\", \\\"{x:1396,y:739,t:1527268484320};\\\", \\\"{x:1428,y:762,t:1527268484337};\\\", \\\"{x:1460,y:786,t:1527268484354};\\\", \\\"{x:1478,y:802,t:1527268484370};\\\", \\\"{x:1501,y:821,t:1527268484387};\\\", \\\"{x:1529,y:852,t:1527268484404};\\\", \\\"{x:1555,y:882,t:1527268484420};\\\", \\\"{x:1567,y:898,t:1527268484437};\\\", \\\"{x:1575,y:909,t:1527268484454};\\\", \\\"{x:1580,y:916,t:1527268484470};\\\", \\\"{x:1582,y:918,t:1527268484487};\\\", \\\"{x:1583,y:918,t:1527268484504};\\\", \\\"{x:1585,y:918,t:1527268484520};\\\", \\\"{x:1586,y:919,t:1527268484536};\\\", \\\"{x:1591,y:923,t:1527268484554};\\\", \\\"{x:1604,y:925,t:1527268484570};\\\", \\\"{x:1611,y:925,t:1527268484587};\\\", \\\"{x:1613,y:925,t:1527268484603};\\\", \\\"{x:1614,y:925,t:1527268484620};\\\", \\\"{x:1620,y:932,t:1527268484637};\\\", \\\"{x:1631,y:943,t:1527268484653};\\\", \\\"{x:1635,y:947,t:1527268484670};\\\", \\\"{x:1635,y:948,t:1527268484794};\\\", \\\"{x:1635,y:951,t:1527268484803};\\\", \\\"{x:1635,y:956,t:1527268484820};\\\", \\\"{x:1634,y:958,t:1527268484837};\\\", \\\"{x:1634,y:959,t:1527268484866};\\\", \\\"{x:1634,y:960,t:1527268484882};\\\", \\\"{x:1634,y:961,t:1527268484890};\\\", \\\"{x:1632,y:963,t:1527268484903};\\\", \\\"{x:1630,y:965,t:1527268484921};\\\", \\\"{x:1627,y:968,t:1527268484937};\\\", \\\"{x:1626,y:969,t:1527268484953};\\\", \\\"{x:1624,y:969,t:1527268485018};\\\", \\\"{x:1621,y:969,t:1527268485026};\\\", \\\"{x:1615,y:969,t:1527268485036};\\\", \\\"{x:1596,y:960,t:1527268485053};\\\", \\\"{x:1555,y:941,t:1527268485070};\\\", \\\"{x:1490,y:918,t:1527268485086};\\\", \\\"{x:1399,y:879,t:1527268485103};\\\", \\\"{x:1304,y:828,t:1527268485120};\\\", \\\"{x:1220,y:781,t:1527268485137};\\\", \\\"{x:1163,y:748,t:1527268485153};\\\", \\\"{x:1140,y:732,t:1527268485170};\\\", \\\"{x:1140,y:728,t:1527268485186};\\\", \\\"{x:1140,y:717,t:1527268485203};\\\", \\\"{x:1147,y:702,t:1527268485221};\\\", \\\"{x:1156,y:687,t:1527268485236};\\\", \\\"{x:1170,y:673,t:1527268485253};\\\", \\\"{x:1183,y:660,t:1527268485271};\\\", \\\"{x:1198,y:649,t:1527268485286};\\\", \\\"{x:1212,y:641,t:1527268485304};\\\", \\\"{x:1226,y:633,t:1527268485320};\\\", \\\"{x:1244,y:623,t:1527268485336};\\\", \\\"{x:1254,y:617,t:1527268485353};\\\", \\\"{x:1262,y:615,t:1527268485369};\\\", \\\"{x:1269,y:615,t:1527268485386};\\\", \\\"{x:1280,y:618,t:1527268485403};\\\", \\\"{x:1304,y:639,t:1527268485419};\\\", \\\"{x:1325,y:664,t:1527268485436};\\\", \\\"{x:1346,y:688,t:1527268485453};\\\", \\\"{x:1359,y:706,t:1527268485469};\\\", \\\"{x:1370,y:722,t:1527268485486};\\\", \\\"{x:1379,y:741,t:1527268485503};\\\", \\\"{x:1389,y:756,t:1527268485519};\\\", \\\"{x:1397,y:765,t:1527268485536};\\\", \\\"{x:1403,y:766,t:1527268485553};\\\", \\\"{x:1404,y:768,t:1527268485569};\\\", \\\"{x:1407,y:768,t:1527268485602};\\\", \\\"{x:1425,y:777,t:1527268485619};\\\", \\\"{x:1450,y:786,t:1527268485636};\\\", \\\"{x:1476,y:798,t:1527268485653};\\\", \\\"{x:1507,y:815,t:1527268485669};\\\", \\\"{x:1540,y:834,t:1527268485686};\\\", \\\"{x:1565,y:848,t:1527268485702};\\\", \\\"{x:1576,y:855,t:1527268485719};\\\", \\\"{x:1582,y:860,t:1527268485736};\\\", \\\"{x:1587,y:865,t:1527268485752};\\\", \\\"{x:1591,y:870,t:1527268485770};\\\", \\\"{x:1600,y:883,t:1527268485786};\\\", \\\"{x:1605,y:890,t:1527268485803};\\\", \\\"{x:1610,y:897,t:1527268485819};\\\", \\\"{x:1615,y:901,t:1527268485837};\\\", \\\"{x:1619,y:902,t:1527268485853};\\\", \\\"{x:1622,y:904,t:1527268485869};\\\", \\\"{x:1622,y:906,t:1527268485898};\\\", \\\"{x:1624,y:907,t:1527268485906};\\\", \\\"{x:1625,y:911,t:1527268485919};\\\", \\\"{x:1627,y:924,t:1527268485936};\\\", \\\"{x:1630,y:940,t:1527268485952};\\\", \\\"{x:1632,y:958,t:1527268485970};\\\", \\\"{x:1639,y:985,t:1527268485986};\\\", \\\"{x:1642,y:995,t:1527268486002};\\\", \\\"{x:1645,y:1002,t:1527268486019};\\\", \\\"{x:1646,y:1005,t:1527268486035};\\\", \\\"{x:1647,y:1006,t:1527268486052};\\\", \\\"{x:1647,y:1007,t:1527268486074};\\\", \\\"{x:1647,y:1008,t:1527268486090};\\\", \\\"{x:1644,y:1006,t:1527268486154};\\\", \\\"{x:1641,y:1004,t:1527268486169};\\\", \\\"{x:1638,y:1002,t:1527268486185};\\\", \\\"{x:1636,y:998,t:1527268486202};\\\", \\\"{x:1633,y:995,t:1527268486219};\\\", \\\"{x:1630,y:991,t:1527268486236};\\\", \\\"{x:1626,y:986,t:1527268486252};\\\", \\\"{x:1624,y:985,t:1527268486282};\\\", \\\"{x:1623,y:983,t:1527268486290};\\\", \\\"{x:1622,y:983,t:1527268486339};\\\", \\\"{x:1622,y:980,t:1527268486354};\\\", \\\"{x:1619,y:979,t:1527268486369};\\\", \\\"{x:1608,y:965,t:1527268486386};\\\", \\\"{x:1588,y:952,t:1527268486402};\\\", \\\"{x:1591,y:952,t:1527268486522};\\\", \\\"{x:1592,y:952,t:1527268486535};\\\", \\\"{x:1594,y:952,t:1527268486552};\\\", \\\"{x:1595,y:952,t:1527268486568};\\\", \\\"{x:1597,y:952,t:1527268486585};\\\", \\\"{x:1598,y:952,t:1527268486714};\\\", \\\"{x:1599,y:953,t:1527268487058};\\\", \\\"{x:1596,y:954,t:1527268504094};\\\", \\\"{x:1586,y:954,t:1527268504107};\\\", \\\"{x:1560,y:953,t:1527268504124};\\\", \\\"{x:1536,y:946,t:1527268504141};\\\", \\\"{x:1521,y:938,t:1527268504157};\\\", \\\"{x:1511,y:930,t:1527268504175};\\\", \\\"{x:1510,y:929,t:1527268504192};\\\", \\\"{x:1509,y:928,t:1527268504230};\\\", \\\"{x:1499,y:925,t:1527268504242};\\\", \\\"{x:1449,y:920,t:1527268504258};\\\", \\\"{x:1358,y:897,t:1527268504275};\\\", \\\"{x:1279,y:869,t:1527268504292};\\\", \\\"{x:1219,y:855,t:1527268504308};\\\", \\\"{x:1164,y:849,t:1527268504325};\\\", \\\"{x:1138,y:848,t:1527268504340};\\\", \\\"{x:1127,y:847,t:1527268504358};\\\", \\\"{x:1126,y:847,t:1527268504375};\\\", \\\"{x:1121,y:846,t:1527268504405};\\\", \\\"{x:1112,y:846,t:1527268504413};\\\", \\\"{x:1100,y:846,t:1527268504425};\\\", \\\"{x:1056,y:839,t:1527268504441};\\\", \\\"{x:989,y:822,t:1527268504458};\\\", \\\"{x:898,y:794,t:1527268504475};\\\", \\\"{x:817,y:768,t:1527268504490};\\\", \\\"{x:742,y:750,t:1527268504508};\\\", \\\"{x:702,y:727,t:1527268504525};\\\", \\\"{x:688,y:718,t:1527268504540};\\\", \\\"{x:680,y:707,t:1527268504557};\\\", \\\"{x:673,y:694,t:1527268504574};\\\", \\\"{x:663,y:679,t:1527268504591};\\\", \\\"{x:653,y:661,t:1527268504607};\\\", \\\"{x:637,y:639,t:1527268504625};\\\", \\\"{x:620,y:619,t:1527268504641};\\\", \\\"{x:595,y:600,t:1527268504658};\\\", \\\"{x:587,y:594,t:1527268504675};\\\", \\\"{x:585,y:592,t:1527268504696};\\\", \\\"{x:585,y:590,t:1527268504749};\\\", \\\"{x:585,y:588,t:1527268504763};\\\", \\\"{x:582,y:581,t:1527268504780};\\\", \\\"{x:580,y:576,t:1527268504795};\\\", \\\"{x:580,y:575,t:1527268504854};\\\", \\\"{x:581,y:575,t:1527268504862};\\\", \\\"{x:586,y:575,t:1527268504879};\\\", \\\"{x:589,y:575,t:1527268504895};\\\", \\\"{x:591,y:575,t:1527268504913};\\\", \\\"{x:592,y:575,t:1527268504929};\\\", \\\"{x:594,y:575,t:1527268504949};\\\", \\\"{x:595,y:575,t:1527268504965};\\\", \\\"{x:598,y:575,t:1527268504979};\\\", \\\"{x:599,y:575,t:1527268504996};\\\", \\\"{x:602,y:575,t:1527268505013};\\\", \\\"{x:609,y:579,t:1527268505029};\\\", \\\"{x:611,y:579,t:1527268505221};\\\", \\\"{x:613,y:579,t:1527268505229};\\\", \\\"{x:616,y:579,t:1527268505246};\\\", \\\"{x:622,y:580,t:1527268505263};\\\", \\\"{x:647,y:586,t:1527268505280};\\\", \\\"{x:699,y:597,t:1527268505297};\\\", \\\"{x:783,y:616,t:1527268505314};\\\", \\\"{x:852,y:630,t:1527268505330};\\\", \\\"{x:947,y:652,t:1527268505347};\\\", \\\"{x:1066,y:686,t:1527268505364};\\\", \\\"{x:1172,y:718,t:1527268505380};\\\", \\\"{x:1272,y:752,t:1527268505397};\\\", \\\"{x:1369,y:795,t:1527268505413};\\\", \\\"{x:1503,y:856,t:1527268505430};\\\", \\\"{x:1572,y:899,t:1527268505447};\\\", \\\"{x:1638,y:941,t:1527268505463};\\\", \\\"{x:1695,y:983,t:1527268505479};\\\", \\\"{x:1765,y:1032,t:1527268505497};\\\", \\\"{x:1817,y:1066,t:1527268505513};\\\", \\\"{x:1835,y:1081,t:1527268505530};\\\", \\\"{x:1850,y:1093,t:1527268505546};\\\", \\\"{x:1868,y:1103,t:1527268505563};\\\", \\\"{x:1885,y:1110,t:1527268505579};\\\", \\\"{x:1904,y:1119,t:1527268505597};\\\", \\\"{x:1919,y:1132,t:1527268505613};\\\", \\\"{x:1919,y:1133,t:1527268505629};\\\", \\\"{x:1919,y:1132,t:1527268505677};\\\", \\\"{x:1913,y:1126,t:1527268505685};\\\", \\\"{x:1898,y:1116,t:1527268505696};\\\", \\\"{x:1848,y:1087,t:1527268505713};\\\", \\\"{x:1816,y:1075,t:1527268505730};\\\", \\\"{x:1802,y:1072,t:1527268505747};\\\", \\\"{x:1790,y:1068,t:1527268505764};\\\", \\\"{x:1780,y:1063,t:1527268505779};\\\", \\\"{x:1771,y:1057,t:1527268505797};\\\", \\\"{x:1763,y:1049,t:1527268505814};\\\", \\\"{x:1756,y:1035,t:1527268505830};\\\", \\\"{x:1740,y:1013,t:1527268505847};\\\", \\\"{x:1728,y:997,t:1527268505863};\\\", \\\"{x:1724,y:992,t:1527268505881};\\\", \\\"{x:1723,y:987,t:1527268505897};\\\", \\\"{x:1723,y:984,t:1527268505913};\\\", \\\"{x:1721,y:981,t:1527268505930};\\\", \\\"{x:1720,y:978,t:1527268505947};\\\", \\\"{x:1714,y:974,t:1527268505963};\\\", \\\"{x:1707,y:974,t:1527268505981};\\\", \\\"{x:1701,y:974,t:1527268505997};\\\", \\\"{x:1699,y:974,t:1527268506013};\\\", \\\"{x:1696,y:974,t:1527268506031};\\\", \\\"{x:1690,y:974,t:1527268506046};\\\", \\\"{x:1683,y:976,t:1527268506064};\\\", \\\"{x:1678,y:977,t:1527268506081};\\\", \\\"{x:1671,y:979,t:1527268506097};\\\", \\\"{x:1663,y:981,t:1527268506114};\\\", \\\"{x:1660,y:981,t:1527268506131};\\\", \\\"{x:1659,y:981,t:1527268506147};\\\", \\\"{x:1656,y:981,t:1527268506164};\\\", \\\"{x:1649,y:981,t:1527268506181};\\\", \\\"{x:1640,y:981,t:1527268506196};\\\", \\\"{x:1617,y:981,t:1527268506213};\\\", \\\"{x:1607,y:981,t:1527268506230};\\\", \\\"{x:1602,y:981,t:1527268506246};\\\", \\\"{x:1598,y:981,t:1527268506263};\\\", \\\"{x:1596,y:981,t:1527268506280};\\\", \\\"{x:1595,y:981,t:1527268506296};\\\", \\\"{x:1593,y:981,t:1527268506314};\\\", \\\"{x:1595,y:981,t:1527268506413};\\\", \\\"{x:1599,y:981,t:1527268506431};\\\", \\\"{x:1603,y:980,t:1527268506447};\\\", \\\"{x:1605,y:979,t:1527268506463};\\\", \\\"{x:1605,y:978,t:1527268506501};\\\", \\\"{x:1605,y:976,t:1527268506525};\\\", \\\"{x:1605,y:975,t:1527268506534};\\\", \\\"{x:1605,y:974,t:1527268506548};\\\", \\\"{x:1605,y:972,t:1527268506564};\\\", \\\"{x:1605,y:969,t:1527268506581};\\\", \\\"{x:1605,y:965,t:1527268506598};\\\", \\\"{x:1605,y:962,t:1527268506614};\\\", \\\"{x:1606,y:960,t:1527268506630};\\\", \\\"{x:1607,y:960,t:1527268506648};\\\", \\\"{x:1608,y:958,t:1527268506664};\\\", \\\"{x:1609,y:957,t:1527268506680};\\\", \\\"{x:1612,y:956,t:1527268506698};\\\", \\\"{x:1615,y:955,t:1527268506714};\\\", \\\"{x:1616,y:955,t:1527268506730};\\\", \\\"{x:1618,y:955,t:1527268506748};\\\", \\\"{x:1619,y:951,t:1527268515742};\\\", \\\"{x:1619,y:941,t:1527268515754};\\\", \\\"{x:1606,y:917,t:1527268515770};\\\", \\\"{x:1585,y:897,t:1527268515787};\\\", \\\"{x:1569,y:890,t:1527268515803};\\\", \\\"{x:1557,y:886,t:1527268515820};\\\", \\\"{x:1525,y:886,t:1527268515837};\\\", \\\"{x:1501,y:884,t:1527268515853};\\\", \\\"{x:1463,y:877,t:1527268515870};\\\", \\\"{x:1399,y:869,t:1527268515887};\\\", \\\"{x:1327,y:858,t:1527268515904};\\\", \\\"{x:1252,y:847,t:1527268515919};\\\", \\\"{x:1187,y:837,t:1527268515937};\\\", \\\"{x:1128,y:827,t:1527268515954};\\\", \\\"{x:1076,y:815,t:1527268515970};\\\", \\\"{x:1037,y:799,t:1527268515988};\\\", \\\"{x:1009,y:776,t:1527268516004};\\\", \\\"{x:990,y:753,t:1527268516020};\\\", \\\"{x:972,y:717,t:1527268516037};\\\", \\\"{x:962,y:698,t:1527268516053};\\\", \\\"{x:952,y:680,t:1527268516070};\\\", \\\"{x:944,y:664,t:1527268516087};\\\", \\\"{x:938,y:652,t:1527268516104};\\\", \\\"{x:935,y:643,t:1527268516120};\\\", \\\"{x:933,y:638,t:1527268516137};\\\", \\\"{x:931,y:633,t:1527268516154};\\\", \\\"{x:923,y:626,t:1527268516171};\\\", \\\"{x:901,y:619,t:1527268516187};\\\", \\\"{x:870,y:611,t:1527268516204};\\\", \\\"{x:825,y:597,t:1527268516219};\\\", \\\"{x:785,y:589,t:1527268516236};\\\", \\\"{x:735,y:580,t:1527268516255};\\\", \\\"{x:707,y:573,t:1527268516272};\\\", \\\"{x:681,y:567,t:1527268516289};\\\", \\\"{x:656,y:560,t:1527268516305};\\\", \\\"{x:636,y:557,t:1527268516322};\\\", \\\"{x:618,y:552,t:1527268516339};\\\", \\\"{x:603,y:550,t:1527268516355};\\\", \\\"{x:586,y:548,t:1527268516372};\\\", \\\"{x:553,y:548,t:1527268516389};\\\", \\\"{x:534,y:548,t:1527268516405};\\\", \\\"{x:521,y:548,t:1527268516422};\\\", \\\"{x:506,y:550,t:1527268516439};\\\", \\\"{x:493,y:552,t:1527268516456};\\\", \\\"{x:482,y:555,t:1527268516472};\\\", \\\"{x:473,y:556,t:1527268516490};\\\", \\\"{x:466,y:557,t:1527268516506};\\\", \\\"{x:458,y:560,t:1527268516522};\\\", \\\"{x:446,y:563,t:1527268516539};\\\", \\\"{x:433,y:567,t:1527268516556};\\\", \\\"{x:418,y:571,t:1527268516571};\\\", \\\"{x:399,y:575,t:1527268516589};\\\", \\\"{x:381,y:580,t:1527268516605};\\\", \\\"{x:373,y:581,t:1527268516622};\\\", \\\"{x:367,y:582,t:1527268516639};\\\", \\\"{x:358,y:582,t:1527268516656};\\\", \\\"{x:346,y:582,t:1527268516672};\\\", \\\"{x:332,y:582,t:1527268516688};\\\", \\\"{x:321,y:582,t:1527268516706};\\\", \\\"{x:312,y:582,t:1527268516722};\\\", \\\"{x:304,y:582,t:1527268516739};\\\", \\\"{x:295,y:580,t:1527268516756};\\\", \\\"{x:287,y:578,t:1527268516772};\\\", \\\"{x:273,y:575,t:1527268516789};\\\", \\\"{x:264,y:574,t:1527268516807};\\\", \\\"{x:255,y:572,t:1527268516821};\\\", \\\"{x:248,y:571,t:1527268516839};\\\", \\\"{x:238,y:571,t:1527268516856};\\\", \\\"{x:225,y:571,t:1527268516872};\\\", \\\"{x:209,y:571,t:1527268516889};\\\", \\\"{x:188,y:571,t:1527268516906};\\\", \\\"{x:170,y:573,t:1527268516922};\\\", \\\"{x:160,y:577,t:1527268516939};\\\", \\\"{x:152,y:579,t:1527268516956};\\\", \\\"{x:148,y:582,t:1527268516973};\\\", \\\"{x:145,y:584,t:1527268516989};\\\", \\\"{x:144,y:585,t:1527268517006};\\\", \\\"{x:144,y:587,t:1527268517023};\\\", \\\"{x:144,y:588,t:1527268517045};\\\", \\\"{x:144,y:589,t:1527268517093};\\\", \\\"{x:144,y:590,t:1527268517109};\\\", \\\"{x:145,y:591,t:1527268517405};\\\", \\\"{x:153,y:591,t:1527268517413};\\\", \\\"{x:160,y:591,t:1527268517423};\\\", \\\"{x:173,y:591,t:1527268517440};\\\", \\\"{x:185,y:591,t:1527268517457};\\\", \\\"{x:193,y:591,t:1527268517473};\\\", \\\"{x:202,y:591,t:1527268517490};\\\", \\\"{x:210,y:591,t:1527268517507};\\\", \\\"{x:224,y:591,t:1527268517523};\\\", \\\"{x:247,y:591,t:1527268517540};\\\", \\\"{x:295,y:591,t:1527268517558};\\\", \\\"{x:348,y:591,t:1527268517573};\\\", \\\"{x:414,y:591,t:1527268517590};\\\", \\\"{x:495,y:591,t:1527268517607};\\\", \\\"{x:585,y:595,t:1527268517624};\\\", \\\"{x:685,y:610,t:1527268517640};\\\", \\\"{x:788,y:628,t:1527268517657};\\\", \\\"{x:882,y:640,t:1527268517674};\\\", \\\"{x:961,y:652,t:1527268517690};\\\", \\\"{x:1037,y:667,t:1527268517707};\\\", \\\"{x:1101,y:677,t:1527268517723};\\\", \\\"{x:1175,y:693,t:1527268517740};\\\", \\\"{x:1245,y:709,t:1527268517757};\\\", \\\"{x:1281,y:718,t:1527268517773};\\\", \\\"{x:1312,y:727,t:1527268517790};\\\", \\\"{x:1329,y:733,t:1527268517808};\\\", \\\"{x:1345,y:737,t:1527268517823};\\\", \\\"{x:1350,y:739,t:1527268517841};\\\", \\\"{x:1358,y:742,t:1527268517857};\\\", \\\"{x:1367,y:748,t:1527268517873};\\\", \\\"{x:1374,y:752,t:1527268517890};\\\", \\\"{x:1380,y:756,t:1527268517907};\\\", \\\"{x:1384,y:757,t:1527268517924};\\\", \\\"{x:1388,y:760,t:1527268517940};\\\", \\\"{x:1395,y:760,t:1527268517958};\\\", \\\"{x:1398,y:760,t:1527268517973};\\\", \\\"{x:1403,y:760,t:1527268517990};\\\", \\\"{x:1409,y:759,t:1527268518007};\\\", \\\"{x:1416,y:754,t:1527268518024};\\\", \\\"{x:1423,y:745,t:1527268518040};\\\", \\\"{x:1426,y:732,t:1527268518058};\\\", \\\"{x:1428,y:721,t:1527268518074};\\\", \\\"{x:1429,y:712,t:1527268518090};\\\", \\\"{x:1429,y:705,t:1527268518107};\\\", \\\"{x:1429,y:704,t:1527268518124};\\\", \\\"{x:1429,y:703,t:1527268518142};\\\", \\\"{x:1428,y:703,t:1527268518158};\\\", \\\"{x:1422,y:703,t:1527268518173};\\\", \\\"{x:1416,y:703,t:1527268518191};\\\", \\\"{x:1409,y:703,t:1527268518208};\\\", \\\"{x:1403,y:703,t:1527268518224};\\\", \\\"{x:1395,y:704,t:1527268518242};\\\", \\\"{x:1389,y:705,t:1527268518257};\\\", \\\"{x:1373,y:706,t:1527268518275};\\\", \\\"{x:1348,y:706,t:1527268518291};\\\", \\\"{x:1304,y:706,t:1527268518307};\\\", \\\"{x:1247,y:702,t:1527268518324};\\\", \\\"{x:1131,y:673,t:1527268518341};\\\", \\\"{x:1041,y:652,t:1527268518357};\\\", \\\"{x:955,y:627,t:1527268518374};\\\", \\\"{x:895,y:606,t:1527268518391};\\\", \\\"{x:871,y:595,t:1527268518408};\\\", \\\"{x:864,y:590,t:1527268518422};\\\", \\\"{x:864,y:588,t:1527268518439};\\\", \\\"{x:864,y:585,t:1527268518457};\\\", \\\"{x:864,y:581,t:1527268518474};\\\", \\\"{x:864,y:573,t:1527268518489};\\\", \\\"{x:866,y:567,t:1527268518507};\\\", \\\"{x:870,y:557,t:1527268518524};\\\", \\\"{x:878,y:544,t:1527268518541};\\\", \\\"{x:886,y:531,t:1527268518557};\\\", \\\"{x:894,y:524,t:1527268518574};\\\", \\\"{x:898,y:518,t:1527268518590};\\\", \\\"{x:900,y:514,t:1527268518608};\\\", \\\"{x:901,y:510,t:1527268518624};\\\", \\\"{x:901,y:508,t:1527268518641};\\\", \\\"{x:901,y:507,t:1527268518657};\\\", \\\"{x:900,y:505,t:1527268518674};\\\", \\\"{x:894,y:503,t:1527268518691};\\\", \\\"{x:883,y:499,t:1527268518707};\\\", \\\"{x:872,y:497,t:1527268518724};\\\", \\\"{x:858,y:494,t:1527268518741};\\\", \\\"{x:856,y:494,t:1527268518757};\\\", \\\"{x:855,y:494,t:1527268518774};\\\", \\\"{x:855,y:495,t:1527268518950};\\\", \\\"{x:855,y:496,t:1527268518958};\\\", \\\"{x:857,y:497,t:1527268518974};\\\", \\\"{x:858,y:497,t:1527268518991};\\\", \\\"{x:859,y:498,t:1527268519029};\\\", \\\"{x:861,y:498,t:1527268519085};\\\", \\\"{x:862,y:498,t:1527268519109};\\\", \\\"{x:863,y:500,t:1527268519125};\\\", \\\"{x:868,y:502,t:1527268519141};\\\", \\\"{x:873,y:506,t:1527268519158};\\\", \\\"{x:883,y:511,t:1527268519174};\\\", \\\"{x:893,y:518,t:1527268519192};\\\", \\\"{x:907,y:525,t:1527268519208};\\\", \\\"{x:923,y:535,t:1527268519224};\\\", \\\"{x:938,y:545,t:1527268519241};\\\", \\\"{x:956,y:557,t:1527268519259};\\\", \\\"{x:975,y:570,t:1527268519274};\\\", \\\"{x:1000,y:587,t:1527268519291};\\\", \\\"{x:1035,y:615,t:1527268519308};\\\", \\\"{x:1069,y:647,t:1527268519324};\\\", \\\"{x:1133,y:714,t:1527268519340};\\\", \\\"{x:1176,y:754,t:1527268519359};\\\", \\\"{x:1211,y:789,t:1527268519375};\\\", \\\"{x:1247,y:822,t:1527268519391};\\\", \\\"{x:1280,y:849,t:1527268519408};\\\", \\\"{x:1300,y:874,t:1527268519424};\\\", \\\"{x:1326,y:898,t:1527268519441};\\\", \\\"{x:1352,y:919,t:1527268519458};\\\", \\\"{x:1375,y:935,t:1527268519475};\\\", \\\"{x:1390,y:946,t:1527268519492};\\\", \\\"{x:1398,y:948,t:1527268519509};\\\", \\\"{x:1404,y:950,t:1527268519525};\\\", \\\"{x:1408,y:950,t:1527268519541};\\\", \\\"{x:1414,y:954,t:1527268519559};\\\", \\\"{x:1418,y:955,t:1527268519575};\\\", \\\"{x:1424,y:955,t:1527268519591};\\\", \\\"{x:1435,y:957,t:1527268519608};\\\", \\\"{x:1447,y:958,t:1527268519624};\\\", \\\"{x:1458,y:959,t:1527268519641};\\\", \\\"{x:1468,y:959,t:1527268519658};\\\", \\\"{x:1479,y:959,t:1527268519675};\\\", \\\"{x:1485,y:959,t:1527268519691};\\\", \\\"{x:1488,y:959,t:1527268519708};\\\", \\\"{x:1489,y:959,t:1527268519726};\\\", \\\"{x:1491,y:959,t:1527268519797};\\\", \\\"{x:1493,y:959,t:1527268519837};\\\", \\\"{x:1494,y:958,t:1527268519845};\\\", \\\"{x:1495,y:957,t:1527268519861};\\\", \\\"{x:1497,y:957,t:1527268519875};\\\", \\\"{x:1500,y:955,t:1527268519892};\\\", \\\"{x:1503,y:953,t:1527268519908};\\\", \\\"{x:1506,y:952,t:1527268519926};\\\", \\\"{x:1509,y:951,t:1527268519941};\\\", \\\"{x:1511,y:951,t:1527268519965};\\\", \\\"{x:1512,y:951,t:1527268520005};\\\", \\\"{x:1514,y:951,t:1527268520021};\\\", \\\"{x:1516,y:951,t:1527268520038};\\\", \\\"{x:1518,y:953,t:1527268520045};\\\", \\\"{x:1524,y:959,t:1527268520058};\\\", \\\"{x:1534,y:972,t:1527268520075};\\\", \\\"{x:1547,y:983,t:1527268520092};\\\", \\\"{x:1555,y:990,t:1527268520109};\\\", \\\"{x:1559,y:993,t:1527268520125};\\\", \\\"{x:1561,y:993,t:1527268520229};\\\", \\\"{x:1562,y:993,t:1527268520245};\\\", \\\"{x:1564,y:993,t:1527268520269};\\\", \\\"{x:1566,y:992,t:1527268520278};\\\", \\\"{x:1568,y:990,t:1527268520293};\\\", \\\"{x:1569,y:989,t:1527268520308};\\\", \\\"{x:1571,y:985,t:1527268520325};\\\", \\\"{x:1572,y:982,t:1527268520343};\\\", \\\"{x:1573,y:979,t:1527268520359};\\\", \\\"{x:1574,y:978,t:1527268520375};\\\", \\\"{x:1575,y:975,t:1527268520392};\\\", \\\"{x:1576,y:972,t:1527268520409};\\\", \\\"{x:1580,y:968,t:1527268520426};\\\", \\\"{x:1582,y:967,t:1527268520443};\\\", \\\"{x:1586,y:963,t:1527268520459};\\\", \\\"{x:1589,y:959,t:1527268520475};\\\", \\\"{x:1591,y:956,t:1527268520492};\\\", \\\"{x:1594,y:953,t:1527268520509};\\\", \\\"{x:1596,y:952,t:1527268520525};\\\", \\\"{x:1597,y:950,t:1527268520542};\\\", \\\"{x:1598,y:950,t:1527268520560};\\\", \\\"{x:1599,y:950,t:1527268520575};\\\", \\\"{x:1601,y:949,t:1527268520605};\\\", \\\"{x:1602,y:949,t:1527268520654};\\\", \\\"{x:1604,y:949,t:1527268520669};\\\", \\\"{x:1605,y:949,t:1527268520677};\\\", \\\"{x:1608,y:949,t:1527268520692};\\\", \\\"{x:1618,y:959,t:1527268520709};\\\", \\\"{x:1618,y:960,t:1527268520725};\\\", \\\"{x:1618,y:961,t:1527268520750};\\\", \\\"{x:1618,y:962,t:1527268520789};\\\", \\\"{x:1617,y:963,t:1527268526917};\\\", \\\"{x:1589,y:957,t:1527268526930};\\\", \\\"{x:1436,y:876,t:1527268526947};\\\", \\\"{x:1169,y:754,t:1527268526964};\\\", \\\"{x:841,y:618,t:1527268526980};\\\", \\\"{x:406,y:491,t:1527268526998};\\\", \\\"{x:261,y:480,t:1527268527015};\\\", \\\"{x:228,y:480,t:1527268527030};\\\", \\\"{x:226,y:480,t:1527268527047};\\\", \\\"{x:226,y:482,t:1527268527093};\\\", \\\"{x:226,y:486,t:1527268527101};\\\", \\\"{x:226,y:493,t:1527268527115};\\\", \\\"{x:227,y:503,t:1527268527130};\\\", \\\"{x:228,y:513,t:1527268527148};\\\", \\\"{x:231,y:530,t:1527268527166};\\\", \\\"{x:249,y:581,t:1527268527181};\\\", \\\"{x:273,y:632,t:1527268527198};\\\", \\\"{x:297,y:680,t:1527268527214};\\\", \\\"{x:334,y:728,t:1527268527231};\\\", \\\"{x:386,y:774,t:1527268527247};\\\", \\\"{x:454,y:822,t:1527268527265};\\\", \\\"{x:522,y:861,t:1527268527281};\\\", \\\"{x:583,y:893,t:1527268527297};\\\", \\\"{x:629,y:906,t:1527268527314};\\\", \\\"{x:649,y:910,t:1527268527331};\\\", \\\"{x:655,y:910,t:1527268527348};\\\", \\\"{x:656,y:911,t:1527268527372};\\\", \\\"{x:656,y:909,t:1527268527421};\\\", \\\"{x:657,y:908,t:1527268527431};\\\", \\\"{x:658,y:904,t:1527268527447};\\\", \\\"{x:659,y:903,t:1527268527469};\\\", \\\"{x:659,y:902,t:1527268527485};\\\", \\\"{x:659,y:901,t:1527268527498};\\\", \\\"{x:660,y:899,t:1527268527515};\\\", \\\"{x:661,y:898,t:1527268527531};\\\", \\\"{x:661,y:894,t:1527268527548};\\\", \\\"{x:661,y:892,t:1527268527564};\\\", \\\"{x:661,y:888,t:1527268527582};\\\", \\\"{x:659,y:883,t:1527268527597};\\\", \\\"{x:655,y:878,t:1527268527615};\\\", \\\"{x:648,y:873,t:1527268527631};\\\", \\\"{x:636,y:866,t:1527268527647};\\\", \\\"{x:620,y:858,t:1527268527664};\\\", \\\"{x:603,y:849,t:1527268527681};\\\", \\\"{x:585,y:843,t:1527268527698};\\\", \\\"{x:566,y:838,t:1527268527714};\\\", \\\"{x:554,y:833,t:1527268527731};\\\", \\\"{x:550,y:833,t:1527268527747};\\\", \\\"{x:547,y:831,t:1527268527765};\\\", \\\"{x:547,y:830,t:1527268528366};\\\", \\\"{x:548,y:830,t:1527268528397};\\\", \\\"{x:549,y:829,t:1527268528421};\\\", \\\"{x:550,y:829,t:1527268528445};\\\", \\\"{x:551,y:829,t:1527268528605};\\\", \\\"{x:550,y:826,t:1527268528615};\\\", \\\"{x:547,y:824,t:1527268528631};\\\", \\\"{x:545,y:822,t:1527268528648};\\\", \\\"{x:544,y:822,t:1527268528664};\\\", \\\"{x:544,y:821,t:1527268528709};\\\", \\\"{x:544,y:820,t:1527268528725};\\\", \\\"{x:543,y:819,t:1527268528733};\\\", \\\"{x:543,y:818,t:1527268528748};\\\", \\\"{x:542,y:817,t:1527268528765};\\\", \\\"{x:540,y:814,t:1527268528782};\\\", \\\"{x:539,y:811,t:1527268528798};\\\", \\\"{x:537,y:809,t:1527268528814};\\\", \\\"{x:534,y:806,t:1527268528831};\\\", \\\"{x:527,y:795,t:1527268528849};\\\", \\\"{x:518,y:786,t:1527268528864};\\\", \\\"{x:511,y:780,t:1527268528881};\\\", \\\"{x:504,y:775,t:1527268528898};\\\", \\\"{x:503,y:774,t:1527268528973};\\\", \\\"{x:503,y:773,t:1527268528989};\\\", \\\"{x:503,y:771,t:1527268528999};\\\", \\\"{x:501,y:765,t:1527268529015};\\\", \\\"{x:501,y:761,t:1527268529031};\\\", \\\"{x:501,y:757,t:1527268529049};\\\", \\\"{x:501,y:756,t:1527268529064};\\\", \\\"{x:501,y:753,t:1527268529081};\\\", \\\"{x:501,y:751,t:1527268529098};\\\", \\\"{x:501,y:750,t:1527268529116};\\\", \\\"{x:501,y:748,t:1527268529132};\\\", \\\"{x:501,y:747,t:1527268529157};\\\", \\\"{x:497,y:755,t:1527268530445};\\\", \\\"{x:494,y:761,t:1527268530453};\\\", \\\"{x:490,y:766,t:1527268530467};\\\", \\\"{x:482,y:776,t:1527268530484};\\\", \\\"{x:476,y:784,t:1527268530500};\\\", \\\"{x:464,y:807,t:1527268530549};\\\", \\\"{x:462,y:815,t:1527268530574};\\\", \\\"{x:460,y:818,t:1527268530583};\\\", \\\"{x:458,y:824,t:1527268530600};\\\", \\\"{x:455,y:830,t:1527268530618};\\\", \\\"{x:455,y:833,t:1527268530634};\\\", \\\"{x:454,y:834,t:1527268530650};\\\", \\\"{x:453,y:836,t:1527268530668};\\\", \\\"{x:452,y:837,t:1527268530683};\\\", \\\"{x:451,y:838,t:1527268530701};\\\" ] }, { \\\"rt\\\": 16305, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 590903, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -F -F -12 PM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:452,y:840,t:1527268532221};\\\", \\\"{x:454,y:846,t:1527268532235};\\\", \\\"{x:463,y:858,t:1527268532251};\\\", \\\"{x:479,y:872,t:1527268532269};\\\", \\\"{x:496,y:891,t:1527268532284};\\\", \\\"{x:506,y:903,t:1527268532302};\\\", \\\"{x:510,y:909,t:1527268532319};\\\", \\\"{x:514,y:915,t:1527268532335};\\\", \\\"{x:522,y:922,t:1527268532351};\\\", \\\"{x:531,y:930,t:1527268532368};\\\", \\\"{x:543,y:941,t:1527268532386};\\\", \\\"{x:559,y:953,t:1527268532401};\\\", \\\"{x:582,y:969,t:1527268532419};\\\", \\\"{x:602,y:985,t:1527268532436};\\\", \\\"{x:642,y:1008,t:1527268532451};\\\", \\\"{x:685,y:1033,t:1527268532469};\\\", \\\"{x:755,y:1068,t:1527268532485};\\\", \\\"{x:804,y:1087,t:1527268532501};\\\", \\\"{x:856,y:1101,t:1527268532519};\\\", \\\"{x:920,y:1118,t:1527268532536};\\\", \\\"{x:1000,y:1137,t:1527268532552};\\\", \\\"{x:1075,y:1149,t:1527268532569};\\\", \\\"{x:1139,y:1158,t:1527268532585};\\\", \\\"{x:1184,y:1164,t:1527268532602};\\\", \\\"{x:1222,y:1165,t:1527268532619};\\\", \\\"{x:1244,y:1165,t:1527268532635};\\\", \\\"{x:1254,y:1165,t:1527268532651};\\\", \\\"{x:1266,y:1161,t:1527268532669};\\\", \\\"{x:1271,y:1158,t:1527268532685};\\\", \\\"{x:1280,y:1150,t:1527268532702};\\\", \\\"{x:1293,y:1138,t:1527268532719};\\\", \\\"{x:1312,y:1126,t:1527268532736};\\\", \\\"{x:1328,y:1115,t:1527268532753};\\\", \\\"{x:1348,y:1106,t:1527268532768};\\\", \\\"{x:1362,y:1099,t:1527268532786};\\\", \\\"{x:1378,y:1089,t:1527268532802};\\\", \\\"{x:1388,y:1083,t:1527268532818};\\\", \\\"{x:1393,y:1077,t:1527268532836};\\\", \\\"{x:1401,y:1068,t:1527268532853};\\\", \\\"{x:1406,y:1064,t:1527268532868};\\\", \\\"{x:1411,y:1060,t:1527268532885};\\\", \\\"{x:1416,y:1055,t:1527268532902};\\\", \\\"{x:1421,y:1050,t:1527268532918};\\\", \\\"{x:1424,y:1045,t:1527268532936};\\\", \\\"{x:1426,y:1040,t:1527268532952};\\\", \\\"{x:1427,y:1038,t:1527268532968};\\\", \\\"{x:1427,y:1035,t:1527268532985};\\\", \\\"{x:1427,y:1032,t:1527268533003};\\\", \\\"{x:1426,y:1029,t:1527268533018};\\\", \\\"{x:1422,y:1025,t:1527268533036};\\\", \\\"{x:1412,y:1022,t:1527268533053};\\\", \\\"{x:1405,y:1018,t:1527268533069};\\\", \\\"{x:1392,y:1014,t:1527268533085};\\\", \\\"{x:1381,y:1009,t:1527268533103};\\\", \\\"{x:1361,y:1001,t:1527268533119};\\\", \\\"{x:1345,y:994,t:1527268533135};\\\", \\\"{x:1329,y:985,t:1527268533153};\\\", \\\"{x:1318,y:978,t:1527268533168};\\\", \\\"{x:1315,y:976,t:1527268533185};\\\", \\\"{x:1315,y:975,t:1527268533253};\\\", \\\"{x:1314,y:969,t:1527268533269};\\\", \\\"{x:1314,y:967,t:1527268533286};\\\", \\\"{x:1314,y:966,t:1527268533302};\\\", \\\"{x:1314,y:965,t:1527268533319};\\\", \\\"{x:1315,y:963,t:1527268533335};\\\", \\\"{x:1318,y:963,t:1527268533353};\\\", \\\"{x:1323,y:963,t:1527268533369};\\\", \\\"{x:1325,y:964,t:1527268533386};\\\", \\\"{x:1326,y:964,t:1527268533429};\\\", \\\"{x:1329,y:964,t:1527268533469};\\\", \\\"{x:1335,y:964,t:1527268533486};\\\", \\\"{x:1339,y:964,t:1527268533503};\\\", \\\"{x:1340,y:965,t:1527268533520};\\\", \\\"{x:1341,y:965,t:1527268534125};\\\", \\\"{x:1343,y:962,t:1527268534137};\\\", \\\"{x:1343,y:958,t:1527268534154};\\\", \\\"{x:1343,y:952,t:1527268534170};\\\", \\\"{x:1343,y:945,t:1527268534186};\\\", \\\"{x:1343,y:939,t:1527268534203};\\\", \\\"{x:1343,y:933,t:1527268534220};\\\", \\\"{x:1343,y:926,t:1527268534237};\\\", \\\"{x:1343,y:921,t:1527268534253};\\\", \\\"{x:1343,y:915,t:1527268534270};\\\", \\\"{x:1343,y:910,t:1527268534287};\\\", \\\"{x:1343,y:905,t:1527268534303};\\\", \\\"{x:1343,y:901,t:1527268534320};\\\", \\\"{x:1343,y:898,t:1527268534336};\\\", \\\"{x:1342,y:895,t:1527268534353};\\\", \\\"{x:1342,y:892,t:1527268534369};\\\", \\\"{x:1340,y:889,t:1527268534387};\\\", \\\"{x:1340,y:888,t:1527268534403};\\\", \\\"{x:1340,y:886,t:1527268534419};\\\", \\\"{x:1339,y:883,t:1527268534437};\\\", \\\"{x:1339,y:882,t:1527268534453};\\\", \\\"{x:1339,y:881,t:1527268534470};\\\", \\\"{x:1339,y:880,t:1527268534487};\\\", \\\"{x:1339,y:879,t:1527268534504};\\\", \\\"{x:1339,y:877,t:1527268534520};\\\", \\\"{x:1339,y:876,t:1527268534557};\\\", \\\"{x:1339,y:874,t:1527268534571};\\\", \\\"{x:1339,y:873,t:1527268534586};\\\", \\\"{x:1339,y:871,t:1527268534604};\\\", \\\"{x:1339,y:870,t:1527268534620};\\\", \\\"{x:1339,y:868,t:1527268534637};\\\", \\\"{x:1339,y:866,t:1527268534654};\\\", \\\"{x:1339,y:865,t:1527268534671};\\\", \\\"{x:1339,y:864,t:1527268534687};\\\", \\\"{x:1339,y:862,t:1527268534703};\\\", \\\"{x:1339,y:861,t:1527268534721};\\\", \\\"{x:1339,y:859,t:1527268534737};\\\", \\\"{x:1339,y:858,t:1527268534753};\\\", \\\"{x:1339,y:856,t:1527268534770};\\\", \\\"{x:1339,y:855,t:1527268534797};\\\", \\\"{x:1339,y:854,t:1527268534909};\\\", \\\"{x:1339,y:853,t:1527268534920};\\\", \\\"{x:1339,y:852,t:1527268534941};\\\", \\\"{x:1339,y:851,t:1527268534953};\\\", \\\"{x:1339,y:850,t:1527268534970};\\\", \\\"{x:1339,y:849,t:1527268534987};\\\", \\\"{x:1339,y:846,t:1527268535003};\\\", \\\"{x:1340,y:841,t:1527268535021};\\\", \\\"{x:1342,y:834,t:1527268535037};\\\", \\\"{x:1343,y:831,t:1527268535054};\\\", \\\"{x:1344,y:829,t:1527268535071};\\\", \\\"{x:1345,y:825,t:1527268535088};\\\", \\\"{x:1345,y:824,t:1527268535104};\\\", \\\"{x:1345,y:823,t:1527268535121};\\\", \\\"{x:1346,y:822,t:1527268535138};\\\", \\\"{x:1346,y:821,t:1527268535157};\\\", \\\"{x:1347,y:821,t:1527268535197};\\\", \\\"{x:1347,y:819,t:1527268535221};\\\", \\\"{x:1347,y:818,t:1527268535429};\\\", \\\"{x:1347,y:817,t:1527268535438};\\\", \\\"{x:1347,y:815,t:1527268535453};\\\", \\\"{x:1347,y:813,t:1527268535471};\\\", \\\"{x:1347,y:811,t:1527268535488};\\\", \\\"{x:1348,y:806,t:1527268535505};\\\", \\\"{x:1348,y:801,t:1527268535521};\\\", \\\"{x:1348,y:794,t:1527268535538};\\\", \\\"{x:1348,y:784,t:1527268535554};\\\", \\\"{x:1348,y:780,t:1527268535571};\\\", \\\"{x:1349,y:776,t:1527268535588};\\\", \\\"{x:1349,y:771,t:1527268535605};\\\", \\\"{x:1349,y:770,t:1527268535621};\\\", \\\"{x:1349,y:768,t:1527268535645};\\\", \\\"{x:1349,y:767,t:1527268535677};\\\", \\\"{x:1349,y:765,t:1527268535717};\\\", \\\"{x:1349,y:764,t:1527268535828};\\\", \\\"{x:1349,y:762,t:1527268535933};\\\", \\\"{x:1347,y:760,t:1527268536125};\\\", \\\"{x:1345,y:760,t:1527268536141};\\\", \\\"{x:1344,y:760,t:1527268536155};\\\", \\\"{x:1343,y:759,t:1527268537023};\\\", \\\"{x:1343,y:755,t:1527268537040};\\\", \\\"{x:1343,y:751,t:1527268537056};\\\", \\\"{x:1344,y:749,t:1527268537073};\\\", \\\"{x:1344,y:748,t:1527268537090};\\\", \\\"{x:1344,y:747,t:1527268537109};\\\", \\\"{x:1344,y:746,t:1527268537134};\\\", \\\"{x:1344,y:745,t:1527268537174};\\\", \\\"{x:1344,y:744,t:1527268537277};\\\", \\\"{x:1344,y:742,t:1527268537289};\\\", \\\"{x:1344,y:741,t:1527268537309};\\\", \\\"{x:1345,y:739,t:1527268537322};\\\", \\\"{x:1345,y:738,t:1527268537339};\\\", \\\"{x:1345,y:735,t:1527268537356};\\\", \\\"{x:1345,y:733,t:1527268537372};\\\", \\\"{x:1345,y:728,t:1527268537389};\\\", \\\"{x:1345,y:726,t:1527268537406};\\\", \\\"{x:1345,y:725,t:1527268537422};\\\", \\\"{x:1347,y:722,t:1527268537438};\\\", \\\"{x:1347,y:721,t:1527268537525};\\\", \\\"{x:1347,y:720,t:1527268537557};\\\", \\\"{x:1347,y:719,t:1527268537581};\\\", \\\"{x:1347,y:718,t:1527268537605};\\\", \\\"{x:1347,y:717,t:1527268537623};\\\", \\\"{x:1347,y:715,t:1527268537639};\\\", \\\"{x:1347,y:714,t:1527268537670};\\\", \\\"{x:1347,y:713,t:1527268537686};\\\", \\\"{x:1347,y:712,t:1527268537735};\\\", \\\"{x:1348,y:710,t:1527268537751};\\\", \\\"{x:1348,y:708,t:1527268537974};\\\", \\\"{x:1348,y:707,t:1527268537998};\\\", \\\"{x:1348,y:705,t:1527268538022};\\\", \\\"{x:1348,y:704,t:1527268538054};\\\", \\\"{x:1348,y:702,t:1527268538102};\\\", \\\"{x:1347,y:702,t:1527268538318};\\\", \\\"{x:1338,y:702,t:1527268538327};\\\", \\\"{x:1324,y:702,t:1527268538341};\\\", \\\"{x:1291,y:702,t:1527268538356};\\\", \\\"{x:1209,y:700,t:1527268538374};\\\", \\\"{x:1140,y:691,t:1527268538390};\\\", \\\"{x:1079,y:683,t:1527268538407};\\\", \\\"{x:1029,y:669,t:1527268538423};\\\", \\\"{x:990,y:659,t:1527268538440};\\\", \\\"{x:962,y:652,t:1527268538457};\\\", \\\"{x:937,y:643,t:1527268538473};\\\", \\\"{x:909,y:638,t:1527268538489};\\\", \\\"{x:879,y:631,t:1527268538507};\\\", \\\"{x:854,y:626,t:1527268538523};\\\", \\\"{x:815,y:618,t:1527268538541};\\\", \\\"{x:794,y:612,t:1527268538557};\\\", \\\"{x:768,y:608,t:1527268538574};\\\", \\\"{x:743,y:603,t:1527268538591};\\\", \\\"{x:717,y:601,t:1527268538607};\\\", \\\"{x:691,y:596,t:1527268538624};\\\", \\\"{x:663,y:593,t:1527268538641};\\\", \\\"{x:638,y:590,t:1527268538657};\\\", \\\"{x:612,y:585,t:1527268538675};\\\", \\\"{x:586,y:582,t:1527268538691};\\\", \\\"{x:567,y:578,t:1527268538707};\\\", \\\"{x:547,y:575,t:1527268538724};\\\", \\\"{x:517,y:570,t:1527268538741};\\\", \\\"{x:499,y:568,t:1527268538757};\\\", \\\"{x:480,y:563,t:1527268538775};\\\", \\\"{x:464,y:560,t:1527268538792};\\\", \\\"{x:448,y:557,t:1527268538807};\\\", \\\"{x:436,y:553,t:1527268538824};\\\", \\\"{x:429,y:552,t:1527268538841};\\\", \\\"{x:422,y:551,t:1527268538857};\\\", \\\"{x:412,y:549,t:1527268538874};\\\", \\\"{x:394,y:546,t:1527268538891};\\\", \\\"{x:375,y:543,t:1527268538908};\\\", \\\"{x:347,y:539,t:1527268538924};\\\", \\\"{x:300,y:532,t:1527268538941};\\\", \\\"{x:265,y:527,t:1527268538959};\\\", \\\"{x:237,y:524,t:1527268538975};\\\", \\\"{x:212,y:519,t:1527268538991};\\\", \\\"{x:198,y:518,t:1527268539008};\\\", \\\"{x:192,y:516,t:1527268539025};\\\", \\\"{x:191,y:516,t:1527268539040};\\\", \\\"{x:190,y:516,t:1527268539061};\\\", \\\"{x:188,y:516,t:1527268539077};\\\", \\\"{x:185,y:516,t:1527268539093};\\\", \\\"{x:182,y:516,t:1527268539108};\\\", \\\"{x:175,y:516,t:1527268539124};\\\", \\\"{x:166,y:516,t:1527268539141};\\\", \\\"{x:161,y:516,t:1527268539158};\\\", \\\"{x:160,y:516,t:1527268539174};\\\", \\\"{x:159,y:517,t:1527268539191};\\\", \\\"{x:158,y:519,t:1527268539210};\\\", \\\"{x:158,y:520,t:1527268539245};\\\", \\\"{x:157,y:521,t:1527268539258};\\\", \\\"{x:157,y:522,t:1527268539274};\\\", \\\"{x:156,y:525,t:1527268539291};\\\", \\\"{x:154,y:528,t:1527268539308};\\\", \\\"{x:154,y:532,t:1527268539325};\\\", \\\"{x:153,y:533,t:1527268539341};\\\", \\\"{x:153,y:535,t:1527268539358};\\\", \\\"{x:153,y:536,t:1527268539375};\\\", \\\"{x:153,y:537,t:1527268539582};\\\", \\\"{x:153,y:538,t:1527268539614};\\\", \\\"{x:153,y:539,t:1527268539654};\\\", \\\"{x:152,y:539,t:1527268539670};\\\", \\\"{x:160,y:539,t:1527268540077};\\\", \\\"{x:170,y:539,t:1527268540092};\\\", \\\"{x:192,y:536,t:1527268540108};\\\", \\\"{x:217,y:533,t:1527268540125};\\\", \\\"{x:234,y:530,t:1527268540141};\\\", \\\"{x:249,y:529,t:1527268540158};\\\", \\\"{x:270,y:527,t:1527268540175};\\\", \\\"{x:292,y:527,t:1527268540192};\\\", \\\"{x:314,y:526,t:1527268540209};\\\", \\\"{x:341,y:526,t:1527268540225};\\\", \\\"{x:371,y:526,t:1527268540242};\\\", \\\"{x:399,y:526,t:1527268540259};\\\", \\\"{x:431,y:526,t:1527268540275};\\\", \\\"{x:464,y:526,t:1527268540292};\\\", \\\"{x:510,y:526,t:1527268540310};\\\", \\\"{x:527,y:526,t:1527268540325};\\\", \\\"{x:536,y:526,t:1527268540342};\\\", \\\"{x:542,y:526,t:1527268540359};\\\", \\\"{x:546,y:526,t:1527268540375};\\\", \\\"{x:551,y:526,t:1527268540392};\\\", \\\"{x:557,y:526,t:1527268540409};\\\", \\\"{x:563,y:526,t:1527268540426};\\\", \\\"{x:569,y:526,t:1527268540442};\\\", \\\"{x:577,y:526,t:1527268540460};\\\", \\\"{x:590,y:528,t:1527268540475};\\\", \\\"{x:610,y:531,t:1527268540493};\\\", \\\"{x:641,y:535,t:1527268540510};\\\", \\\"{x:660,y:538,t:1527268540526};\\\", \\\"{x:675,y:538,t:1527268540542};\\\", \\\"{x:688,y:538,t:1527268540559};\\\", \\\"{x:704,y:538,t:1527268540575};\\\", \\\"{x:719,y:538,t:1527268540592};\\\", \\\"{x:742,y:538,t:1527268540610};\\\", \\\"{x:765,y:538,t:1527268540626};\\\", \\\"{x:787,y:538,t:1527268540642};\\\", \\\"{x:802,y:538,t:1527268540659};\\\", \\\"{x:810,y:538,t:1527268540676};\\\", \\\"{x:816,y:538,t:1527268540692};\\\", \\\"{x:820,y:538,t:1527268540709};\\\", \\\"{x:822,y:538,t:1527268540726};\\\", \\\"{x:823,y:538,t:1527268540744};\\\", \\\"{x:825,y:538,t:1527268540766};\\\", \\\"{x:828,y:536,t:1527268540776};\\\", \\\"{x:829,y:536,t:1527268540792};\\\", \\\"{x:831,y:535,t:1527268540809};\\\", \\\"{x:831,y:534,t:1527268540826};\\\", \\\"{x:832,y:534,t:1527268540845};\\\", \\\"{x:833,y:532,t:1527268540861};\\\", \\\"{x:834,y:531,t:1527268540876};\\\", \\\"{x:836,y:528,t:1527268540893};\\\", \\\"{x:838,y:522,t:1527268540910};\\\", \\\"{x:839,y:520,t:1527268540926};\\\", \\\"{x:840,y:517,t:1527268540944};\\\", \\\"{x:841,y:516,t:1527268540959};\\\", \\\"{x:841,y:515,t:1527268540976};\\\", \\\"{x:841,y:514,t:1527268540993};\\\", \\\"{x:841,y:513,t:1527268541009};\\\", \\\"{x:841,y:512,t:1527268541037};\\\", \\\"{x:841,y:511,t:1527268541060};\\\", \\\"{x:841,y:510,t:1527268541076};\\\", \\\"{x:840,y:507,t:1527268541093};\\\", \\\"{x:840,y:506,t:1527268541133};\\\", \\\"{x:839,y:506,t:1527268541157};\\\", \\\"{x:839,y:505,t:1527268541173};\\\", \\\"{x:838,y:505,t:1527268541198};\\\", \\\"{x:838,y:504,t:1527268541214};\\\", \\\"{x:837,y:504,t:1527268541246};\\\", \\\"{x:836,y:504,t:1527268541261};\\\", \\\"{x:835,y:504,t:1527268541276};\\\", \\\"{x:833,y:502,t:1527268541293};\\\", \\\"{x:830,y:501,t:1527268541310};\\\", \\\"{x:828,y:500,t:1527268541328};\\\", \\\"{x:825,y:499,t:1527268541344};\\\", \\\"{x:821,y:498,t:1527268541361};\\\", \\\"{x:818,y:498,t:1527268541376};\\\", \\\"{x:817,y:497,t:1527268541394};\\\", \\\"{x:816,y:497,t:1527268541734};\\\", \\\"{x:814,y:497,t:1527268541743};\\\", \\\"{x:811,y:496,t:1527268541761};\\\", \\\"{x:809,y:496,t:1527268541777};\\\", \\\"{x:808,y:496,t:1527268541838};\\\", \\\"{x:807,y:496,t:1527268541846};\\\", \\\"{x:806,y:496,t:1527268541860};\\\", \\\"{x:803,y:501,t:1527268541878};\\\", \\\"{x:801,y:503,t:1527268541893};\\\", \\\"{x:800,y:504,t:1527268541910};\\\", \\\"{x:799,y:506,t:1527268541927};\\\", \\\"{x:798,y:509,t:1527268541943};\\\", \\\"{x:797,y:513,t:1527268541961};\\\", \\\"{x:797,y:521,t:1527268541978};\\\", \\\"{x:797,y:534,t:1527268541994};\\\", \\\"{x:797,y:545,t:1527268542010};\\\", \\\"{x:799,y:556,t:1527268542027};\\\", \\\"{x:802,y:567,t:1527268542043};\\\", \\\"{x:807,y:577,t:1527268542060};\\\", \\\"{x:813,y:587,t:1527268542076};\\\", \\\"{x:818,y:594,t:1527268542094};\\\", \\\"{x:826,y:605,t:1527268542110};\\\", \\\"{x:839,y:619,t:1527268542127};\\\", \\\"{x:859,y:633,t:1527268542143};\\\", \\\"{x:878,y:647,t:1527268542160};\\\", \\\"{x:901,y:659,t:1527268542177};\\\", \\\"{x:930,y:671,t:1527268542194};\\\", \\\"{x:959,y:679,t:1527268542210};\\\", \\\"{x:987,y:685,t:1527268542228};\\\", \\\"{x:1016,y:691,t:1527268542243};\\\", \\\"{x:1048,y:695,t:1527268542261};\\\", \\\"{x:1082,y:702,t:1527268542277};\\\", \\\"{x:1096,y:703,t:1527268542295};\\\", \\\"{x:1098,y:704,t:1527268542310};\\\", \\\"{x:1100,y:704,t:1527268542357};\\\", \\\"{x:1106,y:707,t:1527268542365};\\\", \\\"{x:1115,y:712,t:1527268542377};\\\", \\\"{x:1146,y:723,t:1527268542394};\\\", \\\"{x:1189,y:738,t:1527268542411};\\\", \\\"{x:1247,y:752,t:1527268542427};\\\", \\\"{x:1302,y:766,t:1527268542444};\\\", \\\"{x:1344,y:771,t:1527268542461};\\\", \\\"{x:1352,y:771,t:1527268542478};\\\", \\\"{x:1354,y:771,t:1527268542494};\\\", \\\"{x:1355,y:771,t:1527268542512};\\\", \\\"{x:1355,y:770,t:1527268542528};\\\", \\\"{x:1356,y:767,t:1527268542544};\\\", \\\"{x:1357,y:760,t:1527268542562};\\\", \\\"{x:1357,y:754,t:1527268542578};\\\", \\\"{x:1357,y:745,t:1527268542594};\\\", \\\"{x:1356,y:736,t:1527268542611};\\\", \\\"{x:1355,y:732,t:1527268542628};\\\", \\\"{x:1352,y:727,t:1527268542645};\\\", \\\"{x:1348,y:718,t:1527268542661};\\\", \\\"{x:1344,y:711,t:1527268542678};\\\", \\\"{x:1338,y:702,t:1527268542695};\\\", \\\"{x:1334,y:698,t:1527268542712};\\\", \\\"{x:1333,y:695,t:1527268542729};\\\", \\\"{x:1331,y:693,t:1527268542745};\\\", \\\"{x:1330,y:690,t:1527268542762};\\\", \\\"{x:1330,y:689,t:1527268542782};\\\", \\\"{x:1329,y:687,t:1527268542814};\\\", \\\"{x:1331,y:687,t:1527268542894};\\\", \\\"{x:1338,y:687,t:1527268542912};\\\", \\\"{x:1344,y:687,t:1527268542929};\\\", \\\"{x:1346,y:687,t:1527268542945};\\\", \\\"{x:1347,y:687,t:1527268542961};\\\", \\\"{x:1348,y:688,t:1527268543206};\\\", \\\"{x:1348,y:689,t:1527268543222};\\\", \\\"{x:1347,y:692,t:1527268543230};\\\", \\\"{x:1346,y:695,t:1527268543245};\\\", \\\"{x:1345,y:701,t:1527268543262};\\\", \\\"{x:1343,y:706,t:1527268543279};\\\", \\\"{x:1342,y:713,t:1527268543296};\\\", \\\"{x:1342,y:718,t:1527268543312};\\\", \\\"{x:1341,y:723,t:1527268543328};\\\", \\\"{x:1341,y:729,t:1527268543346};\\\", \\\"{x:1341,y:733,t:1527268543363};\\\", \\\"{x:1341,y:738,t:1527268543378};\\\", \\\"{x:1339,y:741,t:1527268543396};\\\", \\\"{x:1339,y:744,t:1527268543413};\\\", \\\"{x:1339,y:747,t:1527268543429};\\\", \\\"{x:1338,y:755,t:1527268543445};\\\", \\\"{x:1337,y:759,t:1527268543462};\\\", \\\"{x:1337,y:764,t:1527268543479};\\\", \\\"{x:1337,y:766,t:1527268543496};\\\", \\\"{x:1337,y:768,t:1527268543513};\\\", \\\"{x:1337,y:769,t:1527268543541};\\\", \\\"{x:1337,y:771,t:1527268543573};\\\", \\\"{x:1337,y:772,t:1527268543589};\\\", \\\"{x:1337,y:774,t:1527268543604};\\\", \\\"{x:1337,y:775,t:1527268543629};\\\", \\\"{x:1337,y:777,t:1527268543645};\\\", \\\"{x:1337,y:778,t:1527268543677};\\\", \\\"{x:1337,y:780,t:1527268543694};\\\", \\\"{x:1337,y:781,t:1527268543709};\\\", \\\"{x:1337,y:783,t:1527268543733};\\\", \\\"{x:1337,y:784,t:1527268543750};\\\", \\\"{x:1337,y:785,t:1527268543763};\\\", \\\"{x:1337,y:787,t:1527268543780};\\\", \\\"{x:1338,y:788,t:1527268543795};\\\", \\\"{x:1340,y:790,t:1527268543813};\\\", \\\"{x:1341,y:792,t:1527268543829};\\\", \\\"{x:1342,y:796,t:1527268543846};\\\", \\\"{x:1343,y:798,t:1527268543863};\\\", \\\"{x:1345,y:802,t:1527268543880};\\\", \\\"{x:1346,y:804,t:1527268543896};\\\", \\\"{x:1347,y:807,t:1527268543912};\\\", \\\"{x:1348,y:809,t:1527268543929};\\\", \\\"{x:1350,y:813,t:1527268543947};\\\", \\\"{x:1350,y:814,t:1527268543963};\\\", \\\"{x:1352,y:816,t:1527268543980};\\\", \\\"{x:1352,y:817,t:1527268543996};\\\", \\\"{x:1353,y:818,t:1527268544013};\\\", \\\"{x:1353,y:819,t:1527268544030};\\\", \\\"{x:1353,y:820,t:1527268544142};\\\", \\\"{x:1353,y:821,t:1527268544150};\\\", \\\"{x:1353,y:822,t:1527268544163};\\\", \\\"{x:1353,y:824,t:1527268544179};\\\", \\\"{x:1353,y:826,t:1527268544197};\\\", \\\"{x:1353,y:830,t:1527268544213};\\\", \\\"{x:1353,y:835,t:1527268544230};\\\", \\\"{x:1353,y:839,t:1527268544247};\\\", \\\"{x:1354,y:843,t:1527268544264};\\\", \\\"{x:1355,y:846,t:1527268544280};\\\", \\\"{x:1355,y:848,t:1527268544297};\\\", \\\"{x:1356,y:853,t:1527268544314};\\\", \\\"{x:1356,y:857,t:1527268544330};\\\", \\\"{x:1356,y:862,t:1527268544347};\\\", \\\"{x:1356,y:870,t:1527268544364};\\\", \\\"{x:1357,y:876,t:1527268544379};\\\", \\\"{x:1357,y:880,t:1527268544397};\\\", \\\"{x:1357,y:887,t:1527268544414};\\\", \\\"{x:1357,y:890,t:1527268544430};\\\", \\\"{x:1357,y:894,t:1527268544447};\\\", \\\"{x:1357,y:897,t:1527268544464};\\\", \\\"{x:1357,y:901,t:1527268544479};\\\", \\\"{x:1357,y:903,t:1527268544497};\\\", \\\"{x:1357,y:906,t:1527268544513};\\\", \\\"{x:1359,y:910,t:1527268544530};\\\", \\\"{x:1359,y:912,t:1527268544547};\\\", \\\"{x:1359,y:916,t:1527268544564};\\\", \\\"{x:1360,y:921,t:1527268544581};\\\", \\\"{x:1360,y:932,t:1527268544597};\\\", \\\"{x:1358,y:953,t:1527268544614};\\\", \\\"{x:1356,y:966,t:1527268544630};\\\", \\\"{x:1353,y:972,t:1527268544647};\\\", \\\"{x:1350,y:984,t:1527268544664};\\\", \\\"{x:1348,y:994,t:1527268544681};\\\", \\\"{x:1343,y:1006,t:1527268544697};\\\", \\\"{x:1340,y:1013,t:1527268544714};\\\", \\\"{x:1338,y:1017,t:1527268544731};\\\", \\\"{x:1335,y:1022,t:1527268544747};\\\", \\\"{x:1331,y:1026,t:1527268544764};\\\", \\\"{x:1325,y:1027,t:1527268544781};\\\", \\\"{x:1315,y:1027,t:1527268544797};\\\", \\\"{x:1285,y:1023,t:1527268544813};\\\", \\\"{x:1262,y:1016,t:1527268544831};\\\", \\\"{x:1243,y:1012,t:1527268544848};\\\", \\\"{x:1222,y:1007,t:1527268544864};\\\", \\\"{x:1206,y:1001,t:1527268544880};\\\", \\\"{x:1190,y:997,t:1527268544898};\\\", \\\"{x:1178,y:993,t:1527268544914};\\\", \\\"{x:1162,y:987,t:1527268544931};\\\", \\\"{x:1144,y:983,t:1527268544948};\\\", \\\"{x:1123,y:975,t:1527268544965};\\\", \\\"{x:1099,y:967,t:1527268544981};\\\", \\\"{x:1041,y:944,t:1527268544997};\\\", \\\"{x:991,y:921,t:1527268545014};\\\", \\\"{x:931,y:897,t:1527268545031};\\\", \\\"{x:870,y:869,t:1527268545047};\\\", \\\"{x:796,y:842,t:1527268545064};\\\", \\\"{x:741,y:817,t:1527268545080};\\\", \\\"{x:690,y:794,t:1527268545097};\\\", \\\"{x:632,y:776,t:1527268545114};\\\", \\\"{x:586,y:761,t:1527268545131};\\\", \\\"{x:559,y:751,t:1527268545149};\\\", \\\"{x:537,y:744,t:1527268545164};\\\", \\\"{x:519,y:739,t:1527268545180};\\\", \\\"{x:507,y:734,t:1527268545195};\\\", \\\"{x:497,y:731,t:1527268545212};\\\", \\\"{x:479,y:725,t:1527268545229};\\\", \\\"{x:469,y:721,t:1527268545246};\\\", \\\"{x:459,y:716,t:1527268545263};\\\", \\\"{x:450,y:713,t:1527268545279};\\\", \\\"{x:441,y:709,t:1527268545296};\\\", \\\"{x:434,y:706,t:1527268545313};\\\", \\\"{x:432,y:706,t:1527268545329};\\\", \\\"{x:430,y:705,t:1527268545346};\\\", \\\"{x:429,y:705,t:1527268545363};\\\", \\\"{x:426,y:704,t:1527268545379};\\\", \\\"{x:424,y:704,t:1527268545398};\\\", \\\"{x:423,y:704,t:1527268545455};\\\", \\\"{x:421,y:704,t:1527268545566};\\\", \\\"{x:420,y:705,t:1527268545598};\\\", \\\"{x:420,y:706,t:1527268545613};\\\", \\\"{x:420,y:707,t:1527268545629};\\\", \\\"{x:420,y:708,t:1527268545662};\\\", \\\"{x:421,y:709,t:1527268545670};\\\", \\\"{x:423,y:709,t:1527268545680};\\\", \\\"{x:435,y:709,t:1527268545697};\\\", \\\"{x:461,y:709,t:1527268545714};\\\", \\\"{x:513,y:699,t:1527268545731};\\\", \\\"{x:600,y:672,t:1527268545747};\\\", \\\"{x:696,y:634,t:1527268545764};\\\", \\\"{x:781,y:595,t:1527268545781};\\\", \\\"{x:834,y:561,t:1527268545796};\\\", \\\"{x:868,y:534,t:1527268545815};\\\", \\\"{x:875,y:524,t:1527268545830};\\\", \\\"{x:875,y:522,t:1527268545847};\\\", \\\"{x:877,y:520,t:1527268545863};\\\", \\\"{x:877,y:519,t:1527268545880};\\\", \\\"{x:878,y:517,t:1527268545898};\\\", \\\"{x:882,y:513,t:1527268545913};\\\", \\\"{x:886,y:509,t:1527268545930};\\\", \\\"{x:888,y:504,t:1527268545946};\\\", \\\"{x:889,y:500,t:1527268545963};\\\", \\\"{x:889,y:499,t:1527268546021};\\\", \\\"{x:886,y:499,t:1527268546030};\\\", \\\"{x:873,y:499,t:1527268546047};\\\", \\\"{x:859,y:501,t:1527268546064};\\\", \\\"{x:846,y:505,t:1527268546081};\\\", \\\"{x:840,y:506,t:1527268546097};\\\", \\\"{x:838,y:506,t:1527268546114};\\\", \\\"{x:837,y:507,t:1527268546389};\\\", \\\"{x:831,y:507,t:1527268546397};\\\", \\\"{x:806,y:512,t:1527268546414};\\\", \\\"{x:767,y:519,t:1527268546431};\\\", \\\"{x:717,y:526,t:1527268546448};\\\", \\\"{x:667,y:532,t:1527268546464};\\\", \\\"{x:636,y:541,t:1527268546480};\\\", \\\"{x:607,y:550,t:1527268546497};\\\", \\\"{x:594,y:556,t:1527268546515};\\\", \\\"{x:574,y:569,t:1527268546530};\\\", \\\"{x:552,y:586,t:1527268546547};\\\", \\\"{x:530,y:605,t:1527268546564};\\\", \\\"{x:509,y:622,t:1527268546580};\\\", \\\"{x:486,y:645,t:1527268546597};\\\", \\\"{x:473,y:662,t:1527268546614};\\\", \\\"{x:464,y:673,t:1527268546630};\\\", \\\"{x:458,y:684,t:1527268546647};\\\", \\\"{x:453,y:697,t:1527268546664};\\\", \\\"{x:450,y:707,t:1527268546681};\\\", \\\"{x:448,y:716,t:1527268546697};\\\", \\\"{x:448,y:722,t:1527268546715};\\\", \\\"{x:448,y:728,t:1527268546732};\\\", \\\"{x:448,y:732,t:1527268546747};\\\", \\\"{x:448,y:733,t:1527268546773};\\\", \\\"{x:448,y:734,t:1527268546788};\\\", \\\"{x:448,y:735,t:1527268546797};\\\", \\\"{x:452,y:740,t:1527268546814};\\\", \\\"{x:459,y:744,t:1527268546831};\\\", \\\"{x:467,y:748,t:1527268546847};\\\", \\\"{x:475,y:752,t:1527268546864};\\\", \\\"{x:480,y:753,t:1527268546882};\\\", \\\"{x:483,y:754,t:1527268546897};\\\", \\\"{x:484,y:754,t:1527268546914};\\\", \\\"{x:485,y:754,t:1527268546941};\\\", \\\"{x:486,y:753,t:1527268547005};\\\", \\\"{x:487,y:752,t:1527268547045};\\\", \\\"{x:488,y:749,t:1527268547077};\\\", \\\"{x:489,y:748,t:1527268547086};\\\", \\\"{x:490,y:747,t:1527268547098};\\\", \\\"{x:491,y:742,t:1527268547115};\\\", \\\"{x:494,y:737,t:1527268547132};\\\", \\\"{x:495,y:731,t:1527268547150};\\\", \\\"{x:497,y:729,t:1527268547165};\\\" ] }, { \\\"rt\\\": 16414, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 608517, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:729,t:1527268550974};\\\", \\\"{x:498,y:728,t:1527268550989};\\\", \\\"{x:500,y:727,t:1527268551742};\\\", \\\"{x:504,y:727,t:1527268551757};\\\", \\\"{x:508,y:727,t:1527268551774};\\\", \\\"{x:511,y:727,t:1527268551791};\\\", \\\"{x:512,y:727,t:1527268551807};\\\", \\\"{x:513,y:727,t:1527268551823};\\\", \\\"{x:514,y:727,t:1527268551878};\\\", \\\"{x:515,y:727,t:1527268551894};\\\", \\\"{x:516,y:727,t:1527268551908};\\\", \\\"{x:517,y:727,t:1527268551925};\\\", \\\"{x:518,y:727,t:1527268551941};\\\", \\\"{x:519,y:727,t:1527268551958};\\\", \\\"{x:522,y:727,t:1527268551975};\\\", \\\"{x:524,y:727,t:1527268551992};\\\", \\\"{x:527,y:727,t:1527268552008};\\\", \\\"{x:530,y:727,t:1527268552025};\\\", \\\"{x:530,y:728,t:1527268552042};\\\", \\\"{x:532,y:728,t:1527268552058};\\\", \\\"{x:534,y:729,t:1527268552075};\\\", \\\"{x:535,y:729,t:1527268552092};\\\", \\\"{x:537,y:731,t:1527268552108};\\\", \\\"{x:539,y:731,t:1527268552125};\\\", \\\"{x:541,y:733,t:1527268552142};\\\", \\\"{x:542,y:733,t:1527268552173};\\\", \\\"{x:543,y:733,t:1527268552181};\\\", \\\"{x:544,y:734,t:1527268552192};\\\", \\\"{x:548,y:736,t:1527268552209};\\\", \\\"{x:554,y:740,t:1527268552226};\\\", \\\"{x:563,y:743,t:1527268552242};\\\", \\\"{x:572,y:746,t:1527268552261};\\\", \\\"{x:579,y:747,t:1527268552276};\\\", \\\"{x:587,y:750,t:1527268552291};\\\", \\\"{x:598,y:754,t:1527268552316};\\\", \\\"{x:604,y:755,t:1527268552333};\\\", \\\"{x:610,y:757,t:1527268552349};\\\", \\\"{x:616,y:760,t:1527268552367};\\\", \\\"{x:621,y:763,t:1527268552383};\\\", \\\"{x:629,y:767,t:1527268552399};\\\", \\\"{x:639,y:771,t:1527268552417};\\\", \\\"{x:653,y:777,t:1527268552432};\\\", \\\"{x:671,y:786,t:1527268552450};\\\", \\\"{x:684,y:792,t:1527268552467};\\\", \\\"{x:697,y:798,t:1527268552482};\\\", \\\"{x:704,y:802,t:1527268552500};\\\", \\\"{x:709,y:803,t:1527268552516};\\\", \\\"{x:713,y:805,t:1527268552533};\\\", \\\"{x:716,y:806,t:1527268552549};\\\", \\\"{x:721,y:808,t:1527268552567};\\\", \\\"{x:729,y:811,t:1527268552583};\\\", \\\"{x:735,y:814,t:1527268552600};\\\", \\\"{x:745,y:819,t:1527268552616};\\\", \\\"{x:755,y:822,t:1527268552633};\\\", \\\"{x:768,y:825,t:1527268552650};\\\", \\\"{x:779,y:830,t:1527268552667};\\\", \\\"{x:785,y:831,t:1527268552683};\\\", \\\"{x:790,y:833,t:1527268552700};\\\", \\\"{x:794,y:834,t:1527268552717};\\\", \\\"{x:799,y:835,t:1527268552733};\\\", \\\"{x:802,y:836,t:1527268552749};\\\", \\\"{x:804,y:836,t:1527268552767};\\\", \\\"{x:805,y:836,t:1527268552783};\\\", \\\"{x:805,y:837,t:1527268552799};\\\", \\\"{x:807,y:837,t:1527268552829};\\\", \\\"{x:808,y:837,t:1527268552861};\\\", \\\"{x:808,y:838,t:1527268552870};\\\", \\\"{x:810,y:839,t:1527268552883};\\\", \\\"{x:811,y:840,t:1527268552900};\\\", \\\"{x:812,y:842,t:1527268552917};\\\", \\\"{x:813,y:843,t:1527268552933};\\\", \\\"{x:814,y:845,t:1527268552950};\\\", \\\"{x:815,y:846,t:1527268552967};\\\", \\\"{x:817,y:846,t:1527268552983};\\\", \\\"{x:818,y:847,t:1527268553000};\\\", \\\"{x:818,y:848,t:1527268553017};\\\", \\\"{x:819,y:848,t:1527268553033};\\\", \\\"{x:820,y:848,t:1527268553070};\\\", \\\"{x:821,y:848,t:1527268553093};\\\", \\\"{x:822,y:848,t:1527268553110};\\\", \\\"{x:823,y:848,t:1527268553117};\\\", \\\"{x:824,y:848,t:1527268553134};\\\", \\\"{x:825,y:848,t:1527268553150};\\\", \\\"{x:826,y:848,t:1527268553167};\\\", \\\"{x:827,y:848,t:1527268553189};\\\", \\\"{x:828,y:848,t:1527268553269};\\\", \\\"{x:829,y:848,t:1527268553282};\\\", \\\"{x:831,y:848,t:1527268553310};\\\", \\\"{x:832,y:848,t:1527268553317};\\\", \\\"{x:835,y:849,t:1527268553333};\\\", \\\"{x:839,y:849,t:1527268553350};\\\", \\\"{x:843,y:849,t:1527268553367};\\\", \\\"{x:847,y:849,t:1527268553382};\\\", \\\"{x:855,y:849,t:1527268553400};\\\", \\\"{x:858,y:849,t:1527268553417};\\\", \\\"{x:864,y:849,t:1527268553433};\\\", \\\"{x:869,y:850,t:1527268553450};\\\", \\\"{x:874,y:851,t:1527268553467};\\\", \\\"{x:879,y:851,t:1527268553483};\\\", \\\"{x:883,y:853,t:1527268553499};\\\", \\\"{x:886,y:855,t:1527268553517};\\\", \\\"{x:888,y:855,t:1527268553533};\\\", \\\"{x:894,y:857,t:1527268553550};\\\", \\\"{x:904,y:859,t:1527268553567};\\\", \\\"{x:920,y:864,t:1527268553584};\\\", \\\"{x:942,y:871,t:1527268553600};\\\", \\\"{x:968,y:879,t:1527268553617};\\\", \\\"{x:996,y:887,t:1527268553634};\\\", \\\"{x:1024,y:891,t:1527268553650};\\\", \\\"{x:1054,y:897,t:1527268553668};\\\", \\\"{x:1083,y:900,t:1527268553684};\\\", \\\"{x:1115,y:905,t:1527268553700};\\\", \\\"{x:1174,y:913,t:1527268553718};\\\", \\\"{x:1207,y:919,t:1527268553734};\\\", \\\"{x:1236,y:922,t:1527268553751};\\\", \\\"{x:1257,y:925,t:1527268553767};\\\", \\\"{x:1276,y:929,t:1527268553784};\\\", \\\"{x:1289,y:930,t:1527268553801};\\\", \\\"{x:1301,y:931,t:1527268553817};\\\", \\\"{x:1307,y:931,t:1527268553834};\\\", \\\"{x:1314,y:931,t:1527268553850};\\\", \\\"{x:1324,y:932,t:1527268553867};\\\", \\\"{x:1338,y:934,t:1527268553884};\\\", \\\"{x:1348,y:936,t:1527268553900};\\\", \\\"{x:1371,y:939,t:1527268553918};\\\", \\\"{x:1390,y:943,t:1527268553934};\\\", \\\"{x:1404,y:945,t:1527268553950};\\\", \\\"{x:1419,y:947,t:1527268553968};\\\", \\\"{x:1435,y:951,t:1527268553984};\\\", \\\"{x:1450,y:952,t:1527268554000};\\\", \\\"{x:1465,y:955,t:1527268554017};\\\", \\\"{x:1475,y:956,t:1527268554034};\\\", \\\"{x:1488,y:956,t:1527268554050};\\\", \\\"{x:1499,y:956,t:1527268554068};\\\", \\\"{x:1511,y:956,t:1527268554084};\\\", \\\"{x:1522,y:956,t:1527268554100};\\\", \\\"{x:1526,y:957,t:1527268554118};\\\", \\\"{x:1526,y:956,t:1527268554366};\\\", \\\"{x:1524,y:953,t:1527268554384};\\\", \\\"{x:1516,y:948,t:1527268554400};\\\", \\\"{x:1506,y:944,t:1527268554417};\\\", \\\"{x:1493,y:936,t:1527268554434};\\\", \\\"{x:1471,y:924,t:1527268554450};\\\", \\\"{x:1431,y:897,t:1527268554468};\\\", \\\"{x:1380,y:869,t:1527268554484};\\\", \\\"{x:1327,y:837,t:1527268554500};\\\", \\\"{x:1281,y:811,t:1527268554518};\\\", \\\"{x:1267,y:800,t:1527268554534};\\\", \\\"{x:1260,y:793,t:1527268554550};\\\", \\\"{x:1257,y:790,t:1527268554567};\\\", \\\"{x:1257,y:787,t:1527268554584};\\\", \\\"{x:1257,y:782,t:1527268554600};\\\", \\\"{x:1256,y:776,t:1527268554617};\\\", \\\"{x:1256,y:769,t:1527268554634};\\\", \\\"{x:1256,y:759,t:1527268554650};\\\", \\\"{x:1256,y:751,t:1527268554668};\\\", \\\"{x:1256,y:744,t:1527268554684};\\\", \\\"{x:1261,y:728,t:1527268554700};\\\", \\\"{x:1270,y:714,t:1527268554717};\\\", \\\"{x:1284,y:702,t:1527268554734};\\\", \\\"{x:1293,y:692,t:1527268554750};\\\", \\\"{x:1306,y:682,t:1527268554767};\\\", \\\"{x:1315,y:676,t:1527268554785};\\\", \\\"{x:1329,y:668,t:1527268554800};\\\", \\\"{x:1339,y:661,t:1527268554817};\\\", \\\"{x:1344,y:658,t:1527268554835};\\\", \\\"{x:1346,y:658,t:1527268554851};\\\", \\\"{x:1348,y:658,t:1527268554867};\\\", \\\"{x:1350,y:658,t:1527268554884};\\\", \\\"{x:1351,y:658,t:1527268554901};\\\", \\\"{x:1358,y:660,t:1527268554917};\\\", \\\"{x:1361,y:663,t:1527268554934};\\\", \\\"{x:1362,y:664,t:1527268554950};\\\", \\\"{x:1362,y:665,t:1527268554982};\\\", \\\"{x:1362,y:666,t:1527268554998};\\\", \\\"{x:1362,y:669,t:1527268555006};\\\", \\\"{x:1362,y:672,t:1527268555017};\\\", \\\"{x:1362,y:683,t:1527268555035};\\\", \\\"{x:1362,y:696,t:1527268555051};\\\", \\\"{x:1361,y:706,t:1527268555068};\\\", \\\"{x:1361,y:710,t:1527268555084};\\\", \\\"{x:1361,y:713,t:1527268555100};\\\", \\\"{x:1360,y:714,t:1527268555398};\\\", \\\"{x:1359,y:713,t:1527268555406};\\\", \\\"{x:1357,y:712,t:1527268555417};\\\", \\\"{x:1353,y:708,t:1527268555434};\\\", \\\"{x:1350,y:705,t:1527268555450};\\\", \\\"{x:1348,y:704,t:1527268555468};\\\", \\\"{x:1347,y:704,t:1527268555558};\\\", \\\"{x:1347,y:703,t:1527268555726};\\\", \\\"{x:1347,y:702,t:1527268555760};\\\", \\\"{x:1346,y:701,t:1527268555784};\\\", \\\"{x:1346,y:703,t:1527268560675};\\\", \\\"{x:1346,y:709,t:1527268560688};\\\", \\\"{x:1346,y:717,t:1527268560705};\\\", \\\"{x:1346,y:722,t:1527268560722};\\\", \\\"{x:1346,y:726,t:1527268560738};\\\", \\\"{x:1346,y:728,t:1527268560755};\\\", \\\"{x:1346,y:729,t:1527268560772};\\\", \\\"{x:1345,y:731,t:1527268560788};\\\", \\\"{x:1345,y:733,t:1527268560805};\\\", \\\"{x:1345,y:734,t:1527268560821};\\\", \\\"{x:1345,y:737,t:1527268560838};\\\", \\\"{x:1345,y:738,t:1527268560855};\\\", \\\"{x:1345,y:740,t:1527268560872};\\\", \\\"{x:1345,y:741,t:1527268560887};\\\", \\\"{x:1345,y:743,t:1527268560904};\\\", \\\"{x:1345,y:745,t:1527268560921};\\\", \\\"{x:1345,y:749,t:1527268560938};\\\", \\\"{x:1344,y:751,t:1527268560955};\\\", \\\"{x:1344,y:755,t:1527268560972};\\\", \\\"{x:1343,y:757,t:1527268560988};\\\", \\\"{x:1343,y:760,t:1527268561005};\\\", \\\"{x:1343,y:761,t:1527268561022};\\\", \\\"{x:1342,y:763,t:1527268561038};\\\", \\\"{x:1342,y:764,t:1527268561065};\\\", \\\"{x:1342,y:765,t:1527268561122};\\\", \\\"{x:1342,y:766,t:1527268561233};\\\", \\\"{x:1342,y:767,t:1527268561265};\\\", \\\"{x:1342,y:769,t:1527268561313};\\\", \\\"{x:1342,y:770,t:1527268561353};\\\", \\\"{x:1342,y:772,t:1527268561497};\\\", \\\"{x:1342,y:773,t:1527268561833};\\\", \\\"{x:1340,y:774,t:1527268561841};\\\", \\\"{x:1336,y:777,t:1527268561854};\\\", \\\"{x:1325,y:778,t:1527268561872};\\\", \\\"{x:1304,y:778,t:1527268561888};\\\", \\\"{x:1258,y:768,t:1527268561905};\\\", \\\"{x:1210,y:754,t:1527268561922};\\\", \\\"{x:1168,y:741,t:1527268561938};\\\", \\\"{x:1135,y:732,t:1527268561954};\\\", \\\"{x:1110,y:721,t:1527268561971};\\\", \\\"{x:1085,y:712,t:1527268561987};\\\", \\\"{x:1065,y:704,t:1527268562004};\\\", \\\"{x:1048,y:698,t:1527268562021};\\\", \\\"{x:1034,y:692,t:1527268562037};\\\", \\\"{x:1014,y:682,t:1527268562054};\\\", \\\"{x:987,y:667,t:1527268562071};\\\", \\\"{x:946,y:643,t:1527268562087};\\\", \\\"{x:861,y:604,t:1527268562104};\\\", \\\"{x:837,y:592,t:1527268562121};\\\", \\\"{x:830,y:589,t:1527268562130};\\\", \\\"{x:821,y:585,t:1527268562147};\\\", \\\"{x:820,y:584,t:1527268562163};\\\", \\\"{x:817,y:584,t:1527268562181};\\\", \\\"{x:813,y:583,t:1527268562197};\\\", \\\"{x:798,y:579,t:1527268562213};\\\", \\\"{x:774,y:574,t:1527268562230};\\\", \\\"{x:743,y:566,t:1527268562247};\\\", \\\"{x:709,y:561,t:1527268562263};\\\", \\\"{x:656,y:554,t:1527268562280};\\\", \\\"{x:625,y:549,t:1527268562298};\\\", \\\"{x:596,y:548,t:1527268562314};\\\", \\\"{x:574,y:544,t:1527268562330};\\\", \\\"{x:546,y:540,t:1527268562347};\\\", \\\"{x:509,y:537,t:1527268562364};\\\", \\\"{x:467,y:537,t:1527268562382};\\\", \\\"{x:439,y:537,t:1527268562397};\\\", \\\"{x:409,y:537,t:1527268562414};\\\", \\\"{x:378,y:537,t:1527268562431};\\\", \\\"{x:349,y:537,t:1527268562448};\\\", \\\"{x:326,y:537,t:1527268562464};\\\", \\\"{x:299,y:536,t:1527268562481};\\\", \\\"{x:290,y:536,t:1527268562498};\\\", \\\"{x:277,y:536,t:1527268562513};\\\", \\\"{x:269,y:534,t:1527268562532};\\\", \\\"{x:260,y:533,t:1527268562547};\\\", \\\"{x:245,y:528,t:1527268562564};\\\", \\\"{x:225,y:524,t:1527268562582};\\\", \\\"{x:206,y:522,t:1527268562597};\\\", \\\"{x:187,y:518,t:1527268562614};\\\", \\\"{x:179,y:518,t:1527268562631};\\\", \\\"{x:172,y:518,t:1527268562647};\\\", \\\"{x:166,y:518,t:1527268562663};\\\", \\\"{x:163,y:520,t:1527268562680};\\\", \\\"{x:161,y:523,t:1527268562698};\\\", \\\"{x:158,y:526,t:1527268562715};\\\", \\\"{x:156,y:528,t:1527268562731};\\\", \\\"{x:155,y:530,t:1527268562747};\\\", \\\"{x:154,y:531,t:1527268562765};\\\", \\\"{x:153,y:532,t:1527268562781};\\\", \\\"{x:151,y:535,t:1527268562797};\\\", \\\"{x:151,y:536,t:1527268562816};\\\", \\\"{x:151,y:537,t:1527268562831};\\\", \\\"{x:151,y:538,t:1527268562848};\\\", \\\"{x:161,y:539,t:1527268563152};\\\", \\\"{x:172,y:543,t:1527268563165};\\\", \\\"{x:200,y:550,t:1527268563182};\\\", \\\"{x:245,y:572,t:1527268563198};\\\", \\\"{x:291,y:597,t:1527268563214};\\\", \\\"{x:344,y:622,t:1527268563232};\\\", \\\"{x:390,y:647,t:1527268563249};\\\", \\\"{x:434,y:674,t:1527268563265};\\\", \\\"{x:456,y:691,t:1527268563281};\\\", \\\"{x:474,y:705,t:1527268563297};\\\", \\\"{x:488,y:719,t:1527268563314};\\\", \\\"{x:496,y:730,t:1527268563332};\\\", \\\"{x:500,y:737,t:1527268563347};\\\", \\\"{x:500,y:742,t:1527268563365};\\\", \\\"{x:503,y:748,t:1527268563382};\\\", \\\"{x:504,y:755,t:1527268563399};\\\", \\\"{x:506,y:762,t:1527268563414};\\\", \\\"{x:507,y:768,t:1527268563431};\\\", \\\"{x:508,y:774,t:1527268563448};\\\", \\\"{x:508,y:775,t:1527268563465};\\\", \\\"{x:509,y:775,t:1527268563482};\\\", \\\"{x:510,y:775,t:1527268563633};\\\", \\\"{x:510,y:772,t:1527268563648};\\\", \\\"{x:511,y:767,t:1527268563665};\\\", \\\"{x:513,y:761,t:1527268563682};\\\", \\\"{x:513,y:759,t:1527268563699};\\\", \\\"{x:514,y:758,t:1527268563715};\\\", \\\"{x:514,y:757,t:1527268563732};\\\", \\\"{x:515,y:757,t:1527268563749};\\\", \\\"{x:515,y:756,t:1527268563841};\\\", \\\"{x:516,y:753,t:1527268563850};\\\", \\\"{x:517,y:751,t:1527268563865};\\\", \\\"{x:518,y:749,t:1527268563881};\\\", \\\"{x:519,y:745,t:1527268563898};\\\", \\\"{x:521,y:743,t:1527268563915};\\\", \\\"{x:521,y:741,t:1527268563932};\\\", \\\"{x:522,y:739,t:1527268563948};\\\", \\\"{x:523,y:739,t:1527268563976};\\\", \\\"{x:524,y:739,t:1527268563992};\\\", \\\"{x:524,y:738,t:1527268564025};\\\", \\\"{x:525,y:737,t:1527268564040};\\\", \\\"{x:526,y:735,t:1527268564089};\\\" ] }, { \\\"rt\\\": 39928, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 649739, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-Z -04 PM-04 PM-F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:735,t:1527268567914};\\\", \\\"{x:528,y:734,t:1527268567950};\\\", \\\"{x:529,y:734,t:1527268567960};\\\", \\\"{x:530,y:734,t:1527268567975};\\\", \\\"{x:531,y:734,t:1527268567987};\\\", \\\"{x:533,y:733,t:1527268568003};\\\", \\\"{x:538,y:733,t:1527268568020};\\\", \\\"{x:543,y:733,t:1527268568036};\\\", \\\"{x:546,y:733,t:1527268568054};\\\", \\\"{x:548,y:733,t:1527268568069};\\\", \\\"{x:551,y:733,t:1527268568086};\\\", \\\"{x:553,y:733,t:1527268568103};\\\", \\\"{x:556,y:733,t:1527268568120};\\\", \\\"{x:560,y:733,t:1527268568137};\\\", \\\"{x:564,y:733,t:1527268568153};\\\", \\\"{x:567,y:733,t:1527268568171};\\\", \\\"{x:570,y:733,t:1527268568187};\\\", \\\"{x:571,y:733,t:1527268568200};\\\", \\\"{x:572,y:733,t:1527268568217};\\\", \\\"{x:573,y:733,t:1527268568234};\\\", \\\"{x:574,y:733,t:1527268568251};\\\", \\\"{x:576,y:733,t:1527268568272};\\\", \\\"{x:577,y:733,t:1527268568285};\\\", \\\"{x:579,y:733,t:1527268568300};\\\", \\\"{x:580,y:733,t:1527268568318};\\\", \\\"{x:582,y:733,t:1527268568335};\\\", \\\"{x:583,y:734,t:1527268568350};\\\", \\\"{x:584,y:734,t:1527268568368};\\\", \\\"{x:587,y:734,t:1527268568384};\\\", \\\"{x:590,y:734,t:1527268568401};\\\", \\\"{x:594,y:735,t:1527268568418};\\\", \\\"{x:596,y:737,t:1527268568435};\\\", \\\"{x:598,y:737,t:1527268568451};\\\", \\\"{x:603,y:738,t:1527268568468};\\\", \\\"{x:608,y:740,t:1527268568485};\\\", \\\"{x:613,y:743,t:1527268568501};\\\", \\\"{x:619,y:744,t:1527268568519};\\\", \\\"{x:624,y:746,t:1527268568536};\\\", \\\"{x:632,y:748,t:1527268568551};\\\", \\\"{x:637,y:750,t:1527268568568};\\\", \\\"{x:643,y:751,t:1527268568584};\\\", \\\"{x:649,y:753,t:1527268568602};\\\", \\\"{x:655,y:755,t:1527268568618};\\\", \\\"{x:663,y:758,t:1527268568635};\\\", \\\"{x:672,y:763,t:1527268568652};\\\", \\\"{x:682,y:767,t:1527268568668};\\\", \\\"{x:686,y:770,t:1527268568685};\\\", \\\"{x:692,y:772,t:1527268568702};\\\", \\\"{x:699,y:775,t:1527268568718};\\\", \\\"{x:711,y:779,t:1527268568735};\\\", \\\"{x:723,y:783,t:1527268568752};\\\", \\\"{x:739,y:790,t:1527268568769};\\\", \\\"{x:763,y:801,t:1527268568785};\\\", \\\"{x:778,y:807,t:1527268568802};\\\", \\\"{x:794,y:813,t:1527268568818};\\\", \\\"{x:810,y:818,t:1527268568835};\\\", \\\"{x:828,y:826,t:1527268568852};\\\", \\\"{x:846,y:832,t:1527268568868};\\\", \\\"{x:864,y:838,t:1527268568885};\\\", \\\"{x:879,y:843,t:1527268568902};\\\", \\\"{x:890,y:847,t:1527268568918};\\\", \\\"{x:899,y:850,t:1527268568935};\\\", \\\"{x:911,y:852,t:1527268568952};\\\", \\\"{x:925,y:854,t:1527268568968};\\\", \\\"{x:945,y:859,t:1527268568984};\\\", \\\"{x:960,y:860,t:1527268569002};\\\", \\\"{x:973,y:863,t:1527268569018};\\\", \\\"{x:985,y:864,t:1527268569035};\\\", \\\"{x:992,y:866,t:1527268569053};\\\", \\\"{x:1000,y:868,t:1527268569068};\\\", \\\"{x:1014,y:871,t:1527268569086};\\\", \\\"{x:1029,y:872,t:1527268569103};\\\", \\\"{x:1045,y:874,t:1527268569118};\\\", \\\"{x:1060,y:877,t:1527268569135};\\\", \\\"{x:1080,y:882,t:1527268569152};\\\", \\\"{x:1096,y:887,t:1527268569168};\\\", \\\"{x:1129,y:895,t:1527268569185};\\\", \\\"{x:1149,y:901,t:1527268569202};\\\", \\\"{x:1170,y:910,t:1527268569218};\\\", \\\"{x:1192,y:915,t:1527268569235};\\\", \\\"{x:1212,y:920,t:1527268569253};\\\", \\\"{x:1228,y:923,t:1527268569269};\\\", \\\"{x:1242,y:927,t:1527268569285};\\\", \\\"{x:1255,y:930,t:1527268569302};\\\", \\\"{x:1267,y:933,t:1527268569318};\\\", \\\"{x:1278,y:936,t:1527268569335};\\\", \\\"{x:1290,y:938,t:1527268569353};\\\", \\\"{x:1304,y:941,t:1527268569369};\\\", \\\"{x:1321,y:943,t:1527268569385};\\\", \\\"{x:1334,y:945,t:1527268569402};\\\", \\\"{x:1345,y:947,t:1527268569418};\\\", \\\"{x:1361,y:950,t:1527268569435};\\\", \\\"{x:1378,y:957,t:1527268569452};\\\", \\\"{x:1400,y:961,t:1527268569469};\\\", \\\"{x:1422,y:965,t:1527268569485};\\\", \\\"{x:1442,y:968,t:1527268569502};\\\", \\\"{x:1455,y:970,t:1527268569519};\\\", \\\"{x:1465,y:972,t:1527268569535};\\\", \\\"{x:1472,y:972,t:1527268569552};\\\", \\\"{x:1478,y:972,t:1527268569569};\\\", \\\"{x:1480,y:973,t:1527268569585};\\\", \\\"{x:1485,y:973,t:1527268569602};\\\", \\\"{x:1490,y:974,t:1527268569618};\\\", \\\"{x:1497,y:975,t:1527268569635};\\\", \\\"{x:1502,y:975,t:1527268569653};\\\", \\\"{x:1510,y:976,t:1527268569670};\\\", \\\"{x:1519,y:977,t:1527268569686};\\\", \\\"{x:1531,y:977,t:1527268569703};\\\", \\\"{x:1548,y:977,t:1527268569719};\\\", \\\"{x:1564,y:977,t:1527268569736};\\\", \\\"{x:1587,y:966,t:1527268569753};\\\", \\\"{x:1622,y:907,t:1527268569768};\\\", \\\"{x:1641,y:843,t:1527268569785};\\\", \\\"{x:1673,y:745,t:1527268569802};\\\", \\\"{x:1683,y:709,t:1527268569818};\\\", \\\"{x:1686,y:687,t:1527268569835};\\\", \\\"{x:1688,y:669,t:1527268569852};\\\", \\\"{x:1688,y:658,t:1527268569869};\\\", \\\"{x:1689,y:649,t:1527268569886};\\\", \\\"{x:1691,y:642,t:1527268569902};\\\", \\\"{x:1691,y:638,t:1527268569919};\\\", \\\"{x:1691,y:633,t:1527268569935};\\\", \\\"{x:1691,y:627,t:1527268569952};\\\", \\\"{x:1691,y:624,t:1527268569969};\\\", \\\"{x:1689,y:623,t:1527268570025};\\\", \\\"{x:1686,y:623,t:1527268570035};\\\", \\\"{x:1673,y:634,t:1527268570052};\\\", \\\"{x:1660,y:648,t:1527268570069};\\\", \\\"{x:1648,y:660,t:1527268570086};\\\", \\\"{x:1641,y:669,t:1527268570103};\\\", \\\"{x:1635,y:676,t:1527268570119};\\\", \\\"{x:1631,y:682,t:1527268570136};\\\", \\\"{x:1627,y:687,t:1527268570153};\\\", \\\"{x:1623,y:693,t:1527268570169};\\\", \\\"{x:1620,y:696,t:1527268570188};\\\", \\\"{x:1619,y:698,t:1527268570202};\\\", \\\"{x:1618,y:699,t:1527268570223};\\\", \\\"{x:1618,y:700,t:1527268570279};\\\", \\\"{x:1617,y:701,t:1527268570296};\\\", \\\"{x:1616,y:701,t:1527268570825};\\\", \\\"{x:1615,y:699,t:1527268570840};\\\", \\\"{x:1615,y:698,t:1527268570852};\\\", \\\"{x:1615,y:695,t:1527268570869};\\\", \\\"{x:1615,y:694,t:1527268570886};\\\", \\\"{x:1614,y:692,t:1527268570902};\\\", \\\"{x:1614,y:695,t:1527268571073};\\\", \\\"{x:1612,y:700,t:1527268571086};\\\", \\\"{x:1612,y:704,t:1527268571103};\\\", \\\"{x:1612,y:712,t:1527268571120};\\\", \\\"{x:1613,y:717,t:1527268571136};\\\", \\\"{x:1613,y:722,t:1527268571152};\\\", \\\"{x:1613,y:726,t:1527268571169};\\\", \\\"{x:1613,y:733,t:1527268571187};\\\", \\\"{x:1613,y:739,t:1527268571202};\\\", \\\"{x:1613,y:746,t:1527268571219};\\\", \\\"{x:1613,y:760,t:1527268571236};\\\", \\\"{x:1613,y:770,t:1527268571252};\\\", \\\"{x:1613,y:781,t:1527268571270};\\\", \\\"{x:1613,y:787,t:1527268571286};\\\", \\\"{x:1613,y:796,t:1527268571302};\\\", \\\"{x:1613,y:802,t:1527268571320};\\\", \\\"{x:1613,y:807,t:1527268571337};\\\", \\\"{x:1613,y:818,t:1527268571352};\\\", \\\"{x:1613,y:840,t:1527268571370};\\\", \\\"{x:1614,y:857,t:1527268571386};\\\", \\\"{x:1614,y:871,t:1527268571403};\\\", \\\"{x:1615,y:885,t:1527268571420};\\\", \\\"{x:1618,y:896,t:1527268571437};\\\", \\\"{x:1618,y:909,t:1527268571453};\\\", \\\"{x:1620,y:923,t:1527268571469};\\\", \\\"{x:1620,y:938,t:1527268571487};\\\", \\\"{x:1620,y:956,t:1527268571503};\\\", \\\"{x:1620,y:969,t:1527268571520};\\\", \\\"{x:1620,y:978,t:1527268571536};\\\", \\\"{x:1620,y:984,t:1527268571552};\\\", \\\"{x:1620,y:990,t:1527268571570};\\\", \\\"{x:1622,y:998,t:1527268571586};\\\", \\\"{x:1622,y:1001,t:1527268571602};\\\", \\\"{x:1622,y:1004,t:1527268571619};\\\", \\\"{x:1623,y:1008,t:1527268571636};\\\", \\\"{x:1623,y:1009,t:1527268571657};\\\", \\\"{x:1624,y:1010,t:1527268571669};\\\", \\\"{x:1625,y:1010,t:1527268572338};\\\", \\\"{x:1626,y:1010,t:1527268572409};\\\", \\\"{x:1626,y:1009,t:1527268572420};\\\", \\\"{x:1626,y:1005,t:1527268572437};\\\", \\\"{x:1618,y:995,t:1527268572453};\\\", \\\"{x:1598,y:981,t:1527268572470};\\\", \\\"{x:1571,y:964,t:1527268572487};\\\", \\\"{x:1528,y:939,t:1527268572504};\\\", \\\"{x:1466,y:909,t:1527268572519};\\\", \\\"{x:1327,y:864,t:1527268572536};\\\", \\\"{x:1251,y:836,t:1527268572553};\\\", \\\"{x:1183,y:815,t:1527268572570};\\\", \\\"{x:1131,y:792,t:1527268572586};\\\", \\\"{x:1048,y:757,t:1527268572603};\\\", \\\"{x:954,y:715,t:1527268572620};\\\", \\\"{x:849,y:670,t:1527268572636};\\\", \\\"{x:775,y:639,t:1527268572654};\\\", \\\"{x:722,y:616,t:1527268572671};\\\", \\\"{x:697,y:604,t:1527268572686};\\\", \\\"{x:681,y:594,t:1527268572703};\\\", \\\"{x:672,y:589,t:1527268572719};\\\", \\\"{x:659,y:580,t:1527268572739};\\\", \\\"{x:648,y:573,t:1527268572756};\\\", \\\"{x:635,y:565,t:1527268572773};\\\", \\\"{x:625,y:561,t:1527268572789};\\\", \\\"{x:620,y:558,t:1527268572806};\\\", \\\"{x:619,y:558,t:1527268572823};\\\", \\\"{x:621,y:556,t:1527268572912};\\\", \\\"{x:632,y:554,t:1527268572923};\\\", \\\"{x:648,y:551,t:1527268572939};\\\", \\\"{x:669,y:545,t:1527268572956};\\\", \\\"{x:691,y:539,t:1527268572973};\\\", \\\"{x:712,y:533,t:1527268572990};\\\", \\\"{x:732,y:523,t:1527268573006};\\\", \\\"{x:744,y:515,t:1527268573023};\\\", \\\"{x:755,y:505,t:1527268573040};\\\", \\\"{x:760,y:501,t:1527268573056};\\\", \\\"{x:765,y:499,t:1527268573073};\\\", \\\"{x:770,y:499,t:1527268573090};\\\", \\\"{x:774,y:499,t:1527268573106};\\\", \\\"{x:780,y:499,t:1527268573123};\\\", \\\"{x:784,y:499,t:1527268573140};\\\", \\\"{x:785,y:499,t:1527268573161};\\\", \\\"{x:786,y:499,t:1527268573233};\\\", \\\"{x:787,y:499,t:1527268573241};\\\", \\\"{x:789,y:500,t:1527268573256};\\\", \\\"{x:791,y:501,t:1527268573273};\\\", \\\"{x:792,y:501,t:1527268573290};\\\", \\\"{x:793,y:501,t:1527268573306};\\\", \\\"{x:794,y:501,t:1527268573323};\\\", \\\"{x:795,y:503,t:1527268573341};\\\", \\\"{x:797,y:503,t:1527268573357};\\\", \\\"{x:798,y:503,t:1527268573373};\\\", \\\"{x:800,y:503,t:1527268573390};\\\", \\\"{x:804,y:503,t:1527268573407};\\\", \\\"{x:811,y:503,t:1527268573423};\\\", \\\"{x:817,y:503,t:1527268573441};\\\", \\\"{x:818,y:503,t:1527268573457};\\\", \\\"{x:820,y:503,t:1527268573489};\\\", \\\"{x:821,y:503,t:1527268573553};\\\", \\\"{x:823,y:503,t:1527268573568};\\\", \\\"{x:825,y:503,t:1527268573593};\\\", \\\"{x:820,y:503,t:1527268573841};\\\", \\\"{x:786,y:503,t:1527268573857};\\\", \\\"{x:730,y:501,t:1527268573874};\\\", \\\"{x:665,y:499,t:1527268573892};\\\", \\\"{x:600,y:494,t:1527268573907};\\\", \\\"{x:549,y:494,t:1527268573924};\\\", \\\"{x:507,y:494,t:1527268573940};\\\", \\\"{x:478,y:496,t:1527268573957};\\\", \\\"{x:455,y:501,t:1527268573973};\\\", \\\"{x:441,y:505,t:1527268573990};\\\", \\\"{x:431,y:508,t:1527268574007};\\\", \\\"{x:418,y:513,t:1527268574023};\\\", \\\"{x:410,y:516,t:1527268574040};\\\", \\\"{x:405,y:520,t:1527268574057};\\\", \\\"{x:401,y:523,t:1527268574074};\\\", \\\"{x:399,y:525,t:1527268574092};\\\", \\\"{x:396,y:529,t:1527268574107};\\\", \\\"{x:393,y:535,t:1527268574124};\\\", \\\"{x:392,y:541,t:1527268574139};\\\", \\\"{x:392,y:545,t:1527268574157};\\\", \\\"{x:392,y:546,t:1527268574175};\\\", \\\"{x:392,y:547,t:1527268574189};\\\", \\\"{x:392,y:548,t:1527268574207};\\\", \\\"{x:392,y:552,t:1527268574224};\\\", \\\"{x:392,y:559,t:1527268574241};\\\", \\\"{x:393,y:563,t:1527268574258};\\\", \\\"{x:394,y:566,t:1527268574274};\\\", \\\"{x:394,y:567,t:1527268574290};\\\", \\\"{x:394,y:568,t:1527268574328};\\\", \\\"{x:394,y:570,t:1527268574353};\\\", \\\"{x:395,y:571,t:1527268574360};\\\", \\\"{x:396,y:574,t:1527268574374};\\\", \\\"{x:397,y:577,t:1527268574390};\\\", \\\"{x:399,y:580,t:1527268574407};\\\", \\\"{x:403,y:585,t:1527268574424};\\\", \\\"{x:405,y:585,t:1527268574440};\\\", \\\"{x:408,y:585,t:1527268574457};\\\", \\\"{x:419,y:585,t:1527268574475};\\\", \\\"{x:437,y:585,t:1527268574490};\\\", \\\"{x:470,y:580,t:1527268574507};\\\", \\\"{x:509,y:575,t:1527268574526};\\\", \\\"{x:541,y:574,t:1527268574541};\\\", \\\"{x:566,y:574,t:1527268574556};\\\", \\\"{x:582,y:574,t:1527268574574};\\\", \\\"{x:591,y:574,t:1527268574591};\\\", \\\"{x:595,y:574,t:1527268574607};\\\", \\\"{x:597,y:572,t:1527268574624};\\\", \\\"{x:601,y:572,t:1527268574641};\\\", \\\"{x:603,y:572,t:1527268574657};\\\", \\\"{x:605,y:572,t:1527268574674};\\\", \\\"{x:606,y:572,t:1527268574691};\\\", \\\"{x:607,y:572,t:1527268574752};\\\", \\\"{x:607,y:574,t:1527268574760};\\\", \\\"{x:607,y:575,t:1527268574776};\\\", \\\"{x:608,y:576,t:1527268574807};\\\", \\\"{x:610,y:576,t:1527268575457};\\\", \\\"{x:614,y:576,t:1527268575464};\\\", \\\"{x:619,y:576,t:1527268575475};\\\", \\\"{x:639,y:573,t:1527268575492};\\\", \\\"{x:669,y:568,t:1527268575509};\\\", \\\"{x:698,y:561,t:1527268575526};\\\", \\\"{x:721,y:556,t:1527268575541};\\\", \\\"{x:737,y:553,t:1527268575560};\\\", \\\"{x:747,y:549,t:1527268575574};\\\", \\\"{x:751,y:547,t:1527268575591};\\\", \\\"{x:753,y:545,t:1527268575608};\\\", \\\"{x:755,y:543,t:1527268575625};\\\", \\\"{x:758,y:542,t:1527268575642};\\\", \\\"{x:760,y:539,t:1527268575658};\\\", \\\"{x:761,y:539,t:1527268575674};\\\", \\\"{x:766,y:536,t:1527268575692};\\\", \\\"{x:770,y:531,t:1527268575708};\\\", \\\"{x:776,y:527,t:1527268575725};\\\", \\\"{x:783,y:521,t:1527268575743};\\\", \\\"{x:787,y:519,t:1527268575758};\\\", \\\"{x:791,y:516,t:1527268575776};\\\", \\\"{x:792,y:515,t:1527268575791};\\\", \\\"{x:798,y:514,t:1527268575808};\\\", \\\"{x:804,y:512,t:1527268575824};\\\", \\\"{x:815,y:508,t:1527268575842};\\\", \\\"{x:825,y:506,t:1527268575858};\\\", \\\"{x:830,y:504,t:1527268575876};\\\", \\\"{x:833,y:503,t:1527268575892};\\\", \\\"{x:835,y:503,t:1527268575908};\\\", \\\"{x:836,y:503,t:1527268575924};\\\", \\\"{x:837,y:504,t:1527268576537};\\\", \\\"{x:847,y:516,t:1527268576546};\\\", \\\"{x:859,y:528,t:1527268576559};\\\", \\\"{x:896,y:561,t:1527268576576};\\\", \\\"{x:916,y:578,t:1527268576593};\\\", \\\"{x:932,y:592,t:1527268576609};\\\", \\\"{x:937,y:601,t:1527268576626};\\\", \\\"{x:942,y:614,t:1527268576642};\\\", \\\"{x:947,y:630,t:1527268576659};\\\", \\\"{x:953,y:644,t:1527268576676};\\\", \\\"{x:960,y:661,t:1527268576692};\\\", \\\"{x:968,y:677,t:1527268576708};\\\", \\\"{x:975,y:691,t:1527268576725};\\\", \\\"{x:989,y:709,t:1527268576742};\\\", \\\"{x:1006,y:724,t:1527268576759};\\\", \\\"{x:1030,y:742,t:1527268576776};\\\", \\\"{x:1049,y:754,t:1527268576792};\\\", \\\"{x:1072,y:768,t:1527268576809};\\\", \\\"{x:1096,y:781,t:1527268576826};\\\", \\\"{x:1118,y:794,t:1527268576842};\\\", \\\"{x:1142,y:806,t:1527268576859};\\\", \\\"{x:1167,y:819,t:1527268576876};\\\", \\\"{x:1181,y:828,t:1527268576892};\\\", \\\"{x:1188,y:831,t:1527268576909};\\\", \\\"{x:1189,y:831,t:1527268576926};\\\", \\\"{x:1190,y:831,t:1527268577225};\\\", \\\"{x:1197,y:827,t:1527268577233};\\\", \\\"{x:1209,y:818,t:1527268577244};\\\", \\\"{x:1225,y:804,t:1527268577260};\\\", \\\"{x:1226,y:801,t:1527268577277};\\\", \\\"{x:1230,y:795,t:1527268577294};\\\", \\\"{x:1234,y:782,t:1527268577309};\\\", \\\"{x:1237,y:761,t:1527268577326};\\\", \\\"{x:1246,y:733,t:1527268577343};\\\", \\\"{x:1265,y:686,t:1527268577360};\\\", \\\"{x:1274,y:663,t:1527268577376};\\\", \\\"{x:1284,y:639,t:1527268577393};\\\", \\\"{x:1295,y:616,t:1527268577410};\\\", \\\"{x:1304,y:602,t:1527268577426};\\\", \\\"{x:1309,y:591,t:1527268577443};\\\", \\\"{x:1315,y:583,t:1527268577460};\\\", \\\"{x:1323,y:576,t:1527268577476};\\\", \\\"{x:1328,y:575,t:1527268577493};\\\", \\\"{x:1336,y:573,t:1527268577511};\\\", \\\"{x:1344,y:576,t:1527268577527};\\\", \\\"{x:1361,y:582,t:1527268577543};\\\", \\\"{x:1383,y:592,t:1527268577561};\\\", \\\"{x:1386,y:593,t:1527268577576};\\\", \\\"{x:1389,y:594,t:1527268577593};\\\", \\\"{x:1389,y:599,t:1527268577610};\\\", \\\"{x:1389,y:605,t:1527268577627};\\\", \\\"{x:1388,y:614,t:1527268577643};\\\", \\\"{x:1379,y:626,t:1527268577661};\\\", \\\"{x:1369,y:639,t:1527268577677};\\\", \\\"{x:1354,y:652,t:1527268577694};\\\", \\\"{x:1344,y:661,t:1527268577710};\\\", \\\"{x:1339,y:665,t:1527268577726};\\\", \\\"{x:1338,y:666,t:1527268577743};\\\", \\\"{x:1337,y:669,t:1527268577760};\\\", \\\"{x:1338,y:669,t:1527268577777};\\\", \\\"{x:1341,y:669,t:1527268577794};\\\", \\\"{x:1346,y:671,t:1527268577810};\\\", \\\"{x:1350,y:673,t:1527268577828};\\\", \\\"{x:1353,y:675,t:1527268577843};\\\", \\\"{x:1357,y:677,t:1527268577861};\\\", \\\"{x:1360,y:678,t:1527268577878};\\\", \\\"{x:1361,y:679,t:1527268577893};\\\", \\\"{x:1363,y:679,t:1527268577910};\\\", \\\"{x:1364,y:679,t:1527268577929};\\\", \\\"{x:1364,y:680,t:1527268577944};\\\", \\\"{x:1366,y:681,t:1527268577960};\\\", \\\"{x:1367,y:682,t:1527268577993};\\\", \\\"{x:1370,y:682,t:1527268578011};\\\", \\\"{x:1371,y:683,t:1527268578027};\\\", \\\"{x:1373,y:684,t:1527268578044};\\\", \\\"{x:1373,y:685,t:1527268578060};\\\", \\\"{x:1374,y:685,t:1527268578078};\\\", \\\"{x:1375,y:685,t:1527268578093};\\\", \\\"{x:1376,y:685,t:1527268578111};\\\", \\\"{x:1376,y:687,t:1527268578128};\\\", \\\"{x:1376,y:689,t:1527268578144};\\\", \\\"{x:1374,y:691,t:1527268578161};\\\", \\\"{x:1369,y:694,t:1527268578177};\\\", \\\"{x:1364,y:697,t:1527268578194};\\\", \\\"{x:1355,y:700,t:1527268578210};\\\", \\\"{x:1347,y:704,t:1527268578228};\\\", \\\"{x:1346,y:704,t:1527268578244};\\\", \\\"{x:1345,y:704,t:1527268578746};\\\", \\\"{x:1345,y:703,t:1527268579033};\\\", \\\"{x:1345,y:702,t:1527268579045};\\\", \\\"{x:1345,y:700,t:1527268579274};\\\", \\\"{x:1347,y:698,t:1527268579295};\\\", \\\"{x:1347,y:697,t:1527268579336};\\\", \\\"{x:1347,y:696,t:1527268579344};\\\", \\\"{x:1348,y:696,t:1527268581249};\\\", \\\"{x:1349,y:696,t:1527268581262};\\\", \\\"{x:1352,y:703,t:1527268581281};\\\", \\\"{x:1372,y:724,t:1527268581297};\\\", \\\"{x:1390,y:737,t:1527268581314};\\\", \\\"{x:1413,y:755,t:1527268581330};\\\", \\\"{x:1438,y:770,t:1527268581346};\\\", \\\"{x:1458,y:781,t:1527268581363};\\\", \\\"{x:1473,y:791,t:1527268581380};\\\", \\\"{x:1484,y:798,t:1527268581397};\\\", \\\"{x:1492,y:802,t:1527268581413};\\\", \\\"{x:1496,y:805,t:1527268581430};\\\", \\\"{x:1500,y:808,t:1527268581447};\\\", \\\"{x:1501,y:809,t:1527268581505};\\\", \\\"{x:1501,y:811,t:1527268581521};\\\", \\\"{x:1502,y:813,t:1527268581530};\\\", \\\"{x:1503,y:815,t:1527268581546};\\\", \\\"{x:1503,y:816,t:1527268581563};\\\", \\\"{x:1503,y:818,t:1527268581580};\\\", \\\"{x:1503,y:819,t:1527268581597};\\\", \\\"{x:1503,y:821,t:1527268581614};\\\", \\\"{x:1503,y:822,t:1527268581630};\\\", \\\"{x:1503,y:824,t:1527268581647};\\\", \\\"{x:1503,y:825,t:1527268581664};\\\", \\\"{x:1499,y:825,t:1527268581680};\\\", \\\"{x:1495,y:826,t:1527268581697};\\\", \\\"{x:1492,y:826,t:1527268581714};\\\", \\\"{x:1490,y:826,t:1527268581730};\\\", \\\"{x:1489,y:826,t:1527268581746};\\\", \\\"{x:1488,y:826,t:1527268581784};\\\", \\\"{x:1487,y:826,t:1527268581808};\\\", \\\"{x:1486,y:826,t:1527268581929};\\\", \\\"{x:1484,y:826,t:1527268581945};\\\", \\\"{x:1483,y:826,t:1527268581963};\\\", \\\"{x:1481,y:826,t:1527268581980};\\\", \\\"{x:1480,y:826,t:1527268581996};\\\", \\\"{x:1478,y:826,t:1527268582032};\\\", \\\"{x:1471,y:826,t:1527268583186};\\\", \\\"{x:1460,y:826,t:1527268583198};\\\", \\\"{x:1410,y:826,t:1527268583215};\\\", \\\"{x:1327,y:826,t:1527268583232};\\\", \\\"{x:1236,y:829,t:1527268583249};\\\", \\\"{x:1201,y:833,t:1527268583264};\\\", \\\"{x:1173,y:839,t:1527268583281};\\\", \\\"{x:1150,y:839,t:1527268583298};\\\", \\\"{x:1125,y:839,t:1527268583314};\\\", \\\"{x:1098,y:838,t:1527268583332};\\\", \\\"{x:1065,y:830,t:1527268583348};\\\", \\\"{x:1038,y:827,t:1527268583364};\\\", \\\"{x:1002,y:821,t:1527268583382};\\\", \\\"{x:954,y:814,t:1527268583398};\\\", \\\"{x:877,y:807,t:1527268583415};\\\", \\\"{x:797,y:788,t:1527268583432};\\\", \\\"{x:657,y:769,t:1527268583449};\\\", \\\"{x:582,y:759,t:1527268583464};\\\", \\\"{x:520,y:748,t:1527268583483};\\\", \\\"{x:479,y:738,t:1527268583498};\\\", \\\"{x:452,y:735,t:1527268583514};\\\", \\\"{x:429,y:731,t:1527268583531};\\\", \\\"{x:410,y:727,t:1527268583548};\\\", \\\"{x:393,y:725,t:1527268583564};\\\", \\\"{x:378,y:722,t:1527268583581};\\\", \\\"{x:366,y:721,t:1527268583598};\\\", \\\"{x:354,y:720,t:1527268583614};\\\", \\\"{x:338,y:717,t:1527268583631};\\\", \\\"{x:316,y:715,t:1527268583648};\\\", \\\"{x:310,y:715,t:1527268583664};\\\", \\\"{x:307,y:715,t:1527268583681};\\\", \\\"{x:306,y:715,t:1527268583727};\\\", \\\"{x:304,y:714,t:1527268583744};\\\", \\\"{x:306,y:713,t:1527268583785};\\\", \\\"{x:312,y:713,t:1527268583799};\\\", \\\"{x:332,y:713,t:1527268583816};\\\", \\\"{x:358,y:713,t:1527268583832};\\\", \\\"{x:371,y:713,t:1527268583848};\\\", \\\"{x:379,y:712,t:1527268583866};\\\", \\\"{x:387,y:711,t:1527268583881};\\\", \\\"{x:390,y:711,t:1527268583898};\\\", \\\"{x:398,y:708,t:1527268583916};\\\", \\\"{x:412,y:706,t:1527268583931};\\\", \\\"{x:430,y:706,t:1527268583949};\\\", \\\"{x:446,y:706,t:1527268583966};\\\", \\\"{x:459,y:704,t:1527268583982};\\\", \\\"{x:466,y:703,t:1527268583998};\\\", \\\"{x:468,y:703,t:1527268584015};\\\", \\\"{x:473,y:703,t:1527268584032};\\\", \\\"{x:476,y:703,t:1527268584049};\\\", \\\"{x:481,y:703,t:1527268584066};\\\", \\\"{x:486,y:703,t:1527268584082};\\\", \\\"{x:493,y:703,t:1527268584099};\\\", \\\"{x:499,y:703,t:1527268584115};\\\", \\\"{x:503,y:703,t:1527268584132};\\\", \\\"{x:505,y:703,t:1527268584149};\\\", \\\"{x:506,y:703,t:1527268584166};\\\", \\\"{x:507,y:703,t:1527268584182};\\\", \\\"{x:508,y:703,t:1527268584240};\\\", \\\"{x:508,y:704,t:1527268584344};\\\", \\\"{x:508,y:705,t:1527268584352};\\\", \\\"{x:508,y:706,t:1527268584366};\\\", \\\"{x:508,y:708,t:1527268584382};\\\", \\\"{x:508,y:709,t:1527268584399};\\\", \\\"{x:508,y:710,t:1527268584416};\\\", \\\"{x:508,y:711,t:1527268584432};\\\", \\\"{x:508,y:712,t:1527268584456};\\\", \\\"{x:508,y:713,t:1527268584480};\\\", \\\"{x:508,y:714,t:1527268584497};\\\", \\\"{x:508,y:716,t:1527268584512};\\\", \\\"{x:510,y:717,t:1527268584520};\\\", \\\"{x:510,y:718,t:1527268584533};\\\", \\\"{x:510,y:722,t:1527268584551};\\\", \\\"{x:510,y:725,t:1527268584566};\\\", \\\"{x:510,y:728,t:1527268584582};\\\", \\\"{x:510,y:733,t:1527268584600};\\\", \\\"{x:510,y:738,t:1527268584616};\\\", \\\"{x:510,y:745,t:1527268584633};\\\", \\\"{x:510,y:748,t:1527268584650};\\\", \\\"{x:510,y:750,t:1527268584667};\\\", \\\"{x:511,y:752,t:1527268584683};\\\", \\\"{x:512,y:752,t:1527268585497};\\\", \\\"{x:514,y:751,t:1527268585529};\\\", \\\"{x:517,y:750,t:1527268586520};\\\", \\\"{x:517,y:748,t:1527268586785};\\\", \\\"{x:517,y:744,t:1527268586802};\\\", \\\"{x:516,y:744,t:1527268606448};\\\", \\\"{x:514,y:744,t:1527268606464};\\\", \\\"{x:512,y:744,t:1527268606512};\\\", \\\"{x:511,y:744,t:1527268606527};\\\", \\\"{x:509,y:744,t:1527268606560};\\\", \\\"{x:508,y:744,t:1527268606584};\\\", \\\"{x:506,y:744,t:1527268606601};\\\", \\\"{x:505,y:744,t:1527268606617};\\\", \\\"{x:503,y:744,t:1527268606634};\\\", \\\"{x:502,y:744,t:1527268606650};\\\", \\\"{x:499,y:744,t:1527268606667};\\\", \\\"{x:498,y:744,t:1527268606685};\\\", \\\"{x:497,y:744,t:1527268606700};\\\", \\\"{x:496,y:744,t:1527268606717};\\\", \\\"{x:495,y:744,t:1527268606760};\\\", \\\"{x:494,y:744,t:1527268606792};\\\", \\\"{x:493,y:744,t:1527268606808};\\\", \\\"{x:492,y:744,t:1527268606864};\\\", \\\"{x:491,y:744,t:1527268606904};\\\", \\\"{x:490,y:744,t:1527268607024};\\\", \\\"{x:489,y:744,t:1527268607055};\\\", \\\"{x:488,y:744,t:1527268607068};\\\" ] }, { \\\"rt\\\": 41114, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 692065, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-03 PM-02 PM-01 PM-M -M -M -B -B -B -B -B -F -J -J -C -M -M -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:745,t:1527268607377};\\\", \\\"{x:496,y:745,t:1527268607839};\\\", \\\"{x:500,y:745,t:1527268607851};\\\", \\\"{x:509,y:745,t:1527268607868};\\\", \\\"{x:514,y:745,t:1527268607886};\\\", \\\"{x:526,y:720,t:1527268607973};\\\", \\\"{x:530,y:696,t:1527268607988};\\\", \\\"{x:530,y:660,t:1527268608001};\\\", \\\"{x:530,y:604,t:1527268608019};\\\", \\\"{x:524,y:546,t:1527268608036};\\\", \\\"{x:519,y:512,t:1527268608051};\\\", \\\"{x:512,y:484,t:1527268608068};\\\", \\\"{x:509,y:472,t:1527268608085};\\\", \\\"{x:508,y:469,t:1527268608101};\\\", \\\"{x:507,y:469,t:1527268608183};\\\", \\\"{x:506,y:469,t:1527268608191};\\\", \\\"{x:503,y:469,t:1527268608202};\\\", \\\"{x:498,y:470,t:1527268608219};\\\", \\\"{x:493,y:473,t:1527268608235};\\\", \\\"{x:490,y:475,t:1527268608252};\\\", \\\"{x:485,y:477,t:1527268608268};\\\", \\\"{x:484,y:477,t:1527268608285};\\\", \\\"{x:481,y:478,t:1527268608302};\\\", \\\"{x:480,y:478,t:1527268608318};\\\", \\\"{x:481,y:478,t:1527268608441};\\\", \\\"{x:489,y:479,t:1527268608453};\\\", \\\"{x:505,y:481,t:1527268608469};\\\", \\\"{x:514,y:481,t:1527268608485};\\\", \\\"{x:521,y:481,t:1527268608502};\\\", \\\"{x:523,y:481,t:1527268608519};\\\", \\\"{x:524,y:481,t:1527268608535};\\\", \\\"{x:525,y:481,t:1527268608632};\\\", \\\"{x:526,y:481,t:1527268608663};\\\", \\\"{x:528,y:481,t:1527268608671};\\\", \\\"{x:532,y:481,t:1527268608685};\\\", \\\"{x:542,y:481,t:1527268608702};\\\", \\\"{x:549,y:481,t:1527268608719};\\\", \\\"{x:556,y:481,t:1527268608736};\\\", \\\"{x:561,y:481,t:1527268608752};\\\", \\\"{x:563,y:481,t:1527268608769};\\\", \\\"{x:565,y:481,t:1527268608786};\\\", \\\"{x:567,y:481,t:1527268608802};\\\", \\\"{x:571,y:481,t:1527268608818};\\\", \\\"{x:575,y:481,t:1527268608835};\\\", \\\"{x:578,y:481,t:1527268608852};\\\", \\\"{x:580,y:480,t:1527268608869};\\\", \\\"{x:581,y:480,t:1527268608885};\\\", \\\"{x:583,y:480,t:1527268608903};\\\", \\\"{x:584,y:480,t:1527268608928};\\\", \\\"{x:586,y:480,t:1527268608936};\\\", \\\"{x:588,y:480,t:1527268608952};\\\", \\\"{x:590,y:480,t:1527268608969};\\\", \\\"{x:591,y:480,t:1527268608986};\\\", \\\"{x:593,y:480,t:1527268609002};\\\", \\\"{x:595,y:480,t:1527268609019};\\\", \\\"{x:597,y:480,t:1527268609036};\\\", \\\"{x:601,y:480,t:1527268609052};\\\", \\\"{x:606,y:480,t:1527268609070};\\\", \\\"{x:612,y:480,t:1527268609086};\\\", \\\"{x:621,y:481,t:1527268609103};\\\", \\\"{x:644,y:488,t:1527268609120};\\\", \\\"{x:660,y:496,t:1527268609135};\\\", \\\"{x:675,y:506,t:1527268609151};\\\", \\\"{x:700,y:521,t:1527268609167};\\\", \\\"{x:722,y:536,t:1527268609184};\\\", \\\"{x:738,y:548,t:1527268609203};\\\", \\\"{x:747,y:556,t:1527268609219};\\\", \\\"{x:751,y:563,t:1527268609236};\\\", \\\"{x:752,y:570,t:1527268609252};\\\", \\\"{x:752,y:574,t:1527268609269};\\\", \\\"{x:752,y:581,t:1527268609286};\\\", \\\"{x:752,y:591,t:1527268609303};\\\", \\\"{x:752,y:610,t:1527268609320};\\\", \\\"{x:752,y:625,t:1527268609335};\\\", \\\"{x:752,y:642,t:1527268609353};\\\", \\\"{x:755,y:661,t:1527268609369};\\\", \\\"{x:758,y:685,t:1527268609386};\\\", \\\"{x:767,y:707,t:1527268609403};\\\", \\\"{x:774,y:723,t:1527268609419};\\\", \\\"{x:787,y:741,t:1527268609436};\\\", \\\"{x:798,y:760,t:1527268609454};\\\", \\\"{x:808,y:785,t:1527268609469};\\\", \\\"{x:831,y:822,t:1527268609486};\\\", \\\"{x:883,y:878,t:1527268609503};\\\", \\\"{x:919,y:901,t:1527268609520};\\\", \\\"{x:939,y:911,t:1527268609536};\\\", \\\"{x:957,y:915,t:1527268609553};\\\", \\\"{x:979,y:916,t:1527268609569};\\\", \\\"{x:1002,y:916,t:1527268609587};\\\", \\\"{x:1020,y:912,t:1527268609604};\\\", \\\"{x:1037,y:902,t:1527268609620};\\\", \\\"{x:1048,y:886,t:1527268609637};\\\", \\\"{x:1056,y:870,t:1527268609654};\\\", \\\"{x:1066,y:856,t:1527268609670};\\\", \\\"{x:1071,y:846,t:1527268609687};\\\", \\\"{x:1085,y:829,t:1527268609704};\\\", \\\"{x:1094,y:817,t:1527268609720};\\\", \\\"{x:1103,y:804,t:1527268609737};\\\", \\\"{x:1115,y:793,t:1527268609753};\\\", \\\"{x:1127,y:783,t:1527268609770};\\\", \\\"{x:1140,y:779,t:1527268609787};\\\", \\\"{x:1141,y:779,t:1527268609804};\\\", \\\"{x:1143,y:779,t:1527268609832};\\\", \\\"{x:1150,y:779,t:1527268609840};\\\", \\\"{x:1165,y:779,t:1527268609854};\\\", \\\"{x:1239,y:793,t:1527268609870};\\\", \\\"{x:1308,y:826,t:1527268609887};\\\", \\\"{x:1427,y:884,t:1527268609904};\\\", \\\"{x:1508,y:926,t:1527268609920};\\\", \\\"{x:1573,y:960,t:1527268609937};\\\", \\\"{x:1615,y:982,t:1527268609954};\\\", \\\"{x:1650,y:1001,t:1527268609972};\\\", \\\"{x:1674,y:1014,t:1527268609986};\\\", \\\"{x:1683,y:1019,t:1527268610003};\\\", \\\"{x:1684,y:1019,t:1527268610021};\\\", \\\"{x:1684,y:1020,t:1527268610088};\\\", \\\"{x:1677,y:1029,t:1527268610104};\\\", \\\"{x:1668,y:1037,t:1527268610120};\\\", \\\"{x:1657,y:1043,t:1527268610138};\\\", \\\"{x:1646,y:1048,t:1527268610154};\\\", \\\"{x:1632,y:1053,t:1527268610171};\\\", \\\"{x:1620,y:1054,t:1527268610187};\\\", \\\"{x:1607,y:1054,t:1527268610203};\\\", \\\"{x:1593,y:1054,t:1527268610221};\\\", \\\"{x:1581,y:1054,t:1527268610237};\\\", \\\"{x:1569,y:1052,t:1527268610254};\\\", \\\"{x:1563,y:1052,t:1527268610270};\\\", \\\"{x:1562,y:1051,t:1527268610320};\\\", \\\"{x:1562,y:1049,t:1527268610368};\\\", \\\"{x:1562,y:1048,t:1527268610376};\\\", \\\"{x:1562,y:1044,t:1527268610388};\\\", \\\"{x:1562,y:1041,t:1527268610404};\\\", \\\"{x:1562,y:1039,t:1527268610420};\\\", \\\"{x:1562,y:1037,t:1527268610438};\\\", \\\"{x:1562,y:1034,t:1527268610454};\\\", \\\"{x:1562,y:1030,t:1527268610471};\\\", \\\"{x:1564,y:1020,t:1527268610488};\\\", \\\"{x:1564,y:1011,t:1527268610504};\\\", \\\"{x:1564,y:1002,t:1527268610521};\\\", \\\"{x:1564,y:992,t:1527268610538};\\\", \\\"{x:1564,y:990,t:1527268610554};\\\", \\\"{x:1564,y:989,t:1527268610584};\\\", \\\"{x:1564,y:988,t:1527268610608};\\\", \\\"{x:1564,y:987,t:1527268610621};\\\", \\\"{x:1564,y:986,t:1527268610640};\\\", \\\"{x:1564,y:985,t:1527268610656};\\\", \\\"{x:1564,y:984,t:1527268610671};\\\", \\\"{x:1564,y:981,t:1527268610688};\\\", \\\"{x:1564,y:980,t:1527268610720};\\\", \\\"{x:1564,y:978,t:1527268610768};\\\", \\\"{x:1563,y:978,t:1527268610776};\\\", \\\"{x:1563,y:977,t:1527268610787};\\\", \\\"{x:1562,y:977,t:1527268610804};\\\", \\\"{x:1561,y:976,t:1527268610821};\\\", \\\"{x:1560,y:975,t:1527268610961};\\\", \\\"{x:1559,y:973,t:1527268610971};\\\", \\\"{x:1555,y:970,t:1527268610988};\\\", \\\"{x:1553,y:969,t:1527268611005};\\\", \\\"{x:1551,y:967,t:1527268611023};\\\", \\\"{x:1550,y:967,t:1527268611176};\\\", \\\"{x:1549,y:966,t:1527268611192};\\\", \\\"{x:1549,y:965,t:1527268611208};\\\", \\\"{x:1547,y:964,t:1527268611545};\\\", \\\"{x:1543,y:963,t:1527268613049};\\\", \\\"{x:1538,y:963,t:1527268613056};\\\", \\\"{x:1532,y:963,t:1527268613073};\\\", \\\"{x:1532,y:962,t:1527268613091};\\\", \\\"{x:1531,y:962,t:1527268613416};\\\", \\\"{x:1528,y:962,t:1527268613424};\\\", \\\"{x:1523,y:963,t:1527268613440};\\\", \\\"{x:1520,y:964,t:1527268613457};\\\", \\\"{x:1517,y:965,t:1527268613475};\\\", \\\"{x:1514,y:965,t:1527268613490};\\\", \\\"{x:1512,y:967,t:1527268613507};\\\", \\\"{x:1511,y:967,t:1527268613524};\\\", \\\"{x:1510,y:968,t:1527268613568};\\\", \\\"{x:1509,y:968,t:1527268613592};\\\", \\\"{x:1509,y:969,t:1527268613632};\\\", \\\"{x:1509,y:970,t:1527268613672};\\\", \\\"{x:1511,y:971,t:1527268613680};\\\", \\\"{x:1514,y:972,t:1527268613691};\\\", \\\"{x:1527,y:975,t:1527268613707};\\\", \\\"{x:1534,y:976,t:1527268613724};\\\", \\\"{x:1541,y:977,t:1527268613740};\\\", \\\"{x:1548,y:977,t:1527268613757};\\\", \\\"{x:1552,y:977,t:1527268613774};\\\", \\\"{x:1555,y:977,t:1527268613791};\\\", \\\"{x:1556,y:977,t:1527268613806};\\\", \\\"{x:1558,y:977,t:1527268613824};\\\", \\\"{x:1555,y:977,t:1527268614024};\\\", \\\"{x:1547,y:975,t:1527268614041};\\\", \\\"{x:1540,y:974,t:1527268614058};\\\", \\\"{x:1529,y:973,t:1527268614074};\\\", \\\"{x:1522,y:973,t:1527268614091};\\\", \\\"{x:1517,y:973,t:1527268614108};\\\", \\\"{x:1514,y:973,t:1527268614124};\\\", \\\"{x:1510,y:973,t:1527268614141};\\\", \\\"{x:1507,y:973,t:1527268614158};\\\", \\\"{x:1502,y:973,t:1527268614173};\\\", \\\"{x:1498,y:973,t:1527268614191};\\\", \\\"{x:1493,y:974,t:1527268614208};\\\", \\\"{x:1490,y:974,t:1527268614224};\\\", \\\"{x:1489,y:974,t:1527268614241};\\\", \\\"{x:1486,y:974,t:1527268614258};\\\", \\\"{x:1484,y:975,t:1527268614275};\\\", \\\"{x:1481,y:975,t:1527268614291};\\\", \\\"{x:1479,y:975,t:1527268614308};\\\", \\\"{x:1477,y:976,t:1527268614325};\\\", \\\"{x:1474,y:976,t:1527268614341};\\\", \\\"{x:1470,y:976,t:1527268614358};\\\", \\\"{x:1466,y:976,t:1527268614375};\\\", \\\"{x:1463,y:976,t:1527268614391};\\\", \\\"{x:1461,y:976,t:1527268614408};\\\", \\\"{x:1460,y:976,t:1527268614424};\\\", \\\"{x:1457,y:976,t:1527268614441};\\\", \\\"{x:1456,y:976,t:1527268614458};\\\", \\\"{x:1451,y:976,t:1527268614475};\\\", \\\"{x:1447,y:976,t:1527268614491};\\\", \\\"{x:1443,y:976,t:1527268614508};\\\", \\\"{x:1440,y:976,t:1527268614525};\\\", \\\"{x:1438,y:976,t:1527268614541};\\\", \\\"{x:1436,y:976,t:1527268614558};\\\", \\\"{x:1433,y:976,t:1527268614575};\\\", \\\"{x:1431,y:976,t:1527268614591};\\\", \\\"{x:1428,y:976,t:1527268614608};\\\", \\\"{x:1427,y:976,t:1527268614625};\\\", \\\"{x:1426,y:976,t:1527268614640};\\\", \\\"{x:1423,y:976,t:1527268614658};\\\", \\\"{x:1421,y:976,t:1527268614675};\\\", \\\"{x:1420,y:976,t:1527268614696};\\\", \\\"{x:1418,y:976,t:1527268614727};\\\", \\\"{x:1417,y:976,t:1527268614751};\\\", \\\"{x:1415,y:976,t:1527268614767};\\\", \\\"{x:1414,y:976,t:1527268614791};\\\", \\\"{x:1412,y:976,t:1527268614831};\\\", \\\"{x:1411,y:976,t:1527268614928};\\\", \\\"{x:1410,y:976,t:1527268614942};\\\", \\\"{x:1409,y:976,t:1527268618924};\\\", \\\"{x:1408,y:976,t:1527268618932};\\\", \\\"{x:1408,y:974,t:1527268618949};\\\", \\\"{x:1408,y:973,t:1527268618980};\\\", \\\"{x:1407,y:970,t:1527268621923};\\\", \\\"{x:1404,y:966,t:1527268621936};\\\", \\\"{x:1400,y:957,t:1527268621952};\\\", \\\"{x:1398,y:951,t:1527268621969};\\\", \\\"{x:1396,y:945,t:1527268621985};\\\", \\\"{x:1395,y:941,t:1527268622002};\\\", \\\"{x:1394,y:936,t:1527268622019};\\\", \\\"{x:1393,y:931,t:1527268622035};\\\", \\\"{x:1392,y:928,t:1527268622051};\\\", \\\"{x:1392,y:927,t:1527268622084};\\\", \\\"{x:1392,y:925,t:1527268622099};\\\", \\\"{x:1392,y:922,t:1527268622106};\\\", \\\"{x:1392,y:920,t:1527268622118};\\\", \\\"{x:1392,y:914,t:1527268622134};\\\", \\\"{x:1392,y:909,t:1527268622151};\\\", \\\"{x:1392,y:905,t:1527268622168};\\\", \\\"{x:1392,y:899,t:1527268622185};\\\", \\\"{x:1391,y:897,t:1527268622201};\\\", \\\"{x:1391,y:895,t:1527268622218};\\\", \\\"{x:1391,y:894,t:1527268622235};\\\", \\\"{x:1391,y:893,t:1527268622251};\\\", \\\"{x:1389,y:891,t:1527268622516};\\\", \\\"{x:1386,y:891,t:1527268622524};\\\", \\\"{x:1384,y:891,t:1527268622536};\\\", \\\"{x:1381,y:891,t:1527268622552};\\\", \\\"{x:1379,y:891,t:1527268622569};\\\", \\\"{x:1378,y:891,t:1527268622586};\\\", \\\"{x:1377,y:891,t:1527268622628};\\\", \\\"{x:1376,y:892,t:1527268622724};\\\", \\\"{x:1375,y:893,t:1527268622779};\\\", \\\"{x:1375,y:895,t:1527268622802};\\\", \\\"{x:1374,y:896,t:1527268622827};\\\", \\\"{x:1373,y:898,t:1527268622835};\\\", \\\"{x:1372,y:899,t:1527268622852};\\\", \\\"{x:1371,y:900,t:1527268622869};\\\", \\\"{x:1371,y:901,t:1527268622886};\\\", \\\"{x:1371,y:902,t:1527268622903};\\\", \\\"{x:1371,y:903,t:1527268622931};\\\", \\\"{x:1371,y:904,t:1527268622940};\\\", \\\"{x:1371,y:905,t:1527268622952};\\\", \\\"{x:1371,y:907,t:1527268622969};\\\", \\\"{x:1371,y:908,t:1527268622986};\\\", \\\"{x:1371,y:910,t:1527268623003};\\\", \\\"{x:1371,y:911,t:1527268623236};\\\", \\\"{x:1372,y:911,t:1527268623348};\\\", \\\"{x:1373,y:907,t:1527268623355};\\\", \\\"{x:1374,y:906,t:1527268623370};\\\", \\\"{x:1375,y:902,t:1527268623386};\\\", \\\"{x:1376,y:900,t:1527268623403};\\\", \\\"{x:1377,y:899,t:1527268623437};\\\", \\\"{x:1377,y:895,t:1527268624388};\\\", \\\"{x:1380,y:888,t:1527268624405};\\\", \\\"{x:1381,y:882,t:1527268624421};\\\", \\\"{x:1382,y:879,t:1527268624436};\\\", \\\"{x:1384,y:876,t:1527268624454};\\\", \\\"{x:1384,y:874,t:1527268624471};\\\", \\\"{x:1384,y:873,t:1527268624486};\\\", \\\"{x:1384,y:871,t:1527268624504};\\\", \\\"{x:1384,y:870,t:1527268624521};\\\", \\\"{x:1384,y:868,t:1527268625003};\\\", \\\"{x:1389,y:864,t:1527268625021};\\\", \\\"{x:1392,y:862,t:1527268625038};\\\", \\\"{x:1398,y:858,t:1527268625056};\\\", \\\"{x:1409,y:848,t:1527268625071};\\\", \\\"{x:1423,y:839,t:1527268625088};\\\", \\\"{x:1439,y:828,t:1527268625105};\\\", \\\"{x:1449,y:822,t:1527268625121};\\\", \\\"{x:1456,y:818,t:1527268625138};\\\", \\\"{x:1465,y:814,t:1527268625155};\\\", \\\"{x:1468,y:814,t:1527268625171};\\\", \\\"{x:1471,y:813,t:1527268625188};\\\", \\\"{x:1473,y:813,t:1527268625212};\\\", \\\"{x:1474,y:812,t:1527268625227};\\\", \\\"{x:1475,y:812,t:1527268625300};\\\", \\\"{x:1473,y:812,t:1527268625627};\\\", \\\"{x:1469,y:812,t:1527268625639};\\\", \\\"{x:1459,y:812,t:1527268625655};\\\", \\\"{x:1450,y:812,t:1527268625672};\\\", \\\"{x:1445,y:812,t:1527268625689};\\\", \\\"{x:1443,y:812,t:1527268625705};\\\", \\\"{x:1442,y:812,t:1527268625722};\\\", \\\"{x:1441,y:812,t:1527268625748};\\\", \\\"{x:1440,y:812,t:1527268625948};\\\", \\\"{x:1439,y:812,t:1527268625955};\\\", \\\"{x:1435,y:812,t:1527268625972};\\\", \\\"{x:1430,y:813,t:1527268625990};\\\", \\\"{x:1424,y:814,t:1527268626005};\\\", \\\"{x:1419,y:815,t:1527268626022};\\\", \\\"{x:1416,y:815,t:1527268626039};\\\", \\\"{x:1415,y:816,t:1527268626060};\\\", \\\"{x:1414,y:816,t:1527268626072};\\\", \\\"{x:1412,y:818,t:1527268626090};\\\", \\\"{x:1411,y:818,t:1527268626140};\\\", \\\"{x:1409,y:818,t:1527268626156};\\\", \\\"{x:1407,y:819,t:1527268626172};\\\", \\\"{x:1405,y:819,t:1527268626189};\\\", \\\"{x:1403,y:819,t:1527268626206};\\\", \\\"{x:1401,y:819,t:1527268626222};\\\", \\\"{x:1399,y:820,t:1527268626240};\\\", \\\"{x:1398,y:820,t:1527268626256};\\\", \\\"{x:1396,y:820,t:1527268626272};\\\", \\\"{x:1394,y:820,t:1527268626289};\\\", \\\"{x:1393,y:820,t:1527268626306};\\\", \\\"{x:1391,y:820,t:1527268626322};\\\", \\\"{x:1390,y:820,t:1527268626347};\\\", \\\"{x:1389,y:820,t:1527268626412};\\\", \\\"{x:1388,y:820,t:1527268626422};\\\", \\\"{x:1387,y:820,t:1527268626508};\\\", \\\"{x:1385,y:820,t:1527268626531};\\\", \\\"{x:1384,y:819,t:1527268626539};\\\", \\\"{x:1383,y:817,t:1527268626556};\\\", \\\"{x:1382,y:817,t:1527268626573};\\\", \\\"{x:1382,y:816,t:1527268626589};\\\", \\\"{x:1381,y:814,t:1527268626606};\\\", \\\"{x:1380,y:812,t:1527268626623};\\\", \\\"{x:1379,y:811,t:1527268626640};\\\", \\\"{x:1377,y:808,t:1527268626656};\\\", \\\"{x:1374,y:803,t:1527268626673};\\\", \\\"{x:1373,y:801,t:1527268626689};\\\", \\\"{x:1371,y:798,t:1527268626707};\\\", \\\"{x:1367,y:793,t:1527268626723};\\\", \\\"{x:1363,y:789,t:1527268626739};\\\", \\\"{x:1359,y:784,t:1527268626757};\\\", \\\"{x:1357,y:782,t:1527268626774};\\\", \\\"{x:1355,y:780,t:1527268626790};\\\", \\\"{x:1354,y:779,t:1527268626806};\\\", \\\"{x:1353,y:778,t:1527268626835};\\\", \\\"{x:1352,y:777,t:1527268626843};\\\", \\\"{x:1352,y:776,t:1527268626859};\\\", \\\"{x:1350,y:774,t:1527268626875};\\\", \\\"{x:1350,y:773,t:1527268626899};\\\", \\\"{x:1350,y:771,t:1527268626932};\\\", \\\"{x:1349,y:771,t:1527268626940};\\\", \\\"{x:1349,y:770,t:1527268626956};\\\", \\\"{x:1349,y:768,t:1527268626988};\\\", \\\"{x:1347,y:767,t:1527268627011};\\\", \\\"{x:1347,y:765,t:1527268627099};\\\", \\\"{x:1347,y:764,t:1527268627147};\\\", \\\"{x:1347,y:763,t:1527268627243};\\\", \\\"{x:1347,y:762,t:1527268627258};\\\", \\\"{x:1346,y:762,t:1527268627306};\\\", \\\"{x:1346,y:761,t:1527268627338};\\\", \\\"{x:1346,y:759,t:1527268628091};\\\", \\\"{x:1347,y:756,t:1527268628108};\\\", \\\"{x:1347,y:754,t:1527268628124};\\\", \\\"{x:1348,y:752,t:1527268628141};\\\", \\\"{x:1349,y:751,t:1527268628157};\\\", \\\"{x:1349,y:754,t:1527268628291};\\\", \\\"{x:1349,y:759,t:1527268628307};\\\", \\\"{x:1347,y:768,t:1527268628324};\\\", \\\"{x:1346,y:775,t:1527268628341};\\\", \\\"{x:1345,y:780,t:1527268628357};\\\", \\\"{x:1345,y:782,t:1527268628373};\\\", \\\"{x:1345,y:783,t:1527268628391};\\\", \\\"{x:1345,y:785,t:1527268628408};\\\", \\\"{x:1345,y:786,t:1527268628424};\\\", \\\"{x:1343,y:788,t:1527268628441};\\\", \\\"{x:1343,y:791,t:1527268628458};\\\", \\\"{x:1343,y:793,t:1527268628474};\\\", \\\"{x:1342,y:800,t:1527268628491};\\\", \\\"{x:1342,y:803,t:1527268628507};\\\", \\\"{x:1342,y:804,t:1527268628524};\\\", \\\"{x:1342,y:803,t:1527268628627};\\\", \\\"{x:1342,y:799,t:1527268628641};\\\", \\\"{x:1343,y:792,t:1527268628658};\\\", \\\"{x:1343,y:787,t:1527268628674};\\\", \\\"{x:1344,y:780,t:1527268628692};\\\", \\\"{x:1345,y:774,t:1527268628708};\\\", \\\"{x:1346,y:771,t:1527268628725};\\\", \\\"{x:1346,y:769,t:1527268628741};\\\", \\\"{x:1339,y:768,t:1527268628980};\\\", \\\"{x:1324,y:768,t:1527268628991};\\\", \\\"{x:1285,y:768,t:1527268629009};\\\", \\\"{x:1198,y:766,t:1527268629025};\\\", \\\"{x:1115,y:757,t:1527268629041};\\\", \\\"{x:1018,y:745,t:1527268629058};\\\", \\\"{x:894,y:713,t:1527268629075};\\\", \\\"{x:849,y:698,t:1527268629092};\\\", \\\"{x:807,y:685,t:1527268629108};\\\", \\\"{x:781,y:677,t:1527268629125};\\\", \\\"{x:756,y:671,t:1527268629142};\\\", \\\"{x:734,y:664,t:1527268629158};\\\", \\\"{x:709,y:655,t:1527268629175};\\\", \\\"{x:678,y:645,t:1527268629192};\\\", \\\"{x:648,y:636,t:1527268629208};\\\", \\\"{x:607,y:626,t:1527268629225};\\\", \\\"{x:556,y:611,t:1527268629241};\\\", \\\"{x:517,y:599,t:1527268629253};\\\", \\\"{x:464,y:584,t:1527268629270};\\\", \\\"{x:420,y:574,t:1527268629287};\\\", \\\"{x:367,y:558,t:1527268629306};\\\", \\\"{x:278,y:541,t:1527268629323};\\\", \\\"{x:233,y:536,t:1527268629340};\\\", \\\"{x:194,y:530,t:1527268629356};\\\", \\\"{x:162,y:526,t:1527268629372};\\\", \\\"{x:134,y:522,t:1527268629390};\\\", \\\"{x:113,y:518,t:1527268629407};\\\", \\\"{x:97,y:516,t:1527268629424};\\\", \\\"{x:89,y:516,t:1527268629439};\\\", \\\"{x:87,y:516,t:1527268629456};\\\", \\\"{x:86,y:516,t:1527268629473};\\\", \\\"{x:85,y:517,t:1527268629555};\\\", \\\"{x:90,y:520,t:1527268629564};\\\", \\\"{x:95,y:521,t:1527268629572};\\\", \\\"{x:104,y:524,t:1527268629590};\\\", \\\"{x:116,y:529,t:1527268629608};\\\", \\\"{x:127,y:533,t:1527268629624};\\\", \\\"{x:130,y:533,t:1527268629640};\\\", \\\"{x:131,y:533,t:1527268629683};\\\", \\\"{x:132,y:533,t:1527268629707};\\\", \\\"{x:134,y:533,t:1527268629747};\\\", \\\"{x:135,y:533,t:1527268629771};\\\", \\\"{x:136,y:533,t:1527268630284};\\\", \\\"{x:144,y:533,t:1527268630291};\\\", \\\"{x:165,y:540,t:1527268630307};\\\", \\\"{x:184,y:545,t:1527268630324};\\\", \\\"{x:199,y:553,t:1527268630341};\\\", \\\"{x:204,y:555,t:1527268630356};\\\", \\\"{x:205,y:556,t:1527268630379};\\\", \\\"{x:206,y:556,t:1527268630418};\\\", \\\"{x:207,y:556,t:1527268630651};\\\", \\\"{x:208,y:556,t:1527268630683};\\\", \\\"{x:209,y:556,t:1527268630707};\\\", \\\"{x:211,y:557,t:1527268630731};\\\", \\\"{x:213,y:557,t:1527268630771};\\\", \\\"{x:215,y:558,t:1527268630779};\\\", \\\"{x:218,y:558,t:1527268630791};\\\", \\\"{x:223,y:561,t:1527268630808};\\\", \\\"{x:233,y:564,t:1527268630826};\\\", \\\"{x:245,y:567,t:1527268630841};\\\", \\\"{x:259,y:570,t:1527268630858};\\\", \\\"{x:276,y:575,t:1527268630875};\\\", \\\"{x:304,y:580,t:1527268630890};\\\", \\\"{x:325,y:584,t:1527268630908};\\\", \\\"{x:343,y:588,t:1527268630923};\\\", \\\"{x:364,y:590,t:1527268630941};\\\", \\\"{x:375,y:593,t:1527268630958};\\\", \\\"{x:383,y:594,t:1527268630975};\\\", \\\"{x:386,y:594,t:1527268630991};\\\", \\\"{x:388,y:594,t:1527268631008};\\\", \\\"{x:389,y:594,t:1527268631024};\\\", \\\"{x:391,y:594,t:1527268631040};\\\", \\\"{x:392,y:594,t:1527268631058};\\\", \\\"{x:397,y:596,t:1527268631075};\\\", \\\"{x:403,y:596,t:1527268631091};\\\", \\\"{x:410,y:597,t:1527268631108};\\\", \\\"{x:420,y:600,t:1527268631125};\\\", \\\"{x:433,y:605,t:1527268631142};\\\", \\\"{x:448,y:608,t:1527268631158};\\\", \\\"{x:461,y:612,t:1527268631175};\\\", \\\"{x:472,y:614,t:1527268631191};\\\", \\\"{x:480,y:615,t:1527268631207};\\\", \\\"{x:489,y:617,t:1527268631225};\\\", \\\"{x:502,y:620,t:1527268631242};\\\", \\\"{x:515,y:624,t:1527268631257};\\\", \\\"{x:547,y:632,t:1527268631275};\\\", \\\"{x:570,y:642,t:1527268631291};\\\", \\\"{x:597,y:649,t:1527268631307};\\\", \\\"{x:631,y:659,t:1527268631325};\\\", \\\"{x:657,y:666,t:1527268631341};\\\", \\\"{x:674,y:672,t:1527268631358};\\\", \\\"{x:689,y:676,t:1527268631375};\\\", \\\"{x:696,y:677,t:1527268631392};\\\", \\\"{x:699,y:677,t:1527268631408};\\\", \\\"{x:700,y:677,t:1527268631435};\\\", \\\"{x:702,y:677,t:1527268631451};\\\", \\\"{x:705,y:678,t:1527268631467};\\\", \\\"{x:706,y:678,t:1527268631476};\\\", \\\"{x:708,y:680,t:1527268631491};\\\", \\\"{x:705,y:680,t:1527268631524};\\\", \\\"{x:694,y:680,t:1527268631531};\\\", \\\"{x:679,y:677,t:1527268631542};\\\", \\\"{x:608,y:654,t:1527268631558};\\\", \\\"{x:504,y:613,t:1527268631576};\\\", \\\"{x:379,y:570,t:1527268631592};\\\", \\\"{x:281,y:536,t:1527268631608};\\\", \\\"{x:223,y:513,t:1527268631625};\\\", \\\"{x:206,y:507,t:1527268631641};\\\", \\\"{x:202,y:506,t:1527268631658};\\\", \\\"{x:201,y:506,t:1527268631674};\\\", \\\"{x:198,y:506,t:1527268631723};\\\", \\\"{x:195,y:509,t:1527268631730};\\\", \\\"{x:190,y:511,t:1527268631742};\\\", \\\"{x:179,y:515,t:1527268631758};\\\", \\\"{x:170,y:520,t:1527268631776};\\\", \\\"{x:164,y:523,t:1527268631792};\\\", \\\"{x:161,y:526,t:1527268631809};\\\", \\\"{x:159,y:527,t:1527268631824};\\\", \\\"{x:158,y:529,t:1527268631842};\\\", \\\"{x:152,y:534,t:1527268631859};\\\", \\\"{x:146,y:538,t:1527268631875};\\\", \\\"{x:139,y:542,t:1527268631892};\\\", \\\"{x:135,y:545,t:1527268631907};\\\", \\\"{x:134,y:546,t:1527268631924};\\\", \\\"{x:133,y:546,t:1527268631942};\\\", \\\"{x:134,y:547,t:1527268632147};\\\", \\\"{x:138,y:547,t:1527268632158};\\\", \\\"{x:143,y:547,t:1527268632175};\\\", \\\"{x:146,y:547,t:1527268632192};\\\", \\\"{x:147,y:546,t:1527268632208};\\\", \\\"{x:149,y:544,t:1527268632225};\\\", \\\"{x:150,y:543,t:1527268632241};\\\", \\\"{x:154,y:541,t:1527268632258};\\\", \\\"{x:157,y:539,t:1527268632275};\\\", \\\"{x:160,y:538,t:1527268632291};\\\", \\\"{x:160,y:537,t:1527268632309};\\\", \\\"{x:163,y:537,t:1527268632562};\\\", \\\"{x:167,y:535,t:1527268632576};\\\", \\\"{x:170,y:535,t:1527268632592};\\\", \\\"{x:171,y:535,t:1527268632608};\\\", \\\"{x:174,y:535,t:1527268632626};\\\", \\\"{x:178,y:535,t:1527268632642};\\\", \\\"{x:184,y:535,t:1527268632659};\\\", \\\"{x:193,y:536,t:1527268632676};\\\", \\\"{x:204,y:537,t:1527268632692};\\\", \\\"{x:222,y:544,t:1527268632709};\\\", \\\"{x:244,y:551,t:1527268632726};\\\", \\\"{x:271,y:558,t:1527268632743};\\\", \\\"{x:313,y:571,t:1527268632759};\\\", \\\"{x:364,y:587,t:1527268632775};\\\", \\\"{x:425,y:604,t:1527268632793};\\\", \\\"{x:497,y:623,t:1527268632809};\\\", \\\"{x:594,y:653,t:1527268632826};\\\", \\\"{x:773,y:699,t:1527268632843};\\\", \\\"{x:895,y:735,t:1527268632859};\\\", \\\"{x:1008,y:761,t:1527268632876};\\\", \\\"{x:1107,y:785,t:1527268632893};\\\", \\\"{x:1179,y:807,t:1527268632909};\\\", \\\"{x:1227,y:821,t:1527268632927};\\\", \\\"{x:1257,y:828,t:1527268632943};\\\", \\\"{x:1286,y:834,t:1527268632960};\\\", \\\"{x:1309,y:839,t:1527268632976};\\\", \\\"{x:1324,y:840,t:1527268632993};\\\", \\\"{x:1336,y:843,t:1527268633010};\\\", \\\"{x:1350,y:845,t:1527268633026};\\\", \\\"{x:1365,y:845,t:1527268633042};\\\", \\\"{x:1371,y:845,t:1527268633060};\\\", \\\"{x:1374,y:845,t:1527268633076};\\\", \\\"{x:1375,y:844,t:1527268633123};\\\", \\\"{x:1375,y:843,t:1527268633132};\\\", \\\"{x:1375,y:840,t:1527268633144};\\\", \\\"{x:1375,y:835,t:1527268633160};\\\", \\\"{x:1371,y:829,t:1527268633177};\\\", \\\"{x:1369,y:826,t:1527268633193};\\\", \\\"{x:1368,y:824,t:1527268633210};\\\", \\\"{x:1366,y:822,t:1527268633227};\\\", \\\"{x:1365,y:822,t:1527268633243};\\\", \\\"{x:1365,y:821,t:1527268633261};\\\", \\\"{x:1364,y:817,t:1527268633278};\\\", \\\"{x:1363,y:814,t:1527268633294};\\\", \\\"{x:1362,y:810,t:1527268633310};\\\", \\\"{x:1361,y:807,t:1527268633327};\\\", \\\"{x:1361,y:801,t:1527268633343};\\\", \\\"{x:1358,y:796,t:1527268633360};\\\", \\\"{x:1357,y:793,t:1527268633378};\\\", \\\"{x:1356,y:792,t:1527268633395};\\\", \\\"{x:1355,y:791,t:1527268633411};\\\", \\\"{x:1355,y:788,t:1527268633428};\\\", \\\"{x:1355,y:782,t:1527268633444};\\\", \\\"{x:1352,y:776,t:1527268633461};\\\", \\\"{x:1352,y:772,t:1527268633478};\\\", \\\"{x:1351,y:769,t:1527268633495};\\\", \\\"{x:1351,y:768,t:1527268633510};\\\", \\\"{x:1351,y:766,t:1527268633555};\\\", \\\"{x:1349,y:765,t:1527268633587};\\\", \\\"{x:1349,y:764,t:1527268634380};\\\", \\\"{x:1349,y:763,t:1527268634395};\\\", \\\"{x:1349,y:762,t:1527268634412};\\\", \\\"{x:1349,y:760,t:1527268634443};\\\", \\\"{x:1349,y:758,t:1527268635299};\\\", \\\"{x:1349,y:755,t:1527268635314};\\\", \\\"{x:1351,y:748,t:1527268635331};\\\", \\\"{x:1351,y:734,t:1527268635347};\\\", \\\"{x:1351,y:728,t:1527268635363};\\\", \\\"{x:1352,y:725,t:1527268635381};\\\", \\\"{x:1352,y:721,t:1527268635397};\\\", \\\"{x:1352,y:720,t:1527268635413};\\\", \\\"{x:1353,y:719,t:1527268635430};\\\", \\\"{x:1353,y:718,t:1527268635451};\\\", \\\"{x:1354,y:717,t:1527268635464};\\\", \\\"{x:1354,y:716,t:1527268635491};\\\", \\\"{x:1354,y:714,t:1527268635540};\\\", \\\"{x:1354,y:713,t:1527268635547};\\\", \\\"{x:1354,y:712,t:1527268635571};\\\", \\\"{x:1354,y:711,t:1527268635581};\\\", \\\"{x:1354,y:709,t:1527268635598};\\\", \\\"{x:1354,y:707,t:1527268635615};\\\", \\\"{x:1354,y:706,t:1527268635631};\\\", \\\"{x:1354,y:705,t:1527268635648};\\\", \\\"{x:1354,y:703,t:1527268635665};\\\", \\\"{x:1354,y:702,t:1527268635681};\\\", \\\"{x:1354,y:701,t:1527268635699};\\\", \\\"{x:1354,y:700,t:1527268635715};\\\", \\\"{x:1352,y:700,t:1527268636308};\\\", \\\"{x:1348,y:704,t:1527268636316};\\\", \\\"{x:1342,y:713,t:1527268636333};\\\", \\\"{x:1335,y:724,t:1527268636349};\\\", \\\"{x:1331,y:736,t:1527268636366};\\\", \\\"{x:1328,y:747,t:1527268636382};\\\", \\\"{x:1327,y:753,t:1527268636399};\\\", \\\"{x:1325,y:758,t:1527268636416};\\\", \\\"{x:1325,y:760,t:1527268636433};\\\", \\\"{x:1325,y:762,t:1527268636448};\\\", \\\"{x:1324,y:763,t:1527268636466};\\\", \\\"{x:1324,y:765,t:1527268636482};\\\", \\\"{x:1324,y:766,t:1527268636500};\\\", \\\"{x:1324,y:767,t:1527268636579};\\\", \\\"{x:1324,y:768,t:1527268636588};\\\", \\\"{x:1322,y:768,t:1527268636600};\\\", \\\"{x:1308,y:769,t:1527268636616};\\\", \\\"{x:1289,y:769,t:1527268636633};\\\", \\\"{x:1266,y:774,t:1527268636649};\\\", \\\"{x:1244,y:776,t:1527268636665};\\\", \\\"{x:1231,y:777,t:1527268636683};\\\", \\\"{x:1219,y:780,t:1527268636699};\\\", \\\"{x:1214,y:780,t:1527268636717};\\\", \\\"{x:1210,y:781,t:1527268636733};\\\", \\\"{x:1206,y:783,t:1527268636750};\\\", \\\"{x:1202,y:784,t:1527268636767};\\\", \\\"{x:1200,y:785,t:1527268636783};\\\", \\\"{x:1199,y:786,t:1527268636799};\\\", \\\"{x:1199,y:787,t:1527268636892};\\\", \\\"{x:1199,y:789,t:1527268636907};\\\", \\\"{x:1199,y:790,t:1527268636917};\\\", \\\"{x:1200,y:795,t:1527268636934};\\\", \\\"{x:1207,y:805,t:1527268636950};\\\", \\\"{x:1213,y:813,t:1527268636967};\\\", \\\"{x:1219,y:820,t:1527268636984};\\\", \\\"{x:1223,y:823,t:1527268636999};\\\", \\\"{x:1224,y:824,t:1527268637019};\\\", \\\"{x:1224,y:825,t:1527268637083};\\\", \\\"{x:1224,y:826,t:1527268637101};\\\", \\\"{x:1224,y:827,t:1527268637117};\\\", \\\"{x:1224,y:828,t:1527268637134};\\\", \\\"{x:1223,y:828,t:1527268637787};\\\", \\\"{x:1221,y:829,t:1527268637801};\\\", \\\"{x:1220,y:830,t:1527268637876};\\\", \\\"{x:1220,y:831,t:1527268638003};\\\", \\\"{x:1222,y:830,t:1527268638428};\\\", \\\"{x:1224,y:830,t:1527268638435};\\\", \\\"{x:1227,y:829,t:1527268638452};\\\", \\\"{x:1229,y:829,t:1527268638468};\\\", \\\"{x:1231,y:827,t:1527268638485};\\\", \\\"{x:1237,y:827,t:1527268638503};\\\", \\\"{x:1243,y:825,t:1527268638519};\\\", \\\"{x:1252,y:823,t:1527268638536};\\\", \\\"{x:1262,y:822,t:1527268638553};\\\", \\\"{x:1268,y:821,t:1527268638569};\\\", \\\"{x:1277,y:821,t:1527268638586};\\\", \\\"{x:1282,y:819,t:1527268638603};\\\", \\\"{x:1301,y:814,t:1527268638620};\\\", \\\"{x:1310,y:811,t:1527268638636};\\\", \\\"{x:1318,y:807,t:1527268638653};\\\", \\\"{x:1326,y:803,t:1527268638670};\\\", \\\"{x:1338,y:797,t:1527268638686};\\\", \\\"{x:1356,y:789,t:1527268638703};\\\", \\\"{x:1372,y:782,t:1527268638720};\\\", \\\"{x:1387,y:770,t:1527268638736};\\\", \\\"{x:1405,y:748,t:1527268638753};\\\", \\\"{x:1433,y:707,t:1527268638770};\\\", \\\"{x:1451,y:690,t:1527268638787};\\\", \\\"{x:1462,y:674,t:1527268638803};\\\", \\\"{x:1465,y:666,t:1527268638820};\\\", \\\"{x:1467,y:656,t:1527268638837};\\\", \\\"{x:1470,y:647,t:1527268638853};\\\", \\\"{x:1472,y:640,t:1527268638870};\\\", \\\"{x:1473,y:635,t:1527268638887};\\\", \\\"{x:1474,y:632,t:1527268638902};\\\", \\\"{x:1475,y:631,t:1527268638920};\\\", \\\"{x:1475,y:629,t:1527268638937};\\\", \\\"{x:1475,y:628,t:1527268638952};\\\", \\\"{x:1475,y:627,t:1527268638979};\\\", \\\"{x:1475,y:626,t:1527268639036};\\\", \\\"{x:1473,y:626,t:1527268639054};\\\", \\\"{x:1470,y:626,t:1527268639070};\\\", \\\"{x:1468,y:626,t:1527268639087};\\\", \\\"{x:1467,y:626,t:1527268639103};\\\", \\\"{x:1465,y:627,t:1527268639120};\\\", \\\"{x:1464,y:628,t:1527268639136};\\\", \\\"{x:1462,y:628,t:1527268639153};\\\", \\\"{x:1461,y:629,t:1527268639170};\\\", \\\"{x:1460,y:629,t:1527268639195};\\\", \\\"{x:1459,y:629,t:1527268639276};\\\", \\\"{x:1458,y:629,t:1527268639287};\\\", \\\"{x:1457,y:629,t:1527268639307};\\\", \\\"{x:1456,y:629,t:1527268639321};\\\", \\\"{x:1455,y:630,t:1527268639336};\\\", \\\"{x:1454,y:630,t:1527268639370};\\\", \\\"{x:1453,y:630,t:1527268639395};\\\", \\\"{x:1452,y:630,t:1527268639403};\\\", \\\"{x:1450,y:630,t:1527268639426};\\\", \\\"{x:1449,y:631,t:1527268639437};\\\", \\\"{x:1447,y:631,t:1527268639467};\\\", \\\"{x:1446,y:631,t:1527268639483};\\\", \\\"{x:1444,y:631,t:1527268639507};\\\", \\\"{x:1443,y:631,t:1527268639539};\\\", \\\"{x:1440,y:633,t:1527268641517};\\\", \\\"{x:1434,y:639,t:1527268641523};\\\", \\\"{x:1421,y:650,t:1527268641541};\\\", \\\"{x:1406,y:665,t:1527268641558};\\\", \\\"{x:1391,y:683,t:1527268641573};\\\", \\\"{x:1378,y:703,t:1527268641591};\\\", \\\"{x:1366,y:725,t:1527268641608};\\\", \\\"{x:1355,y:749,t:1527268641624};\\\", \\\"{x:1343,y:773,t:1527268641640};\\\", \\\"{x:1336,y:793,t:1527268641657};\\\", \\\"{x:1331,y:806,t:1527268641674};\\\", \\\"{x:1328,y:818,t:1527268641690};\\\", \\\"{x:1325,y:825,t:1527268641707};\\\", \\\"{x:1325,y:827,t:1527268641724};\\\", \\\"{x:1325,y:828,t:1527268641741};\\\", \\\"{x:1324,y:830,t:1527268641758};\\\", \\\"{x:1323,y:833,t:1527268641775};\\\", \\\"{x:1321,y:836,t:1527268641791};\\\", \\\"{x:1319,y:841,t:1527268641808};\\\", \\\"{x:1317,y:846,t:1527268641825};\\\", \\\"{x:1316,y:848,t:1527268641841};\\\", \\\"{x:1314,y:854,t:1527268641858};\\\", \\\"{x:1314,y:857,t:1527268641875};\\\", \\\"{x:1314,y:861,t:1527268641891};\\\", \\\"{x:1314,y:866,t:1527268641908};\\\", \\\"{x:1314,y:873,t:1527268641924};\\\", \\\"{x:1315,y:877,t:1527268641942};\\\", \\\"{x:1315,y:879,t:1527268641958};\\\", \\\"{x:1315,y:880,t:1527268641975};\\\", \\\"{x:1316,y:881,t:1527268641991};\\\", \\\"{x:1317,y:881,t:1527268642026};\\\", \\\"{x:1318,y:881,t:1527268642042};\\\", \\\"{x:1323,y:881,t:1527268642057};\\\", \\\"{x:1333,y:884,t:1527268642074};\\\", \\\"{x:1338,y:884,t:1527268642091};\\\", \\\"{x:1347,y:887,t:1527268642107};\\\", \\\"{x:1354,y:890,t:1527268642125};\\\", \\\"{x:1359,y:892,t:1527268642141};\\\", \\\"{x:1360,y:893,t:1527268642158};\\\", \\\"{x:1361,y:893,t:1527268642228};\\\", \\\"{x:1363,y:893,t:1527268642371};\\\", \\\"{x:1364,y:893,t:1527268642379};\\\", \\\"{x:1367,y:893,t:1527268642392};\\\", \\\"{x:1373,y:893,t:1527268642409};\\\", \\\"{x:1378,y:893,t:1527268642426};\\\", \\\"{x:1380,y:893,t:1527268642441};\\\", \\\"{x:1382,y:893,t:1527268642459};\\\", \\\"{x:1383,y:893,t:1527268642475};\\\", \\\"{x:1384,y:893,t:1527268642491};\\\", \\\"{x:1385,y:893,t:1527268642859};\\\", \\\"{x:1385,y:892,t:1527268642899};\\\", \\\"{x:1385,y:891,t:1527268642931};\\\", \\\"{x:1385,y:890,t:1527268643155};\\\", \\\"{x:1385,y:888,t:1527268643163};\\\", \\\"{x:1385,y:886,t:1527268643176};\\\", \\\"{x:1383,y:881,t:1527268643193};\\\", \\\"{x:1380,y:874,t:1527268643211};\\\", \\\"{x:1373,y:857,t:1527268643228};\\\", \\\"{x:1367,y:844,t:1527268643243};\\\", \\\"{x:1360,y:830,t:1527268643261};\\\", \\\"{x:1354,y:823,t:1527268643277};\\\", \\\"{x:1352,y:817,t:1527268643293};\\\", \\\"{x:1351,y:814,t:1527268643310};\\\", \\\"{x:1351,y:813,t:1527268643327};\\\", \\\"{x:1351,y:812,t:1527268643344};\\\", \\\"{x:1351,y:811,t:1527268643360};\\\", \\\"{x:1351,y:809,t:1527268643715};\\\", \\\"{x:1351,y:806,t:1527268643728};\\\", \\\"{x:1350,y:803,t:1527268643744};\\\", \\\"{x:1349,y:802,t:1527268643761};\\\", \\\"{x:1349,y:800,t:1527268643778};\\\", \\\"{x:1349,y:798,t:1527268643796};\\\", \\\"{x:1349,y:797,t:1527268643811};\\\", \\\"{x:1349,y:796,t:1527268643836};\\\", \\\"{x:1349,y:795,t:1527268643845};\\\", \\\"{x:1349,y:793,t:1527268643861};\\\", \\\"{x:1349,y:791,t:1527268643877};\\\", \\\"{x:1349,y:787,t:1527268643895};\\\", \\\"{x:1349,y:784,t:1527268643911};\\\", \\\"{x:1349,y:781,t:1527268643927};\\\", \\\"{x:1348,y:779,t:1527268643945};\\\", \\\"{x:1348,y:776,t:1527268643961};\\\", \\\"{x:1348,y:774,t:1527268643978};\\\", \\\"{x:1346,y:770,t:1527268643995};\\\", \\\"{x:1345,y:766,t:1527268644011};\\\", \\\"{x:1345,y:764,t:1527268644045};\\\", \\\"{x:1345,y:763,t:1527268644061};\\\", \\\"{x:1345,y:761,t:1527268644091};\\\", \\\"{x:1345,y:759,t:1527268644315};\\\", \\\"{x:1345,y:755,t:1527268644330};\\\", \\\"{x:1345,y:749,t:1527268644345};\\\", \\\"{x:1345,y:744,t:1527268644362};\\\", \\\"{x:1345,y:734,t:1527268644380};\\\", \\\"{x:1345,y:729,t:1527268644395};\\\", \\\"{x:1345,y:721,t:1527268644412};\\\", \\\"{x:1345,y:715,t:1527268644429};\\\", \\\"{x:1345,y:709,t:1527268644445};\\\", \\\"{x:1345,y:706,t:1527268644462};\\\", \\\"{x:1345,y:704,t:1527268644479};\\\", \\\"{x:1345,y:703,t:1527268644496};\\\", \\\"{x:1345,y:701,t:1527268644512};\\\", \\\"{x:1345,y:700,t:1527268644546};\\\", \\\"{x:1341,y:695,t:1527268646684};\\\", \\\"{x:1323,y:675,t:1527268646699};\\\", \\\"{x:1304,y:653,t:1527268646716};\\\", \\\"{x:1291,y:638,t:1527268646733};\\\", \\\"{x:1287,y:631,t:1527268646749};\\\", \\\"{x:1286,y:629,t:1527268646766};\\\", \\\"{x:1286,y:628,t:1527268646783};\\\", \\\"{x:1286,y:627,t:1527268646799};\\\", \\\"{x:1286,y:626,t:1527268646908};\\\", \\\"{x:1287,y:625,t:1527268646916};\\\", \\\"{x:1293,y:623,t:1527268646933};\\\", \\\"{x:1299,y:623,t:1527268646950};\\\", \\\"{x:1301,y:621,t:1527268646966};\\\", \\\"{x:1302,y:621,t:1527268646995};\\\", \\\"{x:1303,y:620,t:1527268647011};\\\", \\\"{x:1303,y:619,t:1527268647051};\\\", \\\"{x:1303,y:618,t:1527268647067};\\\", \\\"{x:1303,y:616,t:1527268647091};\\\", \\\"{x:1296,y:616,t:1527268647315};\\\", \\\"{x:1289,y:616,t:1527268647323};\\\", \\\"{x:1280,y:618,t:1527268647333};\\\", \\\"{x:1262,y:622,t:1527268647350};\\\", \\\"{x:1242,y:627,t:1527268647367};\\\", \\\"{x:1218,y:638,t:1527268647384};\\\", \\\"{x:1176,y:657,t:1527268647400};\\\", \\\"{x:1124,y:680,t:1527268647416};\\\", \\\"{x:1075,y:706,t:1527268647434};\\\", \\\"{x:1029,y:732,t:1527268647450};\\\", \\\"{x:978,y:761,t:1527268647466};\\\", \\\"{x:929,y:788,t:1527268647484};\\\", \\\"{x:885,y:806,t:1527268647499};\\\", \\\"{x:840,y:821,t:1527268647516};\\\", \\\"{x:804,y:829,t:1527268647534};\\\", \\\"{x:782,y:834,t:1527268647550};\\\", \\\"{x:765,y:837,t:1527268647567};\\\", \\\"{x:761,y:837,t:1527268647584};\\\", \\\"{x:753,y:837,t:1527268647600};\\\", \\\"{x:744,y:837,t:1527268647617};\\\", \\\"{x:730,y:835,t:1527268647634};\\\", \\\"{x:694,y:818,t:1527268647650};\\\", \\\"{x:657,y:797,t:1527268647667};\\\", \\\"{x:623,y:781,t:1527268647684};\\\", \\\"{x:600,y:768,t:1527268647700};\\\", \\\"{x:584,y:760,t:1527268647717};\\\", \\\"{x:568,y:750,t:1527268647733};\\\", \\\"{x:552,y:740,t:1527268647752};\\\", \\\"{x:534,y:731,t:1527268647767};\\\", \\\"{x:519,y:723,t:1527268647783};\\\", \\\"{x:507,y:717,t:1527268647799};\\\", \\\"{x:503,y:715,t:1527268647816};\\\", \\\"{x:502,y:714,t:1527268647833};\\\", \\\"{x:501,y:715,t:1527268648099};\\\", \\\"{x:498,y:720,t:1527268648117};\\\", \\\"{x:498,y:723,t:1527268648132};\\\", \\\"{x:498,y:725,t:1527268648155};\\\", \\\"{x:497,y:726,t:1527268648186};\\\", \\\"{x:498,y:726,t:1527268649266};\\\", \\\"{x:499,y:726,t:1527268649274};\\\", \\\"{x:500,y:726,t:1527268649322};\\\", \\\"{x:501,y:726,t:1527268649339};\\\", \\\"{x:502,y:726,t:1527268649370};\\\", \\\"{x:503,y:726,t:1527268649410};\\\", \\\"{x:505,y:726,t:1527268649424};\\\", \\\"{x:507,y:726,t:1527268649442};\\\", \\\"{x:508,y:726,t:1527268649457};\\\", \\\"{x:509,y:726,t:1527268649499};\\\", \\\"{x:510,y:725,t:1527268649525};\\\", \\\"{x:511,y:725,t:1527268649539};\\\", \\\"{x:512,y:725,t:1527268649586};\\\", \\\"{x:513,y:725,t:1527268649602};\\\" ] }, { \\\"rt\\\": 44769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 738059, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-M -J -B -B -O -C -C -E -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:724,t:1527268649717};\\\", \\\"{x:517,y:723,t:1527268649725};\\\", \\\"{x:518,y:723,t:1527268649746};\\\", \\\"{x:519,y:723,t:1527268649757};\\\", \\\"{x:520,y:723,t:1527268649778};\\\", \\\"{x:521,y:723,t:1527268649810};\\\", \\\"{x:523,y:722,t:1527268649826};\\\", \\\"{x:524,y:722,t:1527268649914};\\\", \\\"{x:526,y:722,t:1527268649924};\\\", \\\"{x:528,y:722,t:1527268649963};\\\", \\\"{x:529,y:721,t:1527268649978};\\\", \\\"{x:530,y:721,t:1527268650010};\\\", \\\"{x:531,y:721,t:1527268650083};\\\", \\\"{x:534,y:720,t:1527268650182};\\\", \\\"{x:535,y:720,t:1527268650242};\\\", \\\"{x:536,y:720,t:1527268650266};\\\", \\\"{x:536,y:719,t:1527268650274};\\\", \\\"{x:537,y:719,t:1527268650322};\\\", \\\"{x:538,y:719,t:1527268650346};\\\", \\\"{x:539,y:719,t:1527268650378};\\\", \\\"{x:540,y:719,t:1527268650391};\\\", \\\"{x:541,y:719,t:1527268650407};\\\", \\\"{x:544,y:718,t:1527268650423};\\\", \\\"{x:545,y:718,t:1527268650440};\\\", \\\"{x:549,y:718,t:1527268650458};\\\", \\\"{x:554,y:716,t:1527268650473};\\\", \\\"{x:559,y:716,t:1527268650491};\\\", \\\"{x:562,y:716,t:1527268650508};\\\", \\\"{x:568,y:716,t:1527268650524};\\\", \\\"{x:575,y:716,t:1527268650541};\\\", \\\"{x:586,y:716,t:1527268650557};\\\", \\\"{x:601,y:716,t:1527268650573};\\\", \\\"{x:618,y:716,t:1527268650591};\\\", \\\"{x:632,y:717,t:1527268650607};\\\", \\\"{x:645,y:719,t:1527268650623};\\\", \\\"{x:658,y:722,t:1527268650641};\\\", \\\"{x:668,y:724,t:1527268650658};\\\", \\\"{x:676,y:726,t:1527268650674};\\\", \\\"{x:691,y:730,t:1527268650690};\\\", \\\"{x:707,y:734,t:1527268650708};\\\", \\\"{x:717,y:736,t:1527268650724};\\\", \\\"{x:728,y:738,t:1527268650740};\\\", \\\"{x:735,y:740,t:1527268650758};\\\", \\\"{x:741,y:740,t:1527268650774};\\\", \\\"{x:748,y:740,t:1527268650791};\\\", \\\"{x:754,y:742,t:1527268650808};\\\", \\\"{x:758,y:742,t:1527268650824};\\\", \\\"{x:763,y:744,t:1527268650841};\\\", \\\"{x:764,y:744,t:1527268650858};\\\", \\\"{x:766,y:744,t:1527268650874};\\\", \\\"{x:767,y:744,t:1527268650891};\\\", \\\"{x:769,y:744,t:1527268650908};\\\", \\\"{x:772,y:744,t:1527268650924};\\\", \\\"{x:774,y:745,t:1527268650941};\\\", \\\"{x:776,y:745,t:1527268650958};\\\", \\\"{x:777,y:745,t:1527268650975};\\\", \\\"{x:778,y:745,t:1527268650991};\\\", \\\"{x:779,y:745,t:1527268651008};\\\", \\\"{x:780,y:745,t:1527268651025};\\\", \\\"{x:781,y:745,t:1527268651041};\\\", \\\"{x:782,y:745,t:1527268651059};\\\", \\\"{x:783,y:745,t:1527268651083};\\\", \\\"{x:784,y:745,t:1527268651132};\\\", \\\"{x:785,y:745,t:1527268651235};\\\", \\\"{x:786,y:745,t:1527268651251};\\\", \\\"{x:787,y:745,t:1527268651267};\\\", \\\"{x:788,y:745,t:1527268651291};\\\", \\\"{x:789,y:745,t:1527268651308};\\\", \\\"{x:791,y:747,t:1527268651324};\\\", \\\"{x:794,y:747,t:1527268651342};\\\", \\\"{x:798,y:748,t:1527268651358};\\\", \\\"{x:799,y:748,t:1527268651375};\\\", \\\"{x:801,y:748,t:1527268651392};\\\", \\\"{x:802,y:748,t:1527268651408};\\\", \\\"{x:803,y:748,t:1527268651427};\\\", \\\"{x:805,y:749,t:1527268651442};\\\", \\\"{x:807,y:750,t:1527268651459};\\\", \\\"{x:808,y:750,t:1527268651475};\\\", \\\"{x:812,y:752,t:1527268651492};\\\", \\\"{x:814,y:752,t:1527268651508};\\\", \\\"{x:816,y:754,t:1527268651525};\\\", \\\"{x:817,y:754,t:1527268651546};\\\", \\\"{x:817,y:755,t:1527268651558};\\\", \\\"{x:818,y:755,t:1527268651575};\\\", \\\"{x:819,y:756,t:1527268651592};\\\", \\\"{x:820,y:756,t:1527268651608};\\\", \\\"{x:822,y:757,t:1527268651625};\\\", \\\"{x:824,y:758,t:1527268651642};\\\", \\\"{x:826,y:758,t:1527268651658};\\\", \\\"{x:829,y:759,t:1527268651675};\\\", \\\"{x:831,y:761,t:1527268651692};\\\", \\\"{x:833,y:762,t:1527268651709};\\\", \\\"{x:834,y:762,t:1527268651739};\\\", \\\"{x:835,y:762,t:1527268651763};\\\", \\\"{x:835,y:763,t:1527268651775};\\\", \\\"{x:836,y:763,t:1527268651818};\\\", \\\"{x:837,y:763,t:1527268652003};\\\", \\\"{x:837,y:764,t:1527268652883};\\\", \\\"{x:839,y:765,t:1527268652898};\\\", \\\"{x:840,y:765,t:1527268652931};\\\", \\\"{x:842,y:765,t:1527268652947};\\\", \\\"{x:843,y:765,t:1527268652963};\\\", \\\"{x:844,y:765,t:1527268652976};\\\", \\\"{x:846,y:765,t:1527268652992};\\\", \\\"{x:848,y:765,t:1527268653009};\\\", \\\"{x:849,y:765,t:1527268653026};\\\", \\\"{x:851,y:765,t:1527268653043};\\\", \\\"{x:852,y:765,t:1527268653067};\\\", \\\"{x:853,y:765,t:1527268653083};\\\", \\\"{x:855,y:765,t:1527268653107};\\\", \\\"{x:856,y:765,t:1527268653131};\\\", \\\"{x:858,y:765,t:1527268653155};\\\", \\\"{x:859,y:765,t:1527268653338};\\\", \\\"{x:862,y:765,t:1527268653378};\\\", \\\"{x:864,y:765,t:1527268653394};\\\", \\\"{x:865,y:765,t:1527268653410};\\\", \\\"{x:870,y:766,t:1527268653426};\\\", \\\"{x:876,y:767,t:1527268653442};\\\", \\\"{x:878,y:769,t:1527268653459};\\\", \\\"{x:880,y:770,t:1527268653476};\\\", \\\"{x:883,y:771,t:1527268653493};\\\", \\\"{x:885,y:773,t:1527268653510};\\\", \\\"{x:887,y:775,t:1527268653527};\\\", \\\"{x:889,y:777,t:1527268653543};\\\", \\\"{x:890,y:779,t:1527268653560};\\\", \\\"{x:891,y:781,t:1527268653576};\\\", \\\"{x:893,y:783,t:1527268653593};\\\", \\\"{x:894,y:785,t:1527268653610};\\\", \\\"{x:898,y:788,t:1527268653627};\\\", \\\"{x:902,y:790,t:1527268653643};\\\", \\\"{x:908,y:793,t:1527268653660};\\\", \\\"{x:919,y:797,t:1527268653676};\\\", \\\"{x:933,y:805,t:1527268653693};\\\", \\\"{x:948,y:811,t:1527268653709};\\\", \\\"{x:979,y:825,t:1527268653727};\\\", \\\"{x:1005,y:838,t:1527268653743};\\\", \\\"{x:1060,y:862,t:1527268653760};\\\", \\\"{x:1123,y:888,t:1527268653777};\\\", \\\"{x:1181,y:912,t:1527268653793};\\\", \\\"{x:1217,y:928,t:1527268653810};\\\", \\\"{x:1263,y:952,t:1527268653827};\\\", \\\"{x:1283,y:963,t:1527268653844};\\\", \\\"{x:1299,y:970,t:1527268653861};\\\", \\\"{x:1306,y:972,t:1527268653878};\\\", \\\"{x:1309,y:972,t:1527268653894};\\\", \\\"{x:1316,y:973,t:1527268653911};\\\", \\\"{x:1326,y:978,t:1527268653927};\\\", \\\"{x:1348,y:990,t:1527268653944};\\\", \\\"{x:1381,y:1010,t:1527268653960};\\\", \\\"{x:1436,y:1042,t:1527268653978};\\\", \\\"{x:1488,y:1076,t:1527268653995};\\\", \\\"{x:1532,y:1101,t:1527268654010};\\\", \\\"{x:1558,y:1114,t:1527268654027};\\\", \\\"{x:1559,y:1115,t:1527268654044};\\\", \\\"{x:1559,y:1113,t:1527268654115};\\\", \\\"{x:1558,y:1111,t:1527268654127};\\\", \\\"{x:1553,y:1108,t:1527268654144};\\\", \\\"{x:1551,y:1106,t:1527268654160};\\\", \\\"{x:1546,y:1102,t:1527268654177};\\\", \\\"{x:1538,y:1098,t:1527268654194};\\\", \\\"{x:1534,y:1097,t:1527268654211};\\\", \\\"{x:1531,y:1095,t:1527268654227};\\\", \\\"{x:1529,y:1095,t:1527268654244};\\\", \\\"{x:1525,y:1093,t:1527268654260};\\\", \\\"{x:1520,y:1091,t:1527268654277};\\\", \\\"{x:1507,y:1085,t:1527268654294};\\\", \\\"{x:1488,y:1075,t:1527268654310};\\\", \\\"{x:1468,y:1067,t:1527268654327};\\\", \\\"{x:1451,y:1060,t:1527268654345};\\\", \\\"{x:1435,y:1053,t:1527268654360};\\\", \\\"{x:1427,y:1049,t:1527268654377};\\\", \\\"{x:1422,y:1048,t:1527268654394};\\\", \\\"{x:1421,y:1047,t:1527268654411};\\\", \\\"{x:1421,y:1046,t:1527268654948};\\\", \\\"{x:1421,y:1044,t:1527268654987};\\\", \\\"{x:1421,y:1043,t:1527268655011};\\\", \\\"{x:1421,y:1041,t:1527268655035};\\\", \\\"{x:1421,y:1039,t:1527268655045};\\\", \\\"{x:1420,y:1038,t:1527268655061};\\\", \\\"{x:1420,y:1036,t:1527268655078};\\\", \\\"{x:1420,y:1034,t:1527268655094};\\\", \\\"{x:1420,y:1032,t:1527268655111};\\\", \\\"{x:1420,y:1030,t:1527268655128};\\\", \\\"{x:1420,y:1028,t:1527268655147};\\\", \\\"{x:1420,y:1027,t:1527268655163};\\\", \\\"{x:1419,y:1026,t:1527268655179};\\\", \\\"{x:1419,y:1024,t:1527268655195};\\\", \\\"{x:1418,y:1024,t:1527268655211};\\\", \\\"{x:1418,y:1021,t:1527268655228};\\\", \\\"{x:1417,y:1019,t:1527268655259};\\\", \\\"{x:1417,y:1018,t:1527268655283};\\\", \\\"{x:1417,y:1017,t:1527268655294};\\\", \\\"{x:1416,y:1016,t:1527268655311};\\\", \\\"{x:1415,y:1015,t:1527268655328};\\\", \\\"{x:1414,y:1014,t:1527268655345};\\\", \\\"{x:1413,y:1014,t:1527268655361};\\\", \\\"{x:1412,y:1013,t:1527268655378};\\\", \\\"{x:1411,y:1012,t:1527268655395};\\\", \\\"{x:1410,y:1012,t:1527268655411};\\\", \\\"{x:1409,y:1011,t:1527268655428};\\\", \\\"{x:1407,y:1010,t:1527268655446};\\\", \\\"{x:1405,y:1008,t:1527268655461};\\\", \\\"{x:1403,y:1008,t:1527268655478};\\\", \\\"{x:1402,y:1007,t:1527268655495};\\\", \\\"{x:1400,y:1005,t:1527268655512};\\\", \\\"{x:1399,y:1004,t:1527268655528};\\\", \\\"{x:1397,y:1003,t:1527268655545};\\\", \\\"{x:1396,y:1002,t:1527268655561};\\\", \\\"{x:1395,y:1001,t:1527268655578};\\\", \\\"{x:1394,y:1000,t:1527268655595};\\\", \\\"{x:1392,y:999,t:1527268655611};\\\", \\\"{x:1390,y:993,t:1527268655628};\\\", \\\"{x:1387,y:987,t:1527268655645};\\\", \\\"{x:1383,y:981,t:1527268655661};\\\", \\\"{x:1379,y:974,t:1527268655678};\\\", \\\"{x:1376,y:966,t:1527268655696};\\\", \\\"{x:1372,y:959,t:1527268655712};\\\", \\\"{x:1369,y:951,t:1527268655728};\\\", \\\"{x:1366,y:944,t:1527268655745};\\\", \\\"{x:1364,y:941,t:1527268655762};\\\", \\\"{x:1364,y:939,t:1527268655899};\\\", \\\"{x:1364,y:938,t:1527268655923};\\\", \\\"{x:1364,y:937,t:1527268655947};\\\", \\\"{x:1364,y:936,t:1527268655962};\\\", \\\"{x:1365,y:935,t:1527268655987};\\\", \\\"{x:1365,y:933,t:1527268656027};\\\", \\\"{x:1366,y:932,t:1527268656059};\\\", \\\"{x:1367,y:930,t:1527268656131};\\\", \\\"{x:1368,y:929,t:1527268656147};\\\", \\\"{x:1368,y:928,t:1527268656163};\\\", \\\"{x:1369,y:928,t:1527268656187};\\\", \\\"{x:1369,y:927,t:1527268656203};\\\", \\\"{x:1371,y:926,t:1527268656227};\\\", \\\"{x:1372,y:925,t:1527268656267};\\\", \\\"{x:1373,y:925,t:1527268656283};\\\", \\\"{x:1373,y:924,t:1527268656299};\\\", \\\"{x:1374,y:923,t:1527268656312};\\\", \\\"{x:1375,y:922,t:1527268656329};\\\", \\\"{x:1376,y:920,t:1527268656347};\\\", \\\"{x:1376,y:919,t:1527268656362};\\\", \\\"{x:1377,y:918,t:1527268656387};\\\", \\\"{x:1378,y:918,t:1527268656443};\\\", \\\"{x:1378,y:917,t:1527268656459};\\\", \\\"{x:1378,y:916,t:1527268656483};\\\", \\\"{x:1378,y:914,t:1527268656499};\\\", \\\"{x:1379,y:912,t:1527268656539};\\\", \\\"{x:1380,y:912,t:1527268656547};\\\", \\\"{x:1380,y:911,t:1527268656562};\\\", \\\"{x:1380,y:910,t:1527268656579};\\\", \\\"{x:1380,y:909,t:1527268656597};\\\", \\\"{x:1381,y:907,t:1527268656619};\\\", \\\"{x:1381,y:906,t:1527268656780};\\\", \\\"{x:1381,y:905,t:1527268656811};\\\", \\\"{x:1381,y:904,t:1527268656843};\\\", \\\"{x:1381,y:903,t:1527268656875};\\\", \\\"{x:1380,y:902,t:1527268657110};\\\", \\\"{x:1380,y:901,t:1527268657131};\\\", \\\"{x:1380,y:900,t:1527268657402};\\\", \\\"{x:1380,y:899,t:1527268657417};\\\", \\\"{x:1380,y:898,t:1527268657442};\\\", \\\"{x:1379,y:898,t:1527268658555};\\\", \\\"{x:1376,y:898,t:1527268658564};\\\", \\\"{x:1367,y:898,t:1527268658582};\\\", \\\"{x:1359,y:897,t:1527268658597};\\\", \\\"{x:1355,y:896,t:1527268658615};\\\", \\\"{x:1353,y:896,t:1527268658631};\\\", \\\"{x:1351,y:895,t:1527268658648};\\\", \\\"{x:1350,y:895,t:1527268658667};\\\", \\\"{x:1347,y:895,t:1527268658681};\\\", \\\"{x:1342,y:893,t:1527268658698};\\\", \\\"{x:1333,y:890,t:1527268658715};\\\", \\\"{x:1320,y:888,t:1527268658730};\\\", \\\"{x:1301,y:880,t:1527268658747};\\\", \\\"{x:1291,y:878,t:1527268658765};\\\", \\\"{x:1280,y:875,t:1527268658781};\\\", \\\"{x:1271,y:873,t:1527268658797};\\\", \\\"{x:1262,y:871,t:1527268658815};\\\", \\\"{x:1257,y:869,t:1527268658831};\\\", \\\"{x:1249,y:869,t:1527268658847};\\\", \\\"{x:1242,y:866,t:1527268658864};\\\", \\\"{x:1236,y:866,t:1527268658881};\\\", \\\"{x:1229,y:866,t:1527268658898};\\\", \\\"{x:1223,y:866,t:1527268658914};\\\", \\\"{x:1215,y:866,t:1527268658931};\\\", \\\"{x:1213,y:865,t:1527268658947};\\\", \\\"{x:1210,y:863,t:1527268658964};\\\", \\\"{x:1209,y:862,t:1527268658981};\\\", \\\"{x:1208,y:862,t:1527268658998};\\\", \\\"{x:1208,y:861,t:1527268659014};\\\", \\\"{x:1206,y:859,t:1527268659032};\\\", \\\"{x:1205,y:858,t:1527268659047};\\\", \\\"{x:1204,y:858,t:1527268659064};\\\", \\\"{x:1202,y:856,t:1527268659082};\\\", \\\"{x:1202,y:855,t:1527268659098};\\\", \\\"{x:1201,y:853,t:1527268659114};\\\", \\\"{x:1200,y:852,t:1527268659131};\\\", \\\"{x:1198,y:850,t:1527268659148};\\\", \\\"{x:1197,y:849,t:1527268659171};\\\", \\\"{x:1197,y:847,t:1527268659731};\\\", \\\"{x:1199,y:846,t:1527268659755};\\\", \\\"{x:1200,y:846,t:1527268659827};\\\", \\\"{x:1201,y:846,t:1527268659843};\\\", \\\"{x:1202,y:846,t:1527268659851};\\\", \\\"{x:1204,y:845,t:1527268659875};\\\", \\\"{x:1205,y:845,t:1527268659899};\\\", \\\"{x:1207,y:845,t:1527268659915};\\\", \\\"{x:1207,y:844,t:1527268659931};\\\", \\\"{x:1208,y:844,t:1527268659949};\\\", \\\"{x:1208,y:843,t:1527268660004};\\\", \\\"{x:1210,y:843,t:1527268660035};\\\", \\\"{x:1211,y:842,t:1527268660051};\\\", \\\"{x:1211,y:841,t:1527268660066};\\\", \\\"{x:1212,y:840,t:1527268660082};\\\", \\\"{x:1213,y:840,t:1527268660123};\\\", \\\"{x:1213,y:838,t:1527268660388};\\\", \\\"{x:1213,y:837,t:1527268660403};\\\", \\\"{x:1213,y:835,t:1527268660435};\\\", \\\"{x:1213,y:834,t:1527268660490};\\\", \\\"{x:1214,y:833,t:1527268662659};\\\", \\\"{x:1218,y:831,t:1527268662675};\\\", \\\"{x:1221,y:830,t:1527268662685};\\\", \\\"{x:1229,y:829,t:1527268662701};\\\", \\\"{x:1240,y:825,t:1527268662718};\\\", \\\"{x:1248,y:822,t:1527268662733};\\\", \\\"{x:1258,y:817,t:1527268662750};\\\", \\\"{x:1273,y:810,t:1527268662767};\\\", \\\"{x:1285,y:804,t:1527268662785};\\\", \\\"{x:1298,y:796,t:1527268662801};\\\", \\\"{x:1311,y:787,t:1527268662818};\\\", \\\"{x:1318,y:781,t:1527268662835};\\\", \\\"{x:1322,y:778,t:1527268662851};\\\", \\\"{x:1322,y:777,t:1527268662868};\\\", \\\"{x:1323,y:777,t:1527268662885};\\\", \\\"{x:1323,y:776,t:1527268662901};\\\", \\\"{x:1324,y:775,t:1527268662946};\\\", \\\"{x:1324,y:774,t:1527268662971};\\\", \\\"{x:1325,y:774,t:1527268662985};\\\", \\\"{x:1325,y:773,t:1527268663019};\\\", \\\"{x:1326,y:772,t:1527268663034};\\\", \\\"{x:1328,y:771,t:1527268663051};\\\", \\\"{x:1329,y:769,t:1527268663068};\\\", \\\"{x:1330,y:768,t:1527268663084};\\\", \\\"{x:1332,y:767,t:1527268663101};\\\", \\\"{x:1334,y:765,t:1527268663118};\\\", \\\"{x:1335,y:764,t:1527268663134};\\\", \\\"{x:1336,y:763,t:1527268663152};\\\", \\\"{x:1337,y:763,t:1527268663168};\\\", \\\"{x:1338,y:763,t:1527268663675};\\\", \\\"{x:1340,y:763,t:1527268663699};\\\", \\\"{x:1341,y:763,t:1527268663723};\\\", \\\"{x:1343,y:763,t:1527268663739};\\\", \\\"{x:1343,y:762,t:1527268663751};\\\", \\\"{x:1344,y:762,t:1527268663827};\\\", \\\"{x:1345,y:760,t:1527268667891};\\\", \\\"{x:1347,y:757,t:1527268667905};\\\", \\\"{x:1348,y:751,t:1527268667921};\\\", \\\"{x:1351,y:741,t:1527268667939};\\\", \\\"{x:1352,y:735,t:1527268667955};\\\", \\\"{x:1353,y:731,t:1527268667971};\\\", \\\"{x:1355,y:725,t:1527268667989};\\\", \\\"{x:1356,y:721,t:1527268668005};\\\", \\\"{x:1356,y:717,t:1527268668022};\\\", \\\"{x:1356,y:714,t:1527268668039};\\\", \\\"{x:1357,y:710,t:1527268668055};\\\", \\\"{x:1357,y:708,t:1527268668072};\\\", \\\"{x:1357,y:707,t:1527268668088};\\\", \\\"{x:1357,y:706,t:1527268668105};\\\", \\\"{x:1358,y:704,t:1527268668122};\\\", \\\"{x:1358,y:703,t:1527268668435};\\\", \\\"{x:1357,y:703,t:1527268668563};\\\", \\\"{x:1355,y:703,t:1527268668572};\\\", \\\"{x:1352,y:703,t:1527268668589};\\\", \\\"{x:1350,y:703,t:1527268668606};\\\", \\\"{x:1349,y:703,t:1527268668622};\\\", \\\"{x:1337,y:703,t:1527268671539};\\\", \\\"{x:1300,y:701,t:1527268671547};\\\", \\\"{x:1260,y:694,t:1527268671558};\\\", \\\"{x:1149,y:678,t:1527268671575};\\\", \\\"{x:1029,y:661,t:1527268671591};\\\", \\\"{x:940,y:648,t:1527268671608};\\\", \\\"{x:892,y:641,t:1527268671625};\\\", \\\"{x:883,y:640,t:1527268671640};\\\", \\\"{x:882,y:640,t:1527268671690};\\\", \\\"{x:881,y:640,t:1527268671697};\\\", \\\"{x:880,y:640,t:1527268671754};\\\", \\\"{x:880,y:639,t:1527268671778};\\\", \\\"{x:880,y:633,t:1527268671792};\\\", \\\"{x:881,y:618,t:1527268671809};\\\", \\\"{x:883,y:605,t:1527268671825};\\\", \\\"{x:883,y:598,t:1527268671841};\\\", \\\"{x:883,y:590,t:1527268671858};\\\", \\\"{x:882,y:587,t:1527268671874};\\\", \\\"{x:880,y:583,t:1527268671892};\\\", \\\"{x:876,y:579,t:1527268671909};\\\", \\\"{x:873,y:574,t:1527268671926};\\\", \\\"{x:869,y:569,t:1527268671942};\\\", \\\"{x:864,y:564,t:1527268671958};\\\", \\\"{x:861,y:561,t:1527268671974};\\\", \\\"{x:859,y:558,t:1527268671991};\\\", \\\"{x:856,y:554,t:1527268672008};\\\", \\\"{x:853,y:551,t:1527268672025};\\\", \\\"{x:852,y:548,t:1527268672042};\\\", \\\"{x:848,y:544,t:1527268672057};\\\", \\\"{x:845,y:540,t:1527268672076};\\\", \\\"{x:843,y:538,t:1527268672091};\\\", \\\"{x:841,y:537,t:1527268672108};\\\", \\\"{x:840,y:535,t:1527268672125};\\\", \\\"{x:838,y:533,t:1527268672142};\\\", \\\"{x:836,y:532,t:1527268672158};\\\", \\\"{x:835,y:531,t:1527268672176};\\\", \\\"{x:834,y:528,t:1527268672192};\\\", \\\"{x:832,y:528,t:1527268672208};\\\", \\\"{x:831,y:526,t:1527268672226};\\\", \\\"{x:830,y:525,t:1527268672241};\\\", \\\"{x:829,y:524,t:1527268672258};\\\", \\\"{x:827,y:524,t:1527268672276};\\\", \\\"{x:826,y:523,t:1527268672331};\\\", \\\"{x:826,y:522,t:1527268672354};\\\", \\\"{x:826,y:521,t:1527268672378};\\\", \\\"{x:826,y:520,t:1527268672394};\\\", \\\"{x:826,y:519,t:1527268672410};\\\", \\\"{x:826,y:517,t:1527268672425};\\\", \\\"{x:826,y:516,t:1527268672442};\\\", \\\"{x:826,y:514,t:1527268672481};\\\", \\\"{x:826,y:513,t:1527268672522};\\\", \\\"{x:826,y:514,t:1527268676391};\\\", \\\"{x:826,y:515,t:1527268676406};\\\", \\\"{x:826,y:516,t:1527268676416};\\\", \\\"{x:826,y:517,t:1527268676432};\\\", \\\"{x:825,y:519,t:1527268676450};\\\", \\\"{x:825,y:521,t:1527268676465};\\\", \\\"{x:825,y:523,t:1527268676482};\\\", \\\"{x:826,y:527,t:1527268676499};\\\", \\\"{x:828,y:530,t:1527268676516};\\\", \\\"{x:833,y:534,t:1527268676532};\\\", \\\"{x:849,y:545,t:1527268676549};\\\", \\\"{x:861,y:554,t:1527268676565};\\\", \\\"{x:879,y:565,t:1527268676582};\\\", \\\"{x:897,y:576,t:1527268676600};\\\", \\\"{x:910,y:583,t:1527268676617};\\\", \\\"{x:926,y:595,t:1527268676631};\\\", \\\"{x:949,y:611,t:1527268676650};\\\", \\\"{x:994,y:644,t:1527268676666};\\\", \\\"{x:1066,y:691,t:1527268676682};\\\", \\\"{x:1139,y:742,t:1527268676699};\\\", \\\"{x:1207,y:783,t:1527268676716};\\\", \\\"{x:1278,y:822,t:1527268676732};\\\", \\\"{x:1379,y:867,t:1527268676749};\\\", \\\"{x:1429,y:890,t:1527268676765};\\\", \\\"{x:1463,y:902,t:1527268676782};\\\", \\\"{x:1481,y:909,t:1527268676799};\\\", \\\"{x:1492,y:913,t:1527268676816};\\\", \\\"{x:1496,y:913,t:1527268676832};\\\", \\\"{x:1498,y:913,t:1527268676849};\\\", \\\"{x:1501,y:912,t:1527268676866};\\\", \\\"{x:1505,y:907,t:1527268676882};\\\", \\\"{x:1512,y:895,t:1527268676900};\\\", \\\"{x:1514,y:880,t:1527268676917};\\\", \\\"{x:1514,y:861,t:1527268676932};\\\", \\\"{x:1509,y:840,t:1527268676949};\\\", \\\"{x:1488,y:812,t:1527268676966};\\\", \\\"{x:1475,y:797,t:1527268676983};\\\", \\\"{x:1458,y:783,t:1527268677000};\\\", \\\"{x:1447,y:775,t:1527268677016};\\\", \\\"{x:1440,y:768,t:1527268677032};\\\", \\\"{x:1434,y:763,t:1527268677050};\\\", \\\"{x:1431,y:759,t:1527268677067};\\\", \\\"{x:1429,y:757,t:1527268677083};\\\", \\\"{x:1428,y:755,t:1527268677100};\\\", \\\"{x:1427,y:754,t:1527268677574};\\\", \\\"{x:1427,y:753,t:1527268677583};\\\", \\\"{x:1425,y:752,t:1527268677622};\\\", \\\"{x:1424,y:752,t:1527268677646};\\\", \\\"{x:1423,y:752,t:1527268677695};\\\", \\\"{x:1421,y:751,t:1527268677718};\\\", \\\"{x:1420,y:750,t:1527268677783};\\\", \\\"{x:1419,y:749,t:1527268677801};\\\", \\\"{x:1419,y:748,t:1527268677822};\\\", \\\"{x:1419,y:747,t:1527268678295};\\\", \\\"{x:1419,y:746,t:1527268678302};\\\", \\\"{x:1420,y:744,t:1527268678318};\\\", \\\"{x:1423,y:742,t:1527268678334};\\\", \\\"{x:1425,y:741,t:1527268678351};\\\", \\\"{x:1426,y:740,t:1527268678368};\\\", \\\"{x:1428,y:739,t:1527268678384};\\\", \\\"{x:1430,y:738,t:1527268678401};\\\", \\\"{x:1431,y:738,t:1527268678417};\\\", \\\"{x:1433,y:737,t:1527268678435};\\\", \\\"{x:1434,y:737,t:1527268678454};\\\", \\\"{x:1435,y:737,t:1527268678468};\\\", \\\"{x:1436,y:737,t:1527268678485};\\\", \\\"{x:1437,y:737,t:1527268678527};\\\", \\\"{x:1439,y:737,t:1527268678542};\\\", \\\"{x:1441,y:738,t:1527268678551};\\\", \\\"{x:1448,y:747,t:1527268678568};\\\", \\\"{x:1457,y:758,t:1527268678585};\\\", \\\"{x:1463,y:768,t:1527268678601};\\\", \\\"{x:1468,y:774,t:1527268678617};\\\", \\\"{x:1470,y:777,t:1527268678635};\\\", \\\"{x:1471,y:778,t:1527268678651};\\\", \\\"{x:1471,y:779,t:1527268678694};\\\", \\\"{x:1471,y:780,t:1527268678719};\\\", \\\"{x:1472,y:781,t:1527268678831};\\\", \\\"{x:1474,y:781,t:1527268678838};\\\", \\\"{x:1475,y:781,t:1527268678851};\\\", \\\"{x:1481,y:780,t:1527268678868};\\\", \\\"{x:1486,y:778,t:1527268678885};\\\", \\\"{x:1493,y:775,t:1527268678902};\\\", \\\"{x:1498,y:773,t:1527268678919};\\\", \\\"{x:1501,y:771,t:1527268678935};\\\", \\\"{x:1505,y:770,t:1527268678952};\\\", \\\"{x:1506,y:769,t:1527268678968};\\\", \\\"{x:1507,y:768,t:1527268678984};\\\", \\\"{x:1509,y:768,t:1527268679001};\\\", \\\"{x:1510,y:767,t:1527268679018};\\\", \\\"{x:1511,y:767,t:1527268679034};\\\", \\\"{x:1513,y:765,t:1527268679052};\\\", \\\"{x:1514,y:764,t:1527268679102};\\\", \\\"{x:1511,y:764,t:1527268680654};\\\", \\\"{x:1503,y:764,t:1527268680671};\\\", \\\"{x:1495,y:761,t:1527268680687};\\\", \\\"{x:1488,y:759,t:1527268680703};\\\", \\\"{x:1484,y:757,t:1527268680720};\\\", \\\"{x:1483,y:757,t:1527268680750};\\\", \\\"{x:1482,y:757,t:1527268680766};\\\", \\\"{x:1481,y:757,t:1527268680782};\\\", \\\"{x:1479,y:755,t:1527268680790};\\\", \\\"{x:1478,y:754,t:1527268680803};\\\", \\\"{x:1478,y:753,t:1527268680820};\\\", \\\"{x:1477,y:752,t:1527268680837};\\\", \\\"{x:1476,y:751,t:1527268680853};\\\", \\\"{x:1475,y:750,t:1527268680878};\\\", \\\"{x:1474,y:750,t:1527268680887};\\\", \\\"{x:1473,y:747,t:1527268680903};\\\", \\\"{x:1472,y:744,t:1527268680920};\\\", \\\"{x:1471,y:738,t:1527268680937};\\\", \\\"{x:1469,y:730,t:1527268680953};\\\", \\\"{x:1469,y:718,t:1527268680970};\\\", \\\"{x:1469,y:708,t:1527268680987};\\\", \\\"{x:1469,y:702,t:1527268681003};\\\", \\\"{x:1469,y:688,t:1527268681020};\\\", \\\"{x:1464,y:673,t:1527268681037};\\\", \\\"{x:1457,y:648,t:1527268681054};\\\", \\\"{x:1454,y:641,t:1527268681071};\\\", \\\"{x:1453,y:634,t:1527268681087};\\\", \\\"{x:1452,y:629,t:1527268681104};\\\", \\\"{x:1451,y:628,t:1527268681120};\\\", \\\"{x:1451,y:627,t:1527268681137};\\\", \\\"{x:1451,y:626,t:1527268681154};\\\", \\\"{x:1450,y:625,t:1527268681170};\\\", \\\"{x:1449,y:625,t:1527268681223};\\\", \\\"{x:1448,y:625,t:1527268681238};\\\", \\\"{x:1447,y:625,t:1527268681254};\\\", \\\"{x:1445,y:625,t:1527268681270};\\\", \\\"{x:1443,y:623,t:1527268681288};\\\", \\\"{x:1442,y:623,t:1527268681304};\\\", \\\"{x:1441,y:623,t:1527268682725};\\\", \\\"{x:1440,y:622,t:1527268682749};\\\", \\\"{x:1440,y:619,t:1527268682757};\\\", \\\"{x:1439,y:616,t:1527268682771};\\\", \\\"{x:1437,y:612,t:1527268682787};\\\", \\\"{x:1437,y:610,t:1527268682804};\\\", \\\"{x:1436,y:605,t:1527268682821};\\\", \\\"{x:1434,y:601,t:1527268682837};\\\", \\\"{x:1433,y:598,t:1527268682854};\\\", \\\"{x:1432,y:597,t:1527268682872};\\\", \\\"{x:1430,y:595,t:1527268682888};\\\", \\\"{x:1430,y:594,t:1527268682905};\\\", \\\"{x:1430,y:592,t:1527268682922};\\\", \\\"{x:1429,y:592,t:1527268682938};\\\", \\\"{x:1429,y:591,t:1527268682955};\\\", \\\"{x:1428,y:591,t:1527268682971};\\\", \\\"{x:1428,y:589,t:1527268682988};\\\", \\\"{x:1427,y:588,t:1527268683014};\\\", \\\"{x:1426,y:586,t:1527268683030};\\\", \\\"{x:1426,y:585,t:1527268683047};\\\", \\\"{x:1426,y:584,t:1527268683055};\\\", \\\"{x:1424,y:583,t:1527268683072};\\\", \\\"{x:1424,y:582,t:1527268683089};\\\", \\\"{x:1424,y:581,t:1527268683105};\\\", \\\"{x:1424,y:580,t:1527268683510};\\\", \\\"{x:1424,y:579,t:1527268683522};\\\", \\\"{x:1424,y:577,t:1527268683539};\\\", \\\"{x:1422,y:576,t:1527268683556};\\\", \\\"{x:1421,y:575,t:1527268683572};\\\", \\\"{x:1420,y:575,t:1527268683655};\\\", \\\"{x:1419,y:574,t:1527268683672};\\\", \\\"{x:1418,y:573,t:1527268683702};\\\", \\\"{x:1417,y:573,t:1527268683751};\\\", \\\"{x:1416,y:573,t:1527268683766};\\\", \\\"{x:1415,y:573,t:1527268683790};\\\", \\\"{x:1414,y:573,t:1527268683814};\\\", \\\"{x:1413,y:573,t:1527268683822};\\\", \\\"{x:1412,y:573,t:1527268683982};\\\", \\\"{x:1411,y:573,t:1527268683998};\\\", \\\"{x:1410,y:573,t:1527268684006};\\\", \\\"{x:1409,y:573,t:1527268684030};\\\", \\\"{x:1408,y:573,t:1527268684046};\\\", \\\"{x:1407,y:573,t:1527268684056};\\\", \\\"{x:1404,y:573,t:1527268684073};\\\", \\\"{x:1398,y:573,t:1527268684089};\\\", \\\"{x:1395,y:573,t:1527268684106};\\\", \\\"{x:1388,y:573,t:1527268684123};\\\", \\\"{x:1378,y:573,t:1527268684138};\\\", \\\"{x:1367,y:573,t:1527268684156};\\\", \\\"{x:1352,y:573,t:1527268684173};\\\", \\\"{x:1334,y:573,t:1527268684189};\\\", \\\"{x:1315,y:573,t:1527268684206};\\\", \\\"{x:1307,y:573,t:1527268684222};\\\", \\\"{x:1304,y:573,t:1527268684239};\\\", \\\"{x:1301,y:573,t:1527268684256};\\\", \\\"{x:1300,y:573,t:1527268684272};\\\", \\\"{x:1297,y:574,t:1527268684290};\\\", \\\"{x:1296,y:574,t:1527268684334};\\\", \\\"{x:1295,y:574,t:1527268684342};\\\", \\\"{x:1294,y:574,t:1527268684356};\\\", \\\"{x:1291,y:574,t:1527268684373};\\\", \\\"{x:1284,y:574,t:1527268684390};\\\", \\\"{x:1281,y:574,t:1527268684406};\\\", \\\"{x:1277,y:574,t:1527268684423};\\\", \\\"{x:1276,y:574,t:1527268684440};\\\", \\\"{x:1275,y:574,t:1527268684456};\\\", \\\"{x:1274,y:573,t:1527268684591};\\\", \\\"{x:1273,y:572,t:1527268684606};\\\", \\\"{x:1273,y:570,t:1527268684623};\\\", \\\"{x:1272,y:569,t:1527268684640};\\\", \\\"{x:1272,y:568,t:1527268684656};\\\", \\\"{x:1272,y:567,t:1527268684673};\\\", \\\"{x:1272,y:566,t:1527268684690};\\\", \\\"{x:1272,y:565,t:1527268684710};\\\", \\\"{x:1272,y:564,t:1527268684759};\\\", \\\"{x:1272,y:563,t:1527268685423};\\\", \\\"{x:1272,y:562,t:1527268685535};\\\", \\\"{x:1272,y:561,t:1527268685558};\\\", \\\"{x:1273,y:561,t:1527268685574};\\\", \\\"{x:1274,y:561,t:1527268685606};\\\", \\\"{x:1275,y:561,t:1527268685624};\\\", \\\"{x:1276,y:561,t:1527268685641};\\\", \\\"{x:1277,y:560,t:1527268685657};\\\", \\\"{x:1278,y:560,t:1527268685673};\\\", \\\"{x:1279,y:560,t:1527268685694};\\\", \\\"{x:1280,y:559,t:1527268685798};\\\", \\\"{x:1281,y:558,t:1527268685838};\\\", \\\"{x:1281,y:559,t:1527268686206};\\\", \\\"{x:1280,y:562,t:1527268686213};\\\", \\\"{x:1278,y:568,t:1527268686224};\\\", \\\"{x:1272,y:581,t:1527268686242};\\\", \\\"{x:1267,y:596,t:1527268686258};\\\", \\\"{x:1265,y:609,t:1527268686274};\\\", \\\"{x:1261,y:623,t:1527268686291};\\\", \\\"{x:1260,y:638,t:1527268686308};\\\", \\\"{x:1260,y:663,t:1527268686326};\\\", \\\"{x:1260,y:704,t:1527268686341};\\\", \\\"{x:1271,y:761,t:1527268686358};\\\", \\\"{x:1280,y:792,t:1527268686374};\\\", \\\"{x:1290,y:819,t:1527268686391};\\\", \\\"{x:1295,y:839,t:1527268686408};\\\", \\\"{x:1296,y:846,t:1527268686425};\\\", \\\"{x:1296,y:851,t:1527268686441};\\\", \\\"{x:1296,y:853,t:1527268686458};\\\", \\\"{x:1296,y:858,t:1527268686475};\\\", \\\"{x:1296,y:865,t:1527268686491};\\\", \\\"{x:1296,y:880,t:1527268686508};\\\", \\\"{x:1296,y:890,t:1527268686525};\\\", \\\"{x:1296,y:898,t:1527268686541};\\\", \\\"{x:1299,y:912,t:1527268686558};\\\", \\\"{x:1299,y:914,t:1527268686574};\\\", \\\"{x:1299,y:915,t:1527268686592};\\\", \\\"{x:1299,y:917,t:1527268686608};\\\", \\\"{x:1299,y:919,t:1527268686630};\\\", \\\"{x:1299,y:922,t:1527268686646};\\\", \\\"{x:1299,y:926,t:1527268686658};\\\", \\\"{x:1296,y:940,t:1527268686676};\\\", \\\"{x:1292,y:953,t:1527268686691};\\\", \\\"{x:1289,y:963,t:1527268686708};\\\", \\\"{x:1288,y:970,t:1527268686725};\\\", \\\"{x:1287,y:975,t:1527268686742};\\\", \\\"{x:1286,y:976,t:1527268686758};\\\", \\\"{x:1286,y:975,t:1527268687630};\\\", \\\"{x:1286,y:974,t:1527268687642};\\\", \\\"{x:1285,y:972,t:1527268687678};\\\", \\\"{x:1285,y:971,t:1527268687806};\\\", \\\"{x:1285,y:970,t:1527268687999};\\\", \\\"{x:1285,y:968,t:1527268688023};\\\", \\\"{x:1285,y:967,t:1527268688134};\\\", \\\"{x:1284,y:967,t:1527268688158};\\\", \\\"{x:1284,y:966,t:1527268688830};\\\", \\\"{x:1284,y:961,t:1527268691999};\\\", \\\"{x:1284,y:951,t:1527268692012};\\\", \\\"{x:1288,y:909,t:1527268692029};\\\", \\\"{x:1305,y:782,t:1527268692046};\\\", \\\"{x:1307,y:707,t:1527268692063};\\\", \\\"{x:1307,y:629,t:1527268692080};\\\", \\\"{x:1307,y:590,t:1527268692096};\\\", \\\"{x:1307,y:569,t:1527268692114};\\\", \\\"{x:1307,y:561,t:1527268692131};\\\", \\\"{x:1307,y:557,t:1527268692147};\\\", \\\"{x:1307,y:555,t:1527268692163};\\\", \\\"{x:1301,y:555,t:1527268692255};\\\", \\\"{x:1286,y:555,t:1527268692263};\\\", \\\"{x:1243,y:568,t:1527268692279};\\\", \\\"{x:1182,y:585,t:1527268692297};\\\", \\\"{x:1120,y:603,t:1527268692314};\\\", \\\"{x:1054,y:621,t:1527268692330};\\\", \\\"{x:1005,y:638,t:1527268692347};\\\", \\\"{x:969,y:649,t:1527268692363};\\\", \\\"{x:943,y:656,t:1527268692379};\\\", \\\"{x:928,y:658,t:1527268692396};\\\", \\\"{x:911,y:660,t:1527268692412};\\\", \\\"{x:883,y:660,t:1527268692428};\\\", \\\"{x:866,y:657,t:1527268692445};\\\", \\\"{x:845,y:651,t:1527268692463};\\\", \\\"{x:825,y:642,t:1527268692479};\\\", \\\"{x:799,y:630,t:1527268692496};\\\", \\\"{x:777,y:620,t:1527268692513};\\\", \\\"{x:754,y:611,t:1527268692529};\\\", \\\"{x:724,y:593,t:1527268692546};\\\", \\\"{x:694,y:581,t:1527268692562};\\\", \\\"{x:666,y:575,t:1527268692579};\\\", \\\"{x:638,y:565,t:1527268692596};\\\", \\\"{x:619,y:559,t:1527268692612};\\\", \\\"{x:602,y:554,t:1527268692628};\\\", \\\"{x:575,y:551,t:1527268692645};\\\", \\\"{x:561,y:548,t:1527268692662};\\\", \\\"{x:547,y:547,t:1527268692678};\\\", \\\"{x:541,y:545,t:1527268692696};\\\", \\\"{x:540,y:545,t:1527268692712};\\\", \\\"{x:539,y:544,t:1527268692741};\\\", \\\"{x:539,y:540,t:1527268692757};\\\", \\\"{x:539,y:537,t:1527268692766};\\\", \\\"{x:539,y:533,t:1527268692779};\\\", \\\"{x:543,y:526,t:1527268692796};\\\", \\\"{x:549,y:519,t:1527268692812};\\\", \\\"{x:559,y:510,t:1527268692828};\\\", \\\"{x:566,y:507,t:1527268692845};\\\", \\\"{x:576,y:503,t:1527268692864};\\\", \\\"{x:587,y:501,t:1527268692878};\\\", \\\"{x:597,y:500,t:1527268692896};\\\", \\\"{x:601,y:498,t:1527268692913};\\\", \\\"{x:605,y:498,t:1527268692930};\\\", \\\"{x:607,y:498,t:1527268692946};\\\", \\\"{x:609,y:498,t:1527268692963};\\\", \\\"{x:610,y:499,t:1527268692997};\\\", \\\"{x:611,y:500,t:1527268693014};\\\", \\\"{x:612,y:503,t:1527268693031};\\\", \\\"{x:615,y:508,t:1527268693045};\\\", \\\"{x:618,y:513,t:1527268693062};\\\", \\\"{x:619,y:517,t:1527268693080};\\\", \\\"{x:619,y:518,t:1527268693101};\\\", \\\"{x:620,y:519,t:1527268693125};\\\", \\\"{x:617,y:521,t:1527268693501};\\\", \\\"{x:611,y:525,t:1527268693513};\\\", \\\"{x:602,y:531,t:1527268693531};\\\", \\\"{x:593,y:539,t:1527268693546};\\\", \\\"{x:584,y:546,t:1527268693563};\\\", \\\"{x:571,y:563,t:1527268693579};\\\", \\\"{x:546,y:592,t:1527268693597};\\\", \\\"{x:521,y:623,t:1527268693614};\\\", \\\"{x:508,y:641,t:1527268693629};\\\", \\\"{x:503,y:650,t:1527268693647};\\\", \\\"{x:498,y:661,t:1527268693663};\\\", \\\"{x:497,y:665,t:1527268693679};\\\", \\\"{x:496,y:669,t:1527268693697};\\\", \\\"{x:495,y:671,t:1527268693712};\\\", \\\"{x:494,y:674,t:1527268693732};\\\", \\\"{x:493,y:676,t:1527268693748};\\\", \\\"{x:493,y:679,t:1527268693765};\\\", \\\"{x:493,y:681,t:1527268693779};\\\", \\\"{x:489,y:695,t:1527268693797};\\\", \\\"{x:486,y:705,t:1527268693813};\\\", \\\"{x:485,y:714,t:1527268693830};\\\", \\\"{x:485,y:720,t:1527268693847};\\\", \\\"{x:485,y:721,t:1527268693863};\\\", \\\"{x:485,y:723,t:1527268693933};\\\", \\\"{x:485,y:724,t:1527268693947};\\\", \\\"{x:485,y:727,t:1527268693963};\\\", \\\"{x:485,y:733,t:1527268693980};\\\", \\\"{x:485,y:737,t:1527268693998};\\\", \\\"{x:485,y:739,t:1527268694014};\\\", \\\"{x:485,y:740,t:1527268694677};\\\", \\\"{x:486,y:740,t:1527268695014};\\\", \\\"{x:486,y:739,t:1527268695117};\\\", \\\"{x:487,y:738,t:1527268695150};\\\", \\\"{x:488,y:737,t:1527268695165};\\\" ] }, { \\\"rt\\\": 41447, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 780725, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Go to the 12pm marker at bottom then follow it up the cross section to see the dots that fall onto the time \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6695, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 788426, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14452, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 803893, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 29813, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 835017, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"5QCE3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"5QCE3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 275, dom: 860, initialDom: 1127",
  "javascriptErrors": []
}