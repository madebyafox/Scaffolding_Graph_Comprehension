var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d743def3935bb4bb7633b03e91a6f9ee",
  "created": "2018-06-04T13:22:04.1537203-07:00",
  "lastActivity": "2018-06-04T13:22:17.2747203-07:00",
  "pageViews": [
    {
      "id": "06040488edbfaf1cc2753f7b7d19b717e07ed1b5",
      "startTime": "2018-06-04T13:22:04.1537203-07:00",
      "endTime": "2018-06-04T13:22:17.2747203-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 13121,
      "engagementTime": 13095,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13121,
  "engagementTime": 13095,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K0CNH",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "022fec4f8fb00f7279beddd9ad12c5fa",
  "gdpr": false
}