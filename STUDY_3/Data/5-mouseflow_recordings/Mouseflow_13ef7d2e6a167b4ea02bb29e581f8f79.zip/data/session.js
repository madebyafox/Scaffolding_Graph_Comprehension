var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "13ef7d2e6a167b4ea02bb29e581f8f79",
  "created": "2018-05-24T12:16:27.987465-07:00",
  "lastActivity": "2018-05-24T12:17:16.310465-07:00",
  "pageViews": [
    {
      "id": "05242879275e12d8b04f4c56fc0bdf2daf02e2cb",
      "startTime": "2018-05-24T12:16:27.987465-07:00",
      "endTime": "2018-05-24T12:17:16.310465-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 48323,
      "engagementTime": 48074,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48323,
  "engagementTime": 48074,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=K2YPP",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0b3bb6c795850b972bff2d9799866228",
  "gdpr": false
}