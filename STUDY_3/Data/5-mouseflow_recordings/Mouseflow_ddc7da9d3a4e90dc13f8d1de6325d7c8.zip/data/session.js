var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ddc7da9d3a4e90dc13f8d1de6325d7c8",
  "created": "2018-05-21T10:17:05.35988-07:00",
  "lastActivity": "2018-05-21T10:17:37.645217-07:00",
  "pageViews": [
    {
      "id": "05210593ecd108f83c7e9614db6cb717333abfc4",
      "startTime": "2018-05-21T10:17:05.35988-07:00",
      "endTime": "2018-05-21T10:17:37.645217-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 32541,
      "engagementTime": 31592,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32541,
  "engagementTime": 31592,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=8MVD2",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "44930674c216c47e5ea32ac0a4532953",
  "gdpr": false
}