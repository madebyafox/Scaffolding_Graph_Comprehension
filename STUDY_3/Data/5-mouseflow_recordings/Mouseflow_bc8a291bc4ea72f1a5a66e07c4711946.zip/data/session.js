var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bc8a291bc4ea72f1a5a66e07c4711946",
  "created": "2018-06-04T12:12:56.7568376-07:00",
  "lastActivity": "2018-06-04T12:13:19.5219085-07:00",
  "pageViews": [
    {
      "id": "06045668bf2e2ef1a6c2f3e2abd3fb5ace80b142",
      "startTime": "2018-06-04T12:12:56.8668586-07:00",
      "endTime": "2018-06-04T12:13:19.5219085-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 22794,
      "engagementTime": 15777,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22794,
  "engagementTime": 15777,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=S6D2F",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a063c9bc16cd52f202bed79a1b96c40e",
  "gdpr": false
}