var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529455368229d81cd4aa99216f70609d50c8a14"] = {
  "startTime": "2018-05-29T22:10:44.9229421Z",
  "websitePageUrl": "/",
  "visitTime": 56241,
  "engagementTime": 48340,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "ed886c7374aaf064c6dd32d5f0eb84f8",
    "created": "2018-05-29T22:10:44.8296004+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e80a2b2359d2a44f0dc8a71f60b4c7a0",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/ed886c7374aaf064c6dd32d5f0eb84f8/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 289,
      "e": 289,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 3998,
      "e": 3998,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 856,
      "y": 83
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 29203,
      "y": 4563,
      "ta": "html > body"
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 64329,
      "y": 2494,
      "ta": "html > body"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1880,
      "y": 52
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 64467,
      "y": 2677,
      "ta": "html > body"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1834,
      "y": 164
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1631,
      "y": 604
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 54480,
      "y": 51235,
      "ta": "html > body"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1637,
      "y": 976
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1655,
      "y": 986
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1655,
      "y": 987
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 56718,
      "y": 59571,
      "ta": "html > body"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1653,
      "y": 989
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1587,
      "y": 1015
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1571,
      "y": 1026
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 53826,
      "y": 61944,
      "ta": "html > body"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1571,
      "y": 1027
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 53826,
      "y": 62005,
      "ta": "html > body"
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1571,
      "y": 1093
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 53826,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1692,
      "y": 996
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1919,
      "y": 840
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1919,
      "y": 828
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14367,
      "e": 12600,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 15468,
      "e": 12600,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 20002,
      "e": 12600,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20501,
      "e": 12600,
      "ty": 2,
      "x": 1753,
      "y": 1118
    },
    {
      "t": 20501,
      "e": 12600,
      "ty": 41,
      "x": 60093,
      "y": 61490,
      "ta": "> div.masterdiv"
    },
    {
      "t": 20601,
      "e": 12700,
      "ty": 2,
      "x": 1676,
      "y": 1199
    },
    {
      "t": 20701,
      "e": 12800,
      "ty": 2,
      "x": 1579,
      "y": 1187
    },
    {
      "t": 20752,
      "e": 12851,
      "ty": 41,
      "x": 51966,
      "y": 59330,
      "ta": "> div.masterdiv"
    },
    {
      "t": 20802,
      "e": 12901,
      "ty": 2,
      "x": 1381,
      "y": 936
    },
    {
      "t": 20901,
      "e": 13000,
      "ty": 2,
      "x": 920,
      "y": 665
    },
    {
      "t": 21002,
      "e": 13101,
      "ty": 2,
      "x": 647,
      "y": 710
    },
    {
      "t": 21002,
      "e": 13101,
      "ty": 41,
      "x": 17393,
      "y": 17327,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 21101,
      "e": 13200,
      "ty": 2,
      "x": 573,
      "y": 867
    },
    {
      "t": 21201,
      "e": 13300,
      "ty": 2,
      "x": 710,
      "y": 1007
    },
    {
      "t": 21251,
      "e": 13350,
      "ty": 41,
      "x": 23493,
      "y": 63271,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 21301,
      "e": 13400,
      "ty": 2,
      "x": 793,
      "y": 1029
    },
    {
      "t": 21401,
      "e": 13500,
      "ty": 2,
      "x": 858,
      "y": 948
    },
    {
      "t": 21501,
      "e": 13600,
      "ty": 2,
      "x": 857,
      "y": 920
    },
    {
      "t": 21501,
      "e": 13600,
      "ty": 41,
      "x": 11246,
      "y": 35792,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 21601,
      "e": 13700,
      "ty": 2,
      "x": 839,
      "y": 915
    },
    {
      "t": 21702,
      "e": 13801,
      "ty": 2,
      "x": 817,
      "y": 917
    },
    {
      "t": 21751,
      "e": 13850,
      "ty": 41,
      "x": 41164,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 21802,
      "e": 13901,
      "ty": 2,
      "x": 816,
      "y": 917
    },
    {
      "t": 21896,
      "e": 13995,
      "ty": 3,
      "x": 816,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 21999,
      "e": 14098,
      "ty": 4,
      "x": 41164,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 22000,
      "e": 14099,
      "ty": 5,
      "x": 816,
      "y": 917,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 22001,
      "e": 14100,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 22004,
      "e": 14103,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 22202,
      "e": 14301,
      "ty": 2,
      "x": 832,
      "y": 936
    },
    {
      "t": 22251,
      "e": 14350,
      "ty": 41,
      "x": 31857,
      "y": 61678,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 22297,
      "e": 14396,
      "ty": 6,
      "x": 1019,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 22301,
      "e": 14400,
      "ty": 2,
      "x": 1019,
      "y": 1077
    },
    {
      "t": 22314,
      "e": 14413,
      "ty": 7,
      "x": 1038,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 22402,
      "e": 14501,
      "ty": 2,
      "x": 1060,
      "y": 1113
    },
    {
      "t": 22501,
      "e": 14600,
      "ty": 2,
      "x": 1034,
      "y": 1123
    },
    {
      "t": 22501,
      "e": 14600,
      "ty": 41,
      "x": 35333,
      "y": 61767,
      "ta": "> div.masterdiv"
    },
    {
      "t": 22600,
      "e": 14699,
      "ty": 2,
      "x": 1004,
      "y": 1121
    },
    {
      "t": 22664,
      "e": 14763,
      "ty": 6,
      "x": 987,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 22701,
      "e": 14800,
      "ty": 2,
      "x": 983,
      "y": 1095
    },
    {
      "t": 22750,
      "e": 14849,
      "ty": 41,
      "x": 39047,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 22801,
      "e": 14900,
      "ty": 2,
      "x": 981,
      "y": 1090
    },
    {
      "t": 23455,
      "e": 15554,
      "ty": 3,
      "x": 981,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 23457,
      "e": 15556,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 23457,
      "e": 15556,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23565,
      "e": 15664,
      "ty": 4,
      "x": 39047,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 23566,
      "e": 15665,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 23567,
      "e": 15666,
      "ty": 5,
      "x": 981,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 23567,
      "e": 15666,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 24571,
      "e": 16670,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 25100,
      "e": 17199,
      "ty": 2,
      "x": 981,
      "y": 1066
    },
    {
      "t": 25201,
      "e": 17300,
      "ty": 2,
      "x": 955,
      "y": 933
    },
    {
      "t": 25251,
      "e": 17350,
      "ty": 41,
      "x": 31992,
      "y": 45038,
      "ta": "html > body"
    },
    {
      "t": 25300,
      "e": 17399,
      "ty": 6,
      "x": 915,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 25301,
      "e": 17400,
      "ty": 2,
      "x": 915,
      "y": 720
    },
    {
      "t": 25316,
      "e": 17415,
      "ty": 7,
      "x": 911,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 25316,
      "e": 17415,
      "ty": 6,
      "x": 911,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25333,
      "e": 17432,
      "ty": 7,
      "x": 911,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25366,
      "e": 17465,
      "ty": 6,
      "x": 911,
      "y": 592,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25383,
      "e": 17482,
      "ty": 7,
      "x": 911,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25401,
      "e": 17500,
      "ty": 2,
      "x": 913,
      "y": 562
    },
    {
      "t": 25500,
      "e": 17599,
      "ty": 2,
      "x": 914,
      "y": 528
    },
    {
      "t": 25501,
      "e": 17600,
      "ty": 41,
      "x": 22926,
      "y": 4228,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 25601,
      "e": 17700,
      "ty": 2,
      "x": 909,
      "y": 537
    },
    {
      "t": 25651,
      "e": 17750,
      "ty": 6,
      "x": 899,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25700,
      "e": 17799,
      "ty": 2,
      "x": 897,
      "y": 605
    },
    {
      "t": 25718,
      "e": 17817,
      "ty": 7,
      "x": 897,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25751,
      "e": 17850,
      "ty": 41,
      "x": 19033,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 25801,
      "e": 17900,
      "ty": 2,
      "x": 896,
      "y": 609
    },
    {
      "t": 25885,
      "e": 17984,
      "ty": 3,
      "x": 896,
      "y": 609,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 25997,
      "e": 18096,
      "ty": 4,
      "x": 19033,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 25997,
      "e": 18096,
      "ty": 5,
      "x": 896,
      "y": 609,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26168,
      "e": 18267,
      "ty": 6,
      "x": 891,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26200,
      "e": 18299,
      "ty": 2,
      "x": 889,
      "y": 604
    },
    {
      "t": 26251,
      "e": 18350,
      "ty": 41,
      "x": 17519,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26294,
      "e": 18393,
      "ty": 3,
      "x": 889,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26295,
      "e": 18394,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26429,
      "e": 18528,
      "ty": 4,
      "x": 17519,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26429,
      "e": 18528,
      "ty": 5,
      "x": 889,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27954,
      "e": 20053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 27956,
      "e": 20055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28034,
      "e": 20133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "s"
    },
    {
      "t": 28330,
      "e": 20429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 28330,
      "e": 20429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28473,
      "e": 20572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "si"
    },
    {
      "t": 28665,
      "e": 20764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 28665,
      "e": 20764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28753,
      "e": 20852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sie"
    },
    {
      "t": 28857,
      "e": 20956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 28857,
      "e": 20956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28913,
      "e": 21012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sier"
    },
    {
      "t": 28995,
      "e": 21094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 28996,
      "e": 21095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29065,
      "e": 21164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 29218,
      "e": 21317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 29218,
      "e": 21317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29330,
      "e": 21429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||a"
    },
    {
      "t": 30001,
      "e": 22100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31010,
      "e": 23109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 31010,
      "e": 23109,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "sierra"
    },
    {
      "t": 31010,
      "e": 23109,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31011,
      "e": 23110,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31106,
      "e": 23205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 31426,
      "e": 23525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 31426,
      "e": 23525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31529,
      "e": 23628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 31658,
      "e": 23757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 31658,
      "e": 23757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31770,
      "e": 23869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 32458,
      "e": 24557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 32458,
      "e": 24557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32545,
      "e": 24644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 33323,
      "e": 25422,
      "ty": 7,
      "x": 896,
      "y": 623,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33357,
      "e": 25456,
      "ty": 6,
      "x": 972,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33374,
      "e": 25473,
      "ty": 7,
      "x": 1006,
      "y": 757,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33401,
      "e": 25500,
      "ty": 2,
      "x": 1016,
      "y": 768
    },
    {
      "t": 33501,
      "e": 25600,
      "ty": 2,
      "x": 1022,
      "y": 762
    },
    {
      "t": 33501,
      "e": 25600,
      "ty": 41,
      "x": 34919,
      "y": 41769,
      "ta": "html > body"
    },
    {
      "t": 33573,
      "e": 25672,
      "ty": 6,
      "x": 1017,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33601,
      "e": 25700,
      "ty": 2,
      "x": 1016,
      "y": 731
    },
    {
      "t": 33701,
      "e": 25800,
      "ty": 2,
      "x": 1005,
      "y": 723
    },
    {
      "t": 33751,
      "e": 25850,
      "ty": 41,
      "x": 52609,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33801,
      "e": 25900,
      "ty": 2,
      "x": 998,
      "y": 719
    },
    {
      "t": 33829,
      "e": 25928,
      "ty": 3,
      "x": 998,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33830,
      "e": 25929,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 33831,
      "e": 25930,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33831,
      "e": 25930,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33925,
      "e": 26024,
      "ty": 4,
      "x": 52609,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33926,
      "e": 26025,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33926,
      "e": 26025,
      "ty": 5,
      "x": 998,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33926,
      "e": 26025,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 34201,
      "e": 26300,
      "ty": 2,
      "x": 990,
      "y": 719
    },
    {
      "t": 34251,
      "e": 26350,
      "ty": 41,
      "x": 33680,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 34301,
      "e": 26400,
      "ty": 2,
      "x": 986,
      "y": 720
    },
    {
      "t": 34401,
      "e": 26500,
      "ty": 2,
      "x": 988,
      "y": 723
    },
    {
      "t": 34501,
      "e": 26600,
      "ty": 2,
      "x": 1012,
      "y": 729
    },
    {
      "t": 34501,
      "e": 26600,
      "ty": 41,
      "x": 34575,
      "y": 39941,
      "ta": "html > body"
    },
    {
      "t": 35018,
      "e": 27117,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 35047,
      "e": 27146,
      "ty": 6,
      "x": 1012,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38043,
      "e": 30142,
      "ty": 7,
      "x": 1038,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 38044,
      "e": 30143,
      "ty": 6,
      "x": 1038,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38060,
      "e": 30159,
      "ty": 7,
      "x": 1058,
      "y": 802,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 38101,
      "e": 30200,
      "ty": 2,
      "x": 1102,
      "y": 895
    },
    {
      "t": 38201,
      "e": 30300,
      "ty": 2,
      "x": 1193,
      "y": 1103
    },
    {
      "t": 38251,
      "e": 30350,
      "ty": 41,
      "x": 40636,
      "y": 61214,
      "ta": "> div.masterdiv"
    },
    {
      "t": 38301,
      "e": 30400,
      "ty": 2,
      "x": 1170,
      "y": 1115
    },
    {
      "t": 38401,
      "e": 30500,
      "ty": 2,
      "x": 1156,
      "y": 1115
    },
    {
      "t": 38502,
      "e": 30601,
      "ty": 2,
      "x": 1091,
      "y": 1127
    },
    {
      "t": 38502,
      "e": 30601,
      "ty": 41,
      "x": 37296,
      "y": 61989,
      "ta": "> div.masterdiv"
    },
    {
      "t": 38601,
      "e": 30700,
      "ty": 2,
      "x": 1018,
      "y": 1132
    },
    {
      "t": 38702,
      "e": 30801,
      "ty": 2,
      "x": 1000,
      "y": 1131
    },
    {
      "t": 38752,
      "e": 30851,
      "ty": 41,
      "x": 51257,
      "y": 32304,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 38801,
      "e": 30900,
      "ty": 2,
      "x": 999,
      "y": 1131
    },
    {
      "t": 38900,
      "e": 30999,
      "ty": 2,
      "x": 999,
      "y": 1112
    },
    {
      "t": 38927,
      "e": 31026,
      "ty": 6,
      "x": 999,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 39001,
      "e": 31100,
      "ty": 2,
      "x": 998,
      "y": 1102
    },
    {
      "t": 39001,
      "e": 31100,
      "ty": 41,
      "x": 48332,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 40002,
      "e": 32101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40602,
      "e": 32701,
      "ty": 2,
      "x": 993,
      "y": 1086
    },
    {
      "t": 40702,
      "e": 32801,
      "ty": 2,
      "x": 992,
      "y": 1083
    },
    {
      "t": 40752,
      "e": 32851,
      "ty": 41,
      "x": 44509,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 40802,
      "e": 32901,
      "ty": 2,
      "x": 991,
      "y": 1076
    },
    {
      "t": 40901,
      "e": 33000,
      "ty": 2,
      "x": 990,
      "y": 1073
    },
    {
      "t": 40949,
      "e": 33048,
      "ty": 7,
      "x": 989,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 41001,
      "e": 33100,
      "ty": 2,
      "x": 989,
      "y": 1071
    },
    {
      "t": 41002,
      "e": 33101,
      "ty": 41,
      "x": 34218,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 41301,
      "e": 33400,
      "ty": 2,
      "x": 988,
      "y": 1071
    },
    {
      "t": 41401,
      "e": 33500,
      "ty": 2,
      "x": 982,
      "y": 1071
    },
    {
      "t": 41501,
      "e": 33600,
      "ty": 2,
      "x": 977,
      "y": 1071
    },
    {
      "t": 41501,
      "e": 33600,
      "ty": 41,
      "x": 33628,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 41513,
      "e": 33612,
      "ty": 6,
      "x": 974,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 41601,
      "e": 33700,
      "ty": 2,
      "x": 964,
      "y": 1077
    },
    {
      "t": 41701,
      "e": 33800,
      "ty": 2,
      "x": 957,
      "y": 1080
    },
    {
      "t": 41752,
      "e": 33851,
      "ty": 41,
      "x": 25940,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 45662,
      "e": 37761,
      "ty": 3,
      "x": 957,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 45662,
      "e": 37761,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 45773,
      "e": 37872,
      "ty": 4,
      "x": 25940,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 45774,
      "e": 37873,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 45774,
      "e": 37873,
      "ty": 5,
      "x": 957,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 45775,
      "e": 37874,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 46200,
      "e": 38299,
      "ty": 2,
      "x": 942,
      "y": 1027
    },
    {
      "t": 46250,
      "e": 38349,
      "ty": 41,
      "x": 31131,
      "y": 52516,
      "ta": "html > body"
    },
    {
      "t": 46301,
      "e": 38400,
      "ty": 2,
      "x": 874,
      "y": 902
    },
    {
      "t": 46401,
      "e": 38500,
      "ty": 2,
      "x": 862,
      "y": 882
    },
    {
      "t": 46501,
      "e": 38600,
      "ty": 41,
      "x": 29409,
      "y": 48417,
      "ta": "html > body"
    },
    {
      "t": 46777,
      "e": 38876,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 46800,
      "e": 38899,
      "ty": 2,
      "x": 855,
      "y": 843
    },
    {
      "t": 46900,
      "e": 38999,
      "ty": 2,
      "x": 811,
      "y": 713
    },
    {
      "t": 47001,
      "e": 39100,
      "ty": 2,
      "x": 778,
      "y": 658
    },
    {
      "t": 47001,
      "e": 39100,
      "ty": 41,
      "x": 23956,
      "y": 39794,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47101,
      "e": 39200,
      "ty": 2,
      "x": 773,
      "y": 657
    },
    {
      "t": 47251,
      "e": 39350,
      "ty": 41,
      "x": 23713,
      "y": 39717,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 48301,
      "e": 40400,
      "ty": 2,
      "x": 772,
      "y": 658
    },
    {
      "t": 48401,
      "e": 40500,
      "ty": 2,
      "x": 766,
      "y": 660
    },
    {
      "t": 48501,
      "e": 40600,
      "ty": 41,
      "x": 23374,
      "y": 39949,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50001,
      "e": 42100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51601,
      "e": 43700,
      "ty": 2,
      "x": 778,
      "y": 680
    },
    {
      "t": 51701,
      "e": 43800,
      "ty": 2,
      "x": 1022,
      "y": 882
    },
    {
      "t": 51752,
      "e": 43851,
      "ty": 41,
      "x": 38277,
      "y": 60216,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 51801,
      "e": 43900,
      "ty": 2,
      "x": 1088,
      "y": 939
    },
    {
      "t": 51901,
      "e": 44000,
      "ty": 2,
      "x": 1114,
      "y": 986
    },
    {
      "t": 52001,
      "e": 44100,
      "ty": 2,
      "x": 1114,
      "y": 987
    },
    {
      "t": 52001,
      "e": 44100,
      "ty": 41,
      "x": 40267,
      "y": 65340,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 53001,
      "e": 45100,
      "ty": 2,
      "x": 1113,
      "y": 987
    },
    {
      "t": 53001,
      "e": 45100,
      "ty": 41,
      "x": 40219,
      "y": 65340,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 53101,
      "e": 45200,
      "ty": 2,
      "x": 1104,
      "y": 990
    },
    {
      "t": 53201,
      "e": 45300,
      "ty": 2,
      "x": 1093,
      "y": 994
    },
    {
      "t": 53251,
      "e": 45350,
      "ty": 41,
      "x": 37054,
      "y": 54732,
      "ta": "html > body"
    },
    {
      "t": 53301,
      "e": 45400,
      "ty": 2,
      "x": 1074,
      "y": 999
    },
    {
      "t": 53401,
      "e": 45500,
      "ty": 2,
      "x": 1056,
      "y": 1004
    },
    {
      "t": 53501,
      "e": 45600,
      "ty": 2,
      "x": 1052,
      "y": 1005
    },
    {
      "t": 53502,
      "e": 45601,
      "ty": 41,
      "x": 35952,
      "y": 55231,
      "ta": "html > body"
    },
    {
      "t": 53901,
      "e": 46000,
      "ty": 2,
      "x": 1132,
      "y": 983
    },
    {
      "t": 54000,
      "e": 46099,
      "ty": 2,
      "x": 1254,
      "y": 980
    },
    {
      "t": 54001,
      "e": 46100,
      "ty": 41,
      "x": 47063,
      "y": 64797,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 54101,
      "e": 46200,
      "ty": 2,
      "x": 1414,
      "y": 982
    },
    {
      "t": 54251,
      "e": 46350,
      "ty": 41,
      "x": 54830,
      "y": 64952,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 55234,
      "e": 47333,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 56241,
      "e": 48340,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 706, dom: 1344, initialDom: 1384",
  "javascriptErrors": []
}