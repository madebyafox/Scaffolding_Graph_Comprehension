var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "63f3216b7777c953e45b5214efc66a46",
  "created": "2018-06-04T12:20:40.8534894-07:00",
  "lastActivity": "2018-06-04T12:21:00.6384894-07:00",
  "pageViews": [
    {
      "id": "060441315df6d5586f232edc53de0ebde2ba6122",
      "startTime": "2018-06-04T12:20:40.8534894-07:00",
      "endTime": "2018-06-04T12:21:00.6384894-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 19785,
      "engagementTime": 19612,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19785,
  "engagementTime": 19612,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G27Q3",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b86500075ba1f62b39528fca7d78b5b4",
  "gdpr": false
}