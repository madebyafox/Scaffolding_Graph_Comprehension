var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052439482e4332fd144a2244cffc0cc7dcbc818d"] = {
  "startTime": "2018-05-24T19:03:39.9232184Z",
  "websitePageUrl": "/",
  "visitTime": 109552,
  "engagementTime": 52293,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "0941ee99e3278bd471f885ea6da3ff49",
    "created": "2018-05-24T19:03:39.9232184+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "af37164fc8b6ca9d962f43f3b39b9794",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0941ee99e3278bd471f885ea6da3ff49/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 307,
      "e": 307,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 4305,
      "e": 4305,
      "ty": 2,
      "x": 602,
      "y": 122
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 916,
      "y": 628
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1281,
      "y": 935
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 50325,
      "y": 64592,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1081,
      "y": 825
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 650,
      "y": 518
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 15701,
      "y": 29777,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 647,
      "y": 506
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 731,
      "y": 519
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 765,
      "y": 524
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 22145,
      "y": 30924,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 796,
      "y": 530
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 24220,
      "y": 31333,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 806,
      "y": 527
    },
    {
      "t": 5406,
      "e": 5406,
      "ty": 2,
      "x": 807,
      "y": 527
    },
    {
      "t": 5506,
      "e": 5506,
      "ty": 41,
      "x": 24439,
      "y": 31170,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5906,
      "e": 5906,
      "ty": 2,
      "x": 807,
      "y": 526
    },
    {
      "t": 6007,
      "e": 6007,
      "ty": 41,
      "x": 24439,
      "y": 31088,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10006,
      "e": 10006,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12903,
      "e": 11007,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 13001,
      "e": 11105,
      "ty": 2,
      "x": 807,
      "y": 592
    },
    {
      "t": 13001,
      "e": 11105,
      "ty": 41,
      "x": 24439,
      "y": 32153,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20005,
      "e": 16105,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 66604,
      "e": 16105,
      "ty": 2,
      "x": 667,
      "y": 773
    },
    {
      "t": 66705,
      "e": 16206,
      "ty": 2,
      "x": 624,
      "y": 859
    },
    {
      "t": 66754,
      "e": 16255,
      "ty": 41,
      "x": 20738,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66804,
      "e": 16305,
      "ty": 2,
      "x": 829,
      "y": 1028
    },
    {
      "t": 66904,
      "e": 16405,
      "ty": 2,
      "x": 920,
      "y": 974
    },
    {
      "t": 67003,
      "e": 16504,
      "ty": 2,
      "x": 870,
      "y": 930
    },
    {
      "t": 67004,
      "e": 16505,
      "ty": 41,
      "x": 28364,
      "y": 56530,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 67103,
      "e": 16604,
      "ty": 2,
      "x": 819,
      "y": 922
    },
    {
      "t": 67203,
      "e": 16704,
      "ty": 2,
      "x": 813,
      "y": 922
    },
    {
      "t": 67236,
      "e": 16737,
      "ty": 3,
      "x": 813,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 67254,
      "e": 16755,
      "ty": 41,
      "x": 31333,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 67339,
      "e": 16840,
      "ty": 4,
      "x": 31333,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 67339,
      "e": 16840,
      "ty": 5,
      "x": 813,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 67340,
      "e": 16841,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 67344,
      "e": 16845,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 67403,
      "e": 16904,
      "ty": 2,
      "x": 813,
      "y": 923
    },
    {
      "t": 67503,
      "e": 17004,
      "ty": 2,
      "x": 907,
      "y": 989
    },
    {
      "t": 67503,
      "e": 17004,
      "ty": 41,
      "x": 30184,
      "y": 59739,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 67603,
      "e": 17104,
      "ty": 2,
      "x": 992,
      "y": 1056
    },
    {
      "t": 67703,
      "e": 17204,
      "ty": 2,
      "x": 1016,
      "y": 1084
    },
    {
      "t": 67754,
      "e": 17255,
      "ty": 41,
      "x": 58162,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 67804,
      "e": 17305,
      "ty": 2,
      "x": 1016,
      "y": 1085
    },
    {
      "t": 67875,
      "e": 17376,
      "ty": 3,
      "x": 1016,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 67875,
      "e": 17376,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 67876,
      "e": 17377,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 67962,
      "e": 17463,
      "ty": 4,
      "x": 58162,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 67963,
      "e": 17464,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 67965,
      "e": 17466,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 67965,
      "e": 17466,
      "ty": 5,
      "x": 1016,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 68003,
      "e": 17504,
      "ty": 41,
      "x": 34713,
      "y": 59662,
      "ta": "html > body"
    },
    {
      "t": 68204,
      "e": 17705,
      "ty": 2,
      "x": 990,
      "y": 1081
    },
    {
      "t": 68253,
      "e": 17754,
      "ty": 41,
      "x": 31407,
      "y": 56837,
      "ta": "html > body"
    },
    {
      "t": 68304,
      "e": 17805,
      "ty": 2,
      "x": 832,
      "y": 967
    },
    {
      "t": 68404,
      "e": 17905,
      "ty": 2,
      "x": 582,
      "y": 758
    },
    {
      "t": 68504,
      "e": 18005,
      "ty": 2,
      "x": 302,
      "y": 492
    },
    {
      "t": 68504,
      "e": 18005,
      "ty": 41,
      "x": 10124,
      "y": 26812,
      "ta": "html > body"
    },
    {
      "t": 68603,
      "e": 18104,
      "ty": 2,
      "x": 267,
      "y": 318
    },
    {
      "t": 68703,
      "e": 18204,
      "ty": 2,
      "x": 240,
      "y": 220
    },
    {
      "t": 68754,
      "e": 18255,
      "ty": 41,
      "x": 7576,
      "y": 10026,
      "ta": "html > body"
    },
    {
      "t": 68803,
      "e": 18304,
      "ty": 2,
      "x": 212,
      "y": 156
    },
    {
      "t": 68904,
      "e": 18405,
      "ty": 2,
      "x": 203,
      "y": 140
    },
    {
      "t": 68970,
      "e": 18471,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 69003,
      "e": 18504,
      "ty": 2,
      "x": 203,
      "y": 139
    },
    {
      "t": 69003,
      "e": 18504,
      "ty": 41,
      "x": 6715,
      "y": 7257,
      "ta": "html > body"
    },
    {
      "t": 69404,
      "e": 18905,
      "ty": 2,
      "x": 202,
      "y": 135
    },
    {
      "t": 69504,
      "e": 19005,
      "ty": 2,
      "x": 194,
      "y": 118
    },
    {
      "t": 69504,
      "e": 19005,
      "ty": 41,
      "x": 6405,
      "y": 6093,
      "ta": "html > body"
    },
    {
      "t": 69753,
      "e": 19254,
      "ty": 41,
      "x": 6749,
      "y": 7755,
      "ta": "html > body"
    },
    {
      "t": 69803,
      "e": 19304,
      "ty": 2,
      "x": 504,
      "y": 501
    },
    {
      "t": 69903,
      "e": 19404,
      "ty": 2,
      "x": 800,
      "y": 662
    },
    {
      "t": 70004,
      "e": 19505,
      "ty": 2,
      "x": 817,
      "y": 643
    },
    {
      "t": 70004,
      "e": 19505,
      "ty": 41,
      "x": 1946,
      "y": 23405,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 70104,
      "e": 19605,
      "ty": 2,
      "x": 839,
      "y": 630
    },
    {
      "t": 70203,
      "e": 19704,
      "ty": 2,
      "x": 851,
      "y": 621
    },
    {
      "t": 70254,
      "e": 19755,
      "ty": 41,
      "x": 11679,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 70303,
      "e": 19804,
      "ty": 2,
      "x": 862,
      "y": 608
    },
    {
      "t": 70324,
      "e": 19825,
      "ty": 3,
      "x": 862,
      "y": 608,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 70427,
      "e": 19928,
      "ty": 4,
      "x": 11679,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 70427,
      "e": 19928,
      "ty": 5,
      "x": 862,
      "y": 608,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 70476,
      "e": 19977,
      "ty": 6,
      "x": 867,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70504,
      "e": 20005,
      "ty": 2,
      "x": 868,
      "y": 602
    },
    {
      "t": 70504,
      "e": 20005,
      "ty": 41,
      "x": 12977,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70579,
      "e": 20080,
      "ty": 3,
      "x": 870,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70579,
      "e": 20080,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70603,
      "e": 20104,
      "ty": 2,
      "x": 870,
      "y": 599
    },
    {
      "t": 70674,
      "e": 20175,
      "ty": 4,
      "x": 13409,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70675,
      "e": 20176,
      "ty": 5,
      "x": 870,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70754,
      "e": 20255,
      "ty": 41,
      "x": 13409,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72816,
      "e": 22317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 72820,
      "e": 22321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72894,
      "e": 22395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "k"
    },
    {
      "t": 72999,
      "e": 22500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 72999,
      "e": 22500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73079,
      "e": 22580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 73199,
      "e": 22700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 73200,
      "e": 22701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73271,
      "e": 22772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kil"
    },
    {
      "t": 73383,
      "e": 22884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 73384,
      "e": 22885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73398,
      "e": 22899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 74004,
      "e": 23505,
      "ty": 2,
      "x": 870,
      "y": 606
    },
    {
      "t": 74004,
      "e": 23505,
      "ty": 41,
      "x": 13409,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74008,
      "e": 23509,
      "ty": 7,
      "x": 870,
      "y": 614,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74104,
      "e": 23605,
      "ty": 2,
      "x": 878,
      "y": 669
    },
    {
      "t": 74191,
      "e": 23692,
      "ty": 6,
      "x": 878,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74204,
      "e": 23705,
      "ty": 2,
      "x": 878,
      "y": 683
    },
    {
      "t": 74254,
      "e": 23755,
      "ty": 41,
      "x": 15140,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74303,
      "e": 23804,
      "ty": 2,
      "x": 878,
      "y": 695
    },
    {
      "t": 74379,
      "e": 23880,
      "ty": 3,
      "x": 878,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74380,
      "e": 23881,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 74380,
      "e": 23881,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74381,
      "e": 23882,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74514,
      "e": 24015,
      "ty": 4,
      "x": 15140,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74514,
      "e": 24015,
      "ty": 5,
      "x": 878,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75046,
      "e": 24547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 75047,
      "e": 24548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75111,
      "e": 24612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 75199,
      "e": 24700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 75200,
      "e": 24701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75246,
      "e": 24747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 75375,
      "e": 24876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 75375,
      "e": 24876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75455,
      "e": 24956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 76031,
      "e": 25532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 76031,
      "e": 25532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76110,
      "e": 25611,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 77643,
      "e": 27144,
      "ty": 7,
      "x": 900,
      "y": 717,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77643,
      "e": 27144,
      "ty": 6,
      "x": 900,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77694,
      "e": 27195,
      "ty": 7,
      "x": 967,
      "y": 746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77705,
      "e": 27196,
      "ty": 2,
      "x": 967,
      "y": 746
    },
    {
      "t": 77754,
      "e": 27245,
      "ty": 41,
      "x": 33680,
      "y": 41160,
      "ta": "html > body"
    },
    {
      "t": 77804,
      "e": 27295,
      "ty": 2,
      "x": 991,
      "y": 751
    },
    {
      "t": 77876,
      "e": 27367,
      "ty": 6,
      "x": 997,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77904,
      "e": 27395,
      "ty": 2,
      "x": 999,
      "y": 732
    },
    {
      "t": 77979,
      "e": 27470,
      "ty": 7,
      "x": 1003,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78003,
      "e": 27494,
      "ty": 2,
      "x": 1003,
      "y": 707
    },
    {
      "t": 78004,
      "e": 27495,
      "ty": 41,
      "x": 42175,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78043,
      "e": 27534,
      "ty": 3,
      "x": 1003,
      "y": 707,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78043,
      "e": 27534,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 78043,
      "e": 27534,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78122,
      "e": 27613,
      "ty": 4,
      "x": 42175,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78122,
      "e": 27613,
      "ty": 5,
      "x": 1003,
      "y": 707,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 78292,
      "e": 27783,
      "ty": 6,
      "x": 1003,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78304,
      "e": 27795,
      "ty": 2,
      "x": 1003,
      "y": 708
    },
    {
      "t": 78404,
      "e": 27895,
      "ty": 2,
      "x": 1000,
      "y": 717
    },
    {
      "t": 78426,
      "e": 27917,
      "ty": 3,
      "x": 1000,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78427,
      "e": 27918,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78499,
      "e": 27990,
      "ty": 4,
      "x": 53640,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78502,
      "e": 27993,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78502,
      "e": 27993,
      "ty": 5,
      "x": 1000,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 78504,
      "e": 27995,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 78506,
      "e": 27997,
      "ty": 41,
      "x": 34162,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 78754,
      "e": 28245,
      "ty": 41,
      "x": 32819,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 78804,
      "e": 28295,
      "ty": 2,
      "x": 810,
      "y": 667
    },
    {
      "t": 78904,
      "e": 28395,
      "ty": 2,
      "x": 403,
      "y": 513
    },
    {
      "t": 79004,
      "e": 28495,
      "ty": 2,
      "x": 0,
      "y": 310
    },
    {
      "t": 79005,
      "e": 28496,
      "ty": 41,
      "x": 0,
      "y": 17173,
      "ta": "html"
    },
    {
      "t": 79104,
      "e": 28595,
      "ty": 2,
      "x": 0,
      "y": 238
    },
    {
      "t": 79204,
      "e": 28695,
      "ty": 2,
      "x": 0,
      "y": 237
    },
    {
      "t": 79254,
      "e": 28745,
      "ty": 41,
      "x": 0,
      "y": 13129,
      "ta": "html"
    },
    {
      "t": 79590,
      "e": 29081,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 80404,
      "e": 29895,
      "ty": 2,
      "x": 0,
      "y": 236
    },
    {
      "t": 80505,
      "e": 29996,
      "ty": 41,
      "x": 0,
      "y": 13073,
      "ta": "html"
    },
    {
      "t": 82604,
      "e": 32095,
      "ty": 2,
      "x": 18,
      "y": 241
    },
    {
      "t": 82704,
      "e": 32195,
      "ty": 2,
      "x": 247,
      "y": 333
    },
    {
      "t": 82755,
      "e": 32246,
      "ty": 41,
      "x": 6520,
      "y": 8210,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 82805,
      "e": 32296,
      "ty": 2,
      "x": 590,
      "y": 481
    },
    {
      "t": 82904,
      "e": 32395,
      "ty": 2,
      "x": 670,
      "y": 503
    },
    {
      "t": 83005,
      "e": 32496,
      "ty": 41,
      "x": 36698,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 83204,
      "e": 32695,
      "ty": 2,
      "x": 669,
      "y": 503
    },
    {
      "t": 83254,
      "e": 32745,
      "ty": 41,
      "x": 36589,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 89504,
      "e": 37745,
      "ty": 2,
      "x": 664,
      "y": 503
    },
    {
      "t": 89504,
      "e": 37745,
      "ty": 41,
      "x": 36043,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 89604,
      "e": 37845,
      "ty": 2,
      "x": 585,
      "y": 491
    },
    {
      "t": 89704,
      "e": 37945,
      "ty": 2,
      "x": 505,
      "y": 491
    },
    {
      "t": 89754,
      "e": 37995,
      "ty": 41,
      "x": 16307,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 89788,
      "e": 38029,
      "ty": 6,
      "x": 464,
      "y": 520,
      "ta": "#da1"
    },
    {
      "t": 89804,
      "e": 38045,
      "ty": 2,
      "x": 453,
      "y": 526
    },
    {
      "t": 89904,
      "e": 38145,
      "ty": 2,
      "x": 449,
      "y": 527
    },
    {
      "t": 90004,
      "e": 38245,
      "ty": 41,
      "x": 12613,
      "y": 49202,
      "ta": "#da1"
    },
    {
      "t": 90004,
      "e": 38245,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90303,
      "e": 38544,
      "ty": 2,
      "x": 449,
      "y": 529
    },
    {
      "t": 90404,
      "e": 38645,
      "ty": 2,
      "x": 457,
      "y": 530
    },
    {
      "t": 90472,
      "e": 38713,
      "ty": 7,
      "x": 540,
      "y": 535,
      "ta": "#da1"
    },
    {
      "t": 90504,
      "e": 38745,
      "ty": 2,
      "x": 570,
      "y": 544
    },
    {
      "t": 90504,
      "e": 38745,
      "ty": 41,
      "x": 13605,
      "y": 33033,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 90604,
      "e": 38845,
      "ty": 2,
      "x": 699,
      "y": 582
    },
    {
      "t": 90704,
      "e": 38945,
      "ty": 2,
      "x": 833,
      "y": 627
    },
    {
      "t": 90754,
      "e": 38995,
      "ty": 41,
      "x": 29249,
      "y": 39825,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 90789,
      "e": 39030,
      "ty": 6,
      "x": 951,
      "y": 672,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 90804,
      "e": 39045,
      "ty": 2,
      "x": 951,
      "y": 672
    },
    {
      "t": 90838,
      "e": 39079,
      "ty": 7,
      "x": 997,
      "y": 710,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 90839,
      "e": 39080,
      "ty": 6,
      "x": 997,
      "y": 710,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 90855,
      "e": 39096,
      "ty": 7,
      "x": 1011,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 90855,
      "e": 39096,
      "ty": 6,
      "x": 1011,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 90888,
      "e": 39129,
      "ty": 7,
      "x": 1031,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 90889,
      "e": 39130,
      "ty": 6,
      "x": 1031,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 90904,
      "e": 39145,
      "ty": 2,
      "x": 1031,
      "y": 771
    },
    {
      "t": 90905,
      "e": 39146,
      "ty": 7,
      "x": 1042,
      "y": 807,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 91004,
      "e": 39245,
      "ty": 2,
      "x": 1054,
      "y": 868
    },
    {
      "t": 91004,
      "e": 39245,
      "ty": 41,
      "x": 37416,
      "y": 51360,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91503,
      "e": 39744,
      "ty": 2,
      "x": 1049,
      "y": 874
    },
    {
      "t": 91504,
      "e": 39745,
      "ty": 41,
      "x": 37170,
      "y": 51776,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91604,
      "e": 39845,
      "ty": 2,
      "x": 998,
      "y": 908
    },
    {
      "t": 91704,
      "e": 39945,
      "ty": 2,
      "x": 989,
      "y": 960
    },
    {
      "t": 91754,
      "e": 39995,
      "ty": 41,
      "x": 34268,
      "y": 58354,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91803,
      "e": 40044,
      "ty": 2,
      "x": 990,
      "y": 969
    },
    {
      "t": 92004,
      "e": 40245,
      "ty": 2,
      "x": 990,
      "y": 971
    },
    {
      "t": 92004,
      "e": 40245,
      "ty": 41,
      "x": 34268,
      "y": 58493,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92104,
      "e": 40345,
      "ty": 2,
      "x": 982,
      "y": 983
    },
    {
      "t": 92203,
      "e": 40444,
      "ty": 2,
      "x": 977,
      "y": 1001
    },
    {
      "t": 92254,
      "e": 40495,
      "ty": 41,
      "x": 33628,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92304,
      "e": 40545,
      "ty": 2,
      "x": 977,
      "y": 1013
    },
    {
      "t": 92504,
      "e": 40745,
      "ty": 41,
      "x": 33628,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94604,
      "e": 42845,
      "ty": 2,
      "x": 987,
      "y": 1036
    },
    {
      "t": 94704,
      "e": 42945,
      "ty": 2,
      "x": 990,
      "y": 1044
    },
    {
      "t": 94754,
      "e": 42995,
      "ty": 41,
      "x": 34268,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94804,
      "e": 43045,
      "ty": 2,
      "x": 992,
      "y": 1050
    },
    {
      "t": 94903,
      "e": 43144,
      "ty": 2,
      "x": 996,
      "y": 1068
    },
    {
      "t": 94925,
      "e": 43166,
      "ty": 6,
      "x": 997,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 95004,
      "e": 43245,
      "ty": 2,
      "x": 999,
      "y": 1078
    },
    {
      "t": 95004,
      "e": 43245,
      "ty": 41,
      "x": 48878,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 95104,
      "e": 43345,
      "ty": 2,
      "x": 998,
      "y": 1079
    },
    {
      "t": 95204,
      "e": 43445,
      "ty": 2,
      "x": 998,
      "y": 1080
    },
    {
      "t": 95254,
      "e": 43495,
      "ty": 41,
      "x": 48332,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 95388,
      "e": 43629,
      "ty": 3,
      "x": 998,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 95389,
      "e": 43630,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95498,
      "e": 43739,
      "ty": 4,
      "x": 48332,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 95499,
      "e": 43740,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95500,
      "e": 43741,
      "ty": 5,
      "x": 998,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 95502,
      "e": 43743,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 96004,
      "e": 44245,
      "ty": 2,
      "x": 948,
      "y": 1053
    },
    {
      "t": 96005,
      "e": 44246,
      "ty": 41,
      "x": 32371,
      "y": 57890,
      "ta": "html > body"
    },
    {
      "t": 96104,
      "e": 44345,
      "ty": 2,
      "x": 703,
      "y": 898
    },
    {
      "t": 96204,
      "e": 44445,
      "ty": 2,
      "x": 575,
      "y": 771
    },
    {
      "t": 96254,
      "e": 44495,
      "ty": 41,
      "x": 19560,
      "y": 41104,
      "ta": "html > body"
    },
    {
      "t": 96303,
      "e": 44544,
      "ty": 2,
      "x": 578,
      "y": 745
    },
    {
      "t": 96501,
      "e": 44742,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 96504,
      "e": 44745,
      "ty": 41,
      "x": 14247,
      "y": 46550,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 100004,
      "e": 48245,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 107004,
      "e": 49745,
      "ty": 2,
      "x": 603,
      "y": 739
    },
    {
      "t": 107004,
      "e": 49745,
      "ty": 41,
      "x": 15461,
      "y": 46084,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 107103,
      "e": 49844,
      "ty": 2,
      "x": 713,
      "y": 771
    },
    {
      "t": 107203,
      "e": 49944,
      "ty": 2,
      "x": 1004,
      "y": 977
    },
    {
      "t": 107254,
      "e": 49995,
      "ty": 41,
      "x": 38019,
      "y": 57391,
      "ta": "html > body"
    },
    {
      "t": 107305,
      "e": 50046,
      "ty": 2,
      "x": 1121,
      "y": 1049
    },
    {
      "t": 107505,
      "e": 50246,
      "ty": 2,
      "x": 1110,
      "y": 1045
    },
    {
      "t": 107505,
      "e": 50246,
      "ty": 41,
      "x": 37950,
      "y": 57446,
      "ta": "html > body"
    },
    {
      "t": 107604,
      "e": 50345,
      "ty": 2,
      "x": 1069,
      "y": 1026
    },
    {
      "t": 107704,
      "e": 50445,
      "ty": 2,
      "x": 1065,
      "y": 1025
    },
    {
      "t": 107755,
      "e": 50496,
      "ty": 41,
      "x": 36400,
      "y": 56339,
      "ta": "html > body"
    },
    {
      "t": 108545,
      "e": 51286,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 109403,
      "e": 52144,
      "ty": 2,
      "x": 1032,
      "y": 930
    },
    {
      "t": 109504,
      "e": 52245,
      "ty": 2,
      "x": 992,
      "y": 834
    },
    {
      "t": 109504,
      "e": 52245,
      "ty": 41,
      "x": 33886,
      "y": 45758,
      "ta": "html > body"
    },
    {
      "t": 109552,
      "e": 52293,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 147, dom: 607, initialDom: 611",
  "javascriptErrors": []
}