var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05252918feefd1a747c3af00a04e0544174982cc"] = {
  "startTime": "2018-05-25T16:59:29.419707Z",
  "websitePageUrl": "/16",
  "visitTime": 111124,
  "engagementTime": 87583,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "9e889a3ec7f0b4af3e61124a3b318719",
    "created": "2018-05-25T16:59:29.419707+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=3H1U8",
      "CONDITION=115-late"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2973171b630c7fe2618da9e3da9f0317",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/9e889a3ec7f0b4af3e61124a3b318719/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 105,
      "e": 105,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 667,
      "e": 667,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1205,
      "e": 1205,
      "ty": 2,
      "x": 868,
      "y": 785
    },
    {
      "t": 1255,
      "e": 1255,
      "ty": 41,
      "x": 4528,
      "y": 46506,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1305,
      "e": 1305,
      "ty": 2,
      "x": 722,
      "y": 779
    },
    {
      "t": 1404,
      "e": 1404,
      "ty": 2,
      "x": 679,
      "y": 687
    },
    {
      "t": 1505,
      "e": 1505,
      "ty": 2,
      "x": 633,
      "y": 642
    },
    {
      "t": 1506,
      "e": 1506,
      "ty": 41,
      "x": 60241,
      "y": 35121,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1605,
      "e": 1605,
      "ty": 2,
      "x": 609,
      "y": 606
    },
    {
      "t": 1609,
      "e": 1609,
      "ty": 6,
      "x": 606,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1705,
      "e": 1705,
      "ty": 2,
      "x": 587,
      "y": 559
    },
    {
      "t": 1755,
      "e": 1755,
      "ty": 41,
      "x": 54733,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1805,
      "e": 1805,
      "ty": 2,
      "x": 584,
      "y": 546
    },
    {
      "t": 1815,
      "e": 1815,
      "ty": 3,
      "x": 584,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1816,
      "e": 1816,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1950,
      "e": 1950,
      "ty": 4,
      "x": 54733,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1951,
      "e": 1951,
      "ty": 5,
      "x": 584,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2254,
      "e": 2254,
      "ty": 41,
      "x": 54733,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2305,
      "e": 2305,
      "ty": 2,
      "x": 584,
      "y": 554
    },
    {
      "t": 2405,
      "e": 2405,
      "ty": 2,
      "x": 592,
      "y": 570
    },
    {
      "t": 2505,
      "e": 2505,
      "ty": 2,
      "x": 594,
      "y": 572
    },
    {
      "t": 2505,
      "e": 2505,
      "ty": 41,
      "x": 55857,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2604,
      "e": 2604,
      "ty": 2,
      "x": 595,
      "y": 575
    },
    {
      "t": 2705,
      "e": 2705,
      "ty": 2,
      "x": 602,
      "y": 595
    },
    {
      "t": 2711,
      "e": 2711,
      "ty": 7,
      "x": 606,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2755,
      "e": 2755,
      "ty": 41,
      "x": 57880,
      "y": 34401,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2805,
      "e": 2805,
      "ty": 2,
      "x": 616,
      "y": 645
    },
    {
      "t": 2905,
      "e": 2905,
      "ty": 2,
      "x": 615,
      "y": 646
    },
    {
      "t": 2994,
      "e": 2994,
      "ty": 6,
      "x": 590,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3004,
      "e": 3004,
      "ty": 2,
      "x": 590,
      "y": 599
    },
    {
      "t": 3005,
      "e": 3005,
      "ty": 41,
      "x": 55407,
      "y": 61704,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3105,
      "e": 3105,
      "ty": 2,
      "x": 565,
      "y": 579
    },
    {
      "t": 3204,
      "e": 3204,
      "ty": 2,
      "x": 560,
      "y": 577
    },
    {
      "t": 3254,
      "e": 3254,
      "ty": 41,
      "x": 52035,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3361,
      "e": 3361,
      "ty": 7,
      "x": 589,
      "y": 639,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3404,
      "e": 3404,
      "ty": 2,
      "x": 646,
      "y": 784
    },
    {
      "t": 3504,
      "e": 3504,
      "ty": 2,
      "x": 682,
      "y": 889
    },
    {
      "t": 3504,
      "e": 3504,
      "ty": 41,
      "x": 109,
      "y": 53322,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 10004,
      "e": 8504,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12716,
      "e": 8504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12717,
      "e": 8505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12802,
      "e": 8590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 12931,
      "e": 8719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12931,
      "e": 8719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12993,
      "e": 8781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 13066,
      "e": 8854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13066,
      "e": 8854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13146,
      "e": 8934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 13291,
      "e": 9079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13291,
      "e": 9079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13362,
      "e": 9150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 13482,
      "e": 9270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13483,
      "e": 9271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13569,
      "e": 9357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13826,
      "e": 9614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13827,
      "e": 9615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13906,
      "e": 9694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13970,
      "e": 9758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13971,
      "e": 9759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14034,
      "e": 9822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14114,
      "e": 9902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14115,
      "e": 9903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14218,
      "e": 10006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14314,
      "e": 10102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14314,
      "e": 10102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14387,
      "e": 10175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14515,
      "e": 10303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14515,
      "e": 10303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14593,
      "e": 10381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14618,
      "e": 10406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14618,
      "e": 10406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14698,
      "e": 10486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14731,
      "e": 10519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14731,
      "e": 10519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14802,
      "e": 10590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15411,
      "e": 11199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15411,
      "e": 11199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15498,
      "e": 11286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 15554,
      "e": 11342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15554,
      "e": 11342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15626,
      "e": 11414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15723,
      "e": 11511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15723,
      "e": 11511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15802,
      "e": 11590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16115,
      "e": 11903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16116,
      "e": 11904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16194,
      "e": 11982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16306,
      "e": 12094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16307,
      "e": 12095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16362,
      "e": 12150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16441,
      "e": 12229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16442,
      "e": 12230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16514,
      "e": 12302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16651,
      "e": 12439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 16652,
      "e": 12440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16738,
      "e": 12526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 16850,
      "e": 12638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16850,
      "e": 12638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16914,
      "e": 12702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17026,
      "e": 12814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17028,
      "e": 12816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17098,
      "e": 12886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 17154,
      "e": 12942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17154,
      "e": 12942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17210,
      "e": 12998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17307,
      "e": 13095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17307,
      "e": 13095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17387,
      "e": 13175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17611,
      "e": 13399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17612,
      "e": 13400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17689,
      "e": 13477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 17746,
      "e": 13534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17747,
      "e": 13535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17826,
      "e": 13614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17962,
      "e": 13750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17963,
      "e": 13751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18049,
      "e": 13837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 18195,
      "e": 13983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18195,
      "e": 13983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18226,
      "e": 14014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 18297,
      "e": 14085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18298,
      "e": 14086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18370,
      "e": 14158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18515,
      "e": 14303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 18594,
      "e": 14382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18650,
      "e": 14438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18651,
      "e": 14439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18737,
      "e": 14525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 18818,
      "e": 14606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18818,
      "e": 14606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18915,
      "e": 14703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 18916,
      "e": 14704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18916,
      "e": 14704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19010,
      "e": 14798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19090,
      "e": 14878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19091,
      "e": 14879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19170,
      "e": 14958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 19203,
      "e": 14991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19203,
      "e": 14991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19273,
      "e": 15061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 19338,
      "e": 15126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19338,
      "e": 15126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19410,
      "e": 15198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 19418,
      "e": 15206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19418,
      "e": 15206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19498,
      "e": 15286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 19602,
      "e": 15390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19603,
      "e": 15391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19690,
      "e": 15478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20004,
      "e": 15792,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20698,
      "e": 16486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20806,
      "e": 16594,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND THEN"
    },
    {
      "t": 20826,
      "e": 16614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND THEN"
    },
    {
      "t": 20931,
      "e": 16719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21002,
      "e": 16790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND THE"
    },
    {
      "t": 21098,
      "e": 16886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21171,
      "e": 16959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND TH"
    },
    {
      "t": 21265,
      "e": 17053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21346,
      "e": 17134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND T"
    },
    {
      "t": 21588,
      "e": 17376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21641,
      "e": 17429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND "
    },
    {
      "t": 21770,
      "e": 17558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21826,
      "e": 17614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 ND"
    },
    {
      "t": 22035,
      "e": 17823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22114,
      "e": 17902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 N"
    },
    {
      "t": 22226,
      "e": 18014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22290,
      "e": 18078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 "
    },
    {
      "t": 22406,
      "e": 18194,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 "
    },
    {
      "t": 22987,
      "e": 18775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22988,
      "e": 18776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23066,
      "e": 18854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 23138,
      "e": 18926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23138,
      "e": 18926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23226,
      "e": 19014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 23299,
      "e": 19087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23299,
      "e": 19087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23378,
      "e": 19166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 23426,
      "e": 19214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23426,
      "e": 19214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23498,
      "e": 19286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23578,
      "e": 19366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23578,
      "e": 19366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23666,
      "e": 19454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 23762,
      "e": 19550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23762,
      "e": 19550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23826,
      "e": 19614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 23890,
      "e": 19678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23891,
      "e": 19679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23938,
      "e": 19726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 24203,
      "e": 19991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24205,
      "e": 19993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24265,
      "e": 20053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 24362,
      "e": 20150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24363,
      "e": 20151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24434,
      "e": 20222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26739,
      "e": 22527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26739,
      "e": 22527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26818,
      "e": 22606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 26890,
      "e": 22678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26890,
      "e": 22678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26945,
      "e": 22733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 27082,
      "e": 22870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27083,
      "e": 22871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27154,
      "e": 22942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27314,
      "e": 23102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 27315,
      "e": 23103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27378,
      "e": 23166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||U"
    },
    {
      "t": 27571,
      "e": 23359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27572,
      "e": 23360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27633,
      "e": 23421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 27770,
      "e": 23558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27770,
      "e": 23558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27842,
      "e": 23630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27905,
      "e": 23693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27906,
      "e": 23694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27994,
      "e": 23782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 28058,
      "e": 23846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28059,
      "e": 23847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28114,
      "e": 23902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 28162,
      "e": 23950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28162,
      "e": 23950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28234,
      "e": 24022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 28282,
      "e": 24070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28284,
      "e": 24072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28354,
      "e": 24142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28650,
      "e": 24438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28650,
      "e": 24438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28714,
      "e": 24502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 28858,
      "e": 24646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28858,
      "e": 24646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28938,
      "e": 24726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29233,
      "e": 25021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29234,
      "e": 25022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29313,
      "e": 25101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 29466,
      "e": 25254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 29466,
      "e": 25254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29545,
      "e": 25333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 29657,
      "e": 25445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29658,
      "e": 25446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29722,
      "e": 25447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 29793,
      "e": 25518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29793,
      "e": 25518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29866,
      "e": 25591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 29921,
      "e": 25646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29921,
      "e": 25646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29993,
      "e": 25718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30073,
      "e": 25798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30074,
      "e": 25799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30161,
      "e": 25886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 30266,
      "e": 25991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30266,
      "e": 25991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30338,
      "e": 26063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 30378,
      "e": 26103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30380,
      "e": 26105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30441,
      "e": 26166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 30545,
      "e": 26270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30546,
      "e": 26271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30609,
      "e": 26334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 30705,
      "e": 26430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30706,
      "e": 26431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30785,
      "e": 26510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30938,
      "e": 26663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30938,
      "e": 26663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30993,
      "e": 26718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 31114,
      "e": 26839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31115,
      "e": 26840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31202,
      "e": 26927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 31242,
      "e": 26967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31242,
      "e": 26967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31321,
      "e": 27046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 31345,
      "e": 27070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31345,
      "e": 27070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31401,
      "e": 27126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 31474,
      "e": 27199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31474,
      "e": 27199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31554,
      "e": 27279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31810,
      "e": 27535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31811,
      "e": 27536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31882,
      "e": 27607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 31978,
      "e": 27703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31978,
      "e": 27703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32050,
      "e": 27775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 32204,
      "e": 27929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32205,
      "e": 27930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32273,
      "e": 27998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 32410,
      "e": 28135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32410,
      "e": 28135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32490,
      "e": 28215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 32529,
      "e": 28254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32529,
      "e": 28254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32601,
      "e": 28326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 32665,
      "e": 28390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32666,
      "e": 28391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32737,
      "e": 28462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32858,
      "e": 28583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32859,
      "e": 28584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32938,
      "e": 28663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 32994,
      "e": 28719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32994,
      "e": 28719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33058,
      "e": 28783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 33114,
      "e": 28839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33115,
      "e": 28840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33178,
      "e": 28903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 33218,
      "e": 28943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33219,
      "e": 28944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33289,
      "e": 29014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33407,
      "e": 29132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 AND THEN GO UP THE Y AXIS FROM THAT POINT AND "
    },
    {
      "t": 33467,
      "e": 29192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33468,
      "e": 29193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33530,
      "e": 29255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 34426,
      "e": 30151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34521,
      "e": 30246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 AND THEN GO UP THE Y AXIS FROM THAT POINT AND "
    },
    {
      "t": 35194,
      "e": 30919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35195,
      "e": 30920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35249,
      "e": 30974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 35403,
      "e": 31128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35403,
      "e": 31128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35474,
      "e": 31199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 35706,
      "e": 31431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35707,
      "e": 31432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35762,
      "e": 31487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 35833,
      "e": 31558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35833,
      "e": 31558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35906,
      "e": 31631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 35954,
      "e": 31679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35955,
      "e": 31680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36026,
      "e": 31751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36154,
      "e": 31879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36155,
      "e": 31880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36234,
      "e": 31959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 36297,
      "e": 32022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36298,
      "e": 32023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36354,
      "e": 32079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 36434,
      "e": 32159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36436,
      "e": 32161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36473,
      "e": 32198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 36602,
      "e": 32327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36603,
      "e": 32328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36690,
      "e": 32415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36754,
      "e": 32479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36755,
      "e": 32480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36802,
      "e": 32527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 36874,
      "e": 32599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36874,
      "e": 32599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36938,
      "e": 32663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 36978,
      "e": 32703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36979,
      "e": 32704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37057,
      "e": 32782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 37073,
      "e": 32798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37074,
      "e": 32798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37146,
      "e": 32870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39922,
      "e": 35646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39923,
      "e": 35647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40002,
      "e": 35726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 40074,
      "e": 35798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40074,
      "e": 35798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40138,
      "e": 35862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 40202,
      "e": 35926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40203,
      "e": 35927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40289,
      "e": 36013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 40466,
      "e": 36190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40467,
      "e": 36191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40530,
      "e": 36254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 40650,
      "e": 36374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40650,
      "e": 36374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40731,
      "e": 36455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 40842,
      "e": 36566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40843,
      "e": 36567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40930,
      "e": 36654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 40993,
      "e": 36717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40993,
      "e": 36717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41058,
      "e": 36782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41402,
      "e": 37126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41403,
      "e": 37127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41481,
      "e": 37205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 41553,
      "e": 37277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41554,
      "e": 37278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41626,
      "e": 37350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 41835,
      "e": 37559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41835,
      "e": 37559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41889,
      "e": 37613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 42002,
      "e": 37726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42003,
      "e": 37727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42074,
      "e": 37798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 42755,
      "e": 38479,
      "ty": 41,
      "x": 64625,
      "y": 44539,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 42805,
      "e": 38529,
      "ty": 2,
      "x": 639,
      "y": 789
    },
    {
      "t": 42904,
      "e": 38628,
      "ty": 2,
      "x": 581,
      "y": 764
    },
    {
      "t": 43006,
      "e": 38730,
      "ty": 2,
      "x": 490,
      "y": 732
    },
    {
      "t": 43006,
      "e": 38730,
      "ty": 41,
      "x": 44166,
      "y": 40107,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43104,
      "e": 38828,
      "ty": 2,
      "x": 440,
      "y": 716
    },
    {
      "t": 43204,
      "e": 38928,
      "ty": 2,
      "x": 413,
      "y": 705
    },
    {
      "t": 43255,
      "e": 38979,
      "ty": 41,
      "x": 41383,
      "y": 47359,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43277,
      "e": 39001,
      "ty": 6,
      "x": 403,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 43304,
      "e": 39028,
      "ty": 2,
      "x": 402,
      "y": 687
    },
    {
      "t": 43405,
      "e": 39129,
      "ty": 2,
      "x": 398,
      "y": 671
    },
    {
      "t": 43488,
      "e": 39212,
      "ty": 3,
      "x": 397,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 43489,
      "e": 39213,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x axis, find 12 AND THEN GO UP THE Y AXIS FROM THAT POINT AND NOTE ALL THE SHADED DOTS"
    },
    {
      "t": 43491,
      "e": 39215,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43492,
      "e": 39216,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43504,
      "e": 39228,
      "ty": 2,
      "x": 397,
      "y": 670
    },
    {
      "t": 43505,
      "e": 39229,
      "ty": 41,
      "x": 31897,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 43638,
      "e": 39362,
      "ty": 4,
      "x": 31897,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 43651,
      "e": 39375,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43652,
      "e": 39376,
      "ty": 5,
      "x": 397,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 43662,
      "e": 39386,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 43905,
      "e": 39629,
      "ty": 2,
      "x": 397,
      "y": 671
    },
    {
      "t": 44004,
      "e": 39728,
      "ty": 2,
      "x": 501,
      "y": 741
    },
    {
      "t": 44005,
      "e": 39729,
      "ty": 41,
      "x": 16977,
      "y": 40606,
      "ta": "html > body"
    },
    {
      "t": 44104,
      "e": 39828,
      "ty": 2,
      "x": 555,
      "y": 781
    },
    {
      "t": 44255,
      "e": 39979,
      "ty": 41,
      "x": 18837,
      "y": 42822,
      "ta": "html > body"
    },
    {
      "t": 44657,
      "e": 40381,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 45254,
      "e": 40978,
      "ty": 41,
      "x": 19491,
      "y": 43099,
      "ta": "html > body"
    },
    {
      "t": 45304,
      "e": 41028,
      "ty": 2,
      "x": 725,
      "y": 726
    },
    {
      "t": 45328,
      "e": 41052,
      "ty": 6,
      "x": 812,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45344,
      "e": 41068,
      "ty": 7,
      "x": 841,
      "y": 611,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45378,
      "e": 41102,
      "ty": 6,
      "x": 865,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45405,
      "e": 41129,
      "ty": 2,
      "x": 869,
      "y": 558
    },
    {
      "t": 45411,
      "e": 41135,
      "ty": 7,
      "x": 871,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45505,
      "e": 41229,
      "ty": 2,
      "x": 890,
      "y": 528
    },
    {
      "t": 45505,
      "e": 41229,
      "ty": 41,
      "x": 17735,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 45678,
      "e": 41402,
      "ty": 6,
      "x": 898,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45704,
      "e": 41428,
      "ty": 2,
      "x": 898,
      "y": 557
    },
    {
      "t": 45754,
      "e": 41478,
      "ty": 41,
      "x": 19465,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45804,
      "e": 41528,
      "ty": 2,
      "x": 899,
      "y": 562
    },
    {
      "t": 45871,
      "e": 41595,
      "ty": 3,
      "x": 899,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45872,
      "e": 41596,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45965,
      "e": 41689,
      "ty": 4,
      "x": 19682,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45965,
      "e": 41689,
      "ty": 5,
      "x": 899,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46005,
      "e": 41729,
      "ty": 41,
      "x": 19682,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47035,
      "e": 42759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 47035,
      "e": 42759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47105,
      "e": 42829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 47225,
      "e": 42949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "99"
    },
    {
      "t": 47226,
      "e": 42950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47306,
      "e": 43030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 47779,
      "e": 43503,
      "ty": 7,
      "x": 889,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47805,
      "e": 43529,
      "ty": 2,
      "x": 881,
      "y": 589
    },
    {
      "t": 47904,
      "e": 43628,
      "ty": 2,
      "x": 877,
      "y": 617
    },
    {
      "t": 48004,
      "e": 43728,
      "ty": 2,
      "x": 882,
      "y": 631
    },
    {
      "t": 48004,
      "e": 43728,
      "ty": 41,
      "x": 16005,
      "y": 33824,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 48098,
      "e": 43822,
      "ty": 6,
      "x": 897,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48104,
      "e": 43828,
      "ty": 2,
      "x": 897,
      "y": 649
    },
    {
      "t": 48203,
      "e": 43927,
      "ty": 2,
      "x": 901,
      "y": 659
    },
    {
      "t": 48254,
      "e": 43978,
      "ty": 41,
      "x": 20114,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48333,
      "e": 44057,
      "ty": 3,
      "x": 901,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48334,
      "e": 44058,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 48334,
      "e": 44058,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48335,
      "e": 44059,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48430,
      "e": 44154,
      "ty": 4,
      "x": 20114,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48430,
      "e": 44154,
      "ty": 5,
      "x": 901,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49338,
      "e": 45062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 49450,
      "e": 45174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 49451,
      "e": 45175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49505,
      "e": 45229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 49914,
      "e": 45638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 49914,
      "e": 45638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49995,
      "e": 45639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "us"
    },
    {
      "t": 50130,
      "e": 45774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 50130,
      "e": 45774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50201,
      "e": 45845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 50418,
      "e": 46062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 50950,
      "e": 46594,
      "ty": 7,
      "x": 927,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50983,
      "e": 46627,
      "ty": 6,
      "x": 956,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51003,
      "e": 46647,
      "ty": 2,
      "x": 958,
      "y": 685
    },
    {
      "t": 51004,
      "e": 46648,
      "ty": 41,
      "x": 31994,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51104,
      "e": 46748,
      "ty": 2,
      "x": 962,
      "y": 687
    },
    {
      "t": 51230,
      "e": 46874,
      "ty": 3,
      "x": 962,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51232,
      "e": 46876,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 51233,
      "e": 46877,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51233,
      "e": 46877,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51254,
      "e": 46898,
      "ty": 41,
      "x": 34055,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51326,
      "e": 46970,
      "ty": 4,
      "x": 34055,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51326,
      "e": 46970,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51327,
      "e": 46971,
      "ty": 5,
      "x": 962,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51327,
      "e": 46971,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 51704,
      "e": 47348,
      "ty": 2,
      "x": 942,
      "y": 875
    },
    {
      "t": 51754,
      "e": 47398,
      "ty": 41,
      "x": 30029,
      "y": 52738,
      "ta": "html > body"
    },
    {
      "t": 51804,
      "e": 47448,
      "ty": 2,
      "x": 704,
      "y": 932
    },
    {
      "t": 51904,
      "e": 47548,
      "ty": 2,
      "x": 620,
      "y": 524
    },
    {
      "t": 52004,
      "e": 47648,
      "ty": 2,
      "x": 662,
      "y": 456
    },
    {
      "t": 52004,
      "e": 47648,
      "ty": 41,
      "x": 22522,
      "y": 24817,
      "ta": "html > body"
    },
    {
      "t": 52104,
      "e": 47748,
      "ty": 2,
      "x": 663,
      "y": 456
    },
    {
      "t": 52254,
      "e": 47898,
      "ty": 41,
      "x": 22556,
      "y": 24817,
      "ta": "html > body"
    },
    {
      "t": 52342,
      "e": 47986,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 53004,
      "e": 48648,
      "ty": 2,
      "x": 666,
      "y": 455
    },
    {
      "t": 53004,
      "e": 48648,
      "ty": 41,
      "x": 22660,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 53103,
      "e": 48747,
      "ty": 2,
      "x": 1132,
      "y": 0
    },
    {
      "t": 53204,
      "e": 48848,
      "ty": 2,
      "x": 1279,
      "y": 7
    },
    {
      "t": 53254,
      "e": 48898,
      "ty": 41,
      "x": 43184,
      "y": 4653,
      "ta": "html > body"
    },
    {
      "t": 53304,
      "e": 48948,
      "ty": 2,
      "x": 1193,
      "y": 201
    },
    {
      "t": 53404,
      "e": 49048,
      "ty": 2,
      "x": 979,
      "y": 408
    },
    {
      "t": 53504,
      "e": 49148,
      "ty": 2,
      "x": 914,
      "y": 392
    },
    {
      "t": 53504,
      "e": 49148,
      "ty": 41,
      "x": 21971,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 53603,
      "e": 49247,
      "ty": 2,
      "x": 843,
      "y": 311
    },
    {
      "t": 53618,
      "e": 49262,
      "ty": 6,
      "x": 839,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 53652,
      "e": 49296,
      "ty": 7,
      "x": 834,
      "y": 280,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 53668,
      "e": 49312,
      "ty": 6,
      "x": 832,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 53684,
      "e": 49328,
      "ty": 7,
      "x": 827,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 53702,
      "e": 49346,
      "ty": 6,
      "x": 826,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53703,
      "e": 49347,
      "ty": 2,
      "x": 826,
      "y": 237
    },
    {
      "t": 53719,
      "e": 49363,
      "ty": 7,
      "x": 826,
      "y": 231,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53754,
      "e": 49398,
      "ty": 41,
      "x": 1086,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 53804,
      "e": 49448,
      "ty": 2,
      "x": 822,
      "y": 198
    },
    {
      "t": 54004,
      "e": 49648,
      "ty": 2,
      "x": 825,
      "y": 209
    },
    {
      "t": 54004,
      "e": 49648,
      "ty": 41,
      "x": 849,
      "y": 12443,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 54104,
      "e": 49748,
      "ty": 2,
      "x": 827,
      "y": 223
    },
    {
      "t": 54204,
      "e": 49848,
      "ty": 2,
      "x": 828,
      "y": 225
    },
    {
      "t": 54254,
      "e": 49898,
      "ty": 41,
      "x": 1561,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 54304,
      "e": 49948,
      "ty": 2,
      "x": 830,
      "y": 231
    },
    {
      "t": 54327,
      "e": 49971,
      "ty": 6,
      "x": 830,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54404,
      "e": 50048,
      "ty": 2,
      "x": 831,
      "y": 236
    },
    {
      "t": 54505,
      "e": 50149,
      "ty": 2,
      "x": 831,
      "y": 237
    },
    {
      "t": 54505,
      "e": 50149,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54782,
      "e": 50426,
      "ty": 7,
      "x": 833,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54798,
      "e": 50442,
      "ty": 6,
      "x": 834,
      "y": 271,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 54804,
      "e": 50448,
      "ty": 2,
      "x": 834,
      "y": 271
    },
    {
      "t": 54820,
      "e": 50464,
      "ty": 7,
      "x": 837,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 54820,
      "e": 50464,
      "ty": 6,
      "x": 837,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54835,
      "e": 50479,
      "ty": 7,
      "x": 840,
      "y": 310,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 54904,
      "e": 50548,
      "ty": 2,
      "x": 840,
      "y": 336
    },
    {
      "t": 55005,
      "e": 50649,
      "ty": 41,
      "x": 4409,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 55103,
      "e": 50747,
      "ty": 6,
      "x": 838,
      "y": 327,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55104,
      "e": 50748,
      "ty": 2,
      "x": 838,
      "y": 327
    },
    {
      "t": 55204,
      "e": 50848,
      "ty": 2,
      "x": 836,
      "y": 323
    },
    {
      "t": 55254,
      "e": 50898,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55304,
      "e": 50948,
      "ty": 2,
      "x": 836,
      "y": 322
    },
    {
      "t": 55327,
      "e": 50971,
      "ty": 3,
      "x": 836,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55329,
      "e": 50973,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55421,
      "e": 51065,
      "ty": 4,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55421,
      "e": 51065,
      "ty": 5,
      "x": 836,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55421,
      "e": 51065,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 55604,
      "e": 51248,
      "ty": 2,
      "x": 836,
      "y": 327
    },
    {
      "t": 55620,
      "e": 51264,
      "ty": 7,
      "x": 838,
      "y": 337,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 55705,
      "e": 51349,
      "ty": 2,
      "x": 876,
      "y": 422
    },
    {
      "t": 55756,
      "e": 51350,
      "ty": 41,
      "x": 21496,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 55804,
      "e": 51398,
      "ty": 2,
      "x": 931,
      "y": 468
    },
    {
      "t": 55905,
      "e": 51499,
      "ty": 2,
      "x": 934,
      "y": 469
    },
    {
      "t": 56004,
      "e": 51598,
      "ty": 41,
      "x": 26717,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 56804,
      "e": 52398,
      "ty": 2,
      "x": 938,
      "y": 487
    },
    {
      "t": 56904,
      "e": 52498,
      "ty": 2,
      "x": 1065,
      "y": 603
    },
    {
      "t": 57004,
      "e": 52598,
      "ty": 2,
      "x": 1250,
      "y": 455
    },
    {
      "t": 57005,
      "e": 52599,
      "ty": 41,
      "x": 42771,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 57105,
      "e": 52699,
      "ty": 2,
      "x": 1261,
      "y": 442
    },
    {
      "t": 57254,
      "e": 52848,
      "ty": 41,
      "x": 43150,
      "y": 24042,
      "ta": "html > body"
    },
    {
      "t": 57704,
      "e": 53298,
      "ty": 2,
      "x": 1191,
      "y": 436
    },
    {
      "t": 57755,
      "e": 53349,
      "ty": 41,
      "x": 38225,
      "y": 23543,
      "ta": "html > body"
    },
    {
      "t": 57804,
      "e": 53398,
      "ty": 2,
      "x": 1048,
      "y": 432
    },
    {
      "t": 57904,
      "e": 53498,
      "ty": 2,
      "x": 1013,
      "y": 437
    },
    {
      "t": 58004,
      "e": 53598,
      "ty": 2,
      "x": 968,
      "y": 443
    },
    {
      "t": 58005,
      "e": 53599,
      "ty": 41,
      "x": 34786,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 58105,
      "e": 53699,
      "ty": 2,
      "x": 850,
      "y": 431
    },
    {
      "t": 58204,
      "e": 53798,
      "ty": 2,
      "x": 841,
      "y": 426
    },
    {
      "t": 58255,
      "e": 53849,
      "ty": 41,
      "x": 4646,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 58304,
      "e": 53898,
      "ty": 2,
      "x": 842,
      "y": 427
    },
    {
      "t": 58405,
      "e": 53999,
      "ty": 2,
      "x": 846,
      "y": 460
    },
    {
      "t": 58504,
      "e": 54098,
      "ty": 2,
      "x": 846,
      "y": 466
    },
    {
      "t": 58504,
      "e": 54098,
      "ty": 41,
      "x": 25979,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 58656,
      "e": 54250,
      "ty": 6,
      "x": 839,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58689,
      "e": 54283,
      "ty": 7,
      "x": 838,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58704,
      "e": 54298,
      "ty": 2,
      "x": 838,
      "y": 435
    },
    {
      "t": 58739,
      "e": 54333,
      "ty": 6,
      "x": 838,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58755,
      "e": 54349,
      "ty": 41,
      "x": 58367,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58756,
      "e": 54350,
      "ty": 7,
      "x": 841,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58804,
      "e": 54398,
      "ty": 2,
      "x": 843,
      "y": 392
    },
    {
      "t": 58904,
      "e": 54498,
      "ty": 2,
      "x": 848,
      "y": 382
    },
    {
      "t": 59004,
      "e": 54598,
      "ty": 2,
      "x": 890,
      "y": 380
    },
    {
      "t": 59004,
      "e": 54598,
      "ty": 41,
      "x": 16275,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 59105,
      "e": 54699,
      "ty": 2,
      "x": 971,
      "y": 378
    },
    {
      "t": 59204,
      "e": 54798,
      "ty": 2,
      "x": 985,
      "y": 406
    },
    {
      "t": 59255,
      "e": 54849,
      "ty": 41,
      "x": 32176,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 59304,
      "e": 54898,
      "ty": 2,
      "x": 884,
      "y": 500
    },
    {
      "t": 59338,
      "e": 54932,
      "ty": 6,
      "x": 833,
      "y": 526,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59404,
      "e": 54998,
      "ty": 2,
      "x": 830,
      "y": 527
    },
    {
      "t": 59504,
      "e": 55098,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59604,
      "e": 55198,
      "ty": 2,
      "x": 834,
      "y": 521
    },
    {
      "t": 59704,
      "e": 55298,
      "ty": 2,
      "x": 830,
      "y": 531
    },
    {
      "t": 59706,
      "e": 55300,
      "ty": 7,
      "x": 828,
      "y": 535,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59754,
      "e": 55348,
      "ty": 41,
      "x": 7698,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 59805,
      "e": 55399,
      "ty": 2,
      "x": 828,
      "y": 535
    },
    {
      "t": 59925,
      "e": 55519,
      "ty": 6,
      "x": 828,
      "y": 532,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 59991,
      "e": 55585,
      "ty": 7,
      "x": 828,
      "y": 514,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 60004,
      "e": 55598,
      "ty": 2,
      "x": 828,
      "y": 514
    },
    {
      "t": 60004,
      "e": 55598,
      "ty": 41,
      "x": 1561,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 60108,
      "e": 55702,
      "ty": 2,
      "x": 828,
      "y": 507
    },
    {
      "t": 60144,
      "e": 55703,
      "ty": 6,
      "x": 828,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60208,
      "e": 55767,
      "ty": 2,
      "x": 828,
      "y": 493
    },
    {
      "t": 60257,
      "e": 55816,
      "ty": 7,
      "x": 828,
      "y": 491,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60258,
      "e": 55817,
      "ty": 41,
      "x": 5904,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60307,
      "e": 55866,
      "ty": 2,
      "x": 828,
      "y": 489
    },
    {
      "t": 60434,
      "e": 55993,
      "ty": 3,
      "x": 828,
      "y": 489,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60435,
      "e": 55994,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 60507,
      "e": 56066,
      "ty": 41,
      "x": 5904,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60528,
      "e": 56087,
      "ty": 4,
      "x": 5904,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60529,
      "e": 56088,
      "ty": 5,
      "x": 828,
      "y": 489,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60529,
      "e": 56088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60530,
      "e": 56089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 60842,
      "e": 56401,
      "ty": 6,
      "x": 829,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60907,
      "e": 56466,
      "ty": 2,
      "x": 831,
      "y": 497
    },
    {
      "t": 60938,
      "e": 56497,
      "ty": 3,
      "x": 831,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61008,
      "e": 56567,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61042,
      "e": 56601,
      "ty": 4,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61042,
      "e": 56601,
      "ty": 5,
      "x": 831,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61194,
      "e": 56753,
      "ty": 7,
      "x": 840,
      "y": 518,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61208,
      "e": 56767,
      "ty": 2,
      "x": 840,
      "y": 518
    },
    {
      "t": 61258,
      "e": 56817,
      "ty": 41,
      "x": 44253,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 61307,
      "e": 56866,
      "ty": 2,
      "x": 879,
      "y": 592
    },
    {
      "t": 61408,
      "e": 56967,
      "ty": 2,
      "x": 907,
      "y": 653
    },
    {
      "t": 61508,
      "e": 57067,
      "ty": 2,
      "x": 908,
      "y": 655
    },
    {
      "t": 61508,
      "e": 57067,
      "ty": 41,
      "x": 20547,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 61608,
      "e": 57167,
      "ty": 2,
      "x": 908,
      "y": 662
    },
    {
      "t": 61758,
      "e": 57317,
      "ty": 41,
      "x": 20547,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 61908,
      "e": 57467,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 62008,
      "e": 57567,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 62108,
      "e": 57667,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 63907,
      "e": 59466,
      "ty": 2,
      "x": 903,
      "y": 729
    },
    {
      "t": 64008,
      "e": 59567,
      "ty": 2,
      "x": 847,
      "y": 702
    },
    {
      "t": 64008,
      "e": 59567,
      "ty": 41,
      "x": 6445,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64047,
      "e": 59606,
      "ty": 6,
      "x": 826,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 64063,
      "e": 59622,
      "ty": 7,
      "x": 824,
      "y": 666,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 64108,
      "e": 59667,
      "ty": 2,
      "x": 824,
      "y": 658
    },
    {
      "t": 64208,
      "e": 59767,
      "ty": 2,
      "x": 836,
      "y": 642
    },
    {
      "t": 64258,
      "e": 59817,
      "ty": 41,
      "x": 6782,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 64308,
      "e": 59867,
      "ty": 2,
      "x": 863,
      "y": 636
    },
    {
      "t": 64408,
      "e": 59967,
      "ty": 2,
      "x": 973,
      "y": 643
    },
    {
      "t": 64508,
      "e": 60067,
      "ty": 2,
      "x": 996,
      "y": 643
    },
    {
      "t": 64508,
      "e": 60067,
      "ty": 41,
      "x": 41431,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 64608,
      "e": 60167,
      "ty": 2,
      "x": 1041,
      "y": 639
    },
    {
      "t": 64708,
      "e": 60267,
      "ty": 2,
      "x": 1071,
      "y": 635
    },
    {
      "t": 64758,
      "e": 60317,
      "ty": 41,
      "x": 59705,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 64807,
      "e": 60366,
      "ty": 2,
      "x": 1073,
      "y": 635
    },
    {
      "t": 64908,
      "e": 60467,
      "ty": 2,
      "x": 1018,
      "y": 676
    },
    {
      "t": 65008,
      "e": 60567,
      "ty": 2,
      "x": 954,
      "y": 691
    },
    {
      "t": 65008,
      "e": 60567,
      "ty": 41,
      "x": 31464,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 65108,
      "e": 60667,
      "ty": 2,
      "x": 927,
      "y": 690
    },
    {
      "t": 65208,
      "e": 60767,
      "ty": 2,
      "x": 912,
      "y": 689
    },
    {
      "t": 65258,
      "e": 60817,
      "ty": 41,
      "x": 20072,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 65308,
      "e": 60867,
      "ty": 2,
      "x": 902,
      "y": 698
    },
    {
      "t": 65408,
      "e": 60967,
      "ty": 2,
      "x": 900,
      "y": 710
    },
    {
      "t": 65508,
      "e": 61067,
      "ty": 2,
      "x": 901,
      "y": 732
    },
    {
      "t": 65510,
      "e": 61069,
      "ty": 41,
      "x": 19973,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 65608,
      "e": 61167,
      "ty": 2,
      "x": 906,
      "y": 744
    },
    {
      "t": 65708,
      "e": 61267,
      "ty": 2,
      "x": 908,
      "y": 762
    },
    {
      "t": 65758,
      "e": 61317,
      "ty": 41,
      "x": 33621,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 65808,
      "e": 61367,
      "ty": 2,
      "x": 895,
      "y": 773
    },
    {
      "t": 65908,
      "e": 61467,
      "ty": 2,
      "x": 889,
      "y": 784
    },
    {
      "t": 66008,
      "e": 61567,
      "ty": 2,
      "x": 896,
      "y": 810
    },
    {
      "t": 66008,
      "e": 61567,
      "ty": 41,
      "x": 44018,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66108,
      "e": 61667,
      "ty": 2,
      "x": 891,
      "y": 838
    },
    {
      "t": 66208,
      "e": 61767,
      "ty": 2,
      "x": 877,
      "y": 847
    },
    {
      "t": 66258,
      "e": 61817,
      "ty": 41,
      "x": 12715,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 66308,
      "e": 61867,
      "ty": 2,
      "x": 875,
      "y": 858
    },
    {
      "t": 66508,
      "e": 62067,
      "ty": 41,
      "x": 12715,
      "y": 52084,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67808,
      "e": 63367,
      "ty": 2,
      "x": 871,
      "y": 819
    },
    {
      "t": 67908,
      "e": 63467,
      "ty": 2,
      "x": 865,
      "y": 716
    },
    {
      "t": 68008,
      "e": 63567,
      "ty": 2,
      "x": 869,
      "y": 691
    },
    {
      "t": 68008,
      "e": 63567,
      "ty": 41,
      "x": 11291,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 68108,
      "e": 63667,
      "ty": 2,
      "x": 872,
      "y": 680
    },
    {
      "t": 68258,
      "e": 63817,
      "ty": 41,
      "x": 13580,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 68408,
      "e": 63967,
      "ty": 2,
      "x": 896,
      "y": 684
    },
    {
      "t": 68508,
      "e": 64067,
      "ty": 2,
      "x": 918,
      "y": 676
    },
    {
      "t": 68509,
      "e": 64068,
      "ty": 41,
      "x": 25931,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 68608,
      "e": 64167,
      "ty": 2,
      "x": 921,
      "y": 675
    },
    {
      "t": 68708,
      "e": 64267,
      "ty": 2,
      "x": 921,
      "y": 680
    },
    {
      "t": 68758,
      "e": 64317,
      "ty": 41,
      "x": 27666,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 68808,
      "e": 64367,
      "ty": 2,
      "x": 945,
      "y": 687
    },
    {
      "t": 68908,
      "e": 64467,
      "ty": 2,
      "x": 1001,
      "y": 670
    },
    {
      "t": 69008,
      "e": 64567,
      "ty": 2,
      "x": 1011,
      "y": 670
    },
    {
      "t": 69008,
      "e": 64567,
      "ty": 41,
      "x": 50901,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 69108,
      "e": 64667,
      "ty": 2,
      "x": 1040,
      "y": 677
    },
    {
      "t": 69208,
      "e": 64767,
      "ty": 2,
      "x": 1039,
      "y": 673
    },
    {
      "t": 69258,
      "e": 64817,
      "ty": 41,
      "x": 48022,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 69308,
      "e": 64867,
      "ty": 2,
      "x": 972,
      "y": 715
    },
    {
      "t": 69409,
      "e": 64968,
      "ty": 2,
      "x": 913,
      "y": 722
    },
    {
      "t": 69508,
      "e": 65067,
      "ty": 2,
      "x": 885,
      "y": 722
    },
    {
      "t": 69509,
      "e": 65068,
      "ty": 41,
      "x": 15957,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 69608,
      "e": 65167,
      "ty": 2,
      "x": 874,
      "y": 719
    },
    {
      "t": 69708,
      "e": 65267,
      "ty": 2,
      "x": 865,
      "y": 715
    },
    {
      "t": 69758,
      "e": 65317,
      "ty": 41,
      "x": 10342,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 69809,
      "e": 65368,
      "ty": 2,
      "x": 864,
      "y": 714
    },
    {
      "t": 70008,
      "e": 65567,
      "ty": 41,
      "x": 10104,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 70707,
      "e": 66266,
      "ty": 2,
      "x": 885,
      "y": 718
    },
    {
      "t": 70758,
      "e": 66317,
      "ty": 41,
      "x": 16275,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 70807,
      "e": 66366,
      "ty": 2,
      "x": 914,
      "y": 715
    },
    {
      "t": 70907,
      "e": 66466,
      "ty": 2,
      "x": 943,
      "y": 711
    },
    {
      "t": 71008,
      "e": 66567,
      "ty": 41,
      "x": 30635,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 71107,
      "e": 66666,
      "ty": 2,
      "x": 912,
      "y": 733
    },
    {
      "t": 71207,
      "e": 66766,
      "ty": 2,
      "x": 887,
      "y": 740
    },
    {
      "t": 71259,
      "e": 66818,
      "ty": 41,
      "x": 15325,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 71309,
      "e": 66868,
      "ty": 2,
      "x": 911,
      "y": 744
    },
    {
      "t": 71407,
      "e": 66966,
      "ty": 2,
      "x": 970,
      "y": 744
    },
    {
      "t": 71508,
      "e": 67067,
      "ty": 2,
      "x": 972,
      "y": 744
    },
    {
      "t": 71508,
      "e": 67067,
      "ty": 41,
      "x": 35735,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 71607,
      "e": 67166,
      "ty": 2,
      "x": 970,
      "y": 748
    },
    {
      "t": 71707,
      "e": 67266,
      "ty": 2,
      "x": 965,
      "y": 750
    },
    {
      "t": 71757,
      "e": 67316,
      "ty": 41,
      "x": 58656,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71808,
      "e": 67367,
      "ty": 2,
      "x": 961,
      "y": 752
    },
    {
      "t": 71907,
      "e": 67466,
      "ty": 2,
      "x": 960,
      "y": 752
    },
    {
      "t": 72007,
      "e": 67566,
      "ty": 2,
      "x": 953,
      "y": 754
    },
    {
      "t": 72007,
      "e": 67566,
      "ty": 41,
      "x": 54901,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 72107,
      "e": 67666,
      "ty": 2,
      "x": 939,
      "y": 758
    },
    {
      "t": 72207,
      "e": 67766,
      "ty": 2,
      "x": 913,
      "y": 764
    },
    {
      "t": 72258,
      "e": 67817,
      "ty": 41,
      "x": 33621,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 72307,
      "e": 67866,
      "ty": 2,
      "x": 897,
      "y": 768
    },
    {
      "t": 72407,
      "e": 67966,
      "ty": 2,
      "x": 896,
      "y": 769
    },
    {
      "t": 72507,
      "e": 68066,
      "ty": 2,
      "x": 896,
      "y": 773
    },
    {
      "t": 72507,
      "e": 68066,
      "ty": 41,
      "x": 17699,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 72607,
      "e": 68166,
      "ty": 2,
      "x": 917,
      "y": 798
    },
    {
      "t": 72707,
      "e": 68266,
      "ty": 2,
      "x": 897,
      "y": 810
    },
    {
      "t": 72758,
      "e": 68317,
      "ty": 41,
      "x": 39297,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 72808,
      "e": 68367,
      "ty": 2,
      "x": 888,
      "y": 814
    },
    {
      "t": 72907,
      "e": 68466,
      "ty": 2,
      "x": 889,
      "y": 827
    },
    {
      "t": 73008,
      "e": 68567,
      "ty": 2,
      "x": 889,
      "y": 844
    },
    {
      "t": 73009,
      "e": 68568,
      "ty": 41,
      "x": 47612,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 73108,
      "e": 68667,
      "ty": 2,
      "x": 881,
      "y": 857
    },
    {
      "t": 73207,
      "e": 68766,
      "ty": 2,
      "x": 873,
      "y": 863
    },
    {
      "t": 73257,
      "e": 68816,
      "ty": 41,
      "x": 10342,
      "y": 52457,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 73307,
      "e": 68866,
      "ty": 2,
      "x": 855,
      "y": 857
    },
    {
      "t": 73407,
      "e": 68966,
      "ty": 2,
      "x": 840,
      "y": 839
    },
    {
      "t": 73508,
      "e": 69067,
      "ty": 2,
      "x": 836,
      "y": 824
    },
    {
      "t": 73508,
      "e": 69067,
      "ty": 41,
      "x": 8604,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 73608,
      "e": 69167,
      "ty": 2,
      "x": 833,
      "y": 821
    },
    {
      "t": 73658,
      "e": 69217,
      "ty": 6,
      "x": 831,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73708,
      "e": 69267,
      "ty": 2,
      "x": 830,
      "y": 819
    },
    {
      "t": 73758,
      "e": 69317,
      "ty": 41,
      "x": 7955,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73808,
      "e": 69367,
      "ty": 2,
      "x": 828,
      "y": 811
    },
    {
      "t": 73810,
      "e": 69369,
      "ty": 3,
      "x": 828,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73811,
      "e": 69370,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 73812,
      "e": 69371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73888,
      "e": 69447,
      "ty": 4,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73889,
      "e": 69448,
      "ty": 5,
      "x": 828,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 73889,
      "e": 69448,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 74007,
      "e": 69566,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 74038,
      "e": 69597,
      "ty": 7,
      "x": 835,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 74107,
      "e": 69666,
      "ty": 2,
      "x": 864,
      "y": 851
    },
    {
      "t": 74208,
      "e": 69767,
      "ty": 2,
      "x": 886,
      "y": 872
    },
    {
      "t": 74257,
      "e": 69816,
      "ty": 41,
      "x": 16987,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 74308,
      "e": 69867,
      "ty": 2,
      "x": 896,
      "y": 883
    },
    {
      "t": 74407,
      "e": 69966,
      "ty": 2,
      "x": 897,
      "y": 883
    },
    {
      "t": 74508,
      "e": 70067,
      "ty": 41,
      "x": 17936,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 74707,
      "e": 70266,
      "ty": 2,
      "x": 871,
      "y": 932
    },
    {
      "t": 74757,
      "e": 70316,
      "ty": 41,
      "x": 9392,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 74807,
      "e": 70366,
      "ty": 2,
      "x": 855,
      "y": 958
    },
    {
      "t": 74907,
      "e": 70466,
      "ty": 2,
      "x": 829,
      "y": 976
    },
    {
      "t": 75007,
      "e": 70566,
      "ty": 2,
      "x": 825,
      "y": 974
    },
    {
      "t": 75008,
      "e": 70567,
      "ty": 41,
      "x": 849,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 75107,
      "e": 70666,
      "ty": 2,
      "x": 823,
      "y": 973
    },
    {
      "t": 75207,
      "e": 70766,
      "ty": 2,
      "x": 824,
      "y": 964
    },
    {
      "t": 75258,
      "e": 70817,
      "ty": 41,
      "x": 2085,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 75306,
      "e": 70865,
      "ty": 6,
      "x": 826,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75308,
      "e": 70867,
      "ty": 2,
      "x": 826,
      "y": 964
    },
    {
      "t": 75407,
      "e": 70966,
      "ty": 2,
      "x": 833,
      "y": 963
    },
    {
      "t": 75442,
      "e": 71001,
      "ty": 3,
      "x": 833,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75443,
      "e": 71002,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 75443,
      "e": 71002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75508,
      "e": 71067,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75536,
      "e": 71095,
      "ty": 4,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75536,
      "e": 71095,
      "ty": 5,
      "x": 833,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75537,
      "e": 71096,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 75739,
      "e": 71298,
      "ty": 7,
      "x": 846,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 75758,
      "e": 71317,
      "ty": 41,
      "x": 8680,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 75807,
      "e": 71366,
      "ty": 2,
      "x": 881,
      "y": 1003
    },
    {
      "t": 75823,
      "e": 71382,
      "ty": 6,
      "x": 882,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75908,
      "e": 71467,
      "ty": 2,
      "x": 886,
      "y": 1011
    },
    {
      "t": 76007,
      "e": 71566,
      "ty": 2,
      "x": 889,
      "y": 1014
    },
    {
      "t": 76008,
      "e": 71567,
      "ty": 41,
      "x": 30705,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76058,
      "e": 71617,
      "ty": 3,
      "x": 889,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76059,
      "e": 71618,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76059,
      "e": 71618,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76144,
      "e": 71703,
      "ty": 4,
      "x": 30705,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76145,
      "e": 71704,
      "ty": 5,
      "x": 889,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76147,
      "e": 71706,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76148,
      "e": 71707,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76149,
      "e": 71708,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 76507,
      "e": 72066,
      "ty": 2,
      "x": 1055,
      "y": 586
    },
    {
      "t": 76508,
      "e": 72067,
      "ty": 41,
      "x": 36056,
      "y": 32019,
      "ta": "html > body"
    },
    {
      "t": 76608,
      "e": 72167,
      "ty": 2,
      "x": 1030,
      "y": 458
    },
    {
      "t": 76758,
      "e": 72317,
      "ty": 41,
      "x": 35195,
      "y": 24928,
      "ta": "html > body"
    },
    {
      "t": 77566,
      "e": 73125,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 80008,
      "e": 75567,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80758,
      "e": 76317,
      "ty": 41,
      "x": 36383,
      "y": 15459,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 80807,
      "e": 76366,
      "ty": 2,
      "x": 1060,
      "y": 525
    },
    {
      "t": 80908,
      "e": 76467,
      "ty": 2,
      "x": 1124,
      "y": 665
    },
    {
      "t": 81008,
      "e": 76567,
      "ty": 2,
      "x": 1195,
      "y": 764
    },
    {
      "t": 81008,
      "e": 76567,
      "ty": 41,
      "x": 44353,
      "y": 55889,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 81108,
      "e": 76667,
      "ty": 2,
      "x": 1235,
      "y": 836
    },
    {
      "t": 81208,
      "e": 76767,
      "ty": 2,
      "x": 1232,
      "y": 836
    },
    {
      "t": 81258,
      "e": 76817,
      "ty": 41,
      "x": 46075,
      "y": 46243,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 81308,
      "e": 76867,
      "ty": 2,
      "x": 1229,
      "y": 843
    },
    {
      "t": 81407,
      "e": 76966,
      "ty": 2,
      "x": 1239,
      "y": 874
    },
    {
      "t": 81508,
      "e": 77067,
      "ty": 2,
      "x": 1238,
      "y": 874
    },
    {
      "t": 81508,
      "e": 77067,
      "ty": 41,
      "x": 46468,
      "y": 3547,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 90008,
      "e": 82067,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 105608,
      "e": 82067,
      "ty": 2,
      "x": 1194,
      "y": 903
    },
    {
      "t": 105708,
      "e": 82167,
      "ty": 2,
      "x": 1169,
      "y": 919
    },
    {
      "t": 105759,
      "e": 82218,
      "ty": 41,
      "x": 42483,
      "y": 55654,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105807,
      "e": 82266,
      "ty": 2,
      "x": 1132,
      "y": 946
    },
    {
      "t": 105908,
      "e": 82367,
      "ty": 2,
      "x": 1066,
      "y": 989
    },
    {
      "t": 106008,
      "e": 82467,
      "ty": 2,
      "x": 1013,
      "y": 1045
    },
    {
      "t": 106008,
      "e": 82467,
      "ty": 41,
      "x": 35399,
      "y": 63617,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106057,
      "e": 82516,
      "ty": 6,
      "x": 997,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 106108,
      "e": 82567,
      "ty": 2,
      "x": 981,
      "y": 1100
    },
    {
      "t": 106208,
      "e": 82667,
      "ty": 2,
      "x": 979,
      "y": 1103
    },
    {
      "t": 106258,
      "e": 82717,
      "ty": 41,
      "x": 37955,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 106508,
      "e": 82967,
      "ty": 2,
      "x": 978,
      "y": 1104
    },
    {
      "t": 106508,
      "e": 82967,
      "ty": 41,
      "x": 37409,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 106708,
      "e": 83167,
      "ty": 2,
      "x": 976,
      "y": 1104
    },
    {
      "t": 106758,
      "e": 83217,
      "ty": 41,
      "x": 36317,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 106808,
      "e": 83267,
      "ty": 2,
      "x": 972,
      "y": 1103
    },
    {
      "t": 106907,
      "e": 83366,
      "ty": 2,
      "x": 969,
      "y": 1100
    },
    {
      "t": 107008,
      "e": 83467,
      "ty": 41,
      "x": 32494,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 108411,
      "e": 84870,
      "ty": 3,
      "x": 969,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 108411,
      "e": 84870,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 108536,
      "e": 84995,
      "ty": 4,
      "x": 32494,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 108537,
      "e": 84996,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 108537,
      "e": 84996,
      "ty": 5,
      "x": 969,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 108537,
      "e": 84996,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 109208,
      "e": 85667,
      "ty": 2,
      "x": 964,
      "y": 1098
    },
    {
      "t": 109258,
      "e": 85717,
      "ty": 41,
      "x": 28858,
      "y": 52184,
      "ta": "html > body"
    },
    {
      "t": 109308,
      "e": 85767,
      "ty": 2,
      "x": 801,
      "y": 816
    },
    {
      "t": 109408,
      "e": 85867,
      "ty": 2,
      "x": 801,
      "y": 705
    },
    {
      "t": 109508,
      "e": 85967,
      "ty": 2,
      "x": 801,
      "y": 703
    },
    {
      "t": 109509,
      "e": 85968,
      "ty": 41,
      "x": 27309,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 109579,
      "e": 86038,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 110427,
      "e": 86886,
      "ty": 2,
      "x": 804,
      "y": 703
    },
    {
      "t": 110428,
      "e": 86887,
      "ty": 41,
      "x": 23654,
      "y": 32789,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 110608,
      "e": 87067,
      "ty": 2,
      "x": 805,
      "y": 703
    },
    {
      "t": 110758,
      "e": 87217,
      "ty": 41,
      "x": 23772,
      "y": 32789,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 110807,
      "e": 87266,
      "ty": 2,
      "x": 807,
      "y": 704
    },
    {
      "t": 111008,
      "e": 87467,
      "ty": 41,
      "x": 23830,
      "y": 32789,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 111124,
      "e": 87583,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 18943, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 18949, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 30306, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 50357, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 21804, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"LIMA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115-late\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 73167, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 14408, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 88663, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 5074, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 94738, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 21341, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 117329, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-11 AM-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:747,y:821,t:1527267128801};\\\", \\\"{x:748,y:824,t:1527267128810};\\\", \\\"{x:749,y:832,t:1527267128827};\\\", \\\"{x:751,y:840,t:1527267128843};\\\", \\\"{x:755,y:852,t:1527267128860};\\\", \\\"{x:758,y:866,t:1527267128877};\\\", \\\"{x:764,y:880,t:1527267128893};\\\", \\\"{x:768,y:890,t:1527267128910};\\\", \\\"{x:773,y:900,t:1527267128927};\\\", \\\"{x:775,y:905,t:1527267128942};\\\", \\\"{x:784,y:919,t:1527267128960};\\\", \\\"{x:793,y:929,t:1527267128976};\\\", \\\"{x:805,y:940,t:1527267128993};\\\", \\\"{x:824,y:950,t:1527267129009};\\\", \\\"{x:842,y:956,t:1527267129027};\\\", \\\"{x:865,y:963,t:1527267129043};\\\", \\\"{x:891,y:970,t:1527267129059};\\\", \\\"{x:923,y:977,t:1527267129076};\\\", \\\"{x:947,y:980,t:1527267129093};\\\", \\\"{x:970,y:981,t:1527267129110};\\\", \\\"{x:990,y:981,t:1527267129127};\\\", \\\"{x:1011,y:981,t:1527267129142};\\\", \\\"{x:1034,y:981,t:1527267129160};\\\", \\\"{x:1044,y:981,t:1527267129177};\\\", \\\"{x:1048,y:981,t:1527267129193};\\\", \\\"{x:1052,y:981,t:1527267129210};\\\", \\\"{x:1058,y:980,t:1527267129227};\\\", \\\"{x:1064,y:979,t:1527267129244};\\\", \\\"{x:1070,y:978,t:1527267129260};\\\", \\\"{x:1075,y:978,t:1527267129277};\\\", \\\"{x:1081,y:978,t:1527267129294};\\\", \\\"{x:1088,y:976,t:1527267129310};\\\", \\\"{x:1093,y:976,t:1527267129327};\\\", \\\"{x:1096,y:975,t:1527267129344};\\\", \\\"{x:1097,y:975,t:1527267129360};\\\", \\\"{x:1099,y:974,t:1527267129376};\\\", \\\"{x:1104,y:972,t:1527267129394};\\\", \\\"{x:1107,y:972,t:1527267129410};\\\", \\\"{x:1117,y:968,t:1527267129427};\\\", \\\"{x:1131,y:967,t:1527267129444};\\\", \\\"{x:1143,y:966,t:1527267129459};\\\", \\\"{x:1152,y:966,t:1527267129476};\\\", \\\"{x:1163,y:966,t:1527267129493};\\\", \\\"{x:1168,y:966,t:1527267129509};\\\", \\\"{x:1170,y:966,t:1527267129526};\\\", \\\"{x:1175,y:966,t:1527267129543};\\\", \\\"{x:1178,y:966,t:1527267129559};\\\", \\\"{x:1188,y:966,t:1527267129577};\\\", \\\"{x:1202,y:966,t:1527267129593};\\\", \\\"{x:1215,y:966,t:1527267129610};\\\", \\\"{x:1233,y:966,t:1527267129627};\\\", \\\"{x:1255,y:966,t:1527267129643};\\\", \\\"{x:1274,y:966,t:1527267129660};\\\", \\\"{x:1288,y:966,t:1527267129677};\\\", \\\"{x:1293,y:966,t:1527267129694};\\\", \\\"{x:1299,y:966,t:1527267129710};\\\", \\\"{x:1304,y:966,t:1527267129727};\\\", \\\"{x:1307,y:966,t:1527267129744};\\\", \\\"{x:1310,y:967,t:1527267129760};\\\", \\\"{x:1315,y:968,t:1527267129777};\\\", \\\"{x:1319,y:970,t:1527267129794};\\\", \\\"{x:1321,y:970,t:1527267129865};\\\", \\\"{x:1321,y:971,t:1527267129881};\\\", \\\"{x:1322,y:971,t:1527267129912};\\\", \\\"{x:1321,y:972,t:1527267129926};\\\", \\\"{x:1309,y:972,t:1527267129943};\\\", \\\"{x:1302,y:972,t:1527267129960};\\\", \\\"{x:1297,y:972,t:1527267129977};\\\", \\\"{x:1292,y:972,t:1527267129993};\\\", \\\"{x:1290,y:972,t:1527267130010};\\\", \\\"{x:1288,y:972,t:1527267130027};\\\", \\\"{x:1287,y:972,t:1527267130044};\\\", \\\"{x:1285,y:970,t:1527267130061};\\\", \\\"{x:1284,y:968,t:1527267130077};\\\", \\\"{x:1283,y:965,t:1527267130093};\\\", \\\"{x:1282,y:962,t:1527267130110};\\\", \\\"{x:1281,y:958,t:1527267130127};\\\", \\\"{x:1281,y:956,t:1527267130144};\\\", \\\"{x:1281,y:951,t:1527267130161};\\\", \\\"{x:1281,y:945,t:1527267130178};\\\", \\\"{x:1281,y:938,t:1527267130194};\\\", \\\"{x:1281,y:927,t:1527267130211};\\\", \\\"{x:1281,y:920,t:1527267130228};\\\", \\\"{x:1281,y:913,t:1527267130244};\\\", \\\"{x:1283,y:904,t:1527267130261};\\\", \\\"{x:1286,y:893,t:1527267130278};\\\", \\\"{x:1286,y:879,t:1527267130294};\\\", \\\"{x:1286,y:869,t:1527267130311};\\\", \\\"{x:1286,y:863,t:1527267130328};\\\", \\\"{x:1287,y:860,t:1527267130344};\\\", \\\"{x:1287,y:859,t:1527267130368};\\\", \\\"{x:1287,y:858,t:1527267130385};\\\", \\\"{x:1288,y:855,t:1527267130394};\\\", \\\"{x:1288,y:854,t:1527267130412};\\\", \\\"{x:1289,y:852,t:1527267130428};\\\", \\\"{x:1289,y:851,t:1527267130444};\\\", \\\"{x:1289,y:850,t:1527267130461};\\\", \\\"{x:1289,y:849,t:1527267130480};\\\", \\\"{x:1289,y:848,t:1527267130497};\\\", \\\"{x:1289,y:847,t:1527267130520};\\\", \\\"{x:1289,y:846,t:1527267130546};\\\", \\\"{x:1289,y:843,t:1527267130562};\\\", \\\"{x:1289,y:842,t:1527267130578};\\\", \\\"{x:1289,y:840,t:1527267130594};\\\", \\\"{x:1289,y:839,t:1527267130611};\\\", \\\"{x:1288,y:838,t:1527267130640};\\\", \\\"{x:1287,y:837,t:1527267130655};\\\", \\\"{x:1287,y:836,t:1527267130728};\\\", \\\"{x:1286,y:831,t:1527267133971};\\\", \\\"{x:1286,y:824,t:1527267133981};\\\", \\\"{x:1285,y:817,t:1527267133997};\\\", \\\"{x:1283,y:812,t:1527267134013};\\\", \\\"{x:1282,y:808,t:1527267134030};\\\", \\\"{x:1281,y:806,t:1527267134046};\\\", \\\"{x:1280,y:802,t:1527267134064};\\\", \\\"{x:1280,y:801,t:1527267134080};\\\", \\\"{x:1279,y:799,t:1527267134097};\\\", \\\"{x:1279,y:798,t:1527267134114};\\\", \\\"{x:1279,y:796,t:1527267134129};\\\", \\\"{x:1279,y:794,t:1527267134147};\\\", \\\"{x:1279,y:792,t:1527267134164};\\\", \\\"{x:1279,y:789,t:1527267134180};\\\", \\\"{x:1279,y:785,t:1527267134197};\\\", \\\"{x:1279,y:782,t:1527267134214};\\\", \\\"{x:1279,y:779,t:1527267134230};\\\", \\\"{x:1279,y:776,t:1527267134248};\\\", \\\"{x:1279,y:769,t:1527267134264};\\\", \\\"{x:1279,y:764,t:1527267134281};\\\", \\\"{x:1279,y:761,t:1527267134298};\\\", \\\"{x:1279,y:758,t:1527267134315};\\\", \\\"{x:1279,y:757,t:1527267134330};\\\", \\\"{x:1279,y:755,t:1527267134347};\\\", \\\"{x:1279,y:754,t:1527267134364};\\\", \\\"{x:1279,y:752,t:1527267134380};\\\", \\\"{x:1279,y:750,t:1527267134398};\\\", \\\"{x:1279,y:746,t:1527267134414};\\\", \\\"{x:1279,y:745,t:1527267134431};\\\", \\\"{x:1279,y:741,t:1527267134448};\\\", \\\"{x:1279,y:736,t:1527267134464};\\\", \\\"{x:1280,y:734,t:1527267134481};\\\", \\\"{x:1281,y:731,t:1527267134498};\\\", \\\"{x:1281,y:729,t:1527267134514};\\\", \\\"{x:1281,y:726,t:1527267134531};\\\", \\\"{x:1281,y:725,t:1527267134551};\\\", \\\"{x:1282,y:722,t:1527267134564};\\\", \\\"{x:1282,y:721,t:1527267134580};\\\", \\\"{x:1282,y:719,t:1527267134596};\\\", \\\"{x:1282,y:716,t:1527267134613};\\\", \\\"{x:1282,y:715,t:1527267134630};\\\", \\\"{x:1282,y:713,t:1527267134647};\\\", \\\"{x:1283,y:710,t:1527267134664};\\\", \\\"{x:1283,y:709,t:1527267134681};\\\", \\\"{x:1283,y:706,t:1527267134697};\\\", \\\"{x:1283,y:704,t:1527267134714};\\\", \\\"{x:1283,y:703,t:1527267134731};\\\", \\\"{x:1283,y:700,t:1527267134747};\\\", \\\"{x:1283,y:697,t:1527267134765};\\\", \\\"{x:1283,y:695,t:1527267134781};\\\", \\\"{x:1283,y:694,t:1527267134797};\\\", \\\"{x:1283,y:692,t:1527267134814};\\\", \\\"{x:1283,y:691,t:1527267134831};\\\", \\\"{x:1283,y:690,t:1527267134847};\\\", \\\"{x:1283,y:689,t:1527267134880};\\\", \\\"{x:1284,y:688,t:1527267134888};\\\", \\\"{x:1284,y:691,t:1527267135001};\\\", \\\"{x:1283,y:697,t:1527267135015};\\\", \\\"{x:1275,y:717,t:1527267135031};\\\", \\\"{x:1266,y:745,t:1527267135048};\\\", \\\"{x:1259,y:770,t:1527267135065};\\\", \\\"{x:1257,y:795,t:1527267135081};\\\", \\\"{x:1254,y:813,t:1527267135098};\\\", \\\"{x:1253,y:826,t:1527267135114};\\\", \\\"{x:1252,y:834,t:1527267135131};\\\", \\\"{x:1252,y:840,t:1527267135149};\\\", \\\"{x:1252,y:845,t:1527267135169};\\\", \\\"{x:1253,y:845,t:1527267135264};\\\", \\\"{x:1255,y:844,t:1527267135281};\\\", \\\"{x:1262,y:840,t:1527267135298};\\\", \\\"{x:1269,y:835,t:1527267135314};\\\", \\\"{x:1272,y:831,t:1527267135331};\\\", \\\"{x:1274,y:829,t:1527267135348};\\\", \\\"{x:1275,y:827,t:1527267135364};\\\", \\\"{x:1276,y:825,t:1527267135381};\\\", \\\"{x:1276,y:824,t:1527267135398};\\\", \\\"{x:1277,y:824,t:1527267135414};\\\", \\\"{x:1277,y:823,t:1527267135799};\\\", \\\"{x:1277,y:821,t:1527267135815};\\\", \\\"{x:1277,y:818,t:1527267135831};\\\", \\\"{x:1278,y:813,t:1527267135848};\\\", \\\"{x:1278,y:812,t:1527267135871};\\\", \\\"{x:1278,y:811,t:1527267135882};\\\", \\\"{x:1278,y:810,t:1527267135911};\\\", \\\"{x:1278,y:809,t:1527267135919};\\\", \\\"{x:1279,y:807,t:1527267135931};\\\", \\\"{x:1279,y:805,t:1527267135948};\\\", \\\"{x:1279,y:803,t:1527267135965};\\\", \\\"{x:1280,y:801,t:1527267135982};\\\", \\\"{x:1280,y:799,t:1527267135999};\\\", \\\"{x:1280,y:797,t:1527267136015};\\\", \\\"{x:1280,y:796,t:1527267136032};\\\", \\\"{x:1281,y:795,t:1527267136048};\\\", \\\"{x:1281,y:794,t:1527267136065};\\\", \\\"{x:1281,y:792,t:1527267136082};\\\", \\\"{x:1281,y:791,t:1527267136099};\\\", \\\"{x:1281,y:789,t:1527267136115};\\\", \\\"{x:1282,y:786,t:1527267136132};\\\", \\\"{x:1282,y:785,t:1527267136148};\\\", \\\"{x:1282,y:783,t:1527267136166};\\\", \\\"{x:1282,y:780,t:1527267136182};\\\", \\\"{x:1282,y:777,t:1527267136199};\\\", \\\"{x:1282,y:772,t:1527267136216};\\\", \\\"{x:1282,y:766,t:1527267136232};\\\", \\\"{x:1282,y:761,t:1527267136248};\\\", \\\"{x:1282,y:758,t:1527267136265};\\\", \\\"{x:1282,y:754,t:1527267136283};\\\", \\\"{x:1282,y:751,t:1527267136299};\\\", \\\"{x:1282,y:747,t:1527267136316};\\\", \\\"{x:1282,y:745,t:1527267136333};\\\", \\\"{x:1282,y:741,t:1527267136349};\\\", \\\"{x:1283,y:738,t:1527267136366};\\\", \\\"{x:1283,y:734,t:1527267136382};\\\", \\\"{x:1284,y:731,t:1527267136400};\\\", \\\"{x:1284,y:726,t:1527267136415};\\\", \\\"{x:1284,y:721,t:1527267136433};\\\", \\\"{x:1284,y:718,t:1527267136449};\\\", \\\"{x:1284,y:713,t:1527267136466};\\\", \\\"{x:1284,y:708,t:1527267136483};\\\", \\\"{x:1283,y:703,t:1527267136500};\\\", \\\"{x:1282,y:699,t:1527267136516};\\\", \\\"{x:1282,y:696,t:1527267136533};\\\", \\\"{x:1282,y:693,t:1527267136549};\\\", \\\"{x:1282,y:689,t:1527267136566};\\\", \\\"{x:1281,y:686,t:1527267136583};\\\", \\\"{x:1281,y:685,t:1527267136600};\\\", \\\"{x:1281,y:683,t:1527267136616};\\\", \\\"{x:1281,y:681,t:1527267136632};\\\", \\\"{x:1280,y:679,t:1527267136649};\\\", \\\"{x:1280,y:676,t:1527267136666};\\\", \\\"{x:1279,y:674,t:1527267136682};\\\", \\\"{x:1279,y:671,t:1527267136700};\\\", \\\"{x:1278,y:669,t:1527267136716};\\\", \\\"{x:1278,y:668,t:1527267136732};\\\", \\\"{x:1278,y:667,t:1527267136750};\\\", \\\"{x:1278,y:665,t:1527267136766};\\\", \\\"{x:1276,y:663,t:1527267136782};\\\", \\\"{x:1276,y:660,t:1527267136800};\\\", \\\"{x:1275,y:657,t:1527267136816};\\\", \\\"{x:1275,y:654,t:1527267136832};\\\", \\\"{x:1275,y:653,t:1527267136850};\\\", \\\"{x:1275,y:650,t:1527267136866};\\\", \\\"{x:1275,y:648,t:1527267136883};\\\", \\\"{x:1274,y:645,t:1527267136900};\\\", \\\"{x:1274,y:644,t:1527267136916};\\\", \\\"{x:1274,y:642,t:1527267136933};\\\", \\\"{x:1273,y:640,t:1527267136950};\\\", \\\"{x:1273,y:638,t:1527267136966};\\\", \\\"{x:1273,y:635,t:1527267136981};\\\", \\\"{x:1273,y:632,t:1527267136999};\\\", \\\"{x:1273,y:623,t:1527267137016};\\\", \\\"{x:1273,y:617,t:1527267137032};\\\", \\\"{x:1273,y:612,t:1527267137049};\\\", \\\"{x:1273,y:606,t:1527267137066};\\\", \\\"{x:1273,y:600,t:1527267137082};\\\", \\\"{x:1273,y:594,t:1527267137099};\\\", \\\"{x:1273,y:588,t:1527267137116};\\\", \\\"{x:1273,y:583,t:1527267137132};\\\", \\\"{x:1273,y:579,t:1527267137149};\\\", \\\"{x:1273,y:575,t:1527267137166};\\\", \\\"{x:1273,y:572,t:1527267137182};\\\", \\\"{x:1273,y:569,t:1527267137199};\\\", \\\"{x:1273,y:564,t:1527267137216};\\\", \\\"{x:1273,y:562,t:1527267137232};\\\", \\\"{x:1273,y:558,t:1527267137249};\\\", \\\"{x:1273,y:555,t:1527267137267};\\\", \\\"{x:1273,y:551,t:1527267137282};\\\", \\\"{x:1273,y:549,t:1527267137299};\\\", \\\"{x:1273,y:545,t:1527267137317};\\\", \\\"{x:1273,y:541,t:1527267137333};\\\", \\\"{x:1273,y:536,t:1527267137349};\\\", \\\"{x:1273,y:532,t:1527267137367};\\\", \\\"{x:1273,y:526,t:1527267137384};\\\", \\\"{x:1273,y:521,t:1527267137399};\\\", \\\"{x:1273,y:514,t:1527267137418};\\\", \\\"{x:1273,y:510,t:1527267137434};\\\", \\\"{x:1272,y:503,t:1527267137450};\\\", \\\"{x:1272,y:499,t:1527267137467};\\\", \\\"{x:1272,y:495,t:1527267137483};\\\", \\\"{x:1272,y:489,t:1527267137500};\\\", \\\"{x:1272,y:482,t:1527267137517};\\\", \\\"{x:1272,y:476,t:1527267137533};\\\", \\\"{x:1272,y:469,t:1527267137549};\\\", \\\"{x:1272,y:462,t:1527267137567};\\\", \\\"{x:1272,y:456,t:1527267137583};\\\", \\\"{x:1272,y:447,t:1527267137599};\\\", \\\"{x:1272,y:429,t:1527267137616};\\\", \\\"{x:1272,y:416,t:1527267137634};\\\", \\\"{x:1272,y:400,t:1527267137649};\\\", \\\"{x:1272,y:385,t:1527267137666};\\\", \\\"{x:1272,y:370,t:1527267137684};\\\", \\\"{x:1272,y:354,t:1527267137700};\\\", \\\"{x:1272,y:333,t:1527267137717};\\\", \\\"{x:1272,y:312,t:1527267137734};\\\", \\\"{x:1272,y:294,t:1527267137749};\\\", \\\"{x:1272,y:276,t:1527267137767};\\\", \\\"{x:1272,y:264,t:1527267137784};\\\", \\\"{x:1272,y:250,t:1527267137799};\\\", \\\"{x:1272,y:229,t:1527267137816};\\\", \\\"{x:1271,y:217,t:1527267137834};\\\", \\\"{x:1270,y:201,t:1527267137851};\\\", \\\"{x:1270,y:193,t:1527267137867};\\\", \\\"{x:1270,y:183,t:1527267137884};\\\", \\\"{x:1270,y:179,t:1527267137900};\\\", \\\"{x:1270,y:176,t:1527267137916};\\\", \\\"{x:1274,y:187,t:1527267138009};\\\", \\\"{x:1280,y:212,t:1527267138017};\\\", \\\"{x:1288,y:266,t:1527267138033};\\\", \\\"{x:1301,y:344,t:1527267138050};\\\", \\\"{x:1316,y:433,t:1527267138066};\\\", \\\"{x:1336,y:545,t:1527267138084};\\\", \\\"{x:1351,y:658,t:1527267138101};\\\", \\\"{x:1374,y:755,t:1527267138117};\\\", \\\"{x:1390,y:808,t:1527267138133};\\\", \\\"{x:1390,y:809,t:1527267138151};\\\", \\\"{x:1395,y:812,t:1527267138167};\\\", \\\"{x:1395,y:813,t:1527267138888};\\\", \\\"{x:1396,y:814,t:1527267138921};\\\", \\\"{x:1396,y:815,t:1527267139144};\\\", \\\"{x:1396,y:816,t:1527267139561};\\\", \\\"{x:1394,y:819,t:1527267139568};\\\", \\\"{x:1389,y:826,t:1527267139584};\\\", \\\"{x:1381,y:832,t:1527267139600};\\\", \\\"{x:1375,y:838,t:1527267139617};\\\", \\\"{x:1368,y:846,t:1527267139634};\\\", \\\"{x:1360,y:855,t:1527267139651};\\\", \\\"{x:1357,y:859,t:1527267139667};\\\", \\\"{x:1353,y:864,t:1527267139684};\\\", \\\"{x:1349,y:869,t:1527267139701};\\\", \\\"{x:1346,y:873,t:1527267139718};\\\", \\\"{x:1343,y:877,t:1527267139734};\\\", \\\"{x:1339,y:880,t:1527267139752};\\\", \\\"{x:1333,y:884,t:1527267139767};\\\", \\\"{x:1328,y:888,t:1527267139785};\\\", \\\"{x:1323,y:891,t:1527267139802};\\\", \\\"{x:1317,y:895,t:1527267139819};\\\", \\\"{x:1310,y:900,t:1527267139834};\\\", \\\"{x:1303,y:903,t:1527267139852};\\\", \\\"{x:1302,y:904,t:1527267139868};\\\", \\\"{x:1301,y:904,t:1527267140009};\\\", \\\"{x:1299,y:900,t:1527267140019};\\\", \\\"{x:1299,y:896,t:1527267140035};\\\", \\\"{x:1299,y:892,t:1527267140051};\\\", \\\"{x:1298,y:891,t:1527267140069};\\\", \\\"{x:1298,y:889,t:1527267140085};\\\", \\\"{x:1298,y:887,t:1527267140102};\\\", \\\"{x:1298,y:886,t:1527267140118};\\\", \\\"{x:1298,y:885,t:1527267140135};\\\", \\\"{x:1298,y:883,t:1527267140152};\\\", \\\"{x:1298,y:882,t:1527267140169};\\\", \\\"{x:1298,y:881,t:1527267140185};\\\", \\\"{x:1298,y:880,t:1527267140202};\\\", \\\"{x:1298,y:879,t:1527267140232};\\\", \\\"{x:1298,y:878,t:1527267140241};\\\", \\\"{x:1297,y:876,t:1527267140252};\\\", \\\"{x:1296,y:873,t:1527267140269};\\\", \\\"{x:1295,y:870,t:1527267140286};\\\", \\\"{x:1294,y:867,t:1527267140301};\\\", \\\"{x:1292,y:862,t:1527267140319};\\\", \\\"{x:1289,y:856,t:1527267140337};\\\", \\\"{x:1288,y:856,t:1527267140352};\\\", \\\"{x:1287,y:855,t:1527267140369};\\\", \\\"{x:1286,y:854,t:1527267140386};\\\", \\\"{x:1285,y:854,t:1527267140497};\\\", \\\"{x:1280,y:854,t:1527267140504};\\\", \\\"{x:1276,y:854,t:1527267140519};\\\", \\\"{x:1257,y:858,t:1527267140536};\\\", \\\"{x:1210,y:872,t:1527267140552};\\\", \\\"{x:1145,y:893,t:1527267140569};\\\", \\\"{x:1046,y:919,t:1527267140586};\\\", \\\"{x:937,y:927,t:1527267140602};\\\", \\\"{x:801,y:929,t:1527267140619};\\\", \\\"{x:662,y:911,t:1527267140636};\\\", \\\"{x:536,y:886,t:1527267140652};\\\", \\\"{x:438,y:850,t:1527267140669};\\\", \\\"{x:392,y:823,t:1527267140686};\\\", \\\"{x:376,y:802,t:1527267140703};\\\", \\\"{x:369,y:788,t:1527267140718};\\\", \\\"{x:368,y:777,t:1527267140736};\\\", \\\"{x:368,y:765,t:1527267140752};\\\", \\\"{x:370,y:758,t:1527267140769};\\\", \\\"{x:374,y:747,t:1527267140786};\\\", \\\"{x:375,y:741,t:1527267140802};\\\", \\\"{x:379,y:732,t:1527267140818};\\\", \\\"{x:380,y:721,t:1527267140836};\\\", \\\"{x:381,y:705,t:1527267140853};\\\", \\\"{x:381,y:692,t:1527267140868};\\\", \\\"{x:381,y:675,t:1527267140886};\\\", \\\"{x:381,y:666,t:1527267140903};\\\", \\\"{x:380,y:658,t:1527267140918};\\\", \\\"{x:375,y:653,t:1527267140936};\\\", \\\"{x:369,y:648,t:1527267140953};\\\", \\\"{x:363,y:644,t:1527267140968};\\\", \\\"{x:356,y:640,t:1527267140985};\\\", \\\"{x:349,y:634,t:1527267141003};\\\", \\\"{x:344,y:626,t:1527267141020};\\\", \\\"{x:332,y:613,t:1527267141036};\\\", \\\"{x:318,y:600,t:1527267141053};\\\", \\\"{x:306,y:585,t:1527267141070};\\\", \\\"{x:295,y:567,t:1527267141087};\\\", \\\"{x:282,y:549,t:1527267141103};\\\", \\\"{x:274,y:530,t:1527267141120};\\\", \\\"{x:274,y:520,t:1527267141136};\\\", \\\"{x:274,y:513,t:1527267141153};\\\", \\\"{x:278,y:506,t:1527267141169};\\\", \\\"{x:281,y:502,t:1527267141186};\\\", \\\"{x:285,y:494,t:1527267141204};\\\", \\\"{x:289,y:489,t:1527267141220};\\\", \\\"{x:295,y:482,t:1527267141237};\\\", \\\"{x:301,y:477,t:1527267141253};\\\", \\\"{x:305,y:476,t:1527267141270};\\\", \\\"{x:307,y:476,t:1527267141287};\\\", \\\"{x:310,y:476,t:1527267141303};\\\", \\\"{x:317,y:477,t:1527267141320};\\\", \\\"{x:325,y:484,t:1527267141337};\\\", \\\"{x:338,y:494,t:1527267141354};\\\", \\\"{x:344,y:501,t:1527267141370};\\\", \\\"{x:352,y:505,t:1527267141387};\\\", \\\"{x:357,y:506,t:1527267141404};\\\", \\\"{x:360,y:506,t:1527267141420};\\\", \\\"{x:362,y:506,t:1527267141503};\\\", \\\"{x:363,y:506,t:1527267141520};\\\", \\\"{x:364,y:506,t:1527267141544};\\\", \\\"{x:365,y:506,t:1527267141554};\\\", \\\"{x:366,y:506,t:1527267141571};\\\", \\\"{x:368,y:506,t:1527267141587};\\\", \\\"{x:369,y:506,t:1527267141603};\\\", \\\"{x:370,y:508,t:1527267141621};\\\", \\\"{x:371,y:509,t:1527267141637};\\\", \\\"{x:371,y:514,t:1527267141655};\\\", \\\"{x:373,y:517,t:1527267141670};\\\", \\\"{x:374,y:517,t:1527267141689};\\\", \\\"{x:375,y:517,t:1527267142071};\\\", \\\"{x:377,y:519,t:1527267142112};\\\", \\\"{x:379,y:519,t:1527267142128};\\\", \\\"{x:382,y:520,t:1527267142138};\\\", \\\"{x:388,y:523,t:1527267142155};\\\", \\\"{x:404,y:532,t:1527267142171};\\\", \\\"{x:484,y:558,t:1527267142188};\\\", \\\"{x:590,y:578,t:1527267142204};\\\", \\\"{x:672,y:596,t:1527267142220};\\\", \\\"{x:673,y:601,t:1527267142237};\\\", \\\"{x:674,y:602,t:1527267143736};\\\", \\\"{x:674,y:604,t:1527267146792};\\\", \\\"{x:670,y:613,t:1527267146801};\\\", \\\"{x:667,y:623,t:1527267146815};\\\", \\\"{x:660,y:639,t:1527267146824};\\\", \\\"{x:653,y:655,t:1527267146841};\\\", \\\"{x:644,y:668,t:1527267146858};\\\", \\\"{x:640,y:671,t:1527267146874};\\\", \\\"{x:631,y:676,t:1527267146891};\\\", \\\"{x:615,y:682,t:1527267146908};\\\", \\\"{x:600,y:683,t:1527267146925};\\\", \\\"{x:588,y:685,t:1527267146941};\\\", \\\"{x:584,y:686,t:1527267146957};\\\", \\\"{x:578,y:687,t:1527267146975};\\\", \\\"{x:574,y:689,t:1527267146992};\\\", \\\"{x:569,y:691,t:1527267147008};\\\", \\\"{x:567,y:691,t:1527267147025};\\\", \\\"{x:564,y:691,t:1527267147042};\\\", \\\"{x:563,y:693,t:1527267147058};\\\", \\\"{x:562,y:693,t:1527267147075};\\\", \\\"{x:558,y:694,t:1527267147091};\\\", \\\"{x:555,y:696,t:1527267147107};\\\", \\\"{x:552,y:698,t:1527267147125};\\\", \\\"{x:551,y:699,t:1527267147142};\\\", \\\"{x:549,y:700,t:1527267147158};\\\", \\\"{x:548,y:701,t:1527267147186};\\\", \\\"{x:547,y:701,t:1527267147249};\\\", \\\"{x:546,y:701,t:1527267147259};\\\", \\\"{x:544,y:701,t:1527267147275};\\\", \\\"{x:543,y:701,t:1527267147292};\\\", \\\"{x:542,y:702,t:1527267147309};\\\", \\\"{x:542,y:703,t:1527267147328};\\\", \\\"{x:542,y:704,t:1527267147342};\\\", \\\"{x:542,y:705,t:1527267147359};\\\", \\\"{x:542,y:706,t:1527267147375};\\\" ] }, { \\\"rt\\\": 22744, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 141382, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -D -D -D -E -E -D -D -D -D -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:707,t:1527267151364};\\\", \\\"{x:555,y:707,t:1527267151377};\\\", \\\"{x:564,y:708,t:1527267151386};\\\", \\\"{x:578,y:709,t:1527267151403};\\\", \\\"{x:586,y:709,t:1527267151418};\\\", \\\"{x:601,y:709,t:1527267151435};\\\", \\\"{x:606,y:709,t:1527267151448};\\\", \\\"{x:618,y:709,t:1527267151465};\\\", \\\"{x:627,y:709,t:1527267151481};\\\", \\\"{x:630,y:709,t:1527267151498};\\\", \\\"{x:634,y:710,t:1527267151514};\\\", \\\"{x:636,y:711,t:1527267151532};\\\", \\\"{x:637,y:711,t:1527267151549};\\\", \\\"{x:639,y:711,t:1527267151565};\\\", \\\"{x:641,y:712,t:1527267151595};\\\", \\\"{x:643,y:713,t:1527267151619};\\\", \\\"{x:644,y:713,t:1527267151636};\\\", \\\"{x:645,y:713,t:1527267151649};\\\", \\\"{x:647,y:714,t:1527267151665};\\\", \\\"{x:650,y:715,t:1527267151682};\\\", \\\"{x:653,y:715,t:1527267151699};\\\", \\\"{x:657,y:715,t:1527267151715};\\\", \\\"{x:661,y:717,t:1527267151733};\\\", \\\"{x:665,y:718,t:1527267151749};\\\", \\\"{x:670,y:718,t:1527267151766};\\\", \\\"{x:674,y:718,t:1527267151782};\\\", \\\"{x:678,y:718,t:1527267151798};\\\", \\\"{x:692,y:721,t:1527267151816};\\\", \\\"{x:717,y:724,t:1527267151833};\\\", \\\"{x:746,y:725,t:1527267151848};\\\", \\\"{x:785,y:725,t:1527267151865};\\\", \\\"{x:833,y:725,t:1527267151883};\\\", \\\"{x:865,y:730,t:1527267151899};\\\", \\\"{x:905,y:733,t:1527267151915};\\\", \\\"{x:929,y:733,t:1527267151933};\\\", \\\"{x:955,y:733,t:1527267151949};\\\", \\\"{x:977,y:733,t:1527267151966};\\\", \\\"{x:988,y:733,t:1527267151983};\\\", \\\"{x:995,y:733,t:1527267151999};\\\", \\\"{x:1001,y:733,t:1527267152016};\\\", \\\"{x:1007,y:733,t:1527267152033};\\\", \\\"{x:1012,y:733,t:1527267152050};\\\", \\\"{x:1017,y:733,t:1527267152065};\\\", \\\"{x:1022,y:733,t:1527267152083};\\\", \\\"{x:1033,y:733,t:1527267152099};\\\", \\\"{x:1042,y:733,t:1527267152115};\\\", \\\"{x:1051,y:733,t:1527267152132};\\\", \\\"{x:1063,y:733,t:1527267152149};\\\", \\\"{x:1074,y:733,t:1527267152165};\\\", \\\"{x:1089,y:733,t:1527267152182};\\\", \\\"{x:1100,y:733,t:1527267152199};\\\", \\\"{x:1108,y:733,t:1527267152216};\\\", \\\"{x:1120,y:733,t:1527267152232};\\\", \\\"{x:1131,y:733,t:1527267152249};\\\", \\\"{x:1144,y:733,t:1527267152266};\\\", \\\"{x:1155,y:733,t:1527267152282};\\\", \\\"{x:1180,y:736,t:1527267152299};\\\", \\\"{x:1200,y:739,t:1527267152316};\\\", \\\"{x:1216,y:739,t:1527267152332};\\\", \\\"{x:1231,y:739,t:1527267152349};\\\", \\\"{x:1245,y:740,t:1527267152366};\\\", \\\"{x:1256,y:741,t:1527267152383};\\\", \\\"{x:1266,y:742,t:1527267152399};\\\", \\\"{x:1279,y:744,t:1527267152417};\\\", \\\"{x:1289,y:745,t:1527267152432};\\\", \\\"{x:1295,y:745,t:1527267152449};\\\", \\\"{x:1298,y:746,t:1527267152466};\\\", \\\"{x:1303,y:748,t:1527267152482};\\\", \\\"{x:1314,y:748,t:1527267152499};\\\", \\\"{x:1321,y:749,t:1527267152517};\\\", \\\"{x:1328,y:749,t:1527267152533};\\\", \\\"{x:1332,y:750,t:1527267152549};\\\", \\\"{x:1339,y:752,t:1527267152566};\\\", \\\"{x:1353,y:754,t:1527267152583};\\\", \\\"{x:1370,y:755,t:1527267152599};\\\", \\\"{x:1384,y:758,t:1527267152618};\\\", \\\"{x:1390,y:758,t:1527267152633};\\\", \\\"{x:1393,y:758,t:1527267152649};\\\", \\\"{x:1394,y:758,t:1527267152701};\\\", \\\"{x:1397,y:757,t:1527267152717};\\\", \\\"{x:1401,y:753,t:1527267152733};\\\", \\\"{x:1402,y:751,t:1527267152750};\\\", \\\"{x:1403,y:749,t:1527267152767};\\\", \\\"{x:1405,y:746,t:1527267152783};\\\", \\\"{x:1408,y:740,t:1527267152800};\\\", \\\"{x:1410,y:737,t:1527267152816};\\\", \\\"{x:1411,y:731,t:1527267152834};\\\", \\\"{x:1412,y:724,t:1527267152849};\\\", \\\"{x:1412,y:712,t:1527267152867};\\\", \\\"{x:1412,y:690,t:1527267152883};\\\", \\\"{x:1403,y:672,t:1527267152900};\\\", \\\"{x:1397,y:654,t:1527267152916};\\\", \\\"{x:1392,y:643,t:1527267152934};\\\", \\\"{x:1390,y:639,t:1527267152949};\\\", \\\"{x:1388,y:635,t:1527267152966};\\\", \\\"{x:1388,y:633,t:1527267152996};\\\", \\\"{x:1388,y:632,t:1527267153020};\\\", \\\"{x:1387,y:630,t:1527267153033};\\\", \\\"{x:1386,y:629,t:1527267153051};\\\", \\\"{x:1385,y:626,t:1527267153067};\\\", \\\"{x:1383,y:621,t:1527267153084};\\\", \\\"{x:1379,y:616,t:1527267153100};\\\", \\\"{x:1376,y:613,t:1527267153117};\\\", \\\"{x:1375,y:611,t:1527267153134};\\\", \\\"{x:1374,y:610,t:1527267153150};\\\", \\\"{x:1373,y:610,t:1527267153204};\\\", \\\"{x:1372,y:609,t:1527267153217};\\\", \\\"{x:1370,y:609,t:1527267153236};\\\", \\\"{x:1369,y:609,t:1527267153250};\\\", \\\"{x:1367,y:609,t:1527267153267};\\\", \\\"{x:1363,y:609,t:1527267153284};\\\", \\\"{x:1362,y:609,t:1527267153340};\\\", \\\"{x:1360,y:610,t:1527267153396};\\\", \\\"{x:1360,y:612,t:1527267153533};\\\", \\\"{x:1361,y:612,t:1527267153540};\\\", \\\"{x:1364,y:612,t:1527267153551};\\\", \\\"{x:1371,y:613,t:1527267153567};\\\", \\\"{x:1381,y:614,t:1527267153583};\\\", \\\"{x:1387,y:615,t:1527267153601};\\\", \\\"{x:1390,y:616,t:1527267153617};\\\", \\\"{x:1393,y:616,t:1527267153634};\\\", \\\"{x:1394,y:618,t:1527267153651};\\\", \\\"{x:1397,y:619,t:1527267153667};\\\", \\\"{x:1402,y:623,t:1527267153684};\\\", \\\"{x:1403,y:623,t:1527267153701};\\\", \\\"{x:1405,y:625,t:1527267153718};\\\", \\\"{x:1407,y:627,t:1527267153756};\\\", \\\"{x:1408,y:629,t:1527267153768};\\\", \\\"{x:1408,y:631,t:1527267153784};\\\", \\\"{x:1409,y:635,t:1527267153801};\\\", \\\"{x:1411,y:638,t:1527267153818};\\\", \\\"{x:1411,y:639,t:1527267153834};\\\", \\\"{x:1411,y:642,t:1527267153852};\\\", \\\"{x:1414,y:647,t:1527267153868};\\\", \\\"{x:1421,y:654,t:1527267153884};\\\", \\\"{x:1429,y:663,t:1527267153901};\\\", \\\"{x:1436,y:672,t:1527267153918};\\\", \\\"{x:1442,y:680,t:1527267153934};\\\", \\\"{x:1444,y:683,t:1527267153951};\\\", \\\"{x:1444,y:685,t:1527267153967};\\\", \\\"{x:1444,y:687,t:1527267153984};\\\", \\\"{x:1444,y:689,t:1527267154000};\\\", \\\"{x:1446,y:692,t:1527267154018};\\\", \\\"{x:1446,y:695,t:1527267154034};\\\", \\\"{x:1446,y:698,t:1527267154051};\\\", \\\"{x:1446,y:706,t:1527267154068};\\\", \\\"{x:1446,y:711,t:1527267154085};\\\", \\\"{x:1447,y:717,t:1527267154101};\\\", \\\"{x:1447,y:722,t:1527267154118};\\\", \\\"{x:1448,y:730,t:1527267154135};\\\", \\\"{x:1449,y:733,t:1527267154151};\\\", \\\"{x:1452,y:737,t:1527267154168};\\\", \\\"{x:1455,y:741,t:1527267154185};\\\", \\\"{x:1457,y:743,t:1527267154201};\\\", \\\"{x:1459,y:746,t:1527267154218};\\\", \\\"{x:1463,y:751,t:1527267154235};\\\", \\\"{x:1466,y:756,t:1527267154251};\\\", \\\"{x:1471,y:767,t:1527267154268};\\\", \\\"{x:1474,y:773,t:1527267154285};\\\", \\\"{x:1479,y:783,t:1527267154301};\\\", \\\"{x:1484,y:792,t:1527267154318};\\\", \\\"{x:1488,y:799,t:1527267154335};\\\", \\\"{x:1492,y:807,t:1527267154352};\\\", \\\"{x:1496,y:813,t:1527267154368};\\\", \\\"{x:1500,y:818,t:1527267154385};\\\", \\\"{x:1504,y:821,t:1527267154402};\\\", \\\"{x:1506,y:824,t:1527267154418};\\\", \\\"{x:1507,y:826,t:1527267154435};\\\", \\\"{x:1510,y:829,t:1527267154451};\\\", \\\"{x:1514,y:836,t:1527267154468};\\\", \\\"{x:1517,y:839,t:1527267154485};\\\", \\\"{x:1523,y:842,t:1527267154501};\\\", \\\"{x:1524,y:844,t:1527267154518};\\\", \\\"{x:1525,y:844,t:1527267154535};\\\", \\\"{x:1527,y:846,t:1527267154597};\\\", \\\"{x:1529,y:847,t:1527267154604};\\\", \\\"{x:1530,y:848,t:1527267154618};\\\", \\\"{x:1531,y:849,t:1527267154635};\\\", \\\"{x:1532,y:849,t:1527267154652};\\\", \\\"{x:1534,y:850,t:1527267154668};\\\", \\\"{x:1535,y:850,t:1527267154691};\\\", \\\"{x:1536,y:850,t:1527267154708};\\\", \\\"{x:1538,y:850,t:1527267154718};\\\", \\\"{x:1540,y:851,t:1527267154736};\\\", \\\"{x:1543,y:852,t:1527267154752};\\\", \\\"{x:1545,y:853,t:1527267154768};\\\", \\\"{x:1545,y:854,t:1527267154828};\\\", \\\"{x:1545,y:855,t:1527267154852};\\\", \\\"{x:1543,y:856,t:1527267154868};\\\", \\\"{x:1539,y:857,t:1527267154885};\\\", \\\"{x:1531,y:859,t:1527267154902};\\\", \\\"{x:1527,y:860,t:1527267154918};\\\", \\\"{x:1519,y:861,t:1527267154935};\\\", \\\"{x:1514,y:862,t:1527267154952};\\\", \\\"{x:1508,y:864,t:1527267154967};\\\", \\\"{x:1506,y:864,t:1527267154985};\\\", \\\"{x:1505,y:864,t:1527267155003};\\\", \\\"{x:1504,y:864,t:1527267155028};\\\", \\\"{x:1502,y:864,t:1527267155068};\\\", \\\"{x:1497,y:865,t:1527267155085};\\\", \\\"{x:1496,y:865,t:1527267155102};\\\", \\\"{x:1492,y:867,t:1527267155119};\\\", \\\"{x:1490,y:867,t:1527267155135};\\\", \\\"{x:1487,y:868,t:1527267155152};\\\", \\\"{x:1484,y:868,t:1527267155169};\\\", \\\"{x:1480,y:869,t:1527267155185};\\\", \\\"{x:1477,y:869,t:1527267155204};\\\", \\\"{x:1475,y:869,t:1527267155219};\\\", \\\"{x:1473,y:869,t:1527267155235};\\\", \\\"{x:1471,y:869,t:1527267155252};\\\", \\\"{x:1470,y:869,t:1527267155269};\\\", \\\"{x:1470,y:870,t:1527267155284};\\\", \\\"{x:1469,y:871,t:1527267155324};\\\", \\\"{x:1468,y:871,t:1527267155348};\\\", \\\"{x:1467,y:870,t:1527267155356};\\\", \\\"{x:1465,y:869,t:1527267155388};\\\", \\\"{x:1465,y:868,t:1527267155452};\\\", \\\"{x:1465,y:867,t:1527267155588};\\\", \\\"{x:1465,y:865,t:1527267155740};\\\", \\\"{x:1465,y:864,t:1527267155752};\\\", \\\"{x:1465,y:862,t:1527267155769};\\\", \\\"{x:1465,y:861,t:1527267155786};\\\", \\\"{x:1465,y:859,t:1527267155804};\\\", \\\"{x:1465,y:858,t:1527267155820};\\\", \\\"{x:1464,y:856,t:1527267155836};\\\", \\\"{x:1464,y:854,t:1527267155853};\\\", \\\"{x:1463,y:852,t:1527267155869};\\\", \\\"{x:1462,y:849,t:1527267155886};\\\", \\\"{x:1462,y:847,t:1527267155903};\\\", \\\"{x:1461,y:845,t:1527267155919};\\\", \\\"{x:1460,y:842,t:1527267155936};\\\", \\\"{x:1460,y:839,t:1527267155953};\\\", \\\"{x:1456,y:834,t:1527267155969};\\\", \\\"{x:1455,y:828,t:1527267155986};\\\", \\\"{x:1450,y:817,t:1527267156004};\\\", \\\"{x:1448,y:814,t:1527267156018};\\\", \\\"{x:1444,y:804,t:1527267156036};\\\", \\\"{x:1435,y:793,t:1527267156053};\\\", \\\"{x:1429,y:786,t:1527267156069};\\\", \\\"{x:1426,y:782,t:1527267156086};\\\", \\\"{x:1424,y:780,t:1527267156103};\\\", \\\"{x:1423,y:779,t:1527267156119};\\\", \\\"{x:1422,y:779,t:1527267156136};\\\", \\\"{x:1421,y:778,t:1527267156237};\\\", \\\"{x:1421,y:776,t:1527267156253};\\\", \\\"{x:1420,y:776,t:1527267156291};\\\", \\\"{x:1419,y:774,t:1527267157228};\\\", \\\"{x:1420,y:772,t:1527267157237};\\\", \\\"{x:1424,y:764,t:1527267157254};\\\", \\\"{x:1427,y:756,t:1527267157270};\\\", \\\"{x:1431,y:751,t:1527267157288};\\\", \\\"{x:1435,y:743,t:1527267157304};\\\", \\\"{x:1439,y:739,t:1527267157320};\\\", \\\"{x:1443,y:732,t:1527267157337};\\\", \\\"{x:1451,y:720,t:1527267157355};\\\", \\\"{x:1462,y:699,t:1527267157370};\\\", \\\"{x:1473,y:679,t:1527267157387};\\\", \\\"{x:1488,y:652,t:1527267157404};\\\", \\\"{x:1498,y:634,t:1527267157420};\\\", \\\"{x:1508,y:620,t:1527267157438};\\\", \\\"{x:1516,y:609,t:1527267157454};\\\", \\\"{x:1521,y:602,t:1527267157470};\\\", \\\"{x:1525,y:594,t:1527267157487};\\\", \\\"{x:1531,y:585,t:1527267157504};\\\", \\\"{x:1537,y:575,t:1527267157520};\\\", \\\"{x:1545,y:564,t:1527267157537};\\\", \\\"{x:1551,y:553,t:1527267157555};\\\", \\\"{x:1553,y:545,t:1527267157571};\\\", \\\"{x:1556,y:536,t:1527267157587};\\\", \\\"{x:1567,y:516,t:1527267157604};\\\", \\\"{x:1577,y:493,t:1527267157620};\\\", \\\"{x:1588,y:475,t:1527267157638};\\\", \\\"{x:1599,y:455,t:1527267157655};\\\", \\\"{x:1609,y:439,t:1527267157671};\\\", \\\"{x:1614,y:428,t:1527267157687};\\\", \\\"{x:1617,y:422,t:1527267157705};\\\", \\\"{x:1620,y:417,t:1527267157721};\\\", \\\"{x:1622,y:414,t:1527267157737};\\\", \\\"{x:1623,y:414,t:1527267157957};\\\", \\\"{x:1623,y:416,t:1527267157971};\\\", \\\"{x:1622,y:420,t:1527267157987};\\\", \\\"{x:1621,y:423,t:1527267158004};\\\", \\\"{x:1620,y:426,t:1527267158124};\\\", \\\"{x:1620,y:428,t:1527267158138};\\\", \\\"{x:1620,y:434,t:1527267158155};\\\", \\\"{x:1618,y:439,t:1527267158171};\\\", \\\"{x:1617,y:444,t:1527267158188};\\\", \\\"{x:1617,y:447,t:1527267158204};\\\", \\\"{x:1617,y:451,t:1527267158221};\\\", \\\"{x:1616,y:454,t:1527267158237};\\\", \\\"{x:1616,y:456,t:1527267158253};\\\", \\\"{x:1616,y:458,t:1527267158270};\\\", \\\"{x:1615,y:461,t:1527267158288};\\\", \\\"{x:1615,y:463,t:1527267158304};\\\", \\\"{x:1615,y:470,t:1527267158321};\\\", \\\"{x:1615,y:478,t:1527267158338};\\\", \\\"{x:1615,y:486,t:1527267158354};\\\", \\\"{x:1615,y:495,t:1527267158370};\\\", \\\"{x:1615,y:503,t:1527267158387};\\\", \\\"{x:1615,y:510,t:1527267158404};\\\", \\\"{x:1615,y:515,t:1527267158421};\\\", \\\"{x:1615,y:523,t:1527267158437};\\\", \\\"{x:1615,y:535,t:1527267158454};\\\", \\\"{x:1615,y:541,t:1527267158471};\\\", \\\"{x:1615,y:548,t:1527267158488};\\\", \\\"{x:1615,y:555,t:1527267158504};\\\", \\\"{x:1615,y:557,t:1527267158521};\\\", \\\"{x:1615,y:559,t:1527267158538};\\\", \\\"{x:1615,y:563,t:1527267158554};\\\", \\\"{x:1615,y:565,t:1527267158596};\\\", \\\"{x:1615,y:566,t:1527267160404};\\\", \\\"{x:1615,y:568,t:1527267160412};\\\", \\\"{x:1615,y:572,t:1527267160425};\\\", \\\"{x:1615,y:575,t:1527267160440};\\\", \\\"{x:1615,y:577,t:1527267160456};\\\", \\\"{x:1615,y:580,t:1527267160473};\\\", \\\"{x:1614,y:582,t:1527267160489};\\\", \\\"{x:1614,y:584,t:1527267160506};\\\", \\\"{x:1614,y:586,t:1527267160523};\\\", \\\"{x:1614,y:588,t:1527267160540};\\\", \\\"{x:1614,y:592,t:1527267160556};\\\", \\\"{x:1613,y:594,t:1527267160574};\\\", \\\"{x:1613,y:596,t:1527267160589};\\\", \\\"{x:1613,y:598,t:1527267160606};\\\", \\\"{x:1613,y:600,t:1527267160623};\\\", \\\"{x:1612,y:602,t:1527267160640};\\\", \\\"{x:1612,y:604,t:1527267160656};\\\", \\\"{x:1611,y:605,t:1527267160673};\\\", \\\"{x:1611,y:607,t:1527267160689};\\\", \\\"{x:1611,y:608,t:1527267160707};\\\", \\\"{x:1611,y:612,t:1527267160723};\\\", \\\"{x:1611,y:614,t:1527267160740};\\\", \\\"{x:1610,y:615,t:1527267160756};\\\", \\\"{x:1610,y:610,t:1527267160916};\\\", \\\"{x:1607,y:604,t:1527267160924};\\\", \\\"{x:1605,y:590,t:1527267160939};\\\", \\\"{x:1601,y:576,t:1527267160956};\\\", \\\"{x:1598,y:567,t:1527267160973};\\\", \\\"{x:1597,y:562,t:1527267160990};\\\", \\\"{x:1597,y:558,t:1527267161006};\\\", \\\"{x:1598,y:554,t:1527267161024};\\\", \\\"{x:1598,y:552,t:1527267161040};\\\", \\\"{x:1598,y:546,t:1527267161056};\\\", \\\"{x:1598,y:540,t:1527267161074};\\\", \\\"{x:1598,y:532,t:1527267161090};\\\", \\\"{x:1598,y:525,t:1527267161107};\\\", \\\"{x:1599,y:517,t:1527267161123};\\\", \\\"{x:1603,y:507,t:1527267161140};\\\", \\\"{x:1604,y:500,t:1527267161156};\\\", \\\"{x:1605,y:491,t:1527267161173};\\\", \\\"{x:1606,y:480,t:1527267161191};\\\", \\\"{x:1608,y:471,t:1527267161207};\\\", \\\"{x:1611,y:463,t:1527267161224};\\\", \\\"{x:1612,y:458,t:1527267161240};\\\", \\\"{x:1612,y:453,t:1527267161257};\\\", \\\"{x:1612,y:449,t:1527267161274};\\\", \\\"{x:1615,y:445,t:1527267161290};\\\", \\\"{x:1615,y:442,t:1527267161307};\\\", \\\"{x:1616,y:439,t:1527267161323};\\\", \\\"{x:1617,y:435,t:1527267161340};\\\", \\\"{x:1618,y:435,t:1527267161359};\\\", \\\"{x:1618,y:433,t:1527267161429};\\\", \\\"{x:1618,y:432,t:1527267161440};\\\", \\\"{x:1618,y:429,t:1527267161457};\\\", \\\"{x:1618,y:427,t:1527267161473};\\\", \\\"{x:1617,y:424,t:1527267161491};\\\", \\\"{x:1617,y:422,t:1527267161507};\\\", \\\"{x:1616,y:422,t:1527267161531};\\\", \\\"{x:1615,y:421,t:1527267161556};\\\", \\\"{x:1614,y:421,t:1527267161571};\\\", \\\"{x:1612,y:421,t:1527267161587};\\\", \\\"{x:1611,y:421,t:1527267161700};\\\", \\\"{x:1611,y:423,t:1527267161731};\\\", \\\"{x:1611,y:424,t:1527267161740};\\\", \\\"{x:1611,y:426,t:1527267161757};\\\", \\\"{x:1611,y:428,t:1527267161774};\\\", \\\"{x:1611,y:432,t:1527267161790};\\\", \\\"{x:1613,y:435,t:1527267161807};\\\", \\\"{x:1613,y:439,t:1527267161826};\\\", \\\"{x:1613,y:441,t:1527267161840};\\\", \\\"{x:1613,y:444,t:1527267161858};\\\", \\\"{x:1613,y:446,t:1527267161874};\\\", \\\"{x:1613,y:449,t:1527267161891};\\\", \\\"{x:1615,y:455,t:1527267161908};\\\", \\\"{x:1616,y:459,t:1527267161924};\\\", \\\"{x:1616,y:462,t:1527267161941};\\\", \\\"{x:1616,y:465,t:1527267161958};\\\", \\\"{x:1616,y:467,t:1527267161975};\\\", \\\"{x:1617,y:470,t:1527267161990};\\\", \\\"{x:1617,y:472,t:1527267162012};\\\", \\\"{x:1617,y:473,t:1527267162025};\\\", \\\"{x:1617,y:475,t:1527267162040};\\\", \\\"{x:1617,y:476,t:1527267162057};\\\", \\\"{x:1617,y:479,t:1527267162073};\\\", \\\"{x:1617,y:481,t:1527267162089};\\\", \\\"{x:1617,y:485,t:1527267162107};\\\", \\\"{x:1617,y:486,t:1527267162123};\\\", \\\"{x:1617,y:489,t:1527267162141};\\\", \\\"{x:1617,y:491,t:1527267162157};\\\", \\\"{x:1617,y:494,t:1527267162174};\\\", \\\"{x:1617,y:497,t:1527267162191};\\\", \\\"{x:1619,y:501,t:1527267162207};\\\", \\\"{x:1619,y:504,t:1527267162224};\\\", \\\"{x:1619,y:508,t:1527267162241};\\\", \\\"{x:1619,y:511,t:1527267162257};\\\", \\\"{x:1619,y:516,t:1527267162274};\\\", \\\"{x:1619,y:523,t:1527267162291};\\\", \\\"{x:1619,y:526,t:1527267162307};\\\", \\\"{x:1619,y:527,t:1527267162324};\\\", \\\"{x:1619,y:529,t:1527267162341};\\\", \\\"{x:1620,y:530,t:1527267162357};\\\", \\\"{x:1621,y:531,t:1527267162380};\\\", \\\"{x:1621,y:532,t:1527267162391};\\\", \\\"{x:1621,y:533,t:1527267162407};\\\", \\\"{x:1621,y:536,t:1527267162424};\\\", \\\"{x:1621,y:540,t:1527267162441};\\\", \\\"{x:1621,y:544,t:1527267162457};\\\", \\\"{x:1621,y:548,t:1527267162474};\\\", \\\"{x:1620,y:555,t:1527267162492};\\\", \\\"{x:1620,y:556,t:1527267162507};\\\", \\\"{x:1620,y:558,t:1527267162524};\\\", \\\"{x:1619,y:560,t:1527267162541};\\\", \\\"{x:1619,y:563,t:1527267162557};\\\", \\\"{x:1619,y:565,t:1527267162574};\\\", \\\"{x:1618,y:567,t:1527267162591};\\\", \\\"{x:1618,y:569,t:1527267162609};\\\", \\\"{x:1618,y:570,t:1527267162624};\\\", \\\"{x:1618,y:572,t:1527267162641};\\\", \\\"{x:1618,y:573,t:1527267162659};\\\", \\\"{x:1618,y:577,t:1527267162674};\\\", \\\"{x:1616,y:582,t:1527267162691};\\\", \\\"{x:1616,y:584,t:1527267162708};\\\", \\\"{x:1615,y:589,t:1527267162725};\\\", \\\"{x:1615,y:591,t:1527267162741};\\\", \\\"{x:1615,y:594,t:1527267162758};\\\", \\\"{x:1615,y:596,t:1527267162774};\\\", \\\"{x:1615,y:597,t:1527267162791};\\\", \\\"{x:1615,y:599,t:1527267162808};\\\", \\\"{x:1615,y:600,t:1527267162824};\\\", \\\"{x:1615,y:604,t:1527267162841};\\\", \\\"{x:1615,y:606,t:1527267162859};\\\", \\\"{x:1615,y:608,t:1527267162874};\\\", \\\"{x:1615,y:611,t:1527267162892};\\\", \\\"{x:1615,y:613,t:1527267162908};\\\", \\\"{x:1615,y:614,t:1527267162925};\\\", \\\"{x:1615,y:615,t:1527267162941};\\\", \\\"{x:1615,y:617,t:1527267162958};\\\", \\\"{x:1615,y:619,t:1527267162975};\\\", \\\"{x:1615,y:622,t:1527267162991};\\\", \\\"{x:1615,y:626,t:1527267163008};\\\", \\\"{x:1615,y:629,t:1527267163024};\\\", \\\"{x:1615,y:631,t:1527267163041};\\\", \\\"{x:1615,y:632,t:1527267163058};\\\", \\\"{x:1615,y:636,t:1527267163075};\\\", \\\"{x:1615,y:637,t:1527267163090};\\\", \\\"{x:1615,y:639,t:1527267163108};\\\", \\\"{x:1615,y:640,t:1527267163124};\\\", \\\"{x:1615,y:642,t:1527267163141};\\\", \\\"{x:1615,y:643,t:1527267163158};\\\", \\\"{x:1615,y:645,t:1527267163175};\\\", \\\"{x:1615,y:647,t:1527267163191};\\\", \\\"{x:1615,y:649,t:1527267163208};\\\", \\\"{x:1614,y:651,t:1527267163225};\\\", \\\"{x:1614,y:653,t:1527267163241};\\\", \\\"{x:1614,y:656,t:1527267163258};\\\", \\\"{x:1614,y:661,t:1527267163275};\\\", \\\"{x:1614,y:663,t:1527267163291};\\\", \\\"{x:1614,y:665,t:1527267163307};\\\", \\\"{x:1614,y:666,t:1527267163325};\\\", \\\"{x:1614,y:668,t:1527267163341};\\\", \\\"{x:1614,y:670,t:1527267163358};\\\", \\\"{x:1614,y:673,t:1527267163375};\\\", \\\"{x:1614,y:676,t:1527267163391};\\\", \\\"{x:1614,y:679,t:1527267163409};\\\", \\\"{x:1614,y:681,t:1527267163425};\\\", \\\"{x:1614,y:683,t:1527267163441};\\\", \\\"{x:1614,y:685,t:1527267163458};\\\", \\\"{x:1614,y:688,t:1527267163475};\\\", \\\"{x:1614,y:689,t:1527267163492};\\\", \\\"{x:1614,y:690,t:1527267163508};\\\", \\\"{x:1614,y:691,t:1527267163525};\\\", \\\"{x:1614,y:692,t:1527267163542};\\\", \\\"{x:1614,y:693,t:1527267163558};\\\", \\\"{x:1614,y:694,t:1527267163575};\\\", \\\"{x:1614,y:696,t:1527267163593};\\\", \\\"{x:1614,y:697,t:1527267163607};\\\", \\\"{x:1614,y:698,t:1527267163625};\\\", \\\"{x:1614,y:699,t:1527267163641};\\\", \\\"{x:1614,y:701,t:1527267163658};\\\", \\\"{x:1616,y:705,t:1527267163675};\\\", \\\"{x:1616,y:708,t:1527267163691};\\\", \\\"{x:1616,y:714,t:1527267163708};\\\", \\\"{x:1618,y:717,t:1527267163724};\\\", \\\"{x:1618,y:719,t:1527267163742};\\\", \\\"{x:1618,y:721,t:1527267163757};\\\", \\\"{x:1618,y:722,t:1527267163787};\\\", \\\"{x:1618,y:723,t:1527267163795};\\\", \\\"{x:1619,y:723,t:1527267163808};\\\", \\\"{x:1619,y:724,t:1527267163825};\\\", \\\"{x:1619,y:726,t:1527267163842};\\\", \\\"{x:1619,y:729,t:1527267163859};\\\", \\\"{x:1619,y:731,t:1527267163875};\\\", \\\"{x:1620,y:734,t:1527267163892};\\\", \\\"{x:1620,y:736,t:1527267163909};\\\", \\\"{x:1620,y:740,t:1527267163925};\\\", \\\"{x:1621,y:742,t:1527267163942};\\\", \\\"{x:1622,y:747,t:1527267163959};\\\", \\\"{x:1622,y:750,t:1527267163975};\\\", \\\"{x:1623,y:754,t:1527267163992};\\\", \\\"{x:1624,y:760,t:1527267164009};\\\", \\\"{x:1624,y:762,t:1527267164025};\\\", \\\"{x:1624,y:766,t:1527267164042};\\\", \\\"{x:1624,y:769,t:1527267164059};\\\", \\\"{x:1626,y:773,t:1527267164075};\\\", \\\"{x:1626,y:774,t:1527267164092};\\\", \\\"{x:1626,y:775,t:1527267164109};\\\", \\\"{x:1626,y:778,t:1527267164125};\\\", \\\"{x:1626,y:779,t:1527267164143};\\\", \\\"{x:1626,y:781,t:1527267164159};\\\", \\\"{x:1626,y:786,t:1527267164175};\\\", \\\"{x:1626,y:791,t:1527267164192};\\\", \\\"{x:1626,y:796,t:1527267164209};\\\", \\\"{x:1626,y:802,t:1527267164226};\\\", \\\"{x:1626,y:807,t:1527267164242};\\\", \\\"{x:1626,y:811,t:1527267164259};\\\", \\\"{x:1626,y:813,t:1527267164276};\\\", \\\"{x:1626,y:815,t:1527267164292};\\\", \\\"{x:1626,y:817,t:1527267164309};\\\", \\\"{x:1627,y:820,t:1527267164326};\\\", \\\"{x:1627,y:823,t:1527267164343};\\\", \\\"{x:1628,y:827,t:1527267164359};\\\", \\\"{x:1628,y:830,t:1527267164377};\\\", \\\"{x:1629,y:833,t:1527267164393};\\\", \\\"{x:1629,y:838,t:1527267164409};\\\", \\\"{x:1629,y:841,t:1527267164427};\\\", \\\"{x:1629,y:846,t:1527267164443};\\\", \\\"{x:1629,y:851,t:1527267164460};\\\", \\\"{x:1629,y:856,t:1527267164476};\\\", \\\"{x:1629,y:861,t:1527267164492};\\\", \\\"{x:1629,y:864,t:1527267164509};\\\", \\\"{x:1629,y:867,t:1527267164527};\\\", \\\"{x:1629,y:870,t:1527267164543};\\\", \\\"{x:1629,y:873,t:1527267164559};\\\", \\\"{x:1629,y:874,t:1527267164576};\\\", \\\"{x:1629,y:878,t:1527267164592};\\\", \\\"{x:1629,y:880,t:1527267164609};\\\", \\\"{x:1629,y:883,t:1527267164626};\\\", \\\"{x:1629,y:885,t:1527267164642};\\\", \\\"{x:1629,y:889,t:1527267164659};\\\", \\\"{x:1628,y:892,t:1527267164675};\\\", \\\"{x:1628,y:893,t:1527267164692};\\\", \\\"{x:1628,y:895,t:1527267164708};\\\", \\\"{x:1628,y:896,t:1527267164726};\\\", \\\"{x:1628,y:899,t:1527267164743};\\\", \\\"{x:1628,y:900,t:1527267164759};\\\", \\\"{x:1628,y:901,t:1527267164777};\\\", \\\"{x:1628,y:903,t:1527267164793};\\\", \\\"{x:1628,y:906,t:1527267164809};\\\", \\\"{x:1628,y:910,t:1527267164826};\\\", \\\"{x:1628,y:913,t:1527267164843};\\\", \\\"{x:1628,y:915,t:1527267164859};\\\", \\\"{x:1628,y:916,t:1527267164876};\\\", \\\"{x:1628,y:919,t:1527267164893};\\\", \\\"{x:1629,y:921,t:1527267164909};\\\", \\\"{x:1630,y:923,t:1527267164926};\\\", \\\"{x:1631,y:926,t:1527267164943};\\\", \\\"{x:1634,y:931,t:1527267164960};\\\", \\\"{x:1634,y:933,t:1527267164976};\\\", \\\"{x:1638,y:942,t:1527267164994};\\\", \\\"{x:1641,y:949,t:1527267165010};\\\", \\\"{x:1643,y:953,t:1527267165026};\\\", \\\"{x:1643,y:956,t:1527267165044};\\\", \\\"{x:1643,y:957,t:1527267165068};\\\", \\\"{x:1644,y:959,t:1527267165076};\\\", \\\"{x:1645,y:961,t:1527267165093};\\\", \\\"{x:1646,y:965,t:1527267165110};\\\", \\\"{x:1646,y:967,t:1527267165127};\\\", \\\"{x:1646,y:969,t:1527267165144};\\\", \\\"{x:1646,y:970,t:1527267165159};\\\", \\\"{x:1646,y:969,t:1527267165804};\\\", \\\"{x:1646,y:968,t:1527267165836};\\\", \\\"{x:1646,y:967,t:1527267165860};\\\", \\\"{x:1646,y:966,t:1527267165877};\\\", \\\"{x:1646,y:964,t:1527267165894};\\\", \\\"{x:1646,y:963,t:1527267165910};\\\", \\\"{x:1646,y:962,t:1527267165928};\\\", \\\"{x:1646,y:961,t:1527267165943};\\\", \\\"{x:1646,y:960,t:1527267165963};\\\", \\\"{x:1646,y:959,t:1527267165979};\\\", \\\"{x:1646,y:958,t:1527267165993};\\\", \\\"{x:1645,y:956,t:1527267166010};\\\", \\\"{x:1645,y:952,t:1527267166028};\\\", \\\"{x:1645,y:949,t:1527267166043};\\\", \\\"{x:1645,y:948,t:1527267166061};\\\", \\\"{x:1645,y:946,t:1527267166077};\\\", \\\"{x:1645,y:945,t:1527267166094};\\\", \\\"{x:1645,y:943,t:1527267166110};\\\", \\\"{x:1645,y:942,t:1527267166127};\\\", \\\"{x:1645,y:940,t:1527267166144};\\\", \\\"{x:1645,y:938,t:1527267166161};\\\", \\\"{x:1645,y:936,t:1527267166177};\\\", \\\"{x:1645,y:933,t:1527267166194};\\\", \\\"{x:1645,y:930,t:1527267166211};\\\", \\\"{x:1644,y:923,t:1527267166228};\\\", \\\"{x:1644,y:919,t:1527267166244};\\\", \\\"{x:1644,y:916,t:1527267166260};\\\", \\\"{x:1644,y:912,t:1527267166278};\\\", \\\"{x:1644,y:911,t:1527267166295};\\\", \\\"{x:1644,y:908,t:1527267166310};\\\", \\\"{x:1644,y:904,t:1527267166328};\\\", \\\"{x:1645,y:901,t:1527267166344};\\\", \\\"{x:1647,y:898,t:1527267166360};\\\", \\\"{x:1647,y:897,t:1527267166377};\\\", \\\"{x:1648,y:895,t:1527267166395};\\\", \\\"{x:1649,y:893,t:1527267166411};\\\", \\\"{x:1650,y:889,t:1527267166428};\\\", \\\"{x:1651,y:885,t:1527267166445};\\\", \\\"{x:1652,y:882,t:1527267166461};\\\", \\\"{x:1653,y:880,t:1527267166477};\\\", \\\"{x:1653,y:876,t:1527267166494};\\\", \\\"{x:1653,y:872,t:1527267166512};\\\", \\\"{x:1653,y:870,t:1527267166528};\\\", \\\"{x:1653,y:867,t:1527267166544};\\\", \\\"{x:1654,y:864,t:1527267166561};\\\", \\\"{x:1654,y:863,t:1527267166577};\\\", \\\"{x:1654,y:861,t:1527267166594};\\\", \\\"{x:1654,y:860,t:1527267166611};\\\", \\\"{x:1653,y:857,t:1527267166628};\\\", \\\"{x:1653,y:856,t:1527267166645};\\\", \\\"{x:1653,y:854,t:1527267166662};\\\", \\\"{x:1651,y:852,t:1527267166678};\\\", \\\"{x:1650,y:850,t:1527267166694};\\\", \\\"{x:1649,y:849,t:1527267166712};\\\", \\\"{x:1647,y:848,t:1527267166728};\\\", \\\"{x:1644,y:847,t:1527267166745};\\\", \\\"{x:1639,y:845,t:1527267166761};\\\", \\\"{x:1637,y:845,t:1527267166777};\\\", \\\"{x:1636,y:844,t:1527267166794};\\\", \\\"{x:1635,y:843,t:1527267166812};\\\", \\\"{x:1634,y:843,t:1527267166828};\\\", \\\"{x:1631,y:841,t:1527267166844};\\\", \\\"{x:1631,y:838,t:1527267166861};\\\", \\\"{x:1631,y:835,t:1527267166878};\\\", \\\"{x:1631,y:834,t:1527267166894};\\\", \\\"{x:1631,y:830,t:1527267166912};\\\", \\\"{x:1631,y:827,t:1527267166928};\\\", \\\"{x:1631,y:822,t:1527267166944};\\\", \\\"{x:1630,y:820,t:1527267166962};\\\", \\\"{x:1629,y:816,t:1527267166979};\\\", \\\"{x:1629,y:814,t:1527267166995};\\\", \\\"{x:1629,y:809,t:1527267167012};\\\", \\\"{x:1629,y:807,t:1527267167028};\\\", \\\"{x:1629,y:805,t:1527267167045};\\\", \\\"{x:1629,y:803,t:1527267167061};\\\", \\\"{x:1629,y:801,t:1527267167078};\\\", \\\"{x:1629,y:800,t:1527267167095};\\\", \\\"{x:1629,y:797,t:1527267167112};\\\", \\\"{x:1629,y:795,t:1527267167128};\\\", \\\"{x:1629,y:791,t:1527267167144};\\\", \\\"{x:1629,y:787,t:1527267167161};\\\", \\\"{x:1628,y:781,t:1527267167179};\\\", \\\"{x:1628,y:773,t:1527267167194};\\\", \\\"{x:1628,y:764,t:1527267167212};\\\", \\\"{x:1628,y:758,t:1527267167228};\\\", \\\"{x:1628,y:754,t:1527267167244};\\\", \\\"{x:1628,y:752,t:1527267167261};\\\", \\\"{x:1628,y:750,t:1527267167279};\\\", \\\"{x:1627,y:745,t:1527267167295};\\\", \\\"{x:1626,y:743,t:1527267167312};\\\", \\\"{x:1626,y:739,t:1527267167329};\\\", \\\"{x:1626,y:735,t:1527267167344};\\\", \\\"{x:1626,y:731,t:1527267167362};\\\", \\\"{x:1626,y:724,t:1527267167379};\\\", \\\"{x:1626,y:713,t:1527267167396};\\\", \\\"{x:1626,y:708,t:1527267167411};\\\", \\\"{x:1626,y:704,t:1527267167429};\\\", \\\"{x:1627,y:699,t:1527267167445};\\\", \\\"{x:1627,y:695,t:1527267167460};\\\", \\\"{x:1628,y:692,t:1527267167478};\\\", \\\"{x:1628,y:690,t:1527267167495};\\\", \\\"{x:1629,y:687,t:1527267167510};\\\", \\\"{x:1629,y:685,t:1527267167528};\\\", \\\"{x:1630,y:681,t:1527267167545};\\\", \\\"{x:1630,y:677,t:1527267167561};\\\", \\\"{x:1630,y:671,t:1527267167578};\\\", \\\"{x:1630,y:663,t:1527267167595};\\\", \\\"{x:1630,y:659,t:1527267167610};\\\", \\\"{x:1630,y:652,t:1527267167628};\\\", \\\"{x:1630,y:646,t:1527267167645};\\\", \\\"{x:1630,y:642,t:1527267167661};\\\", \\\"{x:1630,y:639,t:1527267167678};\\\", \\\"{x:1630,y:636,t:1527267167695};\\\", \\\"{x:1630,y:632,t:1527267167712};\\\", \\\"{x:1630,y:628,t:1527267167728};\\\", \\\"{x:1628,y:623,t:1527267167746};\\\", \\\"{x:1626,y:619,t:1527267167761};\\\", \\\"{x:1626,y:615,t:1527267167778};\\\", \\\"{x:1626,y:608,t:1527267167795};\\\", \\\"{x:1624,y:604,t:1527267167811};\\\", \\\"{x:1623,y:599,t:1527267167828};\\\", \\\"{x:1623,y:595,t:1527267167846};\\\", \\\"{x:1621,y:587,t:1527267167862};\\\", \\\"{x:1621,y:581,t:1527267167878};\\\", \\\"{x:1620,y:575,t:1527267167896};\\\", \\\"{x:1619,y:568,t:1527267167912};\\\", \\\"{x:1618,y:565,t:1527267167929};\\\", \\\"{x:1617,y:560,t:1527267167945};\\\", \\\"{x:1617,y:556,t:1527267167962};\\\", \\\"{x:1616,y:550,t:1527267167978};\\\", \\\"{x:1615,y:542,t:1527267167995};\\\", \\\"{x:1615,y:539,t:1527267168012};\\\", \\\"{x:1614,y:536,t:1527267168028};\\\", \\\"{x:1614,y:532,t:1527267168045};\\\", \\\"{x:1613,y:524,t:1527267168062};\\\", \\\"{x:1612,y:518,t:1527267168079};\\\", \\\"{x:1609,y:507,t:1527267168096};\\\", \\\"{x:1606,y:500,t:1527267168112};\\\", \\\"{x:1606,y:491,t:1527267168128};\\\", \\\"{x:1606,y:483,t:1527267168145};\\\", \\\"{x:1606,y:470,t:1527267168163};\\\", \\\"{x:1605,y:461,t:1527267168178};\\\", \\\"{x:1604,y:452,t:1527267168196};\\\", \\\"{x:1604,y:448,t:1527267168212};\\\", \\\"{x:1604,y:446,t:1527267168228};\\\", \\\"{x:1604,y:445,t:1527267168245};\\\", \\\"{x:1604,y:444,t:1527267168263};\\\", \\\"{x:1604,y:442,t:1527267168279};\\\", \\\"{x:1604,y:440,t:1527267168295};\\\", \\\"{x:1604,y:438,t:1527267168313};\\\", \\\"{x:1604,y:437,t:1527267168330};\\\", \\\"{x:1604,y:434,t:1527267168346};\\\", \\\"{x:1604,y:433,t:1527267168362};\\\", \\\"{x:1601,y:427,t:1527267168380};\\\", \\\"{x:1596,y:426,t:1527267168395};\\\", \\\"{x:1594,y:425,t:1527267168413};\\\", \\\"{x:1591,y:425,t:1527267168451};\\\", \\\"{x:1587,y:425,t:1527267168463};\\\", \\\"{x:1580,y:432,t:1527267168480};\\\", \\\"{x:1572,y:442,t:1527267168496};\\\", \\\"{x:1558,y:457,t:1527267168512};\\\", \\\"{x:1538,y:480,t:1527267168529};\\\", \\\"{x:1517,y:504,t:1527267168546};\\\", \\\"{x:1487,y:538,t:1527267168562};\\\", \\\"{x:1424,y:592,t:1527267168580};\\\", \\\"{x:1374,y:625,t:1527267168595};\\\", \\\"{x:1324,y:650,t:1527267168612};\\\", \\\"{x:1282,y:663,t:1527267168629};\\\", \\\"{x:1227,y:676,t:1527267168645};\\\", \\\"{x:1169,y:691,t:1527267168662};\\\", \\\"{x:1096,y:702,t:1527267168678};\\\", \\\"{x:1013,y:715,t:1527267168695};\\\", \\\"{x:920,y:720,t:1527267168712};\\\", \\\"{x:837,y:730,t:1527267168729};\\\", \\\"{x:763,y:744,t:1527267168746};\\\", \\\"{x:711,y:750,t:1527267168761};\\\", \\\"{x:641,y:750,t:1527267168779};\\\", \\\"{x:610,y:742,t:1527267168796};\\\", \\\"{x:588,y:736,t:1527267168812};\\\", \\\"{x:569,y:727,t:1527267168829};\\\", \\\"{x:552,y:719,t:1527267168847};\\\", \\\"{x:537,y:712,t:1527267168862};\\\", \\\"{x:527,y:706,t:1527267168879};\\\", \\\"{x:518,y:701,t:1527267168896};\\\", \\\"{x:511,y:697,t:1527267168912};\\\", \\\"{x:507,y:695,t:1527267168929};\\\", \\\"{x:504,y:688,t:1527267168946};\\\", \\\"{x:507,y:666,t:1527267168962};\\\", \\\"{x:518,y:649,t:1527267168979};\\\", \\\"{x:529,y:632,t:1527267168996};\\\", \\\"{x:536,y:619,t:1527267169013};\\\", \\\"{x:548,y:604,t:1527267169029};\\\", \\\"{x:555,y:589,t:1527267169046};\\\", \\\"{x:558,y:581,t:1527267169064};\\\", \\\"{x:560,y:576,t:1527267169079};\\\", \\\"{x:561,y:574,t:1527267169097};\\\", \\\"{x:561,y:573,t:1527267169123};\\\", \\\"{x:560,y:573,t:1527267169130};\\\", \\\"{x:559,y:572,t:1527267169146};\\\", \\\"{x:552,y:572,t:1527267169162};\\\", \\\"{x:539,y:572,t:1527267169180};\\\", \\\"{x:526,y:575,t:1527267169197};\\\", \\\"{x:511,y:578,t:1527267169213};\\\", \\\"{x:502,y:580,t:1527267169230};\\\", \\\"{x:496,y:580,t:1527267169246};\\\", \\\"{x:492,y:580,t:1527267169263};\\\", \\\"{x:487,y:579,t:1527267169280};\\\", \\\"{x:481,y:578,t:1527267169296};\\\", \\\"{x:477,y:575,t:1527267169313};\\\", \\\"{x:472,y:575,t:1527267169330};\\\", \\\"{x:464,y:572,t:1527267169347};\\\", \\\"{x:456,y:570,t:1527267169363};\\\", \\\"{x:452,y:568,t:1527267169380};\\\", \\\"{x:446,y:567,t:1527267169396};\\\", \\\"{x:440,y:566,t:1527267169413};\\\", \\\"{x:428,y:563,t:1527267169430};\\\", \\\"{x:417,y:563,t:1527267169446};\\\", \\\"{x:408,y:563,t:1527267169463};\\\", \\\"{x:401,y:564,t:1527267169480};\\\", \\\"{x:390,y:567,t:1527267169496};\\\", \\\"{x:383,y:568,t:1527267169513};\\\", \\\"{x:377,y:568,t:1527267169530};\\\", \\\"{x:371,y:568,t:1527267169546};\\\", \\\"{x:366,y:568,t:1527267169563};\\\", \\\"{x:365,y:568,t:1527267169580};\\\", \\\"{x:364,y:568,t:1527267169596};\\\", \\\"{x:363,y:568,t:1527267169716};\\\", \\\"{x:363,y:566,t:1527267169772};\\\", \\\"{x:364,y:566,t:1527267169803};\\\", \\\"{x:368,y:564,t:1527267169814};\\\", \\\"{x:372,y:562,t:1527267169830};\\\", \\\"{x:373,y:562,t:1527267169908};\\\", \\\"{x:374,y:562,t:1527267169932};\\\", \\\"{x:375,y:562,t:1527267170116};\\\", \\\"{x:378,y:562,t:1527267170131};\\\", \\\"{x:383,y:562,t:1527267170146};\\\", \\\"{x:388,y:562,t:1527267170162};\\\", \\\"{x:393,y:565,t:1527267170180};\\\", \\\"{x:402,y:567,t:1527267170197};\\\", \\\"{x:406,y:569,t:1527267170213};\\\", \\\"{x:409,y:570,t:1527267170230};\\\", \\\"{x:412,y:571,t:1527267170247};\\\", \\\"{x:423,y:576,t:1527267170264};\\\", \\\"{x:438,y:586,t:1527267170280};\\\", \\\"{x:444,y:591,t:1527267170297};\\\", \\\"{x:451,y:595,t:1527267170314};\\\", \\\"{x:456,y:599,t:1527267170330};\\\", \\\"{x:460,y:605,t:1527267170346};\\\", \\\"{x:461,y:608,t:1527267170363};\\\", \\\"{x:461,y:609,t:1527267170380};\\\", \\\"{x:461,y:610,t:1527267170402};\\\", \\\"{x:459,y:611,t:1527267170414};\\\", \\\"{x:446,y:611,t:1527267170430};\\\", \\\"{x:438,y:607,t:1527267170447};\\\", \\\"{x:433,y:606,t:1527267170464};\\\", \\\"{x:430,y:605,t:1527267170480};\\\", \\\"{x:428,y:603,t:1527267170497};\\\", \\\"{x:427,y:602,t:1527267170514};\\\", \\\"{x:421,y:597,t:1527267170531};\\\", \\\"{x:414,y:589,t:1527267170548};\\\", \\\"{x:412,y:587,t:1527267170564};\\\", \\\"{x:409,y:586,t:1527267170580};\\\", \\\"{x:407,y:584,t:1527267170597};\\\", \\\"{x:406,y:582,t:1527267170613};\\\", \\\"{x:403,y:578,t:1527267170630};\\\", \\\"{x:400,y:572,t:1527267170647};\\\", \\\"{x:397,y:568,t:1527267170664};\\\", \\\"{x:395,y:565,t:1527267170680};\\\", \\\"{x:392,y:564,t:1527267170697};\\\", \\\"{x:390,y:562,t:1527267170714};\\\", \\\"{x:385,y:560,t:1527267170730};\\\", \\\"{x:381,y:558,t:1527267170747};\\\", \\\"{x:380,y:558,t:1527267170764};\\\", \\\"{x:379,y:558,t:1527267170781};\\\", \\\"{x:379,y:557,t:1527267171043};\\\", \\\"{x:384,y:557,t:1527267171059};\\\", \\\"{x:393,y:564,t:1527267171067};\\\", \\\"{x:400,y:570,t:1527267171082};\\\", \\\"{x:413,y:582,t:1527267171099};\\\", \\\"{x:426,y:597,t:1527267171114};\\\", \\\"{x:441,y:623,t:1527267171131};\\\", \\\"{x:452,y:641,t:1527267171147};\\\", \\\"{x:459,y:656,t:1527267171164};\\\", \\\"{x:464,y:666,t:1527267171181};\\\", \\\"{x:470,y:681,t:1527267171197};\\\", \\\"{x:479,y:698,t:1527267171214};\\\", \\\"{x:486,y:712,t:1527267171231};\\\", \\\"{x:491,y:720,t:1527267171248};\\\", \\\"{x:494,y:722,t:1527267171264};\\\", \\\"{x:494,y:723,t:1527267171281};\\\", \\\"{x:495,y:724,t:1527267171297};\\\", \\\"{x:496,y:725,t:1527267171412};\\\", \\\"{x:497,y:725,t:1527267171420};\\\", \\\"{x:507,y:725,t:1527267172028};\\\", \\\"{x:523,y:725,t:1527267172035};\\\", \\\"{x:537,y:725,t:1527267172048};\\\", \\\"{x:581,y:709,t:1527267172065};\\\", \\\"{x:664,y:674,t:1527267172081};\\\", \\\"{x:699,y:653,t:1527267172098};\\\", \\\"{x:705,y:650,t:1527267172115};\\\" ] }, { \\\"rt\\\": 23184, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 165843, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -Z -Z -Z -Z -Z -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:704,y:652,t:1527267175198};\\\", \\\"{x:701,y:655,t:1527267175217};\\\", \\\"{x:697,y:659,t:1527267175234};\\\", \\\"{x:690,y:668,t:1527267175250};\\\", \\\"{x:686,y:672,t:1527267175267};\\\", \\\"{x:685,y:673,t:1527267175284};\\\", \\\"{x:685,y:675,t:1527267175301};\\\", \\\"{x:684,y:677,t:1527267175317};\\\", \\\"{x:682,y:679,t:1527267175334};\\\", \\\"{x:682,y:681,t:1527267175351};\\\", \\\"{x:681,y:685,t:1527267175367};\\\", \\\"{x:681,y:688,t:1527267175384};\\\", \\\"{x:681,y:693,t:1527267175402};\\\", \\\"{x:681,y:697,t:1527267175418};\\\", \\\"{x:681,y:702,t:1527267175435};\\\", \\\"{x:681,y:711,t:1527267175451};\\\", \\\"{x:681,y:715,t:1527267175468};\\\", \\\"{x:681,y:719,t:1527267175484};\\\", \\\"{x:681,y:721,t:1527267175502};\\\", \\\"{x:682,y:722,t:1527267175518};\\\", \\\"{x:683,y:725,t:1527267175534};\\\", \\\"{x:686,y:727,t:1527267175551};\\\", \\\"{x:688,y:728,t:1527267175568};\\\", \\\"{x:692,y:731,t:1527267175584};\\\", \\\"{x:700,y:733,t:1527267175601};\\\", \\\"{x:714,y:737,t:1527267175618};\\\", \\\"{x:732,y:739,t:1527267175634};\\\", \\\"{x:766,y:744,t:1527267175651};\\\", \\\"{x:794,y:745,t:1527267175669};\\\", \\\"{x:824,y:746,t:1527267175684};\\\", \\\"{x:858,y:746,t:1527267175701};\\\", \\\"{x:886,y:746,t:1527267175719};\\\", \\\"{x:907,y:746,t:1527267175734};\\\", \\\"{x:923,y:746,t:1527267175751};\\\", \\\"{x:935,y:746,t:1527267175769};\\\", \\\"{x:949,y:746,t:1527267175785};\\\", \\\"{x:962,y:746,t:1527267175802};\\\", \\\"{x:974,y:746,t:1527267175819};\\\", \\\"{x:983,y:746,t:1527267175835};\\\", \\\"{x:1000,y:746,t:1527267175852};\\\", \\\"{x:1015,y:746,t:1527267175869};\\\", \\\"{x:1034,y:746,t:1527267175885};\\\", \\\"{x:1055,y:746,t:1527267175902};\\\", \\\"{x:1070,y:746,t:1527267175919};\\\", \\\"{x:1085,y:746,t:1527267175936};\\\", \\\"{x:1101,y:746,t:1527267175952};\\\", \\\"{x:1118,y:746,t:1527267175969};\\\", \\\"{x:1128,y:746,t:1527267175986};\\\", \\\"{x:1135,y:746,t:1527267176002};\\\", \\\"{x:1138,y:746,t:1527267176019};\\\", \\\"{x:1139,y:746,t:1527267176036};\\\", \\\"{x:1140,y:746,t:1527267176052};\\\", \\\"{x:1141,y:746,t:1527267176069};\\\", \\\"{x:1143,y:746,t:1527267176086};\\\", \\\"{x:1145,y:746,t:1527267176102};\\\", \\\"{x:1150,y:746,t:1527267176119};\\\", \\\"{x:1155,y:746,t:1527267176136};\\\", \\\"{x:1160,y:746,t:1527267176152};\\\", \\\"{x:1165,y:748,t:1527267176169};\\\", \\\"{x:1167,y:748,t:1527267176186};\\\", \\\"{x:1170,y:749,t:1527267176202};\\\", \\\"{x:1171,y:749,t:1527267176244};\\\", \\\"{x:1172,y:749,t:1527267176252};\\\", \\\"{x:1174,y:751,t:1527267176269};\\\", \\\"{x:1176,y:752,t:1527267176286};\\\", \\\"{x:1177,y:754,t:1527267176301};\\\", \\\"{x:1179,y:756,t:1527267176320};\\\", \\\"{x:1184,y:762,t:1527267176336};\\\", \\\"{x:1187,y:766,t:1527267176352};\\\", \\\"{x:1193,y:770,t:1527267176369};\\\", \\\"{x:1197,y:775,t:1527267176386};\\\", \\\"{x:1202,y:779,t:1527267176402};\\\", \\\"{x:1208,y:783,t:1527267176419};\\\", \\\"{x:1214,y:790,t:1527267176436};\\\", \\\"{x:1216,y:794,t:1527267176453};\\\", \\\"{x:1219,y:797,t:1527267176469};\\\", \\\"{x:1222,y:799,t:1527267176486};\\\", \\\"{x:1229,y:805,t:1527267176503};\\\", \\\"{x:1235,y:810,t:1527267176519};\\\", \\\"{x:1239,y:813,t:1527267176536};\\\", \\\"{x:1241,y:815,t:1527267176553};\\\", \\\"{x:1242,y:818,t:1527267176569};\\\", \\\"{x:1243,y:819,t:1527267176586};\\\", \\\"{x:1245,y:823,t:1527267176603};\\\", \\\"{x:1250,y:827,t:1527267176619};\\\", \\\"{x:1258,y:834,t:1527267176636};\\\", \\\"{x:1262,y:837,t:1527267176653};\\\", \\\"{x:1268,y:841,t:1527267176669};\\\", \\\"{x:1273,y:844,t:1527267176686};\\\", \\\"{x:1277,y:847,t:1527267176703};\\\", \\\"{x:1281,y:848,t:1527267176719};\\\", \\\"{x:1283,y:849,t:1527267176736};\\\", \\\"{x:1288,y:852,t:1527267176753};\\\", \\\"{x:1294,y:856,t:1527267176770};\\\", \\\"{x:1297,y:859,t:1527267176787};\\\", \\\"{x:1298,y:860,t:1527267176853};\\\", \\\"{x:1298,y:862,t:1527267176876};\\\", \\\"{x:1297,y:862,t:1527267176886};\\\", \\\"{x:1292,y:862,t:1527267176903};\\\", \\\"{x:1281,y:862,t:1527267176920};\\\", \\\"{x:1269,y:862,t:1527267176936};\\\", \\\"{x:1255,y:858,t:1527267176953};\\\", \\\"{x:1243,y:855,t:1527267176970};\\\", \\\"{x:1237,y:853,t:1527267176986};\\\", \\\"{x:1233,y:852,t:1527267177003};\\\", \\\"{x:1230,y:851,t:1527267177019};\\\", \\\"{x:1228,y:850,t:1527267177036};\\\", \\\"{x:1225,y:849,t:1527267177053};\\\", \\\"{x:1223,y:848,t:1527267177070};\\\", \\\"{x:1222,y:848,t:1527267177100};\\\", \\\"{x:1222,y:847,t:1527267177116};\\\", \\\"{x:1222,y:846,t:1527267177124};\\\", \\\"{x:1222,y:843,t:1527267177137};\\\", \\\"{x:1220,y:839,t:1527267177153};\\\", \\\"{x:1219,y:836,t:1527267177170};\\\", \\\"{x:1219,y:834,t:1527267177186};\\\", \\\"{x:1219,y:832,t:1527267177206};\\\", \\\"{x:1218,y:831,t:1527267177220};\\\", \\\"{x:1217,y:831,t:1527267177236};\\\", \\\"{x:1216,y:830,t:1527267177253};\\\", \\\"{x:1214,y:830,t:1527267177269};\\\", \\\"{x:1212,y:829,t:1527267177286};\\\", \\\"{x:1211,y:829,t:1527267177303};\\\", \\\"{x:1210,y:829,t:1527267179932};\\\", \\\"{x:1211,y:829,t:1527267179988};\\\", \\\"{x:1212,y:829,t:1527267180005};\\\", \\\"{x:1213,y:829,t:1527267182243};\\\", \\\"{x:1214,y:829,t:1527267182256};\\\", \\\"{x:1216,y:829,t:1527267182273};\\\", \\\"{x:1217,y:829,t:1527267182290};\\\", \\\"{x:1221,y:828,t:1527267182309};\\\", \\\"{x:1222,y:828,t:1527267182325};\\\", \\\"{x:1223,y:828,t:1527267182340};\\\", \\\"{x:1224,y:828,t:1527267182357};\\\", \\\"{x:1225,y:828,t:1527267182395};\\\", \\\"{x:1226,y:828,t:1527267182428};\\\", \\\"{x:1228,y:827,t:1527267182442};\\\", \\\"{x:1229,y:827,t:1527267182458};\\\", \\\"{x:1230,y:827,t:1527267182473};\\\", \\\"{x:1231,y:827,t:1527267182491};\\\", \\\"{x:1232,y:827,t:1527267182523};\\\", \\\"{x:1233,y:827,t:1527267182531};\\\", \\\"{x:1234,y:826,t:1527267182540};\\\", \\\"{x:1235,y:826,t:1527267182557};\\\", \\\"{x:1236,y:826,t:1527267182578};\\\", \\\"{x:1237,y:826,t:1527267182595};\\\", \\\"{x:1238,y:826,t:1527267182619};\\\", \\\"{x:1238,y:825,t:1527267182667};\\\", \\\"{x:1239,y:825,t:1527267182699};\\\", \\\"{x:1240,y:825,t:1527267182716};\\\", \\\"{x:1241,y:825,t:1527267182731};\\\", \\\"{x:1242,y:825,t:1527267182796};\\\", \\\"{x:1243,y:825,t:1527267182807};\\\", \\\"{x:1244,y:825,t:1527267182828};\\\", \\\"{x:1245,y:825,t:1527267182851};\\\", \\\"{x:1246,y:825,t:1527267182900};\\\", \\\"{x:1247,y:825,t:1527267182939};\\\", \\\"{x:1248,y:825,t:1527267182947};\\\", \\\"{x:1249,y:824,t:1527267182972};\\\", \\\"{x:1250,y:824,t:1527267182980};\\\", \\\"{x:1251,y:824,t:1527267183012};\\\", \\\"{x:1252,y:824,t:1527267183027};\\\", \\\"{x:1253,y:824,t:1527267183052};\\\", \\\"{x:1254,y:824,t:1527267183075};\\\", \\\"{x:1255,y:824,t:1527267183124};\\\", \\\"{x:1256,y:823,t:1527267183148};\\\", \\\"{x:1258,y:823,t:1527267183188};\\\", \\\"{x:1259,y:822,t:1527267183195};\\\", \\\"{x:1261,y:822,t:1527267183211};\\\", \\\"{x:1262,y:822,t:1527267183224};\\\", \\\"{x:1266,y:822,t:1527267183241};\\\", \\\"{x:1268,y:822,t:1527267183258};\\\", \\\"{x:1269,y:822,t:1527267183274};\\\", \\\"{x:1272,y:821,t:1527267183292};\\\", \\\"{x:1275,y:821,t:1527267183308};\\\", \\\"{x:1280,y:821,t:1527267183325};\\\", \\\"{x:1292,y:819,t:1527267183342};\\\", \\\"{x:1306,y:819,t:1527267183359};\\\", \\\"{x:1314,y:819,t:1527267183375};\\\", \\\"{x:1318,y:819,t:1527267183391};\\\", \\\"{x:1319,y:819,t:1527267183409};\\\", \\\"{x:1320,y:819,t:1527267183425};\\\", \\\"{x:1323,y:820,t:1527267183441};\\\", \\\"{x:1324,y:820,t:1527267183458};\\\", \\\"{x:1325,y:820,t:1527267183483};\\\", \\\"{x:1328,y:822,t:1527267183499};\\\", \\\"{x:1334,y:823,t:1527267183508};\\\", \\\"{x:1350,y:830,t:1527267183525};\\\", \\\"{x:1365,y:839,t:1527267183541};\\\", \\\"{x:1376,y:846,t:1527267183558};\\\", \\\"{x:1385,y:855,t:1527267183576};\\\", \\\"{x:1390,y:861,t:1527267183592};\\\", \\\"{x:1393,y:867,t:1527267183608};\\\", \\\"{x:1394,y:870,t:1527267183625};\\\", \\\"{x:1394,y:873,t:1527267183641};\\\", \\\"{x:1394,y:877,t:1527267183657};\\\", \\\"{x:1394,y:886,t:1527267183675};\\\", \\\"{x:1393,y:891,t:1527267183691};\\\", \\\"{x:1393,y:893,t:1527267183708};\\\", \\\"{x:1392,y:895,t:1527267183724};\\\", \\\"{x:1391,y:895,t:1527267183740};\\\", \\\"{x:1390,y:896,t:1527267183757};\\\", \\\"{x:1387,y:897,t:1527267183775};\\\", \\\"{x:1383,y:899,t:1527267183792};\\\", \\\"{x:1381,y:899,t:1527267183808};\\\", \\\"{x:1377,y:901,t:1527267183825};\\\", \\\"{x:1374,y:901,t:1527267183841};\\\", \\\"{x:1373,y:901,t:1527267183858};\\\", \\\"{x:1366,y:901,t:1527267183875};\\\", \\\"{x:1362,y:901,t:1527267183892};\\\", \\\"{x:1360,y:900,t:1527267183980};\\\", \\\"{x:1357,y:899,t:1527267183992};\\\", \\\"{x:1353,y:898,t:1527267184009};\\\", \\\"{x:1351,y:897,t:1527267184025};\\\", \\\"{x:1350,y:897,t:1527267184042};\\\", \\\"{x:1348,y:897,t:1527267184058};\\\", \\\"{x:1347,y:896,t:1527267184492};\\\", \\\"{x:1347,y:895,t:1527267184509};\\\", \\\"{x:1347,y:892,t:1527267184525};\\\", \\\"{x:1347,y:891,t:1527267184543};\\\", \\\"{x:1347,y:889,t:1527267184564};\\\", \\\"{x:1347,y:887,t:1527267184595};\\\", \\\"{x:1347,y:885,t:1527267184609};\\\", \\\"{x:1347,y:884,t:1527267184627};\\\", \\\"{x:1347,y:883,t:1527267184642};\\\", \\\"{x:1347,y:882,t:1527267184658};\\\", \\\"{x:1347,y:881,t:1527267184675};\\\", \\\"{x:1347,y:880,t:1527267184794};\\\", \\\"{x:1347,y:879,t:1527267184809};\\\", \\\"{x:1347,y:878,t:1527267184834};\\\", \\\"{x:1347,y:877,t:1527267184843};\\\", \\\"{x:1347,y:875,t:1527267184859};\\\", \\\"{x:1347,y:872,t:1527267184875};\\\", \\\"{x:1347,y:870,t:1527267184892};\\\", \\\"{x:1348,y:867,t:1527267184909};\\\", \\\"{x:1348,y:866,t:1527267184926};\\\", \\\"{x:1348,y:863,t:1527267184941};\\\", \\\"{x:1348,y:862,t:1527267184959};\\\", \\\"{x:1348,y:860,t:1527267184976};\\\", \\\"{x:1349,y:859,t:1527267184992};\\\", \\\"{x:1349,y:858,t:1527267185009};\\\", \\\"{x:1350,y:856,t:1527267185026};\\\", \\\"{x:1350,y:855,t:1527267185042};\\\", \\\"{x:1350,y:851,t:1527267185058};\\\", \\\"{x:1350,y:850,t:1527267185091};\\\", \\\"{x:1350,y:848,t:1527267185109};\\\", \\\"{x:1349,y:845,t:1527267185127};\\\", \\\"{x:1349,y:843,t:1527267185143};\\\", \\\"{x:1349,y:841,t:1527267185159};\\\", \\\"{x:1348,y:840,t:1527267185176};\\\", \\\"{x:1348,y:838,t:1527267185193};\\\", \\\"{x:1348,y:836,t:1527267185209};\\\", \\\"{x:1348,y:832,t:1527267185226};\\\", \\\"{x:1346,y:829,t:1527267185243};\\\", \\\"{x:1346,y:828,t:1527267185259};\\\", \\\"{x:1345,y:826,t:1527267185277};\\\", \\\"{x:1345,y:825,t:1527267185294};\\\", \\\"{x:1345,y:824,t:1527267185309};\\\", \\\"{x:1345,y:822,t:1527267185327};\\\", \\\"{x:1344,y:819,t:1527267185344};\\\", \\\"{x:1344,y:818,t:1527267185359};\\\", \\\"{x:1344,y:816,t:1527267185395};\\\", \\\"{x:1344,y:815,t:1527267185411};\\\", \\\"{x:1344,y:814,t:1527267185426};\\\", \\\"{x:1344,y:812,t:1527267185442};\\\", \\\"{x:1344,y:811,t:1527267185458};\\\", \\\"{x:1344,y:810,t:1527267185476};\\\", \\\"{x:1344,y:809,t:1527267185492};\\\", \\\"{x:1344,y:806,t:1527267185509};\\\", \\\"{x:1344,y:804,t:1527267185525};\\\", \\\"{x:1344,y:800,t:1527267185543};\\\", \\\"{x:1344,y:799,t:1527267185560};\\\", \\\"{x:1344,y:797,t:1527267185575};\\\", \\\"{x:1344,y:795,t:1527267185595};\\\", \\\"{x:1344,y:794,t:1527267185609};\\\", \\\"{x:1343,y:792,t:1527267185625};\\\", \\\"{x:1343,y:790,t:1527267185643};\\\", \\\"{x:1343,y:789,t:1527267185660};\\\", \\\"{x:1343,y:788,t:1527267185676};\\\", \\\"{x:1343,y:787,t:1527267185693};\\\", \\\"{x:1343,y:785,t:1527267185710};\\\", \\\"{x:1343,y:784,t:1527267185725};\\\", \\\"{x:1343,y:780,t:1527267185743};\\\", \\\"{x:1343,y:779,t:1527267185760};\\\", \\\"{x:1343,y:777,t:1527267185776};\\\", \\\"{x:1343,y:776,t:1527267185793};\\\", \\\"{x:1343,y:774,t:1527267185809};\\\", \\\"{x:1343,y:773,t:1527267185825};\\\", \\\"{x:1343,y:770,t:1527267185843};\\\", \\\"{x:1343,y:769,t:1527267185860};\\\", \\\"{x:1343,y:767,t:1527267185875};\\\", \\\"{x:1343,y:765,t:1527267185893};\\\", \\\"{x:1343,y:764,t:1527267185909};\\\", \\\"{x:1343,y:763,t:1527267185926};\\\", \\\"{x:1343,y:762,t:1527267185943};\\\", \\\"{x:1343,y:760,t:1527267185960};\\\", \\\"{x:1343,y:759,t:1527267185979};\\\", \\\"{x:1343,y:758,t:1527267185994};\\\", \\\"{x:1343,y:757,t:1527267186011};\\\", \\\"{x:1343,y:756,t:1527267186059};\\\", \\\"{x:1343,y:755,t:1527267186067};\\\", \\\"{x:1343,y:754,t:1527267186077};\\\", \\\"{x:1343,y:753,t:1527267186099};\\\", \\\"{x:1343,y:752,t:1527267186110};\\\", \\\"{x:1343,y:751,t:1527267186126};\\\", \\\"{x:1343,y:750,t:1527267186171};\\\", \\\"{x:1343,y:749,t:1527267186194};\\\", \\\"{x:1343,y:748,t:1527267186227};\\\", \\\"{x:1343,y:747,t:1527267186354};\\\", \\\"{x:1343,y:746,t:1527267186379};\\\", \\\"{x:1343,y:745,t:1527267186410};\\\", \\\"{x:1343,y:744,t:1527267186434};\\\", \\\"{x:1343,y:743,t:1527267186810};\\\", \\\"{x:1342,y:746,t:1527267186907};\\\", \\\"{x:1342,y:747,t:1527267186914};\\\", \\\"{x:1341,y:749,t:1527267186926};\\\", \\\"{x:1340,y:752,t:1527267186944};\\\", \\\"{x:1338,y:756,t:1527267186961};\\\", \\\"{x:1337,y:757,t:1527267186978};\\\", \\\"{x:1337,y:758,t:1527267186994};\\\", \\\"{x:1336,y:761,t:1527267187011};\\\", \\\"{x:1336,y:763,t:1527267187027};\\\", \\\"{x:1335,y:766,t:1527267187044};\\\", \\\"{x:1335,y:769,t:1527267187061};\\\", \\\"{x:1335,y:770,t:1527267187077};\\\", \\\"{x:1335,y:772,t:1527267187094};\\\", \\\"{x:1335,y:774,t:1527267187111};\\\", \\\"{x:1335,y:779,t:1527267187126};\\\", \\\"{x:1336,y:784,t:1527267187144};\\\", \\\"{x:1337,y:790,t:1527267187161};\\\", \\\"{x:1341,y:799,t:1527267187176};\\\", \\\"{x:1342,y:808,t:1527267187194};\\\", \\\"{x:1342,y:822,t:1527267187210};\\\", \\\"{x:1342,y:831,t:1527267187227};\\\", \\\"{x:1344,y:844,t:1527267187244};\\\", \\\"{x:1345,y:848,t:1527267187261};\\\", \\\"{x:1345,y:852,t:1527267187277};\\\", \\\"{x:1345,y:853,t:1527267187299};\\\", \\\"{x:1345,y:855,t:1527267187323};\\\", \\\"{x:1345,y:856,t:1527267187340};\\\", \\\"{x:1345,y:858,t:1527267187355};\\\", \\\"{x:1345,y:859,t:1527267187363};\\\", \\\"{x:1345,y:862,t:1527267187378};\\\", \\\"{x:1345,y:866,t:1527267187394};\\\", \\\"{x:1346,y:870,t:1527267187412};\\\", \\\"{x:1346,y:872,t:1527267187427};\\\", \\\"{x:1346,y:873,t:1527267187450};\\\", \\\"{x:1346,y:875,t:1527267187460};\\\", \\\"{x:1345,y:878,t:1527267187478};\\\", \\\"{x:1345,y:883,t:1527267187493};\\\", \\\"{x:1345,y:887,t:1527267187511};\\\", \\\"{x:1345,y:889,t:1527267187528};\\\", \\\"{x:1345,y:890,t:1527267187543};\\\", \\\"{x:1345,y:891,t:1527267187578};\\\", \\\"{x:1345,y:893,t:1527267187594};\\\", \\\"{x:1345,y:894,t:1527267187659};\\\", \\\"{x:1345,y:896,t:1527267187667};\\\", \\\"{x:1344,y:897,t:1527267187678};\\\", \\\"{x:1343,y:899,t:1527267187694};\\\", \\\"{x:1343,y:895,t:1527267187820};\\\", \\\"{x:1343,y:889,t:1527267187829};\\\", \\\"{x:1343,y:882,t:1527267187845};\\\", \\\"{x:1343,y:875,t:1527267187862};\\\", \\\"{x:1343,y:868,t:1527267187878};\\\", \\\"{x:1343,y:864,t:1527267187895};\\\", \\\"{x:1343,y:861,t:1527267187912};\\\", \\\"{x:1343,y:859,t:1527267187929};\\\", \\\"{x:1343,y:854,t:1527267187945};\\\", \\\"{x:1343,y:848,t:1527267187961};\\\", \\\"{x:1343,y:845,t:1527267187979};\\\", \\\"{x:1343,y:840,t:1527267187996};\\\", \\\"{x:1343,y:839,t:1527267188011};\\\", \\\"{x:1343,y:838,t:1527267188029};\\\", \\\"{x:1343,y:836,t:1527267188045};\\\", \\\"{x:1343,y:835,t:1527267188061};\\\", \\\"{x:1343,y:833,t:1527267188078};\\\", \\\"{x:1344,y:832,t:1527267188095};\\\", \\\"{x:1344,y:830,t:1527267188111};\\\", \\\"{x:1344,y:829,t:1527267188128};\\\", \\\"{x:1344,y:827,t:1527267188145};\\\", \\\"{x:1344,y:825,t:1527267188161};\\\", \\\"{x:1344,y:823,t:1527267188179};\\\", \\\"{x:1344,y:820,t:1527267188195};\\\", \\\"{x:1344,y:818,t:1527267188211};\\\", \\\"{x:1344,y:817,t:1527267188228};\\\", \\\"{x:1344,y:815,t:1527267188245};\\\", \\\"{x:1344,y:812,t:1527267188263};\\\", \\\"{x:1343,y:811,t:1527267188279};\\\", \\\"{x:1343,y:810,t:1527267188295};\\\", \\\"{x:1342,y:807,t:1527267188312};\\\", \\\"{x:1341,y:807,t:1527267188332};\\\", \\\"{x:1341,y:805,t:1527267188345};\\\", \\\"{x:1340,y:804,t:1527267188362};\\\", \\\"{x:1339,y:801,t:1527267188378};\\\", \\\"{x:1337,y:797,t:1527267188395};\\\", \\\"{x:1337,y:794,t:1527267188412};\\\", \\\"{x:1337,y:792,t:1527267188428};\\\", \\\"{x:1335,y:790,t:1527267188446};\\\", \\\"{x:1335,y:789,t:1527267188468};\\\", \\\"{x:1335,y:788,t:1527267188478};\\\", \\\"{x:1335,y:786,t:1527267188495};\\\", \\\"{x:1335,y:784,t:1527267188513};\\\", \\\"{x:1334,y:780,t:1527267188528};\\\", \\\"{x:1334,y:778,t:1527267188545};\\\", \\\"{x:1334,y:776,t:1527267188562};\\\", \\\"{x:1333,y:775,t:1527267188578};\\\", \\\"{x:1333,y:772,t:1527267188595};\\\", \\\"{x:1333,y:771,t:1527267188613};\\\", \\\"{x:1332,y:768,t:1527267188628};\\\", \\\"{x:1332,y:766,t:1527267188645};\\\", \\\"{x:1332,y:764,t:1527267188661};\\\", \\\"{x:1332,y:761,t:1527267188678};\\\", \\\"{x:1332,y:757,t:1527267188694};\\\", \\\"{x:1331,y:755,t:1527267188712};\\\", \\\"{x:1331,y:752,t:1527267188728};\\\", \\\"{x:1331,y:749,t:1527267188745};\\\", \\\"{x:1331,y:747,t:1527267188762};\\\", \\\"{x:1331,y:741,t:1527267188778};\\\", \\\"{x:1331,y:740,t:1527267188795};\\\", \\\"{x:1331,y:737,t:1527267188812};\\\", \\\"{x:1331,y:735,t:1527267188834};\\\", \\\"{x:1331,y:734,t:1527267188851};\\\", \\\"{x:1331,y:733,t:1527267188867};\\\", \\\"{x:1331,y:732,t:1527267188879};\\\", \\\"{x:1331,y:731,t:1527267188895};\\\", \\\"{x:1331,y:729,t:1527267188913};\\\", \\\"{x:1331,y:726,t:1527267188929};\\\", \\\"{x:1330,y:725,t:1527267188945};\\\", \\\"{x:1330,y:724,t:1527267188972};\\\", \\\"{x:1330,y:723,t:1527267188980};\\\", \\\"{x:1330,y:722,t:1527267188995};\\\", \\\"{x:1330,y:721,t:1527267189020};\\\", \\\"{x:1330,y:720,t:1527267189035};\\\", \\\"{x:1329,y:719,t:1527267189051};\\\", \\\"{x:1328,y:719,t:1527267189062};\\\", \\\"{x:1328,y:718,t:1527267189092};\\\", \\\"{x:1328,y:717,t:1527267189140};\\\", \\\"{x:1328,y:716,t:1527267189163};\\\", \\\"{x:1328,y:715,t:1527267189252};\\\", \\\"{x:1328,y:714,t:1527267189276};\\\", \\\"{x:1328,y:713,t:1527267189292};\\\", \\\"{x:1328,y:712,t:1527267189356};\\\", \\\"{x:1328,y:711,t:1527267189388};\\\", \\\"{x:1328,y:710,t:1527267189403};\\\", \\\"{x:1328,y:709,t:1527267189428};\\\", \\\"{x:1328,y:708,t:1527267189443};\\\", \\\"{x:1328,y:707,t:1527267189451};\\\", \\\"{x:1328,y:706,t:1527267189475};\\\", \\\"{x:1328,y:705,t:1527267189483};\\\", \\\"{x:1328,y:704,t:1527267189496};\\\", \\\"{x:1328,y:703,t:1527267189513};\\\", \\\"{x:1328,y:701,t:1527267189530};\\\", \\\"{x:1328,y:700,t:1527267189547};\\\", \\\"{x:1328,y:698,t:1527267189563};\\\", \\\"{x:1328,y:695,t:1527267189579};\\\", \\\"{x:1329,y:693,t:1527267189596};\\\", \\\"{x:1329,y:692,t:1527267189613};\\\", \\\"{x:1329,y:689,t:1527267189629};\\\", \\\"{x:1329,y:687,t:1527267189646};\\\", \\\"{x:1329,y:684,t:1527267189663};\\\", \\\"{x:1331,y:680,t:1527267189679};\\\", \\\"{x:1331,y:678,t:1527267189696};\\\", \\\"{x:1331,y:675,t:1527267189712};\\\", \\\"{x:1331,y:672,t:1527267189729};\\\", \\\"{x:1332,y:668,t:1527267189746};\\\", \\\"{x:1332,y:664,t:1527267189762};\\\", \\\"{x:1333,y:661,t:1527267189779};\\\", \\\"{x:1333,y:658,t:1527267189796};\\\", \\\"{x:1333,y:657,t:1527267189814};\\\", \\\"{x:1335,y:653,t:1527267189829};\\\", \\\"{x:1335,y:650,t:1527267189846};\\\", \\\"{x:1336,y:646,t:1527267189863};\\\", \\\"{x:1336,y:644,t:1527267189879};\\\", \\\"{x:1336,y:640,t:1527267189896};\\\", \\\"{x:1336,y:638,t:1527267189914};\\\", \\\"{x:1336,y:634,t:1527267189929};\\\", \\\"{x:1336,y:631,t:1527267189946};\\\", \\\"{x:1338,y:626,t:1527267189963};\\\", \\\"{x:1339,y:623,t:1527267189980};\\\", \\\"{x:1339,y:621,t:1527267189997};\\\", \\\"{x:1339,y:620,t:1527267190019};\\\", \\\"{x:1339,y:618,t:1527267190035};\\\", \\\"{x:1339,y:617,t:1527267190051};\\\", \\\"{x:1339,y:616,t:1527267190067};\\\", \\\"{x:1339,y:615,t:1527267190080};\\\", \\\"{x:1340,y:614,t:1527267190096};\\\", \\\"{x:1340,y:611,t:1527267190114};\\\", \\\"{x:1340,y:609,t:1527267190131};\\\", \\\"{x:1340,y:607,t:1527267190146};\\\", \\\"{x:1340,y:605,t:1527267190164};\\\", \\\"{x:1340,y:602,t:1527267190181};\\\", \\\"{x:1340,y:600,t:1527267190197};\\\", \\\"{x:1341,y:598,t:1527267190213};\\\", \\\"{x:1341,y:595,t:1527267190231};\\\", \\\"{x:1341,y:593,t:1527267190246};\\\", \\\"{x:1341,y:590,t:1527267190263};\\\", \\\"{x:1341,y:586,t:1527267190281};\\\", \\\"{x:1341,y:585,t:1527267190297};\\\", \\\"{x:1341,y:582,t:1527267190313};\\\", \\\"{x:1341,y:580,t:1527267190330};\\\", \\\"{x:1342,y:579,t:1527267190347};\\\", \\\"{x:1342,y:576,t:1527267190363};\\\", \\\"{x:1342,y:573,t:1527267190381};\\\", \\\"{x:1342,y:572,t:1527267190397};\\\", \\\"{x:1342,y:568,t:1527267190413};\\\", \\\"{x:1342,y:565,t:1527267190431};\\\", \\\"{x:1342,y:562,t:1527267190446};\\\", \\\"{x:1342,y:559,t:1527267190464};\\\", \\\"{x:1342,y:556,t:1527267190481};\\\", \\\"{x:1342,y:552,t:1527267190498};\\\", \\\"{x:1342,y:551,t:1527267190514};\\\", \\\"{x:1342,y:549,t:1527267190531};\\\", \\\"{x:1342,y:545,t:1527267190548};\\\", \\\"{x:1341,y:543,t:1527267190563};\\\", \\\"{x:1340,y:542,t:1527267190581};\\\", \\\"{x:1340,y:540,t:1527267190598};\\\", \\\"{x:1339,y:539,t:1527267190613};\\\", \\\"{x:1336,y:535,t:1527267190630};\\\", \\\"{x:1335,y:534,t:1527267190647};\\\", \\\"{x:1335,y:532,t:1527267190664};\\\", \\\"{x:1334,y:529,t:1527267190680};\\\", \\\"{x:1334,y:527,t:1527267190698};\\\", \\\"{x:1332,y:524,t:1527267190713};\\\", \\\"{x:1332,y:522,t:1527267190730};\\\", \\\"{x:1331,y:519,t:1527267190747};\\\", \\\"{x:1330,y:517,t:1527267190763};\\\", \\\"{x:1328,y:514,t:1527267190781};\\\", \\\"{x:1328,y:513,t:1527267190797};\\\", \\\"{x:1326,y:510,t:1527267190813};\\\", \\\"{x:1326,y:509,t:1527267190830};\\\", \\\"{x:1326,y:507,t:1527267190847};\\\", \\\"{x:1326,y:506,t:1527267190867};\\\", \\\"{x:1325,y:506,t:1527267190880};\\\", \\\"{x:1325,y:505,t:1527267190898};\\\", \\\"{x:1324,y:504,t:1527267190914};\\\", \\\"{x:1323,y:503,t:1527267190930};\\\", \\\"{x:1322,y:501,t:1527267190948};\\\", \\\"{x:1322,y:500,t:1527267191044};\\\", \\\"{x:1322,y:499,t:1527267191051};\\\", \\\"{x:1322,y:498,t:1527267191065};\\\", \\\"{x:1322,y:497,t:1527267191081};\\\", \\\"{x:1322,y:496,t:1527267191098};\\\", \\\"{x:1318,y:499,t:1527267193324};\\\", \\\"{x:1314,y:508,t:1527267193333};\\\", \\\"{x:1299,y:537,t:1527267193349};\\\", \\\"{x:1263,y:599,t:1527267193366};\\\", \\\"{x:1213,y:692,t:1527267193382};\\\", \\\"{x:1151,y:789,t:1527267193400};\\\", \\\"{x:1073,y:882,t:1527267193417};\\\", \\\"{x:987,y:957,t:1527267193432};\\\", \\\"{x:899,y:1014,t:1527267193449};\\\", \\\"{x:810,y:1043,t:1527267193465};\\\", \\\"{x:728,y:1049,t:1527267193482};\\\", \\\"{x:643,y:1041,t:1527267193499};\\\", \\\"{x:614,y:1018,t:1527267193516};\\\", \\\"{x:594,y:989,t:1527267193532};\\\", \\\"{x:585,y:957,t:1527267193549};\\\", \\\"{x:582,y:931,t:1527267193565};\\\", \\\"{x:578,y:907,t:1527267193583};\\\", \\\"{x:576,y:890,t:1527267193600};\\\", \\\"{x:574,y:875,t:1527267193617};\\\", \\\"{x:574,y:860,t:1527267193632};\\\", \\\"{x:574,y:840,t:1527267193649};\\\", \\\"{x:577,y:818,t:1527267193666};\\\", \\\"{x:585,y:795,t:1527267193682};\\\", \\\"{x:602,y:755,t:1527267193699};\\\", \\\"{x:609,y:730,t:1527267193716};\\\", \\\"{x:614,y:702,t:1527267193732};\\\", \\\"{x:615,y:686,t:1527267193749};\\\", \\\"{x:615,y:677,t:1527267193766};\\\", \\\"{x:613,y:672,t:1527267193782};\\\", \\\"{x:607,y:670,t:1527267193799};\\\", \\\"{x:604,y:668,t:1527267193816};\\\", \\\"{x:603,y:668,t:1527267193834};\\\", \\\"{x:602,y:668,t:1527267193849};\\\", \\\"{x:597,y:668,t:1527267193867};\\\", \\\"{x:587,y:668,t:1527267193883};\\\", \\\"{x:570,y:668,t:1527267193899};\\\", \\\"{x:554,y:668,t:1527267193916};\\\", \\\"{x:531,y:668,t:1527267193932};\\\", \\\"{x:509,y:668,t:1527267193949};\\\", \\\"{x:498,y:668,t:1527267193967};\\\", \\\"{x:493,y:668,t:1527267193983};\\\", \\\"{x:489,y:665,t:1527267193999};\\\", \\\"{x:483,y:660,t:1527267194018};\\\", \\\"{x:478,y:657,t:1527267194033};\\\", \\\"{x:472,y:653,t:1527267194049};\\\", \\\"{x:464,y:648,t:1527267194066};\\\", \\\"{x:446,y:633,t:1527267194082};\\\", \\\"{x:426,y:627,t:1527267194099};\\\", \\\"{x:404,y:622,t:1527267194116};\\\", \\\"{x:380,y:619,t:1527267194133};\\\", \\\"{x:361,y:618,t:1527267194149};\\\", \\\"{x:347,y:615,t:1527267194166};\\\", \\\"{x:329,y:608,t:1527267194183};\\\", \\\"{x:315,y:606,t:1527267194199};\\\", \\\"{x:307,y:603,t:1527267194216};\\\", \\\"{x:300,y:603,t:1527267194233};\\\", \\\"{x:294,y:603,t:1527267194250};\\\", \\\"{x:288,y:603,t:1527267194266};\\\", \\\"{x:265,y:605,t:1527267194284};\\\", \\\"{x:237,y:612,t:1527267194300};\\\", \\\"{x:215,y:615,t:1527267194317};\\\", \\\"{x:203,y:616,t:1527267194333};\\\", \\\"{x:198,y:617,t:1527267194350};\\\", \\\"{x:197,y:617,t:1527267194366};\\\", \\\"{x:196,y:617,t:1527267194383};\\\", \\\"{x:195,y:617,t:1527267194400};\\\", \\\"{x:194,y:617,t:1527267194419};\\\", \\\"{x:193,y:617,t:1527267194467};\\\", \\\"{x:192,y:617,t:1527267194556};\\\", \\\"{x:192,y:616,t:1527267194568};\\\", \\\"{x:191,y:616,t:1527267194584};\\\", \\\"{x:190,y:615,t:1527267194636};\\\", \\\"{x:191,y:614,t:1527267194650};\\\", \\\"{x:194,y:612,t:1527267194667};\\\", \\\"{x:201,y:607,t:1527267194685};\\\", \\\"{x:209,y:602,t:1527267194700};\\\", \\\"{x:213,y:597,t:1527267194716};\\\", \\\"{x:216,y:595,t:1527267194733};\\\", \\\"{x:217,y:594,t:1527267194820};\\\", \\\"{x:218,y:594,t:1527267194834};\\\", \\\"{x:220,y:594,t:1527267194850};\\\", \\\"{x:221,y:594,t:1527267194866};\\\", \\\"{x:218,y:593,t:1527267194987};\\\", \\\"{x:214,y:592,t:1527267195000};\\\", \\\"{x:204,y:587,t:1527267195017};\\\", \\\"{x:194,y:581,t:1527267195034};\\\", \\\"{x:183,y:573,t:1527267195052};\\\", \\\"{x:172,y:566,t:1527267195068};\\\", \\\"{x:166,y:562,t:1527267195084};\\\", \\\"{x:160,y:559,t:1527267195100};\\\", \\\"{x:159,y:558,t:1527267195117};\\\", \\\"{x:157,y:557,t:1527267195138};\\\", \\\"{x:158,y:556,t:1527267195506};\\\", \\\"{x:161,y:557,t:1527267195517};\\\", \\\"{x:182,y:570,t:1527267195534};\\\", \\\"{x:220,y:592,t:1527267195551};\\\", \\\"{x:266,y:619,t:1527267195567};\\\", \\\"{x:325,y:647,t:1527267195584};\\\", \\\"{x:360,y:660,t:1527267195602};\\\", \\\"{x:376,y:664,t:1527267195617};\\\", \\\"{x:382,y:667,t:1527267195634};\\\", \\\"{x:398,y:680,t:1527267195650};\\\", \\\"{x:413,y:687,t:1527267195667};\\\", \\\"{x:431,y:697,t:1527267195684};\\\", \\\"{x:440,y:701,t:1527267195700};\\\", \\\"{x:447,y:704,t:1527267195718};\\\", \\\"{x:450,y:705,t:1527267195734};\\\", \\\"{x:453,y:706,t:1527267195751};\\\", \\\"{x:457,y:708,t:1527267195767};\\\", \\\"{x:460,y:708,t:1527267195784};\\\", \\\"{x:468,y:710,t:1527267195801};\\\", \\\"{x:480,y:714,t:1527267195818};\\\", \\\"{x:483,y:714,t:1527267195834};\\\", \\\"{x:482,y:716,t:1527267196387};\\\", \\\"{x:480,y:721,t:1527267196402};\\\", \\\"{x:471,y:737,t:1527267196418};\\\", \\\"{x:467,y:741,t:1527267196435};\\\", \\\"{x:465,y:746,t:1527267196451};\\\", \\\"{x:462,y:748,t:1527267196468};\\\", \\\"{x:462,y:751,t:1527267196485};\\\", \\\"{x:462,y:759,t:1527267196501};\\\", \\\"{x:462,y:774,t:1527267196518};\\\", \\\"{x:464,y:796,t:1527267196535};\\\", \\\"{x:475,y:823,t:1527267196551};\\\", \\\"{x:484,y:846,t:1527267196568};\\\", \\\"{x:495,y:867,t:1527267196585};\\\", \\\"{x:515,y:897,t:1527267196601};\\\", \\\"{x:557,y:940,t:1527267196619};\\\", \\\"{x:596,y:963,t:1527267196634};\\\", \\\"{x:627,y:979,t:1527267196652};\\\", \\\"{x:651,y:982,t:1527267196668};\\\", \\\"{x:673,y:985,t:1527267196686};\\\", \\\"{x:702,y:976,t:1527267196702};\\\", \\\"{x:739,y:947,t:1527267196718};\\\", \\\"{x:784,y:899,t:1527267196735};\\\", \\\"{x:816,y:844,t:1527267196752};\\\", \\\"{x:845,y:790,t:1527267196768};\\\", \\\"{x:876,y:734,t:1527267196785};\\\", \\\"{x:901,y:685,t:1527267196802};\\\", \\\"{x:928,y:638,t:1527267196819};\\\", \\\"{x:941,y:617,t:1527267196834};\\\", \\\"{x:948,y:605,t:1527267196853};\\\", \\\"{x:950,y:601,t:1527267196868};\\\" ] }, { \\\"rt\\\": 41565, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 208742, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -Z -03 PM-02 PM-01 PM-I -J -J -A -U -U -3-F -U -F -F -F -F -O -O -O -I -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:950,y:607,t:1527267198620};\\\", \\\"{x:950,y:620,t:1527267198638};\\\", \\\"{x:950,y:632,t:1527267198653};\\\", \\\"{x:950,y:642,t:1527267198670};\\\", \\\"{x:950,y:650,t:1527267198686};\\\", \\\"{x:950,y:659,t:1527267198703};\\\", \\\"{x:950,y:666,t:1527267198720};\\\", \\\"{x:952,y:676,t:1527267198736};\\\", \\\"{x:954,y:684,t:1527267198753};\\\", \\\"{x:956,y:691,t:1527267198770};\\\", \\\"{x:959,y:695,t:1527267198786};\\\", \\\"{x:965,y:697,t:1527267198803};\\\", \\\"{x:967,y:698,t:1527267198820};\\\", \\\"{x:970,y:698,t:1527267198836};\\\", \\\"{x:977,y:698,t:1527267198853};\\\", \\\"{x:987,y:698,t:1527267198871};\\\", \\\"{x:1001,y:698,t:1527267198886};\\\", \\\"{x:1022,y:692,t:1527267198904};\\\", \\\"{x:1043,y:685,t:1527267198920};\\\", \\\"{x:1067,y:676,t:1527267198936};\\\", \\\"{x:1092,y:669,t:1527267198953};\\\", \\\"{x:1136,y:655,t:1527267198971};\\\", \\\"{x:1162,y:649,t:1527267198987};\\\", \\\"{x:1186,y:645,t:1527267199004};\\\", \\\"{x:1211,y:641,t:1527267199020};\\\", \\\"{x:1229,y:639,t:1527267199036};\\\", \\\"{x:1243,y:636,t:1527267199054};\\\", \\\"{x:1254,y:634,t:1527267199071};\\\", \\\"{x:1268,y:630,t:1527267199088};\\\", \\\"{x:1275,y:629,t:1527267199103};\\\", \\\"{x:1282,y:627,t:1527267199121};\\\", \\\"{x:1285,y:627,t:1527267199137};\\\", \\\"{x:1291,y:627,t:1527267199153};\\\", \\\"{x:1305,y:627,t:1527267199170};\\\", \\\"{x:1319,y:627,t:1527267199188};\\\", \\\"{x:1329,y:627,t:1527267199204};\\\", \\\"{x:1331,y:627,t:1527267199220};\\\", \\\"{x:1336,y:627,t:1527267199238};\\\", \\\"{x:1338,y:629,t:1527267199254};\\\", \\\"{x:1342,y:633,t:1527267199270};\\\", \\\"{x:1345,y:639,t:1527267199287};\\\", \\\"{x:1351,y:650,t:1527267199303};\\\", \\\"{x:1357,y:664,t:1527267199320};\\\", \\\"{x:1362,y:676,t:1527267199337};\\\", \\\"{x:1366,y:687,t:1527267199353};\\\", \\\"{x:1369,y:699,t:1527267199370};\\\", \\\"{x:1370,y:704,t:1527267199388};\\\", \\\"{x:1370,y:707,t:1527267199403};\\\", \\\"{x:1370,y:715,t:1527267199421};\\\", \\\"{x:1369,y:726,t:1527267199437};\\\", \\\"{x:1363,y:744,t:1527267199454};\\\", \\\"{x:1357,y:759,t:1527267199471};\\\", \\\"{x:1350,y:769,t:1527267199488};\\\", \\\"{x:1348,y:775,t:1527267199503};\\\", \\\"{x:1345,y:779,t:1527267199521};\\\", \\\"{x:1342,y:786,t:1527267199537};\\\", \\\"{x:1339,y:799,t:1527267199554};\\\", \\\"{x:1338,y:809,t:1527267199571};\\\", \\\"{x:1336,y:814,t:1527267199587};\\\", \\\"{x:1336,y:816,t:1527267199605};\\\", \\\"{x:1336,y:820,t:1527267199621};\\\", \\\"{x:1336,y:823,t:1527267199638};\\\", \\\"{x:1336,y:828,t:1527267199655};\\\", \\\"{x:1340,y:837,t:1527267199670};\\\", \\\"{x:1343,y:845,t:1527267199687};\\\", \\\"{x:1345,y:853,t:1527267199704};\\\", \\\"{x:1345,y:856,t:1527267199721};\\\", \\\"{x:1347,y:858,t:1527267199738};\\\", \\\"{x:1347,y:864,t:1527267199755};\\\", \\\"{x:1347,y:866,t:1527267199771};\\\", \\\"{x:1347,y:869,t:1527267199788};\\\", \\\"{x:1347,y:873,t:1527267199805};\\\", \\\"{x:1347,y:878,t:1527267199821};\\\", \\\"{x:1346,y:881,t:1527267199838};\\\", \\\"{x:1346,y:882,t:1527267199854};\\\", \\\"{x:1346,y:885,t:1527267199871};\\\", \\\"{x:1348,y:889,t:1527267199887};\\\", \\\"{x:1355,y:898,t:1527267199905};\\\", \\\"{x:1357,y:901,t:1527267199921};\\\", \\\"{x:1360,y:903,t:1527267199938};\\\", \\\"{x:1364,y:905,t:1527267199955};\\\", \\\"{x:1366,y:906,t:1527267199971};\\\", \\\"{x:1368,y:908,t:1527267199988};\\\", \\\"{x:1370,y:908,t:1527267200005};\\\", \\\"{x:1372,y:908,t:1527267200022};\\\", \\\"{x:1373,y:909,t:1527267200043};\\\", \\\"{x:1374,y:909,t:1527267200075};\\\", \\\"{x:1376,y:910,t:1527267200090};\\\", \\\"{x:1378,y:911,t:1527267200105};\\\", \\\"{x:1383,y:912,t:1527267200122};\\\", \\\"{x:1392,y:913,t:1527267200138};\\\", \\\"{x:1409,y:916,t:1527267200155};\\\", \\\"{x:1422,y:918,t:1527267200172};\\\", \\\"{x:1438,y:921,t:1527267200188};\\\", \\\"{x:1457,y:922,t:1527267200204};\\\", \\\"{x:1472,y:922,t:1527267200221};\\\", \\\"{x:1486,y:922,t:1527267200238};\\\", \\\"{x:1501,y:922,t:1527267200255};\\\", \\\"{x:1522,y:922,t:1527267200272};\\\", \\\"{x:1542,y:923,t:1527267200288};\\\", \\\"{x:1562,y:925,t:1527267200304};\\\", \\\"{x:1579,y:928,t:1527267200321};\\\", \\\"{x:1593,y:930,t:1527267200338};\\\", \\\"{x:1603,y:931,t:1527267200354};\\\", \\\"{x:1604,y:933,t:1527267200443};\\\", \\\"{x:1606,y:935,t:1527267200455};\\\", \\\"{x:1609,y:943,t:1527267200471};\\\", \\\"{x:1611,y:948,t:1527267200488};\\\", \\\"{x:1612,y:950,t:1527267200505};\\\", \\\"{x:1613,y:952,t:1527267200521};\\\", \\\"{x:1613,y:955,t:1527267200538};\\\", \\\"{x:1613,y:960,t:1527267200555};\\\", \\\"{x:1613,y:964,t:1527267200571};\\\", \\\"{x:1613,y:965,t:1527267200588};\\\", \\\"{x:1613,y:967,t:1527267200605};\\\", \\\"{x:1613,y:968,t:1527267201812};\\\", \\\"{x:1612,y:968,t:1527267201823};\\\", \\\"{x:1610,y:968,t:1527267201839};\\\", \\\"{x:1605,y:968,t:1527267201856};\\\", \\\"{x:1598,y:968,t:1527267201873};\\\", \\\"{x:1592,y:969,t:1527267201889};\\\", \\\"{x:1584,y:971,t:1527267201906};\\\", \\\"{x:1561,y:974,t:1527267201924};\\\", \\\"{x:1540,y:974,t:1527267201939};\\\", \\\"{x:1511,y:974,t:1527267201957};\\\", \\\"{x:1469,y:974,t:1527267201973};\\\", \\\"{x:1446,y:974,t:1527267201991};\\\", \\\"{x:1421,y:974,t:1527267202006};\\\", \\\"{x:1402,y:971,t:1527267202023};\\\", \\\"{x:1379,y:964,t:1527267202041};\\\", \\\"{x:1359,y:958,t:1527267202056};\\\", \\\"{x:1339,y:952,t:1527267202073};\\\", \\\"{x:1319,y:946,t:1527267202090};\\\", \\\"{x:1302,y:942,t:1527267202106};\\\", \\\"{x:1265,y:935,t:1527267202122};\\\", \\\"{x:1230,y:923,t:1527267202140};\\\", \\\"{x:1188,y:910,t:1527267202156};\\\", \\\"{x:1158,y:902,t:1527267202173};\\\", \\\"{x:1147,y:899,t:1527267202189};\\\", \\\"{x:1146,y:898,t:1527267202205};\\\", \\\"{x:1144,y:896,t:1527267202222};\\\", \\\"{x:1143,y:891,t:1527267202240};\\\", \\\"{x:1139,y:881,t:1527267202255};\\\", \\\"{x:1135,y:865,t:1527267202273};\\\", \\\"{x:1133,y:852,t:1527267202289};\\\", \\\"{x:1132,y:845,t:1527267202306};\\\", \\\"{x:1130,y:839,t:1527267202323};\\\", \\\"{x:1131,y:835,t:1527267202339};\\\", \\\"{x:1133,y:832,t:1527267202356};\\\", \\\"{x:1137,y:828,t:1527267202372};\\\", \\\"{x:1138,y:825,t:1527267202390};\\\", \\\"{x:1140,y:823,t:1527267202407};\\\", \\\"{x:1140,y:822,t:1527267202423};\\\", \\\"{x:1140,y:821,t:1527267202440};\\\", \\\"{x:1136,y:823,t:1527267202588};\\\", \\\"{x:1133,y:824,t:1527267202595};\\\", \\\"{x:1127,y:827,t:1527267202607};\\\", \\\"{x:1117,y:830,t:1527267202624};\\\", \\\"{x:1109,y:834,t:1527267202641};\\\", \\\"{x:1106,y:836,t:1527267202657};\\\", \\\"{x:1101,y:839,t:1527267202673};\\\", \\\"{x:1096,y:842,t:1527267202690};\\\", \\\"{x:1088,y:844,t:1527267202707};\\\", \\\"{x:1084,y:844,t:1527267202723};\\\", \\\"{x:1082,y:845,t:1527267202740};\\\", \\\"{x:1080,y:845,t:1527267202756};\\\", \\\"{x:1079,y:845,t:1527267202773};\\\", \\\"{x:1079,y:844,t:1527267210215};\\\", \\\"{x:1109,y:811,t:1527267210233};\\\", \\\"{x:1144,y:760,t:1527267210248};\\\", \\\"{x:1197,y:683,t:1527267210266};\\\", \\\"{x:1240,y:624,t:1527267210282};\\\", \\\"{x:1270,y:576,t:1527267210299};\\\", \\\"{x:1282,y:549,t:1527267210316};\\\", \\\"{x:1289,y:529,t:1527267210332};\\\", \\\"{x:1292,y:515,t:1527267210348};\\\", \\\"{x:1293,y:511,t:1527267210365};\\\", \\\"{x:1295,y:508,t:1527267210382};\\\", \\\"{x:1296,y:507,t:1527267210399};\\\", \\\"{x:1298,y:506,t:1527267210430};\\\", \\\"{x:1299,y:504,t:1527267210438};\\\", \\\"{x:1303,y:502,t:1527267210449};\\\", \\\"{x:1308,y:498,t:1527267210466};\\\", \\\"{x:1315,y:492,t:1527267210483};\\\", \\\"{x:1326,y:486,t:1527267210499};\\\", \\\"{x:1334,y:481,t:1527267210515};\\\", \\\"{x:1337,y:478,t:1527267210532};\\\", \\\"{x:1340,y:475,t:1527267210548};\\\", \\\"{x:1346,y:471,t:1527267210565};\\\", \\\"{x:1358,y:463,t:1527267210581};\\\", \\\"{x:1364,y:458,t:1527267210599};\\\", \\\"{x:1367,y:453,t:1527267210615};\\\", \\\"{x:1370,y:447,t:1527267210632};\\\", \\\"{x:1374,y:442,t:1527267210649};\\\", \\\"{x:1376,y:439,t:1527267210665};\\\", \\\"{x:1377,y:437,t:1527267210685};\\\", \\\"{x:1380,y:434,t:1527267210699};\\\", \\\"{x:1390,y:424,t:1527267210716};\\\", \\\"{x:1400,y:414,t:1527267210733};\\\", \\\"{x:1407,y:409,t:1527267210749};\\\", \\\"{x:1411,y:406,t:1527267210765};\\\", \\\"{x:1412,y:406,t:1527267210782};\\\", \\\"{x:1413,y:406,t:1527267210806};\\\", \\\"{x:1415,y:406,t:1527267210815};\\\", \\\"{x:1416,y:406,t:1527267210832};\\\", \\\"{x:1417,y:406,t:1527267210854};\\\", \\\"{x:1418,y:406,t:1527267210927};\\\", \\\"{x:1419,y:407,t:1527267211015};\\\", \\\"{x:1419,y:408,t:1527267211030};\\\", \\\"{x:1419,y:409,t:1527267211047};\\\", \\\"{x:1419,y:411,t:1527267211054};\\\", \\\"{x:1419,y:412,t:1527267211067};\\\", \\\"{x:1418,y:416,t:1527267211083};\\\", \\\"{x:1418,y:422,t:1527267211100};\\\", \\\"{x:1418,y:425,t:1527267211117};\\\", \\\"{x:1418,y:427,t:1527267211132};\\\", \\\"{x:1418,y:429,t:1527267211149};\\\", \\\"{x:1418,y:430,t:1527267211174};\\\", \\\"{x:1420,y:431,t:1527267211190};\\\", \\\"{x:1421,y:431,t:1527267211207};\\\", \\\"{x:1422,y:431,t:1527267211231};\\\", \\\"{x:1424,y:432,t:1527267211254};\\\", \\\"{x:1423,y:432,t:1527267211471};\\\", \\\"{x:1422,y:432,t:1527267211484};\\\", \\\"{x:1421,y:432,t:1527267211517};\\\", \\\"{x:1419,y:432,t:1527267211533};\\\", \\\"{x:1418,y:432,t:1527267211654};\\\", \\\"{x:1417,y:430,t:1527267211670};\\\", \\\"{x:1416,y:430,t:1527267211686};\\\", \\\"{x:1415,y:430,t:1527267211700};\\\", \\\"{x:1413,y:430,t:1527267211718};\\\", \\\"{x:1412,y:430,t:1527267211734};\\\", \\\"{x:1411,y:429,t:1527267211750};\\\", \\\"{x:1404,y:436,t:1527267213662};\\\", \\\"{x:1394,y:455,t:1527267213669};\\\", \\\"{x:1379,y:479,t:1527267213684};\\\", \\\"{x:1332,y:584,t:1527267213701};\\\", \\\"{x:1299,y:653,t:1527267213718};\\\", \\\"{x:1281,y:695,t:1527267213735};\\\", \\\"{x:1273,y:715,t:1527267213751};\\\", \\\"{x:1266,y:729,t:1527267213767};\\\", \\\"{x:1263,y:737,t:1527267213784};\\\", \\\"{x:1261,y:746,t:1527267213801};\\\", \\\"{x:1261,y:751,t:1527267213817};\\\", \\\"{x:1259,y:758,t:1527267213834};\\\", \\\"{x:1258,y:763,t:1527267213851};\\\", \\\"{x:1255,y:772,t:1527267213868};\\\", \\\"{x:1252,y:784,t:1527267213884};\\\", \\\"{x:1248,y:794,t:1527267213902};\\\", \\\"{x:1243,y:807,t:1527267213918};\\\", \\\"{x:1238,y:817,t:1527267213935};\\\", \\\"{x:1234,y:824,t:1527267213952};\\\", \\\"{x:1230,y:830,t:1527267213969};\\\", \\\"{x:1229,y:832,t:1527267213985};\\\", \\\"{x:1228,y:832,t:1527267214002};\\\", \\\"{x:1227,y:834,t:1527267214018};\\\", \\\"{x:1225,y:835,t:1527267214035};\\\", \\\"{x:1225,y:837,t:1527267214052};\\\", \\\"{x:1224,y:839,t:1527267214078};\\\", \\\"{x:1224,y:840,t:1527267214095};\\\", \\\"{x:1224,y:841,t:1527267214175};\\\", \\\"{x:1224,y:843,t:1527267214185};\\\", \\\"{x:1230,y:843,t:1527267214202};\\\", \\\"{x:1241,y:843,t:1527267214219};\\\", \\\"{x:1247,y:843,t:1527267214235};\\\", \\\"{x:1254,y:843,t:1527267214252};\\\", \\\"{x:1259,y:843,t:1527267214269};\\\", \\\"{x:1262,y:843,t:1527267214285};\\\", \\\"{x:1266,y:843,t:1527267214302};\\\", \\\"{x:1272,y:843,t:1527267214318};\\\", \\\"{x:1276,y:843,t:1527267214334};\\\", \\\"{x:1278,y:842,t:1527267214352};\\\", \\\"{x:1282,y:842,t:1527267214368};\\\", \\\"{x:1284,y:842,t:1527267214385};\\\", \\\"{x:1286,y:842,t:1527267214447};\\\", \\\"{x:1288,y:842,t:1527267214455};\\\", \\\"{x:1291,y:840,t:1527267214469};\\\", \\\"{x:1296,y:839,t:1527267214486};\\\", \\\"{x:1299,y:838,t:1527267214502};\\\", \\\"{x:1300,y:838,t:1527267214519};\\\", \\\"{x:1299,y:837,t:1527267214647};\\\", \\\"{x:1297,y:836,t:1527267214654};\\\", \\\"{x:1296,y:835,t:1527267214669};\\\", \\\"{x:1291,y:833,t:1527267214686};\\\", \\\"{x:1286,y:831,t:1527267214702};\\\", \\\"{x:1285,y:831,t:1527267214718};\\\", \\\"{x:1283,y:830,t:1527267215111};\\\", \\\"{x:1282,y:829,t:1527267215135};\\\", \\\"{x:1284,y:829,t:1527267218327};\\\", \\\"{x:1286,y:829,t:1527267218343};\\\", \\\"{x:1289,y:829,t:1527267218356};\\\", \\\"{x:1291,y:830,t:1527267218372};\\\", \\\"{x:1293,y:831,t:1527267218389};\\\", \\\"{x:1297,y:831,t:1527267218406};\\\", \\\"{x:1303,y:833,t:1527267218422};\\\", \\\"{x:1310,y:834,t:1527267218438};\\\", \\\"{x:1317,y:836,t:1527267218455};\\\", \\\"{x:1323,y:838,t:1527267218472};\\\", \\\"{x:1333,y:841,t:1527267218488};\\\", \\\"{x:1336,y:842,t:1527267218505};\\\", \\\"{x:1340,y:844,t:1527267218522};\\\", \\\"{x:1341,y:845,t:1527267218539};\\\", \\\"{x:1343,y:846,t:1527267218555};\\\", \\\"{x:1344,y:847,t:1527267218623};\\\", \\\"{x:1345,y:847,t:1527267218647};\\\", \\\"{x:1346,y:847,t:1527267218654};\\\", \\\"{x:1354,y:847,t:1527267218671};\\\", \\\"{x:1364,y:847,t:1527267218688};\\\", \\\"{x:1371,y:847,t:1527267218705};\\\", \\\"{x:1376,y:847,t:1527267218721};\\\", \\\"{x:1381,y:847,t:1527267218738};\\\", \\\"{x:1385,y:846,t:1527267218755};\\\", \\\"{x:1391,y:844,t:1527267218772};\\\", \\\"{x:1401,y:843,t:1527267218789};\\\", \\\"{x:1413,y:842,t:1527267218805};\\\", \\\"{x:1422,y:842,t:1527267218821};\\\", \\\"{x:1426,y:841,t:1527267218839};\\\", \\\"{x:1427,y:840,t:1527267218855};\\\", \\\"{x:1428,y:839,t:1527267218871};\\\", \\\"{x:1430,y:837,t:1527267218888};\\\", \\\"{x:1436,y:835,t:1527267218904};\\\", \\\"{x:1441,y:831,t:1527267218922};\\\", \\\"{x:1447,y:829,t:1527267218938};\\\", \\\"{x:1451,y:827,t:1527267218955};\\\", \\\"{x:1455,y:827,t:1527267218971};\\\", \\\"{x:1458,y:825,t:1527267218988};\\\", \\\"{x:1461,y:825,t:1527267219004};\\\", \\\"{x:1462,y:823,t:1527267219021};\\\", \\\"{x:1464,y:823,t:1527267219095};\\\", \\\"{x:1465,y:823,t:1527267219105};\\\", \\\"{x:1466,y:823,t:1527267219122};\\\", \\\"{x:1467,y:823,t:1527267219138};\\\", \\\"{x:1469,y:823,t:1527267219155};\\\", \\\"{x:1475,y:825,t:1527267219172};\\\", \\\"{x:1483,y:829,t:1527267219189};\\\", \\\"{x:1490,y:832,t:1527267219206};\\\", \\\"{x:1493,y:834,t:1527267219222};\\\", \\\"{x:1493,y:835,t:1527267219367};\\\", \\\"{x:1493,y:836,t:1527267219382};\\\", \\\"{x:1492,y:836,t:1527267219407};\\\", \\\"{x:1488,y:836,t:1527267219423};\\\", \\\"{x:1486,y:836,t:1527267219439};\\\", \\\"{x:1483,y:835,t:1527267219456};\\\", \\\"{x:1482,y:835,t:1527267219472};\\\", \\\"{x:1481,y:835,t:1527267219518};\\\", \\\"{x:1480,y:835,t:1527267219542};\\\", \\\"{x:1479,y:834,t:1527267219822};\\\", \\\"{x:1479,y:833,t:1527267219855};\\\", \\\"{x:1470,y:834,t:1527267223136};\\\", \\\"{x:1459,y:836,t:1527267223143};\\\", \\\"{x:1438,y:843,t:1527267223158};\\\", \\\"{x:1418,y:845,t:1527267223175};\\\", \\\"{x:1381,y:843,t:1527267223192};\\\", \\\"{x:1288,y:826,t:1527267223208};\\\", \\\"{x:1202,y:801,t:1527267223225};\\\", \\\"{x:1119,y:774,t:1527267223242};\\\", \\\"{x:1057,y:756,t:1527267223259};\\\", \\\"{x:1012,y:742,t:1527267223275};\\\", \\\"{x:984,y:732,t:1527267223293};\\\", \\\"{x:970,y:724,t:1527267223309};\\\", \\\"{x:956,y:715,t:1527267223325};\\\", \\\"{x:949,y:706,t:1527267223342};\\\", \\\"{x:946,y:699,t:1527267223358};\\\", \\\"{x:945,y:696,t:1527267223375};\\\", \\\"{x:938,y:686,t:1527267223392};\\\", \\\"{x:922,y:674,t:1527267223408};\\\", \\\"{x:878,y:653,t:1527267223426};\\\", \\\"{x:816,y:636,t:1527267223442};\\\", \\\"{x:751,y:624,t:1527267223458};\\\", \\\"{x:704,y:617,t:1527267223475};\\\", \\\"{x:651,y:610,t:1527267223494};\\\", \\\"{x:617,y:608,t:1527267223509};\\\", \\\"{x:595,y:608,t:1527267223524};\\\", \\\"{x:585,y:606,t:1527267223542};\\\", \\\"{x:584,y:606,t:1527267223559};\\\", \\\"{x:583,y:606,t:1527267223575};\\\", \\\"{x:582,y:605,t:1527267223593};\\\", \\\"{x:580,y:604,t:1527267223609};\\\", \\\"{x:578,y:604,t:1527267223626};\\\", \\\"{x:579,y:603,t:1527267223774};\\\", \\\"{x:582,y:603,t:1527267223782};\\\", \\\"{x:584,y:603,t:1527267223793};\\\", \\\"{x:591,y:602,t:1527267223810};\\\", \\\"{x:597,y:601,t:1527267223827};\\\", \\\"{x:601,y:600,t:1527267223843};\\\", \\\"{x:604,y:599,t:1527267223860};\\\", \\\"{x:606,y:598,t:1527267223909};\\\", \\\"{x:610,y:598,t:1527267223926};\\\", \\\"{x:613,y:598,t:1527267223942};\\\", \\\"{x:614,y:598,t:1527267224301};\\\", \\\"{x:618,y:598,t:1527267224310};\\\", \\\"{x:627,y:600,t:1527267224328};\\\", \\\"{x:666,y:611,t:1527267224344};\\\", \\\"{x:739,y:625,t:1527267224361};\\\", \\\"{x:863,y:653,t:1527267224378};\\\", \\\"{x:1030,y:686,t:1527267224393};\\\", \\\"{x:1205,y:722,t:1527267224410};\\\", \\\"{x:1380,y:758,t:1527267224428};\\\", \\\"{x:1525,y:786,t:1527267224444};\\\", \\\"{x:1644,y:815,t:1527267224461};\\\", \\\"{x:1719,y:835,t:1527267224477};\\\", \\\"{x:1727,y:839,t:1527267224494};\\\", \\\"{x:1727,y:842,t:1527267224582};\\\", \\\"{x:1728,y:849,t:1527267224594};\\\", \\\"{x:1731,y:866,t:1527267224611};\\\", \\\"{x:1733,y:879,t:1527267224628};\\\", \\\"{x:1733,y:884,t:1527267224645};\\\", \\\"{x:1730,y:891,t:1527267224661};\\\", \\\"{x:1718,y:902,t:1527267224678};\\\", \\\"{x:1707,y:907,t:1527267224695};\\\", \\\"{x:1691,y:908,t:1527267224711};\\\", \\\"{x:1674,y:909,t:1527267224728};\\\", \\\"{x:1650,y:909,t:1527267224745};\\\", \\\"{x:1623,y:906,t:1527267224761};\\\", \\\"{x:1595,y:897,t:1527267224778};\\\", \\\"{x:1582,y:890,t:1527267224796};\\\", \\\"{x:1574,y:885,t:1527267224811};\\\", \\\"{x:1567,y:879,t:1527267224828};\\\", \\\"{x:1566,y:876,t:1527267224845};\\\", \\\"{x:1565,y:874,t:1527267224861};\\\", \\\"{x:1565,y:870,t:1527267224878};\\\", \\\"{x:1565,y:865,t:1527267224896};\\\", \\\"{x:1563,y:856,t:1527267224912};\\\", \\\"{x:1557,y:846,t:1527267224928};\\\", \\\"{x:1555,y:843,t:1527267224945};\\\", \\\"{x:1553,y:842,t:1527267224961};\\\", \\\"{x:1553,y:841,t:1527267224979};\\\", \\\"{x:1552,y:841,t:1527267224995};\\\", \\\"{x:1551,y:841,t:1527267225011};\\\", \\\"{x:1549,y:839,t:1527267225028};\\\", \\\"{x:1545,y:838,t:1527267225045};\\\", \\\"{x:1540,y:837,t:1527267225062};\\\", \\\"{x:1534,y:835,t:1527267225078};\\\", \\\"{x:1528,y:834,t:1527267225095};\\\", \\\"{x:1523,y:834,t:1527267225112};\\\", \\\"{x:1518,y:832,t:1527267225128};\\\", \\\"{x:1516,y:831,t:1527267225144};\\\", \\\"{x:1513,y:830,t:1527267225162};\\\", \\\"{x:1512,y:830,t:1527267225181};\\\", \\\"{x:1511,y:829,t:1527267225213};\\\", \\\"{x:1510,y:829,t:1527267225230};\\\", \\\"{x:1509,y:829,t:1527267225246};\\\", \\\"{x:1508,y:829,t:1527267225310};\\\", \\\"{x:1506,y:828,t:1527267225334};\\\", \\\"{x:1504,y:827,t:1527267225345};\\\", \\\"{x:1501,y:827,t:1527267225362};\\\", \\\"{x:1498,y:826,t:1527267225377};\\\", \\\"{x:1496,y:826,t:1527267225395};\\\", \\\"{x:1492,y:824,t:1527267226319};\\\", \\\"{x:1482,y:824,t:1527267226329};\\\", \\\"{x:1470,y:824,t:1527267226347};\\\", \\\"{x:1461,y:824,t:1527267226362};\\\", \\\"{x:1455,y:823,t:1527267226380};\\\", \\\"{x:1454,y:823,t:1527267226397};\\\", \\\"{x:1450,y:821,t:1527267226413};\\\", \\\"{x:1446,y:818,t:1527267226429};\\\", \\\"{x:1437,y:810,t:1527267226447};\\\", \\\"{x:1434,y:807,t:1527267226464};\\\", \\\"{x:1433,y:806,t:1527267226479};\\\", \\\"{x:1433,y:805,t:1527267226497};\\\", \\\"{x:1433,y:798,t:1527267226513};\\\", \\\"{x:1433,y:791,t:1527267226529};\\\", \\\"{x:1431,y:786,t:1527267226546};\\\", \\\"{x:1430,y:785,t:1527267226563};\\\", \\\"{x:1429,y:784,t:1527267226579};\\\", \\\"{x:1428,y:784,t:1527267226596};\\\", \\\"{x:1426,y:783,t:1527267226613};\\\", \\\"{x:1425,y:783,t:1527267226629};\\\", \\\"{x:1421,y:782,t:1527267226646};\\\", \\\"{x:1419,y:781,t:1527267226664};\\\", \\\"{x:1418,y:781,t:1527267226679};\\\", \\\"{x:1416,y:781,t:1527267226718};\\\", \\\"{x:1415,y:781,t:1527267226742};\\\", \\\"{x:1413,y:781,t:1527267226767};\\\", \\\"{x:1412,y:780,t:1527267226782};\\\", \\\"{x:1411,y:779,t:1527267226797};\\\", \\\"{x:1410,y:779,t:1527267226814};\\\", \\\"{x:1406,y:778,t:1527267226831};\\\", \\\"{x:1404,y:777,t:1527267226846};\\\", \\\"{x:1403,y:777,t:1527267226878};\\\", \\\"{x:1401,y:777,t:1527267226919};\\\", \\\"{x:1399,y:775,t:1527267227023};\\\", \\\"{x:1398,y:774,t:1527267227038};\\\", \\\"{x:1397,y:774,t:1527267227055};\\\", \\\"{x:1395,y:774,t:1527267227064};\\\", \\\"{x:1394,y:773,t:1527267227084};\\\", \\\"{x:1392,y:772,t:1527267227095};\\\", \\\"{x:1390,y:771,t:1527267227113};\\\", \\\"{x:1389,y:771,t:1527267227133};\\\", \\\"{x:1388,y:771,t:1527267227149};\\\", \\\"{x:1387,y:770,t:1527267227162};\\\", \\\"{x:1386,y:769,t:1527267227180};\\\", \\\"{x:1385,y:769,t:1527267227197};\\\", \\\"{x:1384,y:769,t:1527267227214};\\\", \\\"{x:1383,y:768,t:1527267227238};\\\", \\\"{x:1382,y:768,t:1527267227246};\\\", \\\"{x:1380,y:766,t:1527267227263};\\\", \\\"{x:1379,y:766,t:1527267227279};\\\", \\\"{x:1386,y:766,t:1527267229079};\\\", \\\"{x:1394,y:766,t:1527267229087};\\\", \\\"{x:1399,y:767,t:1527267229098};\\\", \\\"{x:1402,y:767,t:1527267229115};\\\", \\\"{x:1406,y:767,t:1527267229132};\\\", \\\"{x:1407,y:768,t:1527267229287};\\\", \\\"{x:1405,y:770,t:1527267229351};\\\", \\\"{x:1403,y:770,t:1527267229366};\\\", \\\"{x:1402,y:770,t:1527267229381};\\\", \\\"{x:1399,y:773,t:1527267229398};\\\", \\\"{x:1395,y:774,t:1527267229416};\\\", \\\"{x:1393,y:777,t:1527267229432};\\\", \\\"{x:1392,y:779,t:1527267229448};\\\", \\\"{x:1391,y:781,t:1527267229466};\\\", \\\"{x:1390,y:786,t:1527267229483};\\\", \\\"{x:1389,y:796,t:1527267229498};\\\", \\\"{x:1387,y:811,t:1527267229515};\\\", \\\"{x:1385,y:833,t:1527267229532};\\\", \\\"{x:1381,y:861,t:1527267229548};\\\", \\\"{x:1377,y:891,t:1527267229565};\\\", \\\"{x:1377,y:932,t:1527267229581};\\\", \\\"{x:1377,y:948,t:1527267229598};\\\", \\\"{x:1380,y:962,t:1527267229616};\\\", \\\"{x:1383,y:970,t:1527267229632};\\\", \\\"{x:1385,y:975,t:1527267229648};\\\", \\\"{x:1386,y:977,t:1527267229665};\\\", \\\"{x:1386,y:978,t:1527267229685};\\\", \\\"{x:1386,y:979,t:1527267229698};\\\", \\\"{x:1386,y:980,t:1527267229716};\\\", \\\"{x:1386,y:983,t:1527267229732};\\\", \\\"{x:1386,y:984,t:1527267229748};\\\", \\\"{x:1386,y:985,t:1527267229839};\\\", \\\"{x:1385,y:985,t:1527267229848};\\\", \\\"{x:1384,y:985,t:1527267229865};\\\", \\\"{x:1382,y:983,t:1527267229883};\\\", \\\"{x:1380,y:982,t:1527267229898};\\\", \\\"{x:1379,y:974,t:1527267229915};\\\", \\\"{x:1379,y:965,t:1527267229933};\\\", \\\"{x:1378,y:956,t:1527267229949};\\\", \\\"{x:1378,y:947,t:1527267229966};\\\", \\\"{x:1378,y:925,t:1527267229982};\\\", \\\"{x:1378,y:903,t:1527267230000};\\\", \\\"{x:1381,y:878,t:1527267230016};\\\", \\\"{x:1383,y:855,t:1527267230032};\\\", \\\"{x:1383,y:825,t:1527267230049};\\\", \\\"{x:1383,y:794,t:1527267230065};\\\", \\\"{x:1383,y:768,t:1527267230083};\\\", \\\"{x:1383,y:752,t:1527267230100};\\\", \\\"{x:1386,y:739,t:1527267230116};\\\", \\\"{x:1387,y:733,t:1527267230133};\\\", \\\"{x:1387,y:729,t:1527267230149};\\\", \\\"{x:1388,y:726,t:1527267230165};\\\", \\\"{x:1390,y:720,t:1527267230182};\\\", \\\"{x:1390,y:717,t:1527267230199};\\\", \\\"{x:1390,y:716,t:1527267230215};\\\", \\\"{x:1390,y:717,t:1527267230383};\\\", \\\"{x:1389,y:725,t:1527267230400};\\\", \\\"{x:1385,y:734,t:1527267230417};\\\", \\\"{x:1383,y:741,t:1527267230432};\\\", \\\"{x:1381,y:745,t:1527267230449};\\\", \\\"{x:1381,y:748,t:1527267230466};\\\", \\\"{x:1380,y:748,t:1527267230482};\\\", \\\"{x:1380,y:749,t:1527267230558};\\\", \\\"{x:1380,y:750,t:1527267230582};\\\", \\\"{x:1379,y:750,t:1527267232173};\\\", \\\"{x:1377,y:750,t:1527267232184};\\\", \\\"{x:1372,y:742,t:1527267232200};\\\", \\\"{x:1354,y:713,t:1527267232217};\\\", \\\"{x:1333,y:684,t:1527267232234};\\\", \\\"{x:1313,y:653,t:1527267232250};\\\", \\\"{x:1306,y:642,t:1527267232268};\\\", \\\"{x:1305,y:640,t:1527267232284};\\\", \\\"{x:1305,y:637,t:1527267232300};\\\", \\\"{x:1304,y:630,t:1527267232317};\\\", \\\"{x:1300,y:624,t:1527267232333};\\\", \\\"{x:1296,y:619,t:1527267232350};\\\", \\\"{x:1293,y:615,t:1527267232368};\\\", \\\"{x:1292,y:613,t:1527267232384};\\\", \\\"{x:1290,y:608,t:1527267232401};\\\", \\\"{x:1289,y:608,t:1527267232417};\\\", \\\"{x:1289,y:606,t:1527267232434};\\\", \\\"{x:1290,y:606,t:1527267232526};\\\", \\\"{x:1297,y:606,t:1527267232534};\\\", \\\"{x:1304,y:609,t:1527267232550};\\\", \\\"{x:1307,y:610,t:1527267232568};\\\", \\\"{x:1310,y:611,t:1527267232584};\\\", \\\"{x:1312,y:613,t:1527267232602};\\\", \\\"{x:1313,y:614,t:1527267232654};\\\", \\\"{x:1313,y:615,t:1527267232694};\\\", \\\"{x:1313,y:616,t:1527267232702};\\\", \\\"{x:1313,y:617,t:1527267232718};\\\", \\\"{x:1313,y:619,t:1527267232734};\\\", \\\"{x:1313,y:621,t:1527267232752};\\\", \\\"{x:1313,y:623,t:1527267232768};\\\", \\\"{x:1313,y:626,t:1527267232786};\\\", \\\"{x:1313,y:629,t:1527267232801};\\\", \\\"{x:1313,y:632,t:1527267232818};\\\", \\\"{x:1313,y:633,t:1527267232835};\\\", \\\"{x:1313,y:630,t:1527267234710};\\\", \\\"{x:1313,y:624,t:1527267234721};\\\", \\\"{x:1313,y:617,t:1527267234735};\\\", \\\"{x:1313,y:613,t:1527267234752};\\\", \\\"{x:1313,y:608,t:1527267234770};\\\", \\\"{x:1313,y:604,t:1527267234785};\\\", \\\"{x:1313,y:599,t:1527267234803};\\\", \\\"{x:1312,y:590,t:1527267234819};\\\", \\\"{x:1310,y:580,t:1527267234837};\\\", \\\"{x:1309,y:571,t:1527267234853};\\\", \\\"{x:1308,y:562,t:1527267234869};\\\", \\\"{x:1308,y:557,t:1527267234885};\\\", \\\"{x:1308,y:552,t:1527267234903};\\\", \\\"{x:1308,y:547,t:1527267234919};\\\", \\\"{x:1307,y:541,t:1527267234936};\\\", \\\"{x:1306,y:535,t:1527267234952};\\\", \\\"{x:1306,y:530,t:1527267234969};\\\", \\\"{x:1306,y:526,t:1527267234987};\\\", \\\"{x:1306,y:523,t:1527267235003};\\\", \\\"{x:1306,y:521,t:1527267235020};\\\", \\\"{x:1306,y:518,t:1527267235036};\\\", \\\"{x:1306,y:515,t:1527267235053};\\\", \\\"{x:1307,y:511,t:1527267235070};\\\", \\\"{x:1307,y:508,t:1527267235087};\\\", \\\"{x:1308,y:507,t:1527267235102};\\\", \\\"{x:1308,y:506,t:1527267235119};\\\", \\\"{x:1308,y:505,t:1527267235141};\\\", \\\"{x:1308,y:504,t:1527267235166};\\\", \\\"{x:1308,y:503,t:1527267235213};\\\", \\\"{x:1309,y:502,t:1527267235278};\\\", \\\"{x:1309,y:501,t:1527267235366};\\\", \\\"{x:1310,y:499,t:1527267235374};\\\", \\\"{x:1311,y:498,t:1527267235387};\\\", \\\"{x:1312,y:496,t:1527267235403};\\\", \\\"{x:1312,y:495,t:1527267235422};\\\", \\\"{x:1311,y:498,t:1527267236942};\\\", \\\"{x:1310,y:505,t:1527267236955};\\\", \\\"{x:1307,y:523,t:1527267236971};\\\", \\\"{x:1306,y:538,t:1527267236988};\\\", \\\"{x:1305,y:554,t:1527267237005};\\\", \\\"{x:1303,y:567,t:1527267237021};\\\", \\\"{x:1300,y:579,t:1527267237038};\\\", \\\"{x:1300,y:585,t:1527267237054};\\\", \\\"{x:1300,y:593,t:1527267237071};\\\", \\\"{x:1300,y:605,t:1527267237088};\\\", \\\"{x:1300,y:614,t:1527267237104};\\\", \\\"{x:1298,y:624,t:1527267237121};\\\", \\\"{x:1298,y:633,t:1527267237137};\\\", \\\"{x:1298,y:639,t:1527267237154};\\\", \\\"{x:1298,y:644,t:1527267237172};\\\", \\\"{x:1298,y:646,t:1527267237187};\\\", \\\"{x:1298,y:648,t:1527267237204};\\\", \\\"{x:1298,y:654,t:1527267237221};\\\", \\\"{x:1298,y:657,t:1527267237237};\\\", \\\"{x:1298,y:658,t:1527267237254};\\\", \\\"{x:1298,y:661,t:1527267237407};\\\", \\\"{x:1299,y:676,t:1527267237422};\\\", \\\"{x:1303,y:695,t:1527267237438};\\\", \\\"{x:1303,y:713,t:1527267237455};\\\", \\\"{x:1303,y:732,t:1527267237471};\\\", \\\"{x:1303,y:751,t:1527267237489};\\\", \\\"{x:1303,y:770,t:1527267237505};\\\", \\\"{x:1303,y:780,t:1527267237522};\\\", \\\"{x:1302,y:788,t:1527267237539};\\\", \\\"{x:1300,y:795,t:1527267237555};\\\", \\\"{x:1296,y:805,t:1527267237572};\\\", \\\"{x:1293,y:811,t:1527267237589};\\\", \\\"{x:1292,y:815,t:1527267237605};\\\", \\\"{x:1292,y:817,t:1527267237622};\\\", \\\"{x:1292,y:818,t:1527267237735};\\\", \\\"{x:1290,y:820,t:1527267237742};\\\", \\\"{x:1290,y:821,t:1527267237755};\\\", \\\"{x:1287,y:824,t:1527267237772};\\\", \\\"{x:1286,y:825,t:1527267237789};\\\", \\\"{x:1286,y:826,t:1527267237805};\\\", \\\"{x:1285,y:826,t:1527267237919};\\\", \\\"{x:1284,y:828,t:1527267237982};\\\", \\\"{x:1279,y:829,t:1527267237990};\\\", \\\"{x:1270,y:833,t:1527267238007};\\\", \\\"{x:1253,y:836,t:1527267238022};\\\", \\\"{x:1212,y:842,t:1527267238039};\\\", \\\"{x:1142,y:844,t:1527267238056};\\\", \\\"{x:1081,y:844,t:1527267238072};\\\", \\\"{x:1025,y:844,t:1527267238089};\\\", \\\"{x:983,y:844,t:1527267238105};\\\", \\\"{x:962,y:841,t:1527267238121};\\\", \\\"{x:953,y:839,t:1527267238139};\\\", \\\"{x:949,y:836,t:1527267238155};\\\", \\\"{x:946,y:832,t:1527267238171};\\\", \\\"{x:945,y:830,t:1527267238188};\\\", \\\"{x:943,y:827,t:1527267238205};\\\", \\\"{x:939,y:823,t:1527267238222};\\\", \\\"{x:925,y:818,t:1527267238238};\\\", \\\"{x:899,y:811,t:1527267238256};\\\", \\\"{x:876,y:807,t:1527267238271};\\\", \\\"{x:849,y:802,t:1527267238289};\\\", \\\"{x:808,y:793,t:1527267238305};\\\", \\\"{x:760,y:785,t:1527267238321};\\\", \\\"{x:720,y:779,t:1527267238338};\\\", \\\"{x:692,y:775,t:1527267238356};\\\", \\\"{x:670,y:772,t:1527267238372};\\\", \\\"{x:653,y:766,t:1527267238389};\\\", \\\"{x:645,y:763,t:1527267238406};\\\", \\\"{x:641,y:760,t:1527267238421};\\\", \\\"{x:632,y:757,t:1527267238439};\\\", \\\"{x:625,y:754,t:1527267238455};\\\", \\\"{x:621,y:753,t:1527267238472};\\\", \\\"{x:614,y:751,t:1527267238489};\\\", \\\"{x:604,y:747,t:1527267238505};\\\", \\\"{x:592,y:742,t:1527267238523};\\\", \\\"{x:587,y:741,t:1527267238538};\\\", \\\"{x:586,y:741,t:1527267238555};\\\", \\\"{x:583,y:740,t:1527267238573};\\\", \\\"{x:580,y:738,t:1527267238588};\\\", \\\"{x:573,y:734,t:1527267238605};\\\", \\\"{x:568,y:732,t:1527267238622};\\\", \\\"{x:564,y:731,t:1527267238638};\\\", \\\"{x:563,y:730,t:1527267238657};\\\", \\\"{x:559,y:729,t:1527267238672};\\\", \\\"{x:553,y:725,t:1527267238688};\\\", \\\"{x:546,y:722,t:1527267238704};\\\", \\\"{x:540,y:719,t:1527267238722};\\\", \\\"{x:534,y:715,t:1527267238737};\\\", \\\"{x:529,y:711,t:1527267238754};\\\", \\\"{x:526,y:709,t:1527267238771};\\\", \\\"{x:531,y:702,t:1527267239333};\\\", \\\"{x:552,y:681,t:1527267239340};\\\", \\\"{x:582,y:649,t:1527267239356};\\\", \\\"{x:667,y:556,t:1527267239373};\\\", \\\"{x:720,y:488,t:1527267239389};\\\", \\\"{x:779,y:412,t:1527267239406};\\\", \\\"{x:840,y:330,t:1527267239424};\\\", \\\"{x:880,y:290,t:1527267239439};\\\", \\\"{x:890,y:278,t:1527267239456};\\\", \\\"{x:892,y:276,t:1527267239473};\\\" ] }, { \\\"rt\\\": 48363, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 258377, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -08 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:886,y:289,t:1527267240670};\\\", \\\"{x:876,y:310,t:1527267240677};\\\", \\\"{x:866,y:334,t:1527267240691};\\\", \\\"{x:841,y:392,t:1527267240707};\\\", \\\"{x:774,y:544,t:1527267240808};\\\", \\\"{x:768,y:554,t:1527267240824};\\\", \\\"{x:764,y:561,t:1527267240841};\\\", \\\"{x:754,y:568,t:1527267240857};\\\", \\\"{x:740,y:571,t:1527267240874};\\\", \\\"{x:717,y:576,t:1527267240890};\\\", \\\"{x:684,y:576,t:1527267240907};\\\", \\\"{x:647,y:576,t:1527267240924};\\\", \\\"{x:603,y:571,t:1527267240940};\\\", \\\"{x:567,y:553,t:1527267240957};\\\", \\\"{x:550,y:537,t:1527267240976};\\\", \\\"{x:530,y:517,t:1527267240990};\\\", \\\"{x:514,y:498,t:1527267241007};\\\", \\\"{x:505,y:488,t:1527267241024};\\\", \\\"{x:500,y:484,t:1527267241040};\\\", \\\"{x:497,y:482,t:1527267241057};\\\", \\\"{x:494,y:482,t:1527267241190};\\\", \\\"{x:490,y:482,t:1527267241208};\\\", \\\"{x:482,y:482,t:1527267241224};\\\", \\\"{x:474,y:482,t:1527267241240};\\\", \\\"{x:461,y:484,t:1527267241257};\\\", \\\"{x:448,y:490,t:1527267241275};\\\", \\\"{x:436,y:494,t:1527267241291};\\\", \\\"{x:433,y:495,t:1527267241308};\\\", \\\"{x:428,y:495,t:1527267241325};\\\", \\\"{x:426,y:495,t:1527267241341};\\\", \\\"{x:423,y:495,t:1527267241358};\\\", \\\"{x:421,y:494,t:1527267241375};\\\", \\\"{x:425,y:494,t:1527267241446};\\\", \\\"{x:436,y:494,t:1527267241458};\\\", \\\"{x:461,y:494,t:1527267241475};\\\", \\\"{x:485,y:494,t:1527267241491};\\\", \\\"{x:507,y:492,t:1527267241508};\\\", \\\"{x:521,y:490,t:1527267241524};\\\", \\\"{x:529,y:489,t:1527267241541};\\\", \\\"{x:534,y:489,t:1527267241558};\\\", \\\"{x:540,y:489,t:1527267241575};\\\", \\\"{x:543,y:489,t:1527267241590};\\\", \\\"{x:544,y:489,t:1527267241608};\\\", \\\"{x:547,y:489,t:1527267241624};\\\", \\\"{x:552,y:488,t:1527267241640};\\\", \\\"{x:555,y:487,t:1527267241657};\\\", \\\"{x:556,y:486,t:1527267241675};\\\", \\\"{x:557,y:486,t:1527267241690};\\\", \\\"{x:558,y:485,t:1527267241718};\\\", \\\"{x:559,y:485,t:1527267241726};\\\", \\\"{x:562,y:483,t:1527267241740};\\\", \\\"{x:571,y:478,t:1527267241758};\\\", \\\"{x:579,y:472,t:1527267241775};\\\", \\\"{x:584,y:469,t:1527267241791};\\\", \\\"{x:587,y:467,t:1527267241807};\\\", \\\"{x:589,y:466,t:1527267241825};\\\", \\\"{x:592,y:466,t:1527267241841};\\\", \\\"{x:601,y:466,t:1527267241858};\\\", \\\"{x:612,y:466,t:1527267241875};\\\", \\\"{x:629,y:467,t:1527267241891};\\\", \\\"{x:642,y:469,t:1527267241908};\\\", \\\"{x:646,y:469,t:1527267241925};\\\", \\\"{x:648,y:471,t:1527267241998};\\\", \\\"{x:648,y:475,t:1527267242086};\\\", \\\"{x:644,y:479,t:1527267242094};\\\", \\\"{x:639,y:484,t:1527267242108};\\\", \\\"{x:628,y:492,t:1527267242125};\\\", \\\"{x:614,y:502,t:1527267242141};\\\", \\\"{x:594,y:512,t:1527267242158};\\\", \\\"{x:575,y:515,t:1527267242175};\\\", \\\"{x:558,y:515,t:1527267242190};\\\", \\\"{x:538,y:514,t:1527267242208};\\\", \\\"{x:520,y:508,t:1527267242225};\\\", \\\"{x:502,y:504,t:1527267242241};\\\", \\\"{x:482,y:502,t:1527267242257};\\\", \\\"{x:469,y:499,t:1527267242275};\\\", \\\"{x:458,y:498,t:1527267242290};\\\", \\\"{x:455,y:497,t:1527267242307};\\\", \\\"{x:451,y:497,t:1527267242325};\\\", \\\"{x:449,y:497,t:1527267242340};\\\", \\\"{x:446,y:497,t:1527267242357};\\\", \\\"{x:445,y:497,t:1527267242374};\\\", \\\"{x:444,y:499,t:1527267242391};\\\", \\\"{x:443,y:499,t:1527267242413};\\\", \\\"{x:443,y:500,t:1527267242425};\\\", \\\"{x:437,y:504,t:1527267242441};\\\", \\\"{x:434,y:507,t:1527267242458};\\\", \\\"{x:429,y:511,t:1527267242475};\\\", \\\"{x:428,y:511,t:1527267242491};\\\", \\\"{x:429,y:513,t:1527267242566};\\\", \\\"{x:432,y:513,t:1527267242574};\\\", \\\"{x:444,y:514,t:1527267242591};\\\", \\\"{x:456,y:514,t:1527267242608};\\\", \\\"{x:470,y:514,t:1527267242625};\\\", \\\"{x:485,y:514,t:1527267242641};\\\", \\\"{x:503,y:512,t:1527267242657};\\\", \\\"{x:518,y:507,t:1527267242675};\\\", \\\"{x:528,y:502,t:1527267242691};\\\", \\\"{x:538,y:498,t:1527267242708};\\\", \\\"{x:543,y:498,t:1527267242725};\\\", \\\"{x:547,y:497,t:1527267242741};\\\", \\\"{x:552,y:497,t:1527267242758};\\\", \\\"{x:555,y:496,t:1527267242775};\\\", \\\"{x:556,y:496,t:1527267242791};\\\", \\\"{x:558,y:496,t:1527267242863};\\\", \\\"{x:559,y:496,t:1527267242875};\\\", \\\"{x:562,y:496,t:1527267242891};\\\", \\\"{x:563,y:496,t:1527267242908};\\\", \\\"{x:564,y:496,t:1527267242926};\\\", \\\"{x:565,y:498,t:1527267242941};\\\", \\\"{x:565,y:501,t:1527267242958};\\\", \\\"{x:565,y:502,t:1527267242975};\\\", \\\"{x:565,y:503,t:1527267242991};\\\", \\\"{x:565,y:506,t:1527267243008};\\\", \\\"{x:565,y:508,t:1527267243025};\\\", \\\"{x:561,y:513,t:1527267243041};\\\", \\\"{x:559,y:515,t:1527267243058};\\\", \\\"{x:557,y:518,t:1527267243075};\\\", \\\"{x:553,y:521,t:1527267243092};\\\", \\\"{x:547,y:523,t:1527267243107};\\\", \\\"{x:538,y:526,t:1527267243125};\\\", \\\"{x:530,y:527,t:1527267243142};\\\", \\\"{x:526,y:527,t:1527267243159};\\\", \\\"{x:521,y:527,t:1527267243175};\\\", \\\"{x:513,y:527,t:1527267243193};\\\", \\\"{x:499,y:520,t:1527267243209};\\\", \\\"{x:489,y:515,t:1527267243226};\\\", \\\"{x:485,y:514,t:1527267243243};\\\", \\\"{x:483,y:511,t:1527267243259};\\\", \\\"{x:473,y:503,t:1527267243275};\\\", \\\"{x:464,y:496,t:1527267243293};\\\", \\\"{x:457,y:487,t:1527267243309};\\\", \\\"{x:448,y:478,t:1527267243325};\\\", \\\"{x:438,y:468,t:1527267243342};\\\", \\\"{x:432,y:464,t:1527267243359};\\\", \\\"{x:431,y:463,t:1527267243377};\\\", \\\"{x:430,y:463,t:1527267243397};\\\", \\\"{x:429,y:463,t:1527267243410};\\\", \\\"{x:427,y:463,t:1527267243427};\\\", \\\"{x:421,y:463,t:1527267243443};\\\", \\\"{x:414,y:463,t:1527267243459};\\\", \\\"{x:407,y:463,t:1527267243477};\\\", \\\"{x:400,y:463,t:1527267243492};\\\", \\\"{x:387,y:467,t:1527267243509};\\\", \\\"{x:373,y:471,t:1527267243527};\\\", \\\"{x:369,y:474,t:1527267243543};\\\", \\\"{x:373,y:474,t:1527267243670};\\\", \\\"{x:378,y:473,t:1527267243677};\\\", \\\"{x:385,y:472,t:1527267243693};\\\", \\\"{x:403,y:469,t:1527267243709};\\\", \\\"{x:416,y:467,t:1527267243727};\\\", \\\"{x:432,y:463,t:1527267243743};\\\", \\\"{x:441,y:463,t:1527267243759};\\\", \\\"{x:453,y:463,t:1527267243778};\\\", \\\"{x:457,y:463,t:1527267243793};\\\", \\\"{x:458,y:463,t:1527267243810};\\\", \\\"{x:459,y:463,t:1527267243827};\\\", \\\"{x:463,y:463,t:1527267243844};\\\", \\\"{x:469,y:463,t:1527267243860};\\\", \\\"{x:477,y:463,t:1527267243878};\\\", \\\"{x:484,y:463,t:1527267243894};\\\", \\\"{x:487,y:463,t:1527267243910};\\\", \\\"{x:488,y:463,t:1527267243927};\\\", \\\"{x:489,y:463,t:1527267243944};\\\", \\\"{x:490,y:463,t:1527267243966};\\\", \\\"{x:491,y:463,t:1527267244014};\\\", \\\"{x:492,y:463,t:1527267244038};\\\", \\\"{x:493,y:463,t:1527267244062};\\\", \\\"{x:495,y:463,t:1527267244077};\\\", \\\"{x:497,y:463,t:1527267244094};\\\", \\\"{x:499,y:463,t:1527267244110};\\\", \\\"{x:504,y:463,t:1527267244127};\\\", \\\"{x:510,y:463,t:1527267244144};\\\", \\\"{x:517,y:463,t:1527267244160};\\\", \\\"{x:521,y:463,t:1527267244177};\\\", \\\"{x:523,y:463,t:1527267244194};\\\", \\\"{x:526,y:463,t:1527267244210};\\\", \\\"{x:529,y:463,t:1527267244227};\\\", \\\"{x:530,y:463,t:1527267244244};\\\", \\\"{x:532,y:463,t:1527267244260};\\\", \\\"{x:533,y:463,t:1527267244277};\\\", \\\"{x:537,y:463,t:1527267244294};\\\", \\\"{x:540,y:463,t:1527267244311};\\\", \\\"{x:542,y:462,t:1527267244327};\\\", \\\"{x:544,y:462,t:1527267244344};\\\", \\\"{x:546,y:461,t:1527267244361};\\\", \\\"{x:547,y:461,t:1527267244406};\\\", \\\"{x:548,y:461,t:1527267244430};\\\", \\\"{x:550,y:461,t:1527267244444};\\\", \\\"{x:552,y:461,t:1527267244461};\\\", \\\"{x:561,y:461,t:1527267244477};\\\", \\\"{x:582,y:462,t:1527267244494};\\\", \\\"{x:597,y:462,t:1527267244511};\\\", \\\"{x:615,y:462,t:1527267244527};\\\", \\\"{x:628,y:462,t:1527267244544};\\\", \\\"{x:635,y:462,t:1527267244561};\\\", \\\"{x:639,y:464,t:1527267244577};\\\", \\\"{x:641,y:464,t:1527267244594};\\\", \\\"{x:642,y:464,t:1527267244611};\\\", \\\"{x:643,y:464,t:1527267244679};\\\", \\\"{x:649,y:464,t:1527267244693};\\\", \\\"{x:654,y:464,t:1527267244711};\\\", \\\"{x:656,y:464,t:1527267244728};\\\", \\\"{x:658,y:464,t:1527267244744};\\\", \\\"{x:662,y:465,t:1527267244950};\\\", \\\"{x:671,y:470,t:1527267244961};\\\", \\\"{x:680,y:474,t:1527267244978};\\\", \\\"{x:691,y:479,t:1527267244994};\\\", \\\"{x:700,y:483,t:1527267245011};\\\", \\\"{x:708,y:485,t:1527267245028};\\\", \\\"{x:714,y:488,t:1527267245044};\\\", \\\"{x:716,y:489,t:1527267245061};\\\", \\\"{x:717,y:489,t:1527267245718};\\\", \\\"{x:717,y:490,t:1527267247454};\\\", \\\"{x:717,y:495,t:1527267247463};\\\", \\\"{x:717,y:504,t:1527267247480};\\\", \\\"{x:716,y:520,t:1527267247496};\\\", \\\"{x:716,y:535,t:1527267247512};\\\", \\\"{x:716,y:549,t:1527267247530};\\\", \\\"{x:717,y:558,t:1527267247548};\\\", \\\"{x:718,y:567,t:1527267247563};\\\", \\\"{x:722,y:574,t:1527267247580};\\\", \\\"{x:725,y:579,t:1527267247597};\\\", \\\"{x:731,y:591,t:1527267247613};\\\", \\\"{x:736,y:598,t:1527267247630};\\\", \\\"{x:743,y:608,t:1527267247646};\\\", \\\"{x:756,y:624,t:1527267247662};\\\", \\\"{x:767,y:638,t:1527267247680};\\\", \\\"{x:776,y:648,t:1527267247696};\\\", \\\"{x:785,y:655,t:1527267247713};\\\", \\\"{x:793,y:659,t:1527267247729};\\\", \\\"{x:800,y:664,t:1527267247746};\\\", \\\"{x:804,y:666,t:1527267247762};\\\", \\\"{x:805,y:666,t:1527267247780};\\\", \\\"{x:805,y:674,t:1527267248015};\\\", \\\"{x:803,y:696,t:1527267248030};\\\", \\\"{x:797,y:725,t:1527267248046};\\\", \\\"{x:794,y:754,t:1527267248063};\\\", \\\"{x:789,y:779,t:1527267248079};\\\", \\\"{x:787,y:795,t:1527267248096};\\\", \\\"{x:787,y:806,t:1527267248113};\\\", \\\"{x:787,y:821,t:1527267248129};\\\", \\\"{x:794,y:843,t:1527267248145};\\\", \\\"{x:806,y:862,t:1527267248163};\\\", \\\"{x:815,y:874,t:1527267248180};\\\", \\\"{x:822,y:882,t:1527267248196};\\\", \\\"{x:832,y:889,t:1527267248213};\\\", \\\"{x:845,y:897,t:1527267248229};\\\", \\\"{x:871,y:898,t:1527267248246};\\\", \\\"{x:894,y:898,t:1527267248264};\\\", \\\"{x:927,y:896,t:1527267248279};\\\", \\\"{x:989,y:888,t:1527267248297};\\\", \\\"{x:1072,y:876,t:1527267248313};\\\", \\\"{x:1139,y:866,t:1527267248330};\\\", \\\"{x:1218,y:851,t:1527267248346};\\\", \\\"{x:1290,y:830,t:1527267248364};\\\", \\\"{x:1356,y:814,t:1527267248380};\\\", \\\"{x:1428,y:794,t:1527267248397};\\\", \\\"{x:1496,y:780,t:1527267248413};\\\", \\\"{x:1559,y:777,t:1527267248430};\\\", \\\"{x:1631,y:777,t:1527267248446};\\\", \\\"{x:1652,y:777,t:1527267248462};\\\", \\\"{x:1668,y:776,t:1527267248480};\\\", \\\"{x:1676,y:774,t:1527267248496};\\\", \\\"{x:1678,y:774,t:1527267248512};\\\", \\\"{x:1678,y:773,t:1527267248845};\\\", \\\"{x:1677,y:773,t:1527267248934};\\\", \\\"{x:1676,y:773,t:1527267248950};\\\", \\\"{x:1675,y:773,t:1527267248982};\\\", \\\"{x:1674,y:773,t:1527267249006};\\\", \\\"{x:1673,y:773,t:1527267249014};\\\", \\\"{x:1672,y:773,t:1527267249038};\\\", \\\"{x:1671,y:773,t:1527267249054};\\\", \\\"{x:1670,y:773,t:1527267249062};\\\", \\\"{x:1668,y:773,t:1527267249080};\\\", \\\"{x:1667,y:775,t:1527267249096};\\\", \\\"{x:1665,y:777,t:1527267249118};\\\", \\\"{x:1663,y:778,t:1527267249128};\\\", \\\"{x:1662,y:779,t:1527267249146};\\\", \\\"{x:1660,y:781,t:1527267249162};\\\", \\\"{x:1657,y:784,t:1527267249179};\\\", \\\"{x:1653,y:788,t:1527267249195};\\\", \\\"{x:1647,y:792,t:1527267249212};\\\", \\\"{x:1639,y:797,t:1527267249229};\\\", \\\"{x:1629,y:799,t:1527267249245};\\\", \\\"{x:1611,y:803,t:1527267249262};\\\", \\\"{x:1603,y:804,t:1527267249278};\\\", \\\"{x:1596,y:805,t:1527267249296};\\\", \\\"{x:1592,y:806,t:1527267249312};\\\", \\\"{x:1588,y:807,t:1527267249329};\\\", \\\"{x:1585,y:807,t:1527267249346};\\\", \\\"{x:1581,y:807,t:1527267249362};\\\", \\\"{x:1578,y:807,t:1527267249379};\\\", \\\"{x:1574,y:809,t:1527267249395};\\\", \\\"{x:1572,y:809,t:1527267249413};\\\", \\\"{x:1570,y:809,t:1527267249429};\\\", \\\"{x:1566,y:809,t:1527267249446};\\\", \\\"{x:1562,y:809,t:1527267249460};\\\", \\\"{x:1557,y:809,t:1527267249477};\\\", \\\"{x:1556,y:809,t:1527267249494};\\\", \\\"{x:1554,y:809,t:1527267249512};\\\", \\\"{x:1553,y:809,t:1527267249528};\\\", \\\"{x:1552,y:809,t:1527267249565};\\\", \\\"{x:1551,y:809,t:1527267249581};\\\", \\\"{x:1550,y:809,t:1527267249595};\\\", \\\"{x:1548,y:808,t:1527267249610};\\\", \\\"{x:1543,y:806,t:1527267249628};\\\", \\\"{x:1535,y:802,t:1527267249645};\\\", \\\"{x:1529,y:798,t:1527267249661};\\\", \\\"{x:1526,y:798,t:1527267249678};\\\", \\\"{x:1523,y:797,t:1527267249695};\\\", \\\"{x:1519,y:796,t:1527267249711};\\\", \\\"{x:1516,y:796,t:1527267249729};\\\", \\\"{x:1515,y:796,t:1527267249745};\\\", \\\"{x:1513,y:796,t:1527267249761};\\\", \\\"{x:1510,y:796,t:1527267249779};\\\", \\\"{x:1509,y:796,t:1527267249796};\\\", \\\"{x:1506,y:796,t:1527267249811};\\\", \\\"{x:1503,y:796,t:1527267249828};\\\", \\\"{x:1500,y:798,t:1527267249846};\\\", \\\"{x:1497,y:798,t:1527267249861};\\\", \\\"{x:1496,y:799,t:1527267249878};\\\", \\\"{x:1493,y:800,t:1527267249895};\\\", \\\"{x:1491,y:801,t:1527267249912};\\\", \\\"{x:1488,y:802,t:1527267249929};\\\", \\\"{x:1486,y:802,t:1527267249945};\\\", \\\"{x:1481,y:804,t:1527267249962};\\\", \\\"{x:1478,y:805,t:1527267249979};\\\", \\\"{x:1473,y:806,t:1527267249994};\\\", \\\"{x:1468,y:808,t:1527267250011};\\\", \\\"{x:1464,y:809,t:1527267250028};\\\", \\\"{x:1460,y:809,t:1527267250043};\\\", \\\"{x:1452,y:812,t:1527267250061};\\\", \\\"{x:1449,y:813,t:1527267250077};\\\", \\\"{x:1443,y:815,t:1527267250094};\\\", \\\"{x:1440,y:817,t:1527267250111};\\\", \\\"{x:1438,y:817,t:1527267250128};\\\", \\\"{x:1431,y:821,t:1527267250144};\\\", \\\"{x:1426,y:824,t:1527267250161};\\\", \\\"{x:1423,y:826,t:1527267250178};\\\", \\\"{x:1419,y:831,t:1527267250194};\\\", \\\"{x:1417,y:834,t:1527267250211};\\\", \\\"{x:1414,y:839,t:1527267250229};\\\", \\\"{x:1411,y:843,t:1527267250244};\\\", \\\"{x:1407,y:847,t:1527267250261};\\\", \\\"{x:1403,y:855,t:1527267250278};\\\", \\\"{x:1403,y:859,t:1527267250295};\\\", \\\"{x:1402,y:863,t:1527267250311};\\\", \\\"{x:1401,y:865,t:1527267250328};\\\", \\\"{x:1401,y:860,t:1527267250407};\\\", \\\"{x:1406,y:850,t:1527267250414};\\\", \\\"{x:1409,y:839,t:1527267250427};\\\", \\\"{x:1421,y:814,t:1527267250444};\\\", \\\"{x:1438,y:782,t:1527267250462};\\\", \\\"{x:1451,y:763,t:1527267250479};\\\", \\\"{x:1466,y:746,t:1527267250495};\\\", \\\"{x:1475,y:731,t:1527267250511};\\\", \\\"{x:1487,y:717,t:1527267250528};\\\", \\\"{x:1495,y:706,t:1527267250544};\\\", \\\"{x:1503,y:692,t:1527267250561};\\\", \\\"{x:1513,y:680,t:1527267250578};\\\", \\\"{x:1520,y:670,t:1527267250595};\\\", \\\"{x:1524,y:665,t:1527267250612};\\\", \\\"{x:1527,y:661,t:1527267250628};\\\", \\\"{x:1531,y:657,t:1527267250645};\\\", \\\"{x:1535,y:653,t:1527267250661};\\\", \\\"{x:1539,y:650,t:1527267250678};\\\", \\\"{x:1543,y:647,t:1527267250693};\\\", \\\"{x:1547,y:645,t:1527267250711};\\\", \\\"{x:1550,y:643,t:1527267250728};\\\", \\\"{x:1555,y:641,t:1527267250744};\\\", \\\"{x:1561,y:638,t:1527267250760};\\\", \\\"{x:1564,y:636,t:1527267250777};\\\", \\\"{x:1566,y:635,t:1527267250794};\\\", \\\"{x:1567,y:634,t:1527267250810};\\\", \\\"{x:1567,y:633,t:1527267250885};\\\", \\\"{x:1567,y:632,t:1527267250901};\\\", \\\"{x:1567,y:630,t:1527267250910};\\\", \\\"{x:1567,y:628,t:1527267250928};\\\", \\\"{x:1566,y:626,t:1527267250944};\\\", \\\"{x:1563,y:622,t:1527267250960};\\\", \\\"{x:1561,y:616,t:1527267250977};\\\", \\\"{x:1559,y:611,t:1527267250994};\\\", \\\"{x:1555,y:603,t:1527267251010};\\\", \\\"{x:1550,y:595,t:1527267251027};\\\", \\\"{x:1543,y:584,t:1527267251044};\\\", \\\"{x:1538,y:578,t:1527267251061};\\\", \\\"{x:1535,y:571,t:1527267251077};\\\", \\\"{x:1533,y:565,t:1527267251094};\\\", \\\"{x:1530,y:558,t:1527267251110};\\\", \\\"{x:1527,y:553,t:1527267251127};\\\", \\\"{x:1525,y:551,t:1527267251143};\\\", \\\"{x:1522,y:547,t:1527267251160};\\\", \\\"{x:1521,y:544,t:1527267251178};\\\", \\\"{x:1519,y:541,t:1527267251194};\\\", \\\"{x:1515,y:536,t:1527267251210};\\\", \\\"{x:1510,y:530,t:1527267251227};\\\", \\\"{x:1504,y:526,t:1527267251243};\\\", \\\"{x:1497,y:521,t:1527267251261};\\\", \\\"{x:1489,y:517,t:1527267251278};\\\", \\\"{x:1483,y:516,t:1527267251294};\\\", \\\"{x:1478,y:513,t:1527267251310};\\\", \\\"{x:1476,y:512,t:1527267251327};\\\", \\\"{x:1475,y:512,t:1527267251344};\\\", \\\"{x:1474,y:512,t:1527267251361};\\\", \\\"{x:1473,y:512,t:1527267251378};\\\", \\\"{x:1470,y:512,t:1527267251394};\\\", \\\"{x:1468,y:512,t:1527267251411};\\\", \\\"{x:1466,y:512,t:1527267251427};\\\", \\\"{x:1464,y:512,t:1527267251443};\\\", \\\"{x:1459,y:512,t:1527267251460};\\\", \\\"{x:1451,y:513,t:1527267251476};\\\", \\\"{x:1435,y:515,t:1527267251494};\\\", \\\"{x:1421,y:517,t:1527267251510};\\\", \\\"{x:1410,y:519,t:1527267251527};\\\", \\\"{x:1404,y:520,t:1527267251543};\\\", \\\"{x:1401,y:520,t:1527267251560};\\\", \\\"{x:1399,y:520,t:1527267251576};\\\", \\\"{x:1398,y:520,t:1527267251593};\\\", \\\"{x:1397,y:520,t:1527267251610};\\\", \\\"{x:1395,y:520,t:1527267251627};\\\", \\\"{x:1392,y:520,t:1527267251644};\\\", \\\"{x:1387,y:520,t:1527267251660};\\\", \\\"{x:1382,y:520,t:1527267251676};\\\", \\\"{x:1376,y:520,t:1527267251694};\\\", \\\"{x:1373,y:520,t:1527267251710};\\\", \\\"{x:1370,y:518,t:1527267251727};\\\", \\\"{x:1365,y:517,t:1527267251744};\\\", \\\"{x:1363,y:515,t:1527267251760};\\\", \\\"{x:1361,y:515,t:1527267251776};\\\", \\\"{x:1357,y:513,t:1527267251793};\\\", \\\"{x:1353,y:511,t:1527267251810};\\\", \\\"{x:1348,y:510,t:1527267251827};\\\", \\\"{x:1346,y:508,t:1527267251843};\\\", \\\"{x:1344,y:507,t:1527267251859};\\\", \\\"{x:1341,y:506,t:1527267251877};\\\", \\\"{x:1336,y:504,t:1527267251894};\\\", \\\"{x:1334,y:504,t:1527267251910};\\\", \\\"{x:1333,y:503,t:1527267251927};\\\", \\\"{x:1331,y:502,t:1527267251943};\\\", \\\"{x:1330,y:502,t:1527267251960};\\\", \\\"{x:1328,y:501,t:1527267251976};\\\", \\\"{x:1327,y:501,t:1527267251993};\\\", \\\"{x:1325,y:500,t:1527267252009};\\\", \\\"{x:1324,y:500,t:1527267252026};\\\", \\\"{x:1322,y:500,t:1527267252043};\\\", \\\"{x:1321,y:499,t:1527267252093};\\\", \\\"{x:1320,y:499,t:1527267252109};\\\", \\\"{x:1319,y:499,t:1527267252151};\\\", \\\"{x:1319,y:498,t:1527267252159};\\\", \\\"{x:1317,y:497,t:1527267252176};\\\", \\\"{x:1316,y:497,t:1527267252193};\\\", \\\"{x:1315,y:497,t:1527267252209};\\\", \\\"{x:1313,y:497,t:1527267252227};\\\", \\\"{x:1311,y:497,t:1527267252262};\\\", \\\"{x:1310,y:497,t:1527267252293};\\\", \\\"{x:1309,y:497,t:1527267252326};\\\", \\\"{x:1308,y:497,t:1527267252351};\\\", \\\"{x:1307,y:497,t:1527267252366};\\\", \\\"{x:1306,y:496,t:1527267252382};\\\", \\\"{x:1307,y:496,t:1527267252726};\\\", \\\"{x:1309,y:496,t:1527267252743};\\\", \\\"{x:1310,y:497,t:1527267252942};\\\", \\\"{x:1311,y:498,t:1527267253606};\\\", \\\"{x:1312,y:498,t:1527267253614};\\\", \\\"{x:1313,y:498,t:1527267253629};\\\", \\\"{x:1314,y:498,t:1527267253646};\\\", \\\"{x:1321,y:500,t:1527267256895};\\\", \\\"{x:1340,y:509,t:1527267256906};\\\", \\\"{x:1401,y:526,t:1527267256923};\\\", \\\"{x:1481,y:547,t:1527267256938};\\\", \\\"{x:1571,y:566,t:1527267256955};\\\", \\\"{x:1666,y:579,t:1527267256973};\\\", \\\"{x:1746,y:588,t:1527267256989};\\\", \\\"{x:1830,y:596,t:1527267257006};\\\", \\\"{x:1853,y:596,t:1527267257022};\\\", \\\"{x:1863,y:598,t:1527267257040};\\\", \\\"{x:1867,y:599,t:1527267257056};\\\", \\\"{x:1873,y:601,t:1527267257073};\\\", \\\"{x:1879,y:602,t:1527267257088};\\\", \\\"{x:1882,y:604,t:1527267257106};\\\", \\\"{x:1885,y:605,t:1527267257134};\\\", \\\"{x:1887,y:606,t:1527267257142};\\\", \\\"{x:1890,y:610,t:1527267257156};\\\", \\\"{x:1895,y:615,t:1527267257173};\\\", \\\"{x:1899,y:620,t:1527267257189};\\\", \\\"{x:1902,y:630,t:1527267257205};\\\", \\\"{x:1903,y:646,t:1527267257222};\\\", \\\"{x:1903,y:675,t:1527267257238};\\\", \\\"{x:1912,y:732,t:1527267257254};\\\", \\\"{x:1918,y:766,t:1527267257269};\\\", \\\"{x:1918,y:880,t:1527267257301};\\\", \\\"{x:1911,y:898,t:1527267257309};\\\", \\\"{x:1907,y:909,t:1527267257321};\\\", \\\"{x:1896,y:929,t:1527267257337};\\\", \\\"{x:1888,y:945,t:1527267257354};\\\", \\\"{x:1880,y:958,t:1527267257372};\\\", \\\"{x:1877,y:966,t:1527267257387};\\\", \\\"{x:1875,y:968,t:1527267257404};\\\", \\\"{x:1873,y:970,t:1527267257421};\\\", \\\"{x:1872,y:970,t:1527267257445};\\\", \\\"{x:1870,y:970,t:1527267257517};\\\", \\\"{x:1869,y:970,t:1527267257525};\\\", \\\"{x:1867,y:970,t:1527267257538};\\\", \\\"{x:1859,y:969,t:1527267257555};\\\", \\\"{x:1853,y:968,t:1527267257572};\\\", \\\"{x:1850,y:967,t:1527267257589};\\\", \\\"{x:1846,y:965,t:1527267257605};\\\", \\\"{x:1840,y:964,t:1527267257622};\\\", \\\"{x:1839,y:964,t:1527267257638};\\\", \\\"{x:1835,y:963,t:1527267257654};\\\", \\\"{x:1830,y:961,t:1527267257672};\\\", \\\"{x:1826,y:960,t:1527267257688};\\\", \\\"{x:1824,y:959,t:1527267257705};\\\", \\\"{x:1821,y:959,t:1527267257721};\\\", \\\"{x:1820,y:958,t:1527267257738};\\\", \\\"{x:1819,y:958,t:1527267257773};\\\", \\\"{x:1818,y:957,t:1527267257789};\\\", \\\"{x:1815,y:955,t:1527267257806};\\\", \\\"{x:1814,y:954,t:1527267257822};\\\", \\\"{x:1814,y:955,t:1527267258030};\\\", \\\"{x:1814,y:956,t:1527267258039};\\\", \\\"{x:1814,y:958,t:1527267258056};\\\", \\\"{x:1814,y:959,t:1527267258073};\\\", \\\"{x:1815,y:960,t:1527267258542};\\\", \\\"{x:1815,y:961,t:1527267258557};\\\", \\\"{x:1815,y:964,t:1527267258574};\\\", \\\"{x:1815,y:966,t:1527267258590};\\\", \\\"{x:1815,y:967,t:1527267259734};\\\", \\\"{x:1813,y:967,t:1527267259750};\\\", \\\"{x:1811,y:967,t:1527267259759};\\\", \\\"{x:1808,y:966,t:1527267259776};\\\", \\\"{x:1805,y:965,t:1527267259793};\\\", \\\"{x:1802,y:964,t:1527267259810};\\\", \\\"{x:1801,y:964,t:1527267259826};\\\", \\\"{x:1795,y:963,t:1527267259842};\\\", \\\"{x:1789,y:962,t:1527267259860};\\\", \\\"{x:1778,y:962,t:1527267259876};\\\", \\\"{x:1772,y:962,t:1527267259894};\\\", \\\"{x:1765,y:962,t:1527267259909};\\\", \\\"{x:1759,y:962,t:1527267259926};\\\", \\\"{x:1754,y:961,t:1527267259943};\\\", \\\"{x:1750,y:960,t:1527267259960};\\\", \\\"{x:1744,y:959,t:1527267259977};\\\", \\\"{x:1739,y:959,t:1527267259992};\\\", \\\"{x:1733,y:959,t:1527267260009};\\\", \\\"{x:1727,y:959,t:1527267260026};\\\", \\\"{x:1718,y:959,t:1527267260042};\\\", \\\"{x:1704,y:958,t:1527267260059};\\\", \\\"{x:1685,y:958,t:1527267260076};\\\", \\\"{x:1664,y:958,t:1527267260093};\\\", \\\"{x:1649,y:958,t:1527267260109};\\\", \\\"{x:1633,y:958,t:1527267260127};\\\", \\\"{x:1616,y:958,t:1527267260144};\\\", \\\"{x:1605,y:958,t:1527267260160};\\\", \\\"{x:1596,y:956,t:1527267260177};\\\", \\\"{x:1587,y:956,t:1527267260194};\\\", \\\"{x:1584,y:956,t:1527267260209};\\\", \\\"{x:1579,y:956,t:1527267260227};\\\", \\\"{x:1572,y:957,t:1527267260244};\\\", \\\"{x:1562,y:960,t:1527267260261};\\\", \\\"{x:1554,y:960,t:1527267260276};\\\", \\\"{x:1550,y:960,t:1527267260293};\\\", \\\"{x:1548,y:960,t:1527267260310};\\\", \\\"{x:1547,y:960,t:1527267260327};\\\", \\\"{x:1547,y:961,t:1527267260343};\\\", \\\"{x:1550,y:961,t:1527267260486};\\\", \\\"{x:1553,y:961,t:1527267260494};\\\", \\\"{x:1561,y:961,t:1527267260511};\\\", \\\"{x:1571,y:961,t:1527267260527};\\\", \\\"{x:1579,y:961,t:1527267260544};\\\", \\\"{x:1584,y:960,t:1527267260560};\\\", \\\"{x:1586,y:959,t:1527267260578};\\\", \\\"{x:1587,y:959,t:1527267260594};\\\", \\\"{x:1586,y:959,t:1527267260725};\\\", \\\"{x:1584,y:959,t:1527267260742};\\\", \\\"{x:1583,y:959,t:1527267260862};\\\", \\\"{x:1582,y:960,t:1527267260878};\\\", \\\"{x:1581,y:961,t:1527267260901};\\\", \\\"{x:1580,y:962,t:1527267260912};\\\", \\\"{x:1580,y:963,t:1527267260942};\\\", \\\"{x:1579,y:964,t:1527267260950};\\\", \\\"{x:1579,y:965,t:1527267260962};\\\", \\\"{x:1578,y:966,t:1527267260980};\\\", \\\"{x:1577,y:967,t:1527267260995};\\\", \\\"{x:1578,y:966,t:1527267261310};\\\", \\\"{x:1580,y:965,t:1527267261837};\\\", \\\"{x:1582,y:964,t:1527267261853};\\\", \\\"{x:1582,y:963,t:1527267261870};\\\", \\\"{x:1583,y:963,t:1527267261880};\\\", \\\"{x:1583,y:962,t:1527267261926};\\\", \\\"{x:1584,y:962,t:1527267263958};\\\", \\\"{x:1585,y:961,t:1527267263968};\\\", \\\"{x:1585,y:960,t:1527267263984};\\\", \\\"{x:1585,y:959,t:1527267264014};\\\", \\\"{x:1585,y:957,t:1527267264062};\\\", \\\"{x:1585,y:956,t:1527267264094};\\\", \\\"{x:1586,y:956,t:1527267264101};\\\", \\\"{x:1586,y:955,t:1527267264150};\\\", \\\"{x:1586,y:954,t:1527267264198};\\\", \\\"{x:1586,y:953,t:1527267264222};\\\", \\\"{x:1586,y:954,t:1527267264357};\\\", \\\"{x:1586,y:956,t:1527267264369};\\\", \\\"{x:1586,y:957,t:1527267264385};\\\", \\\"{x:1586,y:959,t:1527267264402};\\\", \\\"{x:1586,y:960,t:1527267264419};\\\", \\\"{x:1586,y:962,t:1527267264461};\\\", \\\"{x:1586,y:963,t:1527267264478};\\\", \\\"{x:1586,y:965,t:1527267264485};\\\", \\\"{x:1586,y:967,t:1527267264501};\\\", \\\"{x:1586,y:968,t:1527267264519};\\\", \\\"{x:1586,y:969,t:1527267264536};\\\", \\\"{x:1585,y:970,t:1527267264742};\\\", \\\"{x:1584,y:970,t:1527267264765};\\\", \\\"{x:1583,y:969,t:1527267264798};\\\", \\\"{x:1583,y:968,t:1527267264822};\\\", \\\"{x:1583,y:966,t:1527267264836};\\\", \\\"{x:1583,y:965,t:1527267264853};\\\", \\\"{x:1583,y:963,t:1527267264871};\\\", \\\"{x:1583,y:961,t:1527267264887};\\\", \\\"{x:1583,y:959,t:1527267264903};\\\", \\\"{x:1581,y:957,t:1527267264920};\\\", \\\"{x:1581,y:956,t:1527267264936};\\\", \\\"{x:1581,y:954,t:1527267264953};\\\", \\\"{x:1581,y:951,t:1527267264970};\\\", \\\"{x:1581,y:948,t:1527267264986};\\\", \\\"{x:1581,y:947,t:1527267265003};\\\", \\\"{x:1582,y:944,t:1527267265020};\\\", \\\"{x:1582,y:943,t:1527267265037};\\\", \\\"{x:1582,y:942,t:1527267265053};\\\", \\\"{x:1582,y:940,t:1527267265069};\\\", \\\"{x:1582,y:939,t:1527267265094};\\\", \\\"{x:1582,y:938,t:1527267265103};\\\", \\\"{x:1582,y:937,t:1527267265120};\\\", \\\"{x:1582,y:935,t:1527267265137};\\\", \\\"{x:1581,y:934,t:1527267265153};\\\", \\\"{x:1581,y:932,t:1527267265173};\\\", \\\"{x:1581,y:931,t:1527267265189};\\\", \\\"{x:1580,y:929,t:1527267265205};\\\", \\\"{x:1580,y:927,t:1527267265238};\\\", \\\"{x:1580,y:926,t:1527267265270};\\\", \\\"{x:1578,y:925,t:1527267265287};\\\", \\\"{x:1577,y:924,t:1527267265304};\\\", \\\"{x:1577,y:922,t:1527267265350};\\\", \\\"{x:1576,y:920,t:1527267265398};\\\", \\\"{x:1576,y:919,t:1527267265422};\\\", \\\"{x:1576,y:918,t:1527267265437};\\\", \\\"{x:1576,y:917,t:1527267265468};\\\", \\\"{x:1576,y:916,t:1527267265493};\\\", \\\"{x:1575,y:915,t:1527267265541};\\\", \\\"{x:1575,y:914,t:1527267265564};\\\", \\\"{x:1575,y:913,t:1527267265573};\\\", \\\"{x:1575,y:912,t:1527267265597};\\\", \\\"{x:1575,y:911,t:1527267265613};\\\", \\\"{x:1575,y:910,t:1527267265629};\\\", \\\"{x:1574,y:909,t:1527267265645};\\\", \\\"{x:1574,y:908,t:1527267265661};\\\", \\\"{x:1574,y:907,t:1527267265671};\\\", \\\"{x:1574,y:906,t:1527267265688};\\\", \\\"{x:1574,y:904,t:1527267265705};\\\", \\\"{x:1574,y:903,t:1527267265721};\\\", \\\"{x:1574,y:901,t:1527267265738};\\\", \\\"{x:1574,y:900,t:1527267265755};\\\", \\\"{x:1574,y:898,t:1527267265771};\\\", \\\"{x:1574,y:897,t:1527267265788};\\\", \\\"{x:1574,y:894,t:1527267265804};\\\", \\\"{x:1574,y:892,t:1527267265822};\\\", \\\"{x:1574,y:891,t:1527267265846};\\\", \\\"{x:1574,y:890,t:1527267265870};\\\", \\\"{x:1574,y:889,t:1527267265886};\\\", \\\"{x:1574,y:888,t:1527267265893};\\\", \\\"{x:1574,y:887,t:1527267265926};\\\", \\\"{x:1574,y:886,t:1527267265938};\\\", \\\"{x:1574,y:885,t:1527267265955};\\\", \\\"{x:1574,y:883,t:1527267265972};\\\", \\\"{x:1574,y:882,t:1527267265990};\\\", \\\"{x:1574,y:880,t:1527267266014};\\\", \\\"{x:1574,y:879,t:1527267266030};\\\", \\\"{x:1574,y:877,t:1527267266046};\\\", \\\"{x:1574,y:876,t:1527267266062};\\\", \\\"{x:1574,y:875,t:1527267266072};\\\", \\\"{x:1574,y:874,t:1527267266089};\\\", \\\"{x:1574,y:873,t:1527267266126};\\\", \\\"{x:1573,y:872,t:1527267266142};\\\", \\\"{x:1573,y:871,t:1527267266158};\\\", \\\"{x:1573,y:870,t:1527267266181};\\\", \\\"{x:1573,y:869,t:1527267266206};\\\", \\\"{x:1573,y:868,t:1527267266222};\\\", \\\"{x:1573,y:867,t:1527267266262};\\\", \\\"{x:1572,y:869,t:1527267266374};\\\", \\\"{x:1572,y:876,t:1527267266390};\\\", \\\"{x:1572,y:898,t:1527267266406};\\\", \\\"{x:1572,y:913,t:1527267266423};\\\", \\\"{x:1572,y:927,t:1527267266439};\\\", \\\"{x:1572,y:939,t:1527267266456};\\\", \\\"{x:1572,y:945,t:1527267266472};\\\", \\\"{x:1575,y:949,t:1527267266489};\\\", \\\"{x:1575,y:951,t:1527267266505};\\\", \\\"{x:1576,y:952,t:1527267266522};\\\", \\\"{x:1576,y:954,t:1527267266540};\\\", \\\"{x:1577,y:958,t:1527267266556};\\\", \\\"{x:1578,y:961,t:1527267266573};\\\", \\\"{x:1580,y:964,t:1527267266588};\\\", \\\"{x:1580,y:965,t:1527267266605};\\\", \\\"{x:1581,y:966,t:1527267266623};\\\", \\\"{x:1581,y:968,t:1527267266645};\\\", \\\"{x:1582,y:968,t:1527267266750};\\\", \\\"{x:1583,y:969,t:1527267266815};\\\", \\\"{x:1582,y:969,t:1527267267238};\\\", \\\"{x:1581,y:969,t:1527267285753};\\\", \\\"{x:1575,y:965,t:1527267285764};\\\", \\\"{x:1548,y:964,t:1527267285781};\\\", \\\"{x:1460,y:953,t:1527267285799};\\\", \\\"{x:1340,y:934,t:1527267285814};\\\", \\\"{x:1238,y:920,t:1527267285831};\\\", \\\"{x:1041,y:884,t:1527267285849};\\\", \\\"{x:881,y:858,t:1527267285865};\\\", \\\"{x:737,y:819,t:1527267285882};\\\", \\\"{x:603,y:791,t:1527267285898};\\\", \\\"{x:487,y:760,t:1527267285916};\\\", \\\"{x:401,y:733,t:1527267285931};\\\", \\\"{x:353,y:711,t:1527267285948};\\\", \\\"{x:330,y:699,t:1527267285965};\\\", \\\"{x:312,y:684,t:1527267285982};\\\", \\\"{x:297,y:671,t:1527267285999};\\\", \\\"{x:288,y:661,t:1527267286017};\\\", \\\"{x:262,y:647,t:1527267286034};\\\", \\\"{x:235,y:638,t:1527267286047};\\\", \\\"{x:215,y:632,t:1527267286057};\\\", \\\"{x:181,y:622,t:1527267286074};\\\", \\\"{x:167,y:618,t:1527267286090};\\\", \\\"{x:173,y:610,t:1527267286114};\\\", \\\"{x:191,y:600,t:1527267286131};\\\", \\\"{x:208,y:590,t:1527267286148};\\\", \\\"{x:223,y:584,t:1527267286164};\\\", \\\"{x:233,y:583,t:1527267286180};\\\", \\\"{x:237,y:581,t:1527267286198};\\\", \\\"{x:238,y:581,t:1527267286214};\\\", \\\"{x:239,y:581,t:1527267286264};\\\", \\\"{x:247,y:586,t:1527267286281};\\\", \\\"{x:253,y:589,t:1527267286298};\\\", \\\"{x:259,y:593,t:1527267286314};\\\", \\\"{x:266,y:599,t:1527267286332};\\\", \\\"{x:273,y:605,t:1527267286349};\\\", \\\"{x:274,y:615,t:1527267286365};\\\", \\\"{x:276,y:621,t:1527267286381};\\\", \\\"{x:272,y:630,t:1527267286398};\\\", \\\"{x:264,y:638,t:1527267286415};\\\", \\\"{x:255,y:643,t:1527267286430};\\\", \\\"{x:244,y:647,t:1527267286448};\\\", \\\"{x:237,y:648,t:1527267286463};\\\", \\\"{x:227,y:649,t:1527267286481};\\\", \\\"{x:221,y:649,t:1527267286498};\\\", \\\"{x:212,y:649,t:1527267286515};\\\", \\\"{x:195,y:645,t:1527267286531};\\\", \\\"{x:181,y:641,t:1527267286548};\\\", \\\"{x:174,y:639,t:1527267286565};\\\", \\\"{x:170,y:638,t:1527267286580};\\\", \\\"{x:169,y:637,t:1527267286598};\\\", \\\"{x:168,y:637,t:1527267286624};\\\", \\\"{x:167,y:636,t:1527267286649};\\\", \\\"{x:167,y:635,t:1527267286665};\\\", \\\"{x:167,y:632,t:1527267286682};\\\", \\\"{x:167,y:630,t:1527267286698};\\\", \\\"{x:167,y:628,t:1527267286715};\\\", \\\"{x:167,y:625,t:1527267286731};\\\", \\\"{x:167,y:621,t:1527267286748};\\\", \\\"{x:169,y:616,t:1527267286765};\\\", \\\"{x:174,y:610,t:1527267286782};\\\", \\\"{x:183,y:603,t:1527267286798};\\\", \\\"{x:195,y:600,t:1527267286816};\\\", \\\"{x:202,y:598,t:1527267286832};\\\", \\\"{x:208,y:597,t:1527267286848};\\\", \\\"{x:216,y:597,t:1527267286864};\\\", \\\"{x:229,y:597,t:1527267286882};\\\", \\\"{x:240,y:597,t:1527267286898};\\\", \\\"{x:256,y:597,t:1527267286915};\\\", \\\"{x:276,y:597,t:1527267286933};\\\", \\\"{x:294,y:599,t:1527267286948};\\\", \\\"{x:310,y:603,t:1527267286965};\\\", \\\"{x:323,y:605,t:1527267286982};\\\", \\\"{x:331,y:607,t:1527267286998};\\\", \\\"{x:340,y:610,t:1527267287015};\\\", \\\"{x:355,y:615,t:1527267287033};\\\", \\\"{x:358,y:615,t:1527267287049};\\\", \\\"{x:365,y:615,t:1527267287065};\\\", \\\"{x:370,y:615,t:1527267287082};\\\", \\\"{x:380,y:615,t:1527267287099};\\\", \\\"{x:399,y:616,t:1527267287116};\\\", \\\"{x:419,y:616,t:1527267287133};\\\", \\\"{x:440,y:616,t:1527267287147};\\\", \\\"{x:460,y:616,t:1527267287164};\\\", \\\"{x:477,y:616,t:1527267287182};\\\", \\\"{x:488,y:616,t:1527267287198};\\\", \\\"{x:495,y:616,t:1527267287215};\\\", \\\"{x:504,y:616,t:1527267287233};\\\", \\\"{x:511,y:616,t:1527267287248};\\\", \\\"{x:516,y:616,t:1527267287265};\\\", \\\"{x:520,y:618,t:1527267287282};\\\", \\\"{x:524,y:619,t:1527267287298};\\\", \\\"{x:529,y:619,t:1527267287315};\\\", \\\"{x:536,y:620,t:1527267287333};\\\", \\\"{x:541,y:620,t:1527267287348};\\\", \\\"{x:546,y:620,t:1527267287365};\\\", \\\"{x:550,y:620,t:1527267287382};\\\", \\\"{x:552,y:620,t:1527267287399};\\\", \\\"{x:556,y:622,t:1527267287415};\\\", \\\"{x:564,y:623,t:1527267287432};\\\", \\\"{x:570,y:623,t:1527267287448};\\\", \\\"{x:575,y:624,t:1527267287465};\\\", \\\"{x:577,y:624,t:1527267287482};\\\", \\\"{x:578,y:624,t:1527267287499};\\\", \\\"{x:580,y:625,t:1527267287537};\\\", \\\"{x:582,y:625,t:1527267287601};\\\", \\\"{x:584,y:625,t:1527267287616};\\\", \\\"{x:586,y:625,t:1527267287633};\\\", \\\"{x:589,y:625,t:1527267287649};\\\", \\\"{x:592,y:624,t:1527267287665};\\\", \\\"{x:594,y:623,t:1527267287682};\\\", \\\"{x:595,y:622,t:1527267287699};\\\", \\\"{x:596,y:622,t:1527267287715};\\\", \\\"{x:598,y:622,t:1527267287733};\\\", \\\"{x:600,y:620,t:1527267287750};\\\", \\\"{x:601,y:620,t:1527267287766};\\\", \\\"{x:602,y:619,t:1527267287782};\\\", \\\"{x:603,y:619,t:1527267287801};\\\", \\\"{x:605,y:618,t:1527267287816};\\\", \\\"{x:606,y:617,t:1527267287832};\\\", \\\"{x:607,y:616,t:1527267287850};\\\", \\\"{x:608,y:616,t:1527267288080};\\\", \\\"{x:608,y:619,t:1527267288088};\\\", \\\"{x:607,y:622,t:1527267288098};\\\", \\\"{x:604,y:630,t:1527267288117};\\\", \\\"{x:598,y:639,t:1527267288134};\\\", \\\"{x:593,y:648,t:1527267288149};\\\", \\\"{x:587,y:656,t:1527267288166};\\\", \\\"{x:582,y:666,t:1527267288182};\\\", \\\"{x:574,y:677,t:1527267288199};\\\", \\\"{x:563,y:690,t:1527267288216};\\\", \\\"{x:558,y:696,t:1527267288233};\\\", \\\"{x:555,y:700,t:1527267288249};\\\", \\\"{x:550,y:704,t:1527267288266};\\\", \\\"{x:543,y:709,t:1527267288283};\\\", \\\"{x:532,y:718,t:1527267288300};\\\", \\\"{x:525,y:723,t:1527267288316};\\\", \\\"{x:520,y:727,t:1527267288333};\\\", \\\"{x:519,y:728,t:1527267288352};\\\", \\\"{x:519,y:729,t:1527267288809};\\\", \\\"{x:527,y:731,t:1527267288816};\\\", \\\"{x:565,y:733,t:1527267288833};\\\", \\\"{x:618,y:733,t:1527267288850};\\\", \\\"{x:669,y:737,t:1527267288866};\\\", \\\"{x:695,y:737,t:1527267288883};\\\", \\\"{x:711,y:737,t:1527267288900};\\\", \\\"{x:717,y:737,t:1527267288917};\\\", \\\"{x:718,y:737,t:1527267288934};\\\", \\\"{x:719,y:737,t:1527267288950};\\\" ] }, { \\\"rt\\\": 11594, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 271307, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:704,y:737,t:1527267291737};\\\", \\\"{x:634,y:737,t:1527267291753};\\\", \\\"{x:565,y:729,t:1527267291769};\\\", \\\"{x:483,y:712,t:1527267291786};\\\", \\\"{x:417,y:695,t:1527267291803};\\\", \\\"{x:363,y:670,t:1527267291820};\\\", \\\"{x:321,y:638,t:1527267291835};\\\", \\\"{x:289,y:602,t:1527267291853};\\\", \\\"{x:269,y:569,t:1527267291869};\\\", \\\"{x:266,y:553,t:1527267291886};\\\", \\\"{x:266,y:542,t:1527267291902};\\\", \\\"{x:275,y:528,t:1527267291918};\\\", \\\"{x:279,y:523,t:1527267291936};\\\", \\\"{x:282,y:517,t:1527267291952};\\\", \\\"{x:286,y:511,t:1527267291969};\\\", \\\"{x:290,y:504,t:1527267291985};\\\", \\\"{x:296,y:497,t:1527267292002};\\\", \\\"{x:302,y:492,t:1527267292019};\\\", \\\"{x:306,y:489,t:1527267292035};\\\", \\\"{x:309,y:489,t:1527267292052};\\\", \\\"{x:310,y:489,t:1527267292068};\\\", \\\"{x:312,y:489,t:1527267292088};\\\", \\\"{x:314,y:489,t:1527267292104};\\\", \\\"{x:317,y:488,t:1527267292119};\\\", \\\"{x:323,y:488,t:1527267292135};\\\", \\\"{x:335,y:485,t:1527267292152};\\\", \\\"{x:371,y:484,t:1527267292168};\\\", \\\"{x:399,y:484,t:1527267292186};\\\", \\\"{x:430,y:484,t:1527267292202};\\\", \\\"{x:460,y:484,t:1527267292219};\\\", \\\"{x:485,y:484,t:1527267292235};\\\", \\\"{x:501,y:484,t:1527267292252};\\\", \\\"{x:515,y:484,t:1527267292270};\\\", \\\"{x:528,y:481,t:1527267292286};\\\", \\\"{x:546,y:479,t:1527267292303};\\\", \\\"{x:558,y:479,t:1527267292320};\\\", \\\"{x:571,y:479,t:1527267292336};\\\", \\\"{x:578,y:479,t:1527267292352};\\\", \\\"{x:579,y:479,t:1527267292401};\\\", \\\"{x:582,y:479,t:1527267292521};\\\", \\\"{x:585,y:479,t:1527267292536};\\\", \\\"{x:601,y:479,t:1527267292552};\\\", \\\"{x:616,y:479,t:1527267292569};\\\", \\\"{x:634,y:479,t:1527267292585};\\\", \\\"{x:645,y:479,t:1527267292602};\\\", \\\"{x:649,y:479,t:1527267292620};\\\", \\\"{x:654,y:479,t:1527267293001};\\\", \\\"{x:665,y:483,t:1527267293009};\\\", \\\"{x:674,y:489,t:1527267293021};\\\", \\\"{x:693,y:500,t:1527267293036};\\\", \\\"{x:722,y:518,t:1527267293053};\\\", \\\"{x:747,y:533,t:1527267293069};\\\", \\\"{x:770,y:542,t:1527267293086};\\\", \\\"{x:796,y:551,t:1527267293103};\\\", \\\"{x:839,y:562,t:1527267293121};\\\", \\\"{x:870,y:571,t:1527267293136};\\\", \\\"{x:899,y:581,t:1527267293153};\\\", \\\"{x:921,y:586,t:1527267293170};\\\", \\\"{x:934,y:587,t:1527267293186};\\\", \\\"{x:944,y:588,t:1527267293203};\\\", \\\"{x:954,y:589,t:1527267293221};\\\", \\\"{x:969,y:591,t:1527267293236};\\\", \\\"{x:986,y:593,t:1527267293254};\\\", \\\"{x:1003,y:596,t:1527267293270};\\\", \\\"{x:1017,y:597,t:1527267293287};\\\", \\\"{x:1031,y:597,t:1527267293304};\\\", \\\"{x:1049,y:601,t:1527267293319};\\\", \\\"{x:1074,y:604,t:1527267293337};\\\", \\\"{x:1088,y:604,t:1527267293353};\\\", \\\"{x:1097,y:604,t:1527267293369};\\\", \\\"{x:1109,y:605,t:1527267293387};\\\", \\\"{x:1124,y:605,t:1527267293404};\\\", \\\"{x:1146,y:605,t:1527267293420};\\\", \\\"{x:1173,y:605,t:1527267293437};\\\", \\\"{x:1196,y:605,t:1527267293454};\\\", \\\"{x:1211,y:605,t:1527267293470};\\\", \\\"{x:1218,y:605,t:1527267293487};\\\", \\\"{x:1220,y:603,t:1527267293504};\\\", \\\"{x:1221,y:603,t:1527267293520};\\\", \\\"{x:1221,y:602,t:1527267293610};\\\", \\\"{x:1221,y:600,t:1527267293620};\\\", \\\"{x:1222,y:599,t:1527267293636};\\\", \\\"{x:1225,y:597,t:1527267293652};\\\", \\\"{x:1233,y:594,t:1527267293669};\\\", \\\"{x:1249,y:584,t:1527267293686};\\\", \\\"{x:1265,y:576,t:1527267293702};\\\", \\\"{x:1284,y:569,t:1527267293719};\\\", \\\"{x:1303,y:563,t:1527267293736};\\\", \\\"{x:1307,y:561,t:1527267293753};\\\", \\\"{x:1308,y:560,t:1527267293769};\\\", \\\"{x:1309,y:560,t:1527267293801};\\\", \\\"{x:1307,y:560,t:1527267293929};\\\", \\\"{x:1303,y:562,t:1527267293937};\\\", \\\"{x:1296,y:567,t:1527267293954};\\\", \\\"{x:1287,y:574,t:1527267293971};\\\", \\\"{x:1285,y:574,t:1527267293986};\\\", \\\"{x:1281,y:575,t:1527267294003};\\\", \\\"{x:1279,y:576,t:1527267294020};\\\", \\\"{x:1277,y:576,t:1527267294036};\\\", \\\"{x:1281,y:576,t:1527267294273};\\\", \\\"{x:1286,y:578,t:1527267294286};\\\", \\\"{x:1296,y:578,t:1527267294303};\\\", \\\"{x:1311,y:578,t:1527267294319};\\\", \\\"{x:1323,y:578,t:1527267294335};\\\", \\\"{x:1334,y:578,t:1527267294353};\\\", \\\"{x:1338,y:577,t:1527267294369};\\\", \\\"{x:1340,y:577,t:1527267294386};\\\", \\\"{x:1343,y:577,t:1527267294402};\\\", \\\"{x:1345,y:577,t:1527267294418};\\\", \\\"{x:1349,y:577,t:1527267294435};\\\", \\\"{x:1353,y:577,t:1527267294452};\\\", \\\"{x:1359,y:577,t:1527267294468};\\\", \\\"{x:1364,y:577,t:1527267294486};\\\", \\\"{x:1370,y:576,t:1527267294503};\\\", \\\"{x:1374,y:575,t:1527267294519};\\\", \\\"{x:1377,y:574,t:1527267294536};\\\", \\\"{x:1380,y:574,t:1527267294553};\\\", \\\"{x:1381,y:574,t:1527267294569};\\\", \\\"{x:1382,y:574,t:1527267294586};\\\", \\\"{x:1383,y:574,t:1527267294819};\\\", \\\"{x:1384,y:574,t:1527267294835};\\\", \\\"{x:1385,y:574,t:1527267294851};\\\", \\\"{x:1387,y:574,t:1527267294869};\\\", \\\"{x:1390,y:573,t:1527267294885};\\\", \\\"{x:1393,y:573,t:1527267294901};\\\", \\\"{x:1395,y:573,t:1527267294919};\\\", \\\"{x:1398,y:571,t:1527267294935};\\\", \\\"{x:1400,y:571,t:1527267294951};\\\", \\\"{x:1403,y:569,t:1527267294969};\\\", \\\"{x:1406,y:568,t:1527267294985};\\\", \\\"{x:1408,y:567,t:1527267295001};\\\", \\\"{x:1411,y:567,t:1527267295020};\\\", \\\"{x:1413,y:566,t:1527267295034};\\\", \\\"{x:1414,y:566,t:1527267295051};\\\", \\\"{x:1416,y:566,t:1527267295069};\\\", \\\"{x:1416,y:565,t:1527267295084};\\\", \\\"{x:1418,y:564,t:1527267295101};\\\", \\\"{x:1419,y:564,t:1527267295137};\\\", \\\"{x:1418,y:565,t:1527267296249};\\\", \\\"{x:1412,y:569,t:1527267296258};\\\", \\\"{x:1404,y:578,t:1527267296268};\\\", \\\"{x:1392,y:595,t:1527267296284};\\\", \\\"{x:1381,y:607,t:1527267296301};\\\", \\\"{x:1366,y:624,t:1527267296317};\\\", \\\"{x:1349,y:642,t:1527267296334};\\\", \\\"{x:1331,y:656,t:1527267296351};\\\", \\\"{x:1314,y:670,t:1527267296367};\\\", \\\"{x:1288,y:677,t:1527267296385};\\\", \\\"{x:1254,y:687,t:1527267296401};\\\", \\\"{x:1231,y:690,t:1527267296417};\\\", \\\"{x:1207,y:692,t:1527267296434};\\\", \\\"{x:1169,y:696,t:1527267296451};\\\", \\\"{x:1133,y:696,t:1527267296467};\\\", \\\"{x:1085,y:696,t:1527267296484};\\\", \\\"{x:1046,y:696,t:1527267296501};\\\", \\\"{x:1014,y:696,t:1527267296517};\\\", \\\"{x:994,y:696,t:1527267296534};\\\", \\\"{x:981,y:696,t:1527267296551};\\\", \\\"{x:971,y:696,t:1527267296567};\\\", \\\"{x:956,y:696,t:1527267296584};\\\", \\\"{x:933,y:696,t:1527267296601};\\\", \\\"{x:918,y:696,t:1527267296617};\\\", \\\"{x:895,y:696,t:1527267296634};\\\", \\\"{x:866,y:696,t:1527267296650};\\\", \\\"{x:823,y:696,t:1527267296667};\\\", \\\"{x:764,y:696,t:1527267296684};\\\", \\\"{x:719,y:696,t:1527267296700};\\\", \\\"{x:679,y:703,t:1527267296716};\\\", \\\"{x:650,y:706,t:1527267296733};\\\", \\\"{x:626,y:706,t:1527267296749};\\\", \\\"{x:607,y:706,t:1527267296767};\\\", \\\"{x:590,y:702,t:1527267296784};\\\", \\\"{x:583,y:700,t:1527267296800};\\\", \\\"{x:582,y:699,t:1527267296818};\\\", \\\"{x:582,y:687,t:1527267296835};\\\", \\\"{x:582,y:669,t:1527267296850};\\\", \\\"{x:582,y:650,t:1527267296867};\\\", \\\"{x:582,y:640,t:1527267296884};\\\", \\\"{x:585,y:626,t:1527267296901};\\\", \\\"{x:597,y:608,t:1527267296916};\\\", \\\"{x:606,y:597,t:1527267296933};\\\", \\\"{x:618,y:583,t:1527267296957};\\\", \\\"{x:626,y:578,t:1527267296974};\\\", \\\"{x:639,y:570,t:1527267296989};\\\", \\\"{x:653,y:564,t:1527267297007};\\\", \\\"{x:661,y:560,t:1527267297023};\\\", \\\"{x:668,y:557,t:1527267297040};\\\", \\\"{x:675,y:554,t:1527267297057};\\\", \\\"{x:677,y:554,t:1527267297074};\\\", \\\"{x:681,y:552,t:1527267297090};\\\", \\\"{x:687,y:550,t:1527267297106};\\\", \\\"{x:696,y:546,t:1527267297122};\\\", \\\"{x:705,y:542,t:1527267297140};\\\", \\\"{x:707,y:542,t:1527267297156};\\\", \\\"{x:708,y:541,t:1527267297172};\\\", \\\"{x:706,y:540,t:1527267297208};\\\", \\\"{x:703,y:540,t:1527267297223};\\\", \\\"{x:694,y:539,t:1527267297240};\\\", \\\"{x:678,y:535,t:1527267297257};\\\", \\\"{x:669,y:532,t:1527267297272};\\\", \\\"{x:661,y:530,t:1527267297289};\\\", \\\"{x:655,y:529,t:1527267297306};\\\", \\\"{x:648,y:528,t:1527267297322};\\\", \\\"{x:641,y:525,t:1527267297340};\\\", \\\"{x:639,y:525,t:1527267297356};\\\", \\\"{x:638,y:524,t:1527267297374};\\\", \\\"{x:637,y:523,t:1527267297391};\\\", \\\"{x:636,y:523,t:1527267297407};\\\", \\\"{x:636,y:522,t:1527267297424};\\\", \\\"{x:628,y:519,t:1527267297440};\\\", \\\"{x:624,y:518,t:1527267297457};\\\", \\\"{x:617,y:515,t:1527267297474};\\\", \\\"{x:612,y:514,t:1527267297491};\\\", \\\"{x:609,y:513,t:1527267297507};\\\", \\\"{x:606,y:511,t:1527267297524};\\\", \\\"{x:605,y:511,t:1527267297540};\\\", \\\"{x:604,y:510,t:1527267297568};\\\", \\\"{x:603,y:510,t:1527267297576};\\\", \\\"{x:603,y:509,t:1527267297591};\\\", \\\"{x:602,y:508,t:1527267297607};\\\", \\\"{x:601,y:508,t:1527267297904};\\\", \\\"{x:597,y:508,t:1527267297912};\\\", \\\"{x:590,y:509,t:1527267297923};\\\", \\\"{x:579,y:515,t:1527267297941};\\\", \\\"{x:573,y:518,t:1527267297958};\\\", \\\"{x:567,y:518,t:1527267297973};\\\", \\\"{x:556,y:519,t:1527267297991};\\\", \\\"{x:538,y:523,t:1527267298008};\\\", \\\"{x:502,y:531,t:1527267298024};\\\", \\\"{x:356,y:551,t:1527267298041};\\\", \\\"{x:257,y:562,t:1527267298058};\\\", \\\"{x:179,y:562,t:1527267298074};\\\", \\\"{x:122,y:567,t:1527267298091};\\\", \\\"{x:81,y:574,t:1527267298108};\\\", \\\"{x:66,y:575,t:1527267298123};\\\", \\\"{x:60,y:576,t:1527267298140};\\\", \\\"{x:59,y:576,t:1527267298157};\\\", \\\"{x:59,y:577,t:1527267298289};\\\", \\\"{x:65,y:577,t:1527267298297};\\\", \\\"{x:79,y:577,t:1527267298308};\\\", \\\"{x:103,y:578,t:1527267298325};\\\", \\\"{x:126,y:579,t:1527267298341};\\\", \\\"{x:156,y:585,t:1527267298359};\\\", \\\"{x:187,y:590,t:1527267298374};\\\", \\\"{x:212,y:597,t:1527267298391};\\\", \\\"{x:237,y:604,t:1527267298408};\\\", \\\"{x:269,y:611,t:1527267298424};\\\", \\\"{x:283,y:613,t:1527267298441};\\\", \\\"{x:291,y:614,t:1527267298457};\\\", \\\"{x:296,y:616,t:1527267298474};\\\", \\\"{x:300,y:617,t:1527267298491};\\\", \\\"{x:303,y:620,t:1527267298507};\\\", \\\"{x:306,y:623,t:1527267298524};\\\", \\\"{x:308,y:625,t:1527267298541};\\\", \\\"{x:310,y:627,t:1527267298559};\\\", \\\"{x:311,y:629,t:1527267298574};\\\", \\\"{x:311,y:633,t:1527267298592};\\\", \\\"{x:314,y:649,t:1527267298609};\\\", \\\"{x:316,y:665,t:1527267298625};\\\", \\\"{x:319,y:690,t:1527267298654};\\\", \\\"{x:318,y:694,t:1527267298657};\\\", \\\"{x:310,y:709,t:1527267298675};\\\", \\\"{x:304,y:720,t:1527267298691};\\\", \\\"{x:304,y:724,t:1527267298707};\\\", \\\"{x:307,y:724,t:1527267298768};\\\", \\\"{x:310,y:724,t:1527267298776};\\\", \\\"{x:314,y:724,t:1527267298792};\\\", \\\"{x:327,y:721,t:1527267298807};\\\", \\\"{x:354,y:713,t:1527267298825};\\\", \\\"{x:376,y:706,t:1527267298841};\\\", \\\"{x:400,y:699,t:1527267298858};\\\", \\\"{x:425,y:693,t:1527267298875};\\\", \\\"{x:454,y:687,t:1527267298891};\\\", \\\"{x:479,y:683,t:1527267298909};\\\", \\\"{x:498,y:679,t:1527267298924};\\\", \\\"{x:514,y:677,t:1527267298942};\\\", \\\"{x:528,y:674,t:1527267298958};\\\", \\\"{x:539,y:673,t:1527267298975};\\\", \\\"{x:554,y:673,t:1527267298991};\\\", \\\"{x:594,y:672,t:1527267299008};\\\", \\\"{x:616,y:671,t:1527267299026};\\\", \\\"{x:630,y:668,t:1527267299042};\\\", \\\"{x:639,y:667,t:1527267299059};\\\", \\\"{x:644,y:666,t:1527267299076};\\\", \\\"{x:645,y:666,t:1527267299096};\\\", \\\"{x:646,y:666,t:1527267299109};\\\", \\\"{x:647,y:665,t:1527267299126};\\\", \\\"{x:649,y:664,t:1527267299142};\\\", \\\"{x:655,y:663,t:1527267299158};\\\", \\\"{x:673,y:658,t:1527267299176};\\\", \\\"{x:709,y:653,t:1527267299193};\\\", \\\"{x:732,y:646,t:1527267299209};\\\", \\\"{x:747,y:641,t:1527267299225};\\\", \\\"{x:755,y:636,t:1527267299242};\\\", \\\"{x:761,y:633,t:1527267299268};\\\", \\\"{x:762,y:633,t:1527267299275};\\\", \\\"{x:763,y:631,t:1527267299293};\\\", \\\"{x:763,y:630,t:1527267299336};\\\", \\\"{x:763,y:628,t:1527267299343};\\\", \\\"{x:764,y:628,t:1527267299359};\\\", \\\"{x:767,y:624,t:1527267299375};\\\", \\\"{x:769,y:620,t:1527267299392};\\\", \\\"{x:775,y:616,t:1527267299409};\\\", \\\"{x:779,y:612,t:1527267299425};\\\", \\\"{x:782,y:607,t:1527267299442};\\\", \\\"{x:786,y:601,t:1527267299458};\\\", \\\"{x:795,y:591,t:1527267299476};\\\", \\\"{x:804,y:584,t:1527267299492};\\\", \\\"{x:809,y:576,t:1527267299509};\\\", \\\"{x:812,y:572,t:1527267299525};\\\", \\\"{x:813,y:571,t:1527267299541};\\\", \\\"{x:814,y:570,t:1527267299576};\\\", \\\"{x:814,y:569,t:1527267299591};\\\", \\\"{x:818,y:563,t:1527267299608};\\\", \\\"{x:821,y:559,t:1527267299626};\\\", \\\"{x:821,y:558,t:1527267299641};\\\", \\\"{x:822,y:556,t:1527267299659};\\\", \\\"{x:825,y:552,t:1527267299676};\\\", \\\"{x:828,y:549,t:1527267299692};\\\", \\\"{x:831,y:545,t:1527267299709};\\\", \\\"{x:833,y:541,t:1527267299725};\\\", \\\"{x:836,y:537,t:1527267299741};\\\", \\\"{x:836,y:541,t:1527267299976};\\\", \\\"{x:826,y:557,t:1527267299992};\\\", \\\"{x:811,y:580,t:1527267300009};\\\", \\\"{x:789,y:608,t:1527267300026};\\\", \\\"{x:763,y:632,t:1527267300043};\\\", \\\"{x:742,y:645,t:1527267300059};\\\", \\\"{x:729,y:655,t:1527267300075};\\\", \\\"{x:718,y:660,t:1527267300092};\\\", \\\"{x:708,y:665,t:1527267300109};\\\", \\\"{x:699,y:669,t:1527267300126};\\\", \\\"{x:695,y:672,t:1527267300142};\\\", \\\"{x:684,y:680,t:1527267300159};\\\", \\\"{x:670,y:688,t:1527267300175};\\\", \\\"{x:649,y:693,t:1527267300192};\\\", \\\"{x:617,y:701,t:1527267300208};\\\", \\\"{x:604,y:704,t:1527267300226};\\\", \\\"{x:591,y:706,t:1527267300242};\\\", \\\"{x:581,y:708,t:1527267300259};\\\", \\\"{x:571,y:709,t:1527267300275};\\\", \\\"{x:560,y:710,t:1527267300292};\\\", \\\"{x:545,y:715,t:1527267300309};\\\", \\\"{x:528,y:719,t:1527267300325};\\\", \\\"{x:511,y:724,t:1527267300343};\\\", \\\"{x:497,y:726,t:1527267300358};\\\", \\\"{x:489,y:727,t:1527267300376};\\\", \\\"{x:486,y:728,t:1527267300393};\\\", \\\"{x:485,y:729,t:1527267300409};\\\", \\\"{x:491,y:729,t:1527267301817};\\\", \\\"{x:503,y:731,t:1527267301827};\\\", \\\"{x:515,y:737,t:1527267301844};\\\", \\\"{x:523,y:740,t:1527267301861};\\\", \\\"{x:532,y:743,t:1527267301877};\\\", \\\"{x:537,y:744,t:1527267301894};\\\", \\\"{x:539,y:744,t:1527267301911};\\\", \\\"{x:542,y:744,t:1527267301927};\\\", \\\"{x:544,y:744,t:1527267301944};\\\", \\\"{x:545,y:744,t:1527267301961};\\\" ] }, { \\\"rt\\\": 22681, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 295235, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -B -B -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:734,t:1527267303832};\\\", \\\"{x:536,y:720,t:1527267303847};\\\", \\\"{x:524,y:686,t:1527267303865};\\\", \\\"{x:512,y:657,t:1527267303880};\\\", \\\"{x:503,y:634,t:1527267303896};\\\", \\\"{x:497,y:618,t:1527267303913};\\\", \\\"{x:492,y:608,t:1527267303929};\\\", \\\"{x:487,y:596,t:1527267303947};\\\", \\\"{x:484,y:589,t:1527267303963};\\\", \\\"{x:481,y:583,t:1527267303979};\\\", \\\"{x:478,y:578,t:1527267303995};\\\", \\\"{x:473,y:571,t:1527267304011};\\\", \\\"{x:467,y:562,t:1527267304030};\\\", \\\"{x:464,y:559,t:1527267304045};\\\", \\\"{x:463,y:558,t:1527267304062};\\\", \\\"{x:459,y:554,t:1527267304080};\\\", \\\"{x:452,y:551,t:1527267304095};\\\", \\\"{x:441,y:544,t:1527267304112};\\\", \\\"{x:428,y:537,t:1527267304129};\\\", \\\"{x:418,y:530,t:1527267304146};\\\", \\\"{x:411,y:524,t:1527267304163};\\\", \\\"{x:395,y:514,t:1527267304180};\\\", \\\"{x:380,y:508,t:1527267304196};\\\", \\\"{x:370,y:504,t:1527267304213};\\\", \\\"{x:369,y:503,t:1527267304228};\\\", \\\"{x:368,y:502,t:1527267304246};\\\", \\\"{x:365,y:499,t:1527267304263};\\\", \\\"{x:363,y:496,t:1527267304278};\\\", \\\"{x:359,y:490,t:1527267304296};\\\", \\\"{x:359,y:489,t:1527267304312};\\\", \\\"{x:358,y:489,t:1527267304336};\\\", \\\"{x:358,y:488,t:1527267304352};\\\", \\\"{x:358,y:487,t:1527267304363};\\\", \\\"{x:358,y:486,t:1527267304409};\\\", \\\"{x:358,y:485,t:1527267304416};\\\", \\\"{x:358,y:483,t:1527267304432};\\\", \\\"{x:358,y:481,t:1527267304446};\\\", \\\"{x:358,y:477,t:1527267304463};\\\", \\\"{x:360,y:476,t:1527267304479};\\\", \\\"{x:362,y:473,t:1527267304495};\\\", \\\"{x:364,y:472,t:1527267304512};\\\", \\\"{x:365,y:472,t:1527267304536};\\\", \\\"{x:366,y:472,t:1527267304546};\\\", \\\"{x:368,y:471,t:1527267304584};\\\", \\\"{x:369,y:470,t:1527267304600};\\\", \\\"{x:372,y:470,t:1527267304613};\\\", \\\"{x:381,y:469,t:1527267304629};\\\", \\\"{x:390,y:469,t:1527267304646};\\\", \\\"{x:404,y:469,t:1527267304663};\\\", \\\"{x:425,y:469,t:1527267304680};\\\", \\\"{x:432,y:469,t:1527267304696};\\\", \\\"{x:437,y:469,t:1527267304712};\\\", \\\"{x:441,y:469,t:1527267304730};\\\", \\\"{x:444,y:469,t:1527267304746};\\\", \\\"{x:445,y:469,t:1527267304763};\\\", \\\"{x:446,y:469,t:1527267304780};\\\", \\\"{x:447,y:469,t:1527267305241};\\\", \\\"{x:452,y:469,t:1527267305321};\\\", \\\"{x:465,y:469,t:1527267305331};\\\", \\\"{x:490,y:469,t:1527267305348};\\\", \\\"{x:516,y:469,t:1527267305363};\\\", \\\"{x:539,y:469,t:1527267305381};\\\", \\\"{x:549,y:469,t:1527267305397};\\\", \\\"{x:551,y:469,t:1527267305414};\\\", \\\"{x:551,y:470,t:1527267307080};\\\", \\\"{x:547,y:476,t:1527267307087};\\\", \\\"{x:540,y:480,t:1527267307098};\\\", \\\"{x:522,y:486,t:1527267307114};\\\", \\\"{x:508,y:492,t:1527267307132};\\\", \\\"{x:491,y:495,t:1527267307148};\\\", \\\"{x:478,y:496,t:1527267307165};\\\", \\\"{x:470,y:497,t:1527267307181};\\\", \\\"{x:454,y:497,t:1527267307198};\\\", \\\"{x:434,y:497,t:1527267307213};\\\", \\\"{x:414,y:499,t:1527267307231};\\\", \\\"{x:399,y:499,t:1527267307247};\\\", \\\"{x:392,y:499,t:1527267307265};\\\", \\\"{x:382,y:499,t:1527267307281};\\\", \\\"{x:368,y:498,t:1527267307299};\\\", \\\"{x:354,y:495,t:1527267307314};\\\", \\\"{x:345,y:493,t:1527267307331};\\\", \\\"{x:341,y:492,t:1527267307348};\\\", \\\"{x:338,y:491,t:1527267307365};\\\", \\\"{x:337,y:491,t:1527267307382};\\\", \\\"{x:335,y:490,t:1527267307397};\\\", \\\"{x:327,y:486,t:1527267307415};\\\", \\\"{x:309,y:477,t:1527267307432};\\\", \\\"{x:297,y:472,t:1527267307448};\\\", \\\"{x:293,y:471,t:1527267307465};\\\", \\\"{x:292,y:470,t:1527267307482};\\\", \\\"{x:291,y:470,t:1527267307504};\\\", \\\"{x:290,y:469,t:1527267307528};\\\", \\\"{x:291,y:469,t:1527267307640};\\\", \\\"{x:292,y:469,t:1527267307649};\\\", \\\"{x:295,y:469,t:1527267307664};\\\", \\\"{x:301,y:469,t:1527267307682};\\\", \\\"{x:307,y:469,t:1527267307699};\\\", \\\"{x:313,y:469,t:1527267307715};\\\", \\\"{x:317,y:469,t:1527267307732};\\\", \\\"{x:322,y:469,t:1527267307749};\\\", \\\"{x:331,y:469,t:1527267307765};\\\", \\\"{x:340,y:469,t:1527267307782};\\\", \\\"{x:353,y:469,t:1527267307799};\\\", \\\"{x:361,y:469,t:1527267307814};\\\", \\\"{x:370,y:469,t:1527267307832};\\\", \\\"{x:372,y:469,t:1527267307849};\\\", \\\"{x:373,y:469,t:1527267307867};\\\", \\\"{x:375,y:469,t:1527267307913};\\\", \\\"{x:377,y:469,t:1527267307920};\\\", \\\"{x:380,y:469,t:1527267307933};\\\", \\\"{x:389,y:469,t:1527267307949};\\\", \\\"{x:402,y:469,t:1527267307966};\\\", \\\"{x:414,y:469,t:1527267307982};\\\", \\\"{x:428,y:469,t:1527267308000};\\\", \\\"{x:454,y:469,t:1527267308017};\\\", \\\"{x:470,y:469,t:1527267308032};\\\", \\\"{x:479,y:469,t:1527267308049};\\\", \\\"{x:485,y:469,t:1527267308066};\\\", \\\"{x:489,y:468,t:1527267308082};\\\", \\\"{x:491,y:468,t:1527267308099};\\\", \\\"{x:493,y:468,t:1527267308116};\\\", \\\"{x:498,y:468,t:1527267308133};\\\", \\\"{x:502,y:468,t:1527267308149};\\\", \\\"{x:505,y:468,t:1527267308167};\\\", \\\"{x:510,y:467,t:1527267308183};\\\", \\\"{x:513,y:467,t:1527267308200};\\\", \\\"{x:517,y:467,t:1527267308216};\\\", \\\"{x:521,y:467,t:1527267308232};\\\", \\\"{x:524,y:467,t:1527267308250};\\\", \\\"{x:528,y:467,t:1527267308266};\\\", \\\"{x:529,y:467,t:1527267308361};\\\", \\\"{x:530,y:467,t:1527267308385};\\\", \\\"{x:531,y:467,t:1527267308416};\\\", \\\"{x:533,y:467,t:1527267308433};\\\", \\\"{x:543,y:467,t:1527267308450};\\\", \\\"{x:558,y:467,t:1527267308466};\\\", \\\"{x:571,y:467,t:1527267308483};\\\", \\\"{x:580,y:467,t:1527267308500};\\\", \\\"{x:584,y:467,t:1527267308515};\\\", \\\"{x:585,y:467,t:1527267308533};\\\", \\\"{x:587,y:467,t:1527267308550};\\\", \\\"{x:588,y:467,t:1527267308649};\\\", \\\"{x:589,y:467,t:1527267308673};\\\", \\\"{x:591,y:467,t:1527267308683};\\\", \\\"{x:594,y:467,t:1527267308700};\\\", \\\"{x:595,y:467,t:1527267308717};\\\", \\\"{x:598,y:468,t:1527267308733};\\\", \\\"{x:602,y:468,t:1527267308750};\\\", \\\"{x:604,y:468,t:1527267308767};\\\", \\\"{x:605,y:468,t:1527267308784};\\\", \\\"{x:607,y:468,t:1527267308800};\\\", \\\"{x:615,y:469,t:1527267308817};\\\", \\\"{x:624,y:469,t:1527267308833};\\\", \\\"{x:637,y:469,t:1527267308850};\\\", \\\"{x:648,y:469,t:1527267308867};\\\", \\\"{x:658,y:469,t:1527267308883};\\\", \\\"{x:669,y:469,t:1527267308900};\\\", \\\"{x:687,y:469,t:1527267308917};\\\", \\\"{x:707,y:470,t:1527267308934};\\\", \\\"{x:724,y:470,t:1527267308951};\\\", \\\"{x:736,y:470,t:1527267308968};\\\", \\\"{x:738,y:470,t:1527267308984};\\\", \\\"{x:741,y:470,t:1527267309456};\\\", \\\"{x:764,y:470,t:1527267309468};\\\", \\\"{x:825,y:470,t:1527267309484};\\\", \\\"{x:914,y:470,t:1527267309500};\\\", \\\"{x:1028,y:470,t:1527267309518};\\\", \\\"{x:1147,y:470,t:1527267309534};\\\", \\\"{x:1269,y:470,t:1527267309550};\\\", \\\"{x:1421,y:470,t:1527267309567};\\\", \\\"{x:1502,y:470,t:1527267309584};\\\", \\\"{x:1552,y:470,t:1527267309600};\\\", \\\"{x:1581,y:470,t:1527267309617};\\\", \\\"{x:1592,y:467,t:1527267309635};\\\", \\\"{x:1595,y:467,t:1527267309650};\\\", \\\"{x:1596,y:467,t:1527267309776};\\\", \\\"{x:1596,y:468,t:1527267309791};\\\", \\\"{x:1594,y:471,t:1527267309801};\\\", \\\"{x:1593,y:471,t:1527267309840};\\\", \\\"{x:1593,y:472,t:1527267312025};\\\", \\\"{x:1590,y:476,t:1527267312039};\\\", \\\"{x:1584,y:480,t:1527267312054};\\\", \\\"{x:1577,y:483,t:1527267312071};\\\", \\\"{x:1565,y:491,t:1527267312088};\\\", \\\"{x:1561,y:494,t:1527267312104};\\\", \\\"{x:1560,y:495,t:1527267312122};\\\", \\\"{x:1559,y:496,t:1527267312138};\\\", \\\"{x:1558,y:497,t:1527267312184};\\\", \\\"{x:1557,y:498,t:1527267312200};\\\", \\\"{x:1556,y:498,t:1527267312208};\\\", \\\"{x:1556,y:499,t:1527267312221};\\\", \\\"{x:1552,y:502,t:1527267312238};\\\", \\\"{x:1550,y:503,t:1527267312255};\\\", \\\"{x:1546,y:508,t:1527267312272};\\\", \\\"{x:1536,y:518,t:1527267312288};\\\", \\\"{x:1529,y:526,t:1527267312305};\\\", \\\"{x:1520,y:535,t:1527267312321};\\\", \\\"{x:1511,y:543,t:1527267312338};\\\", \\\"{x:1501,y:554,t:1527267312356};\\\", \\\"{x:1495,y:561,t:1527267312372};\\\", \\\"{x:1487,y:569,t:1527267312388};\\\", \\\"{x:1478,y:575,t:1527267312405};\\\", \\\"{x:1470,y:583,t:1527267312421};\\\", \\\"{x:1463,y:588,t:1527267312438};\\\", \\\"{x:1459,y:592,t:1527267312455};\\\", \\\"{x:1454,y:596,t:1527267312472};\\\", \\\"{x:1450,y:599,t:1527267312488};\\\", \\\"{x:1448,y:601,t:1527267312506};\\\", \\\"{x:1445,y:605,t:1527267312522};\\\", \\\"{x:1442,y:608,t:1527267312539};\\\", \\\"{x:1439,y:612,t:1527267312555};\\\", \\\"{x:1434,y:617,t:1527267312573};\\\", \\\"{x:1428,y:621,t:1527267312588};\\\", \\\"{x:1421,y:629,t:1527267312605};\\\", \\\"{x:1417,y:631,t:1527267312623};\\\", \\\"{x:1414,y:634,t:1527267312638};\\\", \\\"{x:1413,y:634,t:1527267312655};\\\", \\\"{x:1412,y:634,t:1527267312672};\\\", \\\"{x:1410,y:635,t:1527267312688};\\\", \\\"{x:1410,y:636,t:1527267312712};\\\", \\\"{x:1409,y:637,t:1527267312744};\\\", \\\"{x:1409,y:639,t:1527267314217};\\\", \\\"{x:1406,y:643,t:1527267314225};\\\", \\\"{x:1401,y:649,t:1527267314240};\\\", \\\"{x:1399,y:653,t:1527267314258};\\\", \\\"{x:1397,y:657,t:1527267314275};\\\", \\\"{x:1395,y:660,t:1527267314291};\\\", \\\"{x:1393,y:664,t:1527267314308};\\\", \\\"{x:1392,y:666,t:1527267314325};\\\", \\\"{x:1390,y:671,t:1527267314342};\\\", \\\"{x:1386,y:676,t:1527267314358};\\\", \\\"{x:1380,y:683,t:1527267314375};\\\", \\\"{x:1377,y:686,t:1527267314392};\\\", \\\"{x:1374,y:688,t:1527267314407};\\\", \\\"{x:1373,y:692,t:1527267314424};\\\", \\\"{x:1372,y:692,t:1527267314441};\\\", \\\"{x:1371,y:695,t:1527267314457};\\\", \\\"{x:1371,y:697,t:1527267314474};\\\", \\\"{x:1369,y:702,t:1527267314491};\\\", \\\"{x:1368,y:708,t:1527267314507};\\\", \\\"{x:1367,y:715,t:1527267314524};\\\", \\\"{x:1364,y:719,t:1527267314541};\\\", \\\"{x:1364,y:722,t:1527267314558};\\\", \\\"{x:1363,y:724,t:1527267314575};\\\", \\\"{x:1361,y:728,t:1527267314592};\\\", \\\"{x:1360,y:732,t:1527267314608};\\\", \\\"{x:1358,y:738,t:1527267314625};\\\", \\\"{x:1357,y:741,t:1527267314642};\\\", \\\"{x:1355,y:743,t:1527267314659};\\\", \\\"{x:1354,y:747,t:1527267314674};\\\", \\\"{x:1353,y:748,t:1527267314692};\\\", \\\"{x:1351,y:751,t:1527267314709};\\\", \\\"{x:1349,y:754,t:1527267314724};\\\", \\\"{x:1348,y:757,t:1527267314741};\\\", \\\"{x:1347,y:758,t:1527267314759};\\\", \\\"{x:1345,y:761,t:1527267314774};\\\", \\\"{x:1344,y:762,t:1527267314791};\\\", \\\"{x:1343,y:764,t:1527267314809};\\\", \\\"{x:1342,y:765,t:1527267314825};\\\", \\\"{x:1341,y:767,t:1527267314841};\\\", \\\"{x:1340,y:769,t:1527267314858};\\\", \\\"{x:1338,y:771,t:1527267314876};\\\", \\\"{x:1338,y:772,t:1527267314891};\\\", \\\"{x:1337,y:774,t:1527267314909};\\\", \\\"{x:1337,y:776,t:1527267314926};\\\", \\\"{x:1335,y:777,t:1527267314942};\\\", \\\"{x:1334,y:778,t:1527267314959};\\\", \\\"{x:1330,y:786,t:1527267314977};\\\", \\\"{x:1327,y:791,t:1527267314991};\\\", \\\"{x:1321,y:805,t:1527267315008};\\\", \\\"{x:1318,y:811,t:1527267315026};\\\", \\\"{x:1316,y:813,t:1527267315041};\\\", \\\"{x:1314,y:815,t:1527267315059};\\\", \\\"{x:1313,y:817,t:1527267315076};\\\", \\\"{x:1312,y:818,t:1527267315092};\\\", \\\"{x:1312,y:817,t:1527267316065};\\\", \\\"{x:1312,y:815,t:1527267316077};\\\", \\\"{x:1312,y:813,t:1527267316094};\\\", \\\"{x:1316,y:808,t:1527267316110};\\\", \\\"{x:1320,y:801,t:1527267316128};\\\", \\\"{x:1328,y:791,t:1527267316144};\\\", \\\"{x:1336,y:782,t:1527267316161};\\\", \\\"{x:1340,y:775,t:1527267316177};\\\", \\\"{x:1346,y:765,t:1527267316194};\\\", \\\"{x:1347,y:760,t:1527267316211};\\\", \\\"{x:1351,y:753,t:1527267316228};\\\", \\\"{x:1355,y:743,t:1527267316244};\\\", \\\"{x:1356,y:737,t:1527267316261};\\\", \\\"{x:1357,y:733,t:1527267316277};\\\", \\\"{x:1359,y:729,t:1527267316294};\\\", \\\"{x:1361,y:724,t:1527267316311};\\\", \\\"{x:1362,y:719,t:1527267316328};\\\", \\\"{x:1362,y:715,t:1527267316344};\\\", \\\"{x:1363,y:709,t:1527267316361};\\\", \\\"{x:1363,y:706,t:1527267316378};\\\", \\\"{x:1363,y:705,t:1527267316394};\\\", \\\"{x:1363,y:704,t:1527267316411};\\\", \\\"{x:1363,y:703,t:1527267316432};\\\", \\\"{x:1363,y:701,t:1527267316444};\\\", \\\"{x:1363,y:697,t:1527267316461};\\\", \\\"{x:1363,y:693,t:1527267316478};\\\", \\\"{x:1363,y:691,t:1527267316494};\\\", \\\"{x:1362,y:689,t:1527267316511};\\\", \\\"{x:1361,y:689,t:1527267316528};\\\", \\\"{x:1359,y:690,t:1527267316665};\\\", \\\"{x:1359,y:692,t:1527267316737};\\\", \\\"{x:1359,y:693,t:1527267316753};\\\", \\\"{x:1358,y:696,t:1527267316761};\\\", \\\"{x:1358,y:698,t:1527267316778};\\\", \\\"{x:1357,y:700,t:1527267316795};\\\", \\\"{x:1357,y:702,t:1527267316811};\\\", \\\"{x:1357,y:703,t:1527267316828};\\\", \\\"{x:1357,y:706,t:1527267316845};\\\", \\\"{x:1357,y:709,t:1527267316861};\\\", \\\"{x:1357,y:713,t:1527267316878};\\\", \\\"{x:1357,y:717,t:1527267316894};\\\", \\\"{x:1357,y:720,t:1527267316911};\\\", \\\"{x:1357,y:723,t:1527267316927};\\\", \\\"{x:1357,y:727,t:1527267316944};\\\", \\\"{x:1356,y:729,t:1527267316961};\\\", \\\"{x:1356,y:731,t:1527267316977};\\\", \\\"{x:1356,y:733,t:1527267316995};\\\", \\\"{x:1356,y:736,t:1527267317012};\\\", \\\"{x:1356,y:738,t:1527267317032};\\\", \\\"{x:1356,y:739,t:1527267317048};\\\", \\\"{x:1356,y:740,t:1527267317064};\\\", \\\"{x:1355,y:741,t:1527267317078};\\\", \\\"{x:1355,y:742,t:1527267317095};\\\", \\\"{x:1355,y:744,t:1527267317111};\\\", \\\"{x:1355,y:746,t:1527267317127};\\\", \\\"{x:1354,y:747,t:1527267317145};\\\", \\\"{x:1354,y:748,t:1527267317162};\\\", \\\"{x:1354,y:749,t:1527267317179};\\\", \\\"{x:1354,y:751,t:1527267317194};\\\", \\\"{x:1354,y:753,t:1527267317212};\\\", \\\"{x:1354,y:755,t:1527267317229};\\\", \\\"{x:1354,y:757,t:1527267317245};\\\", \\\"{x:1354,y:761,t:1527267317261};\\\", \\\"{x:1354,y:763,t:1527267317279};\\\", \\\"{x:1354,y:765,t:1527267317295};\\\", \\\"{x:1355,y:766,t:1527267317312};\\\", \\\"{x:1355,y:767,t:1527267317328};\\\", \\\"{x:1355,y:768,t:1527267317369};\\\", \\\"{x:1355,y:767,t:1527267317657};\\\", \\\"{x:1355,y:766,t:1527267317665};\\\", \\\"{x:1355,y:765,t:1527267317680};\\\", \\\"{x:1355,y:764,t:1527267317696};\\\", \\\"{x:1354,y:761,t:1527267317713};\\\", \\\"{x:1353,y:760,t:1527267317729};\\\", \\\"{x:1353,y:759,t:1527267317746};\\\", \\\"{x:1353,y:758,t:1527267317769};\\\", \\\"{x:1353,y:757,t:1527267317779};\\\", \\\"{x:1353,y:756,t:1527267317796};\\\", \\\"{x:1353,y:755,t:1527267317817};\\\", \\\"{x:1353,y:754,t:1527267317829};\\\", \\\"{x:1353,y:753,t:1527267317846};\\\", \\\"{x:1353,y:752,t:1527267317864};\\\", \\\"{x:1353,y:751,t:1527267317879};\\\", \\\"{x:1353,y:750,t:1527267317896};\\\", \\\"{x:1353,y:749,t:1527267317953};\\\", \\\"{x:1353,y:748,t:1527267317978};\\\", \\\"{x:1353,y:747,t:1527267318001};\\\", \\\"{x:1353,y:746,t:1527267318041};\\\", \\\"{x:1353,y:745,t:1527267318049};\\\", \\\"{x:1353,y:744,t:1527267318063};\\\", \\\"{x:1353,y:743,t:1527267318080};\\\", \\\"{x:1353,y:740,t:1527267318096};\\\", \\\"{x:1353,y:737,t:1527267318113};\\\", \\\"{x:1353,y:733,t:1527267318130};\\\", \\\"{x:1353,y:729,t:1527267318147};\\\", \\\"{x:1353,y:726,t:1527267318163};\\\", \\\"{x:1354,y:722,t:1527267318180};\\\", \\\"{x:1354,y:720,t:1527267318197};\\\", \\\"{x:1354,y:717,t:1527267318214};\\\", \\\"{x:1354,y:715,t:1527267318230};\\\", \\\"{x:1354,y:714,t:1527267318247};\\\", \\\"{x:1354,y:713,t:1527267318297};\\\", \\\"{x:1354,y:712,t:1527267318313};\\\", \\\"{x:1354,y:711,t:1527267318330};\\\", \\\"{x:1354,y:710,t:1527267318347};\\\", \\\"{x:1354,y:709,t:1527267318362};\\\", \\\"{x:1354,y:708,t:1527267318401};\\\", \\\"{x:1354,y:707,t:1527267318425};\\\", \\\"{x:1354,y:706,t:1527267318441};\\\", \\\"{x:1354,y:705,t:1527267318456};\\\", \\\"{x:1354,y:704,t:1527267318497};\\\", \\\"{x:1354,y:703,t:1527267318514};\\\", \\\"{x:1354,y:702,t:1527267318530};\\\", \\\"{x:1355,y:702,t:1527267318547};\\\", \\\"{x:1355,y:701,t:1527267318565};\\\", \\\"{x:1355,y:700,t:1527267318600};\\\", \\\"{x:1356,y:702,t:1527267318721};\\\", \\\"{x:1357,y:707,t:1527267318731};\\\", \\\"{x:1358,y:719,t:1527267318747};\\\", \\\"{x:1361,y:733,t:1527267318764};\\\", \\\"{x:1362,y:740,t:1527267318781};\\\", \\\"{x:1363,y:746,t:1527267318797};\\\", \\\"{x:1364,y:749,t:1527267318814};\\\", \\\"{x:1364,y:753,t:1527267318831};\\\", \\\"{x:1364,y:758,t:1527267318847};\\\", \\\"{x:1365,y:764,t:1527267318864};\\\", \\\"{x:1365,y:774,t:1527267318881};\\\", \\\"{x:1365,y:779,t:1527267318897};\\\", \\\"{x:1366,y:780,t:1527267318914};\\\", \\\"{x:1366,y:781,t:1527267320193};\\\", \\\"{x:1357,y:783,t:1527267320201};\\\", \\\"{x:1354,y:784,t:1527267320216};\\\", \\\"{x:1345,y:785,t:1527267320233};\\\", \\\"{x:1338,y:785,t:1527267320249};\\\", \\\"{x:1328,y:785,t:1527267320266};\\\", \\\"{x:1313,y:785,t:1527267320283};\\\", \\\"{x:1280,y:785,t:1527267320299};\\\", \\\"{x:1269,y:785,t:1527267320316};\\\", \\\"{x:1247,y:785,t:1527267320333};\\\", \\\"{x:1207,y:784,t:1527267320350};\\\", \\\"{x:1193,y:782,t:1527267320366};\\\", \\\"{x:1172,y:778,t:1527267320383};\\\", \\\"{x:1154,y:776,t:1527267320399};\\\", \\\"{x:1138,y:773,t:1527267320416};\\\", \\\"{x:1106,y:768,t:1527267320433};\\\", \\\"{x:1058,y:759,t:1527267320449};\\\", \\\"{x:1008,y:752,t:1527267320467};\\\", \\\"{x:982,y:750,t:1527267320483};\\\", \\\"{x:945,y:750,t:1527267320501};\\\", \\\"{x:898,y:743,t:1527267320516};\\\", \\\"{x:863,y:736,t:1527267320532};\\\", \\\"{x:808,y:730,t:1527267320550};\\\", \\\"{x:751,y:720,t:1527267320566};\\\", \\\"{x:717,y:715,t:1527267320582};\\\", \\\"{x:680,y:705,t:1527267320599};\\\", \\\"{x:657,y:699,t:1527267320616};\\\", \\\"{x:649,y:697,t:1527267320632};\\\", \\\"{x:641,y:692,t:1527267320649};\\\", \\\"{x:636,y:688,t:1527267320666};\\\", \\\"{x:634,y:685,t:1527267320683};\\\", \\\"{x:630,y:678,t:1527267320700};\\\", \\\"{x:617,y:666,t:1527267320715};\\\", \\\"{x:594,y:649,t:1527267320732};\\\", \\\"{x:552,y:623,t:1527267320750};\\\", \\\"{x:505,y:594,t:1527267320767};\\\", \\\"{x:453,y:571,t:1527267320782};\\\", \\\"{x:372,y:547,t:1527267320803};\\\", \\\"{x:333,y:537,t:1527267320819};\\\", \\\"{x:290,y:525,t:1527267320842};\\\", \\\"{x:277,y:521,t:1527267320859};\\\", \\\"{x:275,y:519,t:1527267320876};\\\", \\\"{x:274,y:519,t:1527267320896};\\\", \\\"{x:273,y:518,t:1527267320909};\\\", \\\"{x:272,y:518,t:1527267320926};\\\", \\\"{x:271,y:517,t:1527267320968};\\\", \\\"{x:268,y:515,t:1527267320983};\\\", \\\"{x:267,y:515,t:1527267320993};\\\", \\\"{x:260,y:514,t:1527267321009};\\\", \\\"{x:249,y:514,t:1527267321026};\\\", \\\"{x:226,y:515,t:1527267321043};\\\", \\\"{x:185,y:528,t:1527267321061};\\\", \\\"{x:152,y:541,t:1527267321075};\\\", \\\"{x:136,y:547,t:1527267321092};\\\", \\\"{x:133,y:549,t:1527267321109};\\\", \\\"{x:133,y:552,t:1527267321233};\\\", \\\"{x:133,y:554,t:1527267321243};\\\", \\\"{x:134,y:559,t:1527267321260};\\\", \\\"{x:136,y:562,t:1527267321277};\\\", \\\"{x:143,y:564,t:1527267321294};\\\", \\\"{x:147,y:566,t:1527267321309};\\\", \\\"{x:154,y:570,t:1527267321327};\\\", \\\"{x:162,y:575,t:1527267321343};\\\", \\\"{x:174,y:582,t:1527267321360};\\\", \\\"{x:182,y:590,t:1527267321377};\\\", \\\"{x:191,y:601,t:1527267321394};\\\", \\\"{x:197,y:609,t:1527267321409};\\\", \\\"{x:198,y:612,t:1527267321427};\\\", \\\"{x:198,y:615,t:1527267321442};\\\", \\\"{x:198,y:617,t:1527267321459};\\\", \\\"{x:190,y:624,t:1527267321476};\\\", \\\"{x:180,y:627,t:1527267321493};\\\", \\\"{x:174,y:627,t:1527267321509};\\\", \\\"{x:167,y:627,t:1527267321527};\\\", \\\"{x:163,y:627,t:1527267321542};\\\", \\\"{x:162,y:627,t:1527267321560};\\\", \\\"{x:163,y:625,t:1527267321664};\\\", \\\"{x:170,y:624,t:1527267321677};\\\", \\\"{x:186,y:617,t:1527267321693};\\\", \\\"{x:205,y:612,t:1527267321709};\\\", \\\"{x:223,y:608,t:1527267321726};\\\", \\\"{x:239,y:605,t:1527267321743};\\\", \\\"{x:246,y:604,t:1527267321759};\\\", \\\"{x:253,y:603,t:1527267321776};\\\", \\\"{x:271,y:600,t:1527267321793};\\\", \\\"{x:289,y:598,t:1527267321809};\\\", \\\"{x:303,y:594,t:1527267321826};\\\", \\\"{x:310,y:592,t:1527267321843};\\\", \\\"{x:316,y:591,t:1527267321860};\\\", \\\"{x:321,y:590,t:1527267321877};\\\", \\\"{x:328,y:588,t:1527267321894};\\\", \\\"{x:331,y:587,t:1527267321910};\\\", \\\"{x:335,y:586,t:1527267321926};\\\", \\\"{x:337,y:585,t:1527267321944};\\\", \\\"{x:338,y:584,t:1527267321959};\\\", \\\"{x:342,y:582,t:1527267321976};\\\", \\\"{x:345,y:582,t:1527267321994};\\\", \\\"{x:349,y:579,t:1527267322009};\\\", \\\"{x:350,y:579,t:1527267322057};\\\", \\\"{x:355,y:578,t:1527267322073};\\\", \\\"{x:361,y:577,t:1527267322080};\\\", \\\"{x:367,y:574,t:1527267322093};\\\", \\\"{x:383,y:569,t:1527267322110};\\\", \\\"{x:395,y:564,t:1527267322127};\\\", \\\"{x:403,y:562,t:1527267322144};\\\", \\\"{x:408,y:560,t:1527267322160};\\\", \\\"{x:415,y:559,t:1527267322177};\\\", \\\"{x:421,y:557,t:1527267322194};\\\", \\\"{x:423,y:556,t:1527267322211};\\\", \\\"{x:427,y:554,t:1527267322228};\\\", \\\"{x:432,y:551,t:1527267322243};\\\", \\\"{x:438,y:549,t:1527267322260};\\\", \\\"{x:448,y:546,t:1527267322276};\\\", \\\"{x:460,y:544,t:1527267322294};\\\", \\\"{x:468,y:543,t:1527267322309};\\\", \\\"{x:479,y:543,t:1527267322326};\\\", \\\"{x:493,y:543,t:1527267322343};\\\", \\\"{x:507,y:543,t:1527267322361};\\\", \\\"{x:522,y:543,t:1527267322376};\\\", \\\"{x:540,y:544,t:1527267322394};\\\", \\\"{x:554,y:546,t:1527267322411};\\\", \\\"{x:566,y:547,t:1527267322427};\\\", \\\"{x:573,y:549,t:1527267322444};\\\", \\\"{x:583,y:550,t:1527267322460};\\\", \\\"{x:595,y:554,t:1527267322477};\\\", \\\"{x:605,y:557,t:1527267322494};\\\", \\\"{x:617,y:560,t:1527267322511};\\\", \\\"{x:630,y:560,t:1527267322527};\\\", \\\"{x:644,y:561,t:1527267322544};\\\", \\\"{x:651,y:561,t:1527267322560};\\\", \\\"{x:655,y:561,t:1527267322577};\\\", \\\"{x:661,y:560,t:1527267322594};\\\", \\\"{x:671,y:557,t:1527267322611};\\\", \\\"{x:683,y:550,t:1527267322628};\\\", \\\"{x:692,y:546,t:1527267322644};\\\", \\\"{x:706,y:539,t:1527267322660};\\\", \\\"{x:719,y:532,t:1527267322677};\\\", \\\"{x:735,y:526,t:1527267322694};\\\", \\\"{x:744,y:522,t:1527267322711};\\\", \\\"{x:755,y:519,t:1527267322728};\\\", \\\"{x:763,y:518,t:1527267322743};\\\", \\\"{x:766,y:516,t:1527267322761};\\\", \\\"{x:768,y:516,t:1527267322777};\\\", \\\"{x:772,y:516,t:1527267322793};\\\", \\\"{x:775,y:516,t:1527267322810};\\\", \\\"{x:781,y:516,t:1527267322828};\\\", \\\"{x:790,y:516,t:1527267322844};\\\", \\\"{x:796,y:517,t:1527267322860};\\\", \\\"{x:801,y:519,t:1527267322878};\\\", \\\"{x:803,y:519,t:1527267322894};\\\", \\\"{x:805,y:519,t:1527267322910};\\\", \\\"{x:810,y:516,t:1527267322928};\\\", \\\"{x:812,y:516,t:1527267322944};\\\", \\\"{x:813,y:515,t:1527267322961};\\\", \\\"{x:815,y:514,t:1527267322978};\\\", \\\"{x:816,y:513,t:1527267322994};\\\", \\\"{x:817,y:513,t:1527267323011};\\\", \\\"{x:818,y:511,t:1527267323028};\\\", \\\"{x:820,y:509,t:1527267323045};\\\", \\\"{x:822,y:508,t:1527267323072};\\\", \\\"{x:822,y:507,t:1527267323096};\\\", \\\"{x:823,y:507,t:1527267323112};\\\", \\\"{x:825,y:505,t:1527267323128};\\\", \\\"{x:826,y:504,t:1527267323146};\\\", \\\"{x:830,y:501,t:1527267323160};\\\", \\\"{x:832,y:499,t:1527267323177};\\\", \\\"{x:831,y:499,t:1527267323448};\\\", \\\"{x:829,y:500,t:1527267323460};\\\", \\\"{x:825,y:507,t:1527267323478};\\\", \\\"{x:821,y:515,t:1527267323494};\\\", \\\"{x:816,y:519,t:1527267323511};\\\", \\\"{x:807,y:531,t:1527267323528};\\\", \\\"{x:795,y:541,t:1527267323544};\\\", \\\"{x:780,y:550,t:1527267323561};\\\", \\\"{x:764,y:559,t:1527267323579};\\\", \\\"{x:748,y:568,t:1527267323595};\\\", \\\"{x:724,y:576,t:1527267323612};\\\", \\\"{x:695,y:585,t:1527267323628};\\\", \\\"{x:666,y:590,t:1527267323644};\\\", \\\"{x:617,y:597,t:1527267323663};\\\", \\\"{x:573,y:601,t:1527267323678};\\\", \\\"{x:531,y:601,t:1527267323695};\\\", \\\"{x:474,y:601,t:1527267323712};\\\", \\\"{x:450,y:601,t:1527267323728};\\\", \\\"{x:431,y:601,t:1527267323744};\\\", \\\"{x:419,y:597,t:1527267323763};\\\", \\\"{x:415,y:595,t:1527267323778};\\\", \\\"{x:413,y:594,t:1527267323795};\\\", \\\"{x:412,y:593,t:1527267323812};\\\", \\\"{x:411,y:591,t:1527267323829};\\\", \\\"{x:410,y:591,t:1527267323845};\\\", \\\"{x:410,y:588,t:1527267323862};\\\", \\\"{x:408,y:582,t:1527267323879};\\\", \\\"{x:405,y:577,t:1527267323895};\\\", \\\"{x:397,y:570,t:1527267323912};\\\", \\\"{x:390,y:568,t:1527267323928};\\\", \\\"{x:382,y:568,t:1527267323945};\\\", \\\"{x:371,y:568,t:1527267323962};\\\", \\\"{x:354,y:568,t:1527267323979};\\\", \\\"{x:334,y:568,t:1527267323994};\\\", \\\"{x:304,y:568,t:1527267324011};\\\", \\\"{x:264,y:568,t:1527267324029};\\\", \\\"{x:238,y:570,t:1527267324044};\\\", \\\"{x:223,y:570,t:1527267324061};\\\", \\\"{x:214,y:570,t:1527267324079};\\\", \\\"{x:211,y:570,t:1527267324095};\\\", \\\"{x:208,y:569,t:1527267324111};\\\", \\\"{x:207,y:568,t:1527267324129};\\\", \\\"{x:206,y:568,t:1527267324159};\\\", \\\"{x:204,y:568,t:1527267324168};\\\", \\\"{x:202,y:568,t:1527267324179};\\\", \\\"{x:197,y:565,t:1527267324194};\\\", \\\"{x:191,y:563,t:1527267324212};\\\", \\\"{x:188,y:561,t:1527267324229};\\\", \\\"{x:186,y:560,t:1527267324244};\\\", \\\"{x:184,y:558,t:1527267324262};\\\", \\\"{x:181,y:554,t:1527267324279};\\\", \\\"{x:177,y:551,t:1527267324295};\\\", \\\"{x:171,y:550,t:1527267324311};\\\", \\\"{x:166,y:550,t:1527267324329};\\\", \\\"{x:164,y:549,t:1527267324345};\\\", \\\"{x:162,y:548,t:1527267324361};\\\", \\\"{x:160,y:546,t:1527267324378};\\\", \\\"{x:159,y:545,t:1527267324396};\\\", \\\"{x:159,y:544,t:1527267324412};\\\", \\\"{x:167,y:543,t:1527267324736};\\\", \\\"{x:188,y:551,t:1527267324746};\\\", \\\"{x:239,y:567,t:1527267324764};\\\", \\\"{x:266,y:576,t:1527267324779};\\\", \\\"{x:298,y:589,t:1527267324796};\\\", \\\"{x:322,y:601,t:1527267324813};\\\", \\\"{x:342,y:610,t:1527267324829};\\\", \\\"{x:365,y:622,t:1527267324846};\\\", \\\"{x:392,y:641,t:1527267324864};\\\", \\\"{x:438,y:675,t:1527267324879};\\\", \\\"{x:495,y:724,t:1527267324897};\\\", \\\"{x:508,y:738,t:1527267324913};\\\", \\\"{x:512,y:743,t:1527267324929};\\\", \\\"{x:512,y:745,t:1527267324945};\\\", \\\"{x:512,y:748,t:1527267324963};\\\", \\\"{x:512,y:753,t:1527267324979};\\\", \\\"{x:512,y:755,t:1527267324996};\\\", \\\"{x:512,y:757,t:1527267325013};\\\", \\\"{x:512,y:758,t:1527267325029};\\\", \\\"{x:512,y:759,t:1527267325045};\\\", \\\"{x:511,y:756,t:1527267325120};\\\", \\\"{x:511,y:751,t:1527267325131};\\\", \\\"{x:511,y:749,t:1527267325146};\\\", \\\"{x:511,y:746,t:1527267325163};\\\", \\\"{x:511,y:743,t:1527267325179};\\\", \\\"{x:511,y:742,t:1527267325196};\\\", \\\"{x:511,y:741,t:1527267325213};\\\", \\\"{x:508,y:739,t:1527267325247};\\\", \\\"{x:506,y:737,t:1527267325264};\\\", \\\"{x:505,y:737,t:1527267325279};\\\", \\\"{x:509,y:736,t:1527267325624};\\\", \\\"{x:542,y:736,t:1527267325632};\\\", \\\"{x:589,y:736,t:1527267325646};\\\", \\\"{x:700,y:736,t:1527267325663};\\\", \\\"{x:904,y:736,t:1527267325680};\\\", \\\"{x:1023,y:736,t:1527267325696};\\\", \\\"{x:1112,y:736,t:1527267325713};\\\", \\\"{x:1159,y:734,t:1527267325729};\\\", \\\"{x:1168,y:732,t:1527267325747};\\\" ] }, { \\\"rt\\\": 32343, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 328854, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1164,y:728,t:1527267327272};\\\", \\\"{x:1155,y:725,t:1527267327281};\\\", \\\"{x:1090,y:714,t:1527267327298};\\\", \\\"{x:957,y:697,t:1527267327314};\\\", \\\"{x:841,y:678,t:1527267327331};\\\", \\\"{x:694,y:654,t:1527267327348};\\\", \\\"{x:567,y:625,t:1527267327365};\\\", \\\"{x:506,y:608,t:1527267327381};\\\", \\\"{x:482,y:604,t:1527267327399};\\\", \\\"{x:467,y:600,t:1527267327415};\\\", \\\"{x:465,y:600,t:1527267327431};\\\", \\\"{x:465,y:599,t:1527267327472};\\\", \\\"{x:464,y:599,t:1527267327481};\\\", \\\"{x:459,y:595,t:1527267327498};\\\", \\\"{x:451,y:584,t:1527267327516};\\\", \\\"{x:434,y:547,t:1527267327531};\\\", \\\"{x:412,y:513,t:1527267327548};\\\", \\\"{x:397,y:498,t:1527267327565};\\\", \\\"{x:383,y:489,t:1527267327581};\\\", \\\"{x:370,y:483,t:1527267327598};\\\", \\\"{x:353,y:481,t:1527267327614};\\\", \\\"{x:342,y:481,t:1527267327631};\\\", \\\"{x:332,y:481,t:1527267327648};\\\", \\\"{x:330,y:481,t:1527267327665};\\\", \\\"{x:325,y:481,t:1527267327681};\\\", \\\"{x:320,y:481,t:1527267327698};\\\", \\\"{x:317,y:481,t:1527267327715};\\\", \\\"{x:308,y:484,t:1527267327731};\\\", \\\"{x:300,y:488,t:1527267327748};\\\", \\\"{x:297,y:490,t:1527267327765};\\\", \\\"{x:296,y:491,t:1527267327791};\\\", \\\"{x:296,y:492,t:1527267327815};\\\", \\\"{x:300,y:492,t:1527267327832};\\\", \\\"{x:308,y:490,t:1527267327848};\\\", \\\"{x:314,y:489,t:1527267327864};\\\", \\\"{x:320,y:487,t:1527267327882};\\\", \\\"{x:329,y:486,t:1527267327900};\\\", \\\"{x:344,y:486,t:1527267327915};\\\", \\\"{x:364,y:482,t:1527267327932};\\\", \\\"{x:383,y:480,t:1527267327948};\\\", \\\"{x:388,y:478,t:1527267327965};\\\", \\\"{x:390,y:477,t:1527267327982};\\\", \\\"{x:391,y:477,t:1527267327998};\\\", \\\"{x:392,y:477,t:1527267328015};\\\", \\\"{x:394,y:476,t:1527267328032};\\\", \\\"{x:402,y:473,t:1527267328048};\\\", \\\"{x:406,y:473,t:1527267328065};\\\", \\\"{x:410,y:472,t:1527267328082};\\\", \\\"{x:414,y:472,t:1527267328097};\\\", \\\"{x:419,y:471,t:1527267328116};\\\", \\\"{x:423,y:470,t:1527267328132};\\\", \\\"{x:426,y:469,t:1527267328148};\\\", \\\"{x:430,y:468,t:1527267328165};\\\", \\\"{x:436,y:466,t:1527267328182};\\\", \\\"{x:442,y:466,t:1527267328199};\\\", \\\"{x:467,y:466,t:1527267328216};\\\", \\\"{x:488,y:466,t:1527267328232};\\\", \\\"{x:507,y:466,t:1527267328248};\\\", \\\"{x:520,y:464,t:1527267328265};\\\", \\\"{x:528,y:464,t:1527267328282};\\\", \\\"{x:533,y:464,t:1527267328299};\\\", \\\"{x:539,y:464,t:1527267328315};\\\", \\\"{x:547,y:464,t:1527267328332};\\\", \\\"{x:557,y:464,t:1527267328349};\\\", \\\"{x:568,y:464,t:1527267328365};\\\", \\\"{x:583,y:465,t:1527267328382};\\\", \\\"{x:598,y:465,t:1527267328399};\\\", \\\"{x:610,y:467,t:1527267328416};\\\", \\\"{x:617,y:467,t:1527267328433};\\\", \\\"{x:621,y:467,t:1527267328449};\\\", \\\"{x:622,y:467,t:1527267328465};\\\", \\\"{x:623,y:467,t:1527267328483};\\\", \\\"{x:624,y:467,t:1527267328499};\\\", \\\"{x:625,y:467,t:1527267328537};\\\", \\\"{x:626,y:467,t:1527267328553};\\\", \\\"{x:627,y:467,t:1527267328565};\\\", \\\"{x:629,y:467,t:1527267328583};\\\", \\\"{x:631,y:467,t:1527267328600};\\\", \\\"{x:634,y:467,t:1527267328617};\\\", \\\"{x:637,y:467,t:1527267328632};\\\", \\\"{x:639,y:467,t:1527267328648};\\\", \\\"{x:644,y:467,t:1527267328666};\\\", \\\"{x:649,y:467,t:1527267328682};\\\", \\\"{x:652,y:467,t:1527267328699};\\\", \\\"{x:655,y:467,t:1527267328716};\\\", \\\"{x:659,y:467,t:1527267328732};\\\", \\\"{x:668,y:467,t:1527267328750};\\\", \\\"{x:676,y:467,t:1527267328766};\\\", \\\"{x:685,y:467,t:1527267328782};\\\", \\\"{x:689,y:467,t:1527267328798};\\\", \\\"{x:691,y:467,t:1527267328816};\\\", \\\"{x:692,y:467,t:1527267328831};\\\", \\\"{x:693,y:467,t:1527267328863};\\\", \\\"{x:694,y:467,t:1527267328872};\\\", \\\"{x:695,y:467,t:1527267328887};\\\", \\\"{x:696,y:467,t:1527267328904};\\\", \\\"{x:697,y:467,t:1527267328916};\\\", \\\"{x:698,y:468,t:1527267328985};\\\", \\\"{x:699,y:469,t:1527267329659};\\\", \\\"{x:707,y:469,t:1527267329670};\\\", \\\"{x:726,y:472,t:1527267329686};\\\", \\\"{x:734,y:474,t:1527267329703};\\\", \\\"{x:738,y:475,t:1527267329719};\\\", \\\"{x:739,y:475,t:1527267329736};\\\", \\\"{x:740,y:476,t:1527267329753};\\\", \\\"{x:741,y:476,t:1527267330484};\\\", \\\"{x:742,y:477,t:1527267330492};\\\", \\\"{x:743,y:478,t:1527267330503};\\\", \\\"{x:744,y:478,t:1527267330520};\\\", \\\"{x:746,y:479,t:1527267330537};\\\", \\\"{x:747,y:479,t:1527267330553};\\\", \\\"{x:750,y:481,t:1527267330570};\\\", \\\"{x:761,y:482,t:1527267330587};\\\", \\\"{x:773,y:482,t:1527267330603};\\\", \\\"{x:787,y:482,t:1527267330620};\\\", \\\"{x:800,y:481,t:1527267330637};\\\", \\\"{x:812,y:480,t:1527267330654};\\\", \\\"{x:830,y:479,t:1527267330671};\\\", \\\"{x:857,y:479,t:1527267330687};\\\", \\\"{x:887,y:479,t:1527267330704};\\\", \\\"{x:913,y:478,t:1527267330720};\\\", \\\"{x:937,y:478,t:1527267330737};\\\", \\\"{x:958,y:478,t:1527267330754};\\\", \\\"{x:973,y:478,t:1527267330770};\\\", \\\"{x:998,y:478,t:1527267330788};\\\", \\\"{x:1010,y:478,t:1527267330804};\\\", \\\"{x:1021,y:478,t:1527267330820};\\\", \\\"{x:1030,y:480,t:1527267330837};\\\", \\\"{x:1043,y:481,t:1527267330854};\\\", \\\"{x:1060,y:485,t:1527267330870};\\\", \\\"{x:1079,y:486,t:1527267330887};\\\", \\\"{x:1099,y:490,t:1527267330904};\\\", \\\"{x:1115,y:492,t:1527267330921};\\\", \\\"{x:1132,y:493,t:1527267330938};\\\", \\\"{x:1150,y:498,t:1527267330955};\\\", \\\"{x:1175,y:502,t:1527267330970};\\\", \\\"{x:1212,y:510,t:1527267330987};\\\", \\\"{x:1238,y:513,t:1527267331004};\\\", \\\"{x:1263,y:519,t:1527267331020};\\\", \\\"{x:1295,y:524,t:1527267331037};\\\", \\\"{x:1327,y:530,t:1527267331054};\\\", \\\"{x:1356,y:534,t:1527267331071};\\\", \\\"{x:1383,y:538,t:1527267331087};\\\", \\\"{x:1408,y:543,t:1527267331104};\\\", \\\"{x:1430,y:545,t:1527267331120};\\\", \\\"{x:1451,y:548,t:1527267331136};\\\", \\\"{x:1465,y:552,t:1527267331154};\\\", \\\"{x:1480,y:555,t:1527267331171};\\\", \\\"{x:1486,y:558,t:1527267331187};\\\", \\\"{x:1490,y:558,t:1527267331203};\\\", \\\"{x:1494,y:558,t:1527267331221};\\\", \\\"{x:1500,y:561,t:1527267331237};\\\", \\\"{x:1503,y:561,t:1527267331254};\\\", \\\"{x:1506,y:561,t:1527267331270};\\\", \\\"{x:1508,y:561,t:1527267331287};\\\", \\\"{x:1510,y:561,t:1527267331304};\\\", \\\"{x:1513,y:562,t:1527267331321};\\\", \\\"{x:1514,y:562,t:1527267331339};\\\", \\\"{x:1515,y:562,t:1527267331354};\\\", \\\"{x:1516,y:563,t:1527267331371};\\\", \\\"{x:1514,y:564,t:1527267332436};\\\", \\\"{x:1512,y:564,t:1527267332443};\\\", \\\"{x:1508,y:565,t:1527267332456};\\\", \\\"{x:1505,y:565,t:1527267332473};\\\", \\\"{x:1497,y:565,t:1527267332488};\\\", \\\"{x:1493,y:565,t:1527267332505};\\\", \\\"{x:1492,y:565,t:1527267332627};\\\", \\\"{x:1491,y:565,t:1527267332642};\\\", \\\"{x:1491,y:562,t:1527267332655};\\\", \\\"{x:1491,y:557,t:1527267332672};\\\", \\\"{x:1491,y:550,t:1527267332688};\\\", \\\"{x:1491,y:545,t:1527267332705};\\\", \\\"{x:1493,y:541,t:1527267332722};\\\", \\\"{x:1493,y:538,t:1527267332738};\\\", \\\"{x:1493,y:537,t:1527267332755};\\\", \\\"{x:1493,y:533,t:1527267332772};\\\", \\\"{x:1493,y:531,t:1527267332789};\\\", \\\"{x:1493,y:529,t:1527267332805};\\\", \\\"{x:1493,y:528,t:1527267332827};\\\", \\\"{x:1493,y:527,t:1527267332840};\\\", \\\"{x:1493,y:524,t:1527267332855};\\\", \\\"{x:1493,y:520,t:1527267332872};\\\", \\\"{x:1493,y:517,t:1527267332889};\\\", \\\"{x:1493,y:516,t:1527267332905};\\\", \\\"{x:1493,y:514,t:1527267332923};\\\", \\\"{x:1493,y:513,t:1527267332939};\\\", \\\"{x:1493,y:511,t:1527267332996};\\\", \\\"{x:1493,y:510,t:1527267333011};\\\", \\\"{x:1492,y:508,t:1527267333027};\\\", \\\"{x:1492,y:507,t:1527267333039};\\\", \\\"{x:1490,y:502,t:1527267333055};\\\", \\\"{x:1489,y:494,t:1527267333072};\\\", \\\"{x:1488,y:491,t:1527267333089};\\\", \\\"{x:1487,y:488,t:1527267333105};\\\", \\\"{x:1486,y:487,t:1527267333122};\\\", \\\"{x:1484,y:489,t:1527267333339};\\\", \\\"{x:1482,y:492,t:1527267333356};\\\", \\\"{x:1479,y:497,t:1527267333372};\\\", \\\"{x:1478,y:500,t:1527267333389};\\\", \\\"{x:1476,y:503,t:1527267333406};\\\", \\\"{x:1475,y:503,t:1527267333422};\\\", \\\"{x:1475,y:504,t:1527267333440};\\\", \\\"{x:1475,y:505,t:1527267333475};\\\", \\\"{x:1475,y:506,t:1527267333489};\\\", \\\"{x:1475,y:508,t:1527267333506};\\\", \\\"{x:1475,y:510,t:1527267333522};\\\", \\\"{x:1474,y:516,t:1527267333539};\\\", \\\"{x:1472,y:520,t:1527267333556};\\\", \\\"{x:1471,y:525,t:1527267333573};\\\", \\\"{x:1469,y:528,t:1527267333589};\\\", \\\"{x:1467,y:535,t:1527267333607};\\\", \\\"{x:1464,y:540,t:1527267333624};\\\", \\\"{x:1459,y:555,t:1527267333639};\\\", \\\"{x:1453,y:567,t:1527267333657};\\\", \\\"{x:1446,y:583,t:1527267333673};\\\", \\\"{x:1442,y:592,t:1527267333688};\\\", \\\"{x:1439,y:601,t:1527267333706};\\\", \\\"{x:1433,y:613,t:1527267333722};\\\", \\\"{x:1431,y:618,t:1527267333738};\\\", \\\"{x:1429,y:627,t:1527267333756};\\\", \\\"{x:1425,y:642,t:1527267333773};\\\", \\\"{x:1421,y:656,t:1527267333789};\\\", \\\"{x:1419,y:666,t:1527267333806};\\\", \\\"{x:1415,y:675,t:1527267333823};\\\", \\\"{x:1413,y:683,t:1527267333839};\\\", \\\"{x:1410,y:691,t:1527267333856};\\\", \\\"{x:1409,y:698,t:1527267333872};\\\", \\\"{x:1409,y:701,t:1527267333888};\\\", \\\"{x:1409,y:705,t:1527267333906};\\\", \\\"{x:1409,y:712,t:1527267333922};\\\", \\\"{x:1409,y:717,t:1527267333939};\\\", \\\"{x:1411,y:721,t:1527267333956};\\\", \\\"{x:1412,y:727,t:1527267333973};\\\", \\\"{x:1415,y:736,t:1527267333990};\\\", \\\"{x:1416,y:744,t:1527267334006};\\\", \\\"{x:1417,y:749,t:1527267334023};\\\", \\\"{x:1417,y:753,t:1527267334040};\\\", \\\"{x:1417,y:758,t:1527267334056};\\\", \\\"{x:1417,y:762,t:1527267334073};\\\", \\\"{x:1417,y:769,t:1527267334090};\\\", \\\"{x:1416,y:777,t:1527267334106};\\\", \\\"{x:1414,y:786,t:1527267334123};\\\", \\\"{x:1412,y:787,t:1527267334140};\\\", \\\"{x:1408,y:788,t:1527267334156};\\\", \\\"{x:1397,y:791,t:1527267334173};\\\", \\\"{x:1385,y:792,t:1527267334190};\\\", \\\"{x:1372,y:795,t:1527267334206};\\\", \\\"{x:1364,y:796,t:1527267334223};\\\", \\\"{x:1357,y:796,t:1527267334240};\\\", \\\"{x:1351,y:796,t:1527267334256};\\\", \\\"{x:1346,y:796,t:1527267334273};\\\", \\\"{x:1344,y:796,t:1527267334290};\\\", \\\"{x:1341,y:795,t:1527267334305};\\\", \\\"{x:1339,y:792,t:1527267334323};\\\", \\\"{x:1338,y:788,t:1527267334340};\\\", \\\"{x:1338,y:787,t:1527267334363};\\\", \\\"{x:1338,y:786,t:1527267334374};\\\", \\\"{x:1338,y:784,t:1527267334390};\\\", \\\"{x:1338,y:780,t:1527267334407};\\\", \\\"{x:1338,y:775,t:1527267334423};\\\", \\\"{x:1338,y:771,t:1527267334440};\\\", \\\"{x:1339,y:768,t:1527267334457};\\\", \\\"{x:1339,y:765,t:1527267334474};\\\", \\\"{x:1340,y:764,t:1527267334490};\\\", \\\"{x:1341,y:763,t:1527267334892};\\\", \\\"{x:1342,y:763,t:1527267334950};\\\", \\\"{x:1343,y:762,t:1527267334974};\\\", \\\"{x:1344,y:762,t:1527267335018};\\\", \\\"{x:1345,y:761,t:1527267335026};\\\", \\\"{x:1346,y:761,t:1527267335819};\\\", \\\"{x:1348,y:761,t:1527267343131};\\\", \\\"{x:1349,y:761,t:1527267343148};\\\", \\\"{x:1344,y:761,t:1527267355699};\\\", \\\"{x:1333,y:761,t:1527267355710};\\\", \\\"{x:1315,y:762,t:1527267355725};\\\", \\\"{x:1297,y:763,t:1527267355741};\\\", \\\"{x:1249,y:764,t:1527267355757};\\\", \\\"{x:1119,y:764,t:1527267355774};\\\", \\\"{x:1023,y:760,t:1527267355791};\\\", \\\"{x:928,y:742,t:1527267355808};\\\", \\\"{x:828,y:726,t:1527267355824};\\\", \\\"{x:691,y:684,t:1527267355842};\\\", \\\"{x:657,y:669,t:1527267355857};\\\", \\\"{x:572,y:632,t:1527267355875};\\\", \\\"{x:528,y:614,t:1527267355893};\\\", \\\"{x:502,y:604,t:1527267355907};\\\", \\\"{x:483,y:596,t:1527267355925};\\\", \\\"{x:454,y:582,t:1527267355949};\\\", \\\"{x:434,y:574,t:1527267355965};\\\", \\\"{x:411,y:566,t:1527267355982};\\\", \\\"{x:394,y:562,t:1527267355998};\\\", \\\"{x:380,y:560,t:1527267356023};\\\", \\\"{x:373,y:560,t:1527267356039};\\\", \\\"{x:353,y:554,t:1527267356057};\\\", \\\"{x:308,y:541,t:1527267356074};\\\", \\\"{x:289,y:536,t:1527267356089};\\\", \\\"{x:283,y:534,t:1527267356106};\\\", \\\"{x:281,y:533,t:1527267356123};\\\", \\\"{x:280,y:533,t:1527267356154};\\\", \\\"{x:278,y:533,t:1527267356170};\\\", \\\"{x:277,y:533,t:1527267356178};\\\", \\\"{x:276,y:533,t:1527267356191};\\\", \\\"{x:271,y:533,t:1527267356207};\\\", \\\"{x:260,y:537,t:1527267356223};\\\", \\\"{x:243,y:539,t:1527267356240};\\\", \\\"{x:224,y:540,t:1527267356256};\\\", \\\"{x:198,y:543,t:1527267356273};\\\", \\\"{x:187,y:545,t:1527267356290};\\\", \\\"{x:180,y:547,t:1527267356307};\\\", \\\"{x:174,y:550,t:1527267356324};\\\", \\\"{x:168,y:553,t:1527267356340};\\\", \\\"{x:165,y:555,t:1527267356356};\\\", \\\"{x:163,y:556,t:1527267356374};\\\", \\\"{x:163,y:557,t:1527267356418};\\\", \\\"{x:163,y:559,t:1527267356426};\\\", \\\"{x:163,y:562,t:1527267356441};\\\", \\\"{x:162,y:568,t:1527267356457};\\\", \\\"{x:162,y:574,t:1527267356473};\\\", \\\"{x:162,y:591,t:1527267356491};\\\", \\\"{x:162,y:598,t:1527267356507};\\\", \\\"{x:162,y:603,t:1527267356524};\\\", \\\"{x:162,y:607,t:1527267356541};\\\", \\\"{x:162,y:614,t:1527267356556};\\\", \\\"{x:162,y:620,t:1527267356573};\\\", \\\"{x:163,y:622,t:1527267356591};\\\", \\\"{x:164,y:624,t:1527267356618};\\\", \\\"{x:167,y:624,t:1527267356675};\\\", \\\"{x:172,y:624,t:1527267356691};\\\", \\\"{x:179,y:624,t:1527267356708};\\\", \\\"{x:202,y:618,t:1527267356725};\\\", \\\"{x:225,y:611,t:1527267356741};\\\", \\\"{x:245,y:605,t:1527267356758};\\\", \\\"{x:262,y:599,t:1527267356774};\\\", \\\"{x:273,y:595,t:1527267356790};\\\", \\\"{x:277,y:592,t:1527267356808};\\\", \\\"{x:280,y:590,t:1527267356824};\\\", \\\"{x:281,y:590,t:1527267356841};\\\", \\\"{x:282,y:590,t:1527267356857};\\\", \\\"{x:283,y:588,t:1527267356873};\\\", \\\"{x:285,y:587,t:1527267356890};\\\", \\\"{x:289,y:585,t:1527267356908};\\\", \\\"{x:293,y:582,t:1527267356923};\\\", \\\"{x:301,y:577,t:1527267356940};\\\", \\\"{x:307,y:574,t:1527267356957};\\\", \\\"{x:313,y:571,t:1527267356974};\\\", \\\"{x:318,y:568,t:1527267356991};\\\", \\\"{x:322,y:566,t:1527267357008};\\\", \\\"{x:325,y:563,t:1527267357023};\\\", \\\"{x:326,y:560,t:1527267357042};\\\", \\\"{x:332,y:556,t:1527267357058};\\\", \\\"{x:337,y:552,t:1527267357074};\\\", \\\"{x:340,y:550,t:1527267357091};\\\", \\\"{x:342,y:548,t:1527267357108};\\\", \\\"{x:344,y:547,t:1527267357124};\\\", \\\"{x:351,y:544,t:1527267357141};\\\", \\\"{x:363,y:540,t:1527267357158};\\\", \\\"{x:374,y:536,t:1527267357176};\\\", \\\"{x:392,y:531,t:1527267357190};\\\", \\\"{x:410,y:529,t:1527267357207};\\\", \\\"{x:434,y:528,t:1527267357224};\\\", \\\"{x:478,y:525,t:1527267357241};\\\", \\\"{x:506,y:525,t:1527267357258};\\\", \\\"{x:535,y:525,t:1527267357274};\\\", \\\"{x:566,y:525,t:1527267357290};\\\", \\\"{x:591,y:525,t:1527267357308};\\\", \\\"{x:607,y:525,t:1527267357325};\\\", \\\"{x:614,y:524,t:1527267357341};\\\", \\\"{x:615,y:524,t:1527267357362};\\\", \\\"{x:616,y:524,t:1527267357426};\\\", \\\"{x:617,y:524,t:1527267357441};\\\", \\\"{x:640,y:520,t:1527267357458};\\\", \\\"{x:659,y:518,t:1527267357474};\\\", \\\"{x:676,y:516,t:1527267357493};\\\", \\\"{x:693,y:516,t:1527267357508};\\\", \\\"{x:712,y:516,t:1527267357524};\\\", \\\"{x:728,y:516,t:1527267357541};\\\", \\\"{x:737,y:516,t:1527267357558};\\\", \\\"{x:740,y:516,t:1527267357574};\\\", \\\"{x:742,y:515,t:1527267357592};\\\", \\\"{x:743,y:515,t:1527267357608};\\\", \\\"{x:745,y:515,t:1527267357625};\\\", \\\"{x:752,y:513,t:1527267357642};\\\", \\\"{x:753,y:512,t:1527267357657};\\\", \\\"{x:756,y:511,t:1527267357675};\\\", \\\"{x:760,y:510,t:1527267357692};\\\", \\\"{x:764,y:508,t:1527267357707};\\\", \\\"{x:768,y:508,t:1527267357725};\\\", \\\"{x:773,y:507,t:1527267357742};\\\", \\\"{x:776,y:506,t:1527267357758};\\\", \\\"{x:780,y:504,t:1527267357775};\\\", \\\"{x:783,y:504,t:1527267357792};\\\", \\\"{x:786,y:504,t:1527267357809};\\\", \\\"{x:788,y:504,t:1527267357825};\\\", \\\"{x:791,y:504,t:1527267357843};\\\", \\\"{x:794,y:504,t:1527267357859};\\\", \\\"{x:799,y:504,t:1527267357875};\\\", \\\"{x:806,y:504,t:1527267357892};\\\", \\\"{x:811,y:504,t:1527267357909};\\\", \\\"{x:817,y:504,t:1527267357925};\\\", \\\"{x:821,y:504,t:1527267357943};\\\", \\\"{x:822,y:504,t:1527267357959};\\\", \\\"{x:825,y:504,t:1527267357975};\\\", \\\"{x:826,y:504,t:1527267357995};\\\", \\\"{x:828,y:503,t:1527267358010};\\\", \\\"{x:829,y:503,t:1527267358025};\\\", \\\"{x:831,y:503,t:1527267358042};\\\", \\\"{x:832,y:503,t:1527267358058};\\\", \\\"{x:826,y:509,t:1527267358314};\\\", \\\"{x:818,y:516,t:1527267358326};\\\", \\\"{x:795,y:535,t:1527267358342};\\\", \\\"{x:779,y:546,t:1527267358358};\\\", \\\"{x:767,y:552,t:1527267358376};\\\", \\\"{x:760,y:556,t:1527267358393};\\\", \\\"{x:750,y:563,t:1527267358410};\\\", \\\"{x:738,y:571,t:1527267358424};\\\", \\\"{x:708,y:595,t:1527267358442};\\\", \\\"{x:679,y:614,t:1527267358460};\\\", \\\"{x:643,y:631,t:1527267358475};\\\", \\\"{x:620,y:641,t:1527267358492};\\\", \\\"{x:607,y:645,t:1527267358508};\\\", \\\"{x:598,y:649,t:1527267358526};\\\", \\\"{x:591,y:652,t:1527267358543};\\\", \\\"{x:581,y:657,t:1527267358559};\\\", \\\"{x:571,y:664,t:1527267358576};\\\", \\\"{x:564,y:669,t:1527267358593};\\\", \\\"{x:560,y:671,t:1527267358609};\\\", \\\"{x:553,y:674,t:1527267358627};\\\", \\\"{x:547,y:678,t:1527267358643};\\\", \\\"{x:542,y:684,t:1527267358660};\\\", \\\"{x:538,y:689,t:1527267358676};\\\", \\\"{x:534,y:693,t:1527267358692};\\\", \\\"{x:532,y:698,t:1527267358710};\\\", \\\"{x:530,y:703,t:1527267358726};\\\", \\\"{x:528,y:708,t:1527267358743};\\\", \\\"{x:525,y:711,t:1527267358760};\\\", \\\"{x:523,y:715,t:1527267358777};\\\", \\\"{x:519,y:725,t:1527267358795};\\\", \\\"{x:514,y:735,t:1527267358810};\\\", \\\"{x:516,y:736,t:1527267359251};\\\", \\\"{x:530,y:736,t:1527267359260};\\\", \\\"{x:562,y:736,t:1527267359276};\\\", \\\"{x:613,y:736,t:1527267359293};\\\", \\\"{x:672,y:736,t:1527267359310};\\\", \\\"{x:722,y:736,t:1527267359326};\\\", \\\"{x:772,y:725,t:1527267359343};\\\", \\\"{x:820,y:709,t:1527267359359};\\\", \\\"{x:857,y:683,t:1527267359376};\\\", \\\"{x:886,y:647,t:1527267359393};\\\", \\\"{x:952,y:592,t:1527267359410};\\\", \\\"{x:1008,y:574,t:1527267359426};\\\", \\\"{x:1021,y:571,t:1527267359443};\\\" ] }, { \\\"rt\\\": 18039, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 348110, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1019,y:572,t:1527267362482};\\\", \\\"{x:1013,y:575,t:1527267362497};\\\", \\\"{x:998,y:580,t:1527267362511};\\\", \\\"{x:970,y:583,t:1527267362528};\\\", \\\"{x:939,y:583,t:1527267362545};\\\", \\\"{x:899,y:581,t:1527267362561};\\\", \\\"{x:860,y:571,t:1527267362579};\\\", \\\"{x:823,y:559,t:1527267362596};\\\", \\\"{x:795,y:553,t:1527267362612};\\\", \\\"{x:775,y:551,t:1527267362629};\\\", \\\"{x:760,y:545,t:1527267362645};\\\", \\\"{x:750,y:542,t:1527267362662};\\\", \\\"{x:745,y:539,t:1527267362679};\\\", \\\"{x:731,y:532,t:1527267362695};\\\", \\\"{x:717,y:527,t:1527267362712};\\\", \\\"{x:691,y:518,t:1527267362729};\\\", \\\"{x:614,y:501,t:1527267362746};\\\", \\\"{x:558,y:493,t:1527267362762};\\\", \\\"{x:510,y:490,t:1527267362779};\\\", \\\"{x:469,y:487,t:1527267362796};\\\", \\\"{x:437,y:484,t:1527267362813};\\\", \\\"{x:414,y:483,t:1527267362829};\\\", \\\"{x:396,y:483,t:1527267362845};\\\", \\\"{x:381,y:483,t:1527267362862};\\\", \\\"{x:367,y:483,t:1527267362879};\\\", \\\"{x:357,y:483,t:1527267362896};\\\", \\\"{x:348,y:485,t:1527267362912};\\\", \\\"{x:342,y:485,t:1527267362929};\\\", \\\"{x:332,y:484,t:1527267362945};\\\", \\\"{x:324,y:484,t:1527267362962};\\\", \\\"{x:323,y:484,t:1527267362979};\\\", \\\"{x:322,y:484,t:1527267363002};\\\", \\\"{x:321,y:484,t:1527267363018};\\\", \\\"{x:320,y:483,t:1527267363066};\\\", \\\"{x:320,y:482,t:1527267363082};\\\", \\\"{x:320,y:481,t:1527267363095};\\\", \\\"{x:323,y:478,t:1527267363112};\\\", \\\"{x:334,y:476,t:1527267363129};\\\", \\\"{x:352,y:473,t:1527267363145};\\\", \\\"{x:386,y:468,t:1527267363162};\\\", \\\"{x:407,y:465,t:1527267363179};\\\", \\\"{x:428,y:462,t:1527267363195};\\\", \\\"{x:438,y:460,t:1527267363212};\\\", \\\"{x:441,y:460,t:1527267363229};\\\", \\\"{x:443,y:459,t:1527267363245};\\\", \\\"{x:444,y:459,t:1527267363262};\\\", \\\"{x:445,y:459,t:1527267363279};\\\", \\\"{x:448,y:458,t:1527267363295};\\\", \\\"{x:449,y:458,t:1527267363314};\\\", \\\"{x:450,y:458,t:1527267363328};\\\", \\\"{x:451,y:458,t:1527267363345};\\\", \\\"{x:452,y:458,t:1527267363362};\\\", \\\"{x:456,y:458,t:1527267363378};\\\", \\\"{x:460,y:458,t:1527267363395};\\\", \\\"{x:465,y:458,t:1527267363413};\\\", \\\"{x:469,y:459,t:1527267363428};\\\", \\\"{x:472,y:459,t:1527267363445};\\\", \\\"{x:473,y:459,t:1527267363466};\\\", \\\"{x:475,y:459,t:1527267363483};\\\", \\\"{x:477,y:459,t:1527267363506};\\\", \\\"{x:479,y:459,t:1527267363522};\\\", \\\"{x:481,y:460,t:1527267363538};\\\", \\\"{x:482,y:460,t:1527267363554};\\\", \\\"{x:484,y:460,t:1527267363603};\\\", \\\"{x:485,y:460,t:1527267363651};\\\", \\\"{x:486,y:461,t:1527267363663};\\\", \\\"{x:487,y:461,t:1527267363679};\\\", \\\"{x:488,y:462,t:1527267363696};\\\", \\\"{x:491,y:463,t:1527267363712};\\\", \\\"{x:493,y:463,t:1527267363728};\\\", \\\"{x:494,y:465,t:1527267363745};\\\", \\\"{x:498,y:465,t:1527267363763};\\\", \\\"{x:500,y:465,t:1527267363778};\\\", \\\"{x:506,y:466,t:1527267363796};\\\", \\\"{x:514,y:467,t:1527267363812};\\\", \\\"{x:524,y:469,t:1527267363828};\\\", \\\"{x:535,y:469,t:1527267363844};\\\", \\\"{x:546,y:471,t:1527267363862};\\\", \\\"{x:554,y:472,t:1527267363878};\\\", \\\"{x:558,y:472,t:1527267363895};\\\", \\\"{x:560,y:472,t:1527267363912};\\\", \\\"{x:561,y:472,t:1527267363928};\\\", \\\"{x:563,y:472,t:1527267363978};\\\", \\\"{x:564,y:472,t:1527267363995};\\\", \\\"{x:567,y:472,t:1527267364012};\\\", \\\"{x:570,y:472,t:1527267364028};\\\", \\\"{x:573,y:472,t:1527267364045};\\\", \\\"{x:576,y:472,t:1527267364062};\\\", \\\"{x:578,y:472,t:1527267364079};\\\", \\\"{x:581,y:472,t:1527267364095};\\\", \\\"{x:589,y:472,t:1527267364112};\\\", \\\"{x:600,y:472,t:1527267364129};\\\", \\\"{x:610,y:472,t:1527267364146};\\\", \\\"{x:623,y:472,t:1527267364161};\\\", \\\"{x:641,y:472,t:1527267364179};\\\", \\\"{x:648,y:472,t:1527267364196};\\\", \\\"{x:654,y:472,t:1527267364211};\\\", \\\"{x:660,y:471,t:1527267364229};\\\", \\\"{x:665,y:470,t:1527267364245};\\\", \\\"{x:666,y:470,t:1527267364266};\\\", \\\"{x:667,y:470,t:1527267364278};\\\", \\\"{x:670,y:469,t:1527267364295};\\\", \\\"{x:676,y:468,t:1527267364311};\\\", \\\"{x:687,y:468,t:1527267364328};\\\", \\\"{x:701,y:465,t:1527267364346};\\\", \\\"{x:713,y:464,t:1527267364362};\\\", \\\"{x:724,y:464,t:1527267364378};\\\", \\\"{x:732,y:462,t:1527267364395};\\\", \\\"{x:736,y:461,t:1527267364411};\\\", \\\"{x:737,y:461,t:1527267364428};\\\", \\\"{x:744,y:461,t:1527267364819};\\\", \\\"{x:758,y:460,t:1527267364829};\\\", \\\"{x:773,y:459,t:1527267364845};\\\", \\\"{x:784,y:459,t:1527267364861};\\\", \\\"{x:811,y:454,t:1527267364879};\\\", \\\"{x:863,y:447,t:1527267364894};\\\", \\\"{x:961,y:445,t:1527267364912};\\\", \\\"{x:1088,y:445,t:1527267364929};\\\", \\\"{x:1189,y:464,t:1527267364944};\\\", \\\"{x:1298,y:464,t:1527267364962};\\\", \\\"{x:1380,y:478,t:1527267364979};\\\", \\\"{x:1381,y:478,t:1527267364995};\\\", \\\"{x:1382,y:478,t:1527267365026};\\\", \\\"{x:1382,y:477,t:1527267365034};\\\", \\\"{x:1382,y:480,t:1527267366618};\\\", \\\"{x:1382,y:482,t:1527267366627};\\\", \\\"{x:1383,y:494,t:1527267366643};\\\", \\\"{x:1386,y:501,t:1527267366660};\\\", \\\"{x:1387,y:511,t:1527267366678};\\\", \\\"{x:1388,y:518,t:1527267366694};\\\", \\\"{x:1388,y:523,t:1527267366710};\\\", \\\"{x:1390,y:528,t:1527267366728};\\\", \\\"{x:1390,y:532,t:1527267366743};\\\", \\\"{x:1391,y:535,t:1527267366760};\\\", \\\"{x:1391,y:538,t:1527267366777};\\\", \\\"{x:1391,y:541,t:1527267366793};\\\", \\\"{x:1394,y:545,t:1527267366810};\\\", \\\"{x:1394,y:549,t:1527267366828};\\\", \\\"{x:1395,y:554,t:1527267366843};\\\", \\\"{x:1399,y:563,t:1527267366861};\\\", \\\"{x:1403,y:577,t:1527267366877};\\\", \\\"{x:1407,y:590,t:1527267366894};\\\", \\\"{x:1409,y:601,t:1527267366910};\\\", \\\"{x:1410,y:608,t:1527267366928};\\\", \\\"{x:1411,y:613,t:1527267366943};\\\", \\\"{x:1412,y:618,t:1527267366960};\\\", \\\"{x:1413,y:621,t:1527267366976};\\\", \\\"{x:1415,y:626,t:1527267366994};\\\", \\\"{x:1416,y:629,t:1527267367011};\\\", \\\"{x:1416,y:630,t:1527267367027};\\\", \\\"{x:1416,y:633,t:1527267367044};\\\", \\\"{x:1417,y:638,t:1527267367060};\\\", \\\"{x:1421,y:643,t:1527267367076};\\\", \\\"{x:1423,y:652,t:1527267367093};\\\", \\\"{x:1424,y:658,t:1527267367111};\\\", \\\"{x:1424,y:662,t:1527267367126};\\\", \\\"{x:1424,y:664,t:1527267367143};\\\", \\\"{x:1424,y:666,t:1527267367160};\\\", \\\"{x:1423,y:667,t:1527267367178};\\\", \\\"{x:1423,y:669,t:1527267367194};\\\", \\\"{x:1419,y:681,t:1527267367209};\\\", \\\"{x:1415,y:694,t:1527267367227};\\\", \\\"{x:1412,y:705,t:1527267367243};\\\", \\\"{x:1408,y:715,t:1527267367260};\\\", \\\"{x:1404,y:723,t:1527267367276};\\\", \\\"{x:1400,y:730,t:1527267367294};\\\", \\\"{x:1396,y:738,t:1527267367311};\\\", \\\"{x:1395,y:744,t:1527267367326};\\\", \\\"{x:1392,y:750,t:1527267367344};\\\", \\\"{x:1391,y:755,t:1527267367360};\\\", \\\"{x:1390,y:761,t:1527267367377};\\\", \\\"{x:1388,y:768,t:1527267367394};\\\", \\\"{x:1388,y:772,t:1527267367410};\\\", \\\"{x:1388,y:774,t:1527267367426};\\\", \\\"{x:1390,y:774,t:1527267367444};\\\", \\\"{x:1393,y:775,t:1527267367460};\\\", \\\"{x:1395,y:777,t:1527267367476};\\\", \\\"{x:1398,y:780,t:1527267367494};\\\", \\\"{x:1400,y:781,t:1527267367511};\\\", \\\"{x:1402,y:783,t:1527267367527};\\\", \\\"{x:1403,y:783,t:1527267367554};\\\", \\\"{x:1399,y:778,t:1527267367667};\\\", \\\"{x:1399,y:777,t:1527267367676};\\\", \\\"{x:1399,y:774,t:1527267367694};\\\", \\\"{x:1399,y:769,t:1527267367710};\\\", \\\"{x:1401,y:764,t:1527267367727};\\\", \\\"{x:1408,y:759,t:1527267367743};\\\", \\\"{x:1417,y:754,t:1527267367759};\\\", \\\"{x:1425,y:749,t:1527267367777};\\\", \\\"{x:1430,y:745,t:1527267367793};\\\", \\\"{x:1434,y:739,t:1527267367810};\\\", \\\"{x:1439,y:732,t:1527267367826};\\\", \\\"{x:1442,y:727,t:1527267367844};\\\", \\\"{x:1442,y:725,t:1527267367860};\\\", \\\"{x:1443,y:723,t:1527267367877};\\\", \\\"{x:1444,y:722,t:1527267367894};\\\", \\\"{x:1445,y:722,t:1527267367914};\\\", \\\"{x:1447,y:722,t:1527267367963};\\\", \\\"{x:1453,y:722,t:1527267367977};\\\", \\\"{x:1469,y:724,t:1527267367993};\\\", \\\"{x:1478,y:731,t:1527267368010};\\\", \\\"{x:1488,y:738,t:1527267368027};\\\", \\\"{x:1490,y:741,t:1527267368044};\\\", \\\"{x:1491,y:742,t:1527267368060};\\\", \\\"{x:1491,y:743,t:1527267368077};\\\", \\\"{x:1492,y:744,t:1527267368094};\\\", \\\"{x:1495,y:748,t:1527267368110};\\\", \\\"{x:1498,y:752,t:1527267368127};\\\", \\\"{x:1500,y:756,t:1527267368144};\\\", \\\"{x:1500,y:761,t:1527267368160};\\\", \\\"{x:1501,y:766,t:1527267368177};\\\", \\\"{x:1501,y:771,t:1527267368192};\\\", \\\"{x:1501,y:776,t:1527267368210};\\\", \\\"{x:1498,y:786,t:1527267368226};\\\", \\\"{x:1497,y:794,t:1527267368243};\\\", \\\"{x:1497,y:798,t:1527267368260};\\\", \\\"{x:1498,y:800,t:1527267368277};\\\", \\\"{x:1498,y:801,t:1527267368331};\\\", \\\"{x:1499,y:802,t:1527267368475};\\\", \\\"{x:1498,y:802,t:1527267368484};\\\", \\\"{x:1497,y:802,t:1527267368493};\\\", \\\"{x:1490,y:802,t:1527267368510};\\\", \\\"{x:1479,y:800,t:1527267368526};\\\", \\\"{x:1470,y:795,t:1527267368542};\\\", \\\"{x:1459,y:792,t:1527267368559};\\\", \\\"{x:1451,y:787,t:1527267368577};\\\", \\\"{x:1447,y:785,t:1527267368592};\\\", \\\"{x:1447,y:783,t:1527267368610};\\\", \\\"{x:1444,y:773,t:1527267368625};\\\", \\\"{x:1444,y:767,t:1527267368643};\\\", \\\"{x:1444,y:764,t:1527267368659};\\\", \\\"{x:1444,y:760,t:1527267368677};\\\", \\\"{x:1444,y:757,t:1527267368692};\\\", \\\"{x:1445,y:751,t:1527267368709};\\\", \\\"{x:1450,y:745,t:1527267368726};\\\", \\\"{x:1455,y:739,t:1527267368742};\\\", \\\"{x:1464,y:730,t:1527267368760};\\\", \\\"{x:1467,y:725,t:1527267368775};\\\", \\\"{x:1472,y:719,t:1527267368792};\\\", \\\"{x:1475,y:715,t:1527267368809};\\\", \\\"{x:1475,y:713,t:1527267368825};\\\", \\\"{x:1478,y:708,t:1527267368842};\\\", \\\"{x:1480,y:705,t:1527267368859};\\\", \\\"{x:1482,y:700,t:1527267368876};\\\", \\\"{x:1482,y:699,t:1527267368893};\\\", \\\"{x:1474,y:707,t:1527267369491};\\\", \\\"{x:1459,y:723,t:1527267369499};\\\", \\\"{x:1440,y:741,t:1527267369509};\\\", \\\"{x:1419,y:760,t:1527267369525};\\\", \\\"{x:1401,y:771,t:1527267369543};\\\", \\\"{x:1381,y:779,t:1527267369558};\\\", \\\"{x:1363,y:784,t:1527267369576};\\\", \\\"{x:1347,y:788,t:1527267369592};\\\", \\\"{x:1333,y:792,t:1527267369608};\\\", \\\"{x:1325,y:793,t:1527267369625};\\\", \\\"{x:1318,y:795,t:1527267369641};\\\", \\\"{x:1310,y:799,t:1527267369659};\\\", \\\"{x:1295,y:804,t:1527267369675};\\\", \\\"{x:1284,y:809,t:1527267369692};\\\", \\\"{x:1272,y:816,t:1527267369708};\\\", \\\"{x:1258,y:819,t:1527267369725};\\\", \\\"{x:1237,y:828,t:1527267369742};\\\", \\\"{x:1205,y:836,t:1527267369759};\\\", \\\"{x:1180,y:841,t:1527267369775};\\\", \\\"{x:1167,y:842,t:1527267369792};\\\", \\\"{x:1164,y:842,t:1527267369809};\\\", \\\"{x:1163,y:842,t:1527267369825};\\\", \\\"{x:1168,y:842,t:1527267369947};\\\", \\\"{x:1172,y:842,t:1527267369959};\\\", \\\"{x:1180,y:840,t:1527267369976};\\\", \\\"{x:1189,y:840,t:1527267369992};\\\", \\\"{x:1196,y:839,t:1527267370009};\\\", \\\"{x:1201,y:838,t:1527267370025};\\\", \\\"{x:1204,y:837,t:1527267370042};\\\", \\\"{x:1205,y:837,t:1527267370065};\\\", \\\"{x:1206,y:837,t:1527267370113};\\\", \\\"{x:1207,y:837,t:1527267370125};\\\", \\\"{x:1207,y:836,t:1527267370141};\\\", \\\"{x:1210,y:836,t:1527267370337};\\\", \\\"{x:1211,y:836,t:1527267370346};\\\", \\\"{x:1210,y:835,t:1527267376252};\\\", \\\"{x:1188,y:830,t:1527267376258};\\\", \\\"{x:1154,y:828,t:1527267376271};\\\", \\\"{x:1049,y:818,t:1527267376289};\\\", \\\"{x:843,y:807,t:1527267376306};\\\", \\\"{x:718,y:807,t:1527267376322};\\\", \\\"{x:610,y:789,t:1527267376339};\\\", \\\"{x:510,y:761,t:1527267376355};\\\", \\\"{x:445,y:740,t:1527267376372};\\\", \\\"{x:412,y:724,t:1527267376389};\\\", \\\"{x:406,y:720,t:1527267376405};\\\", \\\"{x:404,y:718,t:1527267376423};\\\", \\\"{x:403,y:717,t:1527267376440};\\\", \\\"{x:403,y:716,t:1527267376456};\\\", \\\"{x:400,y:710,t:1527267376473};\\\", \\\"{x:393,y:703,t:1527267376490};\\\", \\\"{x:382,y:695,t:1527267376506};\\\", \\\"{x:372,y:689,t:1527267376524};\\\", \\\"{x:362,y:681,t:1527267376539};\\\", \\\"{x:347,y:669,t:1527267376557};\\\", \\\"{x:324,y:657,t:1527267376573};\\\", \\\"{x:301,y:647,t:1527267376589};\\\", \\\"{x:286,y:640,t:1527267376606};\\\", \\\"{x:275,y:631,t:1527267376624};\\\", \\\"{x:268,y:623,t:1527267376640};\\\", \\\"{x:261,y:614,t:1527267376656};\\\", \\\"{x:257,y:608,t:1527267376673};\\\", \\\"{x:255,y:606,t:1527267376689};\\\", \\\"{x:252,y:603,t:1527267376707};\\\", \\\"{x:250,y:599,t:1527267376723};\\\", \\\"{x:246,y:592,t:1527267376741};\\\", \\\"{x:240,y:585,t:1527267376756};\\\", \\\"{x:230,y:577,t:1527267376773};\\\", \\\"{x:222,y:570,t:1527267376791};\\\", \\\"{x:215,y:565,t:1527267376806};\\\", \\\"{x:206,y:560,t:1527267376824};\\\", \\\"{x:198,y:554,t:1527267376842};\\\", \\\"{x:189,y:549,t:1527267376857};\\\", \\\"{x:179,y:543,t:1527267376873};\\\", \\\"{x:176,y:541,t:1527267376891};\\\", \\\"{x:170,y:537,t:1527267376906};\\\", \\\"{x:164,y:534,t:1527267376924};\\\", \\\"{x:161,y:532,t:1527267376941};\\\", \\\"{x:158,y:531,t:1527267376956};\\\", \\\"{x:156,y:530,t:1527267376974};\\\", \\\"{x:152,y:527,t:1527267376991};\\\", \\\"{x:151,y:526,t:1527267377008};\\\", \\\"{x:151,y:525,t:1527267377025};\\\", \\\"{x:151,y:524,t:1527267377039};\\\", \\\"{x:151,y:519,t:1527267377057};\\\", \\\"{x:149,y:514,t:1527267377074};\\\", \\\"{x:149,y:513,t:1527267377090};\\\", \\\"{x:149,y:511,t:1527267377108};\\\", \\\"{x:149,y:510,t:1527267377129};\\\", \\\"{x:149,y:509,t:1527267377146};\\\", \\\"{x:149,y:508,t:1527267377157};\\\", \\\"{x:150,y:504,t:1527267377174};\\\", \\\"{x:151,y:502,t:1527267377190};\\\", \\\"{x:152,y:499,t:1527267377207};\\\", \\\"{x:157,y:492,t:1527267377224};\\\", \\\"{x:158,y:491,t:1527267377241};\\\", \\\"{x:159,y:491,t:1527267377257};\\\", \\\"{x:159,y:490,t:1527267377489};\\\", \\\"{x:168,y:499,t:1527267377507};\\\", \\\"{x:178,y:508,t:1527267377524};\\\", \\\"{x:198,y:522,t:1527267377541};\\\", \\\"{x:228,y:543,t:1527267377557};\\\", \\\"{x:255,y:561,t:1527267377575};\\\", \\\"{x:282,y:576,t:1527267377591};\\\", \\\"{x:317,y:595,t:1527267377608};\\\", \\\"{x:354,y:614,t:1527267377625};\\\", \\\"{x:383,y:626,t:1527267377641};\\\", \\\"{x:431,y:647,t:1527267377658};\\\", \\\"{x:449,y:653,t:1527267377674};\\\", \\\"{x:464,y:658,t:1527267377690};\\\", \\\"{x:471,y:662,t:1527267377707};\\\", \\\"{x:475,y:664,t:1527267377724};\\\", \\\"{x:476,y:666,t:1527267377740};\\\", \\\"{x:478,y:667,t:1527267377757};\\\", \\\"{x:482,y:673,t:1527267377776};\\\", \\\"{x:490,y:682,t:1527267377791};\\\", \\\"{x:494,y:688,t:1527267377808};\\\", \\\"{x:499,y:692,t:1527267377825};\\\", \\\"{x:500,y:694,t:1527267377842};\\\", \\\"{x:502,y:697,t:1527267377858};\\\", \\\"{x:502,y:698,t:1527267377875};\\\", \\\"{x:502,y:699,t:1527267377891};\\\", \\\"{x:502,y:700,t:1527267377978};\\\", \\\"{x:502,y:703,t:1527267377992};\\\", \\\"{x:502,y:708,t:1527267378008};\\\", \\\"{x:502,y:715,t:1527267378025};\\\", \\\"{x:502,y:722,t:1527267378042};\\\", \\\"{x:502,y:724,t:1527267378058};\\\", \\\"{x:502,y:726,t:1527267378074};\\\", \\\"{x:515,y:713,t:1527267378779};\\\", \\\"{x:550,y:680,t:1527267378791};\\\", \\\"{x:621,y:618,t:1527267378809};\\\", \\\"{x:678,y:574,t:1527267378825};\\\", \\\"{x:780,y:513,t:1527267378841};\\\", \\\"{x:827,y:491,t:1527267378859};\\\", \\\"{x:851,y:480,t:1527267378874};\\\", \\\"{x:858,y:477,t:1527267378891};\\\", \\\"{x:859,y:477,t:1527267378908};\\\" ] }, { \\\"rt\\\": 36206, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 385589, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -B -B -F -Z -B -F -F -E -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:864,y:477,t:1527267379579};\\\", \\\"{x:866,y:478,t:1527267379608};\\\", \\\"{x:866,y:479,t:1527267379722};\\\", \\\"{x:867,y:480,t:1527267379753};\\\", \\\"{x:868,y:480,t:1527267379931};\\\", \\\"{x:851,y:485,t:1527267380181};\\\", \\\"{x:825,y:486,t:1527267380193};\\\", \\\"{x:718,y:500,t:1527267380209};\\\", \\\"{x:632,y:514,t:1527267380226};\\\", \\\"{x:563,y:522,t:1527267380243};\\\", \\\"{x:500,y:527,t:1527267380260};\\\", \\\"{x:457,y:527,t:1527267380277};\\\", \\\"{x:437,y:519,t:1527267380293};\\\", \\\"{x:422,y:510,t:1527267380310};\\\", \\\"{x:416,y:504,t:1527267380326};\\\", \\\"{x:413,y:502,t:1527267380343};\\\", \\\"{x:411,y:498,t:1527267380359};\\\", \\\"{x:410,y:496,t:1527267380377};\\\", \\\"{x:409,y:495,t:1527267380392};\\\", \\\"{x:407,y:492,t:1527267380410};\\\", \\\"{x:406,y:491,t:1527267380434};\\\", \\\"{x:405,y:491,t:1527267380443};\\\", \\\"{x:404,y:489,t:1527267380461};\\\", \\\"{x:404,y:488,t:1527267380477};\\\", \\\"{x:403,y:487,t:1527267380493};\\\", \\\"{x:403,y:486,t:1527267380510};\\\", \\\"{x:403,y:482,t:1527267380527};\\\", \\\"{x:403,y:478,t:1527267380544};\\\", \\\"{x:403,y:477,t:1527267380560};\\\", \\\"{x:403,y:476,t:1527267380586};\\\", \\\"{x:403,y:475,t:1527267380594};\\\", \\\"{x:404,y:475,t:1527267380610};\\\", \\\"{x:405,y:475,t:1527267380635};\\\", \\\"{x:407,y:475,t:1527267380644};\\\", \\\"{x:411,y:475,t:1527267380659};\\\", \\\"{x:419,y:474,t:1527267380677};\\\", \\\"{x:426,y:473,t:1527267380694};\\\", \\\"{x:441,y:473,t:1527267380710};\\\", \\\"{x:454,y:472,t:1527267380726};\\\", \\\"{x:463,y:471,t:1527267380744};\\\", \\\"{x:470,y:471,t:1527267380760};\\\", \\\"{x:474,y:471,t:1527267380777};\\\", \\\"{x:478,y:471,t:1527267380794};\\\", \\\"{x:480,y:471,t:1527267380810};\\\", \\\"{x:484,y:471,t:1527267380827};\\\", \\\"{x:488,y:471,t:1527267380843};\\\", \\\"{x:495,y:471,t:1527267380860};\\\", \\\"{x:505,y:471,t:1527267380877};\\\", \\\"{x:514,y:471,t:1527267380893};\\\", \\\"{x:523,y:472,t:1527267380910};\\\", \\\"{x:536,y:472,t:1527267380926};\\\", \\\"{x:551,y:472,t:1527267380944};\\\", \\\"{x:568,y:472,t:1527267380961};\\\", \\\"{x:583,y:472,t:1527267380977};\\\", \\\"{x:600,y:472,t:1527267380994};\\\", \\\"{x:603,y:472,t:1527267381010};\\\", \\\"{x:604,y:472,t:1527267381043};\\\", \\\"{x:605,y:472,t:1527267381058};\\\", \\\"{x:606,y:472,t:1527267381067};\\\", \\\"{x:608,y:472,t:1527267381077};\\\", \\\"{x:614,y:471,t:1527267381094};\\\", \\\"{x:617,y:471,t:1527267381112};\\\", \\\"{x:619,y:471,t:1527267381127};\\\", \\\"{x:620,y:471,t:1527267381144};\\\", \\\"{x:621,y:471,t:1527267381161};\\\", \\\"{x:623,y:471,t:1527267381418};\\\", \\\"{x:624,y:471,t:1527267381435};\\\", \\\"{x:626,y:471,t:1527267381444};\\\", \\\"{x:629,y:471,t:1527267381461};\\\", \\\"{x:634,y:471,t:1527267381478};\\\", \\\"{x:636,y:472,t:1527267381494};\\\", \\\"{x:637,y:472,t:1527267381511};\\\", \\\"{x:638,y:473,t:1527267381563};\\\", \\\"{x:640,y:474,t:1527267381642};\\\", \\\"{x:643,y:475,t:1527267381650};\\\", \\\"{x:648,y:476,t:1527267381661};\\\", \\\"{x:658,y:480,t:1527267381678};\\\", \\\"{x:691,y:488,t:1527267381696};\\\", \\\"{x:739,y:496,t:1527267381711};\\\", \\\"{x:803,y:504,t:1527267381728};\\\", \\\"{x:872,y:513,t:1527267381744};\\\", \\\"{x:960,y:520,t:1527267381761};\\\", \\\"{x:1036,y:522,t:1527267381777};\\\", \\\"{x:1128,y:524,t:1527267381794};\\\", \\\"{x:1207,y:530,t:1527267381810};\\\", \\\"{x:1285,y:530,t:1527267381827};\\\", \\\"{x:1357,y:530,t:1527267381845};\\\", \\\"{x:1438,y:530,t:1527267381860};\\\", \\\"{x:1516,y:530,t:1527267381878};\\\", \\\"{x:1583,y:531,t:1527267381894};\\\", \\\"{x:1658,y:531,t:1527267381910};\\\", \\\"{x:1721,y:536,t:1527267381928};\\\", \\\"{x:1733,y:538,t:1527267381945};\\\", \\\"{x:1744,y:539,t:1527267381961};\\\", \\\"{x:1745,y:539,t:1527267381978};\\\", \\\"{x:1745,y:541,t:1527267382041};\\\", \\\"{x:1740,y:545,t:1527267382050};\\\", \\\"{x:1734,y:550,t:1527267382061};\\\", \\\"{x:1721,y:557,t:1527267382078};\\\", \\\"{x:1700,y:568,t:1527267382095};\\\", \\\"{x:1690,y:574,t:1527267382111};\\\", \\\"{x:1679,y:581,t:1527267382128};\\\", \\\"{x:1667,y:587,t:1527267382145};\\\", \\\"{x:1653,y:593,t:1527267382161};\\\", \\\"{x:1634,y:601,t:1527267382178};\\\", \\\"{x:1629,y:604,t:1527267382195};\\\", \\\"{x:1621,y:607,t:1527267382211};\\\", \\\"{x:1618,y:611,t:1527267382228};\\\", \\\"{x:1615,y:615,t:1527267382245};\\\", \\\"{x:1612,y:619,t:1527267382261};\\\", \\\"{x:1606,y:629,t:1527267382279};\\\", \\\"{x:1595,y:637,t:1527267382295};\\\", \\\"{x:1581,y:646,t:1527267382311};\\\", \\\"{x:1574,y:649,t:1527267382328};\\\", \\\"{x:1563,y:652,t:1527267382345};\\\", \\\"{x:1549,y:657,t:1527267382362};\\\", \\\"{x:1538,y:658,t:1527267382378};\\\", \\\"{x:1535,y:658,t:1527267382395};\\\", \\\"{x:1533,y:658,t:1527267382411};\\\", \\\"{x:1529,y:658,t:1527267382429};\\\", \\\"{x:1528,y:658,t:1527267382445};\\\", \\\"{x:1526,y:658,t:1527267382491};\\\", \\\"{x:1524,y:657,t:1527267382506};\\\", \\\"{x:1518,y:656,t:1527267382514};\\\", \\\"{x:1509,y:651,t:1527267382529};\\\", \\\"{x:1480,y:640,t:1527267382545};\\\", \\\"{x:1440,y:627,t:1527267382563};\\\", \\\"{x:1412,y:623,t:1527267382579};\\\", \\\"{x:1380,y:619,t:1527267382596};\\\", \\\"{x:1358,y:615,t:1527267382613};\\\", \\\"{x:1343,y:611,t:1527267382628};\\\", \\\"{x:1332,y:607,t:1527267382645};\\\", \\\"{x:1324,y:603,t:1527267382662};\\\", \\\"{x:1319,y:601,t:1527267382679};\\\", \\\"{x:1316,y:599,t:1527267382695};\\\", \\\"{x:1315,y:597,t:1527267382739};\\\", \\\"{x:1311,y:594,t:1527267382754};\\\", \\\"{x:1307,y:590,t:1527267382762};\\\", \\\"{x:1307,y:589,t:1527267382778};\\\", \\\"{x:1306,y:588,t:1527267382796};\\\", \\\"{x:1306,y:587,t:1527267382813};\\\", \\\"{x:1306,y:586,t:1527267382828};\\\", \\\"{x:1306,y:585,t:1527267382850};\\\", \\\"{x:1306,y:583,t:1527267382862};\\\", \\\"{x:1304,y:580,t:1527267382879};\\\", \\\"{x:1303,y:579,t:1527267382896};\\\", \\\"{x:1303,y:578,t:1527267382915};\\\", \\\"{x:1302,y:577,t:1527267382938};\\\", \\\"{x:1301,y:576,t:1527267382954};\\\", \\\"{x:1300,y:575,t:1527267382962};\\\", \\\"{x:1297,y:574,t:1527267382979};\\\", \\\"{x:1294,y:573,t:1527267382996};\\\", \\\"{x:1293,y:573,t:1527267383523};\\\", \\\"{x:1293,y:577,t:1527267383539};\\\", \\\"{x:1293,y:578,t:1527267383547};\\\", \\\"{x:1295,y:581,t:1527267383561};\\\", \\\"{x:1296,y:583,t:1527267383579};\\\", \\\"{x:1298,y:584,t:1527267383595};\\\", \\\"{x:1299,y:587,t:1527267383612};\\\", \\\"{x:1302,y:591,t:1527267383629};\\\", \\\"{x:1302,y:592,t:1527267383646};\\\", \\\"{x:1303,y:594,t:1527267383662};\\\", \\\"{x:1302,y:594,t:1527267383771};\\\", \\\"{x:1301,y:594,t:1527267383779};\\\", \\\"{x:1298,y:594,t:1527267383796};\\\", \\\"{x:1295,y:594,t:1527267383812};\\\", \\\"{x:1294,y:594,t:1527267383829};\\\", \\\"{x:1293,y:594,t:1527267383846};\\\", \\\"{x:1292,y:594,t:1527267383915};\\\", \\\"{x:1292,y:593,t:1527267384907};\\\", \\\"{x:1291,y:593,t:1527267384914};\\\", \\\"{x:1296,y:611,t:1527267384930};\\\", \\\"{x:1305,y:629,t:1527267384947};\\\", \\\"{x:1313,y:648,t:1527267384964};\\\", \\\"{x:1319,y:663,t:1527267384981};\\\", \\\"{x:1325,y:677,t:1527267384997};\\\", \\\"{x:1332,y:692,t:1527267385013};\\\", \\\"{x:1338,y:705,t:1527267385030};\\\", \\\"{x:1341,y:717,t:1527267385046};\\\", \\\"{x:1346,y:730,t:1527267385064};\\\", \\\"{x:1347,y:740,t:1527267385081};\\\", \\\"{x:1351,y:751,t:1527267385097};\\\", \\\"{x:1353,y:753,t:1527267385114};\\\", \\\"{x:1353,y:762,t:1527267385133};\\\", \\\"{x:1355,y:764,t:1527267385146};\\\", \\\"{x:1355,y:766,t:1527267385163};\\\", \\\"{x:1355,y:767,t:1527267385180};\\\", \\\"{x:1355,y:768,t:1527267385196};\\\", \\\"{x:1355,y:769,t:1527267385306};\\\", \\\"{x:1355,y:770,t:1527267385355};\\\", \\\"{x:1354,y:770,t:1527267385386};\\\", \\\"{x:1354,y:769,t:1527267385397};\\\", \\\"{x:1353,y:768,t:1527267385413};\\\", \\\"{x:1353,y:765,t:1527267385430};\\\", \\\"{x:1351,y:762,t:1527267385447};\\\", \\\"{x:1351,y:758,t:1527267385464};\\\", \\\"{x:1351,y:751,t:1527267385480};\\\", \\\"{x:1351,y:744,t:1527267385498};\\\", \\\"{x:1351,y:738,t:1527267385513};\\\", \\\"{x:1353,y:731,t:1527267385530};\\\", \\\"{x:1354,y:728,t:1527267385548};\\\", \\\"{x:1354,y:723,t:1527267385563};\\\", \\\"{x:1354,y:718,t:1527267385580};\\\", \\\"{x:1354,y:715,t:1527267385597};\\\", \\\"{x:1354,y:712,t:1527267385613};\\\", \\\"{x:1354,y:709,t:1527267385631};\\\", \\\"{x:1354,y:708,t:1527267385647};\\\", \\\"{x:1354,y:707,t:1527267385664};\\\", \\\"{x:1354,y:706,t:1527267385680};\\\", \\\"{x:1354,y:705,t:1527267385731};\\\", \\\"{x:1354,y:704,t:1527267385795};\\\", \\\"{x:1354,y:703,t:1527267385803};\\\", \\\"{x:1354,y:702,t:1527267385818};\\\", \\\"{x:1353,y:702,t:1527267385835};\\\", \\\"{x:1353,y:701,t:1527267385891};\\\", \\\"{x:1353,y:700,t:1527267385906};\\\", \\\"{x:1352,y:700,t:1527267386051};\\\", \\\"{x:1348,y:699,t:1527267386618};\\\", \\\"{x:1347,y:699,t:1527267386633};\\\", \\\"{x:1347,y:698,t:1527267386647};\\\", \\\"{x:1346,y:698,t:1527267386664};\\\", \\\"{x:1345,y:698,t:1527267386730};\\\", \\\"{x:1344,y:698,t:1527267386738};\\\", \\\"{x:1344,y:697,t:1527267386777};\\\", \\\"{x:1344,y:699,t:1527267389331};\\\", \\\"{x:1342,y:701,t:1527267389340};\\\", \\\"{x:1342,y:702,t:1527267389353};\\\", \\\"{x:1342,y:703,t:1527267389378};\\\", \\\"{x:1342,y:704,t:1527267389425};\\\", \\\"{x:1342,y:705,t:1527267389441};\\\", \\\"{x:1341,y:707,t:1527267389465};\\\", \\\"{x:1341,y:708,t:1527267389485};\\\", \\\"{x:1340,y:710,t:1527267389502};\\\", \\\"{x:1340,y:713,t:1527267389534};\\\", \\\"{x:1339,y:714,t:1527267389549};\\\", \\\"{x:1338,y:715,t:1527267389565};\\\", \\\"{x:1338,y:716,t:1527267389581};\\\", \\\"{x:1338,y:717,t:1527267389598};\\\", \\\"{x:1338,y:718,t:1527267389606};\\\", \\\"{x:1338,y:719,t:1527267389620};\\\", \\\"{x:1338,y:721,t:1527267389636};\\\", \\\"{x:1338,y:722,t:1527267389653};\\\", \\\"{x:1338,y:725,t:1527267389669};\\\", \\\"{x:1338,y:726,t:1527267389686};\\\", \\\"{x:1338,y:728,t:1527267389704};\\\", \\\"{x:1338,y:729,t:1527267389720};\\\", \\\"{x:1338,y:730,t:1527267389742};\\\", \\\"{x:1338,y:731,t:1527267389758};\\\", \\\"{x:1338,y:732,t:1527267389771};\\\", \\\"{x:1338,y:733,t:1527267389786};\\\", \\\"{x:1338,y:734,t:1527267389803};\\\", \\\"{x:1338,y:735,t:1527267389821};\\\", \\\"{x:1338,y:736,t:1527267389837};\\\", \\\"{x:1338,y:737,t:1527267389853};\\\", \\\"{x:1338,y:738,t:1527267389870};\\\", \\\"{x:1339,y:738,t:1527267389886};\\\", \\\"{x:1339,y:740,t:1527267389903};\\\", \\\"{x:1340,y:743,t:1527267389920};\\\", \\\"{x:1341,y:745,t:1527267389936};\\\", \\\"{x:1341,y:746,t:1527267389953};\\\", \\\"{x:1343,y:751,t:1527267389970};\\\", \\\"{x:1343,y:754,t:1527267389986};\\\", \\\"{x:1343,y:757,t:1527267390002};\\\", \\\"{x:1343,y:761,t:1527267390021};\\\", \\\"{x:1343,y:765,t:1527267390037};\\\", \\\"{x:1343,y:768,t:1527267390054};\\\", \\\"{x:1343,y:770,t:1527267390070};\\\", \\\"{x:1343,y:771,t:1527267390093};\\\", \\\"{x:1343,y:773,t:1527267390110};\\\", \\\"{x:1343,y:774,t:1527267390120};\\\", \\\"{x:1343,y:776,t:1527267390137};\\\", \\\"{x:1343,y:780,t:1527267390152};\\\", \\\"{x:1343,y:782,t:1527267390170};\\\", \\\"{x:1343,y:787,t:1527267390187};\\\", \\\"{x:1343,y:789,t:1527267390203};\\\", \\\"{x:1343,y:791,t:1527267390220};\\\", \\\"{x:1343,y:794,t:1527267390237};\\\", \\\"{x:1343,y:797,t:1527267390254};\\\", \\\"{x:1343,y:801,t:1527267390270};\\\", \\\"{x:1343,y:805,t:1527267390287};\\\", \\\"{x:1343,y:808,t:1527267390303};\\\", \\\"{x:1343,y:811,t:1527267390320};\\\", \\\"{x:1343,y:813,t:1527267390340};\\\", \\\"{x:1343,y:814,t:1527267390357};\\\", \\\"{x:1343,y:816,t:1527267390373};\\\", \\\"{x:1343,y:817,t:1527267390389};\\\", \\\"{x:1343,y:820,t:1527267390403};\\\", \\\"{x:1343,y:822,t:1527267390420};\\\", \\\"{x:1343,y:825,t:1527267390436};\\\", \\\"{x:1345,y:829,t:1527267390452};\\\", \\\"{x:1345,y:832,t:1527267390469};\\\", \\\"{x:1345,y:836,t:1527267390486};\\\", \\\"{x:1345,y:839,t:1527267390503};\\\", \\\"{x:1345,y:843,t:1527267390520};\\\", \\\"{x:1345,y:847,t:1527267390536};\\\", \\\"{x:1345,y:850,t:1527267390553};\\\", \\\"{x:1345,y:855,t:1527267390570};\\\", \\\"{x:1345,y:858,t:1527267390586};\\\", \\\"{x:1345,y:861,t:1527267390603};\\\", \\\"{x:1345,y:865,t:1527267390620};\\\", \\\"{x:1345,y:868,t:1527267390637};\\\", \\\"{x:1345,y:872,t:1527267390653};\\\", \\\"{x:1345,y:877,t:1527267390670};\\\", \\\"{x:1345,y:882,t:1527267390687};\\\", \\\"{x:1345,y:886,t:1527267390704};\\\", \\\"{x:1346,y:893,t:1527267390720};\\\", \\\"{x:1346,y:897,t:1527267390737};\\\", \\\"{x:1346,y:902,t:1527267390754};\\\", \\\"{x:1346,y:909,t:1527267390770};\\\", \\\"{x:1346,y:915,t:1527267390787};\\\", \\\"{x:1346,y:921,t:1527267390803};\\\", \\\"{x:1346,y:926,t:1527267390820};\\\", \\\"{x:1347,y:929,t:1527267390837};\\\", \\\"{x:1347,y:935,t:1527267390853};\\\", \\\"{x:1347,y:937,t:1527267390870};\\\", \\\"{x:1347,y:940,t:1527267390887};\\\", \\\"{x:1347,y:944,t:1527267390904};\\\", \\\"{x:1345,y:952,t:1527267390920};\\\", \\\"{x:1343,y:959,t:1527267390937};\\\", \\\"{x:1343,y:964,t:1527267390954};\\\", \\\"{x:1343,y:967,t:1527267390971};\\\", \\\"{x:1343,y:968,t:1527267390989};\\\", \\\"{x:1343,y:965,t:1527267391030};\\\", \\\"{x:1343,y:956,t:1527267391037};\\\", \\\"{x:1343,y:933,t:1527267391054};\\\", \\\"{x:1343,y:892,t:1527267391070};\\\", \\\"{x:1337,y:831,t:1527267391087};\\\", \\\"{x:1327,y:770,t:1527267391104};\\\", \\\"{x:1319,y:717,t:1527267391120};\\\", \\\"{x:1315,y:696,t:1527267391137};\\\", \\\"{x:1317,y:676,t:1527267391154};\\\", \\\"{x:1322,y:655,t:1527267391171};\\\", \\\"{x:1326,y:637,t:1527267391187};\\\", \\\"{x:1330,y:625,t:1527267391204};\\\", \\\"{x:1332,y:621,t:1527267391222};\\\", \\\"{x:1332,y:620,t:1527267391237};\\\", \\\"{x:1332,y:618,t:1527267391253};\\\", \\\"{x:1334,y:620,t:1527267391366};\\\", \\\"{x:1336,y:627,t:1527267391374};\\\", \\\"{x:1340,y:635,t:1527267391387};\\\", \\\"{x:1347,y:657,t:1527267391404};\\\", \\\"{x:1353,y:678,t:1527267391421};\\\", \\\"{x:1359,y:700,t:1527267391437};\\\", \\\"{x:1367,y:722,t:1527267391454};\\\", \\\"{x:1367,y:725,t:1527267391471};\\\", \\\"{x:1367,y:726,t:1527267391487};\\\", \\\"{x:1363,y:727,t:1527267391591};\\\", \\\"{x:1358,y:722,t:1527267391605};\\\", \\\"{x:1348,y:708,t:1527267391621};\\\", \\\"{x:1347,y:707,t:1527267391637};\\\", \\\"{x:1344,y:702,t:1527267391654};\\\", \\\"{x:1344,y:701,t:1527267391671};\\\", \\\"{x:1343,y:700,t:1527267391773};\\\", \\\"{x:1344,y:700,t:1527267394206};\\\", \\\"{x:1365,y:696,t:1527267394223};\\\", \\\"{x:1387,y:691,t:1527267394240};\\\", \\\"{x:1412,y:689,t:1527267394256};\\\", \\\"{x:1438,y:688,t:1527267394272};\\\", \\\"{x:1459,y:685,t:1527267394289};\\\", \\\"{x:1483,y:682,t:1527267394306};\\\", \\\"{x:1513,y:678,t:1527267394322};\\\", \\\"{x:1539,y:672,t:1527267394340};\\\", \\\"{x:1558,y:666,t:1527267394356};\\\", \\\"{x:1575,y:664,t:1527267394373};\\\", \\\"{x:1580,y:663,t:1527267394389};\\\", \\\"{x:1581,y:662,t:1527267394406};\\\", \\\"{x:1584,y:662,t:1527267394503};\\\", \\\"{x:1591,y:663,t:1527267394510};\\\", \\\"{x:1594,y:666,t:1527267394522};\\\", \\\"{x:1598,y:670,t:1527267394539};\\\", \\\"{x:1600,y:675,t:1527267394556};\\\", \\\"{x:1601,y:679,t:1527267394572};\\\", \\\"{x:1601,y:683,t:1527267394588};\\\", \\\"{x:1602,y:685,t:1527267394606};\\\", \\\"{x:1602,y:687,t:1527267394622};\\\", \\\"{x:1603,y:687,t:1527267394652};\\\", \\\"{x:1604,y:687,t:1527267394661};\\\", \\\"{x:1605,y:687,t:1527267394806};\\\", \\\"{x:1608,y:687,t:1527267394824};\\\", \\\"{x:1609,y:688,t:1527267394966};\\\", \\\"{x:1609,y:689,t:1527267394982};\\\", \\\"{x:1609,y:690,t:1527267394998};\\\", \\\"{x:1609,y:691,t:1527267395063};\\\", \\\"{x:1609,y:693,t:1527267395077};\\\", \\\"{x:1610,y:695,t:1527267395094};\\\", \\\"{x:1611,y:695,t:1527267399286};\\\", \\\"{x:1605,y:695,t:1527267401647};\\\", \\\"{x:1597,y:696,t:1527267401662};\\\", \\\"{x:1575,y:706,t:1527267401677};\\\", \\\"{x:1510,y:732,t:1527267401693};\\\", \\\"{x:1404,y:768,t:1527267401711};\\\", \\\"{x:1249,y:812,t:1527267401728};\\\", \\\"{x:1091,y:836,t:1527267401743};\\\", \\\"{x:943,y:845,t:1527267401761};\\\", \\\"{x:806,y:840,t:1527267401777};\\\", \\\"{x:692,y:821,t:1527267401794};\\\", \\\"{x:624,y:808,t:1527267401810};\\\", \\\"{x:598,y:796,t:1527267401827};\\\", \\\"{x:589,y:790,t:1527267401843};\\\", \\\"{x:585,y:782,t:1527267401861};\\\", \\\"{x:579,y:761,t:1527267401877};\\\", \\\"{x:578,y:755,t:1527267401893};\\\", \\\"{x:572,y:744,t:1527267401911};\\\", \\\"{x:568,y:737,t:1527267401928};\\\", \\\"{x:561,y:728,t:1527267401945};\\\", \\\"{x:553,y:719,t:1527267401961};\\\", \\\"{x:544,y:713,t:1527267401977};\\\", \\\"{x:540,y:710,t:1527267401996};\\\", \\\"{x:539,y:707,t:1527267402014};\\\", \\\"{x:535,y:700,t:1527267402030};\\\", \\\"{x:530,y:689,t:1527267402047};\\\", \\\"{x:522,y:679,t:1527267402064};\\\", \\\"{x:515,y:671,t:1527267402080};\\\", \\\"{x:512,y:663,t:1527267402097};\\\", \\\"{x:508,y:652,t:1527267402115};\\\", \\\"{x:506,y:639,t:1527267402131};\\\", \\\"{x:504,y:635,t:1527267402148};\\\", \\\"{x:504,y:626,t:1527267402164};\\\", \\\"{x:504,y:622,t:1527267402180};\\\", \\\"{x:503,y:614,t:1527267402198};\\\", \\\"{x:503,y:612,t:1527267402214};\\\", \\\"{x:502,y:608,t:1527267402231};\\\", \\\"{x:499,y:604,t:1527267402248};\\\", \\\"{x:495,y:600,t:1527267402266};\\\", \\\"{x:488,y:595,t:1527267402281};\\\", \\\"{x:476,y:588,t:1527267402298};\\\", \\\"{x:464,y:580,t:1527267402314};\\\", \\\"{x:452,y:575,t:1527267402331};\\\", \\\"{x:439,y:571,t:1527267402348};\\\", \\\"{x:427,y:570,t:1527267402364};\\\", \\\"{x:410,y:566,t:1527267402381};\\\", \\\"{x:406,y:565,t:1527267402399};\\\", \\\"{x:406,y:564,t:1527267402414};\\\", \\\"{x:408,y:564,t:1527267402510};\\\", \\\"{x:411,y:564,t:1527267402517};\\\", \\\"{x:414,y:564,t:1527267402531};\\\", \\\"{x:428,y:566,t:1527267402549};\\\", \\\"{x:448,y:568,t:1527267402564};\\\", \\\"{x:478,y:572,t:1527267402582};\\\", \\\"{x:498,y:572,t:1527267402598};\\\", \\\"{x:521,y:572,t:1527267402616};\\\", \\\"{x:542,y:574,t:1527267402631};\\\", \\\"{x:563,y:577,t:1527267402648};\\\", \\\"{x:582,y:579,t:1527267402665};\\\", \\\"{x:600,y:582,t:1527267402681};\\\", \\\"{x:610,y:583,t:1527267402698};\\\", \\\"{x:613,y:583,t:1527267402714};\\\", \\\"{x:614,y:583,t:1527267402773};\\\", \\\"{x:613,y:583,t:1527267402950};\\\", \\\"{x:609,y:583,t:1527267402965};\\\", \\\"{x:605,y:582,t:1527267402981};\\\", \\\"{x:603,y:581,t:1527267402999};\\\", \\\"{x:602,y:581,t:1527267403016};\\\", \\\"{x:604,y:582,t:1527267403789};\\\", \\\"{x:605,y:582,t:1527267403813};\\\", \\\"{x:607,y:583,t:1527267404086};\\\", \\\"{x:615,y:585,t:1527267404100};\\\", \\\"{x:655,y:601,t:1527267404117};\\\", \\\"{x:704,y:620,t:1527267404132};\\\", \\\"{x:899,y:665,t:1527267404150};\\\", \\\"{x:1037,y:699,t:1527267404166};\\\", \\\"{x:1165,y:720,t:1527267404182};\\\", \\\"{x:1268,y:736,t:1527267404199};\\\", \\\"{x:1345,y:747,t:1527267404217};\\\", \\\"{x:1403,y:753,t:1527267404232};\\\", \\\"{x:1427,y:753,t:1527267404249};\\\", \\\"{x:1429,y:753,t:1527267404266};\\\", \\\"{x:1430,y:754,t:1527267404509};\\\", \\\"{x:1430,y:755,t:1527267404517};\\\", \\\"{x:1430,y:756,t:1527267404550};\\\", \\\"{x:1428,y:756,t:1527267404567};\\\", \\\"{x:1427,y:756,t:1527267404582};\\\", \\\"{x:1424,y:755,t:1527267404599};\\\", \\\"{x:1421,y:753,t:1527267404617};\\\", \\\"{x:1417,y:752,t:1527267404633};\\\", \\\"{x:1414,y:751,t:1527267404649};\\\", \\\"{x:1410,y:748,t:1527267404666};\\\", \\\"{x:1406,y:746,t:1527267404683};\\\", \\\"{x:1403,y:744,t:1527267404699};\\\", \\\"{x:1401,y:744,t:1527267404716};\\\", \\\"{x:1398,y:741,t:1527267404732};\\\", \\\"{x:1394,y:739,t:1527267404749};\\\", \\\"{x:1391,y:736,t:1527267404767};\\\", \\\"{x:1390,y:734,t:1527267404783};\\\", \\\"{x:1388,y:731,t:1527267404799};\\\", \\\"{x:1387,y:725,t:1527267404816};\\\", \\\"{x:1382,y:718,t:1527267404834};\\\", \\\"{x:1378,y:711,t:1527267404850};\\\", \\\"{x:1374,y:706,t:1527267404866};\\\", \\\"{x:1370,y:703,t:1527267404884};\\\", \\\"{x:1369,y:702,t:1527267404899};\\\", \\\"{x:1368,y:701,t:1527267404917};\\\", \\\"{x:1366,y:701,t:1527267404934};\\\", \\\"{x:1362,y:700,t:1527267404949};\\\", \\\"{x:1359,y:699,t:1527267404966};\\\", \\\"{x:1357,y:699,t:1527267404983};\\\", \\\"{x:1355,y:699,t:1527267405182};\\\", \\\"{x:1352,y:699,t:1527267405190};\\\", \\\"{x:1351,y:698,t:1527267405201};\\\", \\\"{x:1350,y:698,t:1527267405217};\\\", \\\"{x:1348,y:697,t:1527267405234};\\\", \\\"{x:1347,y:697,t:1527267405286};\\\", \\\"{x:1346,y:696,t:1527267405301};\\\", \\\"{x:1345,y:696,t:1527267405334};\\\", \\\"{x:1344,y:693,t:1527267407438};\\\", \\\"{x:1344,y:689,t:1527267407452};\\\", \\\"{x:1344,y:682,t:1527267407470};\\\", \\\"{x:1344,y:681,t:1527267407485};\\\", \\\"{x:1343,y:672,t:1527267407502};\\\", \\\"{x:1340,y:664,t:1527267407519};\\\", \\\"{x:1337,y:655,t:1527267407535};\\\", \\\"{x:1335,y:648,t:1527267407552};\\\", \\\"{x:1331,y:639,t:1527267407568};\\\", \\\"{x:1328,y:632,t:1527267407586};\\\", \\\"{x:1325,y:627,t:1527267407602};\\\", \\\"{x:1321,y:622,t:1527267407619};\\\", \\\"{x:1319,y:619,t:1527267407636};\\\", \\\"{x:1318,y:618,t:1527267407652};\\\", \\\"{x:1315,y:614,t:1527267407669};\\\", \\\"{x:1310,y:609,t:1527267407686};\\\", \\\"{x:1308,y:605,t:1527267407702};\\\", \\\"{x:1305,y:602,t:1527267407719};\\\", \\\"{x:1305,y:600,t:1527267407736};\\\", \\\"{x:1303,y:598,t:1527267407751};\\\", \\\"{x:1302,y:596,t:1527267407769};\\\", \\\"{x:1300,y:595,t:1527267407786};\\\", \\\"{x:1297,y:592,t:1527267407801};\\\", \\\"{x:1294,y:589,t:1527267407818};\\\", \\\"{x:1293,y:587,t:1527267407836};\\\", \\\"{x:1293,y:585,t:1527267407851};\\\", \\\"{x:1291,y:583,t:1527267407868};\\\", \\\"{x:1289,y:577,t:1527267407886};\\\", \\\"{x:1287,y:576,t:1527267407902};\\\", \\\"{x:1286,y:574,t:1527267407918};\\\", \\\"{x:1285,y:572,t:1527267407935};\\\", \\\"{x:1284,y:572,t:1527267407952};\\\", \\\"{x:1284,y:571,t:1527267407973};\\\", \\\"{x:1284,y:570,t:1527267407990};\\\", \\\"{x:1282,y:568,t:1527267408003};\\\", \\\"{x:1282,y:565,t:1527267408019};\\\", \\\"{x:1280,y:561,t:1527267408035};\\\", \\\"{x:1279,y:559,t:1527267408053};\\\", \\\"{x:1278,y:559,t:1527267408494};\\\", \\\"{x:1278,y:560,t:1527267408503};\\\", \\\"{x:1278,y:562,t:1527267408520};\\\", \\\"{x:1278,y:563,t:1527267408536};\\\", \\\"{x:1278,y:564,t:1527267408553};\\\", \\\"{x:1278,y:567,t:1527267411998};\\\", \\\"{x:1278,y:569,t:1527267412006};\\\", \\\"{x:1278,y:571,t:1527267412023};\\\", \\\"{x:1278,y:573,t:1527267412039};\\\", \\\"{x:1278,y:574,t:1527267412055};\\\", \\\"{x:1278,y:575,t:1527267412166};\\\", \\\"{x:1279,y:577,t:1527267412173};\\\", \\\"{x:1279,y:580,t:1527267412190};\\\", \\\"{x:1279,y:583,t:1527267412206};\\\", \\\"{x:1280,y:584,t:1527267412222};\\\", \\\"{x:1280,y:587,t:1527267412239};\\\", \\\"{x:1281,y:589,t:1527267412255};\\\", \\\"{x:1282,y:590,t:1527267412272};\\\", \\\"{x:1282,y:593,t:1527267412289};\\\", \\\"{x:1283,y:595,t:1527267412307};\\\", \\\"{x:1284,y:598,t:1527267412322};\\\", \\\"{x:1284,y:603,t:1527267412339};\\\", \\\"{x:1285,y:607,t:1527267412356};\\\", \\\"{x:1286,y:612,t:1527267412372};\\\", \\\"{x:1287,y:620,t:1527267412389};\\\", \\\"{x:1288,y:628,t:1527267412405};\\\", \\\"{x:1289,y:635,t:1527267412422};\\\", \\\"{x:1289,y:639,t:1527267412439};\\\", \\\"{x:1290,y:646,t:1527267412456};\\\", \\\"{x:1292,y:650,t:1527267412472};\\\", \\\"{x:1293,y:655,t:1527267412489};\\\", \\\"{x:1295,y:660,t:1527267412506};\\\", \\\"{x:1298,y:668,t:1527267412522};\\\", \\\"{x:1298,y:672,t:1527267412540};\\\", \\\"{x:1298,y:679,t:1527267412556};\\\", \\\"{x:1298,y:688,t:1527267412572};\\\", \\\"{x:1298,y:698,t:1527267412589};\\\", \\\"{x:1298,y:706,t:1527267412605};\\\", \\\"{x:1298,y:715,t:1527267412622};\\\", \\\"{x:1298,y:722,t:1527267412640};\\\", \\\"{x:1298,y:727,t:1527267412656};\\\", \\\"{x:1298,y:734,t:1527267412672};\\\", \\\"{x:1298,y:739,t:1527267412689};\\\", \\\"{x:1298,y:742,t:1527267412706};\\\", \\\"{x:1298,y:746,t:1527267412722};\\\", \\\"{x:1298,y:750,t:1527267412739};\\\", \\\"{x:1298,y:756,t:1527267412757};\\\", \\\"{x:1298,y:761,t:1527267412773};\\\", \\\"{x:1298,y:768,t:1527267412789};\\\", \\\"{x:1298,y:774,t:1527267412805};\\\", \\\"{x:1298,y:780,t:1527267412822};\\\", \\\"{x:1298,y:788,t:1527267412838};\\\", \\\"{x:1298,y:795,t:1527267412855};\\\", \\\"{x:1297,y:803,t:1527267412872};\\\", \\\"{x:1296,y:808,t:1527267412889};\\\", \\\"{x:1294,y:814,t:1527267412906};\\\", \\\"{x:1294,y:818,t:1527267412922};\\\", \\\"{x:1294,y:822,t:1527267412939};\\\", \\\"{x:1293,y:825,t:1527267412956};\\\", \\\"{x:1293,y:830,t:1527267412972};\\\", \\\"{x:1293,y:834,t:1527267412989};\\\", \\\"{x:1293,y:838,t:1527267413006};\\\", \\\"{x:1292,y:844,t:1527267413023};\\\", \\\"{x:1291,y:849,t:1527267413039};\\\", \\\"{x:1290,y:854,t:1527267413056};\\\", \\\"{x:1289,y:861,t:1527267413073};\\\", \\\"{x:1288,y:866,t:1527267413089};\\\", \\\"{x:1288,y:872,t:1527267413106};\\\", \\\"{x:1286,y:879,t:1527267413123};\\\", \\\"{x:1285,y:886,t:1527267413139};\\\", \\\"{x:1284,y:893,t:1527267413156};\\\", \\\"{x:1284,y:902,t:1527267413173};\\\", \\\"{x:1283,y:907,t:1527267413189};\\\", \\\"{x:1283,y:911,t:1527267413206};\\\", \\\"{x:1283,y:915,t:1527267413223};\\\", \\\"{x:1283,y:919,t:1527267413239};\\\", \\\"{x:1283,y:924,t:1527267413256};\\\", \\\"{x:1283,y:929,t:1527267413273};\\\", \\\"{x:1283,y:933,t:1527267413290};\\\", \\\"{x:1283,y:937,t:1527267413306};\\\", \\\"{x:1283,y:940,t:1527267413323};\\\", \\\"{x:1283,y:942,t:1527267413339};\\\", \\\"{x:1283,y:945,t:1527267413356};\\\", \\\"{x:1286,y:949,t:1527267413373};\\\", \\\"{x:1290,y:953,t:1527267413389};\\\", \\\"{x:1293,y:957,t:1527267413406};\\\", \\\"{x:1294,y:958,t:1527267413423};\\\", \\\"{x:1294,y:960,t:1527267413440};\\\", \\\"{x:1294,y:957,t:1527267413612};\\\", \\\"{x:1294,y:954,t:1527267413622};\\\", \\\"{x:1294,y:948,t:1527267413640};\\\", \\\"{x:1294,y:940,t:1527267413656};\\\", \\\"{x:1294,y:932,t:1527267413673};\\\", \\\"{x:1296,y:923,t:1527267413689};\\\", \\\"{x:1297,y:909,t:1527267413707};\\\", \\\"{x:1297,y:889,t:1527267413722};\\\", \\\"{x:1303,y:847,t:1527267413740};\\\", \\\"{x:1306,y:787,t:1527267413756};\\\", \\\"{x:1312,y:734,t:1527267413772};\\\", \\\"{x:1323,y:677,t:1527267413789};\\\", \\\"{x:1343,y:626,t:1527267413806};\\\", \\\"{x:1353,y:582,t:1527267413823};\\\", \\\"{x:1361,y:549,t:1527267413840};\\\", \\\"{x:1365,y:525,t:1527267413856};\\\", \\\"{x:1366,y:512,t:1527267413873};\\\", \\\"{x:1368,y:504,t:1527267413889};\\\", \\\"{x:1368,y:499,t:1527267413906};\\\", \\\"{x:1368,y:494,t:1527267413922};\\\", \\\"{x:1366,y:486,t:1527267413939};\\\", \\\"{x:1365,y:481,t:1527267413956};\\\", \\\"{x:1365,y:479,t:1527267413972};\\\", \\\"{x:1365,y:478,t:1527267413989};\\\", \\\"{x:1365,y:477,t:1527267414029};\\\", \\\"{x:1365,y:475,t:1527267414044};\\\", \\\"{x:1366,y:473,t:1527267414057};\\\", \\\"{x:1371,y:465,t:1527267414073};\\\", \\\"{x:1380,y:456,t:1527267414090};\\\", \\\"{x:1390,y:447,t:1527267414107};\\\", \\\"{x:1396,y:443,t:1527267414124};\\\", \\\"{x:1405,y:436,t:1527267414140};\\\", \\\"{x:1420,y:428,t:1527267414157};\\\", \\\"{x:1425,y:424,t:1527267414174};\\\", \\\"{x:1432,y:420,t:1527267414189};\\\", \\\"{x:1437,y:418,t:1527267414206};\\\", \\\"{x:1440,y:416,t:1527267414223};\\\", \\\"{x:1439,y:417,t:1527267414422};\\\", \\\"{x:1437,y:419,t:1527267414430};\\\", \\\"{x:1434,y:421,t:1527267414440};\\\", \\\"{x:1432,y:422,t:1527267414457};\\\", \\\"{x:1430,y:424,t:1527267414474};\\\", \\\"{x:1428,y:425,t:1527267414493};\\\", \\\"{x:1428,y:426,t:1527267414989};\\\", \\\"{x:1424,y:431,t:1527267414997};\\\", \\\"{x:1419,y:437,t:1527267415007};\\\", \\\"{x:1409,y:453,t:1527267415024};\\\", \\\"{x:1400,y:471,t:1527267415041};\\\", \\\"{x:1388,y:492,t:1527267415057};\\\", \\\"{x:1376,y:513,t:1527267415074};\\\", \\\"{x:1356,y:545,t:1527267415091};\\\", \\\"{x:1327,y:583,t:1527267415107};\\\", \\\"{x:1293,y:629,t:1527267415124};\\\", \\\"{x:1240,y:686,t:1527267415141};\\\", \\\"{x:1196,y:715,t:1527267415157};\\\", \\\"{x:1146,y:737,t:1527267415174};\\\", \\\"{x:1092,y:756,t:1527267415191};\\\", \\\"{x:1048,y:767,t:1527267415208};\\\", \\\"{x:990,y:774,t:1527267415224};\\\", \\\"{x:948,y:778,t:1527267415241};\\\", \\\"{x:908,y:778,t:1527267415258};\\\", \\\"{x:875,y:778,t:1527267415274};\\\", \\\"{x:825,y:778,t:1527267415291};\\\", \\\"{x:750,y:778,t:1527267415308};\\\", \\\"{x:673,y:787,t:1527267415324};\\\", \\\"{x:590,y:798,t:1527267415341};\\\", \\\"{x:556,y:798,t:1527267415358};\\\", \\\"{x:530,y:798,t:1527267415374};\\\", \\\"{x:514,y:791,t:1527267415392};\\\", \\\"{x:504,y:783,t:1527267415409};\\\", \\\"{x:498,y:779,t:1527267415424};\\\", \\\"{x:496,y:775,t:1527267415441};\\\", \\\"{x:493,y:766,t:1527267415458};\\\", \\\"{x:491,y:753,t:1527267415476};\\\", \\\"{x:489,y:750,t:1527267415490};\\\", \\\"{x:487,y:748,t:1527267415508};\\\", \\\"{x:485,y:747,t:1527267415524};\\\", \\\"{x:485,y:745,t:1527267415581};\\\", \\\"{x:484,y:744,t:1527267415592};\\\", \\\"{x:483,y:739,t:1527267415609};\\\", \\\"{x:481,y:732,t:1527267415625};\\\", \\\"{x:480,y:731,t:1527267415642};\\\", \\\"{x:480,y:730,t:1527267415659};\\\", \\\"{x:480,y:727,t:1527267415989};\\\", \\\"{x:488,y:716,t:1527267415997};\\\", \\\"{x:500,y:700,t:1527267416008};\\\", \\\"{x:551,y:651,t:1527267416026};\\\", \\\"{x:622,y:596,t:1527267416042};\\\", \\\"{x:684,y:548,t:1527267416059};\\\", \\\"{x:723,y:516,t:1527267416075};\\\", \\\"{x:750,y:485,t:1527267416092};\\\", \\\"{x:758,y:476,t:1527267416109};\\\" ] }, { \\\"rt\\\": 9536, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 396375, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-12 PM-B -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:755,y:486,t:1527267417525};\\\", \\\"{x:750,y:495,t:1527267417533};\\\", \\\"{x:696,y:572,t:1527267417626};\\\", \\\"{x:695,y:572,t:1527267417701};\\\", \\\"{x:694,y:572,t:1527267417717};\\\", \\\"{x:690,y:570,t:1527267417727};\\\", \\\"{x:684,y:561,t:1527267417744};\\\", \\\"{x:674,y:551,t:1527267417760};\\\", \\\"{x:661,y:545,t:1527267417777};\\\", \\\"{x:646,y:539,t:1527267417794};\\\", \\\"{x:630,y:532,t:1527267417810};\\\", \\\"{x:615,y:526,t:1527267417827};\\\", \\\"{x:602,y:520,t:1527267417845};\\\", \\\"{x:590,y:517,t:1527267417860};\\\", \\\"{x:575,y:512,t:1527267417877};\\\", \\\"{x:567,y:510,t:1527267417894};\\\", \\\"{x:560,y:508,t:1527267417910};\\\", \\\"{x:541,y:505,t:1527267417926};\\\", \\\"{x:523,y:503,t:1527267417944};\\\", \\\"{x:510,y:500,t:1527267417960};\\\", \\\"{x:501,y:496,t:1527267417977};\\\", \\\"{x:495,y:494,t:1527267417995};\\\", \\\"{x:494,y:493,t:1527267418061};\\\", \\\"{x:494,y:492,t:1527267418117};\\\", \\\"{x:496,y:489,t:1527267418181};\\\", \\\"{x:498,y:489,t:1527267418196};\\\", \\\"{x:507,y:485,t:1527267418213};\\\", \\\"{x:520,y:483,t:1527267418228};\\\", \\\"{x:527,y:482,t:1527267418244};\\\", \\\"{x:531,y:482,t:1527267418261};\\\", \\\"{x:533,y:482,t:1527267418277};\\\", \\\"{x:534,y:481,t:1527267418294};\\\", \\\"{x:536,y:481,t:1527267418310};\\\", \\\"{x:540,y:480,t:1527267418327};\\\", \\\"{x:545,y:480,t:1527267418343};\\\", \\\"{x:550,y:479,t:1527267418361};\\\", \\\"{x:553,y:479,t:1527267418378};\\\", \\\"{x:557,y:478,t:1527267418394};\\\", \\\"{x:562,y:478,t:1527267418410};\\\", \\\"{x:566,y:478,t:1527267418428};\\\", \\\"{x:573,y:478,t:1527267418444};\\\", \\\"{x:586,y:478,t:1527267418460};\\\", \\\"{x:592,y:478,t:1527267418478};\\\", \\\"{x:598,y:478,t:1527267418494};\\\", \\\"{x:608,y:478,t:1527267418511};\\\", \\\"{x:617,y:478,t:1527267418528};\\\", \\\"{x:626,y:478,t:1527267418544};\\\", \\\"{x:631,y:478,t:1527267418561};\\\", \\\"{x:633,y:478,t:1527267418578};\\\", \\\"{x:634,y:478,t:1527267418594};\\\", \\\"{x:635,y:478,t:1527267418611};\\\", \\\"{x:636,y:478,t:1527267418637};\\\", \\\"{x:639,y:478,t:1527267418645};\\\", \\\"{x:648,y:478,t:1527267418661};\\\", \\\"{x:665,y:478,t:1527267418678};\\\", \\\"{x:689,y:478,t:1527267418694};\\\", \\\"{x:735,y:478,t:1527267418711};\\\", \\\"{x:799,y:478,t:1527267418727};\\\", \\\"{x:882,y:478,t:1527267418744};\\\", \\\"{x:971,y:478,t:1527267418761};\\\", \\\"{x:1041,y:478,t:1527267418778};\\\", \\\"{x:1103,y:480,t:1527267418795};\\\", \\\"{x:1159,y:488,t:1527267418811};\\\", \\\"{x:1205,y:497,t:1527267418828};\\\", \\\"{x:1227,y:503,t:1527267418844};\\\", \\\"{x:1251,y:515,t:1527267418861};\\\", \\\"{x:1269,y:528,t:1527267418878};\\\", \\\"{x:1289,y:547,t:1527267418895};\\\", \\\"{x:1326,y:579,t:1527267418911};\\\", \\\"{x:1364,y:613,t:1527267418928};\\\", \\\"{x:1398,y:649,t:1527267418945};\\\", \\\"{x:1422,y:686,t:1527267418961};\\\", \\\"{x:1442,y:724,t:1527267418978};\\\", \\\"{x:1464,y:759,t:1527267418995};\\\", \\\"{x:1479,y:789,t:1527267419011};\\\", \\\"{x:1486,y:811,t:1527267419028};\\\", \\\"{x:1494,y:839,t:1527267419044};\\\", \\\"{x:1501,y:857,t:1527267419061};\\\", \\\"{x:1506,y:871,t:1527267419079};\\\", \\\"{x:1509,y:881,t:1527267419095};\\\", \\\"{x:1512,y:896,t:1527267419111};\\\", \\\"{x:1517,y:909,t:1527267419129};\\\", \\\"{x:1521,y:921,t:1527267419145};\\\", \\\"{x:1522,y:927,t:1527267419161};\\\", \\\"{x:1520,y:932,t:1527267419178};\\\", \\\"{x:1514,y:939,t:1527267419195};\\\", \\\"{x:1499,y:946,t:1527267419211};\\\", \\\"{x:1482,y:952,t:1527267419228};\\\", \\\"{x:1449,y:958,t:1527267419245};\\\", \\\"{x:1426,y:963,t:1527267419262};\\\", \\\"{x:1403,y:966,t:1527267419279};\\\", \\\"{x:1383,y:970,t:1527267419295};\\\", \\\"{x:1362,y:974,t:1527267419312};\\\", \\\"{x:1346,y:976,t:1527267419328};\\\", \\\"{x:1336,y:976,t:1527267419345};\\\", \\\"{x:1326,y:979,t:1527267419363};\\\", \\\"{x:1317,y:979,t:1527267419378};\\\", \\\"{x:1311,y:979,t:1527267419396};\\\", \\\"{x:1308,y:979,t:1527267419413};\\\", \\\"{x:1306,y:979,t:1527267419428};\\\", \\\"{x:1304,y:979,t:1527267419445};\\\", \\\"{x:1303,y:979,t:1527267419462};\\\", \\\"{x:1302,y:979,t:1527267419478};\\\", \\\"{x:1301,y:979,t:1527267419495};\\\", \\\"{x:1300,y:979,t:1527267419512};\\\", \\\"{x:1301,y:979,t:1527267419580};\\\", \\\"{x:1306,y:979,t:1527267419596};\\\", \\\"{x:1314,y:979,t:1527267419612};\\\", \\\"{x:1321,y:978,t:1527267419628};\\\", \\\"{x:1327,y:975,t:1527267419645};\\\", \\\"{x:1329,y:975,t:1527267419662};\\\", \\\"{x:1330,y:975,t:1527267419684};\\\", \\\"{x:1332,y:974,t:1527267419708};\\\", \\\"{x:1334,y:974,t:1527267419741};\\\", \\\"{x:1336,y:974,t:1527267419750};\\\", \\\"{x:1337,y:974,t:1527267419762};\\\", \\\"{x:1340,y:974,t:1527267419779};\\\", \\\"{x:1342,y:974,t:1527267419821};\\\", \\\"{x:1342,y:973,t:1527267419829};\\\", \\\"{x:1343,y:973,t:1527267419845};\\\", \\\"{x:1345,y:972,t:1527267419863};\\\", \\\"{x:1347,y:972,t:1527267419879};\\\", \\\"{x:1348,y:971,t:1527267419895};\\\", \\\"{x:1349,y:969,t:1527267420030};\\\", \\\"{x:1349,y:965,t:1527267420046};\\\", \\\"{x:1350,y:961,t:1527267420062};\\\", \\\"{x:1350,y:957,t:1527267420079};\\\", \\\"{x:1351,y:954,t:1527267420095};\\\", \\\"{x:1351,y:949,t:1527267420113};\\\", \\\"{x:1351,y:937,t:1527267420129};\\\", \\\"{x:1351,y:921,t:1527267420146};\\\", \\\"{x:1351,y:902,t:1527267420163};\\\", \\\"{x:1351,y:889,t:1527267420179};\\\", \\\"{x:1353,y:881,t:1527267420196};\\\", \\\"{x:1353,y:877,t:1527267420212};\\\", \\\"{x:1354,y:872,t:1527267420229};\\\", \\\"{x:1353,y:868,t:1527267420246};\\\", \\\"{x:1350,y:861,t:1527267420262};\\\", \\\"{x:1349,y:856,t:1527267420279};\\\", \\\"{x:1349,y:852,t:1527267420297};\\\", \\\"{x:1349,y:848,t:1527267420312};\\\", \\\"{x:1349,y:845,t:1527267420330};\\\", \\\"{x:1349,y:842,t:1527267420347};\\\", \\\"{x:1349,y:840,t:1527267420362};\\\", \\\"{x:1349,y:837,t:1527267420379};\\\", \\\"{x:1349,y:834,t:1527267420397};\\\", \\\"{x:1349,y:831,t:1527267420413};\\\", \\\"{x:1350,y:825,t:1527267420430};\\\", \\\"{x:1350,y:821,t:1527267420447};\\\", \\\"{x:1350,y:818,t:1527267420463};\\\", \\\"{x:1351,y:816,t:1527267420480};\\\", \\\"{x:1351,y:814,t:1527267420496};\\\", \\\"{x:1351,y:813,t:1527267420513};\\\", \\\"{x:1351,y:810,t:1527267420530};\\\", \\\"{x:1352,y:808,t:1527267420546};\\\", \\\"{x:1352,y:807,t:1527267420562};\\\", \\\"{x:1352,y:806,t:1527267420579};\\\", \\\"{x:1352,y:805,t:1527267420597};\\\", \\\"{x:1352,y:804,t:1527267420621};\\\", \\\"{x:1352,y:803,t:1527267420629};\\\", \\\"{x:1352,y:802,t:1527267420646};\\\", \\\"{x:1353,y:800,t:1527267420664};\\\", \\\"{x:1353,y:799,t:1527267420680};\\\", \\\"{x:1353,y:795,t:1527267420696};\\\", \\\"{x:1353,y:791,t:1527267420714};\\\", \\\"{x:1353,y:787,t:1527267420730};\\\", \\\"{x:1353,y:784,t:1527267420747};\\\", \\\"{x:1353,y:782,t:1527267420764};\\\", \\\"{x:1353,y:781,t:1527267420779};\\\", \\\"{x:1353,y:779,t:1527267420796};\\\", \\\"{x:1353,y:777,t:1527267420814};\\\", \\\"{x:1353,y:775,t:1527267420830};\\\", \\\"{x:1353,y:772,t:1527267420847};\\\", \\\"{x:1353,y:770,t:1527267420864};\\\", \\\"{x:1353,y:769,t:1527267420879};\\\", \\\"{x:1353,y:766,t:1527267420897};\\\", \\\"{x:1353,y:765,t:1527267420917};\\\", \\\"{x:1353,y:763,t:1527267420928};\\\", \\\"{x:1353,y:761,t:1527267420946};\\\", \\\"{x:1353,y:759,t:1527267420964};\\\", \\\"{x:1353,y:758,t:1527267420979};\\\", \\\"{x:1353,y:756,t:1527267420996};\\\", \\\"{x:1352,y:755,t:1527267421012};\\\", \\\"{x:1352,y:754,t:1527267421029};\\\", \\\"{x:1352,y:753,t:1527267421046};\\\", \\\"{x:1352,y:752,t:1527267421063};\\\", \\\"{x:1352,y:750,t:1527267421080};\\\", \\\"{x:1352,y:748,t:1527267421096};\\\", \\\"{x:1352,y:746,t:1527267421113};\\\", \\\"{x:1352,y:743,t:1527267421129};\\\", \\\"{x:1352,y:741,t:1527267421146};\\\", \\\"{x:1352,y:738,t:1527267421164};\\\", \\\"{x:1353,y:734,t:1527267421181};\\\", \\\"{x:1353,y:731,t:1527267421196};\\\", \\\"{x:1355,y:727,t:1527267421213};\\\", \\\"{x:1355,y:726,t:1527267421231};\\\", \\\"{x:1355,y:723,t:1527267421246};\\\", \\\"{x:1355,y:722,t:1527267421263};\\\", \\\"{x:1356,y:721,t:1527267421281};\\\", \\\"{x:1356,y:719,t:1527267421296};\\\", \\\"{x:1357,y:717,t:1527267421314};\\\", \\\"{x:1357,y:714,t:1527267421331};\\\", \\\"{x:1357,y:713,t:1527267421347};\\\", \\\"{x:1357,y:711,t:1527267421364};\\\", \\\"{x:1357,y:710,t:1527267421380};\\\", \\\"{x:1357,y:709,t:1527267421397};\\\", \\\"{x:1356,y:706,t:1527267421413};\\\", \\\"{x:1356,y:704,t:1527267421430};\\\", \\\"{x:1355,y:702,t:1527267421446};\\\", \\\"{x:1355,y:700,t:1527267421463};\\\", \\\"{x:1353,y:698,t:1527267421480};\\\", \\\"{x:1352,y:696,t:1527267421497};\\\", \\\"{x:1351,y:695,t:1527267421513};\\\", \\\"{x:1350,y:693,t:1527267421530};\\\", \\\"{x:1349,y:692,t:1527267421547};\\\", \\\"{x:1349,y:691,t:1527267421565};\\\", \\\"{x:1352,y:692,t:1527267421662};\\\", \\\"{x:1353,y:692,t:1527267421685};\\\", \\\"{x:1353,y:693,t:1527267421765};\\\", \\\"{x:1349,y:697,t:1527267421781};\\\", \\\"{x:1315,y:708,t:1527267421798};\\\", \\\"{x:1283,y:716,t:1527267421813};\\\", \\\"{x:1245,y:725,t:1527267421831};\\\", \\\"{x:1196,y:738,t:1527267421847};\\\", \\\"{x:1127,y:745,t:1527267421863};\\\", \\\"{x:1049,y:745,t:1527267421881};\\\", \\\"{x:969,y:745,t:1527267421897};\\\", \\\"{x:874,y:745,t:1527267421913};\\\", \\\"{x:816,y:745,t:1527267421931};\\\", \\\"{x:790,y:743,t:1527267421948};\\\", \\\"{x:765,y:735,t:1527267421963};\\\", \\\"{x:733,y:723,t:1527267421980};\\\", \\\"{x:705,y:701,t:1527267421997};\\\", \\\"{x:693,y:683,t:1527267422015};\\\", \\\"{x:677,y:658,t:1527267422030};\\\", \\\"{x:655,y:624,t:1527267422048};\\\", \\\"{x:634,y:596,t:1527267422065};\\\", \\\"{x:618,y:582,t:1527267422081};\\\", \\\"{x:614,y:576,t:1527267422097};\\\", \\\"{x:613,y:574,t:1527267422113};\\\", \\\"{x:613,y:571,t:1527267422130};\\\", \\\"{x:612,y:567,t:1527267422147};\\\", \\\"{x:609,y:564,t:1527267422163};\\\", \\\"{x:609,y:563,t:1527267422180};\\\", \\\"{x:607,y:562,t:1527267422197};\\\", \\\"{x:607,y:561,t:1527267422214};\\\", \\\"{x:601,y:560,t:1527267422230};\\\", \\\"{x:589,y:559,t:1527267422247};\\\", \\\"{x:580,y:559,t:1527267422264};\\\", \\\"{x:574,y:557,t:1527267422280};\\\", \\\"{x:560,y:555,t:1527267422297};\\\", \\\"{x:537,y:552,t:1527267422314};\\\", \\\"{x:508,y:549,t:1527267422330};\\\", \\\"{x:461,y:545,t:1527267422347};\\\", \\\"{x:410,y:543,t:1527267422364};\\\", \\\"{x:370,y:541,t:1527267422380};\\\", \\\"{x:354,y:538,t:1527267422397};\\\", \\\"{x:342,y:536,t:1527267422414};\\\", \\\"{x:330,y:532,t:1527267422430};\\\", \\\"{x:321,y:529,t:1527267422447};\\\", \\\"{x:314,y:528,t:1527267422464};\\\", \\\"{x:310,y:527,t:1527267422480};\\\", \\\"{x:305,y:527,t:1527267422497};\\\", \\\"{x:299,y:527,t:1527267422515};\\\", \\\"{x:294,y:527,t:1527267422530};\\\", \\\"{x:291,y:527,t:1527267422547};\\\", \\\"{x:283,y:527,t:1527267422564};\\\", \\\"{x:258,y:531,t:1527267422581};\\\", \\\"{x:212,y:543,t:1527267422597};\\\", \\\"{x:202,y:544,t:1527267422614};\\\", \\\"{x:198,y:545,t:1527267422631};\\\", \\\"{x:194,y:544,t:1527267422648};\\\", \\\"{x:189,y:542,t:1527267422665};\\\", \\\"{x:186,y:541,t:1527267422681};\\\", \\\"{x:184,y:540,t:1527267422697};\\\", \\\"{x:183,y:539,t:1527267422715};\\\", \\\"{x:180,y:539,t:1527267422731};\\\", \\\"{x:179,y:539,t:1527267422747};\\\", \\\"{x:178,y:539,t:1527267422765};\\\", \\\"{x:177,y:538,t:1527267422782};\\\", \\\"{x:175,y:537,t:1527267422813};\\\", \\\"{x:173,y:536,t:1527267422830};\\\", \\\"{x:172,y:536,t:1527267422837};\\\", \\\"{x:172,y:535,t:1527267422848};\\\", \\\"{x:171,y:535,t:1527267422864};\\\", \\\"{x:169,y:535,t:1527267422886};\\\", \\\"{x:168,y:535,t:1527267422898};\\\", \\\"{x:165,y:535,t:1527267422914};\\\", \\\"{x:164,y:535,t:1527267422931};\\\", \\\"{x:163,y:534,t:1527267422949};\\\", \\\"{x:162,y:534,t:1527267422964};\\\", \\\"{x:161,y:534,t:1527267422981};\\\", \\\"{x:164,y:535,t:1527267423349};\\\", \\\"{x:176,y:538,t:1527267423365};\\\", \\\"{x:192,y:543,t:1527267423382};\\\", \\\"{x:209,y:548,t:1527267423398};\\\", \\\"{x:228,y:554,t:1527267423415};\\\", \\\"{x:244,y:556,t:1527267423431};\\\", \\\"{x:261,y:559,t:1527267423447};\\\", \\\"{x:277,y:560,t:1527267423465};\\\", \\\"{x:290,y:563,t:1527267423481};\\\", \\\"{x:299,y:564,t:1527267423498};\\\", \\\"{x:309,y:564,t:1527267423515};\\\", \\\"{x:317,y:567,t:1527267423531};\\\", \\\"{x:324,y:568,t:1527267423548};\\\", \\\"{x:335,y:568,t:1527267423564};\\\", \\\"{x:342,y:568,t:1527267423581};\\\", \\\"{x:348,y:568,t:1527267423598};\\\", \\\"{x:351,y:567,t:1527267423615};\\\", \\\"{x:358,y:567,t:1527267423631};\\\", \\\"{x:364,y:564,t:1527267423648};\\\", \\\"{x:373,y:562,t:1527267423666};\\\", \\\"{x:385,y:561,t:1527267423682};\\\", \\\"{x:399,y:557,t:1527267423698};\\\", \\\"{x:414,y:556,t:1527267423715};\\\", \\\"{x:430,y:553,t:1527267423733};\\\", \\\"{x:460,y:548,t:1527267423748};\\\", \\\"{x:518,y:539,t:1527267423765};\\\", \\\"{x:548,y:533,t:1527267423782};\\\", \\\"{x:571,y:527,t:1527267423798};\\\", \\\"{x:586,y:523,t:1527267423816};\\\", \\\"{x:593,y:522,t:1527267423832};\\\", \\\"{x:595,y:522,t:1527267423848};\\\", \\\"{x:597,y:520,t:1527267423865};\\\", \\\"{x:599,y:520,t:1527267423882};\\\", \\\"{x:603,y:519,t:1527267423898};\\\", \\\"{x:609,y:518,t:1527267423915};\\\", \\\"{x:611,y:517,t:1527267423932};\\\", \\\"{x:615,y:517,t:1527267423949};\\\", \\\"{x:623,y:517,t:1527267423965};\\\", \\\"{x:635,y:517,t:1527267423982};\\\", \\\"{x:649,y:517,t:1527267423998};\\\", \\\"{x:663,y:517,t:1527267424016};\\\", \\\"{x:679,y:516,t:1527267424033};\\\", \\\"{x:710,y:511,t:1527267424048};\\\", \\\"{x:742,y:507,t:1527267424066};\\\", \\\"{x:766,y:504,t:1527267424082};\\\", \\\"{x:781,y:502,t:1527267424098};\\\", \\\"{x:786,y:499,t:1527267424116};\\\", \\\"{x:788,y:499,t:1527267424132};\\\", \\\"{x:789,y:499,t:1527267424213};\\\", \\\"{x:792,y:499,t:1527267424221};\\\", \\\"{x:793,y:499,t:1527267424233};\\\", \\\"{x:797,y:499,t:1527267424250};\\\", \\\"{x:800,y:499,t:1527267424265};\\\", \\\"{x:802,y:499,t:1527267424333};\\\", \\\"{x:810,y:500,t:1527267424349};\\\", \\\"{x:814,y:501,t:1527267424366};\\\", \\\"{x:819,y:502,t:1527267424382};\\\", \\\"{x:821,y:502,t:1527267424400};\\\", \\\"{x:822,y:502,t:1527267424437};\\\", \\\"{x:824,y:502,t:1527267424509};\\\", \\\"{x:824,y:503,t:1527267424925};\\\", \\\"{x:824,y:505,t:1527267424942};\\\", \\\"{x:824,y:514,t:1527267424950};\\\", \\\"{x:824,y:529,t:1527267424969};\\\", \\\"{x:824,y:537,t:1527267424984};\\\", \\\"{x:824,y:545,t:1527267424999};\\\", \\\"{x:824,y:548,t:1527267425016};\\\", \\\"{x:822,y:552,t:1527267425033};\\\", \\\"{x:821,y:555,t:1527267425049};\\\", \\\"{x:821,y:556,t:1527267425068};\\\", \\\"{x:818,y:561,t:1527267425083};\\\", \\\"{x:811,y:573,t:1527267425099};\\\", \\\"{x:789,y:602,t:1527267425117};\\\", \\\"{x:774,y:615,t:1527267425132};\\\", \\\"{x:769,y:619,t:1527267425149};\\\", \\\"{x:768,y:620,t:1527267425166};\\\", \\\"{x:770,y:618,t:1527267425197};\\\", \\\"{x:774,y:608,t:1527267425205};\\\", \\\"{x:779,y:597,t:1527267425217};\\\", \\\"{x:787,y:577,t:1527267425234};\\\", \\\"{x:796,y:556,t:1527267425252};\\\", \\\"{x:801,y:543,t:1527267425267};\\\", \\\"{x:803,y:533,t:1527267425283};\\\", \\\"{x:805,y:526,t:1527267425299};\\\", \\\"{x:807,y:520,t:1527267425316};\\\", \\\"{x:808,y:516,t:1527267425333};\\\", \\\"{x:808,y:514,t:1527267425351};\\\", \\\"{x:808,y:513,t:1527267425372};\\\", \\\"{x:809,y:510,t:1527267425384};\\\", \\\"{x:810,y:508,t:1527267425401};\\\", \\\"{x:810,y:507,t:1527267425417};\\\", \\\"{x:811,y:505,t:1527267425433};\\\", \\\"{x:813,y:504,t:1527267425451};\\\", \\\"{x:815,y:504,t:1527267425467};\\\", \\\"{x:823,y:504,t:1527267425483};\\\", \\\"{x:831,y:504,t:1527267425502};\\\", \\\"{x:832,y:504,t:1527267425516};\\\", \\\"{x:833,y:503,t:1527267425565};\\\", \\\"{x:834,y:505,t:1527267425821};\\\", \\\"{x:832,y:511,t:1527267425833};\\\", \\\"{x:821,y:527,t:1527267425851};\\\", \\\"{x:807,y:547,t:1527267425867};\\\", \\\"{x:787,y:571,t:1527267425884};\\\", \\\"{x:766,y:593,t:1527267425900};\\\", \\\"{x:733,y:609,t:1527267425917};\\\", \\\"{x:715,y:615,t:1527267425933};\\\", \\\"{x:695,y:621,t:1527267425950};\\\", \\\"{x:671,y:632,t:1527267425967};\\\", \\\"{x:653,y:643,t:1527267425983};\\\", \\\"{x:631,y:654,t:1527267426000};\\\", \\\"{x:606,y:669,t:1527267426016};\\\", \\\"{x:576,y:681,t:1527267426033};\\\", \\\"{x:553,y:690,t:1527267426050};\\\", \\\"{x:537,y:698,t:1527267426066};\\\", \\\"{x:528,y:704,t:1527267426083};\\\", \\\"{x:521,y:708,t:1527267426102};\\\", \\\"{x:520,y:709,t:1527267426116};\\\", \\\"{x:518,y:710,t:1527267426133};\\\", \\\"{x:516,y:710,t:1527267426150};\\\", \\\"{x:514,y:711,t:1527267426167};\\\", \\\"{x:511,y:712,t:1527267426184};\\\", \\\"{x:509,y:714,t:1527267426200};\\\", \\\"{x:508,y:715,t:1527267426216};\\\", \\\"{x:506,y:718,t:1527267426233};\\\", \\\"{x:506,y:720,t:1527267426250};\\\", \\\"{x:506,y:721,t:1527267426266};\\\", \\\"{x:506,y:723,t:1527267426283};\\\", \\\"{x:506,y:724,t:1527267426300};\\\", \\\"{x:506,y:726,t:1527267426324};\\\", \\\"{x:507,y:726,t:1527267426813};\\\", \\\"{x:513,y:726,t:1527267426821};\\\", \\\"{x:520,y:726,t:1527267426835};\\\", \\\"{x:538,y:725,t:1527267426852};\\\", \\\"{x:565,y:724,t:1527267426868};\\\", \\\"{x:618,y:722,t:1527267426885};\\\", \\\"{x:760,y:720,t:1527267426901};\\\", \\\"{x:849,y:706,t:1527267426917};\\\", \\\"{x:904,y:696,t:1527267426934};\\\", \\\"{x:930,y:688,t:1527267426952};\\\", \\\"{x:940,y:684,t:1527267426967};\\\", \\\"{x:941,y:684,t:1527267426984};\\\", \\\"{x:941,y:683,t:1527267427566};\\\" ] }, { \\\"rt\\\": 8478, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 406117, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:905,y:676,t:1527267428420};\\\", \\\"{x:777,y:640,t:1527267428435};\\\", \\\"{x:625,y:596,t:1527267428452};\\\", \\\"{x:531,y:569,t:1527267428469};\\\", \\\"{x:480,y:553,t:1527267428486};\\\", \\\"{x:443,y:543,t:1527267428502};\\\", \\\"{x:424,y:534,t:1527267428519};\\\", \\\"{x:416,y:529,t:1527267428536};\\\", \\\"{x:414,y:527,t:1527267428553};\\\", \\\"{x:414,y:524,t:1527267428570};\\\", \\\"{x:410,y:518,t:1527267428585};\\\", \\\"{x:405,y:510,t:1527267428603};\\\", \\\"{x:397,y:502,t:1527267428619};\\\", \\\"{x:394,y:499,t:1527267428635};\\\", \\\"{x:392,y:497,t:1527267428652};\\\", \\\"{x:391,y:496,t:1527267428676};\\\", \\\"{x:390,y:496,t:1527267428685};\\\", \\\"{x:384,y:492,t:1527267428702};\\\", \\\"{x:380,y:489,t:1527267428720};\\\", \\\"{x:378,y:487,t:1527267428735};\\\", \\\"{x:376,y:486,t:1527267428753};\\\", \\\"{x:375,y:483,t:1527267428769};\\\", \\\"{x:375,y:480,t:1527267428785};\\\", \\\"{x:375,y:476,t:1527267428802};\\\", \\\"{x:379,y:471,t:1527267428820};\\\", \\\"{x:396,y:463,t:1527267428835};\\\", \\\"{x:426,y:461,t:1527267428853};\\\", \\\"{x:432,y:461,t:1527267428869};\\\", \\\"{x:441,y:463,t:1527267428886};\\\", \\\"{x:452,y:468,t:1527267428903};\\\", \\\"{x:465,y:471,t:1527267428920};\\\", \\\"{x:475,y:474,t:1527267428937};\\\", \\\"{x:483,y:477,t:1527267428952};\\\", \\\"{x:490,y:478,t:1527267428969};\\\", \\\"{x:495,y:478,t:1527267428986};\\\", \\\"{x:500,y:479,t:1527267429003};\\\", \\\"{x:503,y:479,t:1527267429019};\\\", \\\"{x:504,y:479,t:1527267429037};\\\", \\\"{x:505,y:479,t:1527267429060};\\\", \\\"{x:508,y:479,t:1527267429069};\\\", \\\"{x:520,y:477,t:1527267429086};\\\", \\\"{x:534,y:475,t:1527267429103};\\\", \\\"{x:547,y:471,t:1527267429119};\\\", \\\"{x:562,y:466,t:1527267429137};\\\", \\\"{x:577,y:464,t:1527267429153};\\\", \\\"{x:590,y:462,t:1527267429170};\\\", \\\"{x:596,y:461,t:1527267429187};\\\", \\\"{x:600,y:460,t:1527267429202};\\\", \\\"{x:603,y:460,t:1527267429219};\\\", \\\"{x:615,y:461,t:1527267429237};\\\", \\\"{x:624,y:461,t:1527267429253};\\\", \\\"{x:634,y:461,t:1527267429269};\\\", \\\"{x:641,y:461,t:1527267429286};\\\", \\\"{x:642,y:461,t:1527267429302};\\\", \\\"{x:645,y:462,t:1527267429320};\\\", \\\"{x:650,y:463,t:1527267429337};\\\", \\\"{x:659,y:470,t:1527267429354};\\\", \\\"{x:673,y:476,t:1527267429369};\\\", \\\"{x:686,y:481,t:1527267429386};\\\", \\\"{x:700,y:482,t:1527267429404};\\\", \\\"{x:714,y:482,t:1527267429420};\\\", \\\"{x:748,y:482,t:1527267429437};\\\", \\\"{x:787,y:482,t:1527267429453};\\\", \\\"{x:853,y:482,t:1527267429469};\\\", \\\"{x:945,y:482,t:1527267429487};\\\", \\\"{x:1039,y:482,t:1527267429504};\\\", \\\"{x:1136,y:482,t:1527267429520};\\\", \\\"{x:1231,y:482,t:1527267429537};\\\", \\\"{x:1325,y:484,t:1527267429554};\\\", \\\"{x:1405,y:493,t:1527267429570};\\\", \\\"{x:1461,y:501,t:1527267429587};\\\", \\\"{x:1511,y:507,t:1527267429604};\\\", \\\"{x:1544,y:517,t:1527267429620};\\\", \\\"{x:1596,y:540,t:1527267429637};\\\", \\\"{x:1624,y:559,t:1527267429653};\\\", \\\"{x:1642,y:589,t:1527267429670};\\\", \\\"{x:1659,y:617,t:1527267429687};\\\", \\\"{x:1669,y:638,t:1527267429704};\\\", \\\"{x:1676,y:655,t:1527267429720};\\\", \\\"{x:1679,y:665,t:1527267429737};\\\", \\\"{x:1681,y:678,t:1527267429754};\\\", \\\"{x:1686,y:692,t:1527267429771};\\\", \\\"{x:1687,y:703,t:1527267429787};\\\", \\\"{x:1688,y:704,t:1527267429804};\\\", \\\"{x:1686,y:703,t:1527267429884};\\\", \\\"{x:1679,y:700,t:1527267429893};\\\", \\\"{x:1661,y:694,t:1527267429903};\\\", \\\"{x:1598,y:670,t:1527267429920};\\\", \\\"{x:1544,y:652,t:1527267429936};\\\", \\\"{x:1489,y:638,t:1527267429954};\\\", \\\"{x:1429,y:628,t:1527267429970};\\\", \\\"{x:1372,y:616,t:1527267429986};\\\", \\\"{x:1328,y:616,t:1527267430003};\\\", \\\"{x:1298,y:616,t:1527267430020};\\\", \\\"{x:1296,y:616,t:1527267430036};\\\", \\\"{x:1296,y:615,t:1527267430053};\\\", \\\"{x:1296,y:612,t:1527267430070};\\\", \\\"{x:1296,y:608,t:1527267430086};\\\", \\\"{x:1297,y:603,t:1527267430104};\\\", \\\"{x:1298,y:601,t:1527267430121};\\\", \\\"{x:1297,y:595,t:1527267430136};\\\", \\\"{x:1294,y:589,t:1527267430154};\\\", \\\"{x:1294,y:588,t:1527267430170};\\\", \\\"{x:1294,y:587,t:1527267430187};\\\", \\\"{x:1295,y:582,t:1527267430204};\\\", \\\"{x:1308,y:567,t:1527267430220};\\\", \\\"{x:1318,y:561,t:1527267430238};\\\", \\\"{x:1332,y:557,t:1527267430253};\\\", \\\"{x:1354,y:554,t:1527267430270};\\\", \\\"{x:1377,y:551,t:1527267430288};\\\", \\\"{x:1401,y:544,t:1527267430304};\\\", \\\"{x:1420,y:537,t:1527267430321};\\\", \\\"{x:1437,y:530,t:1527267430338};\\\", \\\"{x:1446,y:525,t:1527267430353};\\\", \\\"{x:1453,y:521,t:1527267430370};\\\", \\\"{x:1455,y:519,t:1527267430388};\\\", \\\"{x:1456,y:517,t:1527267430403};\\\", \\\"{x:1457,y:515,t:1527267430421};\\\", \\\"{x:1464,y:503,t:1527267430438};\\\", \\\"{x:1475,y:483,t:1527267430454};\\\", \\\"{x:1485,y:466,t:1527267430470};\\\", \\\"{x:1488,y:457,t:1527267430487};\\\", \\\"{x:1491,y:454,t:1527267430503};\\\", \\\"{x:1491,y:453,t:1527267430533};\\\", \\\"{x:1491,y:452,t:1527267430670};\\\", \\\"{x:1490,y:452,t:1527267430687};\\\", \\\"{x:1488,y:452,t:1527267430705};\\\", \\\"{x:1486,y:463,t:1527267431550};\\\", \\\"{x:1482,y:477,t:1527267431557};\\\", \\\"{x:1482,y:495,t:1527267431572};\\\", \\\"{x:1465,y:549,t:1527267431589};\\\", \\\"{x:1445,y:594,t:1527267431606};\\\", \\\"{x:1428,y:630,t:1527267431622};\\\", \\\"{x:1419,y:650,t:1527267431638};\\\", \\\"{x:1416,y:658,t:1527267431654};\\\", \\\"{x:1415,y:664,t:1527267431671};\\\", \\\"{x:1414,y:672,t:1527267431689};\\\", \\\"{x:1410,y:680,t:1527267431705};\\\", \\\"{x:1407,y:686,t:1527267431721};\\\", \\\"{x:1403,y:690,t:1527267431738};\\\", \\\"{x:1398,y:695,t:1527267431755};\\\", \\\"{x:1393,y:699,t:1527267431772};\\\", \\\"{x:1386,y:702,t:1527267431789};\\\", \\\"{x:1381,y:702,t:1527267431804};\\\", \\\"{x:1372,y:703,t:1527267431822};\\\", \\\"{x:1363,y:703,t:1527267431838};\\\", \\\"{x:1360,y:703,t:1527267431854};\\\", \\\"{x:1358,y:703,t:1527267431871};\\\", \\\"{x:1357,y:703,t:1527267431889};\\\", \\\"{x:1355,y:703,t:1527267431905};\\\", \\\"{x:1354,y:703,t:1527267432108};\\\", \\\"{x:1353,y:703,t:1527267432121};\\\", \\\"{x:1352,y:705,t:1527267432139};\\\", \\\"{x:1350,y:705,t:1527267432157};\\\", \\\"{x:1349,y:705,t:1527267432189};\\\", \\\"{x:1347,y:705,t:1527267432205};\\\", \\\"{x:1346,y:705,t:1527267432221};\\\", \\\"{x:1344,y:705,t:1527267432239};\\\", \\\"{x:1343,y:705,t:1527267432258};\\\", \\\"{x:1343,y:704,t:1527267432486};\\\", \\\"{x:1343,y:703,t:1527267432493};\\\", \\\"{x:1343,y:702,t:1527267432506};\\\", \\\"{x:1344,y:701,t:1527267432525};\\\", \\\"{x:1344,y:699,t:1527267432538};\\\", \\\"{x:1345,y:698,t:1527267432572};\\\", \\\"{x:1346,y:697,t:1527267433838};\\\", \\\"{x:1349,y:697,t:1527267433845};\\\", \\\"{x:1352,y:697,t:1527267433857};\\\", \\\"{x:1357,y:698,t:1527267433875};\\\", \\\"{x:1361,y:698,t:1527267433889};\\\", \\\"{x:1366,y:699,t:1527267433906};\\\", \\\"{x:1369,y:700,t:1527267433924};\\\", \\\"{x:1372,y:700,t:1527267433940};\\\", \\\"{x:1373,y:700,t:1527267433957};\\\", \\\"{x:1373,y:699,t:1527267434037};\\\", \\\"{x:1372,y:698,t:1527267434053};\\\", \\\"{x:1371,y:698,t:1527267434133};\\\", \\\"{x:1371,y:700,t:1527267434141};\\\", \\\"{x:1371,y:711,t:1527267434157};\\\", \\\"{x:1371,y:722,t:1527267434174};\\\", \\\"{x:1371,y:731,t:1527267434191};\\\", \\\"{x:1371,y:745,t:1527267434207};\\\", \\\"{x:1371,y:755,t:1527267434224};\\\", \\\"{x:1371,y:759,t:1527267434240};\\\", \\\"{x:1371,y:760,t:1527267434257};\\\", \\\"{x:1369,y:760,t:1527267434373};\\\", \\\"{x:1368,y:760,t:1527267434388};\\\", \\\"{x:1365,y:760,t:1527267434397};\\\", \\\"{x:1362,y:760,t:1527267434407};\\\", \\\"{x:1347,y:760,t:1527267434424};\\\", \\\"{x:1327,y:760,t:1527267434441};\\\", \\\"{x:1285,y:760,t:1527267434457};\\\", \\\"{x:1188,y:760,t:1527267434474};\\\", \\\"{x:1033,y:760,t:1527267434491};\\\", \\\"{x:861,y:758,t:1527267434507};\\\", \\\"{x:712,y:736,t:1527267434523};\\\", \\\"{x:575,y:710,t:1527267434541};\\\", \\\"{x:542,y:697,t:1527267434557};\\\", \\\"{x:532,y:688,t:1527267434574};\\\", \\\"{x:529,y:685,t:1527267434591};\\\", \\\"{x:528,y:681,t:1527267434607};\\\", \\\"{x:526,y:671,t:1527267434623};\\\", \\\"{x:524,y:659,t:1527267434640};\\\", \\\"{x:519,y:645,t:1527267434658};\\\", \\\"{x:510,y:632,t:1527267434674};\\\", \\\"{x:497,y:619,t:1527267434691};\\\", \\\"{x:488,y:610,t:1527267434708};\\\", \\\"{x:488,y:607,t:1527267434724};\\\", \\\"{x:488,y:605,t:1527267434740};\\\", \\\"{x:488,y:604,t:1527267434758};\\\", \\\"{x:487,y:601,t:1527267434773};\\\", \\\"{x:486,y:600,t:1527267434791};\\\", \\\"{x:485,y:599,t:1527267434808};\\\", \\\"{x:483,y:597,t:1527267434823};\\\", \\\"{x:479,y:592,t:1527267434841};\\\", \\\"{x:466,y:585,t:1527267434857};\\\", \\\"{x:454,y:580,t:1527267434873};\\\", \\\"{x:443,y:578,t:1527267434891};\\\", \\\"{x:422,y:577,t:1527267434907};\\\", \\\"{x:402,y:575,t:1527267434924};\\\", \\\"{x:370,y:575,t:1527267434941};\\\", \\\"{x:347,y:575,t:1527267434958};\\\", \\\"{x:328,y:575,t:1527267434975};\\\", \\\"{x:304,y:575,t:1527267434991};\\\", \\\"{x:281,y:575,t:1527267435008};\\\", \\\"{x:258,y:575,t:1527267435026};\\\", \\\"{x:237,y:575,t:1527267435040};\\\", \\\"{x:234,y:574,t:1527267435058};\\\", \\\"{x:230,y:573,t:1527267435074};\\\", \\\"{x:226,y:571,t:1527267435090};\\\", \\\"{x:224,y:570,t:1527267435108};\\\", \\\"{x:223,y:570,t:1527267435157};\\\", \\\"{x:220,y:568,t:1527267435175};\\\", \\\"{x:216,y:566,t:1527267435190};\\\", \\\"{x:212,y:564,t:1527267435208};\\\", \\\"{x:210,y:563,t:1527267435225};\\\", \\\"{x:206,y:561,t:1527267435243};\\\", \\\"{x:202,y:558,t:1527267435258};\\\", \\\"{x:197,y:555,t:1527267435275};\\\", \\\"{x:194,y:554,t:1527267435290};\\\", \\\"{x:190,y:552,t:1527267435308};\\\", \\\"{x:187,y:552,t:1527267435325};\\\", \\\"{x:183,y:549,t:1527267435341};\\\", \\\"{x:179,y:549,t:1527267435358};\\\", \\\"{x:175,y:547,t:1527267435375};\\\", \\\"{x:170,y:546,t:1527267435392};\\\", \\\"{x:165,y:544,t:1527267435408};\\\", \\\"{x:161,y:542,t:1527267435425};\\\", \\\"{x:158,y:541,t:1527267435442};\\\", \\\"{x:155,y:540,t:1527267435458};\\\", \\\"{x:154,y:540,t:1527267435475};\\\", \\\"{x:152,y:538,t:1527267435492};\\\", \\\"{x:150,y:538,t:1527267435508};\\\", \\\"{x:149,y:538,t:1527267435613};\\\", \\\"{x:149,y:538,t:1527267435673};\\\", \\\"{x:150,y:538,t:1527267435764};\\\", \\\"{x:163,y:545,t:1527267435775};\\\", \\\"{x:209,y:577,t:1527267435792};\\\", \\\"{x:256,y:610,t:1527267435808};\\\", \\\"{x:290,y:633,t:1527267435825};\\\", \\\"{x:305,y:641,t:1527267435843};\\\", \\\"{x:319,y:646,t:1527267435859};\\\", \\\"{x:336,y:654,t:1527267435875};\\\", \\\"{x:358,y:664,t:1527267435891};\\\", \\\"{x:393,y:686,t:1527267435910};\\\", \\\"{x:414,y:702,t:1527267435925};\\\", \\\"{x:432,y:716,t:1527267435941};\\\", \\\"{x:442,y:721,t:1527267435958};\\\", \\\"{x:445,y:724,t:1527267435975};\\\", \\\"{x:447,y:725,t:1527267435993};\\\", \\\"{x:450,y:726,t:1527267436009};\\\", \\\"{x:451,y:727,t:1527267436062};\\\", \\\"{x:452,y:727,t:1527267436075};\\\", \\\"{x:453,y:728,t:1527267436092};\\\", \\\"{x:456,y:729,t:1527267436109};\\\", \\\"{x:457,y:730,t:1527267436124};\\\", \\\"{x:458,y:730,t:1527267436142};\\\", \\\"{x:459,y:731,t:1527267436159};\\\", \\\"{x:462,y:731,t:1527267436468};\\\", \\\"{x:465,y:733,t:1527267436476};\\\", \\\"{x:474,y:735,t:1527267436491};\\\", \\\"{x:515,y:741,t:1527267436509};\\\", \\\"{x:546,y:745,t:1527267436526};\\\", \\\"{x:576,y:748,t:1527267436542};\\\", \\\"{x:615,y:748,t:1527267436559};\\\", \\\"{x:644,y:748,t:1527267436576};\\\", \\\"{x:664,y:748,t:1527267436592};\\\", \\\"{x:678,y:745,t:1527267436609};\\\", \\\"{x:683,y:744,t:1527267436626};\\\", \\\"{x:684,y:743,t:1527267436642};\\\" ] }, { \\\"rt\\\": 32763, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 440114, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -Z -04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:676,y:734,t:1527267438068};\\\", \\\"{x:659,y:704,t:1527267438076};\\\", \\\"{x:613,y:617,t:1527267438094};\\\", \\\"{x:573,y:551,t:1527267438111};\\\", \\\"{x:562,y:535,t:1527267438127};\\\", \\\"{x:559,y:530,t:1527267438144};\\\", \\\"{x:553,y:522,t:1527267438160};\\\", \\\"{x:552,y:520,t:1527267438204};\\\", \\\"{x:551,y:519,t:1527267438212};\\\", \\\"{x:550,y:517,t:1527267438227};\\\", \\\"{x:548,y:514,t:1527267438244};\\\", \\\"{x:548,y:513,t:1527267438259};\\\", \\\"{x:547,y:512,t:1527267438277};\\\", \\\"{x:546,y:512,t:1527267438293};\\\", \\\"{x:537,y:511,t:1527267438310};\\\", \\\"{x:521,y:511,t:1527267438327};\\\", \\\"{x:498,y:509,t:1527267438345};\\\", \\\"{x:470,y:505,t:1527267438360};\\\", \\\"{x:431,y:501,t:1527267438377};\\\", \\\"{x:399,y:499,t:1527267438395};\\\", \\\"{x:376,y:493,t:1527267438411};\\\", \\\"{x:362,y:491,t:1527267438427};\\\", \\\"{x:351,y:491,t:1527267438444};\\\", \\\"{x:348,y:491,t:1527267438460};\\\", \\\"{x:349,y:490,t:1527267438621};\\\", \\\"{x:357,y:489,t:1527267438629};\\\", \\\"{x:362,y:489,t:1527267438644};\\\", \\\"{x:380,y:486,t:1527267438662};\\\", \\\"{x:395,y:484,t:1527267438677};\\\", \\\"{x:412,y:484,t:1527267438694};\\\", \\\"{x:432,y:484,t:1527267438711};\\\", \\\"{x:447,y:484,t:1527267438727};\\\", \\\"{x:456,y:484,t:1527267438743};\\\", \\\"{x:463,y:482,t:1527267438761};\\\", \\\"{x:466,y:482,t:1527267438776};\\\", \\\"{x:469,y:482,t:1527267438794};\\\", \\\"{x:472,y:482,t:1527267438811};\\\", \\\"{x:475,y:482,t:1527267438827};\\\", \\\"{x:482,y:482,t:1527267438844};\\\", \\\"{x:498,y:482,t:1527267438861};\\\", \\\"{x:513,y:480,t:1527267438877};\\\", \\\"{x:529,y:477,t:1527267438894};\\\", \\\"{x:540,y:476,t:1527267438911};\\\", \\\"{x:544,y:475,t:1527267438927};\\\", \\\"{x:548,y:474,t:1527267438944};\\\", \\\"{x:549,y:474,t:1527267438965};\\\", \\\"{x:551,y:474,t:1527267438997};\\\", \\\"{x:552,y:474,t:1527267439011};\\\", \\\"{x:556,y:473,t:1527267439028};\\\", \\\"{x:560,y:473,t:1527267439044};\\\", \\\"{x:566,y:472,t:1527267439061};\\\", \\\"{x:568,y:472,t:1527267439078};\\\", \\\"{x:569,y:472,t:1527267439094};\\\", \\\"{x:570,y:472,t:1527267439117};\\\", \\\"{x:571,y:472,t:1527267439133};\\\", \\\"{x:572,y:472,t:1527267439144};\\\", \\\"{x:573,y:472,t:1527267439165};\\\", \\\"{x:575,y:472,t:1527267439788};\\\", \\\"{x:583,y:472,t:1527267439796};\\\", \\\"{x:596,y:472,t:1527267439811};\\\", \\\"{x:619,y:474,t:1527267439828};\\\", \\\"{x:632,y:478,t:1527267439844};\\\", \\\"{x:637,y:481,t:1527267439861};\\\", \\\"{x:641,y:483,t:1527267439878};\\\", \\\"{x:643,y:483,t:1527267439895};\\\", \\\"{x:644,y:485,t:1527267439912};\\\", \\\"{x:645,y:486,t:1527267439928};\\\", \\\"{x:646,y:486,t:1527267439945};\\\", \\\"{x:647,y:487,t:1527267439966};\\\", \\\"{x:649,y:487,t:1527267440116};\\\", \\\"{x:650,y:487,t:1527267440140};\\\", \\\"{x:651,y:488,t:1527267440149};\\\", \\\"{x:653,y:488,t:1527267440162};\\\", \\\"{x:660,y:488,t:1527267440179};\\\", \\\"{x:678,y:488,t:1527267440195};\\\", \\\"{x:705,y:486,t:1527267440213};\\\", \\\"{x:760,y:481,t:1527267440229};\\\", \\\"{x:820,y:479,t:1527267440244};\\\", \\\"{x:895,y:479,t:1527267440262};\\\", \\\"{x:973,y:476,t:1527267440279};\\\", \\\"{x:1048,y:476,t:1527267440296};\\\", \\\"{x:1091,y:474,t:1527267440312};\\\", \\\"{x:1120,y:474,t:1527267440329};\\\", \\\"{x:1142,y:474,t:1527267440345};\\\", \\\"{x:1156,y:474,t:1527267440362};\\\", \\\"{x:1163,y:477,t:1527267440380};\\\", \\\"{x:1168,y:480,t:1527267440395};\\\", \\\"{x:1176,y:485,t:1527267440412};\\\", \\\"{x:1203,y:502,t:1527267440429};\\\", \\\"{x:1226,y:512,t:1527267440445};\\\", \\\"{x:1276,y:525,t:1527267440462};\\\", \\\"{x:1317,y:531,t:1527267440480};\\\", \\\"{x:1348,y:534,t:1527267440495};\\\", \\\"{x:1373,y:535,t:1527267440513};\\\", \\\"{x:1399,y:538,t:1527267440529};\\\", \\\"{x:1419,y:540,t:1527267440545};\\\", \\\"{x:1436,y:540,t:1527267440562};\\\", \\\"{x:1446,y:540,t:1527267440579};\\\", \\\"{x:1451,y:536,t:1527267440595};\\\", \\\"{x:1451,y:533,t:1527267440612};\\\", \\\"{x:1451,y:534,t:1527267441374};\\\", \\\"{x:1448,y:536,t:1527267441381};\\\", \\\"{x:1445,y:541,t:1527267441397};\\\", \\\"{x:1439,y:556,t:1527267441413};\\\", \\\"{x:1433,y:575,t:1527267441430};\\\", \\\"{x:1428,y:598,t:1527267441447};\\\", \\\"{x:1418,y:625,t:1527267441464};\\\", \\\"{x:1408,y:651,t:1527267441479};\\\", \\\"{x:1396,y:680,t:1527267441496};\\\", \\\"{x:1388,y:708,t:1527267441513};\\\", \\\"{x:1385,y:733,t:1527267441529};\\\", \\\"{x:1380,y:753,t:1527267441546};\\\", \\\"{x:1378,y:763,t:1527267441563};\\\", \\\"{x:1377,y:767,t:1527267441580};\\\", \\\"{x:1376,y:771,t:1527267441596};\\\", \\\"{x:1376,y:778,t:1527267441613};\\\", \\\"{x:1376,y:780,t:1527267441630};\\\", \\\"{x:1376,y:782,t:1527267441646};\\\", \\\"{x:1376,y:787,t:1527267441664};\\\", \\\"{x:1376,y:792,t:1527267441680};\\\", \\\"{x:1376,y:795,t:1527267441697};\\\", \\\"{x:1375,y:799,t:1527267441714};\\\", \\\"{x:1374,y:804,t:1527267441731};\\\", \\\"{x:1373,y:810,t:1527267441747};\\\", \\\"{x:1371,y:817,t:1527267441764};\\\", \\\"{x:1369,y:823,t:1527267441781};\\\", \\\"{x:1368,y:830,t:1527267441797};\\\", \\\"{x:1368,y:833,t:1527267441814};\\\", \\\"{x:1368,y:834,t:1527267441830};\\\", \\\"{x:1370,y:838,t:1527267441846};\\\", \\\"{x:1378,y:841,t:1527267441863};\\\", \\\"{x:1384,y:844,t:1527267441881};\\\", \\\"{x:1390,y:846,t:1527267441897};\\\", \\\"{x:1397,y:848,t:1527267441913};\\\", \\\"{x:1403,y:850,t:1527267441930};\\\", \\\"{x:1407,y:852,t:1527267441946};\\\", \\\"{x:1411,y:855,t:1527267441963};\\\", \\\"{x:1413,y:856,t:1527267441979};\\\", \\\"{x:1416,y:858,t:1527267441995};\\\", \\\"{x:1416,y:859,t:1527267442012};\\\", \\\"{x:1416,y:861,t:1527267442030};\\\", \\\"{x:1416,y:864,t:1527267442046};\\\", \\\"{x:1417,y:868,t:1527267442062};\\\", \\\"{x:1417,y:872,t:1527267442080};\\\", \\\"{x:1417,y:874,t:1527267442096};\\\", \\\"{x:1417,y:877,t:1527267442113};\\\", \\\"{x:1416,y:879,t:1527267442130};\\\", \\\"{x:1416,y:881,t:1527267442147};\\\", \\\"{x:1415,y:882,t:1527267442163};\\\", \\\"{x:1412,y:885,t:1527267442180};\\\", \\\"{x:1410,y:887,t:1527267442196};\\\", \\\"{x:1409,y:887,t:1527267442213};\\\", \\\"{x:1408,y:888,t:1527267442236};\\\", \\\"{x:1406,y:889,t:1527267442248};\\\", \\\"{x:1405,y:889,t:1527267442269};\\\", \\\"{x:1403,y:889,t:1527267442280};\\\", \\\"{x:1402,y:889,t:1527267442317};\\\", \\\"{x:1401,y:889,t:1527267442933};\\\", \\\"{x:1401,y:888,t:1527267442948};\\\", \\\"{x:1401,y:887,t:1527267442997};\\\", \\\"{x:1401,y:885,t:1527267443015};\\\", \\\"{x:1401,y:879,t:1527267443031};\\\", \\\"{x:1401,y:872,t:1527267443047};\\\", \\\"{x:1401,y:862,t:1527267443064};\\\", \\\"{x:1401,y:858,t:1527267443080};\\\", \\\"{x:1401,y:850,t:1527267443097};\\\", \\\"{x:1401,y:840,t:1527267443114};\\\", \\\"{x:1405,y:834,t:1527267443131};\\\", \\\"{x:1406,y:832,t:1527267443147};\\\", \\\"{x:1407,y:831,t:1527267443165};\\\", \\\"{x:1408,y:830,t:1527267443229};\\\", \\\"{x:1411,y:830,t:1527267443261};\\\", \\\"{x:1414,y:830,t:1527267443269};\\\", \\\"{x:1416,y:830,t:1527267443282};\\\", \\\"{x:1423,y:830,t:1527267443297};\\\", \\\"{x:1433,y:830,t:1527267443314};\\\", \\\"{x:1446,y:833,t:1527267443332};\\\", \\\"{x:1453,y:833,t:1527267443348};\\\", \\\"{x:1459,y:833,t:1527267443365};\\\", \\\"{x:1466,y:833,t:1527267443381};\\\", \\\"{x:1467,y:832,t:1527267443405};\\\", \\\"{x:1467,y:830,t:1527267443421};\\\", \\\"{x:1467,y:827,t:1527267443432};\\\", \\\"{x:1464,y:822,t:1527267443447};\\\", \\\"{x:1456,y:817,t:1527267443465};\\\", \\\"{x:1452,y:815,t:1527267443481};\\\", \\\"{x:1449,y:814,t:1527267443497};\\\", \\\"{x:1447,y:814,t:1527267443514};\\\", \\\"{x:1445,y:814,t:1527267443532};\\\", \\\"{x:1442,y:814,t:1527267443547};\\\", \\\"{x:1440,y:814,t:1527267443565};\\\", \\\"{x:1437,y:815,t:1527267443581};\\\", \\\"{x:1436,y:821,t:1527267443599};\\\", \\\"{x:1436,y:831,t:1527267443614};\\\", \\\"{x:1442,y:838,t:1527267443632};\\\", \\\"{x:1446,y:842,t:1527267443649};\\\", \\\"{x:1450,y:846,t:1527267443665};\\\", \\\"{x:1454,y:847,t:1527267443681};\\\", \\\"{x:1460,y:848,t:1527267443699};\\\", \\\"{x:1463,y:849,t:1527267443715};\\\", \\\"{x:1464,y:849,t:1527267443732};\\\", \\\"{x:1467,y:846,t:1527267443750};\\\", \\\"{x:1468,y:843,t:1527267443765};\\\", \\\"{x:1470,y:838,t:1527267443782};\\\", \\\"{x:1470,y:837,t:1527267443799};\\\", \\\"{x:1471,y:836,t:1527267443815};\\\", \\\"{x:1486,y:838,t:1527267443832};\\\", \\\"{x:1500,y:849,t:1527267443849};\\\", \\\"{x:1510,y:860,t:1527267443865};\\\", \\\"{x:1517,y:872,t:1527267443881};\\\", \\\"{x:1521,y:881,t:1527267443898};\\\", \\\"{x:1524,y:885,t:1527267443914};\\\", \\\"{x:1524,y:887,t:1527267443931};\\\", \\\"{x:1524,y:888,t:1527267443948};\\\", \\\"{x:1524,y:889,t:1527267443964};\\\", \\\"{x:1522,y:889,t:1527267444013};\\\", \\\"{x:1521,y:889,t:1527267444037};\\\", \\\"{x:1519,y:889,t:1527267444048};\\\", \\\"{x:1518,y:889,t:1527267444066};\\\", \\\"{x:1516,y:889,t:1527267444310};\\\", \\\"{x:1515,y:889,t:1527267444351};\\\", \\\"{x:1515,y:888,t:1527267444381};\\\", \\\"{x:1514,y:886,t:1527267444405};\\\", \\\"{x:1514,y:885,t:1527267444429};\\\", \\\"{x:1514,y:883,t:1527267444445};\\\", \\\"{x:1514,y:882,t:1527267444453};\\\", \\\"{x:1514,y:881,t:1527267444465};\\\", \\\"{x:1514,y:878,t:1527267444481};\\\", \\\"{x:1512,y:876,t:1527267444498};\\\", \\\"{x:1512,y:875,t:1527267444515};\\\", \\\"{x:1512,y:874,t:1527267444597};\\\", \\\"{x:1513,y:874,t:1527267444604};\\\", \\\"{x:1515,y:874,t:1527267444615};\\\", \\\"{x:1522,y:874,t:1527267444632};\\\", \\\"{x:1528,y:874,t:1527267444648};\\\", \\\"{x:1535,y:882,t:1527267444666};\\\", \\\"{x:1536,y:887,t:1527267444682};\\\", \\\"{x:1537,y:892,t:1527267444698};\\\", \\\"{x:1537,y:893,t:1527267444715};\\\", \\\"{x:1537,y:894,t:1527267444732};\\\", \\\"{x:1535,y:893,t:1527267444773};\\\", \\\"{x:1531,y:887,t:1527267444783};\\\", \\\"{x:1531,y:873,t:1527267444798};\\\", \\\"{x:1531,y:847,t:1527267444815};\\\", \\\"{x:1542,y:823,t:1527267444833};\\\", \\\"{x:1553,y:809,t:1527267444849};\\\", \\\"{x:1559,y:803,t:1527267444865};\\\", \\\"{x:1562,y:798,t:1527267444883};\\\", \\\"{x:1563,y:794,t:1527267444899};\\\", \\\"{x:1565,y:791,t:1527267444916};\\\", \\\"{x:1565,y:789,t:1527267444933};\\\", \\\"{x:1565,y:786,t:1527267444949};\\\", \\\"{x:1563,y:781,t:1527267444966};\\\", \\\"{x:1563,y:777,t:1527267444983};\\\", \\\"{x:1563,y:774,t:1527267444998};\\\", \\\"{x:1563,y:770,t:1527267445015};\\\", \\\"{x:1563,y:766,t:1527267445033};\\\", \\\"{x:1563,y:760,t:1527267445050};\\\", \\\"{x:1563,y:754,t:1527267445066};\\\", \\\"{x:1566,y:745,t:1527267445083};\\\", \\\"{x:1576,y:729,t:1527267445099};\\\", \\\"{x:1585,y:715,t:1527267445116};\\\", \\\"{x:1593,y:708,t:1527267445133};\\\", \\\"{x:1596,y:703,t:1527267445150};\\\", \\\"{x:1597,y:702,t:1527267445166};\\\", \\\"{x:1597,y:701,t:1527267445197};\\\", \\\"{x:1598,y:700,t:1527267445254};\\\", \\\"{x:1599,y:699,t:1527267445266};\\\", \\\"{x:1600,y:699,t:1527267445283};\\\", \\\"{x:1600,y:698,t:1527267445299};\\\", \\\"{x:1602,y:697,t:1527267445316};\\\", \\\"{x:1605,y:697,t:1527267445333};\\\", \\\"{x:1608,y:697,t:1527267445349};\\\", \\\"{x:1610,y:697,t:1527267445367};\\\", \\\"{x:1611,y:697,t:1527267445382};\\\", \\\"{x:1612,y:697,t:1527267445399};\\\", \\\"{x:1613,y:697,t:1527267445420};\\\", \\\"{x:1614,y:698,t:1527267445517};\\\", \\\"{x:1615,y:698,t:1527267445532};\\\", \\\"{x:1614,y:699,t:1527267449342};\\\", \\\"{x:1594,y:710,t:1527267449353};\\\", \\\"{x:1509,y:729,t:1527267449368};\\\", \\\"{x:1384,y:744,t:1527267449385};\\\", \\\"{x:1231,y:750,t:1527267449402};\\\", \\\"{x:1055,y:750,t:1527267449418};\\\", \\\"{x:852,y:742,t:1527267449435};\\\", \\\"{x:524,y:686,t:1527267449452};\\\", \\\"{x:338,y:657,t:1527267449469};\\\", \\\"{x:231,y:633,t:1527267449490};\\\", \\\"{x:199,y:622,t:1527267449507};\\\", \\\"{x:190,y:617,t:1527267449522};\\\", \\\"{x:189,y:616,t:1527267449538};\\\", \\\"{x:188,y:613,t:1527267449556};\\\", \\\"{x:188,y:607,t:1527267449573};\\\", \\\"{x:188,y:604,t:1527267449590};\\\", \\\"{x:188,y:600,t:1527267449606};\\\", \\\"{x:188,y:595,t:1527267449623};\\\", \\\"{x:188,y:583,t:1527267449641};\\\", \\\"{x:188,y:577,t:1527267449656};\\\", \\\"{x:187,y:571,t:1527267449673};\\\", \\\"{x:187,y:565,t:1527267449691};\\\", \\\"{x:190,y:560,t:1527267449707};\\\", \\\"{x:196,y:555,t:1527267449724};\\\", \\\"{x:211,y:548,t:1527267449740};\\\", \\\"{x:235,y:539,t:1527267449757};\\\", \\\"{x:265,y:534,t:1527267449773};\\\", \\\"{x:311,y:531,t:1527267449792};\\\", \\\"{x:372,y:524,t:1527267449806};\\\", \\\"{x:436,y:524,t:1527267449823};\\\", \\\"{x:512,y:523,t:1527267449840};\\\", \\\"{x:547,y:523,t:1527267449858};\\\", \\\"{x:570,y:523,t:1527267449873};\\\", \\\"{x:580,y:523,t:1527267449890};\\\", \\\"{x:582,y:523,t:1527267449907};\\\", \\\"{x:583,y:523,t:1527267449976};\\\", \\\"{x:584,y:523,t:1527267449990};\\\", \\\"{x:585,y:523,t:1527267450017};\\\", \\\"{x:588,y:523,t:1527267450024};\\\", \\\"{x:588,y:524,t:1527267450040};\\\", \\\"{x:590,y:527,t:1527267450058};\\\", \\\"{x:591,y:530,t:1527267450074};\\\", \\\"{x:590,y:535,t:1527267450090};\\\", \\\"{x:581,y:541,t:1527267450107};\\\", \\\"{x:566,y:545,t:1527267450123};\\\", \\\"{x:551,y:549,t:1527267450140};\\\", \\\"{x:531,y:551,t:1527267450157};\\\", \\\"{x:510,y:552,t:1527267450174};\\\", \\\"{x:485,y:555,t:1527267450191};\\\", \\\"{x:472,y:555,t:1527267450208};\\\", \\\"{x:469,y:555,t:1527267450224};\\\", \\\"{x:467,y:555,t:1527267450240};\\\", \\\"{x:466,y:555,t:1527267450257};\\\", \\\"{x:464,y:554,t:1527267450289};\\\", \\\"{x:463,y:554,t:1527267450321};\\\", \\\"{x:460,y:553,t:1527267450328};\\\", \\\"{x:456,y:552,t:1527267450341};\\\", \\\"{x:446,y:550,t:1527267450358};\\\", \\\"{x:436,y:550,t:1527267450375};\\\", \\\"{x:428,y:550,t:1527267450390};\\\", \\\"{x:420,y:550,t:1527267450407};\\\", \\\"{x:417,y:549,t:1527267450425};\\\", \\\"{x:415,y:547,t:1527267450440};\\\", \\\"{x:411,y:546,t:1527267450458};\\\", \\\"{x:405,y:543,t:1527267450475};\\\", \\\"{x:391,y:542,t:1527267450490};\\\", \\\"{x:377,y:542,t:1527267450507};\\\", \\\"{x:363,y:542,t:1527267450524};\\\", \\\"{x:340,y:545,t:1527267450540};\\\", \\\"{x:300,y:546,t:1527267450557};\\\", \\\"{x:247,y:554,t:1527267450574};\\\", \\\"{x:215,y:555,t:1527267450590};\\\", \\\"{x:197,y:557,t:1527267450608};\\\", \\\"{x:187,y:557,t:1527267450624};\\\", \\\"{x:185,y:557,t:1527267450712};\\\", \\\"{x:181,y:558,t:1527267450725};\\\", \\\"{x:176,y:559,t:1527267450741};\\\", \\\"{x:173,y:561,t:1527267450758};\\\", \\\"{x:170,y:562,t:1527267450775};\\\", \\\"{x:169,y:564,t:1527267450794};\\\", \\\"{x:166,y:567,t:1527267450808};\\\", \\\"{x:161,y:573,t:1527267450824};\\\", \\\"{x:158,y:577,t:1527267450842};\\\", \\\"{x:157,y:582,t:1527267450858};\\\", \\\"{x:154,y:587,t:1527267450875};\\\", \\\"{x:154,y:594,t:1527267450892};\\\", \\\"{x:153,y:601,t:1527267450907};\\\", \\\"{x:153,y:611,t:1527267450925};\\\", \\\"{x:154,y:623,t:1527267450940};\\\", \\\"{x:155,y:629,t:1527267450957};\\\", \\\"{x:157,y:632,t:1527267450975};\\\", \\\"{x:158,y:634,t:1527267450991};\\\", \\\"{x:160,y:636,t:1527267451008};\\\", \\\"{x:161,y:637,t:1527267451024};\\\", \\\"{x:163,y:637,t:1527267451048};\\\", \\\"{x:164,y:637,t:1527267451058};\\\", \\\"{x:171,y:637,t:1527267451074};\\\", \\\"{x:187,y:637,t:1527267451091};\\\", \\\"{x:211,y:637,t:1527267451108};\\\", \\\"{x:247,y:637,t:1527267451125};\\\", \\\"{x:284,y:637,t:1527267451141};\\\", \\\"{x:312,y:637,t:1527267451158};\\\", \\\"{x:341,y:637,t:1527267451175};\\\", \\\"{x:369,y:637,t:1527267451192};\\\", \\\"{x:397,y:633,t:1527267451209};\\\", \\\"{x:407,y:631,t:1527267451226};\\\", \\\"{x:415,y:629,t:1527267451241};\\\", \\\"{x:426,y:623,t:1527267451258};\\\", \\\"{x:439,y:617,t:1527267451274};\\\", \\\"{x:458,y:608,t:1527267451291};\\\", \\\"{x:479,y:602,t:1527267451308};\\\", \\\"{x:496,y:595,t:1527267451324};\\\", \\\"{x:506,y:590,t:1527267451342};\\\", \\\"{x:510,y:587,t:1527267451358};\\\", \\\"{x:510,y:586,t:1527267451374};\\\", \\\"{x:510,y:585,t:1527267451392};\\\", \\\"{x:510,y:583,t:1527267451408};\\\", \\\"{x:510,y:580,t:1527267451424};\\\", \\\"{x:510,y:578,t:1527267451442};\\\", \\\"{x:511,y:576,t:1527267451459};\\\", \\\"{x:515,y:573,t:1527267451474};\\\", \\\"{x:521,y:571,t:1527267451491};\\\", \\\"{x:536,y:565,t:1527267451508};\\\", \\\"{x:557,y:557,t:1527267451525};\\\", \\\"{x:578,y:547,t:1527267451542};\\\", \\\"{x:594,y:542,t:1527267451558};\\\", \\\"{x:602,y:538,t:1527267451576};\\\", \\\"{x:606,y:537,t:1527267451591};\\\", \\\"{x:608,y:537,t:1527267451608};\\\", \\\"{x:608,y:536,t:1527267451625};\\\", \\\"{x:608,y:533,t:1527267451641};\\\", \\\"{x:613,y:530,t:1527267451659};\\\", \\\"{x:621,y:527,t:1527267451676};\\\", \\\"{x:627,y:525,t:1527267451692};\\\", \\\"{x:633,y:524,t:1527267451708};\\\", \\\"{x:649,y:522,t:1527267451725};\\\", \\\"{x:679,y:522,t:1527267451741};\\\", \\\"{x:705,y:522,t:1527267451758};\\\", \\\"{x:728,y:520,t:1527267451775};\\\", \\\"{x:745,y:517,t:1527267451792};\\\", \\\"{x:758,y:515,t:1527267451808};\\\", \\\"{x:762,y:513,t:1527267451825};\\\", \\\"{x:763,y:513,t:1527267451842};\\\", \\\"{x:766,y:513,t:1527267451880};\\\", \\\"{x:769,y:512,t:1527267451891};\\\", \\\"{x:775,y:510,t:1527267451909};\\\", \\\"{x:781,y:508,t:1527267451925};\\\", \\\"{x:783,y:508,t:1527267451942};\\\", \\\"{x:785,y:507,t:1527267451959};\\\", \\\"{x:789,y:506,t:1527267451975};\\\", \\\"{x:793,y:505,t:1527267451992};\\\", \\\"{x:800,y:505,t:1527267452008};\\\", \\\"{x:803,y:505,t:1527267452025};\\\", \\\"{x:807,y:505,t:1527267452043};\\\", \\\"{x:810,y:505,t:1527267452059};\\\", \\\"{x:812,y:505,t:1527267452075};\\\", \\\"{x:813,y:505,t:1527267452092};\\\", \\\"{x:814,y:505,t:1527267452129};\\\", \\\"{x:815,y:505,t:1527267452154};\\\", \\\"{x:816,y:505,t:1527267452177};\\\", \\\"{x:818,y:505,t:1527267452321};\\\", \\\"{x:819,y:505,t:1527267452329};\\\", \\\"{x:821,y:505,t:1527267452344};\\\", \\\"{x:822,y:505,t:1527267452359};\\\", \\\"{x:826,y:505,t:1527267452376};\\\", \\\"{x:830,y:505,t:1527267452392};\\\", \\\"{x:831,y:505,t:1527267452794};\\\", \\\"{x:835,y:505,t:1527267452810};\\\", \\\"{x:840,y:506,t:1527267452826};\\\", \\\"{x:849,y:508,t:1527267452843};\\\", \\\"{x:871,y:513,t:1527267452860};\\\", \\\"{x:916,y:524,t:1527267452877};\\\", \\\"{x:988,y:535,t:1527267452893};\\\", \\\"{x:1069,y:550,t:1527267452910};\\\", \\\"{x:1126,y:561,t:1527267452925};\\\", \\\"{x:1166,y:574,t:1527267452943};\\\", \\\"{x:1193,y:586,t:1527267452959};\\\", \\\"{x:1236,y:604,t:1527267452976};\\\", \\\"{x:1267,y:617,t:1527267452993};\\\", \\\"{x:1301,y:626,t:1527267453009};\\\", \\\"{x:1340,y:637,t:1527267453026};\\\", \\\"{x:1387,y:651,t:1527267453043};\\\", \\\"{x:1437,y:663,t:1527267453060};\\\", \\\"{x:1491,y:681,t:1527267453076};\\\", \\\"{x:1549,y:700,t:1527267453093};\\\", \\\"{x:1588,y:710,t:1527267453110};\\\", \\\"{x:1610,y:717,t:1527267453127};\\\", \\\"{x:1619,y:719,t:1527267453142};\\\", \\\"{x:1620,y:719,t:1527267453273};\\\", \\\"{x:1622,y:719,t:1527267453297};\\\", \\\"{x:1623,y:719,t:1527267453337};\\\", \\\"{x:1624,y:717,t:1527267453354};\\\", \\\"{x:1626,y:715,t:1527267453360};\\\", \\\"{x:1626,y:712,t:1527267453376};\\\", \\\"{x:1626,y:709,t:1527267453393};\\\", \\\"{x:1624,y:705,t:1527267453409};\\\", \\\"{x:1620,y:702,t:1527267453427};\\\", \\\"{x:1618,y:701,t:1527267453444};\\\", \\\"{x:1617,y:701,t:1527267453459};\\\", \\\"{x:1616,y:701,t:1527267453476};\\\", \\\"{x:1615,y:701,t:1527267453529};\\\", \\\"{x:1614,y:700,t:1527267453544};\\\", \\\"{x:1613,y:700,t:1527267453559};\\\", \\\"{x:1612,y:700,t:1527267454418};\\\", \\\"{x:1611,y:700,t:1527267464408};\\\", \\\"{x:1610,y:700,t:1527267464416};\\\", \\\"{x:1609,y:701,t:1527267464441};\\\", \\\"{x:1609,y:702,t:1527267464554};\\\", \\\"{x:1609,y:705,t:1527267464568};\\\", \\\"{x:1609,y:708,t:1527267464584};\\\", \\\"{x:1609,y:715,t:1527267464601};\\\", \\\"{x:1609,y:724,t:1527267464616};\\\", \\\"{x:1609,y:735,t:1527267464634};\\\", \\\"{x:1609,y:745,t:1527267464651};\\\", \\\"{x:1609,y:750,t:1527267464668};\\\", \\\"{x:1609,y:752,t:1527267464684};\\\", \\\"{x:1609,y:754,t:1527267464701};\\\", \\\"{x:1610,y:756,t:1527267464737};\\\", \\\"{x:1610,y:758,t:1527267464751};\\\", \\\"{x:1614,y:764,t:1527267464768};\\\", \\\"{x:1618,y:775,t:1527267464784};\\\", \\\"{x:1623,y:791,t:1527267464801};\\\", \\\"{x:1625,y:803,t:1527267464817};\\\", \\\"{x:1627,y:814,t:1527267464834};\\\", \\\"{x:1627,y:825,t:1527267464851};\\\", \\\"{x:1627,y:839,t:1527267464868};\\\", \\\"{x:1627,y:850,t:1527267464884};\\\", \\\"{x:1627,y:858,t:1527267464900};\\\", \\\"{x:1627,y:863,t:1527267464918};\\\", \\\"{x:1627,y:866,t:1527267464933};\\\", \\\"{x:1627,y:869,t:1527267464950};\\\", \\\"{x:1627,y:873,t:1527267464968};\\\", \\\"{x:1627,y:876,t:1527267464983};\\\", \\\"{x:1627,y:882,t:1527267465001};\\\", \\\"{x:1627,y:884,t:1527267465017};\\\", \\\"{x:1627,y:888,t:1527267465033};\\\", \\\"{x:1627,y:891,t:1527267465051};\\\", \\\"{x:1627,y:894,t:1527267465066};\\\", \\\"{x:1627,y:896,t:1527267465083};\\\", \\\"{x:1628,y:897,t:1527267465100};\\\", \\\"{x:1628,y:900,t:1527267465117};\\\", \\\"{x:1629,y:902,t:1527267465134};\\\", \\\"{x:1629,y:903,t:1527267465150};\\\", \\\"{x:1631,y:905,t:1527267465167};\\\", \\\"{x:1631,y:906,t:1527267465184};\\\", \\\"{x:1631,y:909,t:1527267465200};\\\", \\\"{x:1632,y:912,t:1527267465217};\\\", \\\"{x:1632,y:913,t:1527267465235};\\\", \\\"{x:1633,y:917,t:1527267465250};\\\", \\\"{x:1634,y:920,t:1527267465267};\\\", \\\"{x:1634,y:923,t:1527267465284};\\\", \\\"{x:1635,y:924,t:1527267465300};\\\", \\\"{x:1635,y:926,t:1527267465317};\\\", \\\"{x:1635,y:928,t:1527267465334};\\\", \\\"{x:1635,y:929,t:1527267465350};\\\", \\\"{x:1635,y:930,t:1527267465368};\\\", \\\"{x:1635,y:932,t:1527267465384};\\\", \\\"{x:1635,y:935,t:1527267465401};\\\", \\\"{x:1635,y:937,t:1527267465417};\\\", \\\"{x:1635,y:941,t:1527267465434};\\\", \\\"{x:1635,y:944,t:1527267465451};\\\", \\\"{x:1635,y:946,t:1527267465468};\\\", \\\"{x:1635,y:949,t:1527267465485};\\\", \\\"{x:1635,y:950,t:1527267465501};\\\", \\\"{x:1635,y:951,t:1527267465518};\\\", \\\"{x:1635,y:953,t:1527267465535};\\\", \\\"{x:1635,y:954,t:1527267465551};\\\", \\\"{x:1635,y:955,t:1527267465567};\\\", \\\"{x:1635,y:957,t:1527267465585};\\\", \\\"{x:1635,y:958,t:1527267465649};\\\", \\\"{x:1635,y:959,t:1527267465657};\\\", \\\"{x:1635,y:960,t:1527267465681};\\\", \\\"{x:1638,y:961,t:1527267465762};\\\", \\\"{x:1638,y:962,t:1527267465777};\\\", \\\"{x:1639,y:963,t:1527267465785};\\\", \\\"{x:1639,y:964,t:1527267465802};\\\", \\\"{x:1640,y:965,t:1527267465890};\\\", \\\"{x:1641,y:964,t:1527267465929};\\\", \\\"{x:1641,y:959,t:1527267465938};\\\", \\\"{x:1639,y:950,t:1527267465951};\\\", \\\"{x:1633,y:927,t:1527267465967};\\\", \\\"{x:1621,y:874,t:1527267465984};\\\", \\\"{x:1617,y:846,t:1527267466001};\\\", \\\"{x:1612,y:820,t:1527267466017};\\\", \\\"{x:1609,y:794,t:1527267466034};\\\", \\\"{x:1604,y:774,t:1527267466051};\\\", \\\"{x:1604,y:766,t:1527267466067};\\\", \\\"{x:1604,y:761,t:1527267466085};\\\", \\\"{x:1604,y:754,t:1527267466101};\\\", \\\"{x:1604,y:746,t:1527267466117};\\\", \\\"{x:1602,y:737,t:1527267466134};\\\", \\\"{x:1602,y:731,t:1527267466151};\\\", \\\"{x:1602,y:722,t:1527267466167};\\\", \\\"{x:1601,y:711,t:1527267466184};\\\", \\\"{x:1600,y:705,t:1527267466201};\\\", \\\"{x:1599,y:702,t:1527267466217};\\\", \\\"{x:1599,y:698,t:1527267466234};\\\", \\\"{x:1599,y:697,t:1527267466251};\\\", \\\"{x:1599,y:693,t:1527267466267};\\\", \\\"{x:1599,y:690,t:1527267466284};\\\", \\\"{x:1599,y:686,t:1527267466301};\\\", \\\"{x:1601,y:682,t:1527267466318};\\\", \\\"{x:1601,y:680,t:1527267466335};\\\", \\\"{x:1604,y:677,t:1527267466352};\\\", \\\"{x:1605,y:676,t:1527267466368};\\\", \\\"{x:1608,y:676,t:1527267466417};\\\", \\\"{x:1609,y:677,t:1527267466425};\\\", \\\"{x:1610,y:677,t:1527267466441};\\\", \\\"{x:1611,y:679,t:1527267466452};\\\", \\\"{x:1612,y:684,t:1527267466468};\\\", \\\"{x:1613,y:692,t:1527267466485};\\\", \\\"{x:1613,y:699,t:1527267466501};\\\", \\\"{x:1613,y:708,t:1527267466520};\\\", \\\"{x:1613,y:713,t:1527267466535};\\\", \\\"{x:1613,y:717,t:1527267466552};\\\", \\\"{x:1612,y:723,t:1527267466569};\\\", \\\"{x:1612,y:732,t:1527267466585};\\\", \\\"{x:1612,y:741,t:1527267466602};\\\", \\\"{x:1612,y:753,t:1527267466619};\\\", \\\"{x:1612,y:758,t:1527267466635};\\\", \\\"{x:1611,y:766,t:1527267466651};\\\", \\\"{x:1610,y:779,t:1527267466668};\\\", \\\"{x:1610,y:790,t:1527267466685};\\\", \\\"{x:1610,y:800,t:1527267466702};\\\", \\\"{x:1609,y:809,t:1527267466718};\\\", \\\"{x:1607,y:817,t:1527267466734};\\\", \\\"{x:1606,y:829,t:1527267466752};\\\", \\\"{x:1605,y:844,t:1527267466769};\\\", \\\"{x:1605,y:854,t:1527267466784};\\\", \\\"{x:1602,y:865,t:1527267466802};\\\", \\\"{x:1601,y:875,t:1527267466819};\\\", \\\"{x:1601,y:883,t:1527267466834};\\\", \\\"{x:1601,y:893,t:1527267466851};\\\", \\\"{x:1600,y:902,t:1527267466869};\\\", \\\"{x:1600,y:906,t:1527267466885};\\\", \\\"{x:1598,y:912,t:1527267466901};\\\", \\\"{x:1597,y:918,t:1527267466918};\\\", \\\"{x:1597,y:922,t:1527267466935};\\\", \\\"{x:1597,y:929,t:1527267466952};\\\", \\\"{x:1597,y:937,t:1527267466968};\\\", \\\"{x:1597,y:940,t:1527267466985};\\\", \\\"{x:1597,y:946,t:1527267467001};\\\", \\\"{x:1597,y:952,t:1527267467018};\\\", \\\"{x:1597,y:955,t:1527267467035};\\\", \\\"{x:1597,y:958,t:1527267467051};\\\", \\\"{x:1597,y:959,t:1527267467068};\\\", \\\"{x:1597,y:960,t:1527267467085};\\\", \\\"{x:1597,y:962,t:1527267467101};\\\", \\\"{x:1597,y:964,t:1527267467118};\\\", \\\"{x:1597,y:967,t:1527267467135};\\\", \\\"{x:1598,y:969,t:1527267467151};\\\", \\\"{x:1598,y:971,t:1527267467168};\\\", \\\"{x:1599,y:973,t:1527267467185};\\\", \\\"{x:1599,y:974,t:1527267467201};\\\", \\\"{x:1600,y:975,t:1527267467218};\\\", \\\"{x:1600,y:976,t:1527267467235};\\\", \\\"{x:1600,y:977,t:1527267467608};\\\", \\\"{x:1594,y:976,t:1527267467618};\\\", \\\"{x:1580,y:971,t:1527267467635};\\\", \\\"{x:1567,y:968,t:1527267467652};\\\", \\\"{x:1556,y:966,t:1527267467667};\\\", \\\"{x:1548,y:962,t:1527267467685};\\\", \\\"{x:1544,y:961,t:1527267467702};\\\", \\\"{x:1536,y:957,t:1527267467717};\\\", \\\"{x:1531,y:954,t:1527267467735};\\\", \\\"{x:1511,y:941,t:1527267467751};\\\", \\\"{x:1486,y:927,t:1527267467768};\\\", \\\"{x:1466,y:918,t:1527267467785};\\\", \\\"{x:1454,y:910,t:1527267467802};\\\", \\\"{x:1446,y:905,t:1527267467818};\\\", \\\"{x:1436,y:896,t:1527267467835};\\\", \\\"{x:1426,y:888,t:1527267467851};\\\", \\\"{x:1417,y:875,t:1527267467868};\\\", \\\"{x:1414,y:870,t:1527267467885};\\\", \\\"{x:1409,y:866,t:1527267467902};\\\", \\\"{x:1408,y:865,t:1527267467919};\\\", \\\"{x:1408,y:864,t:1527267467935};\\\", \\\"{x:1405,y:861,t:1527267467953};\\\", \\\"{x:1399,y:857,t:1527267467968};\\\", \\\"{x:1381,y:853,t:1527267467985};\\\", \\\"{x:1360,y:846,t:1527267468002};\\\", \\\"{x:1348,y:845,t:1527267468019};\\\", \\\"{x:1332,y:841,t:1527267468035};\\\", \\\"{x:1311,y:839,t:1527267468052};\\\", \\\"{x:1282,y:838,t:1527267468068};\\\", \\\"{x:1253,y:838,t:1527267468086};\\\", \\\"{x:1229,y:838,t:1527267468103};\\\", \\\"{x:1210,y:838,t:1527267468120};\\\", \\\"{x:1201,y:838,t:1527267468135};\\\", \\\"{x:1189,y:838,t:1527267468153};\\\", \\\"{x:1184,y:838,t:1527267468169};\\\", \\\"{x:1179,y:838,t:1527267468185};\\\", \\\"{x:1173,y:838,t:1527267468202};\\\", \\\"{x:1167,y:838,t:1527267468219};\\\", \\\"{x:1156,y:838,t:1527267468235};\\\", \\\"{x:1134,y:838,t:1527267468253};\\\", \\\"{x:1108,y:838,t:1527267468270};\\\", \\\"{x:1091,y:838,t:1527267468285};\\\", \\\"{x:1070,y:838,t:1527267468303};\\\", \\\"{x:1051,y:838,t:1527267468320};\\\", \\\"{x:1025,y:833,t:1527267468335};\\\", \\\"{x:980,y:827,t:1527267468354};\\\", \\\"{x:957,y:824,t:1527267468369};\\\", \\\"{x:940,y:822,t:1527267468386};\\\", \\\"{x:923,y:818,t:1527267468403};\\\", \\\"{x:904,y:816,t:1527267468420};\\\", \\\"{x:886,y:813,t:1527267468435};\\\", \\\"{x:864,y:811,t:1527267468452};\\\", \\\"{x:813,y:802,t:1527267468470};\\\", \\\"{x:731,y:787,t:1527267468486};\\\", \\\"{x:630,y:768,t:1527267468502};\\\", \\\"{x:529,y:748,t:1527267468521};\\\", \\\"{x:402,y:727,t:1527267468536};\\\", \\\"{x:299,y:705,t:1527267468569};\\\", \\\"{x:283,y:698,t:1527267468589};\\\", \\\"{x:277,y:692,t:1527267468605};\\\", \\\"{x:273,y:682,t:1527267468622};\\\", \\\"{x:272,y:676,t:1527267468639};\\\", \\\"{x:270,y:670,t:1527267468655};\\\", \\\"{x:271,y:659,t:1527267468673};\\\", \\\"{x:282,y:641,t:1527267468690};\\\", \\\"{x:297,y:621,t:1527267468706};\\\", \\\"{x:316,y:602,t:1527267468722};\\\", \\\"{x:341,y:586,t:1527267468740};\\\", \\\"{x:355,y:574,t:1527267468755};\\\", \\\"{x:359,y:569,t:1527267468772};\\\", \\\"{x:363,y:565,t:1527267468789};\\\", \\\"{x:365,y:563,t:1527267468806};\\\", \\\"{x:369,y:561,t:1527267468823};\\\", \\\"{x:374,y:561,t:1527267468839};\\\", \\\"{x:380,y:561,t:1527267468855};\\\", \\\"{x:399,y:562,t:1527267468871};\\\", \\\"{x:410,y:565,t:1527267468889};\\\", \\\"{x:425,y:570,t:1527267468904};\\\", \\\"{x:433,y:572,t:1527267468922};\\\", \\\"{x:443,y:573,t:1527267468939};\\\", \\\"{x:464,y:575,t:1527267468956};\\\", \\\"{x:486,y:578,t:1527267468972};\\\", \\\"{x:504,y:581,t:1527267468990};\\\", \\\"{x:517,y:583,t:1527267469006};\\\", \\\"{x:526,y:584,t:1527267469022};\\\", \\\"{x:531,y:584,t:1527267469039};\\\", \\\"{x:536,y:584,t:1527267469055};\\\", \\\"{x:537,y:584,t:1527267469072};\\\", \\\"{x:540,y:585,t:1527267469089};\\\", \\\"{x:544,y:585,t:1527267469106};\\\", \\\"{x:549,y:585,t:1527267469122};\\\", \\\"{x:558,y:585,t:1527267469139};\\\", \\\"{x:565,y:585,t:1527267469156};\\\", \\\"{x:574,y:587,t:1527267469172};\\\", \\\"{x:578,y:587,t:1527267469189};\\\", \\\"{x:582,y:586,t:1527267469207};\\\", \\\"{x:584,y:586,t:1527267469222};\\\", \\\"{x:587,y:586,t:1527267469239};\\\", \\\"{x:595,y:587,t:1527267469256};\\\", \\\"{x:596,y:587,t:1527267469272};\\\", \\\"{x:598,y:587,t:1527267469289};\\\", \\\"{x:600,y:587,t:1527267469307};\\\", \\\"{x:601,y:587,t:1527267469322};\\\", \\\"{x:604,y:587,t:1527267469339};\\\", \\\"{x:606,y:587,t:1527267469356};\\\", \\\"{x:607,y:587,t:1527267469785};\\\", \\\"{x:607,y:588,t:1527267469793};\\\", \\\"{x:607,y:591,t:1527267469807};\\\", \\\"{x:605,y:605,t:1527267469823};\\\", \\\"{x:598,y:624,t:1527267469839};\\\", \\\"{x:590,y:649,t:1527267469856};\\\", \\\"{x:583,y:663,t:1527267469873};\\\", \\\"{x:578,y:670,t:1527267469889};\\\", \\\"{x:572,y:679,t:1527267469906};\\\", \\\"{x:567,y:689,t:1527267469924};\\\", \\\"{x:564,y:696,t:1527267469940};\\\", \\\"{x:563,y:700,t:1527267469957};\\\", \\\"{x:559,y:708,t:1527267469973};\\\", \\\"{x:555,y:714,t:1527267469989};\\\", \\\"{x:553,y:717,t:1527267470006};\\\", \\\"{x:552,y:718,t:1527267470024};\\\", \\\"{x:551,y:720,t:1527267470041};\\\", \\\"{x:551,y:723,t:1527267470056};\\\", \\\"{x:550,y:725,t:1527267470080};\\\", \\\"{x:550,y:726,t:1527267470096};\\\", \\\"{x:550,y:727,t:1527267470106};\\\", \\\"{x:545,y:734,t:1527267470122};\\\", \\\"{x:544,y:738,t:1527267470139};\\\", \\\"{x:543,y:738,t:1527267470176};\\\", \\\"{x:546,y:741,t:1527267470456};\\\", \\\"{x:563,y:747,t:1527267470473};\\\", \\\"{x:587,y:749,t:1527267470490};\\\", \\\"{x:611,y:749,t:1527267470507};\\\", \\\"{x:636,y:749,t:1527267470523};\\\", \\\"{x:664,y:749,t:1527267470540};\\\", \\\"{x:691,y:748,t:1527267470557};\\\", \\\"{x:705,y:746,t:1527267470573};\\\", \\\"{x:709,y:742,t:1527267470590};\\\", \\\"{x:710,y:742,t:1527267470607};\\\" ] }, { \\\"rt\\\": 31795, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 473114, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-F -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:710,y:741,t:1527267472425};\\\", \\\"{x:710,y:740,t:1527267473281};\\\", \\\"{x:707,y:739,t:1527267473297};\\\", \\\"{x:705,y:739,t:1527267473310};\\\", \\\"{x:703,y:738,t:1527267473327};\\\", \\\"{x:702,y:739,t:1527267473401};\\\", \\\"{x:702,y:742,t:1527267473410};\\\", \\\"{x:700,y:750,t:1527267473427};\\\", \\\"{x:700,y:755,t:1527267473442};\\\", \\\"{x:700,y:758,t:1527267473460};\\\", \\\"{x:701,y:759,t:1527267473481};\\\", \\\"{x:702,y:759,t:1527267473492};\\\", \\\"{x:707,y:762,t:1527267473509};\\\", \\\"{x:709,y:762,t:1527267473526};\\\", \\\"{x:710,y:762,t:1527267473543};\\\", \\\"{x:713,y:762,t:1527267473559};\\\", \\\"{x:721,y:762,t:1527267473577};\\\", \\\"{x:726,y:762,t:1527267473593};\\\", \\\"{x:736,y:763,t:1527267473610};\\\", \\\"{x:751,y:768,t:1527267473626};\\\", \\\"{x:760,y:772,t:1527267473643};\\\", \\\"{x:764,y:775,t:1527267473659};\\\", \\\"{x:767,y:781,t:1527267473677};\\\", \\\"{x:767,y:787,t:1527267473692};\\\", \\\"{x:766,y:794,t:1527267473710};\\\", \\\"{x:760,y:800,t:1527267473727};\\\", \\\"{x:754,y:802,t:1527267473743};\\\", \\\"{x:745,y:805,t:1527267473760};\\\", \\\"{x:727,y:806,t:1527267473776};\\\", \\\"{x:713,y:806,t:1527267473793};\\\", \\\"{x:703,y:804,t:1527267473810};\\\", \\\"{x:691,y:798,t:1527267473826};\\\", \\\"{x:677,y:788,t:1527267473843};\\\", \\\"{x:675,y:782,t:1527267473859};\\\", \\\"{x:675,y:780,t:1527267473876};\\\", \\\"{x:675,y:779,t:1527267473894};\\\", \\\"{x:675,y:778,t:1527267473945};\\\", \\\"{x:681,y:778,t:1527267473959};\\\", \\\"{x:696,y:789,t:1527267473977};\\\", \\\"{x:702,y:793,t:1527267473994};\\\", \\\"{x:707,y:793,t:1527267474009};\\\", \\\"{x:710,y:794,t:1527267474027};\\\", \\\"{x:712,y:794,t:1527267474044};\\\", \\\"{x:715,y:794,t:1527267474060};\\\", \\\"{x:719,y:786,t:1527267474076};\\\", \\\"{x:720,y:781,t:1527267474093};\\\", \\\"{x:722,y:772,t:1527267474110};\\\", \\\"{x:716,y:762,t:1527267474127};\\\", \\\"{x:707,y:752,t:1527267474144};\\\", \\\"{x:706,y:750,t:1527267474160};\\\", \\\"{x:707,y:750,t:1527267474361};\\\", \\\"{x:716,y:751,t:1527267474377};\\\", \\\"{x:743,y:755,t:1527267474394};\\\", \\\"{x:783,y:763,t:1527267474411};\\\", \\\"{x:845,y:775,t:1527267474426};\\\", \\\"{x:938,y:792,t:1527267474444};\\\", \\\"{x:1043,y:823,t:1527267474461};\\\", \\\"{x:1148,y:849,t:1527267474477};\\\", \\\"{x:1256,y:879,t:1527267474494};\\\", \\\"{x:1361,y:910,t:1527267474512};\\\", \\\"{x:1468,y:936,t:1527267474527};\\\", \\\"{x:1568,y:964,t:1527267474545};\\\", \\\"{x:1668,y:994,t:1527267474561};\\\", \\\"{x:1706,y:1009,t:1527267474577};\\\", \\\"{x:1727,y:1019,t:1527267474594};\\\", \\\"{x:1743,y:1024,t:1527267474611};\\\", \\\"{x:1752,y:1028,t:1527267474627};\\\", \\\"{x:1756,y:1030,t:1527267474644};\\\", \\\"{x:1756,y:1032,t:1527267474661};\\\", \\\"{x:1758,y:1034,t:1527267474678};\\\", \\\"{x:1760,y:1038,t:1527267474694};\\\", \\\"{x:1762,y:1039,t:1527267474711};\\\", \\\"{x:1762,y:1040,t:1527267474745};\\\", \\\"{x:1762,y:1041,t:1527267474760};\\\", \\\"{x:1742,y:1042,t:1527267474778};\\\", \\\"{x:1713,y:1037,t:1527267474793};\\\", \\\"{x:1685,y:1029,t:1527267474810};\\\", \\\"{x:1649,y:1021,t:1527267474828};\\\", \\\"{x:1615,y:1016,t:1527267474843};\\\", \\\"{x:1600,y:1013,t:1527267474861};\\\", \\\"{x:1596,y:1012,t:1527267474878};\\\", \\\"{x:1596,y:1010,t:1527267474897};\\\", \\\"{x:1596,y:1008,t:1527267474910};\\\", \\\"{x:1596,y:1004,t:1527267474927};\\\", \\\"{x:1593,y:1000,t:1527267474944};\\\", \\\"{x:1592,y:999,t:1527267474961};\\\", \\\"{x:1592,y:998,t:1527267475048};\\\", \\\"{x:1591,y:998,t:1527267475060};\\\", \\\"{x:1588,y:998,t:1527267475077};\\\", \\\"{x:1580,y:994,t:1527267475093};\\\", \\\"{x:1573,y:993,t:1527267475110};\\\", \\\"{x:1568,y:992,t:1527267475127};\\\", \\\"{x:1566,y:990,t:1527267475145};\\\", \\\"{x:1564,y:989,t:1527267475160};\\\", \\\"{x:1562,y:989,t:1527267475177};\\\", \\\"{x:1561,y:987,t:1527267475195};\\\", \\\"{x:1559,y:983,t:1527267475211};\\\", \\\"{x:1557,y:981,t:1527267475228};\\\", \\\"{x:1557,y:980,t:1527267475245};\\\", \\\"{x:1557,y:978,t:1527267475264};\\\", \\\"{x:1556,y:976,t:1527267475281};\\\", \\\"{x:1555,y:976,t:1527267475295};\\\", \\\"{x:1554,y:974,t:1527267475311};\\\", \\\"{x:1553,y:971,t:1527267475328};\\\", \\\"{x:1551,y:969,t:1527267475345};\\\", \\\"{x:1550,y:968,t:1527267475378};\\\", \\\"{x:1550,y:967,t:1527267475409};\\\", \\\"{x:1550,y:966,t:1527267475417};\\\", \\\"{x:1548,y:965,t:1527267476746};\\\", \\\"{x:1547,y:965,t:1527267476785};\\\", \\\"{x:1546,y:965,t:1527267476817};\\\", \\\"{x:1545,y:965,t:1527267476829};\\\", \\\"{x:1543,y:965,t:1527267476846};\\\", \\\"{x:1545,y:965,t:1527267479801};\\\", \\\"{x:1551,y:966,t:1527267479816};\\\", \\\"{x:1553,y:966,t:1527267479831};\\\", \\\"{x:1554,y:966,t:1527267479848};\\\", \\\"{x:1556,y:967,t:1527267479864};\\\", \\\"{x:1555,y:967,t:1527267480585};\\\", \\\"{x:1553,y:967,t:1527267480599};\\\", \\\"{x:1552,y:966,t:1527267480615};\\\", \\\"{x:1551,y:966,t:1527267480632};\\\", \\\"{x:1550,y:965,t:1527267480929};\\\", \\\"{x:1550,y:963,t:1527267480978};\\\", \\\"{x:1550,y:962,t:1527267480993};\\\", \\\"{x:1550,y:961,t:1527267481009};\\\", \\\"{x:1550,y:959,t:1527267481017};\\\", \\\"{x:1550,y:957,t:1527267481033};\\\", \\\"{x:1550,y:956,t:1527267481049};\\\", \\\"{x:1550,y:955,t:1527267481067};\\\", \\\"{x:1550,y:954,t:1527267481082};\\\", \\\"{x:1550,y:953,t:1527267481105};\\\", \\\"{x:1550,y:952,t:1527267481121};\\\", \\\"{x:1551,y:950,t:1527267481132};\\\", \\\"{x:1551,y:949,t:1527267481153};\\\", \\\"{x:1551,y:948,t:1527267481176};\\\", \\\"{x:1551,y:947,t:1527267481192};\\\", \\\"{x:1551,y:946,t:1527267481225};\\\", \\\"{x:1552,y:946,t:1527267481233};\\\", \\\"{x:1552,y:945,t:1527267481265};\\\", \\\"{x:1552,y:943,t:1527267481284};\\\", \\\"{x:1552,y:942,t:1527267481299};\\\", \\\"{x:1552,y:938,t:1527267481316};\\\", \\\"{x:1552,y:936,t:1527267481333};\\\", \\\"{x:1552,y:934,t:1527267481349};\\\", \\\"{x:1552,y:933,t:1527267481366};\\\", \\\"{x:1550,y:930,t:1527267481383};\\\", \\\"{x:1549,y:926,t:1527267481398};\\\", \\\"{x:1547,y:921,t:1527267481416};\\\", \\\"{x:1546,y:920,t:1527267481432};\\\", \\\"{x:1546,y:918,t:1527267481448};\\\", \\\"{x:1546,y:917,t:1527267481466};\\\", \\\"{x:1546,y:915,t:1527267481483};\\\", \\\"{x:1545,y:914,t:1527267481499};\\\", \\\"{x:1545,y:913,t:1527267481520};\\\", \\\"{x:1544,y:912,t:1527267481533};\\\", \\\"{x:1544,y:911,t:1527267481552};\\\", \\\"{x:1544,y:910,t:1527267481566};\\\", \\\"{x:1544,y:908,t:1527267481583};\\\", \\\"{x:1543,y:906,t:1527267481599};\\\", \\\"{x:1542,y:903,t:1527267481617};\\\", \\\"{x:1542,y:901,t:1527267481634};\\\", \\\"{x:1542,y:898,t:1527267481649};\\\", \\\"{x:1542,y:897,t:1527267481666};\\\", \\\"{x:1542,y:895,t:1527267481683};\\\", \\\"{x:1542,y:893,t:1527267481699};\\\", \\\"{x:1542,y:891,t:1527267481716};\\\", \\\"{x:1542,y:890,t:1527267481734};\\\", \\\"{x:1542,y:888,t:1527267481750};\\\", \\\"{x:1542,y:886,t:1527267481766};\\\", \\\"{x:1542,y:884,t:1527267481784};\\\", \\\"{x:1542,y:881,t:1527267481801};\\\", \\\"{x:1542,y:879,t:1527267481817};\\\", \\\"{x:1542,y:875,t:1527267481833};\\\", \\\"{x:1542,y:873,t:1527267481851};\\\", \\\"{x:1542,y:870,t:1527267481866};\\\", \\\"{x:1542,y:868,t:1527267481884};\\\", \\\"{x:1542,y:866,t:1527267481900};\\\", \\\"{x:1542,y:863,t:1527267481916};\\\", \\\"{x:1542,y:862,t:1527267481934};\\\", \\\"{x:1542,y:860,t:1527267481951};\\\", \\\"{x:1542,y:859,t:1527267481966};\\\", \\\"{x:1542,y:858,t:1527267481985};\\\", \\\"{x:1542,y:857,t:1527267482001};\\\", \\\"{x:1542,y:856,t:1527267482017};\\\", \\\"{x:1542,y:855,t:1527267482041};\\\", \\\"{x:1542,y:854,t:1527267482057};\\\", \\\"{x:1542,y:853,t:1527267482066};\\\", \\\"{x:1540,y:851,t:1527267482097};\\\", \\\"{x:1540,y:850,t:1527267482105};\\\", \\\"{x:1540,y:849,t:1527267482121};\\\", \\\"{x:1540,y:848,t:1527267482134};\\\", \\\"{x:1540,y:847,t:1527267482150};\\\", \\\"{x:1540,y:846,t:1527267482166};\\\", \\\"{x:1540,y:845,t:1527267482183};\\\", \\\"{x:1540,y:844,t:1527267482200};\\\", \\\"{x:1540,y:842,t:1527267482217};\\\", \\\"{x:1540,y:841,t:1527267482233};\\\", \\\"{x:1540,y:839,t:1527267482250};\\\", \\\"{x:1540,y:838,t:1527267482267};\\\", \\\"{x:1540,y:836,t:1527267482283};\\\", \\\"{x:1540,y:835,t:1527267482301};\\\", \\\"{x:1540,y:833,t:1527267482318};\\\", \\\"{x:1540,y:832,t:1527267482333};\\\", \\\"{x:1540,y:831,t:1527267482351};\\\", \\\"{x:1540,y:829,t:1527267482367};\\\", \\\"{x:1540,y:828,t:1527267482440};\\\", \\\"{x:1540,y:827,t:1527267482464};\\\", \\\"{x:1540,y:826,t:1527267482705};\\\", \\\"{x:1539,y:825,t:1527267482753};\\\", \\\"{x:1539,y:824,t:1527267482777};\\\", \\\"{x:1539,y:823,t:1527267482793};\\\", \\\"{x:1539,y:822,t:1527267482808};\\\", \\\"{x:1539,y:821,t:1527267482817};\\\", \\\"{x:1539,y:820,t:1527267482835};\\\", \\\"{x:1539,y:819,t:1527267482851};\\\", \\\"{x:1539,y:817,t:1527267482867};\\\", \\\"{x:1539,y:816,t:1527267482897};\\\", \\\"{x:1539,y:815,t:1527267482921};\\\", \\\"{x:1539,y:814,t:1527267482937};\\\", \\\"{x:1539,y:813,t:1527267482961};\\\", \\\"{x:1539,y:812,t:1527267482976};\\\", \\\"{x:1539,y:811,t:1527267482993};\\\", \\\"{x:1539,y:810,t:1527267483025};\\\", \\\"{x:1539,y:809,t:1527267483040};\\\", \\\"{x:1539,y:808,t:1527267483056};\\\", \\\"{x:1539,y:807,t:1527267483081};\\\", \\\"{x:1539,y:805,t:1527267483089};\\\", \\\"{x:1539,y:804,t:1527267483104};\\\", \\\"{x:1539,y:803,t:1527267483117};\\\", \\\"{x:1539,y:802,t:1527267483134};\\\", \\\"{x:1539,y:800,t:1527267483151};\\\", \\\"{x:1539,y:799,t:1527267483167};\\\", \\\"{x:1539,y:795,t:1527267483185};\\\", \\\"{x:1539,y:792,t:1527267483201};\\\", \\\"{x:1539,y:790,t:1527267483217};\\\", \\\"{x:1539,y:787,t:1527267483235};\\\", \\\"{x:1539,y:786,t:1527267483252};\\\", \\\"{x:1539,y:784,t:1527267483268};\\\", \\\"{x:1539,y:783,t:1527267483284};\\\", \\\"{x:1538,y:782,t:1527267483302};\\\", \\\"{x:1537,y:782,t:1527267483317};\\\", \\\"{x:1537,y:780,t:1527267483335};\\\", \\\"{x:1537,y:779,t:1527267483351};\\\", \\\"{x:1537,y:777,t:1527267483367};\\\", \\\"{x:1537,y:776,t:1527267483384};\\\", \\\"{x:1537,y:775,t:1527267483401};\\\", \\\"{x:1537,y:774,t:1527267483417};\\\", \\\"{x:1537,y:773,t:1527267483434};\\\", \\\"{x:1537,y:772,t:1527267483464};\\\", \\\"{x:1537,y:771,t:1527267483480};\\\", \\\"{x:1536,y:771,t:1527267483488};\\\", \\\"{x:1536,y:770,t:1527267483521};\\\", \\\"{x:1536,y:769,t:1527267483534};\\\", \\\"{x:1536,y:768,t:1527267483551};\\\", \\\"{x:1536,y:767,t:1527267483625};\\\", \\\"{x:1536,y:766,t:1527267483640};\\\", \\\"{x:1536,y:765,t:1527267483664};\\\", \\\"{x:1536,y:764,t:1527267483745};\\\", \\\"{x:1536,y:763,t:1527267483785};\\\", \\\"{x:1536,y:762,t:1527267483809};\\\", \\\"{x:1536,y:761,t:1527267483920};\\\", \\\"{x:1536,y:762,t:1527267489841};\\\", \\\"{x:1525,y:792,t:1527267489857};\\\", \\\"{x:1502,y:824,t:1527267489873};\\\", \\\"{x:1437,y:856,t:1527267489890};\\\", \\\"{x:1335,y:884,t:1527267489906};\\\", \\\"{x:1223,y:904,t:1527267489923};\\\", \\\"{x:1122,y:913,t:1527267489940};\\\", \\\"{x:997,y:913,t:1527267489957};\\\", \\\"{x:856,y:909,t:1527267489973};\\\", \\\"{x:721,y:879,t:1527267489989};\\\", \\\"{x:637,y:853,t:1527267490007};\\\", \\\"{x:588,y:823,t:1527267490023};\\\", \\\"{x:552,y:790,t:1527267490039};\\\", \\\"{x:523,y:749,t:1527267490057};\\\", \\\"{x:514,y:729,t:1527267490073};\\\", \\\"{x:510,y:717,t:1527267490089};\\\", \\\"{x:505,y:701,t:1527267490106};\\\", \\\"{x:504,y:697,t:1527267490119};\\\", \\\"{x:499,y:683,t:1527267490136};\\\", \\\"{x:495,y:674,t:1527267490153};\\\", \\\"{x:492,y:668,t:1527267490170};\\\", \\\"{x:487,y:662,t:1527267490185};\\\", \\\"{x:485,y:658,t:1527267490206};\\\", \\\"{x:485,y:657,t:1527267490223};\\\", \\\"{x:483,y:649,t:1527267490239};\\\", \\\"{x:479,y:640,t:1527267490256};\\\", \\\"{x:477,y:633,t:1527267490274};\\\", \\\"{x:476,y:628,t:1527267490291};\\\", \\\"{x:474,y:626,t:1527267490306};\\\", \\\"{x:473,y:623,t:1527267490323};\\\", \\\"{x:471,y:618,t:1527267490341};\\\", \\\"{x:469,y:613,t:1527267490357};\\\", \\\"{x:467,y:609,t:1527267490373};\\\", \\\"{x:466,y:607,t:1527267490390};\\\", \\\"{x:466,y:606,t:1527267490408};\\\", \\\"{x:465,y:605,t:1527267490423};\\\", \\\"{x:461,y:604,t:1527267490441};\\\", \\\"{x:459,y:603,t:1527267490456};\\\", \\\"{x:458,y:603,t:1527267490473};\\\", \\\"{x:457,y:603,t:1527267490503};\\\", \\\"{x:454,y:603,t:1527267490528};\\\", \\\"{x:451,y:603,t:1527267490541};\\\", \\\"{x:440,y:603,t:1527267490558};\\\", \\\"{x:427,y:603,t:1527267490573};\\\", \\\"{x:412,y:603,t:1527267490590};\\\", \\\"{x:398,y:603,t:1527267490607};\\\", \\\"{x:389,y:603,t:1527267490623};\\\", \\\"{x:376,y:603,t:1527267490640};\\\", \\\"{x:367,y:603,t:1527267490657};\\\", \\\"{x:360,y:603,t:1527267490673};\\\", \\\"{x:350,y:603,t:1527267490690};\\\", \\\"{x:341,y:603,t:1527267490707};\\\", \\\"{x:321,y:603,t:1527267490723};\\\", \\\"{x:283,y:603,t:1527267490741};\\\", \\\"{x:245,y:603,t:1527267490759};\\\", \\\"{x:215,y:603,t:1527267490774};\\\", \\\"{x:192,y:603,t:1527267490790};\\\", \\\"{x:179,y:600,t:1527267490807};\\\", \\\"{x:177,y:599,t:1527267490823};\\\", \\\"{x:176,y:599,t:1527267490839};\\\", \\\"{x:175,y:598,t:1527267490871};\\\", \\\"{x:174,y:597,t:1527267490895};\\\", \\\"{x:174,y:596,t:1527267490912};\\\", \\\"{x:174,y:595,t:1527267490923};\\\", \\\"{x:174,y:594,t:1527267490940};\\\", \\\"{x:174,y:592,t:1527267490957};\\\", \\\"{x:174,y:590,t:1527267490973};\\\", \\\"{x:174,y:586,t:1527267490991};\\\", \\\"{x:174,y:580,t:1527267491007};\\\", \\\"{x:174,y:575,t:1527267491023};\\\", \\\"{x:174,y:568,t:1527267491040};\\\", \\\"{x:171,y:560,t:1527267491058};\\\", \\\"{x:170,y:556,t:1527267491073};\\\", \\\"{x:169,y:556,t:1527267491091};\\\", \\\"{x:167,y:553,t:1527267491109};\\\", \\\"{x:166,y:552,t:1527267491127};\\\", \\\"{x:165,y:551,t:1527267491168};\\\", \\\"{x:164,y:550,t:1527267491175};\\\", \\\"{x:162,y:549,t:1527267491192};\\\", \\\"{x:159,y:548,t:1527267491207};\\\", \\\"{x:156,y:545,t:1527267491224};\\\", \\\"{x:155,y:545,t:1527267491240};\\\", \\\"{x:161,y:545,t:1527267491560};\\\", \\\"{x:185,y:555,t:1527267491575};\\\", \\\"{x:270,y:573,t:1527267491592};\\\", \\\"{x:398,y:594,t:1527267491608};\\\", \\\"{x:626,y:622,t:1527267491625};\\\", \\\"{x:767,y:640,t:1527267491642};\\\", \\\"{x:911,y:640,t:1527267491657};\\\", \\\"{x:1033,y:642,t:1527267491674};\\\", \\\"{x:1133,y:642,t:1527267491690};\\\", \\\"{x:1186,y:647,t:1527267491708};\\\", \\\"{x:1206,y:648,t:1527267491724};\\\", \\\"{x:1210,y:649,t:1527267491740};\\\", \\\"{x:1211,y:649,t:1527267491757};\\\", \\\"{x:1215,y:649,t:1527267491774};\\\", \\\"{x:1222,y:652,t:1527267491791};\\\", \\\"{x:1237,y:657,t:1527267491807};\\\", \\\"{x:1264,y:663,t:1527267491824};\\\", \\\"{x:1281,y:669,t:1527267491841};\\\", \\\"{x:1301,y:674,t:1527267491858};\\\", \\\"{x:1323,y:680,t:1527267491875};\\\", \\\"{x:1346,y:686,t:1527267491891};\\\", \\\"{x:1367,y:693,t:1527267491908};\\\", \\\"{x:1382,y:696,t:1527267491925};\\\", \\\"{x:1396,y:699,t:1527267491941};\\\", \\\"{x:1409,y:700,t:1527267491957};\\\", \\\"{x:1418,y:701,t:1527267491974};\\\", \\\"{x:1429,y:702,t:1527267491990};\\\", \\\"{x:1441,y:705,t:1527267492007};\\\", \\\"{x:1453,y:708,t:1527267492023};\\\", \\\"{x:1462,y:711,t:1527267492041};\\\", \\\"{x:1471,y:715,t:1527267492057};\\\", \\\"{x:1482,y:720,t:1527267492074};\\\", \\\"{x:1490,y:723,t:1527267492090};\\\", \\\"{x:1498,y:729,t:1527267492107};\\\", \\\"{x:1505,y:734,t:1527267492123};\\\", \\\"{x:1512,y:739,t:1527267492140};\\\", \\\"{x:1516,y:741,t:1527267492158};\\\", \\\"{x:1519,y:742,t:1527267492174};\\\", \\\"{x:1522,y:744,t:1527267492190};\\\", \\\"{x:1524,y:746,t:1527267492207};\\\", \\\"{x:1528,y:748,t:1527267492224};\\\", \\\"{x:1534,y:751,t:1527267492240};\\\", \\\"{x:1537,y:752,t:1527267492257};\\\", \\\"{x:1540,y:753,t:1527267492274};\\\", \\\"{x:1542,y:753,t:1527267492291};\\\", \\\"{x:1543,y:754,t:1527267492312};\\\", \\\"{x:1543,y:755,t:1527267492458};\\\", \\\"{x:1542,y:755,t:1527267492474};\\\", \\\"{x:1541,y:755,t:1527267492491};\\\", \\\"{x:1540,y:754,t:1527267492508};\\\", \\\"{x:1538,y:753,t:1527267492524};\\\", \\\"{x:1536,y:751,t:1527267492541};\\\", \\\"{x:1534,y:748,t:1527267492557};\\\", \\\"{x:1532,y:745,t:1527267492574};\\\", \\\"{x:1531,y:742,t:1527267492591};\\\", \\\"{x:1530,y:738,t:1527267492607};\\\", \\\"{x:1528,y:733,t:1527267492623};\\\", \\\"{x:1527,y:727,t:1527267492641};\\\", \\\"{x:1526,y:725,t:1527267492657};\\\", \\\"{x:1526,y:722,t:1527267492674};\\\", \\\"{x:1526,y:720,t:1527267492691};\\\", \\\"{x:1526,y:718,t:1527267492707};\\\", \\\"{x:1525,y:715,t:1527267492724};\\\", \\\"{x:1525,y:713,t:1527267492740};\\\", \\\"{x:1525,y:711,t:1527267492757};\\\", \\\"{x:1525,y:709,t:1527267492773};\\\", \\\"{x:1525,y:708,t:1527267492790};\\\", \\\"{x:1525,y:706,t:1527267492807};\\\", \\\"{x:1524,y:704,t:1527267492824};\\\", \\\"{x:1523,y:701,t:1527267492840};\\\", \\\"{x:1523,y:699,t:1527267492857};\\\", \\\"{x:1522,y:697,t:1527267492874};\\\", \\\"{x:1521,y:696,t:1527267492891};\\\", \\\"{x:1520,y:696,t:1527267492913};\\\", \\\"{x:1520,y:695,t:1527267492924};\\\", \\\"{x:1519,y:694,t:1527267492940};\\\", \\\"{x:1517,y:693,t:1527267492957};\\\", \\\"{x:1517,y:692,t:1527267492984};\\\", \\\"{x:1513,y:694,t:1527267495889};\\\", \\\"{x:1495,y:713,t:1527267495904};\\\", \\\"{x:1474,y:730,t:1527267495922};\\\", \\\"{x:1453,y:747,t:1527267495938};\\\", \\\"{x:1426,y:766,t:1527267495955};\\\", \\\"{x:1405,y:777,t:1527267495972};\\\", \\\"{x:1392,y:786,t:1527267495988};\\\", \\\"{x:1381,y:792,t:1527267496005};\\\", \\\"{x:1372,y:800,t:1527267496022};\\\", \\\"{x:1361,y:809,t:1527267496038};\\\", \\\"{x:1349,y:822,t:1527267496055};\\\", \\\"{x:1338,y:831,t:1527267496072};\\\", \\\"{x:1328,y:841,t:1527267496088};\\\", \\\"{x:1314,y:854,t:1527267496104};\\\", \\\"{x:1311,y:857,t:1527267496121};\\\", \\\"{x:1310,y:857,t:1527267496138};\\\", \\\"{x:1310,y:858,t:1527267496155};\\\", \\\"{x:1310,y:861,t:1527267496171};\\\", \\\"{x:1310,y:863,t:1527267496188};\\\", \\\"{x:1310,y:867,t:1527267496205};\\\", \\\"{x:1306,y:873,t:1527267496221};\\\", \\\"{x:1305,y:876,t:1527267496238};\\\", \\\"{x:1302,y:878,t:1527267496255};\\\", \\\"{x:1301,y:879,t:1527267496271};\\\", \\\"{x:1299,y:879,t:1527267496305};\\\", \\\"{x:1296,y:878,t:1527267496321};\\\", \\\"{x:1290,y:864,t:1527267496338};\\\", \\\"{x:1283,y:840,t:1527267496355};\\\", \\\"{x:1275,y:810,t:1527267496371};\\\", \\\"{x:1267,y:767,t:1527267496388};\\\", \\\"{x:1265,y:737,t:1527267496405};\\\", \\\"{x:1262,y:715,t:1527267496421};\\\", \\\"{x:1262,y:697,t:1527267496438};\\\", \\\"{x:1262,y:684,t:1527267496455};\\\", \\\"{x:1264,y:673,t:1527267496471};\\\", \\\"{x:1266,y:666,t:1527267496488};\\\", \\\"{x:1270,y:655,t:1527267496505};\\\", \\\"{x:1270,y:649,t:1527267496520};\\\", \\\"{x:1271,y:642,t:1527267496538};\\\", \\\"{x:1272,y:634,t:1527267496554};\\\", \\\"{x:1276,y:625,t:1527267496571};\\\", \\\"{x:1280,y:613,t:1527267496588};\\\", \\\"{x:1285,y:600,t:1527267496604};\\\", \\\"{x:1288,y:591,t:1527267496621};\\\", \\\"{x:1291,y:580,t:1527267496638};\\\", \\\"{x:1294,y:571,t:1527267496654};\\\", \\\"{x:1296,y:565,t:1527267496671};\\\", \\\"{x:1296,y:563,t:1527267496688};\\\", \\\"{x:1297,y:561,t:1527267496704};\\\", \\\"{x:1297,y:560,t:1527267496721};\\\", \\\"{x:1297,y:558,t:1527267496745};\\\", \\\"{x:1297,y:557,t:1527267496754};\\\", \\\"{x:1297,y:555,t:1527267496771};\\\", \\\"{x:1296,y:555,t:1527267496865};\\\", \\\"{x:1295,y:555,t:1527267496873};\\\", \\\"{x:1294,y:555,t:1527267496888};\\\", \\\"{x:1293,y:555,t:1527267496904};\\\", \\\"{x:1291,y:555,t:1527267496921};\\\", \\\"{x:1290,y:555,t:1527267496945};\\\", \\\"{x:1289,y:555,t:1527267496968};\\\", \\\"{x:1288,y:555,t:1527267496992};\\\", \\\"{x:1287,y:556,t:1527267497009};\\\", \\\"{x:1286,y:556,t:1527267497033};\\\", \\\"{x:1285,y:556,t:1527267497049};\\\", \\\"{x:1284,y:556,t:1527267497073};\\\", \\\"{x:1284,y:557,t:1527267497105};\\\", \\\"{x:1283,y:557,t:1527267497129};\\\", \\\"{x:1282,y:557,t:1527267497145};\\\", \\\"{x:1281,y:557,t:1527267497168};\\\", \\\"{x:1280,y:557,t:1527267497184};\\\", \\\"{x:1279,y:558,t:1527267497324};\\\", \\\"{x:1279,y:559,t:1527267497432};\\\", \\\"{x:1279,y:560,t:1527267497440};\\\", \\\"{x:1279,y:561,t:1527267497453};\\\", \\\"{x:1279,y:565,t:1527267497470};\\\", \\\"{x:1279,y:568,t:1527267497487};\\\", \\\"{x:1279,y:574,t:1527267497504};\\\", \\\"{x:1278,y:577,t:1527267497519};\\\", \\\"{x:1278,y:581,t:1527267497536};\\\", \\\"{x:1278,y:585,t:1527267497553};\\\", \\\"{x:1278,y:590,t:1527267497570};\\\", \\\"{x:1278,y:593,t:1527267497586};\\\", \\\"{x:1276,y:596,t:1527267497604};\\\", \\\"{x:1276,y:599,t:1527267497620};\\\", \\\"{x:1276,y:601,t:1527267497637};\\\", \\\"{x:1276,y:602,t:1527267497653};\\\", \\\"{x:1276,y:605,t:1527267497670};\\\", \\\"{x:1276,y:606,t:1527267497687};\\\", \\\"{x:1276,y:608,t:1527267497704};\\\", \\\"{x:1276,y:609,t:1527267497720};\\\", \\\"{x:1276,y:611,t:1527267497737};\\\", \\\"{x:1276,y:612,t:1527267497754};\\\", \\\"{x:1276,y:614,t:1527267497770};\\\", \\\"{x:1276,y:616,t:1527267497787};\\\", \\\"{x:1276,y:618,t:1527267497804};\\\", \\\"{x:1276,y:621,t:1527267497820};\\\", \\\"{x:1276,y:624,t:1527267497837};\\\", \\\"{x:1276,y:626,t:1527267497854};\\\", \\\"{x:1276,y:627,t:1527267497870};\\\", \\\"{x:1276,y:629,t:1527267497887};\\\", \\\"{x:1276,y:631,t:1527267497903};\\\", \\\"{x:1276,y:634,t:1527267497920};\\\", \\\"{x:1276,y:637,t:1527267497937};\\\", \\\"{x:1276,y:639,t:1527267497960};\\\", \\\"{x:1276,y:640,t:1527267497970};\\\", \\\"{x:1276,y:642,t:1527267497987};\\\", \\\"{x:1276,y:645,t:1527267498003};\\\", \\\"{x:1276,y:649,t:1527267498020};\\\", \\\"{x:1276,y:651,t:1527267498037};\\\", \\\"{x:1276,y:654,t:1527267498053};\\\", \\\"{x:1276,y:657,t:1527267498070};\\\", \\\"{x:1277,y:660,t:1527267498087};\\\", \\\"{x:1277,y:663,t:1527267498103};\\\", \\\"{x:1278,y:667,t:1527267498120};\\\", \\\"{x:1279,y:671,t:1527267498137};\\\", \\\"{x:1279,y:674,t:1527267498153};\\\", \\\"{x:1280,y:678,t:1527267498170};\\\", \\\"{x:1280,y:680,t:1527267498187};\\\", \\\"{x:1281,y:684,t:1527267498203};\\\", \\\"{x:1281,y:687,t:1527267498220};\\\", \\\"{x:1281,y:690,t:1527267498237};\\\", \\\"{x:1283,y:694,t:1527267498253};\\\", \\\"{x:1283,y:697,t:1527267498270};\\\", \\\"{x:1283,y:700,t:1527267498287};\\\", \\\"{x:1284,y:702,t:1527267498303};\\\", \\\"{x:1284,y:705,t:1527267498320};\\\", \\\"{x:1284,y:708,t:1527267498337};\\\", \\\"{x:1284,y:711,t:1527267498352};\\\", \\\"{x:1285,y:714,t:1527267498369};\\\", \\\"{x:1285,y:717,t:1527267498386};\\\", \\\"{x:1285,y:719,t:1527267498402};\\\", \\\"{x:1285,y:723,t:1527267498419};\\\", \\\"{x:1285,y:725,t:1527267498435};\\\", \\\"{x:1285,y:728,t:1527267498453};\\\", \\\"{x:1285,y:729,t:1527267498470};\\\", \\\"{x:1286,y:730,t:1527267498485};\\\", \\\"{x:1286,y:732,t:1527267498502};\\\", \\\"{x:1287,y:735,t:1527267498519};\\\", \\\"{x:1287,y:737,t:1527267498536};\\\", \\\"{x:1288,y:738,t:1527267498553};\\\", \\\"{x:1288,y:740,t:1527267498570};\\\", \\\"{x:1288,y:742,t:1527267498585};\\\", \\\"{x:1288,y:744,t:1527267498603};\\\", \\\"{x:1289,y:745,t:1527267498619};\\\", \\\"{x:1290,y:747,t:1527267498635};\\\", \\\"{x:1290,y:751,t:1527267498653};\\\", \\\"{x:1290,y:753,t:1527267498670};\\\", \\\"{x:1291,y:755,t:1527267498686};\\\", \\\"{x:1291,y:757,t:1527267498703};\\\", \\\"{x:1291,y:760,t:1527267498720};\\\", \\\"{x:1293,y:763,t:1527267498737};\\\", \\\"{x:1293,y:767,t:1527267498752};\\\", \\\"{x:1293,y:770,t:1527267498770};\\\", \\\"{x:1293,y:772,t:1527267498786};\\\", \\\"{x:1293,y:774,t:1527267498803};\\\", \\\"{x:1293,y:777,t:1527267498819};\\\", \\\"{x:1293,y:780,t:1527267498835};\\\", \\\"{x:1293,y:783,t:1527267498853};\\\", \\\"{x:1293,y:786,t:1527267498869};\\\", \\\"{x:1293,y:790,t:1527267498886};\\\", \\\"{x:1293,y:794,t:1527267498903};\\\", \\\"{x:1293,y:797,t:1527267498919};\\\", \\\"{x:1293,y:802,t:1527267498936};\\\", \\\"{x:1293,y:807,t:1527267498952};\\\", \\\"{x:1293,y:811,t:1527267498969};\\\", \\\"{x:1294,y:817,t:1527267498986};\\\", \\\"{x:1294,y:824,t:1527267499003};\\\", \\\"{x:1294,y:828,t:1527267499019};\\\", \\\"{x:1294,y:834,t:1527267499036};\\\", \\\"{x:1294,y:838,t:1527267499053};\\\", \\\"{x:1294,y:842,t:1527267499069};\\\", \\\"{x:1294,y:844,t:1527267499086};\\\", \\\"{x:1294,y:848,t:1527267499104};\\\", \\\"{x:1294,y:850,t:1527267499119};\\\", \\\"{x:1294,y:854,t:1527267499136};\\\", \\\"{x:1294,y:858,t:1527267499152};\\\", \\\"{x:1294,y:859,t:1527267499169};\\\", \\\"{x:1294,y:863,t:1527267499186};\\\", \\\"{x:1294,y:866,t:1527267499203};\\\", \\\"{x:1294,y:872,t:1527267499219};\\\", \\\"{x:1295,y:876,t:1527267499236};\\\", \\\"{x:1295,y:880,t:1527267499252};\\\", \\\"{x:1297,y:884,t:1527267499269};\\\", \\\"{x:1297,y:889,t:1527267499286};\\\", \\\"{x:1297,y:894,t:1527267499303};\\\", \\\"{x:1298,y:900,t:1527267499319};\\\", \\\"{x:1298,y:905,t:1527267499336};\\\", \\\"{x:1298,y:907,t:1527267499353};\\\", \\\"{x:1298,y:909,t:1527267499369};\\\", \\\"{x:1299,y:911,t:1527267499386};\\\", \\\"{x:1299,y:913,t:1527267499403};\\\", \\\"{x:1300,y:917,t:1527267499419};\\\", \\\"{x:1301,y:919,t:1527267499436};\\\", \\\"{x:1302,y:920,t:1527267499452};\\\", \\\"{x:1303,y:922,t:1527267499469};\\\", \\\"{x:1304,y:923,t:1527267499485};\\\", \\\"{x:1305,y:924,t:1527267499502};\\\", \\\"{x:1305,y:927,t:1527267499519};\\\", \\\"{x:1307,y:931,t:1527267499535};\\\", \\\"{x:1308,y:932,t:1527267499552};\\\", \\\"{x:1308,y:934,t:1527267499568};\\\", \\\"{x:1309,y:936,t:1527267499585};\\\", \\\"{x:1309,y:940,t:1527267499602};\\\", \\\"{x:1309,y:942,t:1527267499618};\\\", \\\"{x:1309,y:945,t:1527267499635};\\\", \\\"{x:1309,y:947,t:1527267499651};\\\", \\\"{x:1309,y:950,t:1527267499668};\\\", \\\"{x:1309,y:952,t:1527267499686};\\\", \\\"{x:1309,y:953,t:1527267499702};\\\", \\\"{x:1302,y:953,t:1527267502320};\\\", \\\"{x:1283,y:953,t:1527267502332};\\\", \\\"{x:1230,y:952,t:1527267502349};\\\", \\\"{x:1102,y:933,t:1527267502366};\\\", \\\"{x:876,y:900,t:1527267502384};\\\", \\\"{x:740,y:879,t:1527267502399};\\\", \\\"{x:596,y:858,t:1527267502416};\\\", \\\"{x:456,y:819,t:1527267502433};\\\", \\\"{x:348,y:773,t:1527267502449};\\\", \\\"{x:277,y:735,t:1527267502466};\\\", \\\"{x:250,y:706,t:1527267502482};\\\", \\\"{x:239,y:686,t:1527267502500};\\\", \\\"{x:235,y:674,t:1527267502516};\\\", \\\"{x:234,y:669,t:1527267502534};\\\", \\\"{x:232,y:663,t:1527267502549};\\\", \\\"{x:231,y:660,t:1527267502566};\\\", \\\"{x:227,y:655,t:1527267502583};\\\", \\\"{x:223,y:651,t:1527267502599};\\\", \\\"{x:220,y:649,t:1527267502616};\\\", \\\"{x:221,y:649,t:1527267502712};\\\", \\\"{x:226,y:649,t:1527267502719};\\\", \\\"{x:236,y:650,t:1527267502733};\\\", \\\"{x:259,y:655,t:1527267502749};\\\", \\\"{x:291,y:664,t:1527267502767};\\\", \\\"{x:337,y:679,t:1527267502784};\\\", \\\"{x:365,y:686,t:1527267502800};\\\", \\\"{x:389,y:696,t:1527267502817};\\\", \\\"{x:410,y:699,t:1527267502833};\\\", \\\"{x:419,y:702,t:1527267502849};\\\", \\\"{x:422,y:702,t:1527267502867};\\\", \\\"{x:427,y:702,t:1527267502883};\\\", \\\"{x:433,y:702,t:1527267502900};\\\", \\\"{x:436,y:701,t:1527267502916};\\\", \\\"{x:438,y:701,t:1527267502934};\\\", \\\"{x:439,y:701,t:1527267502949};\\\", \\\"{x:440,y:701,t:1527267502967};\\\", \\\"{x:449,y:704,t:1527267502983};\\\", \\\"{x:455,y:708,t:1527267502999};\\\", \\\"{x:459,y:712,t:1527267503017};\\\", \\\"{x:464,y:716,t:1527267503034};\\\", \\\"{x:469,y:720,t:1527267503051};\\\", \\\"{x:473,y:722,t:1527267503067};\\\", \\\"{x:474,y:722,t:1527267503082};\\\", \\\"{x:476,y:723,t:1527267503099};\\\", \\\"{x:481,y:723,t:1527267503569};\\\", \\\"{x:514,y:699,t:1527267503584};\\\", \\\"{x:572,y:665,t:1527267503600};\\\", \\\"{x:630,y:626,t:1527267503617};\\\", \\\"{x:691,y:590,t:1527267503634};\\\", \\\"{x:753,y:555,t:1527267503650};\\\", \\\"{x:798,y:533,t:1527267503666};\\\", \\\"{x:822,y:518,t:1527267503684};\\\", \\\"{x:826,y:515,t:1527267503701};\\\" ] }, { \\\"rt\\\": 63960, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 538293, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -G -M -01 PM-02 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:825,y:515,t:1527267505208};\\\", \\\"{x:804,y:515,t:1527267505218};\\\", \\\"{x:731,y:519,t:1527267505234};\\\", \\\"{x:659,y:519,t:1527267505252};\\\", \\\"{x:613,y:517,t:1527267505268};\\\", \\\"{x:554,y:502,t:1527267505285};\\\", \\\"{x:520,y:490,t:1527267505302};\\\", \\\"{x:509,y:482,t:1527267505318};\\\", \\\"{x:504,y:476,t:1527267505334};\\\", \\\"{x:499,y:468,t:1527267505352};\\\", \\\"{x:497,y:466,t:1527267505369};\\\", \\\"{x:496,y:463,t:1527267505385};\\\", \\\"{x:492,y:459,t:1527267505402};\\\", \\\"{x:482,y:454,t:1527267505419};\\\", \\\"{x:472,y:451,t:1527267505435};\\\", \\\"{x:462,y:448,t:1527267505452};\\\", \\\"{x:450,y:444,t:1527267505468};\\\", \\\"{x:426,y:441,t:1527267505485};\\\", \\\"{x:402,y:439,t:1527267505502};\\\", \\\"{x:380,y:439,t:1527267505518};\\\", \\\"{x:366,y:439,t:1527267505535};\\\", \\\"{x:350,y:439,t:1527267505552};\\\", \\\"{x:345,y:439,t:1527267505569};\\\", \\\"{x:343,y:439,t:1527267505586};\\\", \\\"{x:341,y:439,t:1527267505601};\\\", \\\"{x:339,y:439,t:1527267505618};\\\", \\\"{x:338,y:440,t:1527267505656};\\\", \\\"{x:342,y:440,t:1527267505745};\\\", \\\"{x:347,y:440,t:1527267505752};\\\", \\\"{x:360,y:440,t:1527267505769};\\\", \\\"{x:382,y:440,t:1527267505786};\\\", \\\"{x:411,y:440,t:1527267505802};\\\", \\\"{x:447,y:440,t:1527267505819};\\\", \\\"{x:490,y:440,t:1527267505836};\\\", \\\"{x:519,y:440,t:1527267505852};\\\", \\\"{x:544,y:440,t:1527267505868};\\\", \\\"{x:561,y:440,t:1527267505886};\\\", \\\"{x:569,y:440,t:1527267505901};\\\", \\\"{x:570,y:440,t:1527267505919};\\\", \\\"{x:571,y:440,t:1527267505936};\\\", \\\"{x:572,y:440,t:1527267505952};\\\", \\\"{x:573,y:439,t:1527267505977};\\\", \\\"{x:575,y:439,t:1527267505986};\\\", \\\"{x:581,y:439,t:1527267506003};\\\", \\\"{x:590,y:438,t:1527267506019};\\\", \\\"{x:598,y:438,t:1527267506036};\\\", \\\"{x:607,y:438,t:1527267506053};\\\", \\\"{x:613,y:438,t:1527267506068};\\\", \\\"{x:617,y:438,t:1527267506086};\\\", \\\"{x:623,y:438,t:1527267506103};\\\", \\\"{x:628,y:438,t:1527267506119};\\\", \\\"{x:633,y:440,t:1527267506136};\\\", \\\"{x:635,y:441,t:1527267506153};\\\", \\\"{x:640,y:442,t:1527267506169};\\\", \\\"{x:645,y:443,t:1527267506186};\\\", \\\"{x:650,y:445,t:1527267506203};\\\", \\\"{x:654,y:446,t:1527267506218};\\\", \\\"{x:657,y:448,t:1527267506236};\\\", \\\"{x:658,y:449,t:1527267506264};\\\", \\\"{x:658,y:450,t:1527267506281};\\\", \\\"{x:658,y:453,t:1527267506288};\\\", \\\"{x:658,y:454,t:1527267506303};\\\", \\\"{x:652,y:456,t:1527267506319};\\\", \\\"{x:627,y:463,t:1527267506337};\\\", \\\"{x:592,y:467,t:1527267506352};\\\", \\\"{x:560,y:472,t:1527267506369};\\\", \\\"{x:527,y:477,t:1527267506387};\\\", \\\"{x:499,y:479,t:1527267506404};\\\", \\\"{x:476,y:479,t:1527267506419};\\\", \\\"{x:461,y:479,t:1527267506436};\\\", \\\"{x:452,y:482,t:1527267506453};\\\", \\\"{x:447,y:482,t:1527267506469};\\\", \\\"{x:442,y:483,t:1527267506486};\\\", \\\"{x:431,y:486,t:1527267506503};\\\", \\\"{x:413,y:488,t:1527267506519};\\\", \\\"{x:404,y:490,t:1527267506536};\\\", \\\"{x:394,y:491,t:1527267506552};\\\", \\\"{x:387,y:491,t:1527267506570};\\\", \\\"{x:383,y:491,t:1527267506585};\\\", \\\"{x:384,y:491,t:1527267506696};\\\", \\\"{x:388,y:491,t:1527267506704};\\\", \\\"{x:403,y:491,t:1527267506720};\\\", \\\"{x:424,y:490,t:1527267506736};\\\", \\\"{x:447,y:489,t:1527267506753};\\\", \\\"{x:473,y:489,t:1527267506770};\\\", \\\"{x:493,y:489,t:1527267506785};\\\", \\\"{x:504,y:489,t:1527267506803};\\\", \\\"{x:508,y:489,t:1527267506820};\\\", \\\"{x:510,y:489,t:1527267506836};\\\", \\\"{x:511,y:489,t:1527267506853};\\\", \\\"{x:513,y:489,t:1527267506913};\\\", \\\"{x:514,y:489,t:1527267506920};\\\", \\\"{x:517,y:489,t:1527267506937};\\\", \\\"{x:521,y:489,t:1527267506954};\\\", \\\"{x:528,y:489,t:1527267506970};\\\", \\\"{x:538,y:489,t:1527267506986};\\\", \\\"{x:546,y:489,t:1527267507003};\\\", \\\"{x:556,y:489,t:1527267507020};\\\", \\\"{x:563,y:489,t:1527267507036};\\\", \\\"{x:569,y:489,t:1527267507053};\\\", \\\"{x:574,y:489,t:1527267507070};\\\", \\\"{x:575,y:489,t:1527267507088};\\\", \\\"{x:577,y:488,t:1527267507271};\\\", \\\"{x:580,y:488,t:1527267507286};\\\", \\\"{x:589,y:486,t:1527267507303};\\\", \\\"{x:602,y:485,t:1527267507319};\\\", \\\"{x:603,y:485,t:1527267507337};\\\", \\\"{x:605,y:485,t:1527267507352};\\\", \\\"{x:605,y:484,t:1527267508984};\\\", \\\"{x:610,y:485,t:1527267509827};\\\", \\\"{x:614,y:486,t:1527267509841};\\\", \\\"{x:619,y:486,t:1527267509858};\\\", \\\"{x:626,y:489,t:1527267509875};\\\", \\\"{x:629,y:490,t:1527267509891};\\\", \\\"{x:630,y:490,t:1527267509908};\\\", \\\"{x:631,y:491,t:1527267509925};\\\", \\\"{x:632,y:491,t:1527267509942};\\\", \\\"{x:632,y:492,t:1527267510075};\\\", \\\"{x:638,y:497,t:1527267510092};\\\", \\\"{x:654,y:509,t:1527267510109};\\\", \\\"{x:693,y:531,t:1527267510125};\\\", \\\"{x:746,y:557,t:1527267510142};\\\", \\\"{x:801,y:581,t:1527267510159};\\\", \\\"{x:873,y:610,t:1527267510175};\\\", \\\"{x:969,y:650,t:1527267510192};\\\", \\\"{x:1041,y:683,t:1527267510208};\\\", \\\"{x:1094,y:708,t:1527267510225};\\\", \\\"{x:1128,y:723,t:1527267510242};\\\", \\\"{x:1165,y:742,t:1527267510257};\\\", \\\"{x:1182,y:753,t:1527267510274};\\\", \\\"{x:1191,y:760,t:1527267510292};\\\", \\\"{x:1199,y:767,t:1527267510308};\\\", \\\"{x:1204,y:771,t:1527267510324};\\\", \\\"{x:1212,y:775,t:1527267510342};\\\", \\\"{x:1219,y:780,t:1527267510359};\\\", \\\"{x:1234,y:788,t:1527267510375};\\\", \\\"{x:1253,y:802,t:1527267510391};\\\", \\\"{x:1275,y:816,t:1527267510408};\\\", \\\"{x:1285,y:823,t:1527267510424};\\\", \\\"{x:1290,y:828,t:1527267510442};\\\", \\\"{x:1312,y:849,t:1527267510458};\\\", \\\"{x:1326,y:867,t:1527267510476};\\\", \\\"{x:1337,y:878,t:1527267510491};\\\", \\\"{x:1344,y:888,t:1527267510508};\\\", \\\"{x:1350,y:897,t:1527267510526};\\\", \\\"{x:1355,y:907,t:1527267510541};\\\", \\\"{x:1357,y:911,t:1527267510559};\\\", \\\"{x:1359,y:916,t:1527267510576};\\\", \\\"{x:1360,y:917,t:1527267510603};\\\", \\\"{x:1360,y:918,t:1527267510619};\\\", \\\"{x:1362,y:919,t:1527267510635};\\\", \\\"{x:1363,y:919,t:1527267510642};\\\", \\\"{x:1368,y:921,t:1527267510659};\\\", \\\"{x:1371,y:922,t:1527267510676};\\\", \\\"{x:1374,y:922,t:1527267510692};\\\", \\\"{x:1377,y:923,t:1527267510709};\\\", \\\"{x:1380,y:926,t:1527267510727};\\\", \\\"{x:1386,y:929,t:1527267510742};\\\", \\\"{x:1395,y:933,t:1527267510759};\\\", \\\"{x:1403,y:936,t:1527267510776};\\\", \\\"{x:1411,y:940,t:1527267510792};\\\", \\\"{x:1418,y:942,t:1527267510809};\\\", \\\"{x:1430,y:948,t:1527267510826};\\\", \\\"{x:1455,y:960,t:1527267510842};\\\", \\\"{x:1465,y:964,t:1527267510860};\\\", \\\"{x:1473,y:966,t:1527267510877};\\\", \\\"{x:1478,y:968,t:1527267510893};\\\", \\\"{x:1483,y:972,t:1527267510909};\\\", \\\"{x:1484,y:973,t:1527267510926};\\\", \\\"{x:1485,y:973,t:1527267511043};\\\", \\\"{x:1485,y:971,t:1527267511187};\\\", \\\"{x:1484,y:968,t:1527267511196};\\\", \\\"{x:1484,y:967,t:1527267511209};\\\", \\\"{x:1482,y:964,t:1527267511227};\\\", \\\"{x:1480,y:962,t:1527267511243};\\\", \\\"{x:1479,y:961,t:1527267511260};\\\", \\\"{x:1478,y:960,t:1527267511276};\\\", \\\"{x:1477,y:959,t:1527267511293};\\\", \\\"{x:1477,y:958,t:1527267511323};\\\", \\\"{x:1476,y:958,t:1527267511348};\\\", \\\"{x:1476,y:957,t:1527267511363};\\\", \\\"{x:1476,y:956,t:1527267511376};\\\", \\\"{x:1475,y:952,t:1527267511393};\\\", \\\"{x:1475,y:949,t:1527267511411};\\\", \\\"{x:1475,y:945,t:1527267511425};\\\", \\\"{x:1475,y:942,t:1527267511442};\\\", \\\"{x:1476,y:938,t:1527267511460};\\\", \\\"{x:1476,y:935,t:1527267511476};\\\", \\\"{x:1477,y:931,t:1527267511493};\\\", \\\"{x:1479,y:926,t:1527267511510};\\\", \\\"{x:1479,y:920,t:1527267511526};\\\", \\\"{x:1480,y:917,t:1527267511542};\\\", \\\"{x:1480,y:913,t:1527267511560};\\\", \\\"{x:1480,y:909,t:1527267511576};\\\", \\\"{x:1480,y:905,t:1527267511593};\\\", \\\"{x:1480,y:902,t:1527267511609};\\\", \\\"{x:1480,y:897,t:1527267511626};\\\", \\\"{x:1479,y:892,t:1527267511642};\\\", \\\"{x:1479,y:889,t:1527267511660};\\\", \\\"{x:1479,y:886,t:1527267511677};\\\", \\\"{x:1479,y:884,t:1527267511693};\\\", \\\"{x:1479,y:880,t:1527267511710};\\\", \\\"{x:1477,y:876,t:1527267511726};\\\", \\\"{x:1476,y:872,t:1527267511743};\\\", \\\"{x:1476,y:870,t:1527267511760};\\\", \\\"{x:1476,y:868,t:1527267511777};\\\", \\\"{x:1476,y:867,t:1527267511793};\\\", \\\"{x:1476,y:865,t:1527267511810};\\\", \\\"{x:1475,y:862,t:1527267511827};\\\", \\\"{x:1475,y:861,t:1527267511851};\\\", \\\"{x:1475,y:860,t:1527267511861};\\\", \\\"{x:1475,y:859,t:1527267511877};\\\", \\\"{x:1475,y:857,t:1527267511893};\\\", \\\"{x:1475,y:855,t:1527267511910};\\\", \\\"{x:1475,y:853,t:1527267511927};\\\", \\\"{x:1475,y:851,t:1527267511943};\\\", \\\"{x:1475,y:849,t:1527267511960};\\\", \\\"{x:1475,y:847,t:1527267511979};\\\", \\\"{x:1475,y:846,t:1527267511993};\\\", \\\"{x:1475,y:843,t:1527267512010};\\\", \\\"{x:1475,y:840,t:1527267512026};\\\", \\\"{x:1475,y:838,t:1527267512043};\\\", \\\"{x:1476,y:836,t:1527267512060};\\\", \\\"{x:1476,y:835,t:1527267512083};\\\", \\\"{x:1476,y:834,t:1527267512099};\\\", \\\"{x:1476,y:833,t:1527267512130};\\\", \\\"{x:1476,y:831,t:1527267512165};\\\", \\\"{x:1476,y:830,t:1527267512193};\\\", \\\"{x:1476,y:828,t:1527267512218};\\\", \\\"{x:1476,y:827,t:1527267512226};\\\", \\\"{x:1475,y:826,t:1527267512395};\\\", \\\"{x:1475,y:823,t:1527267513508};\\\", \\\"{x:1474,y:821,t:1527267513515};\\\", \\\"{x:1474,y:819,t:1527267513528};\\\", \\\"{x:1473,y:815,t:1527267513545};\\\", \\\"{x:1472,y:810,t:1527267513561};\\\", \\\"{x:1472,y:808,t:1527267513579};\\\", \\\"{x:1472,y:804,t:1527267513594};\\\", \\\"{x:1472,y:800,t:1527267513612};\\\", \\\"{x:1472,y:795,t:1527267513628};\\\", \\\"{x:1472,y:792,t:1527267513645};\\\", \\\"{x:1472,y:789,t:1527267513662};\\\", \\\"{x:1472,y:788,t:1527267513678};\\\", \\\"{x:1472,y:786,t:1527267513696};\\\", \\\"{x:1472,y:784,t:1527267513711};\\\", \\\"{x:1471,y:781,t:1527267513728};\\\", \\\"{x:1471,y:778,t:1527267513745};\\\", \\\"{x:1469,y:774,t:1527267513761};\\\", \\\"{x:1468,y:770,t:1527267513778};\\\", \\\"{x:1468,y:768,t:1527267513795};\\\", \\\"{x:1467,y:766,t:1527267513812};\\\", \\\"{x:1467,y:765,t:1527267513828};\\\", \\\"{x:1466,y:764,t:1527267513845};\\\", \\\"{x:1465,y:763,t:1527267513907};\\\", \\\"{x:1465,y:762,t:1527267513924};\\\", \\\"{x:1464,y:761,t:1527267515476};\\\", \\\"{x:1463,y:761,t:1527267515483};\\\", \\\"{x:1462,y:761,t:1527267515496};\\\", \\\"{x:1461,y:761,t:1527267515513};\\\", \\\"{x:1459,y:761,t:1527267515529};\\\", \\\"{x:1458,y:761,t:1527267525371};\\\", \\\"{x:1454,y:758,t:1527267525387};\\\", \\\"{x:1452,y:756,t:1527267525405};\\\", \\\"{x:1450,y:739,t:1527267525421};\\\", \\\"{x:1450,y:729,t:1527267525438};\\\", \\\"{x:1449,y:717,t:1527267525455};\\\", \\\"{x:1449,y:703,t:1527267525471};\\\", \\\"{x:1449,y:698,t:1527267525487};\\\", \\\"{x:1449,y:694,t:1527267525505};\\\", \\\"{x:1449,y:692,t:1527267525520};\\\", \\\"{x:1449,y:691,t:1527267525538};\\\", \\\"{x:1449,y:689,t:1527267525555};\\\", \\\"{x:1449,y:688,t:1527267525579};\\\", \\\"{x:1449,y:687,t:1527267525588};\\\", \\\"{x:1449,y:686,t:1527267525605};\\\", \\\"{x:1449,y:685,t:1527267526075};\\\", \\\"{x:1449,y:686,t:1527267526298};\\\", \\\"{x:1449,y:688,t:1527267526314};\\\", \\\"{x:1449,y:689,t:1527267526323};\\\", \\\"{x:1452,y:692,t:1527267526339};\\\", \\\"{x:1453,y:696,t:1527267526354};\\\", \\\"{x:1454,y:698,t:1527267526372};\\\", \\\"{x:1455,y:700,t:1527267526389};\\\", \\\"{x:1455,y:701,t:1527267526410};\\\", \\\"{x:1456,y:701,t:1527267526515};\\\", \\\"{x:1456,y:699,t:1527267527587};\\\", \\\"{x:1456,y:695,t:1527267527595};\\\", \\\"{x:1456,y:690,t:1527267527606};\\\", \\\"{x:1456,y:683,t:1527267527622};\\\", \\\"{x:1456,y:678,t:1527267527640};\\\", \\\"{x:1456,y:674,t:1527267527656};\\\", \\\"{x:1456,y:673,t:1527267527673};\\\", \\\"{x:1457,y:671,t:1527267527690};\\\", \\\"{x:1458,y:670,t:1527267527706};\\\", \\\"{x:1459,y:668,t:1527267527723};\\\", \\\"{x:1459,y:666,t:1527267527739};\\\", \\\"{x:1461,y:662,t:1527267527756};\\\", \\\"{x:1461,y:661,t:1527267527773};\\\", \\\"{x:1461,y:658,t:1527267527790};\\\", \\\"{x:1461,y:655,t:1527267527806};\\\", \\\"{x:1461,y:652,t:1527267527823};\\\", \\\"{x:1461,y:650,t:1527267527840};\\\", \\\"{x:1461,y:646,t:1527267527856};\\\", \\\"{x:1461,y:644,t:1527267527873};\\\", \\\"{x:1461,y:642,t:1527267527890};\\\", \\\"{x:1461,y:640,t:1527267527906};\\\", \\\"{x:1461,y:636,t:1527267527923};\\\", \\\"{x:1461,y:633,t:1527267527940};\\\", \\\"{x:1461,y:632,t:1527267527956};\\\", \\\"{x:1461,y:629,t:1527267527973};\\\", \\\"{x:1461,y:627,t:1527267527990};\\\", \\\"{x:1460,y:625,t:1527267528007};\\\", \\\"{x:1460,y:623,t:1527267528023};\\\", \\\"{x:1459,y:621,t:1527267528040};\\\", \\\"{x:1459,y:619,t:1527267528057};\\\", \\\"{x:1458,y:618,t:1527267528072};\\\", \\\"{x:1458,y:617,t:1527267528090};\\\", \\\"{x:1457,y:613,t:1527267528107};\\\", \\\"{x:1457,y:612,t:1527267528123};\\\", \\\"{x:1455,y:610,t:1527267528140};\\\", \\\"{x:1455,y:609,t:1527267528157};\\\", \\\"{x:1454,y:608,t:1527267528173};\\\", \\\"{x:1453,y:606,t:1527267528190};\\\", \\\"{x:1452,y:603,t:1527267528207};\\\", \\\"{x:1451,y:600,t:1527267528223};\\\", \\\"{x:1450,y:597,t:1527267528240};\\\", \\\"{x:1449,y:595,t:1527267528258};\\\", \\\"{x:1448,y:594,t:1527267528283};\\\", \\\"{x:1447,y:593,t:1527267528290};\\\", \\\"{x:1447,y:591,t:1527267528307};\\\", \\\"{x:1446,y:590,t:1527267528323};\\\", \\\"{x:1446,y:589,t:1527267528340};\\\", \\\"{x:1446,y:587,t:1527267528356};\\\", \\\"{x:1445,y:586,t:1527267528372};\\\", \\\"{x:1445,y:585,t:1527267528389};\\\", \\\"{x:1445,y:584,t:1527267528406};\\\", \\\"{x:1445,y:583,t:1527267528424};\\\", \\\"{x:1445,y:581,t:1527267528440};\\\", \\\"{x:1445,y:580,t:1527267528457};\\\", \\\"{x:1445,y:578,t:1527267528473};\\\", \\\"{x:1444,y:577,t:1527267528489};\\\", \\\"{x:1444,y:575,t:1527267528538};\\\", \\\"{x:1444,y:574,t:1527267528563};\\\", \\\"{x:1444,y:572,t:1527267528587};\\\", \\\"{x:1444,y:571,t:1527267528595};\\\", \\\"{x:1443,y:570,t:1527267528607};\\\", \\\"{x:1443,y:569,t:1527267528624};\\\", \\\"{x:1443,y:568,t:1527267528651};\\\", \\\"{x:1442,y:567,t:1527267528658};\\\", \\\"{x:1442,y:566,t:1527267528674};\\\", \\\"{x:1442,y:565,t:1527267528715};\\\", \\\"{x:1442,y:564,t:1527267528739};\\\", \\\"{x:1442,y:563,t:1527267528757};\\\", \\\"{x:1442,y:562,t:1527267528787};\\\", \\\"{x:1442,y:561,t:1527267528803};\\\", \\\"{x:1442,y:560,t:1527267528827};\\\", \\\"{x:1441,y:560,t:1527267529203};\\\", \\\"{x:1440,y:560,t:1527267529219};\\\", \\\"{x:1438,y:560,t:1527267529227};\\\", \\\"{x:1437,y:561,t:1527267529241};\\\", \\\"{x:1433,y:563,t:1527267529258};\\\", \\\"{x:1429,y:567,t:1527267529274};\\\", \\\"{x:1416,y:580,t:1527267529291};\\\", \\\"{x:1404,y:593,t:1527267529307};\\\", \\\"{x:1383,y:609,t:1527267529324};\\\", \\\"{x:1319,y:632,t:1527267529341};\\\", \\\"{x:1229,y:651,t:1527267529357};\\\", \\\"{x:1123,y:665,t:1527267529374};\\\", \\\"{x:1005,y:675,t:1527267529391};\\\", \\\"{x:875,y:675,t:1527267529408};\\\", \\\"{x:764,y:675,t:1527267529423};\\\", \\\"{x:673,y:675,t:1527267529441};\\\", \\\"{x:592,y:675,t:1527267529457};\\\", \\\"{x:523,y:669,t:1527267529474};\\\", \\\"{x:468,y:657,t:1527267529491};\\\", \\\"{x:456,y:652,t:1527267529509};\\\", \\\"{x:453,y:649,t:1527267529523};\\\", \\\"{x:451,y:649,t:1527267529540};\\\", \\\"{x:442,y:645,t:1527267529558};\\\", \\\"{x:426,y:643,t:1527267529574};\\\", \\\"{x:406,y:640,t:1527267529591};\\\", \\\"{x:398,y:637,t:1527267529607};\\\", \\\"{x:394,y:635,t:1527267529624};\\\", \\\"{x:392,y:633,t:1527267529640};\\\", \\\"{x:389,y:629,t:1527267529657};\\\", \\\"{x:387,y:622,t:1527267529674};\\\", \\\"{x:387,y:618,t:1527267529690};\\\", \\\"{x:387,y:614,t:1527267529708};\\\", \\\"{x:389,y:612,t:1527267529724};\\\", \\\"{x:393,y:609,t:1527267529740};\\\", \\\"{x:396,y:607,t:1527267529758};\\\", \\\"{x:398,y:606,t:1527267529773};\\\", \\\"{x:400,y:605,t:1527267529790};\\\", \\\"{x:401,y:605,t:1527267529851};\\\", \\\"{x:401,y:611,t:1527267530268};\\\", \\\"{x:394,y:620,t:1527267530275};\\\", \\\"{x:383,y:635,t:1527267530291};\\\", \\\"{x:370,y:647,t:1527267530308};\\\", \\\"{x:355,y:656,t:1527267530324};\\\", \\\"{x:339,y:665,t:1527267530341};\\\", \\\"{x:323,y:669,t:1527267530357};\\\", \\\"{x:306,y:671,t:1527267530374};\\\", \\\"{x:290,y:671,t:1527267530391};\\\", \\\"{x:279,y:671,t:1527267530408};\\\", \\\"{x:267,y:671,t:1527267530425};\\\", \\\"{x:251,y:668,t:1527267530442};\\\", \\\"{x:208,y:654,t:1527267530457};\\\", \\\"{x:170,y:645,t:1527267530476};\\\", \\\"{x:145,y:643,t:1527267530491};\\\", \\\"{x:143,y:642,t:1527267530508};\\\", \\\"{x:142,y:642,t:1527267530524};\\\", \\\"{x:141,y:640,t:1527267530541};\\\", \\\"{x:141,y:636,t:1527267530559};\\\", \\\"{x:144,y:631,t:1527267530574};\\\", \\\"{x:146,y:628,t:1527267530592};\\\", \\\"{x:149,y:625,t:1527267530609};\\\", \\\"{x:150,y:621,t:1527267530624};\\\", \\\"{x:152,y:618,t:1527267530642};\\\", \\\"{x:154,y:613,t:1527267530658};\\\", \\\"{x:157,y:608,t:1527267530675};\\\", \\\"{x:160,y:603,t:1527267530692};\\\", \\\"{x:163,y:600,t:1527267530708};\\\", \\\"{x:164,y:597,t:1527267530724};\\\", \\\"{x:166,y:594,t:1527267530741};\\\", \\\"{x:167,y:592,t:1527267530758};\\\", \\\"{x:168,y:590,t:1527267530775};\\\", \\\"{x:168,y:589,t:1527267530791};\\\", \\\"{x:168,y:588,t:1527267530808};\\\", \\\"{x:168,y:587,t:1527267530825};\\\", \\\"{x:169,y:586,t:1527267530948};\\\", \\\"{x:173,y:586,t:1527267530958};\\\", \\\"{x:187,y:586,t:1527267530976};\\\", \\\"{x:206,y:586,t:1527267530993};\\\", \\\"{x:234,y:586,t:1527267531009};\\\", \\\"{x:268,y:586,t:1527267531025};\\\", \\\"{x:312,y:586,t:1527267531042};\\\", \\\"{x:358,y:586,t:1527267531058};\\\", \\\"{x:379,y:586,t:1527267531075};\\\", \\\"{x:394,y:586,t:1527267531091};\\\", \\\"{x:404,y:586,t:1527267531109};\\\", \\\"{x:407,y:586,t:1527267531125};\\\", \\\"{x:411,y:585,t:1527267531141};\\\", \\\"{x:412,y:585,t:1527267531159};\\\", \\\"{x:414,y:585,t:1527267531176};\\\", \\\"{x:415,y:585,t:1527267531202};\\\", \\\"{x:416,y:585,t:1527267531210};\\\", \\\"{x:418,y:585,t:1527267531226};\\\", \\\"{x:424,y:585,t:1527267531242};\\\", \\\"{x:425,y:585,t:1527267531258};\\\", \\\"{x:426,y:585,t:1527267531275};\\\", \\\"{x:428,y:585,t:1527267532275};\\\", \\\"{x:425,y:582,t:1527267532282};\\\", \\\"{x:415,y:578,t:1527267532293};\\\", \\\"{x:402,y:569,t:1527267532311};\\\", \\\"{x:398,y:565,t:1527267532326};\\\", \\\"{x:396,y:564,t:1527267532342};\\\", \\\"{x:396,y:563,t:1527267532378};\\\", \\\"{x:396,y:562,t:1527267532392};\\\", \\\"{x:414,y:559,t:1527267532409};\\\", \\\"{x:432,y:556,t:1527267532426};\\\", \\\"{x:454,y:552,t:1527267532442};\\\", \\\"{x:477,y:550,t:1527267532459};\\\", \\\"{x:498,y:550,t:1527267532477};\\\", \\\"{x:522,y:550,t:1527267532493};\\\", \\\"{x:544,y:550,t:1527267532509};\\\", \\\"{x:560,y:549,t:1527267532527};\\\", \\\"{x:570,y:548,t:1527267532544};\\\", \\\"{x:575,y:547,t:1527267532559};\\\", \\\"{x:578,y:545,t:1527267532576};\\\", \\\"{x:588,y:540,t:1527267532594};\\\", \\\"{x:593,y:537,t:1527267532610};\\\", \\\"{x:597,y:533,t:1527267532627};\\\", \\\"{x:598,y:531,t:1527267532644};\\\", \\\"{x:600,y:530,t:1527267532660};\\\", \\\"{x:602,y:526,t:1527267532676};\\\", \\\"{x:607,y:524,t:1527267532693};\\\", \\\"{x:608,y:524,t:1527267532709};\\\", \\\"{x:608,y:523,t:1527267532747};\\\", \\\"{x:608,y:522,t:1527267532760};\\\", \\\"{x:610,y:520,t:1527267532777};\\\", \\\"{x:611,y:519,t:1527267532794};\\\", \\\"{x:612,y:519,t:1527267533138};\\\", \\\"{x:614,y:519,t:1527267533162};\\\", \\\"{x:618,y:519,t:1527267533177};\\\", \\\"{x:633,y:521,t:1527267533194};\\\", \\\"{x:685,y:526,t:1527267533210};\\\", \\\"{x:754,y:526,t:1527267533228};\\\", \\\"{x:851,y:526,t:1527267533244};\\\", \\\"{x:940,y:526,t:1527267533260};\\\", \\\"{x:1021,y:526,t:1527267533277};\\\", \\\"{x:1074,y:526,t:1527267533294};\\\", \\\"{x:1107,y:526,t:1527267533310};\\\", \\\"{x:1122,y:526,t:1527267533327};\\\", \\\"{x:1130,y:526,t:1527267533344};\\\", \\\"{x:1134,y:526,t:1527267533360};\\\", \\\"{x:1138,y:526,t:1527267533376};\\\", \\\"{x:1141,y:526,t:1527267533410};\\\", \\\"{x:1147,y:527,t:1527267533426};\\\", \\\"{x:1163,y:532,t:1527267533444};\\\", \\\"{x:1182,y:539,t:1527267533460};\\\", \\\"{x:1209,y:545,t:1527267533477};\\\", \\\"{x:1242,y:554,t:1527267533493};\\\", \\\"{x:1286,y:558,t:1527267533510};\\\", \\\"{x:1325,y:563,t:1527267533527};\\\", \\\"{x:1350,y:568,t:1527267533543};\\\", \\\"{x:1365,y:570,t:1527267533560};\\\", \\\"{x:1378,y:572,t:1527267533577};\\\", \\\"{x:1383,y:573,t:1527267533593};\\\", \\\"{x:1386,y:573,t:1527267533609};\\\", \\\"{x:1388,y:573,t:1527267533626};\\\", \\\"{x:1391,y:573,t:1527267533642};\\\", \\\"{x:1393,y:573,t:1527267533660};\\\", \\\"{x:1395,y:573,t:1527267533677};\\\", \\\"{x:1399,y:574,t:1527267533693};\\\", \\\"{x:1403,y:574,t:1527267533710};\\\", \\\"{x:1409,y:575,t:1527267533726};\\\", \\\"{x:1414,y:576,t:1527267533743};\\\", \\\"{x:1418,y:577,t:1527267533760};\\\", \\\"{x:1421,y:577,t:1527267533776};\\\", \\\"{x:1424,y:577,t:1527267533793};\\\", \\\"{x:1428,y:577,t:1527267533809};\\\", \\\"{x:1430,y:577,t:1527267533826};\\\", \\\"{x:1435,y:577,t:1527267533843};\\\", \\\"{x:1438,y:577,t:1527267533859};\\\", \\\"{x:1441,y:577,t:1527267533876};\\\", \\\"{x:1442,y:577,t:1527267533892};\\\", \\\"{x:1444,y:577,t:1527267533930};\\\", \\\"{x:1444,y:576,t:1527267534003};\\\", \\\"{x:1443,y:575,t:1527267534019};\\\", \\\"{x:1442,y:575,t:1527267534034};\\\", \\\"{x:1442,y:574,t:1527267534042};\\\", \\\"{x:1438,y:573,t:1527267534059};\\\", \\\"{x:1437,y:571,t:1527267534075};\\\", \\\"{x:1435,y:569,t:1527267534091};\\\", \\\"{x:1434,y:567,t:1527267534107};\\\", \\\"{x:1433,y:567,t:1527267534125};\\\", \\\"{x:1432,y:565,t:1527267534142};\\\", \\\"{x:1431,y:564,t:1527267534157};\\\", \\\"{x:1430,y:564,t:1527267534186};\\\", \\\"{x:1429,y:564,t:1527267534193};\\\", \\\"{x:1428,y:564,t:1527267534218};\\\", \\\"{x:1427,y:564,t:1527267534234};\\\", \\\"{x:1426,y:563,t:1527267534322};\\\", \\\"{x:1425,y:563,t:1527267534483};\\\", \\\"{x:1422,y:562,t:1527267534514};\\\", \\\"{x:1421,y:562,t:1527267534546};\\\", \\\"{x:1420,y:561,t:1527267534556};\\\", \\\"{x:1419,y:561,t:1527267534573};\\\", \\\"{x:1416,y:560,t:1527267534666};\\\", \\\"{x:1414,y:560,t:1527267534681};\\\", \\\"{x:1413,y:560,t:1527267534730};\\\", \\\"{x:1408,y:571,t:1527267542100};\\\", \\\"{x:1402,y:598,t:1527267542106};\\\", \\\"{x:1393,y:631,t:1527267542122};\\\", \\\"{x:1385,y:698,t:1527267542137};\\\", \\\"{x:1372,y:789,t:1527267542155};\\\", \\\"{x:1367,y:835,t:1527267542172};\\\", \\\"{x:1367,y:864,t:1527267542188};\\\", \\\"{x:1373,y:887,t:1527267542204};\\\", \\\"{x:1379,y:899,t:1527267542222};\\\", \\\"{x:1387,y:911,t:1527267542238};\\\", \\\"{x:1395,y:922,t:1527267542254};\\\", \\\"{x:1401,y:933,t:1527267542270};\\\", \\\"{x:1409,y:947,t:1527267542287};\\\", \\\"{x:1414,y:960,t:1527267542305};\\\", \\\"{x:1420,y:976,t:1527267542321};\\\", \\\"{x:1427,y:993,t:1527267542337};\\\", \\\"{x:1433,y:1012,t:1527267542354};\\\", \\\"{x:1437,y:1025,t:1527267542370};\\\", \\\"{x:1440,y:1042,t:1527267542387};\\\", \\\"{x:1441,y:1050,t:1527267542404};\\\", \\\"{x:1442,y:1057,t:1527267542421};\\\", \\\"{x:1442,y:1058,t:1527267542437};\\\", \\\"{x:1443,y:1058,t:1527267542475};\\\", \\\"{x:1445,y:1058,t:1527267542498};\\\", \\\"{x:1447,y:1058,t:1527267542506};\\\", \\\"{x:1451,y:1056,t:1527267542520};\\\", \\\"{x:1458,y:1045,t:1527267542537};\\\", \\\"{x:1464,y:1037,t:1527267542554};\\\", \\\"{x:1470,y:1028,t:1527267542570};\\\", \\\"{x:1472,y:1022,t:1527267542587};\\\", \\\"{x:1474,y:1019,t:1527267542603};\\\", \\\"{x:1475,y:1017,t:1527267542620};\\\", \\\"{x:1476,y:1014,t:1527267542637};\\\", \\\"{x:1476,y:1013,t:1527267542654};\\\", \\\"{x:1476,y:1011,t:1527267542669};\\\", \\\"{x:1476,y:1008,t:1527267542686};\\\", \\\"{x:1476,y:1006,t:1527267542704};\\\", \\\"{x:1476,y:1001,t:1527267542719};\\\", \\\"{x:1476,y:997,t:1527267542736};\\\", \\\"{x:1476,y:990,t:1527267542753};\\\", \\\"{x:1476,y:984,t:1527267542770};\\\", \\\"{x:1477,y:981,t:1527267542786};\\\", \\\"{x:1477,y:980,t:1527267542810};\\\", \\\"{x:1477,y:979,t:1527267542820};\\\", \\\"{x:1478,y:976,t:1527267542836};\\\", \\\"{x:1478,y:972,t:1527267542852};\\\", \\\"{x:1479,y:971,t:1527267542869};\\\", \\\"{x:1480,y:969,t:1527267542887};\\\", \\\"{x:1480,y:968,t:1527267543195};\\\", \\\"{x:1480,y:967,t:1527267543235};\\\", \\\"{x:1480,y:965,t:1527267543252};\\\", \\\"{x:1480,y:963,t:1527267543269};\\\", \\\"{x:1480,y:962,t:1527267543285};\\\", \\\"{x:1480,y:961,t:1527267543348};\\\", \\\"{x:1480,y:960,t:1527267543361};\\\", \\\"{x:1480,y:959,t:1527267543369};\\\", \\\"{x:1480,y:958,t:1527267543383};\\\", \\\"{x:1480,y:956,t:1527267543401};\\\", \\\"{x:1480,y:955,t:1527267543417};\\\", \\\"{x:1479,y:953,t:1527267543434};\\\", \\\"{x:1479,y:952,t:1527267543451};\\\", \\\"{x:1478,y:949,t:1527267543467};\\\", \\\"{x:1478,y:948,t:1527267543490};\\\", \\\"{x:1478,y:947,t:1527267543501};\\\", \\\"{x:1477,y:944,t:1527267543517};\\\", \\\"{x:1477,y:943,t:1527267543534};\\\", \\\"{x:1477,y:940,t:1527267543550};\\\", \\\"{x:1477,y:939,t:1527267543567};\\\", \\\"{x:1477,y:937,t:1527267543585};\\\", \\\"{x:1476,y:935,t:1527267543601};\\\", \\\"{x:1476,y:933,t:1527267543617};\\\", \\\"{x:1474,y:928,t:1527267543634};\\\", \\\"{x:1474,y:926,t:1527267543659};\\\", \\\"{x:1474,y:924,t:1527267543674};\\\", \\\"{x:1473,y:923,t:1527267543698};\\\", \\\"{x:1473,y:922,t:1527267543706};\\\", \\\"{x:1473,y:921,t:1527267543717};\\\", \\\"{x:1473,y:920,t:1527267543734};\\\", \\\"{x:1472,y:918,t:1527267543750};\\\", \\\"{x:1472,y:913,t:1527267543767};\\\", \\\"{x:1471,y:911,t:1527267543783};\\\", \\\"{x:1471,y:908,t:1527267543800};\\\", \\\"{x:1471,y:905,t:1527267543816};\\\", \\\"{x:1470,y:905,t:1527267543833};\\\", \\\"{x:1470,y:902,t:1527267543849};\\\", \\\"{x:1470,y:901,t:1527267543866};\\\", \\\"{x:1470,y:900,t:1527267543898};\\\", \\\"{x:1470,y:899,t:1527267543906};\\\", \\\"{x:1470,y:898,t:1527267543930};\\\", \\\"{x:1470,y:897,t:1527267543947};\\\", \\\"{x:1470,y:896,t:1527267543954};\\\", \\\"{x:1470,y:895,t:1527267543986};\\\", \\\"{x:1470,y:893,t:1527267544000};\\\", \\\"{x:1470,y:892,t:1527267544017};\\\", \\\"{x:1469,y:888,t:1527267544032};\\\", \\\"{x:1469,y:886,t:1527267544050};\\\", \\\"{x:1469,y:882,t:1527267544066};\\\", \\\"{x:1468,y:879,t:1527267544082};\\\", \\\"{x:1468,y:878,t:1527267544099};\\\", \\\"{x:1467,y:876,t:1527267544116};\\\", \\\"{x:1467,y:875,t:1527267544138};\\\", \\\"{x:1467,y:873,t:1527267544163};\\\", \\\"{x:1467,y:872,t:1527267544187};\\\", \\\"{x:1466,y:871,t:1527267544200};\\\", \\\"{x:1466,y:870,t:1527267544219};\\\", \\\"{x:1466,y:869,t:1527267544233};\\\", \\\"{x:1466,y:867,t:1527267544249};\\\", \\\"{x:1466,y:866,t:1527267544265};\\\", \\\"{x:1466,y:864,t:1527267544283};\\\", \\\"{x:1466,y:863,t:1527267544299};\\\", \\\"{x:1464,y:862,t:1527267544316};\\\", \\\"{x:1464,y:861,t:1527267544332};\\\", \\\"{x:1464,y:860,t:1527267544370};\\\", \\\"{x:1464,y:858,t:1527267544394};\\\", \\\"{x:1464,y:857,t:1527267544434};\\\", \\\"{x:1464,y:855,t:1527267544450};\\\", \\\"{x:1464,y:854,t:1527267544465};\\\", \\\"{x:1464,y:852,t:1527267544490};\\\", \\\"{x:1464,y:851,t:1527267544513};\\\", \\\"{x:1465,y:849,t:1527267544538};\\\", \\\"{x:1465,y:848,t:1527267544562};\\\", \\\"{x:1465,y:846,t:1527267544586};\\\", \\\"{x:1465,y:845,t:1527267544610};\\\", \\\"{x:1465,y:843,t:1527267544650};\\\", \\\"{x:1465,y:842,t:1527267544707};\\\", \\\"{x:1465,y:840,t:1527267544738};\\\", \\\"{x:1465,y:844,t:1527267545595};\\\", \\\"{x:1465,y:850,t:1527267545613};\\\", \\\"{x:1465,y:854,t:1527267545628};\\\", \\\"{x:1465,y:857,t:1527267545646};\\\", \\\"{x:1465,y:861,t:1527267545663};\\\", \\\"{x:1465,y:864,t:1527267545679};\\\", \\\"{x:1465,y:869,t:1527267545695};\\\", \\\"{x:1465,y:872,t:1527267545713};\\\", \\\"{x:1467,y:878,t:1527267545728};\\\", \\\"{x:1467,y:882,t:1527267545745};\\\", \\\"{x:1468,y:887,t:1527267545762};\\\", \\\"{x:1468,y:889,t:1527267545778};\\\", \\\"{x:1468,y:890,t:1527267545795};\\\", \\\"{x:1469,y:891,t:1527267545818};\\\", \\\"{x:1469,y:892,t:1527267545828};\\\", \\\"{x:1469,y:895,t:1527267545845};\\\", \\\"{x:1471,y:901,t:1527267545861};\\\", \\\"{x:1471,y:905,t:1527267545878};\\\", \\\"{x:1472,y:909,t:1527267545894};\\\", \\\"{x:1473,y:912,t:1527267545912};\\\", \\\"{x:1473,y:915,t:1527267545929};\\\", \\\"{x:1474,y:918,t:1527267545945};\\\", \\\"{x:1474,y:921,t:1527267545962};\\\", \\\"{x:1474,y:922,t:1527267545978};\\\", \\\"{x:1474,y:928,t:1527267545994};\\\", \\\"{x:1474,y:931,t:1527267546011};\\\", \\\"{x:1474,y:933,t:1527267546027};\\\", \\\"{x:1474,y:936,t:1527267546045};\\\", \\\"{x:1474,y:939,t:1527267546061};\\\", \\\"{x:1474,y:943,t:1527267546077};\\\", \\\"{x:1474,y:946,t:1527267546095};\\\", \\\"{x:1474,y:949,t:1527267546111};\\\", \\\"{x:1474,y:950,t:1527267546139};\\\", \\\"{x:1474,y:951,t:1527267546148};\\\", \\\"{x:1474,y:952,t:1527267546162};\\\", \\\"{x:1474,y:953,t:1527267546186};\\\", \\\"{x:1475,y:953,t:1527267546194};\\\", \\\"{x:1475,y:954,t:1527267546211};\\\", \\\"{x:1475,y:955,t:1527267546243};\\\", \\\"{x:1475,y:956,t:1527267546266};\\\", \\\"{x:1475,y:957,t:1527267546282};\\\", \\\"{x:1475,y:956,t:1527267546762};\\\", \\\"{x:1475,y:955,t:1527267546779};\\\", \\\"{x:1475,y:954,t:1527267546819};\\\", \\\"{x:1475,y:953,t:1527267546826};\\\", \\\"{x:1475,y:952,t:1527267546843};\\\", \\\"{x:1475,y:951,t:1527267546859};\\\", \\\"{x:1475,y:949,t:1527267546876};\\\", \\\"{x:1475,y:948,t:1527267546893};\\\", \\\"{x:1475,y:946,t:1527267546909};\\\", \\\"{x:1475,y:945,t:1527267546926};\\\", \\\"{x:1475,y:943,t:1527267546943};\\\", \\\"{x:1475,y:942,t:1527267546969};\\\", \\\"{x:1475,y:941,t:1527267546985};\\\", \\\"{x:1475,y:940,t:1527267547001};\\\", \\\"{x:1475,y:939,t:1527267547017};\\\", \\\"{x:1475,y:938,t:1527267547034};\\\", \\\"{x:1475,y:937,t:1527267547041};\\\", \\\"{x:1475,y:936,t:1527267547074};\\\", \\\"{x:1475,y:934,t:1527267547090};\\\", \\\"{x:1475,y:933,t:1527267547106};\\\", \\\"{x:1475,y:932,t:1527267547113};\\\", \\\"{x:1475,y:931,t:1527267547124};\\\", \\\"{x:1475,y:930,t:1527267547141};\\\", \\\"{x:1475,y:929,t:1527267547158};\\\", \\\"{x:1475,y:928,t:1527267547174};\\\", \\\"{x:1475,y:927,t:1527267547202};\\\", \\\"{x:1475,y:926,t:1527267547210};\\\", \\\"{x:1475,y:925,t:1527267547225};\\\", \\\"{x:1475,y:924,t:1527267547258};\\\", \\\"{x:1475,y:923,t:1527267547291};\\\", \\\"{x:1475,y:922,t:1527267547308};\\\", \\\"{x:1475,y:921,t:1527267547348};\\\", \\\"{x:1475,y:920,t:1527267547371};\\\", \\\"{x:1475,y:919,t:1527267547394};\\\", \\\"{x:1475,y:918,t:1527267547443};\\\", \\\"{x:1475,y:917,t:1527267547458};\\\", \\\"{x:1475,y:916,t:1527267547475};\\\", \\\"{x:1474,y:915,t:1527267547507};\\\", \\\"{x:1474,y:914,t:1527267547524};\\\", \\\"{x:1474,y:913,t:1527267547549};\\\", \\\"{x:1474,y:912,t:1527267547585};\\\", \\\"{x:1474,y:911,t:1527267547593};\\\", \\\"{x:1474,y:910,t:1527267547617};\\\", \\\"{x:1474,y:909,t:1527267547634};\\\", \\\"{x:1474,y:908,t:1527267547649};\\\", \\\"{x:1474,y:907,t:1527267547658};\\\", \\\"{x:1474,y:906,t:1527267547682};\\\", \\\"{x:1474,y:905,t:1527267547698};\\\", \\\"{x:1474,y:904,t:1527267547706};\\\", \\\"{x:1474,y:903,t:1527267547738};\\\", \\\"{x:1474,y:902,t:1527267547762};\\\", \\\"{x:1474,y:901,t:1527267547778};\\\", \\\"{x:1474,y:900,t:1527267547810};\\\", \\\"{x:1474,y:899,t:1527267547834};\\\", \\\"{x:1474,y:898,t:1527267547875};\\\", \\\"{x:1472,y:895,t:1527267548835};\\\", \\\"{x:1471,y:893,t:1527267548843};\\\", \\\"{x:1471,y:892,t:1527267548854};\\\", \\\"{x:1471,y:888,t:1527267548870};\\\", \\\"{x:1471,y:882,t:1527267548887};\\\", \\\"{x:1471,y:877,t:1527267548903};\\\", \\\"{x:1470,y:873,t:1527267548921};\\\", \\\"{x:1470,y:869,t:1527267548936};\\\", \\\"{x:1470,y:867,t:1527267548953};\\\", \\\"{x:1470,y:861,t:1527267548969};\\\", \\\"{x:1470,y:858,t:1527267548986};\\\", \\\"{x:1470,y:855,t:1527267549003};\\\", \\\"{x:1470,y:852,t:1527267549020};\\\", \\\"{x:1470,y:851,t:1527267549036};\\\", \\\"{x:1470,y:848,t:1527267549053};\\\", \\\"{x:1470,y:845,t:1527267549069};\\\", \\\"{x:1470,y:842,t:1527267549086};\\\", \\\"{x:1470,y:840,t:1527267549104};\\\", \\\"{x:1470,y:839,t:1527267549119};\\\", \\\"{x:1469,y:835,t:1527267549136};\\\", \\\"{x:1469,y:834,t:1527267549152};\\\", \\\"{x:1469,y:832,t:1527267549169};\\\", \\\"{x:1469,y:830,t:1527267549187};\\\", \\\"{x:1469,y:828,t:1527267549203};\\\", \\\"{x:1468,y:828,t:1527267550011};\\\", \\\"{x:1468,y:827,t:1527267550018};\\\", \\\"{x:1467,y:818,t:1527267550035};\\\", \\\"{x:1466,y:812,t:1527267550051};\\\", \\\"{x:1464,y:805,t:1527267550068};\\\", \\\"{x:1464,y:798,t:1527267550084};\\\", \\\"{x:1464,y:795,t:1527267550101};\\\", \\\"{x:1463,y:793,t:1527267550118};\\\", \\\"{x:1463,y:792,t:1527267550134};\\\", \\\"{x:1463,y:789,t:1527267550151};\\\", \\\"{x:1463,y:787,t:1527267550167};\\\", \\\"{x:1463,y:784,t:1527267550184};\\\", \\\"{x:1462,y:784,t:1527267550201};\\\", \\\"{x:1462,y:782,t:1527267550217};\\\", \\\"{x:1462,y:781,t:1527267550234};\\\", \\\"{x:1462,y:779,t:1527267550291};\\\", \\\"{x:1462,y:778,t:1527267550331};\\\", \\\"{x:1462,y:776,t:1527267550443};\\\", \\\"{x:1462,y:775,t:1527267550481};\\\", \\\"{x:1461,y:775,t:1527267550489};\\\", \\\"{x:1461,y:773,t:1527267550522};\\\", \\\"{x:1461,y:772,t:1527267550570};\\\", \\\"{x:1461,y:770,t:1527267550642};\\\", \\\"{x:1461,y:769,t:1527267550787};\\\", \\\"{x:1461,y:767,t:1527267551427};\\\", \\\"{x:1461,y:766,t:1527267551499};\\\", \\\"{x:1461,y:765,t:1527267551522};\\\", \\\"{x:1461,y:764,t:1527267551538};\\\", \\\"{x:1461,y:763,t:1527267551819};\\\", \\\"{x:1458,y:762,t:1527267559931};\\\", \\\"{x:1454,y:760,t:1527267559943};\\\", \\\"{x:1452,y:759,t:1527267559958};\\\", \\\"{x:1452,y:756,t:1527267559974};\\\", \\\"{x:1452,y:752,t:1527267559991};\\\", \\\"{x:1452,y:750,t:1527267560007};\\\", \\\"{x:1451,y:749,t:1527267560024};\\\", \\\"{x:1450,y:746,t:1527267560042};\\\", \\\"{x:1449,y:743,t:1527267560058};\\\", \\\"{x:1449,y:742,t:1527267560075};\\\", \\\"{x:1449,y:740,t:1527267560092};\\\", \\\"{x:1449,y:739,t:1527267560113};\\\", \\\"{x:1449,y:738,t:1527267560125};\\\", \\\"{x:1449,y:736,t:1527267560141};\\\", \\\"{x:1449,y:733,t:1527267560158};\\\", \\\"{x:1449,y:730,t:1527267560175};\\\", \\\"{x:1449,y:726,t:1527267560191};\\\", \\\"{x:1449,y:724,t:1527267560208};\\\", \\\"{x:1449,y:722,t:1527267560225};\\\", \\\"{x:1449,y:721,t:1527267560241};\\\", \\\"{x:1450,y:718,t:1527267560258};\\\", \\\"{x:1450,y:717,t:1527267560274};\\\", \\\"{x:1450,y:715,t:1527267560291};\\\", \\\"{x:1451,y:715,t:1527267560308};\\\", \\\"{x:1452,y:713,t:1527267560324};\\\", \\\"{x:1452,y:712,t:1527267560341};\\\", \\\"{x:1452,y:710,t:1527267560359};\\\", \\\"{x:1453,y:709,t:1527267560374};\\\", \\\"{x:1453,y:708,t:1527267560391};\\\", \\\"{x:1453,y:707,t:1527267560407};\\\", \\\"{x:1454,y:706,t:1527267560424};\\\", \\\"{x:1454,y:705,t:1527267560442};\\\", \\\"{x:1454,y:704,t:1527267560457};\\\", \\\"{x:1455,y:701,t:1527267560474};\\\", \\\"{x:1456,y:701,t:1527267560491};\\\", \\\"{x:1456,y:700,t:1527267560507};\\\", \\\"{x:1456,y:699,t:1527267560524};\\\", \\\"{x:1456,y:698,t:1527267560540};\\\", \\\"{x:1457,y:698,t:1527267560562};\\\", \\\"{x:1457,y:697,t:1527267560577};\\\", \\\"{x:1457,y:696,t:1527267560698};\\\", \\\"{x:1458,y:696,t:1527267562321};\\\", \\\"{x:1459,y:696,t:1527267562336};\\\", \\\"{x:1461,y:696,t:1527267562351};\\\", \\\"{x:1457,y:704,t:1527267564113};\\\", \\\"{x:1445,y:721,t:1527267564131};\\\", \\\"{x:1434,y:736,t:1527267564148};\\\", \\\"{x:1420,y:748,t:1527267564164};\\\", \\\"{x:1402,y:756,t:1527267564181};\\\", \\\"{x:1377,y:757,t:1527267564199};\\\", \\\"{x:1361,y:757,t:1527267564214};\\\", \\\"{x:1344,y:757,t:1527267564231};\\\", \\\"{x:1328,y:757,t:1527267564248};\\\", \\\"{x:1307,y:757,t:1527267564264};\\\", \\\"{x:1286,y:757,t:1527267564282};\\\", \\\"{x:1257,y:757,t:1527267564297};\\\", \\\"{x:1213,y:752,t:1527267564314};\\\", \\\"{x:1185,y:747,t:1527267564332};\\\", \\\"{x:1166,y:745,t:1527267564347};\\\", \\\"{x:1144,y:741,t:1527267564365};\\\", \\\"{x:1125,y:737,t:1527267564380};\\\", \\\"{x:1112,y:733,t:1527267564397};\\\", \\\"{x:1105,y:731,t:1527267564415};\\\", \\\"{x:1100,y:729,t:1527267564430};\\\", \\\"{x:1097,y:728,t:1527267564447};\\\", \\\"{x:1093,y:726,t:1527267564465};\\\", \\\"{x:1087,y:725,t:1527267564480};\\\", \\\"{x:1080,y:723,t:1527267564497};\\\", \\\"{x:1068,y:719,t:1527267564513};\\\", \\\"{x:1049,y:717,t:1527267564529};\\\", \\\"{x:1046,y:717,t:1527267564548};\\\", \\\"{x:1045,y:717,t:1527267564562};\\\", \\\"{x:1043,y:717,t:1527267564580};\\\", \\\"{x:1042,y:717,t:1527267565667};\\\", \\\"{x:1041,y:718,t:1527267565678};\\\", \\\"{x:1039,y:723,t:1527267565694};\\\", \\\"{x:1038,y:725,t:1527267565710};\\\", \\\"{x:1037,y:726,t:1527267565727};\\\", \\\"{x:1036,y:727,t:1527267565744};\\\", \\\"{x:1034,y:728,t:1527267566226};\\\", \\\"{x:1032,y:730,t:1527267566243};\\\", \\\"{x:1027,y:732,t:1527267566260};\\\", \\\"{x:1014,y:734,t:1527267566277};\\\", \\\"{x:990,y:734,t:1527267566293};\\\", \\\"{x:962,y:734,t:1527267566310};\\\", \\\"{x:914,y:728,t:1527267566326};\\\", \\\"{x:878,y:719,t:1527267566342};\\\", \\\"{x:853,y:712,t:1527267566359};\\\", \\\"{x:841,y:708,t:1527267566375};\\\", \\\"{x:839,y:707,t:1527267566392};\\\", \\\"{x:837,y:705,t:1527267566409};\\\", \\\"{x:835,y:704,t:1527267566425};\\\", \\\"{x:827,y:697,t:1527267566441};\\\", \\\"{x:821,y:694,t:1527267566458};\\\", \\\"{x:813,y:692,t:1527267566475};\\\", \\\"{x:805,y:687,t:1527267566492};\\\", \\\"{x:797,y:682,t:1527267566508};\\\", \\\"{x:790,y:679,t:1527267566525};\\\", \\\"{x:783,y:674,t:1527267566541};\\\", \\\"{x:773,y:667,t:1527267566558};\\\", \\\"{x:761,y:659,t:1527267566576};\\\", \\\"{x:752,y:653,t:1527267566591};\\\", \\\"{x:745,y:650,t:1527267566608};\\\", \\\"{x:739,y:647,t:1527267566624};\\\", \\\"{x:732,y:644,t:1527267566642};\\\", \\\"{x:705,y:640,t:1527267566658};\\\", \\\"{x:679,y:637,t:1527267566674};\\\", \\\"{x:665,y:637,t:1527267566687};\\\", \\\"{x:640,y:637,t:1527267566704};\\\", \\\"{x:611,y:637,t:1527267566721};\\\", \\\"{x:585,y:637,t:1527267566737};\\\", \\\"{x:559,y:635,t:1527267566754};\\\", \\\"{x:544,y:631,t:1527267566771};\\\", \\\"{x:534,y:629,t:1527267566788};\\\", \\\"{x:531,y:629,t:1527267566804};\\\", \\\"{x:529,y:628,t:1527267566820};\\\", \\\"{x:527,y:626,t:1527267566838};\\\", \\\"{x:517,y:618,t:1527267566854};\\\", \\\"{x:505,y:612,t:1527267566872};\\\", \\\"{x:494,y:607,t:1527267566888};\\\", \\\"{x:487,y:603,t:1527267566904};\\\", \\\"{x:486,y:601,t:1527267566921};\\\", \\\"{x:486,y:598,t:1527267566937};\\\", \\\"{x:486,y:593,t:1527267566954};\\\", \\\"{x:505,y:586,t:1527267566972};\\\", \\\"{x:533,y:580,t:1527267566988};\\\", \\\"{x:555,y:577,t:1527267567004};\\\", \\\"{x:590,y:569,t:1527267567022};\\\", \\\"{x:638,y:555,t:1527267567038};\\\", \\\"{x:690,y:543,t:1527267567054};\\\", \\\"{x:745,y:528,t:1527267567072};\\\", \\\"{x:788,y:527,t:1527267567088};\\\", \\\"{x:845,y:523,t:1527267567104};\\\", \\\"{x:901,y:523,t:1527267567122};\\\", \\\"{x:921,y:521,t:1527267567137};\\\", \\\"{x:926,y:520,t:1527267567154};\\\", \\\"{x:928,y:520,t:1527267567170};\\\", \\\"{x:927,y:519,t:1527267567257};\\\", \\\"{x:921,y:519,t:1527267567271};\\\", \\\"{x:905,y:519,t:1527267567288};\\\", \\\"{x:882,y:527,t:1527267567304};\\\", \\\"{x:859,y:532,t:1527267567321};\\\", \\\"{x:841,y:536,t:1527267567338};\\\", \\\"{x:839,y:536,t:1527267567354};\\\", \\\"{x:837,y:536,t:1527267567370};\\\", \\\"{x:836,y:535,t:1527267567388};\\\", \\\"{x:836,y:534,t:1527267567404};\\\", \\\"{x:836,y:533,t:1527267567426};\\\", \\\"{x:836,y:532,t:1527267567482};\\\", \\\"{x:836,y:530,t:1527267567491};\\\", \\\"{x:836,y:529,t:1527267567506};\\\", \\\"{x:836,y:528,t:1527267567521};\\\", \\\"{x:836,y:525,t:1527267567539};\\\", \\\"{x:838,y:523,t:1527267567555};\\\", \\\"{x:838,y:520,t:1527267567570};\\\", \\\"{x:835,y:528,t:1527267567841};\\\", \\\"{x:819,y:550,t:1527267567856};\\\", \\\"{x:768,y:610,t:1527267567872};\\\", \\\"{x:722,y:658,t:1527267567887};\\\", \\\"{x:690,y:688,t:1527267567905};\\\", \\\"{x:661,y:710,t:1527267567922};\\\", \\\"{x:649,y:718,t:1527267567938};\\\", \\\"{x:645,y:721,t:1527267567955};\\\", \\\"{x:644,y:722,t:1527267567977};\\\", \\\"{x:643,y:723,t:1527267567988};\\\", \\\"{x:638,y:728,t:1527267568005};\\\", \\\"{x:628,y:736,t:1527267568021};\\\", \\\"{x:616,y:744,t:1527267568038};\\\", \\\"{x:608,y:749,t:1527267568055};\\\", \\\"{x:605,y:751,t:1527267568072};\\\", \\\"{x:602,y:752,t:1527267568089};\\\", \\\"{x:601,y:752,t:1527267568105};\\\", \\\"{x:595,y:753,t:1527267568122};\\\", \\\"{x:587,y:757,t:1527267568138};\\\", \\\"{x:575,y:762,t:1527267568155};\\\", \\\"{x:562,y:766,t:1527267568172};\\\", \\\"{x:553,y:766,t:1527267568190};\\\", \\\"{x:550,y:766,t:1527267568205};\\\", \\\"{x:546,y:764,t:1527267568222};\\\", \\\"{x:541,y:760,t:1527267568239};\\\", \\\"{x:537,y:756,t:1527267568255};\\\", \\\"{x:532,y:755,t:1527267568272};\\\", \\\"{x:525,y:752,t:1527267568289};\\\", \\\"{x:522,y:751,t:1527267568305};\\\", \\\"{x:522,y:750,t:1527267568322};\\\", \\\"{x:527,y:752,t:1527267568650};\\\", \\\"{x:533,y:755,t:1527267568657};\\\", \\\"{x:547,y:760,t:1527267568672};\\\", \\\"{x:662,y:772,t:1527267568689};\\\", \\\"{x:745,y:772,t:1527267568706};\\\", \\\"{x:817,y:772,t:1527267568722};\\\", \\\"{x:862,y:772,t:1527267568739};\\\", \\\"{x:893,y:772,t:1527267568756};\\\", \\\"{x:905,y:770,t:1527267568773};\\\", \\\"{x:908,y:770,t:1527267568789};\\\" ] }, { \\\"rt\\\": 43125, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 582961, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at the x axis, find 12 AND THEN GO UP THE Y AXIS FROM THAT POINT AND NOTE ALL THE SHADED DOTS\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6670, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"usa\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 590636, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 23806, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 615456, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" }, { \\\"rt\\\": 30980, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 647846, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"3H1U8\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115-late\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"3H1U8\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 250, dom: 1050, initialDom: 1141",
  "javascriptErrors": []
}