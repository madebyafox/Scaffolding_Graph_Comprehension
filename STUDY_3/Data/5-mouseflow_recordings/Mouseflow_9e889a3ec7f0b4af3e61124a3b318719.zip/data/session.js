var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9e889a3ec7f0b4af3e61124a3b318719",
  "created": "2018-05-25T09:59:29.419707-07:00",
  "lastActivity": "2018-05-25T10:01:20.5039588-07:00",
  "pageViews": [
    {
      "id": "05252918feefd1a747c3af00a04e0544174982cc",
      "startTime": "2018-05-25T09:59:29.419707-07:00",
      "endTime": "2018-05-25T10:01:20.5039588-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 111124,
      "engagementTime": 87583,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 111124,
  "engagementTime": 87583,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=3H1U8",
    "CONDITION=115-late"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2973171b630c7fe2618da9e3da9f0317",
  "gdpr": false
}