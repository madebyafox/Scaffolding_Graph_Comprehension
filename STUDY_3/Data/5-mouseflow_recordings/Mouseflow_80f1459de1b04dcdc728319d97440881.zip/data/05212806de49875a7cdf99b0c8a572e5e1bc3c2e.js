var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05212806de49875a7cdf99b0c8a572e5e1bc3c2e"] = {
  "startTime": "2018-05-21T17:06:28.0876325Z",
  "websitePageUrl": "/",
  "visitTime": 239108,
  "engagementTime": 48267,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "80f1459de1b04dcdc728319d97440881",
    "created": "2018-05-21T17:06:28.0876325+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8f786d22fe6d58bd8033ec8b067f82ec",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/80f1459de1b04dcdc728319d97440881/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 320,
      "e": 320,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 7001,
      "e": 5102,
      "ty": 2,
      "x": 879,
      "y": 212
    },
    {
      "t": 7001,
      "e": 5102,
      "ty": 41,
      "x": 28371,
      "y": 5365,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7101,
      "e": 5202,
      "ty": 2,
      "x": 955,
      "y": 418
    },
    {
      "t": 7251,
      "e": 5352,
      "ty": 41,
      "x": 32521,
      "y": 22240,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7701,
      "e": 5802,
      "ty": 2,
      "x": 956,
      "y": 418
    },
    {
      "t": 7751,
      "e": 5852,
      "ty": 41,
      "x": 33231,
      "y": 22978,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7801,
      "e": 5902,
      "ty": 2,
      "x": 1002,
      "y": 443
    },
    {
      "t": 7901,
      "e": 6002,
      "ty": 2,
      "x": 1161,
      "y": 486
    },
    {
      "t": 8001,
      "e": 6102,
      "ty": 2,
      "x": 1494,
      "y": 561
    },
    {
      "t": 8001,
      "e": 6102,
      "ty": 41,
      "x": 61957,
      "y": 33955,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8101,
      "e": 6202,
      "ty": 2,
      "x": 1728,
      "y": 658
    },
    {
      "t": 8201,
      "e": 6302,
      "ty": 2,
      "x": 1731,
      "y": 660
    },
    {
      "t": 8252,
      "e": 6353,
      "ty": 41,
      "x": 59336,
      "y": 39673,
      "ta": "html > body"
    },
    {
      "t": 9501,
      "e": 7602,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 9501,
      "e": 7602,
      "ty": 2,
      "x": 1731,
      "y": 726
    },
    {
      "t": 9501,
      "e": 7602,
      "ty": 41,
      "x": 59336,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 10002,
      "e": 8103,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 137397,
      "e": 12602,
      "ty": 2,
      "x": 1752,
      "y": 669
    },
    {
      "t": 137496,
      "e": 12701,
      "ty": 2,
      "x": 1782,
      "y": 538
    },
    {
      "t": 137497,
      "e": 12702,
      "ty": 41,
      "x": 61092,
      "y": 29360,
      "ta": "> div.masterdiv"
    },
    {
      "t": 137596,
      "e": 12801,
      "ty": 2,
      "x": 1785,
      "y": 530
    },
    {
      "t": 137697,
      "e": 12902,
      "ty": 2,
      "x": 1018,
      "y": 878
    },
    {
      "t": 137797,
      "e": 13002,
      "ty": 2,
      "x": 321,
      "y": 1199
    },
    {
      "t": 137896,
      "e": 13101,
      "ty": 2,
      "x": 339,
      "y": 1148
    },
    {
      "t": 137997,
      "e": 13202,
      "ty": 2,
      "x": 444,
      "y": 1012
    },
    {
      "t": 137997,
      "e": 13202,
      "ty": 41,
      "x": 7406,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 138096,
      "e": 13301,
      "ty": 2,
      "x": 684,
      "y": 917
    },
    {
      "t": 138196,
      "e": 13401,
      "ty": 2,
      "x": 704,
      "y": 913
    },
    {
      "t": 138247,
      "e": 13452,
      "ty": 41,
      "x": 20492,
      "y": 15854,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 138297,
      "e": 13502,
      "ty": 2,
      "x": 769,
      "y": 909
    },
    {
      "t": 138396,
      "e": 13601,
      "ty": 2,
      "x": 829,
      "y": 897
    },
    {
      "t": 138496,
      "e": 13701,
      "ty": 2,
      "x": 833,
      "y": 895
    },
    {
      "t": 138497,
      "e": 13702,
      "ty": 41,
      "x": 26544,
      "y": 61498,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 138596,
      "e": 13801,
      "ty": 2,
      "x": 823,
      "y": 923
    },
    {
      "t": 138696,
      "e": 13901,
      "ty": 2,
      "x": 821,
      "y": 924
    },
    {
      "t": 138746,
      "e": 13951,
      "ty": 41,
      "x": 57547,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138838,
      "e": 14043,
      "ty": 3,
      "x": 821,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138979,
      "e": 14184,
      "ty": 4,
      "x": 57547,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138980,
      "e": 14185,
      "ty": 5,
      "x": 821,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138981,
      "e": 14186,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 138986,
      "e": 14191,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 139096,
      "e": 14301,
      "ty": 2,
      "x": 820,
      "y": 924
    },
    {
      "t": 139247,
      "e": 14452,
      "ty": 41,
      "x": 54271,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 139397,
      "e": 14602,
      "ty": 2,
      "x": 822,
      "y": 947
    },
    {
      "t": 139496,
      "e": 14701,
      "ty": 2,
      "x": 849,
      "y": 1057
    },
    {
      "t": 139497,
      "e": 14702,
      "ty": 41,
      "x": 27331,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139596,
      "e": 14801,
      "ty": 2,
      "x": 863,
      "y": 1082
    },
    {
      "t": 139697,
      "e": 14902,
      "ty": 2,
      "x": 842,
      "y": 1094
    },
    {
      "t": 139747,
      "e": 14952,
      "ty": 41,
      "x": 28583,
      "y": 60216,
      "ta": "> div.masterdiv"
    },
    {
      "t": 139797,
      "e": 15002,
      "ty": 2,
      "x": 838,
      "y": 1095
    },
    {
      "t": 140496,
      "e": 15701,
      "ty": 2,
      "x": 837,
      "y": 1095
    },
    {
      "t": 140496,
      "e": 15701,
      "ty": 41,
      "x": 28548,
      "y": 60216,
      "ta": "> div.masterdiv"
    },
    {
      "t": 141196,
      "e": 16401,
      "ty": 2,
      "x": 870,
      "y": 1102
    },
    {
      "t": 141247,
      "e": 16452,
      "ty": 41,
      "x": 3510,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 141297,
      "e": 16502,
      "ty": 2,
      "x": 914,
      "y": 1107
    },
    {
      "t": 141397,
      "e": 16602,
      "ty": 2,
      "x": 927,
      "y": 1107
    },
    {
      "t": 141497,
      "e": 16702,
      "ty": 2,
      "x": 940,
      "y": 1107
    },
    {
      "t": 141497,
      "e": 16702,
      "ty": 41,
      "x": 23639,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 141596,
      "e": 16801,
      "ty": 2,
      "x": 953,
      "y": 1106
    },
    {
      "t": 141697,
      "e": 16902,
      "ty": 2,
      "x": 960,
      "y": 1099
    },
    {
      "t": 141747,
      "e": 16952,
      "ty": 41,
      "x": 27579,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 141797,
      "e": 17002,
      "ty": 2,
      "x": 960,
      "y": 1087
    },
    {
      "t": 141897,
      "e": 17102,
      "ty": 2,
      "x": 960,
      "y": 1085
    },
    {
      "t": 141997,
      "e": 17202,
      "ty": 41,
      "x": 27579,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 142020,
      "e": 17225,
      "ty": 3,
      "x": 960,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 142021,
      "e": 17226,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 142022,
      "e": 17227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 142115,
      "e": 17320,
      "ty": 4,
      "x": 27579,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 142116,
      "e": 17321,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 142117,
      "e": 17322,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 142117,
      "e": 17322,
      "ty": 5,
      "x": 960,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 142597,
      "e": 17802,
      "ty": 2,
      "x": 1127,
      "y": 1005
    },
    {
      "t": 142697,
      "e": 17902,
      "ty": 2,
      "x": 1522,
      "y": 848
    },
    {
      "t": 142747,
      "e": 17952,
      "ty": 41,
      "x": 54204,
      "y": 43985,
      "ta": "html > body"
    },
    {
      "t": 142797,
      "e": 18002,
      "ty": 2,
      "x": 1592,
      "y": 784
    },
    {
      "t": 142897,
      "e": 18102,
      "ty": 2,
      "x": 1600,
      "y": 780
    },
    {
      "t": 142996,
      "e": 18201,
      "ty": 2,
      "x": 1612,
      "y": 778
    },
    {
      "t": 142997,
      "e": 18202,
      "ty": 41,
      "x": 55238,
      "y": 42655,
      "ta": "html > body"
    },
    {
      "t": 143097,
      "e": 18302,
      "ty": 2,
      "x": 1770,
      "y": 839
    },
    {
      "t": 143125,
      "e": 18330,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 143197,
      "e": 18402,
      "ty": 2,
      "x": 1771,
      "y": 839
    },
    {
      "t": 143247,
      "e": 18452,
      "ty": 41,
      "x": 60713,
      "y": 46035,
      "ta": "html > body"
    },
    {
      "t": 145397,
      "e": 20602,
      "ty": 2,
      "x": 1560,
      "y": 421
    },
    {
      "t": 145497,
      "e": 20702,
      "ty": 2,
      "x": 1030,
      "y": 379
    },
    {
      "t": 145497,
      "e": 20702,
      "ty": 41,
      "x": 35195,
      "y": 20552,
      "ta": "html > body"
    },
    {
      "t": 145597,
      "e": 20802,
      "ty": 2,
      "x": 977,
      "y": 455
    },
    {
      "t": 145675,
      "e": 20880,
      "ty": 6,
      "x": 1022,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145697,
      "e": 20902,
      "ty": 2,
      "x": 1023,
      "y": 693
    },
    {
      "t": 145746,
      "e": 20951,
      "ty": 41,
      "x": 46501,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145797,
      "e": 21002,
      "ty": 2,
      "x": 1004,
      "y": 684
    },
    {
      "t": 145824,
      "e": 21029,
      "ty": 7,
      "x": 995,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145896,
      "e": 21101,
      "ty": 2,
      "x": 976,
      "y": 647
    },
    {
      "t": 145996,
      "e": 21201,
      "ty": 2,
      "x": 971,
      "y": 627
    },
    {
      "t": 145997,
      "e": 21202,
      "ty": 41,
      "x": 35254,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 146074,
      "e": 21279,
      "ty": 6,
      "x": 967,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146096,
      "e": 21301,
      "ty": 2,
      "x": 967,
      "y": 605
    },
    {
      "t": 146197,
      "e": 21402,
      "ty": 2,
      "x": 967,
      "y": 604
    },
    {
      "t": 146247,
      "e": 21452,
      "ty": 41,
      "x": 34389,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146297,
      "e": 21502,
      "ty": 2,
      "x": 967,
      "y": 603
    },
    {
      "t": 146419,
      "e": 21624,
      "ty": 3,
      "x": 967,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146419,
      "e": 21624,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146524,
      "e": 21729,
      "ty": 4,
      "x": 34389,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146524,
      "e": 21729,
      "ty": 5,
      "x": 967,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146747,
      "e": 21952,
      "ty": 41,
      "x": 34822,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146792,
      "e": 21997,
      "ty": 7,
      "x": 986,
      "y": 613,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146797,
      "e": 22002,
      "ty": 2,
      "x": 986,
      "y": 613
    },
    {
      "t": 146897,
      "e": 22102,
      "ty": 2,
      "x": 1082,
      "y": 661
    },
    {
      "t": 146997,
      "e": 22202,
      "ty": 2,
      "x": 1087,
      "y": 663
    },
    {
      "t": 146997,
      "e": 22202,
      "ty": 41,
      "x": 60344,
      "y": 33824,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 148072,
      "e": 23277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 148074,
      "e": 23279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148135,
      "e": 23340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "b"
    },
    {
      "t": 148256,
      "e": 23461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 148256,
      "e": 23461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148375,
      "e": 23580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "br"
    },
    {
      "t": 148447,
      "e": 23652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 148447,
      "e": 23652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148560,
      "e": 23765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "bra"
    },
    {
      "t": 148688,
      "e": 23893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 148689,
      "e": 23894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148759,
      "e": 23964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "brav"
    },
    {
      "t": 148840,
      "e": 24045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 148841,
      "e": 24046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148902,
      "e": 24107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||o"
    },
    {
      "t": 149997,
      "e": 25202,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150396,
      "e": 25601,
      "ty": 2,
      "x": 1088,
      "y": 666
    },
    {
      "t": 150478,
      "e": 25683,
      "ty": 6,
      "x": 1084,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150497,
      "e": 25702,
      "ty": 2,
      "x": 1080,
      "y": 686
    },
    {
      "t": 150497,
      "e": 25702,
      "ty": 41,
      "x": 58830,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150544,
      "e": 25749,
      "ty": 7,
      "x": 1070,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150597,
      "e": 25802,
      "ty": 2,
      "x": 1065,
      "y": 711
    },
    {
      "t": 150697,
      "e": 25902,
      "ty": 2,
      "x": 1070,
      "y": 772
    },
    {
      "t": 150747,
      "e": 25952,
      "ty": 41,
      "x": 36572,
      "y": 42711,
      "ta": "html > body"
    },
    {
      "t": 150797,
      "e": 26002,
      "ty": 2,
      "x": 1062,
      "y": 779
    },
    {
      "t": 150897,
      "e": 26102,
      "ty": 2,
      "x": 1022,
      "y": 751
    },
    {
      "t": 150912,
      "e": 26117,
      "ty": 6,
      "x": 1008,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 150944,
      "e": 26149,
      "ty": 7,
      "x": 970,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 150961,
      "e": 26166,
      "ty": 6,
      "x": 958,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150997,
      "e": 26202,
      "ty": 2,
      "x": 944,
      "y": 694
    },
    {
      "t": 150997,
      "e": 26202,
      "ty": 41,
      "x": 29415,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151097,
      "e": 26302,
      "ty": 2,
      "x": 942,
      "y": 693
    },
    {
      "t": 151248,
      "e": 26453,
      "ty": 41,
      "x": 28982,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151292,
      "e": 26497,
      "ty": 3,
      "x": 942,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151295,
      "e": 26500,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "bravo"
    },
    {
      "t": 151296,
      "e": 26501,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151297,
      "e": 26502,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151362,
      "e": 26567,
      "ty": 4,
      "x": 28982,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151362,
      "e": 26567,
      "ty": 5,
      "x": 942,
      "y": 693,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152095,
      "e": 27300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 152096,
      "e": 27301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152202,
      "e": 27407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 152271,
      "e": 27476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 152279,
      "e": 27484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 152279,
      "e": 27484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152376,
      "e": 27581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 152431,
      "e": 27636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 152433,
      "e": 27638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152502,
      "e": 27707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 153397,
      "e": 28602,
      "ty": 2,
      "x": 936,
      "y": 688
    },
    {
      "t": 153480,
      "e": 28685,
      "ty": 7,
      "x": 939,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153497,
      "e": 28702,
      "ty": 6,
      "x": 946,
      "y": 713,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153497,
      "e": 28702,
      "ty": 2,
      "x": 946,
      "y": 713
    },
    {
      "t": 153497,
      "e": 28702,
      "ty": 41,
      "x": 25809,
      "y": 9929,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 153597,
      "e": 28802,
      "ty": 2,
      "x": 950,
      "y": 729
    },
    {
      "t": 153697,
      "e": 28902,
      "ty": 2,
      "x": 951,
      "y": 732
    },
    {
      "t": 153747,
      "e": 28952,
      "ty": 41,
      "x": 28386,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154132,
      "e": 29337,
      "ty": 3,
      "x": 951,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154133,
      "e": 29338,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 154134,
      "e": 29339,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 154134,
      "e": 29339,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154212,
      "e": 29417,
      "ty": 4,
      "x": 28386,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154215,
      "e": 29420,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154216,
      "e": 29421,
      "ty": 5,
      "x": 951,
      "y": 732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154216,
      "e": 29421,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 154597,
      "e": 29802,
      "ty": 2,
      "x": 951,
      "y": 733
    },
    {
      "t": 154697,
      "e": 29902,
      "ty": 2,
      "x": 1460,
      "y": 736
    },
    {
      "t": 154797,
      "e": 30002,
      "ty": 2,
      "x": 1919,
      "y": 592
    },
    {
      "t": 154897,
      "e": 30102,
      "ty": 2,
      "x": 1919,
      "y": 584
    },
    {
      "t": 155304,
      "e": 30509,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 159997,
      "e": 35102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 186794,
      "e": 35102,
      "ty": 2,
      "x": 1901,
      "y": 571
    },
    {
      "t": 186894,
      "e": 35202,
      "ty": 2,
      "x": 1864,
      "y": 510
    },
    {
      "t": 186994,
      "e": 35302,
      "ty": 41,
      "x": 63916,
      "y": 27809,
      "ta": "> div.masterdiv"
    },
    {
      "t": 187094,
      "e": 35402,
      "ty": 2,
      "x": 1864,
      "y": 495
    },
    {
      "t": 187194,
      "e": 35502,
      "ty": 2,
      "x": 1269,
      "y": 389
    },
    {
      "t": 187244,
      "e": 35552,
      "ty": 41,
      "x": 25609,
      "y": 17429,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 187289,
      "e": 35597,
      "ty": 6,
      "x": 525,
      "y": 526,
      "ta": "#da1"
    },
    {
      "t": 187294,
      "e": 35602,
      "ty": 2,
      "x": 525,
      "y": 526
    },
    {
      "t": 187305,
      "e": 35613,
      "ty": 7,
      "x": 484,
      "y": 625,
      "ta": "#da1"
    },
    {
      "t": 187322,
      "e": 35630,
      "ty": 6,
      "x": 452,
      "y": 757,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 187339,
      "e": 35647,
      "ty": 7,
      "x": 442,
      "y": 905,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 187394,
      "e": 35702,
      "ty": 2,
      "x": 500,
      "y": 1199
    },
    {
      "t": 187494,
      "e": 35802,
      "ty": 2,
      "x": 636,
      "y": 1198
    },
    {
      "t": 187594,
      "e": 35902,
      "ty": 2,
      "x": 637,
      "y": 1197
    },
    {
      "t": 187994,
      "e": 36302,
      "ty": 2,
      "x": 649,
      "y": 1189
    },
    {
      "t": 188094,
      "e": 36402,
      "ty": 2,
      "x": 770,
      "y": 1105
    },
    {
      "t": 188194,
      "e": 36502,
      "ty": 2,
      "x": 832,
      "y": 1031
    },
    {
      "t": 188244,
      "e": 36552,
      "ty": 41,
      "x": 26740,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 188294,
      "e": 36602,
      "ty": 2,
      "x": 853,
      "y": 1035
    },
    {
      "t": 188373,
      "e": 36681,
      "ty": 6,
      "x": 928,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 188393,
      "e": 36701,
      "ty": 2,
      "x": 940,
      "y": 1082
    },
    {
      "t": 188494,
      "e": 36802,
      "ty": 2,
      "x": 958,
      "y": 1092
    },
    {
      "t": 188494,
      "e": 36802,
      "ty": 41,
      "x": 26487,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 188594,
      "e": 36902,
      "ty": 2,
      "x": 959,
      "y": 1098
    },
    {
      "t": 188745,
      "e": 37053,
      "ty": 41,
      "x": 27033,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 188785,
      "e": 37093,
      "ty": 3,
      "x": 959,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 188787,
      "e": 37095,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 188888,
      "e": 37196,
      "ty": 4,
      "x": 27033,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 188889,
      "e": 37197,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 188890,
      "e": 37198,
      "ty": 5,
      "x": 959,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 188892,
      "e": 37200,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 189494,
      "e": 37802,
      "ty": 2,
      "x": 959,
      "y": 1099
    },
    {
      "t": 189494,
      "e": 37802,
      "ty": 41,
      "x": 32750,
      "y": 60438,
      "ta": "html > body"
    },
    {
      "t": 189594,
      "e": 37902,
      "ty": 2,
      "x": 1291,
      "y": 1015
    },
    {
      "t": 189694,
      "e": 38002,
      "ty": 2,
      "x": 1919,
      "y": 685
    },
    {
      "t": 189794,
      "e": 38102,
      "ty": 2,
      "x": 1919,
      "y": 605
    },
    {
      "t": 189893,
      "e": 38201,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 189898,
      "e": 38206,
      "ty": 2,
      "x": 1919,
      "y": 593
    },
    {
      "t": 189994,
      "e": 38302,
      "ty": 2,
      "x": 1911,
      "y": 593
    },
    {
      "t": 190094,
      "e": 38402,
      "ty": 2,
      "x": 1848,
      "y": 648
    },
    {
      "t": 190194,
      "e": 38502,
      "ty": 2,
      "x": 1830,
      "y": 683
    },
    {
      "t": 190245,
      "e": 38553,
      "ty": 41,
      "x": 62745,
      "y": 37393,
      "ta": "html > body"
    },
    {
      "t": 199994,
      "e": 43553,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 234394,
      "e": 43553,
      "ty": 2,
      "x": 1828,
      "y": 684
    },
    {
      "t": 234494,
      "e": 43653,
      "ty": 2,
      "x": 1547,
      "y": 691
    },
    {
      "t": 234494,
      "e": 43653,
      "ty": 41,
      "x": 61287,
      "y": 42357,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 234594,
      "e": 43753,
      "ty": 2,
      "x": 1272,
      "y": 845
    },
    {
      "t": 234694,
      "e": 43853,
      "ty": 2,
      "x": 1024,
      "y": 1159
    },
    {
      "t": 234794,
      "e": 43953,
      "ty": 2,
      "x": 866,
      "y": 1199
    },
    {
      "t": 234993,
      "e": 44152,
      "ty": 2,
      "x": 867,
      "y": 1198
    },
    {
      "t": 235094,
      "e": 44253,
      "ty": 2,
      "x": 868,
      "y": 1173
    },
    {
      "t": 235194,
      "e": 44353,
      "ty": 2,
      "x": 870,
      "y": 1149
    },
    {
      "t": 235244,
      "e": 44403,
      "ty": 41,
      "x": 29754,
      "y": 62875,
      "ta": "html > body"
    },
    {
      "t": 235294,
      "e": 44453,
      "ty": 2,
      "x": 872,
      "y": 1135
    },
    {
      "t": 235394,
      "e": 44553,
      "ty": 2,
      "x": 878,
      "y": 1108
    },
    {
      "t": 235494,
      "e": 44653,
      "ty": 2,
      "x": 880,
      "y": 1093
    },
    {
      "t": 235494,
      "e": 44653,
      "ty": 41,
      "x": 30029,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 235594,
      "e": 44753,
      "ty": 2,
      "x": 851,
      "y": 1090
    },
    {
      "t": 235694,
      "e": 44853,
      "ty": 2,
      "x": 851,
      "y": 1085
    },
    {
      "t": 235744,
      "e": 44903,
      "ty": 41,
      "x": 29995,
      "y": 58444,
      "ta": "html > body"
    },
    {
      "t": 235794,
      "e": 44953,
      "ty": 2,
      "x": 889,
      "y": 1056
    },
    {
      "t": 235894,
      "e": 45053,
      "ty": 2,
      "x": 895,
      "y": 1044
    },
    {
      "t": 235994,
      "e": 45153,
      "ty": 2,
      "x": 897,
      "y": 1040
    },
    {
      "t": 235995,
      "e": 45154,
      "ty": 41,
      "x": 30615,
      "y": 57170,
      "ta": "html > body"
    },
    {
      "t": 236094,
      "e": 45253,
      "ty": 2,
      "x": 911,
      "y": 1012
    },
    {
      "t": 236194,
      "e": 45353,
      "ty": 2,
      "x": 1038,
      "y": 908
    },
    {
      "t": 236244,
      "e": 45403,
      "ty": 41,
      "x": 37743,
      "y": 59129,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 236294,
      "e": 45453,
      "ty": 2,
      "x": 1063,
      "y": 907
    },
    {
      "t": 236394,
      "e": 45553,
      "ty": 2,
      "x": 1077,
      "y": 939
    },
    {
      "t": 236494,
      "e": 45653,
      "ty": 2,
      "x": 1095,
      "y": 957
    },
    {
      "t": 236494,
      "e": 45653,
      "ty": 41,
      "x": 39345,
      "y": 63011,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 236594,
      "e": 45753,
      "ty": 2,
      "x": 1190,
      "y": 969
    },
    {
      "t": 236694,
      "e": 45853,
      "ty": 2,
      "x": 1359,
      "y": 950
    },
    {
      "t": 236744,
      "e": 45903,
      "ty": 41,
      "x": 55462,
      "y": 62312,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 236794,
      "e": 45953,
      "ty": 2,
      "x": 1466,
      "y": 946
    },
    {
      "t": 236894,
      "e": 46053,
      "ty": 2,
      "x": 1525,
      "y": 961
    },
    {
      "t": 236994,
      "e": 46153,
      "ty": 2,
      "x": 1526,
      "y": 961
    },
    {
      "t": 236994,
      "e": 46153,
      "ty": 41,
      "x": 60267,
      "y": 63322,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 237194,
      "e": 46353,
      "ty": 2,
      "x": 1743,
      "y": 925
    },
    {
      "t": 237244,
      "e": 46403,
      "ty": 41,
      "x": 62986,
      "y": 49857,
      "ta": "html > body"
    },
    {
      "t": 237294,
      "e": 46453,
      "ty": 2,
      "x": 1853,
      "y": 901
    },
    {
      "t": 237394,
      "e": 46553,
      "ty": 2,
      "x": 1863,
      "y": 893
    },
    {
      "t": 237494,
      "e": 46653,
      "ty": 41,
      "x": 63881,
      "y": 49026,
      "ta": "html > body"
    },
    {
      "t": 238102,
      "e": 47261,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 239108,
      "e": 48267,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 2957, dom: 4311, initialDom: 4320",
  "javascriptErrors": []
}