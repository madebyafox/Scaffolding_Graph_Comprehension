var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "21f4b6c5fc3024c08d0cdba8471ba4b0",
  "created": "2018-06-04T12:25:33.7076089-07:00",
  "lastActivity": "2018-06-04T12:25:51.7076089-07:00",
  "pageViews": [
    {
      "id": "0604334312e2b39cd81ca8e2c2db7df5f3ed3abf",
      "startTime": "2018-06-04T12:25:33.7076089-07:00",
      "endTime": "2018-06-04T12:25:51.7076089-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 18000,
      "engagementTime": 18000,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18000,
  "engagementTime": 18000,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0c8fa7ca4eb3deb2b8857b90f4894252",
  "gdpr": false
}