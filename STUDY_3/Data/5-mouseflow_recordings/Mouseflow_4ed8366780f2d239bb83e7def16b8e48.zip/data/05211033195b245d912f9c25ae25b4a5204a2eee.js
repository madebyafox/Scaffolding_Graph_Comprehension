var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05211033195b245d912f9c25ae25b4a5204a2eee"] = {
  "startTime": "2018-05-21T16:17:10.5698946Z",
  "websitePageUrl": "/16",
  "visitTime": 129936,
  "engagementTime": 120551,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "4ed8366780f2d239bb83e7def16b8e48",
    "created": "2018-05-21T16:17:10.5698946+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=UQWX4",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "3236a3e9e83712c837bcb4b49270a26f",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4ed8366780f2d239bb83e7def16b8e48/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 174,
      "e": 174,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 174,
      "e": 174,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 264,
      "e": 264,
      "ty": 41,
      "x": 42817,
      "y": 42046,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 299,
      "e": 299,
      "ty": 2,
      "x": 481,
      "y": 768
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 485,
      "y": 768
    },
    {
      "t": 500,
      "e": 500,
      "ty": 41,
      "x": 43604,
      "y": 42101,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 899,
      "e": 899,
      "ty": 2,
      "x": 499,
      "y": 726
    },
    {
      "t": 999,
      "e": 999,
      "ty": 2,
      "x": 511,
      "y": 665
    },
    {
      "t": 999,
      "e": 999,
      "ty": 41,
      "x": 46527,
      "y": 36396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1076,
      "e": 1076,
      "ty": 6,
      "x": 531,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 537,
      "y": 584
    },
    {
      "t": 1199,
      "e": 1199,
      "ty": 2,
      "x": 547,
      "y": 544
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 50573,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1282,
      "e": 1282,
      "ty": 3,
      "x": 547,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1283,
      "e": 1283,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1299,
      "e": 1299,
      "ty": 2,
      "x": 547,
      "y": 543
    },
    {
      "t": 1315,
      "e": 1315,
      "ty": 4,
      "x": 50573,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1315,
      "e": 1315,
      "ty": 5,
      "x": 547,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 548,
      "y": 543
    },
    {
      "t": 1499,
      "e": 1499,
      "ty": 41,
      "x": 50686,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 50911,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 558,
      "y": 576
    },
    {
      "t": 1826,
      "e": 1826,
      "ty": 7,
      "x": 567,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 595,
      "y": 668
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 631,
      "y": 745
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 60016,
      "y": 40827,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 651,
      "y": 800
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 62264,
      "y": 43874,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 62376,
      "y": 43985,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 653,
      "y": 809
    },
    {
      "t": 4399,
      "e": 4399,
      "ty": 2,
      "x": 653,
      "y": 813
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 62489,
      "y": 44594,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 653,
      "y": 814
    },
    {
      "t": 4749,
      "e": 4749,
      "ty": 41,
      "x": 62489,
      "y": 44650,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5199,
      "e": 5199,
      "ty": 2,
      "x": 656,
      "y": 819
    },
    {
      "t": 5249,
      "e": 5249,
      "ty": 41,
      "x": 63051,
      "y": 45038,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 660,
      "y": 823
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 670,
      "y": 831
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 677,
      "y": 840
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 65187,
      "y": 46090,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 698,
      "y": 862
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 728,
      "y": 895
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 3667,
      "y": 54884,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 5799,
      "e": 5799,
      "ty": 2,
      "x": 778,
      "y": 928
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 5619,
      "y": 56091,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 779,
      "y": 928
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 783,
      "y": 928
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 71,
      "y": 56582,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 792,
      "y": 928
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 800,
      "y": 931
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 824,
      "y": 940
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 41,
      "x": 2678,
      "y": 57441,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7099,
      "e": 7099,
      "ty": 2,
      "x": 842,
      "y": 948
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 867,
      "y": 955
    },
    {
      "t": 7249,
      "e": 7249,
      "ty": 41,
      "x": 6202,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 881,
      "y": 962
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 896,
      "y": 966
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 906,
      "y": 970
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 41,
      "x": 64370,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g > text"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 913,
      "y": 972
    },
    {
      "t": 7699,
      "e": 7699,
      "ty": 2,
      "x": 917,
      "y": 973
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 41,
      "x": 9443,
      "y": 59805,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7799,
      "e": 7799,
      "ty": 2,
      "x": 922,
      "y": 974
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 926,
      "y": 974
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 967,
      "y": 975
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 55190,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[3] > text"
    },
    {
      "t": 8099,
      "e": 8099,
      "ty": 2,
      "x": 993,
      "y": 973
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 1020,
      "y": 971
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 55730,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[5] > text"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1045,
      "y": 969
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1051,
      "y": 967
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 1060,
      "y": 966
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 19309,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8599,
      "e": 8599,
      "ty": 2,
      "x": 1107,
      "y": 964
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 1128,
      "y": 965
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 25017,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8800,
      "e": 8800,
      "ty": 2,
      "x": 1143,
      "y": 965
    },
    {
      "t": 8899,
      "e": 8899,
      "ty": 2,
      "x": 1149,
      "y": 965
    },
    {
      "t": 8999,
      "e": 8999,
      "ty": 2,
      "x": 1151,
      "y": 965
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 25721,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 1154,
      "y": 965
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10623,
      "e": 10623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10807,
      "e": 10807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10807,
      "e": 10807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10863,
      "e": 10863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 10894,
      "e": 10894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 10950,
      "e": 10950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10951,
      "e": 10951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11039,
      "e": 11039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 11094,
      "e": 11094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11095,
      "e": 11095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11199,
      "e": 11199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 11207,
      "e": 11207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11207,
      "e": 11207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11286,
      "e": 11286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 11319,
      "e": 11319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11319,
      "e": 11319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11407,
      "e": 11407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11422,
      "e": 11422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 11423,
      "e": 11423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11518,
      "e": 11518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11519,
      "e": 11519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11551,
      "e": 11551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 11598,
      "e": 11598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11614,
      "e": 11614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11614,
      "e": 11614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11694,
      "e": 11694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11695,
      "e": 11695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11718,
      "e": 11718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 11790,
      "e": 11790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12119,
      "e": 12119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12119,
      "e": 12119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12230,
      "e": 12230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12295,
      "e": 12295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12295,
      "e": 12295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12367,
      "e": 12367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12367,
      "e": 12367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12390,
      "e": 12390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 12446,
      "e": 12446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12494,
      "e": 12494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12494,
      "e": 12494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12526,
      "e": 12526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12527,
      "e": 12527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12598,
      "e": 12598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 12623,
      "e": 12623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12623,
      "e": 12623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12670,
      "e": 12670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12679,
      "e": 12679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12679,
      "e": 12679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12694,
      "e": 12694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12799,
      "e": 12799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12799,
      "e": 12799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12807,
      "e": 12807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12896,
      "e": 12896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12896,
      "e": 12896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12919,
      "e": 12919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12999,
      "e": 12999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13103,
      "e": 13103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13104,
      "e": 13104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13111,
      "e": 13111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 13150,
      "e": 13150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13239,
      "e": 13239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13239,
      "e": 13239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13303,
      "e": 13303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13304,
      "e": 13304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13311,
      "e": 13311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 13407,
      "e": 13407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13407,
      "e": 13407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13414,
      "e": 13414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13519,
      "e": 13519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13519,
      "e": 13519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13551,
      "e": 13551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13582,
      "e": 13582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13582,
      "e": 13582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13622,
      "e": 13622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14303,
      "e": 14303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 14304,
      "e": 14304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14360,
      "e": 14360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 14360,
      "e": 14360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14398,
      "e": 14398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 14487,
      "e": 14487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14503,
      "e": 14503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14503,
      "e": 14503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14583,
      "e": 14583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14584,
      "e": 14584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14631,
      "e": 14631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 14638,
      "e": 14638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14638,
      "e": 14638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14686,
      "e": 14686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14767,
      "e": 14767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15111,
      "e": 15111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15191,
      "e": 15191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12pm"
    },
    {
      "t": 15640,
      "e": 15640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15679,
      "e": 15679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12p"
    },
    {
      "t": 15791,
      "e": 15791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15895,
      "e": 15895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12"
    },
    {
      "t": 16431,
      "e": 16431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16432,
      "e": 16432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16487,
      "e": 16487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16534,
      "e": 16534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16719,
      "e": 16719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16720,
      "e": 16720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16783,
      "e": 16783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16784,
      "e": 16784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16846,
      "e": 16846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PM"
    },
    {
      "t": 16878,
      "e": 16878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17103,
      "e": 17103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18100,
      "e": 18100,
      "ty": 2,
      "x": 870,
      "y": 881
    },
    {
      "t": 18200,
      "e": 18200,
      "ty": 2,
      "x": 735,
      "y": 880
    },
    {
      "t": 18250,
      "e": 18250,
      "ty": 41,
      "x": 1544,
      "y": 53322,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 18301,
      "e": 18301,
      "ty": 2,
      "x": 707,
      "y": 889
    },
    {
      "t": 18400,
      "e": 18400,
      "ty": 2,
      "x": 707,
      "y": 890
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 41,
      "x": 1544,
      "y": 53393,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 18935,
      "e": 18935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18935,
      "e": 18935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19046,
      "e": 19046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 26570,
      "e": 24046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 26571,
      "e": 24047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26698,
      "e": 24174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 26769,
      "e": 24245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26770,
      "e": 24246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26882,
      "e": 24358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27034,
      "e": 24510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27035,
      "e": 24511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27097,
      "e": 24573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27202,
      "e": 24678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27202,
      "e": 24678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27266,
      "e": 24742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27290,
      "e": 24766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27291,
      "e": 24767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27405,
      "e": 24881,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will "
    },
    {
      "t": 27410,
      "e": 24886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37891,
      "e": 29886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37892,
      "e": 29887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38001,
      "e": 29996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 38098,
      "e": 30093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38099,
      "e": 30094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38202,
      "e": 30197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38250,
      "e": 30245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38251,
      "e": 30246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38313,
      "e": 30308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38385,
      "e": 30380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38386,
      "e": 30381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38498,
      "e": 30493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38498,
      "e": 30493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38514,
      "e": 30509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 38601,
      "e": 30596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40003,
      "e": 31998,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41938,
      "e": 33933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41939,
      "e": 33934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42082,
      "e": 34077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42082,
      "e": 34077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42113,
      "e": 34108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 42202,
      "e": 34197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42210,
      "e": 34205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42210,
      "e": 34205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42347,
      "e": 34342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42450,
      "e": 34445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42450,
      "e": 34445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42570,
      "e": 34565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42570,
      "e": 34565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42594,
      "e": 34589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 42698,
      "e": 34693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43066,
      "e": 35061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43066,
      "e": 35061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43202,
      "e": 35197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 44082,
      "e": 36077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44083,
      "e": 36078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44177,
      "e": 36172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44281,
      "e": 36276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44282,
      "e": 36277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44346,
      "e": 36341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44347,
      "e": 36342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44385,
      "e": 36380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 44393,
      "e": 36388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44393,
      "e": 36388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44441,
      "e": 36436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44465,
      "e": 36460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44513,
      "e": 36508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 44513,
      "e": 36508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44578,
      "e": 36573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 44610,
      "e": 36605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44611,
      "e": 36606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44682,
      "e": 36677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44682,
      "e": 36677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44689,
      "e": 36684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 44753,
      "e": 36748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44754,
      "e": 36749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44761,
      "e": 36756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44842,
      "e": 36837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44858,
      "e": 36853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 44859,
      "e": 36854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44890,
      "e": 36885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 45005,
      "e": 37000,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight u"
    },
    {
      "t": 45114,
      "e": 37109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45185,
      "e": 37180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight "
    },
    {
      "t": 45218,
      "e": 37213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45218,
      "e": 37213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45337,
      "e": 37332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45498,
      "e": 37493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45499,
      "e": 37494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45545,
      "e": 37540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45545,
      "e": 37540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45601,
      "e": 37596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 45617,
      "e": 37612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45617,
      "e": 37612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45673,
      "e": 37668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45690,
      "e": 37685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45690,
      "e": 37685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45730,
      "e": 37725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45802,
      "e": 37797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47114,
      "e": 39109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47613,
      "e": 39608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47633,
      "e": 39628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight lin"
    },
    {
      "t": 47754,
      "e": 39749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47817,
      "e": 39812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight li"
    },
    {
      "t": 47907,
      "e": 39902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47962,
      "e": 39957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight l"
    },
    {
      "t": 48035,
      "e": 40030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48121,
      "e": 40116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight "
    },
    {
      "t": 48194,
      "e": 40189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48314,
      "e": 40309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight"
    },
    {
      "t": 48466,
      "e": 40461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 48467,
      "e": 40462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48553,
      "e": 40548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 48842,
      "e": 40837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48843,
      "e": 40838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48921,
      "e": 40916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 48922,
      "e": 40917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48961,
      "e": 40956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| u"
    },
    {
      "t": 49025,
      "e": 40956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49082,
      "e": 41013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 49083,
      "e": 41014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49185,
      "e": 41116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 49193,
      "e": 41124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 49194,
      "e": 41125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49289,
      "e": 41220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49289,
      "e": 41220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49314,
      "e": 41245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49314,
      "e": 41245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49337,
      "e": 41268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||war"
    },
    {
      "t": 49371,
      "e": 41302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49393,
      "e": 41324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49514,
      "e": 41445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49514,
      "e": 41445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49577,
      "e": 41508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49578,
      "e": 41509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49601,
      "e": 41532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 49633,
      "e": 41564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49633,
      "e": 41564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49665,
      "e": 41596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 49713,
      "e": 41644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49842,
      "e": 41773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49843,
      "e": 41774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49906,
      "e": 41837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49909,
      "e": 41840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49937,
      "e": 41868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 49953,
      "e": 41884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49953,
      "e": 41884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50017,
      "e": 41948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50017,
      "e": 41948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50018,
      "e": 41949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50049,
      "e": 41980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50145,
      "e": 42076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50906,
      "e": 42837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50907,
      "e": 42838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51018,
      "e": 42949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 51018,
      "e": 42949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51025,
      "e": 42956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pr"
    },
    {
      "t": 51105,
      "e": 43036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51113,
      "e": 43044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51113,
      "e": 43044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51209,
      "e": 43140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51241,
      "e": 43172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51242,
      "e": 43173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51338,
      "e": 43269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51433,
      "e": 43364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 51435,
      "e": 43366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51489,
      "e": 43420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 51490,
      "e": 43421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51524,
      "e": 43455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ur"
    },
    {
      "t": 51593,
      "e": 43524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51714,
      "e": 43645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51770,
      "e": 43701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protu"
    },
    {
      "t": 51850,
      "e": 43781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51922,
      "e": 43853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 51923,
      "e": 43854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51929,
      "e": 43860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protr"
    },
    {
      "t": 51985,
      "e": 43916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52033,
      "e": 43964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 52033,
      "e": 43964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52097,
      "e": 44028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 52122,
      "e": 44053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 52122,
      "e": 44053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52202,
      "e": 44133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 52249,
      "e": 44180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 52250,
      "e": 44181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52289,
      "e": 44220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52289,
      "e": 44220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52337,
      "e": 44268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 52361,
      "e": 44292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52362,
      "e": 44293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52410,
      "e": 44341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 52417,
      "e": 44348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52417,
      "e": 44348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52425,
      "e": 44356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52530,
      "e": 44461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52586,
      "e": 44517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 52586,
      "e": 44517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52674,
      "e": 44605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 52770,
      "e": 44701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52770,
      "e": 44701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52849,
      "e": 44780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52849,
      "e": 44780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52865,
      "e": 44796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 52889,
      "e": 44820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 52889,
      "e": 44820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52945,
      "e": 44876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 52970,
      "e": 44901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52970,
      "e": 44901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53018,
      "e": 44949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53074,
      "e": 45005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53075,
      "e": 45006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53081,
      "e": 45012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53145,
      "e": 45076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53226,
      "e": 45157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53226,
      "e": 45157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53305,
      "e": 45236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53306,
      "e": 45237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53329,
      "e": 45260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 53361,
      "e": 45292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53361,
      "e": 45292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53401,
      "e": 45332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53473,
      "e": 45404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54746,
      "e": 46677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 54747,
      "e": 46678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54882,
      "e": 46813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 54898,
      "e": 46829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 54898,
      "e": 46829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55007,
      "e": 46831,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12"
    },
    {
      "t": 55011,
      "e": 46835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 55049,
      "e": 46873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55049,
      "e": 46873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55113,
      "e": 46937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 55137,
      "e": 46961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55257,
      "e": 47081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55257,
      "e": 47081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55377,
      "e": 47201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 55378,
      "e": 47202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55433,
      "e": 47257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PM"
    },
    {
      "t": 55434,
      "e": 47258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55490,
      "e": 47314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55523,
      "e": 47347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55525,
      "e": 47349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55617,
      "e": 47441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55641,
      "e": 47465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55641,
      "e": 47465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55697,
      "e": 47521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55698,
      "e": 47522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55761,
      "e": 47585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sp"
    },
    {
      "t": 55777,
      "e": 47601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55779,
      "e": 47603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55817,
      "e": 47641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55873,
      "e": 47697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55873,
      "e": 47697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55881,
      "e": 47705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55929,
      "e": 47753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55929,
      "e": 47753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55961,
      "e": 47785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56066,
      "e": 47890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56106,
      "e": 47930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56106,
      "e": 47930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56177,
      "e": 48001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56450,
      "e": 48274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56537,
      "e": 48361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot "
    },
    {
      "t": 56673,
      "e": 48497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56674,
      "e": 48498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56721,
      "e": 48545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56721,
      "e": 48545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56745,
      "e": 48569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 56769,
      "e": 48593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56769,
      "e": 48593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56817,
      "e": 48641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56825,
      "e": 48649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56826,
      "e": 48650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56865,
      "e": 48689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56914,
      "e": 48738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56954,
      "e": 48778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56955,
      "e": 48779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57041,
      "e": 48865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57049,
      "e": 48873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57049,
      "e": 48873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57105,
      "e": 48929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57105,
      "e": 48929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57121,
      "e": 48945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 57186,
      "e": 49010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57354,
      "e": 49178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 57410,
      "e": 49234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 57411,
      "e": 49235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57481,
      "e": 49305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 57488,
      "e": 49312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57606,
      "e": 49430,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the X"
    },
    {
      "t": 57745,
      "e": 49569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57842,
      "e": 49666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the "
    },
    {
      "t": 57849,
      "e": 49673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 57850,
      "e": 49674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57937,
      "e": 49761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 58155,
      "e": 49979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 58155,
      "e": 49979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58241,
      "e": 50065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 58425,
      "e": 50249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58425,
      "e": 50249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58497,
      "e": 50321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 58605,
      "e": 50322,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-a"
    },
    {
      "t": 58609,
      "e": 50326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58609,
      "e": 50326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58665,
      "e": 50382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58804,
      "e": 50521,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-ai"
    },
    {
      "t": 58841,
      "e": 50558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58905,
      "e": 50622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 58905,
      "e": 50622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58913,
      "e": 50630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-ac"
    },
    {
      "t": 59001,
      "e": 50718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59001,
      "e": 50718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59001,
      "e": 50718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59057,
      "e": 50774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59081,
      "e": 50798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59082,
      "e": 50799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59169,
      "e": 50886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59258,
      "e": 50975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 59259,
      "e": 50976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59321,
      "e": 51038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 59450,
      "e": 51167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59513,
      "e": 51230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-acis"
    },
    {
      "t": 59601,
      "e": 51318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59665,
      "e": 51382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-aci"
    },
    {
      "t": 59746,
      "e": 51463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59801,
      "e": 51518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-ac"
    },
    {
      "t": 59865,
      "e": 51582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59969,
      "e": 51686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-a"
    },
    {
      "t": 60313,
      "e": 52030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 60313,
      "e": 52030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60409,
      "e": 52126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 60417,
      "e": 52134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 60418,
      "e": 52134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60497,
      "e": 52213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 60570,
      "e": 52286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 60570,
      "e": 52286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60633,
      "e": 52349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 60689,
      "e": 52405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 60689,
      "e": 52405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60793,
      "e": 52509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 60818,
      "e": 52534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60818,
      "e": 52534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60929,
      "e": 52645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61057,
      "e": 52773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61169,
      "e": 52885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-axis."
    },
    {
      "t": 62004,
      "e": 53720,
      "ty": 2,
      "x": 696,
      "y": 889
    },
    {
      "t": 62004,
      "e": 53720,
      "ty": 41,
      "x": 912,
      "y": 53322,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 62603,
      "e": 54319,
      "ty": 2,
      "x": 682,
      "y": 881
    },
    {
      "t": 62703,
      "e": 54419,
      "ty": 2,
      "x": 658,
      "y": 879
    },
    {
      "t": 62754,
      "e": 54470,
      "ty": 41,
      "x": 61590,
      "y": 47641,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 62803,
      "e": 54519,
      "ty": 2,
      "x": 614,
      "y": 842
    },
    {
      "t": 62903,
      "e": 54619,
      "ty": 2,
      "x": 545,
      "y": 805
    },
    {
      "t": 63003,
      "e": 54719,
      "ty": 2,
      "x": 535,
      "y": 803
    },
    {
      "t": 63004,
      "e": 54720,
      "ty": 41,
      "x": 49225,
      "y": 44040,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 64903,
      "e": 56619,
      "ty": 2,
      "x": 529,
      "y": 798
    },
    {
      "t": 65003,
      "e": 56719,
      "ty": 2,
      "x": 526,
      "y": 797
    },
    {
      "t": 65004,
      "e": 56720,
      "ty": 41,
      "x": 48213,
      "y": 43708,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 65103,
      "e": 56819,
      "ty": 2,
      "x": 525,
      "y": 739
    },
    {
      "t": 65203,
      "e": 56919,
      "ty": 2,
      "x": 538,
      "y": 697
    },
    {
      "t": 65253,
      "e": 56969,
      "ty": 41,
      "x": 50349,
      "y": 37559,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 65303,
      "e": 57019,
      "ty": 2,
      "x": 546,
      "y": 683
    },
    {
      "t": 65403,
      "e": 57119,
      "ty": 2,
      "x": 548,
      "y": 681
    },
    {
      "t": 65503,
      "e": 57219,
      "ty": 2,
      "x": 551,
      "y": 678
    },
    {
      "t": 65503,
      "e": 57219,
      "ty": 41,
      "x": 51023,
      "y": 37116,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 65603,
      "e": 57319,
      "ty": 2,
      "x": 554,
      "y": 677
    },
    {
      "t": 65704,
      "e": 57420,
      "ty": 2,
      "x": 554,
      "y": 676
    },
    {
      "t": 65754,
      "e": 57470,
      "ty": 41,
      "x": 51360,
      "y": 37005,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 66103,
      "e": 57819,
      "ty": 2,
      "x": 556,
      "y": 677
    },
    {
      "t": 66203,
      "e": 57919,
      "ty": 2,
      "x": 550,
      "y": 680
    },
    {
      "t": 66253,
      "e": 57969,
      "ty": 41,
      "x": 50573,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 66304,
      "e": 58020,
      "ty": 2,
      "x": 544,
      "y": 680
    },
    {
      "t": 66504,
      "e": 58220,
      "ty": 41,
      "x": 50236,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 67503,
      "e": 59219,
      "ty": 2,
      "x": 536,
      "y": 683
    },
    {
      "t": 67504,
      "e": 59220,
      "ty": 41,
      "x": 49337,
      "y": 37393,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 67604,
      "e": 59320,
      "ty": 2,
      "x": 474,
      "y": 685
    },
    {
      "t": 67668,
      "e": 59384,
      "ty": 6,
      "x": 457,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 67703,
      "e": 59419,
      "ty": 2,
      "x": 453,
      "y": 685
    },
    {
      "t": 67754,
      "e": 59470,
      "ty": 41,
      "x": 57564,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 67803,
      "e": 59519,
      "ty": 2,
      "x": 438,
      "y": 684
    },
    {
      "t": 67904,
      "e": 59620,
      "ty": 2,
      "x": 433,
      "y": 684
    },
    {
      "t": 68004,
      "e": 59720,
      "ty": 2,
      "x": 431,
      "y": 683
    },
    {
      "t": 68004,
      "e": 59720,
      "ty": 41,
      "x": 50465,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 70004,
      "e": 61720,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 72967,
      "e": 64683,
      "ty": 3,
      "x": 431,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 72969,
      "e": 64685,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-axis."
    },
    {
      "t": 72969,
      "e": 64685,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72970,
      "e": 64686,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 74382,
      "e": 66098,
      "ty": 4,
      "x": 50465,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 74403,
      "e": 66119,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 74403,
      "e": 66119,
      "ty": 5,
      "x": 431,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 74408,
      "e": 66124,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 75406,
      "e": 67122,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 75903,
      "e": 67619,
      "ty": 2,
      "x": 530,
      "y": 663
    },
    {
      "t": 76002,
      "e": 67718,
      "ty": 2,
      "x": 767,
      "y": 662
    },
    {
      "t": 76002,
      "e": 67718,
      "ty": 41,
      "x": 26138,
      "y": 36229,
      "ta": "html > body"
    },
    {
      "t": 76103,
      "e": 67819,
      "ty": 2,
      "x": 833,
      "y": 607
    },
    {
      "t": 76157,
      "e": 67873,
      "ty": 6,
      "x": 882,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76203,
      "e": 67919,
      "ty": 2,
      "x": 890,
      "y": 561
    },
    {
      "t": 76253,
      "e": 67969,
      "ty": 41,
      "x": 18600,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76303,
      "e": 68019,
      "ty": 2,
      "x": 894,
      "y": 557
    },
    {
      "t": 76310,
      "e": 68026,
      "ty": 3,
      "x": 894,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76311,
      "e": 68027,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76437,
      "e": 68153,
      "ty": 4,
      "x": 18600,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76437,
      "e": 68153,
      "ty": 5,
      "x": 894,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77065,
      "e": 68781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 77066,
      "e": 68782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77130,
      "e": 68846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "99"
    },
    {
      "t": 77130,
      "e": 68846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77192,
      "e": 68908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 77232,
      "e": 68948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 77280,
      "e": 68996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 77281,
      "e": 68997,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 77281,
      "e": 68997,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77282,
      "e": 68998,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77361,
      "e": 69077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 77874,
      "e": 69590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78373,
      "e": 70089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78405,
      "e": 70121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78438,
      "e": 70154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78471,
      "e": 70187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78505,
      "e": 70221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78538,
      "e": 70254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78571,
      "e": 70287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78604,
      "e": 70320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78637,
      "e": 70353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78670,
      "e": 70386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78703,
      "e": 70419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78736,
      "e": 70452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78769,
      "e": 70485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78802,
      "e": 70518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78835,
      "e": 70551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78868,
      "e": 70584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78901,
      "e": 70617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78936,
      "e": 70652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78967,
      "e": 70683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78999,
      "e": 70715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79032,
      "e": 70748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79065,
      "e": 70781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79099,
      "e": 70815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79132,
      "e": 70848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79165,
      "e": 70881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79198,
      "e": 70914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79231,
      "e": 70947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79264,
      "e": 70980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79297,
      "e": 71013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79330,
      "e": 71046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79363,
      "e": 71079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79396,
      "e": 71112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79429,
      "e": 71145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79462,
      "e": 71178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79495,
      "e": 71211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79529,
      "e": 71245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79561,
      "e": 71277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79594,
      "e": 71310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79627,
      "e": 71343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79660,
      "e": 71376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79693,
      "e": 71409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79726,
      "e": 71442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79759,
      "e": 71475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79792,
      "e": 71508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79825,
      "e": 71541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79858,
      "e": 71574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79891,
      "e": 71607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79924,
      "e": 71640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79957,
      "e": 71673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79990,
      "e": 71706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80003,
      "e": 71719,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80023,
      "e": 71739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80056,
      "e": 71772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80089,
      "e": 71805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80122,
      "e": 71838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80155,
      "e": 71871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80169,
      "e": 71885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 80169,
      "e": 71885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80281,
      "e": 71997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 80289,
      "e": 72005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 80432,
      "e": 72148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 80432,
      "e": 72148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80537,
      "e": 72253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 80777,
      "e": 72493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 80778,
      "e": 72494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80841,
      "e": 72557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 81157,
      "e": 72873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81158,
      "e": 72874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81220,
      "e": 72936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 81221,
      "e": 72937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81261,
      "e": 72977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 81300,
      "e": 73016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81397,
      "e": 73113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 81397,
      "e": 73113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81453,
      "e": 73169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 81453,
      "e": 73169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81476,
      "e": 73192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 81516,
      "e": 73232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 81564,
      "e": 73280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81637,
      "e": 73353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 81637,
      "e": 73353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81700,
      "e": 73416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 81741,
      "e": 73457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81741,
      "e": 73457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81773,
      "e": 73489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 81828,
      "e": 73544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81852,
      "e": 73568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 81852,
      "e": 73568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81940,
      "e": 73656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81940,
      "e": 73656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81989,
      "e": 73705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 81996,
      "e": 73712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82117,
      "e": 73833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 82117,
      "e": 73833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82173,
      "e": 73889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 82173,
      "e": 73889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82204,
      "e": 73920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 82204,
      "e": 73920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82212,
      "e": 73928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es "
    },
    {
      "t": 82269,
      "e": 73985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82309,
      "e": 74025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 82309,
      "e": 74025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82317,
      "e": 74033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 82436,
      "e": 74152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82484,
      "e": 74200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 82485,
      "e": 74201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82564,
      "e": 74280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 82566,
      "e": 74282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82596,
      "e": 74312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f "
    },
    {
      "t": 82660,
      "e": 74376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 82668,
      "e": 74384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82773,
      "e": 74489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 82774,
      "e": 74490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82804,
      "e": 74520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 82884,
      "e": 74600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 82933,
      "e": 74649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 82933,
      "e": 74649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82981,
      "e": 74697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 82982,
      "e": 74698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83029,
      "e": 74745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||me"
    },
    {
      "t": 83061,
      "e": 74777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 83061,
      "e": 74777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83092,
      "e": 74808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 83148,
      "e": 74864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 83204,
      "e": 74920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 83205,
      "e": 74921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83285,
      "e": 75001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 83285,
      "e": 75001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83301,
      "e": 75017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ic"
    },
    {
      "t": 83372,
      "e": 75088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 83372,
      "e": 75088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83396,
      "e": 75112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 83468,
      "e": 75184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 84401,
      "e": 76117,
      "ty": 7,
      "x": 942,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84407,
      "e": 76123,
      "ty": 2,
      "x": 942,
      "y": 575
    },
    {
      "t": 84507,
      "e": 76223,
      "ty": 41,
      "x": 32226,
      "y": 25745,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 84507,
      "e": 76223,
      "ty": 2,
      "x": 957,
      "y": 612
    },
    {
      "t": 84607,
      "e": 76323,
      "ty": 2,
      "x": 961,
      "y": 627
    },
    {
      "t": 84685,
      "e": 76401,
      "ty": 6,
      "x": 963,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84707,
      "e": 76423,
      "ty": 2,
      "x": 963,
      "y": 652
    },
    {
      "t": 84757,
      "e": 76473,
      "ty": 41,
      "x": 33524,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84801,
      "e": 76517,
      "ty": 7,
      "x": 960,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84807,
      "e": 76523,
      "ty": 2,
      "x": 960,
      "y": 668
    },
    {
      "t": 84907,
      "e": 76623,
      "ty": 2,
      "x": 959,
      "y": 675
    },
    {
      "t": 84917,
      "e": 76633,
      "ty": 6,
      "x": 957,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 85007,
      "e": 76723,
      "ty": 2,
      "x": 956,
      "y": 689
    },
    {
      "t": 85007,
      "e": 76723,
      "ty": 41,
      "x": 30963,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 85107,
      "e": 76823,
      "ty": 2,
      "x": 956,
      "y": 691
    },
    {
      "t": 85257,
      "e": 76973,
      "ty": 41,
      "x": 30963,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 85370,
      "e": 77086,
      "ty": 3,
      "x": 956,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 85370,
      "e": 77086,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 85371,
      "e": 77087,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85371,
      "e": 77087,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86217,
      "e": 77933,
      "ty": 4,
      "x": 30963,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86219,
      "e": 77935,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86220,
      "e": 77936,
      "ty": 5,
      "x": 956,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86220,
      "e": 77936,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 87235,
      "e": 78951,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 87757,
      "e": 79473,
      "ty": 41,
      "x": 31701,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 87806,
      "e": 79522,
      "ty": 2,
      "x": 950,
      "y": 649
    },
    {
      "t": 87907,
      "e": 79623,
      "ty": 2,
      "x": 942,
      "y": 606
    },
    {
      "t": 88006,
      "e": 79722,
      "ty": 2,
      "x": 939,
      "y": 530
    },
    {
      "t": 88007,
      "e": 79723,
      "ty": 41,
      "x": 27904,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 88107,
      "e": 79823,
      "ty": 2,
      "x": 937,
      "y": 431
    },
    {
      "t": 88206,
      "e": 79922,
      "ty": 2,
      "x": 899,
      "y": 339
    },
    {
      "t": 88259,
      "e": 79924,
      "ty": 41,
      "x": 15224,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 88307,
      "e": 79972,
      "ty": 2,
      "x": 845,
      "y": 257
    },
    {
      "t": 88320,
      "e": 79985,
      "ty": 6,
      "x": 837,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 88407,
      "e": 80072,
      "ty": 2,
      "x": 834,
      "y": 236
    },
    {
      "t": 88454,
      "e": 80119,
      "ty": 7,
      "x": 832,
      "y": 231,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 88507,
      "e": 80172,
      "ty": 2,
      "x": 832,
      "y": 231
    },
    {
      "t": 88507,
      "e": 80172,
      "ty": 41,
      "x": 8662,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 88553,
      "e": 80218,
      "ty": 3,
      "x": 832,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 88665,
      "e": 80330,
      "ty": 4,
      "x": 8662,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 88666,
      "e": 80331,
      "ty": 5,
      "x": 832,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 88666,
      "e": 80331,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 88667,
      "e": 80332,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 88907,
      "e": 80572,
      "ty": 2,
      "x": 831,
      "y": 230
    },
    {
      "t": 88922,
      "e": 80587,
      "ty": 6,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 88937,
      "e": 80602,
      "ty": 7,
      "x": 831,
      "y": 250,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 88955,
      "e": 80620,
      "ty": 6,
      "x": 831,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 88971,
      "e": 80636,
      "ty": 7,
      "x": 831,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 89007,
      "e": 80672,
      "ty": 2,
      "x": 831,
      "y": 287
    },
    {
      "t": 89007,
      "e": 80672,
      "ty": 41,
      "x": 3001,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 89020,
      "e": 80685,
      "ty": 6,
      "x": 832,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 89054,
      "e": 80719,
      "ty": 7,
      "x": 834,
      "y": 305,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 89104,
      "e": 80769,
      "ty": 6,
      "x": 836,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 89107,
      "e": 80772,
      "ty": 2,
      "x": 836,
      "y": 317
    },
    {
      "t": 89172,
      "e": 80837,
      "ty": 7,
      "x": 836,
      "y": 332,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 89207,
      "e": 80872,
      "ty": 2,
      "x": 837,
      "y": 339
    },
    {
      "t": 89257,
      "e": 80922,
      "ty": 41,
      "x": 4409,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 89307,
      "e": 80972,
      "ty": 2,
      "x": 843,
      "y": 369
    },
    {
      "t": 89407,
      "e": 81072,
      "ty": 2,
      "x": 843,
      "y": 380
    },
    {
      "t": 89507,
      "e": 81172,
      "ty": 41,
      "x": 5121,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 90807,
      "e": 82472,
      "ty": 2,
      "x": 843,
      "y": 381
    },
    {
      "t": 90907,
      "e": 82572,
      "ty": 2,
      "x": 843,
      "y": 384
    },
    {
      "t": 91007,
      "e": 82672,
      "ty": 2,
      "x": 843,
      "y": 387
    },
    {
      "t": 91007,
      "e": 82672,
      "ty": 41,
      "x": 5121,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 91107,
      "e": 82772,
      "ty": 2,
      "x": 844,
      "y": 394
    },
    {
      "t": 91206,
      "e": 82871,
      "ty": 2,
      "x": 846,
      "y": 411
    },
    {
      "t": 91257,
      "e": 82922,
      "ty": 41,
      "x": 28771,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 91307,
      "e": 82972,
      "ty": 2,
      "x": 846,
      "y": 424
    },
    {
      "t": 91407,
      "e": 83072,
      "ty": 2,
      "x": 845,
      "y": 432
    },
    {
      "t": 91507,
      "e": 83172,
      "ty": 2,
      "x": 840,
      "y": 439
    },
    {
      "t": 91508,
      "e": 83173,
      "ty": 41,
      "x": 14839,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 91545,
      "e": 83210,
      "ty": 6,
      "x": 839,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 91606,
      "e": 83271,
      "ty": 2,
      "x": 835,
      "y": 445
    },
    {
      "t": 91707,
      "e": 83372,
      "ty": 2,
      "x": 833,
      "y": 447
    },
    {
      "t": 91729,
      "e": 83394,
      "ty": 7,
      "x": 831,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 91757,
      "e": 83422,
      "ty": 41,
      "x": 7650,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 91807,
      "e": 83472,
      "ty": 2,
      "x": 830,
      "y": 452
    },
    {
      "t": 91907,
      "e": 83572,
      "ty": 6,
      "x": 830,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91908,
      "e": 83573,
      "ty": 2,
      "x": 830,
      "y": 464
    },
    {
      "t": 92007,
      "e": 83672,
      "ty": 7,
      "x": 830,
      "y": 480,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92008,
      "e": 83673,
      "ty": 2,
      "x": 830,
      "y": 480
    },
    {
      "t": 92008,
      "e": 83673,
      "ty": 41,
      "x": 9067,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 92073,
      "e": 83738,
      "ty": 6,
      "x": 832,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 92106,
      "e": 83771,
      "ty": 2,
      "x": 833,
      "y": 502
    },
    {
      "t": 92124,
      "e": 83789,
      "ty": 7,
      "x": 835,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 92207,
      "e": 83872,
      "ty": 6,
      "x": 836,
      "y": 523,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 92207,
      "e": 83872,
      "ty": 2,
      "x": 836,
      "y": 523
    },
    {
      "t": 92257,
      "e": 83922,
      "ty": 41,
      "x": 48284,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 92305,
      "e": 83970,
      "ty": 7,
      "x": 836,
      "y": 533,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 92307,
      "e": 83972,
      "ty": 2,
      "x": 836,
      "y": 533
    },
    {
      "t": 92407,
      "e": 84072,
      "ty": 2,
      "x": 834,
      "y": 542
    },
    {
      "t": 92457,
      "e": 84122,
      "ty": 6,
      "x": 834,
      "y": 549,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 92507,
      "e": 84172,
      "ty": 2,
      "x": 834,
      "y": 555
    },
    {
      "t": 92508,
      "e": 84173,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 92541,
      "e": 84206,
      "ty": 7,
      "x": 834,
      "y": 562,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 92607,
      "e": 84272,
      "ty": 2,
      "x": 834,
      "y": 572
    },
    {
      "t": 92641,
      "e": 84306,
      "ty": 6,
      "x": 833,
      "y": 578,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92707,
      "e": 84372,
      "ty": 2,
      "x": 831,
      "y": 581
    },
    {
      "t": 92757,
      "e": 84422,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92761,
      "e": 84426,
      "ty": 3,
      "x": 831,
      "y": 581,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92763,
      "e": 84428,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92763,
      "e": 84428,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92832,
      "e": 84497,
      "ty": 4,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92833,
      "e": 84498,
      "ty": 5,
      "x": 831,
      "y": 581,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 92834,
      "e": 84499,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf",
      "v": "Other"
    },
    {
      "t": 93993,
      "e": 85658,
      "ty": 7,
      "x": 828,
      "y": 592,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 94007,
      "e": 85672,
      "ty": 2,
      "x": 828,
      "y": 592
    },
    {
      "t": 94009,
      "e": 85673,
      "ty": 41,
      "x": 6530,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 94107,
      "e": 85771,
      "ty": 2,
      "x": 828,
      "y": 610
    },
    {
      "t": 94208,
      "e": 85872,
      "ty": 2,
      "x": 828,
      "y": 631
    },
    {
      "t": 94257,
      "e": 85921,
      "ty": 41,
      "x": 611,
      "y": 8936,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 94307,
      "e": 85971,
      "ty": 2,
      "x": 824,
      "y": 665
    },
    {
      "t": 94408,
      "e": 86072,
      "ty": 2,
      "x": 824,
      "y": 690
    },
    {
      "t": 94507,
      "e": 86171,
      "ty": 2,
      "x": 824,
      "y": 691
    },
    {
      "t": 94507,
      "e": 86171,
      "ty": 41,
      "x": 611,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 94708,
      "e": 86372,
      "ty": 2,
      "x": 827,
      "y": 694
    },
    {
      "t": 94757,
      "e": 86421,
      "ty": 41,
      "x": 1405,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95007,
      "e": 86671,
      "ty": 2,
      "x": 827,
      "y": 695
    },
    {
      "t": 95007,
      "e": 86671,
      "ty": 41,
      "x": 1405,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95009,
      "e": 86673,
      "ty": 6,
      "x": 828,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 95108,
      "e": 86772,
      "ty": 2,
      "x": 832,
      "y": 704
    },
    {
      "t": 95257,
      "e": 86921,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 95407,
      "e": 87071,
      "ty": 2,
      "x": 838,
      "y": 708
    },
    {
      "t": 95426,
      "e": 87090,
      "ty": 7,
      "x": 840,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 95507,
      "e": 87171,
      "ty": 2,
      "x": 840,
      "y": 708
    },
    {
      "t": 95507,
      "e": 87171,
      "ty": 41,
      "x": 4681,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95569,
      "e": 87233,
      "ty": 3,
      "x": 840,
      "y": 708,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95569,
      "e": 87233,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 95656,
      "e": 87320,
      "ty": 4,
      "x": 4681,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95657,
      "e": 87321,
      "ty": 5,
      "x": 840,
      "y": 708,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95658,
      "e": 87322,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 95658,
      "e": 87322,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 96607,
      "e": 88271,
      "ty": 2,
      "x": 814,
      "y": 732
    },
    {
      "t": 96708,
      "e": 88372,
      "ty": 2,
      "x": 793,
      "y": 772
    },
    {
      "t": 96757,
      "e": 88421,
      "ty": 41,
      "x": 26482,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 96807,
      "e": 88471,
      "ty": 2,
      "x": 771,
      "y": 813
    },
    {
      "t": 96907,
      "e": 88571,
      "ty": 2,
      "x": 763,
      "y": 865
    },
    {
      "t": 97007,
      "e": 88671,
      "ty": 2,
      "x": 786,
      "y": 937
    },
    {
      "t": 97008,
      "e": 88672,
      "ty": 41,
      "x": 26792,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 97108,
      "e": 88772,
      "ty": 2,
      "x": 823,
      "y": 968
    },
    {
      "t": 97161,
      "e": 88825,
      "ty": 6,
      "x": 833,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 97207,
      "e": 88871,
      "ty": 2,
      "x": 837,
      "y": 959
    },
    {
      "t": 97228,
      "e": 88892,
      "ty": 7,
      "x": 837,
      "y": 955,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 97258,
      "e": 88922,
      "ty": 41,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 97308,
      "e": 88972,
      "ty": 2,
      "x": 838,
      "y": 944
    },
    {
      "t": 97407,
      "e": 89071,
      "ty": 2,
      "x": 839,
      "y": 942
    },
    {
      "t": 97497,
      "e": 89161,
      "ty": 3,
      "x": 839,
      "y": 941,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 97498,
      "e": 89162,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 97508,
      "e": 89172,
      "ty": 2,
      "x": 839,
      "y": 941
    },
    {
      "t": 97508,
      "e": 89172,
      "ty": 41,
      "x": 19199,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 97569,
      "e": 89233,
      "ty": 4,
      "x": 19199,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 97570,
      "e": 89234,
      "ty": 5,
      "x": 839,
      "y": 941,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 97570,
      "e": 89234,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 97572,
      "e": 89236,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 97907,
      "e": 89571,
      "ty": 2,
      "x": 839,
      "y": 945
    },
    {
      "t": 98008,
      "e": 89672,
      "ty": 2,
      "x": 847,
      "y": 967
    },
    {
      "t": 98009,
      "e": 89673,
      "ty": 41,
      "x": 20690,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 98107,
      "e": 89771,
      "ty": 2,
      "x": 858,
      "y": 993
    },
    {
      "t": 98129,
      "e": 89793,
      "ty": 6,
      "x": 867,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98207,
      "e": 89871,
      "ty": 2,
      "x": 872,
      "y": 1020
    },
    {
      "t": 98258,
      "e": 89922,
      "ty": 41,
      "x": 23490,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98308,
      "e": 89972,
      "ty": 2,
      "x": 876,
      "y": 1027
    },
    {
      "t": 98498,
      "e": 90162,
      "ty": 3,
      "x": 876,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98499,
      "e": 90163,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 98499,
      "e": 90163,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98507,
      "e": 90171,
      "ty": 41,
      "x": 24005,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98576,
      "e": 90240,
      "ty": 4,
      "x": 24005,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98576,
      "e": 90240,
      "ty": 5,
      "x": 876,
      "y": 1027,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98579,
      "e": 90243,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 98579,
      "e": 90243,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 98580,
      "e": 90244,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 98907,
      "e": 90571,
      "ty": 2,
      "x": 875,
      "y": 1024
    },
    {
      "t": 99008,
      "e": 90672,
      "ty": 2,
      "x": 873,
      "y": 1019
    },
    {
      "t": 99008,
      "e": 90672,
      "ty": 41,
      "x": 29788,
      "y": 56006,
      "ta": "html > body"
    },
    {
      "t": 99107,
      "e": 90771,
      "ty": 2,
      "x": 872,
      "y": 1012
    },
    {
      "t": 99207,
      "e": 90871,
      "ty": 2,
      "x": 870,
      "y": 1005
    },
    {
      "t": 99258,
      "e": 90922,
      "ty": 41,
      "x": 29650,
      "y": 55064,
      "ta": "html > body"
    },
    {
      "t": 99308,
      "e": 90972,
      "ty": 2,
      "x": 869,
      "y": 1000
    },
    {
      "t": 99407,
      "e": 91071,
      "ty": 2,
      "x": 868,
      "y": 996
    },
    {
      "t": 99507,
      "e": 91171,
      "ty": 2,
      "x": 868,
      "y": 991
    },
    {
      "t": 99508,
      "e": 91172,
      "ty": 41,
      "x": 29616,
      "y": 54455,
      "ta": "html > body"
    },
    {
      "t": 99607,
      "e": 91271,
      "ty": 2,
      "x": 867,
      "y": 988
    },
    {
      "t": 99758,
      "e": 91422,
      "ty": 41,
      "x": 29582,
      "y": 54233,
      "ta": "html > body"
    },
    {
      "t": 99807,
      "e": 91471,
      "ty": 2,
      "x": 866,
      "y": 986
    },
    {
      "t": 99907,
      "e": 91571,
      "ty": 2,
      "x": 866,
      "y": 984
    },
    {
      "t": 99914,
      "e": 91578,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 100008,
      "e": 91672,
      "ty": 41,
      "x": 28167,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105257,
      "e": 96672,
      "ty": 41,
      "x": 28167,
      "y": 59324,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105307,
      "e": 96722,
      "ty": 2,
      "x": 866,
      "y": 983
    },
    {
      "t": 105706,
      "e": 97121,
      "ty": 2,
      "x": 866,
      "y": 980
    },
    {
      "t": 105757,
      "e": 97172,
      "ty": 41,
      "x": 28167,
      "y": 59116,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107007,
      "e": 98422,
      "ty": 2,
      "x": 864,
      "y": 980
    },
    {
      "t": 107007,
      "e": 98422,
      "ty": 41,
      "x": 28069,
      "y": 59116,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108107,
      "e": 99522,
      "ty": 2,
      "x": 869,
      "y": 959
    },
    {
      "t": 108207,
      "e": 99622,
      "ty": 2,
      "x": 885,
      "y": 920
    },
    {
      "t": 108257,
      "e": 99672,
      "ty": 41,
      "x": 29102,
      "y": 54961,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108907,
      "e": 100322,
      "ty": 2,
      "x": 885,
      "y": 919
    },
    {
      "t": 109007,
      "e": 100422,
      "ty": 41,
      "x": 29102,
      "y": 54892,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109258,
      "e": 100673,
      "ty": 41,
      "x": 29102,
      "y": 54823,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109307,
      "e": 100722,
      "ty": 2,
      "x": 885,
      "y": 918
    },
    {
      "t": 110006,
      "e": 101421,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 115107,
      "e": 105722,
      "ty": 2,
      "x": 887,
      "y": 916
    },
    {
      "t": 115207,
      "e": 105822,
      "ty": 2,
      "x": 889,
      "y": 915
    },
    {
      "t": 115257,
      "e": 105872,
      "ty": 41,
      "x": 29299,
      "y": 54615,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 117607,
      "e": 108222,
      "ty": 2,
      "x": 890,
      "y": 915
    },
    {
      "t": 117757,
      "e": 108372,
      "ty": 41,
      "x": 29348,
      "y": 54615,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122607,
      "e": 113222,
      "ty": 2,
      "x": 890,
      "y": 914
    },
    {
      "t": 122707,
      "e": 113322,
      "ty": 2,
      "x": 890,
      "y": 912
    },
    {
      "t": 122757,
      "e": 113372,
      "ty": 41,
      "x": 29348,
      "y": 54338,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122807,
      "e": 113422,
      "ty": 2,
      "x": 890,
      "y": 911
    },
    {
      "t": 122907,
      "e": 113522,
      "ty": 2,
      "x": 887,
      "y": 911
    },
    {
      "t": 123007,
      "e": 113622,
      "ty": 2,
      "x": 886,
      "y": 911
    },
    {
      "t": 123008,
      "e": 113623,
      "ty": 41,
      "x": 29151,
      "y": 54338,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125007,
      "e": 115622,
      "ty": 2,
      "x": 887,
      "y": 913
    },
    {
      "t": 125008,
      "e": 115623,
      "ty": 41,
      "x": 29200,
      "y": 54477,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125108,
      "e": 115723,
      "ty": 2,
      "x": 889,
      "y": 914
    },
    {
      "t": 125207,
      "e": 115822,
      "ty": 2,
      "x": 892,
      "y": 915
    },
    {
      "t": 125258,
      "e": 115873,
      "ty": 41,
      "x": 29594,
      "y": 54615,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125307,
      "e": 115922,
      "ty": 2,
      "x": 897,
      "y": 919
    },
    {
      "t": 125407,
      "e": 116022,
      "ty": 2,
      "x": 907,
      "y": 928
    },
    {
      "t": 125508,
      "e": 116123,
      "ty": 2,
      "x": 917,
      "y": 957
    },
    {
      "t": 125508,
      "e": 116123,
      "ty": 41,
      "x": 30676,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125607,
      "e": 116222,
      "ty": 2,
      "x": 919,
      "y": 1006
    },
    {
      "t": 125707,
      "e": 116322,
      "ty": 2,
      "x": 915,
      "y": 1051
    },
    {
      "t": 125758,
      "e": 116373,
      "ty": 41,
      "x": 30578,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125807,
      "e": 116422,
      "ty": 2,
      "x": 915,
      "y": 1059
    },
    {
      "t": 125899,
      "e": 116514,
      "ty": 6,
      "x": 926,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 125908,
      "e": 116523,
      "ty": 2,
      "x": 926,
      "y": 1074
    },
    {
      "t": 126007,
      "e": 116622,
      "ty": 2,
      "x": 932,
      "y": 1083
    },
    {
      "t": 126007,
      "e": 116622,
      "ty": 41,
      "x": 12287,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 126633,
      "e": 117248,
      "ty": 3,
      "x": 932,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 126635,
      "e": 117250,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 127649,
      "e": 118264,
      "ty": 4,
      "x": 12287,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 127650,
      "e": 118265,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 127651,
      "e": 118266,
      "ty": 5,
      "x": 932,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 127652,
      "e": 118267,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 128680,
      "e": 119295,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 129757,
      "e": 120372,
      "ty": 41,
      "x": 31396,
      "y": 32899,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 129807,
      "e": 120422,
      "ty": 2,
      "x": 933,
      "y": 1079
    },
    {
      "t": 129906,
      "e": 120521,
      "ty": 2,
      "x": 932,
      "y": 1078
    },
    {
      "t": 129936,
      "e": 120551,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 51456, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 51459, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 39697, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 92240, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 8660, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"alpha\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 101904, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 11426, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 114415, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 15565, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 130982, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 42677, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 174876, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:861,y:726,t:1526918867314};\\\", \\\"{x:863,y:721,t:1526918867323};\\\", \\\"{x:864,y:710,t:1526918867340};\\\", \\\"{x:864,y:708,t:1526918867356};\\\", \\\"{x:865,y:708,t:1526918868171};\\\", \\\"{x:866,y:707,t:1526918868179};\\\", \\\"{x:868,y:706,t:1526918868547};\\\", \\\"{x:871,y:704,t:1526918868558};\\\", \\\"{x:876,y:704,t:1526918868574};\\\", \\\"{x:877,y:704,t:1526918868591};\\\", \\\"{x:878,y:704,t:1526918868608};\\\", \\\"{x:879,y:704,t:1526918868624};\\\", \\\"{x:880,y:704,t:1526918868651};\\\", \\\"{x:881,y:704,t:1526918868658};\\\", \\\"{x:883,y:704,t:1526918868674};\\\", \\\"{x:885,y:705,t:1526918868691};\\\", \\\"{x:886,y:705,t:1526918868708};\\\", \\\"{x:887,y:705,t:1526918868724};\\\", \\\"{x:888,y:706,t:1526918868771};\\\", \\\"{x:888,y:707,t:1526918868778};\\\", \\\"{x:889,y:707,t:1526918868802};\\\", \\\"{x:890,y:707,t:1526918868851};\\\", \\\"{x:891,y:707,t:1526918868858};\\\", \\\"{x:892,y:708,t:1526918868875};\\\", \\\"{x:894,y:708,t:1526918868891};\\\", \\\"{x:895,y:709,t:1526918868908};\\\", \\\"{x:896,y:710,t:1526918868925};\\\", \\\"{x:897,y:710,t:1526918868954};\\\", \\\"{x:898,y:710,t:1526918868963};\\\", \\\"{x:898,y:711,t:1526918868986};\\\", \\\"{x:899,y:711,t:1526918868995};\\\", \\\"{x:900,y:711,t:1526918869026};\\\", \\\"{x:901,y:711,t:1526918869041};\\\", \\\"{x:903,y:713,t:1526918869066};\\\", \\\"{x:904,y:713,t:1526918869171};\\\", \\\"{x:905,y:713,t:1526918869227};\\\", \\\"{x:906,y:713,t:1526918869242};\\\", \\\"{x:907,y:713,t:1526918869258};\\\", \\\"{x:908,y:713,t:1526918869283};\\\", \\\"{x:909,y:713,t:1526918869292};\\\", \\\"{x:910,y:713,t:1526918869338};\\\", \\\"{x:911,y:712,t:1526918869355};\\\", \\\"{x:912,y:712,t:1526918869370};\\\", \\\"{x:913,y:711,t:1526918869378};\\\", \\\"{x:913,y:710,t:1526918869391};\\\", \\\"{x:914,y:710,t:1526918869408};\\\", \\\"{x:915,y:707,t:1526918869424};\\\", \\\"{x:917,y:704,t:1526918869442};\\\", \\\"{x:918,y:700,t:1526918869459};\\\", \\\"{x:920,y:697,t:1526918869474};\\\", \\\"{x:920,y:696,t:1526918869498};\\\", \\\"{x:920,y:695,t:1526918869509};\\\", \\\"{x:920,y:694,t:1526918869524};\\\", \\\"{x:921,y:694,t:1526918869542};\\\", \\\"{x:921,y:693,t:1526918869570};\\\", \\\"{x:921,y:692,t:1526918869586};\\\", \\\"{x:921,y:691,t:1526918869602};\\\", \\\"{x:921,y:690,t:1526918869642};\\\", \\\"{x:921,y:689,t:1526918869675};\\\", \\\"{x:921,y:690,t:1526918870083};\\\", \\\"{x:921,y:691,t:1526918870114};\\\", \\\"{x:921,y:692,t:1526918870130};\\\", \\\"{x:921,y:693,t:1526918870142};\\\", \\\"{x:921,y:694,t:1526918870219};\\\", \\\"{x:921,y:695,t:1526918870283};\\\", \\\"{x:921,y:696,t:1526918870298};\\\", \\\"{x:918,y:697,t:1526918882291};\\\", \\\"{x:916,y:698,t:1526918882301};\\\", \\\"{x:910,y:701,t:1526918882318};\\\", \\\"{x:908,y:702,t:1526918882334};\\\", \\\"{x:905,y:703,t:1526918882351};\\\", \\\"{x:898,y:703,t:1526918882367};\\\", \\\"{x:889,y:703,t:1526918882384};\\\", \\\"{x:875,y:702,t:1526918882401};\\\", \\\"{x:825,y:692,t:1526918882418};\\\", \\\"{x:769,y:684,t:1526918882434};\\\", \\\"{x:701,y:670,t:1526918882452};\\\", \\\"{x:648,y:656,t:1526918882468};\\\", \\\"{x:609,y:644,t:1526918882486};\\\", \\\"{x:584,y:641,t:1526918882501};\\\", \\\"{x:568,y:637,t:1526918882517};\\\", \\\"{x:557,y:634,t:1526918882534};\\\", \\\"{x:551,y:633,t:1526918882552};\\\", \\\"{x:547,y:632,t:1526918882568};\\\", \\\"{x:535,y:628,t:1526918882585};\\\", \\\"{x:520,y:623,t:1526918882601};\\\", \\\"{x:512,y:620,t:1526918882618};\\\", \\\"{x:506,y:619,t:1526918882636};\\\", \\\"{x:499,y:615,t:1526918882651};\\\", \\\"{x:497,y:615,t:1526918882668};\\\", \\\"{x:494,y:613,t:1526918882686};\\\", \\\"{x:492,y:611,t:1526918882703};\\\", \\\"{x:487,y:609,t:1526918882718};\\\", \\\"{x:483,y:606,t:1526918882735};\\\", \\\"{x:477,y:603,t:1526918882753};\\\", \\\"{x:472,y:600,t:1526918882770};\\\", \\\"{x:466,y:596,t:1526918882785};\\\", \\\"{x:465,y:595,t:1526918882802};\\\", \\\"{x:462,y:593,t:1526918882819};\\\", \\\"{x:460,y:592,t:1526918882835};\\\", \\\"{x:457,y:591,t:1526918882852};\\\", \\\"{x:455,y:589,t:1526918882869};\\\", \\\"{x:454,y:589,t:1526918882885};\\\", \\\"{x:451,y:587,t:1526918882902};\\\", \\\"{x:449,y:587,t:1526918882919};\\\", \\\"{x:448,y:585,t:1526918882936};\\\", \\\"{x:446,y:585,t:1526918882953};\\\", \\\"{x:443,y:582,t:1526918882969};\\\", \\\"{x:440,y:580,t:1526918882985};\\\", \\\"{x:439,y:580,t:1526918883002};\\\", \\\"{x:437,y:578,t:1526918883018};\\\", \\\"{x:430,y:575,t:1526918883035};\\\", \\\"{x:420,y:570,t:1526918883053};\\\", \\\"{x:415,y:568,t:1526918883069};\\\", \\\"{x:414,y:567,t:1526918883086};\\\", \\\"{x:410,y:567,t:1526918883102};\\\", \\\"{x:409,y:565,t:1526918883120};\\\", \\\"{x:407,y:564,t:1526918883135};\\\", \\\"{x:405,y:564,t:1526918883152};\\\", \\\"{x:404,y:563,t:1526918883169};\\\", \\\"{x:402,y:563,t:1526918883185};\\\", \\\"{x:400,y:562,t:1526918883202};\\\", \\\"{x:400,y:561,t:1526918883220};\\\", \\\"{x:399,y:561,t:1526918883236};\\\", \\\"{x:397,y:561,t:1526918883252};\\\", \\\"{x:397,y:560,t:1526918883270};\\\", \\\"{x:396,y:560,t:1526918883286};\\\", \\\"{x:396,y:558,t:1526918883303};\\\", \\\"{x:396,y:554,t:1526918883319};\\\", \\\"{x:396,y:550,t:1526918883336};\\\", \\\"{x:396,y:547,t:1526918883353};\\\", \\\"{x:396,y:543,t:1526918883371};\\\", \\\"{x:397,y:541,t:1526918883385};\\\", \\\"{x:397,y:539,t:1526918883402};\\\", \\\"{x:398,y:537,t:1526918883420};\\\", \\\"{x:398,y:534,t:1526918883437};\\\", \\\"{x:399,y:532,t:1526918883452};\\\", \\\"{x:399,y:531,t:1526918883469};\\\", \\\"{x:399,y:529,t:1526918883486};\\\", \\\"{x:399,y:528,t:1526918883505};\\\", \\\"{x:399,y:526,t:1526918883529};\\\", \\\"{x:399,y:525,t:1526918883569};\\\", \\\"{x:399,y:524,t:1526918883651};\\\", \\\"{x:398,y:524,t:1526918883658};\\\", \\\"{x:397,y:524,t:1526918883682};\\\", \\\"{x:397,y:523,t:1526918883730};\\\", \\\"{x:398,y:523,t:1526918884361};\\\", \\\"{x:400,y:523,t:1526918884370};\\\", \\\"{x:405,y:527,t:1526918884387};\\\", \\\"{x:408,y:530,t:1526918884404};\\\", \\\"{x:413,y:534,t:1526918884421};\\\", \\\"{x:418,y:537,t:1526918884437};\\\", \\\"{x:423,y:540,t:1526918884454};\\\", \\\"{x:427,y:542,t:1526918884471};\\\", \\\"{x:430,y:543,t:1526918884486};\\\", \\\"{x:432,y:546,t:1526918884504};\\\", \\\"{x:434,y:546,t:1526918884521};\\\", \\\"{x:434,y:547,t:1526918884537};\\\", \\\"{x:436,y:547,t:1526918885194};\\\", \\\"{x:437,y:547,t:1526918885299};\\\", \\\"{x:438,y:548,t:1526918885322};\\\", \\\"{x:439,y:548,t:1526918885690};\\\", \\\"{x:439,y:547,t:1526918885705};\\\", \\\"{x:440,y:546,t:1526918885722};\\\", \\\"{x:440,y:545,t:1526918885738};\\\", \\\"{x:440,y:544,t:1526918885763};\\\", \\\"{x:440,y:542,t:1526918885948};\\\", \\\"{x:440,y:540,t:1526918885955};\\\", \\\"{x:440,y:538,t:1526918885972};\\\", \\\"{x:440,y:536,t:1526918885989};\\\", \\\"{x:440,y:535,t:1526918886018};\\\", \\\"{x:442,y:534,t:1526918893434};\\\", \\\"{x:443,y:534,t:1526918893450};\\\", \\\"{x:444,y:534,t:1526918893462};\\\", \\\"{x:445,y:534,t:1526918893479};\\\", \\\"{x:448,y:535,t:1526918893497};\\\", \\\"{x:452,y:539,t:1526918893513};\\\", \\\"{x:456,y:543,t:1526918893530};\\\", \\\"{x:459,y:546,t:1526918893547};\\\", \\\"{x:460,y:547,t:1526918893562};\\\", \\\"{x:461,y:549,t:1526918893579};\\\", \\\"{x:463,y:550,t:1526918893594};\\\", \\\"{x:464,y:554,t:1526918893611};\\\", \\\"{x:465,y:557,t:1526918893627};\\\", \\\"{x:465,y:560,t:1526918893644};\\\", \\\"{x:466,y:564,t:1526918893661};\\\", \\\"{x:467,y:569,t:1526918893678};\\\", \\\"{x:467,y:572,t:1526918893694};\\\", \\\"{x:468,y:576,t:1526918893711};\\\", \\\"{x:468,y:579,t:1526918893728};\\\", \\\"{x:469,y:585,t:1526918893744};\\\", \\\"{x:469,y:594,t:1526918893761};\\\", \\\"{x:469,y:601,t:1526918893777};\\\", \\\"{x:469,y:608,t:1526918893795};\\\", \\\"{x:469,y:618,t:1526918893812};\\\", \\\"{x:469,y:626,t:1526918893829};\\\", \\\"{x:469,y:633,t:1526918893845};\\\", \\\"{x:469,y:643,t:1526918893861};\\\", \\\"{x:469,y:650,t:1526918893878};\\\", \\\"{x:470,y:655,t:1526918893895};\\\", \\\"{x:471,y:664,t:1526918893911};\\\", \\\"{x:472,y:671,t:1526918893928};\\\", \\\"{x:474,y:684,t:1526918893945};\\\", \\\"{x:475,y:693,t:1526918893961};\\\", \\\"{x:475,y:700,t:1526918893978};\\\", \\\"{x:475,y:706,t:1526918893996};\\\", \\\"{x:475,y:710,t:1526918894011};\\\", \\\"{x:475,y:715,t:1526918894027};\\\", \\\"{x:475,y:717,t:1526918894044};\\\", \\\"{x:475,y:720,t:1526918894061};\\\", \\\"{x:477,y:724,t:1526918894078};\\\", \\\"{x:477,y:727,t:1526918894095};\\\", \\\"{x:477,y:730,t:1526918894111};\\\", \\\"{x:478,y:733,t:1526918894128};\\\", \\\"{x:478,y:732,t:1526918894361};\\\", \\\"{x:477,y:730,t:1526918894377};\\\", \\\"{x:477,y:728,t:1526918894395};\\\", \\\"{x:477,y:727,t:1526918894412};\\\", \\\"{x:477,y:726,t:1526918894428};\\\", \\\"{x:477,y:725,t:1526918894445};\\\", \\\"{x:477,y:724,t:1526918894462};\\\", \\\"{x:477,y:723,t:1526918895593};\\\", \\\"{x:476,y:721,t:1526918896122};\\\", \\\"{x:476,y:720,t:1526918901906};\\\" ] }, { \\\"rt\\\": 27224, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 203358, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:719,t:1526918910322};\\\", \\\"{x:477,y:719,t:1526918910376};\\\", \\\"{x:477,y:718,t:1526918910388};\\\", \\\"{x:478,y:718,t:1526918910489};\\\", \\\"{x:479,y:718,t:1526918910504};\\\", \\\"{x:480,y:717,t:1526918910593};\\\", \\\"{x:480,y:718,t:1526918914219};\\\", \\\"{x:480,y:719,t:1526918914266};\\\", \\\"{x:480,y:720,t:1526918914643};\\\", \\\"{x:481,y:718,t:1526918920491};\\\", \\\"{x:481,y:717,t:1526918920501};\\\", \\\"{x:483,y:711,t:1526918920516};\\\", \\\"{x:484,y:703,t:1526918920533};\\\", \\\"{x:484,y:698,t:1526918920552};\\\", \\\"{x:485,y:691,t:1526918920567};\\\", \\\"{x:485,y:686,t:1526918920583};\\\", \\\"{x:487,y:674,t:1526918920602};\\\", \\\"{x:493,y:662,t:1526918920618};\\\", \\\"{x:499,y:654,t:1526918920635};\\\", \\\"{x:504,y:646,t:1526918920652};\\\", \\\"{x:508,y:639,t:1526918920668};\\\", \\\"{x:513,y:629,t:1526918920685};\\\", \\\"{x:519,y:620,t:1526918920701};\\\", \\\"{x:523,y:609,t:1526918920719};\\\", \\\"{x:527,y:602,t:1526918920735};\\\", \\\"{x:529,y:595,t:1526918920751};\\\", \\\"{x:530,y:592,t:1526918920767};\\\", \\\"{x:530,y:589,t:1526918920785};\\\", \\\"{x:530,y:588,t:1526918920801};\\\", \\\"{x:528,y:582,t:1526918920818};\\\", \\\"{x:521,y:578,t:1526918920836};\\\", \\\"{x:508,y:573,t:1526918920852};\\\", \\\"{x:496,y:569,t:1526918920869};\\\", \\\"{x:481,y:565,t:1526918920885};\\\", \\\"{x:463,y:563,t:1526918920901};\\\", \\\"{x:439,y:560,t:1526918920918};\\\", \\\"{x:414,y:560,t:1526918920935};\\\", \\\"{x:398,y:560,t:1526918920952};\\\", \\\"{x:387,y:560,t:1526918920968};\\\", \\\"{x:380,y:560,t:1526918920985};\\\", \\\"{x:378,y:560,t:1526918921001};\\\", \\\"{x:376,y:560,t:1526918921131};\\\", \\\"{x:375,y:560,t:1526918921139};\\\", \\\"{x:374,y:559,t:1526918921154};\\\", \\\"{x:371,y:558,t:1526918921168};\\\", \\\"{x:366,y:557,t:1526918921185};\\\", \\\"{x:355,y:555,t:1526918921201};\\\", \\\"{x:347,y:555,t:1526918921219};\\\", \\\"{x:342,y:555,t:1526918921235};\\\", \\\"{x:335,y:555,t:1526918921253};\\\", \\\"{x:329,y:555,t:1526918921270};\\\", \\\"{x:320,y:558,t:1526918921285};\\\", \\\"{x:312,y:560,t:1526918921302};\\\", \\\"{x:308,y:561,t:1526918921320};\\\", \\\"{x:304,y:561,t:1526918921336};\\\", \\\"{x:302,y:561,t:1526918921352};\\\", \\\"{x:300,y:562,t:1526918921369};\\\", \\\"{x:290,y:565,t:1526918921386};\\\", \\\"{x:281,y:565,t:1526918921402};\\\", \\\"{x:271,y:565,t:1526918921421};\\\", \\\"{x:261,y:565,t:1526918921436};\\\", \\\"{x:251,y:565,t:1526918921452};\\\", \\\"{x:243,y:565,t:1526918921468};\\\", \\\"{x:229,y:565,t:1526918921485};\\\", \\\"{x:218,y:565,t:1526918921502};\\\", \\\"{x:208,y:565,t:1526918921519};\\\", \\\"{x:202,y:565,t:1526918921535};\\\", \\\"{x:196,y:565,t:1526918921551};\\\", \\\"{x:192,y:565,t:1526918921569};\\\", \\\"{x:191,y:565,t:1526918921585};\\\", \\\"{x:188,y:565,t:1526918921602};\\\", \\\"{x:185,y:564,t:1526918921619};\\\", \\\"{x:181,y:564,t:1526918921635};\\\", \\\"{x:179,y:564,t:1526918921651};\\\", \\\"{x:176,y:564,t:1526918921669};\\\", \\\"{x:175,y:564,t:1526918921686};\\\", \\\"{x:174,y:565,t:1526918921702};\\\", \\\"{x:174,y:570,t:1526918921719};\\\", \\\"{x:174,y:580,t:1526918921736};\\\", \\\"{x:174,y:589,t:1526918921753};\\\", \\\"{x:174,y:600,t:1526918921769};\\\", \\\"{x:174,y:622,t:1526918921787};\\\", \\\"{x:174,y:638,t:1526918921802};\\\", \\\"{x:174,y:647,t:1526918921819};\\\", \\\"{x:176,y:655,t:1526918921836};\\\", \\\"{x:176,y:657,t:1526918921852};\\\", \\\"{x:176,y:658,t:1526918921914};\\\", \\\"{x:175,y:658,t:1526918921954};\\\", \\\"{x:174,y:658,t:1526918922011};\\\", \\\"{x:173,y:658,t:1526918922019};\\\", \\\"{x:172,y:656,t:1526918922036};\\\", \\\"{x:169,y:648,t:1526918922054};\\\", \\\"{x:168,y:644,t:1526918922070};\\\", \\\"{x:166,y:637,t:1526918922086};\\\", \\\"{x:166,y:635,t:1526918922103};\\\", \\\"{x:165,y:635,t:1526918922119};\\\", \\\"{x:165,y:634,t:1526918922136};\\\", \\\"{x:165,y:633,t:1526918922154};\\\", \\\"{x:164,y:632,t:1526918922202};\\\", \\\"{x:164,y:633,t:1526918922458};\\\", \\\"{x:167,y:634,t:1526918922470};\\\", \\\"{x:183,y:639,t:1526918922486};\\\", \\\"{x:206,y:644,t:1526918922503};\\\", \\\"{x:236,y:650,t:1526918922520};\\\", \\\"{x:277,y:660,t:1526918922536};\\\", \\\"{x:330,y:675,t:1526918922553};\\\", \\\"{x:404,y:691,t:1526918922570};\\\", \\\"{x:441,y:698,t:1526918922586};\\\", \\\"{x:467,y:703,t:1526918922604};\\\", \\\"{x:485,y:704,t:1526918922619};\\\", \\\"{x:493,y:704,t:1526918922636};\\\", \\\"{x:495,y:704,t:1526918922653};\\\", \\\"{x:496,y:704,t:1526918922670};\\\", \\\"{x:497,y:704,t:1526918922687};\\\", \\\"{x:499,y:703,t:1526918922703};\\\", \\\"{x:501,y:703,t:1526918922720};\\\", \\\"{x:503,y:703,t:1526918922737};\\\", \\\"{x:504,y:703,t:1526918922754};\\\", \\\"{x:506,y:703,t:1526918922771};\\\", \\\"{x:508,y:703,t:1526918922882};\\\", \\\"{x:508,y:705,t:1526918922915};\\\", \\\"{x:508,y:706,t:1526918922922};\\\", \\\"{x:509,y:707,t:1526918922938};\\\", \\\"{x:510,y:709,t:1526918922962};\\\", \\\"{x:511,y:709,t:1526918923075};\\\", \\\"{x:512,y:710,t:1526918923107};\\\", \\\"{x:513,y:711,t:1526918923371};\\\", \\\"{x:514,y:712,t:1526918923411};\\\", \\\"{x:514,y:713,t:1526918924386};\\\", \\\"{x:515,y:713,t:1526918925883};\\\", \\\"{x:516,y:713,t:1526918925890};\\\", \\\"{x:517,y:712,t:1526918925906};\\\", \\\"{x:518,y:712,t:1526918925922};\\\", \\\"{x:519,y:712,t:1526918925946};\\\", \\\"{x:520,y:712,t:1526918925956};\\\", \\\"{x:521,y:711,t:1526918925973};\\\", \\\"{x:522,y:711,t:1526918925989};\\\", \\\"{x:523,y:710,t:1526918926006};\\\", \\\"{x:523,y:709,t:1526918926026};\\\" ] }, { \\\"rt\\\": 39359, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 243967, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -A -Z -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:706,t:1526918938083};\\\", \\\"{x:523,y:705,t:1526918938097};\\\", \\\"{x:523,y:702,t:1526918938114};\\\", \\\"{x:523,y:698,t:1526918938132};\\\", \\\"{x:523,y:694,t:1526918938147};\\\", \\\"{x:523,y:692,t:1526918938165};\\\", \\\"{x:523,y:691,t:1526918939882};\\\", \\\"{x:523,y:690,t:1526918939979};\\\", \\\"{x:523,y:689,t:1526918940171};\\\", \\\"{x:524,y:688,t:1526918940186};\\\", \\\"{x:524,y:687,t:1526918940385};\\\", \\\"{x:524,y:686,t:1526918940473};\\\", \\\"{x:524,y:685,t:1526918940699};\\\", \\\"{x:524,y:684,t:1526918940730};\\\", \\\"{x:524,y:683,t:1526918940746};\\\", \\\"{x:524,y:681,t:1526918941130};\\\", \\\"{x:524,y:680,t:1526918941154};\\\", \\\"{x:524,y:679,t:1526918941882};\\\", \\\"{x:524,y:678,t:1526918941979};\\\", \\\"{x:525,y:677,t:1526918941987};\\\", \\\"{x:525,y:676,t:1526918942362};\\\", \\\"{x:526,y:675,t:1526918942929};\\\", \\\"{x:527,y:675,t:1526918942945};\\\", \\\"{x:527,y:674,t:1526918942977};\\\", \\\"{x:527,y:673,t:1526918942987};\\\", \\\"{x:527,y:672,t:1526918943049};\\\", \\\"{x:527,y:671,t:1526918943218};\\\", \\\"{x:526,y:655,t:1526918945851};\\\", \\\"{x:533,y:627,t:1526918945860};\\\", \\\"{x:546,y:592,t:1526918945875};\\\", \\\"{x:550,y:585,t:1526918945891};\\\", \\\"{x:550,y:583,t:1526918945913};\\\", \\\"{x:552,y:581,t:1526918945922};\\\", \\\"{x:555,y:570,t:1526918945940};\\\", \\\"{x:556,y:565,t:1526918945955};\\\", \\\"{x:556,y:567,t:1526918946609};\\\", \\\"{x:559,y:568,t:1526918947259};\\\", \\\"{x:566,y:575,t:1526918947267};\\\", \\\"{x:577,y:586,t:1526918947279};\\\", \\\"{x:602,y:607,t:1526918947290};\\\", \\\"{x:637,y:634,t:1526918947308};\\\", \\\"{x:678,y:662,t:1526918947323};\\\", \\\"{x:722,y:687,t:1526918947340};\\\", \\\"{x:750,y:701,t:1526918947356};\\\", \\\"{x:778,y:713,t:1526918947373};\\\", \\\"{x:807,y:725,t:1526918947389};\\\", \\\"{x:840,y:744,t:1526918947406};\\\", \\\"{x:866,y:760,t:1526918947423};\\\", \\\"{x:892,y:772,t:1526918947440};\\\", \\\"{x:914,y:783,t:1526918947456};\\\", \\\"{x:940,y:797,t:1526918947473};\\\", \\\"{x:956,y:804,t:1526918947490};\\\", \\\"{x:976,y:811,t:1526918947506};\\\", \\\"{x:990,y:814,t:1526918947524};\\\", \\\"{x:1002,y:819,t:1526918947540};\\\", \\\"{x:1010,y:823,t:1526918947557};\\\", \\\"{x:1021,y:828,t:1526918947573};\\\", \\\"{x:1034,y:833,t:1526918947590};\\\", \\\"{x:1051,y:834,t:1526918947607};\\\", \\\"{x:1069,y:837,t:1526918947623};\\\", \\\"{x:1091,y:842,t:1526918947640};\\\", \\\"{x:1110,y:844,t:1526918947657};\\\", \\\"{x:1118,y:844,t:1526918947673};\\\", \\\"{x:1123,y:844,t:1526918947690};\\\", \\\"{x:1125,y:842,t:1526918947708};\\\", \\\"{x:1127,y:840,t:1526918947723};\\\", \\\"{x:1131,y:835,t:1526918947741};\\\", \\\"{x:1135,y:832,t:1526918947757};\\\", \\\"{x:1141,y:828,t:1526918947773};\\\", \\\"{x:1145,y:827,t:1526918947790};\\\", \\\"{x:1151,y:824,t:1526918947807};\\\", \\\"{x:1159,y:823,t:1526918947824};\\\", \\\"{x:1171,y:822,t:1526918947841};\\\", \\\"{x:1185,y:822,t:1526918947857};\\\", \\\"{x:1199,y:822,t:1526918947874};\\\", \\\"{x:1208,y:825,t:1526918947890};\\\", \\\"{x:1219,y:829,t:1526918947910};\\\", \\\"{x:1228,y:831,t:1526918947924};\\\", \\\"{x:1232,y:832,t:1526918947940};\\\", \\\"{x:1234,y:832,t:1526918947958};\\\", \\\"{x:1235,y:832,t:1526918947977};\\\", \\\"{x:1235,y:831,t:1526918948074};\\\", \\\"{x:1234,y:831,t:1526918948123};\\\", \\\"{x:1232,y:831,t:1526918948130};\\\", \\\"{x:1230,y:831,t:1526918948141};\\\", \\\"{x:1223,y:834,t:1526918948158};\\\", \\\"{x:1218,y:834,t:1526918948175};\\\", \\\"{x:1215,y:834,t:1526918948190};\\\", \\\"{x:1213,y:834,t:1526918948207};\\\", \\\"{x:1212,y:834,t:1526918948225};\\\", \\\"{x:1210,y:834,t:1526918948242};\\\", \\\"{x:1209,y:834,t:1526918948258};\\\", \\\"{x:1210,y:833,t:1526918948466};\\\", \\\"{x:1211,y:832,t:1526918948474};\\\", \\\"{x:1213,y:831,t:1526918948497};\\\", \\\"{x:1213,y:830,t:1526918948514};\\\", \\\"{x:1214,y:830,t:1526918948546};\\\", \\\"{x:1215,y:830,t:1526918948573};\\\", \\\"{x:1216,y:830,t:1526918948594};\\\", \\\"{x:1217,y:829,t:1526918948610};\\\", \\\"{x:1218,y:829,t:1526918948643};\\\", \\\"{x:1219,y:829,t:1526918948682};\\\", \\\"{x:1221,y:829,t:1526918948723};\\\", \\\"{x:1222,y:829,t:1526918948746};\\\", \\\"{x:1225,y:829,t:1526918948758};\\\", \\\"{x:1227,y:830,t:1526918948775};\\\", \\\"{x:1228,y:830,t:1526918948961};\\\", \\\"{x:1231,y:830,t:1526918948974};\\\", \\\"{x:1233,y:830,t:1526918948991};\\\", \\\"{x:1235,y:830,t:1526918949008};\\\", \\\"{x:1238,y:830,t:1526918949024};\\\", \\\"{x:1246,y:829,t:1526918949042};\\\", \\\"{x:1250,y:829,t:1526918949058};\\\", \\\"{x:1254,y:829,t:1526918949075};\\\", \\\"{x:1256,y:828,t:1526918949091};\\\", \\\"{x:1257,y:827,t:1526918949108};\\\", \\\"{x:1259,y:827,t:1526918949125};\\\", \\\"{x:1260,y:826,t:1526918949142};\\\", \\\"{x:1265,y:826,t:1526918949158};\\\", \\\"{x:1270,y:824,t:1526918949175};\\\", \\\"{x:1276,y:822,t:1526918949191};\\\", \\\"{x:1282,y:820,t:1526918949208};\\\", \\\"{x:1286,y:819,t:1526918949226};\\\", \\\"{x:1288,y:819,t:1526918949242};\\\", \\\"{x:1293,y:818,t:1526918949259};\\\", \\\"{x:1297,y:818,t:1526918949275};\\\", \\\"{x:1301,y:816,t:1526918949292};\\\", \\\"{x:1304,y:815,t:1526918949309};\\\", \\\"{x:1306,y:815,t:1526918949325};\\\", \\\"{x:1307,y:815,t:1526918949342};\\\", \\\"{x:1307,y:814,t:1526918949358};\\\", \\\"{x:1310,y:814,t:1526918949375};\\\", \\\"{x:1311,y:813,t:1526918949392};\\\", \\\"{x:1316,y:813,t:1526918949409};\\\", \\\"{x:1321,y:812,t:1526918949426};\\\", \\\"{x:1324,y:812,t:1526918949442};\\\", \\\"{x:1326,y:812,t:1526918949498};\\\", \\\"{x:1327,y:812,t:1526918949509};\\\", \\\"{x:1329,y:812,t:1526918949526};\\\", \\\"{x:1331,y:813,t:1526918949541};\\\", \\\"{x:1332,y:814,t:1526918949558};\\\", \\\"{x:1333,y:814,t:1526918949578};\\\", \\\"{x:1333,y:815,t:1526918949594};\\\", \\\"{x:1333,y:816,t:1526918949609};\\\", \\\"{x:1334,y:819,t:1526918949627};\\\", \\\"{x:1334,y:820,t:1526918949642};\\\", \\\"{x:1334,y:821,t:1526918949659};\\\", \\\"{x:1335,y:823,t:1526918949675};\\\", \\\"{x:1335,y:825,t:1526918949692};\\\", \\\"{x:1336,y:826,t:1526918949709};\\\", \\\"{x:1337,y:827,t:1526918949726};\\\", \\\"{x:1338,y:828,t:1526918949742};\\\", \\\"{x:1339,y:829,t:1526918949758};\\\", \\\"{x:1339,y:830,t:1526918949776};\\\", \\\"{x:1341,y:832,t:1526918949811};\\\", \\\"{x:1342,y:835,t:1526918949835};\\\", \\\"{x:1342,y:837,t:1526918949850};\\\", \\\"{x:1343,y:838,t:1526918949859};\\\", \\\"{x:1344,y:842,t:1526918949876};\\\", \\\"{x:1345,y:845,t:1526918949892};\\\", \\\"{x:1347,y:849,t:1526918949909};\\\", \\\"{x:1347,y:854,t:1526918949925};\\\", \\\"{x:1347,y:860,t:1526918949942};\\\", \\\"{x:1348,y:868,t:1526918949958};\\\", \\\"{x:1351,y:873,t:1526918949975};\\\", \\\"{x:1352,y:880,t:1526918949993};\\\", \\\"{x:1353,y:884,t:1526918950009};\\\", \\\"{x:1355,y:889,t:1526918950026};\\\", \\\"{x:1355,y:892,t:1526918950042};\\\", \\\"{x:1356,y:897,t:1526918950059};\\\", \\\"{x:1356,y:900,t:1526918950075};\\\", \\\"{x:1357,y:902,t:1526918950093};\\\", \\\"{x:1357,y:906,t:1526918950109};\\\", \\\"{x:1357,y:908,t:1526918950126};\\\", \\\"{x:1357,y:911,t:1526918950142};\\\", \\\"{x:1357,y:912,t:1526918950162};\\\", \\\"{x:1357,y:913,t:1526918950176};\\\", \\\"{x:1357,y:914,t:1526918950193};\\\", \\\"{x:1357,y:916,t:1526918950209};\\\", \\\"{x:1357,y:917,t:1526918950226};\\\", \\\"{x:1356,y:918,t:1526918950243};\\\", \\\"{x:1356,y:919,t:1526918950259};\\\", \\\"{x:1355,y:919,t:1526918950276};\\\", \\\"{x:1353,y:919,t:1526918950298};\\\", \\\"{x:1352,y:919,t:1526918950347};\\\", \\\"{x:1350,y:919,t:1526918950370};\\\", \\\"{x:1350,y:918,t:1526918950378};\\\", \\\"{x:1350,y:916,t:1526918950395};\\\", \\\"{x:1349,y:913,t:1526918950410};\\\", \\\"{x:1349,y:911,t:1526918950427};\\\", \\\"{x:1349,y:909,t:1526918950443};\\\", \\\"{x:1349,y:907,t:1526918950460};\\\", \\\"{x:1349,y:906,t:1526918950476};\\\", \\\"{x:1349,y:905,t:1526918950493};\\\", \\\"{x:1349,y:903,t:1526918950510};\\\", \\\"{x:1349,y:902,t:1526918950526};\\\", \\\"{x:1349,y:901,t:1526918950543};\\\", \\\"{x:1349,y:900,t:1526918950559};\\\", \\\"{x:1349,y:899,t:1526918950641};\\\", \\\"{x:1349,y:898,t:1526918950657};\\\", \\\"{x:1349,y:897,t:1526918950673};\\\", \\\"{x:1349,y:896,t:1526918950705};\\\", \\\"{x:1349,y:895,t:1526918950737};\\\", \\\"{x:1349,y:894,t:1526918950745};\\\", \\\"{x:1345,y:892,t:1526918951362};\\\", \\\"{x:1340,y:891,t:1526918951378};\\\", \\\"{x:1320,y:884,t:1526918951394};\\\", \\\"{x:1299,y:879,t:1526918951410};\\\", \\\"{x:1281,y:873,t:1526918951426};\\\", \\\"{x:1265,y:868,t:1526918951444};\\\", \\\"{x:1256,y:865,t:1526918951459};\\\", \\\"{x:1250,y:864,t:1526918951477};\\\", \\\"{x:1245,y:862,t:1526918951493};\\\", \\\"{x:1241,y:861,t:1526918951510};\\\", \\\"{x:1235,y:859,t:1526918951526};\\\", \\\"{x:1229,y:856,t:1526918951544};\\\", \\\"{x:1225,y:854,t:1526918951560};\\\", \\\"{x:1223,y:853,t:1526918951577};\\\", \\\"{x:1222,y:853,t:1526918951602};\\\", \\\"{x:1221,y:852,t:1526918951610};\\\", \\\"{x:1221,y:850,t:1526918951642};\\\", \\\"{x:1220,y:849,t:1526918951658};\\\", \\\"{x:1220,y:848,t:1526918951666};\\\", \\\"{x:1219,y:847,t:1526918951677};\\\", \\\"{x:1218,y:846,t:1526918951698};\\\", \\\"{x:1218,y:845,t:1526918951714};\\\", \\\"{x:1218,y:843,t:1526918951727};\\\", \\\"{x:1218,y:842,t:1526918951743};\\\", \\\"{x:1218,y:841,t:1526918951759};\\\", \\\"{x:1218,y:839,t:1526918951777};\\\", \\\"{x:1218,y:838,t:1526918951802};\\\", \\\"{x:1218,y:837,t:1526918951809};\\\", \\\"{x:1218,y:836,t:1526918951834};\\\", \\\"{x:1218,y:835,t:1526918952059};\\\", \\\"{x:1218,y:834,t:1526918952090};\\\", \\\"{x:1218,y:833,t:1526918952218};\\\", \\\"{x:1218,y:832,t:1526918952250};\\\", \\\"{x:1218,y:831,t:1526918952394};\\\", \\\"{x:1218,y:830,t:1526918952466};\\\", \\\"{x:1217,y:830,t:1526918957482};\\\", \\\"{x:1217,y:829,t:1526918957506};\\\", \\\"{x:1216,y:829,t:1526918957572};\\\", \\\"{x:1214,y:828,t:1526918971409};\\\", \\\"{x:1208,y:828,t:1526918971417};\\\", \\\"{x:1188,y:825,t:1526918971433};\\\", \\\"{x:1157,y:819,t:1526918971448};\\\", \\\"{x:1120,y:813,t:1526918971465};\\\", \\\"{x:1085,y:807,t:1526918971482};\\\", \\\"{x:1062,y:806,t:1526918971500};\\\", \\\"{x:1041,y:801,t:1526918971515};\\\", \\\"{x:1023,y:801,t:1526918971532};\\\", \\\"{x:1005,y:800,t:1526918971549};\\\", \\\"{x:989,y:798,t:1526918971565};\\\", \\\"{x:972,y:796,t:1526918971582};\\\", \\\"{x:956,y:795,t:1526918971600};\\\", \\\"{x:935,y:792,t:1526918971615};\\\", \\\"{x:910,y:790,t:1526918971632};\\\", \\\"{x:893,y:790,t:1526918971648};\\\", \\\"{x:881,y:790,t:1526918971665};\\\", \\\"{x:867,y:790,t:1526918971682};\\\", \\\"{x:849,y:790,t:1526918971699};\\\", \\\"{x:834,y:790,t:1526918971716};\\\", \\\"{x:818,y:790,t:1526918971732};\\\", \\\"{x:801,y:790,t:1526918971749};\\\", \\\"{x:789,y:790,t:1526918971766};\\\", \\\"{x:779,y:790,t:1526918971783};\\\", \\\"{x:771,y:790,t:1526918971799};\\\", \\\"{x:758,y:790,t:1526918971817};\\\", \\\"{x:753,y:790,t:1526918971832};\\\", \\\"{x:748,y:790,t:1526918971849};\\\", \\\"{x:745,y:788,t:1526918971866};\\\", \\\"{x:742,y:788,t:1526918971882};\\\", \\\"{x:736,y:786,t:1526918971899};\\\", \\\"{x:727,y:786,t:1526918971916};\\\", \\\"{x:727,y:784,t:1526918971932};\\\", \\\"{x:725,y:784,t:1526918972401};\\\", \\\"{x:721,y:784,t:1526918972416};\\\", \\\"{x:709,y:784,t:1526918972433};\\\", \\\"{x:697,y:782,t:1526918972449};\\\", \\\"{x:688,y:781,t:1526918972466};\\\", \\\"{x:681,y:779,t:1526918972484};\\\", \\\"{x:675,y:777,t:1526918972499};\\\", \\\"{x:662,y:773,t:1526918972516};\\\", \\\"{x:645,y:770,t:1526918972533};\\\", \\\"{x:627,y:765,t:1526918972549};\\\", \\\"{x:605,y:758,t:1526918972567};\\\", \\\"{x:586,y:751,t:1526918972584};\\\", \\\"{x:567,y:745,t:1526918972600};\\\", \\\"{x:539,y:735,t:1526918972618};\\\", \\\"{x:519,y:729,t:1526918972633};\\\", \\\"{x:502,y:724,t:1526918972649};\\\", \\\"{x:482,y:717,t:1526918972667};\\\", \\\"{x:465,y:710,t:1526918972683};\\\", \\\"{x:444,y:702,t:1526918972700};\\\", \\\"{x:424,y:695,t:1526918972717};\\\", \\\"{x:407,y:687,t:1526918972735};\\\", \\\"{x:391,y:680,t:1526918972750};\\\", \\\"{x:370,y:671,t:1526918972768};\\\", \\\"{x:357,y:667,t:1526918972785};\\\", \\\"{x:348,y:665,t:1526918972801};\\\", \\\"{x:331,y:660,t:1526918972818};\\\", \\\"{x:319,y:656,t:1526918972835};\\\", \\\"{x:305,y:652,t:1526918972851};\\\", \\\"{x:291,y:648,t:1526918972868};\\\", \\\"{x:273,y:641,t:1526918972885};\\\", \\\"{x:258,y:636,t:1526918972901};\\\", \\\"{x:246,y:633,t:1526918972918};\\\", \\\"{x:236,y:630,t:1526918972934};\\\", \\\"{x:221,y:628,t:1526918972952};\\\", \\\"{x:212,y:626,t:1526918972967};\\\", \\\"{x:202,y:624,t:1526918972985};\\\", \\\"{x:193,y:622,t:1526918973002};\\\", \\\"{x:185,y:619,t:1526918973018};\\\", \\\"{x:175,y:616,t:1526918973035};\\\", \\\"{x:172,y:615,t:1526918973052};\\\", \\\"{x:170,y:614,t:1526918973069};\\\", \\\"{x:170,y:613,t:1526918973128};\\\", \\\"{x:170,y:612,t:1526918973146};\\\", \\\"{x:170,y:609,t:1526918973151};\\\", \\\"{x:176,y:604,t:1526918973168};\\\", \\\"{x:187,y:600,t:1526918973185};\\\", \\\"{x:205,y:595,t:1526918973202};\\\", \\\"{x:228,y:589,t:1526918973218};\\\", \\\"{x:254,y:585,t:1526918973235};\\\", \\\"{x:272,y:582,t:1526918973251};\\\", \\\"{x:276,y:580,t:1526918973270};\\\", \\\"{x:275,y:580,t:1526918973319};\\\", \\\"{x:268,y:580,t:1526918973335};\\\", \\\"{x:242,y:580,t:1526918973352};\\\", \\\"{x:226,y:579,t:1526918973368};\\\", \\\"{x:212,y:579,t:1526918973385};\\\", \\\"{x:202,y:578,t:1526918973402};\\\", \\\"{x:197,y:578,t:1526918973419};\\\", \\\"{x:192,y:578,t:1526918973435};\\\", \\\"{x:190,y:578,t:1526918973452};\\\", \\\"{x:186,y:578,t:1526918973469};\\\", \\\"{x:184,y:578,t:1526918973485};\\\", \\\"{x:180,y:578,t:1526918973502};\\\", \\\"{x:174,y:576,t:1526918973519};\\\", \\\"{x:168,y:575,t:1526918973535};\\\", \\\"{x:162,y:572,t:1526918973554};\\\", \\\"{x:160,y:572,t:1526918973568};\\\", \\\"{x:157,y:570,t:1526918973585};\\\", \\\"{x:155,y:568,t:1526918973602};\\\", \\\"{x:153,y:567,t:1526918973619};\\\", \\\"{x:151,y:566,t:1526918973634};\\\", \\\"{x:150,y:565,t:1526918973652};\\\", \\\"{x:151,y:565,t:1526918973888};\\\", \\\"{x:154,y:567,t:1526918973901};\\\", \\\"{x:163,y:574,t:1526918973919};\\\", \\\"{x:184,y:585,t:1526918973937};\\\", \\\"{x:204,y:594,t:1526918973953};\\\", \\\"{x:227,y:604,t:1526918973969};\\\", \\\"{x:247,y:613,t:1526918973987};\\\", \\\"{x:272,y:626,t:1526918974003};\\\", \\\"{x:311,y:641,t:1526918974019};\\\", \\\"{x:350,y:659,t:1526918974037};\\\", \\\"{x:384,y:675,t:1526918974052};\\\", \\\"{x:406,y:687,t:1526918974069};\\\", \\\"{x:419,y:695,t:1526918974085};\\\", \\\"{x:426,y:695,t:1526918974102};\\\", \\\"{x:429,y:696,t:1526918974119};\\\", \\\"{x:430,y:697,t:1526918974136};\\\", \\\"{x:432,y:698,t:1526918974152};\\\", \\\"{x:434,y:699,t:1526918974169};\\\", \\\"{x:439,y:703,t:1526918974186};\\\", \\\"{x:444,y:704,t:1526918974203};\\\", \\\"{x:447,y:706,t:1526918974220};\\\", \\\"{x:450,y:706,t:1526918974236};\\\", \\\"{x:451,y:706,t:1526918974253};\\\", \\\"{x:454,y:706,t:1526918974269};\\\", \\\"{x:457,y:706,t:1526918974286};\\\", \\\"{x:463,y:706,t:1526918974302};\\\", \\\"{x:469,y:706,t:1526918974318};\\\", \\\"{x:482,y:712,t:1526918974336};\\\", \\\"{x:487,y:713,t:1526918974353};\\\", \\\"{x:490,y:714,t:1526918974368};\\\", \\\"{x:492,y:714,t:1526918974392};\\\", \\\"{x:492,y:715,t:1526918974408};\\\", \\\"{x:494,y:715,t:1526918974419};\\\", \\\"{x:494,y:716,t:1526918974436};\\\", \\\"{x:495,y:716,t:1526918974453};\\\" ] }, { \\\"rt\\\": 67313, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 312511, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-03 PM-Z -Z -O -F -01 PM-04 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:716,t:1526918979856};\\\", \\\"{x:499,y:716,t:1526918979864};\\\", \\\"{x:501,y:716,t:1526918979881};\\\", \\\"{x:503,y:716,t:1526918979894};\\\", \\\"{x:505,y:717,t:1526918979911};\\\", \\\"{x:506,y:718,t:1526918979929};\\\", \\\"{x:506,y:719,t:1526918980817};\\\", \\\"{x:512,y:724,t:1526918980830};\\\", \\\"{x:534,y:740,t:1526918980848};\\\", \\\"{x:559,y:753,t:1526918980863};\\\", \\\"{x:585,y:765,t:1526918980880};\\\", \\\"{x:592,y:768,t:1526918980891};\\\", \\\"{x:598,y:771,t:1526918980908};\\\", \\\"{x:604,y:772,t:1526918980924};\\\", \\\"{x:609,y:773,t:1526918980941};\\\", \\\"{x:619,y:776,t:1526918980958};\\\", \\\"{x:632,y:780,t:1526918980974};\\\", \\\"{x:648,y:787,t:1526918980991};\\\", \\\"{x:675,y:796,t:1526918981008};\\\", \\\"{x:698,y:803,t:1526918981025};\\\", \\\"{x:727,y:813,t:1526918981041};\\\", \\\"{x:752,y:820,t:1526918981058};\\\", \\\"{x:772,y:827,t:1526918981075};\\\", \\\"{x:788,y:832,t:1526918981091};\\\", \\\"{x:796,y:833,t:1526918981108};\\\", \\\"{x:799,y:833,t:1526918981125};\\\", \\\"{x:800,y:834,t:1526918981141};\\\", \\\"{x:801,y:834,t:1526918981465};\\\", \\\"{x:801,y:833,t:1526918981513};\\\", \\\"{x:801,y:832,t:1526918981528};\\\", \\\"{x:801,y:831,t:1526918981616};\\\", \\\"{x:802,y:831,t:1526918981713};\\\", \\\"{x:803,y:831,t:1526918981725};\\\", \\\"{x:812,y:831,t:1526918981742};\\\", \\\"{x:826,y:831,t:1526918981759};\\\", \\\"{x:861,y:836,t:1526918981776};\\\", \\\"{x:890,y:842,t:1526918981791};\\\", \\\"{x:921,y:847,t:1526918981808};\\\", \\\"{x:961,y:853,t:1526918981825};\\\", \\\"{x:1003,y:859,t:1526918981843};\\\", \\\"{x:1053,y:865,t:1526918981859};\\\", \\\"{x:1098,y:873,t:1526918981875};\\\", \\\"{x:1135,y:879,t:1526918981892};\\\", \\\"{x:1182,y:884,t:1526918981908};\\\", \\\"{x:1232,y:890,t:1526918981925};\\\", \\\"{x:1277,y:897,t:1526918981942};\\\", \\\"{x:1309,y:902,t:1526918981958};\\\", \\\"{x:1342,y:907,t:1526918981975};\\\", \\\"{x:1388,y:914,t:1526918981991};\\\", \\\"{x:1419,y:923,t:1526918982010};\\\", \\\"{x:1457,y:937,t:1526918982025};\\\", \\\"{x:1499,y:950,t:1526918982042};\\\", \\\"{x:1546,y:969,t:1526918982060};\\\", \\\"{x:1575,y:980,t:1526918982076};\\\", \\\"{x:1606,y:990,t:1526918982092};\\\", \\\"{x:1633,y:998,t:1526918982109};\\\", \\\"{x:1659,y:1000,t:1526918982126};\\\", \\\"{x:1675,y:999,t:1526918982142};\\\", \\\"{x:1680,y:995,t:1526918982159};\\\", \\\"{x:1680,y:994,t:1526918982529};\\\", \\\"{x:1679,y:993,t:1526918982545};\\\", \\\"{x:1678,y:993,t:1526918982560};\\\", \\\"{x:1675,y:993,t:1526918982576};\\\", \\\"{x:1673,y:992,t:1526918982593};\\\", \\\"{x:1672,y:992,t:1526918982610};\\\", \\\"{x:1671,y:992,t:1526918982627};\\\", \\\"{x:1670,y:992,t:1526918982643};\\\", \\\"{x:1668,y:992,t:1526918982660};\\\", \\\"{x:1666,y:992,t:1526918982677};\\\", \\\"{x:1663,y:991,t:1526918982693};\\\", \\\"{x:1659,y:990,t:1526918982709};\\\", \\\"{x:1657,y:989,t:1526918982726};\\\", \\\"{x:1653,y:989,t:1526918982743};\\\", \\\"{x:1650,y:988,t:1526918982760};\\\", \\\"{x:1642,y:987,t:1526918982776};\\\", \\\"{x:1639,y:987,t:1526918982793};\\\", \\\"{x:1634,y:986,t:1526918982810};\\\", \\\"{x:1630,y:985,t:1526918982827};\\\", \\\"{x:1627,y:984,t:1526918982844};\\\", \\\"{x:1624,y:983,t:1526918982860};\\\", \\\"{x:1621,y:982,t:1526918982877};\\\", \\\"{x:1620,y:981,t:1526918982896};\\\", \\\"{x:1619,y:981,t:1526918982910};\\\", \\\"{x:1618,y:980,t:1526918982926};\\\", \\\"{x:1616,y:979,t:1526918982952};\\\", \\\"{x:1615,y:979,t:1526918983073};\\\", \\\"{x:1614,y:979,t:1526918983129};\\\", \\\"{x:1612,y:979,t:1526918983961};\\\", \\\"{x:1611,y:979,t:1526918984097};\\\", \\\"{x:1610,y:979,t:1526918984153};\\\", \\\"{x:1608,y:979,t:1526918984168};\\\", \\\"{x:1606,y:980,t:1526918984192};\\\", \\\"{x:1605,y:980,t:1526918984200};\\\", \\\"{x:1603,y:980,t:1526918984211};\\\", \\\"{x:1599,y:980,t:1526918984228};\\\", \\\"{x:1594,y:980,t:1526918984246};\\\", \\\"{x:1586,y:980,t:1526918984260};\\\", \\\"{x:1578,y:980,t:1526918984278};\\\", \\\"{x:1564,y:980,t:1526918984295};\\\", \\\"{x:1545,y:975,t:1526918984311};\\\", \\\"{x:1506,y:964,t:1526918984329};\\\", \\\"{x:1475,y:959,t:1526918984344};\\\", \\\"{x:1442,y:954,t:1526918984361};\\\", \\\"{x:1415,y:951,t:1526918984378};\\\", \\\"{x:1385,y:942,t:1526918984395};\\\", \\\"{x:1357,y:934,t:1526918984411};\\\", \\\"{x:1339,y:928,t:1526918984427};\\\", \\\"{x:1326,y:924,t:1526918984445};\\\", \\\"{x:1320,y:923,t:1526918984461};\\\", \\\"{x:1316,y:920,t:1526918984478};\\\", \\\"{x:1312,y:919,t:1526918984495};\\\", \\\"{x:1307,y:917,t:1526918984511};\\\", \\\"{x:1301,y:916,t:1526918984528};\\\", \\\"{x:1293,y:912,t:1526918984544};\\\", \\\"{x:1287,y:909,t:1526918984562};\\\", \\\"{x:1281,y:906,t:1526918984577};\\\", \\\"{x:1278,y:904,t:1526918984594};\\\", \\\"{x:1274,y:900,t:1526918984611};\\\", \\\"{x:1272,y:898,t:1526918984627};\\\", \\\"{x:1268,y:894,t:1526918984645};\\\", \\\"{x:1265,y:891,t:1526918984661};\\\", \\\"{x:1262,y:887,t:1526918984678};\\\", \\\"{x:1258,y:883,t:1526918984694};\\\", \\\"{x:1255,y:880,t:1526918984711};\\\", \\\"{x:1254,y:879,t:1526918984728};\\\", \\\"{x:1252,y:876,t:1526918984744};\\\", \\\"{x:1251,y:875,t:1526918984767};\\\", \\\"{x:1250,y:875,t:1526918984784};\\\", \\\"{x:1249,y:874,t:1526918984808};\\\", \\\"{x:1249,y:873,t:1526918984832};\\\", \\\"{x:1248,y:873,t:1526918984848};\\\", \\\"{x:1247,y:872,t:1526918984864};\\\", \\\"{x:1246,y:871,t:1526918984895};\\\", \\\"{x:1246,y:870,t:1526918984928};\\\", \\\"{x:1245,y:869,t:1526918984944};\\\", \\\"{x:1245,y:868,t:1526918984962};\\\", \\\"{x:1244,y:867,t:1526918984978};\\\", \\\"{x:1243,y:866,t:1526918984995};\\\", \\\"{x:1243,y:864,t:1526918985011};\\\", \\\"{x:1242,y:863,t:1526918985032};\\\", \\\"{x:1240,y:862,t:1526918985048};\\\", \\\"{x:1240,y:861,t:1526918985064};\\\", \\\"{x:1240,y:860,t:1526918985079};\\\", \\\"{x:1239,y:859,t:1526918985096};\\\", \\\"{x:1239,y:858,t:1526918985120};\\\", \\\"{x:1237,y:857,t:1526918985137};\\\", \\\"{x:1236,y:856,t:1526918985201};\\\", \\\"{x:1237,y:856,t:1526918985377};\\\", \\\"{x:1241,y:858,t:1526918985384};\\\", \\\"{x:1244,y:858,t:1526918985395};\\\", \\\"{x:1249,y:860,t:1526918985412};\\\", \\\"{x:1255,y:860,t:1526918985429};\\\", \\\"{x:1260,y:862,t:1526918985446};\\\", \\\"{x:1264,y:862,t:1526918985462};\\\", \\\"{x:1268,y:862,t:1526918985479};\\\", \\\"{x:1273,y:862,t:1526918985497};\\\", \\\"{x:1276,y:861,t:1526918985512};\\\", \\\"{x:1281,y:861,t:1526918985529};\\\", \\\"{x:1285,y:861,t:1526918985546};\\\", \\\"{x:1288,y:861,t:1526918985561};\\\", \\\"{x:1289,y:861,t:1526918985704};\\\", \\\"{x:1287,y:861,t:1526918985921};\\\", \\\"{x:1286,y:858,t:1526918985937};\\\", \\\"{x:1285,y:858,t:1526918985946};\\\", \\\"{x:1285,y:855,t:1526918985963};\\\", \\\"{x:1284,y:852,t:1526918985979};\\\", \\\"{x:1284,y:850,t:1526918985996};\\\", \\\"{x:1283,y:848,t:1526918986013};\\\", \\\"{x:1282,y:846,t:1526918986032};\\\", \\\"{x:1282,y:845,t:1526918986048};\\\", \\\"{x:1282,y:844,t:1526918986073};\\\", \\\"{x:1282,y:843,t:1526918986080};\\\", \\\"{x:1282,y:842,t:1526918986128};\\\", \\\"{x:1282,y:841,t:1526918986169};\\\", \\\"{x:1282,y:840,t:1526918986217};\\\", \\\"{x:1282,y:839,t:1526918986264};\\\", \\\"{x:1282,y:838,t:1526918986288};\\\", \\\"{x:1282,y:837,t:1526918986304};\\\", \\\"{x:1282,y:836,t:1526918986553};\\\", \\\"{x:1285,y:836,t:1526918986576};\\\", \\\"{x:1286,y:836,t:1526918986600};\\\", \\\"{x:1288,y:838,t:1526918986616};\\\", \\\"{x:1290,y:840,t:1526918986633};\\\", \\\"{x:1293,y:843,t:1526918986648};\\\", \\\"{x:1294,y:844,t:1526918986663};\\\", \\\"{x:1300,y:851,t:1526918986680};\\\", \\\"{x:1304,y:856,t:1526918986696};\\\", \\\"{x:1309,y:863,t:1526918986712};\\\", \\\"{x:1312,y:869,t:1526918986730};\\\", \\\"{x:1316,y:873,t:1526918986746};\\\", \\\"{x:1318,y:876,t:1526918986762};\\\", \\\"{x:1322,y:880,t:1526918986780};\\\", \\\"{x:1326,y:884,t:1526918986797};\\\", \\\"{x:1329,y:887,t:1526918986812};\\\", \\\"{x:1331,y:888,t:1526918986830};\\\", \\\"{x:1334,y:891,t:1526918986846};\\\", \\\"{x:1336,y:893,t:1526918986863};\\\", \\\"{x:1338,y:894,t:1526918986879};\\\", \\\"{x:1339,y:894,t:1526918986896};\\\", \\\"{x:1340,y:894,t:1526918986928};\\\", \\\"{x:1341,y:895,t:1526918986936};\\\", \\\"{x:1342,y:895,t:1526918986978};\\\", \\\"{x:1343,y:896,t:1526918986997};\\\", \\\"{x:1344,y:896,t:1526918987536};\\\", \\\"{x:1345,y:896,t:1526918987959};\\\", \\\"{x:1346,y:896,t:1526918987975};\\\", \\\"{x:1347,y:895,t:1526918988023};\\\", \\\"{x:1347,y:894,t:1526918988031};\\\", \\\"{x:1348,y:893,t:1526918988047};\\\", \\\"{x:1348,y:891,t:1526918988063};\\\", \\\"{x:1348,y:888,t:1526918988081};\\\", \\\"{x:1348,y:885,t:1526918988097};\\\", \\\"{x:1348,y:882,t:1526918988113};\\\", \\\"{x:1348,y:876,t:1526918988130};\\\", \\\"{x:1347,y:863,t:1526918988147};\\\", \\\"{x:1345,y:847,t:1526918988164};\\\", \\\"{x:1341,y:830,t:1526918988181};\\\", \\\"{x:1336,y:813,t:1526918988198};\\\", \\\"{x:1333,y:799,t:1526918988213};\\\", \\\"{x:1329,y:780,t:1526918988230};\\\", \\\"{x:1325,y:758,t:1526918988248};\\\", \\\"{x:1319,y:739,t:1526918988263};\\\", \\\"{x:1315,y:724,t:1526918988281};\\\", \\\"{x:1313,y:704,t:1526918988298};\\\", \\\"{x:1312,y:689,t:1526918988314};\\\", \\\"{x:1309,y:677,t:1526918988331};\\\", \\\"{x:1308,y:665,t:1526918988348};\\\", \\\"{x:1307,y:656,t:1526918988364};\\\", \\\"{x:1305,y:651,t:1526918988382};\\\", \\\"{x:1305,y:643,t:1526918988398};\\\", \\\"{x:1304,y:637,t:1526918988414};\\\", \\\"{x:1304,y:633,t:1526918988431};\\\", \\\"{x:1304,y:632,t:1526918988448};\\\", \\\"{x:1304,y:630,t:1526918988464};\\\", \\\"{x:1304,y:629,t:1526918988553};\\\", \\\"{x:1305,y:628,t:1526918988601};\\\", \\\"{x:1306,y:628,t:1526918988641};\\\", \\\"{x:1307,y:628,t:1526918988649};\\\", \\\"{x:1308,y:628,t:1526918988681};\\\", \\\"{x:1310,y:628,t:1526918988699};\\\", \\\"{x:1311,y:628,t:1526918988715};\\\", \\\"{x:1313,y:628,t:1526918988731};\\\", \\\"{x:1315,y:629,t:1526918988748};\\\", \\\"{x:1317,y:630,t:1526918988764};\\\", \\\"{x:1318,y:630,t:1526918988784};\\\", \\\"{x:1319,y:630,t:1526918988798};\\\", \\\"{x:1319,y:637,t:1526918996241};\\\", \\\"{x:1321,y:642,t:1526918996255};\\\", \\\"{x:1323,y:647,t:1526918996270};\\\", \\\"{x:1326,y:655,t:1526918996288};\\\", \\\"{x:1331,y:670,t:1526918996305};\\\", \\\"{x:1332,y:677,t:1526918996320};\\\", \\\"{x:1336,y:687,t:1526918996337};\\\", \\\"{x:1340,y:696,t:1526918996355};\\\", \\\"{x:1344,y:709,t:1526918996372};\\\", \\\"{x:1348,y:722,t:1526918996387};\\\", \\\"{x:1351,y:735,t:1526918996404};\\\", \\\"{x:1359,y:750,t:1526918996421};\\\", \\\"{x:1361,y:759,t:1526918996438};\\\", \\\"{x:1366,y:769,t:1526918996454};\\\", \\\"{x:1369,y:774,t:1526918996471};\\\", \\\"{x:1374,y:783,t:1526918996488};\\\", \\\"{x:1378,y:791,t:1526918996504};\\\", \\\"{x:1384,y:799,t:1526918996522};\\\", \\\"{x:1388,y:803,t:1526918996537};\\\", \\\"{x:1391,y:805,t:1526918996554};\\\", \\\"{x:1393,y:805,t:1526918996571};\\\", \\\"{x:1394,y:805,t:1526918996587};\\\", \\\"{x:1395,y:803,t:1526918996604};\\\", \\\"{x:1397,y:798,t:1526918996621};\\\", \\\"{x:1397,y:796,t:1526918996638};\\\", \\\"{x:1397,y:793,t:1526918996655};\\\", \\\"{x:1397,y:789,t:1526918996671};\\\", \\\"{x:1396,y:784,t:1526918996688};\\\", \\\"{x:1395,y:779,t:1526918996704};\\\", \\\"{x:1394,y:776,t:1526918996721};\\\", \\\"{x:1392,y:775,t:1526918996738};\\\", \\\"{x:1392,y:773,t:1526918996755};\\\", \\\"{x:1391,y:772,t:1526918996776};\\\", \\\"{x:1390,y:771,t:1526918996824};\\\", \\\"{x:1390,y:770,t:1526918996840};\\\", \\\"{x:1389,y:769,t:1526918996880};\\\", \\\"{x:1388,y:768,t:1526918997432};\\\", \\\"{x:1388,y:767,t:1526918997440};\\\", \\\"{x:1387,y:767,t:1526918997456};\\\", \\\"{x:1387,y:766,t:1526918997471};\\\", \\\"{x:1386,y:765,t:1526918997584};\\\", \\\"{x:1386,y:764,t:1526918997615};\\\", \\\"{x:1386,y:763,t:1526918999384};\\\", \\\"{x:1386,y:761,t:1526918999392};\\\", \\\"{x:1386,y:759,t:1526918999408};\\\", \\\"{x:1386,y:756,t:1526918999424};\\\", \\\"{x:1386,y:746,t:1526918999440};\\\", \\\"{x:1388,y:728,t:1526918999457};\\\", \\\"{x:1388,y:716,t:1526918999474};\\\", \\\"{x:1388,y:713,t:1526918999491};\\\", \\\"{x:1388,y:712,t:1526918999506};\\\", \\\"{x:1388,y:711,t:1526918999577};\\\", \\\"{x:1390,y:712,t:1526918999590};\\\", \\\"{x:1392,y:722,t:1526918999607};\\\", \\\"{x:1396,y:741,t:1526918999624};\\\", \\\"{x:1402,y:775,t:1526918999640};\\\", \\\"{x:1408,y:793,t:1526918999657};\\\", \\\"{x:1410,y:810,t:1526918999673};\\\", \\\"{x:1413,y:825,t:1526918999691};\\\", \\\"{x:1417,y:844,t:1526918999707};\\\", \\\"{x:1419,y:859,t:1526918999723};\\\", \\\"{x:1420,y:874,t:1526918999740};\\\", \\\"{x:1420,y:885,t:1526918999757};\\\", \\\"{x:1422,y:894,t:1526918999773};\\\", \\\"{x:1423,y:902,t:1526918999790};\\\", \\\"{x:1423,y:909,t:1526918999806};\\\", \\\"{x:1423,y:918,t:1526918999824};\\\", \\\"{x:1423,y:922,t:1526918999840};\\\", \\\"{x:1423,y:929,t:1526918999858};\\\", \\\"{x:1423,y:937,t:1526918999873};\\\", \\\"{x:1423,y:946,t:1526918999891};\\\", \\\"{x:1424,y:956,t:1526918999908};\\\", \\\"{x:1425,y:962,t:1526918999923};\\\", \\\"{x:1426,y:966,t:1526918999940};\\\", \\\"{x:1427,y:971,t:1526918999958};\\\", \\\"{x:1427,y:973,t:1526918999974};\\\", \\\"{x:1427,y:974,t:1526918999990};\\\", \\\"{x:1427,y:975,t:1526919000160};\\\", \\\"{x:1426,y:974,t:1526919000241};\\\", \\\"{x:1426,y:973,t:1526919000257};\\\", \\\"{x:1425,y:972,t:1526919000288};\\\", \\\"{x:1424,y:970,t:1526919000312};\\\", \\\"{x:1423,y:970,t:1526919000392};\\\", \\\"{x:1421,y:970,t:1526919000424};\\\", \\\"{x:1420,y:970,t:1526919000448};\\\", \\\"{x:1419,y:970,t:1526919000464};\\\", \\\"{x:1418,y:970,t:1526919000475};\\\", \\\"{x:1417,y:970,t:1526919000496};\\\", \\\"{x:1416,y:970,t:1526919002008};\\\", \\\"{x:1416,y:968,t:1526919002592};\\\", \\\"{x:1416,y:967,t:1526919004417};\\\", \\\"{x:1418,y:967,t:1526919004440};\\\", \\\"{x:1418,y:966,t:1526919004504};\\\", \\\"{x:1419,y:965,t:1526919006081};\\\", \\\"{x:1420,y:964,t:1526919006457};\\\", \\\"{x:1421,y:964,t:1526919006463};\\\", \\\"{x:1424,y:963,t:1526919006479};\\\", \\\"{x:1430,y:962,t:1526919006496};\\\", \\\"{x:1436,y:962,t:1526919006512};\\\", \\\"{x:1437,y:961,t:1526919006529};\\\", \\\"{x:1438,y:961,t:1526919006546};\\\", \\\"{x:1441,y:960,t:1526919006563};\\\", \\\"{x:1445,y:960,t:1526919006579};\\\", \\\"{x:1450,y:960,t:1526919006595};\\\", \\\"{x:1458,y:960,t:1526919006613};\\\", \\\"{x:1468,y:960,t:1526919006629};\\\", \\\"{x:1474,y:960,t:1526919006646};\\\", \\\"{x:1478,y:960,t:1526919006663};\\\", \\\"{x:1482,y:960,t:1526919006679};\\\", \\\"{x:1489,y:959,t:1526919006697};\\\", \\\"{x:1496,y:957,t:1526919006713};\\\", \\\"{x:1507,y:956,t:1526919006729};\\\", \\\"{x:1522,y:956,t:1526919006746};\\\", \\\"{x:1534,y:956,t:1526919006763};\\\", \\\"{x:1545,y:956,t:1526919006779};\\\", \\\"{x:1554,y:956,t:1526919006796};\\\", \\\"{x:1560,y:956,t:1526919006813};\\\", \\\"{x:1565,y:956,t:1526919006828};\\\", \\\"{x:1572,y:955,t:1526919006845};\\\", \\\"{x:1576,y:955,t:1526919006863};\\\", \\\"{x:1584,y:953,t:1526919006879};\\\", \\\"{x:1588,y:953,t:1526919006896};\\\", \\\"{x:1590,y:953,t:1526919006913};\\\", \\\"{x:1593,y:953,t:1526919006929};\\\", \\\"{x:1595,y:953,t:1526919006946};\\\", \\\"{x:1597,y:953,t:1526919006963};\\\", \\\"{x:1600,y:953,t:1526919006980};\\\", \\\"{x:1604,y:953,t:1526919006995};\\\", \\\"{x:1607,y:954,t:1526919007013};\\\", \\\"{x:1613,y:956,t:1526919007030};\\\", \\\"{x:1616,y:959,t:1526919007045};\\\", \\\"{x:1621,y:963,t:1526919007063};\\\", \\\"{x:1626,y:969,t:1526919007080};\\\", \\\"{x:1628,y:972,t:1526919007096};\\\", \\\"{x:1631,y:974,t:1526919007113};\\\", \\\"{x:1632,y:978,t:1526919007130};\\\", \\\"{x:1633,y:979,t:1526919007146};\\\", \\\"{x:1634,y:980,t:1526919007176};\\\", \\\"{x:1634,y:981,t:1526919007239};\\\", \\\"{x:1633,y:981,t:1526919007320};\\\", \\\"{x:1632,y:981,t:1526919007335};\\\", \\\"{x:1631,y:981,t:1526919007346};\\\", \\\"{x:1630,y:981,t:1526919007362};\\\", \\\"{x:1629,y:981,t:1526919007379};\\\", \\\"{x:1627,y:980,t:1526919007396};\\\", \\\"{x:1627,y:979,t:1526919007415};\\\", \\\"{x:1626,y:978,t:1526919007568};\\\", \\\"{x:1625,y:978,t:1526919007592};\\\", \\\"{x:1624,y:977,t:1526919007616};\\\", \\\"{x:1623,y:975,t:1526919007632};\\\", \\\"{x:1622,y:974,t:1526919007655};\\\", \\\"{x:1622,y:973,t:1526919007672};\\\", \\\"{x:1622,y:972,t:1526919007681};\\\", \\\"{x:1621,y:972,t:1526919007696};\\\", \\\"{x:1621,y:971,t:1526919007720};\\\", \\\"{x:1621,y:970,t:1526919007759};\\\", \\\"{x:1621,y:969,t:1526919007783};\\\", \\\"{x:1621,y:968,t:1526919007817};\\\", \\\"{x:1621,y:967,t:1526919007840};\\\", \\\"{x:1620,y:966,t:1526919007880};\\\", \\\"{x:1620,y:965,t:1526919007936};\\\", \\\"{x:1620,y:964,t:1526919007960};\\\", \\\"{x:1619,y:963,t:1526919007976};\\\", \\\"{x:1619,y:962,t:1526919008024};\\\", \\\"{x:1619,y:961,t:1526919008056};\\\", \\\"{x:1618,y:960,t:1526919008063};\\\", \\\"{x:1618,y:959,t:1526919008088};\\\", \\\"{x:1618,y:958,t:1526919008112};\\\", \\\"{x:1618,y:957,t:1526919008217};\\\", \\\"{x:1617,y:956,t:1526919008449};\\\", \\\"{x:1616,y:954,t:1526919008472};\\\", \\\"{x:1615,y:954,t:1526919014888};\\\", \\\"{x:1611,y:954,t:1526919014902};\\\", \\\"{x:1605,y:956,t:1526919014919};\\\", \\\"{x:1594,y:960,t:1526919014935};\\\", \\\"{x:1579,y:964,t:1526919014952};\\\", \\\"{x:1570,y:967,t:1526919014970};\\\", \\\"{x:1566,y:968,t:1526919014985};\\\", \\\"{x:1560,y:969,t:1526919015002};\\\", \\\"{x:1554,y:969,t:1526919015018};\\\", \\\"{x:1548,y:971,t:1526919015035};\\\", \\\"{x:1542,y:972,t:1526919015051};\\\", \\\"{x:1537,y:972,t:1526919015068};\\\", \\\"{x:1535,y:972,t:1526919015085};\\\", \\\"{x:1534,y:973,t:1526919015101};\\\", \\\"{x:1533,y:973,t:1526919015192};\\\", \\\"{x:1532,y:973,t:1526919015232};\\\", \\\"{x:1531,y:972,t:1526919015624};\\\", \\\"{x:1530,y:971,t:1526919015639};\\\", \\\"{x:1530,y:970,t:1526919016288};\\\", \\\"{x:1530,y:968,t:1526919016304};\\\", \\\"{x:1530,y:966,t:1526919016320};\\\", \\\"{x:1530,y:963,t:1526919016344};\\\", \\\"{x:1530,y:961,t:1526919016353};\\\", \\\"{x:1530,y:955,t:1526919016370};\\\", \\\"{x:1530,y:947,t:1526919016387};\\\", \\\"{x:1530,y:936,t:1526919016403};\\\", \\\"{x:1530,y:925,t:1526919016420};\\\", \\\"{x:1528,y:913,t:1526919016437};\\\", \\\"{x:1526,y:905,t:1526919016453};\\\", \\\"{x:1526,y:901,t:1526919016470};\\\", \\\"{x:1526,y:898,t:1526919016487};\\\", \\\"{x:1525,y:893,t:1526919016503};\\\", \\\"{x:1525,y:888,t:1526919016521};\\\", \\\"{x:1525,y:887,t:1526919016537};\\\", \\\"{x:1525,y:885,t:1526919016560};\\\", \\\"{x:1524,y:885,t:1526919016584};\\\", \\\"{x:1524,y:884,t:1526919016592};\\\", \\\"{x:1524,y:882,t:1526919016607};\\\", \\\"{x:1524,y:880,t:1526919016620};\\\", \\\"{x:1522,y:874,t:1526919016637};\\\", \\\"{x:1522,y:868,t:1526919016654};\\\", \\\"{x:1521,y:859,t:1526919016671};\\\", \\\"{x:1520,y:853,t:1526919016687};\\\", \\\"{x:1517,y:844,t:1526919016703};\\\", \\\"{x:1517,y:841,t:1526919016720};\\\", \\\"{x:1517,y:837,t:1526919016738};\\\", \\\"{x:1517,y:834,t:1526919016754};\\\", \\\"{x:1516,y:826,t:1526919016770};\\\", \\\"{x:1514,y:821,t:1526919016788};\\\", \\\"{x:1513,y:812,t:1526919016804};\\\", \\\"{x:1512,y:804,t:1526919016820};\\\", \\\"{x:1508,y:793,t:1526919016837};\\\", \\\"{x:1507,y:785,t:1526919016855};\\\", \\\"{x:1506,y:778,t:1526919016870};\\\", \\\"{x:1504,y:769,t:1526919016888};\\\", \\\"{x:1503,y:763,t:1526919016904};\\\", \\\"{x:1503,y:760,t:1526919016921};\\\", \\\"{x:1502,y:757,t:1526919016937};\\\", \\\"{x:1499,y:753,t:1526919016955};\\\", \\\"{x:1498,y:749,t:1526919016972};\\\", \\\"{x:1497,y:745,t:1526919016987};\\\", \\\"{x:1495,y:739,t:1526919017004};\\\", \\\"{x:1493,y:732,t:1526919017021};\\\", \\\"{x:1491,y:721,t:1526919017038};\\\", \\\"{x:1488,y:712,t:1526919017054};\\\", \\\"{x:1482,y:693,t:1526919017072};\\\", \\\"{x:1479,y:683,t:1526919017087};\\\", \\\"{x:1473,y:661,t:1526919017103};\\\", \\\"{x:1470,y:637,t:1526919017121};\\\", \\\"{x:1467,y:618,t:1526919017137};\\\", \\\"{x:1465,y:602,t:1526919017154};\\\", \\\"{x:1463,y:584,t:1526919017171};\\\", \\\"{x:1460,y:565,t:1526919017187};\\\", \\\"{x:1456,y:544,t:1526919017203};\\\", \\\"{x:1455,y:524,t:1526919017221};\\\", \\\"{x:1455,y:498,t:1526919017237};\\\", \\\"{x:1454,y:477,t:1526919017253};\\\", \\\"{x:1454,y:454,t:1526919017270};\\\", \\\"{x:1454,y:433,t:1526919017287};\\\", \\\"{x:1454,y:401,t:1526919017303};\\\", \\\"{x:1454,y:378,t:1526919017320};\\\", \\\"{x:1454,y:358,t:1526919017337};\\\", \\\"{x:1454,y:336,t:1526919017353};\\\", \\\"{x:1454,y:314,t:1526919017371};\\\", \\\"{x:1454,y:292,t:1526919017387};\\\", \\\"{x:1454,y:275,t:1526919017404};\\\", \\\"{x:1454,y:253,t:1526919017421};\\\", \\\"{x:1455,y:232,t:1526919017438};\\\", \\\"{x:1458,y:219,t:1526919017454};\\\", \\\"{x:1461,y:209,t:1526919017470};\\\", \\\"{x:1462,y:199,t:1526919017488};\\\", \\\"{x:1463,y:196,t:1526919017504};\\\", \\\"{x:1463,y:194,t:1526919017521};\\\", \\\"{x:1463,y:191,t:1526919017538};\\\", \\\"{x:1464,y:190,t:1526919017554};\\\", \\\"{x:1465,y:189,t:1526919017576};\\\", \\\"{x:1466,y:193,t:1526919017625};\\\", \\\"{x:1467,y:200,t:1526919017638};\\\", \\\"{x:1471,y:214,t:1526919017654};\\\", \\\"{x:1471,y:226,t:1526919017671};\\\", \\\"{x:1471,y:246,t:1526919017688};\\\", \\\"{x:1471,y:260,t:1526919017704};\\\", \\\"{x:1471,y:275,t:1526919017721};\\\", \\\"{x:1471,y:287,t:1526919017738};\\\", \\\"{x:1471,y:300,t:1526919017754};\\\", \\\"{x:1471,y:312,t:1526919017771};\\\", \\\"{x:1471,y:322,t:1526919017788};\\\", \\\"{x:1471,y:331,t:1526919017804};\\\", \\\"{x:1472,y:338,t:1526919017822};\\\", \\\"{x:1474,y:347,t:1526919017838};\\\", \\\"{x:1474,y:354,t:1526919017855};\\\", \\\"{x:1474,y:362,t:1526919017872};\\\", \\\"{x:1474,y:378,t:1526919017888};\\\", \\\"{x:1474,y:392,t:1526919017905};\\\", \\\"{x:1474,y:401,t:1526919017921};\\\", \\\"{x:1474,y:414,t:1526919017938};\\\", \\\"{x:1474,y:425,t:1526919017955};\\\", \\\"{x:1474,y:435,t:1526919017971};\\\", \\\"{x:1474,y:447,t:1526919017988};\\\", \\\"{x:1474,y:461,t:1526919018005};\\\", \\\"{x:1474,y:475,t:1526919018022};\\\", \\\"{x:1474,y:485,t:1526919018038};\\\", \\\"{x:1474,y:494,t:1526919018055};\\\", \\\"{x:1474,y:498,t:1526919018071};\\\", \\\"{x:1474,y:507,t:1526919018088};\\\", \\\"{x:1474,y:513,t:1526919018105};\\\", \\\"{x:1474,y:520,t:1526919018122};\\\", \\\"{x:1474,y:523,t:1526919018138};\\\", \\\"{x:1474,y:527,t:1526919018155};\\\", \\\"{x:1474,y:530,t:1526919018171};\\\", \\\"{x:1474,y:532,t:1526919018189};\\\", \\\"{x:1474,y:535,t:1526919018206};\\\", \\\"{x:1474,y:537,t:1526919018222};\\\", \\\"{x:1474,y:541,t:1526919018238};\\\", \\\"{x:1474,y:544,t:1526919018255};\\\", \\\"{x:1474,y:551,t:1526919018271};\\\", \\\"{x:1474,y:556,t:1526919018288};\\\", \\\"{x:1474,y:563,t:1526919018306};\\\", \\\"{x:1474,y:567,t:1526919018322};\\\", \\\"{x:1473,y:574,t:1526919018339};\\\", \\\"{x:1473,y:583,t:1526919018355};\\\", \\\"{x:1472,y:592,t:1526919018372};\\\", \\\"{x:1472,y:599,t:1526919018388};\\\", \\\"{x:1472,y:605,t:1526919018405};\\\", \\\"{x:1472,y:612,t:1526919018422};\\\", \\\"{x:1472,y:619,t:1526919018438};\\\", \\\"{x:1472,y:623,t:1526919018455};\\\", \\\"{x:1472,y:630,t:1526919018471};\\\", \\\"{x:1472,y:634,t:1526919018488};\\\", \\\"{x:1472,y:638,t:1526919018505};\\\", \\\"{x:1472,y:644,t:1526919018522};\\\", \\\"{x:1472,y:649,t:1526919018538};\\\", \\\"{x:1472,y:654,t:1526919018555};\\\", \\\"{x:1472,y:659,t:1526919018572};\\\", \\\"{x:1472,y:664,t:1526919018588};\\\", \\\"{x:1472,y:669,t:1526919018605};\\\", \\\"{x:1472,y:676,t:1526919018622};\\\", \\\"{x:1472,y:682,t:1526919018638};\\\", \\\"{x:1472,y:692,t:1526919018656};\\\", \\\"{x:1472,y:699,t:1526919018672};\\\", \\\"{x:1472,y:706,t:1526919018689};\\\", \\\"{x:1472,y:712,t:1526919018705};\\\", \\\"{x:1470,y:719,t:1526919018722};\\\", \\\"{x:1470,y:726,t:1526919018740};\\\", \\\"{x:1470,y:735,t:1526919018755};\\\", \\\"{x:1470,y:741,t:1526919018772};\\\", \\\"{x:1470,y:748,t:1526919018789};\\\", \\\"{x:1470,y:755,t:1526919018806};\\\", \\\"{x:1470,y:759,t:1526919018822};\\\", \\\"{x:1470,y:769,t:1526919018840};\\\", \\\"{x:1470,y:771,t:1526919018856};\\\", \\\"{x:1470,y:779,t:1526919018872};\\\", \\\"{x:1470,y:786,t:1526919018889};\\\", \\\"{x:1470,y:790,t:1526919018905};\\\", \\\"{x:1470,y:794,t:1526919018923};\\\", \\\"{x:1470,y:800,t:1526919018939};\\\", \\\"{x:1470,y:803,t:1526919018955};\\\", \\\"{x:1470,y:807,t:1526919018973};\\\", \\\"{x:1470,y:811,t:1526919018989};\\\", \\\"{x:1470,y:815,t:1526919019005};\\\", \\\"{x:1470,y:819,t:1526919019023};\\\", \\\"{x:1470,y:824,t:1526919019040};\\\", \\\"{x:1470,y:826,t:1526919019056};\\\", \\\"{x:1470,y:830,t:1526919019073};\\\", \\\"{x:1470,y:833,t:1526919019089};\\\", \\\"{x:1470,y:836,t:1526919019105};\\\", \\\"{x:1470,y:839,t:1526919019122};\\\", \\\"{x:1470,y:841,t:1526919019139};\\\", \\\"{x:1470,y:843,t:1526919019156};\\\", \\\"{x:1470,y:845,t:1526919019173};\\\", \\\"{x:1470,y:847,t:1526919019189};\\\", \\\"{x:1470,y:849,t:1526919019206};\\\", \\\"{x:1470,y:851,t:1526919019222};\\\", \\\"{x:1470,y:853,t:1526919019240};\\\", \\\"{x:1470,y:855,t:1526919019256};\\\", \\\"{x:1470,y:858,t:1526919019273};\\\", \\\"{x:1470,y:861,t:1526919019290};\\\", \\\"{x:1471,y:863,t:1526919019307};\\\", \\\"{x:1471,y:864,t:1526919019322};\\\", \\\"{x:1471,y:865,t:1526919019344};\\\", \\\"{x:1471,y:866,t:1526919019357};\\\", \\\"{x:1471,y:867,t:1526919019372};\\\", \\\"{x:1471,y:869,t:1526919019390};\\\", \\\"{x:1471,y:870,t:1526919019405};\\\", \\\"{x:1471,y:873,t:1526919019422};\\\", \\\"{x:1473,y:874,t:1526919019438};\\\", \\\"{x:1473,y:876,t:1526919019456};\\\", \\\"{x:1473,y:879,t:1526919019472};\\\", \\\"{x:1473,y:881,t:1526919019489};\\\", \\\"{x:1473,y:883,t:1526919019505};\\\", \\\"{x:1473,y:886,t:1526919019522};\\\", \\\"{x:1474,y:887,t:1526919019538};\\\", \\\"{x:1474,y:890,t:1526919019556};\\\", \\\"{x:1474,y:892,t:1526919019572};\\\", \\\"{x:1474,y:893,t:1526919019589};\\\", \\\"{x:1474,y:895,t:1526919019606};\\\", \\\"{x:1476,y:898,t:1526919019623};\\\", \\\"{x:1476,y:899,t:1526919019639};\\\", \\\"{x:1476,y:901,t:1526919019655};\\\", \\\"{x:1476,y:902,t:1526919019673};\\\", \\\"{x:1476,y:904,t:1526919019689};\\\", \\\"{x:1476,y:905,t:1526919019720};\\\", \\\"{x:1476,y:906,t:1526919019728};\\\", \\\"{x:1476,y:907,t:1526919019744};\\\", \\\"{x:1476,y:908,t:1526919019768};\\\", \\\"{x:1476,y:909,t:1526919019776};\\\", \\\"{x:1476,y:910,t:1526919019792};\\\", \\\"{x:1476,y:911,t:1526919019808};\\\", \\\"{x:1477,y:912,t:1526919019824};\\\", \\\"{x:1477,y:914,t:1526919019839};\\\", \\\"{x:1477,y:915,t:1526919019864};\\\", \\\"{x:1477,y:916,t:1526919019873};\\\", \\\"{x:1477,y:917,t:1526919019889};\\\", \\\"{x:1477,y:918,t:1526919019906};\\\", \\\"{x:1477,y:920,t:1526919019923};\\\", \\\"{x:1477,y:921,t:1526919019939};\\\", \\\"{x:1477,y:923,t:1526919019956};\\\", \\\"{x:1477,y:926,t:1526919019973};\\\", \\\"{x:1477,y:927,t:1526919019989};\\\", \\\"{x:1477,y:928,t:1526919020006};\\\", \\\"{x:1477,y:929,t:1526919020024};\\\", \\\"{x:1477,y:930,t:1526919020040};\\\", \\\"{x:1477,y:931,t:1526919020056};\\\", \\\"{x:1477,y:932,t:1526919020074};\\\", \\\"{x:1477,y:933,t:1526919020090};\\\", \\\"{x:1477,y:934,t:1526919020127};\\\", \\\"{x:1476,y:935,t:1526919020141};\\\", \\\"{x:1476,y:936,t:1526919020156};\\\", \\\"{x:1476,y:937,t:1526919020176};\\\", \\\"{x:1476,y:938,t:1526919020191};\\\", \\\"{x:1476,y:939,t:1526919020207};\\\", \\\"{x:1476,y:940,t:1526919020231};\\\", \\\"{x:1475,y:941,t:1526919020240};\\\", \\\"{x:1475,y:942,t:1526919020280};\\\", \\\"{x:1475,y:943,t:1526919020290};\\\", \\\"{x:1474,y:945,t:1526919020307};\\\", \\\"{x:1474,y:947,t:1526919020368};\\\", \\\"{x:1473,y:948,t:1526919020384};\\\", \\\"{x:1473,y:949,t:1526919020440};\\\", \\\"{x:1473,y:950,t:1526919020464};\\\", \\\"{x:1473,y:951,t:1526919020528};\\\", \\\"{x:1472,y:952,t:1526919020544};\\\", \\\"{x:1472,y:953,t:1526919020576};\\\", \\\"{x:1472,y:954,t:1526919021024};\\\", \\\"{x:1472,y:955,t:1526919021040};\\\", \\\"{x:1472,y:956,t:1526919021057};\\\", \\\"{x:1473,y:957,t:1526919021080};\\\", \\\"{x:1474,y:958,t:1526919021104};\\\", \\\"{x:1474,y:959,t:1526919021127};\\\", \\\"{x:1474,y:960,t:1526919021143};\\\", \\\"{x:1476,y:961,t:1526919021158};\\\", \\\"{x:1476,y:962,t:1526919021174};\\\", \\\"{x:1476,y:963,t:1526919021192};\\\", \\\"{x:1477,y:964,t:1526919021207};\\\", \\\"{x:1477,y:965,t:1526919021225};\\\", \\\"{x:1477,y:966,t:1526919021264};\\\", \\\"{x:1478,y:967,t:1526919021274};\\\", \\\"{x:1478,y:968,t:1526919021344};\\\", \\\"{x:1478,y:969,t:1526919021408};\\\", \\\"{x:1479,y:970,t:1526919021424};\\\", \\\"{x:1479,y:971,t:1526919021442};\\\", \\\"{x:1480,y:972,t:1526919021464};\\\", \\\"{x:1480,y:973,t:1526919021474};\\\", \\\"{x:1480,y:974,t:1526919021492};\\\", \\\"{x:1480,y:976,t:1526919021507};\\\", \\\"{x:1480,y:977,t:1526919021524};\\\", \\\"{x:1478,y:977,t:1526919021752};\\\", \\\"{x:1475,y:977,t:1526919021760};\\\", \\\"{x:1472,y:977,t:1526919021774};\\\", \\\"{x:1449,y:973,t:1526919021792};\\\", \\\"{x:1430,y:967,t:1526919021807};\\\", \\\"{x:1417,y:962,t:1526919021824};\\\", \\\"{x:1396,y:957,t:1526919021841};\\\", \\\"{x:1368,y:950,t:1526919021858};\\\", \\\"{x:1331,y:937,t:1526919021873};\\\", \\\"{x:1293,y:929,t:1526919021890};\\\", \\\"{x:1255,y:922,t:1526919021908};\\\", \\\"{x:1199,y:906,t:1526919021924};\\\", \\\"{x:1141,y:889,t:1526919021941};\\\", \\\"{x:1085,y:873,t:1526919021958};\\\", \\\"{x:1041,y:861,t:1526919021974};\\\", \\\"{x:986,y:843,t:1526919021991};\\\", \\\"{x:958,y:832,t:1526919022008};\\\", \\\"{x:927,y:821,t:1526919022024};\\\", \\\"{x:891,y:806,t:1526919022041};\\\", \\\"{x:859,y:793,t:1526919022058};\\\", \\\"{x:833,y:782,t:1526919022074};\\\", \\\"{x:810,y:772,t:1526919022091};\\\", \\\"{x:773,y:758,t:1526919022108};\\\", \\\"{x:742,y:744,t:1526919022124};\\\", \\\"{x:734,y:738,t:1526919022141};\\\", \\\"{x:733,y:732,t:1526919022158};\\\", \\\"{x:728,y:723,t:1526919022174};\\\", \\\"{x:724,y:715,t:1526919022191};\\\", \\\"{x:723,y:710,t:1526919022207};\\\", \\\"{x:721,y:709,t:1526919022224};\\\", \\\"{x:721,y:707,t:1526919022240};\\\", \\\"{x:718,y:703,t:1526919022258};\\\", \\\"{x:718,y:697,t:1526919022275};\\\", \\\"{x:717,y:688,t:1526919022291};\\\", \\\"{x:714,y:679,t:1526919022308};\\\", \\\"{x:711,y:674,t:1526919022325};\\\", \\\"{x:706,y:669,t:1526919022341};\\\", \\\"{x:700,y:663,t:1526919022358};\\\", \\\"{x:690,y:658,t:1526919022375};\\\", \\\"{x:666,y:649,t:1526919022393};\\\", \\\"{x:648,y:639,t:1526919022407};\\\", \\\"{x:634,y:633,t:1526919022425};\\\", \\\"{x:621,y:625,t:1526919022441};\\\", \\\"{x:614,y:620,t:1526919022458};\\\", \\\"{x:610,y:617,t:1526919022475};\\\", \\\"{x:608,y:614,t:1526919022491};\\\", \\\"{x:607,y:613,t:1526919022509};\\\", \\\"{x:606,y:611,t:1526919022525};\\\", \\\"{x:606,y:607,t:1526919022542};\\\", \\\"{x:605,y:604,t:1526919022559};\\\", \\\"{x:605,y:601,t:1526919022574};\\\", \\\"{x:605,y:600,t:1526919022591};\\\", \\\"{x:605,y:598,t:1526919022607};\\\", \\\"{x:605,y:597,t:1526919022872};\\\", \\\"{x:606,y:597,t:1526919022880};\\\", \\\"{x:607,y:597,t:1526919022903};\\\", \\\"{x:607,y:598,t:1526919022952};\\\", \\\"{x:608,y:599,t:1526919022959};\\\", \\\"{x:608,y:600,t:1526919022974};\\\", \\\"{x:610,y:601,t:1526919023416};\\\", \\\"{x:613,y:604,t:1526919023426};\\\", \\\"{x:616,y:608,t:1526919023443};\\\", \\\"{x:623,y:612,t:1526919023460};\\\", \\\"{x:633,y:620,t:1526919023476};\\\", \\\"{x:639,y:627,t:1526919023493};\\\", \\\"{x:648,y:636,t:1526919023508};\\\", \\\"{x:657,y:644,t:1526919023525};\\\", \\\"{x:674,y:665,t:1526919023543};\\\", \\\"{x:687,y:681,t:1526919023559};\\\", \\\"{x:701,y:699,t:1526919023575};\\\", \\\"{x:716,y:715,t:1526919023593};\\\", \\\"{x:727,y:729,t:1526919023609};\\\", \\\"{x:737,y:741,t:1526919023626};\\\", \\\"{x:743,y:751,t:1526919023643};\\\", \\\"{x:751,y:762,t:1526919023660};\\\", \\\"{x:757,y:773,t:1526919023675};\\\", \\\"{x:764,y:787,t:1526919023693};\\\", \\\"{x:772,y:799,t:1526919023710};\\\", \\\"{x:783,y:815,t:1526919023726};\\\", \\\"{x:794,y:834,t:1526919023743};\\\", \\\"{x:801,y:845,t:1526919023760};\\\", \\\"{x:808,y:854,t:1526919023776};\\\", \\\"{x:811,y:861,t:1526919023793};\\\", \\\"{x:814,y:865,t:1526919023810};\\\", \\\"{x:816,y:868,t:1526919023826};\\\", \\\"{x:817,y:870,t:1526919023843};\\\", \\\"{x:818,y:873,t:1526919023860};\\\", \\\"{x:819,y:877,t:1526919023876};\\\", \\\"{x:819,y:878,t:1526919023894};\\\", \\\"{x:820,y:878,t:1526919024927};\\\", \\\"{x:821,y:879,t:1526919024944};\\\", \\\"{x:822,y:879,t:1526919024960};\\\", \\\"{x:823,y:879,t:1526919025008};\\\", \\\"{x:824,y:879,t:1526919025031};\\\", \\\"{x:825,y:879,t:1526919025128};\\\", \\\"{x:825,y:878,t:1526919025368};\\\", \\\"{x:825,y:877,t:1526919027480};\\\", \\\"{x:826,y:876,t:1526919027752};\\\", \\\"{x:826,y:875,t:1526919029408};\\\", \\\"{x:827,y:875,t:1526919029447};\\\", \\\"{x:828,y:875,t:1526919029552};\\\", \\\"{x:829,y:874,t:1526919030512};\\\", \\\"{x:828,y:873,t:1526919040221};\\\", \\\"{x:813,y:868,t:1526919040239};\\\", \\\"{x:793,y:863,t:1526919040254};\\\", \\\"{x:766,y:853,t:1526919040272};\\\", \\\"{x:734,y:842,t:1526919040289};\\\", \\\"{x:711,y:834,t:1526919040305};\\\", \\\"{x:654,y:810,t:1526919040321};\\\", \\\"{x:614,y:797,t:1526919040338};\\\", \\\"{x:592,y:787,t:1526919040355};\\\", \\\"{x:580,y:781,t:1526919040371};\\\", \\\"{x:570,y:775,t:1526919040389};\\\", \\\"{x:569,y:774,t:1526919040405};\\\", \\\"{x:569,y:773,t:1526919040428};\\\", \\\"{x:569,y:772,t:1526919040438};\\\", \\\"{x:568,y:767,t:1526919040455};\\\", \\\"{x:568,y:761,t:1526919040472};\\\", \\\"{x:567,y:756,t:1526919040488};\\\", \\\"{x:567,y:754,t:1526919040506};\\\", \\\"{x:567,y:751,t:1526919040521};\\\", \\\"{x:567,y:748,t:1526919040538};\\\", \\\"{x:567,y:744,t:1526919040555};\\\", \\\"{x:567,y:738,t:1526919040571};\\\", \\\"{x:567,y:730,t:1526919040588};\\\", \\\"{x:565,y:725,t:1526919040605};\\\", \\\"{x:563,y:724,t:1526919040623};\\\", \\\"{x:563,y:723,t:1526919040638};\\\", \\\"{x:563,y:722,t:1526919040655};\\\", \\\"{x:562,y:722,t:1526919040671};\\\", \\\"{x:561,y:721,t:1526919040687};\\\", \\\"{x:558,y:717,t:1526919040704};\\\", \\\"{x:557,y:715,t:1526919040721};\\\", \\\"{x:556,y:715,t:1526919040737};\\\" ] }, { \\\"rt\\\": 80404, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 394442, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -03 PM-Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:714,t:1526919048053};\\\", \\\"{x:561,y:714,t:1526919048063};\\\", \\\"{x:566,y:714,t:1526919048075};\\\", \\\"{x:574,y:712,t:1526919048092};\\\", \\\"{x:577,y:712,t:1526919048109};\\\", \\\"{x:581,y:711,t:1526919048126};\\\", \\\"{x:585,y:710,t:1526919048142};\\\", \\\"{x:596,y:710,t:1526919048159};\\\", \\\"{x:615,y:710,t:1526919048175};\\\", \\\"{x:637,y:710,t:1526919048193};\\\", \\\"{x:656,y:710,t:1526919048209};\\\", \\\"{x:667,y:710,t:1526919048225};\\\", \\\"{x:677,y:714,t:1526919048243};\\\", \\\"{x:686,y:720,t:1526919048260};\\\", \\\"{x:696,y:728,t:1526919048275};\\\", \\\"{x:713,y:743,t:1526919048292};\\\", \\\"{x:728,y:756,t:1526919048310};\\\", \\\"{x:741,y:768,t:1526919048326};\\\", \\\"{x:750,y:780,t:1526919048343};\\\", \\\"{x:759,y:791,t:1526919048360};\\\", \\\"{x:765,y:805,t:1526919048375};\\\", \\\"{x:769,y:823,t:1526919048393};\\\", \\\"{x:772,y:842,t:1526919048410};\\\", \\\"{x:772,y:859,t:1526919048425};\\\", \\\"{x:772,y:873,t:1526919048443};\\\", \\\"{x:772,y:882,t:1526919048460};\\\", \\\"{x:773,y:890,t:1526919048476};\\\", \\\"{x:773,y:897,t:1526919048493};\\\", \\\"{x:773,y:900,t:1526919048510};\\\", \\\"{x:773,y:901,t:1526919048526};\\\", \\\"{x:773,y:903,t:1526919048542};\\\", \\\"{x:773,y:904,t:1526919048560};\\\", \\\"{x:773,y:903,t:1526919049598};\\\", \\\"{x:773,y:902,t:1526919050053};\\\", \\\"{x:773,y:901,t:1526919050205};\\\", \\\"{x:773,y:900,t:1526919050213};\\\", \\\"{x:773,y:899,t:1526919050253};\\\", \\\"{x:772,y:898,t:1526919050309};\\\", \\\"{x:772,y:897,t:1526919050404};\\\", \\\"{x:772,y:896,t:1526919050420};\\\", \\\"{x:772,y:895,t:1526919050445};\\\", \\\"{x:772,y:894,t:1526919050460};\\\", \\\"{x:772,y:893,t:1526919050476};\\\", \\\"{x:771,y:893,t:1526919050492};\\\", \\\"{x:771,y:892,t:1526919050509};\\\", \\\"{x:771,y:891,t:1526919050548};\\\", \\\"{x:770,y:891,t:1526919050560};\\\", \\\"{x:770,y:890,t:1526919050580};\\\", \\\"{x:770,y:889,t:1526919050692};\\\", \\\"{x:770,y:888,t:1526919050716};\\\", \\\"{x:769,y:888,t:1526919050732};\\\", \\\"{x:769,y:887,t:1526919050764};\\\", \\\"{x:769,y:886,t:1526919050853};\\\", \\\"{x:769,y:885,t:1526919051085};\\\", \\\"{x:769,y:884,t:1526919051093};\\\", \\\"{x:769,y:883,t:1526919051125};\\\", \\\"{x:769,y:881,t:1526919051157};\\\", \\\"{x:768,y:880,t:1526919051188};\\\", \\\"{x:767,y:879,t:1526919051197};\\\", \\\"{x:767,y:878,t:1526919051229};\\\", \\\"{x:767,y:877,t:1526919051261};\\\", \\\"{x:767,y:876,t:1526919051276};\\\", \\\"{x:767,y:875,t:1526919051324};\\\", \\\"{x:767,y:874,t:1526919051349};\\\", \\\"{x:767,y:873,t:1526919051364};\\\", \\\"{x:767,y:872,t:1526919051377};\\\", \\\"{x:767,y:871,t:1526919051404};\\\", \\\"{x:767,y:870,t:1526919051412};\\\", \\\"{x:767,y:869,t:1526919051428};\\\", \\\"{x:766,y:868,t:1526919051444};\\\", \\\"{x:766,y:866,t:1526919051484};\\\", \\\"{x:766,y:865,t:1526919051517};\\\", \\\"{x:766,y:864,t:1526919051540};\\\", \\\"{x:766,y:863,t:1526919051548};\\\", \\\"{x:766,y:862,t:1526919051559};\\\", \\\"{x:765,y:860,t:1526919051588};\\\", \\\"{x:764,y:859,t:1526919051596};\\\", \\\"{x:764,y:858,t:1526919051636};\\\", \\\"{x:764,y:857,t:1526919051652};\\\", \\\"{x:764,y:856,t:1526919051716};\\\", \\\"{x:764,y:854,t:1526919051773};\\\", \\\"{x:764,y:853,t:1526919051813};\\\", \\\"{x:763,y:853,t:1526919051844};\\\", \\\"{x:763,y:851,t:1526919052493};\\\", \\\"{x:763,y:850,t:1526919054477};\\\", \\\"{x:764,y:839,t:1526919054494};\\\", \\\"{x:766,y:828,t:1526919054510};\\\", \\\"{x:773,y:808,t:1526919054527};\\\", \\\"{x:782,y:784,t:1526919054544};\\\", \\\"{x:800,y:760,t:1526919054560};\\\", \\\"{x:833,y:723,t:1526919054577};\\\", \\\"{x:865,y:698,t:1526919054595};\\\", \\\"{x:897,y:677,t:1526919054610};\\\", \\\"{x:933,y:652,t:1526919054627};\\\", \\\"{x:963,y:635,t:1526919054644};\\\", \\\"{x:1000,y:608,t:1526919054661};\\\", \\\"{x:1031,y:587,t:1526919054677};\\\", \\\"{x:1072,y:564,t:1526919054695};\\\", \\\"{x:1103,y:549,t:1526919054710};\\\", \\\"{x:1135,y:530,t:1526919054728};\\\", \\\"{x:1158,y:517,t:1526919054744};\\\", \\\"{x:1175,y:507,t:1526919054761};\\\", \\\"{x:1184,y:502,t:1526919054778};\\\", \\\"{x:1188,y:499,t:1526919054795};\\\", \\\"{x:1196,y:496,t:1526919054810};\\\", \\\"{x:1201,y:494,t:1526919054828};\\\", \\\"{x:1214,y:489,t:1526919054845};\\\", \\\"{x:1217,y:489,t:1526919054860};\\\", \\\"{x:1221,y:488,t:1526919054877};\\\", \\\"{x:1223,y:488,t:1526919054894};\\\", \\\"{x:1228,y:492,t:1526919054910};\\\", \\\"{x:1234,y:497,t:1526919054927};\\\", \\\"{x:1242,y:498,t:1526919054944};\\\", \\\"{x:1246,y:500,t:1526919054960};\\\", \\\"{x:1250,y:500,t:1526919054977};\\\", \\\"{x:1252,y:499,t:1526919054994};\\\", \\\"{x:1255,y:499,t:1526919055010};\\\", \\\"{x:1256,y:499,t:1526919055027};\\\", \\\"{x:1258,y:499,t:1526919055045};\\\", \\\"{x:1259,y:499,t:1526919055061};\\\", \\\"{x:1261,y:499,t:1526919055077};\\\", \\\"{x:1262,y:499,t:1526919055094};\\\", \\\"{x:1264,y:499,t:1526919055110};\\\", \\\"{x:1264,y:498,t:1526919055127};\\\", \\\"{x:1266,y:498,t:1526919055145};\\\", \\\"{x:1269,y:497,t:1526919055160};\\\", \\\"{x:1272,y:496,t:1526919055177};\\\", \\\"{x:1275,y:496,t:1526919055194};\\\", \\\"{x:1279,y:495,t:1526919055211};\\\", \\\"{x:1286,y:495,t:1526919055227};\\\", \\\"{x:1291,y:493,t:1526919055244};\\\", \\\"{x:1300,y:491,t:1526919055260};\\\", \\\"{x:1309,y:490,t:1526919055277};\\\", \\\"{x:1314,y:489,t:1526919055295};\\\", \\\"{x:1315,y:489,t:1526919055316};\\\", \\\"{x:1316,y:489,t:1526919055332};\\\", \\\"{x:1317,y:489,t:1526919055343};\\\", \\\"{x:1318,y:489,t:1526919055360};\\\", \\\"{x:1320,y:490,t:1526919055376};\\\", \\\"{x:1322,y:491,t:1526919055394};\\\", \\\"{x:1323,y:492,t:1526919055410};\\\", \\\"{x:1324,y:494,t:1526919055427};\\\", \\\"{x:1324,y:495,t:1526919055677};\\\", \\\"{x:1324,y:496,t:1526919055695};\\\", \\\"{x:1323,y:498,t:1526919055710};\\\", \\\"{x:1322,y:498,t:1526919055732};\\\", \\\"{x:1321,y:499,t:1526919055748};\\\", \\\"{x:1320,y:500,t:1526919055764};\\\", \\\"{x:1319,y:501,t:1526919055780};\\\", \\\"{x:1318,y:504,t:1526919055795};\\\", \\\"{x:1317,y:507,t:1526919055820};\\\", \\\"{x:1317,y:508,t:1526919055828};\\\", \\\"{x:1316,y:511,t:1526919055844};\\\", \\\"{x:1316,y:516,t:1526919055860};\\\", \\\"{x:1316,y:523,t:1526919055877};\\\", \\\"{x:1313,y:530,t:1526919055894};\\\", \\\"{x:1313,y:537,t:1526919055909};\\\", \\\"{x:1311,y:546,t:1526919055927};\\\", \\\"{x:1309,y:554,t:1526919055944};\\\", \\\"{x:1309,y:559,t:1526919055960};\\\", \\\"{x:1308,y:564,t:1526919055977};\\\", \\\"{x:1308,y:570,t:1526919055995};\\\", \\\"{x:1307,y:577,t:1526919056010};\\\", \\\"{x:1305,y:583,t:1526919056027};\\\", \\\"{x:1305,y:591,t:1526919056044};\\\", \\\"{x:1304,y:599,t:1526919056060};\\\", \\\"{x:1304,y:603,t:1526919056077};\\\", \\\"{x:1304,y:608,t:1526919056094};\\\", \\\"{x:1304,y:615,t:1526919056110};\\\", \\\"{x:1304,y:622,t:1526919056127};\\\", \\\"{x:1304,y:630,t:1526919056144};\\\", \\\"{x:1304,y:640,t:1526919056161};\\\", \\\"{x:1304,y:648,t:1526919056177};\\\", \\\"{x:1304,y:655,t:1526919056195};\\\", \\\"{x:1304,y:661,t:1526919056210};\\\", \\\"{x:1304,y:667,t:1526919056227};\\\", \\\"{x:1304,y:674,t:1526919056244};\\\", \\\"{x:1304,y:679,t:1526919056261};\\\", \\\"{x:1305,y:684,t:1526919056277};\\\", \\\"{x:1305,y:688,t:1526919056294};\\\", \\\"{x:1305,y:692,t:1526919056311};\\\", \\\"{x:1305,y:697,t:1526919056327};\\\", \\\"{x:1306,y:703,t:1526919056344};\\\", \\\"{x:1307,y:709,t:1526919056360};\\\", \\\"{x:1308,y:714,t:1526919056377};\\\", \\\"{x:1309,y:719,t:1526919056394};\\\", \\\"{x:1309,y:724,t:1526919056411};\\\", \\\"{x:1309,y:730,t:1526919056427};\\\", \\\"{x:1310,y:738,t:1526919056444};\\\", \\\"{x:1311,y:745,t:1526919056460};\\\", \\\"{x:1313,y:753,t:1526919056477};\\\", \\\"{x:1314,y:759,t:1526919056494};\\\", \\\"{x:1314,y:763,t:1526919056510};\\\", \\\"{x:1315,y:767,t:1526919056528};\\\", \\\"{x:1315,y:772,t:1526919056545};\\\", \\\"{x:1315,y:777,t:1526919056561};\\\", \\\"{x:1315,y:783,t:1526919056577};\\\", \\\"{x:1315,y:788,t:1526919056594};\\\", \\\"{x:1315,y:795,t:1526919056610};\\\", \\\"{x:1315,y:801,t:1526919056627};\\\", \\\"{x:1315,y:810,t:1526919056644};\\\", \\\"{x:1315,y:815,t:1526919056660};\\\", \\\"{x:1314,y:820,t:1526919056677};\\\", \\\"{x:1313,y:824,t:1526919056694};\\\", \\\"{x:1313,y:830,t:1526919056710};\\\", \\\"{x:1312,y:835,t:1526919056727};\\\", \\\"{x:1311,y:841,t:1526919056744};\\\", \\\"{x:1310,y:846,t:1526919056760};\\\", \\\"{x:1310,y:849,t:1526919056778};\\\", \\\"{x:1309,y:854,t:1526919056794};\\\", \\\"{x:1308,y:857,t:1526919056810};\\\", \\\"{x:1308,y:861,t:1526919056828};\\\", \\\"{x:1308,y:866,t:1526919056844};\\\", \\\"{x:1308,y:867,t:1526919056860};\\\", \\\"{x:1308,y:870,t:1526919056877};\\\", \\\"{x:1308,y:874,t:1526919056894};\\\", \\\"{x:1307,y:878,t:1526919056910};\\\", \\\"{x:1306,y:882,t:1526919056927};\\\", \\\"{x:1306,y:887,t:1526919056944};\\\", \\\"{x:1306,y:889,t:1526919056960};\\\", \\\"{x:1306,y:890,t:1526919056977};\\\", \\\"{x:1306,y:891,t:1526919057045};\\\", \\\"{x:1306,y:893,t:1526919057061};\\\", \\\"{x:1306,y:894,t:1526919057077};\\\", \\\"{x:1306,y:897,t:1526919057094};\\\", \\\"{x:1306,y:898,t:1526919057110};\\\", \\\"{x:1305,y:899,t:1526919057127};\\\", \\\"{x:1305,y:901,t:1526919057144};\\\", \\\"{x:1305,y:902,t:1526919057160};\\\", \\\"{x:1305,y:905,t:1526919057178};\\\", \\\"{x:1305,y:906,t:1526919057194};\\\", \\\"{x:1305,y:909,t:1526919057212};\\\", \\\"{x:1305,y:910,t:1526919057228};\\\", \\\"{x:1305,y:912,t:1526919057244};\\\", \\\"{x:1305,y:913,t:1526919057261};\\\", \\\"{x:1305,y:915,t:1526919057277};\\\", \\\"{x:1305,y:917,t:1526919057295};\\\", \\\"{x:1306,y:919,t:1526919057311};\\\", \\\"{x:1306,y:922,t:1526919057327};\\\", \\\"{x:1306,y:925,t:1526919057344};\\\", \\\"{x:1306,y:927,t:1526919057362};\\\", \\\"{x:1308,y:929,t:1526919057378};\\\", \\\"{x:1308,y:931,t:1526919057394};\\\", \\\"{x:1308,y:933,t:1526919057411};\\\", \\\"{x:1309,y:934,t:1526919057427};\\\", \\\"{x:1310,y:936,t:1526919057445};\\\", \\\"{x:1311,y:937,t:1526919057462};\\\", \\\"{x:1311,y:939,t:1526919057517};\\\", \\\"{x:1311,y:940,t:1526919057527};\\\", \\\"{x:1311,y:942,t:1526919057545};\\\", \\\"{x:1311,y:944,t:1526919057561};\\\", \\\"{x:1311,y:945,t:1526919057581};\\\", \\\"{x:1312,y:947,t:1526919057597};\\\", \\\"{x:1312,y:948,t:1526919057621};\\\", \\\"{x:1313,y:951,t:1526919057636};\\\", \\\"{x:1313,y:952,t:1526919057717};\\\", \\\"{x:1313,y:953,t:1526919057741};\\\", \\\"{x:1313,y:954,t:1526919057765};\\\", \\\"{x:1313,y:955,t:1526919057804};\\\", \\\"{x:1313,y:956,t:1526919057820};\\\", \\\"{x:1314,y:957,t:1526919057837};\\\", \\\"{x:1314,y:958,t:1526919057853};\\\", \\\"{x:1314,y:959,t:1526919057884};\\\", \\\"{x:1314,y:960,t:1526919057901};\\\", \\\"{x:1315,y:961,t:1526919057911};\\\", \\\"{x:1315,y:962,t:1526919057941};\\\", \\\"{x:1314,y:960,t:1526919064645};\\\", \\\"{x:1310,y:956,t:1526919064661};\\\", \\\"{x:1308,y:953,t:1526919064679};\\\", \\\"{x:1307,y:952,t:1526919064696};\\\", \\\"{x:1307,y:951,t:1526919064711};\\\", \\\"{x:1306,y:951,t:1526919064728};\\\", \\\"{x:1306,y:950,t:1526919064749};\\\", \\\"{x:1305,y:950,t:1526919064821};\\\", \\\"{x:1304,y:949,t:1526919065012};\\\", \\\"{x:1304,y:948,t:1526919065083};\\\", \\\"{x:1304,y:947,t:1526919065115};\\\", \\\"{x:1304,y:946,t:1526919065164};\\\", \\\"{x:1304,y:945,t:1526919065178};\\\", \\\"{x:1304,y:944,t:1526919065220};\\\", \\\"{x:1304,y:943,t:1526919065299};\\\", \\\"{x:1304,y:942,t:1526919065310};\\\", \\\"{x:1304,y:941,t:1526919065332};\\\", \\\"{x:1304,y:940,t:1526919065524};\\\", \\\"{x:1305,y:940,t:1526919065531};\\\", \\\"{x:1305,y:938,t:1526919066308};\\\", \\\"{x:1305,y:937,t:1526919066315};\\\", \\\"{x:1305,y:936,t:1526919066328};\\\", \\\"{x:1304,y:930,t:1526919066345};\\\", \\\"{x:1304,y:927,t:1526919066361};\\\", \\\"{x:1303,y:923,t:1526919066378};\\\", \\\"{x:1303,y:917,t:1526919066395};\\\", \\\"{x:1303,y:908,t:1526919066411};\\\", \\\"{x:1303,y:901,t:1526919066427};\\\", \\\"{x:1303,y:891,t:1526919066445};\\\", \\\"{x:1304,y:880,t:1526919066461};\\\", \\\"{x:1306,y:872,t:1526919066478};\\\", \\\"{x:1307,y:866,t:1526919066495};\\\", \\\"{x:1310,y:861,t:1526919066512};\\\", \\\"{x:1310,y:857,t:1526919066528};\\\", \\\"{x:1310,y:853,t:1526919066545};\\\", \\\"{x:1313,y:846,t:1526919066562};\\\", \\\"{x:1314,y:841,t:1526919066578};\\\", \\\"{x:1316,y:832,t:1526919066595};\\\", \\\"{x:1317,y:829,t:1526919066611};\\\", \\\"{x:1318,y:823,t:1526919066628};\\\", \\\"{x:1318,y:820,t:1526919066644};\\\", \\\"{x:1318,y:818,t:1526919066662};\\\", \\\"{x:1318,y:815,t:1526919066677};\\\", \\\"{x:1318,y:814,t:1526919066694};\\\", \\\"{x:1318,y:813,t:1526919066712};\\\", \\\"{x:1318,y:812,t:1526919066727};\\\", \\\"{x:1318,y:811,t:1526919066747};\\\", \\\"{x:1318,y:810,t:1526919066764};\\\", \\\"{x:1318,y:809,t:1526919066778};\\\", \\\"{x:1318,y:808,t:1526919066795};\\\", \\\"{x:1318,y:806,t:1526919066812};\\\", \\\"{x:1318,y:803,t:1526919066828};\\\", \\\"{x:1318,y:800,t:1526919066845};\\\", \\\"{x:1318,y:796,t:1526919066862};\\\", \\\"{x:1318,y:792,t:1526919066878};\\\", \\\"{x:1318,y:788,t:1526919066895};\\\", \\\"{x:1318,y:786,t:1526919066912};\\\", \\\"{x:1318,y:784,t:1526919066928};\\\", \\\"{x:1318,y:782,t:1526919066944};\\\", \\\"{x:1318,y:780,t:1526919066962};\\\", \\\"{x:1318,y:779,t:1526919066979};\\\", \\\"{x:1318,y:778,t:1526919066995};\\\", \\\"{x:1318,y:777,t:1526919067011};\\\", \\\"{x:1318,y:775,t:1526919067028};\\\", \\\"{x:1318,y:774,t:1526919067046};\\\", \\\"{x:1318,y:773,t:1526919067116};\\\", \\\"{x:1318,y:772,t:1526919067540};\\\", \\\"{x:1316,y:772,t:1526919067563};\\\", \\\"{x:1313,y:772,t:1526919067580};\\\", \\\"{x:1312,y:773,t:1526919067595};\\\", \\\"{x:1309,y:780,t:1526919067611};\\\", \\\"{x:1306,y:787,t:1526919067628};\\\", \\\"{x:1306,y:799,t:1526919067645};\\\", \\\"{x:1305,y:811,t:1526919067662};\\\", \\\"{x:1305,y:825,t:1526919067678};\\\", \\\"{x:1305,y:840,t:1526919067695};\\\", \\\"{x:1308,y:855,t:1526919067712};\\\", \\\"{x:1311,y:865,t:1526919067728};\\\", \\\"{x:1313,y:874,t:1526919067745};\\\", \\\"{x:1315,y:886,t:1526919067762};\\\", \\\"{x:1317,y:899,t:1526919067777};\\\", \\\"{x:1320,y:911,t:1526919067795};\\\", \\\"{x:1322,y:920,t:1526919067812};\\\", \\\"{x:1324,y:925,t:1526919067828};\\\", \\\"{x:1325,y:932,t:1526919067845};\\\", \\\"{x:1325,y:938,t:1526919067862};\\\", \\\"{x:1326,y:940,t:1526919067877};\\\", \\\"{x:1326,y:942,t:1526919067931};\\\", \\\"{x:1325,y:942,t:1526919069092};\\\", \\\"{x:1324,y:942,t:1526919069220};\\\", \\\"{x:1323,y:942,t:1526919069235};\\\", \\\"{x:1322,y:942,t:1526919069252};\\\", \\\"{x:1321,y:941,t:1526919069315};\\\", \\\"{x:1321,y:940,t:1526919069328};\\\", \\\"{x:1320,y:940,t:1526919069345};\\\", \\\"{x:1319,y:940,t:1526919069362};\\\", \\\"{x:1318,y:939,t:1526919069387};\\\", \\\"{x:1318,y:940,t:1526919073821};\\\", \\\"{x:1318,y:941,t:1526919073836};\\\", \\\"{x:1318,y:942,t:1526919073847};\\\", \\\"{x:1318,y:943,t:1526919073901};\\\", \\\"{x:1318,y:944,t:1526919073925};\\\", \\\"{x:1318,y:945,t:1526919073941};\\\", \\\"{x:1318,y:946,t:1526919073988};\\\", \\\"{x:1318,y:948,t:1526919074005};\\\", \\\"{x:1318,y:949,t:1526919074029};\\\", \\\"{x:1318,y:951,t:1526919074077};\\\", \\\"{x:1318,y:952,t:1526919074108};\\\", \\\"{x:1318,y:951,t:1526919074517};\\\", \\\"{x:1319,y:949,t:1526919074530};\\\", \\\"{x:1319,y:948,t:1526919074548};\\\", \\\"{x:1319,y:947,t:1526919074563};\\\", \\\"{x:1319,y:946,t:1526919074580};\\\", \\\"{x:1319,y:945,t:1526919074596};\\\", \\\"{x:1319,y:944,t:1526919074636};\\\", \\\"{x:1319,y:942,t:1526919076365};\\\", \\\"{x:1319,y:939,t:1526919076380};\\\", \\\"{x:1319,y:938,t:1526919076397};\\\", \\\"{x:1319,y:936,t:1526919076414};\\\", \\\"{x:1319,y:935,t:1526919076436};\\\", \\\"{x:1319,y:934,t:1526919076448};\\\", \\\"{x:1319,y:932,t:1526919076463};\\\", \\\"{x:1319,y:931,t:1526919076501};\\\", \\\"{x:1319,y:930,t:1526919076524};\\\", \\\"{x:1319,y:929,t:1526919076532};\\\", \\\"{x:1319,y:928,t:1526919076556};\\\", \\\"{x:1319,y:927,t:1526919076581};\\\", \\\"{x:1319,y:926,t:1526919076628};\\\", \\\"{x:1319,y:925,t:1526919077149};\\\", \\\"{x:1319,y:924,t:1526919077163};\\\", \\\"{x:1319,y:923,t:1526919077180};\\\", \\\"{x:1319,y:921,t:1526919077197};\\\", \\\"{x:1319,y:920,t:1526919077214};\\\", \\\"{x:1319,y:919,t:1526919077230};\\\", \\\"{x:1319,y:918,t:1526919077260};\\\", \\\"{x:1319,y:917,t:1526919077276};\\\", \\\"{x:1319,y:916,t:1526919077325};\\\", \\\"{x:1319,y:915,t:1526919077348};\\\", \\\"{x:1319,y:914,t:1526919077732};\\\", \\\"{x:1319,y:913,t:1526919078341};\\\", \\\"{x:1319,y:912,t:1526919078348};\\\", \\\"{x:1320,y:911,t:1526919078365};\\\", \\\"{x:1321,y:909,t:1526919078381};\\\", \\\"{x:1322,y:908,t:1526919078398};\\\", \\\"{x:1323,y:907,t:1526919078414};\\\", \\\"{x:1325,y:904,t:1526919078430};\\\", \\\"{x:1327,y:901,t:1526919078448};\\\", \\\"{x:1329,y:898,t:1526919078464};\\\", \\\"{x:1332,y:895,t:1526919078480};\\\", \\\"{x:1334,y:892,t:1526919078498};\\\", \\\"{x:1335,y:890,t:1526919078514};\\\", \\\"{x:1337,y:887,t:1526919078530};\\\", \\\"{x:1339,y:885,t:1526919078547};\\\", \\\"{x:1340,y:883,t:1526919078564};\\\", \\\"{x:1341,y:882,t:1526919078579};\\\", \\\"{x:1342,y:881,t:1526919078611};\\\", \\\"{x:1343,y:880,t:1526919078635};\\\", \\\"{x:1343,y:879,t:1526919078821};\\\", \\\"{x:1344,y:879,t:1526919078830};\\\", \\\"{x:1346,y:879,t:1526919078847};\\\", \\\"{x:1350,y:882,t:1526919078865};\\\", \\\"{x:1353,y:884,t:1526919078879};\\\", \\\"{x:1356,y:886,t:1526919078897};\\\", \\\"{x:1361,y:889,t:1526919078914};\\\", \\\"{x:1366,y:891,t:1526919078930};\\\", \\\"{x:1368,y:893,t:1526919078947};\\\", \\\"{x:1375,y:899,t:1526919078964};\\\", \\\"{x:1385,y:906,t:1526919078980};\\\", \\\"{x:1393,y:912,t:1526919078997};\\\", \\\"{x:1402,y:918,t:1526919079015};\\\", \\\"{x:1410,y:922,t:1526919079030};\\\", \\\"{x:1413,y:924,t:1526919079047};\\\", \\\"{x:1415,y:925,t:1526919079064};\\\", \\\"{x:1416,y:927,t:1526919079092};\\\", \\\"{x:1418,y:927,t:1526919079100};\\\", \\\"{x:1419,y:929,t:1526919079115};\\\", \\\"{x:1421,y:932,t:1526919079130};\\\", \\\"{x:1424,y:935,t:1526919079147};\\\", \\\"{x:1425,y:936,t:1526919079164};\\\", \\\"{x:1425,y:937,t:1526919079180};\\\", \\\"{x:1426,y:938,t:1526919079198};\\\", \\\"{x:1427,y:940,t:1526919079214};\\\", \\\"{x:1428,y:943,t:1526919079230};\\\", \\\"{x:1429,y:946,t:1526919079247};\\\", \\\"{x:1429,y:948,t:1526919079265};\\\", \\\"{x:1429,y:949,t:1526919079324};\\\", \\\"{x:1429,y:950,t:1526919079332};\\\", \\\"{x:1429,y:951,t:1526919079347};\\\", \\\"{x:1432,y:955,t:1526919079364};\\\", \\\"{x:1434,y:957,t:1526919079380};\\\", \\\"{x:1436,y:958,t:1526919079404};\\\", \\\"{x:1437,y:958,t:1526919079415};\\\", \\\"{x:1441,y:959,t:1526919079430};\\\", \\\"{x:1446,y:959,t:1526919079448};\\\", \\\"{x:1452,y:959,t:1526919079464};\\\", \\\"{x:1457,y:959,t:1526919079480};\\\", \\\"{x:1463,y:959,t:1526919079497};\\\", \\\"{x:1467,y:959,t:1526919079514};\\\", \\\"{x:1474,y:959,t:1526919079530};\\\", \\\"{x:1480,y:959,t:1526919079548};\\\", \\\"{x:1493,y:961,t:1526919079564};\\\", \\\"{x:1502,y:962,t:1526919079580};\\\", \\\"{x:1508,y:962,t:1526919079597};\\\", \\\"{x:1510,y:962,t:1526919079614};\\\", \\\"{x:1511,y:962,t:1526919079630};\\\", \\\"{x:1512,y:962,t:1526919079660};\\\", \\\"{x:1513,y:962,t:1526919079709};\\\", \\\"{x:1516,y:962,t:1526919079718};\\\", \\\"{x:1518,y:962,t:1526919079730};\\\", \\\"{x:1521,y:962,t:1526919079747};\\\", \\\"{x:1526,y:962,t:1526919079764};\\\", \\\"{x:1528,y:962,t:1526919079780};\\\", \\\"{x:1531,y:962,t:1526919079797};\\\", \\\"{x:1536,y:962,t:1526919079815};\\\", \\\"{x:1539,y:962,t:1526919079830};\\\", \\\"{x:1542,y:962,t:1526919079847};\\\", \\\"{x:1543,y:961,t:1526919080140};\\\", \\\"{x:1544,y:961,t:1526919080165};\\\", \\\"{x:1546,y:961,t:1526919080180};\\\", \\\"{x:1547,y:960,t:1526919080253};\\\", \\\"{x:1548,y:959,t:1526919080405};\\\", \\\"{x:1549,y:959,t:1526919116515};\\\", \\\"{x:1549,y:960,t:1526919116529};\\\", \\\"{x:1549,y:961,t:1526919116546};\\\", \\\"{x:1549,y:963,t:1526919116570};\\\", \\\"{x:1548,y:965,t:1526919116584};\\\", \\\"{x:1541,y:970,t:1526919116600};\\\", \\\"{x:1537,y:970,t:1526919117090};\\\", \\\"{x:1525,y:968,t:1526919117101};\\\", \\\"{x:1500,y:952,t:1526919117118};\\\", \\\"{x:1482,y:933,t:1526919117133};\\\", \\\"{x:1471,y:920,t:1526919117150};\\\", \\\"{x:1452,y:912,t:1526919117167};\\\", \\\"{x:1419,y:897,t:1526919117183};\\\", \\\"{x:1388,y:884,t:1526919117200};\\\", \\\"{x:1374,y:880,t:1526919117217};\\\", \\\"{x:1373,y:880,t:1526919117233};\\\", \\\"{x:1364,y:878,t:1526919117250};\\\", \\\"{x:1352,y:876,t:1526919117267};\\\", \\\"{x:1337,y:873,t:1526919117282};\\\", \\\"{x:1325,y:871,t:1526919117300};\\\", \\\"{x:1324,y:871,t:1526919117317};\\\", \\\"{x:1323,y:870,t:1526919117361};\\\", \\\"{x:1323,y:874,t:1526919117410};\\\", \\\"{x:1322,y:878,t:1526919117417};\\\", \\\"{x:1320,y:882,t:1526919117433};\\\", \\\"{x:1319,y:887,t:1526919117450};\\\", \\\"{x:1318,y:892,t:1526919117467};\\\", \\\"{x:1316,y:893,t:1526919117483};\\\", \\\"{x:1315,y:896,t:1526919117505};\\\", \\\"{x:1312,y:898,t:1526919117517};\\\", \\\"{x:1310,y:900,t:1526919117533};\\\", \\\"{x:1304,y:902,t:1526919117551};\\\", \\\"{x:1290,y:904,t:1526919117567};\\\", \\\"{x:1257,y:906,t:1526919117583};\\\", \\\"{x:1173,y:908,t:1526919117601};\\\", \\\"{x:999,y:908,t:1526919117617};\\\", \\\"{x:872,y:875,t:1526919117633};\\\", \\\"{x:782,y:839,t:1526919117650};\\\", \\\"{x:723,y:810,t:1526919117667};\\\", \\\"{x:680,y:778,t:1526919117683};\\\", \\\"{x:655,y:757,t:1526919117700};\\\", \\\"{x:644,y:744,t:1526919117717};\\\", \\\"{x:640,y:737,t:1526919117733};\\\", \\\"{x:638,y:734,t:1526919117750};\\\", \\\"{x:638,y:733,t:1526919117767};\\\", \\\"{x:636,y:725,t:1526919117783};\\\", \\\"{x:631,y:715,t:1526919117801};\\\", \\\"{x:627,y:697,t:1526919117816};\\\", \\\"{x:624,y:685,t:1526919117833};\\\", \\\"{x:621,y:670,t:1526919117850};\\\", \\\"{x:615,y:650,t:1526919117867};\\\", \\\"{x:603,y:623,t:1526919117884};\\\", \\\"{x:592,y:591,t:1526919117900};\\\", \\\"{x:582,y:577,t:1526919117915};\\\", \\\"{x:575,y:569,t:1526919117931};\\\", \\\"{x:573,y:567,t:1526919117948};\\\", \\\"{x:573,y:569,t:1526919118056};\\\", \\\"{x:576,y:576,t:1526919118065};\\\", \\\"{x:587,y:589,t:1526919118083};\\\", \\\"{x:597,y:598,t:1526919118099};\\\", \\\"{x:603,y:603,t:1526919118115};\\\", \\\"{x:607,y:607,t:1526919118132};\\\", \\\"{x:608,y:608,t:1526919118148};\\\", \\\"{x:609,y:608,t:1526919118165};\\\", \\\"{x:610,y:610,t:1526919118182};\\\", \\\"{x:611,y:614,t:1526919118198};\\\", \\\"{x:613,y:616,t:1526919118215};\\\", \\\"{x:614,y:617,t:1526919118232};\\\", \\\"{x:615,y:617,t:1526919118248};\\\", \\\"{x:617,y:617,t:1526919118577};\\\", \\\"{x:620,y:617,t:1526919118584};\\\", \\\"{x:624,y:617,t:1526919118599};\\\", \\\"{x:643,y:620,t:1526919118615};\\\", \\\"{x:684,y:631,t:1526919118633};\\\", \\\"{x:800,y:663,t:1526919118648};\\\", \\\"{x:890,y:698,t:1526919118665};\\\", \\\"{x:995,y:743,t:1526919118682};\\\", \\\"{x:1097,y:786,t:1526919118698};\\\", \\\"{x:1185,y:825,t:1526919118715};\\\", \\\"{x:1234,y:843,t:1526919118732};\\\", \\\"{x:1263,y:852,t:1526919118749};\\\", \\\"{x:1281,y:860,t:1526919118765};\\\", \\\"{x:1292,y:865,t:1526919118782};\\\", \\\"{x:1298,y:868,t:1526919118800};\\\", \\\"{x:1308,y:873,t:1526919118815};\\\", \\\"{x:1320,y:878,t:1526919118832};\\\", \\\"{x:1349,y:889,t:1526919118849};\\\", \\\"{x:1370,y:894,t:1526919118866};\\\", \\\"{x:1387,y:900,t:1526919118883};\\\", \\\"{x:1398,y:902,t:1526919118899};\\\", \\\"{x:1401,y:903,t:1526919118915};\\\", \\\"{x:1402,y:904,t:1526919118932};\\\", \\\"{x:1407,y:908,t:1526919118949};\\\", \\\"{x:1413,y:912,t:1526919118966};\\\", \\\"{x:1430,y:922,t:1526919118982};\\\", \\\"{x:1449,y:929,t:1526919118999};\\\", \\\"{x:1468,y:939,t:1526919119016};\\\", \\\"{x:1481,y:945,t:1526919119033};\\\", \\\"{x:1498,y:950,t:1526919119049};\\\", \\\"{x:1511,y:954,t:1526919119067};\\\", \\\"{x:1522,y:955,t:1526919119082};\\\", \\\"{x:1533,y:956,t:1526919119100};\\\", \\\"{x:1538,y:956,t:1526919119117};\\\", \\\"{x:1539,y:956,t:1526919119133};\\\", \\\"{x:1540,y:956,t:1526919119161};\\\", \\\"{x:1541,y:956,t:1526919119170};\\\", \\\"{x:1542,y:956,t:1526919119186};\\\", \\\"{x:1543,y:956,t:1526919119199};\\\", \\\"{x:1544,y:956,t:1526919119217};\\\", \\\"{x:1545,y:956,t:1526919119233};\\\", \\\"{x:1547,y:956,t:1526919119258};\\\", \\\"{x:1549,y:956,t:1526919119281};\\\", \\\"{x:1550,y:956,t:1526919119300};\\\", \\\"{x:1551,y:956,t:1526919119330};\\\", \\\"{x:1552,y:956,t:1526919119426};\\\", \\\"{x:1552,y:957,t:1526919121498};\\\", \\\"{x:1567,y:936,t:1526919122330};\\\", \\\"{x:1596,y:864,t:1526919122337};\\\", \\\"{x:1618,y:773,t:1526919122352};\\\", \\\"{x:1653,y:554,t:1526919122368};\\\", \\\"{x:1678,y:333,t:1526919122385};\\\", \\\"{x:1677,y:302,t:1526919122402};\\\", \\\"{x:1677,y:301,t:1526919122434};\\\", \\\"{x:1676,y:301,t:1526919122762};\\\", \\\"{x:1676,y:305,t:1526919122769};\\\", \\\"{x:1676,y:318,t:1526919122786};\\\", \\\"{x:1676,y:333,t:1526919122802};\\\", \\\"{x:1677,y:353,t:1526919122820};\\\", \\\"{x:1677,y:372,t:1526919122836};\\\", \\\"{x:1676,y:388,t:1526919122852};\\\", \\\"{x:1674,y:404,t:1526919122870};\\\", \\\"{x:1669,y:420,t:1526919122886};\\\", \\\"{x:1665,y:434,t:1526919122903};\\\", \\\"{x:1662,y:446,t:1526919122919};\\\", \\\"{x:1661,y:453,t:1526919122935};\\\", \\\"{x:1660,y:457,t:1526919122953};\\\", \\\"{x:1660,y:458,t:1526919122969};\\\", \\\"{x:1660,y:460,t:1526919123296};\\\", \\\"{x:1657,y:462,t:1526919123303};\\\", \\\"{x:1656,y:462,t:1526919123319};\\\", \\\"{x:1643,y:474,t:1526919123336};\\\", \\\"{x:1636,y:482,t:1526919123352};\\\", \\\"{x:1632,y:488,t:1526919123369};\\\", \\\"{x:1631,y:492,t:1526919123386};\\\", \\\"{x:1629,y:496,t:1526919123402};\\\", \\\"{x:1626,y:504,t:1526919123419};\\\", \\\"{x:1621,y:514,t:1526919123436};\\\", \\\"{x:1614,y:523,t:1526919123451};\\\", \\\"{x:1597,y:543,t:1526919123469};\\\", \\\"{x:1580,y:561,t:1526919123486};\\\", \\\"{x:1564,y:578,t:1526919123502};\\\", \\\"{x:1555,y:593,t:1526919123520};\\\", \\\"{x:1550,y:601,t:1526919123536};\\\", \\\"{x:1550,y:602,t:1526919123552};\\\", \\\"{x:1550,y:603,t:1526919123601};\\\", \\\"{x:1549,y:605,t:1526919123609};\\\", \\\"{x:1546,y:607,t:1526919123619};\\\", \\\"{x:1543,y:611,t:1526919123636};\\\", \\\"{x:1541,y:614,t:1526919123652};\\\", \\\"{x:1541,y:618,t:1526919123670};\\\", \\\"{x:1538,y:626,t:1526919123687};\\\", \\\"{x:1534,y:636,t:1526919123703};\\\", \\\"{x:1528,y:652,t:1526919123719};\\\", \\\"{x:1522,y:667,t:1526919123737};\\\", \\\"{x:1518,y:682,t:1526919123752};\\\", \\\"{x:1516,y:688,t:1526919123770};\\\", \\\"{x:1513,y:694,t:1526919124482};\\\", \\\"{x:1511,y:700,t:1526919124489};\\\", \\\"{x:1510,y:706,t:1526919124503};\\\", \\\"{x:1505,y:718,t:1526919124521};\\\", \\\"{x:1491,y:740,t:1526919124537};\\\", \\\"{x:1486,y:749,t:1526919124554};\\\", \\\"{x:1483,y:757,t:1526919124571};\\\", \\\"{x:1483,y:761,t:1526919124587};\\\", \\\"{x:1481,y:763,t:1526919124604};\\\", \\\"{x:1480,y:769,t:1526919124621};\\\", \\\"{x:1475,y:781,t:1526919124638};\\\", \\\"{x:1473,y:794,t:1526919124654};\\\", \\\"{x:1471,y:804,t:1526919124670};\\\", \\\"{x:1470,y:814,t:1526919124688};\\\", \\\"{x:1469,y:821,t:1526919124704};\\\", \\\"{x:1469,y:825,t:1526919124721};\\\", \\\"{x:1469,y:828,t:1526919124738};\\\", \\\"{x:1469,y:829,t:1526919124754};\\\", \\\"{x:1467,y:834,t:1526919124771};\\\", \\\"{x:1465,y:843,t:1526919124788};\\\", \\\"{x:1462,y:856,t:1526919124804};\\\", \\\"{x:1462,y:868,t:1526919124821};\\\", \\\"{x:1461,y:872,t:1526919124838};\\\", \\\"{x:1460,y:872,t:1526919124855};\\\", \\\"{x:1460,y:874,t:1526919124873};\\\", \\\"{x:1460,y:875,t:1526919124887};\\\", \\\"{x:1456,y:879,t:1526919124904};\\\", \\\"{x:1453,y:880,t:1526919124920};\\\", \\\"{x:1449,y:882,t:1526919125610};\\\", \\\"{x:1442,y:884,t:1526919125622};\\\", \\\"{x:1425,y:884,t:1526919125638};\\\", \\\"{x:1396,y:884,t:1526919125654};\\\", \\\"{x:1357,y:884,t:1526919125672};\\\", \\\"{x:1307,y:877,t:1526919125688};\\\", \\\"{x:1207,y:868,t:1526919125704};\\\", \\\"{x:987,y:853,t:1526919125720};\\\", \\\"{x:794,y:837,t:1526919125738};\\\", \\\"{x:635,y:824,t:1526919125754};\\\", \\\"{x:563,y:824,t:1526919125771};\\\", \\\"{x:544,y:822,t:1526919125787};\\\", \\\"{x:543,y:821,t:1526919125804};\\\", \\\"{x:541,y:821,t:1526919125821};\\\", \\\"{x:540,y:821,t:1526919125838};\\\", \\\"{x:537,y:821,t:1526919125854};\\\", \\\"{x:536,y:821,t:1526919125872};\\\", \\\"{x:531,y:821,t:1526919125888};\\\", \\\"{x:526,y:821,t:1526919125905};\\\", \\\"{x:510,y:813,t:1526919125921};\\\", \\\"{x:508,y:809,t:1526919125938};\\\", \\\"{x:512,y:799,t:1526919125954};\\\", \\\"{x:524,y:780,t:1526919125971};\\\", \\\"{x:533,y:768,t:1526919125988};\\\", \\\"{x:537,y:757,t:1526919126004};\\\", \\\"{x:540,y:752,t:1526919126021};\\\", \\\"{x:543,y:746,t:1526919126039};\\\", \\\"{x:543,y:742,t:1526919126054};\\\", \\\"{x:543,y:739,t:1526919126071};\\\", \\\"{x:542,y:737,t:1526919126088};\\\", \\\"{x:541,y:735,t:1526919126104};\\\", \\\"{x:540,y:735,t:1526919126121};\\\", \\\"{x:537,y:733,t:1526919126138};\\\", \\\"{x:531,y:730,t:1526919126154};\\\", \\\"{x:526,y:728,t:1526919126171};\\\", \\\"{x:521,y:725,t:1526919126189};\\\", \\\"{x:518,y:724,t:1526919126204};\\\", \\\"{x:517,y:723,t:1526919126222};\\\", \\\"{x:516,y:723,t:1526919126961};\\\", \\\"{x:516,y:724,t:1526919127001};\\\", \\\"{x:517,y:724,t:1526919127073};\\\", \\\"{x:519,y:724,t:1526919127097};\\\", \\\"{x:520,y:724,t:1526919127128};\\\", \\\"{x:522,y:724,t:1526919127152};\\\", \\\"{x:523,y:724,t:1526919127169};\\\", \\\"{x:525,y:724,t:1526919127184};\\\", \\\"{x:526,y:724,t:1526919127200};\\\", \\\"{x:527,y:724,t:1526919127225};\\\", \\\"{x:528,y:724,t:1526919127238};\\\", \\\"{x:529,y:724,t:1526919127255};\\\", \\\"{x:530,y:724,t:1526919127272};\\\", \\\"{x:531,y:724,t:1526919127296};\\\", \\\"{x:532,y:724,t:1526919127305};\\\", \\\"{x:533,y:724,t:1526919127322};\\\", \\\"{x:534,y:724,t:1526919127344};\\\", \\\"{x:535,y:723,t:1526919127360};\\\", \\\"{x:537,y:723,t:1526919127392};\\\", \\\"{x:538,y:722,t:1526919127405};\\\", \\\"{x:539,y:721,t:1526919127423};\\\", \\\"{x:540,y:721,t:1526919127439};\\\", \\\"{x:541,y:721,t:1526919127455};\\\", \\\"{x:542,y:720,t:1526919127472};\\\", \\\"{x:543,y:720,t:1526919127489};\\\", \\\"{x:544,y:719,t:1526919127505};\\\", \\\"{x:545,y:719,t:1526919127545};\\\", \\\"{x:546,y:719,t:1526919127593};\\\", \\\"{x:547,y:719,t:1526919127625};\\\", \\\"{x:549,y:720,t:1526919127653};\\\", \\\"{x:549,y:722,t:1526919127680};\\\", \\\"{x:550,y:722,t:1526919127785};\\\", \\\"{x:550,y:723,t:1526919127800};\\\" ] }, { \\\"rt\\\": 9773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 405736, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:723,t:1526919128929};\\\", \\\"{x:552,y:723,t:1526919129034};\\\", \\\"{x:553,y:723,t:1526919129065};\\\", \\\"{x:554,y:723,t:1526919129113};\\\", \\\"{x:555,y:723,t:1526919129136};\\\", \\\"{x:556,y:722,t:1526919129144};\\\", \\\"{x:557,y:722,t:1526919129192};\\\", \\\"{x:558,y:722,t:1526919129216};\\\", \\\"{x:559,y:722,t:1526919130609};\\\", \\\"{x:561,y:722,t:1526919131417};\\\", \\\"{x:564,y:720,t:1526919131433};\\\", \\\"{x:575,y:716,t:1526919131448};\\\", \\\"{x:587,y:710,t:1526919131464};\\\", \\\"{x:598,y:705,t:1526919131473};\\\", \\\"{x:625,y:698,t:1526919131490};\\\", \\\"{x:649,y:691,t:1526919131506};\\\", \\\"{x:673,y:685,t:1526919131523};\\\", \\\"{x:697,y:677,t:1526919131540};\\\", \\\"{x:717,y:669,t:1526919131556};\\\", \\\"{x:732,y:664,t:1526919131574};\\\", \\\"{x:748,y:655,t:1526919131591};\\\", \\\"{x:770,y:646,t:1526919131607};\\\", \\\"{x:799,y:634,t:1526919131623};\\\", \\\"{x:856,y:616,t:1526919131641};\\\", \\\"{x:883,y:610,t:1526919131657};\\\", \\\"{x:907,y:603,t:1526919131675};\\\", \\\"{x:919,y:599,t:1526919131693};\\\", \\\"{x:928,y:598,t:1526919131710};\\\", \\\"{x:940,y:594,t:1526919131726};\\\", \\\"{x:953,y:590,t:1526919131743};\\\", \\\"{x:968,y:584,t:1526919131760};\\\", \\\"{x:987,y:578,t:1526919131777};\\\", \\\"{x:1009,y:574,t:1526919131793};\\\", \\\"{x:1018,y:572,t:1526919131810};\\\", \\\"{x:1023,y:570,t:1526919131825};\\\", \\\"{x:1027,y:569,t:1526919131843};\\\", \\\"{x:1028,y:569,t:1526919131860};\\\", \\\"{x:1030,y:569,t:1526919131877};\\\", \\\"{x:1036,y:568,t:1526919131893};\\\", \\\"{x:1045,y:566,t:1526919131910};\\\", \\\"{x:1053,y:566,t:1526919131927};\\\", \\\"{x:1059,y:566,t:1526919131943};\\\", \\\"{x:1061,y:566,t:1526919131960};\\\", \\\"{x:1065,y:566,t:1526919131977};\\\", \\\"{x:1067,y:566,t:1526919131994};\\\", \\\"{x:1071,y:566,t:1526919132009};\\\", \\\"{x:1073,y:566,t:1526919132027};\\\", \\\"{x:1075,y:566,t:1526919132043};\\\", \\\"{x:1077,y:566,t:1526919132060};\\\", \\\"{x:1078,y:567,t:1526919132249};\\\", \\\"{x:1080,y:567,t:1526919133090};\\\", \\\"{x:1085,y:567,t:1526919133097};\\\", \\\"{x:1090,y:567,t:1526919133111};\\\", \\\"{x:1095,y:567,t:1526919133127};\\\", \\\"{x:1097,y:567,t:1526919133144};\\\", \\\"{x:1097,y:568,t:1526919133512};\\\", \\\"{x:1097,y:569,t:1526919133529};\\\", \\\"{x:1096,y:569,t:1526919133544};\\\", \\\"{x:1094,y:570,t:1526919133561};\\\", \\\"{x:1093,y:570,t:1526919133577};\\\", \\\"{x:1091,y:571,t:1526919133593};\\\", \\\"{x:1090,y:572,t:1526919133611};\\\", \\\"{x:1089,y:573,t:1526919133628};\\\", \\\"{x:1088,y:573,t:1526919133706};\\\", \\\"{x:1088,y:574,t:1526919133721};\\\", \\\"{x:1087,y:574,t:1526919133729};\\\", \\\"{x:1085,y:576,t:1526919133744};\\\", \\\"{x:1082,y:576,t:1526919133761};\\\", \\\"{x:1081,y:578,t:1526919133778};\\\", \\\"{x:1079,y:578,t:1526919133850};\\\", \\\"{x:1073,y:579,t:1526919133861};\\\", \\\"{x:1067,y:582,t:1526919133878};\\\", \\\"{x:1057,y:583,t:1526919133895};\\\", \\\"{x:1045,y:586,t:1526919133912};\\\", \\\"{x:1024,y:589,t:1526919133928};\\\", \\\"{x:988,y:593,t:1526919133946};\\\", \\\"{x:964,y:598,t:1526919133962};\\\", \\\"{x:942,y:601,t:1526919133979};\\\", \\\"{x:917,y:604,t:1526919133994};\\\", \\\"{x:895,y:606,t:1526919134011};\\\", \\\"{x:875,y:610,t:1526919134027};\\\", \\\"{x:857,y:612,t:1526919134045};\\\", \\\"{x:839,y:616,t:1526919134061};\\\", \\\"{x:826,y:619,t:1526919134077};\\\", \\\"{x:811,y:621,t:1526919134095};\\\", \\\"{x:797,y:625,t:1526919134111};\\\", \\\"{x:783,y:627,t:1526919134127};\\\", \\\"{x:767,y:628,t:1526919134144};\\\", \\\"{x:759,y:630,t:1526919134162};\\\", \\\"{x:753,y:631,t:1526919134177};\\\", \\\"{x:749,y:631,t:1526919134195};\\\", \\\"{x:745,y:632,t:1526919134212};\\\", \\\"{x:742,y:634,t:1526919134227};\\\", \\\"{x:737,y:635,t:1526919134244};\\\", \\\"{x:733,y:637,t:1526919134262};\\\", \\\"{x:726,y:639,t:1526919134277};\\\", \\\"{x:721,y:641,t:1526919134294};\\\", \\\"{x:719,y:641,t:1526919134311};\\\", \\\"{x:718,y:642,t:1526919134327};\\\", \\\"{x:715,y:642,t:1526919134345};\\\", \\\"{x:714,y:642,t:1526919134362};\\\", \\\"{x:711,y:642,t:1526919134379};\\\", \\\"{x:706,y:642,t:1526919134395};\\\", \\\"{x:701,y:642,t:1526919134412};\\\", \\\"{x:691,y:642,t:1526919134429};\\\", \\\"{x:678,y:642,t:1526919134445};\\\", \\\"{x:662,y:641,t:1526919134462};\\\", \\\"{x:647,y:638,t:1526919134479};\\\", \\\"{x:630,y:634,t:1526919134495};\\\", \\\"{x:609,y:631,t:1526919134513};\\\", \\\"{x:584,y:627,t:1526919134528};\\\", \\\"{x:563,y:624,t:1526919134544};\\\", \\\"{x:542,y:617,t:1526919134561};\\\", \\\"{x:525,y:612,t:1526919134577};\\\", \\\"{x:517,y:605,t:1526919134594};\\\", \\\"{x:515,y:597,t:1526919134612};\\\", \\\"{x:513,y:581,t:1526919134628};\\\", \\\"{x:514,y:563,t:1526919134645};\\\", \\\"{x:528,y:547,t:1526919134662};\\\", \\\"{x:544,y:530,t:1526919134678};\\\", \\\"{x:560,y:519,t:1526919134695};\\\", \\\"{x:571,y:513,t:1526919134712};\\\", \\\"{x:578,y:509,t:1526919134728};\\\", \\\"{x:579,y:509,t:1526919134760};\\\", \\\"{x:581,y:508,t:1526919134784};\\\", \\\"{x:583,y:507,t:1526919134795};\\\", \\\"{x:589,y:506,t:1526919134811};\\\", \\\"{x:591,y:505,t:1526919134828};\\\", \\\"{x:592,y:505,t:1526919134881};\\\", \\\"{x:595,y:504,t:1526919134896};\\\", \\\"{x:598,y:503,t:1526919134911};\\\", \\\"{x:600,y:503,t:1526919134928};\\\", \\\"{x:601,y:503,t:1526919134946};\\\", \\\"{x:603,y:502,t:1526919134968};\\\", \\\"{x:604,y:501,t:1526919134985};\\\", \\\"{x:601,y:501,t:1526919135216};\\\", \\\"{x:595,y:502,t:1526919135229};\\\", \\\"{x:578,y:507,t:1526919135245};\\\", \\\"{x:556,y:513,t:1526919135262};\\\", \\\"{x:511,y:526,t:1526919135279};\\\", \\\"{x:447,y:542,t:1526919135296};\\\", \\\"{x:353,y:565,t:1526919135313};\\\", \\\"{x:307,y:576,t:1526919135328};\\\", \\\"{x:274,y:581,t:1526919135345};\\\", \\\"{x:255,y:587,t:1526919135364};\\\", \\\"{x:246,y:588,t:1526919135378};\\\", \\\"{x:240,y:591,t:1526919135395};\\\", \\\"{x:232,y:595,t:1526919135414};\\\", \\\"{x:229,y:595,t:1526919135429};\\\", \\\"{x:226,y:597,t:1526919135446};\\\", \\\"{x:225,y:598,t:1526919135463};\\\", \\\"{x:227,y:595,t:1526919135521};\\\", \\\"{x:229,y:594,t:1526919135528};\\\", \\\"{x:235,y:590,t:1526919135546};\\\", \\\"{x:244,y:586,t:1526919135563};\\\", \\\"{x:259,y:583,t:1526919135578};\\\", \\\"{x:279,y:580,t:1526919135596};\\\", \\\"{x:312,y:578,t:1526919135613};\\\", \\\"{x:352,y:578,t:1526919135629};\\\", \\\"{x:395,y:575,t:1526919135646};\\\", \\\"{x:446,y:573,t:1526919135663};\\\", \\\"{x:496,y:573,t:1526919135679};\\\", \\\"{x:552,y:573,t:1526919135697};\\\", \\\"{x:638,y:573,t:1526919135712};\\\", \\\"{x:689,y:573,t:1526919135730};\\\", \\\"{x:731,y:573,t:1526919135747};\\\", \\\"{x:758,y:573,t:1526919135762};\\\", \\\"{x:774,y:573,t:1526919135780};\\\", \\\"{x:785,y:573,t:1526919135795};\\\", \\\"{x:791,y:573,t:1526919135812};\\\", \\\"{x:795,y:572,t:1526919135829};\\\", \\\"{x:798,y:572,t:1526919135845};\\\", \\\"{x:801,y:570,t:1526919135862};\\\", \\\"{x:803,y:569,t:1526919135879};\\\", \\\"{x:806,y:568,t:1526919135896};\\\", \\\"{x:814,y:563,t:1526919135912};\\\", \\\"{x:819,y:562,t:1526919135930};\\\", \\\"{x:820,y:561,t:1526919135945};\\\", \\\"{x:820,y:560,t:1526919135992};\\\", \\\"{x:821,y:560,t:1526919136000};\\\", \\\"{x:821,y:559,t:1526919136013};\\\", \\\"{x:822,y:558,t:1526919136029};\\\", \\\"{x:822,y:557,t:1526919136046};\\\", \\\"{x:824,y:554,t:1526919136064};\\\", \\\"{x:826,y:552,t:1526919136079};\\\", \\\"{x:829,y:550,t:1526919136096};\\\", \\\"{x:832,y:548,t:1526919136112};\\\", \\\"{x:834,y:547,t:1526919136129};\\\", \\\"{x:835,y:547,t:1526919136147};\\\", \\\"{x:836,y:546,t:1526919136185};\\\", \\\"{x:836,y:547,t:1526919136353};\\\", \\\"{x:834,y:552,t:1526919136363};\\\", \\\"{x:826,y:558,t:1526919136380};\\\", \\\"{x:816,y:566,t:1526919136397};\\\", \\\"{x:802,y:576,t:1526919136412};\\\", \\\"{x:780,y:592,t:1526919136430};\\\", \\\"{x:762,y:604,t:1526919136447};\\\", \\\"{x:742,y:615,t:1526919136462};\\\", \\\"{x:722,y:626,t:1526919136481};\\\", \\\"{x:689,y:648,t:1526919136497};\\\", \\\"{x:668,y:663,t:1526919136512};\\\", \\\"{x:651,y:674,t:1526919136530};\\\", \\\"{x:638,y:682,t:1526919136547};\\\", \\\"{x:627,y:689,t:1526919136563};\\\", \\\"{x:619,y:694,t:1526919136579};\\\", \\\"{x:611,y:698,t:1526919136597};\\\", \\\"{x:602,y:704,t:1526919136614};\\\", \\\"{x:596,y:707,t:1526919136630};\\\", \\\"{x:591,y:710,t:1526919136647};\\\", \\\"{x:587,y:711,t:1526919136664};\\\", \\\"{x:584,y:713,t:1526919136680};\\\", \\\"{x:582,y:714,t:1526919136705};\\\", \\\"{x:581,y:715,t:1526919136721};\\\", \\\"{x:577,y:715,t:1526919136730};\\\", \\\"{x:575,y:717,t:1526919136747};\\\", \\\"{x:573,y:717,t:1526919136764};\\\", \\\"{x:572,y:717,t:1526919136780};\\\", \\\"{x:571,y:717,t:1526919136797};\\\", \\\"{x:569,y:717,t:1526919136814};\\\", \\\"{x:568,y:717,t:1526919136841};\\\", \\\"{x:567,y:717,t:1526919136849};\\\", \\\"{x:566,y:718,t:1526919136863};\\\", \\\"{x:562,y:722,t:1526919136882};\\\", \\\"{x:550,y:729,t:1526919136896};\\\", \\\"{x:542,y:732,t:1526919136914};\\\", \\\"{x:539,y:734,t:1526919136931};\\\", \\\"{x:536,y:734,t:1526919136948};\\\" ] }, { \\\"rt\\\": 16188, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 423208, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:734,t:1526919140481};\\\", \\\"{x:535,y:733,t:1526919140512};\\\", \\\"{x:535,y:732,t:1526919140528};\\\", \\\"{x:535,y:731,t:1526919140576};\\\", \\\"{x:535,y:730,t:1526919140977};\\\", \\\"{x:536,y:730,t:1526919140985};\\\", \\\"{x:537,y:729,t:1526919141017};\\\", \\\"{x:538,y:729,t:1526919141057};\\\", \\\"{x:538,y:728,t:1526919141081};\\\", \\\"{x:539,y:728,t:1526919141105};\\\", \\\"{x:539,y:727,t:1526919141128};\\\", \\\"{x:541,y:727,t:1526919141137};\\\", \\\"{x:542,y:726,t:1526919141177};\\\", \\\"{x:543,y:725,t:1526919141249};\\\", \\\"{x:544,y:725,t:1526919141267};\\\", \\\"{x:544,y:724,t:1526919141297};\\\", \\\"{x:545,y:724,t:1526919141328};\\\", \\\"{x:546,y:724,t:1526919141352};\\\", \\\"{x:547,y:723,t:1526919141409};\\\", \\\"{x:547,y:722,t:1526919141433};\\\", \\\"{x:548,y:721,t:1526919141441};\\\", \\\"{x:549,y:718,t:1526919141458};\\\", \\\"{x:549,y:717,t:1526919141467};\\\", \\\"{x:551,y:715,t:1526919141483};\\\", \\\"{x:552,y:714,t:1526919141501};\\\", \\\"{x:552,y:713,t:1526919141517};\\\", \\\"{x:552,y:712,t:1526919141534};\\\", \\\"{x:553,y:711,t:1526919141551};\\\", \\\"{x:554,y:709,t:1526919141566};\\\", \\\"{x:554,y:708,t:1526919141583};\\\", \\\"{x:555,y:706,t:1526919141600};\\\", \\\"{x:555,y:705,t:1526919141913};\\\", \\\"{x:555,y:704,t:1526919141937};\\\", \\\"{x:555,y:703,t:1526919141993};\\\", \\\"{x:555,y:702,t:1526919142105};\\\", \\\"{x:555,y:701,t:1526919142177};\\\", \\\"{x:555,y:700,t:1526919142201};\\\", \\\"{x:555,y:699,t:1526919142362};\\\", \\\"{x:555,y:698,t:1526919144265};\\\", \\\"{x:563,y:696,t:1526919144273};\\\", \\\"{x:575,y:691,t:1526919144287};\\\", \\\"{x:608,y:685,t:1526919144303};\\\", \\\"{x:654,y:681,t:1526919144319};\\\", \\\"{x:735,y:668,t:1526919144337};\\\", \\\"{x:833,y:652,t:1526919144353};\\\", \\\"{x:881,y:644,t:1526919144370};\\\", \\\"{x:913,y:636,t:1526919144386};\\\", \\\"{x:936,y:631,t:1526919144405};\\\", \\\"{x:958,y:625,t:1526919144420};\\\", \\\"{x:975,y:621,t:1526919144436};\\\", \\\"{x:990,y:618,t:1526919144452};\\\", \\\"{x:997,y:616,t:1526919144470};\\\", \\\"{x:1001,y:616,t:1526919144486};\\\", \\\"{x:1005,y:616,t:1526919144503};\\\", \\\"{x:1020,y:610,t:1526919144520};\\\", \\\"{x:1040,y:609,t:1526919144536};\\\", \\\"{x:1058,y:606,t:1526919144552};\\\", \\\"{x:1073,y:606,t:1526919144570};\\\", \\\"{x:1080,y:611,t:1526919144586};\\\", \\\"{x:1086,y:615,t:1526919144603};\\\", \\\"{x:1089,y:619,t:1526919144620};\\\", \\\"{x:1094,y:624,t:1526919144636};\\\", \\\"{x:1099,y:631,t:1526919144653};\\\", \\\"{x:1102,y:634,t:1526919144670};\\\", \\\"{x:1105,y:636,t:1526919144687};\\\", \\\"{x:1105,y:637,t:1526919144739};\\\", \\\"{x:1105,y:638,t:1526919144753};\\\", \\\"{x:1105,y:639,t:1526919144769};\\\", \\\"{x:1105,y:640,t:1526919144787};\\\", \\\"{x:1105,y:641,t:1526919144808};\\\", \\\"{x:1105,y:642,t:1526919144820};\\\", \\\"{x:1105,y:643,t:1526919144837};\\\", \\\"{x:1105,y:644,t:1526919144853};\\\", \\\"{x:1105,y:646,t:1526919144870};\\\", \\\"{x:1105,y:647,t:1526919144896};\\\", \\\"{x:1105,y:648,t:1526919144905};\\\", \\\"{x:1105,y:649,t:1526919144920};\\\", \\\"{x:1107,y:650,t:1526919145353};\\\", \\\"{x:1112,y:651,t:1526919145370};\\\", \\\"{x:1119,y:651,t:1526919145387};\\\", \\\"{x:1126,y:651,t:1526919145404};\\\", \\\"{x:1134,y:653,t:1526919145421};\\\", \\\"{x:1141,y:653,t:1526919145437};\\\", \\\"{x:1151,y:655,t:1526919145454};\\\", \\\"{x:1157,y:655,t:1526919145471};\\\", \\\"{x:1162,y:655,t:1526919145487};\\\", \\\"{x:1171,y:655,t:1526919145505};\\\", \\\"{x:1179,y:656,t:1526919145521};\\\", \\\"{x:1192,y:659,t:1526919145537};\\\", \\\"{x:1204,y:661,t:1526919145554};\\\", \\\"{x:1213,y:663,t:1526919145571};\\\", \\\"{x:1216,y:663,t:1526919145587};\\\", \\\"{x:1218,y:663,t:1526919145605};\\\", \\\"{x:1223,y:663,t:1526919145621};\\\", \\\"{x:1228,y:664,t:1526919145637};\\\", \\\"{x:1237,y:665,t:1526919145654};\\\", \\\"{x:1244,y:667,t:1526919145670};\\\", \\\"{x:1253,y:668,t:1526919145687};\\\", \\\"{x:1261,y:669,t:1526919145705};\\\", \\\"{x:1267,y:671,t:1526919145720};\\\", \\\"{x:1270,y:671,t:1526919145737};\\\", \\\"{x:1276,y:672,t:1526919145754};\\\", \\\"{x:1285,y:673,t:1526919145771};\\\", \\\"{x:1290,y:673,t:1526919145787};\\\", \\\"{x:1298,y:675,t:1526919145804};\\\", \\\"{x:1304,y:676,t:1526919145821};\\\", \\\"{x:1309,y:677,t:1526919145837};\\\", \\\"{x:1310,y:677,t:1526919145854};\\\", \\\"{x:1312,y:677,t:1526919145871};\\\", \\\"{x:1313,y:677,t:1526919145887};\\\", \\\"{x:1316,y:677,t:1526919145904};\\\", \\\"{x:1319,y:680,t:1526919145921};\\\", \\\"{x:1327,y:681,t:1526919145937};\\\", \\\"{x:1330,y:684,t:1526919145954};\\\", \\\"{x:1332,y:684,t:1526919145971};\\\", \\\"{x:1333,y:684,t:1526919145987};\\\", \\\"{x:1335,y:684,t:1526919147648};\\\", \\\"{x:1336,y:684,t:1526919147664};\\\", \\\"{x:1337,y:684,t:1526919147672};\\\", \\\"{x:1339,y:684,t:1526919147689};\\\", \\\"{x:1340,y:684,t:1526919147712};\\\", \\\"{x:1341,y:684,t:1526919147792};\\\", \\\"{x:1342,y:684,t:1526919147805};\\\", \\\"{x:1343,y:685,t:1526919147822};\\\", \\\"{x:1344,y:685,t:1526919147945};\\\", \\\"{x:1345,y:685,t:1526919147960};\\\", \\\"{x:1346,y:685,t:1526919147972};\\\", \\\"{x:1347,y:686,t:1526919147990};\\\", \\\"{x:1348,y:686,t:1526919148009};\\\", \\\"{x:1349,y:686,t:1526919148025};\\\", \\\"{x:1349,y:687,t:1526919148048};\\\", \\\"{x:1350,y:687,t:1526919148098};\\\", \\\"{x:1351,y:687,t:1526919149409};\\\", \\\"{x:1351,y:688,t:1526919149432};\\\", \\\"{x:1351,y:689,t:1526919149449};\\\", \\\"{x:1351,y:690,t:1526919149472};\\\", \\\"{x:1351,y:691,t:1526919149602};\\\", \\\"{x:1351,y:692,t:1526919149619};\\\", \\\"{x:1350,y:693,t:1526919149640};\\\", \\\"{x:1349,y:695,t:1526919149657};\\\", \\\"{x:1349,y:696,t:1526919149679};\\\", \\\"{x:1349,y:698,t:1526919149696};\\\", \\\"{x:1349,y:699,t:1526919149720};\\\", \\\"{x:1349,y:701,t:1526919149752};\\\", \\\"{x:1349,y:702,t:1526919149801};\\\", \\\"{x:1349,y:704,t:1526919149825};\\\", \\\"{x:1349,y:705,t:1526919149848};\\\", \\\"{x:1349,y:707,t:1526919149864};\\\", \\\"{x:1349,y:708,t:1526919149889};\\\", \\\"{x:1349,y:710,t:1526919149929};\\\", \\\"{x:1349,y:711,t:1526919149952};\\\", \\\"{x:1349,y:712,t:1526919149967};\\\", \\\"{x:1349,y:713,t:1526919149984};\\\", \\\"{x:1349,y:714,t:1526919149992};\\\", \\\"{x:1349,y:715,t:1526919150056};\\\", \\\"{x:1349,y:716,t:1526919150064};\\\", \\\"{x:1349,y:717,t:1526919150075};\\\", \\\"{x:1349,y:719,t:1526919150096};\\\", \\\"{x:1349,y:720,t:1526919150107};\\\", \\\"{x:1349,y:722,t:1526919150124};\\\", \\\"{x:1349,y:725,t:1526919150141};\\\", \\\"{x:1349,y:727,t:1526919150158};\\\", \\\"{x:1349,y:729,t:1526919150175};\\\", \\\"{x:1349,y:730,t:1526919150225};\\\", \\\"{x:1349,y:731,t:1526919150241};\\\", \\\"{x:1349,y:732,t:1526919150258};\\\", \\\"{x:1349,y:733,t:1526919150281};\\\", \\\"{x:1348,y:734,t:1526919150304};\\\", \\\"{x:1348,y:735,t:1526919150321};\\\", \\\"{x:1348,y:736,t:1526919150345};\\\", \\\"{x:1348,y:737,t:1526919150360};\\\", \\\"{x:1348,y:738,t:1526919150375};\\\", \\\"{x:1348,y:739,t:1526919150393};\\\", \\\"{x:1348,y:740,t:1526919150417};\\\", \\\"{x:1348,y:741,t:1526919150432};\\\", \\\"{x:1348,y:742,t:1526919150449};\\\", \\\"{x:1348,y:743,t:1526919150458};\\\", \\\"{x:1348,y:745,t:1526919150475};\\\", \\\"{x:1347,y:748,t:1526919150492};\\\", \\\"{x:1347,y:749,t:1526919150508};\\\", \\\"{x:1347,y:750,t:1526919150525};\\\", \\\"{x:1347,y:751,t:1526919150542};\\\", \\\"{x:1347,y:752,t:1526919150561};\\\", \\\"{x:1347,y:753,t:1526919150577};\\\", \\\"{x:1347,y:754,t:1526919150592};\\\", \\\"{x:1347,y:755,t:1526919150607};\\\", \\\"{x:1346,y:756,t:1526919150625};\\\", \\\"{x:1346,y:757,t:1526919151702};\\\", \\\"{x:1346,y:759,t:1526919151709};\\\", \\\"{x:1343,y:762,t:1526919151723};\\\", \\\"{x:1333,y:769,t:1526919151739};\\\", \\\"{x:1321,y:774,t:1526919151756};\\\", \\\"{x:1309,y:777,t:1526919151773};\\\", \\\"{x:1294,y:779,t:1526919151789};\\\", \\\"{x:1263,y:779,t:1526919151806};\\\", \\\"{x:1220,y:782,t:1526919151823};\\\", \\\"{x:1177,y:789,t:1526919151839};\\\", \\\"{x:1146,y:794,t:1526919151856};\\\", \\\"{x:1126,y:796,t:1526919151873};\\\", \\\"{x:1106,y:799,t:1526919151889};\\\", \\\"{x:1088,y:800,t:1526919151906};\\\", \\\"{x:1071,y:800,t:1526919151923};\\\", \\\"{x:1043,y:800,t:1526919151940};\\\", \\\"{x:1004,y:800,t:1526919151956};\\\", \\\"{x:960,y:797,t:1526919151974};\\\", \\\"{x:922,y:797,t:1526919151990};\\\", \\\"{x:896,y:797,t:1526919152005};\\\", \\\"{x:880,y:797,t:1526919152023};\\\", \\\"{x:862,y:797,t:1526919152040};\\\", \\\"{x:843,y:797,t:1526919152056};\\\", \\\"{x:825,y:796,t:1526919152073};\\\", \\\"{x:813,y:796,t:1526919152090};\\\", \\\"{x:806,y:796,t:1526919152106};\\\", \\\"{x:794,y:796,t:1526919152123};\\\", \\\"{x:767,y:807,t:1526919152140};\\\", \\\"{x:724,y:820,t:1526919152156};\\\", \\\"{x:669,y:834,t:1526919152173};\\\", \\\"{x:625,y:841,t:1526919152190};\\\", \\\"{x:608,y:841,t:1526919152206};\\\", \\\"{x:596,y:841,t:1526919152224};\\\", \\\"{x:573,y:838,t:1526919152240};\\\", \\\"{x:543,y:828,t:1526919152256};\\\", \\\"{x:504,y:811,t:1526919152273};\\\", \\\"{x:496,y:795,t:1526919152290};\\\", \\\"{x:495,y:794,t:1526919152607};\\\", \\\"{x:494,y:792,t:1526919152623};\\\", \\\"{x:489,y:784,t:1526919152640};\\\", \\\"{x:485,y:777,t:1526919152656};\\\", \\\"{x:484,y:774,t:1526919152673};\\\", \\\"{x:481,y:770,t:1526919152690};\\\", \\\"{x:478,y:766,t:1526919152707};\\\", \\\"{x:474,y:763,t:1526919152723};\\\", \\\"{x:468,y:760,t:1526919152740};\\\", \\\"{x:462,y:757,t:1526919152757};\\\", \\\"{x:457,y:753,t:1526919152774};\\\", \\\"{x:448,y:742,t:1526919152790};\\\", \\\"{x:443,y:737,t:1526919152807};\\\", \\\"{x:435,y:727,t:1526919152824};\\\", \\\"{x:430,y:722,t:1526919152841};\\\", \\\"{x:425,y:716,t:1526919152858};\\\", \\\"{x:420,y:710,t:1526919152874};\\\", \\\"{x:410,y:700,t:1526919152890};\\\", \\\"{x:398,y:689,t:1526919152906};\\\", \\\"{x:385,y:678,t:1526919152924};\\\", \\\"{x:370,y:665,t:1526919152941};\\\", \\\"{x:356,y:653,t:1526919152956};\\\", \\\"{x:340,y:638,t:1526919152974};\\\", \\\"{x:330,y:630,t:1526919152991};\\\", \\\"{x:319,y:624,t:1526919153008};\\\", \\\"{x:312,y:619,t:1526919153024};\\\", \\\"{x:307,y:617,t:1526919153041};\\\", \\\"{x:299,y:614,t:1526919153058};\\\", \\\"{x:291,y:610,t:1526919153074};\\\", \\\"{x:281,y:607,t:1526919153091};\\\", \\\"{x:274,y:604,t:1526919153108};\\\", \\\"{x:269,y:603,t:1526919153125};\\\", \\\"{x:266,y:601,t:1526919153141};\\\", \\\"{x:263,y:600,t:1526919153158};\\\", \\\"{x:262,y:599,t:1526919153189};\\\", \\\"{x:259,y:596,t:1526919153229};\\\", \\\"{x:254,y:593,t:1526919153242};\\\", \\\"{x:247,y:587,t:1526919153258};\\\", \\\"{x:239,y:581,t:1526919153274};\\\", \\\"{x:230,y:576,t:1526919153291};\\\", \\\"{x:216,y:571,t:1526919153308};\\\", \\\"{x:208,y:568,t:1526919153324};\\\", \\\"{x:203,y:565,t:1526919153341};\\\", \\\"{x:197,y:562,t:1526919153358};\\\", \\\"{x:192,y:559,t:1526919153375};\\\", \\\"{x:189,y:558,t:1526919153391};\\\", \\\"{x:186,y:556,t:1526919153408};\\\", \\\"{x:183,y:555,t:1526919153426};\\\", \\\"{x:179,y:552,t:1526919153441};\\\", \\\"{x:176,y:550,t:1526919153458};\\\", \\\"{x:174,y:548,t:1526919153475};\\\", \\\"{x:172,y:548,t:1526919153491};\\\", \\\"{x:170,y:546,t:1526919153508};\\\", \\\"{x:169,y:545,t:1526919153535};\\\", \\\"{x:168,y:545,t:1526919153598};\\\", \\\"{x:168,y:545,t:1526919153666};\\\", \\\"{x:175,y:543,t:1526919153758};\\\", \\\"{x:207,y:537,t:1526919153775};\\\", \\\"{x:262,y:531,t:1526919153791};\\\", \\\"{x:342,y:522,t:1526919153809};\\\", \\\"{x:415,y:512,t:1526919153826};\\\", \\\"{x:495,y:502,t:1526919153842};\\\", \\\"{x:560,y:491,t:1526919153859};\\\", \\\"{x:594,y:491,t:1526919153875};\\\", \\\"{x:622,y:491,t:1526919153892};\\\", \\\"{x:644,y:491,t:1526919153908};\\\", \\\"{x:661,y:491,t:1526919153925};\\\", \\\"{x:683,y:491,t:1526919153942};\\\", \\\"{x:695,y:491,t:1526919153958};\\\", \\\"{x:702,y:491,t:1526919153975};\\\", \\\"{x:712,y:491,t:1526919153992};\\\", \\\"{x:720,y:492,t:1526919154008};\\\", \\\"{x:724,y:494,t:1526919154028};\\\", \\\"{x:726,y:494,t:1526919154041};\\\", \\\"{x:730,y:496,t:1526919154058};\\\", \\\"{x:739,y:497,t:1526919154074};\\\", \\\"{x:754,y:498,t:1526919154092};\\\", \\\"{x:770,y:499,t:1526919154108};\\\", \\\"{x:779,y:499,t:1526919154125};\\\", \\\"{x:783,y:499,t:1526919154142};\\\", \\\"{x:784,y:499,t:1526919154158};\\\", \\\"{x:785,y:499,t:1526919154175};\\\", \\\"{x:789,y:498,t:1526919154192};\\\", \\\"{x:791,y:498,t:1526919154208};\\\", \\\"{x:795,y:498,t:1526919154225};\\\", \\\"{x:799,y:497,t:1526919154242};\\\", \\\"{x:801,y:497,t:1526919154259};\\\", \\\"{x:802,y:497,t:1526919154275};\\\", \\\"{x:804,y:497,t:1526919154293};\\\", \\\"{x:806,y:497,t:1526919154309};\\\", \\\"{x:812,y:497,t:1526919154326};\\\", \\\"{x:821,y:497,t:1526919154342};\\\", \\\"{x:827,y:497,t:1526919154360};\\\", \\\"{x:831,y:497,t:1526919154375};\\\", \\\"{x:832,y:497,t:1526919154392};\\\", \\\"{x:833,y:497,t:1526919154409};\\\", \\\"{x:834,y:497,t:1526919154425};\\\", \\\"{x:835,y:497,t:1526919154442};\\\", \\\"{x:835,y:498,t:1526919154574};\\\", \\\"{x:835,y:499,t:1526919154582};\\\", \\\"{x:832,y:501,t:1526919154591};\\\", \\\"{x:829,y:506,t:1526919154609};\\\", \\\"{x:825,y:509,t:1526919154626};\\\", \\\"{x:821,y:513,t:1526919154642};\\\", \\\"{x:808,y:523,t:1526919154659};\\\", \\\"{x:788,y:541,t:1526919154676};\\\", \\\"{x:758,y:565,t:1526919154692};\\\", \\\"{x:714,y:603,t:1526919154710};\\\", \\\"{x:649,y:651,t:1526919154726};\\\", \\\"{x:615,y:673,t:1526919154742};\\\", \\\"{x:595,y:688,t:1526919154759};\\\", \\\"{x:573,y:702,t:1526919154776};\\\", \\\"{x:563,y:710,t:1526919154792};\\\", \\\"{x:552,y:719,t:1526919154809};\\\", \\\"{x:544,y:724,t:1526919154827};\\\", \\\"{x:534,y:731,t:1526919154842};\\\", \\\"{x:525,y:736,t:1526919154859};\\\", \\\"{x:519,y:739,t:1526919154876};\\\", \\\"{x:514,y:741,t:1526919154893};\\\", \\\"{x:508,y:744,t:1526919154910};\\\", \\\"{x:500,y:747,t:1526919154926};\\\", \\\"{x:497,y:747,t:1526919154943};\\\", \\\"{x:496,y:747,t:1526919154960};\\\", \\\"{x:495,y:747,t:1526919154982};\\\", \\\"{x:494,y:747,t:1526919155158};\\\", \\\"{x:494,y:746,t:1526919155190};\\\", \\\"{x:494,y:745,t:1526919155198};\\\", \\\"{x:494,y:744,t:1526919155214};\\\", \\\"{x:494,y:743,t:1526919155238};\\\", \\\"{x:495,y:743,t:1526919155950};\\\", \\\"{x:497,y:744,t:1526919156030};\\\", \\\"{x:498,y:744,t:1526919156222};\\\", \\\"{x:499,y:744,t:1526919156254};\\\", \\\"{x:502,y:744,t:1526919156450};\\\" ] }, { \\\"rt\\\": 60780, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 485247, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:744,t:1526919156641};\\\", \\\"{x:504,y:744,t:1526919156686};\\\", \\\"{x:506,y:744,t:1526919156725};\\\", \\\"{x:506,y:743,t:1526919156797};\\\", \\\"{x:507,y:743,t:1526919157022};\\\", \\\"{x:507,y:741,t:1526919157551};\\\", \\\"{x:508,y:741,t:1526919157903};\\\", \\\"{x:509,y:741,t:1526919157958};\\\", \\\"{x:510,y:741,t:1526919157974};\\\", \\\"{x:511,y:741,t:1526919157982};\\\", \\\"{x:512,y:741,t:1526919158006};\\\", \\\"{x:513,y:741,t:1526919158022};\\\", \\\"{x:514,y:742,t:1526919158030};\\\", \\\"{x:515,y:742,t:1526919158046};\\\", \\\"{x:516,y:742,t:1526919158166};\\\", \\\"{x:517,y:742,t:1526919158231};\\\", \\\"{x:518,y:742,t:1526919158246};\\\", \\\"{x:518,y:741,t:1526919158262};\\\", \\\"{x:519,y:741,t:1526919158278};\\\", \\\"{x:519,y:740,t:1526919158366};\\\", \\\"{x:520,y:739,t:1526919158471};\\\", \\\"{x:521,y:738,t:1526919158510};\\\", \\\"{x:522,y:737,t:1526919158911};\\\", \\\"{x:523,y:736,t:1526919159127};\\\", \\\"{x:524,y:735,t:1526919159406};\\\", \\\"{x:524,y:734,t:1526919159607};\\\", \\\"{x:527,y:732,t:1526919160815};\\\", \\\"{x:531,y:731,t:1526919160830};\\\", \\\"{x:534,y:729,t:1526919160848};\\\", \\\"{x:537,y:728,t:1526919160864};\\\", \\\"{x:539,y:727,t:1526919160880};\\\", \\\"{x:540,y:727,t:1526919160898};\\\", \\\"{x:541,y:726,t:1526919160913};\\\", \\\"{x:545,y:726,t:1526919160931};\\\", \\\"{x:551,y:728,t:1526919160947};\\\", \\\"{x:563,y:731,t:1526919160963};\\\", \\\"{x:575,y:735,t:1526919160982};\\\", \\\"{x:586,y:739,t:1526919160998};\\\", \\\"{x:603,y:744,t:1526919161013};\\\", \\\"{x:613,y:748,t:1526919161030};\\\", \\\"{x:626,y:751,t:1526919161047};\\\", \\\"{x:637,y:756,t:1526919161064};\\\", \\\"{x:649,y:762,t:1526919161082};\\\", \\\"{x:657,y:764,t:1526919161097};\\\", \\\"{x:666,y:768,t:1526919161114};\\\", \\\"{x:673,y:771,t:1526919161131};\\\", \\\"{x:676,y:772,t:1526919161148};\\\", \\\"{x:682,y:776,t:1526919161165};\\\", \\\"{x:686,y:779,t:1526919161181};\\\", \\\"{x:693,y:782,t:1526919161198};\\\", \\\"{x:697,y:783,t:1526919161215};\\\", \\\"{x:701,y:784,t:1526919161232};\\\", \\\"{x:704,y:786,t:1526919161248};\\\", \\\"{x:710,y:788,t:1526919161264};\\\", \\\"{x:714,y:790,t:1526919161282};\\\", \\\"{x:720,y:794,t:1526919161297};\\\", \\\"{x:722,y:795,t:1526919161314};\\\", \\\"{x:723,y:795,t:1526919161332};\\\", \\\"{x:724,y:796,t:1526919163222};\\\", \\\"{x:724,y:797,t:1526919163295};\\\", \\\"{x:723,y:798,t:1526919163431};\\\", \\\"{x:722,y:798,t:1526919163470};\\\", \\\"{x:723,y:798,t:1526919165783};\\\", \\\"{x:725,y:798,t:1526919165805};\\\", \\\"{x:726,y:797,t:1526919165818};\\\", \\\"{x:729,y:795,t:1526919165835};\\\", \\\"{x:734,y:793,t:1526919165852};\\\", \\\"{x:738,y:790,t:1526919165869};\\\", \\\"{x:743,y:788,t:1526919165885};\\\", \\\"{x:751,y:784,t:1526919165902};\\\", \\\"{x:769,y:779,t:1526919165918};\\\", \\\"{x:807,y:770,t:1526919165936};\\\", \\\"{x:845,y:760,t:1526919165952};\\\", \\\"{x:879,y:755,t:1526919165969};\\\", \\\"{x:908,y:749,t:1526919165985};\\\", \\\"{x:935,y:740,t:1526919166003};\\\", \\\"{x:952,y:733,t:1526919166020};\\\", \\\"{x:971,y:725,t:1526919166036};\\\", \\\"{x:1008,y:714,t:1526919166054};\\\", \\\"{x:1037,y:705,t:1526919166069};\\\", \\\"{x:1060,y:698,t:1526919166086};\\\", \\\"{x:1080,y:692,t:1526919166103};\\\", \\\"{x:1097,y:687,t:1526919166119};\\\", \\\"{x:1112,y:682,t:1526919166135};\\\", \\\"{x:1129,y:674,t:1526919166152};\\\", \\\"{x:1150,y:663,t:1526919166169};\\\", \\\"{x:1168,y:653,t:1526919166185};\\\", \\\"{x:1188,y:642,t:1526919166203};\\\", \\\"{x:1200,y:636,t:1526919166220};\\\", \\\"{x:1219,y:628,t:1526919166236};\\\", \\\"{x:1237,y:621,t:1526919166252};\\\", \\\"{x:1258,y:614,t:1526919166270};\\\", \\\"{x:1266,y:610,t:1526919166286};\\\", \\\"{x:1274,y:606,t:1526919166303};\\\", \\\"{x:1286,y:602,t:1526919166320};\\\", \\\"{x:1303,y:597,t:1526919166336};\\\", \\\"{x:1321,y:590,t:1526919166353};\\\", \\\"{x:1339,y:587,t:1526919166370};\\\", \\\"{x:1355,y:585,t:1526919166387};\\\", \\\"{x:1366,y:582,t:1526919166402};\\\", \\\"{x:1369,y:582,t:1526919166420};\\\", \\\"{x:1373,y:580,t:1526919166437};\\\", \\\"{x:1379,y:579,t:1526919166452};\\\", \\\"{x:1392,y:573,t:1526919166470};\\\", \\\"{x:1399,y:572,t:1526919166486};\\\", \\\"{x:1404,y:570,t:1526919166503};\\\", \\\"{x:1407,y:569,t:1526919166520};\\\", \\\"{x:1409,y:569,t:1526919166537};\\\", \\\"{x:1410,y:569,t:1526919166557};\\\", \\\"{x:1412,y:569,t:1526919166597};\\\", \\\"{x:1413,y:569,t:1526919169206};\\\", \\\"{x:1414,y:569,t:1526919169638};\\\", \\\"{x:1414,y:571,t:1526919169646};\\\", \\\"{x:1414,y:573,t:1526919169655};\\\", \\\"{x:1414,y:576,t:1526919169673};\\\", \\\"{x:1413,y:580,t:1526919169689};\\\", \\\"{x:1412,y:583,t:1526919169706};\\\", \\\"{x:1412,y:584,t:1526919169723};\\\", \\\"{x:1412,y:585,t:1526919169740};\\\", \\\"{x:1412,y:586,t:1526919169756};\\\", \\\"{x:1412,y:587,t:1526919169789};\\\", \\\"{x:1412,y:588,t:1526919169806};\\\", \\\"{x:1412,y:589,t:1526919169838};\\\", \\\"{x:1412,y:590,t:1526919169862};\\\", \\\"{x:1412,y:591,t:1526919169873};\\\", \\\"{x:1411,y:593,t:1526919169890};\\\", \\\"{x:1411,y:594,t:1526919169910};\\\", \\\"{x:1411,y:595,t:1526919169923};\\\", \\\"{x:1411,y:598,t:1526919169939};\\\", \\\"{x:1409,y:600,t:1526919169957};\\\", \\\"{x:1407,y:607,t:1526919169972};\\\", \\\"{x:1401,y:621,t:1526919169990};\\\", \\\"{x:1398,y:630,t:1526919170007};\\\", \\\"{x:1394,y:643,t:1526919170024};\\\", \\\"{x:1390,y:653,t:1526919170040};\\\", \\\"{x:1386,y:664,t:1526919170057};\\\", \\\"{x:1383,y:674,t:1526919170072};\\\", \\\"{x:1376,y:685,t:1526919170090};\\\", \\\"{x:1374,y:691,t:1526919170107};\\\", \\\"{x:1371,y:694,t:1526919170123};\\\", \\\"{x:1371,y:696,t:1526919170140};\\\", \\\"{x:1370,y:697,t:1526919170157};\\\", \\\"{x:1369,y:698,t:1526919170173};\\\", \\\"{x:1368,y:698,t:1526919170190};\\\", \\\"{x:1368,y:699,t:1526919170208};\\\", \\\"{x:1367,y:699,t:1526919170358};\\\", \\\"{x:1363,y:699,t:1526919170373};\\\", \\\"{x:1358,y:695,t:1526919170389};\\\", \\\"{x:1352,y:690,t:1526919170406};\\\", \\\"{x:1341,y:678,t:1526919170424};\\\", \\\"{x:1331,y:666,t:1526919170440};\\\", \\\"{x:1324,y:652,t:1526919170457};\\\", \\\"{x:1317,y:641,t:1526919170474};\\\", \\\"{x:1307,y:628,t:1526919170490};\\\", \\\"{x:1302,y:621,t:1526919170507};\\\", \\\"{x:1298,y:614,t:1526919170524};\\\", \\\"{x:1294,y:609,t:1526919170540};\\\", \\\"{x:1291,y:605,t:1526919170557};\\\", \\\"{x:1289,y:602,t:1526919170574};\\\", \\\"{x:1288,y:602,t:1526919170615};\\\", \\\"{x:1288,y:601,t:1526919171167};\\\", \\\"{x:1288,y:600,t:1526919171174};\\\", \\\"{x:1287,y:596,t:1526919171191};\\\", \\\"{x:1287,y:595,t:1526919171208};\\\", \\\"{x:1287,y:592,t:1526919171224};\\\", \\\"{x:1287,y:589,t:1526919171241};\\\", \\\"{x:1287,y:585,t:1526919171258};\\\", \\\"{x:1287,y:582,t:1526919171274};\\\", \\\"{x:1287,y:574,t:1526919171292};\\\", \\\"{x:1290,y:565,t:1526919171309};\\\", \\\"{x:1294,y:555,t:1526919171326};\\\", \\\"{x:1295,y:547,t:1526919171341};\\\", \\\"{x:1297,y:539,t:1526919171358};\\\", \\\"{x:1298,y:534,t:1526919171374};\\\", \\\"{x:1298,y:532,t:1526919171392};\\\", \\\"{x:1298,y:531,t:1526919171408};\\\", \\\"{x:1298,y:530,t:1526919171426};\\\", \\\"{x:1298,y:529,t:1526919171454};\\\", \\\"{x:1296,y:529,t:1526919171463};\\\", \\\"{x:1294,y:529,t:1526919171476};\\\", \\\"{x:1290,y:530,t:1526919171491};\\\", \\\"{x:1283,y:532,t:1526919171508};\\\", \\\"{x:1269,y:542,t:1526919171526};\\\", \\\"{x:1253,y:555,t:1526919171541};\\\", \\\"{x:1228,y:583,t:1526919171558};\\\", \\\"{x:1213,y:603,t:1526919171576};\\\", \\\"{x:1202,y:621,t:1526919171591};\\\", \\\"{x:1190,y:640,t:1526919171608};\\\", \\\"{x:1180,y:661,t:1526919171626};\\\", \\\"{x:1171,y:687,t:1526919171643};\\\", \\\"{x:1163,y:709,t:1526919171659};\\\", \\\"{x:1156,y:730,t:1526919171675};\\\", \\\"{x:1151,y:749,t:1526919171692};\\\", \\\"{x:1145,y:768,t:1526919171708};\\\", \\\"{x:1145,y:787,t:1526919171725};\\\", \\\"{x:1145,y:816,t:1526919171742};\\\", \\\"{x:1152,y:832,t:1526919171758};\\\", \\\"{x:1156,y:844,t:1526919171776};\\\", \\\"{x:1162,y:850,t:1526919171792};\\\", \\\"{x:1164,y:854,t:1526919171808};\\\", \\\"{x:1166,y:856,t:1526919171825};\\\", \\\"{x:1167,y:857,t:1526919171842};\\\", \\\"{x:1169,y:857,t:1526919171859};\\\", \\\"{x:1171,y:857,t:1526919171876};\\\", \\\"{x:1177,y:856,t:1526919171892};\\\", \\\"{x:1186,y:847,t:1526919171908};\\\", \\\"{x:1192,y:841,t:1526919171926};\\\", \\\"{x:1195,y:837,t:1526919171942};\\\", \\\"{x:1195,y:836,t:1526919171958};\\\", \\\"{x:1196,y:835,t:1526919172175};\\\", \\\"{x:1202,y:831,t:1526919172193};\\\", \\\"{x:1211,y:822,t:1526919172209};\\\", \\\"{x:1220,y:798,t:1526919172227};\\\", \\\"{x:1237,y:764,t:1526919172242};\\\", \\\"{x:1254,y:725,t:1526919172259};\\\", \\\"{x:1269,y:690,t:1526919172275};\\\", \\\"{x:1284,y:662,t:1526919172293};\\\", \\\"{x:1293,y:637,t:1526919172309};\\\", \\\"{x:1302,y:619,t:1526919172326};\\\", \\\"{x:1307,y:599,t:1526919172343};\\\", \\\"{x:1311,y:588,t:1526919172359};\\\", \\\"{x:1312,y:584,t:1526919172376};\\\", \\\"{x:1312,y:582,t:1526919172392};\\\", \\\"{x:1312,y:580,t:1526919172543};\\\", \\\"{x:1311,y:578,t:1526919172559};\\\", \\\"{x:1308,y:575,t:1526919172576};\\\", \\\"{x:1307,y:571,t:1526919172592};\\\", \\\"{x:1306,y:568,t:1526919172609};\\\", \\\"{x:1306,y:565,t:1526919172627};\\\", \\\"{x:1306,y:561,t:1526919172642};\\\", \\\"{x:1306,y:558,t:1526919172660};\\\", \\\"{x:1306,y:554,t:1526919172676};\\\", \\\"{x:1306,y:553,t:1526919172692};\\\", \\\"{x:1306,y:552,t:1526919172709};\\\", \\\"{x:1306,y:551,t:1526919172735};\\\", \\\"{x:1305,y:551,t:1526919172750};\\\", \\\"{x:1304,y:551,t:1526919174614};\\\", \\\"{x:1303,y:551,t:1526919174655};\\\", \\\"{x:1302,y:552,t:1526919174662};\\\", \\\"{x:1301,y:553,t:1526919174726};\\\", \\\"{x:1300,y:554,t:1526919174750};\\\", \\\"{x:1298,y:554,t:1526919207662};\\\", \\\"{x:1288,y:557,t:1526919207676};\\\", \\\"{x:1218,y:557,t:1526919207693};\\\", \\\"{x:1078,y:541,t:1526919207711};\\\", \\\"{x:924,y:530,t:1526919207729};\\\", \\\"{x:835,y:530,t:1526919207744};\\\", \\\"{x:800,y:537,t:1526919207760};\\\", \\\"{x:779,y:546,t:1526919207785};\\\", \\\"{x:774,y:549,t:1526919207801};\\\", \\\"{x:765,y:554,t:1526919207818};\\\", \\\"{x:746,y:564,t:1526919207836};\\\", \\\"{x:733,y:570,t:1526919207851};\\\", \\\"{x:718,y:574,t:1526919207869};\\\", \\\"{x:702,y:575,t:1526919207885};\\\", \\\"{x:699,y:575,t:1526919207902};\\\", \\\"{x:698,y:575,t:1526919207924};\\\", \\\"{x:697,y:573,t:1526919207941};\\\", \\\"{x:697,y:570,t:1526919207952};\\\", \\\"{x:689,y:556,t:1526919207970};\\\", \\\"{x:674,y:538,t:1526919207986};\\\", \\\"{x:662,y:527,t:1526919208002};\\\", \\\"{x:648,y:514,t:1526919208020};\\\", \\\"{x:634,y:508,t:1526919208037};\\\", \\\"{x:631,y:506,t:1526919208052};\\\", \\\"{x:626,y:502,t:1526919208069};\\\", \\\"{x:624,y:500,t:1526919208086};\\\", \\\"{x:623,y:499,t:1526919208102};\\\", \\\"{x:626,y:503,t:1526919208461};\\\", \\\"{x:632,y:517,t:1526919208469};\\\", \\\"{x:642,y:540,t:1526919208486};\\\", \\\"{x:649,y:552,t:1526919208503};\\\", \\\"{x:665,y:578,t:1526919208520};\\\", \\\"{x:688,y:620,t:1526919208537};\\\", \\\"{x:721,y:678,t:1526919208554};\\\", \\\"{x:758,y:733,t:1526919208570};\\\", \\\"{x:783,y:772,t:1526919208586};\\\", \\\"{x:805,y:808,t:1526919208603};\\\", \\\"{x:821,y:835,t:1526919208619};\\\", \\\"{x:832,y:853,t:1526919208636};\\\", \\\"{x:835,y:858,t:1526919208652};\\\", \\\"{x:832,y:859,t:1526919215795};\\\", \\\"{x:809,y:856,t:1526919215811};\\\", \\\"{x:771,y:851,t:1526919215827};\\\", \\\"{x:709,y:851,t:1526919215842};\\\", \\\"{x:628,y:849,t:1526919215860};\\\", \\\"{x:562,y:842,t:1526919215876};\\\", \\\"{x:517,y:836,t:1526919215893};\\\", \\\"{x:495,y:831,t:1526919215910};\\\", \\\"{x:491,y:830,t:1526919215926};\\\", \\\"{x:490,y:830,t:1526919215942};\\\", \\\"{x:489,y:829,t:1526919215995};\\\", \\\"{x:489,y:827,t:1526919216051};\\\", \\\"{x:489,y:824,t:1526919216059};\\\", \\\"{x:489,y:815,t:1526919216076};\\\", \\\"{x:494,y:804,t:1526919216093};\\\", \\\"{x:497,y:796,t:1526919216109};\\\", \\\"{x:498,y:792,t:1526919216126};\\\", \\\"{x:499,y:789,t:1526919216143};\\\", \\\"{x:500,y:785,t:1526919216160};\\\", \\\"{x:501,y:781,t:1526919216176};\\\", \\\"{x:503,y:775,t:1526919216193};\\\", \\\"{x:505,y:768,t:1526919216209};\\\", \\\"{x:508,y:756,t:1526919216226};\\\", \\\"{x:508,y:751,t:1526919216244};\\\", \\\"{x:509,y:746,t:1526919216259};\\\", \\\"{x:509,y:742,t:1526919216276};\\\", \\\"{x:509,y:736,t:1526919216290};\\\", \\\"{x:509,y:733,t:1526919216306};\\\", \\\"{x:509,y:731,t:1526919216323};\\\", \\\"{x:509,y:730,t:1526919216362};\\\" ] }, { \\\"rt\\\": 31278, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 518037, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:731,t:1526919220699};\\\", \\\"{x:514,y:741,t:1526919220711};\\\", \\\"{x:516,y:755,t:1526919220729};\\\", \\\"{x:518,y:766,t:1526919220744};\\\", \\\"{x:519,y:776,t:1526919220759};\\\", \\\"{x:519,y:782,t:1526919220776};\\\", \\\"{x:519,y:788,t:1526919220792};\\\", \\\"{x:519,y:796,t:1526919220809};\\\", \\\"{x:519,y:810,t:1526919220825};\\\", \\\"{x:519,y:817,t:1526919220842};\\\", \\\"{x:519,y:821,t:1526919220859};\\\", \\\"{x:519,y:822,t:1526919220882};\\\", \\\"{x:519,y:825,t:1526919220898};\\\", \\\"{x:519,y:828,t:1526919220909};\\\", \\\"{x:516,y:836,t:1526919220925};\\\", \\\"{x:515,y:842,t:1526919220942};\\\", \\\"{x:513,y:845,t:1526919220960};\\\", \\\"{x:512,y:845,t:1526919221299};\\\", \\\"{x:512,y:844,t:1526919221539};\\\", \\\"{x:512,y:843,t:1526919221570};\\\", \\\"{x:512,y:842,t:1526919221707};\\\", \\\"{x:512,y:841,t:1526919221738};\\\", \\\"{x:511,y:841,t:1526919221747};\\\", \\\"{x:511,y:840,t:1526919221795};\\\", \\\"{x:511,y:839,t:1526919221979};\\\", \\\"{x:511,y:838,t:1526919222115};\\\", \\\"{x:512,y:836,t:1526919225339};\\\", \\\"{x:516,y:835,t:1526919225347};\\\", \\\"{x:517,y:834,t:1526919225360};\\\", \\\"{x:521,y:832,t:1526919225377};\\\", \\\"{x:525,y:831,t:1526919225393};\\\", \\\"{x:526,y:831,t:1526919225419};\\\", \\\"{x:527,y:831,t:1526919225427};\\\", \\\"{x:530,y:831,t:1526919225443};\\\", \\\"{x:544,y:831,t:1526919225460};\\\", \\\"{x:563,y:831,t:1526919225477};\\\", \\\"{x:577,y:832,t:1526919225492};\\\", \\\"{x:591,y:834,t:1526919225509};\\\", \\\"{x:615,y:835,t:1526919225527};\\\", \\\"{x:662,y:842,t:1526919225543};\\\", \\\"{x:730,y:852,t:1526919225560};\\\", \\\"{x:791,y:861,t:1526919225577};\\\", \\\"{x:848,y:866,t:1526919225592};\\\", \\\"{x:877,y:867,t:1526919225610};\\\", \\\"{x:906,y:867,t:1526919225627};\\\", \\\"{x:918,y:867,t:1526919225642};\\\", \\\"{x:933,y:865,t:1526919225659};\\\", \\\"{x:952,y:859,t:1526919225677};\\\", \\\"{x:983,y:846,t:1526919225693};\\\", \\\"{x:1039,y:828,t:1526919225709};\\\", \\\"{x:1077,y:815,t:1526919225727};\\\", \\\"{x:1107,y:808,t:1526919225743};\\\", \\\"{x:1152,y:802,t:1526919225760};\\\", \\\"{x:1184,y:801,t:1526919225777};\\\", \\\"{x:1209,y:796,t:1526919225793};\\\", \\\"{x:1234,y:794,t:1526919225810};\\\", \\\"{x:1268,y:789,t:1526919225827};\\\", \\\"{x:1291,y:785,t:1526919225843};\\\", \\\"{x:1308,y:783,t:1526919225859};\\\", \\\"{x:1322,y:781,t:1526919225876};\\\", \\\"{x:1332,y:779,t:1526919225892};\\\", \\\"{x:1341,y:778,t:1526919225909};\\\", \\\"{x:1347,y:777,t:1526919225927};\\\", \\\"{x:1350,y:777,t:1526919225942};\\\", \\\"{x:1351,y:776,t:1526919225960};\\\", \\\"{x:1350,y:776,t:1526919226219};\\\", \\\"{x:1349,y:776,t:1526919226227};\\\", \\\"{x:1347,y:777,t:1526919226243};\\\", \\\"{x:1343,y:780,t:1526919226260};\\\", \\\"{x:1340,y:781,t:1526919226276};\\\", \\\"{x:1332,y:785,t:1526919226293};\\\", \\\"{x:1323,y:790,t:1526919226309};\\\", \\\"{x:1312,y:796,t:1526919226327};\\\", \\\"{x:1298,y:804,t:1526919226343};\\\", \\\"{x:1291,y:809,t:1526919226360};\\\", \\\"{x:1285,y:810,t:1526919226377};\\\", \\\"{x:1280,y:812,t:1526919226392};\\\", \\\"{x:1276,y:816,t:1526919226409};\\\", \\\"{x:1271,y:818,t:1526919226427};\\\", \\\"{x:1268,y:820,t:1526919226443};\\\", \\\"{x:1264,y:821,t:1526919226460};\\\", \\\"{x:1259,y:825,t:1526919226476};\\\", \\\"{x:1255,y:827,t:1526919226492};\\\", \\\"{x:1250,y:828,t:1526919226510};\\\", \\\"{x:1248,y:829,t:1526919226526};\\\", \\\"{x:1244,y:829,t:1526919226542};\\\", \\\"{x:1240,y:831,t:1526919226559};\\\", \\\"{x:1234,y:831,t:1526919226576};\\\", \\\"{x:1229,y:832,t:1526919226592};\\\", \\\"{x:1226,y:833,t:1526919226609};\\\", \\\"{x:1223,y:833,t:1526919226627};\\\", \\\"{x:1221,y:833,t:1526919226643};\\\", \\\"{x:1220,y:833,t:1526919226660};\\\", \\\"{x:1218,y:833,t:1526919226678};\\\", \\\"{x:1217,y:833,t:1526919226692};\\\", \\\"{x:1216,y:833,t:1526919226737};\\\", \\\"{x:1215,y:833,t:1526919226810};\\\", \\\"{x:1214,y:833,t:1526919228011};\\\", \\\"{x:1213,y:833,t:1526919228139};\\\", \\\"{x:1212,y:833,t:1526919228291};\\\", \\\"{x:1211,y:833,t:1526919228939};\\\", \\\"{x:1211,y:832,t:1526919228994};\\\", \\\"{x:1211,y:831,t:1526919229067};\\\", \\\"{x:1211,y:830,t:1526919229362};\\\", \\\"{x:1211,y:829,t:1526919229939};\\\", \\\"{x:1210,y:829,t:1526919229946};\\\", \\\"{x:1210,y:828,t:1526919229960};\\\", \\\"{x:1210,y:827,t:1526919229977};\\\", \\\"{x:1210,y:826,t:1526919229994};\\\", \\\"{x:1210,y:825,t:1526919230012};\\\", \\\"{x:1208,y:822,t:1526919230027};\\\", \\\"{x:1208,y:819,t:1526919230044};\\\", \\\"{x:1208,y:816,t:1526919230061};\\\", \\\"{x:1207,y:815,t:1526919230077};\\\", \\\"{x:1207,y:813,t:1526919230095};\\\", \\\"{x:1206,y:812,t:1526919230110};\\\", \\\"{x:1206,y:811,t:1526919230128};\\\", \\\"{x:1206,y:810,t:1526919230144};\\\", \\\"{x:1206,y:809,t:1526919230160};\\\", \\\"{x:1206,y:807,t:1526919230178};\\\", \\\"{x:1205,y:804,t:1526919230195};\\\", \\\"{x:1205,y:802,t:1526919230210};\\\", \\\"{x:1205,y:801,t:1526919230227};\\\", \\\"{x:1204,y:799,t:1526919230245};\\\", \\\"{x:1204,y:798,t:1526919230267};\\\", \\\"{x:1204,y:797,t:1526919230291};\\\", \\\"{x:1204,y:796,t:1526919230299};\\\", \\\"{x:1204,y:795,t:1526919230322};\\\", \\\"{x:1203,y:795,t:1526919230331};\\\", \\\"{x:1203,y:794,t:1526919230344};\\\", \\\"{x:1203,y:792,t:1526919230360};\\\", \\\"{x:1201,y:791,t:1526919230377};\\\", \\\"{x:1201,y:790,t:1526919230394};\\\", \\\"{x:1201,y:789,t:1526919230410};\\\", \\\"{x:1200,y:789,t:1526919230427};\\\", \\\"{x:1200,y:788,t:1526919230459};\\\", \\\"{x:1199,y:786,t:1526919230571};\\\", \\\"{x:1198,y:788,t:1526919230853};\\\", \\\"{x:1198,y:790,t:1526919230860};\\\", \\\"{x:1198,y:798,t:1526919230876};\\\", \\\"{x:1198,y:804,t:1526919230893};\\\", \\\"{x:1199,y:809,t:1526919230909};\\\", \\\"{x:1199,y:812,t:1526919230926};\\\", \\\"{x:1199,y:813,t:1526919230943};\\\", \\\"{x:1199,y:815,t:1526919230960};\\\", \\\"{x:1199,y:816,t:1526919230978};\\\", \\\"{x:1199,y:817,t:1526919230994};\\\", \\\"{x:1199,y:818,t:1526919231026};\\\", \\\"{x:1199,y:819,t:1526919231050};\\\", \\\"{x:1199,y:820,t:1526919231067};\\\", \\\"{x:1199,y:821,t:1526919231077};\\\", \\\"{x:1199,y:823,t:1526919231095};\\\", \\\"{x:1199,y:825,t:1526919231110};\\\", \\\"{x:1199,y:827,t:1526919231127};\\\", \\\"{x:1199,y:830,t:1526919231144};\\\", \\\"{x:1199,y:831,t:1526919231161};\\\", \\\"{x:1199,y:833,t:1526919231177};\\\", \\\"{x:1199,y:834,t:1526919231194};\\\", \\\"{x:1200,y:834,t:1526919232107};\\\", \\\"{x:1201,y:834,t:1526919232123};\\\", \\\"{x:1202,y:834,t:1526919232146};\\\", \\\"{x:1203,y:834,t:1526919232163};\\\", \\\"{x:1204,y:834,t:1526919232178};\\\", \\\"{x:1205,y:834,t:1526919232227};\\\", \\\"{x:1206,y:835,t:1526919232245};\\\", \\\"{x:1207,y:835,t:1526919232260};\\\", \\\"{x:1208,y:835,t:1526919232290};\\\", \\\"{x:1209,y:835,t:1526919232323};\\\", \\\"{x:1210,y:835,t:1526919232371};\\\", \\\"{x:1211,y:835,t:1526919232402};\\\", \\\"{x:1212,y:835,t:1526919232411};\\\", \\\"{x:1214,y:835,t:1526919232427};\\\", \\\"{x:1216,y:835,t:1526919232444};\\\", \\\"{x:1217,y:835,t:1526919232499};\\\", \\\"{x:1219,y:835,t:1526919232523};\\\", \\\"{x:1220,y:835,t:1526919232531};\\\", \\\"{x:1224,y:833,t:1526919232545};\\\", \\\"{x:1236,y:833,t:1526919232561};\\\", \\\"{x:1242,y:833,t:1526919232577};\\\", \\\"{x:1248,y:833,t:1526919232595};\\\", \\\"{x:1249,y:833,t:1526919232610};\\\", \\\"{x:1250,y:833,t:1526919232635};\\\", \\\"{x:1252,y:833,t:1526919232644};\\\", \\\"{x:1254,y:835,t:1526919232660};\\\", \\\"{x:1258,y:838,t:1526919232678};\\\", \\\"{x:1264,y:842,t:1526919232694};\\\", \\\"{x:1270,y:846,t:1526919232710};\\\", \\\"{x:1276,y:851,t:1526919232727};\\\", \\\"{x:1282,y:860,t:1526919232744};\\\", \\\"{x:1290,y:871,t:1526919232760};\\\", \\\"{x:1296,y:878,t:1526919232777};\\\", \\\"{x:1300,y:880,t:1526919232794};\\\", \\\"{x:1304,y:883,t:1526919232810};\\\", \\\"{x:1308,y:886,t:1526919232827};\\\", \\\"{x:1310,y:887,t:1526919232844};\\\", \\\"{x:1312,y:887,t:1526919232860};\\\", \\\"{x:1313,y:887,t:1526919232877};\\\", \\\"{x:1315,y:887,t:1526919232923};\\\", \\\"{x:1311,y:885,t:1526919232955};\\\", \\\"{x:1310,y:884,t:1526919232963};\\\", \\\"{x:1308,y:882,t:1526919232978};\\\", \\\"{x:1306,y:881,t:1526919232995};\\\", \\\"{x:1305,y:880,t:1526919233010};\\\", \\\"{x:1305,y:879,t:1526919233075};\\\", \\\"{x:1307,y:878,t:1526919233139};\\\", \\\"{x:1308,y:878,t:1526919233146};\\\", \\\"{x:1309,y:877,t:1526919233162};\\\", \\\"{x:1310,y:877,t:1526919233177};\\\", \\\"{x:1313,y:875,t:1526919233194};\\\", \\\"{x:1314,y:875,t:1526919233219};\\\", \\\"{x:1315,y:875,t:1526919233235};\\\", \\\"{x:1316,y:875,t:1526919233244};\\\", \\\"{x:1317,y:875,t:1526919233266};\\\", \\\"{x:1315,y:875,t:1526919233363};\\\", \\\"{x:1314,y:875,t:1526919233377};\\\", \\\"{x:1312,y:876,t:1526919233393};\\\", \\\"{x:1311,y:876,t:1526919233426};\\\", \\\"{x:1308,y:876,t:1526919233458};\\\", \\\"{x:1306,y:875,t:1526919233466};\\\", \\\"{x:1303,y:875,t:1526919233477};\\\", \\\"{x:1299,y:875,t:1526919233494};\\\", \\\"{x:1296,y:875,t:1526919233510};\\\", \\\"{x:1292,y:874,t:1526919233527};\\\", \\\"{x:1290,y:873,t:1526919233544};\\\", \\\"{x:1288,y:872,t:1526919233560};\\\", \\\"{x:1286,y:871,t:1526919233577};\\\", \\\"{x:1281,y:868,t:1526919233594};\\\", \\\"{x:1274,y:866,t:1526919233610};\\\", \\\"{x:1269,y:863,t:1526919233627};\\\", \\\"{x:1263,y:859,t:1526919233644};\\\", \\\"{x:1259,y:856,t:1526919233661};\\\", \\\"{x:1257,y:855,t:1526919233677};\\\", \\\"{x:1254,y:853,t:1526919233694};\\\", \\\"{x:1253,y:852,t:1526919233711};\\\", \\\"{x:1250,y:850,t:1526919233728};\\\", \\\"{x:1247,y:848,t:1526919233744};\\\", \\\"{x:1245,y:847,t:1526919233760};\\\", \\\"{x:1243,y:845,t:1526919233777};\\\", \\\"{x:1242,y:844,t:1526919233794};\\\", \\\"{x:1241,y:844,t:1526919233810};\\\", \\\"{x:1241,y:843,t:1526919233827};\\\", \\\"{x:1240,y:843,t:1526919233844};\\\", \\\"{x:1239,y:842,t:1526919233963};\\\", \\\"{x:1237,y:842,t:1526919233979};\\\", \\\"{x:1236,y:842,t:1526919233994};\\\", \\\"{x:1235,y:840,t:1526919234018};\\\", \\\"{x:1233,y:840,t:1526919234027};\\\", \\\"{x:1231,y:840,t:1526919234059};\\\", \\\"{x:1230,y:839,t:1526919234074};\\\", \\\"{x:1228,y:839,t:1526919234139};\\\", \\\"{x:1228,y:838,t:1526919234147};\\\", \\\"{x:1227,y:838,t:1526919234252};\\\", \\\"{x:1225,y:839,t:1526919234275};\\\", \\\"{x:1224,y:839,t:1526919234282};\\\", \\\"{x:1223,y:840,t:1526919234294};\\\", \\\"{x:1222,y:841,t:1526919234314};\\\", \\\"{x:1221,y:842,t:1526919234331};\\\", \\\"{x:1220,y:843,t:1526919234371};\\\", \\\"{x:1219,y:843,t:1526919234651};\\\", \\\"{x:1219,y:844,t:1526919234674};\\\", \\\"{x:1218,y:844,t:1526919234698};\\\", \\\"{x:1217,y:844,t:1526919234714};\\\", \\\"{x:1216,y:844,t:1526919234731};\\\", \\\"{x:1215,y:844,t:1526919234754};\\\", \\\"{x:1215,y:845,t:1526919234811};\\\", \\\"{x:1215,y:844,t:1526919237474};\\\", \\\"{x:1215,y:843,t:1526919237539};\\\", \\\"{x:1212,y:842,t:1526919240428};\\\", \\\"{x:1204,y:842,t:1526919240444};\\\", \\\"{x:1186,y:840,t:1526919240462};\\\", \\\"{x:1158,y:832,t:1526919240478};\\\", \\\"{x:1128,y:823,t:1526919240494};\\\", \\\"{x:1107,y:817,t:1526919240511};\\\", \\\"{x:1060,y:806,t:1526919240528};\\\", \\\"{x:1027,y:798,t:1526919240545};\\\", \\\"{x:999,y:791,t:1526919240561};\\\", \\\"{x:975,y:785,t:1526919240578};\\\", \\\"{x:957,y:780,t:1526919240595};\\\", \\\"{x:952,y:778,t:1526919240610};\\\", \\\"{x:951,y:777,t:1526919240739};\\\", \\\"{x:953,y:775,t:1526919240754};\\\", \\\"{x:954,y:774,t:1526919240762};\\\", \\\"{x:958,y:774,t:1526919240777};\\\", \\\"{x:966,y:770,t:1526919240794};\\\", \\\"{x:971,y:769,t:1526919240811};\\\", \\\"{x:975,y:769,t:1526919240828};\\\", \\\"{x:980,y:769,t:1526919240844};\\\", \\\"{x:989,y:772,t:1526919240861};\\\", \\\"{x:999,y:777,t:1526919240877};\\\", \\\"{x:1015,y:783,t:1526919240894};\\\", \\\"{x:1028,y:787,t:1526919240911};\\\", \\\"{x:1036,y:790,t:1526919240926};\\\", \\\"{x:1041,y:790,t:1526919240944};\\\", \\\"{x:1043,y:790,t:1526919240961};\\\", \\\"{x:1045,y:790,t:1526919240977};\\\", \\\"{x:1044,y:792,t:1526919241042};\\\", \\\"{x:1041,y:794,t:1526919241058};\\\", \\\"{x:1036,y:796,t:1526919241066};\\\", \\\"{x:1031,y:799,t:1526919241077};\\\", \\\"{x:1015,y:801,t:1526919241094};\\\", \\\"{x:987,y:801,t:1526919241111};\\\", \\\"{x:951,y:801,t:1526919241127};\\\", \\\"{x:906,y:801,t:1526919241144};\\\", \\\"{x:864,y:795,t:1526919241161};\\\", \\\"{x:795,y:779,t:1526919241177};\\\", \\\"{x:700,y:749,t:1526919241194};\\\", \\\"{x:647,y:735,t:1526919241211};\\\", \\\"{x:597,y:721,t:1526919241227};\\\", \\\"{x:563,y:711,t:1526919241245};\\\", \\\"{x:534,y:702,t:1526919241261};\\\", \\\"{x:511,y:694,t:1526919241277};\\\", \\\"{x:494,y:686,t:1526919241295};\\\", \\\"{x:483,y:680,t:1526919241312};\\\", \\\"{x:474,y:676,t:1526919241327};\\\", \\\"{x:466,y:672,t:1526919241345};\\\", \\\"{x:461,y:667,t:1526919241363};\\\", \\\"{x:454,y:661,t:1526919241377};\\\", \\\"{x:450,y:656,t:1526919241393};\\\", \\\"{x:444,y:650,t:1526919241410};\\\", \\\"{x:436,y:639,t:1526919241427};\\\", \\\"{x:426,y:628,t:1526919241443};\\\", \\\"{x:411,y:619,t:1526919241460};\\\", \\\"{x:395,y:613,t:1526919241477};\\\", \\\"{x:377,y:604,t:1526919241494};\\\", \\\"{x:354,y:596,t:1526919241510};\\\", \\\"{x:333,y:590,t:1526919241527};\\\", \\\"{x:311,y:583,t:1526919241544};\\\", \\\"{x:294,y:575,t:1526919241560};\\\", \\\"{x:280,y:569,t:1526919241577};\\\", \\\"{x:267,y:560,t:1526919241594};\\\", \\\"{x:261,y:555,t:1526919241611};\\\", \\\"{x:254,y:551,t:1526919241627};\\\", \\\"{x:246,y:544,t:1526919241644};\\\", \\\"{x:237,y:539,t:1526919241661};\\\", \\\"{x:228,y:532,t:1526919241677};\\\", \\\"{x:223,y:526,t:1526919241694};\\\", \\\"{x:215,y:520,t:1526919241712};\\\", \\\"{x:208,y:516,t:1526919241728};\\\", \\\"{x:202,y:511,t:1526919241744};\\\", \\\"{x:196,y:508,t:1526919241761};\\\", \\\"{x:194,y:506,t:1526919241777};\\\", \\\"{x:188,y:503,t:1526919241793};\\\", \\\"{x:186,y:502,t:1526919241812};\\\", \\\"{x:185,y:501,t:1526919241827};\\\", \\\"{x:184,y:500,t:1526919241844};\\\", \\\"{x:183,y:499,t:1526919241861};\\\", \\\"{x:180,y:497,t:1526919241877};\\\", \\\"{x:176,y:494,t:1526919241894};\\\", \\\"{x:173,y:493,t:1526919241911};\\\", \\\"{x:170,y:491,t:1526919241927};\\\", \\\"{x:169,y:491,t:1526919241944};\\\", \\\"{x:169,y:490,t:1526919242347};\\\", \\\"{x:169,y:491,t:1526919242387};\\\", \\\"{x:171,y:494,t:1526919243259};\\\", \\\"{x:176,y:499,t:1526919243267};\\\", \\\"{x:184,y:506,t:1526919243279};\\\", \\\"{x:203,y:519,t:1526919243297};\\\", \\\"{x:234,y:542,t:1526919243313};\\\", \\\"{x:259,y:560,t:1526919243328};\\\", \\\"{x:283,y:576,t:1526919243345};\\\", \\\"{x:320,y:609,t:1526919243361};\\\", \\\"{x:357,y:634,t:1526919243379};\\\", \\\"{x:399,y:663,t:1526919243395};\\\", \\\"{x:441,y:693,t:1526919243412};\\\", \\\"{x:473,y:717,t:1526919243429};\\\", \\\"{x:495,y:730,t:1526919243445};\\\", \\\"{x:516,y:744,t:1526919243462};\\\", \\\"{x:532,y:754,t:1526919243479};\\\", \\\"{x:545,y:760,t:1526919243495};\\\", \\\"{x:553,y:765,t:1526919243512};\\\", \\\"{x:560,y:769,t:1526919243529};\\\", \\\"{x:562,y:771,t:1526919243545};\\\", \\\"{x:565,y:772,t:1526919243561};\\\", \\\"{x:567,y:773,t:1526919243585};\\\", \\\"{x:569,y:774,t:1526919243722};\\\", \\\"{x:569,y:775,t:1526919243729};\\\", \\\"{x:571,y:776,t:1526919243745};\\\", \\\"{x:574,y:779,t:1526919243761};\\\", \\\"{x:575,y:779,t:1526919243786};\\\", \\\"{x:576,y:780,t:1526919243850};\\\", \\\"{x:576,y:781,t:1526919243874};\\\", \\\"{x:576,y:782,t:1526919243898};\\\", \\\"{x:576,y:783,t:1526919243930};\\\", \\\"{x:576,y:781,t:1526919244683};\\\", \\\"{x:576,y:780,t:1526919244697};\\\", \\\"{x:576,y:777,t:1526919244714};\\\", \\\"{x:576,y:775,t:1526919244730};\\\", \\\"{x:576,y:773,t:1526919244747};\\\", \\\"{x:576,y:772,t:1526919244763};\\\", \\\"{x:576,y:771,t:1526919244787};\\\", \\\"{x:576,y:770,t:1526919244867};\\\", \\\"{x:576,y:769,t:1526919245626};\\\", \\\"{x:576,y:768,t:1526919248755};\\\", \\\"{x:574,y:765,t:1526919248767};\\\", \\\"{x:570,y:761,t:1526919248783};\\\", \\\"{x:568,y:759,t:1526919248800};\\\", \\\"{x:559,y:750,t:1526919248818};\\\", \\\"{x:546,y:740,t:1526919248832};\\\", \\\"{x:534,y:729,t:1526919248849};\\\", \\\"{x:525,y:722,t:1526919248861};\\\", \\\"{x:524,y:718,t:1526919248879};\\\", \\\"{x:523,y:717,t:1526919248894};\\\", \\\"{x:522,y:717,t:1526919248929};\\\", \\\"{x:520,y:717,t:1526919248953};\\\", \\\"{x:519,y:716,t:1526919248961};\\\", \\\"{x:516,y:715,t:1526919248978};\\\", \\\"{x:513,y:713,t:1526919248994};\\\", \\\"{x:512,y:713,t:1526919249011};\\\", \\\"{x:510,y:713,t:1526919249028};\\\", \\\"{x:510,y:714,t:1526919249179};\\\", \\\"{x:510,y:719,t:1526919249195};\\\", \\\"{x:510,y:720,t:1526919249213};\\\", \\\"{x:510,y:721,t:1526919249258};\\\", \\\"{x:510,y:723,t:1526919249410};\\\", \\\"{x:510,y:724,t:1526919249434};\\\" ] }, { \\\"rt\\\": 43107, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 562343, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -M -M -M -C -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:729,t:1526919252386};\\\", \\\"{x:511,y:736,t:1526919252401};\\\", \\\"{x:514,y:741,t:1526919252418};\\\", \\\"{x:515,y:744,t:1526919252435};\\\", \\\"{x:515,y:745,t:1526919252452};\\\", \\\"{x:516,y:747,t:1526919252467};\\\", \\\"{x:516,y:748,t:1526919252489};\\\", \\\"{x:516,y:749,t:1526919252502};\\\", \\\"{x:516,y:750,t:1526919252517};\\\", \\\"{x:516,y:751,t:1526919252561};\\\", \\\"{x:516,y:752,t:1526919252586};\\\", \\\"{x:516,y:753,t:1526919252674};\\\", \\\"{x:517,y:755,t:1526919252723};\\\", \\\"{x:518,y:757,t:1526919252734};\\\", \\\"{x:518,y:758,t:1526919252753};\\\", \\\"{x:518,y:760,t:1526919252769};\\\", \\\"{x:522,y:768,t:1526919252786};\\\", \\\"{x:528,y:779,t:1526919252802};\\\", \\\"{x:536,y:793,t:1526919252819};\\\", \\\"{x:546,y:805,t:1526919252836};\\\", \\\"{x:550,y:809,t:1526919252853};\\\", \\\"{x:555,y:811,t:1526919252870};\\\", \\\"{x:558,y:812,t:1526919252886};\\\", \\\"{x:559,y:813,t:1526919252902};\\\", \\\"{x:561,y:815,t:1526919252920};\\\", \\\"{x:565,y:816,t:1526919252937};\\\", \\\"{x:569,y:819,t:1526919252953};\\\", \\\"{x:571,y:819,t:1526919252969};\\\", \\\"{x:574,y:819,t:1526919252986};\\\", \\\"{x:575,y:819,t:1526919253610};\\\", \\\"{x:577,y:819,t:1526919253754};\\\", \\\"{x:578,y:819,t:1526919253786};\\\", \\\"{x:578,y:818,t:1526919253978};\\\", \\\"{x:585,y:816,t:1526919254331};\\\", \\\"{x:592,y:813,t:1526919254338};\\\", \\\"{x:611,y:806,t:1526919254354};\\\", \\\"{x:641,y:804,t:1526919254370};\\\", \\\"{x:680,y:804,t:1526919254387};\\\", \\\"{x:722,y:804,t:1526919254404};\\\", \\\"{x:757,y:804,t:1526919254421};\\\", \\\"{x:783,y:804,t:1526919254437};\\\", \\\"{x:807,y:804,t:1526919254453};\\\", \\\"{x:826,y:804,t:1526919254471};\\\", \\\"{x:848,y:804,t:1526919254487};\\\", \\\"{x:874,y:804,t:1526919254503};\\\", \\\"{x:900,y:803,t:1526919254521};\\\", \\\"{x:933,y:803,t:1526919254536};\\\", \\\"{x:983,y:803,t:1526919254554};\\\", \\\"{x:1012,y:802,t:1526919254571};\\\", \\\"{x:1042,y:802,t:1526919254587};\\\", \\\"{x:1068,y:802,t:1526919254604};\\\", \\\"{x:1087,y:802,t:1526919254621};\\\", \\\"{x:1108,y:802,t:1526919254638};\\\", \\\"{x:1133,y:802,t:1526919254654};\\\", \\\"{x:1166,y:802,t:1526919254672};\\\", \\\"{x:1201,y:805,t:1526919254687};\\\", \\\"{x:1234,y:805,t:1526919254704};\\\", \\\"{x:1264,y:801,t:1526919254721};\\\", \\\"{x:1283,y:793,t:1526919254737};\\\", \\\"{x:1303,y:783,t:1526919254754};\\\", \\\"{x:1318,y:774,t:1526919254771};\\\", \\\"{x:1334,y:765,t:1526919254786};\\\", \\\"{x:1351,y:754,t:1526919254803};\\\", \\\"{x:1367,y:742,t:1526919254821};\\\", \\\"{x:1380,y:729,t:1526919254836};\\\", \\\"{x:1394,y:718,t:1526919254854};\\\", \\\"{x:1405,y:710,t:1526919254871};\\\", \\\"{x:1412,y:706,t:1526919254886};\\\", \\\"{x:1416,y:702,t:1526919254903};\\\", \\\"{x:1417,y:701,t:1526919254920};\\\", \\\"{x:1415,y:700,t:1526919255011};\\\", \\\"{x:1412,y:700,t:1526919255021};\\\", \\\"{x:1398,y:699,t:1526919255038};\\\", \\\"{x:1385,y:699,t:1526919255054};\\\", \\\"{x:1375,y:699,t:1526919255071};\\\", \\\"{x:1367,y:700,t:1526919255088};\\\", \\\"{x:1365,y:700,t:1526919255104};\\\", \\\"{x:1362,y:701,t:1526919255121};\\\", \\\"{x:1362,y:702,t:1526919255138};\\\", \\\"{x:1361,y:702,t:1526919255154};\\\", \\\"{x:1360,y:702,t:1526919255171};\\\", \\\"{x:1359,y:703,t:1526919255188};\\\", \\\"{x:1359,y:704,t:1526919255419};\\\", \\\"{x:1359,y:706,t:1526919255426};\\\", \\\"{x:1359,y:708,t:1526919255439};\\\", \\\"{x:1359,y:710,t:1526919255454};\\\", \\\"{x:1359,y:713,t:1526919255471};\\\", \\\"{x:1360,y:718,t:1526919255488};\\\", \\\"{x:1361,y:719,t:1526919255504};\\\", \\\"{x:1361,y:720,t:1526919255521};\\\", \\\"{x:1361,y:718,t:1526919255675};\\\", \\\"{x:1361,y:717,t:1526919255690};\\\", \\\"{x:1361,y:715,t:1526919255706};\\\", \\\"{x:1361,y:714,t:1526919255722};\\\", \\\"{x:1361,y:712,t:1526919255738};\\\", \\\"{x:1360,y:710,t:1526919255754};\\\", \\\"{x:1360,y:709,t:1526919255771};\\\", \\\"{x:1359,y:707,t:1526919255788};\\\", \\\"{x:1358,y:704,t:1526919260394};\\\", \\\"{x:1351,y:698,t:1526919260410};\\\", \\\"{x:1343,y:690,t:1526919260423};\\\", \\\"{x:1330,y:681,t:1526919260441};\\\", \\\"{x:1320,y:672,t:1526919260456};\\\", \\\"{x:1312,y:662,t:1526919260473};\\\", \\\"{x:1305,y:650,t:1526919260489};\\\", \\\"{x:1303,y:646,t:1526919260507};\\\", \\\"{x:1302,y:644,t:1526919260523};\\\", \\\"{x:1301,y:641,t:1526919260539};\\\", \\\"{x:1300,y:639,t:1526919260557};\\\", \\\"{x:1299,y:637,t:1526919260572};\\\", \\\"{x:1299,y:636,t:1526919260590};\\\", \\\"{x:1299,y:634,t:1526919260606};\\\", \\\"{x:1299,y:630,t:1526919260623};\\\", \\\"{x:1299,y:626,t:1526919260641};\\\", \\\"{x:1299,y:620,t:1526919260657};\\\", \\\"{x:1299,y:616,t:1526919260673};\\\", \\\"{x:1299,y:608,t:1526919260690};\\\", \\\"{x:1299,y:603,t:1526919260707};\\\", \\\"{x:1299,y:598,t:1526919260724};\\\", \\\"{x:1299,y:596,t:1526919260741};\\\", \\\"{x:1299,y:594,t:1526919260758};\\\", \\\"{x:1299,y:592,t:1526919260819};\\\", \\\"{x:1299,y:591,t:1526919260826};\\\", \\\"{x:1299,y:590,t:1526919260842};\\\", \\\"{x:1299,y:587,t:1526919260858};\\\", \\\"{x:1299,y:584,t:1526919260874};\\\", \\\"{x:1299,y:581,t:1526919260890};\\\", \\\"{x:1299,y:580,t:1526919260921};\\\", \\\"{x:1299,y:579,t:1526919260929};\\\", \\\"{x:1299,y:578,t:1526919260940};\\\", \\\"{x:1299,y:577,t:1526919260957};\\\", \\\"{x:1299,y:576,t:1526919260973};\\\", \\\"{x:1299,y:575,t:1526919260990};\\\", \\\"{x:1299,y:573,t:1526919261007};\\\", \\\"{x:1298,y:571,t:1526919261023};\\\", \\\"{x:1297,y:569,t:1526919261057};\\\", \\\"{x:1297,y:568,t:1526919261114};\\\", \\\"{x:1297,y:566,t:1526919261338};\\\", \\\"{x:1297,y:565,t:1526919261410};\\\", \\\"{x:1297,y:564,t:1526919262019};\\\", \\\"{x:1296,y:564,t:1526919262042};\\\", \\\"{x:1296,y:563,t:1526919262058};\\\", \\\"{x:1294,y:563,t:1526919262122};\\\", \\\"{x:1293,y:565,t:1526919264219};\\\", \\\"{x:1292,y:566,t:1526919264234};\\\", \\\"{x:1292,y:568,t:1526919264250};\\\", \\\"{x:1292,y:569,t:1526919264282};\\\", \\\"{x:1291,y:570,t:1526919264314};\\\", \\\"{x:1291,y:571,t:1526919264338};\\\", \\\"{x:1290,y:572,t:1526919264451};\\\", \\\"{x:1290,y:574,t:1526919264674};\\\", \\\"{x:1290,y:576,t:1526919264692};\\\", \\\"{x:1290,y:577,t:1526919264710};\\\", \\\"{x:1290,y:579,t:1526919264726};\\\", \\\"{x:1290,y:581,t:1526919264743};\\\", \\\"{x:1290,y:584,t:1526919264760};\\\", \\\"{x:1291,y:587,t:1526919264776};\\\", \\\"{x:1293,y:592,t:1526919264793};\\\", \\\"{x:1295,y:600,t:1526919264809};\\\", \\\"{x:1299,y:612,t:1526919264826};\\\", \\\"{x:1300,y:618,t:1526919264842};\\\", \\\"{x:1303,y:624,t:1526919264859};\\\", \\\"{x:1304,y:629,t:1526919264875};\\\", \\\"{x:1307,y:636,t:1526919264892};\\\", \\\"{x:1311,y:648,t:1526919264909};\\\", \\\"{x:1314,y:662,t:1526919264926};\\\", \\\"{x:1319,y:679,t:1526919264942};\\\", \\\"{x:1324,y:697,t:1526919264959};\\\", \\\"{x:1328,y:709,t:1526919264975};\\\", \\\"{x:1329,y:715,t:1526919264992};\\\", \\\"{x:1329,y:717,t:1526919265010};\\\", \\\"{x:1331,y:717,t:1526919265162};\\\", \\\"{x:1331,y:716,t:1526919265176};\\\", \\\"{x:1333,y:713,t:1526919265193};\\\", \\\"{x:1336,y:708,t:1526919265210};\\\", \\\"{x:1338,y:704,t:1526919265225};\\\", \\\"{x:1340,y:702,t:1526919265243};\\\", \\\"{x:1341,y:699,t:1526919265260};\\\", \\\"{x:1344,y:697,t:1526919265277};\\\", \\\"{x:1346,y:695,t:1526919265292};\\\", \\\"{x:1348,y:695,t:1526919265309};\\\", \\\"{x:1348,y:694,t:1526919265326};\\\", \\\"{x:1351,y:694,t:1526919265342};\\\", \\\"{x:1352,y:694,t:1526919265359};\\\", \\\"{x:1356,y:698,t:1526919265378};\\\", \\\"{x:1360,y:708,t:1526919265393};\\\", \\\"{x:1366,y:727,t:1526919265410};\\\", \\\"{x:1370,y:757,t:1526919265426};\\\", \\\"{x:1370,y:775,t:1526919265442};\\\", \\\"{x:1370,y:791,t:1526919265459};\\\", \\\"{x:1375,y:807,t:1526919265476};\\\", \\\"{x:1376,y:822,t:1526919265492};\\\", \\\"{x:1376,y:838,t:1526919265509};\\\", \\\"{x:1376,y:851,t:1526919265526};\\\", \\\"{x:1376,y:861,t:1526919265542};\\\", \\\"{x:1376,y:863,t:1526919265559};\\\", \\\"{x:1376,y:864,t:1526919265576};\\\", \\\"{x:1375,y:864,t:1526919265643};\\\", \\\"{x:1371,y:857,t:1526919265660};\\\", \\\"{x:1367,y:849,t:1526919265676};\\\", \\\"{x:1365,y:836,t:1526919265692};\\\", \\\"{x:1365,y:823,t:1526919265709};\\\", \\\"{x:1365,y:812,t:1526919265727};\\\", \\\"{x:1365,y:798,t:1526919265742};\\\", \\\"{x:1365,y:789,t:1526919265760};\\\", \\\"{x:1365,y:781,t:1526919265777};\\\", \\\"{x:1365,y:777,t:1526919265793};\\\", \\\"{x:1365,y:773,t:1526919265809};\\\", \\\"{x:1365,y:770,t:1526919265826};\\\", \\\"{x:1367,y:768,t:1526919265858};\\\", \\\"{x:1367,y:767,t:1526919265866};\\\", \\\"{x:1368,y:766,t:1526919265876};\\\", \\\"{x:1368,y:765,t:1526919265893};\\\", \\\"{x:1368,y:761,t:1526919265909};\\\", \\\"{x:1369,y:760,t:1526919265926};\\\", \\\"{x:1369,y:758,t:1526919265943};\\\", \\\"{x:1369,y:755,t:1526919265958};\\\", \\\"{x:1369,y:753,t:1526919265976};\\\", \\\"{x:1369,y:749,t:1526919265993};\\\", \\\"{x:1369,y:748,t:1526919266009};\\\", \\\"{x:1369,y:747,t:1526919266026};\\\", \\\"{x:1369,y:744,t:1526919266043};\\\", \\\"{x:1369,y:742,t:1526919266060};\\\", \\\"{x:1369,y:738,t:1526919266077};\\\", \\\"{x:1369,y:737,t:1526919266094};\\\", \\\"{x:1369,y:735,t:1526919266109};\\\", \\\"{x:1369,y:734,t:1526919266127};\\\", \\\"{x:1369,y:733,t:1526919266144};\\\", \\\"{x:1369,y:732,t:1526919266162};\\\", \\\"{x:1369,y:731,t:1526919266242};\\\", \\\"{x:1369,y:730,t:1526919266314};\\\", \\\"{x:1371,y:737,t:1526919266802};\\\", \\\"{x:1371,y:746,t:1526919266810};\\\", \\\"{x:1375,y:757,t:1526919266826};\\\", \\\"{x:1376,y:765,t:1526919266844};\\\", \\\"{x:1377,y:777,t:1526919266861};\\\", \\\"{x:1378,y:784,t:1526919266877};\\\", \\\"{x:1379,y:787,t:1526919266893};\\\", \\\"{x:1380,y:791,t:1526919266911};\\\", \\\"{x:1381,y:796,t:1526919266926};\\\", \\\"{x:1381,y:799,t:1526919266944};\\\", \\\"{x:1383,y:804,t:1526919266961};\\\", \\\"{x:1384,y:809,t:1526919266977};\\\", \\\"{x:1385,y:813,t:1526919266993};\\\", \\\"{x:1387,y:819,t:1526919267010};\\\", \\\"{x:1388,y:820,t:1526919267026};\\\", \\\"{x:1388,y:821,t:1526919267044};\\\", \\\"{x:1389,y:823,t:1526919267060};\\\", \\\"{x:1389,y:824,t:1526919267090};\\\", \\\"{x:1390,y:824,t:1526919267098};\\\", \\\"{x:1390,y:825,t:1526919267110};\\\", \\\"{x:1391,y:829,t:1526919267126};\\\", \\\"{x:1393,y:835,t:1526919267143};\\\", \\\"{x:1395,y:839,t:1526919267161};\\\", \\\"{x:1397,y:843,t:1526919267177};\\\", \\\"{x:1398,y:845,t:1526919267193};\\\", \\\"{x:1399,y:852,t:1526919267210};\\\", \\\"{x:1402,y:858,t:1526919267226};\\\", \\\"{x:1405,y:864,t:1526919267243};\\\", \\\"{x:1408,y:872,t:1526919267261};\\\", \\\"{x:1412,y:881,t:1526919267277};\\\", \\\"{x:1416,y:889,t:1526919267294};\\\", \\\"{x:1418,y:894,t:1526919267311};\\\", \\\"{x:1420,y:898,t:1526919267326};\\\", \\\"{x:1421,y:900,t:1526919267343};\\\", \\\"{x:1422,y:902,t:1526919267360};\\\", \\\"{x:1422,y:903,t:1526919267378};\\\", \\\"{x:1423,y:907,t:1526919267393};\\\", \\\"{x:1428,y:916,t:1526919267410};\\\", \\\"{x:1430,y:921,t:1526919267428};\\\", \\\"{x:1434,y:925,t:1526919267444};\\\", \\\"{x:1435,y:928,t:1526919267461};\\\", \\\"{x:1438,y:929,t:1526919267478};\\\", \\\"{x:1439,y:931,t:1526919267493};\\\", \\\"{x:1439,y:932,t:1526919267810};\\\", \\\"{x:1439,y:933,t:1526919267858};\\\", \\\"{x:1439,y:935,t:1526919267874};\\\", \\\"{x:1438,y:936,t:1526919268202};\\\", \\\"{x:1436,y:936,t:1526919268211};\\\", \\\"{x:1433,y:935,t:1526919268228};\\\", \\\"{x:1430,y:932,t:1526919268245};\\\", \\\"{x:1428,y:928,t:1526919268260};\\\", \\\"{x:1426,y:924,t:1526919268278};\\\", \\\"{x:1423,y:920,t:1526919268295};\\\", \\\"{x:1420,y:915,t:1526919268311};\\\", \\\"{x:1418,y:909,t:1526919268327};\\\", \\\"{x:1416,y:903,t:1526919268345};\\\", \\\"{x:1414,y:896,t:1526919268361};\\\", \\\"{x:1411,y:887,t:1526919268378};\\\", \\\"{x:1409,y:880,t:1526919268394};\\\", \\\"{x:1408,y:875,t:1526919268411};\\\", \\\"{x:1407,y:871,t:1526919268428};\\\", \\\"{x:1406,y:868,t:1526919268445};\\\", \\\"{x:1405,y:867,t:1526919268461};\\\", \\\"{x:1405,y:866,t:1526919268477};\\\", \\\"{x:1404,y:865,t:1526919268494};\\\", \\\"{x:1404,y:864,t:1526919268594};\\\", \\\"{x:1404,y:862,t:1526919268610};\\\", \\\"{x:1404,y:861,t:1526919268627};\\\", \\\"{x:1403,y:858,t:1526919268644};\\\", \\\"{x:1403,y:853,t:1526919268661};\\\", \\\"{x:1401,y:847,t:1526919268677};\\\", \\\"{x:1400,y:840,t:1526919268694};\\\", \\\"{x:1397,y:829,t:1526919268711};\\\", \\\"{x:1396,y:816,t:1526919268727};\\\", \\\"{x:1394,y:798,t:1526919268744};\\\", \\\"{x:1388,y:767,t:1526919268762};\\\", \\\"{x:1380,y:743,t:1526919268777};\\\", \\\"{x:1373,y:722,t:1526919268795};\\\", \\\"{x:1369,y:710,t:1526919268811};\\\", \\\"{x:1363,y:701,t:1526919268827};\\\", \\\"{x:1361,y:697,t:1526919268844};\\\", \\\"{x:1360,y:694,t:1526919268861};\\\", \\\"{x:1360,y:699,t:1526919270146};\\\", \\\"{x:1360,y:706,t:1526919270162};\\\", \\\"{x:1361,y:716,t:1526919270178};\\\", \\\"{x:1362,y:724,t:1526919270196};\\\", \\\"{x:1363,y:733,t:1526919270212};\\\", \\\"{x:1366,y:742,t:1526919270228};\\\", \\\"{x:1366,y:749,t:1526919270245};\\\", \\\"{x:1368,y:762,t:1526919270262};\\\", \\\"{x:1371,y:778,t:1526919270279};\\\", \\\"{x:1372,y:794,t:1526919270295};\\\", \\\"{x:1376,y:811,t:1526919270312};\\\", \\\"{x:1376,y:827,t:1526919270329};\\\", \\\"{x:1376,y:845,t:1526919270346};\\\", \\\"{x:1376,y:854,t:1526919270361};\\\", \\\"{x:1376,y:862,t:1526919270378};\\\", \\\"{x:1376,y:872,t:1526919270395};\\\", \\\"{x:1376,y:886,t:1526919270411};\\\", \\\"{x:1376,y:894,t:1526919270429};\\\", \\\"{x:1377,y:899,t:1526919270445};\\\", \\\"{x:1377,y:900,t:1526919270462};\\\", \\\"{x:1379,y:902,t:1526919270491};\\\", \\\"{x:1379,y:903,t:1526919270522};\\\", \\\"{x:1380,y:901,t:1526919270674};\\\", \\\"{x:1383,y:896,t:1526919270695};\\\", \\\"{x:1385,y:894,t:1526919270711};\\\", \\\"{x:1386,y:892,t:1526919270730};\\\", \\\"{x:1386,y:891,t:1526919270754};\\\", \\\"{x:1387,y:891,t:1526919270778};\\\", \\\"{x:1388,y:890,t:1526919270866};\\\", \\\"{x:1388,y:889,t:1526919270993};\\\", \\\"{x:1389,y:889,t:1526919271257};\\\", \\\"{x:1390,y:889,t:1526919271265};\\\", \\\"{x:1393,y:887,t:1526919271278};\\\", \\\"{x:1395,y:885,t:1526919271295};\\\", \\\"{x:1398,y:883,t:1526919271312};\\\", \\\"{x:1401,y:879,t:1526919271328};\\\", \\\"{x:1408,y:871,t:1526919271345};\\\", \\\"{x:1410,y:865,t:1526919271362};\\\", \\\"{x:1413,y:858,t:1526919271378};\\\", \\\"{x:1417,y:851,t:1526919271396};\\\", \\\"{x:1418,y:845,t:1526919271412};\\\", \\\"{x:1419,y:837,t:1526919271428};\\\", \\\"{x:1419,y:833,t:1526919271445};\\\", \\\"{x:1420,y:828,t:1526919271460};\\\", \\\"{x:1420,y:820,t:1526919271476};\\\", \\\"{x:1420,y:813,t:1526919271493};\\\", \\\"{x:1421,y:805,t:1526919271511};\\\", \\\"{x:1422,y:796,t:1526919271526};\\\", \\\"{x:1423,y:785,t:1526919271543};\\\", \\\"{x:1423,y:778,t:1526919271560};\\\", \\\"{x:1423,y:771,t:1526919271578};\\\", \\\"{x:1423,y:765,t:1526919271594};\\\", \\\"{x:1422,y:759,t:1526919271611};\\\", \\\"{x:1421,y:752,t:1526919271628};\\\", \\\"{x:1421,y:747,t:1526919271644};\\\", \\\"{x:1419,y:739,t:1526919271661};\\\", \\\"{x:1417,y:732,t:1526919271677};\\\", \\\"{x:1417,y:724,t:1526919271693};\\\", \\\"{x:1416,y:717,t:1526919271711};\\\", \\\"{x:1415,y:707,t:1526919271727};\\\", \\\"{x:1413,y:702,t:1526919271743};\\\", \\\"{x:1413,y:696,t:1526919271760};\\\", \\\"{x:1412,y:690,t:1526919271778};\\\", \\\"{x:1412,y:683,t:1526919271793};\\\", \\\"{x:1411,y:679,t:1526919271810};\\\", \\\"{x:1411,y:673,t:1526919271828};\\\", \\\"{x:1411,y:669,t:1526919271843};\\\", \\\"{x:1411,y:668,t:1526919271861};\\\", \\\"{x:1411,y:666,t:1526919271877};\\\", \\\"{x:1411,y:672,t:1526919272088};\\\", \\\"{x:1411,y:683,t:1526919272096};\\\", \\\"{x:1411,y:695,t:1526919272110};\\\", \\\"{x:1413,y:730,t:1526919272128};\\\", \\\"{x:1416,y:753,t:1526919272144};\\\", \\\"{x:1419,y:775,t:1526919272160};\\\", \\\"{x:1421,y:786,t:1526919272177};\\\", \\\"{x:1422,y:793,t:1526919272194};\\\", \\\"{x:1423,y:797,t:1526919272211};\\\", \\\"{x:1424,y:800,t:1526919272228};\\\", \\\"{x:1424,y:798,t:1526919272304};\\\", \\\"{x:1424,y:791,t:1526919272312};\\\", \\\"{x:1424,y:773,t:1526919272327};\\\", \\\"{x:1424,y:759,t:1526919272344};\\\", \\\"{x:1424,y:741,t:1526919272360};\\\", \\\"{x:1424,y:726,t:1526919272378};\\\", \\\"{x:1424,y:715,t:1526919272395};\\\", \\\"{x:1424,y:705,t:1526919272411};\\\", \\\"{x:1424,y:694,t:1526919272428};\\\", \\\"{x:1424,y:684,t:1526919272445};\\\", \\\"{x:1424,y:671,t:1526919272461};\\\", \\\"{x:1424,y:659,t:1526919272478};\\\", \\\"{x:1424,y:651,t:1526919272495};\\\", \\\"{x:1424,y:647,t:1526919272511};\\\", \\\"{x:1424,y:636,t:1526919272528};\\\", \\\"{x:1424,y:629,t:1526919272544};\\\", \\\"{x:1424,y:625,t:1526919272561};\\\", \\\"{x:1424,y:621,t:1526919272577};\\\", \\\"{x:1425,y:618,t:1526919272595};\\\", \\\"{x:1425,y:615,t:1526919272611};\\\", \\\"{x:1425,y:611,t:1526919272628};\\\", \\\"{x:1425,y:609,t:1526919272645};\\\", \\\"{x:1427,y:604,t:1526919272660};\\\", \\\"{x:1427,y:601,t:1526919272677};\\\", \\\"{x:1427,y:599,t:1526919272695};\\\", \\\"{x:1427,y:598,t:1526919272711};\\\", \\\"{x:1429,y:598,t:1526919273913};\\\", \\\"{x:1432,y:600,t:1526919273928};\\\", \\\"{x:1439,y:609,t:1526919273945};\\\", \\\"{x:1442,y:611,t:1526919273961};\\\", \\\"{x:1446,y:615,t:1526919273979};\\\", \\\"{x:1448,y:616,t:1526919273995};\\\", \\\"{x:1448,y:617,t:1526919274015};\\\", \\\"{x:1449,y:617,t:1526919274032};\\\", \\\"{x:1451,y:619,t:1526919274048};\\\", \\\"{x:1451,y:620,t:1526919274063};\\\", \\\"{x:1453,y:621,t:1526919274088};\\\", \\\"{x:1454,y:622,t:1526919274232};\\\", \\\"{x:1455,y:622,t:1526919274245};\\\", \\\"{x:1455,y:623,t:1526919274272};\\\", \\\"{x:1455,y:626,t:1526919277600};\\\", \\\"{x:1441,y:639,t:1526919277614};\\\", \\\"{x:1404,y:667,t:1526919277630};\\\", \\\"{x:1332,y:717,t:1526919277646};\\\", \\\"{x:1203,y:814,t:1526919277664};\\\", \\\"{x:1144,y:841,t:1526919277680};\\\", \\\"{x:1052,y:854,t:1526919277697};\\\", \\\"{x:959,y:860,t:1526919277714};\\\", \\\"{x:876,y:860,t:1526919277729};\\\", \\\"{x:803,y:859,t:1526919277747};\\\", \\\"{x:761,y:852,t:1526919277764};\\\", \\\"{x:734,y:851,t:1526919277780};\\\", \\\"{x:714,y:850,t:1526919277797};\\\", \\\"{x:700,y:848,t:1526919277814};\\\", \\\"{x:690,y:846,t:1526919277830};\\\", \\\"{x:681,y:842,t:1526919277846};\\\", \\\"{x:671,y:836,t:1526919277864};\\\", \\\"{x:659,y:827,t:1526919277880};\\\", \\\"{x:650,y:817,t:1526919277897};\\\", \\\"{x:642,y:803,t:1526919277914};\\\", \\\"{x:638,y:789,t:1526919277929};\\\", \\\"{x:638,y:770,t:1526919277947};\\\", \\\"{x:638,y:755,t:1526919277963};\\\", \\\"{x:637,y:741,t:1526919277980};\\\", \\\"{x:633,y:725,t:1526919277996};\\\", \\\"{x:633,y:709,t:1526919278014};\\\", \\\"{x:632,y:693,t:1526919278030};\\\", \\\"{x:632,y:676,t:1526919278047};\\\", \\\"{x:632,y:659,t:1526919278064};\\\", \\\"{x:632,y:647,t:1526919278079};\\\", \\\"{x:632,y:639,t:1526919278097};\\\", \\\"{x:631,y:631,t:1526919278115};\\\", \\\"{x:629,y:625,t:1526919278130};\\\", \\\"{x:627,y:620,t:1526919278146};\\\", \\\"{x:623,y:614,t:1526919278171};\\\", \\\"{x:621,y:609,t:1526919278188};\\\", \\\"{x:619,y:604,t:1526919278205};\\\", \\\"{x:617,y:599,t:1526919278222};\\\", \\\"{x:614,y:595,t:1526919278238};\\\", \\\"{x:613,y:594,t:1526919278255};\\\", \\\"{x:613,y:592,t:1526919278271};\\\", \\\"{x:612,y:588,t:1526919278289};\\\", \\\"{x:610,y:586,t:1526919278305};\\\", \\\"{x:609,y:584,t:1526919278321};\\\", \\\"{x:607,y:580,t:1526919278338};\\\", \\\"{x:616,y:580,t:1526919278823};\\\", \\\"{x:647,y:585,t:1526919278839};\\\", \\\"{x:705,y:602,t:1526919278855};\\\", \\\"{x:769,y:619,t:1526919278873};\\\", \\\"{x:842,y:643,t:1526919278888};\\\", \\\"{x:914,y:661,t:1526919278905};\\\", \\\"{x:976,y:673,t:1526919278922};\\\", \\\"{x:1035,y:693,t:1526919278939};\\\", \\\"{x:1088,y:709,t:1526919278955};\\\", \\\"{x:1135,y:720,t:1526919278972};\\\", \\\"{x:1166,y:730,t:1526919278988};\\\", \\\"{x:1191,y:735,t:1526919279006};\\\", \\\"{x:1215,y:742,t:1526919279021};\\\", \\\"{x:1236,y:749,t:1526919279038};\\\", \\\"{x:1267,y:755,t:1526919279055};\\\", \\\"{x:1285,y:759,t:1526919279071};\\\", \\\"{x:1302,y:761,t:1526919279088};\\\", \\\"{x:1318,y:764,t:1526919279105};\\\", \\\"{x:1338,y:766,t:1526919279121};\\\", \\\"{x:1359,y:769,t:1526919279139};\\\", \\\"{x:1377,y:772,t:1526919279156};\\\", \\\"{x:1392,y:775,t:1526919279172};\\\", \\\"{x:1406,y:777,t:1526919279189};\\\", \\\"{x:1419,y:782,t:1526919279204};\\\", \\\"{x:1429,y:785,t:1526919279221};\\\", \\\"{x:1434,y:786,t:1526919279239};\\\", \\\"{x:1442,y:789,t:1526919279255};\\\", \\\"{x:1456,y:791,t:1526919279271};\\\", \\\"{x:1469,y:792,t:1526919279289};\\\", \\\"{x:1480,y:792,t:1526919279305};\\\", \\\"{x:1488,y:792,t:1526919279322};\\\", \\\"{x:1492,y:790,t:1526919279339};\\\", \\\"{x:1496,y:787,t:1526919279355};\\\", \\\"{x:1500,y:784,t:1526919279372};\\\", \\\"{x:1501,y:782,t:1526919279388};\\\", \\\"{x:1504,y:779,t:1526919279405};\\\", \\\"{x:1507,y:775,t:1526919279422};\\\", \\\"{x:1508,y:773,t:1526919279439};\\\", \\\"{x:1511,y:770,t:1526919279456};\\\", \\\"{x:1513,y:768,t:1526919279472};\\\", \\\"{x:1514,y:767,t:1526919279487};\\\", \\\"{x:1514,y:766,t:1526919279504};\\\", \\\"{x:1516,y:765,t:1526919279522};\\\", \\\"{x:1517,y:764,t:1526919279608};\\\", \\\"{x:1518,y:764,t:1526919279704};\\\", \\\"{x:1519,y:764,t:1526919279720};\\\", \\\"{x:1520,y:764,t:1526919279751};\\\", \\\"{x:1521,y:764,t:1526919279761};\\\", \\\"{x:1522,y:764,t:1526919279771};\\\", \\\"{x:1523,y:764,t:1526919279788};\\\", \\\"{x:1525,y:763,t:1526919279804};\\\", \\\"{x:1526,y:763,t:1526919279880};\\\", \\\"{x:1530,y:766,t:1526919283648};\\\", \\\"{x:1532,y:770,t:1526919283665};\\\", \\\"{x:1533,y:772,t:1526919283681};\\\", \\\"{x:1534,y:772,t:1526919283698};\\\", \\\"{x:1535,y:774,t:1526919283760};\\\", \\\"{x:1536,y:776,t:1526919283767};\\\", \\\"{x:1537,y:777,t:1526919283781};\\\", \\\"{x:1539,y:781,t:1526919283798};\\\", \\\"{x:1540,y:783,t:1526919283814};\\\", \\\"{x:1541,y:786,t:1526919283831};\\\", \\\"{x:1543,y:791,t:1526919283847};\\\", \\\"{x:1545,y:797,t:1526919283864};\\\", \\\"{x:1547,y:802,t:1526919283881};\\\", \\\"{x:1549,y:808,t:1526919283898};\\\", \\\"{x:1551,y:815,t:1526919283914};\\\", \\\"{x:1553,y:821,t:1526919283931};\\\", \\\"{x:1556,y:826,t:1526919283947};\\\", \\\"{x:1557,y:830,t:1526919283964};\\\", \\\"{x:1559,y:833,t:1526919283981};\\\", \\\"{x:1560,y:837,t:1526919283997};\\\", \\\"{x:1563,y:843,t:1526919284014};\\\", \\\"{x:1571,y:856,t:1526919284031};\\\", \\\"{x:1574,y:861,t:1526919284047};\\\", \\\"{x:1580,y:870,t:1526919284064};\\\", \\\"{x:1584,y:876,t:1526919284081};\\\", \\\"{x:1588,y:882,t:1526919284097};\\\", \\\"{x:1592,y:886,t:1526919284115};\\\", \\\"{x:1594,y:891,t:1526919284130};\\\", \\\"{x:1598,y:896,t:1526919284148};\\\", \\\"{x:1602,y:902,t:1526919284165};\\\", \\\"{x:1605,y:907,t:1526919284180};\\\", \\\"{x:1609,y:912,t:1526919284197};\\\", \\\"{x:1612,y:915,t:1526919284214};\\\", \\\"{x:1613,y:917,t:1526919284230};\\\", \\\"{x:1616,y:921,t:1526919284247};\\\", \\\"{x:1618,y:924,t:1526919284264};\\\", \\\"{x:1620,y:927,t:1526919284280};\\\", \\\"{x:1622,y:930,t:1526919284297};\\\", \\\"{x:1622,y:932,t:1526919284313};\\\", \\\"{x:1624,y:933,t:1526919284330};\\\", \\\"{x:1625,y:934,t:1526919284347};\\\", \\\"{x:1625,y:935,t:1526919284368};\\\", \\\"{x:1625,y:936,t:1526919284392};\\\", \\\"{x:1625,y:937,t:1526919284400};\\\", \\\"{x:1625,y:938,t:1526919284413};\\\", \\\"{x:1625,y:939,t:1526919284430};\\\", \\\"{x:1625,y:941,t:1526919284448};\\\", \\\"{x:1625,y:943,t:1526919284472};\\\", \\\"{x:1625,y:944,t:1526919284480};\\\", \\\"{x:1625,y:945,t:1526919284496};\\\", \\\"{x:1625,y:946,t:1526919284513};\\\", \\\"{x:1625,y:947,t:1526919284530};\\\", \\\"{x:1625,y:948,t:1526919284551};\\\", \\\"{x:1625,y:949,t:1526919284563};\\\", \\\"{x:1625,y:950,t:1526919284580};\\\", \\\"{x:1625,y:952,t:1526919284596};\\\", \\\"{x:1624,y:953,t:1526919284613};\\\", \\\"{x:1623,y:954,t:1526919286792};\\\", \\\"{x:1622,y:954,t:1526919286864};\\\", \\\"{x:1620,y:954,t:1526919287080};\\\", \\\"{x:1619,y:954,t:1526919287112};\\\", \\\"{x:1617,y:954,t:1526919287136};\\\", \\\"{x:1616,y:955,t:1526919287168};\\\", \\\"{x:1614,y:955,t:1526919287200};\\\", \\\"{x:1613,y:956,t:1526919287216};\\\", \\\"{x:1611,y:956,t:1526919287232};\\\", \\\"{x:1610,y:956,t:1526919287243};\\\", \\\"{x:1608,y:956,t:1526919287258};\\\", \\\"{x:1607,y:956,t:1526919287275};\\\", \\\"{x:1606,y:956,t:1526919287292};\\\", \\\"{x:1605,y:956,t:1526919287308};\\\", \\\"{x:1604,y:957,t:1526919287343};\\\", \\\"{x:1603,y:957,t:1526919287358};\\\", \\\"{x:1601,y:958,t:1526919287375};\\\", \\\"{x:1599,y:958,t:1526919287535};\\\", \\\"{x:1599,y:957,t:1526919287543};\\\", \\\"{x:1599,y:955,t:1526919287558};\\\", \\\"{x:1598,y:952,t:1526919287574};\\\", \\\"{x:1598,y:946,t:1526919287591};\\\", \\\"{x:1597,y:941,t:1526919287608};\\\", \\\"{x:1597,y:934,t:1526919287624};\\\", \\\"{x:1597,y:927,t:1526919287641};\\\", \\\"{x:1596,y:921,t:1526919287658};\\\", \\\"{x:1596,y:914,t:1526919287674};\\\", \\\"{x:1596,y:907,t:1526919287691};\\\", \\\"{x:1594,y:897,t:1526919287708};\\\", \\\"{x:1594,y:888,t:1526919287724};\\\", \\\"{x:1594,y:879,t:1526919287742};\\\", \\\"{x:1594,y:866,t:1526919287758};\\\", \\\"{x:1594,y:855,t:1526919287774};\\\", \\\"{x:1594,y:838,t:1526919287792};\\\", \\\"{x:1594,y:830,t:1526919287808};\\\", \\\"{x:1594,y:821,t:1526919287825};\\\", \\\"{x:1594,y:813,t:1526919287842};\\\", \\\"{x:1594,y:804,t:1526919287858};\\\", \\\"{x:1594,y:793,t:1526919287875};\\\", \\\"{x:1594,y:786,t:1526919287891};\\\", \\\"{x:1594,y:778,t:1526919287907};\\\", \\\"{x:1594,y:768,t:1526919287924};\\\", \\\"{x:1594,y:761,t:1526919287941};\\\", \\\"{x:1594,y:754,t:1526919287958};\\\", \\\"{x:1594,y:745,t:1526919287974};\\\", \\\"{x:1594,y:736,t:1526919287991};\\\", \\\"{x:1594,y:731,t:1526919288008};\\\", \\\"{x:1594,y:726,t:1526919288024};\\\", \\\"{x:1594,y:721,t:1526919288040};\\\", \\\"{x:1594,y:716,t:1526919288058};\\\", \\\"{x:1594,y:712,t:1526919288074};\\\", \\\"{x:1594,y:710,t:1526919288090};\\\", \\\"{x:1594,y:708,t:1526919288107};\\\", \\\"{x:1594,y:705,t:1526919288125};\\\", \\\"{x:1594,y:703,t:1526919288140};\\\", \\\"{x:1594,y:699,t:1526919288157};\\\", \\\"{x:1594,y:694,t:1526919288175};\\\", \\\"{x:1594,y:688,t:1526919288190};\\\", \\\"{x:1594,y:683,t:1526919288207};\\\", \\\"{x:1594,y:680,t:1526919288223};\\\", \\\"{x:1595,y:678,t:1526919288240};\\\", \\\"{x:1595,y:677,t:1526919288258};\\\", \\\"{x:1595,y:675,t:1526919288273};\\\", \\\"{x:1595,y:674,t:1526919288290};\\\", \\\"{x:1595,y:673,t:1526919288327};\\\", \\\"{x:1595,y:672,t:1526919288340};\\\", \\\"{x:1595,y:671,t:1526919288357};\\\", \\\"{x:1596,y:669,t:1526919288373};\\\", \\\"{x:1596,y:668,t:1526919288415};\\\", \\\"{x:1596,y:667,t:1526919288520};\\\", \\\"{x:1596,y:666,t:1526919288528};\\\", \\\"{x:1596,y:664,t:1526919288540};\\\", \\\"{x:1597,y:662,t:1526919288560};\\\", \\\"{x:1597,y:661,t:1526919288575};\\\", \\\"{x:1597,y:659,t:1526919288600};\\\", \\\"{x:1598,y:658,t:1526919288608};\\\", \\\"{x:1598,y:656,t:1526919288624};\\\", \\\"{x:1598,y:654,t:1526919288639};\\\", \\\"{x:1598,y:652,t:1526919288656};\\\", \\\"{x:1598,y:651,t:1526919288673};\\\", \\\"{x:1598,y:649,t:1526919288689};\\\", \\\"{x:1598,y:648,t:1526919288719};\\\", \\\"{x:1598,y:646,t:1526919288736};\\\", \\\"{x:1598,y:645,t:1526919288776};\\\", \\\"{x:1598,y:644,t:1526919288800};\\\", \\\"{x:1598,y:643,t:1526919288816};\\\", \\\"{x:1598,y:642,t:1526919288832};\\\", \\\"{x:1598,y:641,t:1526919288848};\\\", \\\"{x:1598,y:640,t:1526919288856};\\\", \\\"{x:1598,y:638,t:1526919288872};\\\", \\\"{x:1598,y:636,t:1526919288890};\\\", \\\"{x:1598,y:633,t:1526919288907};\\\", \\\"{x:1597,y:630,t:1526919288923};\\\", \\\"{x:1596,y:627,t:1526919288939};\\\", \\\"{x:1596,y:623,t:1526919288956};\\\", \\\"{x:1595,y:618,t:1526919288972};\\\", \\\"{x:1595,y:610,t:1526919288989};\\\", \\\"{x:1593,y:601,t:1526919289005};\\\", \\\"{x:1593,y:591,t:1526919289023};\\\", \\\"{x:1593,y:577,t:1526919289040};\\\", \\\"{x:1593,y:571,t:1526919289055};\\\", \\\"{x:1593,y:563,t:1526919289072};\\\", \\\"{x:1593,y:554,t:1526919289089};\\\", \\\"{x:1593,y:548,t:1526919289106};\\\", \\\"{x:1593,y:541,t:1526919289122};\\\", \\\"{x:1593,y:535,t:1526919289139};\\\", \\\"{x:1593,y:529,t:1526919289155};\\\", \\\"{x:1593,y:525,t:1526919289172};\\\", \\\"{x:1593,y:524,t:1526919289188};\\\", \\\"{x:1593,y:523,t:1526919289205};\\\", \\\"{x:1593,y:529,t:1526919289280};\\\", \\\"{x:1593,y:536,t:1526919289288};\\\", \\\"{x:1593,y:551,t:1526919289305};\\\", \\\"{x:1592,y:568,t:1526919289322};\\\", \\\"{x:1592,y:587,t:1526919289338};\\\", \\\"{x:1592,y:602,t:1526919289355};\\\", \\\"{x:1593,y:612,t:1526919289372};\\\", \\\"{x:1596,y:621,t:1526919289388};\\\", \\\"{x:1597,y:628,t:1526919289405};\\\", \\\"{x:1598,y:638,t:1526919289422};\\\", \\\"{x:1599,y:648,t:1526919289439};\\\", \\\"{x:1601,y:673,t:1526919289456};\\\", \\\"{x:1601,y:692,t:1526919289472};\\\", \\\"{x:1597,y:708,t:1526919289489};\\\", \\\"{x:1590,y:722,t:1526919289505};\\\", \\\"{x:1586,y:727,t:1526919289521};\\\", \\\"{x:1583,y:730,t:1526919289538};\\\", \\\"{x:1576,y:733,t:1526919289554};\\\", \\\"{x:1568,y:737,t:1526919289572};\\\", \\\"{x:1554,y:740,t:1526919289589};\\\", \\\"{x:1516,y:749,t:1526919289605};\\\", \\\"{x:1461,y:765,t:1526919289622};\\\", \\\"{x:1401,y:775,t:1526919289639};\\\", \\\"{x:1332,y:784,t:1526919289655};\\\", \\\"{x:1201,y:797,t:1526919289672};\\\", \\\"{x:1118,y:797,t:1526919289687};\\\", \\\"{x:1044,y:802,t:1526919289705};\\\", \\\"{x:983,y:802,t:1526919289722};\\\", \\\"{x:935,y:804,t:1526919289738};\\\", \\\"{x:890,y:804,t:1526919289754};\\\", \\\"{x:842,y:804,t:1526919289771};\\\", \\\"{x:803,y:804,t:1526919289787};\\\", \\\"{x:767,y:804,t:1526919289803};\\\", \\\"{x:723,y:804,t:1526919289820};\\\", \\\"{x:676,y:804,t:1526919289837};\\\", \\\"{x:635,y:802,t:1526919289854};\\\", \\\"{x:594,y:797,t:1526919289871};\\\", \\\"{x:576,y:795,t:1526919289886};\\\", \\\"{x:562,y:792,t:1526919289904};\\\", \\\"{x:551,y:789,t:1526919289921};\\\", \\\"{x:541,y:786,t:1526919289936};\\\", \\\"{x:531,y:784,t:1526919289954};\\\", \\\"{x:521,y:779,t:1526919289970};\\\", \\\"{x:508,y:775,t:1526919289987};\\\", \\\"{x:499,y:774,t:1526919290003};\\\", \\\"{x:493,y:772,t:1526919290020};\\\", \\\"{x:489,y:772,t:1526919290036};\\\", \\\"{x:487,y:771,t:1526919290053};\\\", \\\"{x:486,y:771,t:1526919290069};\\\", \\\"{x:479,y:767,t:1526919290087};\\\", \\\"{x:476,y:765,t:1526919290103};\\\", \\\"{x:475,y:764,t:1526919290119};\\\", \\\"{x:474,y:764,t:1526919290137};\\\", \\\"{x:473,y:763,t:1526919290174};\\\", \\\"{x:471,y:762,t:1526919290214};\\\", \\\"{x:471,y:761,t:1526919290230};\\\", \\\"{x:470,y:761,t:1526919290246};\\\", \\\"{x:470,y:760,t:1526919290279};\\\", \\\"{x:470,y:759,t:1526919290310};\\\", \\\"{x:470,y:758,t:1526919290320};\\\", \\\"{x:470,y:757,t:1526919290337};\\\", \\\"{x:470,y:755,t:1526919290353};\\\", \\\"{x:470,y:753,t:1526919290370};\\\", \\\"{x:471,y:749,t:1526919290387};\\\", \\\"{x:473,y:747,t:1526919290403};\\\", \\\"{x:474,y:745,t:1526919290426};\\\", \\\"{x:475,y:745,t:1526919290444};\\\", \\\"{x:475,y:743,t:1526919290459};\\\", \\\"{x:476,y:741,t:1526919290476};\\\", \\\"{x:478,y:740,t:1526919290494};\\\", \\\"{x:479,y:738,t:1526919290509};\\\", \\\"{x:480,y:737,t:1526919290527};\\\", \\\"{x:480,y:736,t:1526919290623};\\\" ] }, { \\\"rt\\\": 10800, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 574391, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:736,t:1526919296590};\\\", \\\"{x:492,y:740,t:1526919296603};\\\", \\\"{x:518,y:750,t:1526919296620};\\\", \\\"{x:544,y:758,t:1526919296636};\\\", \\\"{x:564,y:765,t:1526919296653};\\\", \\\"{x:590,y:773,t:1526919296669};\\\", \\\"{x:606,y:778,t:1526919296686};\\\", \\\"{x:616,y:784,t:1526919296702};\\\", \\\"{x:626,y:792,t:1526919296719};\\\", \\\"{x:644,y:807,t:1526919296736};\\\", \\\"{x:651,y:813,t:1526919296752};\\\", \\\"{x:656,y:821,t:1526919296769};\\\", \\\"{x:659,y:821,t:1526919298183};\\\", \\\"{x:668,y:824,t:1526919298190};\\\", \\\"{x:676,y:824,t:1526919298203};\\\", \\\"{x:695,y:825,t:1526919298220};\\\", \\\"{x:718,y:829,t:1526919298237};\\\", \\\"{x:745,y:837,t:1526919298253};\\\", \\\"{x:783,y:850,t:1526919298270};\\\", \\\"{x:839,y:872,t:1526919298287};\\\", \\\"{x:867,y:882,t:1526919298303};\\\", \\\"{x:894,y:893,t:1526919298320};\\\", \\\"{x:916,y:902,t:1526919298337};\\\", \\\"{x:945,y:913,t:1526919298352};\\\", \\\"{x:966,y:923,t:1526919298370};\\\", \\\"{x:986,y:928,t:1526919298387};\\\", \\\"{x:1001,y:933,t:1526919298403};\\\", \\\"{x:1015,y:934,t:1526919298420};\\\", \\\"{x:1028,y:936,t:1526919298437};\\\", \\\"{x:1038,y:938,t:1526919298453};\\\", \\\"{x:1051,y:940,t:1526919298470};\\\", \\\"{x:1078,y:949,t:1526919298486};\\\", \\\"{x:1099,y:954,t:1526919298503};\\\", \\\"{x:1127,y:960,t:1526919298520};\\\", \\\"{x:1151,y:961,t:1526919298537};\\\", \\\"{x:1171,y:962,t:1526919298553};\\\", \\\"{x:1188,y:962,t:1526919298570};\\\", \\\"{x:1204,y:962,t:1526919298587};\\\", \\\"{x:1216,y:962,t:1526919298603};\\\", \\\"{x:1229,y:963,t:1526919298620};\\\", \\\"{x:1242,y:963,t:1526919298637};\\\", \\\"{x:1260,y:963,t:1526919298653};\\\", \\\"{x:1281,y:963,t:1526919298670};\\\", \\\"{x:1301,y:963,t:1526919298686};\\\", \\\"{x:1310,y:963,t:1526919298703};\\\", \\\"{x:1312,y:963,t:1526919298720};\\\", \\\"{x:1314,y:963,t:1526919298737};\\\", \\\"{x:1317,y:963,t:1526919298753};\\\", \\\"{x:1321,y:963,t:1526919298770};\\\", \\\"{x:1328,y:963,t:1526919298787};\\\", \\\"{x:1332,y:963,t:1526919298803};\\\", \\\"{x:1338,y:963,t:1526919298820};\\\", \\\"{x:1339,y:963,t:1526919298837};\\\", \\\"{x:1342,y:963,t:1526919298853};\\\", \\\"{x:1344,y:963,t:1526919298870};\\\", \\\"{x:1349,y:963,t:1526919298887};\\\", \\\"{x:1353,y:963,t:1526919298903};\\\", \\\"{x:1354,y:963,t:1526919298920};\\\", \\\"{x:1355,y:963,t:1526919298937};\\\", \\\"{x:1356,y:964,t:1526919298958};\\\", \\\"{x:1357,y:964,t:1526919298970};\\\", \\\"{x:1357,y:965,t:1526919299055};\\\", \\\"{x:1355,y:968,t:1526919299536};\\\", \\\"{x:1335,y:968,t:1526919299544};\\\", \\\"{x:1312,y:968,t:1526919299554};\\\", \\\"{x:1234,y:968,t:1526919299570};\\\", \\\"{x:1154,y:955,t:1526919299588};\\\", \\\"{x:1040,y:925,t:1526919299605};\\\", \\\"{x:921,y:891,t:1526919299621};\\\", \\\"{x:813,y:854,t:1526919299637};\\\", \\\"{x:726,y:823,t:1526919299654};\\\", \\\"{x:629,y:786,t:1526919299670};\\\", \\\"{x:592,y:769,t:1526919299687};\\\", \\\"{x:570,y:763,t:1526919299703};\\\", \\\"{x:554,y:755,t:1526919299720};\\\", \\\"{x:546,y:752,t:1526919299737};\\\", \\\"{x:538,y:745,t:1526919299754};\\\", \\\"{x:531,y:738,t:1526919299772};\\\", \\\"{x:525,y:731,t:1526919299788};\\\", \\\"{x:515,y:721,t:1526919299804};\\\", \\\"{x:499,y:709,t:1526919299822};\\\", \\\"{x:480,y:696,t:1526919299839};\\\", \\\"{x:458,y:685,t:1526919299855};\\\", \\\"{x:434,y:675,t:1526919299872};\\\", \\\"{x:406,y:665,t:1526919299889};\\\", \\\"{x:382,y:655,t:1526919299906};\\\", \\\"{x:356,y:647,t:1526919299922};\\\", \\\"{x:333,y:641,t:1526919299939};\\\", \\\"{x:316,y:636,t:1526919299956};\\\", \\\"{x:305,y:631,t:1526919299972};\\\", \\\"{x:299,y:628,t:1526919299988};\\\", \\\"{x:293,y:622,t:1526919300005};\\\", \\\"{x:289,y:618,t:1526919300023};\\\", \\\"{x:284,y:611,t:1526919300038};\\\", \\\"{x:281,y:606,t:1526919300055};\\\", \\\"{x:274,y:602,t:1526919300072};\\\", \\\"{x:268,y:597,t:1526919300090};\\\", \\\"{x:254,y:592,t:1526919300105};\\\", \\\"{x:245,y:589,t:1526919300122};\\\", \\\"{x:231,y:584,t:1526919300139};\\\", \\\"{x:219,y:578,t:1526919300156};\\\", \\\"{x:210,y:575,t:1526919300172};\\\", \\\"{x:204,y:573,t:1526919300189};\\\", \\\"{x:200,y:571,t:1526919300206};\\\", \\\"{x:196,y:568,t:1526919300223};\\\", \\\"{x:193,y:566,t:1526919300239};\\\", \\\"{x:188,y:563,t:1526919300256};\\\", \\\"{x:183,y:560,t:1526919300274};\\\", \\\"{x:180,y:558,t:1526919300289};\\\", \\\"{x:176,y:556,t:1526919300305};\\\", \\\"{x:174,y:555,t:1526919300323};\\\", \\\"{x:171,y:553,t:1526919300340};\\\", \\\"{x:168,y:549,t:1526919300356};\\\", \\\"{x:167,y:548,t:1526919300373};\\\", \\\"{x:166,y:548,t:1526919300389};\\\", \\\"{x:165,y:547,t:1526919300406};\\\", \\\"{x:169,y:545,t:1526919300678};\\\", \\\"{x:176,y:544,t:1526919300690};\\\", \\\"{x:196,y:536,t:1526919300706};\\\", \\\"{x:226,y:528,t:1526919300723};\\\", \\\"{x:263,y:523,t:1526919300741};\\\", \\\"{x:301,y:519,t:1526919300755};\\\", \\\"{x:341,y:513,t:1526919300773};\\\", \\\"{x:409,y:506,t:1526919300791};\\\", \\\"{x:468,y:503,t:1526919300806};\\\", \\\"{x:522,y:501,t:1526919300823};\\\", \\\"{x:556,y:501,t:1526919300840};\\\", \\\"{x:581,y:501,t:1526919300856};\\\", \\\"{x:593,y:501,t:1526919300873};\\\", \\\"{x:601,y:501,t:1526919300890};\\\", \\\"{x:606,y:502,t:1526919300906};\\\", \\\"{x:618,y:506,t:1526919300923};\\\", \\\"{x:631,y:511,t:1526919300940};\\\", \\\"{x:645,y:514,t:1526919300957};\\\", \\\"{x:656,y:518,t:1526919300973};\\\", \\\"{x:662,y:520,t:1526919300990};\\\", \\\"{x:663,y:521,t:1526919301006};\\\", \\\"{x:664,y:521,t:1526919301023};\\\", \\\"{x:664,y:523,t:1526919301040};\\\", \\\"{x:661,y:528,t:1526919301057};\\\", \\\"{x:648,y:535,t:1526919301073};\\\", \\\"{x:629,y:545,t:1526919301090};\\\", \\\"{x:606,y:554,t:1526919301107};\\\", \\\"{x:576,y:562,t:1526919301123};\\\", \\\"{x:549,y:566,t:1526919301140};\\\", \\\"{x:528,y:567,t:1526919301156};\\\", \\\"{x:513,y:567,t:1526919301173};\\\", \\\"{x:512,y:567,t:1526919301189};\\\", \\\"{x:522,y:562,t:1526919301223};\\\", \\\"{x:548,y:550,t:1526919301240};\\\", \\\"{x:586,y:536,t:1526919301257};\\\", \\\"{x:638,y:523,t:1526919301273};\\\", \\\"{x:700,y:513,t:1526919301291};\\\", \\\"{x:753,y:506,t:1526919301307};\\\", \\\"{x:795,y:500,t:1526919301324};\\\", \\\"{x:823,y:497,t:1526919301340};\\\", \\\"{x:844,y:492,t:1526919301357};\\\", \\\"{x:861,y:491,t:1526919301374};\\\", \\\"{x:866,y:490,t:1526919301390};\\\", \\\"{x:869,y:489,t:1526919301407};\\\", \\\"{x:870,y:489,t:1526919301423};\\\", \\\"{x:872,y:489,t:1526919301446};\\\", \\\"{x:873,y:489,t:1526919301457};\\\", \\\"{x:877,y:489,t:1526919301474};\\\", \\\"{x:880,y:489,t:1526919301490};\\\", \\\"{x:881,y:489,t:1526919301534};\\\", \\\"{x:880,y:489,t:1526919301607};\\\", \\\"{x:878,y:489,t:1526919301624};\\\", \\\"{x:877,y:489,t:1526919301671};\\\", \\\"{x:872,y:494,t:1526919301878};\\\", \\\"{x:861,y:502,t:1526919301891};\\\", \\\"{x:829,y:525,t:1526919301908};\\\", \\\"{x:779,y:558,t:1526919301925};\\\", \\\"{x:733,y:583,t:1526919301941};\\\", \\\"{x:703,y:603,t:1526919301957};\\\", \\\"{x:672,y:626,t:1526919301974};\\\", \\\"{x:655,y:638,t:1526919301991};\\\", \\\"{x:639,y:652,t:1526919302008};\\\", \\\"{x:624,y:663,t:1526919302024};\\\", \\\"{x:614,y:670,t:1526919302041};\\\", \\\"{x:608,y:674,t:1526919302057};\\\", \\\"{x:605,y:676,t:1526919302074};\\\", \\\"{x:604,y:677,t:1526919302090};\\\", \\\"{x:603,y:677,t:1526919302150};\\\", \\\"{x:602,y:677,t:1526919302158};\\\", \\\"{x:595,y:685,t:1526919302174};\\\", \\\"{x:593,y:688,t:1526919302190};\\\", \\\"{x:589,y:697,t:1526919302207};\\\", \\\"{x:586,y:701,t:1526919302224};\\\", \\\"{x:583,y:705,t:1526919302240};\\\", \\\"{x:583,y:706,t:1526919302257};\\\", \\\"{x:582,y:708,t:1526919302273};\\\", \\\"{x:583,y:708,t:1526919302318};\\\", \\\"{x:589,y:706,t:1526919302326};\\\", \\\"{x:597,y:699,t:1526919302340};\\\", \\\"{x:623,y:676,t:1526919302358};\\\", \\\"{x:656,y:649,t:1526919302373};\\\", \\\"{x:694,y:617,t:1526919302390};\\\", \\\"{x:754,y:574,t:1526919302408};\\\", \\\"{x:781,y:552,t:1526919302425};\\\", \\\"{x:796,y:542,t:1526919302441};\\\", \\\"{x:805,y:533,t:1526919302458};\\\", \\\"{x:809,y:527,t:1526919302474};\\\", \\\"{x:812,y:523,t:1526919302492};\\\", \\\"{x:814,y:521,t:1526919302508};\\\", \\\"{x:816,y:518,t:1526919302523};\\\", \\\"{x:816,y:517,t:1526919302542};\\\", \\\"{x:817,y:516,t:1526919302558};\\\", \\\"{x:817,y:515,t:1526919302631};\\\", \\\"{x:818,y:514,t:1526919302694};\\\", \\\"{x:819,y:513,t:1526919302708};\\\", \\\"{x:825,y:510,t:1526919302724};\\\", \\\"{x:829,y:508,t:1526919302741};\\\", \\\"{x:835,y:505,t:1526919302758};\\\", \\\"{x:836,y:505,t:1526919302775};\\\", \\\"{x:833,y:506,t:1526919302990};\\\", \\\"{x:829,y:510,t:1526919302998};\\\", \\\"{x:824,y:516,t:1526919303008};\\\", \\\"{x:808,y:534,t:1526919303025};\\\", \\\"{x:781,y:556,t:1526919303041};\\\", \\\"{x:753,y:578,t:1526919303058};\\\", \\\"{x:730,y:594,t:1526919303076};\\\", \\\"{x:714,y:608,t:1526919303091};\\\", \\\"{x:702,y:619,t:1526919303108};\\\", \\\"{x:692,y:630,t:1526919303125};\\\", \\\"{x:681,y:640,t:1526919303141};\\\", \\\"{x:667,y:653,t:1526919303158};\\\", \\\"{x:657,y:660,t:1526919303175};\\\", \\\"{x:646,y:669,t:1526919303191};\\\", \\\"{x:637,y:676,t:1526919303208};\\\", \\\"{x:630,y:681,t:1526919303225};\\\", \\\"{x:625,y:686,t:1526919303241};\\\", \\\"{x:620,y:691,t:1526919303258};\\\", \\\"{x:612,y:696,t:1526919303275};\\\", \\\"{x:608,y:700,t:1526919303291};\\\", \\\"{x:605,y:702,t:1526919303308};\\\", \\\"{x:602,y:702,t:1526919303324};\\\", \\\"{x:599,y:705,t:1526919303341};\\\", \\\"{x:597,y:706,t:1526919303358};\\\", \\\"{x:592,y:710,t:1526919303374};\\\", \\\"{x:588,y:713,t:1526919303392};\\\", \\\"{x:583,y:716,t:1526919303408};\\\", \\\"{x:576,y:722,t:1526919303424};\\\", \\\"{x:572,y:724,t:1526919303441};\\\", \\\"{x:568,y:727,t:1526919303458};\\\", \\\"{x:562,y:730,t:1526919303474};\\\", \\\"{x:558,y:733,t:1526919303491};\\\", \\\"{x:553,y:737,t:1526919303509};\\\", \\\"{x:547,y:741,t:1526919303525};\\\", \\\"{x:540,y:744,t:1526919303542};\\\", \\\"{x:538,y:745,t:1526919303559};\\\", \\\"{x:536,y:746,t:1526919303591};\\\", \\\"{x:535,y:746,t:1526919303598};\\\", \\\"{x:533,y:747,t:1526919303609};\\\", \\\"{x:531,y:747,t:1526919303625};\\\", \\\"{x:528,y:748,t:1526919303642};\\\", \\\"{x:527,y:748,t:1526919303662};\\\" ] }, { \\\"rt\\\": 16001, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 591635, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:748,t:1526919312087};\\\", \\\"{x:536,y:743,t:1526919312103};\\\", \\\"{x:542,y:739,t:1526919312118};\\\", \\\"{x:545,y:737,t:1526919312136};\\\", \\\"{x:548,y:736,t:1526919312153};\\\", \\\"{x:550,y:735,t:1526919312169};\\\", \\\"{x:556,y:733,t:1526919312186};\\\", \\\"{x:572,y:728,t:1526919312205};\\\", \\\"{x:598,y:727,t:1526919312219};\\\", \\\"{x:634,y:727,t:1526919312235};\\\", \\\"{x:670,y:731,t:1526919312249};\\\", \\\"{x:702,y:734,t:1526919312265};\\\", \\\"{x:722,y:737,t:1526919312282};\\\", \\\"{x:737,y:740,t:1526919312299};\\\", \\\"{x:749,y:741,t:1526919312315};\\\", \\\"{x:759,y:742,t:1526919312332};\\\", \\\"{x:768,y:742,t:1526919312350};\\\", \\\"{x:784,y:744,t:1526919312366};\\\", \\\"{x:793,y:746,t:1526919312383};\\\", \\\"{x:796,y:747,t:1526919312400};\\\", \\\"{x:798,y:747,t:1526919312416};\\\", \\\"{x:804,y:747,t:1526919312647};\\\", \\\"{x:815,y:747,t:1526919312655};\\\", \\\"{x:828,y:747,t:1526919312667};\\\", \\\"{x:853,y:747,t:1526919312684};\\\", \\\"{x:899,y:742,t:1526919312699};\\\", \\\"{x:954,y:742,t:1526919312717};\\\", \\\"{x:1003,y:740,t:1526919312734};\\\", \\\"{x:1048,y:740,t:1526919312749};\\\", \\\"{x:1102,y:740,t:1526919312767};\\\", \\\"{x:1132,y:740,t:1526919312784};\\\", \\\"{x:1156,y:739,t:1526919312800};\\\", \\\"{x:1173,y:739,t:1526919312817};\\\", \\\"{x:1183,y:739,t:1526919312833};\\\", \\\"{x:1190,y:739,t:1526919312850};\\\", \\\"{x:1196,y:737,t:1526919312867};\\\", \\\"{x:1200,y:735,t:1526919312884};\\\", \\\"{x:1210,y:731,t:1526919312901};\\\", \\\"{x:1216,y:730,t:1526919312917};\\\", \\\"{x:1220,y:728,t:1526919312933};\\\", \\\"{x:1225,y:726,t:1526919312950};\\\", \\\"{x:1226,y:726,t:1526919312966};\\\", \\\"{x:1227,y:726,t:1526919312984};\\\", \\\"{x:1225,y:726,t:1526919313231};\\\", \\\"{x:1221,y:728,t:1526919313238};\\\", \\\"{x:1213,y:732,t:1526919313251};\\\", \\\"{x:1193,y:739,t:1526919313268};\\\", \\\"{x:1148,y:747,t:1526919313284};\\\", \\\"{x:1090,y:754,t:1526919313301};\\\", \\\"{x:1007,y:754,t:1526919313318};\\\", \\\"{x:956,y:754,t:1526919313334};\\\", \\\"{x:897,y:754,t:1526919313351};\\\", \\\"{x:872,y:751,t:1526919313367};\\\", \\\"{x:857,y:749,t:1526919313384};\\\", \\\"{x:850,y:747,t:1526919313400};\\\", \\\"{x:847,y:746,t:1526919313417};\\\", \\\"{x:846,y:746,t:1526919313434};\\\", \\\"{x:843,y:746,t:1526919313451};\\\", \\\"{x:839,y:744,t:1526919313467};\\\", \\\"{x:836,y:743,t:1526919313484};\\\", \\\"{x:834,y:742,t:1526919313501};\\\", \\\"{x:832,y:740,t:1526919313518};\\\", \\\"{x:831,y:739,t:1526919313534};\\\", \\\"{x:830,y:737,t:1526919313550};\\\", \\\"{x:830,y:736,t:1526919313567};\\\", \\\"{x:830,y:735,t:1526919313591};\\\", \\\"{x:830,y:734,t:1526919313623};\\\", \\\"{x:829,y:734,t:1526919313703};\\\", \\\"{x:829,y:732,t:1526919313717};\\\", \\\"{x:823,y:729,t:1526919313735};\\\", \\\"{x:818,y:726,t:1526919313750};\\\", \\\"{x:811,y:721,t:1526919313768};\\\", \\\"{x:801,y:716,t:1526919313785};\\\", \\\"{x:788,y:708,t:1526919313801};\\\", \\\"{x:779,y:702,t:1526919313818};\\\", \\\"{x:769,y:694,t:1526919313835};\\\", \\\"{x:763,y:689,t:1526919313851};\\\", \\\"{x:759,y:684,t:1526919313869};\\\", \\\"{x:758,y:683,t:1526919313885};\\\", \\\"{x:757,y:681,t:1526919313902};\\\", \\\"{x:756,y:678,t:1526919313918};\\\", \\\"{x:755,y:678,t:1526919313935};\\\", \\\"{x:754,y:677,t:1526919313959};\\\", \\\"{x:754,y:676,t:1526919313983};\\\", \\\"{x:753,y:676,t:1526919313990};\\\", \\\"{x:752,y:676,t:1526919314002};\\\", \\\"{x:750,y:675,t:1526919314018};\\\", \\\"{x:748,y:675,t:1526919314035};\\\", \\\"{x:745,y:674,t:1526919314052};\\\", \\\"{x:744,y:674,t:1526919314068};\\\", \\\"{x:743,y:674,t:1526919314084};\\\", \\\"{x:742,y:674,t:1526919314263};\\\", \\\"{x:741,y:674,t:1526919314271};\\\", \\\"{x:739,y:674,t:1526919314284};\\\", \\\"{x:738,y:674,t:1526919314302};\\\", \\\"{x:735,y:674,t:1526919314318};\\\", \\\"{x:727,y:671,t:1526919314335};\\\", \\\"{x:718,y:669,t:1526919314365};\\\", \\\"{x:715,y:668,t:1526919314368};\\\", \\\"{x:711,y:666,t:1526919314385};\\\", \\\"{x:707,y:664,t:1526919314402};\\\", \\\"{x:703,y:662,t:1526919314419};\\\", \\\"{x:698,y:660,t:1526919314434};\\\", \\\"{x:694,y:658,t:1526919314451};\\\", \\\"{x:692,y:657,t:1526919314468};\\\", \\\"{x:688,y:655,t:1526919314485};\\\", \\\"{x:687,y:655,t:1526919314501};\\\", \\\"{x:686,y:655,t:1526919314518};\\\", \\\"{x:685,y:655,t:1526919314536};\\\", \\\"{x:684,y:655,t:1526919314551};\\\", \\\"{x:682,y:653,t:1526919314569};\\\", \\\"{x:681,y:653,t:1526919314591};\\\", \\\"{x:680,y:653,t:1526919314601};\\\", \\\"{x:679,y:652,t:1526919314619};\\\", \\\"{x:678,y:650,t:1526919314638};\\\", \\\"{x:677,y:650,t:1526919314654};\\\", \\\"{x:676,y:649,t:1526919314679};\\\", \\\"{x:675,y:649,t:1526919314695};\\\", \\\"{x:674,y:649,t:1526919314703};\\\", \\\"{x:672,y:648,t:1526919314727};\\\", \\\"{x:671,y:646,t:1526919314742};\\\", \\\"{x:670,y:646,t:1526919314775};\\\", \\\"{x:669,y:645,t:1526919314807};\\\", \\\"{x:667,y:645,t:1526919314823};\\\", \\\"{x:666,y:644,t:1526919314836};\\\", \\\"{x:662,y:642,t:1526919314853};\\\", \\\"{x:658,y:639,t:1526919314869};\\\", \\\"{x:653,y:635,t:1526919314887};\\\", \\\"{x:649,y:629,t:1526919314904};\\\", \\\"{x:645,y:625,t:1526919314919};\\\", \\\"{x:642,y:619,t:1526919314935};\\\", \\\"{x:639,y:613,t:1526919314951};\\\", \\\"{x:636,y:607,t:1526919314968};\\\", \\\"{x:635,y:598,t:1526919314985};\\\", \\\"{x:632,y:590,t:1526919315002};\\\", \\\"{x:632,y:583,t:1526919315018};\\\", \\\"{x:631,y:576,t:1526919315034};\\\", \\\"{x:631,y:571,t:1526919315051};\\\", \\\"{x:631,y:566,t:1526919315068};\\\", \\\"{x:631,y:560,t:1526919315085};\\\", \\\"{x:631,y:555,t:1526919315102};\\\", \\\"{x:631,y:553,t:1526919315117};\\\", \\\"{x:631,y:550,t:1526919315134};\\\", \\\"{x:633,y:545,t:1526919315152};\\\", \\\"{x:639,y:539,t:1526919315167};\\\", \\\"{x:648,y:531,t:1526919315185};\\\", \\\"{x:660,y:525,t:1526919315202};\\\", \\\"{x:677,y:520,t:1526919315218};\\\", \\\"{x:695,y:519,t:1526919315234};\\\", \\\"{x:721,y:514,t:1526919315253};\\\", \\\"{x:752,y:509,t:1526919315269};\\\", \\\"{x:783,y:504,t:1526919315284};\\\", \\\"{x:809,y:504,t:1526919315301};\\\", \\\"{x:832,y:504,t:1526919315318};\\\", \\\"{x:837,y:504,t:1526919315334};\\\", \\\"{x:839,y:504,t:1526919315352};\\\", \\\"{x:840,y:505,t:1526919315368};\\\", \\\"{x:842,y:507,t:1526919315384};\\\", \\\"{x:842,y:511,t:1526919315402};\\\", \\\"{x:841,y:520,t:1526919315419};\\\", \\\"{x:829,y:538,t:1526919315436};\\\", \\\"{x:807,y:555,t:1526919315452};\\\", \\\"{x:766,y:577,t:1526919315469};\\\", \\\"{x:699,y:598,t:1526919315485};\\\", \\\"{x:621,y:609,t:1526919315502};\\\", \\\"{x:504,y:620,t:1526919315518};\\\", \\\"{x:426,y:631,t:1526919315536};\\\", \\\"{x:367,y:634,t:1526919315552};\\\", \\\"{x:327,y:634,t:1526919315569};\\\", \\\"{x:303,y:634,t:1526919315584};\\\", \\\"{x:285,y:634,t:1526919315602};\\\", \\\"{x:267,y:634,t:1526919315618};\\\", \\\"{x:254,y:634,t:1526919315635};\\\", \\\"{x:239,y:634,t:1526919315652};\\\", \\\"{x:225,y:634,t:1526919315669};\\\", \\\"{x:215,y:634,t:1526919315685};\\\", \\\"{x:204,y:630,t:1526919315703};\\\", \\\"{x:195,y:626,t:1526919315719};\\\", \\\"{x:190,y:622,t:1526919315736};\\\", \\\"{x:185,y:618,t:1526919315751};\\\", \\\"{x:180,y:610,t:1526919315769};\\\", \\\"{x:179,y:602,t:1526919315786};\\\", \\\"{x:176,y:594,t:1526919315802};\\\", \\\"{x:174,y:588,t:1526919315820};\\\", \\\"{x:171,y:581,t:1526919315836};\\\", \\\"{x:169,y:575,t:1526919315852};\\\", \\\"{x:167,y:572,t:1526919315869};\\\", \\\"{x:166,y:568,t:1526919315887};\\\", \\\"{x:164,y:565,t:1526919315902};\\\", \\\"{x:164,y:561,t:1526919315919};\\\", \\\"{x:163,y:561,t:1526919315936};\\\", \\\"{x:163,y:559,t:1526919315952};\\\", \\\"{x:163,y:558,t:1526919316254};\\\", \\\"{x:162,y:555,t:1526919316270};\\\", \\\"{x:162,y:550,t:1526919316286};\\\", \\\"{x:162,y:546,t:1526919316302};\\\", \\\"{x:162,y:544,t:1526919316319};\\\", \\\"{x:162,y:543,t:1526919316336};\\\", \\\"{x:161,y:543,t:1526919316353};\\\", \\\"{x:167,y:543,t:1526919316606};\\\", \\\"{x:173,y:546,t:1526919316620};\\\", \\\"{x:186,y:555,t:1526919316637};\\\", \\\"{x:213,y:570,t:1526919316654};\\\", \\\"{x:251,y:591,t:1526919316669};\\\", \\\"{x:299,y:615,t:1526919316687};\\\", \\\"{x:357,y:646,t:1526919316703};\\\", \\\"{x:390,y:659,t:1526919316720};\\\", \\\"{x:418,y:676,t:1526919316736};\\\", \\\"{x:438,y:688,t:1526919316753};\\\", \\\"{x:449,y:694,t:1526919316769};\\\", \\\"{x:457,y:698,t:1526919316786};\\\", \\\"{x:463,y:701,t:1526919316803};\\\", \\\"{x:471,y:705,t:1526919316820};\\\", \\\"{x:481,y:710,t:1526919316836};\\\", \\\"{x:497,y:716,t:1526919316853};\\\", \\\"{x:518,y:723,t:1526919316871};\\\", \\\"{x:543,y:732,t:1526919316886};\\\", \\\"{x:554,y:737,t:1526919316903};\\\", \\\"{x:558,y:740,t:1526919316920};\\\", \\\"{x:559,y:740,t:1526919316936};\\\", \\\"{x:560,y:740,t:1526919316952};\\\", \\\"{x:561,y:740,t:1526919316982};\\\", \\\"{x:561,y:741,t:1526919317031};\\\", \\\"{x:560,y:741,t:1526919317287};\\\", \\\"{x:559,y:741,t:1526919317304};\\\", \\\"{x:557,y:741,t:1526919317320};\\\", \\\"{x:556,y:741,t:1526919317337};\\\", \\\"{x:555,y:741,t:1526919317354};\\\", \\\"{x:554,y:741,t:1526919317370};\\\", \\\"{x:553,y:741,t:1526919317398};\\\" ] }, { \\\"rt\\\": 21823, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 614651, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-M -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:741,t:1526919326119};\\\", \\\"{x:552,y:740,t:1526919326126};\\\", \\\"{x:552,y:739,t:1526919326695};\\\", \\\"{x:552,y:737,t:1526919326735};\\\", \\\"{x:553,y:737,t:1526919326743};\\\", \\\"{x:560,y:736,t:1526919326758};\\\", \\\"{x:567,y:733,t:1526919326777};\\\", \\\"{x:576,y:732,t:1526919326792};\\\", \\\"{x:582,y:728,t:1526919326811};\\\", \\\"{x:586,y:727,t:1526919326827};\\\", \\\"{x:592,y:724,t:1526919326844};\\\", \\\"{x:595,y:724,t:1526919326861};\\\", \\\"{x:597,y:723,t:1526919326877};\\\", \\\"{x:600,y:722,t:1526919326894};\\\", \\\"{x:602,y:722,t:1526919326934};\\\", \\\"{x:602,y:721,t:1526919326944};\\\", \\\"{x:603,y:721,t:1526919326961};\\\", \\\"{x:604,y:721,t:1526919326978};\\\", \\\"{x:605,y:721,t:1526919326994};\\\", \\\"{x:606,y:720,t:1526919327011};\\\", \\\"{x:608,y:720,t:1526919327029};\\\", \\\"{x:609,y:720,t:1526919327054};\\\", \\\"{x:610,y:719,t:1526919327119};\\\", \\\"{x:611,y:719,t:1526919327129};\\\", \\\"{x:612,y:719,t:1526919327151};\\\", \\\"{x:614,y:719,t:1526919327167};\\\", \\\"{x:616,y:719,t:1526919327179};\\\", \\\"{x:622,y:719,t:1526919327195};\\\", \\\"{x:630,y:719,t:1526919327211};\\\", \\\"{x:642,y:719,t:1526919327229};\\\", \\\"{x:660,y:724,t:1526919327244};\\\", \\\"{x:680,y:730,t:1526919327262};\\\", \\\"{x:714,y:739,t:1526919327279};\\\", \\\"{x:733,y:743,t:1526919327294};\\\", \\\"{x:750,y:748,t:1526919327312};\\\", \\\"{x:767,y:754,t:1526919327328};\\\", \\\"{x:784,y:758,t:1526919327345};\\\", \\\"{x:802,y:763,t:1526919327361};\\\", \\\"{x:821,y:769,t:1526919327379};\\\", \\\"{x:849,y:772,t:1526919327395};\\\", \\\"{x:884,y:780,t:1526919327412};\\\", \\\"{x:924,y:786,t:1526919327428};\\\", \\\"{x:965,y:790,t:1526919327445};\\\", \\\"{x:998,y:793,t:1526919327462};\\\", \\\"{x:1035,y:793,t:1526919327479};\\\", \\\"{x:1054,y:793,t:1526919327495};\\\", \\\"{x:1070,y:793,t:1526919327511};\\\", \\\"{x:1093,y:793,t:1526919327529};\\\", \\\"{x:1122,y:793,t:1526919327545};\\\", \\\"{x:1158,y:793,t:1526919327562};\\\", \\\"{x:1208,y:793,t:1526919327579};\\\", \\\"{x:1253,y:793,t:1526919327596};\\\", \\\"{x:1296,y:793,t:1526919327612};\\\", \\\"{x:1335,y:793,t:1526919327629};\\\", \\\"{x:1362,y:790,t:1526919327646};\\\", \\\"{x:1384,y:786,t:1526919327662};\\\", \\\"{x:1411,y:777,t:1526919327679};\\\", \\\"{x:1432,y:771,t:1526919327695};\\\", \\\"{x:1448,y:768,t:1526919327712};\\\", \\\"{x:1464,y:764,t:1526919327729};\\\", \\\"{x:1478,y:760,t:1526919327746};\\\", \\\"{x:1494,y:755,t:1526919327762};\\\", \\\"{x:1509,y:749,t:1526919327779};\\\", \\\"{x:1521,y:744,t:1526919327796};\\\", \\\"{x:1529,y:741,t:1526919327812};\\\", \\\"{x:1532,y:740,t:1526919327829};\\\", \\\"{x:1533,y:739,t:1526919327845};\\\", \\\"{x:1534,y:738,t:1526919327862};\\\", \\\"{x:1535,y:737,t:1526919327879};\\\", \\\"{x:1536,y:737,t:1526919327896};\\\", \\\"{x:1538,y:736,t:1526919327912};\\\", \\\"{x:1539,y:735,t:1526919327928};\\\", \\\"{x:1539,y:734,t:1526919327966};\\\", \\\"{x:1540,y:734,t:1526919327979};\\\", \\\"{x:1540,y:733,t:1526919327996};\\\", \\\"{x:1541,y:732,t:1526919328013};\\\", \\\"{x:1542,y:731,t:1526919328029};\\\", \\\"{x:1543,y:730,t:1526919328046};\\\", \\\"{x:1545,y:727,t:1526919328063};\\\", \\\"{x:1550,y:724,t:1526919328079};\\\", \\\"{x:1554,y:722,t:1526919328096};\\\", \\\"{x:1557,y:720,t:1526919328112};\\\", \\\"{x:1559,y:720,t:1526919328129};\\\", \\\"{x:1562,y:718,t:1526919328146};\\\", \\\"{x:1566,y:717,t:1526919328163};\\\", \\\"{x:1570,y:717,t:1526919328179};\\\", \\\"{x:1574,y:715,t:1526919328196};\\\", \\\"{x:1577,y:715,t:1526919328213};\\\", \\\"{x:1584,y:713,t:1526919328229};\\\", \\\"{x:1588,y:712,t:1526919328246};\\\", \\\"{x:1595,y:710,t:1526919328263};\\\", \\\"{x:1598,y:710,t:1526919328279};\\\", \\\"{x:1603,y:709,t:1526919328296};\\\", \\\"{x:1605,y:709,t:1526919328313};\\\", \\\"{x:1607,y:709,t:1526919328329};\\\", \\\"{x:1608,y:709,t:1526919328346};\\\", \\\"{x:1610,y:708,t:1526919328363};\\\", \\\"{x:1611,y:708,t:1526919328379};\\\", \\\"{x:1613,y:708,t:1526919328415};\\\", \\\"{x:1614,y:708,t:1526919328430};\\\", \\\"{x:1615,y:708,t:1526919328445};\\\", \\\"{x:1617,y:708,t:1526919328463};\\\", \\\"{x:1618,y:708,t:1526919328479};\\\", \\\"{x:1620,y:707,t:1526919328503};\\\", \\\"{x:1621,y:707,t:1526919328519};\\\", \\\"{x:1622,y:706,t:1526919328535};\\\", \\\"{x:1622,y:705,t:1526919328558};\\\", \\\"{x:1622,y:704,t:1526919330167};\\\", \\\"{x:1621,y:704,t:1526919332525};\\\", \\\"{x:1619,y:704,t:1526919332965};\\\", \\\"{x:1618,y:705,t:1526919332980};\\\", \\\"{x:1617,y:706,t:1526919332996};\\\", \\\"{x:1616,y:708,t:1526919333014};\\\", \\\"{x:1614,y:711,t:1526919333030};\\\", \\\"{x:1612,y:714,t:1526919333047};\\\", \\\"{x:1610,y:722,t:1526919333064};\\\", \\\"{x:1606,y:736,t:1526919333081};\\\", \\\"{x:1600,y:752,t:1526919333097};\\\", \\\"{x:1595,y:771,t:1526919333114};\\\", \\\"{x:1588,y:789,t:1526919333130};\\\", \\\"{x:1582,y:808,t:1526919333148};\\\", \\\"{x:1576,y:822,t:1526919333164};\\\", \\\"{x:1567,y:848,t:1526919333181};\\\", \\\"{x:1562,y:866,t:1526919333197};\\\", \\\"{x:1559,y:877,t:1526919333213};\\\", \\\"{x:1557,y:885,t:1526919333231};\\\", \\\"{x:1554,y:892,t:1526919333247};\\\", \\\"{x:1552,y:897,t:1526919333263};\\\", \\\"{x:1549,y:902,t:1526919333281};\\\", \\\"{x:1548,y:905,t:1526919333297};\\\", \\\"{x:1546,y:907,t:1526919333313};\\\", \\\"{x:1544,y:909,t:1526919333331};\\\", \\\"{x:1542,y:911,t:1526919333348};\\\", \\\"{x:1537,y:916,t:1526919333364};\\\", \\\"{x:1530,y:922,t:1526919333380};\\\", \\\"{x:1528,y:924,t:1526919333398};\\\", \\\"{x:1525,y:926,t:1526919333414};\\\", \\\"{x:1521,y:929,t:1526919333431};\\\", \\\"{x:1519,y:932,t:1526919333447};\\\", \\\"{x:1515,y:935,t:1526919333464};\\\", \\\"{x:1510,y:938,t:1526919333481};\\\", \\\"{x:1506,y:939,t:1526919333498};\\\", \\\"{x:1502,y:941,t:1526919333514};\\\", \\\"{x:1498,y:943,t:1526919333531};\\\", \\\"{x:1495,y:945,t:1526919333548};\\\", \\\"{x:1493,y:946,t:1526919333564};\\\", \\\"{x:1491,y:949,t:1526919333581};\\\", \\\"{x:1490,y:952,t:1526919333597};\\\", \\\"{x:1488,y:955,t:1526919333615};\\\", \\\"{x:1486,y:959,t:1526919333631};\\\", \\\"{x:1485,y:963,t:1526919333648};\\\", \\\"{x:1485,y:965,t:1526919333665};\\\", \\\"{x:1485,y:966,t:1526919333681};\\\", \\\"{x:1485,y:968,t:1526919333698};\\\", \\\"{x:1485,y:969,t:1526919333757};\\\", \\\"{x:1485,y:970,t:1526919333780};\\\", \\\"{x:1484,y:970,t:1526919333869};\\\", \\\"{x:1480,y:969,t:1526919334476};\\\", \\\"{x:1468,y:963,t:1526919334486};\\\", \\\"{x:1452,y:959,t:1526919334498};\\\", \\\"{x:1418,y:949,t:1526919334514};\\\", \\\"{x:1395,y:939,t:1526919334532};\\\", \\\"{x:1372,y:930,t:1526919334548};\\\", \\\"{x:1313,y:904,t:1526919334565};\\\", \\\"{x:1283,y:894,t:1526919334583};\\\", \\\"{x:1238,y:882,t:1526919334599};\\\", \\\"{x:1167,y:868,t:1526919334615};\\\", \\\"{x:1086,y:857,t:1526919334633};\\\", \\\"{x:996,y:840,t:1526919334649};\\\", \\\"{x:906,y:821,t:1526919334665};\\\", \\\"{x:821,y:798,t:1526919334681};\\\", \\\"{x:740,y:774,t:1526919334698};\\\", \\\"{x:675,y:753,t:1526919334715};\\\", \\\"{x:651,y:743,t:1526919334732};\\\", \\\"{x:641,y:737,t:1526919334747};\\\", \\\"{x:634,y:733,t:1526919334765};\\\", \\\"{x:633,y:732,t:1526919334782};\\\", \\\"{x:626,y:729,t:1526919334798};\\\", \\\"{x:614,y:721,t:1526919334814};\\\", \\\"{x:599,y:712,t:1526919334833};\\\", \\\"{x:582,y:703,t:1526919334847};\\\", \\\"{x:569,y:694,t:1526919334864};\\\", \\\"{x:564,y:691,t:1526919334881};\\\", \\\"{x:562,y:687,t:1526919334898};\\\", \\\"{x:559,y:682,t:1526919334914};\\\", \\\"{x:550,y:668,t:1526919334931};\\\", \\\"{x:546,y:658,t:1526919334947};\\\", \\\"{x:543,y:650,t:1526919334964};\\\", \\\"{x:542,y:645,t:1526919334981};\\\", \\\"{x:544,y:633,t:1526919334997};\\\", \\\"{x:557,y:619,t:1526919335015};\\\", \\\"{x:574,y:607,t:1526919335031};\\\", \\\"{x:585,y:599,t:1526919335048};\\\", \\\"{x:597,y:592,t:1526919335065};\\\", \\\"{x:606,y:587,t:1526919335082};\\\", \\\"{x:614,y:583,t:1526919335099};\\\", \\\"{x:617,y:582,t:1526919335115};\\\", \\\"{x:621,y:581,t:1526919335132};\\\", \\\"{x:626,y:580,t:1526919335149};\\\", \\\"{x:628,y:580,t:1526919335165};\\\", \\\"{x:629,y:580,t:1526919335182};\\\", \\\"{x:628,y:580,t:1526919335399};\\\", \\\"{x:627,y:583,t:1526919335660};\\\", \\\"{x:633,y:592,t:1526919335669};\\\", \\\"{x:638,y:598,t:1526919335683};\\\", \\\"{x:651,y:608,t:1526919335699};\\\", \\\"{x:677,y:626,t:1526919335715};\\\", \\\"{x:700,y:637,t:1526919335732};\\\", \\\"{x:717,y:645,t:1526919335749};\\\", \\\"{x:732,y:651,t:1526919335766};\\\", \\\"{x:744,y:658,t:1526919335782};\\\", \\\"{x:762,y:668,t:1526919335799};\\\", \\\"{x:779,y:678,t:1526919335816};\\\", \\\"{x:797,y:686,t:1526919335833};\\\", \\\"{x:819,y:697,t:1526919335849};\\\", \\\"{x:839,y:705,t:1526919335866};\\\", \\\"{x:862,y:714,t:1526919335882};\\\", \\\"{x:884,y:719,t:1526919335899};\\\", \\\"{x:929,y:733,t:1526919335915};\\\", \\\"{x:970,y:747,t:1526919335932};\\\", \\\"{x:1014,y:760,t:1526919335949};\\\", \\\"{x:1057,y:773,t:1526919335966};\\\", \\\"{x:1089,y:779,t:1526919335983};\\\", \\\"{x:1115,y:784,t:1526919336000};\\\", \\\"{x:1141,y:785,t:1526919336016};\\\", \\\"{x:1167,y:787,t:1526919336033};\\\", \\\"{x:1186,y:787,t:1526919336049};\\\", \\\"{x:1202,y:787,t:1526919336066};\\\", \\\"{x:1215,y:787,t:1526919336083};\\\", \\\"{x:1230,y:787,t:1526919336100};\\\", \\\"{x:1259,y:787,t:1526919336116};\\\", \\\"{x:1277,y:791,t:1526919336133};\\\", \\\"{x:1294,y:793,t:1526919336149};\\\", \\\"{x:1312,y:798,t:1526919336167};\\\", \\\"{x:1325,y:802,t:1526919336183};\\\", \\\"{x:1343,y:807,t:1526919336199};\\\", \\\"{x:1360,y:812,t:1526919336217};\\\", \\\"{x:1383,y:818,t:1526919336234};\\\", \\\"{x:1402,y:823,t:1526919336249};\\\", \\\"{x:1422,y:827,t:1526919336266};\\\", \\\"{x:1437,y:829,t:1526919336284};\\\", \\\"{x:1446,y:832,t:1526919336300};\\\", \\\"{x:1455,y:834,t:1526919336316};\\\", \\\"{x:1456,y:834,t:1526919336333};\\\", \\\"{x:1457,y:834,t:1526919336350};\\\", \\\"{x:1458,y:836,t:1526919336366};\\\", \\\"{x:1460,y:836,t:1526919336384};\\\", \\\"{x:1462,y:837,t:1526919336400};\\\", \\\"{x:1465,y:839,t:1526919336416};\\\", \\\"{x:1467,y:839,t:1526919336433};\\\", \\\"{x:1469,y:840,t:1526919336451};\\\", \\\"{x:1471,y:841,t:1526919336467};\\\", \\\"{x:1474,y:842,t:1526919336484};\\\", \\\"{x:1476,y:843,t:1526919336500};\\\", \\\"{x:1478,y:843,t:1526919336516};\\\", \\\"{x:1479,y:843,t:1526919336534};\\\", \\\"{x:1481,y:843,t:1526919336551};\\\", \\\"{x:1483,y:844,t:1526919336567};\\\", \\\"{x:1484,y:844,t:1526919336596};\\\", \\\"{x:1485,y:844,t:1526919336620};\\\", \\\"{x:1486,y:844,t:1526919336653};\\\", \\\"{x:1487,y:844,t:1526919336797};\\\", \\\"{x:1489,y:843,t:1526919337060};\\\", \\\"{x:1490,y:843,t:1526919337068};\\\", \\\"{x:1490,y:842,t:1526919337084};\\\", \\\"{x:1493,y:841,t:1526919337101};\\\", \\\"{x:1498,y:840,t:1526919337118};\\\", \\\"{x:1502,y:839,t:1526919337134};\\\", \\\"{x:1504,y:839,t:1526919337150};\\\", \\\"{x:1505,y:839,t:1526919337172};\\\", \\\"{x:1506,y:838,t:1526919337188};\\\", \\\"{x:1508,y:838,t:1526919337204};\\\", \\\"{x:1509,y:838,t:1526919337218};\\\", \\\"{x:1511,y:838,t:1526919337234};\\\", \\\"{x:1515,y:838,t:1526919337251};\\\", \\\"{x:1518,y:840,t:1526919337268};\\\", \\\"{x:1520,y:841,t:1526919337283};\\\", \\\"{x:1524,y:843,t:1526919337300};\\\", \\\"{x:1527,y:845,t:1526919337317};\\\", \\\"{x:1530,y:848,t:1526919337334};\\\", \\\"{x:1534,y:852,t:1526919337350};\\\", \\\"{x:1538,y:856,t:1526919337367};\\\", \\\"{x:1541,y:857,t:1526919337384};\\\", \\\"{x:1542,y:859,t:1526919337400};\\\", \\\"{x:1544,y:861,t:1526919337417};\\\", \\\"{x:1548,y:865,t:1526919337434};\\\", \\\"{x:1550,y:870,t:1526919337450};\\\", \\\"{x:1554,y:878,t:1526919337467};\\\", \\\"{x:1560,y:886,t:1526919337484};\\\", \\\"{x:1562,y:889,t:1526919337501};\\\", \\\"{x:1563,y:890,t:1526919337518};\\\", \\\"{x:1565,y:892,t:1526919337534};\\\", \\\"{x:1566,y:894,t:1526919337551};\\\", \\\"{x:1568,y:894,t:1526919337567};\\\", \\\"{x:1568,y:895,t:1526919337588};\\\", \\\"{x:1566,y:893,t:1526919337685};\\\", \\\"{x:1565,y:888,t:1526919337701};\\\", \\\"{x:1562,y:877,t:1526919337717};\\\", \\\"{x:1561,y:871,t:1526919337734};\\\", \\\"{x:1558,y:862,t:1526919337750};\\\", \\\"{x:1555,y:856,t:1526919337768};\\\", \\\"{x:1554,y:854,t:1526919337785};\\\", \\\"{x:1554,y:852,t:1526919337800};\\\", \\\"{x:1552,y:847,t:1526919337817};\\\", \\\"{x:1550,y:843,t:1526919337834};\\\", \\\"{x:1550,y:840,t:1526919337852};\\\", \\\"{x:1549,y:837,t:1526919337868};\\\", \\\"{x:1547,y:835,t:1526919337884};\\\", \\\"{x:1547,y:834,t:1526919337908};\\\", \\\"{x:1547,y:833,t:1526919337941};\\\", \\\"{x:1547,y:835,t:1526919338069};\\\", \\\"{x:1545,y:845,t:1526919338084};\\\", \\\"{x:1542,y:856,t:1526919338102};\\\", \\\"{x:1541,y:865,t:1526919338118};\\\", \\\"{x:1540,y:872,t:1526919338135};\\\", \\\"{x:1538,y:881,t:1526919338152};\\\", \\\"{x:1538,y:886,t:1526919338168};\\\", \\\"{x:1536,y:892,t:1526919338185};\\\", \\\"{x:1536,y:896,t:1526919338202};\\\", \\\"{x:1534,y:901,t:1526919338218};\\\", \\\"{x:1533,y:906,t:1526919338235};\\\", \\\"{x:1531,y:911,t:1526919338252};\\\", \\\"{x:1530,y:914,t:1526919338269};\\\", \\\"{x:1529,y:915,t:1526919338285};\\\", \\\"{x:1529,y:916,t:1526919338301};\\\", \\\"{x:1529,y:917,t:1526919338318};\\\", \\\"{x:1529,y:918,t:1526919338334};\\\", \\\"{x:1529,y:919,t:1526919338352};\\\", \\\"{x:1529,y:920,t:1526919338369};\\\", \\\"{x:1528,y:921,t:1526919338597};\\\", \\\"{x:1527,y:921,t:1526919338604};\\\", \\\"{x:1525,y:921,t:1526919338619};\\\", \\\"{x:1524,y:921,t:1526919338635};\\\", \\\"{x:1523,y:920,t:1526919338651};\\\", \\\"{x:1523,y:919,t:1526919338669};\\\", \\\"{x:1522,y:918,t:1526919338685};\\\", \\\"{x:1521,y:918,t:1526919338708};\\\", \\\"{x:1520,y:918,t:1526919338733};\\\", \\\"{x:1518,y:917,t:1526919338749};\\\", \\\"{x:1517,y:917,t:1526919338772};\\\", \\\"{x:1516,y:917,t:1526919338788};\\\", \\\"{x:1515,y:917,t:1526919338804};\\\", \\\"{x:1514,y:917,t:1526919338820};\\\", \\\"{x:1513,y:917,t:1526919338836};\\\", \\\"{x:1512,y:917,t:1526919338852};\\\", \\\"{x:1511,y:917,t:1526919338884};\\\", \\\"{x:1510,y:917,t:1526919338891};\\\", \\\"{x:1509,y:917,t:1526919338902};\\\", \\\"{x:1508,y:917,t:1526919338918};\\\", \\\"{x:1506,y:917,t:1526919338935};\\\", \\\"{x:1503,y:917,t:1526919338952};\\\", \\\"{x:1498,y:917,t:1526919338969};\\\", \\\"{x:1492,y:917,t:1526919338986};\\\", \\\"{x:1485,y:918,t:1526919339002};\\\", \\\"{x:1479,y:919,t:1526919339019};\\\", \\\"{x:1468,y:921,t:1526919339036};\\\", \\\"{x:1465,y:922,t:1526919339052};\\\", \\\"{x:1454,y:925,t:1526919339068};\\\", \\\"{x:1450,y:926,t:1526919339086};\\\", \\\"{x:1443,y:927,t:1526919339102};\\\", \\\"{x:1436,y:928,t:1526919339119};\\\", \\\"{x:1430,y:928,t:1526919339136};\\\", \\\"{x:1422,y:928,t:1526919339152};\\\", \\\"{x:1414,y:928,t:1526919339168};\\\", \\\"{x:1408,y:928,t:1526919339186};\\\", \\\"{x:1402,y:925,t:1526919339203};\\\", \\\"{x:1397,y:922,t:1526919339219};\\\", \\\"{x:1389,y:916,t:1526919339236};\\\", \\\"{x:1385,y:911,t:1526919339252};\\\", \\\"{x:1380,y:904,t:1526919339269};\\\", \\\"{x:1377,y:898,t:1526919339289};\\\", \\\"{x:1376,y:892,t:1526919339302};\\\", \\\"{x:1373,y:885,t:1526919339318};\\\", \\\"{x:1372,y:880,t:1526919339335};\\\", \\\"{x:1370,y:874,t:1526919339352};\\\", \\\"{x:1369,y:865,t:1526919339368};\\\", \\\"{x:1367,y:855,t:1526919339385};\\\", \\\"{x:1365,y:847,t:1526919339402};\\\", \\\"{x:1364,y:836,t:1526919339419};\\\", \\\"{x:1363,y:828,t:1526919339435};\\\", \\\"{x:1360,y:810,t:1526919339452};\\\", \\\"{x:1359,y:799,t:1526919339468};\\\", \\\"{x:1356,y:786,t:1526919339486};\\\", \\\"{x:1351,y:773,t:1526919339502};\\\", \\\"{x:1348,y:760,t:1526919339519};\\\", \\\"{x:1343,y:751,t:1526919339536};\\\", \\\"{x:1338,y:741,t:1526919339553};\\\", \\\"{x:1334,y:732,t:1526919339569};\\\", \\\"{x:1330,y:722,t:1526919339585};\\\", \\\"{x:1327,y:707,t:1526919339603};\\\", \\\"{x:1321,y:693,t:1526919339619};\\\", \\\"{x:1314,y:670,t:1526919339636};\\\", \\\"{x:1308,y:655,t:1526919339652};\\\", \\\"{x:1305,y:646,t:1526919339669};\\\", \\\"{x:1303,y:636,t:1526919339686};\\\", \\\"{x:1300,y:627,t:1526919339702};\\\", \\\"{x:1299,y:621,t:1526919339720};\\\", \\\"{x:1297,y:618,t:1526919339735};\\\", \\\"{x:1297,y:616,t:1526919339752};\\\", \\\"{x:1297,y:614,t:1526919339770};\\\", \\\"{x:1296,y:613,t:1526919339786};\\\", \\\"{x:1296,y:611,t:1526919339803};\\\", \\\"{x:1296,y:610,t:1526919339820};\\\", \\\"{x:1296,y:609,t:1526919339925};\\\", \\\"{x:1296,y:607,t:1526919339956};\\\", \\\"{x:1296,y:604,t:1526919339972};\\\", \\\"{x:1295,y:602,t:1526919339985};\\\", \\\"{x:1294,y:599,t:1526919340003};\\\", \\\"{x:1293,y:594,t:1526919340020};\\\", \\\"{x:1292,y:590,t:1526919340036};\\\", \\\"{x:1292,y:589,t:1526919340053};\\\", \\\"{x:1290,y:585,t:1526919340070};\\\", \\\"{x:1289,y:590,t:1526919341677};\\\", \\\"{x:1287,y:603,t:1526919341688};\\\", \\\"{x:1284,y:632,t:1526919341703};\\\", \\\"{x:1279,y:658,t:1526919341721};\\\", \\\"{x:1275,y:690,t:1526919341738};\\\", \\\"{x:1271,y:719,t:1526919341754};\\\", \\\"{x:1267,y:743,t:1526919341771};\\\", \\\"{x:1262,y:772,t:1526919341788};\\\", \\\"{x:1259,y:785,t:1526919341805};\\\", \\\"{x:1257,y:793,t:1526919341821};\\\", \\\"{x:1256,y:799,t:1526919341838};\\\", \\\"{x:1256,y:803,t:1526919341854};\\\", \\\"{x:1256,y:804,t:1526919341871};\\\", \\\"{x:1256,y:806,t:1526919341892};\\\", \\\"{x:1256,y:807,t:1526919341932};\\\", \\\"{x:1257,y:808,t:1526919342012};\\\", \\\"{x:1257,y:809,t:1526919342021};\\\", \\\"{x:1262,y:809,t:1526919342038};\\\", \\\"{x:1268,y:810,t:1526919342054};\\\", \\\"{x:1275,y:811,t:1526919342071};\\\", \\\"{x:1284,y:815,t:1526919342088};\\\", \\\"{x:1295,y:819,t:1526919342105};\\\", \\\"{x:1306,y:826,t:1526919342121};\\\", \\\"{x:1316,y:832,t:1526919342138};\\\", \\\"{x:1324,y:839,t:1526919342155};\\\", \\\"{x:1331,y:845,t:1526919342171};\\\", \\\"{x:1337,y:849,t:1526919342188};\\\", \\\"{x:1339,y:851,t:1526919342204};\\\", \\\"{x:1341,y:853,t:1526919342221};\\\", \\\"{x:1343,y:856,t:1526919342238};\\\", \\\"{x:1344,y:858,t:1526919342255};\\\", \\\"{x:1345,y:861,t:1526919342271};\\\", \\\"{x:1346,y:862,t:1526919342288};\\\", \\\"{x:1346,y:863,t:1526919342305};\\\", \\\"{x:1346,y:864,t:1526919342324};\\\", \\\"{x:1347,y:865,t:1526919342338};\\\", \\\"{x:1347,y:866,t:1526919342354};\\\", \\\"{x:1348,y:870,t:1526919342371};\\\", \\\"{x:1350,y:878,t:1526919342389};\\\", \\\"{x:1351,y:883,t:1526919342404};\\\", \\\"{x:1351,y:892,t:1526919342421};\\\", \\\"{x:1351,y:906,t:1526919342438};\\\", \\\"{x:1351,y:919,t:1526919342455};\\\", \\\"{x:1354,y:935,t:1526919342470};\\\", \\\"{x:1356,y:946,t:1526919342488};\\\", \\\"{x:1356,y:953,t:1526919342505};\\\", \\\"{x:1357,y:958,t:1526919342522};\\\", \\\"{x:1358,y:962,t:1526919342538};\\\", \\\"{x:1358,y:964,t:1526919342555};\\\", \\\"{x:1359,y:965,t:1526919342572};\\\", \\\"{x:1359,y:966,t:1526919342588};\\\", \\\"{x:1359,y:967,t:1526919342604};\\\", \\\"{x:1359,y:968,t:1526919342708};\\\", \\\"{x:1359,y:967,t:1526919343756};\\\", \\\"{x:1361,y:958,t:1526919343772};\\\", \\\"{x:1361,y:944,t:1526919343789};\\\", \\\"{x:1361,y:928,t:1526919343806};\\\", \\\"{x:1361,y:916,t:1526919343822};\\\", \\\"{x:1361,y:903,t:1526919343839};\\\", \\\"{x:1361,y:888,t:1526919343856};\\\", \\\"{x:1361,y:873,t:1526919343872};\\\", \\\"{x:1361,y:852,t:1526919343889};\\\", \\\"{x:1361,y:836,t:1526919343906};\\\", \\\"{x:1358,y:815,t:1526919343922};\\\", \\\"{x:1357,y:802,t:1526919343939};\\\", \\\"{x:1353,y:789,t:1526919343956};\\\", \\\"{x:1353,y:785,t:1526919343973};\\\", \\\"{x:1352,y:779,t:1526919343989};\\\", \\\"{x:1352,y:773,t:1526919344006};\\\", \\\"{x:1352,y:769,t:1526919344023};\\\", \\\"{x:1352,y:766,t:1526919344040};\\\", \\\"{x:1352,y:765,t:1526919344056};\\\", \\\"{x:1352,y:763,t:1526919344073};\\\", \\\"{x:1352,y:762,t:1526919344089};\\\", \\\"{x:1350,y:762,t:1526919344629};\\\", \\\"{x:1347,y:762,t:1526919344640};\\\", \\\"{x:1341,y:765,t:1526919344657};\\\", \\\"{x:1320,y:770,t:1526919344673};\\\", \\\"{x:1293,y:770,t:1526919344690};\\\", \\\"{x:1252,y:770,t:1526919344706};\\\", \\\"{x:1202,y:770,t:1526919344723};\\\", \\\"{x:1129,y:770,t:1526919344740};\\\", \\\"{x:1092,y:770,t:1526919344756};\\\", \\\"{x:1060,y:774,t:1526919344773};\\\", \\\"{x:1028,y:778,t:1526919344790};\\\", \\\"{x:993,y:785,t:1526919344806};\\\", \\\"{x:975,y:787,t:1526919344823};\\\", \\\"{x:960,y:787,t:1526919344840};\\\", \\\"{x:935,y:787,t:1526919344856};\\\", \\\"{x:899,y:787,t:1526919344872};\\\", \\\"{x:857,y:787,t:1526919344889};\\\", \\\"{x:815,y:787,t:1526919344906};\\\", \\\"{x:773,y:787,t:1526919344922};\\\", \\\"{x:709,y:783,t:1526919344939};\\\", \\\"{x:666,y:775,t:1526919344957};\\\", \\\"{x:620,y:760,t:1526919344973};\\\", \\\"{x:589,y:750,t:1526919344989};\\\", \\\"{x:568,y:742,t:1526919345006};\\\", \\\"{x:545,y:733,t:1526919345022};\\\", \\\"{x:529,y:725,t:1526919345040};\\\", \\\"{x:517,y:715,t:1526919345056};\\\", \\\"{x:505,y:706,t:1526919345074};\\\", \\\"{x:493,y:695,t:1526919345090};\\\", \\\"{x:483,y:686,t:1526919345106};\\\", \\\"{x:476,y:679,t:1526919345123};\\\", \\\"{x:473,y:673,t:1526919345141};\\\", \\\"{x:470,y:662,t:1526919345157};\\\", \\\"{x:469,y:656,t:1526919345173};\\\", \\\"{x:465,y:647,t:1526919345190};\\\", \\\"{x:464,y:642,t:1526919345206};\\\", \\\"{x:463,y:637,t:1526919345224};\\\", \\\"{x:461,y:632,t:1526919345241};\\\", \\\"{x:460,y:629,t:1526919345257};\\\", \\\"{x:458,y:626,t:1526919345273};\\\", \\\"{x:457,y:623,t:1526919345290};\\\", \\\"{x:454,y:621,t:1526919345307};\\\", \\\"{x:449,y:618,t:1526919345324};\\\", \\\"{x:447,y:617,t:1526919345340};\\\", \\\"{x:447,y:616,t:1526919345358};\\\", \\\"{x:447,y:615,t:1526919345387};\\\", \\\"{x:447,y:610,t:1526919345396};\\\", \\\"{x:450,y:609,t:1526919345408};\\\", \\\"{x:465,y:599,t:1526919345425};\\\", \\\"{x:493,y:592,t:1526919345441};\\\", \\\"{x:534,y:580,t:1526919345458};\\\", \\\"{x:581,y:566,t:1526919345474};\\\", \\\"{x:625,y:557,t:1526919345491};\\\", \\\"{x:673,y:546,t:1526919345507};\\\", \\\"{x:688,y:544,t:1526919345523};\\\", \\\"{x:694,y:541,t:1526919345541};\\\", \\\"{x:696,y:540,t:1526919345557};\\\", \\\"{x:697,y:540,t:1526919345573};\\\", \\\"{x:703,y:538,t:1526919345590};\\\", \\\"{x:709,y:536,t:1526919345607};\\\", \\\"{x:719,y:531,t:1526919345624};\\\", \\\"{x:728,y:527,t:1526919345641};\\\", \\\"{x:735,y:522,t:1526919345658};\\\", \\\"{x:740,y:520,t:1526919345674};\\\", \\\"{x:752,y:515,t:1526919345691};\\\", \\\"{x:782,y:508,t:1526919345707};\\\", \\\"{x:808,y:505,t:1526919345723};\\\", \\\"{x:827,y:503,t:1526919345741};\\\", \\\"{x:840,y:499,t:1526919345757};\\\", \\\"{x:844,y:498,t:1526919345774};\\\", \\\"{x:845,y:497,t:1526919345791};\\\", \\\"{x:846,y:497,t:1526919345819};\\\", \\\"{x:845,y:497,t:1526919346091};\\\", \\\"{x:826,y:516,t:1526919346108};\\\", \\\"{x:791,y:549,t:1526919346125};\\\", \\\"{x:753,y:581,t:1526919346141};\\\", \\\"{x:703,y:615,t:1526919346158};\\\", \\\"{x:666,y:641,t:1526919346175};\\\", \\\"{x:641,y:656,t:1526919346190};\\\", \\\"{x:627,y:664,t:1526919346207};\\\", \\\"{x:615,y:673,t:1526919346224};\\\", \\\"{x:601,y:684,t:1526919346240};\\\", \\\"{x:585,y:692,t:1526919346257};\\\", \\\"{x:573,y:701,t:1526919346274};\\\", \\\"{x:564,y:704,t:1526919346291};\\\", \\\"{x:562,y:705,t:1526919346307};\\\", \\\"{x:561,y:705,t:1526919346355};\\\", \\\"{x:561,y:706,t:1526919346364};\\\", \\\"{x:559,y:707,t:1526919346375};\\\", \\\"{x:559,y:708,t:1526919346392};\\\", \\\"{x:558,y:708,t:1526919346408};\\\", \\\"{x:556,y:708,t:1526919346436};\\\", \\\"{x:556,y:709,t:1526919346468};\\\", \\\"{x:555,y:709,t:1526919346476};\\\", \\\"{x:551,y:712,t:1526919346492};\\\", \\\"{x:548,y:714,t:1526919346508};\\\", \\\"{x:543,y:717,t:1526919346525};\\\", \\\"{x:537,y:720,t:1526919346542};\\\", \\\"{x:532,y:724,t:1526919346557};\\\", \\\"{x:528,y:728,t:1526919346574};\\\", \\\"{x:524,y:731,t:1526919346591};\\\", \\\"{x:522,y:731,t:1526919346607};\\\", \\\"{x:521,y:732,t:1526919346624};\\\", \\\"{x:520,y:732,t:1526919346643};\\\", \\\"{x:520,y:733,t:1526919346659};\\\", \\\"{x:523,y:733,t:1526919347435};\\\", \\\"{x:524,y:733,t:1526919347442};\\\", \\\"{x:526,y:733,t:1526919347458};\\\", \\\"{x:530,y:733,t:1526919347475};\\\", \\\"{x:532,y:732,t:1526919347492};\\\" ] }, { \\\"rt\\\": 23098, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 638957, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:731,t:1526919349164};\\\", \\\"{x:534,y:730,t:1526919349178};\\\", \\\"{x:542,y:727,t:1526919349195};\\\", \\\"{x:560,y:726,t:1526919349212};\\\", \\\"{x:578,y:724,t:1526919349230};\\\", \\\"{x:597,y:724,t:1526919349244};\\\", \\\"{x:622,y:724,t:1526919349259};\\\", \\\"{x:655,y:726,t:1526919349277};\\\", \\\"{x:717,y:736,t:1526919349293};\\\", \\\"{x:799,y:755,t:1526919349309};\\\", \\\"{x:881,y:773,t:1526919349326};\\\", \\\"{x:964,y:796,t:1526919349343};\\\", \\\"{x:1031,y:817,t:1526919349359};\\\", \\\"{x:1090,y:834,t:1526919349377};\\\", \\\"{x:1142,y:847,t:1526919349393};\\\", \\\"{x:1198,y:863,t:1526919349409};\\\", \\\"{x:1265,y:884,t:1526919349427};\\\", \\\"{x:1329,y:902,t:1526919349443};\\\", \\\"{x:1401,y:922,t:1526919349459};\\\", \\\"{x:1443,y:935,t:1526919349476};\\\", \\\"{x:1472,y:942,t:1526919349493};\\\", \\\"{x:1494,y:948,t:1526919349509};\\\", \\\"{x:1514,y:955,t:1526919349527};\\\", \\\"{x:1532,y:961,t:1526919349543};\\\", \\\"{x:1548,y:963,t:1526919349560};\\\", \\\"{x:1565,y:964,t:1526919349578};\\\", \\\"{x:1580,y:968,t:1526919349594};\\\", \\\"{x:1593,y:972,t:1526919349610};\\\", \\\"{x:1599,y:973,t:1526919349628};\\\", \\\"{x:1602,y:973,t:1526919349643};\\\", \\\"{x:1604,y:975,t:1526919349659};\\\", \\\"{x:1605,y:975,t:1526919349708};\\\", \\\"{x:1605,y:976,t:1526919349804};\\\", \\\"{x:1604,y:976,t:1526919349812};\\\", \\\"{x:1601,y:978,t:1526919349827};\\\", \\\"{x:1599,y:979,t:1526919349843};\\\", \\\"{x:1596,y:980,t:1526919349860};\\\", \\\"{x:1593,y:981,t:1526919349879};\\\", \\\"{x:1592,y:981,t:1526919349989};\\\", \\\"{x:1591,y:981,t:1526919349996};\\\", \\\"{x:1589,y:981,t:1526919350010};\\\", \\\"{x:1588,y:981,t:1526919350027};\\\", \\\"{x:1588,y:980,t:1526919350043};\\\", \\\"{x:1587,y:979,t:1526919350068};\\\", \\\"{x:1586,y:979,t:1526919350100};\\\", \\\"{x:1586,y:978,t:1526919350116};\\\", \\\"{x:1583,y:978,t:1526919350492};\\\", \\\"{x:1581,y:976,t:1526919350500};\\\", \\\"{x:1579,y:975,t:1526919350511};\\\", \\\"{x:1577,y:974,t:1526919350527};\\\", \\\"{x:1573,y:972,t:1526919350545};\\\", \\\"{x:1569,y:970,t:1526919350560};\\\", \\\"{x:1566,y:968,t:1526919350576};\\\", \\\"{x:1563,y:967,t:1526919350593};\\\", \\\"{x:1562,y:966,t:1526919350610};\\\", \\\"{x:1562,y:965,t:1526919350642};\\\", \\\"{x:1561,y:965,t:1526919350667};\\\", \\\"{x:1560,y:965,t:1526919350677};\\\", \\\"{x:1560,y:964,t:1526919350723};\\\", \\\"{x:1559,y:963,t:1526919350748};\\\", \\\"{x:1559,y:962,t:1526919350804};\\\", \\\"{x:1559,y:960,t:1526919351116};\\\", \\\"{x:1559,y:958,t:1526919351127};\\\", \\\"{x:1559,y:951,t:1526919351144};\\\", \\\"{x:1559,y:944,t:1526919351161};\\\", \\\"{x:1559,y:938,t:1526919351177};\\\", \\\"{x:1559,y:932,t:1526919351194};\\\", \\\"{x:1559,y:931,t:1526919351212};\\\", \\\"{x:1559,y:930,t:1526919351227};\\\", \\\"{x:1558,y:929,t:1526919351244};\\\", \\\"{x:1558,y:928,t:1526919351388};\\\", \\\"{x:1558,y:925,t:1526919351396};\\\", \\\"{x:1558,y:920,t:1526919351412};\\\", \\\"{x:1558,y:917,t:1526919351428};\\\", \\\"{x:1558,y:907,t:1526919351444};\\\", \\\"{x:1558,y:903,t:1526919351462};\\\", \\\"{x:1558,y:902,t:1526919351477};\\\", \\\"{x:1557,y:901,t:1526919351494};\\\", \\\"{x:1557,y:900,t:1526919351511};\\\", \\\"{x:1557,y:899,t:1526919352045};\\\", \\\"{x:1555,y:887,t:1526919352061};\\\", \\\"{x:1550,y:875,t:1526919352077};\\\", \\\"{x:1548,y:867,t:1526919352094};\\\", \\\"{x:1546,y:857,t:1526919352111};\\\", \\\"{x:1544,y:851,t:1526919352127};\\\", \\\"{x:1543,y:846,t:1526919352144};\\\", \\\"{x:1543,y:842,t:1526919352161};\\\", \\\"{x:1543,y:839,t:1526919352177};\\\", \\\"{x:1543,y:837,t:1526919352194};\\\", \\\"{x:1542,y:833,t:1526919352211};\\\", \\\"{x:1541,y:831,t:1526919352227};\\\", \\\"{x:1541,y:828,t:1526919352245};\\\", \\\"{x:1540,y:824,t:1526919352261};\\\", \\\"{x:1538,y:821,t:1526919352278};\\\", \\\"{x:1537,y:816,t:1526919352294};\\\", \\\"{x:1536,y:814,t:1526919352311};\\\", \\\"{x:1536,y:812,t:1526919352328};\\\", \\\"{x:1536,y:811,t:1526919352345};\\\", \\\"{x:1535,y:810,t:1526919352361};\\\", \\\"{x:1533,y:811,t:1526919352540};\\\", \\\"{x:1532,y:814,t:1526919352548};\\\", \\\"{x:1531,y:816,t:1526919352561};\\\", \\\"{x:1529,y:826,t:1526919352578};\\\", \\\"{x:1528,y:836,t:1526919352595};\\\", \\\"{x:1527,y:848,t:1526919352611};\\\", \\\"{x:1527,y:859,t:1526919352628};\\\", \\\"{x:1527,y:864,t:1526919352645};\\\", \\\"{x:1527,y:869,t:1526919352661};\\\", \\\"{x:1527,y:871,t:1526919352679};\\\", \\\"{x:1527,y:874,t:1526919352694};\\\", \\\"{x:1527,y:876,t:1526919352711};\\\", \\\"{x:1527,y:882,t:1526919352729};\\\", \\\"{x:1529,y:890,t:1526919352744};\\\", \\\"{x:1530,y:896,t:1526919352761};\\\", \\\"{x:1530,y:900,t:1526919352778};\\\", \\\"{x:1530,y:904,t:1526919352795};\\\", \\\"{x:1530,y:906,t:1526919352811};\\\", \\\"{x:1529,y:910,t:1526919352828};\\\", \\\"{x:1528,y:911,t:1526919352844};\\\", \\\"{x:1524,y:914,t:1526919352862};\\\", \\\"{x:1522,y:915,t:1526919352879};\\\", \\\"{x:1517,y:918,t:1526919352894};\\\", \\\"{x:1515,y:919,t:1526919352911};\\\", \\\"{x:1511,y:921,t:1526919352929};\\\", \\\"{x:1509,y:922,t:1526919352945};\\\", \\\"{x:1508,y:923,t:1526919352961};\\\", \\\"{x:1507,y:923,t:1526919352988};\\\", \\\"{x:1505,y:925,t:1526919352996};\\\", \\\"{x:1504,y:926,t:1526919353012};\\\", \\\"{x:1502,y:929,t:1526919353028};\\\", \\\"{x:1499,y:932,t:1526919353044};\\\", \\\"{x:1497,y:934,t:1526919353061};\\\", \\\"{x:1496,y:936,t:1526919353079};\\\", \\\"{x:1493,y:939,t:1526919353094};\\\", \\\"{x:1491,y:941,t:1526919353112};\\\", \\\"{x:1487,y:945,t:1526919353128};\\\", \\\"{x:1485,y:947,t:1526919353144};\\\", \\\"{x:1483,y:949,t:1526919353161};\\\", \\\"{x:1483,y:951,t:1526919353178};\\\", \\\"{x:1482,y:951,t:1526919353196};\\\", \\\"{x:1484,y:950,t:1526919353541};\\\", \\\"{x:1484,y:949,t:1526919353548};\\\", \\\"{x:1485,y:948,t:1526919353580};\\\", \\\"{x:1485,y:947,t:1526919353595};\\\", \\\"{x:1486,y:946,t:1526919353612};\\\", \\\"{x:1486,y:944,t:1526919353644};\\\", \\\"{x:1487,y:944,t:1526919353661};\\\", \\\"{x:1488,y:942,t:1526919353679};\\\", \\\"{x:1488,y:941,t:1526919353780};\\\", \\\"{x:1489,y:940,t:1526919353795};\\\", \\\"{x:1489,y:939,t:1526919353811};\\\", \\\"{x:1491,y:936,t:1526919353828};\\\", \\\"{x:1491,y:935,t:1526919353845};\\\", \\\"{x:1493,y:932,t:1526919353861};\\\", \\\"{x:1495,y:930,t:1526919353878};\\\", \\\"{x:1497,y:929,t:1526919353895};\\\", \\\"{x:1500,y:928,t:1526919353911};\\\", \\\"{x:1507,y:927,t:1526919353928};\\\", \\\"{x:1513,y:927,t:1526919353945};\\\", \\\"{x:1517,y:927,t:1526919353961};\\\", \\\"{x:1520,y:927,t:1526919353979};\\\", \\\"{x:1522,y:927,t:1526919353995};\\\", \\\"{x:1524,y:928,t:1526919354011};\\\", \\\"{x:1529,y:935,t:1526919354028};\\\", \\\"{x:1532,y:942,t:1526919354045};\\\", \\\"{x:1534,y:947,t:1526919354061};\\\", \\\"{x:1535,y:950,t:1526919354079};\\\", \\\"{x:1536,y:952,t:1526919354095};\\\", \\\"{x:1537,y:952,t:1526919354112};\\\", \\\"{x:1536,y:952,t:1526919354420};\\\", \\\"{x:1534,y:952,t:1526919354428};\\\", \\\"{x:1532,y:952,t:1526919354445};\\\", \\\"{x:1531,y:952,t:1526919354468};\\\", \\\"{x:1529,y:952,t:1526919354548};\\\", \\\"{x:1528,y:952,t:1526919354580};\\\", \\\"{x:1526,y:952,t:1526919354692};\\\", \\\"{x:1525,y:952,t:1526919354836};\\\", \\\"{x:1523,y:952,t:1526919354845};\\\", \\\"{x:1522,y:952,t:1526919354863};\\\", \\\"{x:1519,y:952,t:1526919354878};\\\", \\\"{x:1518,y:952,t:1526919354900};\\\", \\\"{x:1517,y:952,t:1526919354916};\\\", \\\"{x:1516,y:952,t:1526919354940};\\\", \\\"{x:1515,y:952,t:1526919354964};\\\", \\\"{x:1514,y:952,t:1526919354978};\\\", \\\"{x:1513,y:952,t:1526919354996};\\\", \\\"{x:1511,y:952,t:1526919355012};\\\", \\\"{x:1510,y:952,t:1526919355028};\\\", \\\"{x:1509,y:952,t:1526919355059};\\\", \\\"{x:1508,y:952,t:1526919355083};\\\", \\\"{x:1507,y:953,t:1526919355095};\\\", \\\"{x:1506,y:953,t:1526919355112};\\\", \\\"{x:1505,y:953,t:1526919355128};\\\", \\\"{x:1504,y:954,t:1526919355145};\\\", \\\"{x:1502,y:955,t:1526919355162};\\\", \\\"{x:1502,y:956,t:1526919355178};\\\", \\\"{x:1501,y:956,t:1526919355195};\\\", \\\"{x:1500,y:956,t:1526919355220};\\\", \\\"{x:1500,y:957,t:1526919355228};\\\", \\\"{x:1498,y:957,t:1526919355245};\\\", \\\"{x:1497,y:958,t:1526919355262};\\\", \\\"{x:1495,y:959,t:1526919355279};\\\", \\\"{x:1494,y:959,t:1526919355296};\\\", \\\"{x:1492,y:960,t:1526919355312};\\\", \\\"{x:1489,y:960,t:1526919355328};\\\", \\\"{x:1488,y:960,t:1526919355345};\\\", \\\"{x:1486,y:960,t:1526919355363};\\\", \\\"{x:1483,y:960,t:1526919355378};\\\", \\\"{x:1479,y:960,t:1526919355395};\\\", \\\"{x:1476,y:960,t:1526919355412};\\\", \\\"{x:1475,y:960,t:1526919355428};\\\", \\\"{x:1473,y:960,t:1526919355468};\\\", \\\"{x:1471,y:960,t:1526919355484};\\\", \\\"{x:1469,y:960,t:1526919355495};\\\", \\\"{x:1466,y:960,t:1526919355512};\\\", \\\"{x:1462,y:960,t:1526919355528};\\\", \\\"{x:1458,y:960,t:1526919355545};\\\", \\\"{x:1455,y:960,t:1526919355562};\\\", \\\"{x:1454,y:960,t:1526919355578};\\\", \\\"{x:1452,y:959,t:1526919355595};\\\", \\\"{x:1448,y:959,t:1526919355612};\\\", \\\"{x:1444,y:959,t:1526919355628};\\\", \\\"{x:1440,y:959,t:1526919355645};\\\", \\\"{x:1436,y:959,t:1526919355662};\\\", \\\"{x:1434,y:959,t:1526919355679};\\\", \\\"{x:1431,y:959,t:1526919355696};\\\", \\\"{x:1428,y:959,t:1526919355712};\\\", \\\"{x:1424,y:959,t:1526919355728};\\\", \\\"{x:1421,y:959,t:1526919355745};\\\", \\\"{x:1417,y:959,t:1526919355762};\\\", \\\"{x:1414,y:959,t:1526919355779};\\\", \\\"{x:1411,y:959,t:1526919355795};\\\", \\\"{x:1410,y:959,t:1526919355812};\\\", \\\"{x:1409,y:959,t:1526919355829};\\\", \\\"{x:1407,y:959,t:1526919355852};\\\", \\\"{x:1405,y:959,t:1526919355868};\\\", \\\"{x:1404,y:959,t:1526919355883};\\\", \\\"{x:1403,y:959,t:1526919355895};\\\", \\\"{x:1401,y:959,t:1526919355912};\\\", \\\"{x:1400,y:959,t:1526919355929};\\\", \\\"{x:1398,y:959,t:1526919355945};\\\", \\\"{x:1397,y:959,t:1526919355971};\\\", \\\"{x:1396,y:959,t:1526919355979};\\\", \\\"{x:1395,y:959,t:1526919355995};\\\", \\\"{x:1394,y:959,t:1526919356012};\\\", \\\"{x:1392,y:959,t:1526919356029};\\\", \\\"{x:1391,y:959,t:1526919356172};\\\", \\\"{x:1390,y:959,t:1526919356196};\\\", \\\"{x:1389,y:960,t:1526919356213};\\\", \\\"{x:1388,y:960,t:1526919356292};\\\", \\\"{x:1387,y:960,t:1526919356316};\\\", \\\"{x:1386,y:960,t:1526919356340};\\\", \\\"{x:1385,y:960,t:1526919356372};\\\", \\\"{x:1384,y:960,t:1526919356380};\\\", \\\"{x:1383,y:960,t:1526919356404};\\\", \\\"{x:1382,y:960,t:1526919356436};\\\", \\\"{x:1381,y:960,t:1526919356484};\\\", \\\"{x:1381,y:955,t:1526919357725};\\\", \\\"{x:1381,y:950,t:1526919357732};\\\", \\\"{x:1381,y:945,t:1526919357746};\\\", \\\"{x:1381,y:935,t:1526919357763};\\\", \\\"{x:1381,y:917,t:1526919357780};\\\", \\\"{x:1381,y:903,t:1526919357796};\\\", \\\"{x:1381,y:894,t:1526919357814};\\\", \\\"{x:1381,y:880,t:1526919357829};\\\", \\\"{x:1381,y:863,t:1526919357846};\\\", \\\"{x:1381,y:851,t:1526919357862};\\\", \\\"{x:1381,y:841,t:1526919357879};\\\", \\\"{x:1381,y:835,t:1526919357896};\\\", \\\"{x:1381,y:830,t:1526919357912};\\\", \\\"{x:1381,y:825,t:1526919357929};\\\", \\\"{x:1381,y:823,t:1526919357946};\\\", \\\"{x:1381,y:821,t:1526919357962};\\\", \\\"{x:1381,y:822,t:1526919358052};\\\", \\\"{x:1381,y:830,t:1526919358063};\\\", \\\"{x:1379,y:851,t:1526919358079};\\\", \\\"{x:1377,y:875,t:1526919358096};\\\", \\\"{x:1373,y:899,t:1526919358113};\\\", \\\"{x:1373,y:918,t:1526919358129};\\\", \\\"{x:1372,y:929,t:1526919358146};\\\", \\\"{x:1372,y:938,t:1526919358164};\\\", \\\"{x:1371,y:942,t:1526919358180};\\\", \\\"{x:1369,y:946,t:1526919358196};\\\", \\\"{x:1369,y:947,t:1526919358220};\\\", \\\"{x:1368,y:948,t:1526919358229};\\\", \\\"{x:1367,y:948,t:1526919358316};\\\", \\\"{x:1366,y:948,t:1526919358332};\\\", \\\"{x:1363,y:946,t:1526919358348};\\\", \\\"{x:1361,y:939,t:1526919358364};\\\", \\\"{x:1356,y:925,t:1526919358380};\\\", \\\"{x:1353,y:909,t:1526919358396};\\\", \\\"{x:1353,y:896,t:1526919358413};\\\", \\\"{x:1353,y:880,t:1526919358430};\\\", \\\"{x:1353,y:860,t:1526919358447};\\\", \\\"{x:1353,y:842,t:1526919358464};\\\", \\\"{x:1353,y:828,t:1526919358480};\\\", \\\"{x:1353,y:817,t:1526919358497};\\\", \\\"{x:1353,y:812,t:1526919358514};\\\", \\\"{x:1353,y:808,t:1526919358529};\\\", \\\"{x:1353,y:802,t:1526919358547};\\\", \\\"{x:1353,y:795,t:1526919358564};\\\", \\\"{x:1353,y:790,t:1526919358580};\\\", \\\"{x:1353,y:788,t:1526919358596};\\\", \\\"{x:1353,y:785,t:1526919358614};\\\", \\\"{x:1353,y:783,t:1526919358630};\\\", \\\"{x:1353,y:781,t:1526919358646};\\\", \\\"{x:1352,y:781,t:1526919358664};\\\", \\\"{x:1352,y:780,t:1526919358680};\\\", \\\"{x:1351,y:780,t:1526919358852};\\\", \\\"{x:1348,y:780,t:1526919358863};\\\", \\\"{x:1335,y:785,t:1526919358879};\\\", \\\"{x:1312,y:796,t:1526919358896};\\\", \\\"{x:1266,y:811,t:1526919358913};\\\", \\\"{x:1202,y:821,t:1526919358930};\\\", \\\"{x:1122,y:828,t:1526919358947};\\\", \\\"{x:1003,y:828,t:1526919358963};\\\", \\\"{x:949,y:820,t:1526919358980};\\\", \\\"{x:909,y:813,t:1526919358996};\\\", \\\"{x:876,y:809,t:1526919359014};\\\", \\\"{x:849,y:805,t:1526919359029};\\\", \\\"{x:825,y:801,t:1526919359046};\\\", \\\"{x:807,y:798,t:1526919359063};\\\", \\\"{x:787,y:794,t:1526919359079};\\\", \\\"{x:769,y:788,t:1526919359096};\\\", \\\"{x:755,y:784,t:1526919359113};\\\", \\\"{x:742,y:783,t:1526919359129};\\\", \\\"{x:732,y:781,t:1526919359146};\\\", \\\"{x:727,y:779,t:1526919359163};\\\", \\\"{x:726,y:778,t:1526919359228};\\\", \\\"{x:726,y:777,t:1526919359260};\\\", \\\"{x:727,y:777,t:1526919359267};\\\", \\\"{x:728,y:775,t:1526919359280};\\\", \\\"{x:731,y:775,t:1526919359296};\\\", \\\"{x:735,y:775,t:1526919359313};\\\", \\\"{x:740,y:773,t:1526919359330};\\\", \\\"{x:747,y:773,t:1526919359346};\\\", \\\"{x:771,y:771,t:1526919359364};\\\", \\\"{x:798,y:768,t:1526919359379};\\\", \\\"{x:833,y:768,t:1526919359396};\\\", \\\"{x:859,y:768,t:1526919359413};\\\", \\\"{x:884,y:767,t:1526919359430};\\\", \\\"{x:887,y:767,t:1526919359446};\\\", \\\"{x:887,y:765,t:1526919360684};\\\", \\\"{x:885,y:764,t:1526919360715};\\\", \\\"{x:883,y:763,t:1526919360731};\\\", \\\"{x:881,y:758,t:1526919360747};\\\", \\\"{x:878,y:753,t:1526919360763};\\\", \\\"{x:873,y:748,t:1526919360780};\\\", \\\"{x:867,y:740,t:1526919360798};\\\", \\\"{x:863,y:736,t:1526919360814};\\\", \\\"{x:859,y:731,t:1526919360831};\\\", \\\"{x:855,y:726,t:1526919360847};\\\", \\\"{x:849,y:720,t:1526919360864};\\\", \\\"{x:839,y:712,t:1526919360880};\\\", \\\"{x:824,y:704,t:1526919360897};\\\", \\\"{x:807,y:698,t:1526919360914};\\\", \\\"{x:790,y:690,t:1526919360930};\\\", \\\"{x:760,y:681,t:1526919360948};\\\", \\\"{x:736,y:674,t:1526919360964};\\\", \\\"{x:714,y:665,t:1526919360980};\\\", \\\"{x:690,y:659,t:1526919360998};\\\", \\\"{x:654,y:648,t:1526919361013};\\\", \\\"{x:625,y:640,t:1526919361030};\\\", \\\"{x:598,y:633,t:1526919361047};\\\", \\\"{x:573,y:627,t:1526919361065};\\\", \\\"{x:551,y:622,t:1526919361079};\\\", \\\"{x:531,y:621,t:1526919361097};\\\", \\\"{x:499,y:616,t:1526919361119};\\\", \\\"{x:473,y:611,t:1526919361137};\\\", \\\"{x:442,y:601,t:1526919361153};\\\", \\\"{x:413,y:595,t:1526919361171};\\\", \\\"{x:386,y:589,t:1526919361186};\\\", \\\"{x:348,y:584,t:1526919361203};\\\", \\\"{x:326,y:581,t:1526919361220};\\\", \\\"{x:306,y:576,t:1526919361236};\\\", \\\"{x:284,y:573,t:1526919361253};\\\", \\\"{x:261,y:571,t:1526919361270};\\\", \\\"{x:243,y:570,t:1526919361286};\\\", \\\"{x:227,y:567,t:1526919361303};\\\", \\\"{x:217,y:564,t:1526919361320};\\\", \\\"{x:213,y:561,t:1526919361338};\\\", \\\"{x:209,y:559,t:1526919361353};\\\", \\\"{x:205,y:558,t:1526919361369};\\\", \\\"{x:200,y:556,t:1526919361387};\\\", \\\"{x:197,y:555,t:1526919361403};\\\", \\\"{x:194,y:554,t:1526919361420};\\\", \\\"{x:189,y:551,t:1526919361437};\\\", \\\"{x:183,y:547,t:1526919361454};\\\", \\\"{x:178,y:545,t:1526919361470};\\\", \\\"{x:174,y:542,t:1526919361486};\\\", \\\"{x:170,y:541,t:1526919361503};\\\", \\\"{x:168,y:539,t:1526919361520};\\\", \\\"{x:166,y:538,t:1526919361537};\\\", \\\"{x:165,y:538,t:1526919361553};\\\", \\\"{x:171,y:541,t:1526919361811};\\\", \\\"{x:183,y:545,t:1526919361820};\\\", \\\"{x:232,y:569,t:1526919361838};\\\", \\\"{x:298,y:598,t:1526919361854};\\\", \\\"{x:364,y:624,t:1526919361871};\\\", \\\"{x:425,y:649,t:1526919361888};\\\", \\\"{x:487,y:669,t:1526919361904};\\\", \\\"{x:548,y:688,t:1526919361921};\\\", \\\"{x:603,y:711,t:1526919361937};\\\", \\\"{x:646,y:733,t:1526919361954};\\\", \\\"{x:689,y:749,t:1526919361971};\\\", \\\"{x:771,y:784,t:1526919361987};\\\", \\\"{x:837,y:815,t:1526919362004};\\\", \\\"{x:903,y:843,t:1526919362022};\\\", \\\"{x:956,y:868,t:1526919362037};\\\", \\\"{x:1003,y:887,t:1526919362055};\\\", \\\"{x:1031,y:903,t:1526919362071};\\\", \\\"{x:1043,y:910,t:1526919362088};\\\", \\\"{x:1047,y:914,t:1526919362105};\\\", \\\"{x:1047,y:915,t:1526919362122};\\\", \\\"{x:1048,y:916,t:1526919362156};\\\", \\\"{x:1049,y:916,t:1526919362555};\\\", \\\"{x:1050,y:916,t:1526919364293};\\\", \\\"{x:1046,y:914,t:1526919367011};\\\", \\\"{x:1039,y:910,t:1526919367020};\\\", \\\"{x:1034,y:909,t:1526919367034};\\\", \\\"{x:1026,y:905,t:1526919367051};\\\", \\\"{x:1016,y:900,t:1526919367067};\\\", \\\"{x:1005,y:897,t:1526919367084};\\\", \\\"{x:1003,y:896,t:1526919367101};\\\", \\\"{x:1001,y:896,t:1526919367118};\\\", \\\"{x:998,y:894,t:1526919367133};\\\", \\\"{x:994,y:893,t:1526919367151};\\\", \\\"{x:990,y:892,t:1526919367168};\\\", \\\"{x:983,y:892,t:1526919367184};\\\", \\\"{x:979,y:891,t:1526919367201};\\\", \\\"{x:975,y:890,t:1526919367218};\\\", \\\"{x:971,y:890,t:1526919367235};\\\", \\\"{x:968,y:889,t:1526919367252};\\\", \\\"{x:962,y:888,t:1526919367268};\\\", \\\"{x:958,y:888,t:1526919367284};\\\", \\\"{x:953,y:887,t:1526919367301};\\\", \\\"{x:949,y:886,t:1526919367318};\\\", \\\"{x:944,y:886,t:1526919367334};\\\", \\\"{x:942,y:885,t:1526919367352};\\\", \\\"{x:940,y:885,t:1526919367367};\\\", \\\"{x:937,y:885,t:1526919367385};\\\", \\\"{x:936,y:885,t:1526919367402};\\\", \\\"{x:934,y:885,t:1526919367418};\\\", \\\"{x:932,y:883,t:1526919367435};\\\", \\\"{x:929,y:883,t:1526919367452};\\\", \\\"{x:927,y:883,t:1526919367468};\\\", \\\"{x:926,y:883,t:1526919367485};\\\", \\\"{x:924,y:882,t:1526919367501};\\\", \\\"{x:923,y:882,t:1526919367519};\\\", \\\"{x:921,y:882,t:1526919367534};\\\", \\\"{x:918,y:882,t:1526919367552};\\\", \\\"{x:916,y:881,t:1526919367569};\\\", \\\"{x:914,y:880,t:1526919367587};\\\", \\\"{x:913,y:880,t:1526919367619};\\\", \\\"{x:911,y:880,t:1526919367635};\\\", \\\"{x:910,y:880,t:1526919367659};\\\", \\\"{x:908,y:879,t:1526919367669};\\\", \\\"{x:907,y:879,t:1526919367691};\\\", \\\"{x:906,y:879,t:1526919367708};\\\", \\\"{x:905,y:879,t:1526919367719};\\\", \\\"{x:904,y:879,t:1526919367756};\\\", \\\"{x:903,y:879,t:1526919367804};\\\", \\\"{x:902,y:878,t:1526919368260};\\\", \\\"{x:901,y:878,t:1526919368580};\\\", \\\"{x:901,y:877,t:1526919368588};\\\", \\\"{x:901,y:876,t:1526919369284};\\\", \\\"{x:901,y:875,t:1526919369291};\\\", \\\"{x:901,y:874,t:1526919369315};\\\", \\\"{x:901,y:873,t:1526919369387};\\\", \\\"{x:899,y:871,t:1526919369395};\\\", \\\"{x:898,y:870,t:1526919369407};\\\", \\\"{x:890,y:869,t:1526919369422};\\\", \\\"{x:873,y:861,t:1526919369439};\\\", \\\"{x:856,y:855,t:1526919369457};\\\", \\\"{x:833,y:847,t:1526919369473};\\\", \\\"{x:807,y:838,t:1526919369490};\\\", \\\"{x:781,y:830,t:1526919369507};\\\", \\\"{x:750,y:819,t:1526919369523};\\\", \\\"{x:725,y:811,t:1526919369540};\\\", \\\"{x:703,y:805,t:1526919369557};\\\", \\\"{x:682,y:801,t:1526919369573};\\\", \\\"{x:665,y:797,t:1526919369590};\\\", \\\"{x:644,y:793,t:1526919369606};\\\", \\\"{x:623,y:787,t:1526919369624};\\\", \\\"{x:609,y:782,t:1526919369640};\\\", \\\"{x:598,y:777,t:1526919369657};\\\", \\\"{x:589,y:774,t:1526919369674};\\\", \\\"{x:584,y:772,t:1526919369691};\\\", \\\"{x:581,y:770,t:1526919369707};\\\", \\\"{x:575,y:768,t:1526919369723};\\\", \\\"{x:571,y:765,t:1526919369740};\\\", \\\"{x:567,y:764,t:1526919369758};\\\", \\\"{x:563,y:762,t:1526919369774};\\\", \\\"{x:557,y:760,t:1526919369790};\\\", \\\"{x:555,y:759,t:1526919369808};\\\", \\\"{x:551,y:757,t:1526919369823};\\\", \\\"{x:546,y:755,t:1526919369840};\\\", \\\"{x:540,y:753,t:1526919369858};\\\", \\\"{x:536,y:752,t:1526919369874};\\\", \\\"{x:532,y:750,t:1526919369890};\\\", \\\"{x:530,y:750,t:1526919369907};\\\", \\\"{x:529,y:750,t:1526919369986};\\\", \\\"{x:525,y:747,t:1526919370364};\\\", \\\"{x:524,y:747,t:1526919370375};\\\", \\\"{x:522,y:746,t:1526919370392};\\\", \\\"{x:521,y:746,t:1526919370412};\\\", \\\"{x:520,y:746,t:1526919370425};\\\" ] }, { \\\"rt\\\": 57366, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 697530, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-04 PM-03 PM-02 PM-02 PM-12 PM-12 PM-J -11 AM-11 AM-02 PM-01 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:747,t:1526919374083};\\\", \\\"{x:526,y:751,t:1526919374095};\\\", \\\"{x:536,y:757,t:1526919374112};\\\", \\\"{x:543,y:761,t:1526919374127};\\\", \\\"{x:551,y:765,t:1526919374145};\\\", \\\"{x:555,y:767,t:1526919374164};\\\", \\\"{x:556,y:768,t:1526919374179};\\\", \\\"{x:557,y:769,t:1526919374194};\\\", \\\"{x:559,y:770,t:1526919374214};\\\", \\\"{x:561,y:770,t:1526919374231};\\\", \\\"{x:566,y:772,t:1526919374249};\\\", \\\"{x:570,y:773,t:1526919374263};\\\", \\\"{x:572,y:774,t:1526919374281};\\\", \\\"{x:578,y:775,t:1526919374298};\\\", \\\"{x:584,y:777,t:1526919374313};\\\", \\\"{x:595,y:781,t:1526919374331};\\\", \\\"{x:613,y:786,t:1526919374348};\\\", \\\"{x:632,y:789,t:1526919374365};\\\", \\\"{x:654,y:795,t:1526919374381};\\\", \\\"{x:674,y:802,t:1526919374397};\\\", \\\"{x:696,y:808,t:1526919374415};\\\", \\\"{x:717,y:814,t:1526919374431};\\\", \\\"{x:736,y:821,t:1526919374448};\\\", \\\"{x:756,y:830,t:1526919374464};\\\", \\\"{x:773,y:838,t:1526919374481};\\\", \\\"{x:786,y:849,t:1526919374498};\\\", \\\"{x:802,y:859,t:1526919374515};\\\", \\\"{x:820,y:869,t:1526919374531};\\\", \\\"{x:828,y:873,t:1526919374548};\\\", \\\"{x:833,y:876,t:1526919374565};\\\", \\\"{x:834,y:876,t:1526919374581};\\\", \\\"{x:836,y:876,t:1526919375244};\\\", \\\"{x:838,y:876,t:1526919375259};\\\", \\\"{x:839,y:876,t:1526919375356};\\\", \\\"{x:841,y:875,t:1526919375388};\\\", \\\"{x:842,y:875,t:1526919375399};\\\", \\\"{x:843,y:875,t:1526919375435};\\\", \\\"{x:845,y:874,t:1526919375924};\\\", \\\"{x:846,y:874,t:1526919375933};\\\", \\\"{x:846,y:873,t:1526919375949};\\\", \\\"{x:848,y:872,t:1526919375966};\\\", \\\"{x:850,y:872,t:1526919375983};\\\", \\\"{x:854,y:870,t:1526919376000};\\\", \\\"{x:860,y:868,t:1526919376016};\\\", \\\"{x:865,y:866,t:1526919376032};\\\", \\\"{x:873,y:862,t:1526919376050};\\\", \\\"{x:886,y:859,t:1526919376067};\\\", \\\"{x:895,y:857,t:1526919376082};\\\", \\\"{x:905,y:856,t:1526919376099};\\\", \\\"{x:912,y:856,t:1526919376116};\\\", \\\"{x:926,y:852,t:1526919376132};\\\", \\\"{x:938,y:852,t:1526919376150};\\\", \\\"{x:951,y:851,t:1526919376166};\\\", \\\"{x:968,y:851,t:1526919376183};\\\", \\\"{x:986,y:851,t:1526919376200};\\\", \\\"{x:1005,y:851,t:1526919376217};\\\", \\\"{x:1021,y:851,t:1526919376233};\\\", \\\"{x:1036,y:851,t:1526919376250};\\\", \\\"{x:1052,y:851,t:1526919376266};\\\", \\\"{x:1061,y:852,t:1526919376283};\\\", \\\"{x:1072,y:853,t:1526919376300};\\\", \\\"{x:1082,y:854,t:1526919376317};\\\", \\\"{x:1093,y:857,t:1526919376333};\\\", \\\"{x:1107,y:858,t:1526919376350};\\\", \\\"{x:1120,y:861,t:1526919376367};\\\", \\\"{x:1133,y:862,t:1526919376384};\\\", \\\"{x:1142,y:863,t:1526919376400};\\\", \\\"{x:1147,y:864,t:1526919376417};\\\", \\\"{x:1151,y:865,t:1526919376434};\\\", \\\"{x:1153,y:865,t:1526919376450};\\\", \\\"{x:1158,y:865,t:1526919376467};\\\", \\\"{x:1161,y:865,t:1526919376484};\\\", \\\"{x:1164,y:866,t:1526919376500};\\\", \\\"{x:1168,y:866,t:1526919376517};\\\", \\\"{x:1171,y:866,t:1526919376534};\\\", \\\"{x:1175,y:866,t:1526919376550};\\\", \\\"{x:1177,y:866,t:1526919376567};\\\", \\\"{x:1180,y:866,t:1526919376584};\\\", \\\"{x:1183,y:866,t:1526919376600};\\\", \\\"{x:1184,y:866,t:1526919376617};\\\", \\\"{x:1186,y:866,t:1526919376660};\\\", \\\"{x:1187,y:866,t:1526919376955};\\\", \\\"{x:1189,y:866,t:1526919381252};\\\", \\\"{x:1196,y:866,t:1526919381260};\\\", \\\"{x:1206,y:871,t:1526919381273};\\\", \\\"{x:1237,y:880,t:1526919381289};\\\", \\\"{x:1271,y:893,t:1526919381306};\\\", \\\"{x:1323,y:907,t:1526919381323};\\\", \\\"{x:1343,y:913,t:1526919381338};\\\", \\\"{x:1356,y:917,t:1526919381356};\\\", \\\"{x:1368,y:922,t:1526919381373};\\\", \\\"{x:1374,y:925,t:1526919381389};\\\", \\\"{x:1382,y:928,t:1526919381406};\\\", \\\"{x:1389,y:929,t:1526919381423};\\\", \\\"{x:1393,y:931,t:1526919381440};\\\", \\\"{x:1396,y:932,t:1526919381456};\\\", \\\"{x:1398,y:933,t:1526919381474};\\\", \\\"{x:1400,y:933,t:1526919381490};\\\", \\\"{x:1405,y:934,t:1526919381507};\\\", \\\"{x:1421,y:938,t:1526919381523};\\\", \\\"{x:1432,y:939,t:1526919381540};\\\", \\\"{x:1448,y:945,t:1526919381556};\\\", \\\"{x:1462,y:949,t:1526919381573};\\\", \\\"{x:1479,y:953,t:1526919381589};\\\", \\\"{x:1499,y:960,t:1526919381606};\\\", \\\"{x:1521,y:965,t:1526919381624};\\\", \\\"{x:1546,y:971,t:1526919381640};\\\", \\\"{x:1568,y:975,t:1526919381656};\\\", \\\"{x:1589,y:980,t:1526919381674};\\\", \\\"{x:1600,y:981,t:1526919381691};\\\", \\\"{x:1616,y:981,t:1526919381707};\\\", \\\"{x:1623,y:981,t:1526919381723};\\\", \\\"{x:1628,y:981,t:1526919381741};\\\", \\\"{x:1632,y:981,t:1526919381758};\\\", \\\"{x:1636,y:981,t:1526919381774};\\\", \\\"{x:1637,y:981,t:1526919381796};\\\", \\\"{x:1636,y:981,t:1526919381899};\\\", \\\"{x:1635,y:981,t:1526919381907};\\\", \\\"{x:1624,y:981,t:1526919381923};\\\", \\\"{x:1609,y:981,t:1526919381940};\\\", \\\"{x:1591,y:981,t:1526919381958};\\\", \\\"{x:1576,y:981,t:1526919381974};\\\", \\\"{x:1561,y:981,t:1526919381991};\\\", \\\"{x:1553,y:981,t:1526919382008};\\\", \\\"{x:1538,y:981,t:1526919382025};\\\", \\\"{x:1525,y:981,t:1526919382041};\\\", \\\"{x:1512,y:981,t:1526919382058};\\\", \\\"{x:1501,y:981,t:1526919382075};\\\", \\\"{x:1493,y:981,t:1526919382090};\\\", \\\"{x:1484,y:981,t:1526919382107};\\\", \\\"{x:1481,y:981,t:1526919382124};\\\", \\\"{x:1480,y:980,t:1526919382140};\\\", \\\"{x:1479,y:980,t:1526919382157};\\\", \\\"{x:1478,y:980,t:1526919382210};\\\", \\\"{x:1478,y:979,t:1526919382224};\\\", \\\"{x:1478,y:977,t:1526919382240};\\\", \\\"{x:1478,y:974,t:1526919382256};\\\", \\\"{x:1478,y:971,t:1526919382274};\\\", \\\"{x:1478,y:969,t:1526919382291};\\\", \\\"{x:1479,y:967,t:1526919382307};\\\", \\\"{x:1480,y:967,t:1526919383243};\\\", \\\"{x:1481,y:967,t:1526919383484};\\\", \\\"{x:1482,y:967,t:1526919383539};\\\", \\\"{x:1483,y:967,t:1526919383555};\\\", \\\"{x:1484,y:967,t:1526919383604};\\\", \\\"{x:1485,y:968,t:1526919383636};\\\", \\\"{x:1487,y:968,t:1526919383659};\\\", \\\"{x:1488,y:971,t:1526919383676};\\\", \\\"{x:1490,y:975,t:1526919383693};\\\", \\\"{x:1491,y:977,t:1526919383709};\\\", \\\"{x:1492,y:979,t:1526919383727};\\\", \\\"{x:1492,y:977,t:1526919388907};\\\", \\\"{x:1492,y:975,t:1526919388972};\\\", \\\"{x:1493,y:975,t:1526919388987};\\\", \\\"{x:1493,y:974,t:1526919389027};\\\", \\\"{x:1494,y:973,t:1526919389043};\\\", \\\"{x:1494,y:972,t:1526919389051};\\\", \\\"{x:1495,y:970,t:1526919389065};\\\", \\\"{x:1498,y:964,t:1526919389084};\\\", \\\"{x:1500,y:958,t:1526919389099};\\\", \\\"{x:1507,y:944,t:1526919389116};\\\", \\\"{x:1511,y:934,t:1526919389132};\\\", \\\"{x:1514,y:922,t:1526919389150};\\\", \\\"{x:1516,y:912,t:1526919389166};\\\", \\\"{x:1516,y:906,t:1526919389183};\\\", \\\"{x:1516,y:902,t:1526919389200};\\\", \\\"{x:1516,y:896,t:1526919389216};\\\", \\\"{x:1516,y:893,t:1526919389233};\\\", \\\"{x:1516,y:889,t:1526919389250};\\\", \\\"{x:1515,y:883,t:1526919389266};\\\", \\\"{x:1515,y:879,t:1526919389283};\\\", \\\"{x:1512,y:868,t:1526919389299};\\\", \\\"{x:1511,y:863,t:1526919389317};\\\", \\\"{x:1508,y:858,t:1526919389333};\\\", \\\"{x:1507,y:853,t:1526919389350};\\\", \\\"{x:1505,y:848,t:1526919389367};\\\", \\\"{x:1504,y:847,t:1526919389383};\\\", \\\"{x:1503,y:843,t:1526919389399};\\\", \\\"{x:1502,y:841,t:1526919389420};\\\", \\\"{x:1502,y:840,t:1526919389433};\\\", \\\"{x:1502,y:838,t:1526919389812};\\\", \\\"{x:1501,y:836,t:1526919389819};\\\", \\\"{x:1500,y:834,t:1526919389833};\\\", \\\"{x:1500,y:833,t:1526919389850};\\\", \\\"{x:1499,y:829,t:1526919389867};\\\", \\\"{x:1497,y:823,t:1526919389883};\\\", \\\"{x:1496,y:819,t:1526919389899};\\\", \\\"{x:1496,y:815,t:1526919389917};\\\", \\\"{x:1494,y:811,t:1526919389933};\\\", \\\"{x:1493,y:807,t:1526919389951};\\\", \\\"{x:1492,y:804,t:1526919389967};\\\", \\\"{x:1490,y:799,t:1526919389984};\\\", \\\"{x:1490,y:796,t:1526919390001};\\\", \\\"{x:1488,y:792,t:1526919390017};\\\", \\\"{x:1488,y:789,t:1526919390034};\\\", \\\"{x:1487,y:785,t:1526919390051};\\\", \\\"{x:1486,y:782,t:1526919390067};\\\", \\\"{x:1485,y:776,t:1526919390084};\\\", \\\"{x:1484,y:772,t:1526919390101};\\\", \\\"{x:1483,y:769,t:1526919390117};\\\", \\\"{x:1482,y:764,t:1526919390134};\\\", \\\"{x:1481,y:760,t:1526919390150};\\\", \\\"{x:1481,y:754,t:1526919390167};\\\", \\\"{x:1480,y:744,t:1526919390184};\\\", \\\"{x:1479,y:738,t:1526919390200};\\\", \\\"{x:1478,y:728,t:1526919390218};\\\", \\\"{x:1476,y:717,t:1526919390234};\\\", \\\"{x:1474,y:708,t:1526919390251};\\\", \\\"{x:1473,y:697,t:1526919390268};\\\", \\\"{x:1473,y:692,t:1526919390283};\\\", \\\"{x:1472,y:685,t:1526919390301};\\\", \\\"{x:1472,y:681,t:1526919390318};\\\", \\\"{x:1472,y:677,t:1526919390334};\\\", \\\"{x:1470,y:673,t:1526919390351};\\\", \\\"{x:1470,y:671,t:1526919390368};\\\", \\\"{x:1470,y:670,t:1526919390387};\\\", \\\"{x:1470,y:669,t:1526919390403};\\\", \\\"{x:1470,y:668,t:1526919390419};\\\", \\\"{x:1470,y:667,t:1526919390436};\\\", \\\"{x:1470,y:666,t:1526919390451};\\\", \\\"{x:1469,y:662,t:1526919390467};\\\", \\\"{x:1469,y:661,t:1526919390485};\\\", \\\"{x:1469,y:658,t:1526919390500};\\\", \\\"{x:1466,y:655,t:1526919390517};\\\", \\\"{x:1466,y:652,t:1526919390534};\\\", \\\"{x:1465,y:650,t:1526919390551};\\\", \\\"{x:1464,y:648,t:1526919390568};\\\", \\\"{x:1464,y:647,t:1526919390585};\\\", \\\"{x:1463,y:646,t:1526919390604};\\\", \\\"{x:1463,y:645,t:1526919390619};\\\", \\\"{x:1462,y:644,t:1526919390643};\\\", \\\"{x:1462,y:643,t:1526919390779};\\\", \\\"{x:1462,y:642,t:1526919390820};\\\", \\\"{x:1461,y:641,t:1526919390867};\\\", \\\"{x:1461,y:639,t:1526919390923};\\\", \\\"{x:1460,y:639,t:1526919390934};\\\", \\\"{x:1460,y:638,t:1526919390955};\\\", \\\"{x:1459,y:636,t:1526919390994};\\\", \\\"{x:1458,y:635,t:1526919391131};\\\", \\\"{x:1456,y:638,t:1526919391653};\\\", \\\"{x:1451,y:655,t:1526919391669};\\\", \\\"{x:1446,y:680,t:1526919391686};\\\", \\\"{x:1440,y:716,t:1526919391703};\\\", \\\"{x:1438,y:748,t:1526919391719};\\\", \\\"{x:1431,y:783,t:1526919391735};\\\", \\\"{x:1428,y:807,t:1526919391753};\\\", \\\"{x:1422,y:834,t:1526919391769};\\\", \\\"{x:1420,y:857,t:1526919391786};\\\", \\\"{x:1415,y:874,t:1526919391803};\\\", \\\"{x:1412,y:888,t:1526919391819};\\\", \\\"{x:1409,y:904,t:1526919391836};\\\", \\\"{x:1407,y:912,t:1526919391854};\\\", \\\"{x:1406,y:917,t:1526919391869};\\\", \\\"{x:1405,y:919,t:1526919391886};\\\", \\\"{x:1404,y:923,t:1526919391903};\\\", \\\"{x:1403,y:926,t:1526919391919};\\\", \\\"{x:1402,y:931,t:1526919391935};\\\", \\\"{x:1398,y:938,t:1526919391952};\\\", \\\"{x:1398,y:942,t:1526919391970};\\\", \\\"{x:1396,y:944,t:1526919391985};\\\", \\\"{x:1396,y:945,t:1526919392068};\\\", \\\"{x:1395,y:945,t:1526919392075};\\\", \\\"{x:1395,y:946,t:1526919392086};\\\", \\\"{x:1394,y:949,t:1526919392103};\\\", \\\"{x:1394,y:951,t:1526919392120};\\\", \\\"{x:1394,y:952,t:1526919392136};\\\", \\\"{x:1394,y:954,t:1526919392155};\\\", \\\"{x:1394,y:955,t:1526919392170};\\\", \\\"{x:1394,y:957,t:1526919392187};\\\", \\\"{x:1394,y:960,t:1526919392202};\\\", \\\"{x:1394,y:962,t:1526919392219};\\\", \\\"{x:1394,y:964,t:1526919392236};\\\", \\\"{x:1394,y:965,t:1526919392252};\\\", \\\"{x:1393,y:966,t:1526919392571};\\\", \\\"{x:1392,y:966,t:1526919392587};\\\", \\\"{x:1390,y:966,t:1526919392619};\\\", \\\"{x:1389,y:966,t:1526919392923};\\\", \\\"{x:1387,y:966,t:1526919392964};\\\", \\\"{x:1386,y:967,t:1526919393004};\\\", \\\"{x:1386,y:968,t:1526919393156};\\\", \\\"{x:1386,y:969,t:1526919393187};\\\", \\\"{x:1386,y:968,t:1526919393523};\\\", \\\"{x:1386,y:967,t:1526919393612};\\\", \\\"{x:1387,y:967,t:1526919393667};\\\", \\\"{x:1388,y:967,t:1526919394307};\\\", \\\"{x:1388,y:966,t:1526919394892};\\\", \\\"{x:1387,y:965,t:1526919394932};\\\", \\\"{x:1385,y:965,t:1526919394972};\\\", \\\"{x:1384,y:964,t:1526919395013};\\\", \\\"{x:1383,y:964,t:1526919395060};\\\", \\\"{x:1382,y:964,t:1526919395148};\\\", \\\"{x:1380,y:954,t:1526919396660};\\\", \\\"{x:1379,y:939,t:1526919396675};\\\", \\\"{x:1379,y:938,t:1526919396692};\\\", \\\"{x:1378,y:938,t:1526919396709};\\\", \\\"{x:1376,y:937,t:1526919396812};\\\", \\\"{x:1372,y:937,t:1526919396825};\\\", \\\"{x:1369,y:939,t:1526919396842};\\\", \\\"{x:1359,y:946,t:1526919396858};\\\", \\\"{x:1354,y:951,t:1526919396874};\\\", \\\"{x:1350,y:954,t:1526919396892};\\\", \\\"{x:1349,y:955,t:1526919396909};\\\", \\\"{x:1348,y:955,t:1526919397003};\\\", \\\"{x:1348,y:956,t:1526919397043};\\\", \\\"{x:1348,y:957,t:1526919397067};\\\", \\\"{x:1348,y:958,t:1526919397075};\\\", \\\"{x:1348,y:961,t:1526919397092};\\\", \\\"{x:1348,y:966,t:1526919397109};\\\", \\\"{x:1347,y:964,t:1526919397220};\\\", \\\"{x:1346,y:958,t:1526919397227};\\\", \\\"{x:1346,y:955,t:1526919397243};\\\", \\\"{x:1346,y:942,t:1526919397259};\\\", \\\"{x:1346,y:933,t:1526919397276};\\\", \\\"{x:1346,y:921,t:1526919397293};\\\", \\\"{x:1346,y:908,t:1526919397309};\\\", \\\"{x:1346,y:894,t:1526919397326};\\\", \\\"{x:1346,y:886,t:1526919397343};\\\", \\\"{x:1346,y:877,t:1526919397360};\\\", \\\"{x:1346,y:870,t:1526919397376};\\\", \\\"{x:1346,y:863,t:1526919397393};\\\", \\\"{x:1346,y:856,t:1526919397409};\\\", \\\"{x:1346,y:850,t:1526919397426};\\\", \\\"{x:1347,y:839,t:1526919397443};\\\", \\\"{x:1348,y:835,t:1526919397459};\\\", \\\"{x:1348,y:831,t:1526919397477};\\\", \\\"{x:1349,y:827,t:1526919397493};\\\", \\\"{x:1349,y:824,t:1526919397510};\\\", \\\"{x:1349,y:822,t:1526919397527};\\\", \\\"{x:1349,y:821,t:1526919397543};\\\", \\\"{x:1349,y:818,t:1526919397561};\\\", \\\"{x:1349,y:817,t:1526919397577};\\\", \\\"{x:1351,y:812,t:1526919397593};\\\", \\\"{x:1351,y:809,t:1526919397610};\\\", \\\"{x:1351,y:807,t:1526919397626};\\\", \\\"{x:1351,y:802,t:1526919397644};\\\", \\\"{x:1351,y:800,t:1526919397659};\\\", \\\"{x:1351,y:797,t:1526919397676};\\\", \\\"{x:1351,y:794,t:1526919397693};\\\", \\\"{x:1352,y:792,t:1526919397710};\\\", \\\"{x:1352,y:789,t:1526919397726};\\\", \\\"{x:1352,y:787,t:1526919397743};\\\", \\\"{x:1352,y:786,t:1526919397761};\\\", \\\"{x:1352,y:785,t:1526919397796};\\\", \\\"{x:1352,y:784,t:1526919397820};\\\", \\\"{x:1353,y:784,t:1526919397827};\\\", \\\"{x:1353,y:783,t:1526919397852};\\\", \\\"{x:1353,y:782,t:1526919397939};\\\", \\\"{x:1353,y:781,t:1526919397964};\\\", \\\"{x:1354,y:779,t:1526919397987};\\\", \\\"{x:1355,y:778,t:1526919398028};\\\", \\\"{x:1355,y:777,t:1526919398059};\\\", \\\"{x:1355,y:776,t:1526919398148};\\\", \\\"{x:1355,y:775,t:1526919398388};\\\", \\\"{x:1357,y:773,t:1526919398420};\\\", \\\"{x:1358,y:772,t:1526919398435};\\\", \\\"{x:1359,y:772,t:1526919398445};\\\", \\\"{x:1359,y:771,t:1526919398475};\\\", \\\"{x:1359,y:770,t:1526919398491};\\\", \\\"{x:1359,y:769,t:1526919398652};\\\", \\\"{x:1359,y:768,t:1526919398667};\\\", \\\"{x:1359,y:767,t:1526919398692};\\\", \\\"{x:1359,y:766,t:1526919398716};\\\", \\\"{x:1359,y:765,t:1526919398739};\\\", \\\"{x:1358,y:764,t:1526919398771};\\\", \\\"{x:1358,y:763,t:1526919399964};\\\", \\\"{x:1358,y:761,t:1526919402965};\\\", \\\"{x:1358,y:760,t:1526919402972};\\\", \\\"{x:1358,y:758,t:1526919402984};\\\", \\\"{x:1358,y:753,t:1526919403000};\\\", \\\"{x:1358,y:750,t:1526919403016};\\\", \\\"{x:1358,y:747,t:1526919403034};\\\", \\\"{x:1358,y:746,t:1526919403075};\\\", \\\"{x:1358,y:748,t:1526919403179};\\\", \\\"{x:1358,y:751,t:1526919403187};\\\", \\\"{x:1357,y:754,t:1526919403201};\\\", \\\"{x:1357,y:762,t:1526919403216};\\\", \\\"{x:1356,y:772,t:1526919403233};\\\", \\\"{x:1356,y:785,t:1526919403251};\\\", \\\"{x:1356,y:801,t:1526919403267};\\\", \\\"{x:1356,y:832,t:1526919403283};\\\", \\\"{x:1356,y:857,t:1526919403300};\\\", \\\"{x:1361,y:881,t:1526919403316};\\\", \\\"{x:1364,y:907,t:1526919403334};\\\", \\\"{x:1365,y:923,t:1526919403350};\\\", \\\"{x:1366,y:938,t:1526919403367};\\\", \\\"{x:1366,y:951,t:1526919403384};\\\", \\\"{x:1367,y:962,t:1526919403401};\\\", \\\"{x:1367,y:969,t:1526919403416};\\\", \\\"{x:1367,y:975,t:1526919403433};\\\", \\\"{x:1367,y:978,t:1526919403451};\\\", \\\"{x:1367,y:981,t:1526919403467};\\\", \\\"{x:1364,y:979,t:1526919403579};\\\", \\\"{x:1364,y:975,t:1526919403587};\\\", \\\"{x:1362,y:967,t:1526919403601};\\\", \\\"{x:1359,y:952,t:1526919403618};\\\", \\\"{x:1356,y:936,t:1526919403633};\\\", \\\"{x:1356,y:921,t:1526919403650};\\\", \\\"{x:1357,y:912,t:1526919403667};\\\", \\\"{x:1357,y:911,t:1526919403700};\\\", \\\"{x:1358,y:911,t:1526919403756};\\\", \\\"{x:1359,y:911,t:1526919403771};\\\", \\\"{x:1360,y:912,t:1526919403795};\\\", \\\"{x:1360,y:914,t:1526919403803};\\\", \\\"{x:1360,y:917,t:1526919403818};\\\", \\\"{x:1360,y:922,t:1526919403835};\\\", \\\"{x:1360,y:927,t:1526919403850};\\\", \\\"{x:1360,y:937,t:1526919403868};\\\", \\\"{x:1360,y:942,t:1526919403885};\\\", \\\"{x:1360,y:945,t:1526919403901};\\\", \\\"{x:1360,y:948,t:1526919403917};\\\", \\\"{x:1360,y:949,t:1526919403934};\\\", \\\"{x:1360,y:950,t:1526919404468};\\\", \\\"{x:1358,y:951,t:1526919404485};\\\", \\\"{x:1356,y:952,t:1526919404502};\\\", \\\"{x:1355,y:953,t:1526919405683};\\\", \\\"{x:1355,y:959,t:1526919405691};\\\", \\\"{x:1355,y:962,t:1526919405703};\\\", \\\"{x:1356,y:967,t:1526919405720};\\\", \\\"{x:1357,y:969,t:1526919405737};\\\", \\\"{x:1357,y:970,t:1526919405753};\\\", \\\"{x:1357,y:971,t:1526919405812};\\\", \\\"{x:1356,y:971,t:1526919406276};\\\", \\\"{x:1356,y:972,t:1526919406291};\\\", \\\"{x:1355,y:972,t:1526919406379};\\\", \\\"{x:1354,y:972,t:1526919406460};\\\", \\\"{x:1353,y:972,t:1526919406540};\\\", \\\"{x:1353,y:973,t:1526919406571};\\\", \\\"{x:1352,y:973,t:1526919408451};\\\", \\\"{x:1352,y:971,t:1526919408467};\\\", \\\"{x:1352,y:970,t:1526919408491};\\\", \\\"{x:1352,y:968,t:1526919408516};\\\", \\\"{x:1352,y:967,t:1526919408547};\\\", \\\"{x:1352,y:966,t:1526919408587};\\\", \\\"{x:1352,y:965,t:1526919408595};\\\", \\\"{x:1352,y:964,t:1526919408607};\\\", \\\"{x:1352,y:962,t:1526919408624};\\\", \\\"{x:1352,y:961,t:1526919408651};\\\", \\\"{x:1352,y:959,t:1526919408699};\\\", \\\"{x:1352,y:958,t:1526919408731};\\\", \\\"{x:1352,y:956,t:1526919408755};\\\", \\\"{x:1352,y:955,t:1526919408772};\\\", \\\"{x:1352,y:953,t:1526919408780};\\\", \\\"{x:1352,y:952,t:1526919408795};\\\", \\\"{x:1352,y:951,t:1526919408812};\\\", \\\"{x:1352,y:950,t:1526919408824};\\\", \\\"{x:1352,y:949,t:1526919408843};\\\", \\\"{x:1352,y:948,t:1526919408868};\\\", \\\"{x:1352,y:947,t:1526919408883};\\\", \\\"{x:1352,y:946,t:1526919408931};\\\", \\\"{x:1352,y:944,t:1526919409068};\\\", \\\"{x:1352,y:943,t:1526919409180};\\\", \\\"{x:1349,y:943,t:1526919409771};\\\", \\\"{x:1339,y:945,t:1526919409779};\\\", \\\"{x:1327,y:945,t:1526919409792};\\\", \\\"{x:1300,y:945,t:1526919409808};\\\", \\\"{x:1261,y:945,t:1526919409825};\\\", \\\"{x:1191,y:942,t:1526919409842};\\\", \\\"{x:1107,y:931,t:1526919409857};\\\", \\\"{x:991,y:911,t:1526919409875};\\\", \\\"{x:924,y:890,t:1526919409891};\\\", \\\"{x:859,y:869,t:1526919409907};\\\", \\\"{x:798,y:852,t:1526919409924};\\\", \\\"{x:739,y:834,t:1526919409941};\\\", \\\"{x:694,y:819,t:1526919409959};\\\", \\\"{x:652,y:799,t:1526919409974};\\\", \\\"{x:613,y:783,t:1526919409992};\\\", \\\"{x:578,y:768,t:1526919410008};\\\", \\\"{x:542,y:753,t:1526919410026};\\\", \\\"{x:517,y:738,t:1526919410041};\\\", \\\"{x:480,y:715,t:1526919410058};\\\", \\\"{x:461,y:703,t:1526919410076};\\\", \\\"{x:449,y:695,t:1526919410093};\\\", \\\"{x:443,y:688,t:1526919410110};\\\", \\\"{x:436,y:678,t:1526919410126};\\\", \\\"{x:428,y:668,t:1526919410143};\\\", \\\"{x:416,y:658,t:1526919410160};\\\", \\\"{x:403,y:647,t:1526919410177};\\\", \\\"{x:402,y:642,t:1526919410194};\\\", \\\"{x:400,y:633,t:1526919410211};\\\", \\\"{x:409,y:620,t:1526919410226};\\\", \\\"{x:431,y:604,t:1526919410244};\\\", \\\"{x:468,y:586,t:1526919410260};\\\", \\\"{x:503,y:570,t:1526919410277};\\\", \\\"{x:536,y:557,t:1526919410294};\\\", \\\"{x:563,y:547,t:1526919410309};\\\", \\\"{x:585,y:540,t:1526919410327};\\\", \\\"{x:600,y:536,t:1526919410343};\\\", \\\"{x:607,y:534,t:1526919410360};\\\", \\\"{x:615,y:532,t:1526919410376};\\\", \\\"{x:627,y:530,t:1526919410394};\\\", \\\"{x:651,y:526,t:1526919410410};\\\", \\\"{x:659,y:524,t:1526919410426};\\\", \\\"{x:664,y:522,t:1526919410443};\\\", \\\"{x:666,y:521,t:1526919410460};\\\", \\\"{x:667,y:521,t:1526919410635};\\\", \\\"{x:670,y:521,t:1526919410645};\\\", \\\"{x:680,y:520,t:1526919410660};\\\", \\\"{x:705,y:520,t:1526919410677};\\\", \\\"{x:736,y:520,t:1526919410696};\\\", \\\"{x:758,y:520,t:1526919410710};\\\", \\\"{x:765,y:520,t:1526919410727};\\\", \\\"{x:766,y:520,t:1526919410743};\\\", \\\"{x:767,y:519,t:1526919410760};\\\", \\\"{x:768,y:519,t:1526919410777};\\\", \\\"{x:772,y:519,t:1526919410793};\\\", \\\"{x:781,y:519,t:1526919410810};\\\", \\\"{x:789,y:519,t:1526919410827};\\\", \\\"{x:798,y:519,t:1526919410844};\\\", \\\"{x:807,y:519,t:1526919410860};\\\", \\\"{x:820,y:519,t:1526919410877};\\\", \\\"{x:829,y:517,t:1526919410895};\\\", \\\"{x:832,y:517,t:1526919410911};\\\", \\\"{x:834,y:517,t:1526919410927};\\\", \\\"{x:834,y:516,t:1526919410945};\\\", \\\"{x:835,y:515,t:1526919410960};\\\", \\\"{x:836,y:515,t:1526919410987};\\\", \\\"{x:837,y:516,t:1526919411331};\\\", \\\"{x:837,y:524,t:1526919411344};\\\", \\\"{x:837,y:541,t:1526919411363};\\\", \\\"{x:837,y:565,t:1526919411377};\\\", \\\"{x:837,y:601,t:1526919411395};\\\", \\\"{x:841,y:629,t:1526919411413};\\\", \\\"{x:849,y:651,t:1526919411427};\\\", \\\"{x:858,y:672,t:1526919411444};\\\", \\\"{x:869,y:690,t:1526919411461};\\\", \\\"{x:881,y:709,t:1526919411478};\\\", \\\"{x:897,y:729,t:1526919411494};\\\", \\\"{x:914,y:749,t:1526919411511};\\\", \\\"{x:927,y:764,t:1526919411528};\\\", \\\"{x:947,y:782,t:1526919411544};\\\", \\\"{x:972,y:800,t:1526919411561};\\\", \\\"{x:1015,y:824,t:1526919411578};\\\", \\\"{x:1039,y:834,t:1526919411595};\\\", \\\"{x:1063,y:840,t:1526919411611};\\\", \\\"{x:1085,y:843,t:1526919411629};\\\", \\\"{x:1104,y:845,t:1526919411644};\\\", \\\"{x:1121,y:845,t:1526919411661};\\\", \\\"{x:1130,y:845,t:1526919411679};\\\", \\\"{x:1141,y:845,t:1526919411695};\\\", \\\"{x:1146,y:845,t:1526919411711};\\\", \\\"{x:1151,y:845,t:1526919411728};\\\", \\\"{x:1158,y:845,t:1526919411746};\\\", \\\"{x:1168,y:847,t:1526919411761};\\\", \\\"{x:1182,y:851,t:1526919411779};\\\", \\\"{x:1190,y:852,t:1526919411795};\\\", \\\"{x:1198,y:856,t:1526919411811};\\\", \\\"{x:1209,y:862,t:1526919411828};\\\", \\\"{x:1222,y:866,t:1526919411846};\\\", \\\"{x:1232,y:870,t:1526919411863};\\\", \\\"{x:1239,y:873,t:1526919411879};\\\", \\\"{x:1241,y:874,t:1526919411896};\\\", \\\"{x:1242,y:876,t:1526919411913};\\\", \\\"{x:1243,y:882,t:1526919411929};\\\", \\\"{x:1245,y:885,t:1526919411945};\\\", \\\"{x:1248,y:889,t:1526919411963};\\\", \\\"{x:1250,y:894,t:1526919411979};\\\", \\\"{x:1250,y:897,t:1526919411995};\\\", \\\"{x:1251,y:902,t:1526919412013};\\\", \\\"{x:1251,y:905,t:1526919412030};\\\", \\\"{x:1251,y:908,t:1526919412046};\\\", \\\"{x:1251,y:912,t:1526919412062};\\\", \\\"{x:1250,y:916,t:1526919412080};\\\", \\\"{x:1249,y:919,t:1526919412095};\\\", \\\"{x:1247,y:924,t:1526919412113};\\\", \\\"{x:1247,y:928,t:1526919412130};\\\", \\\"{x:1245,y:932,t:1526919412146};\\\", \\\"{x:1243,y:937,t:1526919412163};\\\", \\\"{x:1243,y:939,t:1526919412180};\\\", \\\"{x:1243,y:941,t:1526919412197};\\\", \\\"{x:1241,y:944,t:1526919412213};\\\", \\\"{x:1241,y:947,t:1526919412230};\\\", \\\"{x:1241,y:949,t:1526919412246};\\\", \\\"{x:1240,y:951,t:1526919412262};\\\", \\\"{x:1239,y:954,t:1526919412279};\\\", \\\"{x:1238,y:958,t:1526919412296};\\\", \\\"{x:1237,y:961,t:1526919412313};\\\", \\\"{x:1237,y:962,t:1526919412330};\\\", \\\"{x:1236,y:963,t:1526919412355};\\\", \\\"{x:1235,y:962,t:1526919412491};\\\", \\\"{x:1234,y:962,t:1526919412499};\\\", \\\"{x:1234,y:961,t:1526919412514};\\\", \\\"{x:1234,y:957,t:1526919412531};\\\", \\\"{x:1233,y:954,t:1526919412547};\\\", \\\"{x:1233,y:951,t:1526919412564};\\\", \\\"{x:1233,y:949,t:1526919412581};\\\", \\\"{x:1233,y:948,t:1526919412604};\\\", \\\"{x:1233,y:946,t:1526919412627};\\\", \\\"{x:1233,y:945,t:1526919412635};\\\", \\\"{x:1233,y:943,t:1526919412648};\\\", \\\"{x:1233,y:941,t:1526919412663};\\\", \\\"{x:1233,y:939,t:1526919412681};\\\", \\\"{x:1233,y:936,t:1526919412697};\\\", \\\"{x:1233,y:935,t:1526919412714};\\\", \\\"{x:1233,y:933,t:1526919412730};\\\", \\\"{x:1233,y:932,t:1526919412748};\\\", \\\"{x:1233,y:931,t:1526919412765};\\\", \\\"{x:1233,y:930,t:1526919412781};\\\", \\\"{x:1233,y:929,t:1526919412964};\\\", \\\"{x:1233,y:925,t:1526919412982};\\\", \\\"{x:1231,y:922,t:1526919412998};\\\", \\\"{x:1231,y:919,t:1526919413015};\\\", \\\"{x:1231,y:916,t:1526919413032};\\\", \\\"{x:1231,y:914,t:1526919413048};\\\", \\\"{x:1231,y:912,t:1526919413065};\\\", \\\"{x:1231,y:911,t:1526919413082};\\\", \\\"{x:1230,y:907,t:1526919413099};\\\", \\\"{x:1230,y:906,t:1526919413115};\\\", \\\"{x:1230,y:901,t:1526919413132};\\\", \\\"{x:1229,y:896,t:1526919413149};\\\", \\\"{x:1229,y:893,t:1526919413166};\\\", \\\"{x:1229,y:888,t:1526919413182};\\\", \\\"{x:1228,y:884,t:1526919413199};\\\", \\\"{x:1227,y:880,t:1526919413215};\\\", \\\"{x:1225,y:875,t:1526919413232};\\\", \\\"{x:1224,y:870,t:1526919413249};\\\", \\\"{x:1222,y:866,t:1526919413266};\\\", \\\"{x:1220,y:864,t:1526919413282};\\\", \\\"{x:1220,y:862,t:1526919413299};\\\", \\\"{x:1219,y:862,t:1526919413331};\\\", \\\"{x:1219,y:861,t:1526919413348};\\\", \\\"{x:1218,y:860,t:1526919413365};\\\", \\\"{x:1218,y:859,t:1526919413395};\\\", \\\"{x:1217,y:858,t:1526919413404};\\\", \\\"{x:1217,y:857,t:1526919413416};\\\", \\\"{x:1216,y:856,t:1526919413433};\\\", \\\"{x:1215,y:853,t:1526919413449};\\\", \\\"{x:1213,y:851,t:1526919413465};\\\", \\\"{x:1211,y:846,t:1526919413483};\\\", \\\"{x:1209,y:844,t:1526919413499};\\\", \\\"{x:1208,y:840,t:1526919413516};\\\", \\\"{x:1208,y:839,t:1526919413539};\\\", \\\"{x:1208,y:838,t:1526919413549};\\\", \\\"{x:1208,y:837,t:1526919413566};\\\", \\\"{x:1208,y:836,t:1526919413583};\\\", \\\"{x:1208,y:835,t:1526919413600};\\\", \\\"{x:1208,y:834,t:1526919413651};\\\", \\\"{x:1209,y:832,t:1526919413686};\\\", \\\"{x:1210,y:831,t:1526919413716};\\\", \\\"{x:1211,y:830,t:1526919413965};\\\", \\\"{x:1212,y:830,t:1526919414019};\\\", \\\"{x:1213,y:830,t:1526919414076};\\\", \\\"{x:1214,y:830,t:1526919414427};\\\", \\\"{x:1214,y:831,t:1526919414587};\\\", \\\"{x:1214,y:834,t:1526919414601};\\\", \\\"{x:1214,y:837,t:1526919414619};\\\", \\\"{x:1214,y:843,t:1526919414635};\\\", \\\"{x:1214,y:845,t:1526919414652};\\\", \\\"{x:1215,y:845,t:1526919414779};\\\", \\\"{x:1217,y:845,t:1526919414787};\\\", \\\"{x:1218,y:844,t:1526919414801};\\\", \\\"{x:1220,y:841,t:1526919414819};\\\", \\\"{x:1223,y:836,t:1526919414836};\\\", \\\"{x:1224,y:833,t:1526919414852};\\\", \\\"{x:1227,y:827,t:1526919414869};\\\", \\\"{x:1231,y:817,t:1526919414885};\\\", \\\"{x:1233,y:807,t:1526919414902};\\\", \\\"{x:1237,y:797,t:1526919414919};\\\", \\\"{x:1242,y:786,t:1526919414936};\\\", \\\"{x:1245,y:778,t:1526919414952};\\\", \\\"{x:1247,y:775,t:1526919414969};\\\", \\\"{x:1248,y:773,t:1526919414986};\\\", \\\"{x:1249,y:773,t:1526919415035};\\\", \\\"{x:1250,y:786,t:1526919415053};\\\", \\\"{x:1250,y:806,t:1526919415069};\\\", \\\"{x:1255,y:831,t:1526919415086};\\\", \\\"{x:1257,y:851,t:1526919415103};\\\", \\\"{x:1260,y:870,t:1526919415120};\\\", \\\"{x:1262,y:884,t:1526919415136};\\\", \\\"{x:1265,y:897,t:1526919415153};\\\", \\\"{x:1271,y:909,t:1526919415170};\\\", \\\"{x:1272,y:919,t:1526919415186};\\\", \\\"{x:1276,y:934,t:1526919415203};\\\", \\\"{x:1279,y:943,t:1526919415219};\\\", \\\"{x:1280,y:947,t:1526919415236};\\\", \\\"{x:1280,y:952,t:1526919415252};\\\", \\\"{x:1280,y:957,t:1526919415270};\\\", \\\"{x:1283,y:962,t:1526919415286};\\\", \\\"{x:1283,y:965,t:1526919415303};\\\", \\\"{x:1283,y:962,t:1526919415451};\\\", \\\"{x:1283,y:960,t:1526919415460};\\\", \\\"{x:1283,y:959,t:1526919415470};\\\", \\\"{x:1283,y:957,t:1526919415487};\\\", \\\"{x:1283,y:955,t:1526919415504};\\\", \\\"{x:1283,y:956,t:1526919415876};\\\", \\\"{x:1283,y:957,t:1526919415888};\\\", \\\"{x:1283,y:958,t:1526919415905};\\\", \\\"{x:1283,y:960,t:1526919415920};\\\", \\\"{x:1283,y:961,t:1526919415939};\\\", \\\"{x:1283,y:963,t:1526919416163};\\\", \\\"{x:1283,y:965,t:1526919416179};\\\", \\\"{x:1283,y:966,t:1526919416188};\\\", \\\"{x:1284,y:967,t:1526919416204};\\\", \\\"{x:1284,y:969,t:1526919416222};\\\", \\\"{x:1285,y:971,t:1526919416238};\\\", \\\"{x:1286,y:972,t:1526919416259};\\\", \\\"{x:1286,y:973,t:1526919416291};\\\", \\\"{x:1287,y:974,t:1526919416307};\\\", \\\"{x:1287,y:975,t:1526919417468};\\\", \\\"{x:1286,y:975,t:1526919417499};\\\", \\\"{x:1285,y:975,t:1526919417515};\\\", \\\"{x:1285,y:974,t:1526919417539};\\\", \\\"{x:1284,y:972,t:1526919417555};\\\", \\\"{x:1283,y:970,t:1526919417570};\\\", \\\"{x:1283,y:969,t:1526919417586};\\\", \\\"{x:1283,y:968,t:1526919417595};\\\", \\\"{x:1282,y:967,t:1526919417612};\\\", \\\"{x:1281,y:967,t:1526919417624};\\\", \\\"{x:1280,y:965,t:1526919417642};\\\", \\\"{x:1280,y:964,t:1526919417659};\\\", \\\"{x:1279,y:962,t:1526919417675};\\\", \\\"{x:1275,y:958,t:1526919417692};\\\", \\\"{x:1271,y:955,t:1526919417708};\\\", \\\"{x:1265,y:948,t:1526919417725};\\\", \\\"{x:1257,y:942,t:1526919417742};\\\", \\\"{x:1242,y:934,t:1526919417758};\\\", \\\"{x:1211,y:918,t:1526919417775};\\\", \\\"{x:1142,y:887,t:1526919417792};\\\", \\\"{x:1045,y:843,t:1526919417809};\\\", \\\"{x:932,y:795,t:1526919417826};\\\", \\\"{x:802,y:739,t:1526919417842};\\\", \\\"{x:635,y:664,t:1526919417859};\\\", \\\"{x:549,y:623,t:1526919417877};\\\", \\\"{x:496,y:598,t:1526919417892};\\\", \\\"{x:456,y:575,t:1526919417925};\\\", \\\"{x:444,y:566,t:1526919417950};\\\", \\\"{x:438,y:562,t:1526919417967};\\\", \\\"{x:434,y:558,t:1526919417983};\\\", \\\"{x:423,y:549,t:1526919417999};\\\", \\\"{x:416,y:544,t:1526919418016};\\\", \\\"{x:413,y:541,t:1526919418033};\\\", \\\"{x:412,y:539,t:1526919418050};\\\", \\\"{x:418,y:526,t:1526919418067};\\\", \\\"{x:436,y:516,t:1526919418084};\\\", \\\"{x:474,y:510,t:1526919418100};\\\", \\\"{x:518,y:510,t:1526919418117};\\\", \\\"{x:554,y:510,t:1526919418133};\\\", \\\"{x:576,y:510,t:1526919418149};\\\", \\\"{x:581,y:510,t:1526919418166};\\\", \\\"{x:582,y:510,t:1526919418183};\\\", \\\"{x:583,y:510,t:1526919418299};\\\", \\\"{x:588,y:511,t:1526919418317};\\\", \\\"{x:596,y:511,t:1526919418333};\\\", \\\"{x:609,y:512,t:1526919418350};\\\", \\\"{x:618,y:515,t:1526919418366};\\\", \\\"{x:620,y:515,t:1526919418383};\\\", \\\"{x:623,y:516,t:1526919418399};\\\", \\\"{x:624,y:516,t:1526919418417};\\\", \\\"{x:625,y:519,t:1526919418787};\\\", \\\"{x:625,y:528,t:1526919418802};\\\", \\\"{x:625,y:549,t:1526919418817};\\\", \\\"{x:625,y:573,t:1526919418833};\\\", \\\"{x:635,y:623,t:1526919418850};\\\", \\\"{x:648,y:651,t:1526919418866};\\\", \\\"{x:660,y:678,t:1526919418883};\\\", \\\"{x:671,y:702,t:1526919418901};\\\", \\\"{x:686,y:728,t:1526919418917};\\\", \\\"{x:699,y:757,t:1526919418933};\\\", \\\"{x:709,y:780,t:1526919418950};\\\", \\\"{x:722,y:805,t:1526919418966};\\\", \\\"{x:734,y:823,t:1526919418984};\\\", \\\"{x:747,y:840,t:1526919419000};\\\", \\\"{x:757,y:855,t:1526919419017};\\\", \\\"{x:766,y:866,t:1526919419033};\\\", \\\"{x:780,y:880,t:1526919419051};\\\", \\\"{x:790,y:887,t:1526919419066};\\\", \\\"{x:805,y:896,t:1526919419083};\\\", \\\"{x:825,y:905,t:1526919419100};\\\", \\\"{x:850,y:916,t:1526919419117};\\\", \\\"{x:874,y:924,t:1526919419134};\\\", \\\"{x:895,y:933,t:1526919419150};\\\", \\\"{x:907,y:937,t:1526919419167};\\\", \\\"{x:916,y:940,t:1526919419184};\\\", \\\"{x:922,y:940,t:1526919419200};\\\", \\\"{x:930,y:944,t:1526919419217};\\\", \\\"{x:943,y:950,t:1526919419234};\\\", \\\"{x:961,y:955,t:1526919419250};\\\", \\\"{x:966,y:957,t:1526919419267};\\\", \\\"{x:967,y:957,t:1526919419284};\\\", \\\"{x:969,y:957,t:1526919421027};\\\", \\\"{x:973,y:955,t:1526919421034};\\\", \\\"{x:981,y:953,t:1526919421049};\\\", \\\"{x:1009,y:949,t:1526919421066};\\\", \\\"{x:1037,y:946,t:1526919421082};\\\", \\\"{x:1070,y:946,t:1526919421099};\\\", \\\"{x:1099,y:946,t:1526919421116};\\\", \\\"{x:1128,y:946,t:1526919421132};\\\", \\\"{x:1170,y:947,t:1526919421149};\\\", \\\"{x:1210,y:952,t:1526919421166};\\\", \\\"{x:1254,y:964,t:1526919421183};\\\", \\\"{x:1288,y:973,t:1526919421199};\\\", \\\"{x:1319,y:983,t:1526919421216};\\\", \\\"{x:1340,y:989,t:1526919421233};\\\", \\\"{x:1364,y:995,t:1526919421249};\\\", \\\"{x:1392,y:1001,t:1526919421266};\\\", \\\"{x:1419,y:1004,t:1526919421283};\\\", \\\"{x:1455,y:1009,t:1526919421299};\\\", \\\"{x:1470,y:1009,t:1526919421316};\\\", \\\"{x:1479,y:1009,t:1526919421332};\\\", \\\"{x:1488,y:1007,t:1526919421349};\\\", \\\"{x:1492,y:1005,t:1526919421366};\\\", \\\"{x:1495,y:1003,t:1526919421382};\\\", \\\"{x:1495,y:1002,t:1526919421399};\\\", \\\"{x:1495,y:1001,t:1526919421483};\\\", \\\"{x:1494,y:999,t:1526919421499};\\\", \\\"{x:1491,y:997,t:1526919421515};\\\", \\\"{x:1488,y:996,t:1526919421533};\\\", \\\"{x:1485,y:995,t:1526919421549};\\\", \\\"{x:1483,y:993,t:1526919421565};\\\", \\\"{x:1481,y:992,t:1526919421582};\\\", \\\"{x:1480,y:992,t:1526919421599};\\\", \\\"{x:1477,y:990,t:1526919421616};\\\", \\\"{x:1476,y:989,t:1526919421632};\\\", \\\"{x:1473,y:986,t:1526919421649};\\\", \\\"{x:1470,y:984,t:1526919421665};\\\", \\\"{x:1467,y:981,t:1526919421682};\\\", \\\"{x:1463,y:978,t:1526919421699};\\\", \\\"{x:1463,y:977,t:1526919421715};\\\", \\\"{x:1461,y:975,t:1526919421733};\\\", \\\"{x:1460,y:974,t:1526919421764};\\\", \\\"{x:1460,y:973,t:1526919421783};\\\", \\\"{x:1458,y:972,t:1526919421803};\\\", \\\"{x:1458,y:971,t:1526919421818};\\\", \\\"{x:1457,y:970,t:1526919421832};\\\", \\\"{x:1457,y:968,t:1526919421849};\\\", \\\"{x:1456,y:967,t:1526919421865};\\\", \\\"{x:1456,y:965,t:1526919421882};\\\", \\\"{x:1455,y:964,t:1526919421899};\\\", \\\"{x:1455,y:962,t:1526919421916};\\\", \\\"{x:1455,y:961,t:1526919421932};\\\", \\\"{x:1454,y:960,t:1526919421949};\\\", \\\"{x:1453,y:960,t:1526919422043};\\\", \\\"{x:1451,y:960,t:1526919422051};\\\", \\\"{x:1449,y:960,t:1526919422067};\\\", \\\"{x:1448,y:960,t:1526919422082};\\\", \\\"{x:1441,y:962,t:1526919422098};\\\", \\\"{x:1433,y:966,t:1526919422115};\\\", \\\"{x:1431,y:967,t:1526919422132};\\\", \\\"{x:1429,y:969,t:1526919422148};\\\", \\\"{x:1427,y:970,t:1526919422165};\\\", \\\"{x:1425,y:971,t:1526919422187};\\\", \\\"{x:1423,y:973,t:1526919422198};\\\", \\\"{x:1422,y:973,t:1526919422215};\\\", \\\"{x:1421,y:974,t:1526919422232};\\\", \\\"{x:1420,y:975,t:1526919422259};\\\", \\\"{x:1419,y:975,t:1526919422459};\\\", \\\"{x:1420,y:975,t:1526919423962};\\\", \\\"{x:1425,y:976,t:1526919423969};\\\", \\\"{x:1432,y:978,t:1526919423980};\\\", \\\"{x:1445,y:980,t:1526919423996};\\\", \\\"{x:1454,y:983,t:1526919424014};\\\", \\\"{x:1464,y:987,t:1526919424029};\\\", \\\"{x:1469,y:987,t:1526919424046};\\\", \\\"{x:1472,y:987,t:1526919424064};\\\", \\\"{x:1473,y:987,t:1526919424089};\\\", \\\"{x:1474,y:987,t:1526919424130};\\\", \\\"{x:1473,y:987,t:1526919424730};\\\", \\\"{x:1464,y:988,t:1526919424747};\\\", \\\"{x:1463,y:989,t:1526919424764};\\\", \\\"{x:1450,y:983,t:1526919428763};\\\", \\\"{x:1428,y:969,t:1526919428777};\\\", \\\"{x:1390,y:947,t:1526919428794};\\\", \\\"{x:1357,y:930,t:1526919428810};\\\", \\\"{x:1345,y:922,t:1526919428826};\\\", \\\"{x:1334,y:916,t:1526919428843};\\\", \\\"{x:1326,y:912,t:1526919428860};\\\", \\\"{x:1312,y:906,t:1526919428877};\\\", \\\"{x:1292,y:898,t:1526919428893};\\\", \\\"{x:1267,y:884,t:1526919428911};\\\", \\\"{x:1188,y:856,t:1526919428927};\\\", \\\"{x:1100,y:833,t:1526919428943};\\\", \\\"{x:1015,y:823,t:1526919428960};\\\", \\\"{x:953,y:822,t:1526919428978};\\\", \\\"{x:910,y:822,t:1526919428993};\\\", \\\"{x:866,y:822,t:1526919429010};\\\", \\\"{x:841,y:822,t:1526919429027};\\\", \\\"{x:821,y:822,t:1526919429044};\\\", \\\"{x:802,y:822,t:1526919429060};\\\", \\\"{x:784,y:819,t:1526919429076};\\\", \\\"{x:763,y:819,t:1526919429092};\\\", \\\"{x:743,y:819,t:1526919429110};\\\", \\\"{x:717,y:818,t:1526919429125};\\\", \\\"{x:689,y:813,t:1526919429143};\\\", \\\"{x:662,y:810,t:1526919429159};\\\", \\\"{x:637,y:807,t:1526919429176};\\\", \\\"{x:610,y:800,t:1526919429193};\\\", \\\"{x:577,y:795,t:1526919429210};\\\", \\\"{x:558,y:793,t:1526919429226};\\\", \\\"{x:538,y:791,t:1526919429242};\\\", \\\"{x:523,y:790,t:1526919429260};\\\", \\\"{x:510,y:786,t:1526919429276};\\\", \\\"{x:500,y:784,t:1526919429293};\\\", \\\"{x:491,y:781,t:1526919429310};\\\", \\\"{x:488,y:780,t:1526919429326};\\\", \\\"{x:486,y:779,t:1526919429342};\\\", \\\"{x:482,y:777,t:1526919429360};\\\", \\\"{x:479,y:775,t:1526919429375};\\\", \\\"{x:476,y:772,t:1526919429393};\\\", \\\"{x:473,y:766,t:1526919429411};\\\", \\\"{x:473,y:765,t:1526919429433};\\\", \\\"{x:473,y:764,t:1526919429443};\\\", \\\"{x:473,y:763,t:1526919429555};\\\" ] }, { \\\"rt\\\": 74211, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 772952, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The events that start at 12 PM will fall on a straight, upward line protruding from the 12 PM spot on the x-axis.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10813, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 784768, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 11343, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 797128, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 27739, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 826199, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"UQWX4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"UQWX4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 205, dom: 1250, initialDom: 1293",
  "javascriptErrors": []
}