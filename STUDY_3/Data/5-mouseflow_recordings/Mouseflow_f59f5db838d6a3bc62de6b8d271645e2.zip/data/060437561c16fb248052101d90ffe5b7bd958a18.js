var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060437561c16fb248052101d90ffe5b7bd958a18"] = {
  "startTime": "2018-06-04T19:07:37.4832567Z",
  "websitePageUrl": "/",
  "visitTime": 291334,
  "engagementTime": 80545,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "f59f5db838d6a3bc62de6b8d271645e2",
    "created": "2018-06-04T19:07:37.4832567+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c544777e54d72f93175e72f524cfc518",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f59f5db838d6a3bc62de6b8d271645e2/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 384,
      "e": 384,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10003,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 184410,
      "e": 5101,
      "ty": 2,
      "x": 895,
      "y": 384
    },
    {
      "t": 184510,
      "e": 5201,
      "ty": 2,
      "x": 1479,
      "y": 1022
    },
    {
      "t": 184511,
      "e": 5202,
      "ty": 41,
      "x": 50657,
      "y": 61701,
      "ta": "html > body"
    },
    {
      "t": 184610,
      "e": 5301,
      "ty": 2,
      "x": 1462,
      "y": 977
    },
    {
      "t": 184710,
      "e": 5401,
      "ty": 2,
      "x": 1287,
      "y": 840
    },
    {
      "t": 184760,
      "e": 5451,
      "ty": 41,
      "x": 39348,
      "y": 54353,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 184810,
      "e": 5501,
      "ty": 2,
      "x": 1037,
      "y": 814
    },
    {
      "t": 184910,
      "e": 5601,
      "ty": 2,
      "x": 962,
      "y": 827
    },
    {
      "t": 184998,
      "e": 5689,
      "ty": 3,
      "x": 961,
      "y": 826,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185010,
      "e": 5701,
      "ty": 2,
      "x": 961,
      "y": 826
    },
    {
      "t": 185010,
      "e": 5701,
      "ty": 41,
      "x": 32849,
      "y": 55663,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185103,
      "e": 5794,
      "ty": 4,
      "x": 32849,
      "y": 55663,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185103,
      "e": 5794,
      "ty": 5,
      "x": 961,
      "y": 826,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185311,
      "e": 6002,
      "ty": 2,
      "x": 961,
      "y": 779
    },
    {
      "t": 185411,
      "e": 6102,
      "ty": 2,
      "x": 883,
      "y": 550
    },
    {
      "t": 185438,
      "e": 6129,
      "ty": 3,
      "x": 883,
      "y": 550,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185510,
      "e": 6201,
      "ty": 41,
      "x": 28589,
      "y": 33054,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185557,
      "e": 6248,
      "ty": 4,
      "x": 28589,
      "y": 33054,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185558,
      "e": 6249,
      "ty": 5,
      "x": 883,
      "y": 550,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 190011,
      "e": 10702,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 192091,
      "e": 11249,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 192210,
      "e": 11249,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 192311,
      "e": 11350,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 193425,
      "e": 12464,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 195710,
      "e": 14749,
      "ty": 2,
      "x": 777,
      "y": 543
    },
    {
      "t": 195762,
      "e": 14801,
      "ty": 41,
      "x": 23297,
      "y": 18724,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 195811,
      "e": 14850,
      "ty": 2,
      "x": 768,
      "y": 744
    },
    {
      "t": 195911,
      "e": 14950,
      "ty": 2,
      "x": 777,
      "y": 749
    },
    {
      "t": 196010,
      "e": 15049,
      "ty": 2,
      "x": 832,
      "y": 773
    },
    {
      "t": 196011,
      "e": 15050,
      "ty": 41,
      "x": 26494,
      "y": 54353,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 196110,
      "e": 15149,
      "ty": 2,
      "x": 902,
      "y": 902
    },
    {
      "t": 196210,
      "e": 15249,
      "ty": 2,
      "x": 904,
      "y": 912
    },
    {
      "t": 196260,
      "e": 15299,
      "ty": 41,
      "x": 30627,
      "y": 58438,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 196309,
      "e": 15348,
      "ty": 2,
      "x": 918,
      "y": 879
    },
    {
      "t": 196411,
      "e": 15450,
      "ty": 2,
      "x": 918,
      "y": 872
    },
    {
      "t": 196430,
      "e": 15469,
      "ty": 3,
      "x": 918,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 196510,
      "e": 15549,
      "ty": 41,
      "x": 24055,
      "y": 50640,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 196526,
      "e": 15565,
      "ty": 4,
      "x": 24055,
      "y": 50640,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 196526,
      "e": 15565,
      "ty": 5,
      "x": 918,
      "y": 872,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 196527,
      "e": 15566,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 196530,
      "e": 15569,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 196710,
      "e": 15749,
      "ty": 2,
      "x": 931,
      "y": 886
    },
    {
      "t": 196760,
      "e": 15799,
      "ty": 41,
      "x": 32004,
      "y": 59123,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 196810,
      "e": 15849,
      "ty": 6,
      "x": 1000,
      "y": 1005,
      "ta": "#start"
    },
    {
      "t": 196812,
      "e": 15851,
      "ty": 2,
      "x": 1000,
      "y": 1005
    },
    {
      "t": 196825,
      "e": 15864,
      "ty": 7,
      "x": 1005,
      "y": 1018,
      "ta": "#start"
    },
    {
      "t": 196909,
      "e": 15948,
      "ty": 2,
      "x": 1006,
      "y": 1021
    },
    {
      "t": 197010,
      "e": 16049,
      "ty": 2,
      "x": 1005,
      "y": 1020
    },
    {
      "t": 197010,
      "e": 16049,
      "ty": 41,
      "x": 54066,
      "y": 25987,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 197025,
      "e": 16064,
      "ty": 6,
      "x": 1003,
      "y": 1007,
      "ta": "#start"
    },
    {
      "t": 197110,
      "e": 16149,
      "ty": 2,
      "x": 1002,
      "y": 993
    },
    {
      "t": 197167,
      "e": 16206,
      "ty": 3,
      "x": 1002,
      "y": 993,
      "ta": "#start"
    },
    {
      "t": 197168,
      "e": 16207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 197170,
      "e": 16209,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 197260,
      "e": 16299,
      "ty": 41,
      "x": 50516,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 197270,
      "e": 16309,
      "ty": 4,
      "x": 50516,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 197271,
      "e": 16310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 197271,
      "e": 16310,
      "ty": 5,
      "x": 1002,
      "y": 993,
      "ta": "#start"
    },
    {
      "t": 197272,
      "e": 16311,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 197610,
      "e": 16649,
      "ty": 2,
      "x": 1002,
      "y": 985
    },
    {
      "t": 197760,
      "e": 16799,
      "ty": 41,
      "x": 34231,
      "y": 59450,
      "ta": "html > body"
    },
    {
      "t": 197909,
      "e": 16948,
      "ty": 2,
      "x": 1003,
      "y": 929
    },
    {
      "t": 198010,
      "e": 17049,
      "ty": 2,
      "x": 1047,
      "y": 716
    },
    {
      "t": 198010,
      "e": 17049,
      "ty": 41,
      "x": 35780,
      "y": 43081,
      "ta": "html > body"
    },
    {
      "t": 198109,
      "e": 17148,
      "ty": 2,
      "x": 1047,
      "y": 715
    },
    {
      "t": 198260,
      "e": 17299,
      "ty": 41,
      "x": 35780,
      "y": 43020,
      "ta": "html > body"
    },
    {
      "t": 198278,
      "e": 17317,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 199210,
      "e": 18249,
      "ty": 2,
      "x": 1045,
      "y": 714
    },
    {
      "t": 199260,
      "e": 18299,
      "ty": 41,
      "x": 35643,
      "y": 42959,
      "ta": "html > body"
    },
    {
      "t": 199310,
      "e": 18349,
      "ty": 2,
      "x": 1027,
      "y": 713
    },
    {
      "t": 199345,
      "e": 18384,
      "ty": 6,
      "x": 996,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 199361,
      "e": 18400,
      "ty": 7,
      "x": 975,
      "y": 638,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 199361,
      "e": 18400,
      "ty": 6,
      "x": 975,
      "y": 638,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 199378,
      "e": 18417,
      "ty": 7,
      "x": 951,
      "y": 600,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 199410,
      "e": 18449,
      "ty": 2,
      "x": 924,
      "y": 558
    },
    {
      "t": 199510,
      "e": 18549,
      "ty": 2,
      "x": 888,
      "y": 478
    },
    {
      "t": 199510,
      "e": 18549,
      "ty": 41,
      "x": 17302,
      "y": 6342,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 199610,
      "e": 18649,
      "ty": 2,
      "x": 884,
      "y": 477
    },
    {
      "t": 199710,
      "e": 18749,
      "ty": 2,
      "x": 866,
      "y": 525
    },
    {
      "t": 199745,
      "e": 18784,
      "ty": 6,
      "x": 862,
      "y": 538,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199760,
      "e": 18799,
      "ty": 41,
      "x": 11679,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199777,
      "e": 18816,
      "ty": 7,
      "x": 858,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 199809,
      "e": 18848,
      "ty": 2,
      "x": 858,
      "y": 559
    },
    {
      "t": 199910,
      "e": 18949,
      "ty": 2,
      "x": 857,
      "y": 559
    },
    {
      "t": 200010,
      "e": 19049,
      "ty": 2,
      "x": 858,
      "y": 556
    },
    {
      "t": 200010,
      "e": 19049,
      "ty": 41,
      "x": 10814,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 200010,
      "e": 19049,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 200027,
      "e": 19066,
      "ty": 6,
      "x": 861,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200110,
      "e": 19149,
      "ty": 2,
      "x": 862,
      "y": 549
    },
    {
      "t": 200210,
      "e": 19249,
      "ty": 2,
      "x": 862,
      "y": 548
    },
    {
      "t": 200260,
      "e": 19299,
      "ty": 41,
      "x": 11679,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200550,
      "e": 19589,
      "ty": 3,
      "x": 862,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200552,
      "e": 19591,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200677,
      "e": 19716,
      "ty": 4,
      "x": 11679,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 200678,
      "e": 19717,
      "ty": 5,
      "x": 862,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 202667,
      "e": 21706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203166,
      "e": 22205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203199,
      "e": 22238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203232,
      "e": 22271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203266,
      "e": 22305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203298,
      "e": 22337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203331,
      "e": 22370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203364,
      "e": 22403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203397,
      "e": 22436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203431,
      "e": 22470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203464,
      "e": 22503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203496,
      "e": 22535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203529,
      "e": 22568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203562,
      "e": 22601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203596,
      "e": 22635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203628,
      "e": 22667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203661,
      "e": 22700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 203689,
      "e": 22728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 210010,
      "e": 27728,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 210755,
      "e": 27728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 211253,
      "e": 28226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 211287,
      "e": 28260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 211319,
      "e": 28292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 211347,
      "e": 28320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 211347,
      "e": 28320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 211475,
      "e": 28448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Y"
    },
    {
      "t": 211482,
      "e": 28455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 211483,
      "e": 28456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 211595,
      "e": 28568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YA"
    },
    {
      "t": 211634,
      "e": 28607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 211635,
      "e": 28608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 211746,
      "e": 28719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YAN"
    },
    {
      "t": 211874,
      "e": 28847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 211875,
      "e": 28848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 211978,
      "e": 28951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANK"
    },
    {
      "t": 212866,
      "e": 29839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 212867,
      "e": 29840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 212969,
      "e": 29942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 213058,
      "e": 30031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 213058,
      "e": 30031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 213210,
      "e": 30183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 213242,
      "e": 30215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 214910,
      "e": 31883,
      "ty": 2,
      "x": 869,
      "y": 545
    },
    {
      "t": 214941,
      "e": 31914,
      "ty": 7,
      "x": 871,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 214991,
      "e": 31964,
      "ty": 6,
      "x": 871,
      "y": 629,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215011,
      "e": 31984,
      "ty": 2,
      "x": 871,
      "y": 644
    },
    {
      "t": 215011,
      "e": 31984,
      "ty": 41,
      "x": 13626,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215024,
      "e": 31997,
      "ty": 7,
      "x": 870,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215110,
      "e": 32083,
      "ty": 2,
      "x": 868,
      "y": 678
    },
    {
      "t": 215211,
      "e": 32184,
      "ty": 2,
      "x": 865,
      "y": 648
    },
    {
      "t": 215224,
      "e": 32197,
      "ty": 6,
      "x": 865,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215257,
      "e": 32230,
      "ty": 7,
      "x": 862,
      "y": 623,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215260,
      "e": 32233,
      "ty": 41,
      "x": 11679,
      "y": 42985,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 215310,
      "e": 32283,
      "ty": 2,
      "x": 859,
      "y": 612
    },
    {
      "t": 215390,
      "e": 32363,
      "ty": 6,
      "x": 858,
      "y": 628,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215411,
      "e": 32384,
      "ty": 2,
      "x": 857,
      "y": 630
    },
    {
      "t": 215510,
      "e": 32483,
      "ty": 2,
      "x": 856,
      "y": 632
    },
    {
      "t": 215511,
      "e": 32484,
      "ty": 41,
      "x": 10381,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215678,
      "e": 32651,
      "ty": 3,
      "x": 856,
      "y": 632,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215680,
      "e": 32653,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANKEE"
    },
    {
      "t": 215681,
      "e": 32654,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 215681,
      "e": 32654,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215813,
      "e": 32786,
      "ty": 4,
      "x": 10381,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 215813,
      "e": 32786,
      "ty": 5,
      "x": 856,
      "y": 632,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 216826,
      "e": 33799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 216827,
      "e": 33800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 216905,
      "e": 33878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 217016,
      "e": 33989,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 217107,
      "e": 34080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 217107,
      "e": 34080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217186,
      "e": 34159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 217330,
      "e": 34303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 217330,
      "e": 34303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217394,
      "e": 34367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 218009,
      "e": 34982,
      "ty": 2,
      "x": 858,
      "y": 636
    },
    {
      "t": 218010,
      "e": 34983,
      "ty": 41,
      "x": 10814,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218059,
      "e": 35032,
      "ty": 7,
      "x": 879,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218093,
      "e": 35066,
      "ty": 6,
      "x": 907,
      "y": 659,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 218109,
      "e": 35082,
      "ty": 2,
      "x": 913,
      "y": 659
    },
    {
      "t": 218210,
      "e": 35183,
      "ty": 2,
      "x": 918,
      "y": 659
    },
    {
      "t": 218260,
      "e": 35233,
      "ty": 41,
      "x": 11894,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 218310,
      "e": 35283,
      "ty": 2,
      "x": 929,
      "y": 661
    },
    {
      "t": 218410,
      "e": 35383,
      "ty": 2,
      "x": 930,
      "y": 661
    },
    {
      "t": 218510,
      "e": 35483,
      "ty": 41,
      "x": 17563,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 218609,
      "e": 35582,
      "ty": 2,
      "x": 932,
      "y": 663
    },
    {
      "t": 218710,
      "e": 35683,
      "ty": 2,
      "x": 936,
      "y": 679
    },
    {
      "t": 218760,
      "e": 35733,
      "ty": 41,
      "x": 20655,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220010,
      "e": 36983,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 248342,
      "e": 40733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 248382,
      "e": 40773,
      "ty": 7,
      "x": 936,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 248382,
      "e": 40773,
      "ty": 6,
      "x": 936,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 248403,
      "e": 40794,
      "ty": 7,
      "x": 936,
      "y": 745,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 248403,
      "e": 40794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 248413,
      "e": 40804,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 248413,
      "e": 40804,
      "ty": 2,
      "x": 936,
      "y": 745
    },
    {
      "t": 248513,
      "e": 40904,
      "ty": 41,
      "x": 31958,
      "y": 40827,
      "ta": "html > body"
    },
    {
      "t": 256693,
      "e": 45904,
      "ty": 6,
      "x": 944,
      "y": 738,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256714,
      "e": 45925,
      "ty": 2,
      "x": 947,
      "y": 738
    },
    {
      "t": 256763,
      "e": 45974,
      "ty": 41,
      "x": 26325,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256814,
      "e": 46025,
      "ty": 2,
      "x": 947,
      "y": 737
    },
    {
      "t": 256873,
      "e": 46084,
      "ty": 3,
      "x": 951,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256875,
      "e": 46086,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 256875,
      "e": 46086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 256876,
      "e": 46087,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256914,
      "e": 46125,
      "ty": 2,
      "x": 951,
      "y": 735
    },
    {
      "t": 256969,
      "e": 46180,
      "ty": 4,
      "x": 28386,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256972,
      "e": 46183,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256974,
      "e": 46185,
      "ty": 5,
      "x": 951,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 256975,
      "e": 46186,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 257013,
      "e": 46224,
      "ty": 41,
      "x": 32474,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 257713,
      "e": 46924,
      "ty": 2,
      "x": 950,
      "y": 733
    },
    {
      "t": 257764,
      "e": 46975,
      "ty": 41,
      "x": 32646,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 257813,
      "e": 47024,
      "ty": 2,
      "x": 956,
      "y": 715
    },
    {
      "t": 258316,
      "e": 47527,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 258345,
      "e": 47556,
      "ty": 6,
      "x": 956,
      "y": 715,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 258913,
      "e": 48124,
      "ty": 2,
      "x": 942,
      "y": 715
    },
    {
      "t": 259014,
      "e": 48225,
      "ty": 2,
      "x": 934,
      "y": 714
    },
    {
      "t": 259014,
      "e": 48225,
      "ty": 41,
      "x": 30498,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 259112,
      "e": 48323,
      "ty": 7,
      "x": 923,
      "y": 692,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 259113,
      "e": 48324,
      "ty": 6,
      "x": 923,
      "y": 692,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 259114,
      "e": 48325,
      "ty": 2,
      "x": 923,
      "y": 692
    },
    {
      "t": 259129,
      "e": 48340,
      "ty": 7,
      "x": 903,
      "y": 656,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 259196,
      "e": 48407,
      "ty": 6,
      "x": 789,
      "y": 530,
      "ta": "#da1"
    },
    {
      "t": 259211,
      "e": 48422,
      "ty": 7,
      "x": 755,
      "y": 499,
      "ta": "#da1"
    },
    {
      "t": 259213,
      "e": 48424,
      "ty": 2,
      "x": 755,
      "y": 499
    },
    {
      "t": 259263,
      "e": 48474,
      "ty": 41,
      "x": 16950,
      "y": 45658,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 259313,
      "e": 48524,
      "ty": 2,
      "x": 584,
      "y": 436
    },
    {
      "t": 259414,
      "e": 48625,
      "ty": 2,
      "x": 577,
      "y": 436
    },
    {
      "t": 259514,
      "e": 48725,
      "ty": 41,
      "x": 13949,
      "y": 35126,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 259913,
      "e": 49124,
      "ty": 2,
      "x": 576,
      "y": 433
    },
    {
      "t": 260013,
      "e": 49224,
      "ty": 2,
      "x": 577,
      "y": 421
    },
    {
      "t": 260013,
      "e": 49224,
      "ty": 41,
      "x": 13949,
      "y": 17572,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 260013,
      "e": 49224,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 260112,
      "e": 49323,
      "ty": 2,
      "x": 579,
      "y": 418
    },
    {
      "t": 260213,
      "e": 49424,
      "ty": 2,
      "x": 579,
      "y": 417
    },
    {
      "t": 260263,
      "e": 49474,
      "ty": 41,
      "x": 14048,
      "y": 12891,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 260763,
      "e": 49974,
      "ty": 41,
      "x": 14048,
      "y": 14061,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 260813,
      "e": 50024,
      "ty": 2,
      "x": 577,
      "y": 420
    },
    {
      "t": 260912,
      "e": 50123,
      "ty": 2,
      "x": 575,
      "y": 425
    },
    {
      "t": 261012,
      "e": 50223,
      "ty": 2,
      "x": 574,
      "y": 428
    },
    {
      "t": 261013,
      "e": 50224,
      "ty": 41,
      "x": 13802,
      "y": 25764,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 264913,
      "e": 54124,
      "ty": 2,
      "x": 469,
      "y": 425
    },
    {
      "t": 265012,
      "e": 54223,
      "ty": 2,
      "x": 449,
      "y": 428
    },
    {
      "t": 265013,
      "e": 54224,
      "ty": 41,
      "x": 7652,
      "y": 25764,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 265113,
      "e": 54324,
      "ty": 2,
      "x": 445,
      "y": 431
    },
    {
      "t": 265263,
      "e": 54474,
      "ty": 41,
      "x": 7455,
      "y": 29274,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 265612,
      "e": 54823,
      "ty": 2,
      "x": 444,
      "y": 438
    },
    {
      "t": 265631,
      "e": 54842,
      "ty": 6,
      "x": 479,
      "y": 515,
      "ta": "#da1"
    },
    {
      "t": 265648,
      "e": 54859,
      "ty": 7,
      "x": 597,
      "y": 629,
      "ta": "#da1"
    },
    {
      "t": 265713,
      "e": 54924,
      "ty": 2,
      "x": 1299,
      "y": 1027
    },
    {
      "t": 265763,
      "e": 54974,
      "ty": 41,
      "x": 54239,
      "y": 61657,
      "ta": "> div.masterdiv"
    },
    {
      "t": 265812,
      "e": 55023,
      "ty": 2,
      "x": 1583,
      "y": 1123
    },
    {
      "t": 266013,
      "e": 55224,
      "ty": 41,
      "x": 54239,
      "y": 61767,
      "ta": "> div.masterdiv"
    },
    {
      "t": 266212,
      "e": 55423,
      "ty": 2,
      "x": 1511,
      "y": 1059
    },
    {
      "t": 266263,
      "e": 55474,
      "ty": 41,
      "x": 51978,
      "y": 55377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 266313,
      "e": 55524,
      "ty": 2,
      "x": 1206,
      "y": 825
    },
    {
      "t": 266398,
      "e": 55609,
      "ty": 6,
      "x": 958,
      "y": 770,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 266413,
      "e": 55624,
      "ty": 2,
      "x": 958,
      "y": 770
    },
    {
      "t": 266415,
      "e": 55626,
      "ty": 7,
      "x": 861,
      "y": 744,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 266416,
      "e": 55627,
      "ty": 6,
      "x": 861,
      "y": 744,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 266432,
      "e": 55643,
      "ty": 7,
      "x": 769,
      "y": 715,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 266432,
      "e": 55643,
      "ty": 6,
      "x": 769,
      "y": 715,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 266448,
      "e": 55659,
      "ty": 7,
      "x": 662,
      "y": 674,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 266449,
      "e": 55660,
      "ty": 6,
      "x": 662,
      "y": 674,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 266465,
      "e": 55676,
      "ty": 7,
      "x": 532,
      "y": 622,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 266513,
      "e": 55724,
      "ty": 2,
      "x": 422,
      "y": 542
    },
    {
      "t": 266513,
      "e": 55724,
      "ty": 41,
      "x": 6324,
      "y": 32001,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 266613,
      "e": 55824,
      "ty": 2,
      "x": 386,
      "y": 415
    },
    {
      "t": 266713,
      "e": 55924,
      "ty": 2,
      "x": 437,
      "y": 384
    },
    {
      "t": 266763,
      "e": 55974,
      "ty": 41,
      "x": 8833,
      "y": 18122,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 266813,
      "e": 56024,
      "ty": 2,
      "x": 501,
      "y": 413
    },
    {
      "t": 266912,
      "e": 56123,
      "ty": 2,
      "x": 512,
      "y": 423
    },
    {
      "t": 267013,
      "e": 56224,
      "ty": 2,
      "x": 515,
      "y": 423
    },
    {
      "t": 267013,
      "e": 56224,
      "ty": 41,
      "x": 10899,
      "y": 19912,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 267106,
      "e": 56317,
      "ty": 3,
      "x": 515,
      "y": 423,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 267213,
      "e": 56424,
      "ty": 2,
      "x": 516,
      "y": 423
    },
    {
      "t": 267263,
      "e": 56474,
      "ty": 41,
      "x": 11096,
      "y": 28104,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 267312,
      "e": 56523,
      "ty": 2,
      "x": 523,
      "y": 435
    },
    {
      "t": 267413,
      "e": 56624,
      "ty": 2,
      "x": 524,
      "y": 438
    },
    {
      "t": 267513,
      "e": 56724,
      "ty": 2,
      "x": 524,
      "y": 440
    },
    {
      "t": 267513,
      "e": 56724,
      "ty": 41,
      "x": 11342,
      "y": 39807,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 267904,
      "e": 57115,
      "ty": 4,
      "x": 11342,
      "y": 39807,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 267905,
      "e": 57116,
      "ty": 5,
      "x": 524,
      "y": 440,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 270013,
      "e": 59224,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 272113,
      "e": 61324,
      "ty": 2,
      "x": 747,
      "y": 493
    },
    {
      "t": 272213,
      "e": 61424,
      "ty": 2,
      "x": 808,
      "y": 496
    },
    {
      "t": 272264,
      "e": 61475,
      "ty": 41,
      "x": 51746,
      "y": 37485,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 272441,
      "e": 61652,
      "ty": 3,
      "x": 808,
      "y": 496,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 272536,
      "e": 61747,
      "ty": 4,
      "x": 51746,
      "y": 37485,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 272536,
      "e": 61747,
      "ty": 5,
      "x": 808,
      "y": 496,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 272713,
      "e": 61924,
      "ty": 2,
      "x": 810,
      "y": 493
    },
    {
      "t": 272764,
      "e": 61975,
      "ty": 41,
      "x": 25855,
      "y": 11157,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 272813,
      "e": 62024,
      "ty": 2,
      "x": 827,
      "y": 470
    },
    {
      "t": 272913,
      "e": 62124,
      "ty": 2,
      "x": 841,
      "y": 454
    },
    {
      "t": 273013,
      "e": 62224,
      "ty": 2,
      "x": 842,
      "y": 450
    },
    {
      "t": 273014,
      "e": 62225,
      "ty": 41,
      "x": 26986,
      "y": 51510,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 273113,
      "e": 62324,
      "ty": 2,
      "x": 846,
      "y": 436
    },
    {
      "t": 273161,
      "e": 62372,
      "ty": 3,
      "x": 846,
      "y": 436,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 273263,
      "e": 62474,
      "ty": 41,
      "x": 27183,
      "y": 35126,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 273413,
      "e": 62624,
      "ty": 2,
      "x": 846,
      "y": 454
    },
    {
      "t": 273513,
      "e": 62724,
      "ty": 2,
      "x": 841,
      "y": 469
    },
    {
      "t": 273513,
      "e": 62724,
      "ty": 41,
      "x": 26937,
      "y": 9762,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 273613,
      "e": 62824,
      "ty": 2,
      "x": 839,
      "y": 476
    },
    {
      "t": 273713,
      "e": 62924,
      "ty": 2,
      "x": 839,
      "y": 477
    },
    {
      "t": 273763,
      "e": 62974,
      "ty": 41,
      "x": 26839,
      "y": 11002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 274225,
      "e": 63436,
      "ty": 4,
      "x": 26839,
      "y": 11002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 274225,
      "e": 63436,
      "ty": 5,
      "x": 839,
      "y": 477,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 274343,
      "e": 63554,
      "ty": 3,
      "x": 839,
      "y": 477,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 274448,
      "e": 63659,
      "ty": 4,
      "x": 26839,
      "y": 11002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 274448,
      "e": 63659,
      "ty": 5,
      "x": 839,
      "y": 477,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 275213,
      "e": 64424,
      "ty": 2,
      "x": 796,
      "y": 498
    },
    {
      "t": 275241,
      "e": 64452,
      "ty": 6,
      "x": 723,
      "y": 514,
      "ta": "#da1"
    },
    {
      "t": 275263,
      "e": 64474,
      "ty": 41,
      "x": 38484,
      "y": 29541,
      "ta": "#da1"
    },
    {
      "t": 275308,
      "e": 64519,
      "ty": 7,
      "x": 641,
      "y": 538,
      "ta": "#da1"
    },
    {
      "t": 275313,
      "e": 64524,
      "ty": 2,
      "x": 641,
      "y": 538
    },
    {
      "t": 275413,
      "e": 64624,
      "ty": 2,
      "x": 580,
      "y": 570
    },
    {
      "t": 275513,
      "e": 64724,
      "ty": 2,
      "x": 571,
      "y": 578
    },
    {
      "t": 275514,
      "e": 64725,
      "ty": 41,
      "x": 25902,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 275614,
      "e": 64825,
      "ty": 2,
      "x": 566,
      "y": 596
    },
    {
      "t": 275713,
      "e": 64924,
      "ty": 2,
      "x": 566,
      "y": 599
    },
    {
      "t": 275764,
      "e": 64975,
      "ty": 41,
      "x": 28469,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 275912,
      "e": 65123,
      "ty": 2,
      "x": 566,
      "y": 601
    },
    {
      "t": 276013,
      "e": 65224,
      "ty": 2,
      "x": 568,
      "y": 656
    },
    {
      "t": 276013,
      "e": 65224,
      "ty": 41,
      "x": 13506,
      "y": 38734,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 276060,
      "e": 65271,
      "ty": 6,
      "x": 570,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 276092,
      "e": 65303,
      "ty": 7,
      "x": 574,
      "y": 702,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 276093,
      "e": 65304,
      "ty": 6,
      "x": 574,
      "y": 702,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 276113,
      "e": 65324,
      "ty": 2,
      "x": 575,
      "y": 706
    },
    {
      "t": 276213,
      "e": 65424,
      "ty": 2,
      "x": 576,
      "y": 708
    },
    {
      "t": 276263,
      "e": 65474,
      "ty": 41,
      "x": 12411,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 276313,
      "e": 65524,
      "ty": 2,
      "x": 592,
      "y": 714
    },
    {
      "t": 276414,
      "e": 65625,
      "ty": 2,
      "x": 601,
      "y": 716
    },
    {
      "t": 276513,
      "e": 65724,
      "ty": 2,
      "x": 604,
      "y": 716
    },
    {
      "t": 276514,
      "e": 65725,
      "ty": 41,
      "x": 13779,
      "y": 39825,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 278764,
      "e": 67975,
      "ty": 41,
      "x": 13779,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 278778,
      "e": 67989,
      "ty": 7,
      "x": 650,
      "y": 796,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 278813,
      "e": 68024,
      "ty": 2,
      "x": 833,
      "y": 942
    },
    {
      "t": 278914,
      "e": 68125,
      "ty": 2,
      "x": 1009,
      "y": 985
    },
    {
      "t": 279014,
      "e": 68225,
      "ty": 41,
      "x": 35202,
      "y": 59462,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 279496,
      "e": 68707,
      "ty": 6,
      "x": 993,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 279513,
      "e": 68724,
      "ty": 2,
      "x": 989,
      "y": 1087
    },
    {
      "t": 279513,
      "e": 68724,
      "ty": 41,
      "x": 43416,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 279544,
      "e": 68755,
      "ty": 7,
      "x": 983,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 279613,
      "e": 68824,
      "ty": 2,
      "x": 981,
      "y": 1115
    },
    {
      "t": 279713,
      "e": 68924,
      "ty": 2,
      "x": 978,
      "y": 1126
    },
    {
      "t": 279764,
      "e": 68975,
      "ty": 41,
      "x": 41427,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 279813,
      "e": 69024,
      "ty": 2,
      "x": 991,
      "y": 1113
    },
    {
      "t": 279828,
      "e": 69039,
      "ty": 6,
      "x": 994,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 279913,
      "e": 69124,
      "ty": 2,
      "x": 996,
      "y": 1102
    },
    {
      "t": 280013,
      "e": 69224,
      "ty": 2,
      "x": 1000,
      "y": 1096
    },
    {
      "t": 280014,
      "e": 69225,
      "ty": 41,
      "x": 49424,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 280014,
      "e": 69225,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 280072,
      "e": 69283,
      "ty": 3,
      "x": 1000,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 280072,
      "e": 69283,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 280113,
      "e": 69324,
      "ty": 2,
      "x": 1000,
      "y": 1095
    },
    {
      "t": 280199,
      "e": 69410,
      "ty": 4,
      "x": 49424,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 280201,
      "e": 69412,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 280201,
      "e": 69412,
      "ty": 5,
      "x": 1000,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 280202,
      "e": 69413,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 280263,
      "e": 69474,
      "ty": 41,
      "x": 34162,
      "y": 60216,
      "ta": "html > body"
    },
    {
      "t": 280713,
      "e": 69924,
      "ty": 2,
      "x": 993,
      "y": 1095
    },
    {
      "t": 280763,
      "e": 69974,
      "ty": 41,
      "x": 31648,
      "y": 52793,
      "ta": "html > body"
    },
    {
      "t": 280813,
      "e": 70024,
      "ty": 2,
      "x": 730,
      "y": 629
    },
    {
      "t": 280913,
      "e": 70124,
      "ty": 2,
      "x": 720,
      "y": 610
    },
    {
      "t": 281013,
      "e": 70224,
      "ty": 41,
      "x": 24519,
      "y": 33349,
      "ta": "html > body"
    },
    {
      "t": 281205,
      "e": 70416,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 282212,
      "e": 71423,
      "ty": 2,
      "x": 717,
      "y": 538
    },
    {
      "t": 282262,
      "e": 71473,
      "ty": 41,
      "x": 20995,
      "y": 27060,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 282313,
      "e": 71524,
      "ty": 2,
      "x": 719,
      "y": 482
    },
    {
      "t": 282513,
      "e": 71724,
      "ty": 41,
      "x": 21092,
      "y": 26128,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 287413,
      "e": 76624,
      "ty": 2,
      "x": 722,
      "y": 495
    },
    {
      "t": 287513,
      "e": 76724,
      "ty": 2,
      "x": 876,
      "y": 780
    },
    {
      "t": 287513,
      "e": 76724,
      "ty": 41,
      "x": 28714,
      "y": 49267,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 287613,
      "e": 76824,
      "ty": 2,
      "x": 879,
      "y": 785
    },
    {
      "t": 287763,
      "e": 76974,
      "ty": 41,
      "x": 28956,
      "y": 50121,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 287813,
      "e": 77024,
      "ty": 2,
      "x": 1025,
      "y": 898
    },
    {
      "t": 287913,
      "e": 77124,
      "ty": 2,
      "x": 1135,
      "y": 936
    },
    {
      "t": 288013,
      "e": 77224,
      "ty": 41,
      "x": 41287,
      "y": 61380,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 289112,
      "e": 78323,
      "ty": 2,
      "x": 1131,
      "y": 909
    },
    {
      "t": 289213,
      "e": 78424,
      "ty": 2,
      "x": 1121,
      "y": 874
    },
    {
      "t": 289263,
      "e": 78474,
      "ty": 41,
      "x": 40607,
      "y": 56488,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 289313,
      "e": 78524,
      "ty": 2,
      "x": 1121,
      "y": 873
    },
    {
      "t": 290013,
      "e": 79224,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 290326,
      "e": 79537,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 291334,
      "e": 80545,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 159, dom: 708, initialDom: 712",
  "javascriptErrors": []
}