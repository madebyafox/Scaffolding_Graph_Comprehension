var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9a0f8668aebfc4995142a8273f6c6ab6",
  "created": "2018-05-29T16:06:38.4090474-07:00",
  "lastActivity": "2018-05-29T16:07:17.8160474-07:00",
  "pageViews": [
    {
      "id": "0529381619a68fd2625fd9d50881c53ee8ccb6e4",
      "startTime": "2018-05-29T16:06:38.4090474-07:00",
      "endTime": "2018-05-29T16:07:17.8160474-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 39407,
      "engagementTime": 25825,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 39407,
  "engagementTime": 25825,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CSU5Z",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "93fd60e00c80afd9f3edb9c329eb400a",
  "gdpr": false
}