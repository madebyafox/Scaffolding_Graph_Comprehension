var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "997f11daf5b516bb93f566586526ac8c",
  "created": "2018-05-22T16:07:03.6841718-07:00",
  "lastActivity": "2018-05-22T16:07:18.7191718-07:00",
  "pageViews": [
    {
      "id": "05220460b1e152f412d65b11a643ce95a4815e3e",
      "startTime": "2018-05-22T16:07:03.6841718-07:00",
      "endTime": "2018-05-22T16:07:18.7191718-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 15035,
      "engagementTime": 12385,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15035,
  "engagementTime": 12385,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZY4DY",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3b1ae37bfb98cf2f9aaa0261d93ea434",
  "gdpr": false
}