var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05212922e92290a06ef2b4a6cc712be64c1a4cc5"] = {
  "startTime": "2018-05-21T19:18:29.3379356Z",
  "websitePageUrl": "/16",
  "visitTime": 55732,
  "engagementTime": 51317,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "0f97960ce2291fb4fe57ab777fda0aff",
    "created": "2018-05-21T19:18:29.3379356+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=EGP0T",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c8fb276be03db514ffba91e60eb924c3",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0f97960ce2291fb4fe57ab777fda0aff/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 277,
      "e": 277,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 277,
      "e": 277,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 643,
      "y": 654
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 599,
      "y": 605
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 56419,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 1005,
      "e": 1005,
      "ty": 6,
      "x": 595,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 552,
      "y": 546
    },
    {
      "t": 1194,
      "e": 1194,
      "ty": 3,
      "x": 546,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1196,
      "e": 1196,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 546,
      "y": 536
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 50461,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1281,
      "e": 1281,
      "ty": 4,
      "x": 50461,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1281,
      "e": 1281,
      "ty": 5,
      "x": 546,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7031,
      "e": 6281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7529,
      "e": 6779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7562,
      "e": 6812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7595,
      "e": 6845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7628,
      "e": 6878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7661,
      "e": 6911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7694,
      "e": 6944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7727,
      "e": 6977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7760,
      "e": 7010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7766,
      "e": 7016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7766,
      "e": 7016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7845,
      "e": 7095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 7869,
      "e": 7119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 7966,
      "e": 7216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7966,
      "e": 7216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8020,
      "e": 7270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lO"
    },
    {
      "t": 8101,
      "e": 7351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8101,
      "e": 7351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8157,
      "e": 7407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOO"
    },
    {
      "t": 8254,
      "e": 7504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8254,
      "e": 7504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8309,
      "e": 7559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK"
    },
    {
      "t": 8309,
      "e": 7559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8309,
      "e": 7559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8469,
      "e": 7719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8533,
      "e": 7783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8533,
      "e": 7783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8597,
      "e": 7847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 8701,
      "e": 7951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8756,
      "e": 8006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK "
    },
    {
      "t": 8893,
      "e": 8143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8894,
      "e": 8144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8972,
      "e": 8222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 9262,
      "e": 8512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9317,
      "e": 8567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK "
    },
    {
      "t": 9429,
      "e": 8679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9429,
      "e": 8679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9542,
      "e": 8792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9542,
      "e": 8792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9629,
      "e": 8879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AT"
    },
    {
      "t": 9661,
      "e": 8911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9685,
      "e": 8935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9686,
      "e": 8936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9757,
      "e": 9007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9918,
      "e": 9168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9919,
      "e": 9169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9957,
      "e": 9207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9957,
      "e": 9207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9981,
      "e": 9231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 10000,
      "e": 9250,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10036,
      "e": 9286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10109,
      "e": 9359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10109,
      "e": 9359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10173,
      "e": 9423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10174,
      "e": 9424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10189,
      "e": 9439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E "
    },
    {
      "t": 10253,
      "e": 9503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10397,
      "e": 9647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 10398,
      "e": 9648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10453,
      "e": 9703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 10501,
      "e": 9751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 10501,
      "e": 9751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10573,
      "e": 9823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 10733,
      "e": 9983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10734,
      "e": 9984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10845,
      "e": 10095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 11238,
      "e": 10488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11239,
      "e": 10489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11293,
      "e": 10543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 11325,
      "e": 10575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11325,
      "e": 10575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11405,
      "e": 10655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 11453,
      "e": 10703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11454,
      "e": 10704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11558,
      "e": 10808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 11581,
      "e": 10831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11582,
      "e": 10832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11661,
      "e": 10911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11685,
      "e": 10935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11685,
      "e": 10935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11756,
      "e": 11006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11757,
      "e": 11007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11789,
      "e": 11039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||FO"
    },
    {
      "t": 11853,
      "e": 11103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11918,
      "e": 11168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 11918,
      "e": 11168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12005,
      "e": 11255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12005,
      "e": 11255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12013,
      "e": 11263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R "
    },
    {
      "t": 12085,
      "e": 11335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12203,
      "e": 11453,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR "
    },
    {
      "t": 12829,
      "e": 12079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 12830,
      "e": 12080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12932,
      "e": 12182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 13038,
      "e": 12288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 13038,
      "e": 12288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13140,
      "e": 12390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13141,
      "e": 12391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13181,
      "e": 12431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2 "
    },
    {
      "t": 13221,
      "e": 12471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13253,
      "e": 12503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 13253,
      "e": 12503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13333,
      "e": 12583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 13437,
      "e": 12687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 13437,
      "e": 12687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13501,
      "e": 12751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 13525,
      "e": 12775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13525,
      "e": 12775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13637,
      "e": 12887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13653,
      "e": 12903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13653,
      "e": 12903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13757,
      "e": 13007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13758,
      "e": 13008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13781,
      "e": 13031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AN"
    },
    {
      "t": 13829,
      "e": 13079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13869,
      "e": 13119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 13869,
      "e": 13119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13965,
      "e": 13215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 13981,
      "e": 13231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13983,
      "e": 13233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14076,
      "e": 13326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14117,
      "e": 13367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14117,
      "e": 13367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14213,
      "e": 13463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 14222,
      "e": 13472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14222,
      "e": 13472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14285,
      "e": 13535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 14402,
      "e": 13652,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SE"
    },
    {
      "t": 14405,
      "e": 13655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14406,
      "e": 13656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14429,
      "e": 13679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 14602,
      "e": 13852,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE"
    },
    {
      "t": 14997,
      "e": 14247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14999,
      "e": 14249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15078,
      "e": 14328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15079,
      "e": 14329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15093,
      "e": 14343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| T"
    },
    {
      "t": 15133,
      "e": 14383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15173,
      "e": 14423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15173,
      "e": 14423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15212,
      "e": 14462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 15253,
      "e": 14503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15253,
      "e": 14503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15309,
      "e": 14559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 15381,
      "e": 14631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15381,
      "e": 14631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15436,
      "e": 14686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15444,
      "e": 14694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15444,
      "e": 14694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15533,
      "e": 14783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15533,
      "e": 14783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15549,
      "e": 14799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||DO"
    },
    {
      "t": 15589,
      "e": 14839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15637,
      "e": 14887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15638,
      "e": 14888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15693,
      "e": 14943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 15781,
      "e": 15031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15782,
      "e": 15032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15837,
      "e": 15087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15838,
      "e": 15088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15909,
      "e": 15159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S "
    },
    {
      "t": 15925,
      "e": 15175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15949,
      "e": 15199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15949,
      "e": 15199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16021,
      "e": 15271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16021,
      "e": 15271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16037,
      "e": 15287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 16101,
      "e": 15351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16134,
      "e": 15384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16135,
      "e": 15385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16197,
      "e": 15447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16197,
      "e": 15447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16261,
      "e": 15447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16262,
      "e": 15448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16268,
      "e": 15454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AT "
    },
    {
      "t": 16285,
      "e": 15471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16341,
      "e": 15527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16397,
      "e": 15583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16397,
      "e": 15583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16460,
      "e": 15646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 16469,
      "e": 15655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16469,
      "e": 15655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16565,
      "e": 15751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16565,
      "e": 15751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16573,
      "e": 15759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AT"
    },
    {
      "t": 16612,
      "e": 15798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16789,
      "e": 15975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 16790,
      "e": 15976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16837,
      "e": 16023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16837,
      "e": 16023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16853,
      "e": 16039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||CH"
    },
    {
      "t": 16909,
      "e": 16095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16957,
      "e": 16143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16957,
      "e": 16143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17021,
      "e": 16207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 17021,
      "e": 16207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17076,
      "e": 16262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| U"
    },
    {
      "t": 17085,
      "e": 16271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17198,
      "e": 16384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17199,
      "e": 16385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17237,
      "e": 16423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17237,
      "e": 16423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17269,
      "e": 16455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P "
    },
    {
      "t": 17317,
      "e": 16503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 17317,
      "e": 16503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17357,
      "e": 16543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 17397,
      "e": 16583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17461,
      "e": 16647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17462,
      "e": 16648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17516,
      "e": 16702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 17853,
      "e": 17039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17916,
      "e": 17102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP W"
    },
    {
      "t": 18069,
      "e": 17255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18070,
      "e": 17256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18124,
      "e": 17310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18125,
      "e": 17311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18141,
      "e": 17327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||IT"
    },
    {
      "t": 18204,
      "e": 17390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18221,
      "e": 17407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18221,
      "e": 17407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18285,
      "e": 17471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 18301,
      "e": 17487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18302,
      "e": 17488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18405,
      "e": 17591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18429,
      "e": 17615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18429,
      "e": 17615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18500,
      "e": 17686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 18533,
      "e": 17719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18533,
      "e": 17719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18613,
      "e": 17799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 18781,
      "e": 17967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18784,
      "e": 17970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18845,
      "e": 18031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18884,
      "e": 18070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 18885,
      "e": 18071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18925,
      "e": 18111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 19253,
      "e": 18439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19332,
      "e": 18518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT "
    },
    {
      "t": 19405,
      "e": 18591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19445,
      "e": 18631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT"
    },
    {
      "t": 19603,
      "e": 18789,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT"
    },
    {
      "t": 19621,
      "e": 18807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 19621,
      "e": 18807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19693,
      "e": 18879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 19803,
      "e": 18989,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT."
    },
    {
      "t": 20251,
      "e": 19437,
      "ty": 41,
      "x": 50461,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20300,
      "e": 19486,
      "ty": 2,
      "x": 527,
      "y": 554
    },
    {
      "t": 20321,
      "e": 19507,
      "ty": 7,
      "x": 448,
      "y": 627,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20338,
      "e": 19524,
      "ty": 6,
      "x": 410,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 20400,
      "e": 19586,
      "ty": 2,
      "x": 351,
      "y": 686
    },
    {
      "t": 20421,
      "e": 19607,
      "ty": 7,
      "x": 351,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 20500,
      "e": 19686,
      "ty": 2,
      "x": 353,
      "y": 714
    },
    {
      "t": 20500,
      "e": 19686,
      "ty": 41,
      "x": 16105,
      "y": 60466,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 20570,
      "e": 19756,
      "ty": 6,
      "x": 379,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 20600,
      "e": 19786,
      "ty": 2,
      "x": 384,
      "y": 676
    },
    {
      "t": 20658,
      "e": 19844,
      "ty": 3,
      "x": 389,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 20660,
      "e": 19845,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT."
    },
    {
      "t": 20663,
      "e": 19848,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20664,
      "e": 19849,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 20700,
      "e": 19885,
      "ty": 2,
      "x": 389,
      "y": 667
    },
    {
      "t": 20750,
      "e": 19935,
      "ty": 41,
      "x": 27528,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 21074,
      "e": 20259,
      "ty": 4,
      "x": 27528,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 21087,
      "e": 20272,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 21090,
      "e": 20275,
      "ty": 5,
      "x": 389,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 21095,
      "e": 20280,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 21400,
      "e": 20585,
      "ty": 2,
      "x": 405,
      "y": 538
    },
    {
      "t": 21501,
      "e": 20686,
      "ty": 41,
      "x": 13671,
      "y": 29360,
      "ta": "html > body"
    },
    {
      "t": 22096,
      "e": 21281,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 22701,
      "e": 21886,
      "ty": 2,
      "x": 1168,
      "y": 611
    },
    {
      "t": 22750,
      "e": 21935,
      "ty": 41,
      "x": 50726,
      "y": 35786,
      "ta": "html > body"
    },
    {
      "t": 22800,
      "e": 21985,
      "ty": 2,
      "x": 1483,
      "y": 653
    },
    {
      "t": 22901,
      "e": 22086,
      "ty": 2,
      "x": 1410,
      "y": 628
    },
    {
      "t": 23000,
      "e": 22185,
      "ty": 2,
      "x": 980,
      "y": 590
    },
    {
      "t": 23000,
      "e": 22185,
      "ty": 41,
      "x": 37201,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 23101,
      "e": 22286,
      "ty": 2,
      "x": 913,
      "y": 576
    },
    {
      "t": 23130,
      "e": 22315,
      "ty": 6,
      "x": 913,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23200,
      "e": 22385,
      "ty": 2,
      "x": 915,
      "y": 560
    },
    {
      "t": 23217,
      "e": 22402,
      "ty": 3,
      "x": 915,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23217,
      "e": 22402,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23250,
      "e": 22435,
      "ty": 41,
      "x": 23142,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23300,
      "e": 22485,
      "ty": 2,
      "x": 915,
      "y": 559
    },
    {
      "t": 23320,
      "e": 22505,
      "ty": 4,
      "x": 23142,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23322,
      "e": 22507,
      "ty": 5,
      "x": 915,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 23400,
      "e": 22585,
      "ty": 2,
      "x": 919,
      "y": 558
    },
    {
      "t": 23501,
      "e": 22686,
      "ty": 2,
      "x": 930,
      "y": 558
    },
    {
      "t": 23501,
      "e": 22686,
      "ty": 41,
      "x": 26387,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24037,
      "e": 23222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 24039,
      "e": 23224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24092,
      "e": 23277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 24093,
      "e": 23278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24141,
      "e": 23326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 24164,
      "e": 23349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 24601,
      "e": 23786,
      "ty": 2,
      "x": 937,
      "y": 561
    },
    {
      "t": 24623,
      "e": 23808,
      "ty": 7,
      "x": 960,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24656,
      "e": 23841,
      "ty": 6,
      "x": 948,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 24701,
      "e": 23886,
      "ty": 2,
      "x": 943,
      "y": 691
    },
    {
      "t": 24750,
      "e": 23935,
      "ty": 41,
      "x": 20655,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 24801,
      "e": 23986,
      "ty": 2,
      "x": 936,
      "y": 700
    },
    {
      "t": 24874,
      "e": 24059,
      "ty": 7,
      "x": 922,
      "y": 670,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 24890,
      "e": 24075,
      "ty": 6,
      "x": 922,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24900,
      "e": 24085,
      "ty": 2,
      "x": 922,
      "y": 663
    },
    {
      "t": 25000,
      "e": 24185,
      "ty": 2,
      "x": 925,
      "y": 656
    },
    {
      "t": 25000,
      "e": 24185,
      "ty": 41,
      "x": 25305,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25106,
      "e": 24291,
      "ty": 3,
      "x": 925,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25107,
      "e": 24292,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 25108,
      "e": 24293,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 25108,
      "e": 24293,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25186,
      "e": 24371,
      "ty": 4,
      "x": 25305,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25186,
      "e": 24371,
      "ty": 5,
      "x": 925,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25293,
      "e": 24478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 25421,
      "e": 24606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 25422,
      "e": 24607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25477,
      "e": 24662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "t"
    },
    {
      "t": 25525,
      "e": 24710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "t"
    },
    {
      "t": 25645,
      "e": 24830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 25646,
      "e": 24831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25750,
      "e": 24935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "tA"
    },
    {
      "t": 25766,
      "e": 24951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 25766,
      "e": 24951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25838,
      "e": 25023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "tAI"
    },
    {
      "t": 25861,
      "e": 25046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "87"
    },
    {
      "t": 25862,
      "e": 25047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25909,
      "e": 25094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 25909,
      "e": 25094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 25956,
      "e": 25141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "tAIWA"
    },
    {
      "t": 25973,
      "e": 25158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 25973,
      "e": 25158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26004,
      "e": 25189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||N"
    },
    {
      "t": 26021,
      "e": 25206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 26501,
      "e": 25686,
      "ty": 2,
      "x": 944,
      "y": 664
    },
    {
      "t": 26501,
      "e": 25686,
      "ty": 41,
      "x": 29415,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26601,
      "e": 25786,
      "ty": 2,
      "x": 922,
      "y": 667
    },
    {
      "t": 26642,
      "e": 25827,
      "ty": 7,
      "x": 864,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26700,
      "e": 25885,
      "ty": 2,
      "x": 807,
      "y": 678
    },
    {
      "t": 26750,
      "e": 25935,
      "ty": 41,
      "x": 26826,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 26800,
      "e": 25985,
      "ty": 2,
      "x": 733,
      "y": 675
    },
    {
      "t": 26900,
      "e": 26085,
      "ty": 2,
      "x": 793,
      "y": 640
    },
    {
      "t": 27001,
      "e": 26186,
      "ty": 2,
      "x": 807,
      "y": 640
    },
    {
      "t": 27001,
      "e": 26186,
      "ty": 41,
      "x": 27515,
      "y": 35011,
      "ta": "html > body"
    },
    {
      "t": 27101,
      "e": 26286,
      "ty": 2,
      "x": 812,
      "y": 642
    },
    {
      "t": 27126,
      "e": 26311,
      "ty": 6,
      "x": 813,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27201,
      "e": 26386,
      "ty": 2,
      "x": 817,
      "y": 651
    },
    {
      "t": 27250,
      "e": 26435,
      "ty": 41,
      "x": 1946,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27290,
      "e": 26475,
      "ty": 3,
      "x": 817,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27410,
      "e": 26595,
      "ty": 4,
      "x": 1946,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27410,
      "e": 26595,
      "ty": 5,
      "x": 817,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27544,
      "e": 26729,
      "ty": 7,
      "x": 859,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27600,
      "e": 26785,
      "ty": 2,
      "x": 859,
      "y": 669
    },
    {
      "t": 27751,
      "e": 26936,
      "ty": 41,
      "x": 11030,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 28013,
      "e": 27198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 28085,
      "e": 27270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "AIWAN"
    },
    {
      "t": 28201,
      "e": 27386,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "AIWAN"
    },
    {
      "t": 28205,
      "e": 27390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 28206,
      "e": 27391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28316,
      "e": 27501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "TAIWAN"
    },
    {
      "t": 28751,
      "e": 27936,
      "ty": 41,
      "x": 29857,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 28761,
      "e": 27946,
      "ty": 6,
      "x": 895,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28800,
      "e": 27985,
      "ty": 2,
      "x": 924,
      "y": 700
    },
    {
      "t": 28900,
      "e": 28085,
      "ty": 2,
      "x": 933,
      "y": 700
    },
    {
      "t": 28961,
      "e": 28146,
      "ty": 3,
      "x": 939,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28962,
      "e": 28147,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "TAIWAN"
    },
    {
      "t": 28963,
      "e": 28148,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28963,
      "e": 28148,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29001,
      "e": 28186,
      "ty": 2,
      "x": 939,
      "y": 703
    },
    {
      "t": 29001,
      "e": 28186,
      "ty": 41,
      "x": 22202,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29034,
      "e": 28219,
      "ty": 4,
      "x": 22717,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29035,
      "e": 28220,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29036,
      "e": 28221,
      "ty": 5,
      "x": 940,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29036,
      "e": 28221,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 29101,
      "e": 28286,
      "ty": 2,
      "x": 940,
      "y": 703
    },
    {
      "t": 29251,
      "e": 28436,
      "ty": 41,
      "x": 32095,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 29300,
      "e": 28485,
      "ty": 2,
      "x": 941,
      "y": 739
    },
    {
      "t": 29401,
      "e": 28586,
      "ty": 2,
      "x": 930,
      "y": 767
    },
    {
      "t": 29501,
      "e": 28686,
      "ty": 41,
      "x": 31751,
      "y": 42046,
      "ta": "html > body"
    },
    {
      "t": 29901,
      "e": 29086,
      "ty": 2,
      "x": 929,
      "y": 768
    },
    {
      "t": 30001,
      "e": 29186,
      "ty": 41,
      "x": 31717,
      "y": 42101,
      "ta": "html > body"
    },
    {
      "t": 30001,
      "e": 29186,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30053,
      "e": 29238,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 30751,
      "e": 29936,
      "ty": 41,
      "x": 27000,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 30801,
      "e": 29986,
      "ty": 2,
      "x": 917,
      "y": 362
    },
    {
      "t": 30901,
      "e": 30086,
      "ty": 2,
      "x": 856,
      "y": 16
    },
    {
      "t": 31001,
      "e": 30186,
      "ty": 2,
      "x": 844,
      "y": 140
    },
    {
      "t": 31001,
      "e": 30186,
      "ty": 41,
      "x": 28789,
      "y": 7312,
      "ta": "html > body"
    },
    {
      "t": 31101,
      "e": 30286,
      "ty": 2,
      "x": 825,
      "y": 320
    },
    {
      "t": 31201,
      "e": 30386,
      "ty": 2,
      "x": 786,
      "y": 298
    },
    {
      "t": 31250,
      "e": 30435,
      "ty": 41,
      "x": 27412,
      "y": 15234,
      "ta": "html > body"
    },
    {
      "t": 31301,
      "e": 30486,
      "ty": 2,
      "x": 817,
      "y": 271
    },
    {
      "t": 31401,
      "e": 30586,
      "ty": 2,
      "x": 825,
      "y": 250
    },
    {
      "t": 31501,
      "e": 30686,
      "ty": 2,
      "x": 825,
      "y": 242
    },
    {
      "t": 31501,
      "e": 30686,
      "ty": 41,
      "x": 2930,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 31979,
      "e": 31164,
      "ty": 6,
      "x": 827,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 31996,
      "e": 31181,
      "ty": 7,
      "x": 835,
      "y": 251,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 32001,
      "e": 31186,
      "ty": 2,
      "x": 835,
      "y": 251
    },
    {
      "t": 32001,
      "e": 31186,
      "ty": 41,
      "x": 3222,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 32012,
      "e": 31197,
      "ty": 6,
      "x": 838,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 32029,
      "e": 31214,
      "ty": 7,
      "x": 839,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 32101,
      "e": 31286,
      "ty": 2,
      "x": 841,
      "y": 294
    },
    {
      "t": 32113,
      "e": 31298,
      "ty": 6,
      "x": 839,
      "y": 296,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32200,
      "e": 31385,
      "ty": 2,
      "x": 836,
      "y": 296
    },
    {
      "t": 32251,
      "e": 31436,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32301,
      "e": 31486,
      "ty": 2,
      "x": 832,
      "y": 296
    },
    {
      "t": 32362,
      "e": 31547,
      "ty": 3,
      "x": 831,
      "y": 296,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32363,
      "e": 31548,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32400,
      "e": 31585,
      "ty": 2,
      "x": 831,
      "y": 296
    },
    {
      "t": 32448,
      "e": 31633,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32449,
      "e": 31634,
      "ty": 5,
      "x": 831,
      "y": 296,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32449,
      "e": 31634,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 32500,
      "e": 31685,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32664,
      "e": 31849,
      "ty": 7,
      "x": 841,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32700,
      "e": 31885,
      "ty": 2,
      "x": 858,
      "y": 383
    },
    {
      "t": 32751,
      "e": 31936,
      "ty": 41,
      "x": 62449,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 32800,
      "e": 31985,
      "ty": 2,
      "x": 891,
      "y": 495
    },
    {
      "t": 32901,
      "e": 32086,
      "ty": 2,
      "x": 877,
      "y": 491
    },
    {
      "t": 32942,
      "e": 32127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "20"
    },
    {
      "t": 32947,
      "e": 32132,
      "ty": 6,
      "x": 839,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 32997,
      "e": 32182,
      "ty": 7,
      "x": 831,
      "y": 458,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 33000,
      "e": 32185,
      "ty": 2,
      "x": 831,
      "y": 458
    },
    {
      "t": 33000,
      "e": 32185,
      "ty": 41,
      "x": 2273,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 33069,
      "e": 32254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 33101,
      "e": 32286,
      "ty": 2,
      "x": 825,
      "y": 449
    },
    {
      "t": 33252,
      "e": 32287,
      "ty": 41,
      "x": 2858,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 33901,
      "e": 32936,
      "ty": 2,
      "x": 828,
      "y": 449
    },
    {
      "t": 34001,
      "e": 33036,
      "ty": 2,
      "x": 829,
      "y": 449
    },
    {
      "t": 34001,
      "e": 33036,
      "ty": 41,
      "x": 6053,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 34201,
      "e": 33236,
      "ty": 2,
      "x": 843,
      "y": 446
    },
    {
      "t": 34251,
      "e": 33286,
      "ty": 41,
      "x": 16275,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 34301,
      "e": 33336,
      "ty": 2,
      "x": 898,
      "y": 421
    },
    {
      "t": 34500,
      "e": 33535,
      "ty": 2,
      "x": 856,
      "y": 433
    },
    {
      "t": 34500,
      "e": 33535,
      "ty": 41,
      "x": 27619,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 34601,
      "e": 33636,
      "ty": 2,
      "x": 854,
      "y": 445
    },
    {
      "t": 34701,
      "e": 33736,
      "ty": 2,
      "x": 858,
      "y": 448
    },
    {
      "t": 34751,
      "e": 33786,
      "ty": 41,
      "x": 23625,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 34801,
      "e": 33836,
      "ty": 2,
      "x": 851,
      "y": 449
    },
    {
      "t": 35001,
      "e": 34036,
      "ty": 2,
      "x": 845,
      "y": 440
    },
    {
      "t": 35002,
      "e": 34037,
      "ty": 41,
      "x": 18833,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 35066,
      "e": 34101,
      "ty": 6,
      "x": 835,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35101,
      "e": 34136,
      "ty": 2,
      "x": 830,
      "y": 417
    },
    {
      "t": 35251,
      "e": 34286,
      "ty": 41,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35730,
      "e": 34765,
      "ty": 3,
      "x": 830,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35731,
      "e": 34766,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 35732,
      "e": 34767,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35817,
      "e": 34852,
      "ty": 4,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35817,
      "e": 34852,
      "ty": 5,
      "x": 830,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 35817,
      "e": 34852,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 36066,
      "e": 35101,
      "ty": 7,
      "x": 854,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 36101,
      "e": 35136,
      "ty": 2,
      "x": 890,
      "y": 614
    },
    {
      "t": 36200,
      "e": 35235,
      "ty": 2,
      "x": 914,
      "y": 763
    },
    {
      "t": 36251,
      "e": 35286,
      "ty": 41,
      "x": 38211,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 36301,
      "e": 35336,
      "ty": 2,
      "x": 908,
      "y": 765
    },
    {
      "t": 36401,
      "e": 35436,
      "ty": 2,
      "x": 902,
      "y": 764
    },
    {
      "t": 36501,
      "e": 35536,
      "ty": 2,
      "x": 895,
      "y": 752
    },
    {
      "t": 36501,
      "e": 35536,
      "ty": 41,
      "x": 30700,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 36600,
      "e": 35635,
      "ty": 2,
      "x": 856,
      "y": 682
    },
    {
      "t": 36701,
      "e": 35736,
      "ty": 2,
      "x": 824,
      "y": 634
    },
    {
      "t": 36751,
      "e": 35786,
      "ty": 41,
      "x": 2510,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 36801,
      "e": 35836,
      "ty": 2,
      "x": 829,
      "y": 646
    },
    {
      "t": 36900,
      "e": 35935,
      "ty": 6,
      "x": 832,
      "y": 670,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 36902,
      "e": 35937,
      "ty": 2,
      "x": 832,
      "y": 670
    },
    {
      "t": 37001,
      "e": 36036,
      "ty": 2,
      "x": 836,
      "y": 680
    },
    {
      "t": 37001,
      "e": 36036,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 37101,
      "e": 36136,
      "ty": 2,
      "x": 832,
      "y": 679
    },
    {
      "t": 37201,
      "e": 36236,
      "ty": 2,
      "x": 828,
      "y": 675
    },
    {
      "t": 37251,
      "e": 36286,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 37300,
      "e": 36335,
      "ty": 7,
      "x": 830,
      "y": 684,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 37303,
      "e": 36338,
      "ty": 2,
      "x": 830,
      "y": 684
    },
    {
      "t": 37333,
      "e": 36368,
      "ty": 6,
      "x": 836,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37350,
      "e": 36385,
      "ty": 7,
      "x": 836,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37401,
      "e": 36436,
      "ty": 2,
      "x": 836,
      "y": 711
    },
    {
      "t": 37501,
      "e": 36536,
      "ty": 41,
      "x": 3673,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 37601,
      "e": 36636,
      "ty": 2,
      "x": 835,
      "y": 709
    },
    {
      "t": 37627,
      "e": 36662,
      "ty": 3,
      "x": 835,
      "y": 709,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 37628,
      "e": 36663,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37704,
      "e": 36739,
      "ty": 6,
      "x": 834,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37736,
      "e": 36771,
      "ty": 4,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37751,
      "e": 36786,
      "ty": 41,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37801,
      "e": 36836,
      "ty": 2,
      "x": 834,
      "y": 708
    },
    {
      "t": 37884,
      "e": 36919,
      "ty": 7,
      "x": 820,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 37901,
      "e": 36936,
      "ty": 2,
      "x": 815,
      "y": 706
    },
    {
      "t": 38000,
      "e": 37035,
      "ty": 2,
      "x": 821,
      "y": 705
    },
    {
      "t": 38001,
      "e": 37036,
      "ty": 41,
      "x": 0,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 38041,
      "e": 37076,
      "ty": 3,
      "x": 821,
      "y": 705,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 38101,
      "e": 37136,
      "ty": 2,
      "x": 822,
      "y": 705
    },
    {
      "t": 38145,
      "e": 37180,
      "ty": 4,
      "x": 145,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 38146,
      "e": 37181,
      "ty": 5,
      "x": 822,
      "y": 705,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 38146,
      "e": 37181,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 38149,
      "e": 37182,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 38200,
      "e": 37233,
      "ty": 2,
      "x": 824,
      "y": 703
    },
    {
      "t": 38218,
      "e": 37251,
      "ty": 6,
      "x": 827,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 38251,
      "e": 37284,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 38301,
      "e": 37334,
      "ty": 2,
      "x": 827,
      "y": 703
    },
    {
      "t": 38501,
      "e": 37534,
      "ty": 2,
      "x": 828,
      "y": 702
    },
    {
      "t": 38501,
      "e": 37534,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 38602,
      "e": 37635,
      "ty": 7,
      "x": 837,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 38602,
      "e": 37635,
      "ty": 6,
      "x": 837,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38603,
      "e": 37636,
      "ty": 2,
      "x": 837,
      "y": 729
    },
    {
      "t": 38617,
      "e": 37650,
      "ty": 7,
      "x": 842,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38701,
      "e": 37734,
      "ty": 2,
      "x": 853,
      "y": 900
    },
    {
      "t": 38751,
      "e": 37784,
      "ty": 41,
      "x": 7256,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 38800,
      "e": 37833,
      "ty": 2,
      "x": 852,
      "y": 918
    },
    {
      "t": 39201,
      "e": 38234,
      "ty": 2,
      "x": 851,
      "y": 918
    },
    {
      "t": 39251,
      "e": 38284,
      "ty": 41,
      "x": 22476,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 39252,
      "e": 38285,
      "ty": 6,
      "x": 838,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 39300,
      "e": 38333,
      "ty": 2,
      "x": 836,
      "y": 932
    },
    {
      "t": 39386,
      "e": 38419,
      "ty": 7,
      "x": 834,
      "y": 944,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 39401,
      "e": 38434,
      "ty": 2,
      "x": 834,
      "y": 944
    },
    {
      "t": 39436,
      "e": 38469,
      "ty": 6,
      "x": 832,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 39485,
      "e": 38518,
      "ty": 7,
      "x": 830,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 39500,
      "e": 38533,
      "ty": 2,
      "x": 830,
      "y": 969
    },
    {
      "t": 39501,
      "e": 38534,
      "ty": 41,
      "x": 6939,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 39600,
      "e": 38633,
      "ty": 2,
      "x": 829,
      "y": 970
    },
    {
      "t": 39700,
      "e": 38733,
      "ty": 2,
      "x": 825,
      "y": 969
    },
    {
      "t": 39750,
      "e": 38783,
      "ty": 41,
      "x": 2894,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 39900,
      "e": 38933,
      "ty": 2,
      "x": 825,
      "y": 963
    },
    {
      "t": 39906,
      "e": 38939,
      "ty": 6,
      "x": 826,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40002,
      "e": 39035,
      "ty": 3,
      "x": 826,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40003,
      "e": 39036,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 40004,
      "e": 39037,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40006,
      "e": 39039,
      "ty": 2,
      "x": 826,
      "y": 960
    },
    {
      "t": 40006,
      "e": 39039,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40113,
      "e": 39146,
      "ty": 4,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40114,
      "e": 39147,
      "ty": 5,
      "x": 826,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40115,
      "e": 39148,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 40799,
      "e": 39832,
      "ty": 2,
      "x": 835,
      "y": 961
    },
    {
      "t": 40820,
      "e": 39853,
      "ty": 7,
      "x": 843,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 40887,
      "e": 39920,
      "ty": 6,
      "x": 855,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 40900,
      "e": 39933,
      "ty": 2,
      "x": 855,
      "y": 1012
    },
    {
      "t": 41000,
      "e": 40033,
      "ty": 2,
      "x": 860,
      "y": 1016
    },
    {
      "t": 41001,
      "e": 40034,
      "ty": 41,
      "x": 15759,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41201,
      "e": 40234,
      "ty": 2,
      "x": 861,
      "y": 1016
    },
    {
      "t": 41234,
      "e": 40267,
      "ty": 3,
      "x": 861,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41235,
      "e": 40268,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 41236,
      "e": 40269,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41250,
      "e": 40283,
      "ty": 41,
      "x": 16275,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41300,
      "e": 40333,
      "ty": 2,
      "x": 861,
      "y": 1015
    },
    {
      "t": 41337,
      "e": 40370,
      "ty": 4,
      "x": 16275,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41337,
      "e": 40370,
      "ty": 5,
      "x": 861,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41342,
      "e": 40375,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 41343,
      "e": 40376,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 41345,
      "e": 40378,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 41500,
      "e": 40533,
      "ty": 41,
      "x": 29375,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 41700,
      "e": 40733,
      "ty": 2,
      "x": 861,
      "y": 1012
    },
    {
      "t": 41750,
      "e": 40783,
      "ty": 41,
      "x": 29099,
      "y": 55397,
      "ta": "html > body"
    },
    {
      "t": 41800,
      "e": 40833,
      "ty": 2,
      "x": 853,
      "y": 1008
    },
    {
      "t": 42436,
      "e": 41469,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 43804,
      "e": 42837,
      "ty": 2,
      "x": 862,
      "y": 1009
    },
    {
      "t": 43904,
      "e": 42937,
      "ty": 2,
      "x": 894,
      "y": 1024
    },
    {
      "t": 44003,
      "e": 43036,
      "ty": 2,
      "x": 997,
      "y": 1068
    },
    {
      "t": 44005,
      "e": 43037,
      "ty": 41,
      "x": 34612,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 44009,
      "e": 43041,
      "ty": 6,
      "x": 1006,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 44104,
      "e": 43136,
      "ty": 2,
      "x": 1014,
      "y": 1077
    },
    {
      "t": 44204,
      "e": 43236,
      "ty": 2,
      "x": 1012,
      "y": 1083
    },
    {
      "t": 44254,
      "e": 43286,
      "ty": 41,
      "x": 54885,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 44304,
      "e": 43336,
      "ty": 2,
      "x": 1009,
      "y": 1087
    },
    {
      "t": 44504,
      "e": 43536,
      "ty": 41,
      "x": 54339,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 50004,
      "e": 48536,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52951,
      "e": 48536,
      "ty": 3,
      "x": 1009,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 52951,
      "e": 48536,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 53140,
      "e": 48725,
      "ty": 4,
      "x": 54339,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 53141,
      "e": 48726,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 53141,
      "e": 48726,
      "ty": 5,
      "x": 1009,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 53141,
      "e": 48726,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 54185,
      "e": 49770,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 55404,
      "e": 50989,
      "ty": 2,
      "x": 992,
      "y": 1060
    },
    {
      "t": 55505,
      "e": 51090,
      "ty": 2,
      "x": 922,
      "y": 954
    },
    {
      "t": 55505,
      "e": 51090,
      "ty": 41,
      "x": 30842,
      "y": 32838,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 55604,
      "e": 51189,
      "ty": 2,
      "x": 922,
      "y": 951
    },
    {
      "t": 55732,
      "e": 51317,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 117013, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 117019, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 3117, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 121475, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 20860, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 143341, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 6236, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 150661, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 10825, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 162489, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 20331, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 184167, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:917,y:906,t:1526929841428};\\\", \\\"{x:946,y:918,t:1526929841445};\\\", \\\"{x:992,y:929,t:1526929841461};\\\", \\\"{x:1036,y:931,t:1526929841478};\\\", \\\"{x:1067,y:934,t:1526929841495};\\\", \\\"{x:1079,y:940,t:1526929841511};\\\", \\\"{x:1081,y:940,t:1526929842157};\\\", \\\"{x:1086,y:940,t:1526929842165};\\\", \\\"{x:1095,y:942,t:1526929842179};\\\", \\\"{x:1106,y:945,t:1526929842195};\\\", \\\"{x:1134,y:949,t:1526929842212};\\\", \\\"{x:1150,y:950,t:1526929842229};\\\", \\\"{x:1175,y:952,t:1526929842245};\\\", \\\"{x:1203,y:957,t:1526929842262};\\\", \\\"{x:1232,y:961,t:1526929842279};\\\", \\\"{x:1257,y:962,t:1526929842295};\\\", \\\"{x:1279,y:963,t:1526929842312};\\\", \\\"{x:1298,y:964,t:1526929842329};\\\", \\\"{x:1314,y:964,t:1526929842345};\\\", \\\"{x:1323,y:964,t:1526929842362};\\\", \\\"{x:1327,y:964,t:1526929842379};\\\", \\\"{x:1329,y:964,t:1526929842395};\\\", \\\"{x:1330,y:964,t:1526929842412};\\\", \\\"{x:1334,y:965,t:1526929842429};\\\", \\\"{x:1341,y:967,t:1526929842445};\\\", \\\"{x:1345,y:968,t:1526929842462};\\\", \\\"{x:1348,y:969,t:1526929842479};\\\", \\\"{x:1349,y:971,t:1526929842574};\\\", \\\"{x:1348,y:974,t:1526929842581};\\\", \\\"{x:1340,y:979,t:1526929842596};\\\", \\\"{x:1334,y:985,t:1526929842613};\\\", \\\"{x:1328,y:989,t:1526929842629};\\\", \\\"{x:1321,y:993,t:1526929842646};\\\", \\\"{x:1315,y:996,t:1526929842663};\\\", \\\"{x:1312,y:996,t:1526929842679};\\\", \\\"{x:1311,y:996,t:1526929842697};\\\", \\\"{x:1310,y:996,t:1526929842884};\\\", \\\"{x:1310,y:995,t:1526929842896};\\\", \\\"{x:1310,y:992,t:1526929842912};\\\", \\\"{x:1307,y:989,t:1526929842929};\\\", \\\"{x:1307,y:987,t:1526929842947};\\\", \\\"{x:1303,y:983,t:1526929842962};\\\", \\\"{x:1301,y:981,t:1526929842979};\\\", \\\"{x:1298,y:975,t:1526929842996};\\\", \\\"{x:1296,y:973,t:1526929843012};\\\", \\\"{x:1295,y:971,t:1526929843029};\\\", \\\"{x:1295,y:970,t:1526929843069};\\\", \\\"{x:1294,y:969,t:1526929843157};\\\", \\\"{x:1294,y:968,t:1526929843165};\\\", \\\"{x:1294,y:967,t:1526929843180};\\\", \\\"{x:1293,y:966,t:1526929843940};\\\", \\\"{x:1291,y:965,t:1526929843947};\\\", \\\"{x:1290,y:965,t:1526929843996};\\\", \\\"{x:1289,y:964,t:1526929844003};\\\", \\\"{x:1288,y:964,t:1526929844044};\\\", \\\"{x:1287,y:963,t:1526929844116};\\\", \\\"{x:1287,y:962,t:1526929844469};\\\", \\\"{x:1286,y:962,t:1526929844481};\\\", \\\"{x:1285,y:962,t:1526929844498};\\\", \\\"{x:1284,y:962,t:1526929844515};\\\", \\\"{x:1282,y:962,t:1526929844530};\\\", \\\"{x:1280,y:962,t:1526929844548};\\\", \\\"{x:1280,y:963,t:1526929844782};\\\", \\\"{x:1279,y:964,t:1526929844797};\\\", \\\"{x:1279,y:965,t:1526929844980};\\\", \\\"{x:1278,y:964,t:1526929845189};\\\", \\\"{x:1276,y:962,t:1526929845245};\\\", \\\"{x:1275,y:961,t:1526929845269};\\\", \\\"{x:1276,y:961,t:1526929847061};\\\", \\\"{x:1278,y:961,t:1526929847069};\\\", \\\"{x:1279,y:961,t:1526929847092};\\\", \\\"{x:1280,y:962,t:1526929847107};\\\", \\\"{x:1281,y:962,t:1526929847164};\\\", \\\"{x:1282,y:962,t:1526929847179};\\\", \\\"{x:1283,y:963,t:1526929847438};\\\", \\\"{x:1283,y:964,t:1526929847450};\\\", \\\"{x:1283,y:969,t:1526929847467};\\\", \\\"{x:1283,y:971,t:1526929847483};\\\", \\\"{x:1283,y:972,t:1526929847500};\\\", \\\"{x:1282,y:972,t:1526929847750};\\\", \\\"{x:1277,y:968,t:1526929847767};\\\", \\\"{x:1274,y:962,t:1526929847783};\\\", \\\"{x:1271,y:955,t:1526929847800};\\\", \\\"{x:1267,y:947,t:1526929847817};\\\", \\\"{x:1262,y:940,t:1526929847834};\\\", \\\"{x:1258,y:934,t:1526929847850};\\\", \\\"{x:1258,y:933,t:1526929847926};\\\", \\\"{x:1258,y:932,t:1526929847933};\\\", \\\"{x:1258,y:928,t:1526929847950};\\\", \\\"{x:1266,y:919,t:1526929847967};\\\", \\\"{x:1275,y:909,t:1526929847983};\\\", \\\"{x:1281,y:899,t:1526929848000};\\\", \\\"{x:1287,y:889,t:1526929848017};\\\", \\\"{x:1290,y:877,t:1526929848034};\\\", \\\"{x:1290,y:870,t:1526929848050};\\\", \\\"{x:1290,y:860,t:1526929848067};\\\", \\\"{x:1284,y:849,t:1526929848084};\\\", \\\"{x:1274,y:839,t:1526929848100};\\\", \\\"{x:1241,y:819,t:1526929848116};\\\", \\\"{x:1214,y:809,t:1526929848134};\\\", \\\"{x:1172,y:798,t:1526929848150};\\\", \\\"{x:1121,y:789,t:1526929848167};\\\", \\\"{x:1069,y:767,t:1526929848184};\\\", \\\"{x:982,y:738,t:1526929848200};\\\", \\\"{x:858,y:704,t:1526929848217};\\\", \\\"{x:684,y:657,t:1526929848234};\\\", \\\"{x:461,y:608,t:1526929848251};\\\", \\\"{x:238,y:542,t:1526929848266};\\\", \\\"{x:0,y:453,t:1526929848283};\\\", \\\"{x:0,y:315,t:1526929848300};\\\", \\\"{x:0,y:228,t:1526929848318};\\\", \\\"{x:0,y:160,t:1526929848333};\\\", \\\"{x:0,y:126,t:1526929848350};\\\", \\\"{x:0,y:117,t:1526929848367};\\\", \\\"{x:0,y:116,t:1526929848383};\\\", \\\"{x:0,y:115,t:1526929848444};\\\", \\\"{x:5,y:116,t:1526929848485};\\\", \\\"{x:15,y:121,t:1526929848500};\\\", \\\"{x:23,y:123,t:1526929848517};\\\", \\\"{x:31,y:127,t:1526929848534};\\\", \\\"{x:38,y:131,t:1526929848550};\\\", \\\"{x:45,y:137,t:1526929848567};\\\", \\\"{x:51,y:149,t:1526929848584};\\\", \\\"{x:57,y:164,t:1526929848601};\\\", \\\"{x:63,y:186,t:1526929848617};\\\", \\\"{x:79,y:217,t:1526929848634};\\\", \\\"{x:102,y:246,t:1526929848650};\\\", \\\"{x:124,y:274,t:1526929848667};\\\", \\\"{x:152,y:299,t:1526929848684};\\\", \\\"{x:152,y:302,t:1526929848700};\\\", \\\"{x:156,y:312,t:1526929848813};\\\", \\\"{x:165,y:327,t:1526929848820};\\\", \\\"{x:173,y:350,t:1526929848835};\\\", \\\"{x:191,y:394,t:1526929848851};\\\", \\\"{x:201,y:428,t:1526929848868};\\\", \\\"{x:209,y:455,t:1526929848885};\\\", \\\"{x:212,y:460,t:1526929848901};\\\", \\\"{x:219,y:468,t:1526929848918};\\\", \\\"{x:235,y:484,t:1526929848935};\\\", \\\"{x:266,y:515,t:1526929848954};\\\", \\\"{x:314,y:548,t:1526929848968};\\\", \\\"{x:351,y:568,t:1526929848984};\\\", \\\"{x:382,y:581,t:1526929849001};\\\", \\\"{x:406,y:590,t:1526929849018};\\\", \\\"{x:426,y:600,t:1526929849034};\\\", \\\"{x:442,y:605,t:1526929849050};\\\", \\\"{x:451,y:607,t:1526929849067};\\\", \\\"{x:454,y:607,t:1526929849085};\\\", \\\"{x:454,y:604,t:1526929849101};\\\", \\\"{x:454,y:601,t:1526929849117};\\\", \\\"{x:450,y:595,t:1526929849134};\\\", \\\"{x:437,y:587,t:1526929849152};\\\", \\\"{x:418,y:576,t:1526929849168};\\\", \\\"{x:396,y:561,t:1526929849184};\\\", \\\"{x:373,y:545,t:1526929849204};\\\", \\\"{x:365,y:541,t:1526929849219};\\\", \\\"{x:358,y:534,t:1526929849235};\\\", \\\"{x:354,y:531,t:1526929849251};\\\", \\\"{x:352,y:529,t:1526929849267};\\\", \\\"{x:352,y:527,t:1526929849307};\\\", \\\"{x:352,y:526,t:1526929849317};\\\", \\\"{x:352,y:524,t:1526929849340};\\\", \\\"{x:352,y:521,t:1526929849363};\\\", \\\"{x:353,y:520,t:1526929849371};\\\", \\\"{x:353,y:519,t:1526929849384};\\\", \\\"{x:355,y:517,t:1526929849401};\\\", \\\"{x:356,y:516,t:1526929849420};\\\", \\\"{x:358,y:513,t:1526929849435};\\\", \\\"{x:359,y:513,t:1526929849451};\\\", \\\"{x:361,y:513,t:1526929849468};\\\", \\\"{x:362,y:513,t:1526929849500};\\\", \\\"{x:363,y:513,t:1526929849549};\\\", \\\"{x:364,y:513,t:1526929849557};\\\", \\\"{x:365,y:513,t:1526929849581};\\\", \\\"{x:367,y:513,t:1526929849677};\\\", \\\"{x:375,y:515,t:1526929854614};\\\", \\\"{x:448,y:572,t:1526929854634};\\\", \\\"{x:638,y:683,t:1526929854656};\\\", \\\"{x:766,y:754,t:1526929854672};\\\", \\\"{x:883,y:814,t:1526929854688};\\\", \\\"{x:977,y:856,t:1526929854705};\\\", \\\"{x:1014,y:879,t:1526929854722};\\\", \\\"{x:1016,y:881,t:1526929854738};\\\", \\\"{x:1016,y:884,t:1526929854755};\\\", \\\"{x:1014,y:883,t:1526929854820};\\\", \\\"{x:999,y:876,t:1526929854827};\\\", \\\"{x:975,y:863,t:1526929854839};\\\", \\\"{x:943,y:855,t:1526929854856};\\\", \\\"{x:922,y:854,t:1526929854873};\\\", \\\"{x:913,y:854,t:1526929854888};\\\", \\\"{x:910,y:856,t:1526929854906};\\\", \\\"{x:908,y:857,t:1526929854923};\\\", \\\"{x:905,y:859,t:1526929854938};\\\", \\\"{x:902,y:860,t:1526929854955};\\\", \\\"{x:896,y:861,t:1526929854972};\\\", \\\"{x:886,y:863,t:1526929854989};\\\", \\\"{x:875,y:863,t:1526929855005};\\\", \\\"{x:860,y:863,t:1526929855023};\\\", \\\"{x:838,y:860,t:1526929855039};\\\", \\\"{x:806,y:856,t:1526929855055};\\\", \\\"{x:756,y:840,t:1526929855072};\\\", \\\"{x:700,y:825,t:1526929855090};\\\", \\\"{x:663,y:818,t:1526929855106};\\\", \\\"{x:636,y:812,t:1526929855123};\\\", \\\"{x:618,y:808,t:1526929855140};\\\", \\\"{x:605,y:803,t:1526929855156};\\\", \\\"{x:595,y:800,t:1526929855172};\\\", \\\"{x:593,y:798,t:1526929855188};\\\", \\\"{x:592,y:798,t:1526929855206};\\\", \\\"{x:592,y:795,t:1526929855261};\\\", \\\"{x:592,y:791,t:1526929855273};\\\", \\\"{x:592,y:788,t:1526929855290};\\\", \\\"{x:592,y:786,t:1526929856341};\\\", \\\"{x:592,y:783,t:1526929856357};\\\", \\\"{x:592,y:779,t:1526929856374};\\\", \\\"{x:591,y:776,t:1526929856390};\\\", \\\"{x:589,y:771,t:1526929856407};\\\", \\\"{x:589,y:769,t:1526929856424};\\\", \\\"{x:589,y:767,t:1526929856441};\\\", \\\"{x:589,y:766,t:1526929856457};\\\", \\\"{x:588,y:766,t:1526929856572};\\\", \\\"{x:586,y:766,t:1526929856580};\\\", \\\"{x:583,y:765,t:1526929856591};\\\", \\\"{x:578,y:763,t:1526929856607};\\\", \\\"{x:568,y:763,t:1526929856624};\\\", \\\"{x:555,y:761,t:1526929856640};\\\", \\\"{x:542,y:758,t:1526929856657};\\\", \\\"{x:532,y:754,t:1526929856674};\\\", \\\"{x:525,y:751,t:1526929856691};\\\", \\\"{x:519,y:749,t:1526929856706};\\\", \\\"{x:517,y:747,t:1526929856724};\\\", \\\"{x:514,y:746,t:1526929856740};\\\", \\\"{x:514,y:745,t:1526929856796};\\\", \\\"{x:514,y:744,t:1526929856806};\\\", \\\"{x:514,y:743,t:1526929856824};\\\", \\\"{x:514,y:740,t:1526929856840};\\\", \\\"{x:514,y:739,t:1526929856858};\\\", \\\"{x:515,y:738,t:1526929856874};\\\", \\\"{x:516,y:736,t:1526929856891};\\\", \\\"{x:517,y:735,t:1526929856907};\\\", \\\"{x:520,y:732,t:1526929856923};\\\", \\\"{x:521,y:729,t:1526929856941};\\\", \\\"{x:523,y:728,t:1526929856957};\\\", \\\"{x:526,y:724,t:1526929856973};\\\", \\\"{x:528,y:723,t:1526929856990};\\\", \\\"{x:530,y:722,t:1526929857008};\\\", \\\"{x:531,y:721,t:1526929857024};\\\", \\\"{x:531,y:720,t:1526929857100};\\\", \\\"{x:533,y:720,t:1526929857173};\\\", \\\"{x:534,y:720,t:1526929857181};\\\", \\\"{x:536,y:721,t:1526929857191};\\\", \\\"{x:540,y:722,t:1526929857208};\\\", \\\"{x:543,y:725,t:1526929857224};\\\", \\\"{x:547,y:728,t:1526929857241};\\\", \\\"{x:547,y:729,t:1526929857258};\\\", \\\"{x:548,y:730,t:1526929857275};\\\", \\\"{x:548,y:731,t:1526929857509};\\\", \\\"{x:547,y:731,t:1526929857540};\\\", \\\"{x:545,y:731,t:1526929857558};\\\", \\\"{x:541,y:729,t:1526929857575};\\\", \\\"{x:540,y:721,t:1526929858237};\\\", \\\"{x:528,y:698,t:1526929858246};\\\", \\\"{x:508,y:675,t:1526929858259};\\\", \\\"{x:470,y:642,t:1526929858275};\\\", \\\"{x:412,y:597,t:1526929858291};\\\", \\\"{x:369,y:565,t:1526929858309};\\\", \\\"{x:320,y:533,t:1526929858325};\\\", \\\"{x:297,y:521,t:1526929858341};\\\", \\\"{x:290,y:516,t:1526929858358};\\\", \\\"{x:289,y:516,t:1526929858428};\\\", \\\"{x:289,y:514,t:1526929858442};\\\", \\\"{x:293,y:510,t:1526929858459};\\\", \\\"{x:300,y:506,t:1526929858474};\\\", \\\"{x:316,y:505,t:1526929858492};\\\", \\\"{x:328,y:505,t:1526929858508};\\\", \\\"{x:337,y:506,t:1526929858525};\\\", \\\"{x:343,y:508,t:1526929858540};\\\", \\\"{x:346,y:510,t:1526929858558};\\\", \\\"{x:350,y:512,t:1526929858574};\\\", \\\"{x:354,y:514,t:1526929858592};\\\", \\\"{x:355,y:514,t:1526929858609};\\\", \\\"{x:356,y:515,t:1526929858624};\\\", \\\"{x:357,y:516,t:1526929858733};\\\", \\\"{x:357,y:518,t:1526929858742};\\\", \\\"{x:361,y:519,t:1526929858759};\\\", \\\"{x:364,y:520,t:1526929858775};\\\", \\\"{x:364,y:521,t:1526929858792};\\\", \\\"{x:366,y:521,t:1526929858812};\\\", \\\"{x:367,y:522,t:1526929858908};\\\", \\\"{x:372,y:526,t:1526929859285};\\\", \\\"{x:376,y:529,t:1526929859294};\\\", \\\"{x:381,y:534,t:1526929859309};\\\", \\\"{x:382,y:535,t:1526929859326};\\\", \\\"{x:383,y:536,t:1526929859343};\\\", \\\"{x:384,y:536,t:1526929859444};\\\", \\\"{x:384,y:533,t:1526929859459};\\\", \\\"{x:384,y:529,t:1526929859476};\\\", \\\"{x:384,y:528,t:1526929859493};\\\", \\\"{x:384,y:527,t:1526929859508};\\\", \\\"{x:384,y:526,t:1526929859525};\\\", \\\"{x:384,y:524,t:1526929859556};\\\", \\\"{x:385,y:524,t:1526929859731};\\\", \\\"{x:395,y:534,t:1526929859742};\\\", \\\"{x:436,y:583,t:1526929859760};\\\", \\\"{x:503,y:673,t:1526929859776};\\\", \\\"{x:573,y:768,t:1526929859793};\\\", \\\"{x:640,y:857,t:1526929859810};\\\", \\\"{x:682,y:912,t:1526929859825};\\\", \\\"{x:718,y:935,t:1526929859843};\\\", \\\"{x:729,y:950,t:1526929859859};\\\", \\\"{x:739,y:954,t:1526929859875};\\\", \\\"{x:731,y:948,t:1526929859916};\\\", \\\"{x:714,y:939,t:1526929859927};\\\", \\\"{x:655,y:898,t:1526929859943};\\\", \\\"{x:584,y:857,t:1526929859960};\\\", \\\"{x:507,y:813,t:1526929859977};\\\", \\\"{x:440,y:778,t:1526929859993};\\\", \\\"{x:393,y:756,t:1526929860010};\\\", \\\"{x:371,y:740,t:1526929860027};\\\", \\\"{x:356,y:727,t:1526929860043};\\\", \\\"{x:351,y:717,t:1526929860059};\\\", \\\"{x:352,y:711,t:1526929860076};\\\", \\\"{x:355,y:698,t:1526929860092};\\\", \\\"{x:355,y:689,t:1526929860110};\\\", \\\"{x:356,y:686,t:1526929860127};\\\", \\\"{x:357,y:686,t:1526929860143};\\\", \\\"{x:359,y:685,t:1526929860159};\\\", \\\"{x:361,y:685,t:1526929860176};\\\", \\\"{x:367,y:683,t:1526929860193};\\\", \\\"{x:379,y:683,t:1526929860210};\\\", \\\"{x:392,y:683,t:1526929860227};\\\", \\\"{x:415,y:685,t:1526929860244};\\\", \\\"{x:427,y:689,t:1526929860260};\\\", \\\"{x:440,y:694,t:1526929860277};\\\", \\\"{x:450,y:696,t:1526929860294};\\\", \\\"{x:454,y:697,t:1526929860310};\\\", \\\"{x:456,y:698,t:1526929860348};\\\", \\\"{x:457,y:698,t:1526929860360};\\\", \\\"{x:463,y:700,t:1526929860377};\\\", \\\"{x:469,y:703,t:1526929860395};\\\", \\\"{x:470,y:703,t:1526929860443};\\\", \\\"{x:472,y:704,t:1526929860812};\\\", \\\"{x:475,y:706,t:1526929860827};\\\", \\\"{x:497,y:713,t:1526929860843};\\\", \\\"{x:513,y:717,t:1526929860860};\\\", \\\"{x:535,y:724,t:1526929860877};\\\", \\\"{x:559,y:730,t:1526929860894};\\\", \\\"{x:573,y:732,t:1526929860910};\\\", \\\"{x:581,y:733,t:1526929860927};\\\", \\\"{x:582,y:733,t:1526929860944};\\\" ] }, { \\\"rt\\\": 8592, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 194000, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:586,y:732,t:1526929865996};\\\", \\\"{x:639,y:686,t:1526929866015};\\\", \\\"{x:716,y:621,t:1526929866033};\\\", \\\"{x:776,y:571,t:1526929866048};\\\", \\\"{x:830,y:528,t:1526929866081};\\\", \\\"{x:831,y:525,t:1526929866094};\\\", \\\"{x:829,y:520,t:1526929866111};\\\", \\\"{x:813,y:515,t:1526929866129};\\\", \\\"{x:796,y:509,t:1526929866145};\\\", \\\"{x:784,y:505,t:1526929866164};\\\", \\\"{x:783,y:504,t:1526929866180};\\\", \\\"{x:780,y:504,t:1526929866197};\\\", \\\"{x:773,y:502,t:1526929866215};\\\", \\\"{x:753,y:502,t:1526929866231};\\\", \\\"{x:712,y:524,t:1526929866248};\\\", \\\"{x:660,y:554,t:1526929866266};\\\", \\\"{x:610,y:583,t:1526929866282};\\\", \\\"{x:585,y:595,t:1526929866297};\\\", \\\"{x:573,y:600,t:1526929866315};\\\", \\\"{x:578,y:600,t:1526929866339};\\\", \\\"{x:587,y:600,t:1526929866347};\\\", \\\"{x:615,y:598,t:1526929866365};\\\", \\\"{x:655,y:591,t:1526929866381};\\\", \\\"{x:700,y:578,t:1526929866399};\\\", \\\"{x:738,y:569,t:1526929866415};\\\", \\\"{x:759,y:566,t:1526929866430};\\\", \\\"{x:773,y:564,t:1526929866448};\\\", \\\"{x:778,y:563,t:1526929866463};\\\", \\\"{x:780,y:562,t:1526929866481};\\\", \\\"{x:774,y:562,t:1526929867948};\\\", \\\"{x:743,y:575,t:1526929867964};\\\", \\\"{x:659,y:588,t:1526929867980};\\\", \\\"{x:499,y:588,t:1526929867999};\\\", \\\"{x:396,y:588,t:1526929868018};\\\", \\\"{x:318,y:588,t:1526929868033};\\\", \\\"{x:286,y:585,t:1526929868049};\\\", \\\"{x:270,y:582,t:1526929868067};\\\", \\\"{x:264,y:582,t:1526929868082};\\\", \\\"{x:263,y:582,t:1526929868098};\\\", \\\"{x:260,y:582,t:1526929868172};\\\", \\\"{x:251,y:583,t:1526929868183};\\\", \\\"{x:236,y:584,t:1526929868199};\\\", \\\"{x:227,y:584,t:1526929868215};\\\", \\\"{x:226,y:584,t:1526929868233};\\\", \\\"{x:227,y:582,t:1526929868259};\\\", \\\"{x:231,y:581,t:1526929868268};\\\", \\\"{x:237,y:578,t:1526929868283};\\\", \\\"{x:251,y:575,t:1526929868299};\\\", \\\"{x:280,y:566,t:1526929868317};\\\", \\\"{x:302,y:562,t:1526929868333};\\\", \\\"{x:318,y:562,t:1526929868349};\\\", \\\"{x:327,y:561,t:1526929868366};\\\", \\\"{x:332,y:561,t:1526929868382};\\\", \\\"{x:334,y:561,t:1526929868400};\\\", \\\"{x:335,y:561,t:1526929868416};\\\", \\\"{x:334,y:561,t:1526929868451};\\\", \\\"{x:333,y:561,t:1526929868466};\\\", \\\"{x:330,y:561,t:1526929868483};\\\", \\\"{x:318,y:567,t:1526929868499};\\\", \\\"{x:293,y:579,t:1526929868517};\\\", \\\"{x:259,y:595,t:1526929868534};\\\", \\\"{x:219,y:608,t:1526929868549};\\\", \\\"{x:182,y:612,t:1526929868566};\\\", \\\"{x:153,y:611,t:1526929868583};\\\", \\\"{x:130,y:606,t:1526929868599};\\\", \\\"{x:117,y:602,t:1526929868616};\\\", \\\"{x:115,y:601,t:1526929868633};\\\", \\\"{x:115,y:600,t:1526929868660};\\\", \\\"{x:117,y:599,t:1526929868668};\\\", \\\"{x:118,y:598,t:1526929868683};\\\", \\\"{x:120,y:598,t:1526929868700};\\\", \\\"{x:122,y:597,t:1526929868717};\\\", \\\"{x:123,y:597,t:1526929868748};\\\", \\\"{x:123,y:598,t:1526929868756};\\\", \\\"{x:126,y:599,t:1526929868766};\\\", \\\"{x:130,y:605,t:1526929868784};\\\", \\\"{x:136,y:610,t:1526929868799};\\\", \\\"{x:140,y:614,t:1526929868818};\\\", \\\"{x:143,y:617,t:1526929868833};\\\", \\\"{x:145,y:623,t:1526929868851};\\\", \\\"{x:147,y:628,t:1526929868867};\\\", \\\"{x:147,y:629,t:1526929868883};\\\", \\\"{x:147,y:630,t:1526929868931};\\\", \\\"{x:149,y:632,t:1526929868939};\\\", \\\"{x:150,y:632,t:1526929868950};\\\", \\\"{x:153,y:633,t:1526929868967};\\\", \\\"{x:154,y:633,t:1526929868995};\\\", \\\"{x:155,y:634,t:1526929869004};\\\", \\\"{x:156,y:635,t:1526929869016};\\\", \\\"{x:157,y:635,t:1526929869076};\\\", \\\"{x:159,y:635,t:1526929869083};\\\", \\\"{x:161,y:635,t:1526929869100};\\\", \\\"{x:162,y:635,t:1526929869117};\\\", \\\"{x:162,y:635,t:1526929869187};\\\", \\\"{x:164,y:635,t:1526929869252};\\\", \\\"{x:171,y:637,t:1526929869525};\\\", \\\"{x:180,y:641,t:1526929869535};\\\", \\\"{x:214,y:659,t:1526929869552};\\\", \\\"{x:267,y:684,t:1526929869567};\\\", \\\"{x:332,y:698,t:1526929869584};\\\", \\\"{x:389,y:709,t:1526929869600};\\\", \\\"{x:431,y:713,t:1526929869617};\\\", \\\"{x:462,y:718,t:1526929869636};\\\", \\\"{x:484,y:723,t:1526929869650};\\\", \\\"{x:501,y:723,t:1526929869667};\\\", \\\"{x:515,y:725,t:1526929869683};\\\", \\\"{x:518,y:726,t:1526929869699};\\\", \\\"{x:520,y:726,t:1526929869717};\\\", \\\"{x:521,y:726,t:1526929869733};\\\", \\\"{x:526,y:726,t:1526929869750};\\\", \\\"{x:540,y:726,t:1526929869767};\\\", \\\"{x:557,y:726,t:1526929869784};\\\", \\\"{x:574,y:726,t:1526929869800};\\\", \\\"{x:582,y:726,t:1526929869817};\\\", \\\"{x:584,y:726,t:1526929869834};\\\", \\\"{x:584,y:725,t:1526929869884};\\\", \\\"{x:583,y:725,t:1526929869902};\\\", \\\"{x:582,y:725,t:1526929869917};\\\", \\\"{x:581,y:724,t:1526929869948};\\\", \\\"{x:579,y:724,t:1526929869964};\\\", \\\"{x:578,y:723,t:1526929869972};\\\", \\\"{x:577,y:722,t:1526929869984};\\\", \\\"{x:571,y:719,t:1526929870002};\\\", \\\"{x:566,y:718,t:1526929870017};\\\", \\\"{x:559,y:715,t:1526929870035};\\\", \\\"{x:550,y:712,t:1526929870051};\\\", \\\"{x:547,y:712,t:1526929870067};\\\", \\\"{x:546,y:711,t:1526929870084};\\\", \\\"{x:545,y:711,t:1526929870101};\\\", \\\"{x:548,y:711,t:1526929870788};\\\", \\\"{x:554,y:713,t:1526929870801};\\\", \\\"{x:559,y:714,t:1526929870818};\\\", \\\"{x:563,y:715,t:1526929870834};\\\", \\\"{x:566,y:715,t:1526929870852};\\\", \\\"{x:567,y:715,t:1526929870867};\\\" ] }, { \\\"rt\\\": 17955, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 213198, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -10 AM-C -11 AM-Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:569,y:716,t:1526929874407};\\\", \\\"{x:588,y:723,t:1526929874424};\\\", \\\"{x:638,y:740,t:1526929874440};\\\", \\\"{x:727,y:767,t:1526929874457};\\\", \\\"{x:830,y:797,t:1526929874474};\\\", \\\"{x:943,y:826,t:1526929874490};\\\", \\\"{x:1064,y:858,t:1526929874508};\\\", \\\"{x:1184,y:878,t:1526929874524};\\\", \\\"{x:1274,y:899,t:1526929874540};\\\", \\\"{x:1333,y:909,t:1526929874557};\\\", \\\"{x:1369,y:916,t:1526929874574};\\\", \\\"{x:1373,y:916,t:1526929874591};\\\", \\\"{x:1372,y:916,t:1526929874630};\\\", \\\"{x:1367,y:913,t:1526929874641};\\\", \\\"{x:1362,y:909,t:1526929874658};\\\", \\\"{x:1350,y:903,t:1526929874674};\\\", \\\"{x:1339,y:898,t:1526929874690};\\\", \\\"{x:1324,y:892,t:1526929874707};\\\", \\\"{x:1303,y:884,t:1526929874724};\\\", \\\"{x:1273,y:876,t:1526929874740};\\\", \\\"{x:1228,y:864,t:1526929874758};\\\", \\\"{x:1181,y:852,t:1526929874775};\\\", \\\"{x:1150,y:846,t:1526929874791};\\\", \\\"{x:1125,y:843,t:1526929874808};\\\", \\\"{x:1104,y:840,t:1526929874824};\\\", \\\"{x:1094,y:838,t:1526929874841};\\\", \\\"{x:1092,y:838,t:1526929874858};\\\", \\\"{x:1093,y:838,t:1526929874904};\\\", \\\"{x:1095,y:839,t:1526929874919};\\\", \\\"{x:1096,y:839,t:1526929874968};\\\", \\\"{x:1097,y:839,t:1526929874976};\\\", \\\"{x:1098,y:839,t:1526929874991};\\\", \\\"{x:1103,y:839,t:1526929875008};\\\", \\\"{x:1109,y:839,t:1526929875025};\\\", \\\"{x:1117,y:839,t:1526929875042};\\\", \\\"{x:1125,y:839,t:1526929875058};\\\", \\\"{x:1132,y:839,t:1526929875074};\\\", \\\"{x:1140,y:839,t:1526929875092};\\\", \\\"{x:1146,y:839,t:1526929875107};\\\", \\\"{x:1152,y:839,t:1526929875125};\\\", \\\"{x:1155,y:839,t:1526929875142};\\\", \\\"{x:1156,y:839,t:1526929875158};\\\", \\\"{x:1157,y:839,t:1526929875175};\\\", \\\"{x:1158,y:839,t:1526929875192};\\\", \\\"{x:1159,y:839,t:1526929875239};\\\", \\\"{x:1158,y:839,t:1526929875271};\\\", \\\"{x:1157,y:839,t:1526929875279};\\\", \\\"{x:1156,y:838,t:1526929875303};\\\", \\\"{x:1155,y:838,t:1526929875319};\\\", \\\"{x:1153,y:838,t:1526929875327};\\\", \\\"{x:1151,y:836,t:1526929875351};\\\", \\\"{x:1150,y:836,t:1526929875360};\\\", \\\"{x:1147,y:835,t:1526929875375};\\\", \\\"{x:1146,y:834,t:1526929875392};\\\", \\\"{x:1148,y:834,t:1526929875576};\\\", \\\"{x:1152,y:835,t:1526929875591};\\\", \\\"{x:1161,y:835,t:1526929875609};\\\", \\\"{x:1170,y:835,t:1526929875625};\\\", \\\"{x:1183,y:835,t:1526929875641};\\\", \\\"{x:1196,y:834,t:1526929875659};\\\", \\\"{x:1207,y:834,t:1526929875675};\\\", \\\"{x:1214,y:832,t:1526929875694};\\\", \\\"{x:1216,y:831,t:1526929875709};\\\", \\\"{x:1217,y:831,t:1526929876016};\\\", \\\"{x:1220,y:838,t:1526929876028};\\\", \\\"{x:1222,y:864,t:1526929876042};\\\", \\\"{x:1227,y:891,t:1526929876059};\\\", \\\"{x:1227,y:917,t:1526929876076};\\\", \\\"{x:1227,y:939,t:1526929876092};\\\", \\\"{x:1228,y:958,t:1526929876109};\\\", \\\"{x:1231,y:970,t:1526929876126};\\\", \\\"{x:1231,y:975,t:1526929876142};\\\", \\\"{x:1230,y:980,t:1526929876160};\\\", \\\"{x:1228,y:983,t:1526929876176};\\\", \\\"{x:1226,y:984,t:1526929876192};\\\", \\\"{x:1224,y:984,t:1526929876209};\\\", \\\"{x:1223,y:984,t:1526929876227};\\\", \\\"{x:1222,y:984,t:1526929876242};\\\", \\\"{x:1220,y:984,t:1526929876259};\\\", \\\"{x:1219,y:984,t:1526929876344};\\\", \\\"{x:1219,y:983,t:1526929876360};\\\", \\\"{x:1219,y:980,t:1526929876376};\\\", \\\"{x:1219,y:977,t:1526929876393};\\\", \\\"{x:1218,y:974,t:1526929876409};\\\", \\\"{x:1217,y:967,t:1526929876427};\\\", \\\"{x:1215,y:956,t:1526929876443};\\\", \\\"{x:1213,y:941,t:1526929876459};\\\", \\\"{x:1211,y:919,t:1526929876476};\\\", \\\"{x:1205,y:898,t:1526929876493};\\\", \\\"{x:1199,y:877,t:1526929876509};\\\", \\\"{x:1192,y:862,t:1526929876526};\\\", \\\"{x:1185,y:847,t:1526929876544};\\\", \\\"{x:1184,y:841,t:1526929876559};\\\", \\\"{x:1184,y:837,t:1526929876576};\\\", \\\"{x:1182,y:830,t:1526929876593};\\\", \\\"{x:1181,y:825,t:1526929876609};\\\", \\\"{x:1181,y:822,t:1526929876626};\\\", \\\"{x:1181,y:818,t:1526929876643};\\\", \\\"{x:1181,y:817,t:1526929876660};\\\", \\\"{x:1181,y:815,t:1526929876676};\\\", \\\"{x:1182,y:812,t:1526929876693};\\\", \\\"{x:1184,y:811,t:1526929876709};\\\", \\\"{x:1185,y:811,t:1526929876726};\\\", \\\"{x:1189,y:809,t:1526929876743};\\\", \\\"{x:1190,y:809,t:1526929876759};\\\", \\\"{x:1191,y:809,t:1526929876776};\\\", \\\"{x:1192,y:809,t:1526929876793};\\\", \\\"{x:1194,y:810,t:1526929877240};\\\", \\\"{x:1195,y:810,t:1526929877247};\\\", \\\"{x:1198,y:812,t:1526929877260};\\\", \\\"{x:1201,y:813,t:1526929877276};\\\", \\\"{x:1202,y:813,t:1526929877293};\\\", \\\"{x:1205,y:814,t:1526929877311};\\\", \\\"{x:1205,y:815,t:1526929877456};\\\", \\\"{x:1205,y:816,t:1526929877479};\\\", \\\"{x:1206,y:817,t:1526929877536};\\\", \\\"{x:1206,y:818,t:1526929877575};\\\", \\\"{x:1207,y:818,t:1526929877592};\\\", \\\"{x:1208,y:819,t:1526929877608};\\\", \\\"{x:1209,y:819,t:1526929877632};\\\", \\\"{x:1211,y:820,t:1526929877680};\\\", \\\"{x:1212,y:820,t:1526929877744};\\\", \\\"{x:1212,y:821,t:1526929877760};\\\", \\\"{x:1213,y:821,t:1526929877777};\\\", \\\"{x:1214,y:822,t:1526929877823};\\\", \\\"{x:1215,y:822,t:1526929877839};\\\", \\\"{x:1215,y:823,t:1526929877871};\\\", \\\"{x:1216,y:823,t:1526929877911};\\\", \\\"{x:1217,y:823,t:1526929877951};\\\", \\\"{x:1218,y:823,t:1526929877984};\\\", \\\"{x:1218,y:824,t:1526929878007};\\\", \\\"{x:1219,y:824,t:1526929878015};\\\", \\\"{x:1220,y:824,t:1526929878128};\\\", \\\"{x:1221,y:825,t:1526929878144};\\\", \\\"{x:1222,y:825,t:1526929878320};\\\", \\\"{x:1222,y:829,t:1526929878680};\\\", \\\"{x:1222,y:840,t:1526929878693};\\\", \\\"{x:1222,y:878,t:1526929878711};\\\", \\\"{x:1217,y:898,t:1526929878727};\\\", \\\"{x:1213,y:911,t:1526929878744};\\\", \\\"{x:1211,y:918,t:1526929878761};\\\", \\\"{x:1210,y:926,t:1526929878778};\\\", \\\"{x:1210,y:929,t:1526929878794};\\\", \\\"{x:1210,y:933,t:1526929878811};\\\", \\\"{x:1210,y:934,t:1526929878831};\\\", \\\"{x:1210,y:935,t:1526929878847};\\\", \\\"{x:1210,y:936,t:1526929878861};\\\", \\\"{x:1213,y:941,t:1526929878878};\\\", \\\"{x:1217,y:945,t:1526929878894};\\\", \\\"{x:1222,y:950,t:1526929878911};\\\", \\\"{x:1225,y:952,t:1526929878928};\\\", \\\"{x:1227,y:953,t:1526929878944};\\\", \\\"{x:1228,y:953,t:1526929878968};\\\", \\\"{x:1233,y:953,t:1526929878991};\\\", \\\"{x:1241,y:949,t:1526929878999};\\\", \\\"{x:1254,y:942,t:1526929879011};\\\", \\\"{x:1283,y:930,t:1526929879028};\\\", \\\"{x:1310,y:923,t:1526929879044};\\\", \\\"{x:1333,y:920,t:1526929879061};\\\", \\\"{x:1344,y:920,t:1526929879078};\\\", \\\"{x:1347,y:920,t:1526929879094};\\\", \\\"{x:1345,y:920,t:1526929879128};\\\", \\\"{x:1337,y:926,t:1526929879144};\\\", \\\"{x:1329,y:931,t:1526929879161};\\\", \\\"{x:1322,y:936,t:1526929879178};\\\", \\\"{x:1317,y:941,t:1526929879195};\\\", \\\"{x:1311,y:946,t:1526929879211};\\\", \\\"{x:1298,y:957,t:1526929879228};\\\", \\\"{x:1286,y:965,t:1526929879245};\\\", \\\"{x:1278,y:973,t:1526929879261};\\\", \\\"{x:1275,y:976,t:1526929879278};\\\", \\\"{x:1274,y:977,t:1526929879295};\\\", \\\"{x:1275,y:977,t:1526929879424};\\\", \\\"{x:1283,y:977,t:1526929879431};\\\", \\\"{x:1294,y:977,t:1526929879445};\\\", \\\"{x:1316,y:969,t:1526929879462};\\\", \\\"{x:1337,y:967,t:1526929879478};\\\", \\\"{x:1350,y:964,t:1526929879496};\\\", \\\"{x:1349,y:963,t:1526929879536};\\\", \\\"{x:1348,y:963,t:1526929879551};\\\", \\\"{x:1348,y:961,t:1526929879824};\\\", \\\"{x:1348,y:956,t:1526929879831};\\\", \\\"{x:1348,y:953,t:1526929879845};\\\", \\\"{x:1352,y:935,t:1526929879862};\\\", \\\"{x:1354,y:913,t:1526929879878};\\\", \\\"{x:1353,y:880,t:1526929879895};\\\", \\\"{x:1350,y:872,t:1526929879911};\\\", \\\"{x:1349,y:867,t:1526929879929};\\\", \\\"{x:1349,y:868,t:1526929880143};\\\", \\\"{x:1349,y:869,t:1526929880151};\\\", \\\"{x:1349,y:870,t:1526929880162};\\\", \\\"{x:1349,y:874,t:1526929880180};\\\", \\\"{x:1349,y:876,t:1526929880195};\\\", \\\"{x:1349,y:878,t:1526929880212};\\\", \\\"{x:1349,y:880,t:1526929880229};\\\", \\\"{x:1349,y:881,t:1526929880271};\\\", \\\"{x:1349,y:879,t:1526929880735};\\\", \\\"{x:1349,y:870,t:1526929880746};\\\", \\\"{x:1342,y:853,t:1526929880762};\\\", \\\"{x:1337,y:839,t:1526929880779};\\\", \\\"{x:1334,y:825,t:1526929880796};\\\", \\\"{x:1332,y:809,t:1526929880811};\\\", \\\"{x:1330,y:790,t:1526929880828};\\\", \\\"{x:1328,y:768,t:1526929880846};\\\", \\\"{x:1328,y:755,t:1526929880862};\\\", \\\"{x:1328,y:745,t:1526929880879};\\\", \\\"{x:1328,y:740,t:1526929880895};\\\", \\\"{x:1328,y:734,t:1526929880911};\\\", \\\"{x:1328,y:732,t:1526929880928};\\\", \\\"{x:1329,y:730,t:1526929880946};\\\", \\\"{x:1329,y:729,t:1526929880962};\\\", \\\"{x:1329,y:728,t:1526929881086};\\\", \\\"{x:1332,y:724,t:1526929881102};\\\", \\\"{x:1333,y:721,t:1526929881111};\\\", \\\"{x:1334,y:714,t:1526929881128};\\\", \\\"{x:1337,y:705,t:1526929881146};\\\", \\\"{x:1338,y:698,t:1526929881162};\\\", \\\"{x:1342,y:691,t:1526929881178};\\\", \\\"{x:1344,y:686,t:1526929881196};\\\", \\\"{x:1346,y:683,t:1526929881213};\\\", \\\"{x:1346,y:681,t:1526929881229};\\\", \\\"{x:1347,y:678,t:1526929881246};\\\", \\\"{x:1348,y:678,t:1526929881263};\\\", \\\"{x:1348,y:677,t:1526929881279};\\\", \\\"{x:1348,y:676,t:1526929881296};\\\", \\\"{x:1349,y:675,t:1526929881313};\\\", \\\"{x:1349,y:674,t:1526929881329};\\\", \\\"{x:1349,y:672,t:1526929881345};\\\", \\\"{x:1349,y:671,t:1526929881363};\\\", \\\"{x:1349,y:669,t:1526929881379};\\\", \\\"{x:1349,y:668,t:1526929881399};\\\", \\\"{x:1349,y:667,t:1526929881413};\\\", \\\"{x:1349,y:665,t:1526929881429};\\\", \\\"{x:1349,y:663,t:1526929881447};\\\", \\\"{x:1350,y:658,t:1526929881463};\\\", \\\"{x:1351,y:655,t:1526929881480};\\\", \\\"{x:1352,y:651,t:1526929881496};\\\", \\\"{x:1352,y:645,t:1526929881513};\\\", \\\"{x:1352,y:640,t:1526929881528};\\\", \\\"{x:1352,y:633,t:1526929881546};\\\", \\\"{x:1352,y:627,t:1526929881562};\\\", \\\"{x:1352,y:620,t:1526929881579};\\\", \\\"{x:1352,y:613,t:1526929881595};\\\", \\\"{x:1354,y:605,t:1526929881613};\\\", \\\"{x:1355,y:602,t:1526929881630};\\\", \\\"{x:1355,y:597,t:1526929881646};\\\", \\\"{x:1355,y:591,t:1526929881663};\\\", \\\"{x:1356,y:588,t:1526929881679};\\\", \\\"{x:1357,y:586,t:1526929881696};\\\", \\\"{x:1357,y:583,t:1526929881713};\\\", \\\"{x:1358,y:579,t:1526929881730};\\\", \\\"{x:1358,y:575,t:1526929881746};\\\", \\\"{x:1359,y:572,t:1526929881763};\\\", \\\"{x:1359,y:569,t:1526929881780};\\\", \\\"{x:1359,y:566,t:1526929881796};\\\", \\\"{x:1359,y:562,t:1526929881812};\\\", \\\"{x:1359,y:559,t:1526929881830};\\\", \\\"{x:1359,y:557,t:1526929881846};\\\", \\\"{x:1359,y:553,t:1526929881862};\\\", \\\"{x:1359,y:550,t:1526929881880};\\\", \\\"{x:1359,y:543,t:1526929881896};\\\", \\\"{x:1358,y:528,t:1526929881912};\\\", \\\"{x:1357,y:511,t:1526929881929};\\\", \\\"{x:1357,y:496,t:1526929881946};\\\", \\\"{x:1357,y:481,t:1526929881963};\\\", \\\"{x:1357,y:467,t:1526929881980};\\\", \\\"{x:1356,y:457,t:1526929881995};\\\", \\\"{x:1355,y:453,t:1526929882012};\\\", \\\"{x:1354,y:452,t:1526929882030};\\\", \\\"{x:1350,y:451,t:1526929882055};\\\", \\\"{x:1339,y:451,t:1526929882063};\\\", \\\"{x:1264,y:489,t:1526929882080};\\\", \\\"{x:1123,y:583,t:1526929882097};\\\", \\\"{x:923,y:688,t:1526929882113};\\\", \\\"{x:698,y:776,t:1526929882130};\\\", \\\"{x:486,y:837,t:1526929882147};\\\", \\\"{x:309,y:859,t:1526929882163};\\\", \\\"{x:195,y:864,t:1526929882180};\\\", \\\"{x:129,y:840,t:1526929882197};\\\", \\\"{x:101,y:814,t:1526929882213};\\\", \\\"{x:94,y:800,t:1526929882230};\\\", \\\"{x:95,y:789,t:1526929882247};\\\", \\\"{x:111,y:782,t:1526929882263};\\\", \\\"{x:126,y:775,t:1526929882280};\\\", \\\"{x:143,y:761,t:1526929882297};\\\", \\\"{x:162,y:751,t:1526929882313};\\\", \\\"{x:179,y:742,t:1526929882330};\\\", \\\"{x:196,y:726,t:1526929882347};\\\", \\\"{x:218,y:709,t:1526929882363};\\\", \\\"{x:241,y:691,t:1526929882380};\\\", \\\"{x:269,y:672,t:1526929882397};\\\", \\\"{x:307,y:650,t:1526929882415};\\\", \\\"{x:345,y:633,t:1526929882429};\\\", \\\"{x:386,y:619,t:1526929882448};\\\", \\\"{x:400,y:608,t:1526929882463};\\\", \\\"{x:412,y:601,t:1526929882481};\\\", \\\"{x:418,y:597,t:1526929882497};\\\", \\\"{x:418,y:596,t:1526929882514};\\\", \\\"{x:415,y:594,t:1526929882542};\\\", \\\"{x:403,y:588,t:1526929882550};\\\", \\\"{x:386,y:583,t:1526929882564};\\\", \\\"{x:349,y:575,t:1526929882581};\\\", \\\"{x:323,y:570,t:1526929882598};\\\", \\\"{x:304,y:570,t:1526929882614};\\\", \\\"{x:295,y:570,t:1526929882630};\\\", \\\"{x:298,y:570,t:1526929882678};\\\", \\\"{x:301,y:571,t:1526929882686};\\\", \\\"{x:302,y:571,t:1526929882698};\\\", \\\"{x:311,y:575,t:1526929882714};\\\", \\\"{x:323,y:576,t:1526929882730};\\\", \\\"{x:324,y:576,t:1526929882747};\\\", \\\"{x:324,y:578,t:1526929883055};\\\", \\\"{x:324,y:582,t:1526929883064};\\\", \\\"{x:336,y:596,t:1526929883079};\\\", \\\"{x:365,y:612,t:1526929883097};\\\", \\\"{x:397,y:624,t:1526929883114};\\\", \\\"{x:417,y:629,t:1526929883130};\\\", \\\"{x:427,y:630,t:1526929883147};\\\", \\\"{x:428,y:630,t:1526929883198};\\\", \\\"{x:430,y:632,t:1526929883215};\\\", \\\"{x:438,y:632,t:1526929883230};\\\", \\\"{x:453,y:632,t:1526929883248};\\\", \\\"{x:488,y:632,t:1526929883265};\\\", \\\"{x:568,y:624,t:1526929883282};\\\", \\\"{x:668,y:610,t:1526929883298};\\\", \\\"{x:771,y:610,t:1526929883316};\\\", \\\"{x:854,y:610,t:1526929883331};\\\", \\\"{x:895,y:608,t:1526929883348};\\\", \\\"{x:906,y:608,t:1526929883364};\\\", \\\"{x:907,y:608,t:1526929883380};\\\", \\\"{x:906,y:607,t:1526929883397};\\\", \\\"{x:902,y:605,t:1526929883414};\\\", \\\"{x:901,y:605,t:1526929883430};\\\", \\\"{x:901,y:604,t:1526929883518};\\\", \\\"{x:901,y:601,t:1526929883531};\\\", \\\"{x:892,y:594,t:1526929883548};\\\", \\\"{x:883,y:590,t:1526929883565};\\\", \\\"{x:879,y:589,t:1526929883581};\\\", \\\"{x:874,y:588,t:1526929883598};\\\", \\\"{x:862,y:585,t:1526929883616};\\\", \\\"{x:839,y:579,t:1526929883631};\\\", \\\"{x:807,y:574,t:1526929883649};\\\", \\\"{x:771,y:569,t:1526929883665};\\\", \\\"{x:737,y:565,t:1526929883682};\\\", \\\"{x:703,y:561,t:1526929883699};\\\", \\\"{x:662,y:559,t:1526929883715};\\\", \\\"{x:620,y:559,t:1526929883731};\\\", \\\"{x:578,y:569,t:1526929883748};\\\", \\\"{x:539,y:586,t:1526929883765};\\\", \\\"{x:507,y:602,t:1526929883782};\\\", \\\"{x:499,y:609,t:1526929883798};\\\", \\\"{x:496,y:621,t:1526929883816};\\\", \\\"{x:496,y:622,t:1526929883832};\\\", \\\"{x:496,y:624,t:1526929883871};\\\", \\\"{x:494,y:625,t:1526929883881};\\\", \\\"{x:477,y:625,t:1526929883899};\\\", \\\"{x:472,y:623,t:1526929883915};\\\", \\\"{x:463,y:620,t:1526929883932};\\\", \\\"{x:451,y:612,t:1526929883950};\\\", \\\"{x:444,y:607,t:1526929883965};\\\", \\\"{x:440,y:604,t:1526929883981};\\\", \\\"{x:440,y:601,t:1526929883998};\\\", \\\"{x:440,y:600,t:1526929884014};\\\", \\\"{x:441,y:596,t:1526929884032};\\\", \\\"{x:451,y:593,t:1526929884048};\\\", \\\"{x:476,y:586,t:1526929884065};\\\", \\\"{x:495,y:575,t:1526929884082};\\\", \\\"{x:530,y:556,t:1526929884099};\\\", \\\"{x:565,y:542,t:1526929884115};\\\", \\\"{x:598,y:529,t:1526929884133};\\\", \\\"{x:623,y:521,t:1526929884149};\\\", \\\"{x:644,y:512,t:1526929884165};\\\", \\\"{x:666,y:510,t:1526929884181};\\\", \\\"{x:675,y:510,t:1526929884199};\\\", \\\"{x:676,y:509,t:1526929884215};\\\", \\\"{x:674,y:508,t:1526929884231};\\\", \\\"{x:666,y:506,t:1526929884249};\\\", \\\"{x:662,y:506,t:1526929884266};\\\", \\\"{x:661,y:506,t:1526929884295};\\\", \\\"{x:660,y:506,t:1526929884310};\\\", \\\"{x:659,y:506,t:1526929884327};\\\", \\\"{x:655,y:507,t:1526929884334};\\\", \\\"{x:653,y:508,t:1526929884350};\\\", \\\"{x:649,y:511,t:1526929884366};\\\", \\\"{x:645,y:516,t:1526929884381};\\\", \\\"{x:640,y:530,t:1526929884398};\\\", \\\"{x:631,y:551,t:1526929884417};\\\", \\\"{x:614,y:586,t:1526929884433};\\\", \\\"{x:600,y:629,t:1526929884448};\\\", \\\"{x:598,y:640,t:1526929884464};\\\", \\\"{x:596,y:642,t:1526929884481};\\\", \\\"{x:596,y:645,t:1526929884498};\\\", \\\"{x:597,y:645,t:1526929884534};\\\", \\\"{x:598,y:645,t:1526929884566};\\\", \\\"{x:599,y:645,t:1526929884582};\\\", \\\"{x:599,y:643,t:1526929884606};\\\", \\\"{x:599,y:642,t:1526929884616};\\\", \\\"{x:596,y:636,t:1526929884633};\\\", \\\"{x:578,y:629,t:1526929884650};\\\", \\\"{x:526,y:622,t:1526929884666};\\\", \\\"{x:438,y:611,t:1526929884684};\\\", \\\"{x:325,y:601,t:1526929884700};\\\", \\\"{x:200,y:598,t:1526929884717};\\\", \\\"{x:85,y:590,t:1526929884732};\\\", \\\"{x:29,y:590,t:1526929884749};\\\", \\\"{x:0,y:590,t:1526929884766};\\\", \\\"{x:0,y:591,t:1526929884782};\\\", \\\"{x:0,y:593,t:1526929884799};\\\", \\\"{x:0,y:594,t:1526929884830};\\\", \\\"{x:0,y:596,t:1526929884847};\\\", \\\"{x:0,y:599,t:1526929884854};\\\", \\\"{x:0,y:602,t:1526929884870};\\\", \\\"{x:0,y:604,t:1526929884902};\\\", \\\"{x:0,y:605,t:1526929884927};\\\", \\\"{x:0,y:608,t:1526929884942};\\\", \\\"{x:4,y:610,t:1526929884950};\\\", \\\"{x:12,y:613,t:1526929884966};\\\", \\\"{x:24,y:618,t:1526929884982};\\\", \\\"{x:46,y:629,t:1526929884999};\\\", \\\"{x:57,y:632,t:1526929885018};\\\", \\\"{x:66,y:637,t:1526929885032};\\\", \\\"{x:73,y:640,t:1526929885048};\\\", \\\"{x:79,y:643,t:1526929885066};\\\", \\\"{x:81,y:643,t:1526929885083};\\\", \\\"{x:82,y:643,t:1526929885098};\\\", \\\"{x:85,y:643,t:1526929885116};\\\", \\\"{x:93,y:643,t:1526929885133};\\\", \\\"{x:104,y:633,t:1526929885149};\\\", \\\"{x:116,y:616,t:1526929885166};\\\", \\\"{x:130,y:597,t:1526929885183};\\\", \\\"{x:136,y:590,t:1526929885199};\\\", \\\"{x:137,y:589,t:1526929885216};\\\", \\\"{x:137,y:587,t:1526929885254};\\\", \\\"{x:137,y:585,t:1526929885265};\\\", \\\"{x:141,y:581,t:1526929885284};\\\", \\\"{x:146,y:577,t:1526929885299};\\\", \\\"{x:149,y:574,t:1526929885316};\\\", \\\"{x:149,y:573,t:1526929885334};\\\", \\\"{x:150,y:572,t:1526929885350};\\\", \\\"{x:150,y:571,t:1526929885366};\\\", \\\"{x:153,y:568,t:1526929885382};\\\", \\\"{x:153,y:566,t:1526929885399};\\\", \\\"{x:153,y:565,t:1526929885416};\\\", \\\"{x:154,y:564,t:1526929885433};\\\", \\\"{x:155,y:561,t:1526929885450};\\\", \\\"{x:156,y:561,t:1526929885466};\\\", \\\"{x:156,y:560,t:1526929885482};\\\", \\\"{x:156,y:559,t:1526929885943};\\\", \\\"{x:158,y:559,t:1526929885975};\\\", \\\"{x:166,y:560,t:1526929885983};\\\", \\\"{x:182,y:570,t:1526929886001};\\\", \\\"{x:192,y:579,t:1526929886017};\\\", \\\"{x:198,y:587,t:1526929886033};\\\", \\\"{x:204,y:604,t:1526929886050};\\\", \\\"{x:212,y:629,t:1526929886067};\\\", \\\"{x:237,y:664,t:1526929886083};\\\", \\\"{x:282,y:701,t:1526929886100};\\\", \\\"{x:338,y:732,t:1526929886117};\\\", \\\"{x:403,y:764,t:1526929886133};\\\", \\\"{x:488,y:801,t:1526929886150};\\\", \\\"{x:624,y:842,t:1526929886166};\\\", \\\"{x:721,y:866,t:1526929886183};\\\", \\\"{x:793,y:888,t:1526929886200};\\\", \\\"{x:844,y:905,t:1526929886217};\\\", \\\"{x:874,y:914,t:1526929886233};\\\", \\\"{x:881,y:918,t:1526929886250};\\\", \\\"{x:882,y:918,t:1526929886267};\\\", \\\"{x:882,y:914,t:1526929886487};\\\", \\\"{x:880,y:908,t:1526929886501};\\\", \\\"{x:869,y:892,t:1526929886517};\\\", \\\"{x:813,y:862,t:1526929886535};\\\", \\\"{x:758,y:837,t:1526929886551};\\\", \\\"{x:705,y:822,t:1526929886567};\\\", \\\"{x:664,y:812,t:1526929886584};\\\", \\\"{x:634,y:806,t:1526929886600};\\\", \\\"{x:613,y:799,t:1526929886617};\\\", \\\"{x:602,y:794,t:1526929886634};\\\", \\\"{x:597,y:789,t:1526929886650};\\\", \\\"{x:595,y:784,t:1526929886667};\\\", \\\"{x:587,y:774,t:1526929886684};\\\", \\\"{x:575,y:764,t:1526929886700};\\\", \\\"{x:564,y:755,t:1526929886718};\\\", \\\"{x:558,y:753,t:1526929886734};\\\", \\\"{x:552,y:752,t:1526929886751};\\\", \\\"{x:545,y:750,t:1526929886767};\\\", \\\"{x:540,y:749,t:1526929886784};\\\", \\\"{x:535,y:747,t:1526929886802};\\\", \\\"{x:528,y:745,t:1526929886817};\\\", \\\"{x:513,y:739,t:1526929886834};\\\", \\\"{x:502,y:732,t:1526929886852};\\\", \\\"{x:497,y:728,t:1526929886868};\\\", \\\"{x:496,y:725,t:1526929886884};\\\", \\\"{x:496,y:724,t:1526929886900};\\\", \\\"{x:495,y:722,t:1526929886917};\\\", \\\"{x:495,y:719,t:1526929886934};\\\", \\\"{x:495,y:716,t:1526929886950};\\\", \\\"{x:495,y:715,t:1526929886967};\\\", \\\"{x:495,y:713,t:1526929886983};\\\", \\\"{x:495,y:712,t:1526929887001};\\\" ] }, { \\\"rt\\\": 38042, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 252498, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-U -X -U -I -10 AM-10 AM-A -Z -F -F -F -J -H -03 PM-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:711,t:1526929891895};\\\", \\\"{x:504,y:712,t:1526929891907};\\\", \\\"{x:519,y:718,t:1526929891923};\\\", \\\"{x:528,y:720,t:1526929891939};\\\", \\\"{x:534,y:723,t:1526929891956};\\\", \\\"{x:541,y:726,t:1526929891973};\\\", \\\"{x:552,y:731,t:1526929891990};\\\", \\\"{x:561,y:736,t:1526929892007};\\\", \\\"{x:564,y:737,t:1526929892023};\\\", \\\"{x:565,y:738,t:1526929892038};\\\", \\\"{x:566,y:738,t:1526929892479};\\\", \\\"{x:566,y:739,t:1526929892488};\\\", \\\"{x:573,y:740,t:1526929892506};\\\", \\\"{x:593,y:739,t:1526929892523};\\\", \\\"{x:634,y:739,t:1526929892539};\\\", \\\"{x:667,y:739,t:1526929892555};\\\", \\\"{x:707,y:739,t:1526929892572};\\\", \\\"{x:798,y:747,t:1526929892589};\\\", \\\"{x:933,y:764,t:1526929892605};\\\", \\\"{x:1198,y:809,t:1526929892623};\\\", \\\"{x:1392,y:839,t:1526929892639};\\\", \\\"{x:1564,y:865,t:1526929892655};\\\", \\\"{x:1729,y:888,t:1526929892673};\\\", \\\"{x:1857,y:906,t:1526929892689};\\\", \\\"{x:1919,y:922,t:1526929892706};\\\", \\\"{x:1919,y:930,t:1526929892723};\\\", \\\"{x:1919,y:934,t:1526929892738};\\\", \\\"{x:1918,y:937,t:1526929892879};\\\", \\\"{x:1915,y:938,t:1526929892888};\\\", \\\"{x:1903,y:939,t:1526929892905};\\\", \\\"{x:1888,y:940,t:1526929892923};\\\", \\\"{x:1868,y:940,t:1526929892939};\\\", \\\"{x:1840,y:940,t:1526929892956};\\\", \\\"{x:1801,y:940,t:1526929892973};\\\", \\\"{x:1757,y:940,t:1526929892989};\\\", \\\"{x:1709,y:940,t:1526929893006};\\\", \\\"{x:1666,y:938,t:1526929893022};\\\", \\\"{x:1647,y:934,t:1526929893039};\\\", \\\"{x:1640,y:934,t:1526929893056};\\\", \\\"{x:1640,y:933,t:1526929893072};\\\", \\\"{x:1639,y:933,t:1526929893351};\\\", \\\"{x:1638,y:936,t:1526929893359};\\\", \\\"{x:1637,y:941,t:1526929893373};\\\", \\\"{x:1632,y:951,t:1526929893389};\\\", \\\"{x:1622,y:968,t:1526929893407};\\\", \\\"{x:1616,y:976,t:1526929893423};\\\", \\\"{x:1611,y:979,t:1526929893440};\\\", \\\"{x:1607,y:980,t:1526929893456};\\\", \\\"{x:1603,y:982,t:1526929893473};\\\", \\\"{x:1602,y:983,t:1526929893489};\\\", \\\"{x:1601,y:986,t:1526929893507};\\\", \\\"{x:1601,y:985,t:1526929893790};\\\", \\\"{x:1601,y:984,t:1526929893806};\\\", \\\"{x:1601,y:983,t:1526929893823};\\\", \\\"{x:1601,y:982,t:1526929893846};\\\", \\\"{x:1601,y:980,t:1526929893878};\\\", \\\"{x:1601,y:979,t:1526929893902};\\\", \\\"{x:1602,y:979,t:1526929893918};\\\", \\\"{x:1603,y:977,t:1526929894232};\\\", \\\"{x:1604,y:975,t:1526929894240};\\\", \\\"{x:1605,y:975,t:1526929894257};\\\", \\\"{x:1605,y:973,t:1526929894273};\\\", \\\"{x:1605,y:972,t:1526929894408};\\\", \\\"{x:1605,y:970,t:1526929894911};\\\", \\\"{x:1602,y:967,t:1526929894924};\\\", \\\"{x:1583,y:960,t:1526929894941};\\\", \\\"{x:1557,y:951,t:1526929894958};\\\", \\\"{x:1519,y:939,t:1526929894974};\\\", \\\"{x:1456,y:923,t:1526929894991};\\\", \\\"{x:1414,y:911,t:1526929895007};\\\", \\\"{x:1386,y:903,t:1526929895024};\\\", \\\"{x:1363,y:896,t:1526929895041};\\\", \\\"{x:1342,y:891,t:1526929895059};\\\", \\\"{x:1326,y:887,t:1526929895074};\\\", \\\"{x:1310,y:882,t:1526929895091};\\\", \\\"{x:1301,y:878,t:1526929895108};\\\", \\\"{x:1298,y:875,t:1526929895125};\\\", \\\"{x:1297,y:873,t:1526929895142};\\\", \\\"{x:1296,y:873,t:1526929895607};\\\", \\\"{x:1293,y:870,t:1526929895625};\\\", \\\"{x:1284,y:869,t:1526929895643};\\\", \\\"{x:1277,y:866,t:1526929895658};\\\", \\\"{x:1266,y:862,t:1526929895675};\\\", \\\"{x:1253,y:859,t:1526929895692};\\\", \\\"{x:1240,y:855,t:1526929895708};\\\", \\\"{x:1228,y:849,t:1526929895725};\\\", \\\"{x:1211,y:844,t:1526929895741};\\\", \\\"{x:1197,y:837,t:1526929895758};\\\", \\\"{x:1181,y:830,t:1526929895774};\\\", \\\"{x:1176,y:828,t:1526929895791};\\\", \\\"{x:1174,y:827,t:1526929895807};\\\", \\\"{x:1174,y:826,t:1526929895895};\\\", \\\"{x:1174,y:825,t:1526929895918};\\\", \\\"{x:1175,y:824,t:1526929895942};\\\", \\\"{x:1176,y:823,t:1526929895959};\\\", \\\"{x:1176,y:822,t:1526929895975};\\\", \\\"{x:1178,y:820,t:1526929895992};\\\", \\\"{x:1179,y:817,t:1526929896008};\\\", \\\"{x:1182,y:815,t:1526929896025};\\\", \\\"{x:1186,y:813,t:1526929896042};\\\", \\\"{x:1192,y:810,t:1526929896059};\\\", \\\"{x:1199,y:808,t:1526929896074};\\\", \\\"{x:1206,y:805,t:1526929896091};\\\", \\\"{x:1212,y:805,t:1526929896108};\\\", \\\"{x:1216,y:805,t:1526929896124};\\\", \\\"{x:1217,y:805,t:1526929896142};\\\", \\\"{x:1218,y:805,t:1526929896215};\\\", \\\"{x:1219,y:805,t:1526929896247};\\\", \\\"{x:1220,y:806,t:1526929896311};\\\", \\\"{x:1220,y:807,t:1526929896367};\\\", \\\"{x:1220,y:808,t:1526929896375};\\\", \\\"{x:1219,y:810,t:1526929896391};\\\", \\\"{x:1218,y:811,t:1526929896409};\\\", \\\"{x:1219,y:812,t:1526929896704};\\\", \\\"{x:1226,y:814,t:1526929896711};\\\", \\\"{x:1232,y:817,t:1526929896726};\\\", \\\"{x:1274,y:821,t:1526929896743};\\\", \\\"{x:1315,y:824,t:1526929896759};\\\", \\\"{x:1357,y:824,t:1526929896775};\\\", \\\"{x:1410,y:824,t:1526929896793};\\\", \\\"{x:1457,y:824,t:1526929896809};\\\", \\\"{x:1499,y:824,t:1526929896826};\\\", \\\"{x:1522,y:824,t:1526929896843};\\\", \\\"{x:1536,y:825,t:1526929896859};\\\", \\\"{x:1541,y:827,t:1526929896876};\\\", \\\"{x:1547,y:829,t:1526929896893};\\\", \\\"{x:1553,y:832,t:1526929896909};\\\", \\\"{x:1556,y:833,t:1526929896926};\\\", \\\"{x:1558,y:834,t:1526929896943};\\\", \\\"{x:1558,y:835,t:1526929896958};\\\", \\\"{x:1559,y:835,t:1526929896975};\\\", \\\"{x:1559,y:837,t:1526929896993};\\\", \\\"{x:1559,y:838,t:1526929897009};\\\", \\\"{x:1559,y:840,t:1526929897026};\\\", \\\"{x:1559,y:842,t:1526929897042};\\\", \\\"{x:1559,y:844,t:1526929897059};\\\", \\\"{x:1558,y:845,t:1526929897076};\\\", \\\"{x:1556,y:848,t:1526929897093};\\\", \\\"{x:1554,y:850,t:1526929897108};\\\", \\\"{x:1552,y:852,t:1526929897126};\\\", \\\"{x:1549,y:854,t:1526929897143};\\\", \\\"{x:1546,y:855,t:1526929897159};\\\", \\\"{x:1543,y:857,t:1526929897176};\\\", \\\"{x:1538,y:857,t:1526929897193};\\\", \\\"{x:1535,y:857,t:1526929897210};\\\", \\\"{x:1531,y:857,t:1526929897226};\\\", \\\"{x:1529,y:856,t:1526929897242};\\\", \\\"{x:1522,y:854,t:1526929897259};\\\", \\\"{x:1514,y:848,t:1526929897276};\\\", \\\"{x:1499,y:844,t:1526929897293};\\\", \\\"{x:1483,y:839,t:1526929897310};\\\", \\\"{x:1465,y:837,t:1526929897326};\\\", \\\"{x:1438,y:828,t:1526929897343};\\\", \\\"{x:1421,y:826,t:1526929897359};\\\", \\\"{x:1413,y:825,t:1526929897376};\\\", \\\"{x:1413,y:826,t:1526929897423};\\\", \\\"{x:1415,y:827,t:1526929897439};\\\", \\\"{x:1418,y:828,t:1526929897447};\\\", \\\"{x:1422,y:828,t:1526929897460};\\\", \\\"{x:1432,y:828,t:1526929897476};\\\", \\\"{x:1443,y:828,t:1526929897493};\\\", \\\"{x:1448,y:828,t:1526929897510};\\\", \\\"{x:1450,y:828,t:1526929897526};\\\", \\\"{x:1453,y:828,t:1526929897543};\\\", \\\"{x:1455,y:828,t:1526929897567};\\\", \\\"{x:1456,y:828,t:1526929897576};\\\", \\\"{x:1457,y:828,t:1526929897593};\\\", \\\"{x:1458,y:828,t:1526929897610};\\\", \\\"{x:1459,y:828,t:1526929897720};\\\", \\\"{x:1460,y:828,t:1526929897726};\\\", \\\"{x:1461,y:828,t:1526929897743};\\\", \\\"{x:1462,y:830,t:1526929897760};\\\", \\\"{x:1463,y:830,t:1526929897815};\\\", \\\"{x:1464,y:830,t:1526929897863};\\\", \\\"{x:1465,y:830,t:1526929897879};\\\", \\\"{x:1466,y:830,t:1526929898127};\\\", \\\"{x:1468,y:831,t:1526929898143};\\\", \\\"{x:1469,y:832,t:1526929898160};\\\", \\\"{x:1471,y:832,t:1526929898719};\\\", \\\"{x:1473,y:833,t:1526929898727};\\\", \\\"{x:1474,y:833,t:1526929898744};\\\", \\\"{x:1474,y:834,t:1526929898761};\\\", \\\"{x:1477,y:834,t:1526929898780};\\\", \\\"{x:1478,y:834,t:1526929898793};\\\", \\\"{x:1479,y:835,t:1526929898810};\\\", \\\"{x:1480,y:835,t:1526929898827};\\\", \\\"{x:1482,y:836,t:1526929898844};\\\", \\\"{x:1483,y:837,t:1526929898878};\\\", \\\"{x:1482,y:837,t:1526929899583};\\\", \\\"{x:1462,y:837,t:1526929899594};\\\", \\\"{x:1374,y:816,t:1526929899610};\\\", \\\"{x:1234,y:783,t:1526929899628};\\\", \\\"{x:1075,y:748,t:1526929899645};\\\", \\\"{x:929,y:713,t:1526929899662};\\\", \\\"{x:795,y:688,t:1526929899678};\\\", \\\"{x:615,y:652,t:1526929899695};\\\", \\\"{x:526,y:627,t:1526929899712};\\\", \\\"{x:481,y:608,t:1526929899728};\\\", \\\"{x:460,y:597,t:1526929899744};\\\", \\\"{x:449,y:590,t:1526929899760};\\\", \\\"{x:445,y:587,t:1526929899777};\\\", \\\"{x:441,y:582,t:1526929899793};\\\", \\\"{x:437,y:576,t:1526929899811};\\\", \\\"{x:436,y:572,t:1526929899828};\\\", \\\"{x:436,y:569,t:1526929899844};\\\", \\\"{x:436,y:565,t:1526929899861};\\\", \\\"{x:436,y:559,t:1526929899877};\\\", \\\"{x:440,y:555,t:1526929899893};\\\", \\\"{x:458,y:555,t:1526929899910};\\\", \\\"{x:480,y:556,t:1526929899927};\\\", \\\"{x:495,y:561,t:1526929899944};\\\", \\\"{x:497,y:562,t:1526929899961};\\\", \\\"{x:501,y:565,t:1526929899979};\\\", \\\"{x:513,y:574,t:1526929899993};\\\", \\\"{x:528,y:587,t:1526929900011};\\\", \\\"{x:541,y:595,t:1526929900027};\\\", \\\"{x:554,y:602,t:1526929900044};\\\", \\\"{x:571,y:609,t:1526929900061};\\\", \\\"{x:590,y:617,t:1526929900078};\\\", \\\"{x:594,y:618,t:1526929900094};\\\", \\\"{x:595,y:618,t:1526929900118};\\\", \\\"{x:596,y:618,t:1526929900134};\\\", \\\"{x:598,y:618,t:1526929900145};\\\", \\\"{x:600,y:617,t:1526929900161};\\\", \\\"{x:601,y:616,t:1526929900177};\\\", \\\"{x:603,y:615,t:1526929900194};\\\", \\\"{x:603,y:614,t:1526929900211};\\\", \\\"{x:605,y:613,t:1526929900245};\\\", \\\"{x:605,y:612,t:1526929900261};\\\", \\\"{x:605,y:611,t:1526929900277};\\\", \\\"{x:605,y:609,t:1526929900294};\\\", \\\"{x:605,y:607,t:1526929900311};\\\", \\\"{x:605,y:604,t:1526929900328};\\\", \\\"{x:606,y:601,t:1526929900344};\\\", \\\"{x:607,y:601,t:1526929900362};\\\", \\\"{x:607,y:599,t:1526929900378};\\\", \\\"{x:608,y:598,t:1526929900394};\\\", \\\"{x:608,y:597,t:1526929900412};\\\", \\\"{x:611,y:597,t:1526929900735};\\\", \\\"{x:621,y:600,t:1526929900745};\\\", \\\"{x:658,y:608,t:1526929900762};\\\", \\\"{x:748,y:623,t:1526929900778};\\\", \\\"{x:856,y:637,t:1526929900794};\\\", \\\"{x:975,y:656,t:1526929900811};\\\", \\\"{x:1122,y:677,t:1526929900828};\\\", \\\"{x:1260,y:695,t:1526929900844};\\\", \\\"{x:1405,y:721,t:1526929900862};\\\", \\\"{x:1600,y:753,t:1526929900878};\\\", \\\"{x:1699,y:772,t:1526929900896};\\\", \\\"{x:1755,y:782,t:1526929900911};\\\", \\\"{x:1778,y:788,t:1526929900928};\\\", \\\"{x:1788,y:791,t:1526929900946};\\\", \\\"{x:1789,y:791,t:1526929900961};\\\", \\\"{x:1786,y:791,t:1526929901071};\\\", \\\"{x:1781,y:791,t:1526929901079};\\\", \\\"{x:1765,y:795,t:1526929901096};\\\", \\\"{x:1743,y:798,t:1526929901113};\\\", \\\"{x:1715,y:802,t:1526929901128};\\\", \\\"{x:1688,y:802,t:1526929901145};\\\", \\\"{x:1664,y:798,t:1526929901162};\\\", \\\"{x:1646,y:794,t:1526929901179};\\\", \\\"{x:1634,y:790,t:1526929901196};\\\", \\\"{x:1631,y:789,t:1526929901212};\\\", \\\"{x:1626,y:787,t:1526929901228};\\\", \\\"{x:1622,y:786,t:1526929901246};\\\", \\\"{x:1616,y:785,t:1526929901261};\\\", \\\"{x:1611,y:782,t:1526929901279};\\\", \\\"{x:1606,y:780,t:1526929901295};\\\", \\\"{x:1600,y:779,t:1526929901311};\\\", \\\"{x:1595,y:779,t:1526929901329};\\\", \\\"{x:1586,y:781,t:1526929901346};\\\", \\\"{x:1573,y:787,t:1526929901362};\\\", \\\"{x:1556,y:802,t:1526929901379};\\\", \\\"{x:1548,y:820,t:1526929901396};\\\", \\\"{x:1548,y:823,t:1526929901414};\\\", \\\"{x:1546,y:823,t:1526929901662};\\\", \\\"{x:1539,y:823,t:1526929901679};\\\", \\\"{x:1534,y:823,t:1526929901696};\\\", \\\"{x:1519,y:821,t:1526929901713};\\\", \\\"{x:1497,y:815,t:1526929901729};\\\", \\\"{x:1474,y:809,t:1526929901746};\\\", \\\"{x:1454,y:807,t:1526929901762};\\\", \\\"{x:1446,y:803,t:1526929901780};\\\", \\\"{x:1442,y:801,t:1526929901796};\\\", \\\"{x:1438,y:800,t:1526929901813};\\\", \\\"{x:1434,y:799,t:1526929901830};\\\", \\\"{x:1431,y:799,t:1526929901846};\\\", \\\"{x:1430,y:799,t:1526929901863};\\\", \\\"{x:1432,y:799,t:1526929901968};\\\", \\\"{x:1435,y:799,t:1526929901980};\\\", \\\"{x:1446,y:799,t:1526929901995};\\\", \\\"{x:1454,y:797,t:1526929902013};\\\", \\\"{x:1461,y:796,t:1526929902030};\\\", \\\"{x:1464,y:795,t:1526929902046};\\\", \\\"{x:1466,y:793,t:1526929902240};\\\", \\\"{x:1466,y:790,t:1526929902246};\\\", \\\"{x:1468,y:783,t:1526929902263};\\\", \\\"{x:1469,y:780,t:1526929902280};\\\", \\\"{x:1469,y:777,t:1526929902296};\\\", \\\"{x:1469,y:773,t:1526929902314};\\\", \\\"{x:1472,y:764,t:1526929902330};\\\", \\\"{x:1474,y:752,t:1526929902347};\\\", \\\"{x:1474,y:741,t:1526929902363};\\\", \\\"{x:1476,y:733,t:1526929902380};\\\", \\\"{x:1478,y:719,t:1526929902396};\\\", \\\"{x:1479,y:705,t:1526929902412};\\\", \\\"{x:1481,y:692,t:1526929902430};\\\", \\\"{x:1481,y:674,t:1526929902447};\\\", \\\"{x:1483,y:667,t:1526929902462};\\\", \\\"{x:1484,y:661,t:1526929902479};\\\", \\\"{x:1484,y:654,t:1526929902496};\\\", \\\"{x:1484,y:641,t:1526929902513};\\\", \\\"{x:1486,y:631,t:1526929902529};\\\", \\\"{x:1487,y:618,t:1526929902547};\\\", \\\"{x:1488,y:609,t:1526929902562};\\\", \\\"{x:1489,y:598,t:1526929902579};\\\", \\\"{x:1490,y:592,t:1526929902596};\\\", \\\"{x:1490,y:585,t:1526929902613};\\\", \\\"{x:1490,y:577,t:1526929902630};\\\", \\\"{x:1490,y:562,t:1526929902646};\\\", \\\"{x:1490,y:551,t:1526929902664};\\\", \\\"{x:1490,y:541,t:1526929902680};\\\", \\\"{x:1490,y:533,t:1526929902697};\\\", \\\"{x:1489,y:526,t:1526929902714};\\\", \\\"{x:1489,y:523,t:1526929902730};\\\", \\\"{x:1488,y:521,t:1526929902747};\\\", \\\"{x:1487,y:519,t:1526929902764};\\\", \\\"{x:1487,y:516,t:1526929902779};\\\", \\\"{x:1486,y:510,t:1526929902796};\\\", \\\"{x:1485,y:505,t:1526929902814};\\\", \\\"{x:1482,y:495,t:1526929902831};\\\", \\\"{x:1481,y:488,t:1526929902846};\\\", \\\"{x:1481,y:481,t:1526929902863};\\\", \\\"{x:1479,y:474,t:1526929902880};\\\", \\\"{x:1479,y:469,t:1526929902897};\\\", \\\"{x:1479,y:464,t:1526929902913};\\\", \\\"{x:1479,y:458,t:1526929902929};\\\", \\\"{x:1479,y:453,t:1526929902947};\\\", \\\"{x:1479,y:449,t:1526929902963};\\\", \\\"{x:1479,y:442,t:1526929902979};\\\", \\\"{x:1479,y:435,t:1526929902997};\\\", \\\"{x:1479,y:427,t:1526929903013};\\\", \\\"{x:1479,y:416,t:1526929903030};\\\", \\\"{x:1479,y:400,t:1526929903046};\\\", \\\"{x:1479,y:390,t:1526929903064};\\\", \\\"{x:1479,y:381,t:1526929903081};\\\", \\\"{x:1479,y:368,t:1526929903097};\\\", \\\"{x:1479,y:356,t:1526929903114};\\\", \\\"{x:1479,y:347,t:1526929903130};\\\", \\\"{x:1479,y:336,t:1526929903146};\\\", \\\"{x:1479,y:326,t:1526929903163};\\\", \\\"{x:1479,y:317,t:1526929903180};\\\", \\\"{x:1479,y:310,t:1526929903197};\\\", \\\"{x:1479,y:304,t:1526929903214};\\\", \\\"{x:1479,y:292,t:1526929903231};\\\", \\\"{x:1479,y:284,t:1526929903247};\\\", \\\"{x:1479,y:278,t:1526929903264};\\\", \\\"{x:1479,y:272,t:1526929903281};\\\", \\\"{x:1479,y:265,t:1526929903297};\\\", \\\"{x:1478,y:259,t:1526929903314};\\\", \\\"{x:1478,y:254,t:1526929903331};\\\", \\\"{x:1478,y:247,t:1526929903347};\\\", \\\"{x:1478,y:239,t:1526929903364};\\\", \\\"{x:1477,y:229,t:1526929903381};\\\", \\\"{x:1474,y:218,t:1526929903397};\\\", \\\"{x:1473,y:208,t:1526929903414};\\\", \\\"{x:1471,y:190,t:1526929903430};\\\", \\\"{x:1468,y:177,t:1526929903447};\\\", \\\"{x:1465,y:164,t:1526929903464};\\\", \\\"{x:1464,y:151,t:1526929903481};\\\", \\\"{x:1463,y:140,t:1526929903497};\\\", \\\"{x:1462,y:132,t:1526929903514};\\\", \\\"{x:1462,y:123,t:1526929903531};\\\", \\\"{x:1462,y:118,t:1526929903547};\\\", \\\"{x:1462,y:114,t:1526929903564};\\\", \\\"{x:1462,y:113,t:1526929903581};\\\", \\\"{x:1463,y:113,t:1526929903719};\\\", \\\"{x:1466,y:113,t:1526929903731};\\\", \\\"{x:1470,y:115,t:1526929903747};\\\", \\\"{x:1473,y:121,t:1526929903764};\\\", \\\"{x:1477,y:133,t:1526929903781};\\\", \\\"{x:1480,y:152,t:1526929903797};\\\", \\\"{x:1483,y:177,t:1526929903813};\\\", \\\"{x:1489,y:224,t:1526929903831};\\\", \\\"{x:1498,y:285,t:1526929903848};\\\", \\\"{x:1511,y:369,t:1526929903864};\\\", \\\"{x:1525,y:479,t:1526929903881};\\\", \\\"{x:1544,y:604,t:1526929903898};\\\", \\\"{x:1566,y:705,t:1526929903915};\\\", \\\"{x:1580,y:779,t:1526929903931};\\\", \\\"{x:1589,y:822,t:1526929903947};\\\", \\\"{x:1598,y:852,t:1526929903964};\\\", \\\"{x:1603,y:866,t:1526929903980};\\\", \\\"{x:1605,y:870,t:1526929903998};\\\", \\\"{x:1604,y:875,t:1526929904103};\\\", \\\"{x:1599,y:883,t:1526929904115};\\\", \\\"{x:1582,y:905,t:1526929904132};\\\", \\\"{x:1562,y:928,t:1526929904147};\\\", \\\"{x:1545,y:945,t:1526929904165};\\\", \\\"{x:1536,y:946,t:1526929904181};\\\", \\\"{x:1529,y:946,t:1526929904198};\\\", \\\"{x:1514,y:941,t:1526929904214};\\\", \\\"{x:1514,y:939,t:1526929904230};\\\", \\\"{x:1514,y:935,t:1526929904751};\\\", \\\"{x:1514,y:930,t:1526929904765};\\\", \\\"{x:1514,y:914,t:1526929904782};\\\", \\\"{x:1513,y:889,t:1526929904799};\\\", \\\"{x:1509,y:876,t:1526929904814};\\\", \\\"{x:1507,y:869,t:1526929904833};\\\", \\\"{x:1504,y:862,t:1526929904849};\\\", \\\"{x:1501,y:857,t:1526929904865};\\\", \\\"{x:1500,y:853,t:1526929904882};\\\", \\\"{x:1498,y:848,t:1526929904899};\\\", \\\"{x:1496,y:844,t:1526929904915};\\\", \\\"{x:1494,y:840,t:1526929904932};\\\", \\\"{x:1491,y:838,t:1526929904949};\\\", \\\"{x:1491,y:836,t:1526929904965};\\\", \\\"{x:1489,y:835,t:1526929904982};\\\", \\\"{x:1484,y:832,t:1526929904999};\\\", \\\"{x:1483,y:829,t:1526929905014};\\\", \\\"{x:1481,y:829,t:1526929905054};\\\", \\\"{x:1481,y:828,t:1526929905078};\\\", \\\"{x:1480,y:827,t:1526929905975};\\\", \\\"{x:1477,y:825,t:1526929905983};\\\", \\\"{x:1454,y:798,t:1526929905999};\\\", \\\"{x:1405,y:696,t:1526929906017};\\\", \\\"{x:1323,y:584,t:1526929906033};\\\", \\\"{x:1232,y:464,t:1526929906049};\\\", \\\"{x:1140,y:362,t:1526929906066};\\\", \\\"{x:1087,y:304,t:1526929906083};\\\", \\\"{x:1066,y:274,t:1526929906100};\\\", \\\"{x:1064,y:266,t:1526929906117};\\\", \\\"{x:1064,y:263,t:1526929906134};\\\", \\\"{x:1065,y:260,t:1526929906150};\\\", \\\"{x:1071,y:257,t:1526929906166};\\\", \\\"{x:1086,y:252,t:1526929906183};\\\", \\\"{x:1091,y:250,t:1526929906200};\\\", \\\"{x:1094,y:250,t:1526929906216};\\\", \\\"{x:1098,y:250,t:1526929906233};\\\", \\\"{x:1104,y:250,t:1526929906250};\\\", \\\"{x:1115,y:255,t:1526929906266};\\\", \\\"{x:1127,y:265,t:1526929906283};\\\", \\\"{x:1143,y:290,t:1526929906300};\\\", \\\"{x:1155,y:320,t:1526929906316};\\\", \\\"{x:1175,y:364,t:1526929906334};\\\", \\\"{x:1215,y:435,t:1526929906351};\\\", \\\"{x:1229,y:469,t:1526929906366};\\\", \\\"{x:1262,y:550,t:1526929906382};\\\", \\\"{x:1280,y:591,t:1526929906400};\\\", \\\"{x:1290,y:618,t:1526929906416};\\\", \\\"{x:1294,y:632,t:1526929906433};\\\", \\\"{x:1295,y:640,t:1526929906451};\\\", \\\"{x:1297,y:648,t:1526929906466};\\\", \\\"{x:1298,y:653,t:1526929906483};\\\", \\\"{x:1298,y:658,t:1526929906500};\\\", \\\"{x:1298,y:660,t:1526929906516};\\\", \\\"{x:1298,y:661,t:1526929906533};\\\", \\\"{x:1298,y:662,t:1526929906671};\\\", \\\"{x:1299,y:660,t:1526929906686};\\\", \\\"{x:1300,y:654,t:1526929906701};\\\", \\\"{x:1300,y:649,t:1526929906717};\\\", \\\"{x:1302,y:640,t:1526929906734};\\\", \\\"{x:1302,y:630,t:1526929906751};\\\", \\\"{x:1301,y:623,t:1526929906767};\\\", \\\"{x:1298,y:615,t:1526929906783};\\\", \\\"{x:1296,y:609,t:1526929906800};\\\", \\\"{x:1293,y:605,t:1526929906817};\\\", \\\"{x:1293,y:602,t:1526929906833};\\\", \\\"{x:1293,y:601,t:1526929906850};\\\", \\\"{x:1291,y:597,t:1526929906867};\\\", \\\"{x:1291,y:595,t:1526929906883};\\\", \\\"{x:1291,y:594,t:1526929906900};\\\", \\\"{x:1291,y:592,t:1526929906917};\\\", \\\"{x:1291,y:589,t:1526929906933};\\\", \\\"{x:1291,y:585,t:1526929906951};\\\", \\\"{x:1291,y:581,t:1526929906967};\\\", \\\"{x:1291,y:578,t:1526929906985};\\\", \\\"{x:1291,y:574,t:1526929907000};\\\", \\\"{x:1294,y:570,t:1526929907017};\\\", \\\"{x:1294,y:568,t:1526929907034};\\\", \\\"{x:1295,y:567,t:1526929907051};\\\", \\\"{x:1295,y:565,t:1526929907067};\\\", \\\"{x:1295,y:563,t:1526929907085};\\\", \\\"{x:1295,y:560,t:1526929907101};\\\", \\\"{x:1295,y:557,t:1526929907117};\\\", \\\"{x:1295,y:552,t:1526929907133};\\\", \\\"{x:1295,y:547,t:1526929907150};\\\", \\\"{x:1295,y:545,t:1526929907167};\\\", \\\"{x:1295,y:544,t:1526929907190};\\\", \\\"{x:1295,y:543,t:1526929907215};\\\", \\\"{x:1295,y:541,t:1526929907222};\\\", \\\"{x:1295,y:539,t:1526929907238};\\\", \\\"{x:1295,y:537,t:1526929907251};\\\", \\\"{x:1295,y:534,t:1526929907267};\\\", \\\"{x:1295,y:530,t:1526929907285};\\\", \\\"{x:1298,y:526,t:1526929907300};\\\", \\\"{x:1299,y:519,t:1526929907317};\\\", \\\"{x:1302,y:514,t:1526929907335};\\\", \\\"{x:1303,y:511,t:1526929907351};\\\", \\\"{x:1304,y:509,t:1526929907367};\\\", \\\"{x:1305,y:507,t:1526929907384};\\\", \\\"{x:1305,y:505,t:1526929907400};\\\", \\\"{x:1306,y:503,t:1526929907417};\\\", \\\"{x:1307,y:501,t:1526929907434};\\\", \\\"{x:1307,y:499,t:1526929907451};\\\", \\\"{x:1308,y:499,t:1526929907467};\\\", \\\"{x:1309,y:497,t:1526929907484};\\\", \\\"{x:1309,y:495,t:1526929907500};\\\", \\\"{x:1310,y:495,t:1526929907535};\\\", \\\"{x:1311,y:500,t:1526929907935};\\\", \\\"{x:1311,y:536,t:1526929907952};\\\", \\\"{x:1306,y:626,t:1526929907967};\\\", \\\"{x:1286,y:735,t:1526929907985};\\\", \\\"{x:1255,y:843,t:1526929908001};\\\", \\\"{x:1230,y:929,t:1526929908019};\\\", \\\"{x:1211,y:978,t:1526929908035};\\\", \\\"{x:1201,y:1000,t:1526929908052};\\\", \\\"{x:1199,y:1007,t:1526929908068};\\\", \\\"{x:1198,y:1007,t:1526929908151};\\\", \\\"{x:1197,y:1007,t:1526929908168};\\\", \\\"{x:1195,y:1005,t:1526929908184};\\\", \\\"{x:1195,y:997,t:1526929908201};\\\", \\\"{x:1195,y:985,t:1526929908218};\\\", \\\"{x:1195,y:975,t:1526929908234};\\\", \\\"{x:1195,y:971,t:1526929908251};\\\", \\\"{x:1195,y:964,t:1526929908269};\\\", \\\"{x:1195,y:960,t:1526929908285};\\\", \\\"{x:1197,y:951,t:1526929908301};\\\", \\\"{x:1206,y:931,t:1526929908319};\\\", \\\"{x:1209,y:919,t:1526929908335};\\\", \\\"{x:1211,y:913,t:1526929908351};\\\", \\\"{x:1212,y:910,t:1526929908369};\\\", \\\"{x:1212,y:909,t:1526929908391};\\\", \\\"{x:1216,y:898,t:1526929908615};\\\", \\\"{x:1244,y:857,t:1526929908623};\\\", \\\"{x:1276,y:812,t:1526929908636};\\\", \\\"{x:1322,y:723,t:1526929908651};\\\", \\\"{x:1354,y:617,t:1526929908667};\\\", \\\"{x:1375,y:500,t:1526929908685};\\\", \\\"{x:1393,y:347,t:1526929908701};\\\", \\\"{x:1393,y:294,t:1526929908717};\\\", \\\"{x:1393,y:261,t:1526929908735};\\\", \\\"{x:1393,y:244,t:1526929908751};\\\", \\\"{x:1391,y:237,t:1526929908768};\\\", \\\"{x:1384,y:230,t:1526929908785};\\\", \\\"{x:1375,y:226,t:1526929908801};\\\", \\\"{x:1368,y:221,t:1526929908817};\\\", \\\"{x:1363,y:217,t:1526929908834};\\\", \\\"{x:1359,y:215,t:1526929908852};\\\", \\\"{x:1358,y:214,t:1526929908867};\\\", \\\"{x:1357,y:214,t:1526929908884};\\\", \\\"{x:1353,y:230,t:1526929908902};\\\", \\\"{x:1341,y:269,t:1526929908918};\\\", \\\"{x:1323,y:333,t:1526929908935};\\\", \\\"{x:1304,y:423,t:1526929908952};\\\", \\\"{x:1285,y:505,t:1526929908968};\\\", \\\"{x:1273,y:552,t:1526929908984};\\\", \\\"{x:1262,y:586,t:1526929909002};\\\", \\\"{x:1260,y:608,t:1526929909017};\\\", \\\"{x:1260,y:626,t:1526929909035};\\\", \\\"{x:1260,y:641,t:1526929909052};\\\", \\\"{x:1260,y:646,t:1526929909067};\\\", \\\"{x:1260,y:647,t:1526929909085};\\\", \\\"{x:1262,y:644,t:1526929909263};\\\", \\\"{x:1264,y:642,t:1526929909271};\\\", \\\"{x:1264,y:641,t:1526929909285};\\\", \\\"{x:1266,y:639,t:1526929909302};\\\", \\\"{x:1268,y:639,t:1526929909407};\\\", \\\"{x:1269,y:639,t:1526929909419};\\\", \\\"{x:1272,y:641,t:1526929909435};\\\", \\\"{x:1274,y:642,t:1526929909455};\\\", \\\"{x:1276,y:642,t:1526929909469};\\\", \\\"{x:1281,y:645,t:1526929909486};\\\", \\\"{x:1282,y:645,t:1526929909502};\\\", \\\"{x:1283,y:645,t:1526929909543};\\\", \\\"{x:1286,y:643,t:1526929909552};\\\", \\\"{x:1291,y:642,t:1526929909570};\\\", \\\"{x:1299,y:639,t:1526929909586};\\\", \\\"{x:1304,y:637,t:1526929909602};\\\", \\\"{x:1305,y:637,t:1526929909619};\\\", \\\"{x:1306,y:636,t:1526929909637};\\\", \\\"{x:1307,y:636,t:1526929909652};\\\", \\\"{x:1308,y:636,t:1526929909669};\\\", \\\"{x:1309,y:636,t:1526929909991};\\\", \\\"{x:1311,y:639,t:1526929910439};\\\", \\\"{x:1313,y:646,t:1526929910454};\\\", \\\"{x:1315,y:663,t:1526929910470};\\\", \\\"{x:1320,y:688,t:1526929910487};\\\", \\\"{x:1324,y:697,t:1526929910503};\\\", \\\"{x:1326,y:703,t:1526929910520};\\\", \\\"{x:1327,y:707,t:1526929910536};\\\", \\\"{x:1328,y:711,t:1526929910553};\\\", \\\"{x:1329,y:714,t:1526929910571};\\\", \\\"{x:1329,y:715,t:1526929910587};\\\", \\\"{x:1329,y:716,t:1526929910623};\\\", \\\"{x:1330,y:716,t:1526929910636};\\\", \\\"{x:1330,y:717,t:1526929910653};\\\", \\\"{x:1331,y:720,t:1526929910669};\\\", \\\"{x:1332,y:724,t:1526929910686};\\\", \\\"{x:1332,y:727,t:1526929910703};\\\", \\\"{x:1334,y:731,t:1526929910720};\\\", \\\"{x:1335,y:736,t:1526929910735};\\\", \\\"{x:1335,y:740,t:1526929910753};\\\", \\\"{x:1336,y:748,t:1526929910770};\\\", \\\"{x:1340,y:756,t:1526929910785};\\\", \\\"{x:1341,y:761,t:1526929910802};\\\", \\\"{x:1342,y:763,t:1526929910820};\\\", \\\"{x:1342,y:764,t:1526929910838};\\\", \\\"{x:1342,y:766,t:1526929910862};\\\", \\\"{x:1342,y:767,t:1526929910870};\\\", \\\"{x:1342,y:770,t:1526929910886};\\\", \\\"{x:1342,y:772,t:1526929910903};\\\", \\\"{x:1342,y:776,t:1526929910920};\\\", \\\"{x:1341,y:779,t:1526929910936};\\\", \\\"{x:1341,y:784,t:1526929910953};\\\", \\\"{x:1339,y:787,t:1526929910970};\\\", \\\"{x:1337,y:794,t:1526929910987};\\\", \\\"{x:1334,y:800,t:1526929911003};\\\", \\\"{x:1331,y:808,t:1526929911020};\\\", \\\"{x:1329,y:817,t:1526929911037};\\\", \\\"{x:1326,y:826,t:1526929911053};\\\", \\\"{x:1323,y:840,t:1526929911069};\\\", \\\"{x:1319,y:853,t:1526929911086};\\\", \\\"{x:1318,y:865,t:1526929911103};\\\", \\\"{x:1316,y:875,t:1526929911120};\\\", \\\"{x:1316,y:887,t:1526929911137};\\\", \\\"{x:1316,y:898,t:1526929911153};\\\", \\\"{x:1316,y:911,t:1526929911170};\\\", \\\"{x:1316,y:919,t:1526929911187};\\\", \\\"{x:1315,y:927,t:1526929911203};\\\", \\\"{x:1315,y:931,t:1526929911220};\\\", \\\"{x:1315,y:936,t:1526929911237};\\\", \\\"{x:1315,y:939,t:1526929911253};\\\", \\\"{x:1314,y:946,t:1526929911270};\\\", \\\"{x:1314,y:950,t:1526929911287};\\\", \\\"{x:1313,y:952,t:1526929911303};\\\", \\\"{x:1312,y:954,t:1526929911321};\\\", \\\"{x:1312,y:957,t:1526929911337};\\\", \\\"{x:1312,y:959,t:1526929911354};\\\", \\\"{x:1312,y:963,t:1526929911371};\\\", \\\"{x:1312,y:965,t:1526929911387};\\\", \\\"{x:1311,y:967,t:1526929911404};\\\", \\\"{x:1311,y:969,t:1526929911420};\\\", \\\"{x:1314,y:962,t:1526929912567};\\\", \\\"{x:1317,y:958,t:1526929912574};\\\", \\\"{x:1318,y:955,t:1526929912589};\\\", \\\"{x:1319,y:950,t:1526929912605};\\\", \\\"{x:1321,y:948,t:1526929912622};\\\", \\\"{x:1321,y:947,t:1526929912639};\\\", \\\"{x:1321,y:948,t:1526929912967};\\\", \\\"{x:1321,y:949,t:1526929912975};\\\", \\\"{x:1321,y:951,t:1526929912989};\\\", \\\"{x:1321,y:953,t:1526929913005};\\\", \\\"{x:1321,y:954,t:1526929913022};\\\", \\\"{x:1320,y:954,t:1526929913687};\\\", \\\"{x:1318,y:951,t:1526929913694};\\\", \\\"{x:1317,y:950,t:1526929913706};\\\", \\\"{x:1314,y:947,t:1526929913722};\\\", \\\"{x:1312,y:945,t:1526929913739};\\\", \\\"{x:1312,y:944,t:1526929913767};\\\", \\\"{x:1311,y:944,t:1526929913798};\\\", \\\"{x:1311,y:943,t:1526929913959};\\\", \\\"{x:1311,y:942,t:1526929913972};\\\", \\\"{x:1310,y:941,t:1526929913989};\\\", \\\"{x:1309,y:938,t:1526929914006};\\\", \\\"{x:1308,y:936,t:1526929914022};\\\", \\\"{x:1306,y:934,t:1526929914040};\\\", \\\"{x:1304,y:932,t:1526929914055};\\\", \\\"{x:1303,y:930,t:1526929914073};\\\", \\\"{x:1302,y:930,t:1526929914090};\\\", \\\"{x:1301,y:929,t:1526929914105};\\\", \\\"{x:1298,y:926,t:1526929914122};\\\", \\\"{x:1294,y:922,t:1526929914139};\\\", \\\"{x:1288,y:917,t:1526929914156};\\\", \\\"{x:1276,y:906,t:1526929914172};\\\", \\\"{x:1263,y:891,t:1526929914189};\\\", \\\"{x:1234,y:863,t:1526929914206};\\\", \\\"{x:1207,y:841,t:1526929914223};\\\", \\\"{x:1176,y:819,t:1526929914239};\\\", \\\"{x:1157,y:809,t:1526929914256};\\\", \\\"{x:1149,y:805,t:1526929914273};\\\", \\\"{x:1147,y:804,t:1526929914290};\\\", \\\"{x:1148,y:804,t:1526929914367};\\\", \\\"{x:1150,y:805,t:1526929914374};\\\", \\\"{x:1153,y:807,t:1526929914389};\\\", \\\"{x:1159,y:810,t:1526929914406};\\\", \\\"{x:1164,y:811,t:1526929914423};\\\", \\\"{x:1169,y:813,t:1526929914440};\\\", \\\"{x:1177,y:813,t:1526929914457};\\\", \\\"{x:1190,y:812,t:1526929914474};\\\", \\\"{x:1202,y:810,t:1526929914489};\\\", \\\"{x:1211,y:806,t:1526929914507};\\\", \\\"{x:1219,y:805,t:1526929914523};\\\", \\\"{x:1229,y:804,t:1526929914540};\\\", \\\"{x:1242,y:802,t:1526929914556};\\\", \\\"{x:1254,y:800,t:1526929914573};\\\", \\\"{x:1266,y:799,t:1526929914590};\\\", \\\"{x:1271,y:799,t:1526929914607};\\\", \\\"{x:1274,y:799,t:1526929914623};\\\", \\\"{x:1276,y:799,t:1526929914640};\\\", \\\"{x:1280,y:801,t:1526929914656};\\\", \\\"{x:1283,y:802,t:1526929914672};\\\", \\\"{x:1284,y:802,t:1526929914689};\\\", \\\"{x:1287,y:803,t:1526929914706};\\\", \\\"{x:1290,y:804,t:1526929914723};\\\", \\\"{x:1297,y:810,t:1526929914739};\\\", \\\"{x:1312,y:826,t:1526929914756};\\\", \\\"{x:1328,y:850,t:1526929914773};\\\", \\\"{x:1341,y:871,t:1526929914789};\\\", \\\"{x:1359,y:903,t:1526929914805};\\\", \\\"{x:1368,y:917,t:1526929914823};\\\", \\\"{x:1374,y:924,t:1526929914839};\\\", \\\"{x:1375,y:924,t:1526929914856};\\\", \\\"{x:1376,y:924,t:1526929914873};\\\", \\\"{x:1377,y:924,t:1526929914959};\\\", \\\"{x:1377,y:923,t:1526929914991};\\\", \\\"{x:1369,y:918,t:1526929915007};\\\", \\\"{x:1360,y:914,t:1526929915024};\\\", \\\"{x:1355,y:912,t:1526929915040};\\\", \\\"{x:1350,y:909,t:1526929915056};\\\", \\\"{x:1348,y:909,t:1526929915073};\\\", \\\"{x:1348,y:908,t:1526929915091};\\\", \\\"{x:1348,y:907,t:1526929915135};\\\", \\\"{x:1348,y:906,t:1526929915143};\\\", \\\"{x:1348,y:904,t:1526929915156};\\\", \\\"{x:1349,y:898,t:1526929915174};\\\", \\\"{x:1350,y:881,t:1526929915192};\\\", \\\"{x:1351,y:866,t:1526929915206};\\\", \\\"{x:1355,y:842,t:1526929915223};\\\", \\\"{x:1360,y:813,t:1526929915241};\\\", \\\"{x:1361,y:782,t:1526929915256};\\\", \\\"{x:1366,y:757,t:1526929915274};\\\", \\\"{x:1368,y:742,t:1526929915290};\\\", \\\"{x:1368,y:732,t:1526929915308};\\\", \\\"{x:1368,y:718,t:1526929915324};\\\", \\\"{x:1372,y:708,t:1526929915341};\\\", \\\"{x:1373,y:700,t:1526929915357};\\\", \\\"{x:1376,y:695,t:1526929915374};\\\", \\\"{x:1377,y:693,t:1526929915391};\\\", \\\"{x:1379,y:695,t:1526929915487};\\\", \\\"{x:1379,y:701,t:1526929915495};\\\", \\\"{x:1379,y:709,t:1526929915507};\\\", \\\"{x:1379,y:718,t:1526929915523};\\\", \\\"{x:1379,y:722,t:1526929915541};\\\", \\\"{x:1379,y:725,t:1526929915558};\\\", \\\"{x:1379,y:727,t:1526929915573};\\\", \\\"{x:1378,y:729,t:1526929915590};\\\", \\\"{x:1378,y:731,t:1526929915607};\\\", \\\"{x:1378,y:732,t:1526929915624};\\\", \\\"{x:1378,y:735,t:1526929915641};\\\", \\\"{x:1378,y:739,t:1526929915657};\\\", \\\"{x:1378,y:746,t:1526929915673};\\\", \\\"{x:1380,y:749,t:1526929915690};\\\", \\\"{x:1381,y:751,t:1526929915707};\\\", \\\"{x:1382,y:752,t:1526929915724};\\\", \\\"{x:1383,y:752,t:1526929915740};\\\", \\\"{x:1383,y:753,t:1526929915991};\\\", \\\"{x:1383,y:757,t:1526929916007};\\\", \\\"{x:1384,y:763,t:1526929916025};\\\", \\\"{x:1384,y:769,t:1526929916041};\\\", \\\"{x:1384,y:776,t:1526929916058};\\\", \\\"{x:1384,y:783,t:1526929916074};\\\", \\\"{x:1384,y:788,t:1526929916091};\\\", \\\"{x:1384,y:790,t:1526929916107};\\\", \\\"{x:1384,y:786,t:1526929916190};\\\", \\\"{x:1384,y:782,t:1526929916198};\\\", \\\"{x:1384,y:777,t:1526929916207};\\\", \\\"{x:1384,y:769,t:1526929916224};\\\", \\\"{x:1383,y:765,t:1526929916242};\\\", \\\"{x:1383,y:763,t:1526929916257};\\\", \\\"{x:1383,y:762,t:1526929916274};\\\", \\\"{x:1383,y:760,t:1526929916291};\\\", \\\"{x:1383,y:759,t:1526929916767};\\\", \\\"{x:1382,y:759,t:1526929916782};\\\", \\\"{x:1381,y:759,t:1526929916887};\\\", \\\"{x:1381,y:760,t:1526929916895};\\\", \\\"{x:1380,y:761,t:1526929916910};\\\", \\\"{x:1380,y:763,t:1526929916926};\\\", \\\"{x:1379,y:763,t:1526929916942};\\\", \\\"{x:1379,y:765,t:1526929916958};\\\", \\\"{x:1379,y:769,t:1526929916975};\\\", \\\"{x:1379,y:770,t:1526929916992};\\\", \\\"{x:1378,y:772,t:1526929917009};\\\", \\\"{x:1378,y:774,t:1526929917025};\\\", \\\"{x:1378,y:775,t:1526929917042};\\\", \\\"{x:1378,y:779,t:1526929917058};\\\", \\\"{x:1378,y:785,t:1526929917075};\\\", \\\"{x:1378,y:794,t:1526929917092};\\\", \\\"{x:1378,y:804,t:1526929917108};\\\", \\\"{x:1378,y:814,t:1526929917126};\\\", \\\"{x:1378,y:826,t:1526929917141};\\\", \\\"{x:1376,y:842,t:1526929917159};\\\", \\\"{x:1376,y:853,t:1526929917174};\\\", \\\"{x:1376,y:863,t:1526929917191};\\\", \\\"{x:1376,y:870,t:1526929917209};\\\", \\\"{x:1376,y:875,t:1526929917225};\\\", \\\"{x:1376,y:880,t:1526929917243};\\\", \\\"{x:1376,y:884,t:1526929917258};\\\", \\\"{x:1375,y:887,t:1526929917275};\\\", \\\"{x:1375,y:891,t:1526929917291};\\\", \\\"{x:1375,y:894,t:1526929917309};\\\", \\\"{x:1374,y:898,t:1526929917326};\\\", \\\"{x:1374,y:901,t:1526929917341};\\\", \\\"{x:1374,y:909,t:1526929917358};\\\", \\\"{x:1374,y:914,t:1526929917375};\\\", \\\"{x:1372,y:918,t:1526929917391};\\\", \\\"{x:1372,y:922,t:1526929917409};\\\", \\\"{x:1370,y:926,t:1526929917426};\\\", \\\"{x:1370,y:930,t:1526929917442};\\\", \\\"{x:1368,y:936,t:1526929917459};\\\", \\\"{x:1367,y:941,t:1526929917476};\\\", \\\"{x:1367,y:945,t:1526929917493};\\\", \\\"{x:1367,y:948,t:1526929917509};\\\", \\\"{x:1366,y:952,t:1526929917526};\\\", \\\"{x:1366,y:958,t:1526929917543};\\\", \\\"{x:1366,y:960,t:1526929917558};\\\", \\\"{x:1366,y:961,t:1526929917576};\\\", \\\"{x:1366,y:962,t:1526929917593};\\\", \\\"{x:1366,y:964,t:1526929917609};\\\", \\\"{x:1366,y:965,t:1526929917626};\\\", \\\"{x:1366,y:966,t:1526929917646};\\\", \\\"{x:1367,y:966,t:1526929918479};\\\", \\\"{x:1369,y:966,t:1526929918493};\\\", \\\"{x:1376,y:966,t:1526929918509};\\\", \\\"{x:1382,y:966,t:1526929918527};\\\", \\\"{x:1384,y:966,t:1526929918543};\\\", \\\"{x:1385,y:966,t:1526929918566};\\\", \\\"{x:1386,y:966,t:1526929919294};\\\", \\\"{x:1386,y:956,t:1526929919311};\\\", \\\"{x:1386,y:941,t:1526929919327};\\\", \\\"{x:1386,y:910,t:1526929919343};\\\", \\\"{x:1388,y:832,t:1526929919361};\\\", \\\"{x:1396,y:722,t:1526929919377};\\\", \\\"{x:1406,y:615,t:1526929919393};\\\", \\\"{x:1421,y:523,t:1526929919410};\\\", \\\"{x:1430,y:461,t:1526929919427};\\\", \\\"{x:1433,y:433,t:1526929919444};\\\", \\\"{x:1437,y:417,t:1526929919461};\\\", \\\"{x:1441,y:408,t:1526929919477};\\\", \\\"{x:1442,y:406,t:1526929919494};\\\", \\\"{x:1442,y:405,t:1526929919511};\\\", \\\"{x:1442,y:404,t:1526929919527};\\\", \\\"{x:1442,y:402,t:1526929919544};\\\", \\\"{x:1440,y:401,t:1526929919561};\\\", \\\"{x:1438,y:400,t:1526929919577};\\\", \\\"{x:1431,y:402,t:1526929919594};\\\", \\\"{x:1415,y:424,t:1526929919611};\\\", \\\"{x:1403,y:451,t:1526929919627};\\\", \\\"{x:1394,y:476,t:1526929919644};\\\", \\\"{x:1387,y:503,t:1526929919660};\\\", \\\"{x:1382,y:529,t:1526929919678};\\\", \\\"{x:1381,y:552,t:1526929919693};\\\", \\\"{x:1381,y:581,t:1526929919711};\\\", \\\"{x:1381,y:587,t:1526929919728};\\\", \\\"{x:1381,y:589,t:1526929919744};\\\", \\\"{x:1381,y:590,t:1526929919790};\\\", \\\"{x:1383,y:590,t:1526929919927};\\\", \\\"{x:1386,y:588,t:1526929919944};\\\", \\\"{x:1392,y:584,t:1526929919961};\\\", \\\"{x:1396,y:580,t:1526929919978};\\\", \\\"{x:1403,y:577,t:1526929919994};\\\", \\\"{x:1406,y:574,t:1526929920010};\\\", \\\"{x:1407,y:573,t:1526929920191};\\\", \\\"{x:1407,y:572,t:1526929920199};\\\", \\\"{x:1409,y:570,t:1526929920861};\\\", \\\"{x:1411,y:569,t:1526929920877};\\\", \\\"{x:1412,y:569,t:1526929921054};\\\", \\\"{x:1413,y:569,t:1526929921070};\\\", \\\"{x:1414,y:572,t:1526929921078};\\\", \\\"{x:1415,y:579,t:1526929921094};\\\", \\\"{x:1415,y:581,t:1526929921111};\\\", \\\"{x:1416,y:583,t:1526929921129};\\\", \\\"{x:1416,y:584,t:1526929921175};\\\", \\\"{x:1416,y:585,t:1526929921335};\\\", \\\"{x:1417,y:584,t:1526929921399};\\\", \\\"{x:1417,y:578,t:1526929921412};\\\", \\\"{x:1417,y:570,t:1526929921428};\\\", \\\"{x:1417,y:566,t:1526929921446};\\\", \\\"{x:1417,y:563,t:1526929921461};\\\", \\\"{x:1417,y:559,t:1526929921478};\\\", \\\"{x:1417,y:560,t:1526929921766};\\\", \\\"{x:1417,y:563,t:1526929921779};\\\", \\\"{x:1417,y:567,t:1526929921795};\\\", \\\"{x:1418,y:570,t:1526929921813};\\\", \\\"{x:1419,y:571,t:1526929921829};\\\", \\\"{x:1419,y:572,t:1526929921895};\\\", \\\"{x:1420,y:573,t:1526929921935};\\\", \\\"{x:1420,y:574,t:1526929921983};\\\", \\\"{x:1420,y:576,t:1526929922031};\\\", \\\"{x:1420,y:577,t:1526929922053};\\\", \\\"{x:1420,y:579,t:1526929922070};\\\", \\\"{x:1420,y:580,t:1526929922085};\\\", \\\"{x:1420,y:582,t:1526929922110};\\\", \\\"{x:1420,y:583,t:1526929922117};\\\", \\\"{x:1420,y:584,t:1526929922128};\\\", \\\"{x:1420,y:587,t:1526929922146};\\\", \\\"{x:1420,y:593,t:1526929922162};\\\", \\\"{x:1418,y:602,t:1526929922178};\\\", \\\"{x:1417,y:613,t:1526929922195};\\\", \\\"{x:1417,y:627,t:1526929922212};\\\", \\\"{x:1414,y:641,t:1526929922228};\\\", \\\"{x:1414,y:657,t:1526929922246};\\\", \\\"{x:1414,y:686,t:1526929922261};\\\", \\\"{x:1414,y:698,t:1526929922278};\\\", \\\"{x:1414,y:715,t:1526929922296};\\\", \\\"{x:1414,y:730,t:1526929922312};\\\", \\\"{x:1414,y:744,t:1526929922329};\\\", \\\"{x:1414,y:754,t:1526929922346};\\\", \\\"{x:1414,y:761,t:1526929922362};\\\", \\\"{x:1414,y:768,t:1526929922380};\\\", \\\"{x:1414,y:773,t:1526929922395};\\\", \\\"{x:1414,y:780,t:1526929922412};\\\", \\\"{x:1414,y:784,t:1526929922429};\\\", \\\"{x:1414,y:790,t:1526929922446};\\\", \\\"{x:1415,y:801,t:1526929922461};\\\", \\\"{x:1417,y:809,t:1526929922479};\\\", \\\"{x:1418,y:816,t:1526929922495};\\\", \\\"{x:1420,y:824,t:1526929922513};\\\", \\\"{x:1421,y:830,t:1526929922529};\\\", \\\"{x:1422,y:840,t:1526929922545};\\\", \\\"{x:1422,y:845,t:1526929922562};\\\", \\\"{x:1422,y:852,t:1526929922579};\\\", \\\"{x:1422,y:858,t:1526929922595};\\\", \\\"{x:1422,y:863,t:1526929922613};\\\", \\\"{x:1422,y:868,t:1526929922630};\\\", \\\"{x:1422,y:874,t:1526929922645};\\\", \\\"{x:1422,y:880,t:1526929922663};\\\", \\\"{x:1422,y:883,t:1526929922680};\\\", \\\"{x:1422,y:886,t:1526929922696};\\\", \\\"{x:1422,y:891,t:1526929922713};\\\", \\\"{x:1422,y:896,t:1526929922730};\\\", \\\"{x:1422,y:901,t:1526929922746};\\\", \\\"{x:1422,y:905,t:1526929922763};\\\", \\\"{x:1422,y:908,t:1526929922779};\\\", \\\"{x:1422,y:909,t:1526929922796};\\\", \\\"{x:1422,y:910,t:1526929923239};\\\", \\\"{x:1420,y:909,t:1526929923247};\\\", \\\"{x:1417,y:907,t:1526929923264};\\\", \\\"{x:1407,y:903,t:1526929923280};\\\", \\\"{x:1403,y:902,t:1526929923297};\\\", \\\"{x:1396,y:900,t:1526929923314};\\\", \\\"{x:1391,y:900,t:1526929923330};\\\", \\\"{x:1384,y:900,t:1526929923346};\\\", \\\"{x:1377,y:900,t:1526929923364};\\\", \\\"{x:1367,y:901,t:1526929923379};\\\", \\\"{x:1354,y:906,t:1526929923397};\\\", \\\"{x:1340,y:912,t:1526929923414};\\\", \\\"{x:1322,y:918,t:1526929923430};\\\", \\\"{x:1314,y:922,t:1526929923447};\\\", \\\"{x:1312,y:924,t:1526929923464};\\\", \\\"{x:1313,y:925,t:1526929923543};\\\", \\\"{x:1313,y:926,t:1526929923558};\\\", \\\"{x:1315,y:926,t:1526929923566};\\\", \\\"{x:1317,y:927,t:1526929923579};\\\", \\\"{x:1318,y:928,t:1526929923597};\\\", \\\"{x:1319,y:928,t:1526929923663};\\\", \\\"{x:1321,y:928,t:1526929923681};\\\", \\\"{x:1323,y:928,t:1526929923697};\\\", \\\"{x:1325,y:929,t:1526929923714};\\\", \\\"{x:1329,y:931,t:1526929923730};\\\", \\\"{x:1332,y:932,t:1526929923747};\\\", \\\"{x:1340,y:933,t:1526929923765};\\\", \\\"{x:1355,y:933,t:1526929923781};\\\", \\\"{x:1379,y:930,t:1526929923797};\\\", \\\"{x:1423,y:930,t:1526929923814};\\\", \\\"{x:1499,y:930,t:1526929923831};\\\", \\\"{x:1535,y:930,t:1526929923846};\\\", \\\"{x:1567,y:930,t:1526929923864};\\\", \\\"{x:1597,y:930,t:1526929923881};\\\", \\\"{x:1622,y:930,t:1526929923897};\\\", \\\"{x:1636,y:930,t:1526929923914};\\\", \\\"{x:1642,y:930,t:1526929923931};\\\", \\\"{x:1644,y:930,t:1526929923947};\\\", \\\"{x:1645,y:930,t:1526929924030};\\\", \\\"{x:1639,y:940,t:1526929924047};\\\", \\\"{x:1629,y:946,t:1526929924064};\\\", \\\"{x:1615,y:951,t:1526929924081};\\\", \\\"{x:1598,y:955,t:1526929924098};\\\", \\\"{x:1583,y:959,t:1526929924114};\\\", \\\"{x:1568,y:964,t:1526929924131};\\\", \\\"{x:1558,y:966,t:1526929924148};\\\", \\\"{x:1552,y:969,t:1526929924164};\\\", \\\"{x:1547,y:969,t:1526929924181};\\\", \\\"{x:1544,y:968,t:1526929924198};\\\", \\\"{x:1541,y:967,t:1526929924214};\\\", \\\"{x:1539,y:965,t:1526929924231};\\\", \\\"{x:1538,y:965,t:1526929924254};\\\", \\\"{x:1536,y:964,t:1526929924264};\\\", \\\"{x:1534,y:964,t:1526929924286};\\\", \\\"{x:1533,y:962,t:1526929924391};\\\", \\\"{x:1533,y:960,t:1526929924406};\\\", \\\"{x:1533,y:957,t:1526929924414};\\\", \\\"{x:1533,y:954,t:1526929924431};\\\", \\\"{x:1531,y:946,t:1526929924447};\\\", \\\"{x:1530,y:942,t:1526929924463};\\\", \\\"{x:1529,y:936,t:1526929924480};\\\", \\\"{x:1528,y:933,t:1526929924497};\\\", \\\"{x:1528,y:932,t:1526929924514};\\\", \\\"{x:1528,y:931,t:1526929924863};\\\", \\\"{x:1528,y:926,t:1526929924870};\\\", \\\"{x:1528,y:917,t:1526929924881};\\\", \\\"{x:1531,y:903,t:1526929924898};\\\", \\\"{x:1536,y:892,t:1526929924915};\\\", \\\"{x:1539,y:886,t:1526929924931};\\\", \\\"{x:1539,y:884,t:1526929924948};\\\", \\\"{x:1540,y:881,t:1526929924965};\\\", \\\"{x:1540,y:880,t:1526929924983};\\\", \\\"{x:1540,y:879,t:1526929924998};\\\", \\\"{x:1540,y:878,t:1526929925015};\\\", \\\"{x:1542,y:874,t:1526929925127};\\\", \\\"{x:1543,y:863,t:1526929925135};\\\", \\\"{x:1544,y:848,t:1526929925148};\\\", \\\"{x:1557,y:779,t:1526929925165};\\\", \\\"{x:1579,y:603,t:1526929925182};\\\", \\\"{x:1581,y:475,t:1526929925198};\\\", \\\"{x:1581,y:359,t:1526929925215};\\\", \\\"{x:1573,y:271,t:1526929925232};\\\", \\\"{x:1568,y:219,t:1526929925247};\\\", \\\"{x:1568,y:191,t:1526929925265};\\\", \\\"{x:1569,y:175,t:1526929925282};\\\", \\\"{x:1571,y:166,t:1526929925297};\\\", \\\"{x:1573,y:164,t:1526929925314};\\\", \\\"{x:1573,y:163,t:1526929925332};\\\", \\\"{x:1573,y:169,t:1526929925679};\\\", \\\"{x:1572,y:190,t:1526929925687};\\\", \\\"{x:1572,y:221,t:1526929925699};\\\", \\\"{x:1572,y:298,t:1526929925715};\\\", \\\"{x:1572,y:382,t:1526929925733};\\\", \\\"{x:1572,y:471,t:1526929925750};\\\", \\\"{x:1580,y:543,t:1526929925766};\\\", \\\"{x:1595,y:598,t:1526929925783};\\\", \\\"{x:1602,y:609,t:1526929925799};\\\", \\\"{x:1604,y:611,t:1526929925815};\\\", \\\"{x:1606,y:611,t:1526929925958};\\\", \\\"{x:1608,y:605,t:1526929925967};\\\", \\\"{x:1611,y:579,t:1526929925982};\\\", \\\"{x:1616,y:550,t:1526929925999};\\\", \\\"{x:1621,y:509,t:1526929926016};\\\", \\\"{x:1621,y:464,t:1526929926032};\\\", \\\"{x:1621,y:436,t:1526929926049};\\\", \\\"{x:1621,y:428,t:1526929926066};\\\", \\\"{x:1621,y:427,t:1526929926082};\\\", \\\"{x:1621,y:426,t:1526929926099};\\\", \\\"{x:1622,y:431,t:1526929926150};\\\", \\\"{x:1626,y:466,t:1526929926166};\\\", \\\"{x:1626,y:494,t:1526929926182};\\\", \\\"{x:1628,y:614,t:1526929926199};\\\", \\\"{x:1628,y:705,t:1526929926216};\\\", \\\"{x:1632,y:787,t:1526929926232};\\\", \\\"{x:1640,y:856,t:1526929926249};\\\", \\\"{x:1650,y:913,t:1526929926266};\\\", \\\"{x:1652,y:939,t:1526929926283};\\\", \\\"{x:1654,y:949,t:1526929926299};\\\", \\\"{x:1655,y:949,t:1526929926316};\\\", \\\"{x:1655,y:950,t:1526929926333};\\\", \\\"{x:1655,y:951,t:1526929926407};\\\", \\\"{x:1654,y:951,t:1526929926416};\\\", \\\"{x:1626,y:951,t:1526929926433};\\\", \\\"{x:1531,y:955,t:1526929926449};\\\", \\\"{x:1387,y:957,t:1526929926466};\\\", \\\"{x:1193,y:957,t:1526929926483};\\\", \\\"{x:1004,y:970,t:1526929926499};\\\", \\\"{x:849,y:992,t:1526929926516};\\\", \\\"{x:745,y:1012,t:1526929926532};\\\", \\\"{x:690,y:1018,t:1526929926549};\\\", \\\"{x:678,y:1019,t:1526929926565};\\\", \\\"{x:678,y:1013,t:1526929926671};\\\", \\\"{x:681,y:1005,t:1526929926683};\\\", \\\"{x:694,y:986,t:1526929926699};\\\", \\\"{x:715,y:963,t:1526929926716};\\\", \\\"{x:747,y:930,t:1526929926733};\\\", \\\"{x:810,y:892,t:1526929926750};\\\", \\\"{x:858,y:870,t:1526929926766};\\\", \\\"{x:916,y:853,t:1526929926782};\\\", \\\"{x:975,y:843,t:1526929926799};\\\", \\\"{x:1009,y:833,t:1526929926816};\\\", \\\"{x:1032,y:822,t:1526929926832};\\\", \\\"{x:1043,y:815,t:1526929926849};\\\", \\\"{x:1045,y:814,t:1526929926865};\\\", \\\"{x:1045,y:813,t:1526929926886};\\\", \\\"{x:1045,y:811,t:1526929926900};\\\", \\\"{x:1035,y:804,t:1526929926916};\\\", \\\"{x:1017,y:797,t:1526929926933};\\\", \\\"{x:979,y:776,t:1526929926950};\\\", \\\"{x:939,y:755,t:1526929926965};\\\", \\\"{x:892,y:724,t:1526929926983};\\\", \\\"{x:849,y:693,t:1526929927000};\\\", \\\"{x:812,y:673,t:1526929927015};\\\", \\\"{x:768,y:653,t:1526929927033};\\\", \\\"{x:740,y:646,t:1526929927050};\\\", \\\"{x:725,y:641,t:1526929927065};\\\", \\\"{x:721,y:641,t:1526929928296};\\\", \\\"{x:691,y:656,t:1526929928317};\\\", \\\"{x:626,y:689,t:1526929928333};\\\", \\\"{x:566,y:713,t:1526929928349};\\\", \\\"{x:510,y:729,t:1526929928367};\\\", \\\"{x:471,y:741,t:1526929928383};\\\", \\\"{x:461,y:742,t:1526929928399};\\\", \\\"{x:461,y:740,t:1526929928445};\\\", \\\"{x:464,y:738,t:1526929928454};\\\", \\\"{x:467,y:736,t:1526929928466};\\\", \\\"{x:470,y:733,t:1526929928484};\\\", \\\"{x:474,y:730,t:1526929928501};\\\", \\\"{x:476,y:727,t:1526929928516};\\\", \\\"{x:477,y:724,t:1526929928533};\\\", \\\"{x:479,y:722,t:1526929928558};\\\", \\\"{x:479,y:721,t:1526929928582};\\\", \\\"{x:480,y:720,t:1526929928590};\\\", \\\"{x:481,y:720,t:1526929928601};\\\", \\\"{x:481,y:719,t:1526929928617};\\\", \\\"{x:482,y:719,t:1526929928633};\\\", \\\"{x:484,y:719,t:1526929928651};\\\", \\\"{x:486,y:719,t:1526929928668};\\\", \\\"{x:488,y:719,t:1526929928684};\\\", \\\"{x:491,y:719,t:1526929929102};\\\", \\\"{x:520,y:720,t:1526929929117};\\\", \\\"{x:568,y:720,t:1526929929134};\\\", \\\"{x:625,y:718,t:1526929929150};\\\", \\\"{x:688,y:713,t:1526929929168};\\\", \\\"{x:739,y:711,t:1526929929184};\\\", \\\"{x:759,y:711,t:1526929929200};\\\", \\\"{x:767,y:711,t:1526929929218};\\\" ] }, { \\\"rt\\\": 114486, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 368202, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -I -I -O -I -Z -F -F -F -01 PM-02 PM-U -U -F -F -01 PM-H -H -01 PM-H -01 PM-01 PM-I -J -J -J \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:768,y:711,t:1526929943162};\\\", \\\"{x:777,y:711,t:1526929943169};\\\", \\\"{x:797,y:719,t:1526929943183};\\\", \\\"{x:851,y:727,t:1526929943198};\\\", \\\"{x:942,y:727,t:1526929943216};\\\", \\\"{x:1070,y:727,t:1526929943233};\\\", \\\"{x:1208,y:729,t:1526929943248};\\\", \\\"{x:1433,y:731,t:1526929943266};\\\", \\\"{x:1566,y:737,t:1526929943283};\\\", \\\"{x:1672,y:737,t:1526929943298};\\\", \\\"{x:1763,y:737,t:1526929943316};\\\", \\\"{x:1811,y:737,t:1526929943333};\\\", \\\"{x:1844,y:737,t:1526929943349};\\\", \\\"{x:1866,y:737,t:1526929943366};\\\", \\\"{x:1875,y:737,t:1526929943383};\\\", \\\"{x:1879,y:736,t:1526929943398};\\\", \\\"{x:1881,y:736,t:1526929943416};\\\", \\\"{x:1882,y:736,t:1526929943674};\\\", \\\"{x:1880,y:736,t:1526929943907};\\\", \\\"{x:1879,y:736,t:1526929943922};\\\", \\\"{x:1876,y:734,t:1526929943938};\\\", \\\"{x:1875,y:734,t:1526929943950};\\\", \\\"{x:1871,y:733,t:1526929943966};\\\", \\\"{x:1866,y:733,t:1526929943982};\\\", \\\"{x:1859,y:733,t:1526929943999};\\\", \\\"{x:1851,y:733,t:1526929944016};\\\", \\\"{x:1841,y:733,t:1526929944032};\\\", \\\"{x:1819,y:733,t:1526929944050};\\\", \\\"{x:1797,y:733,t:1526929944066};\\\", \\\"{x:1773,y:733,t:1526929944083};\\\", \\\"{x:1734,y:738,t:1526929944099};\\\", \\\"{x:1658,y:753,t:1526929944116};\\\", \\\"{x:1564,y:776,t:1526929944132};\\\", \\\"{x:1459,y:806,t:1526929944150};\\\", \\\"{x:1376,y:831,t:1526929944167};\\\", \\\"{x:1322,y:840,t:1526929944182};\\\", \\\"{x:1269,y:848,t:1526929944200};\\\", \\\"{x:1246,y:853,t:1526929944216};\\\", \\\"{x:1230,y:854,t:1526929944233};\\\", \\\"{x:1223,y:854,t:1526929944250};\\\", \\\"{x:1222,y:854,t:1526929944267};\\\", \\\"{x:1220,y:855,t:1526929944290};\\\", \\\"{x:1217,y:856,t:1526929944299};\\\", \\\"{x:1211,y:857,t:1526929944316};\\\", \\\"{x:1203,y:860,t:1526929944333};\\\", \\\"{x:1196,y:862,t:1526929944349};\\\", \\\"{x:1192,y:863,t:1526929944367};\\\", \\\"{x:1191,y:863,t:1526929944382};\\\", \\\"{x:1190,y:863,t:1526929944491};\\\", \\\"{x:1190,y:865,t:1526929944500};\\\", \\\"{x:1206,y:879,t:1526929944517};\\\", \\\"{x:1237,y:894,t:1526929944533};\\\", \\\"{x:1268,y:904,t:1526929944550};\\\", \\\"{x:1309,y:919,t:1526929944566};\\\", \\\"{x:1359,y:933,t:1526929944584};\\\", \\\"{x:1405,y:942,t:1526929944599};\\\", \\\"{x:1432,y:948,t:1526929944617};\\\", \\\"{x:1448,y:950,t:1526929944634};\\\", \\\"{x:1451,y:950,t:1526929944649};\\\", \\\"{x:1452,y:949,t:1526929944723};\\\", \\\"{x:1452,y:945,t:1526929944734};\\\", \\\"{x:1452,y:925,t:1526929944749};\\\", \\\"{x:1452,y:881,t:1526929944766};\\\", \\\"{x:1452,y:814,t:1526929944783};\\\", \\\"{x:1454,y:752,t:1526929944799};\\\", \\\"{x:1457,y:687,t:1526929944817};\\\", \\\"{x:1457,y:546,t:1526929944834};\\\", \\\"{x:1457,y:446,t:1526929944850};\\\", \\\"{x:1456,y:365,t:1526929944866};\\\", \\\"{x:1434,y:320,t:1526929944884};\\\", \\\"{x:1418,y:298,t:1526929944900};\\\", \\\"{x:1409,y:291,t:1526929944917};\\\", \\\"{x:1409,y:290,t:1526929944934};\\\", \\\"{x:1408,y:290,t:1526929944951};\\\", \\\"{x:1405,y:291,t:1526929944970};\\\", \\\"{x:1397,y:303,t:1526929944984};\\\", \\\"{x:1374,y:340,t:1526929945001};\\\", \\\"{x:1346,y:394,t:1526929945017};\\\", \\\"{x:1302,y:484,t:1526929945034};\\\", \\\"{x:1282,y:529,t:1526929945050};\\\", \\\"{x:1273,y:550,t:1526929945066};\\\", \\\"{x:1269,y:559,t:1526929945084};\\\", \\\"{x:1269,y:560,t:1526929945100};\\\", \\\"{x:1269,y:561,t:1526929945171};\\\", \\\"{x:1269,y:562,t:1526929945186};\\\", \\\"{x:1269,y:563,t:1526929945202};\\\", \\\"{x:1271,y:564,t:1526929945217};\\\", \\\"{x:1279,y:564,t:1526929945234};\\\", \\\"{x:1286,y:560,t:1526929945250};\\\", \\\"{x:1289,y:554,t:1526929945267};\\\", \\\"{x:1291,y:548,t:1526929945284};\\\", \\\"{x:1293,y:546,t:1526929945301};\\\", \\\"{x:1293,y:543,t:1526929945317};\\\", \\\"{x:1294,y:541,t:1526929945333};\\\", \\\"{x:1294,y:540,t:1526929945350};\\\", \\\"{x:1294,y:539,t:1526929945378};\\\", \\\"{x:1295,y:538,t:1526929945386};\\\", \\\"{x:1295,y:537,t:1526929945400};\\\", \\\"{x:1295,y:533,t:1526929945418};\\\", \\\"{x:1295,y:531,t:1526929945434};\\\", \\\"{x:1295,y:530,t:1526929945451};\\\", \\\"{x:1295,y:528,t:1526929945467};\\\", \\\"{x:1295,y:527,t:1526929945483};\\\", \\\"{x:1295,y:525,t:1526929945506};\\\", \\\"{x:1296,y:525,t:1526929945517};\\\", \\\"{x:1296,y:524,t:1526929945534};\\\", \\\"{x:1297,y:522,t:1526929945551};\\\", \\\"{x:1298,y:520,t:1526929945568};\\\", \\\"{x:1299,y:519,t:1526929945584};\\\", \\\"{x:1300,y:518,t:1526929945600};\\\", \\\"{x:1302,y:515,t:1526929945618};\\\", \\\"{x:1306,y:510,t:1526929945634};\\\", \\\"{x:1307,y:507,t:1526929945651};\\\", \\\"{x:1308,y:506,t:1526929945668};\\\", \\\"{x:1310,y:505,t:1526929945684};\\\", \\\"{x:1310,y:504,t:1526929945701};\\\", \\\"{x:1311,y:502,t:1526929945718};\\\", \\\"{x:1311,y:501,t:1526929945740};\\\", \\\"{x:1312,y:501,t:1526929945750};\\\", \\\"{x:1312,y:504,t:1526929946995};\\\", \\\"{x:1312,y:509,t:1526929947002};\\\", \\\"{x:1312,y:522,t:1526929947018};\\\", \\\"{x:1311,y:533,t:1526929947034};\\\", \\\"{x:1311,y:541,t:1526929947051};\\\", \\\"{x:1311,y:548,t:1526929947068};\\\", \\\"{x:1311,y:554,t:1526929947084};\\\", \\\"{x:1311,y:558,t:1526929947102};\\\", \\\"{x:1311,y:563,t:1526929947118};\\\", \\\"{x:1311,y:565,t:1526929947134};\\\", \\\"{x:1311,y:567,t:1526929947151};\\\", \\\"{x:1311,y:570,t:1526929947168};\\\", \\\"{x:1311,y:571,t:1526929947185};\\\", \\\"{x:1311,y:572,t:1526929947210};\\\", \\\"{x:1311,y:573,t:1526929947218};\\\", \\\"{x:1311,y:575,t:1526929947235};\\\", \\\"{x:1311,y:580,t:1526929947252};\\\", \\\"{x:1311,y:587,t:1526929947269};\\\", \\\"{x:1311,y:594,t:1526929947285};\\\", \\\"{x:1311,y:599,t:1526929947301};\\\", \\\"{x:1311,y:603,t:1526929947319};\\\", \\\"{x:1312,y:606,t:1526929947335};\\\", \\\"{x:1312,y:610,t:1526929947352};\\\", \\\"{x:1312,y:611,t:1526929947368};\\\", \\\"{x:1312,y:612,t:1526929947385};\\\", \\\"{x:1312,y:613,t:1526929947402};\\\", \\\"{x:1312,y:614,t:1526929947434};\\\", \\\"{x:1312,y:615,t:1526929947442};\\\", \\\"{x:1312,y:616,t:1526929947451};\\\", \\\"{x:1312,y:617,t:1526929947474};\\\", \\\"{x:1312,y:618,t:1526929947486};\\\", \\\"{x:1312,y:619,t:1526929947501};\\\", \\\"{x:1312,y:620,t:1526929947517};\\\", \\\"{x:1312,y:622,t:1526929947534};\\\", \\\"{x:1312,y:625,t:1526929947552};\\\", \\\"{x:1312,y:630,t:1526929947568};\\\", \\\"{x:1312,y:636,t:1526929947584};\\\", \\\"{x:1312,y:640,t:1526929947601};\\\", \\\"{x:1313,y:645,t:1526929947618};\\\", \\\"{x:1313,y:652,t:1526929947636};\\\", \\\"{x:1313,y:658,t:1526929947651};\\\", \\\"{x:1313,y:663,t:1526929947669};\\\", \\\"{x:1313,y:667,t:1526929947685};\\\", \\\"{x:1313,y:668,t:1526929947702};\\\", \\\"{x:1313,y:670,t:1526929947718};\\\", \\\"{x:1313,y:674,t:1526929947735};\\\", \\\"{x:1313,y:676,t:1526929947752};\\\", \\\"{x:1313,y:679,t:1526929947769};\\\", \\\"{x:1313,y:682,t:1526929947786};\\\", \\\"{x:1313,y:683,t:1526929947802};\\\", \\\"{x:1313,y:684,t:1526929947850};\\\", \\\"{x:1313,y:686,t:1526929947866};\\\", \\\"{x:1313,y:687,t:1526929947874};\\\", \\\"{x:1313,y:690,t:1526929947886};\\\", \\\"{x:1312,y:696,t:1526929947903};\\\", \\\"{x:1312,y:703,t:1526929947919};\\\", \\\"{x:1312,y:709,t:1526929947936};\\\", \\\"{x:1312,y:713,t:1526929947953};\\\", \\\"{x:1312,y:722,t:1526929947968};\\\", \\\"{x:1312,y:740,t:1526929947985};\\\", \\\"{x:1312,y:755,t:1526929948002};\\\", \\\"{x:1311,y:766,t:1526929948018};\\\", \\\"{x:1311,y:772,t:1526929948036};\\\", \\\"{x:1311,y:774,t:1526929948053};\\\", \\\"{x:1311,y:776,t:1526929948069};\\\", \\\"{x:1311,y:780,t:1526929948086};\\\", \\\"{x:1311,y:787,t:1526929948103};\\\", \\\"{x:1310,y:792,t:1526929948118};\\\", \\\"{x:1308,y:802,t:1526929948136};\\\", \\\"{x:1307,y:816,t:1526929948153};\\\", \\\"{x:1306,y:830,t:1526929948169};\\\", \\\"{x:1303,y:848,t:1526929948186};\\\", \\\"{x:1302,y:856,t:1526929948203};\\\", \\\"{x:1302,y:870,t:1526929948219};\\\", \\\"{x:1302,y:887,t:1526929948236};\\\", \\\"{x:1302,y:902,t:1526929948253};\\\", \\\"{x:1301,y:918,t:1526929948270};\\\", \\\"{x:1301,y:932,t:1526929948286};\\\", \\\"{x:1301,y:944,t:1526929948303};\\\", \\\"{x:1301,y:956,t:1526929948320};\\\", \\\"{x:1301,y:967,t:1526929948335};\\\", \\\"{x:1302,y:979,t:1526929948353};\\\", \\\"{x:1304,y:987,t:1526929948369};\\\", \\\"{x:1304,y:993,t:1526929948386};\\\", \\\"{x:1305,y:993,t:1526929948402};\\\", \\\"{x:1306,y:994,t:1526929948420};\\\", \\\"{x:1307,y:993,t:1526929948530};\\\", \\\"{x:1308,y:992,t:1526929948537};\\\", \\\"{x:1309,y:987,t:1526929948553};\\\", \\\"{x:1311,y:985,t:1526929948569};\\\", \\\"{x:1311,y:984,t:1526929948658};\\\", \\\"{x:1311,y:982,t:1526929948670};\\\", \\\"{x:1311,y:981,t:1526929948685};\\\", \\\"{x:1311,y:980,t:1526929948703};\\\", \\\"{x:1311,y:979,t:1526929948802};\\\", \\\"{x:1311,y:978,t:1526929948859};\\\", \\\"{x:1311,y:977,t:1526929948870};\\\", \\\"{x:1311,y:975,t:1526929948886};\\\", \\\"{x:1311,y:974,t:1526929948903};\\\", \\\"{x:1312,y:973,t:1526929948920};\\\", \\\"{x:1313,y:972,t:1526929948938};\\\", \\\"{x:1313,y:971,t:1526929948962};\\\", \\\"{x:1314,y:969,t:1526929948970};\\\", \\\"{x:1314,y:968,t:1526929948986};\\\", \\\"{x:1314,y:967,t:1526929949003};\\\", \\\"{x:1314,y:966,t:1526929949138};\\\", \\\"{x:1314,y:963,t:1526929949170};\\\", \\\"{x:1317,y:927,t:1526929949187};\\\", \\\"{x:1321,y:823,t:1526929949204};\\\", \\\"{x:1330,y:670,t:1526929949219};\\\", \\\"{x:1339,y:498,t:1526929949237};\\\", \\\"{x:1356,y:341,t:1526929949253};\\\", \\\"{x:1373,y:221,t:1526929949269};\\\", \\\"{x:1376,y:164,t:1526929949287};\\\", \\\"{x:1376,y:140,t:1526929949304};\\\", \\\"{x:1376,y:132,t:1526929949320};\\\", \\\"{x:1376,y:131,t:1526929949336};\\\", \\\"{x:1374,y:141,t:1526929949435};\\\", \\\"{x:1370,y:159,t:1526929949441};\\\", \\\"{x:1361,y:194,t:1526929949454};\\\", \\\"{x:1338,y:277,t:1526929949469};\\\", \\\"{x:1327,y:337,t:1526929949487};\\\", \\\"{x:1318,y:378,t:1526929949504};\\\", \\\"{x:1313,y:400,t:1526929949519};\\\", \\\"{x:1310,y:408,t:1526929949537};\\\", \\\"{x:1309,y:412,t:1526929949553};\\\", \\\"{x:1309,y:413,t:1526929949594};\\\", \\\"{x:1309,y:417,t:1526929949851};\\\", \\\"{x:1311,y:430,t:1526929949858};\\\", \\\"{x:1311,y:453,t:1526929949871};\\\", \\\"{x:1314,y:484,t:1526929949887};\\\", \\\"{x:1318,y:501,t:1526929949905};\\\", \\\"{x:1325,y:502,t:1526929949921};\\\", \\\"{x:1325,y:503,t:1526929950554};\\\", \\\"{x:1322,y:503,t:1526929950571};\\\", \\\"{x:1320,y:502,t:1526929950588};\\\", \\\"{x:1319,y:501,t:1526929950604};\\\", \\\"{x:1317,y:501,t:1526929951139};\\\", \\\"{x:1312,y:499,t:1526929951155};\\\", \\\"{x:1311,y:498,t:1526929951171};\\\", \\\"{x:1309,y:498,t:1526929951187};\\\", \\\"{x:1310,y:498,t:1526929960849};\\\", \\\"{x:1312,y:498,t:1526929960861};\\\", \\\"{x:1314,y:498,t:1526929960881};\\\", \\\"{x:1315,y:498,t:1526929965066};\\\", \\\"{x:1316,y:501,t:1526929965082};\\\", \\\"{x:1317,y:501,t:1526929965801};\\\", \\\"{x:1318,y:501,t:1526929966386};\\\", \\\"{x:1318,y:502,t:1526929966401};\\\", \\\"{x:1319,y:503,t:1526929966416};\\\", \\\"{x:1321,y:504,t:1526929966433};\\\", \\\"{x:1322,y:505,t:1526929966450};\\\", \\\"{x:1322,y:506,t:1526929966682};\\\", \\\"{x:1322,y:507,t:1526929967666};\\\", \\\"{x:1323,y:510,t:1526929967683};\\\", \\\"{x:1323,y:524,t:1526929967700};\\\", \\\"{x:1316,y:558,t:1526929967716};\\\", \\\"{x:1300,y:606,t:1526929967734};\\\", \\\"{x:1289,y:644,t:1526929967750};\\\", \\\"{x:1284,y:665,t:1526929967768};\\\", \\\"{x:1282,y:678,t:1526929967784};\\\", \\\"{x:1280,y:683,t:1526929967801};\\\", \\\"{x:1279,y:690,t:1526929967817};\\\", \\\"{x:1279,y:694,t:1526929967834};\\\", \\\"{x:1279,y:697,t:1526929967851};\\\", \\\"{x:1280,y:698,t:1526929967867};\\\", \\\"{x:1279,y:699,t:1526929968170};\\\", \\\"{x:1279,y:700,t:1526929968226};\\\", \\\"{x:1279,y:703,t:1526929968234};\\\", \\\"{x:1279,y:710,t:1526929968250};\\\", \\\"{x:1278,y:713,t:1526929968267};\\\", \\\"{x:1278,y:714,t:1526929968370};\\\", \\\"{x:1280,y:712,t:1526929968384};\\\", \\\"{x:1287,y:699,t:1526929968400};\\\", \\\"{x:1302,y:675,t:1526929968417};\\\", \\\"{x:1314,y:657,t:1526929968434};\\\", \\\"{x:1328,y:638,t:1526929968451};\\\", \\\"{x:1340,y:618,t:1526929968468};\\\", \\\"{x:1348,y:599,t:1526929968484};\\\", \\\"{x:1351,y:586,t:1526929968501};\\\", \\\"{x:1355,y:573,t:1526929968517};\\\", \\\"{x:1356,y:563,t:1526929968535};\\\", \\\"{x:1356,y:554,t:1526929968551};\\\", \\\"{x:1356,y:547,t:1526929968567};\\\", \\\"{x:1356,y:540,t:1526929968585};\\\", \\\"{x:1356,y:532,t:1526929968601};\\\", \\\"{x:1354,y:521,t:1526929968617};\\\", \\\"{x:1351,y:513,t:1526929968635};\\\", \\\"{x:1350,y:505,t:1526929968651};\\\", \\\"{x:1347,y:500,t:1526929968668};\\\", \\\"{x:1345,y:497,t:1526929968685};\\\", \\\"{x:1340,y:493,t:1526929968701};\\\", \\\"{x:1337,y:491,t:1526929968718};\\\", \\\"{x:1332,y:488,t:1526929968734};\\\", \\\"{x:1327,y:485,t:1526929968752};\\\", \\\"{x:1324,y:484,t:1526929968767};\\\", \\\"{x:1320,y:482,t:1526929968784};\\\", \\\"{x:1319,y:482,t:1526929968801};\\\", \\\"{x:1318,y:482,t:1526929969210};\\\", \\\"{x:1318,y:483,t:1526929969233};\\\", \\\"{x:1321,y:483,t:1526929969252};\\\", \\\"{x:1322,y:484,t:1526929969269};\\\", \\\"{x:1324,y:485,t:1526929969284};\\\", \\\"{x:1326,y:486,t:1526929969302};\\\", \\\"{x:1328,y:487,t:1526929969319};\\\", \\\"{x:1330,y:489,t:1526929969334};\\\", \\\"{x:1331,y:489,t:1526929969362};\\\", \\\"{x:1331,y:491,t:1526929969410};\\\", \\\"{x:1331,y:492,t:1526929969418};\\\", \\\"{x:1329,y:495,t:1526929969435};\\\", \\\"{x:1324,y:502,t:1526929969452};\\\", \\\"{x:1320,y:509,t:1526929969468};\\\", \\\"{x:1316,y:517,t:1526929969485};\\\", \\\"{x:1312,y:533,t:1526929969501};\\\", \\\"{x:1312,y:555,t:1526929969518};\\\", \\\"{x:1312,y:582,t:1526929969535};\\\", \\\"{x:1314,y:623,t:1526929969552};\\\", \\\"{x:1321,y:658,t:1526929969568};\\\", \\\"{x:1327,y:682,t:1526929969584};\\\", \\\"{x:1335,y:695,t:1526929969601};\\\", \\\"{x:1335,y:696,t:1526929969618};\\\", \\\"{x:1336,y:696,t:1526929969746};\\\", \\\"{x:1336,y:695,t:1526929969770};\\\", \\\"{x:1339,y:686,t:1526929969785};\\\", \\\"{x:1342,y:678,t:1526929969801};\\\", \\\"{x:1345,y:666,t:1526929969819};\\\", \\\"{x:1350,y:652,t:1526929969835};\\\", \\\"{x:1365,y:623,t:1526929969852};\\\", \\\"{x:1391,y:579,t:1526929969868};\\\", \\\"{x:1432,y:530,t:1526929969886};\\\", \\\"{x:1458,y:506,t:1526929969902};\\\", \\\"{x:1487,y:483,t:1526929969918};\\\", \\\"{x:1503,y:470,t:1526929969936};\\\", \\\"{x:1512,y:463,t:1526929969951};\\\", \\\"{x:1512,y:461,t:1526929970152};\\\", \\\"{x:1511,y:461,t:1526929970168};\\\", \\\"{x:1508,y:460,t:1526929970185};\\\", \\\"{x:1505,y:458,t:1526929970202};\\\", \\\"{x:1503,y:458,t:1526929970218};\\\", \\\"{x:1501,y:456,t:1526929970235};\\\", \\\"{x:1500,y:456,t:1526929970252};\\\", \\\"{x:1499,y:456,t:1526929970281};\\\", \\\"{x:1498,y:456,t:1526929970289};\\\", \\\"{x:1498,y:455,t:1526929970302};\\\", \\\"{x:1497,y:455,t:1526929970318};\\\", \\\"{x:1496,y:455,t:1526929970335};\\\", \\\"{x:1494,y:453,t:1526929970352};\\\", \\\"{x:1491,y:453,t:1526929970368};\\\", \\\"{x:1486,y:450,t:1526929970385};\\\", \\\"{x:1478,y:450,t:1526929970402};\\\", \\\"{x:1474,y:449,t:1526929970418};\\\", \\\"{x:1465,y:449,t:1526929970435};\\\", \\\"{x:1460,y:449,t:1526929970452};\\\", \\\"{x:1453,y:450,t:1526929970468};\\\", \\\"{x:1449,y:450,t:1526929970485};\\\", \\\"{x:1447,y:450,t:1526929970502};\\\", \\\"{x:1446,y:451,t:1526929970518};\\\", \\\"{x:1444,y:452,t:1526929970546};\\\", \\\"{x:1443,y:453,t:1526929970562};\\\", \\\"{x:1441,y:453,t:1526929970569};\\\", \\\"{x:1436,y:456,t:1526929970585};\\\", \\\"{x:1431,y:458,t:1526929970602};\\\", \\\"{x:1424,y:462,t:1526929970619};\\\", \\\"{x:1417,y:465,t:1526929970635};\\\", \\\"{x:1410,y:469,t:1526929970653};\\\", \\\"{x:1404,y:473,t:1526929970669};\\\", \\\"{x:1397,y:477,t:1526929970685};\\\", \\\"{x:1387,y:482,t:1526929970703};\\\", \\\"{x:1376,y:487,t:1526929970719};\\\", \\\"{x:1371,y:489,t:1526929970736};\\\", \\\"{x:1365,y:492,t:1526929970752};\\\", \\\"{x:1358,y:493,t:1526929970770};\\\", \\\"{x:1352,y:495,t:1526929970786};\\\", \\\"{x:1346,y:496,t:1526929970802};\\\", \\\"{x:1339,y:496,t:1526929970819};\\\", \\\"{x:1329,y:500,t:1526929970836};\\\", \\\"{x:1324,y:501,t:1526929970852};\\\", \\\"{x:1319,y:501,t:1526929970869};\\\", \\\"{x:1315,y:502,t:1526929970885};\\\", \\\"{x:1311,y:503,t:1526929970903};\\\", \\\"{x:1307,y:503,t:1526929970920};\\\", \\\"{x:1300,y:504,t:1526929970935};\\\", \\\"{x:1299,y:505,t:1526929970953};\\\", \\\"{x:1298,y:505,t:1526929971106};\\\", \\\"{x:1298,y:506,t:1526929971119};\\\", \\\"{x:1299,y:506,t:1526929971137};\\\", \\\"{x:1299,y:507,t:1526929971153};\\\", \\\"{x:1300,y:507,t:1526929971169};\\\", \\\"{x:1301,y:507,t:1526929971209};\\\", \\\"{x:1302,y:507,t:1526929971234};\\\", \\\"{x:1303,y:507,t:1526929971266};\\\", \\\"{x:1305,y:507,t:1526929971306};\\\", \\\"{x:1306,y:506,t:1526929971386};\\\", \\\"{x:1307,y:504,t:1526929971522};\\\", \\\"{x:1308,y:503,t:1526929971546};\\\", \\\"{x:1309,y:503,t:1526929971554};\\\", \\\"{x:1309,y:502,t:1526929971570};\\\", \\\"{x:1309,y:503,t:1526929972505};\\\", \\\"{x:1309,y:530,t:1526929972521};\\\", \\\"{x:1317,y:662,t:1526929972537};\\\", \\\"{x:1326,y:731,t:1526929972554};\\\", \\\"{x:1336,y:787,t:1526929972571};\\\", \\\"{x:1346,y:828,t:1526929972588};\\\", \\\"{x:1353,y:855,t:1526929972604};\\\", \\\"{x:1355,y:879,t:1526929972621};\\\", \\\"{x:1356,y:903,t:1526929972638};\\\", \\\"{x:1356,y:924,t:1526929972654};\\\", \\\"{x:1354,y:933,t:1526929972671};\\\", \\\"{x:1352,y:941,t:1526929972688};\\\", \\\"{x:1349,y:943,t:1526929972704};\\\", \\\"{x:1349,y:944,t:1526929972721};\\\", \\\"{x:1348,y:948,t:1526929972738};\\\", \\\"{x:1346,y:949,t:1526929972754};\\\", \\\"{x:1345,y:951,t:1526929972778};\\\", \\\"{x:1344,y:951,t:1526929972788};\\\", \\\"{x:1342,y:951,t:1526929972809};\\\", \\\"{x:1338,y:949,t:1526929972821};\\\", \\\"{x:1334,y:944,t:1526929972837};\\\", \\\"{x:1329,y:934,t:1526929972854};\\\", \\\"{x:1326,y:924,t:1526929972871};\\\", \\\"{x:1324,y:919,t:1526929972888};\\\", \\\"{x:1323,y:916,t:1526929972903};\\\", \\\"{x:1323,y:912,t:1526929972921};\\\", \\\"{x:1322,y:912,t:1526929972938};\\\", \\\"{x:1322,y:911,t:1526929972962};\\\", \\\"{x:1322,y:910,t:1526929973090};\\\", \\\"{x:1322,y:909,t:1526929973113};\\\", \\\"{x:1322,y:907,t:1526929973122};\\\", \\\"{x:1324,y:906,t:1526929973434};\\\", \\\"{x:1325,y:906,t:1526929973449};\\\", \\\"{x:1327,y:906,t:1526929973778};\\\", \\\"{x:1328,y:906,t:1526929973788};\\\", \\\"{x:1333,y:904,t:1526929973805};\\\", \\\"{x:1340,y:903,t:1526929973821};\\\", \\\"{x:1345,y:901,t:1526929973837};\\\", \\\"{x:1347,y:901,t:1526929973854};\\\", \\\"{x:1348,y:900,t:1526929973871};\\\", \\\"{x:1350,y:898,t:1526929974257};\\\", \\\"{x:1352,y:893,t:1526929974272};\\\", \\\"{x:1356,y:884,t:1526929974290};\\\", \\\"{x:1361,y:877,t:1526929974305};\\\", \\\"{x:1370,y:860,t:1526929974321};\\\", \\\"{x:1373,y:854,t:1526929974339};\\\", \\\"{x:1375,y:847,t:1526929974355};\\\", \\\"{x:1380,y:836,t:1526929974371};\\\", \\\"{x:1385,y:820,t:1526929974389};\\\", \\\"{x:1389,y:806,t:1526929974406};\\\", \\\"{x:1392,y:795,t:1526929974422};\\\", \\\"{x:1392,y:789,t:1526929974438};\\\", \\\"{x:1392,y:787,t:1526929974456};\\\", \\\"{x:1392,y:786,t:1526929974471};\\\", \\\"{x:1392,y:785,t:1526929974488};\\\", \\\"{x:1392,y:784,t:1526929974682};\\\", \\\"{x:1392,y:782,t:1526929974689};\\\", \\\"{x:1391,y:777,t:1526929974705};\\\", \\\"{x:1387,y:771,t:1526929974721};\\\", \\\"{x:1385,y:766,t:1526929974739};\\\", \\\"{x:1384,y:765,t:1526929974756};\\\", \\\"{x:1384,y:764,t:1526929974772};\\\", \\\"{x:1384,y:763,t:1526929974789};\\\", \\\"{x:1384,y:762,t:1526929975969};\\\", \\\"{x:1384,y:763,t:1526929976122};\\\", \\\"{x:1384,y:768,t:1526929976139};\\\", \\\"{x:1384,y:771,t:1526929976157};\\\", \\\"{x:1384,y:773,t:1526929976173};\\\", \\\"{x:1384,y:774,t:1526929976190};\\\", \\\"{x:1384,y:775,t:1526929976206};\\\", \\\"{x:1384,y:776,t:1526929976233};\\\", \\\"{x:1384,y:777,t:1526929976298};\\\", \\\"{x:1384,y:778,t:1526929976307};\\\", \\\"{x:1384,y:779,t:1526929976324};\\\", \\\"{x:1384,y:781,t:1526929976340};\\\", \\\"{x:1384,y:784,t:1526929976357};\\\", \\\"{x:1384,y:791,t:1526929976374};\\\", \\\"{x:1385,y:801,t:1526929976389};\\\", \\\"{x:1385,y:809,t:1526929976407};\\\", \\\"{x:1385,y:814,t:1526929976423};\\\", \\\"{x:1385,y:816,t:1526929976439};\\\", \\\"{x:1385,y:823,t:1526929976456};\\\", \\\"{x:1385,y:830,t:1526929976472};\\\", \\\"{x:1385,y:835,t:1526929976489};\\\", \\\"{x:1385,y:838,t:1526929976506};\\\", \\\"{x:1385,y:842,t:1526929976523};\\\", \\\"{x:1385,y:844,t:1526929976539};\\\", \\\"{x:1385,y:847,t:1526929976556};\\\", \\\"{x:1385,y:852,t:1526929976574};\\\", \\\"{x:1385,y:858,t:1526929976589};\\\", \\\"{x:1385,y:866,t:1526929976607};\\\", \\\"{x:1385,y:872,t:1526929976624};\\\", \\\"{x:1385,y:875,t:1526929976639};\\\", \\\"{x:1385,y:877,t:1526929976657};\\\", \\\"{x:1385,y:878,t:1526929976672};\\\", \\\"{x:1385,y:879,t:1526929976690};\\\", \\\"{x:1385,y:881,t:1526929976706};\\\", \\\"{x:1385,y:884,t:1526929976724};\\\", \\\"{x:1385,y:886,t:1526929976740};\\\", \\\"{x:1385,y:889,t:1526929976756};\\\", \\\"{x:1385,y:892,t:1526929976773};\\\", \\\"{x:1385,y:893,t:1526929976790};\\\", \\\"{x:1385,y:896,t:1526929976806};\\\", \\\"{x:1385,y:898,t:1526929976824};\\\", \\\"{x:1387,y:903,t:1526929976840};\\\", \\\"{x:1387,y:904,t:1526929976856};\\\", \\\"{x:1387,y:907,t:1526929976873};\\\", \\\"{x:1387,y:909,t:1526929976891};\\\", \\\"{x:1387,y:910,t:1526929976906};\\\", \\\"{x:1387,y:911,t:1526929976928};\\\", \\\"{x:1387,y:912,t:1526929976940};\\\", \\\"{x:1387,y:913,t:1526929976956};\\\", \\\"{x:1387,y:917,t:1526929976973};\\\", \\\"{x:1387,y:921,t:1526929976991};\\\", \\\"{x:1387,y:927,t:1526929977006};\\\", \\\"{x:1387,y:930,t:1526929977023};\\\", \\\"{x:1389,y:935,t:1526929977041};\\\", \\\"{x:1389,y:939,t:1526929977057};\\\", \\\"{x:1389,y:943,t:1526929977074};\\\", \\\"{x:1389,y:946,t:1526929977091};\\\", \\\"{x:1389,y:949,t:1526929977106};\\\", \\\"{x:1390,y:952,t:1526929977123};\\\", \\\"{x:1390,y:953,t:1526929977140};\\\", \\\"{x:1390,y:955,t:1526929977157};\\\", \\\"{x:1390,y:956,t:1526929977177};\\\", \\\"{x:1390,y:957,t:1526929977217};\\\", \\\"{x:1390,y:958,t:1526929977233};\\\", \\\"{x:1390,y:959,t:1526929977257};\\\", \\\"{x:1390,y:961,t:1526929977273};\\\", \\\"{x:1390,y:962,t:1526929977291};\\\", \\\"{x:1390,y:963,t:1526929977308};\\\", \\\"{x:1390,y:964,t:1526929977324};\\\", \\\"{x:1390,y:965,t:1526929977341};\\\", \\\"{x:1390,y:966,t:1526929977361};\\\", \\\"{x:1390,y:964,t:1526929977682};\\\", \\\"{x:1389,y:963,t:1526929977705};\\\", \\\"{x:1389,y:962,t:1526929977882};\\\", \\\"{x:1389,y:961,t:1526929977913};\\\", \\\"{x:1389,y:960,t:1526929977937};\\\", \\\"{x:1389,y:958,t:1526929978194};\\\", \\\"{x:1389,y:955,t:1526929978208};\\\", \\\"{x:1389,y:937,t:1526929978225};\\\", \\\"{x:1389,y:921,t:1526929978241};\\\", \\\"{x:1389,y:898,t:1526929978258};\\\", \\\"{x:1389,y:867,t:1526929978275};\\\", \\\"{x:1389,y:840,t:1526929978292};\\\", \\\"{x:1389,y:817,t:1526929978308};\\\", \\\"{x:1389,y:798,t:1526929978325};\\\", \\\"{x:1389,y:788,t:1526929978342};\\\", \\\"{x:1389,y:785,t:1526929978358};\\\", \\\"{x:1389,y:784,t:1526929978375};\\\", \\\"{x:1389,y:782,t:1526929978578};\\\", \\\"{x:1389,y:781,t:1526929978592};\\\", \\\"{x:1386,y:776,t:1526929978608};\\\", \\\"{x:1384,y:772,t:1526929978626};\\\", \\\"{x:1382,y:767,t:1526929978642};\\\", \\\"{x:1380,y:761,t:1526929978658};\\\", \\\"{x:1378,y:753,t:1526929978676};\\\", \\\"{x:1376,y:742,t:1526929978692};\\\", \\\"{x:1372,y:731,t:1526929978708};\\\", \\\"{x:1369,y:721,t:1526929978725};\\\", \\\"{x:1366,y:710,t:1526929978742};\\\", \\\"{x:1356,y:694,t:1526929978759};\\\", \\\"{x:1338,y:670,t:1526929978775};\\\", \\\"{x:1324,y:655,t:1526929978792};\\\", \\\"{x:1323,y:651,t:1526929978809};\\\", \\\"{x:1322,y:651,t:1526929978857};\\\", \\\"{x:1323,y:651,t:1526929978889};\\\", \\\"{x:1327,y:651,t:1526929978898};\\\", \\\"{x:1332,y:652,t:1526929978909};\\\", \\\"{x:1344,y:658,t:1526929978925};\\\", \\\"{x:1352,y:659,t:1526929978943};\\\", \\\"{x:1356,y:661,t:1526929978994};\\\", \\\"{x:1381,y:668,t:1526929979009};\\\", \\\"{x:1417,y:668,t:1526929979025};\\\", \\\"{x:1450,y:659,t:1526929979042};\\\", \\\"{x:1465,y:639,t:1526929979059};\\\", \\\"{x:1467,y:622,t:1526929979075};\\\", \\\"{x:1467,y:604,t:1526929979092};\\\", \\\"{x:1460,y:587,t:1526929979108};\\\", \\\"{x:1452,y:578,t:1526929979125};\\\", \\\"{x:1443,y:571,t:1526929979142};\\\", \\\"{x:1439,y:568,t:1526929979159};\\\", \\\"{x:1433,y:564,t:1526929979175};\\\", \\\"{x:1423,y:558,t:1526929979192};\\\", \\\"{x:1402,y:543,t:1526929979210};\\\", \\\"{x:1391,y:532,t:1526929979225};\\\", \\\"{x:1387,y:529,t:1526929979242};\\\", \\\"{x:1386,y:527,t:1526929979259};\\\", \\\"{x:1386,y:528,t:1526929979409};\\\", \\\"{x:1383,y:532,t:1526929979425};\\\", \\\"{x:1382,y:535,t:1526929979441};\\\", \\\"{x:1380,y:538,t:1526929979458};\\\", \\\"{x:1379,y:541,t:1526929979480};\\\", \\\"{x:1379,y:542,t:1526929979512};\\\", \\\"{x:1379,y:544,t:1526929979569};\\\", \\\"{x:1379,y:545,t:1526929979601};\\\", \\\"{x:1379,y:547,t:1526929979680};\\\", \\\"{x:1379,y:548,t:1526929979692};\\\", \\\"{x:1379,y:550,t:1526929979708};\\\", \\\"{x:1379,y:551,t:1526929979727};\\\", \\\"{x:1379,y:553,t:1526929979800};\\\", \\\"{x:1379,y:554,t:1526929979824};\\\", \\\"{x:1379,y:556,t:1526929979856};\\\", \\\"{x:1380,y:556,t:1526929980137};\\\", \\\"{x:1383,y:556,t:1526929980145};\\\", \\\"{x:1387,y:556,t:1526929980159};\\\", \\\"{x:1393,y:556,t:1526929980175};\\\", \\\"{x:1398,y:556,t:1526929980192};\\\", \\\"{x:1399,y:556,t:1526929980209};\\\", \\\"{x:1400,y:557,t:1526929980225};\\\", \\\"{x:1404,y:565,t:1526929980243};\\\", \\\"{x:1405,y:573,t:1526929980260};\\\", \\\"{x:1407,y:576,t:1526929980276};\\\", \\\"{x:1407,y:578,t:1526929980293};\\\", \\\"{x:1408,y:578,t:1526929980417};\\\", \\\"{x:1409,y:577,t:1526929980441};\\\", \\\"{x:1409,y:576,t:1526929980448};\\\", \\\"{x:1410,y:576,t:1526929980465};\\\", \\\"{x:1410,y:575,t:1526929980475};\\\", \\\"{x:1411,y:574,t:1526929980493};\\\", \\\"{x:1411,y:572,t:1526929980510};\\\", \\\"{x:1411,y:573,t:1526929980689};\\\", \\\"{x:1411,y:584,t:1526929980698};\\\", \\\"{x:1411,y:595,t:1526929980709};\\\", \\\"{x:1411,y:614,t:1526929980726};\\\", \\\"{x:1411,y:627,t:1526929980742};\\\", \\\"{x:1413,y:638,t:1526929980760};\\\", \\\"{x:1414,y:646,t:1526929980776};\\\", \\\"{x:1414,y:655,t:1526929980792};\\\", \\\"{x:1414,y:662,t:1526929980809};\\\", \\\"{x:1414,y:665,t:1526929980826};\\\", \\\"{x:1414,y:667,t:1526929980842};\\\", \\\"{x:1414,y:669,t:1526929980860};\\\", \\\"{x:1414,y:670,t:1526929980876};\\\", \\\"{x:1414,y:673,t:1526929980893};\\\", \\\"{x:1413,y:677,t:1526929980909};\\\", \\\"{x:1413,y:682,t:1526929980927};\\\", \\\"{x:1413,y:692,t:1526929980943};\\\", \\\"{x:1413,y:702,t:1526929980959};\\\", \\\"{x:1412,y:725,t:1526929980977};\\\", \\\"{x:1412,y:743,t:1526929980993};\\\", \\\"{x:1412,y:759,t:1526929981009};\\\", \\\"{x:1412,y:772,t:1526929981026};\\\", \\\"{x:1412,y:777,t:1526929981042};\\\", \\\"{x:1412,y:780,t:1526929981059};\\\", \\\"{x:1412,y:784,t:1526929981076};\\\", \\\"{x:1412,y:791,t:1526929981093};\\\", \\\"{x:1412,y:800,t:1526929981109};\\\", \\\"{x:1412,y:808,t:1526929981126};\\\", \\\"{x:1412,y:814,t:1526929981144};\\\", \\\"{x:1412,y:818,t:1526929981159};\\\", \\\"{x:1412,y:831,t:1526929981177};\\\", \\\"{x:1412,y:845,t:1526929981193};\\\", \\\"{x:1409,y:860,t:1526929981210};\\\", \\\"{x:1408,y:873,t:1526929981227};\\\", \\\"{x:1407,y:889,t:1526929981244};\\\", \\\"{x:1407,y:902,t:1526929981260};\\\", \\\"{x:1407,y:910,t:1526929981277};\\\", \\\"{x:1407,y:918,t:1526929981293};\\\", \\\"{x:1405,y:926,t:1526929981310};\\\", \\\"{x:1403,y:937,t:1526929981327};\\\", \\\"{x:1402,y:943,t:1526929981344};\\\", \\\"{x:1400,y:950,t:1526929981360};\\\", \\\"{x:1398,y:957,t:1526929981377};\\\", \\\"{x:1397,y:959,t:1526929981394};\\\", \\\"{x:1397,y:960,t:1526929981410};\\\", \\\"{x:1397,y:962,t:1526929981441};\\\", \\\"{x:1397,y:963,t:1526929981490};\\\", \\\"{x:1397,y:964,t:1526929981497};\\\", \\\"{x:1397,y:965,t:1526929981510};\\\", \\\"{x:1397,y:967,t:1526929981527};\\\", \\\"{x:1400,y:968,t:1526929981544};\\\", \\\"{x:1402,y:969,t:1526929981560};\\\", \\\"{x:1403,y:970,t:1526929981577};\\\", \\\"{x:1405,y:970,t:1526929982506};\\\", \\\"{x:1406,y:970,t:1526929982513};\\\", \\\"{x:1406,y:971,t:1526929982537};\\\", \\\"{x:1407,y:971,t:1526929982547};\\\", \\\"{x:1408,y:971,t:1526929982673};\\\", \\\"{x:1409,y:971,t:1526929982682};\\\", \\\"{x:1410,y:971,t:1526929982722};\\\", \\\"{x:1411,y:971,t:1526929982737};\\\", \\\"{x:1412,y:971,t:1526929982769};\\\", \\\"{x:1414,y:970,t:1526929982801};\\\", \\\"{x:1415,y:969,t:1526929982825};\\\", \\\"{x:1415,y:968,t:1526929982850};\\\", \\\"{x:1415,y:967,t:1526929986449};\\\", \\\"{x:1415,y:956,t:1526929986464};\\\", \\\"{x:1458,y:888,t:1526929986481};\\\", \\\"{x:1485,y:862,t:1526929986498};\\\", \\\"{x:1500,y:849,t:1526929986514};\\\", \\\"{x:1505,y:846,t:1526929986531};\\\", \\\"{x:1507,y:844,t:1526929986548};\\\", \\\"{x:1508,y:844,t:1526929986564};\\\", \\\"{x:1509,y:843,t:1526929986582};\\\", \\\"{x:1510,y:842,t:1526929986633};\\\", \\\"{x:1511,y:839,t:1526929986648};\\\", \\\"{x:1515,y:830,t:1526929986665};\\\", \\\"{x:1515,y:822,t:1526929986681};\\\", \\\"{x:1515,y:821,t:1526929986697};\\\", \\\"{x:1510,y:817,t:1526929986714};\\\", \\\"{x:1500,y:813,t:1526929986731};\\\", \\\"{x:1494,y:810,t:1526929986748};\\\", \\\"{x:1488,y:808,t:1526929986764};\\\", \\\"{x:1479,y:807,t:1526929986782};\\\", \\\"{x:1473,y:807,t:1526929986798};\\\", \\\"{x:1470,y:809,t:1526929986815};\\\", \\\"{x:1469,y:810,t:1526929986832};\\\", \\\"{x:1468,y:810,t:1526929986874};\\\", \\\"{x:1467,y:812,t:1526929986897};\\\", \\\"{x:1467,y:814,t:1526929986914};\\\", \\\"{x:1467,y:815,t:1526929986931};\\\", \\\"{x:1467,y:816,t:1526929987121};\\\", \\\"{x:1467,y:817,t:1526929987132};\\\", \\\"{x:1468,y:818,t:1526929987161};\\\", \\\"{x:1469,y:819,t:1526929987497};\\\", \\\"{x:1470,y:823,t:1526929987515};\\\", \\\"{x:1471,y:831,t:1526929987532};\\\", \\\"{x:1472,y:837,t:1526929987548};\\\", \\\"{x:1472,y:841,t:1526929987565};\\\", \\\"{x:1473,y:845,t:1526929987581};\\\", \\\"{x:1473,y:848,t:1526929987599};\\\", \\\"{x:1474,y:852,t:1526929987616};\\\", \\\"{x:1474,y:856,t:1526929987631};\\\", \\\"{x:1475,y:860,t:1526929987649};\\\", \\\"{x:1476,y:867,t:1526929987665};\\\", \\\"{x:1477,y:871,t:1526929987681};\\\", \\\"{x:1477,y:874,t:1526929987698};\\\", \\\"{x:1477,y:878,t:1526929987716};\\\", \\\"{x:1479,y:881,t:1526929987731};\\\", \\\"{x:1479,y:884,t:1526929987748};\\\", \\\"{x:1480,y:889,t:1526929987766};\\\", \\\"{x:1483,y:901,t:1526929987781};\\\", \\\"{x:1489,y:918,t:1526929987797};\\\", \\\"{x:1492,y:933,t:1526929987815};\\\", \\\"{x:1496,y:946,t:1526929987832};\\\", \\\"{x:1499,y:954,t:1526929987847};\\\", \\\"{x:1499,y:961,t:1526929987864};\\\", \\\"{x:1500,y:964,t:1526929987882};\\\", \\\"{x:1500,y:969,t:1526929987898};\\\", \\\"{x:1501,y:972,t:1526929987914};\\\", \\\"{x:1501,y:974,t:1526929987932};\\\", \\\"{x:1501,y:975,t:1526929987948};\\\", \\\"{x:1500,y:974,t:1526929988137};\\\", \\\"{x:1499,y:973,t:1526929988153};\\\", \\\"{x:1499,y:971,t:1526929988169};\\\", \\\"{x:1499,y:970,t:1526929988182};\\\", \\\"{x:1498,y:969,t:1526929988199};\\\", \\\"{x:1498,y:968,t:1526929988216};\\\", \\\"{x:1498,y:967,t:1526929988232};\\\", \\\"{x:1496,y:964,t:1526929988249};\\\", \\\"{x:1496,y:963,t:1526929988265};\\\", \\\"{x:1495,y:962,t:1526929988283};\\\", \\\"{x:1495,y:960,t:1526929988299};\\\", \\\"{x:1495,y:959,t:1526929988425};\\\", \\\"{x:1494,y:959,t:1526929988433};\\\", \\\"{x:1493,y:958,t:1526929988650};\\\", \\\"{x:1493,y:954,t:1526929988665};\\\", \\\"{x:1492,y:949,t:1526929988682};\\\", \\\"{x:1489,y:940,t:1526929988699};\\\", \\\"{x:1488,y:933,t:1526929988717};\\\", \\\"{x:1487,y:927,t:1526929988732};\\\", \\\"{x:1485,y:918,t:1526929988750};\\\", \\\"{x:1485,y:915,t:1526929988766};\\\", \\\"{x:1484,y:912,t:1526929988782};\\\", \\\"{x:1484,y:911,t:1526929988816};\\\", \\\"{x:1484,y:910,t:1526929988832};\\\", \\\"{x:1484,y:909,t:1526929988848};\\\", \\\"{x:1484,y:908,t:1526929988873};\\\", \\\"{x:1484,y:907,t:1526929988882};\\\", \\\"{x:1484,y:905,t:1526929988899};\\\", \\\"{x:1484,y:903,t:1526929988915};\\\", \\\"{x:1484,y:901,t:1526929988932};\\\", \\\"{x:1484,y:899,t:1526929988949};\\\", \\\"{x:1484,y:897,t:1526929988966};\\\", \\\"{x:1484,y:893,t:1526929988982};\\\", \\\"{x:1484,y:889,t:1526929988999};\\\", \\\"{x:1484,y:886,t:1526929989016};\\\", \\\"{x:1484,y:879,t:1526929989032};\\\", \\\"{x:1484,y:871,t:1526929989049};\\\", \\\"{x:1483,y:867,t:1526929989066};\\\", \\\"{x:1483,y:866,t:1526929989088};\\\", \\\"{x:1483,y:865,t:1526929989099};\\\", \\\"{x:1483,y:863,t:1526929989116};\\\", \\\"{x:1483,y:861,t:1526929989131};\\\", \\\"{x:1483,y:858,t:1526929989149};\\\", \\\"{x:1483,y:854,t:1526929989166};\\\", \\\"{x:1483,y:853,t:1526929989183};\\\", \\\"{x:1482,y:851,t:1526929989199};\\\", \\\"{x:1482,y:850,t:1526929989216};\\\", \\\"{x:1482,y:848,t:1526929989232};\\\", \\\"{x:1481,y:845,t:1526929989249};\\\", \\\"{x:1481,y:844,t:1526929989266};\\\", \\\"{x:1481,y:843,t:1526929989297};\\\", \\\"{x:1481,y:842,t:1526929989320};\\\", \\\"{x:1481,y:841,t:1526929989333};\\\", \\\"{x:1481,y:840,t:1526929989349};\\\", \\\"{x:1481,y:838,t:1526929989366};\\\", \\\"{x:1481,y:837,t:1526929989382};\\\", \\\"{x:1481,y:835,t:1526929989399};\\\", \\\"{x:1481,y:833,t:1526929989416};\\\", \\\"{x:1481,y:832,t:1526929989440};\\\", \\\"{x:1481,y:831,t:1526929991449};\\\", \\\"{x:1484,y:831,t:1526929991457};\\\", \\\"{x:1493,y:831,t:1526929991469};\\\", \\\"{x:1510,y:831,t:1526929991484};\\\", \\\"{x:1526,y:829,t:1526929991501};\\\", \\\"{x:1537,y:829,t:1526929991517};\\\", \\\"{x:1541,y:829,t:1526929991535};\\\", \\\"{x:1542,y:829,t:1526929991553};\\\", \\\"{x:1542,y:828,t:1526929991649};\\\", \\\"{x:1541,y:827,t:1526929991657};\\\", \\\"{x:1536,y:825,t:1526929991668};\\\", \\\"{x:1528,y:820,t:1526929991683};\\\", \\\"{x:1509,y:808,t:1526929991701};\\\", \\\"{x:1468,y:776,t:1526929991718};\\\", \\\"{x:1411,y:732,t:1526929991734};\\\", \\\"{x:1335,y:678,t:1526929991751};\\\", \\\"{x:1257,y:621,t:1526929991768};\\\", \\\"{x:1154,y:550,t:1526929991784};\\\", \\\"{x:1015,y:473,t:1526929991801};\\\", \\\"{x:927,y:436,t:1526929991818};\\\", \\\"{x:855,y:414,t:1526929991834};\\\", \\\"{x:802,y:398,t:1526929991851};\\\", \\\"{x:753,y:389,t:1526929991868};\\\", \\\"{x:686,y:380,t:1526929991883};\\\", \\\"{x:620,y:380,t:1526929991901};\\\", \\\"{x:580,y:380,t:1526929991918};\\\", \\\"{x:563,y:384,t:1526929991934};\\\", \\\"{x:547,y:393,t:1526929991955};\\\", \\\"{x:535,y:401,t:1526929991972};\\\", \\\"{x:530,y:411,t:1526929991988};\\\", \\\"{x:529,y:440,t:1526929992005};\\\", \\\"{x:542,y:469,t:1526929992022};\\\", \\\"{x:567,y:512,t:1526929992039};\\\", \\\"{x:594,y:549,t:1526929992056};\\\", \\\"{x:611,y:569,t:1526929992072};\\\", \\\"{x:620,y:583,t:1526929992089};\\\", \\\"{x:643,y:600,t:1526929992108};\\\", \\\"{x:652,y:603,t:1526929992125};\\\", \\\"{x:653,y:605,t:1526929992141};\\\", \\\"{x:653,y:606,t:1526929992159};\\\", \\\"{x:647,y:610,t:1526929992174};\\\", \\\"{x:627,y:611,t:1526929992192};\\\", \\\"{x:616,y:611,t:1526929992209};\\\", \\\"{x:608,y:611,t:1526929992224};\\\", \\\"{x:601,y:614,t:1526929992242};\\\", \\\"{x:596,y:616,t:1526929992259};\\\", \\\"{x:590,y:620,t:1526929992274};\\\", \\\"{x:588,y:622,t:1526929992291};\\\", \\\"{x:589,y:622,t:1526929992317};\\\", \\\"{x:592,y:622,t:1526929992324};\\\", \\\"{x:596,y:622,t:1526929992342};\\\", \\\"{x:597,y:621,t:1526929992805};\\\", \\\"{x:600,y:621,t:1526929992812};\\\", \\\"{x:609,y:621,t:1526929992824};\\\", \\\"{x:631,y:627,t:1526929992842};\\\", \\\"{x:684,y:634,t:1526929992860};\\\", \\\"{x:803,y:652,t:1526929992876};\\\", \\\"{x:858,y:662,t:1526929992891};\\\", \\\"{x:1035,y:699,t:1526929992909};\\\", \\\"{x:1159,y:731,t:1526929992926};\\\", \\\"{x:1274,y:756,t:1526929992941};\\\", \\\"{x:1360,y:778,t:1526929992958};\\\", \\\"{x:1427,y:798,t:1526929992975};\\\", \\\"{x:1473,y:814,t:1526929992992};\\\", \\\"{x:1508,y:826,t:1526929993009};\\\", \\\"{x:1529,y:833,t:1526929993026};\\\", \\\"{x:1544,y:837,t:1526929993042};\\\", \\\"{x:1554,y:841,t:1526929993059};\\\", \\\"{x:1555,y:841,t:1526929993077};\\\", \\\"{x:1556,y:841,t:1526929993316};\\\", \\\"{x:1556,y:842,t:1526929993452};\\\", \\\"{x:1555,y:842,t:1526929993460};\\\", \\\"{x:1551,y:842,t:1526929993475};\\\", \\\"{x:1537,y:839,t:1526929993492};\\\", \\\"{x:1520,y:835,t:1526929993508};\\\", \\\"{x:1514,y:834,t:1526929993525};\\\", \\\"{x:1511,y:834,t:1526929993541};\\\", \\\"{x:1508,y:834,t:1526929993558};\\\", \\\"{x:1505,y:834,t:1526929993575};\\\", \\\"{x:1504,y:834,t:1526929993596};\\\", \\\"{x:1503,y:834,t:1526929993621};\\\", \\\"{x:1501,y:834,t:1526929993628};\\\", \\\"{x:1498,y:833,t:1526929993642};\\\", \\\"{x:1496,y:832,t:1526929993658};\\\", \\\"{x:1494,y:832,t:1526929993675};\\\", \\\"{x:1493,y:832,t:1526929993709};\\\", \\\"{x:1491,y:832,t:1526929993725};\\\", \\\"{x:1489,y:832,t:1526929993743};\\\", \\\"{x:1486,y:832,t:1526929993759};\\\", \\\"{x:1485,y:832,t:1526929993775};\\\", \\\"{x:1482,y:832,t:1526929993792};\\\", \\\"{x:1482,y:831,t:1526929993893};\\\", \\\"{x:1476,y:831,t:1526929995213};\\\", \\\"{x:1467,y:841,t:1526929995225};\\\", \\\"{x:1407,y:871,t:1526929995241};\\\", \\\"{x:1333,y:887,t:1526929995258};\\\", \\\"{x:1305,y:889,t:1526929995274};\\\", \\\"{x:1303,y:889,t:1526929995290};\\\", \\\"{x:1302,y:890,t:1526929995307};\\\", \\\"{x:1298,y:890,t:1526929995324};\\\", \\\"{x:1297,y:889,t:1526929995509};\\\", \\\"{x:1298,y:887,t:1526929995565};\\\", \\\"{x:1300,y:884,t:1526929995573};\\\", \\\"{x:1306,y:876,t:1526929995590};\\\", \\\"{x:1311,y:868,t:1526929995607};\\\", \\\"{x:1314,y:860,t:1526929995623};\\\", \\\"{x:1319,y:852,t:1526929995640};\\\", \\\"{x:1323,y:847,t:1526929995658};\\\", \\\"{x:1325,y:843,t:1526929995673};\\\", \\\"{x:1327,y:840,t:1526929995690};\\\", \\\"{x:1330,y:837,t:1526929995708};\\\", \\\"{x:1334,y:834,t:1526929995723};\\\", \\\"{x:1339,y:830,t:1526929995741};\\\", \\\"{x:1343,y:826,t:1526929995757};\\\", \\\"{x:1347,y:822,t:1526929995773};\\\", \\\"{x:1355,y:812,t:1526929995790};\\\", \\\"{x:1360,y:804,t:1526929995807};\\\", \\\"{x:1366,y:797,t:1526929995823};\\\", \\\"{x:1372,y:789,t:1526929995840};\\\", \\\"{x:1377,y:786,t:1526929995856};\\\", \\\"{x:1380,y:782,t:1526929995873};\\\", \\\"{x:1382,y:780,t:1526929995890};\\\", \\\"{x:1384,y:777,t:1526929995907};\\\", \\\"{x:1385,y:775,t:1526929995923};\\\", \\\"{x:1385,y:772,t:1526929995940};\\\", \\\"{x:1388,y:769,t:1526929995956};\\\", \\\"{x:1389,y:766,t:1526929995973};\\\", \\\"{x:1391,y:762,t:1526929995990};\\\", \\\"{x:1392,y:762,t:1526929996005};\\\", \\\"{x:1394,y:760,t:1526929996023};\\\", \\\"{x:1395,y:759,t:1526929996040};\\\", \\\"{x:1396,y:756,t:1526929996056};\\\", \\\"{x:1397,y:756,t:1526929996073};\\\", \\\"{x:1397,y:755,t:1526929996090};\\\", \\\"{x:1397,y:753,t:1526929996221};\\\", \\\"{x:1396,y:753,t:1526929996228};\\\", \\\"{x:1394,y:751,t:1526929996240};\\\", \\\"{x:1387,y:748,t:1526929996256};\\\", \\\"{x:1382,y:747,t:1526929996274};\\\", \\\"{x:1380,y:745,t:1526929996290};\\\", \\\"{x:1382,y:746,t:1526929996341};\\\", \\\"{x:1384,y:746,t:1526929996357};\\\", \\\"{x:1384,y:747,t:1526929996372};\\\", \\\"{x:1385,y:748,t:1526929996389};\\\", \\\"{x:1385,y:752,t:1526929996406};\\\", \\\"{x:1385,y:757,t:1526929996422};\\\", \\\"{x:1385,y:761,t:1526929996439};\\\", \\\"{x:1385,y:762,t:1526929996456};\\\", \\\"{x:1385,y:763,t:1526929996473};\\\", \\\"{x:1385,y:765,t:1526929996489};\\\", \\\"{x:1385,y:768,t:1526929996506};\\\", \\\"{x:1385,y:769,t:1526929996523};\\\", \\\"{x:1385,y:771,t:1526929996539};\\\", \\\"{x:1384,y:774,t:1526929996556};\\\", \\\"{x:1383,y:777,t:1526929996572};\\\", \\\"{x:1383,y:780,t:1526929996589};\\\", \\\"{x:1383,y:783,t:1526929996606};\\\", \\\"{x:1383,y:785,t:1526929996623};\\\", \\\"{x:1383,y:789,t:1526929996640};\\\", \\\"{x:1383,y:790,t:1526929996656};\\\", \\\"{x:1383,y:793,t:1526929996673};\\\", \\\"{x:1383,y:797,t:1526929996689};\\\", \\\"{x:1383,y:801,t:1526929996706};\\\", \\\"{x:1383,y:805,t:1526929996723};\\\", \\\"{x:1383,y:808,t:1526929996739};\\\", \\\"{x:1383,y:811,t:1526929996756};\\\", \\\"{x:1383,y:815,t:1526929996772};\\\", \\\"{x:1383,y:818,t:1526929996789};\\\", \\\"{x:1383,y:823,t:1526929996806};\\\", \\\"{x:1383,y:827,t:1526929996822};\\\", \\\"{x:1383,y:832,t:1526929996839};\\\", \\\"{x:1383,y:837,t:1526929996857};\\\", \\\"{x:1383,y:839,t:1526929996872};\\\", \\\"{x:1383,y:840,t:1526929996889};\\\", \\\"{x:1383,y:841,t:1526929996906};\\\", \\\"{x:1383,y:845,t:1526929996922};\\\", \\\"{x:1383,y:848,t:1526929996940};\\\", \\\"{x:1385,y:854,t:1526929996956};\\\", \\\"{x:1385,y:855,t:1526929996973};\\\", \\\"{x:1385,y:858,t:1526929996989};\\\", \\\"{x:1385,y:860,t:1526929997006};\\\", \\\"{x:1385,y:864,t:1526929997022};\\\", \\\"{x:1386,y:871,t:1526929997039};\\\", \\\"{x:1386,y:878,t:1526929997056};\\\", \\\"{x:1387,y:884,t:1526929997072};\\\", \\\"{x:1387,y:894,t:1526929997090};\\\", \\\"{x:1387,y:909,t:1526929997106};\\\", \\\"{x:1387,y:924,t:1526929997122};\\\", \\\"{x:1387,y:936,t:1526929997139};\\\", \\\"{x:1388,y:953,t:1526929997157};\\\", \\\"{x:1389,y:961,t:1526929997172};\\\", \\\"{x:1390,y:967,t:1526929997189};\\\", \\\"{x:1391,y:972,t:1526929997205};\\\", \\\"{x:1391,y:975,t:1526929997223};\\\", \\\"{x:1391,y:976,t:1526929997244};\\\", \\\"{x:1391,y:977,t:1526929997269};\\\", \\\"{x:1392,y:978,t:1526929997301};\\\", \\\"{x:1390,y:977,t:1526929997693};\\\", \\\"{x:1389,y:976,t:1526929997706};\\\", \\\"{x:1388,y:975,t:1526929997723};\\\", \\\"{x:1388,y:976,t:1526929997829};\\\", \\\"{x:1386,y:977,t:1526929997838};\\\", \\\"{x:1386,y:981,t:1526929997855};\\\", \\\"{x:1385,y:984,t:1526929997872};\\\", \\\"{x:1385,y:985,t:1526929997888};\\\", \\\"{x:1385,y:984,t:1526929998021};\\\", \\\"{x:1385,y:979,t:1526929998038};\\\", \\\"{x:1384,y:976,t:1526929998056};\\\", \\\"{x:1384,y:974,t:1526929998071};\\\", \\\"{x:1383,y:972,t:1526929998088};\\\", \\\"{x:1383,y:971,t:1526929998116};\\\", \\\"{x:1383,y:970,t:1526929998151};\\\", \\\"{x:1383,y:965,t:1526930001637};\\\", \\\"{x:1395,y:909,t:1526930001652};\\\", \\\"{x:1431,y:847,t:1526930001669};\\\", \\\"{x:1464,y:784,t:1526930001686};\\\", \\\"{x:1484,y:765,t:1526930001702};\\\", \\\"{x:1498,y:759,t:1526930001720};\\\", \\\"{x:1502,y:756,t:1526930001735};\\\", \\\"{x:1502,y:755,t:1526930001797};\\\", \\\"{x:1501,y:753,t:1526930001811};\\\", \\\"{x:1495,y:750,t:1526930001819};\\\", \\\"{x:1487,y:748,t:1526930001835};\\\", \\\"{x:1390,y:745,t:1526930001852};\\\", \\\"{x:1256,y:734,t:1526930001869};\\\", \\\"{x:1087,y:703,t:1526930001885};\\\", \\\"{x:941,y:672,t:1526930001902};\\\", \\\"{x:829,y:664,t:1526930001918};\\\", \\\"{x:748,y:663,t:1526930001935};\\\", \\\"{x:709,y:663,t:1526930001953};\\\", \\\"{x:692,y:664,t:1526930001968};\\\", \\\"{x:687,y:666,t:1526930001985};\\\", \\\"{x:685,y:667,t:1526930001999};\\\", \\\"{x:681,y:668,t:1526930002016};\\\", \\\"{x:659,y:669,t:1526930002033};\\\", \\\"{x:613,y:664,t:1526930002049};\\\", \\\"{x:537,y:634,t:1526930002066};\\\", \\\"{x:508,y:625,t:1526930002084};\\\", \\\"{x:500,y:618,t:1526930002098};\\\", \\\"{x:487,y:609,t:1526930002116};\\\", \\\"{x:501,y:604,t:1526930002133};\\\", \\\"{x:523,y:603,t:1526930002149};\\\", \\\"{x:537,y:603,t:1526930002166};\\\", \\\"{x:545,y:602,t:1526930002183};\\\", \\\"{x:557,y:602,t:1526930002199};\\\", \\\"{x:561,y:602,t:1526930002216};\\\", \\\"{x:569,y:602,t:1526930002233};\\\", \\\"{x:574,y:602,t:1526930002249};\\\", \\\"{x:577,y:602,t:1526930002266};\\\", \\\"{x:578,y:603,t:1526930002283};\\\", \\\"{x:579,y:603,t:1526930002299};\\\", \\\"{x:579,y:605,t:1526930002317};\\\", \\\"{x:579,y:606,t:1526930002333};\\\", \\\"{x:579,y:608,t:1526930002351};\\\", \\\"{x:581,y:609,t:1526930002396};\\\", \\\"{x:581,y:610,t:1526930002404};\\\", \\\"{x:583,y:610,t:1526930002416};\\\", \\\"{x:584,y:612,t:1526930002433};\\\", \\\"{x:585,y:612,t:1526930002450};\\\", \\\"{x:586,y:612,t:1526930002466};\\\", \\\"{x:587,y:612,t:1526930002483};\\\", \\\"{x:588,y:613,t:1526930002500};\\\", \\\"{x:590,y:613,t:1526930002516};\\\", \\\"{x:591,y:613,t:1526930002533};\\\", \\\"{x:593,y:615,t:1526930002550};\\\", \\\"{x:595,y:616,t:1526930002566};\\\", \\\"{x:600,y:617,t:1526930002584};\\\", \\\"{x:601,y:618,t:1526930002600};\\\", \\\"{x:602,y:619,t:1526930002617};\\\", \\\"{x:606,y:623,t:1526930002981};\\\", \\\"{x:646,y:640,t:1526930003000};\\\", \\\"{x:735,y:686,t:1526930003017};\\\", \\\"{x:867,y:742,t:1526930003033};\\\", \\\"{x:1030,y:817,t:1526930003050};\\\", \\\"{x:1211,y:879,t:1526930003067};\\\", \\\"{x:1382,y:931,t:1526930003083};\\\", \\\"{x:1572,y:979,t:1526930003099};\\\", \\\"{x:1677,y:1005,t:1526930003117};\\\", \\\"{x:1736,y:1013,t:1526930003133};\\\", \\\"{x:1759,y:1013,t:1526930003150};\\\", \\\"{x:1766,y:1012,t:1526930003167};\\\", \\\"{x:1770,y:1003,t:1526930003183};\\\", \\\"{x:1772,y:987,t:1526930003200};\\\", \\\"{x:1772,y:975,t:1526930003217};\\\", \\\"{x:1769,y:960,t:1526930003233};\\\", \\\"{x:1765,y:949,t:1526930003250};\\\", \\\"{x:1760,y:934,t:1526930003268};\\\", \\\"{x:1752,y:918,t:1526930003283};\\\", \\\"{x:1731,y:897,t:1526930003301};\\\", \\\"{x:1705,y:881,t:1526930003318};\\\", \\\"{x:1665,y:852,t:1526930003334};\\\", \\\"{x:1612,y:825,t:1526930003350};\\\", \\\"{x:1565,y:805,t:1526930003367};\\\", \\\"{x:1516,y:786,t:1526930003383};\\\", \\\"{x:1439,y:769,t:1526930003400};\\\", \\\"{x:1366,y:755,t:1526930003417};\\\", \\\"{x:1306,y:743,t:1526930003433};\\\", \\\"{x:1275,y:739,t:1526930003450};\\\", \\\"{x:1260,y:738,t:1526930003467};\\\", \\\"{x:1255,y:738,t:1526930003484};\\\", \\\"{x:1254,y:738,t:1526930003500};\\\", \\\"{x:1255,y:739,t:1526930003517};\\\", \\\"{x:1260,y:740,t:1526930003534};\\\", \\\"{x:1267,y:743,t:1526930003550};\\\", \\\"{x:1269,y:744,t:1526930003568};\\\", \\\"{x:1273,y:745,t:1526930003584};\\\", \\\"{x:1274,y:746,t:1526930003620};\\\", \\\"{x:1276,y:747,t:1526930003634};\\\", \\\"{x:1286,y:750,t:1526930003650};\\\", \\\"{x:1299,y:752,t:1526930003667};\\\", \\\"{x:1318,y:752,t:1526930003684};\\\", \\\"{x:1325,y:752,t:1526930003701};\\\", \\\"{x:1334,y:752,t:1526930003717};\\\", \\\"{x:1341,y:757,t:1526930003734};\\\", \\\"{x:1350,y:761,t:1526930003751};\\\", \\\"{x:1360,y:766,t:1526930003768};\\\", \\\"{x:1369,y:784,t:1526930003784};\\\", \\\"{x:1378,y:805,t:1526930003801};\\\", \\\"{x:1383,y:832,t:1526930003817};\\\", \\\"{x:1387,y:859,t:1526930003834};\\\", \\\"{x:1393,y:891,t:1526930003850};\\\", \\\"{x:1400,y:936,t:1526930003867};\\\", \\\"{x:1414,y:996,t:1526930003884};\\\", \\\"{x:1420,y:1017,t:1526930003900};\\\", \\\"{x:1421,y:1024,t:1526930003917};\\\", \\\"{x:1422,y:1026,t:1526930003934};\\\", \\\"{x:1422,y:1025,t:1526930004061};\\\", \\\"{x:1422,y:1022,t:1526930004068};\\\", \\\"{x:1418,y:1010,t:1526930004085};\\\", \\\"{x:1412,y:998,t:1526930004102};\\\", \\\"{x:1404,y:981,t:1526930004117};\\\", \\\"{x:1399,y:972,t:1526930004134};\\\", \\\"{x:1397,y:968,t:1526930004152};\\\", \\\"{x:1397,y:966,t:1526930004167};\\\", \\\"{x:1397,y:965,t:1526930004197};\\\", \\\"{x:1396,y:965,t:1526930004613};\\\", \\\"{x:1395,y:965,t:1526930004629};\\\", \\\"{x:1393,y:965,t:1526930004645};\\\", \\\"{x:1390,y:965,t:1526930004652};\\\", \\\"{x:1386,y:971,t:1526930004669};\\\", \\\"{x:1384,y:974,t:1526930004685};\\\", \\\"{x:1383,y:976,t:1526930004701};\\\", \\\"{x:1383,y:977,t:1526930004732};\\\", \\\"{x:1383,y:976,t:1526930005412};\\\", \\\"{x:1383,y:974,t:1526930005420};\\\", \\\"{x:1383,y:972,t:1526930005436};\\\", \\\"{x:1383,y:969,t:1526930005452};\\\", \\\"{x:1383,y:967,t:1526930005468};\\\", \\\"{x:1383,y:965,t:1526930005486};\\\", \\\"{x:1383,y:964,t:1526930005502};\\\", \\\"{x:1384,y:964,t:1526930005519};\\\", \\\"{x:1383,y:972,t:1526930007038};\\\", \\\"{x:1382,y:988,t:1526930007053};\\\", \\\"{x:1382,y:998,t:1526930007070};\\\", \\\"{x:1381,y:1002,t:1526930007086};\\\", \\\"{x:1381,y:1001,t:1526930007445};\\\", \\\"{x:1381,y:999,t:1526930007453};\\\", \\\"{x:1381,y:995,t:1526930007470};\\\", \\\"{x:1381,y:991,t:1526930007487};\\\", \\\"{x:1380,y:989,t:1526930007503};\\\", \\\"{x:1380,y:988,t:1526930007524};\\\", \\\"{x:1380,y:986,t:1526930007589};\\\", \\\"{x:1380,y:985,t:1526930007620};\\\", \\\"{x:1380,y:983,t:1526930007645};\\\", \\\"{x:1380,y:982,t:1526930007669};\\\", \\\"{x:1380,y:980,t:1526930007687};\\\", \\\"{x:1380,y:978,t:1526930007703};\\\", \\\"{x:1380,y:976,t:1526930007719};\\\", \\\"{x:1380,y:974,t:1526930007737};\\\", \\\"{x:1379,y:973,t:1526930007754};\\\", \\\"{x:1379,y:972,t:1526930007770};\\\", \\\"{x:1379,y:971,t:1526930007787};\\\", \\\"{x:1379,y:970,t:1526930007804};\\\", \\\"{x:1379,y:969,t:1526930010790};\\\", \\\"{x:1379,y:967,t:1526930011556};\\\", \\\"{x:1378,y:967,t:1526930017621};\\\", \\\"{x:1378,y:966,t:1526930017941};\\\", \\\"{x:1378,y:965,t:1526930017951};\\\", \\\"{x:1378,y:964,t:1526930017965};\\\", \\\"{x:1379,y:963,t:1526930017989};\\\", \\\"{x:1380,y:962,t:1526930017996};\\\", \\\"{x:1381,y:962,t:1526930018011};\\\", \\\"{x:1381,y:961,t:1526930018069};\\\", \\\"{x:1382,y:961,t:1526930018229};\\\", \\\"{x:1383,y:961,t:1526930018244};\\\", \\\"{x:1391,y:960,t:1526930018261};\\\", \\\"{x:1398,y:960,t:1526930018276};\\\", \\\"{x:1405,y:959,t:1526930018293};\\\", \\\"{x:1411,y:959,t:1526930018310};\\\", \\\"{x:1417,y:959,t:1526930018327};\\\", \\\"{x:1424,y:959,t:1526930018343};\\\", \\\"{x:1430,y:959,t:1526930018360};\\\", \\\"{x:1433,y:957,t:1526930018377};\\\", \\\"{x:1435,y:957,t:1526930018393};\\\", \\\"{x:1436,y:957,t:1526930018410};\\\", \\\"{x:1437,y:957,t:1526930018717};\\\", \\\"{x:1440,y:957,t:1526930018740};\\\", \\\"{x:1443,y:957,t:1526930018749};\\\", \\\"{x:1449,y:957,t:1526930018760};\\\", \\\"{x:1467,y:957,t:1526930018777};\\\", \\\"{x:1486,y:957,t:1526930018793};\\\", \\\"{x:1508,y:960,t:1526930018810};\\\", \\\"{x:1529,y:962,t:1526930018828};\\\", \\\"{x:1543,y:962,t:1526930018843};\\\", \\\"{x:1556,y:962,t:1526930018860};\\\", \\\"{x:1557,y:962,t:1526930018878};\\\", \\\"{x:1556,y:962,t:1526930018940};\\\", \\\"{x:1553,y:962,t:1526930018951};\\\", \\\"{x:1549,y:960,t:1526930018961};\\\", \\\"{x:1543,y:957,t:1526930018978};\\\", \\\"{x:1531,y:953,t:1526930018994};\\\", \\\"{x:1525,y:950,t:1526930019011};\\\", \\\"{x:1517,y:946,t:1526930019028};\\\", \\\"{x:1498,y:939,t:1526930019044};\\\", \\\"{x:1479,y:932,t:1526930019061};\\\", \\\"{x:1440,y:907,t:1526930019077};\\\", \\\"{x:1394,y:884,t:1526930019094};\\\", \\\"{x:1386,y:879,t:1526930019110};\\\", \\\"{x:1382,y:869,t:1526930019127};\\\", \\\"{x:1377,y:850,t:1526930019144};\\\", \\\"{x:1371,y:813,t:1526930019160};\\\", \\\"{x:1369,y:775,t:1526930019177};\\\", \\\"{x:1369,y:733,t:1526930019193};\\\", \\\"{x:1379,y:676,t:1526930019210};\\\", \\\"{x:1395,y:635,t:1526930019227};\\\", \\\"{x:1418,y:577,t:1526930019243};\\\", \\\"{x:1432,y:546,t:1526930019259};\\\", \\\"{x:1453,y:510,t:1526930019277};\\\", \\\"{x:1472,y:484,t:1526930019294};\\\", \\\"{x:1485,y:465,t:1526930019310};\\\", \\\"{x:1488,y:457,t:1526930019326};\\\", \\\"{x:1490,y:452,t:1526930019344};\\\", \\\"{x:1491,y:446,t:1526930019359};\\\", \\\"{x:1492,y:442,t:1526930019376};\\\", \\\"{x:1492,y:441,t:1526930019394};\\\", \\\"{x:1492,y:440,t:1526930019411};\\\", \\\"{x:1490,y:439,t:1526930019436};\\\", \\\"{x:1487,y:437,t:1526930019444};\\\", \\\"{x:1482,y:437,t:1526930019461};\\\", \\\"{x:1472,y:439,t:1526930019477};\\\", \\\"{x:1456,y:447,t:1526930019494};\\\", \\\"{x:1446,y:455,t:1526930019510};\\\", \\\"{x:1436,y:469,t:1526930019527};\\\", \\\"{x:1431,y:479,t:1526930019544};\\\", \\\"{x:1427,y:491,t:1526930019561};\\\", \\\"{x:1427,y:501,t:1526930019577};\\\", \\\"{x:1427,y:508,t:1526930019594};\\\", \\\"{x:1427,y:514,t:1526930019611};\\\", \\\"{x:1427,y:520,t:1526930019627};\\\", \\\"{x:1427,y:524,t:1526930019644};\\\", \\\"{x:1426,y:532,t:1526930019660};\\\", \\\"{x:1420,y:542,t:1526930019677};\\\", \\\"{x:1416,y:553,t:1526930019695};\\\", \\\"{x:1413,y:561,t:1526930019711};\\\", \\\"{x:1412,y:565,t:1526930019727};\\\", \\\"{x:1412,y:569,t:1526930019745};\\\", \\\"{x:1412,y:571,t:1526930019761};\\\", \\\"{x:1412,y:572,t:1526930019777};\\\", \\\"{x:1412,y:573,t:1526930019796};\\\", \\\"{x:1412,y:574,t:1526930019901};\\\", \\\"{x:1414,y:575,t:1526930019911};\\\", \\\"{x:1417,y:578,t:1526930019927};\\\", \\\"{x:1420,y:579,t:1526930019945};\\\", \\\"{x:1424,y:587,t:1526930019961};\\\", \\\"{x:1425,y:593,t:1526930019976};\\\", \\\"{x:1425,y:598,t:1526930019993};\\\", \\\"{x:1427,y:607,t:1526930020011};\\\", \\\"{x:1429,y:616,t:1526930020027};\\\", \\\"{x:1432,y:628,t:1526930020044};\\\", \\\"{x:1434,y:637,t:1526930020060};\\\", \\\"{x:1437,y:645,t:1526930020078};\\\", \\\"{x:1438,y:652,t:1526930020094};\\\", \\\"{x:1441,y:658,t:1526930020111};\\\", \\\"{x:1442,y:663,t:1526930020128};\\\", \\\"{x:1444,y:669,t:1526930020144};\\\", \\\"{x:1445,y:675,t:1526930020160};\\\", \\\"{x:1445,y:683,t:1526930020177};\\\", \\\"{x:1445,y:692,t:1526930020194};\\\", \\\"{x:1445,y:700,t:1526930020211};\\\", \\\"{x:1445,y:714,t:1526930020228};\\\", \\\"{x:1445,y:721,t:1526930020244};\\\", \\\"{x:1445,y:726,t:1526930020260};\\\", \\\"{x:1445,y:731,t:1526930020278};\\\", \\\"{x:1443,y:738,t:1526930020294};\\\", \\\"{x:1440,y:745,t:1526930020311};\\\", \\\"{x:1438,y:754,t:1526930020328};\\\", \\\"{x:1436,y:761,t:1526930020344};\\\", \\\"{x:1434,y:767,t:1526930020361};\\\", \\\"{x:1434,y:774,t:1526930020378};\\\", \\\"{x:1433,y:783,t:1526930020394};\\\", \\\"{x:1433,y:794,t:1526930020411};\\\", \\\"{x:1433,y:810,t:1526930020428};\\\", \\\"{x:1433,y:821,t:1526930020444};\\\", \\\"{x:1433,y:837,t:1526930020461};\\\", \\\"{x:1433,y:861,t:1526930020478};\\\", \\\"{x:1430,y:891,t:1526930020494};\\\", \\\"{x:1423,y:915,t:1526930020511};\\\", \\\"{x:1420,y:925,t:1526930020528};\\\", \\\"{x:1419,y:928,t:1526930020544};\\\", \\\"{x:1419,y:932,t:1526930020693};\\\", \\\"{x:1419,y:937,t:1526930020700};\\\", \\\"{x:1419,y:943,t:1526930020711};\\\", \\\"{x:1417,y:958,t:1526930020728};\\\", \\\"{x:1416,y:967,t:1526930020745};\\\", \\\"{x:1416,y:970,t:1526930020761};\\\", \\\"{x:1416,y:972,t:1526930020778};\\\", \\\"{x:1416,y:971,t:1526930021117};\\\", \\\"{x:1416,y:970,t:1526930021129};\\\", \\\"{x:1416,y:969,t:1526930021157};\\\", \\\"{x:1416,y:968,t:1526930021181};\\\", \\\"{x:1415,y:967,t:1526930021195};\\\", \\\"{x:1415,y:966,t:1526930022205};\\\", \\\"{x:1415,y:965,t:1526930022212};\\\", \\\"{x:1415,y:963,t:1526930022229};\\\", \\\"{x:1416,y:962,t:1526930022246};\\\", \\\"{x:1416,y:961,t:1526930022262};\\\", \\\"{x:1416,y:960,t:1526930022279};\\\", \\\"{x:1417,y:958,t:1526930022980};\\\", \\\"{x:1420,y:952,t:1526930022995};\\\", \\\"{x:1424,y:943,t:1526930023013};\\\", \\\"{x:1426,y:935,t:1526930023029};\\\", \\\"{x:1426,y:931,t:1526930023046};\\\", \\\"{x:1430,y:921,t:1526930023063};\\\", \\\"{x:1437,y:894,t:1526930023079};\\\", \\\"{x:1448,y:843,t:1526930023096};\\\", \\\"{x:1457,y:789,t:1526930023113};\\\", \\\"{x:1465,y:733,t:1526930023129};\\\", \\\"{x:1467,y:679,t:1526930023146};\\\", \\\"{x:1467,y:649,t:1526930023162};\\\", \\\"{x:1462,y:624,t:1526930023179};\\\", \\\"{x:1453,y:595,t:1526930023196};\\\", \\\"{x:1449,y:581,t:1526930023213};\\\", \\\"{x:1449,y:571,t:1526930023229};\\\", \\\"{x:1449,y:563,t:1526930023246};\\\", \\\"{x:1449,y:558,t:1526930023263};\\\", \\\"{x:1449,y:555,t:1526930023279};\\\", \\\"{x:1449,y:553,t:1526930023296};\\\", \\\"{x:1448,y:551,t:1526930023313};\\\", \\\"{x:1446,y:548,t:1526930023329};\\\", \\\"{x:1442,y:546,t:1526930023346};\\\", \\\"{x:1438,y:544,t:1526930023363};\\\", \\\"{x:1434,y:542,t:1526930023379};\\\", \\\"{x:1429,y:541,t:1526930023396};\\\", \\\"{x:1428,y:540,t:1526930023413};\\\", \\\"{x:1427,y:540,t:1526930023430};\\\", \\\"{x:1426,y:539,t:1526930023446};\\\", \\\"{x:1425,y:539,t:1526930023463};\\\", \\\"{x:1421,y:538,t:1526930023479};\\\", \\\"{x:1419,y:538,t:1526930023496};\\\", \\\"{x:1418,y:537,t:1526930023513};\\\", \\\"{x:1418,y:538,t:1526930023612};\\\", \\\"{x:1418,y:539,t:1526930023620};\\\", \\\"{x:1418,y:541,t:1526930023636};\\\", \\\"{x:1418,y:542,t:1526930023652};\\\", \\\"{x:1418,y:544,t:1526930023676};\\\", \\\"{x:1418,y:545,t:1526930023717};\\\", \\\"{x:1418,y:547,t:1526930023741};\\\", \\\"{x:1418,y:548,t:1526930023756};\\\", \\\"{x:1418,y:550,t:1526930023773};\\\", \\\"{x:1419,y:551,t:1526930023780};\\\", \\\"{x:1419,y:552,t:1526930023805};\\\", \\\"{x:1419,y:553,t:1526930023820};\\\", \\\"{x:1419,y:554,t:1526930023830};\\\", \\\"{x:1419,y:556,t:1526930023847};\\\", \\\"{x:1419,y:560,t:1526930023864};\\\", \\\"{x:1419,y:566,t:1526930023880};\\\", \\\"{x:1419,y:574,t:1526930023897};\\\", \\\"{x:1418,y:585,t:1526930023913};\\\", \\\"{x:1417,y:597,t:1526930023931};\\\", \\\"{x:1417,y:603,t:1526930023946};\\\", \\\"{x:1417,y:608,t:1526930023964};\\\", \\\"{x:1417,y:619,t:1526930023980};\\\", \\\"{x:1417,y:624,t:1526930023996};\\\", \\\"{x:1417,y:630,t:1526930024013};\\\", \\\"{x:1417,y:635,t:1526930024031};\\\", \\\"{x:1417,y:641,t:1526930024046};\\\", \\\"{x:1417,y:651,t:1526930024064};\\\", \\\"{x:1417,y:658,t:1526930024080};\\\", \\\"{x:1417,y:666,t:1526930024096};\\\", \\\"{x:1417,y:675,t:1526930024113};\\\", \\\"{x:1417,y:680,t:1526930024130};\\\", \\\"{x:1417,y:686,t:1526930024147};\\\", \\\"{x:1418,y:690,t:1526930024163};\\\", \\\"{x:1418,y:691,t:1526930024180};\\\", \\\"{x:1418,y:693,t:1526930024197};\\\", \\\"{x:1418,y:694,t:1526930024228};\\\", \\\"{x:1418,y:695,t:1526930024269};\\\", \\\"{x:1418,y:696,t:1526930024280};\\\", \\\"{x:1418,y:699,t:1526930024297};\\\", \\\"{x:1418,y:703,t:1526930024313};\\\", \\\"{x:1418,y:708,t:1526930024331};\\\", \\\"{x:1418,y:712,t:1526930024347};\\\", \\\"{x:1418,y:715,t:1526930024363};\\\", \\\"{x:1418,y:720,t:1526930024380};\\\", \\\"{x:1418,y:722,t:1526930024397};\\\", \\\"{x:1418,y:724,t:1526930024413};\\\", \\\"{x:1418,y:725,t:1526930024430};\\\", \\\"{x:1418,y:727,t:1526930024447};\\\", \\\"{x:1418,y:729,t:1526930024463};\\\", \\\"{x:1418,y:731,t:1526930024480};\\\", \\\"{x:1418,y:734,t:1526930024497};\\\", \\\"{x:1419,y:738,t:1526930024513};\\\", \\\"{x:1419,y:744,t:1526930024530};\\\", \\\"{x:1419,y:749,t:1526930024547};\\\", \\\"{x:1420,y:753,t:1526930024563};\\\", \\\"{x:1423,y:760,t:1526930024580};\\\", \\\"{x:1424,y:764,t:1526930024598};\\\", \\\"{x:1426,y:768,t:1526930024614};\\\", \\\"{x:1426,y:771,t:1526930024631};\\\", \\\"{x:1427,y:773,t:1526930024647};\\\", \\\"{x:1428,y:774,t:1526930024663};\\\", \\\"{x:1428,y:776,t:1526930024681};\\\", \\\"{x:1429,y:778,t:1526930024698};\\\", \\\"{x:1429,y:779,t:1526930024717};\\\", \\\"{x:1430,y:780,t:1526930024730};\\\", \\\"{x:1431,y:783,t:1526930024749};\\\", \\\"{x:1431,y:793,t:1526930024764};\\\", \\\"{x:1431,y:810,t:1526930024781};\\\", \\\"{x:1431,y:829,t:1526930024797};\\\", \\\"{x:1431,y:846,t:1526930024814};\\\", \\\"{x:1431,y:865,t:1526930024830};\\\", \\\"{x:1431,y:888,t:1526930024847};\\\", \\\"{x:1431,y:910,t:1526930024863};\\\", \\\"{x:1431,y:933,t:1526930024880};\\\", \\\"{x:1431,y:954,t:1526930024896};\\\", \\\"{x:1431,y:969,t:1526930024914};\\\", \\\"{x:1431,y:982,t:1526930024930};\\\", \\\"{x:1431,y:994,t:1526930024947};\\\", \\\"{x:1431,y:999,t:1526930024964};\\\", \\\"{x:1431,y:1001,t:1526930024988};\\\", \\\"{x:1431,y:1002,t:1526930025036};\\\", \\\"{x:1431,y:1004,t:1526930025052};\\\", \\\"{x:1431,y:1000,t:1526930025380};\\\", \\\"{x:1431,y:990,t:1526930025398};\\\", \\\"{x:1431,y:984,t:1526930025414};\\\", \\\"{x:1429,y:980,t:1526930025431};\\\", \\\"{x:1429,y:978,t:1526930025448};\\\", \\\"{x:1429,y:977,t:1526930025509};\\\", \\\"{x:1428,y:977,t:1526930025532};\\\", \\\"{x:1428,y:976,t:1526930025548};\\\", \\\"{x:1428,y:971,t:1526930025564};\\\", \\\"{x:1428,y:969,t:1526930025581};\\\", \\\"{x:1427,y:964,t:1526930025598};\\\", \\\"{x:1427,y:962,t:1526930025615};\\\", \\\"{x:1427,y:960,t:1526930025631};\\\", \\\"{x:1426,y:959,t:1526930025647};\\\", \\\"{x:1426,y:957,t:1526930025665};\\\", \\\"{x:1426,y:956,t:1526930025682};\\\", \\\"{x:1426,y:954,t:1526930025698};\\\", \\\"{x:1425,y:952,t:1526930025715};\\\", \\\"{x:1425,y:950,t:1526930025731};\\\", \\\"{x:1424,y:948,t:1526930025748};\\\", \\\"{x:1424,y:947,t:1526930025765};\\\", \\\"{x:1424,y:944,t:1526930025789};\\\", \\\"{x:1424,y:943,t:1526930025804};\\\", \\\"{x:1424,y:942,t:1526930025820};\\\", \\\"{x:1424,y:941,t:1526930025837};\\\", \\\"{x:1424,y:940,t:1526930025924};\\\", \\\"{x:1424,y:939,t:1526930026011};\\\", \\\"{x:1423,y:938,t:1526930026084};\\\", \\\"{x:1423,y:937,t:1526930026109};\\\", \\\"{x:1423,y:936,t:1526930026173};\\\", \\\"{x:1422,y:935,t:1526930026221};\\\", \\\"{x:1422,y:934,t:1526930026231};\\\", \\\"{x:1422,y:933,t:1526930026249};\\\", \\\"{x:1422,y:932,t:1526930026264};\\\", \\\"{x:1421,y:930,t:1526930026281};\\\", \\\"{x:1421,y:929,t:1526930026299};\\\", \\\"{x:1421,y:927,t:1526930026314};\\\", \\\"{x:1421,y:926,t:1526930026332};\\\", \\\"{x:1421,y:925,t:1526930026364};\\\", \\\"{x:1421,y:924,t:1526930026493};\\\", \\\"{x:1420,y:924,t:1526930031085};\\\", \\\"{x:1418,y:915,t:1526930031102};\\\", \\\"{x:1415,y:899,t:1526930031117};\\\", \\\"{x:1414,y:892,t:1526930031134};\\\", \\\"{x:1413,y:886,t:1526930031151};\\\", \\\"{x:1413,y:881,t:1526930031167};\\\", \\\"{x:1412,y:876,t:1526930031185};\\\", \\\"{x:1412,y:867,t:1526930031201};\\\", \\\"{x:1412,y:857,t:1526930031217};\\\", \\\"{x:1412,y:845,t:1526930031234};\\\", \\\"{x:1412,y:802,t:1526930031252};\\\", \\\"{x:1406,y:741,t:1526930031268};\\\", \\\"{x:1396,y:656,t:1526930031284};\\\", \\\"{x:1385,y:575,t:1526930031302};\\\", \\\"{x:1372,y:515,t:1526930031318};\\\", \\\"{x:1370,y:482,t:1526930031334};\\\", \\\"{x:1366,y:463,t:1526930031351};\\\", \\\"{x:1362,y:452,t:1526930031367};\\\", \\\"{x:1361,y:449,t:1526930031384};\\\", \\\"{x:1359,y:447,t:1526930031401};\\\", \\\"{x:1358,y:446,t:1526930031419};\\\", \\\"{x:1356,y:445,t:1526930031434};\\\", \\\"{x:1345,y:440,t:1526930031451};\\\", \\\"{x:1334,y:436,t:1526930031468};\\\", \\\"{x:1326,y:434,t:1526930031484};\\\", \\\"{x:1325,y:434,t:1526930031501};\\\", \\\"{x:1328,y:435,t:1526930031597};\\\", \\\"{x:1329,y:441,t:1526930031604};\\\", \\\"{x:1332,y:448,t:1526930031618};\\\", \\\"{x:1332,y:458,t:1526930031634};\\\", \\\"{x:1332,y:473,t:1526930031652};\\\", \\\"{x:1332,y:479,t:1526930031667};\\\", \\\"{x:1332,y:482,t:1526930031684};\\\", \\\"{x:1332,y:483,t:1526930031701};\\\", \\\"{x:1332,y:484,t:1526930031756};\\\", \\\"{x:1331,y:486,t:1526930032076};\\\", \\\"{x:1329,y:488,t:1526930032084};\\\", \\\"{x:1324,y:494,t:1526930032102};\\\", \\\"{x:1321,y:497,t:1526930032119};\\\", \\\"{x:1317,y:500,t:1526930032136};\\\", \\\"{x:1315,y:502,t:1526930032151};\\\", \\\"{x:1313,y:505,t:1526930032170};\\\", \\\"{x:1312,y:508,t:1526930032186};\\\", \\\"{x:1312,y:514,t:1526930032202};\\\", \\\"{x:1312,y:522,t:1526930032219};\\\", \\\"{x:1309,y:541,t:1526930032236};\\\", \\\"{x:1309,y:551,t:1526930032252};\\\", \\\"{x:1309,y:559,t:1526930032268};\\\", \\\"{x:1309,y:564,t:1526930032286};\\\", \\\"{x:1309,y:569,t:1526930032302};\\\", \\\"{x:1309,y:571,t:1526930032318};\\\", \\\"{x:1310,y:574,t:1526930032336};\\\", \\\"{x:1310,y:575,t:1526930032356};\\\", \\\"{x:1310,y:576,t:1526930032369};\\\", \\\"{x:1311,y:576,t:1526930032395};\\\", \\\"{x:1312,y:577,t:1526930032403};\\\", \\\"{x:1312,y:578,t:1526930032418};\\\", \\\"{x:1315,y:587,t:1526930032435};\\\", \\\"{x:1317,y:593,t:1526930032451};\\\", \\\"{x:1318,y:599,t:1526930032469};\\\", \\\"{x:1322,y:608,t:1526930032485};\\\", \\\"{x:1326,y:614,t:1526930032501};\\\", \\\"{x:1331,y:621,t:1526930032518};\\\", \\\"{x:1333,y:624,t:1526930032536};\\\", \\\"{x:1334,y:627,t:1526930032552};\\\", \\\"{x:1336,y:630,t:1526930032572};\\\", \\\"{x:1340,y:635,t:1526930033923};\\\", \\\"{x:1346,y:646,t:1526930033935};\\\", \\\"{x:1356,y:666,t:1526930033952};\\\", \\\"{x:1359,y:673,t:1526930033970};\\\", \\\"{x:1361,y:679,t:1526930033986};\\\", \\\"{x:1362,y:687,t:1526930034002};\\\", \\\"{x:1364,y:702,t:1526930034020};\\\", \\\"{x:1359,y:714,t:1526930034036};\\\", \\\"{x:1352,y:725,t:1526930034053};\\\", \\\"{x:1350,y:732,t:1526930034070};\\\", \\\"{x:1348,y:736,t:1526930034087};\\\", \\\"{x:1348,y:739,t:1526930034172};\\\", \\\"{x:1348,y:740,t:1526930034187};\\\", \\\"{x:1353,y:754,t:1526930034202};\\\", \\\"{x:1364,y:781,t:1526930034221};\\\", \\\"{x:1370,y:800,t:1526930034236};\\\", \\\"{x:1376,y:821,t:1526930034252};\\\", \\\"{x:1380,y:847,t:1526930034270};\\\", \\\"{x:1384,y:870,t:1526930034286};\\\", \\\"{x:1381,y:891,t:1526930034303};\\\", \\\"{x:1373,y:908,t:1526930034319};\\\", \\\"{x:1362,y:921,t:1526930034337};\\\", \\\"{x:1356,y:927,t:1526930034352};\\\", \\\"{x:1354,y:929,t:1526930034369};\\\", \\\"{x:1352,y:932,t:1526930034460};\\\", \\\"{x:1350,y:936,t:1526930034470};\\\", \\\"{x:1347,y:942,t:1526930034486};\\\", \\\"{x:1346,y:944,t:1526930034503};\\\", \\\"{x:1345,y:945,t:1526930034519};\\\", \\\"{x:1345,y:944,t:1526930034637};\\\", \\\"{x:1348,y:935,t:1526930034653};\\\", \\\"{x:1352,y:928,t:1526930034670};\\\", \\\"{x:1356,y:921,t:1526930034687};\\\", \\\"{x:1359,y:913,t:1526930034704};\\\", \\\"{x:1363,y:905,t:1526930034720};\\\", \\\"{x:1365,y:898,t:1526930034737};\\\", \\\"{x:1365,y:892,t:1526930034754};\\\", \\\"{x:1368,y:886,t:1526930034769};\\\", \\\"{x:1370,y:877,t:1526930034786};\\\", \\\"{x:1377,y:855,t:1526930034803};\\\", \\\"{x:1383,y:834,t:1526930034819};\\\", \\\"{x:1390,y:812,t:1526930034836};\\\", \\\"{x:1399,y:789,t:1526930034853};\\\", \\\"{x:1408,y:768,t:1526930034869};\\\", \\\"{x:1414,y:752,t:1526930034887};\\\", \\\"{x:1416,y:741,t:1526930034904};\\\", \\\"{x:1416,y:732,t:1526930034920};\\\", \\\"{x:1416,y:727,t:1526930034937};\\\", \\\"{x:1416,y:726,t:1526930034954};\\\", \\\"{x:1416,y:725,t:1526930035172};\\\", \\\"{x:1414,y:725,t:1526930035237};\\\", \\\"{x:1413,y:725,t:1526930035254};\\\", \\\"{x:1408,y:726,t:1526930035271};\\\", \\\"{x:1406,y:729,t:1526930035287};\\\", \\\"{x:1405,y:732,t:1526930035304};\\\", \\\"{x:1404,y:733,t:1526930035321};\\\", \\\"{x:1404,y:735,t:1526930035337};\\\", \\\"{x:1403,y:736,t:1526930035354};\\\", \\\"{x:1403,y:737,t:1526930035460};\\\", \\\"{x:1403,y:741,t:1526930035471};\\\", \\\"{x:1414,y:760,t:1526930035487};\\\", \\\"{x:1437,y:791,t:1526930035504};\\\", \\\"{x:1465,y:828,t:1526930035521};\\\", \\\"{x:1493,y:858,t:1526930035537};\\\", \\\"{x:1515,y:876,t:1526930035553};\\\", \\\"{x:1533,y:888,t:1526930035571};\\\", \\\"{x:1544,y:891,t:1526930035587};\\\", \\\"{x:1548,y:892,t:1526930035604};\\\", \\\"{x:1548,y:889,t:1526930035636};\\\", \\\"{x:1547,y:888,t:1526930035644};\\\", \\\"{x:1546,y:887,t:1526930035654};\\\", \\\"{x:1544,y:886,t:1526930035671};\\\", \\\"{x:1543,y:885,t:1526930035688};\\\", \\\"{x:1542,y:884,t:1526930035704};\\\", \\\"{x:1539,y:882,t:1526930035720};\\\", \\\"{x:1534,y:878,t:1526930035738};\\\", \\\"{x:1526,y:872,t:1526930035754};\\\", \\\"{x:1522,y:870,t:1526930035770};\\\", \\\"{x:1520,y:869,t:1526930035787};\\\", \\\"{x:1519,y:868,t:1526930035803};\\\", \\\"{x:1516,y:866,t:1526930035821};\\\", \\\"{x:1515,y:865,t:1526930035837};\\\", \\\"{x:1514,y:863,t:1526930035854};\\\", \\\"{x:1513,y:861,t:1526930035892};\\\", \\\"{x:1513,y:859,t:1526930035903};\\\", \\\"{x:1512,y:853,t:1526930035921};\\\", \\\"{x:1509,y:844,t:1526930035937};\\\", \\\"{x:1508,y:830,t:1526930035954};\\\", \\\"{x:1504,y:811,t:1526930035971};\\\", \\\"{x:1496,y:779,t:1526930035987};\\\", \\\"{x:1490,y:759,t:1526930036004};\\\", \\\"{x:1487,y:741,t:1526930036020};\\\", \\\"{x:1486,y:724,t:1526930036037};\\\", \\\"{x:1484,y:706,t:1526930036054};\\\", \\\"{x:1484,y:688,t:1526930036070};\\\", \\\"{x:1484,y:676,t:1526930036087};\\\", \\\"{x:1484,y:663,t:1526930036104};\\\", \\\"{x:1484,y:646,t:1526930036121};\\\", \\\"{x:1484,y:631,t:1526930036138};\\\", \\\"{x:1484,y:619,t:1526930036153};\\\", \\\"{x:1487,y:613,t:1526930036171};\\\", \\\"{x:1489,y:610,t:1526930036188};\\\", \\\"{x:1490,y:610,t:1526930036341};\\\", \\\"{x:1492,y:610,t:1526930036356};\\\", \\\"{x:1493,y:610,t:1526930036371};\\\", \\\"{x:1495,y:610,t:1526930036388};\\\", \\\"{x:1498,y:611,t:1526930036405};\\\", \\\"{x:1499,y:612,t:1526930036524};\\\", \\\"{x:1501,y:613,t:1526930036756};\\\", \\\"{x:1501,y:616,t:1526930036772};\\\", \\\"{x:1501,y:632,t:1526930036788};\\\", \\\"{x:1501,y:657,t:1526930036806};\\\", \\\"{x:1501,y:686,t:1526930036822};\\\", \\\"{x:1501,y:714,t:1526930036838};\\\", \\\"{x:1501,y:743,t:1526930036855};\\\", \\\"{x:1506,y:781,t:1526930036872};\\\", \\\"{x:1511,y:815,t:1526930036888};\\\", \\\"{x:1515,y:840,t:1526930036905};\\\", \\\"{x:1518,y:857,t:1526930036922};\\\", \\\"{x:1522,y:872,t:1526930036938};\\\", \\\"{x:1522,y:882,t:1526930036955};\\\", \\\"{x:1522,y:888,t:1526930036973};\\\", \\\"{x:1522,y:889,t:1526930036988};\\\", \\\"{x:1522,y:890,t:1526930037101};\\\", \\\"{x:1522,y:892,t:1526930037108};\\\", \\\"{x:1522,y:893,t:1526930037122};\\\", \\\"{x:1522,y:897,t:1526930037138};\\\", \\\"{x:1522,y:900,t:1526930037155};\\\", \\\"{x:1521,y:904,t:1526930037172};\\\", \\\"{x:1521,y:905,t:1526930037188};\\\", \\\"{x:1521,y:906,t:1526930037204};\\\", \\\"{x:1521,y:910,t:1526930037222};\\\", \\\"{x:1521,y:913,t:1526930037238};\\\", \\\"{x:1520,y:917,t:1526930037254};\\\", \\\"{x:1520,y:921,t:1526930037272};\\\", \\\"{x:1518,y:925,t:1526930037287};\\\", \\\"{x:1518,y:927,t:1526930037305};\\\", \\\"{x:1518,y:930,t:1526930037321};\\\", \\\"{x:1517,y:931,t:1526930037339};\\\", \\\"{x:1516,y:933,t:1526930037354};\\\", \\\"{x:1515,y:935,t:1526930037371};\\\", \\\"{x:1515,y:932,t:1526930037461};\\\", \\\"{x:1515,y:923,t:1526930037472};\\\", \\\"{x:1515,y:907,t:1526930037489};\\\", \\\"{x:1512,y:884,t:1526930037505};\\\", \\\"{x:1502,y:851,t:1526930037522};\\\", \\\"{x:1493,y:810,t:1526930037539};\\\", \\\"{x:1487,y:776,t:1526930037555};\\\", \\\"{x:1484,y:741,t:1526930037572};\\\", \\\"{x:1484,y:732,t:1526930037589};\\\", \\\"{x:1484,y:719,t:1526930037605};\\\", \\\"{x:1485,y:711,t:1526930037622};\\\", \\\"{x:1487,y:707,t:1526930037639};\\\", \\\"{x:1488,y:701,t:1526930037655};\\\", \\\"{x:1489,y:695,t:1526930037672};\\\", \\\"{x:1492,y:688,t:1526930037689};\\\", \\\"{x:1493,y:682,t:1526930037704};\\\", \\\"{x:1495,y:672,t:1526930037722};\\\", \\\"{x:1495,y:663,t:1526930037739};\\\", \\\"{x:1495,y:654,t:1526930037755};\\\", \\\"{x:1490,y:627,t:1526930037772};\\\", \\\"{x:1482,y:606,t:1526930037789};\\\", \\\"{x:1472,y:584,t:1526930037805};\\\", \\\"{x:1460,y:560,t:1526930037822};\\\", \\\"{x:1456,y:543,t:1526930037838};\\\", \\\"{x:1454,y:529,t:1526930037855};\\\", \\\"{x:1454,y:526,t:1526930037871};\\\", \\\"{x:1454,y:523,t:1526930037889};\\\", \\\"{x:1454,y:520,t:1526930037905};\\\", \\\"{x:1454,y:519,t:1526930037940};\\\", \\\"{x:1454,y:517,t:1526930037956};\\\", \\\"{x:1454,y:515,t:1526930037972};\\\", \\\"{x:1454,y:513,t:1526930037989};\\\", \\\"{x:1454,y:512,t:1526930038006};\\\", \\\"{x:1454,y:510,t:1526930038022};\\\", \\\"{x:1453,y:508,t:1526930038039};\\\", \\\"{x:1450,y:503,t:1526930038056};\\\", \\\"{x:1447,y:499,t:1526930038072};\\\", \\\"{x:1439,y:489,t:1526930038088};\\\", \\\"{x:1427,y:475,t:1526930038106};\\\", \\\"{x:1419,y:462,t:1526930038122};\\\", \\\"{x:1405,y:449,t:1526930038139};\\\", \\\"{x:1394,y:439,t:1526930038156};\\\", \\\"{x:1394,y:438,t:1526930038172};\\\", \\\"{x:1393,y:437,t:1526930038189};\\\", \\\"{x:1393,y:436,t:1526930038206};\\\", \\\"{x:1393,y:435,t:1526930038222};\\\", \\\"{x:1393,y:433,t:1526930038239};\\\", \\\"{x:1393,y:429,t:1526930038256};\\\", \\\"{x:1393,y:427,t:1526930038276};\\\", \\\"{x:1394,y:426,t:1526930038289};\\\", \\\"{x:1395,y:424,t:1526930038306};\\\", \\\"{x:1396,y:423,t:1526930038322};\\\", \\\"{x:1397,y:422,t:1526930038339};\\\", \\\"{x:1397,y:421,t:1526930038356};\\\", \\\"{x:1399,y:421,t:1526930038372};\\\", \\\"{x:1403,y:421,t:1526930038389};\\\", \\\"{x:1408,y:423,t:1526930038406};\\\", \\\"{x:1411,y:424,t:1526930038422};\\\", \\\"{x:1412,y:425,t:1526930038440};\\\", \\\"{x:1415,y:429,t:1526930038652};\\\", \\\"{x:1416,y:443,t:1526930038661};\\\", \\\"{x:1416,y:459,t:1526930038673};\\\", \\\"{x:1416,y:502,t:1526930038689};\\\", \\\"{x:1394,y:566,t:1526930038706};\\\", \\\"{x:1341,y:659,t:1526930038723};\\\", \\\"{x:1248,y:759,t:1526930038739};\\\", \\\"{x:1034,y:907,t:1526930038756};\\\", \\\"{x:857,y:997,t:1526930038773};\\\", \\\"{x:679,y:1065,t:1526930038789};\\\", \\\"{x:540,y:1085,t:1526930038806};\\\", \\\"{x:496,y:1085,t:1526930038823};\\\", \\\"{x:491,y:1083,t:1526930038839};\\\", \\\"{x:491,y:1081,t:1526930038856};\\\", \\\"{x:491,y:1075,t:1526930038872};\\\", \\\"{x:491,y:1068,t:1526930038889};\\\", \\\"{x:491,y:1064,t:1526930038906};\\\", \\\"{x:491,y:1055,t:1526930038923};\\\", \\\"{x:491,y:1049,t:1526930038939};\\\", \\\"{x:490,y:1044,t:1526930038955};\\\", \\\"{x:490,y:1042,t:1526930038973};\\\", \\\"{x:490,y:1039,t:1526930038988};\\\", \\\"{x:490,y:1035,t:1526930039005};\\\", \\\"{x:490,y:1030,t:1526930039022};\\\", \\\"{x:490,y:1024,t:1526930039039};\\\", \\\"{x:491,y:1016,t:1526930039055};\\\", \\\"{x:492,y:1007,t:1526930039072};\\\", \\\"{x:494,y:993,t:1526930039089};\\\", \\\"{x:496,y:980,t:1526930039106};\\\", \\\"{x:498,y:965,t:1526930039122};\\\", \\\"{x:503,y:939,t:1526930039139};\\\", \\\"{x:504,y:929,t:1526930039155};\\\", \\\"{x:508,y:916,t:1526930039173};\\\", \\\"{x:512,y:906,t:1526930039190};\\\", \\\"{x:514,y:898,t:1526930039206};\\\", \\\"{x:515,y:893,t:1526930039223};\\\", \\\"{x:516,y:886,t:1526930039240};\\\", \\\"{x:517,y:883,t:1526930039255};\\\", \\\"{x:518,y:879,t:1526930039273};\\\", \\\"{x:519,y:879,t:1526930039290};\\\", \\\"{x:520,y:877,t:1526930039306};\\\", \\\"{x:520,y:874,t:1526930039323};\\\", \\\"{x:521,y:872,t:1526930039339};\\\", \\\"{x:522,y:868,t:1526930039356};\\\", \\\"{x:522,y:867,t:1526930039372};\\\", \\\"{x:523,y:864,t:1526930039390};\\\", \\\"{x:524,y:863,t:1526930039411};\\\", \\\"{x:524,y:862,t:1526930039491};\\\", \\\"{x:524,y:861,t:1526930039506};\\\", \\\"{x:524,y:860,t:1526930039522};\\\", \\\"{x:525,y:859,t:1526930039540};\\\", \\\"{x:525,y:858,t:1526930039556};\\\", \\\"{x:525,y:857,t:1526930039628};\\\", \\\"{x:528,y:853,t:1526930040420};\\\", \\\"{x:569,y:836,t:1526930040428};\\\", \\\"{x:627,y:817,t:1526930040440};\\\", \\\"{x:814,y:746,t:1526930040457};\\\", \\\"{x:1032,y:675,t:1526930040475};\\\", \\\"{x:1270,y:594,t:1526930040490};\\\", \\\"{x:1527,y:515,t:1526930040507};\\\", \\\"{x:1878,y:404,t:1526930040524};\\\", \\\"{x:1919,y:356,t:1526930040540};\\\", \\\"{x:1919,y:328,t:1526930040556};\\\", \\\"{x:1919,y:324,t:1526930040580};\\\", \\\"{x:1918,y:325,t:1526930040603};\\\", \\\"{x:1912,y:327,t:1526930040614};\\\", \\\"{x:1890,y:327,t:1526930040629};\\\", \\\"{x:1867,y:327,t:1526930040646};\\\", \\\"{x:1840,y:325,t:1526930040664};\\\", \\\"{x:1814,y:323,t:1526930040679};\\\", \\\"{x:1786,y:320,t:1526930040697};\\\", \\\"{x:1754,y:320,t:1526930040713};\\\", \\\"{x:1715,y:320,t:1526930040730};\\\", \\\"{x:1676,y:320,t:1526930040746};\\\", \\\"{x:1628,y:323,t:1526930040763};\\\", \\\"{x:1612,y:331,t:1526930040780};\\\", \\\"{x:1606,y:342,t:1526930040796};\\\", \\\"{x:1602,y:357,t:1526930040814};\\\", \\\"{x:1598,y:372,t:1526930040830};\\\", \\\"{x:1585,y:392,t:1526930040847};\\\", \\\"{x:1566,y:417,t:1526930040863};\\\", \\\"{x:1536,y:452,t:1526930040879};\\\", \\\"{x:1500,y:485,t:1526930040897};\\\", \\\"{x:1428,y:519,t:1526930040914};\\\", \\\"{x:1407,y:530,t:1526930040930};\\\", \\\"{x:1359,y:545,t:1526930040947};\\\", \\\"{x:1323,y:535,t:1526930040963};\\\", \\\"{x:1316,y:521,t:1526930040980};\\\", \\\"{x:1317,y:517,t:1526930040997};\\\", \\\"{x:1323,y:507,t:1526930041014};\\\", \\\"{x:1332,y:501,t:1526930041030};\\\", \\\"{x:1341,y:495,t:1526930041047};\\\", \\\"{x:1352,y:492,t:1526930041064};\\\", \\\"{x:1358,y:488,t:1526930041080};\\\", \\\"{x:1362,y:485,t:1526930041096};\\\", \\\"{x:1363,y:485,t:1526930041113};\\\", \\\"{x:1364,y:480,t:1526930041131};\\\", \\\"{x:1367,y:474,t:1526930041147};\\\", \\\"{x:1376,y:464,t:1526930041164};\\\", \\\"{x:1382,y:460,t:1526930041182};\\\", \\\"{x:1384,y:457,t:1526930041197};\\\", \\\"{x:1388,y:454,t:1526930041215};\\\", \\\"{x:1393,y:452,t:1526930041232};\\\", \\\"{x:1402,y:447,t:1526930041247};\\\", \\\"{x:1409,y:443,t:1526930041264};\\\", \\\"{x:1412,y:441,t:1526930041281};\\\", \\\"{x:1413,y:439,t:1526930041297};\\\", \\\"{x:1413,y:438,t:1526930041316};\\\", \\\"{x:1414,y:437,t:1526930041380};\\\", \\\"{x:1414,y:436,t:1526930042332};\\\", \\\"{x:1414,y:435,t:1526930042900};\\\", \\\"{x:1415,y:434,t:1526930043204};\\\", \\\"{x:1415,y:432,t:1526930043725};\\\", \\\"{x:1407,y:431,t:1526930043733};\\\", \\\"{x:1361,y:453,t:1526930043750};\\\", \\\"{x:1286,y:499,t:1526930043766};\\\", \\\"{x:1177,y:557,t:1526930043782};\\\", \\\"{x:1067,y:610,t:1526930043799};\\\", \\\"{x:946,y:656,t:1526930043816};\\\", \\\"{x:838,y:689,t:1526930043832};\\\", \\\"{x:748,y:708,t:1526930043849};\\\", \\\"{x:707,y:718,t:1526930043866};\\\", \\\"{x:688,y:722,t:1526930043883};\\\", \\\"{x:684,y:724,t:1526930043899};\\\", \\\"{x:683,y:725,t:1526930043916};\\\", \\\"{x:680,y:725,t:1526930043933};\\\", \\\"{x:662,y:736,t:1526930043950};\\\", \\\"{x:612,y:759,t:1526930043966};\\\", \\\"{x:539,y:782,t:1526930043984};\\\", \\\"{x:464,y:800,t:1526930043999};\\\", \\\"{x:366,y:806,t:1526930044016};\\\", \\\"{x:286,y:805,t:1526930044033};\\\", \\\"{x:254,y:797,t:1526930044049};\\\", \\\"{x:251,y:794,t:1526930044066};\\\", \\\"{x:251,y:791,t:1526930044083};\\\", \\\"{x:256,y:785,t:1526930044099};\\\", \\\"{x:267,y:775,t:1526930044115};\\\", \\\"{x:279,y:766,t:1526930044133};\\\", \\\"{x:295,y:759,t:1526930044150};\\\", \\\"{x:318,y:749,t:1526930044166};\\\", \\\"{x:342,y:738,t:1526930044183};\\\", \\\"{x:364,y:731,t:1526930044198};\\\", \\\"{x:384,y:726,t:1526930044216};\\\", \\\"{x:399,y:726,t:1526930044233};\\\", \\\"{x:418,y:726,t:1526930044248};\\\", \\\"{x:434,y:726,t:1526930044266};\\\", \\\"{x:449,y:726,t:1526930044283};\\\", \\\"{x:471,y:726,t:1526930044299};\\\", \\\"{x:484,y:726,t:1526930044315};\\\", \\\"{x:499,y:726,t:1526930044331};\\\", \\\"{x:506,y:726,t:1526930044348};\\\", \\\"{x:511,y:726,t:1526930044364};\\\", \\\"{x:512,y:726,t:1526930044419};\\\", \\\"{x:513,y:726,t:1526930044435};\\\", \\\"{x:514,y:726,t:1526930044447};\\\", \\\"{x:515,y:726,t:1526930044464};\\\", \\\"{x:516,y:726,t:1526930044515};\\\", \\\"{x:520,y:726,t:1526930044860};\\\", \\\"{x:530,y:726,t:1526930044867};\\\", \\\"{x:542,y:726,t:1526930044883};\\\", \\\"{x:610,y:726,t:1526930044900};\\\", \\\"{x:674,y:726,t:1526930044917};\\\", \\\"{x:746,y:726,t:1526930044933};\\\", \\\"{x:811,y:726,t:1526930044950};\\\", \\\"{x:855,y:726,t:1526930044967};\\\", \\\"{x:880,y:726,t:1526930044983};\\\", \\\"{x:889,y:726,t:1526930045000};\\\" ] }, { \\\"rt\\\": 8069, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 377796, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:892,y:726,t:1526930047340};\\\", \\\"{x:902,y:733,t:1526930047352};\\\", \\\"{x:933,y:757,t:1526930047369};\\\", \\\"{x:974,y:783,t:1526930047385};\\\", \\\"{x:1017,y:798,t:1526930047403};\\\", \\\"{x:1050,y:807,t:1526930047419};\\\", \\\"{x:1061,y:809,t:1526930047435};\\\", \\\"{x:1062,y:809,t:1526930048372};\\\", \\\"{x:1063,y:809,t:1526930048386};\\\", \\\"{x:1064,y:801,t:1526930048403};\\\", \\\"{x:1065,y:797,t:1526930048420};\\\", \\\"{x:1074,y:777,t:1526930048436};\\\", \\\"{x:1083,y:757,t:1526930048453};\\\", \\\"{x:1100,y:728,t:1526930048469};\\\", \\\"{x:1117,y:686,t:1526930048486};\\\", \\\"{x:1137,y:635,t:1526930048503};\\\", \\\"{x:1156,y:565,t:1526930048519};\\\", \\\"{x:1173,y:504,t:1526930048536};\\\", \\\"{x:1193,y:435,t:1526930048553};\\\", \\\"{x:1207,y:385,t:1526930048569};\\\", \\\"{x:1216,y:354,t:1526930048586};\\\", \\\"{x:1226,y:321,t:1526930048604};\\\", \\\"{x:1229,y:310,t:1526930048619};\\\", \\\"{x:1230,y:306,t:1526930048637};\\\", \\\"{x:1230,y:305,t:1526930048692};\\\", \\\"{x:1230,y:304,t:1526930048708};\\\", \\\"{x:1229,y:304,t:1526930048731};\\\", \\\"{x:1227,y:303,t:1526930048748};\\\", \\\"{x:1226,y:303,t:1526930048756};\\\", \\\"{x:1224,y:302,t:1526930048770};\\\", \\\"{x:1222,y:301,t:1526930048786};\\\", \\\"{x:1217,y:301,t:1526930048803};\\\", \\\"{x:1212,y:301,t:1526930048820};\\\", \\\"{x:1209,y:302,t:1526930048836};\\\", \\\"{x:1208,y:302,t:1526930048854};\\\", \\\"{x:1206,y:303,t:1526930048871};\\\", \\\"{x:1205,y:303,t:1526930048908};\\\", \\\"{x:1204,y:309,t:1526930049076};\\\", \\\"{x:1204,y:316,t:1526930049086};\\\", \\\"{x:1204,y:335,t:1526930049103};\\\", \\\"{x:1204,y:367,t:1526930049120};\\\", \\\"{x:1204,y:445,t:1526930049137};\\\", \\\"{x:1200,y:559,t:1526930049153};\\\", \\\"{x:1198,y:651,t:1526930049171};\\\", \\\"{x:1187,y:729,t:1526930049187};\\\", \\\"{x:1177,y:776,t:1526930049203};\\\", \\\"{x:1169,y:809,t:1526930049219};\\\", \\\"{x:1169,y:813,t:1526930049236};\\\", \\\"{x:1169,y:814,t:1526930049254};\\\", \\\"{x:1173,y:810,t:1526930049284};\\\", \\\"{x:1176,y:804,t:1526930049292};\\\", \\\"{x:1180,y:799,t:1526930049303};\\\", \\\"{x:1183,y:787,t:1526930049320};\\\", \\\"{x:1185,y:770,t:1526930049338};\\\", \\\"{x:1186,y:745,t:1526930049354};\\\", \\\"{x:1186,y:716,t:1526930049371};\\\", \\\"{x:1186,y:670,t:1526930049388};\\\", \\\"{x:1182,y:643,t:1526930049404};\\\", \\\"{x:1175,y:617,t:1526930049420};\\\", \\\"{x:1170,y:597,t:1526930049437};\\\", \\\"{x:1167,y:588,t:1526930049454};\\\", \\\"{x:1166,y:586,t:1526930049471};\\\", \\\"{x:1161,y:584,t:1526930049487};\\\", \\\"{x:1156,y:581,t:1526930049503};\\\", \\\"{x:1147,y:578,t:1526930049520};\\\", \\\"{x:1140,y:574,t:1526930049537};\\\", \\\"{x:1137,y:573,t:1526930049553};\\\", \\\"{x:1138,y:573,t:1526930049604};\\\", \\\"{x:1147,y:573,t:1526930049620};\\\", \\\"{x:1168,y:573,t:1526930049637};\\\", \\\"{x:1189,y:573,t:1526930049653};\\\", \\\"{x:1213,y:575,t:1526930049671};\\\", \\\"{x:1239,y:575,t:1526930049687};\\\", \\\"{x:1264,y:575,t:1526930049703};\\\", \\\"{x:1293,y:576,t:1526930049721};\\\", \\\"{x:1319,y:576,t:1526930049738};\\\", \\\"{x:1339,y:576,t:1526930049754};\\\", \\\"{x:1353,y:576,t:1526930049770};\\\", \\\"{x:1368,y:576,t:1526930049788};\\\", \\\"{x:1378,y:576,t:1526930049804};\\\", \\\"{x:1392,y:576,t:1526930049821};\\\", \\\"{x:1411,y:576,t:1526930049837};\\\", \\\"{x:1429,y:576,t:1526930049854};\\\", \\\"{x:1453,y:576,t:1526930049870};\\\", \\\"{x:1476,y:576,t:1526930049886};\\\", \\\"{x:1503,y:576,t:1526930049904};\\\", \\\"{x:1547,y:576,t:1526930049919};\\\", \\\"{x:1589,y:576,t:1526930049937};\\\", \\\"{x:1625,y:576,t:1526930049954};\\\", \\\"{x:1647,y:576,t:1526930049970};\\\", \\\"{x:1658,y:576,t:1526930049987};\\\", \\\"{x:1657,y:576,t:1526930050115};\\\", \\\"{x:1656,y:575,t:1526930050131};\\\", \\\"{x:1654,y:574,t:1526930050147};\\\", \\\"{x:1653,y:574,t:1526930050155};\\\", \\\"{x:1641,y:571,t:1526930050171};\\\", \\\"{x:1589,y:565,t:1526930050187};\\\", \\\"{x:1458,y:561,t:1526930050204};\\\", \\\"{x:1269,y:574,t:1526930050220};\\\", \\\"{x:1058,y:583,t:1526930050237};\\\", \\\"{x:850,y:590,t:1526930050255};\\\", \\\"{x:672,y:603,t:1526930050272};\\\", \\\"{x:544,y:603,t:1526930050287};\\\", \\\"{x:478,y:603,t:1526930050304};\\\", \\\"{x:466,y:604,t:1526930050321};\\\", \\\"{x:465,y:606,t:1526930050338};\\\", \\\"{x:471,y:608,t:1526930050353};\\\", \\\"{x:475,y:611,t:1526930050371};\\\", \\\"{x:474,y:611,t:1526930050435};\\\", \\\"{x:471,y:611,t:1526930050443};\\\", \\\"{x:464,y:611,t:1526930050454};\\\", \\\"{x:463,y:611,t:1526930050471};\\\", \\\"{x:467,y:611,t:1526930050488};\\\", \\\"{x:483,y:609,t:1526930050504};\\\", \\\"{x:500,y:602,t:1526930050522};\\\", \\\"{x:519,y:594,t:1526930050538};\\\", \\\"{x:540,y:585,t:1526930050554};\\\", \\\"{x:598,y:565,t:1526930050571};\\\", \\\"{x:658,y:558,t:1526930050588};\\\", \\\"{x:723,y:555,t:1526930050605};\\\", \\\"{x:760,y:555,t:1526930050621};\\\", \\\"{x:777,y:553,t:1526930050638};\\\", \\\"{x:783,y:552,t:1526930050654};\\\", \\\"{x:784,y:552,t:1526930050671};\\\", \\\"{x:784,y:551,t:1526930050688};\\\", \\\"{x:771,y:544,t:1526930050704};\\\", \\\"{x:753,y:536,t:1526930050721};\\\", \\\"{x:729,y:526,t:1526930050739};\\\", \\\"{x:710,y:515,t:1526930050756};\\\", \\\"{x:684,y:504,t:1526930050771};\\\", \\\"{x:676,y:501,t:1526930050788};\\\", \\\"{x:674,y:501,t:1526930050805};\\\", \\\"{x:673,y:500,t:1526930050821};\\\", \\\"{x:672,y:500,t:1526930050842};\\\", \\\"{x:670,y:499,t:1526930050875};\\\", \\\"{x:667,y:499,t:1526930050890};\\\", \\\"{x:663,y:498,t:1526930050905};\\\", \\\"{x:652,y:495,t:1526930050921};\\\", \\\"{x:637,y:489,t:1526930050938};\\\", \\\"{x:631,y:486,t:1526930050956};\\\", \\\"{x:626,y:483,t:1526930050971};\\\", \\\"{x:618,y:482,t:1526930050988};\\\", \\\"{x:616,y:479,t:1526930051005};\\\", \\\"{x:617,y:479,t:1526930051252};\\\", \\\"{x:619,y:479,t:1526930051260};\\\", \\\"{x:622,y:480,t:1526930051272};\\\", \\\"{x:630,y:484,t:1526930051288};\\\", \\\"{x:636,y:487,t:1526930051307};\\\", \\\"{x:645,y:492,t:1526930051321};\\\", \\\"{x:650,y:494,t:1526930051338};\\\", \\\"{x:651,y:494,t:1526930051355};\\\", \\\"{x:652,y:495,t:1526930051372};\\\", \\\"{x:649,y:497,t:1526930051388};\\\", \\\"{x:648,y:499,t:1526930051405};\\\", \\\"{x:643,y:501,t:1526930051422};\\\", \\\"{x:635,y:504,t:1526930051438};\\\", \\\"{x:627,y:507,t:1526930051455};\\\", \\\"{x:622,y:508,t:1526930051471};\\\", \\\"{x:620,y:508,t:1526930051488};\\\", \\\"{x:619,y:508,t:1526930051540};\\\", \\\"{x:619,y:507,t:1526930051691};\\\", \\\"{x:623,y:506,t:1526930051705};\\\", \\\"{x:632,y:503,t:1526930051722};\\\", \\\"{x:668,y:501,t:1526930051739};\\\", \\\"{x:716,y:508,t:1526930051755};\\\", \\\"{x:787,y:527,t:1526930051772};\\\", \\\"{x:851,y:544,t:1526930051789};\\\", \\\"{x:877,y:548,t:1526930051805};\\\", \\\"{x:898,y:550,t:1526930051821};\\\", \\\"{x:919,y:558,t:1526930051840};\\\", \\\"{x:938,y:563,t:1526930051856};\\\", \\\"{x:941,y:565,t:1526930051872};\\\", \\\"{x:942,y:565,t:1526930051889};\\\", \\\"{x:943,y:565,t:1526930051905};\\\", \\\"{x:938,y:565,t:1526930051931};\\\", \\\"{x:937,y:565,t:1526930051939};\\\", \\\"{x:929,y:563,t:1526930051958};\\\", \\\"{x:921,y:561,t:1526930051976};\\\", \\\"{x:915,y:559,t:1526930051993};\\\", \\\"{x:904,y:554,t:1526930052010};\\\", \\\"{x:901,y:554,t:1526930052025};\\\", \\\"{x:897,y:552,t:1526930052042};\\\", \\\"{x:896,y:551,t:1526930052059};\\\", \\\"{x:896,y:550,t:1526930052111};\\\", \\\"{x:895,y:549,t:1526930052143};\\\", \\\"{x:889,y:545,t:1526930052159};\\\", \\\"{x:882,y:542,t:1526930052176};\\\", \\\"{x:878,y:541,t:1526930052192};\\\", \\\"{x:874,y:539,t:1526930052210};\\\", \\\"{x:869,y:538,t:1526930052226};\\\", \\\"{x:866,y:538,t:1526930052243};\\\", \\\"{x:865,y:537,t:1526930052260};\\\", \\\"{x:863,y:538,t:1526930052559};\\\", \\\"{x:842,y:574,t:1526930052578};\\\", \\\"{x:807,y:641,t:1526930052593};\\\", \\\"{x:739,y:741,t:1526930052610};\\\", \\\"{x:624,y:853,t:1526930052627};\\\", \\\"{x:487,y:963,t:1526930052642};\\\", \\\"{x:354,y:1031,t:1526930052659};\\\", \\\"{x:238,y:1087,t:1526930052677};\\\", \\\"{x:141,y:1111,t:1526930052693};\\\", \\\"{x:117,y:1114,t:1526930052710};\\\", \\\"{x:94,y:1107,t:1526930052726};\\\", \\\"{x:92,y:1098,t:1526930052742};\\\", \\\"{x:92,y:1080,t:1526930052759};\\\", \\\"{x:102,y:1064,t:1526930052777};\\\", \\\"{x:126,y:1047,t:1526930052793};\\\", \\\"{x:148,y:1031,t:1526930052810};\\\", \\\"{x:161,y:1023,t:1526930052827};\\\", \\\"{x:169,y:1016,t:1526930052842};\\\", \\\"{x:174,y:1011,t:1526930052859};\\\", \\\"{x:176,y:1008,t:1526930052877};\\\", \\\"{x:181,y:998,t:1526930052893};\\\", \\\"{x:189,y:982,t:1526930052909};\\\", \\\"{x:214,y:945,t:1526930052926};\\\", \\\"{x:233,y:918,t:1526930052943};\\\", \\\"{x:253,y:889,t:1526930052959};\\\", \\\"{x:280,y:856,t:1526930052977};\\\", \\\"{x:306,y:835,t:1526930052993};\\\", \\\"{x:338,y:814,t:1526930053009};\\\", \\\"{x:361,y:798,t:1526930053027};\\\", \\\"{x:377,y:789,t:1526930053043};\\\", \\\"{x:384,y:786,t:1526930053060};\\\", \\\"{x:386,y:784,t:1526930053077};\\\", \\\"{x:388,y:784,t:1526930053094};\\\", \\\"{x:394,y:784,t:1526930053110};\\\", \\\"{x:408,y:784,t:1526930053127};\\\", \\\"{x:419,y:782,t:1526930053144};\\\", \\\"{x:428,y:780,t:1526930053161};\\\", \\\"{x:429,y:778,t:1526930053177};\\\", \\\"{x:432,y:776,t:1526930053360};\\\", \\\"{x:446,y:767,t:1526930053377};\\\", \\\"{x:463,y:760,t:1526930053395};\\\", \\\"{x:479,y:753,t:1526930053411};\\\", \\\"{x:492,y:749,t:1526930053427};\\\", \\\"{x:498,y:746,t:1526930053442};\\\", \\\"{x:501,y:744,t:1526930053459};\\\", \\\"{x:502,y:744,t:1526930053474};\\\", \\\"{x:503,y:744,t:1526930053492};\\\", \\\"{x:504,y:744,t:1526930053509};\\\", \\\"{x:511,y:743,t:1526930053524};\\\", \\\"{x:520,y:740,t:1526930053541};\\\", \\\"{x:532,y:737,t:1526930053559};\\\", \\\"{x:539,y:735,t:1526930053575};\\\", \\\"{x:546,y:733,t:1526930053592};\\\" ] }, { \\\"rt\\\": 27275, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 406297, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -F -F -B -B -12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:733,t:1526930057224};\\\", \\\"{x:549,y:738,t:1526930057254};\\\", \\\"{x:549,y:739,t:1526930057264};\\\", \\\"{x:550,y:739,t:1526930057280};\\\", \\\"{x:552,y:739,t:1526930057302};\\\", \\\"{x:554,y:740,t:1526930057314};\\\", \\\"{x:556,y:740,t:1526930057504};\\\", \\\"{x:557,y:740,t:1526930057514};\\\", \\\"{x:558,y:732,t:1526930057530};\\\", \\\"{x:558,y:723,t:1526930057547};\\\", \\\"{x:553,y:702,t:1526930057564};\\\", \\\"{x:540,y:672,t:1526930057581};\\\", \\\"{x:525,y:646,t:1526930057597};\\\", \\\"{x:495,y:601,t:1526930057614};\\\", \\\"{x:447,y:543,t:1526930057631};\\\", \\\"{x:428,y:520,t:1526930057646};\\\", \\\"{x:411,y:498,t:1526930057664};\\\", \\\"{x:399,y:482,t:1526930057680};\\\", \\\"{x:389,y:469,t:1526930057696};\\\", \\\"{x:387,y:459,t:1526930057713};\\\", \\\"{x:382,y:442,t:1526930057729};\\\", \\\"{x:374,y:423,t:1526930057747};\\\", \\\"{x:365,y:401,t:1526930057764};\\\", \\\"{x:357,y:383,t:1526930057780};\\\", \\\"{x:353,y:376,t:1526930057796};\\\", \\\"{x:353,y:374,t:1526930057813};\\\", \\\"{x:353,y:373,t:1526930057967};\\\", \\\"{x:356,y:373,t:1526930057982};\\\", \\\"{x:361,y:375,t:1526930057998};\\\", \\\"{x:370,y:379,t:1526930058014};\\\", \\\"{x:384,y:391,t:1526930058031};\\\", \\\"{x:388,y:404,t:1526930058047};\\\", \\\"{x:388,y:411,t:1526930058065};\\\", \\\"{x:388,y:417,t:1526930058081};\\\", \\\"{x:388,y:421,t:1526930058097};\\\", \\\"{x:388,y:422,t:1526930058115};\\\", \\\"{x:388,y:423,t:1526930058135};\\\", \\\"{x:389,y:423,t:1526930062008};\\\", \\\"{x:393,y:424,t:1526930062018};\\\", \\\"{x:403,y:429,t:1526930062034};\\\", \\\"{x:424,y:434,t:1526930062051};\\\", \\\"{x:455,y:443,t:1526930062068};\\\", \\\"{x:504,y:454,t:1526930062084};\\\", \\\"{x:564,y:465,t:1526930062100};\\\", \\\"{x:636,y:476,t:1526930062118};\\\", \\\"{x:695,y:486,t:1526930062134};\\\", \\\"{x:751,y:492,t:1526930062152};\\\", \\\"{x:755,y:492,t:1526930062167};\\\", \\\"{x:757,y:492,t:1526930062791};\\\", \\\"{x:759,y:492,t:1526930062807};\\\", \\\"{x:761,y:493,t:1526930062818};\\\", \\\"{x:763,y:493,t:1526930062834};\\\", \\\"{x:766,y:493,t:1526930062852};\\\", \\\"{x:769,y:495,t:1526930062869};\\\", \\\"{x:771,y:495,t:1526930062887};\\\", \\\"{x:773,y:496,t:1526930062901};\\\", \\\"{x:778,y:497,t:1526930062918};\\\", \\\"{x:783,y:498,t:1526930062935};\\\", \\\"{x:799,y:504,t:1526930062951};\\\", \\\"{x:817,y:510,t:1526930062969};\\\", \\\"{x:843,y:518,t:1526930062986};\\\", \\\"{x:920,y:540,t:1526930063002};\\\", \\\"{x:1022,y:566,t:1526930063018};\\\", \\\"{x:1138,y:593,t:1526930063034};\\\", \\\"{x:1254,y:624,t:1526930063051};\\\", \\\"{x:1359,y:638,t:1526930063068};\\\", \\\"{x:1445,y:654,t:1526930063084};\\\", \\\"{x:1485,y:660,t:1526930063101};\\\", \\\"{x:1500,y:664,t:1526930063118};\\\", \\\"{x:1503,y:665,t:1526930063134};\\\", \\\"{x:1500,y:668,t:1526930063152};\\\", \\\"{x:1491,y:668,t:1526930063168};\\\", \\\"{x:1484,y:669,t:1526930063185};\\\", \\\"{x:1476,y:673,t:1526930063201};\\\", \\\"{x:1463,y:679,t:1526930063219};\\\", \\\"{x:1442,y:686,t:1526930063235};\\\", \\\"{x:1413,y:695,t:1526930063251};\\\", \\\"{x:1387,y:700,t:1526930063268};\\\", \\\"{x:1358,y:703,t:1526930063286};\\\", \\\"{x:1334,y:705,t:1526930063301};\\\", \\\"{x:1301,y:705,t:1526930063318};\\\", \\\"{x:1224,y:705,t:1526930063334};\\\", \\\"{x:1190,y:706,t:1526930063351};\\\", \\\"{x:1174,y:707,t:1526930063369};\\\", \\\"{x:1172,y:707,t:1526930063385};\\\", \\\"{x:1176,y:707,t:1526930063487};\\\", \\\"{x:1182,y:707,t:1526930063501};\\\", \\\"{x:1194,y:706,t:1526930063518};\\\", \\\"{x:1212,y:706,t:1526930063535};\\\", \\\"{x:1229,y:706,t:1526930063551};\\\", \\\"{x:1238,y:706,t:1526930063569};\\\", \\\"{x:1255,y:706,t:1526930063586};\\\", \\\"{x:1273,y:706,t:1526930063601};\\\", \\\"{x:1294,y:706,t:1526930063618};\\\", \\\"{x:1316,y:706,t:1526930063636};\\\", \\\"{x:1343,y:706,t:1526930063651};\\\", \\\"{x:1369,y:706,t:1526930063669};\\\", \\\"{x:1395,y:704,t:1526930063685};\\\", \\\"{x:1421,y:700,t:1526930063703};\\\", \\\"{x:1446,y:695,t:1526930063718};\\\", \\\"{x:1476,y:688,t:1526930063736};\\\", \\\"{x:1499,y:684,t:1526930063753};\\\", \\\"{x:1521,y:684,t:1526930063768};\\\", \\\"{x:1535,y:682,t:1526930063786};\\\", \\\"{x:1551,y:682,t:1526930063802};\\\", \\\"{x:1557,y:682,t:1526930063819};\\\", \\\"{x:1563,y:684,t:1526930063835};\\\", \\\"{x:1570,y:686,t:1526930063853};\\\", \\\"{x:1570,y:687,t:1526930063869};\\\", \\\"{x:1570,y:688,t:1526930064000};\\\", \\\"{x:1569,y:688,t:1526930064016};\\\", \\\"{x:1568,y:688,t:1526930064031};\\\", \\\"{x:1567,y:688,t:1526930064039};\\\", \\\"{x:1566,y:688,t:1526930064052};\\\", \\\"{x:1559,y:691,t:1526930064068};\\\", \\\"{x:1546,y:693,t:1526930064085};\\\", \\\"{x:1520,y:697,t:1526930064102};\\\", \\\"{x:1448,y:706,t:1526930064118};\\\", \\\"{x:1365,y:715,t:1526930064135};\\\", \\\"{x:1297,y:719,t:1526930064152};\\\", \\\"{x:1250,y:719,t:1526930064169};\\\", \\\"{x:1217,y:722,t:1526930064186};\\\", \\\"{x:1199,y:725,t:1526930064203};\\\", \\\"{x:1192,y:725,t:1526930064219};\\\", \\\"{x:1191,y:725,t:1526930064235};\\\", \\\"{x:1192,y:725,t:1526930064343};\\\", \\\"{x:1195,y:725,t:1526930064353};\\\", \\\"{x:1202,y:724,t:1526930064369};\\\", \\\"{x:1214,y:719,t:1526930064385};\\\", \\\"{x:1226,y:714,t:1526930064402};\\\", \\\"{x:1235,y:711,t:1526930064420};\\\", \\\"{x:1241,y:709,t:1526930064436};\\\", \\\"{x:1244,y:707,t:1526930064452};\\\", \\\"{x:1247,y:706,t:1526930064470};\\\", \\\"{x:1253,y:704,t:1526930064486};\\\", \\\"{x:1255,y:703,t:1526930064502};\\\", \\\"{x:1264,y:701,t:1526930064519};\\\", \\\"{x:1269,y:700,t:1526930064536};\\\", \\\"{x:1275,y:699,t:1526930064553};\\\", \\\"{x:1280,y:698,t:1526930064570};\\\", \\\"{x:1286,y:698,t:1526930064585};\\\", \\\"{x:1291,y:697,t:1526930064603};\\\", \\\"{x:1296,y:696,t:1526930064620};\\\", \\\"{x:1301,y:695,t:1526930064636};\\\", \\\"{x:1303,y:695,t:1526930064652};\\\", \\\"{x:1306,y:695,t:1526930064670};\\\", \\\"{x:1308,y:694,t:1526930064686};\\\", \\\"{x:1309,y:694,t:1526930064703};\\\", \\\"{x:1315,y:694,t:1526930064719};\\\", \\\"{x:1316,y:694,t:1526930064783};\\\", \\\"{x:1317,y:694,t:1526930065241};\\\", \\\"{x:1318,y:694,t:1526930065254};\\\", \\\"{x:1319,y:694,t:1526930065269};\\\", \\\"{x:1320,y:694,t:1526930065286};\\\", \\\"{x:1321,y:694,t:1526930065303};\\\", \\\"{x:1322,y:695,t:1526930065327};\\\", \\\"{x:1323,y:695,t:1526930065398};\\\", \\\"{x:1324,y:695,t:1526930065423};\\\", \\\"{x:1325,y:695,t:1526930065776};\\\", \\\"{x:1326,y:696,t:1526930065792};\\\", \\\"{x:1327,y:696,t:1526930065803};\\\", \\\"{x:1330,y:696,t:1526930065820};\\\", \\\"{x:1333,y:696,t:1526930065836};\\\", \\\"{x:1336,y:696,t:1526930065853};\\\", \\\"{x:1339,y:696,t:1526930065870};\\\", \\\"{x:1341,y:696,t:1526930065886};\\\", \\\"{x:1342,y:696,t:1526930065905};\\\", \\\"{x:1344,y:696,t:1526930065937};\\\", \\\"{x:1345,y:696,t:1526930066688};\\\", \\\"{x:1347,y:696,t:1526930066704};\\\", \\\"{x:1349,y:696,t:1526930066721};\\\", \\\"{x:1353,y:696,t:1526930066738};\\\", \\\"{x:1359,y:696,t:1526930066756};\\\", \\\"{x:1361,y:696,t:1526930066771};\\\", \\\"{x:1363,y:696,t:1526930066788};\\\", \\\"{x:1364,y:696,t:1526930066840};\\\", \\\"{x:1365,y:696,t:1526930066887};\\\", \\\"{x:1367,y:696,t:1526930067071};\\\", \\\"{x:1373,y:696,t:1526930067088};\\\", \\\"{x:1381,y:696,t:1526930067105};\\\", \\\"{x:1396,y:696,t:1526930067122};\\\", \\\"{x:1408,y:696,t:1526930067138};\\\", \\\"{x:1421,y:696,t:1526930067155};\\\", \\\"{x:1431,y:696,t:1526930067172};\\\", \\\"{x:1440,y:696,t:1526930067188};\\\", \\\"{x:1447,y:696,t:1526930067205};\\\", \\\"{x:1452,y:696,t:1526930067221};\\\", \\\"{x:1455,y:696,t:1526930067238};\\\", \\\"{x:1460,y:696,t:1526930067255};\\\", \\\"{x:1464,y:696,t:1526930067271};\\\", \\\"{x:1468,y:696,t:1526930067288};\\\", \\\"{x:1473,y:696,t:1526930067304};\\\", \\\"{x:1485,y:696,t:1526930067322};\\\", \\\"{x:1495,y:696,t:1526930067338};\\\", \\\"{x:1507,y:696,t:1526930067355};\\\", \\\"{x:1518,y:696,t:1526930067371};\\\", \\\"{x:1528,y:696,t:1526930067387};\\\", \\\"{x:1535,y:696,t:1526930067404};\\\", \\\"{x:1542,y:696,t:1526930067421};\\\", \\\"{x:1547,y:696,t:1526930067439};\\\", \\\"{x:1553,y:696,t:1526930067456};\\\", \\\"{x:1554,y:696,t:1526930067471};\\\", \\\"{x:1557,y:696,t:1526930067488};\\\", \\\"{x:1561,y:696,t:1526930067504};\\\", \\\"{x:1568,y:696,t:1526930067522};\\\", \\\"{x:1575,y:696,t:1526930067539};\\\", \\\"{x:1580,y:696,t:1526930067555};\\\", \\\"{x:1586,y:696,t:1526930067572};\\\", \\\"{x:1589,y:696,t:1526930067589};\\\", \\\"{x:1592,y:696,t:1526930067604};\\\", \\\"{x:1594,y:696,t:1526930067622};\\\", \\\"{x:1595,y:696,t:1526930067639};\\\", \\\"{x:1596,y:696,t:1526930067655};\\\", \\\"{x:1597,y:696,t:1526930067679};\\\", \\\"{x:1598,y:696,t:1526930067712};\\\", \\\"{x:1599,y:696,t:1526930067783};\\\", \\\"{x:1600,y:696,t:1526930067815};\\\", \\\"{x:1598,y:696,t:1526930068136};\\\", \\\"{x:1596,y:696,t:1526930068143};\\\", \\\"{x:1592,y:696,t:1526930068156};\\\", \\\"{x:1584,y:693,t:1526930068172};\\\", \\\"{x:1568,y:685,t:1526930068189};\\\", \\\"{x:1562,y:683,t:1526930068206};\\\", \\\"{x:1559,y:681,t:1526930068222};\\\", \\\"{x:1557,y:680,t:1526930068239};\\\", \\\"{x:1555,y:679,t:1526930068272};\\\", \\\"{x:1555,y:678,t:1526930068289};\\\", \\\"{x:1555,y:674,t:1526930068306};\\\", \\\"{x:1554,y:673,t:1526930068322};\\\", \\\"{x:1549,y:673,t:1526930068339};\\\", \\\"{x:1542,y:674,t:1526930068356};\\\", \\\"{x:1534,y:678,t:1526930068372};\\\", \\\"{x:1521,y:680,t:1526930068389};\\\", \\\"{x:1494,y:687,t:1526930068405};\\\", \\\"{x:1454,y:693,t:1526930068423};\\\", \\\"{x:1429,y:699,t:1526930068439};\\\", \\\"{x:1407,y:709,t:1526930068456};\\\", \\\"{x:1387,y:718,t:1526930068473};\\\", \\\"{x:1362,y:732,t:1526930068489};\\\", \\\"{x:1337,y:744,t:1526930068506};\\\", \\\"{x:1314,y:751,t:1526930068523};\\\", \\\"{x:1297,y:757,t:1526930068539};\\\", \\\"{x:1288,y:758,t:1526930068556};\\\", \\\"{x:1283,y:759,t:1526930068572};\\\", \\\"{x:1282,y:759,t:1526930068589};\\\", \\\"{x:1281,y:759,t:1526930068687};\\\", \\\"{x:1283,y:753,t:1526930068706};\\\", \\\"{x:1292,y:746,t:1526930068723};\\\", \\\"{x:1301,y:736,t:1526930068739};\\\", \\\"{x:1307,y:731,t:1526930068756};\\\", \\\"{x:1311,y:725,t:1526930068773};\\\", \\\"{x:1315,y:722,t:1526930068789};\\\", \\\"{x:1320,y:719,t:1526930068806};\\\", \\\"{x:1326,y:715,t:1526930068823};\\\", \\\"{x:1330,y:713,t:1526930068840};\\\", \\\"{x:1331,y:711,t:1526930068856};\\\", \\\"{x:1332,y:711,t:1526930068873};\\\", \\\"{x:1333,y:710,t:1526930068920};\\\", \\\"{x:1334,y:710,t:1526930068927};\\\", \\\"{x:1335,y:708,t:1526930068943};\\\", \\\"{x:1337,y:706,t:1526930068967};\\\", \\\"{x:1338,y:706,t:1526930068983};\\\", \\\"{x:1339,y:705,t:1526930068991};\\\", \\\"{x:1340,y:705,t:1526930069080};\\\", \\\"{x:1341,y:705,t:1526930069090};\\\", \\\"{x:1342,y:705,t:1526930069111};\\\", \\\"{x:1344,y:705,t:1526930069168};\\\", \\\"{x:1344,y:704,t:1526930069191};\\\", \\\"{x:1345,y:703,t:1526930069207};\\\", \\\"{x:1353,y:702,t:1526930070495};\\\", \\\"{x:1364,y:702,t:1526930070507};\\\", \\\"{x:1387,y:701,t:1526930070524};\\\", \\\"{x:1421,y:698,t:1526930070541};\\\", \\\"{x:1460,y:698,t:1526930070557};\\\", \\\"{x:1490,y:698,t:1526930070573};\\\", \\\"{x:1536,y:698,t:1526930070592};\\\", \\\"{x:1559,y:698,t:1526930070607};\\\", \\\"{x:1578,y:698,t:1526930070624};\\\", \\\"{x:1589,y:698,t:1526930070643};\\\", \\\"{x:1596,y:698,t:1526930070657};\\\", \\\"{x:1600,y:698,t:1526930070674};\\\", \\\"{x:1602,y:698,t:1526930070691};\\\", \\\"{x:1603,y:698,t:1526930070707};\\\", \\\"{x:1604,y:698,t:1526930070724};\\\", \\\"{x:1603,y:698,t:1526930070799};\\\", \\\"{x:1599,y:697,t:1526930070807};\\\", \\\"{x:1583,y:696,t:1526930070825};\\\", \\\"{x:1562,y:696,t:1526930070842};\\\", \\\"{x:1520,y:696,t:1526930070858};\\\", \\\"{x:1480,y:700,t:1526930070874};\\\", \\\"{x:1460,y:703,t:1526930070891};\\\", \\\"{x:1440,y:707,t:1526930070908};\\\", \\\"{x:1430,y:708,t:1526930070924};\\\", \\\"{x:1423,y:709,t:1526930070941};\\\", \\\"{x:1418,y:710,t:1526930070958};\\\", \\\"{x:1414,y:710,t:1526930070974};\\\", \\\"{x:1410,y:711,t:1526930070991};\\\", \\\"{x:1407,y:711,t:1526930071008};\\\", \\\"{x:1398,y:711,t:1526930071025};\\\", \\\"{x:1384,y:710,t:1526930071042};\\\", \\\"{x:1372,y:708,t:1526930071058};\\\", \\\"{x:1367,y:707,t:1526930071074};\\\", \\\"{x:1366,y:707,t:1526930071091};\\\", \\\"{x:1365,y:707,t:1526930071319};\\\", \\\"{x:1363,y:707,t:1526930071335};\\\", \\\"{x:1361,y:706,t:1526930071343};\\\", \\\"{x:1360,y:706,t:1526930071358};\\\", \\\"{x:1358,y:705,t:1526930071374};\\\", \\\"{x:1356,y:704,t:1526930071391};\\\", \\\"{x:1356,y:707,t:1526930071711};\\\", \\\"{x:1355,y:712,t:1526930071725};\\\", \\\"{x:1353,y:724,t:1526930071742};\\\", \\\"{x:1349,y:733,t:1526930071758};\\\", \\\"{x:1345,y:747,t:1526930071776};\\\", \\\"{x:1344,y:754,t:1526930071791};\\\", \\\"{x:1342,y:760,t:1526930071808};\\\", \\\"{x:1342,y:762,t:1526930071826};\\\", \\\"{x:1342,y:764,t:1526930071842};\\\", \\\"{x:1342,y:765,t:1526930071864};\\\", \\\"{x:1341,y:762,t:1526930072096};\\\", \\\"{x:1340,y:756,t:1526930072108};\\\", \\\"{x:1338,y:749,t:1526930072125};\\\", \\\"{x:1336,y:744,t:1526930072142};\\\", \\\"{x:1336,y:741,t:1526930072158};\\\", \\\"{x:1336,y:739,t:1526930072175};\\\", \\\"{x:1336,y:737,t:1526930072191};\\\", \\\"{x:1335,y:734,t:1526930072209};\\\", \\\"{x:1335,y:731,t:1526930072226};\\\", \\\"{x:1335,y:727,t:1526930072242};\\\", \\\"{x:1335,y:724,t:1526930072259};\\\", \\\"{x:1335,y:720,t:1526930072276};\\\", \\\"{x:1335,y:718,t:1526930072292};\\\", \\\"{x:1335,y:715,t:1526930072309};\\\", \\\"{x:1335,y:712,t:1526930072325};\\\", \\\"{x:1337,y:709,t:1526930072342};\\\", \\\"{x:1337,y:706,t:1526930072359};\\\", \\\"{x:1337,y:704,t:1526930072375};\\\", \\\"{x:1337,y:703,t:1526930072392};\\\", \\\"{x:1337,y:702,t:1526930072409};\\\", \\\"{x:1337,y:701,t:1526930072425};\\\", \\\"{x:1337,y:700,t:1526930072442};\\\", \\\"{x:1337,y:699,t:1526930072459};\\\", \\\"{x:1338,y:698,t:1526930072475};\\\", \\\"{x:1338,y:697,t:1526930072492};\\\", \\\"{x:1338,y:696,t:1526930072520};\\\", \\\"{x:1338,y:695,t:1526930072543};\\\", \\\"{x:1338,y:693,t:1526930072559};\\\", \\\"{x:1340,y:691,t:1526930072575};\\\", \\\"{x:1341,y:689,t:1526930072599};\\\", \\\"{x:1341,y:688,t:1526930072615};\\\", \\\"{x:1342,y:687,t:1526930072639};\\\", \\\"{x:1342,y:686,t:1526930072663};\\\", \\\"{x:1343,y:686,t:1526930072675};\\\", \\\"{x:1344,y:685,t:1526930072695};\\\", \\\"{x:1345,y:685,t:1526930074104};\\\", \\\"{x:1345,y:687,t:1526930074111};\\\", \\\"{x:1346,y:691,t:1526930074127};\\\", \\\"{x:1347,y:694,t:1526930074144};\\\", \\\"{x:1347,y:695,t:1526930074183};\\\", \\\"{x:1347,y:696,t:1526930074207};\\\", \\\"{x:1347,y:697,t:1526930074215};\\\", \\\"{x:1347,y:698,t:1526930074226};\\\", \\\"{x:1347,y:700,t:1526930074243};\\\", \\\"{x:1348,y:702,t:1526930074260};\\\", \\\"{x:1348,y:703,t:1526930074278};\\\", \\\"{x:1348,y:707,t:1526930074294};\\\", \\\"{x:1349,y:711,t:1526930074311};\\\", \\\"{x:1350,y:714,t:1526930074327};\\\", \\\"{x:1350,y:716,t:1526930074343};\\\", \\\"{x:1350,y:719,t:1526930074361};\\\", \\\"{x:1350,y:722,t:1526930074377};\\\", \\\"{x:1350,y:727,t:1526930074393};\\\", \\\"{x:1350,y:730,t:1526930074410};\\\", \\\"{x:1350,y:735,t:1526930074427};\\\", \\\"{x:1350,y:737,t:1526930074443};\\\", \\\"{x:1350,y:741,t:1526930074460};\\\", \\\"{x:1350,y:744,t:1526930074477};\\\", \\\"{x:1350,y:747,t:1526930074493};\\\", \\\"{x:1350,y:748,t:1526930074510};\\\", \\\"{x:1350,y:752,t:1526930074527};\\\", \\\"{x:1351,y:754,t:1526930074544};\\\", \\\"{x:1351,y:757,t:1526930074560};\\\", \\\"{x:1351,y:758,t:1526930074576};\\\", \\\"{x:1351,y:760,t:1526930074594};\\\", \\\"{x:1352,y:763,t:1526930074627};\\\", \\\"{x:1352,y:766,t:1526930074644};\\\", \\\"{x:1352,y:769,t:1526930074661};\\\", \\\"{x:1352,y:771,t:1526930074677};\\\", \\\"{x:1352,y:773,t:1526930074694};\\\", \\\"{x:1352,y:774,t:1526930074711};\\\", \\\"{x:1352,y:779,t:1526930074727};\\\", \\\"{x:1352,y:782,t:1526930074743};\\\", \\\"{x:1352,y:786,t:1526930074760};\\\", \\\"{x:1352,y:789,t:1526930074777};\\\", \\\"{x:1352,y:793,t:1526930074794};\\\", \\\"{x:1352,y:797,t:1526930074810};\\\", \\\"{x:1352,y:801,t:1526930074827};\\\", \\\"{x:1352,y:808,t:1526930074844};\\\", \\\"{x:1352,y:814,t:1526930074860};\\\", \\\"{x:1352,y:822,t:1526930074877};\\\", \\\"{x:1352,y:833,t:1526930074894};\\\", \\\"{x:1352,y:842,t:1526930074910};\\\", \\\"{x:1352,y:856,t:1526930074927};\\\", \\\"{x:1352,y:864,t:1526930074944};\\\", \\\"{x:1352,y:871,t:1526930074960};\\\", \\\"{x:1352,y:879,t:1526930074977};\\\", \\\"{x:1352,y:892,t:1526930074995};\\\", \\\"{x:1352,y:912,t:1526930075010};\\\", \\\"{x:1352,y:929,t:1526930075027};\\\", \\\"{x:1352,y:947,t:1526930075044};\\\", \\\"{x:1352,y:961,t:1526930075060};\\\", \\\"{x:1352,y:975,t:1526930075077};\\\", \\\"{x:1352,y:987,t:1526930075094};\\\", \\\"{x:1352,y:993,t:1526930075110};\\\", \\\"{x:1352,y:996,t:1526930075127};\\\", \\\"{x:1352,y:997,t:1526930075183};\\\", \\\"{x:1353,y:995,t:1526930075294};\\\", \\\"{x:1353,y:986,t:1526930075311};\\\", \\\"{x:1353,y:971,t:1526930075326};\\\", \\\"{x:1348,y:955,t:1526930075343};\\\", \\\"{x:1340,y:936,t:1526930075360};\\\", \\\"{x:1336,y:913,t:1526930075376};\\\", \\\"{x:1330,y:887,t:1526930075393};\\\", \\\"{x:1323,y:857,t:1526930075410};\\\", \\\"{x:1318,y:835,t:1526930075426};\\\", \\\"{x:1315,y:818,t:1526930075444};\\\", \\\"{x:1315,y:809,t:1526930075460};\\\", \\\"{x:1315,y:801,t:1526930075478};\\\", \\\"{x:1315,y:789,t:1526930075493};\\\", \\\"{x:1318,y:772,t:1526930075510};\\\", \\\"{x:1318,y:754,t:1526930075527};\\\", \\\"{x:1319,y:739,t:1526930075543};\\\", \\\"{x:1319,y:729,t:1526930075560};\\\", \\\"{x:1319,y:724,t:1526930075577};\\\", \\\"{x:1320,y:721,t:1526930075594};\\\", \\\"{x:1321,y:716,t:1526930075611};\\\", \\\"{x:1323,y:712,t:1526930075628};\\\", \\\"{x:1324,y:706,t:1526930075644};\\\", \\\"{x:1325,y:701,t:1526930075661};\\\", \\\"{x:1327,y:695,t:1526930075677};\\\", \\\"{x:1328,y:693,t:1526930075694};\\\", \\\"{x:1330,y:689,t:1526930075711};\\\", \\\"{x:1330,y:688,t:1526930075735};\\\", \\\"{x:1330,y:697,t:1526930075958};\\\", \\\"{x:1330,y:708,t:1526930075966};\\\", \\\"{x:1330,y:715,t:1526930075977};\\\", \\\"{x:1330,y:728,t:1526930075995};\\\", \\\"{x:1330,y:737,t:1526930076011};\\\", \\\"{x:1331,y:740,t:1526930076028};\\\", \\\"{x:1331,y:744,t:1526930076044};\\\", \\\"{x:1331,y:749,t:1526930076060};\\\", \\\"{x:1332,y:755,t:1526930076078};\\\", \\\"{x:1332,y:772,t:1526930076095};\\\", \\\"{x:1332,y:782,t:1526930076111};\\\", \\\"{x:1335,y:791,t:1526930076128};\\\", \\\"{x:1335,y:799,t:1526930076145};\\\", \\\"{x:1336,y:805,t:1526930076161};\\\", \\\"{x:1338,y:812,t:1526930076178};\\\", \\\"{x:1338,y:815,t:1526930076194};\\\", \\\"{x:1339,y:823,t:1526930076211};\\\", \\\"{x:1341,y:833,t:1526930076228};\\\", \\\"{x:1343,y:843,t:1526930076245};\\\", \\\"{x:1343,y:850,t:1526930076261};\\\", \\\"{x:1344,y:857,t:1526930076278};\\\", \\\"{x:1347,y:875,t:1526930076295};\\\", \\\"{x:1348,y:887,t:1526930076310};\\\", \\\"{x:1350,y:896,t:1526930076328};\\\", \\\"{x:1352,y:905,t:1526930076345};\\\", \\\"{x:1353,y:912,t:1526930076361};\\\", \\\"{x:1353,y:918,t:1526930076378};\\\", \\\"{x:1353,y:921,t:1526930076395};\\\", \\\"{x:1353,y:925,t:1526930076411};\\\", \\\"{x:1353,y:927,t:1526930076428};\\\", \\\"{x:1353,y:929,t:1526930076445};\\\", \\\"{x:1353,y:930,t:1526930076461};\\\", \\\"{x:1353,y:931,t:1526930076478};\\\", \\\"{x:1353,y:934,t:1526930076495};\\\", \\\"{x:1353,y:935,t:1526930076519};\\\", \\\"{x:1353,y:936,t:1526930076528};\\\", \\\"{x:1353,y:939,t:1526930076545};\\\", \\\"{x:1353,y:940,t:1526930076562};\\\", \\\"{x:1353,y:944,t:1526930076578};\\\", \\\"{x:1353,y:947,t:1526930076595};\\\", \\\"{x:1354,y:951,t:1526930076612};\\\", \\\"{x:1354,y:954,t:1526930076629};\\\", \\\"{x:1356,y:957,t:1526930076645};\\\", \\\"{x:1356,y:961,t:1526930076662};\\\", \\\"{x:1356,y:964,t:1526930076678};\\\", \\\"{x:1356,y:965,t:1526930076695};\\\", \\\"{x:1356,y:963,t:1526930076856};\\\", \\\"{x:1356,y:960,t:1526930076863};\\\", \\\"{x:1356,y:958,t:1526930076879};\\\", \\\"{x:1356,y:956,t:1526930076895};\\\", \\\"{x:1356,y:955,t:1526930076912};\\\", \\\"{x:1356,y:954,t:1526930076928};\\\", \\\"{x:1356,y:953,t:1526930077016};\\\", \\\"{x:1355,y:950,t:1526930077695};\\\", \\\"{x:1348,y:939,t:1526930077712};\\\", \\\"{x:1328,y:924,t:1526930077729};\\\", \\\"{x:1293,y:907,t:1526930077747};\\\", \\\"{x:1222,y:866,t:1526930077763};\\\", \\\"{x:1122,y:821,t:1526930077780};\\\", \\\"{x:1019,y:769,t:1526930077796};\\\", \\\"{x:926,y:730,t:1526930077813};\\\", \\\"{x:847,y:689,t:1526930077829};\\\", \\\"{x:778,y:660,t:1526930077847};\\\", \\\"{x:729,y:640,t:1526930077862};\\\", \\\"{x:696,y:625,t:1526930077880};\\\", \\\"{x:693,y:624,t:1526930077896};\\\", \\\"{x:691,y:622,t:1526930077942};\\\", \\\"{x:689,y:620,t:1526930077950};\\\", \\\"{x:687,y:614,t:1526930077961};\\\", \\\"{x:676,y:600,t:1526930077979};\\\", \\\"{x:655,y:584,t:1526930077996};\\\", \\\"{x:621,y:568,t:1526930078013};\\\", \\\"{x:564,y:544,t:1526930078030};\\\", \\\"{x:484,y:508,t:1526930078046};\\\", \\\"{x:461,y:499,t:1526930078062};\\\", \\\"{x:449,y:495,t:1526930078079};\\\", \\\"{x:446,y:494,t:1526930078097};\\\", \\\"{x:445,y:493,t:1526930078112};\\\", \\\"{x:445,y:492,t:1526930078182};\\\", \\\"{x:446,y:491,t:1526930078195};\\\", \\\"{x:447,y:491,t:1526930078213};\\\", \\\"{x:448,y:490,t:1526930078230};\\\", \\\"{x:449,y:488,t:1526930078246};\\\", \\\"{x:452,y:486,t:1526930078264};\\\", \\\"{x:453,y:484,t:1526930078278};\\\", \\\"{x:456,y:484,t:1526930078297};\\\", \\\"{x:461,y:484,t:1526930078314};\\\", \\\"{x:465,y:485,t:1526930078329};\\\", \\\"{x:467,y:486,t:1526930078346};\\\", \\\"{x:467,y:492,t:1526930078363};\\\", \\\"{x:471,y:518,t:1526930078380};\\\", \\\"{x:478,y:555,t:1526930078397};\\\", \\\"{x:483,y:589,t:1526930078414};\\\", \\\"{x:489,y:609,t:1526930078431};\\\", \\\"{x:494,y:617,t:1526930078447};\\\", \\\"{x:494,y:618,t:1526930078463};\\\", \\\"{x:498,y:617,t:1526930078519};\\\", \\\"{x:503,y:615,t:1526930078532};\\\", \\\"{x:514,y:613,t:1526930078546};\\\", \\\"{x:531,y:608,t:1526930078563};\\\", \\\"{x:547,y:603,t:1526930078579};\\\", \\\"{x:560,y:598,t:1526930078597};\\\", \\\"{x:564,y:597,t:1526930078613};\\\", \\\"{x:565,y:597,t:1526930078630};\\\", \\\"{x:565,y:596,t:1526930078735};\\\", \\\"{x:565,y:595,t:1526930078747};\\\", \\\"{x:563,y:593,t:1526930078764};\\\", \\\"{x:562,y:593,t:1526930078780};\\\", \\\"{x:561,y:593,t:1526930078911};\\\", \\\"{x:561,y:591,t:1526930078918};\\\", \\\"{x:564,y:586,t:1526930078931};\\\", \\\"{x:575,y:579,t:1526930078948};\\\", \\\"{x:596,y:571,t:1526930078964};\\\", \\\"{x:629,y:569,t:1526930078982};\\\", \\\"{x:656,y:569,t:1526930078998};\\\", \\\"{x:680,y:569,t:1526930079014};\\\", \\\"{x:704,y:569,t:1526930079031};\\\", \\\"{x:725,y:569,t:1526930079048};\\\", \\\"{x:747,y:569,t:1526930079064};\\\", \\\"{x:771,y:569,t:1526930079081};\\\", \\\"{x:796,y:569,t:1526930079097};\\\", \\\"{x:818,y:566,t:1526930079113};\\\", \\\"{x:826,y:564,t:1526930079130};\\\", \\\"{x:827,y:561,t:1526930079148};\\\", \\\"{x:827,y:555,t:1526930079165};\\\", \\\"{x:826,y:549,t:1526930079181};\\\", \\\"{x:826,y:540,t:1526930079198};\\\", \\\"{x:826,y:534,t:1526930079214};\\\", \\\"{x:831,y:528,t:1526930079231};\\\", \\\"{x:831,y:524,t:1526930079249};\\\", \\\"{x:831,y:520,t:1526930079263};\\\", \\\"{x:831,y:517,t:1526930079281};\\\", \\\"{x:830,y:515,t:1526930079298};\\\", \\\"{x:831,y:513,t:1526930079314};\\\", \\\"{x:831,y:511,t:1526930079331};\\\", \\\"{x:831,y:508,t:1526930079348};\\\", \\\"{x:832,y:505,t:1526930079364};\\\", \\\"{x:833,y:505,t:1526930079381};\\\", \\\"{x:833,y:504,t:1526930079398};\\\", \\\"{x:833,y:502,t:1526930079414};\\\", \\\"{x:833,y:500,t:1526930079431};\\\", \\\"{x:832,y:499,t:1526930079646};\\\", \\\"{x:819,y:499,t:1526930079655};\\\", \\\"{x:794,y:504,t:1526930079665};\\\", \\\"{x:713,y:540,t:1526930079681};\\\", \\\"{x:611,y:589,t:1526930079698};\\\", \\\"{x:516,y:634,t:1526930079715};\\\", \\\"{x:455,y:663,t:1526930079731};\\\", \\\"{x:413,y:675,t:1526930079748};\\\", \\\"{x:383,y:681,t:1526930079764};\\\", \\\"{x:368,y:687,t:1526930079781};\\\", \\\"{x:357,y:690,t:1526930079798};\\\", \\\"{x:334,y:691,t:1526930079814};\\\", \\\"{x:321,y:691,t:1526930079831};\\\", \\\"{x:310,y:683,t:1526930079848};\\\", \\\"{x:295,y:668,t:1526930079865};\\\", \\\"{x:260,y:644,t:1526930079881};\\\", \\\"{x:231,y:625,t:1526930079898};\\\", \\\"{x:221,y:616,t:1526930079915};\\\", \\\"{x:219,y:613,t:1526930079930};\\\", \\\"{x:219,y:608,t:1526930079947};\\\", \\\"{x:220,y:604,t:1526930079964};\\\", \\\"{x:224,y:594,t:1526930079981};\\\", \\\"{x:227,y:587,t:1526930079998};\\\", \\\"{x:227,y:583,t:1526930080015};\\\", \\\"{x:223,y:579,t:1526930080030};\\\", \\\"{x:207,y:571,t:1526930080048};\\\", \\\"{x:194,y:564,t:1526930080064};\\\", \\\"{x:188,y:564,t:1526930080082};\\\", \\\"{x:186,y:563,t:1526930080097};\\\", \\\"{x:181,y:561,t:1526930080116};\\\", \\\"{x:176,y:560,t:1526930080131};\\\", \\\"{x:169,y:558,t:1526930080147};\\\", \\\"{x:161,y:555,t:1526930080165};\\\", \\\"{x:155,y:552,t:1526930080182};\\\", \\\"{x:154,y:551,t:1526930080198};\\\", \\\"{x:153,y:550,t:1526930080214};\\\", \\\"{x:151,y:546,t:1526930080231};\\\", \\\"{x:148,y:544,t:1526930080248};\\\", \\\"{x:148,y:543,t:1526930080264};\\\", \\\"{x:147,y:542,t:1526930080282};\\\", \\\"{x:147,y:541,t:1526930080298};\\\", \\\"{x:147,y:539,t:1526930080315};\\\", \\\"{x:150,y:539,t:1526930080527};\\\", \\\"{x:156,y:540,t:1526930080534};\\\", \\\"{x:163,y:543,t:1526930080548};\\\", \\\"{x:180,y:552,t:1526930080565};\\\", \\\"{x:205,y:564,t:1526930080582};\\\", \\\"{x:297,y:627,t:1526930080598};\\\", \\\"{x:376,y:691,t:1526930080615};\\\", \\\"{x:452,y:749,t:1526930080632};\\\", \\\"{x:502,y:783,t:1526930080649};\\\", \\\"{x:536,y:799,t:1526930080665};\\\", \\\"{x:566,y:810,t:1526930080682};\\\", \\\"{x:580,y:814,t:1526930080698};\\\", \\\"{x:586,y:815,t:1526930080714};\\\", \\\"{x:578,y:811,t:1526930080766};\\\", \\\"{x:571,y:808,t:1526930080781};\\\", \\\"{x:554,y:798,t:1526930080798};\\\", \\\"{x:548,y:793,t:1526930080815};\\\", \\\"{x:534,y:783,t:1526930080832};\\\", \\\"{x:497,y:759,t:1526930080849};\\\", \\\"{x:444,y:725,t:1526930080865};\\\", \\\"{x:377,y:676,t:1526930080883};\\\", \\\"{x:292,y:625,t:1526930080900};\\\", \\\"{x:207,y:573,t:1526930080915};\\\", \\\"{x:157,y:544,t:1526930080932};\\\", \\\"{x:133,y:530,t:1526930080948};\\\", \\\"{x:118,y:519,t:1526930080966};\\\", \\\"{x:108,y:510,t:1526930080982};\\\", \\\"{x:106,y:507,t:1526930080999};\\\", \\\"{x:105,y:506,t:1526930081016};\\\", \\\"{x:104,y:506,t:1526930081062};\\\", \\\"{x:104,y:505,t:1526930081143};\\\", \\\"{x:104,y:506,t:1526930081191};\\\", \\\"{x:105,y:508,t:1526930081199};\\\", \\\"{x:107,y:509,t:1526930081216};\\\", \\\"{x:108,y:509,t:1526930081234};\\\", \\\"{x:111,y:512,t:1526930081249};\\\", \\\"{x:115,y:517,t:1526930081266};\\\", \\\"{x:119,y:520,t:1526930081283};\\\", \\\"{x:121,y:522,t:1526930081300};\\\", \\\"{x:122,y:523,t:1526930081316};\\\", \\\"{x:123,y:525,t:1526930081359};\\\", \\\"{x:124,y:525,t:1526930081365};\\\", \\\"{x:125,y:526,t:1526930081382};\\\", \\\"{x:125,y:527,t:1526930081446};\\\", \\\"{x:126,y:529,t:1526930081455};\\\", \\\"{x:127,y:529,t:1526930081466};\\\", \\\"{x:129,y:529,t:1526930081483};\\\", \\\"{x:130,y:529,t:1526930081527};\\\", \\\"{x:132,y:530,t:1526930081535};\\\", \\\"{x:135,y:531,t:1526930081550};\\\", \\\"{x:136,y:531,t:1526930081567};\\\", \\\"{x:139,y:532,t:1526930081583};\\\", \\\"{x:143,y:533,t:1526930081599};\\\", \\\"{x:151,y:537,t:1526930081617};\\\", \\\"{x:156,y:539,t:1526930081632};\\\", \\\"{x:157,y:540,t:1526930081649};\\\", \\\"{x:163,y:542,t:1526930081894};\\\", \\\"{x:173,y:546,t:1526930081903};\\\", \\\"{x:185,y:552,t:1526930081916};\\\", \\\"{x:222,y:574,t:1526930081933};\\\", \\\"{x:281,y:613,t:1526930081950};\\\", \\\"{x:417,y:708,t:1526930081967};\\\", \\\"{x:514,y:772,t:1526930081983};\\\", \\\"{x:600,y:813,t:1526930082000};\\\", \\\"{x:668,y:841,t:1526930082015};\\\", \\\"{x:709,y:857,t:1526930082033};\\\", \\\"{x:728,y:864,t:1526930082050};\\\", \\\"{x:729,y:864,t:1526930082066};\\\", \\\"{x:730,y:864,t:1526930082083};\\\", \\\"{x:722,y:856,t:1526930082100};\\\", \\\"{x:706,y:848,t:1526930082117};\\\", \\\"{x:690,y:836,t:1526930082132};\\\", \\\"{x:677,y:825,t:1526930082149};\\\", \\\"{x:662,y:813,t:1526930082166};\\\", \\\"{x:651,y:807,t:1526930082183};\\\", \\\"{x:643,y:799,t:1526930082200};\\\", \\\"{x:626,y:794,t:1526930082217};\\\", \\\"{x:613,y:786,t:1526930082234};\\\", \\\"{x:600,y:778,t:1526930082250};\\\", \\\"{x:592,y:774,t:1526930082267};\\\", \\\"{x:584,y:772,t:1526930082284};\\\", \\\"{x:578,y:769,t:1526930082300};\\\", \\\"{x:570,y:764,t:1526930082317};\\\", \\\"{x:566,y:763,t:1526930082334};\\\", \\\"{x:565,y:762,t:1526930082351};\\\", \\\"{x:564,y:762,t:1526930082384};\\\", \\\"{x:563,y:762,t:1526930082399};\\\", \\\"{x:562,y:761,t:1526930082407};\\\", \\\"{x:562,y:760,t:1526930082503};\\\", \\\"{x:560,y:757,t:1526930082518};\\\", \\\"{x:549,y:750,t:1526930082536};\\\", \\\"{x:543,y:747,t:1526930082551};\\\", \\\"{x:542,y:746,t:1526930082567};\\\", \\\"{x:541,y:745,t:1526930082584};\\\", \\\"{x:540,y:744,t:1526930082607};\\\", \\\"{x:541,y:744,t:1526930082903};\\\", \\\"{x:545,y:747,t:1526930082917};\\\", \\\"{x:558,y:751,t:1526930082933};\\\", \\\"{x:577,y:757,t:1526930082950};\\\", \\\"{x:586,y:759,t:1526930082967};\\\", \\\"{x:601,y:763,t:1526930082984};\\\", \\\"{x:618,y:766,t:1526930083000};\\\", \\\"{x:631,y:767,t:1526930083017};\\\", \\\"{x:648,y:769,t:1526930083034};\\\", \\\"{x:662,y:771,t:1526930083050};\\\", \\\"{x:671,y:771,t:1526930083067};\\\", \\\"{x:675,y:771,t:1526930083084};\\\", \\\"{x:677,y:771,t:1526930083100};\\\" ] }, { \\\"rt\\\": 47696, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 455336, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -E -J -E -E -E -E -E -11 AM-X -X -X -X -J -F -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:687,y:771,t:1526930087015};\\\", \\\"{x:770,y:783,t:1526930087042};\\\", \\\"{x:801,y:783,t:1526930087053};\\\", \\\"{x:905,y:779,t:1526930087070};\\\", \\\"{x:1000,y:766,t:1526930087087};\\\", \\\"{x:1106,y:757,t:1526930087103};\\\", \\\"{x:1200,y:748,t:1526930087120};\\\", \\\"{x:1263,y:733,t:1526930087137};\\\", \\\"{x:1299,y:718,t:1526930087153};\\\", \\\"{x:1302,y:716,t:1526930087170};\\\", \\\"{x:1302,y:715,t:1526930087695};\\\", \\\"{x:1302,y:714,t:1526930087711};\\\", \\\"{x:1302,y:711,t:1526930087720};\\\", \\\"{x:1304,y:702,t:1526930087738};\\\", \\\"{x:1306,y:691,t:1526930087754};\\\", \\\"{x:1308,y:675,t:1526930087770};\\\", \\\"{x:1311,y:647,t:1526930087787};\\\", \\\"{x:1319,y:599,t:1526930087804};\\\", \\\"{x:1326,y:551,t:1526930087820};\\\", \\\"{x:1328,y:503,t:1526930087837};\\\", \\\"{x:1328,y:439,t:1526930087855};\\\", \\\"{x:1326,y:410,t:1526930087871};\\\", \\\"{x:1326,y:388,t:1526930087887};\\\", \\\"{x:1324,y:375,t:1526930087905};\\\", \\\"{x:1323,y:372,t:1526930087921};\\\", \\\"{x:1323,y:370,t:1526930087937};\\\", \\\"{x:1326,y:370,t:1526930093239};\\\", \\\"{x:1333,y:374,t:1526930093247};\\\", \\\"{x:1341,y:384,t:1526930093258};\\\", \\\"{x:1358,y:408,t:1526930093275};\\\", \\\"{x:1369,y:420,t:1526930093292};\\\", \\\"{x:1380,y:428,t:1526930093309};\\\", \\\"{x:1390,y:435,t:1526930093325};\\\", \\\"{x:1397,y:439,t:1526930093342};\\\", \\\"{x:1400,y:441,t:1526930093358};\\\", \\\"{x:1402,y:442,t:1526930093375};\\\", \\\"{x:1402,y:445,t:1526930093600};\\\", \\\"{x:1403,y:449,t:1526930093609};\\\", \\\"{x:1406,y:459,t:1526930093626};\\\", \\\"{x:1410,y:469,t:1526930093641};\\\", \\\"{x:1414,y:477,t:1526930093658};\\\", \\\"{x:1416,y:485,t:1526930093676};\\\", \\\"{x:1420,y:494,t:1526930093692};\\\", \\\"{x:1422,y:503,t:1526930093709};\\\", \\\"{x:1423,y:508,t:1526930093726};\\\", \\\"{x:1425,y:518,t:1526930093744};\\\", \\\"{x:1425,y:524,t:1526930093758};\\\", \\\"{x:1425,y:529,t:1526930093775};\\\", \\\"{x:1425,y:533,t:1526930093791};\\\", \\\"{x:1425,y:534,t:1526930093808};\\\", \\\"{x:1425,y:536,t:1526930093825};\\\", \\\"{x:1425,y:537,t:1526930093841};\\\", \\\"{x:1425,y:544,t:1526930093858};\\\", \\\"{x:1424,y:551,t:1526930093875};\\\", \\\"{x:1421,y:563,t:1526930093891};\\\", \\\"{x:1416,y:580,t:1526930093908};\\\", \\\"{x:1411,y:602,t:1526930093926};\\\", \\\"{x:1404,y:639,t:1526930093942};\\\", \\\"{x:1371,y:753,t:1526930093958};\\\", \\\"{x:1344,y:837,t:1526930093976};\\\", \\\"{x:1333,y:889,t:1526930093992};\\\", \\\"{x:1329,y:920,t:1526930094009};\\\", \\\"{x:1324,y:941,t:1526930094025};\\\", \\\"{x:1323,y:950,t:1526930094041};\\\", \\\"{x:1323,y:944,t:1526930094166};\\\", \\\"{x:1323,y:937,t:1526930094176};\\\", \\\"{x:1324,y:905,t:1526930094192};\\\", \\\"{x:1325,y:874,t:1526930094208};\\\", \\\"{x:1325,y:843,t:1526930094226};\\\", \\\"{x:1325,y:819,t:1526930094242};\\\", \\\"{x:1325,y:801,t:1526930094258};\\\", \\\"{x:1327,y:791,t:1526930094276};\\\", \\\"{x:1330,y:785,t:1526930094293};\\\", \\\"{x:1331,y:781,t:1526930094309};\\\", \\\"{x:1331,y:779,t:1526930094326};\\\", \\\"{x:1331,y:778,t:1526930094391};\\\", \\\"{x:1331,y:777,t:1526930094398};\\\", \\\"{x:1330,y:777,t:1526930094415};\\\", \\\"{x:1331,y:774,t:1526930094479};\\\", \\\"{x:1335,y:771,t:1526930094492};\\\", \\\"{x:1344,y:765,t:1526930094513};\\\", \\\"{x:1354,y:759,t:1526930094526};\\\", \\\"{x:1363,y:756,t:1526930094542};\\\", \\\"{x:1366,y:756,t:1526930094559};\\\", \\\"{x:1367,y:756,t:1526930094575};\\\", \\\"{x:1368,y:756,t:1526930094592};\\\", \\\"{x:1368,y:754,t:1526930094702};\\\", \\\"{x:1365,y:753,t:1526930094711};\\\", \\\"{x:1362,y:753,t:1526930094725};\\\", \\\"{x:1356,y:750,t:1526930094743};\\\", \\\"{x:1353,y:749,t:1526930094760};\\\", \\\"{x:1351,y:748,t:1526930094776};\\\", \\\"{x:1349,y:748,t:1526930094793};\\\", \\\"{x:1349,y:747,t:1526930094810};\\\", \\\"{x:1348,y:747,t:1526930094887};\\\", \\\"{x:1347,y:748,t:1526930094927};\\\", \\\"{x:1346,y:750,t:1526930094943};\\\", \\\"{x:1345,y:751,t:1526930094960};\\\", \\\"{x:1343,y:752,t:1526930094976};\\\", \\\"{x:1343,y:753,t:1526930094992};\\\", \\\"{x:1342,y:753,t:1526930095010};\\\", \\\"{x:1341,y:753,t:1526930095815};\\\", \\\"{x:1340,y:753,t:1526930095827};\\\", \\\"{x:1338,y:753,t:1526930095844};\\\", \\\"{x:1336,y:753,t:1526930095860};\\\", \\\"{x:1335,y:753,t:1526930095877};\\\", \\\"{x:1333,y:753,t:1526930095894};\\\", \\\"{x:1332,y:754,t:1526930095910};\\\", \\\"{x:1333,y:755,t:1526930096054};\\\", \\\"{x:1333,y:756,t:1526930096069};\\\", \\\"{x:1334,y:756,t:1526930096078};\\\", \\\"{x:1335,y:752,t:1526930096344};\\\", \\\"{x:1334,y:722,t:1526930096361};\\\", \\\"{x:1333,y:695,t:1526930096377};\\\", \\\"{x:1327,y:666,t:1526930096394};\\\", \\\"{x:1319,y:635,t:1526930096410};\\\", \\\"{x:1309,y:589,t:1526930096428};\\\", \\\"{x:1309,y:554,t:1526930096444};\\\", \\\"{x:1309,y:548,t:1526930096460};\\\", \\\"{x:1309,y:542,t:1526930096477};\\\", \\\"{x:1309,y:540,t:1526930096494};\\\", \\\"{x:1309,y:538,t:1526930096510};\\\", \\\"{x:1309,y:535,t:1526930096528};\\\", \\\"{x:1309,y:531,t:1526930096545};\\\", \\\"{x:1308,y:522,t:1526930096561};\\\", \\\"{x:1298,y:505,t:1526930096578};\\\", \\\"{x:1285,y:488,t:1526930096594};\\\", \\\"{x:1269,y:472,t:1526930096611};\\\", \\\"{x:1253,y:456,t:1526930096628};\\\", \\\"{x:1237,y:444,t:1526930096644};\\\", \\\"{x:1232,y:440,t:1526930096661};\\\", \\\"{x:1233,y:440,t:1526930096687};\\\", \\\"{x:1237,y:442,t:1526930096695};\\\", \\\"{x:1245,y:444,t:1526930096710};\\\", \\\"{x:1249,y:446,t:1526930096728};\\\", \\\"{x:1250,y:448,t:1526930096744};\\\", \\\"{x:1249,y:466,t:1526930096761};\\\", \\\"{x:1249,y:474,t:1526930096778};\\\", \\\"{x:1253,y:488,t:1526930096794};\\\", \\\"{x:1256,y:504,t:1526930096811};\\\", \\\"{x:1259,y:510,t:1526930096828};\\\", \\\"{x:1259,y:511,t:1526930096844};\\\", \\\"{x:1259,y:514,t:1526930096861};\\\", \\\"{x:1259,y:516,t:1526930096878};\\\", \\\"{x:1259,y:522,t:1526930096894};\\\", \\\"{x:1259,y:534,t:1526930096911};\\\", \\\"{x:1260,y:541,t:1526930096927};\\\", \\\"{x:1262,y:546,t:1526930096944};\\\", \\\"{x:1263,y:547,t:1526930096961};\\\", \\\"{x:1263,y:548,t:1526930096978};\\\", \\\"{x:1263,y:549,t:1526930097039};\\\", \\\"{x:1263,y:550,t:1526930097047};\\\", \\\"{x:1263,y:551,t:1526930097063};\\\", \\\"{x:1264,y:552,t:1526930097078};\\\", \\\"{x:1265,y:554,t:1526930097095};\\\", \\\"{x:1266,y:555,t:1526930097110};\\\", \\\"{x:1266,y:556,t:1526930097128};\\\", \\\"{x:1267,y:556,t:1526930097145};\\\", \\\"{x:1268,y:557,t:1526930097175};\\\", \\\"{x:1269,y:557,t:1526930097407};\\\", \\\"{x:1270,y:557,t:1526930097423};\\\", \\\"{x:1271,y:558,t:1526930097439};\\\", \\\"{x:1272,y:559,t:1526930097567};\\\", \\\"{x:1274,y:559,t:1526930098223};\\\", \\\"{x:1275,y:559,t:1526930099280};\\\", \\\"{x:1275,y:563,t:1526930099345};\\\", \\\"{x:1263,y:621,t:1526930099364};\\\", \\\"{x:1242,y:722,t:1526930099380};\\\", \\\"{x:1232,y:832,t:1526930099396};\\\", \\\"{x:1234,y:922,t:1526930099413};\\\", \\\"{x:1268,y:1014,t:1526930099430};\\\", \\\"{x:1282,y:1043,t:1526930099446};\\\", \\\"{x:1292,y:1057,t:1526930099462};\\\", \\\"{x:1292,y:1058,t:1526930099480};\\\", \\\"{x:1293,y:1058,t:1526930099550};\\\", \\\"{x:1292,y:1054,t:1526930099563};\\\", \\\"{x:1277,y:1036,t:1526930099580};\\\", \\\"{x:1241,y:1006,t:1526930099596};\\\", \\\"{x:1184,y:964,t:1526930099613};\\\", \\\"{x:1125,y:919,t:1526930099631};\\\", \\\"{x:1081,y:881,t:1526930099646};\\\", \\\"{x:1044,y:834,t:1526930099663};\\\", \\\"{x:1041,y:808,t:1526930099680};\\\", \\\"{x:1042,y:792,t:1526930099697};\\\", \\\"{x:1053,y:773,t:1526930099713};\\\", \\\"{x:1064,y:752,t:1526930099730};\\\", \\\"{x:1084,y:726,t:1526930099746};\\\", \\\"{x:1107,y:676,t:1526930099763};\\\", \\\"{x:1129,y:634,t:1526930099781};\\\", \\\"{x:1141,y:603,t:1526930099797};\\\", \\\"{x:1154,y:580,t:1526930099813};\\\", \\\"{x:1176,y:548,t:1526930099830};\\\", \\\"{x:1206,y:528,t:1526930099846};\\\", \\\"{x:1224,y:518,t:1526930099863};\\\", \\\"{x:1245,y:507,t:1526930099881};\\\", \\\"{x:1263,y:500,t:1526930099897};\\\", \\\"{x:1276,y:493,t:1526930099913};\\\", \\\"{x:1284,y:489,t:1526930099930};\\\", \\\"{x:1286,y:487,t:1526930099947};\\\", \\\"{x:1289,y:487,t:1526930099999};\\\", \\\"{x:1291,y:490,t:1526930100013};\\\", \\\"{x:1299,y:500,t:1526930100030};\\\", \\\"{x:1312,y:516,t:1526930100047};\\\", \\\"{x:1316,y:527,t:1526930100063};\\\", \\\"{x:1317,y:535,t:1526930100080};\\\", \\\"{x:1317,y:540,t:1526930100097};\\\", \\\"{x:1317,y:546,t:1526930100113};\\\", \\\"{x:1317,y:555,t:1526930100130};\\\", \\\"{x:1313,y:563,t:1526930100148};\\\", \\\"{x:1309,y:573,t:1526930100164};\\\", \\\"{x:1304,y:581,t:1526930100180};\\\", \\\"{x:1298,y:592,t:1526930100197};\\\", \\\"{x:1289,y:607,t:1526930100214};\\\", \\\"{x:1282,y:627,t:1526930100230};\\\", \\\"{x:1266,y:662,t:1526930100247};\\\", \\\"{x:1256,y:688,t:1526930100264};\\\", \\\"{x:1253,y:719,t:1526930100281};\\\", \\\"{x:1248,y:749,t:1526930100298};\\\", \\\"{x:1247,y:787,t:1526930100314};\\\", \\\"{x:1247,y:815,t:1526930100330};\\\", \\\"{x:1247,y:833,t:1526930100347};\\\", \\\"{x:1247,y:839,t:1526930100364};\\\", \\\"{x:1247,y:843,t:1526930100380};\\\", \\\"{x:1247,y:844,t:1526930100398};\\\", \\\"{x:1244,y:847,t:1526930100414};\\\", \\\"{x:1238,y:849,t:1526930100430};\\\", \\\"{x:1229,y:851,t:1526930100447};\\\", \\\"{x:1227,y:851,t:1526930100470};\\\", \\\"{x:1226,y:851,t:1526930100487};\\\", \\\"{x:1226,y:850,t:1526930100497};\\\", \\\"{x:1224,y:848,t:1526930100514};\\\", \\\"{x:1222,y:844,t:1526930100530};\\\", \\\"{x:1220,y:841,t:1526930100547};\\\", \\\"{x:1219,y:840,t:1526930100564};\\\", \\\"{x:1219,y:837,t:1526930100581};\\\", \\\"{x:1218,y:831,t:1526930100598};\\\", \\\"{x:1217,y:822,t:1526930100615};\\\", \\\"{x:1216,y:820,t:1526930100630};\\\", \\\"{x:1216,y:816,t:1526930100647};\\\", \\\"{x:1216,y:807,t:1526930100664};\\\", \\\"{x:1216,y:798,t:1526930100680};\\\", \\\"{x:1222,y:778,t:1526930100697};\\\", \\\"{x:1227,y:751,t:1526930100714};\\\", \\\"{x:1232,y:723,t:1526930100731};\\\", \\\"{x:1239,y:693,t:1526930100748};\\\", \\\"{x:1246,y:669,t:1526930100764};\\\", \\\"{x:1251,y:648,t:1526930100781};\\\", \\\"{x:1257,y:630,t:1526930100797};\\\", \\\"{x:1262,y:610,t:1526930100815};\\\", \\\"{x:1271,y:583,t:1526930100831};\\\", \\\"{x:1276,y:570,t:1526930100847};\\\", \\\"{x:1277,y:566,t:1526930100864};\\\", \\\"{x:1279,y:562,t:1526930100881};\\\", \\\"{x:1281,y:559,t:1526930100897};\\\", \\\"{x:1283,y:557,t:1526930100915};\\\", \\\"{x:1284,y:555,t:1526930100931};\\\", \\\"{x:1286,y:555,t:1526930101046};\\\", \\\"{x:1288,y:553,t:1526930101199};\\\", \\\"{x:1290,y:550,t:1526930101214};\\\", \\\"{x:1292,y:548,t:1526930101230};\\\", \\\"{x:1291,y:550,t:1526930101471};\\\", \\\"{x:1289,y:551,t:1526930101482};\\\", \\\"{x:1283,y:557,t:1526930101498};\\\", \\\"{x:1276,y:561,t:1526930101514};\\\", \\\"{x:1271,y:564,t:1526930101532};\\\", \\\"{x:1269,y:565,t:1526930101548};\\\", \\\"{x:1269,y:566,t:1526930101687};\\\", \\\"{x:1270,y:566,t:1526930101726};\\\", \\\"{x:1271,y:566,t:1526930101734};\\\", \\\"{x:1272,y:567,t:1526930101807};\\\", \\\"{x:1273,y:567,t:1526930101815};\\\", \\\"{x:1276,y:565,t:1526930101832};\\\", \\\"{x:1276,y:564,t:1526930101848};\\\", \\\"{x:1277,y:563,t:1526930101864};\\\", \\\"{x:1277,y:562,t:1526930102344};\\\", \\\"{x:1278,y:562,t:1526930108071};\\\", \\\"{x:1279,y:562,t:1526930108086};\\\", \\\"{x:1280,y:562,t:1526930108103};\\\", \\\"{x:1281,y:567,t:1526930108135};\\\", \\\"{x:1283,y:575,t:1526930108145};\\\", \\\"{x:1284,y:579,t:1526930108152};\\\", \\\"{x:1288,y:588,t:1526930108169};\\\", \\\"{x:1289,y:593,t:1526930108186};\\\", \\\"{x:1290,y:596,t:1526930108202};\\\", \\\"{x:1292,y:599,t:1526930108219};\\\", \\\"{x:1292,y:600,t:1526930108254};\\\", \\\"{x:1292,y:601,t:1526930108269};\\\", \\\"{x:1292,y:604,t:1526930108287};\\\", \\\"{x:1293,y:606,t:1526930108303};\\\", \\\"{x:1293,y:610,t:1526930108320};\\\", \\\"{x:1293,y:617,t:1526930108337};\\\", \\\"{x:1293,y:624,t:1526930108353};\\\", \\\"{x:1293,y:631,t:1526930108370};\\\", \\\"{x:1293,y:637,t:1526930108387};\\\", \\\"{x:1293,y:646,t:1526930108403};\\\", \\\"{x:1293,y:653,t:1526930108420};\\\", \\\"{x:1293,y:660,t:1526930108437};\\\", \\\"{x:1293,y:667,t:1526930108453};\\\", \\\"{x:1293,y:672,t:1526930108470};\\\", \\\"{x:1293,y:681,t:1526930108487};\\\", \\\"{x:1293,y:687,t:1526930108502};\\\", \\\"{x:1293,y:697,t:1526930108520};\\\", \\\"{x:1293,y:716,t:1526930108536};\\\", \\\"{x:1293,y:741,t:1526930108554};\\\", \\\"{x:1293,y:766,t:1526930108569};\\\", \\\"{x:1294,y:785,t:1526930108587};\\\", \\\"{x:1296,y:799,t:1526930108604};\\\", \\\"{x:1297,y:813,t:1526930108619};\\\", \\\"{x:1298,y:824,t:1526930108637};\\\", \\\"{x:1298,y:838,t:1526930108654};\\\", \\\"{x:1298,y:848,t:1526930108669};\\\", \\\"{x:1298,y:861,t:1526930108687};\\\", \\\"{x:1298,y:864,t:1526930108703};\\\", \\\"{x:1298,y:868,t:1526930108720};\\\", \\\"{x:1297,y:872,t:1526930108736};\\\", \\\"{x:1297,y:877,t:1526930108753};\\\", \\\"{x:1297,y:883,t:1526930108769};\\\", \\\"{x:1296,y:888,t:1526930108786};\\\", \\\"{x:1295,y:894,t:1526930108803};\\\", \\\"{x:1293,y:898,t:1526930108820};\\\", \\\"{x:1291,y:904,t:1526930108836};\\\", \\\"{x:1287,y:914,t:1526930108854};\\\", \\\"{x:1280,y:930,t:1526930108871};\\\", \\\"{x:1277,y:939,t:1526930108886};\\\", \\\"{x:1274,y:952,t:1526930108904};\\\", \\\"{x:1272,y:960,t:1526930108920};\\\", \\\"{x:1270,y:965,t:1526930108937};\\\", \\\"{x:1270,y:967,t:1526930108953};\\\", \\\"{x:1270,y:968,t:1526930108971};\\\", \\\"{x:1270,y:970,t:1526930108990};\\\", \\\"{x:1270,y:972,t:1526930109003};\\\", \\\"{x:1270,y:978,t:1526930109020};\\\", \\\"{x:1269,y:981,t:1526930109036};\\\", \\\"{x:1269,y:982,t:1526930109053};\\\", \\\"{x:1268,y:983,t:1526930109175};\\\", \\\"{x:1267,y:983,t:1526930109191};\\\", \\\"{x:1267,y:982,t:1526930109203};\\\", \\\"{x:1268,y:974,t:1526930109220};\\\", \\\"{x:1268,y:970,t:1526930109237};\\\", \\\"{x:1269,y:967,t:1526930109255};\\\", \\\"{x:1270,y:965,t:1526930109270};\\\", \\\"{x:1270,y:964,t:1526930109288};\\\", \\\"{x:1271,y:963,t:1526930109519};\\\", \\\"{x:1273,y:963,t:1526930110110};\\\", \\\"{x:1275,y:964,t:1526930110120};\\\", \\\"{x:1282,y:964,t:1526930110137};\\\", \\\"{x:1289,y:964,t:1526930110155};\\\", \\\"{x:1291,y:964,t:1526930110170};\\\", \\\"{x:1293,y:965,t:1526930110188};\\\", \\\"{x:1292,y:965,t:1526930110375};\\\", \\\"{x:1291,y:965,t:1526930110387};\\\", \\\"{x:1287,y:964,t:1526930110405};\\\", \\\"{x:1282,y:963,t:1526930110422};\\\", \\\"{x:1276,y:962,t:1526930110438};\\\", \\\"{x:1275,y:961,t:1526930110454};\\\", \\\"{x:1274,y:961,t:1526930110478};\\\", \\\"{x:1272,y:961,t:1526930110527};\\\", \\\"{x:1273,y:961,t:1526930110790};\\\", \\\"{x:1274,y:961,t:1526930110805};\\\", \\\"{x:1276,y:961,t:1526930110821};\\\", \\\"{x:1285,y:961,t:1526930110838};\\\", \\\"{x:1290,y:961,t:1526930110855};\\\", \\\"{x:1291,y:962,t:1526930110872};\\\", \\\"{x:1290,y:962,t:1526930111087};\\\", \\\"{x:1289,y:962,t:1526930111094};\\\", \\\"{x:1288,y:961,t:1526930111254};\\\", \\\"{x:1288,y:960,t:1526930111278};\\\", \\\"{x:1288,y:955,t:1526930117995};\\\", \\\"{x:1315,y:935,t:1526930118002};\\\", \\\"{x:1345,y:919,t:1526930118013};\\\", \\\"{x:1414,y:899,t:1526930118030};\\\", \\\"{x:1462,y:877,t:1526930118047};\\\", \\\"{x:1502,y:870,t:1526930118064};\\\", \\\"{x:1528,y:866,t:1526930118080};\\\", \\\"{x:1538,y:865,t:1526930118098};\\\", \\\"{x:1538,y:864,t:1526930118114};\\\", \\\"{x:1539,y:864,t:1526930118153};\\\", \\\"{x:1540,y:863,t:1526930118164};\\\", \\\"{x:1542,y:860,t:1526930118181};\\\", \\\"{x:1553,y:851,t:1526930118198};\\\", \\\"{x:1562,y:843,t:1526930118214};\\\", \\\"{x:1571,y:834,t:1526930118231};\\\", \\\"{x:1573,y:826,t:1526930118248};\\\", \\\"{x:1572,y:820,t:1526930118263};\\\", \\\"{x:1563,y:814,t:1526930118280};\\\", \\\"{x:1559,y:811,t:1526930118297};\\\", \\\"{x:1543,y:812,t:1526930118314};\\\", \\\"{x:1506,y:829,t:1526930118330};\\\", \\\"{x:1490,y:836,t:1526930118348};\\\", \\\"{x:1486,y:840,t:1526930118365};\\\", \\\"{x:1485,y:840,t:1526930118381};\\\", \\\"{x:1485,y:841,t:1526930118410};\\\", \\\"{x:1485,y:842,t:1526930118442};\\\", \\\"{x:1485,y:844,t:1526930118450};\\\", \\\"{x:1487,y:844,t:1526930118466};\\\", \\\"{x:1489,y:844,t:1526930118506};\\\", \\\"{x:1490,y:843,t:1526930118514};\\\", \\\"{x:1492,y:842,t:1526930118530};\\\", \\\"{x:1494,y:841,t:1526930118548};\\\", \\\"{x:1496,y:840,t:1526930118564};\\\", \\\"{x:1496,y:839,t:1526930118626};\\\", \\\"{x:1496,y:837,t:1526930118642};\\\", \\\"{x:1497,y:836,t:1526930118650};\\\", \\\"{x:1497,y:834,t:1526930118664};\\\", \\\"{x:1497,y:832,t:1526930118680};\\\", \\\"{x:1494,y:830,t:1526930118697};\\\", \\\"{x:1489,y:828,t:1526930118714};\\\", \\\"{x:1487,y:826,t:1526930118730};\\\", \\\"{x:1486,y:826,t:1526930118748};\\\", \\\"{x:1485,y:826,t:1526930118819};\\\", \\\"{x:1483,y:825,t:1526930118847};\\\", \\\"{x:1482,y:824,t:1526930118865};\\\", \\\"{x:1481,y:824,t:1526930118881};\\\", \\\"{x:1480,y:824,t:1526930118897};\\\", \\\"{x:1479,y:824,t:1526930118945};\\\", \\\"{x:1479,y:825,t:1526930119019};\\\", \\\"{x:1479,y:826,t:1526930119047};\\\", \\\"{x:1479,y:827,t:1526930119065};\\\", \\\"{x:1478,y:829,t:1526930119090};\\\", \\\"{x:1478,y:831,t:1526930119148};\\\", \\\"{x:1476,y:835,t:1526930119165};\\\", \\\"{x:1476,y:839,t:1526930119181};\\\", \\\"{x:1474,y:844,t:1526930119197};\\\", \\\"{x:1472,y:850,t:1526930119215};\\\", \\\"{x:1471,y:862,t:1526930119231};\\\", \\\"{x:1470,y:877,t:1526930119249};\\\", \\\"{x:1466,y:898,t:1526930119264};\\\", \\\"{x:1462,y:915,t:1526930119282};\\\", \\\"{x:1461,y:937,t:1526930119297};\\\", \\\"{x:1460,y:948,t:1526930119314};\\\", \\\"{x:1458,y:953,t:1526930119331};\\\", \\\"{x:1458,y:956,t:1526930119349};\\\", \\\"{x:1459,y:953,t:1526930119474};\\\", \\\"{x:1460,y:947,t:1526930119481};\\\", \\\"{x:1460,y:935,t:1526930119497};\\\", \\\"{x:1460,y:912,t:1526930119514};\\\", \\\"{x:1460,y:890,t:1526930119532};\\\", \\\"{x:1460,y:867,t:1526930119548};\\\", \\\"{x:1458,y:850,t:1526930119565};\\\", \\\"{x:1458,y:841,t:1526930119581};\\\", \\\"{x:1458,y:837,t:1526930119599};\\\", \\\"{x:1458,y:834,t:1526930119615};\\\", \\\"{x:1459,y:834,t:1526930119631};\\\", \\\"{x:1459,y:833,t:1526930119690};\\\", \\\"{x:1461,y:832,t:1526930119698};\\\", \\\"{x:1462,y:831,t:1526930119715};\\\", \\\"{x:1463,y:831,t:1526930119859};\\\", \\\"{x:1464,y:831,t:1526930119865};\\\", \\\"{x:1465,y:831,t:1526930119882};\\\", \\\"{x:1466,y:831,t:1526930119906};\\\", \\\"{x:1467,y:831,t:1526930119915};\\\", \\\"{x:1468,y:831,t:1526930119931};\\\", \\\"{x:1469,y:831,t:1526930119948};\\\", \\\"{x:1470,y:831,t:1526930120059};\\\", \\\"{x:1471,y:831,t:1526930120082};\\\", \\\"{x:1472,y:831,t:1526930120114};\\\", \\\"{x:1473,y:832,t:1526930120338};\\\", \\\"{x:1475,y:832,t:1526930120354};\\\", \\\"{x:1476,y:832,t:1526930120403};\\\", \\\"{x:1478,y:832,t:1526930120434};\\\", \\\"{x:1479,y:832,t:1526930120466};\\\", \\\"{x:1481,y:832,t:1526930120938};\\\", \\\"{x:1482,y:832,t:1526930120949};\\\", \\\"{x:1484,y:832,t:1526930120978};\\\", \\\"{x:1484,y:833,t:1526930121050};\\\", \\\"{x:1485,y:833,t:1526930121065};\\\", \\\"{x:1487,y:833,t:1526930121083};\\\", \\\"{x:1491,y:833,t:1526930121099};\\\", \\\"{x:1498,y:833,t:1526930121115};\\\", \\\"{x:1508,y:833,t:1526930121133};\\\", \\\"{x:1519,y:833,t:1526930121150};\\\", \\\"{x:1532,y:833,t:1526930121166};\\\", \\\"{x:1541,y:833,t:1526930121183};\\\", \\\"{x:1550,y:833,t:1526930121199};\\\", \\\"{x:1556,y:833,t:1526930121217};\\\", \\\"{x:1560,y:833,t:1526930121233};\\\", \\\"{x:1565,y:833,t:1526930121250};\\\", \\\"{x:1567,y:833,t:1526930121266};\\\", \\\"{x:1568,y:833,t:1526930121282};\\\", \\\"{x:1565,y:833,t:1526930121402};\\\", \\\"{x:1554,y:829,t:1526930121416};\\\", \\\"{x:1505,y:807,t:1526930121433};\\\", \\\"{x:1375,y:757,t:1526930121450};\\\", \\\"{x:1252,y:732,t:1526930121466};\\\", \\\"{x:1137,y:706,t:1526930121481};\\\", \\\"{x:1034,y:676,t:1526930121499};\\\", \\\"{x:969,y:655,t:1526930121516};\\\", \\\"{x:924,y:639,t:1526930121532};\\\", \\\"{x:910,y:635,t:1526930121549};\\\", \\\"{x:907,y:634,t:1526930121565};\\\", \\\"{x:906,y:633,t:1526930121601};\\\", \\\"{x:904,y:632,t:1526930121616};\\\", \\\"{x:877,y:621,t:1526930121635};\\\", \\\"{x:827,y:598,t:1526930121649};\\\", \\\"{x:743,y:569,t:1526930121667};\\\", \\\"{x:591,y:505,t:1526930121700};\\\", \\\"{x:563,y:494,t:1526930121717};\\\", \\\"{x:556,y:491,t:1526930121734};\\\", \\\"{x:556,y:490,t:1526930121750};\\\", \\\"{x:554,y:489,t:1526930121767};\\\", \\\"{x:554,y:488,t:1526930121784};\\\", \\\"{x:554,y:487,t:1526930121816};\\\", \\\"{x:553,y:484,t:1526930121825};\\\", \\\"{x:550,y:482,t:1526930121834};\\\", \\\"{x:534,y:470,t:1526930121851};\\\", \\\"{x:505,y:450,t:1526930121868};\\\", \\\"{x:456,y:420,t:1526930121885};\\\", \\\"{x:403,y:395,t:1526930121902};\\\", \\\"{x:364,y:378,t:1526930121918};\\\", \\\"{x:347,y:373,t:1526930121935};\\\", \\\"{x:346,y:373,t:1526930121952};\\\", \\\"{x:347,y:373,t:1526930121968};\\\", \\\"{x:369,y:380,t:1526930121985};\\\", \\\"{x:384,y:389,t:1526930122002};\\\", \\\"{x:397,y:402,t:1526930122018};\\\", \\\"{x:410,y:419,t:1526930122035};\\\", \\\"{x:422,y:441,t:1526930122051};\\\", \\\"{x:431,y:458,t:1526930122068};\\\", \\\"{x:443,y:475,t:1526930122085};\\\", \\\"{x:458,y:489,t:1526930122103};\\\", \\\"{x:474,y:500,t:1526930122119};\\\", \\\"{x:486,y:507,t:1526930122135};\\\", \\\"{x:501,y:515,t:1526930122151};\\\", \\\"{x:516,y:522,t:1526930122168};\\\", \\\"{x:543,y:530,t:1526930122186};\\\", \\\"{x:558,y:533,t:1526930122202};\\\", \\\"{x:570,y:537,t:1526930122218};\\\", \\\"{x:575,y:538,t:1526930122235};\\\", \\\"{x:580,y:541,t:1526930122252};\\\", \\\"{x:584,y:541,t:1526930122268};\\\", \\\"{x:589,y:542,t:1526930122285};\\\", \\\"{x:591,y:542,t:1526930122302};\\\", \\\"{x:593,y:542,t:1526930122318};\\\", \\\"{x:594,y:542,t:1526930122442};\\\", \\\"{x:596,y:540,t:1526930122452};\\\", \\\"{x:599,y:537,t:1526930122468};\\\", \\\"{x:602,y:533,t:1526930122486};\\\", \\\"{x:611,y:529,t:1526930122502};\\\", \\\"{x:624,y:526,t:1526930122519};\\\", \\\"{x:633,y:525,t:1526930122536};\\\", \\\"{x:641,y:525,t:1526930122551};\\\", \\\"{x:646,y:525,t:1526930122568};\\\", \\\"{x:648,y:525,t:1526930122585};\\\", \\\"{x:649,y:525,t:1526930122601};\\\", \\\"{x:650,y:527,t:1526930122625};\\\", \\\"{x:651,y:528,t:1526930122634};\\\", \\\"{x:652,y:533,t:1526930122652};\\\", \\\"{x:653,y:538,t:1526930122669};\\\", \\\"{x:654,y:539,t:1526930122684};\\\", \\\"{x:656,y:538,t:1526930122748};\\\", \\\"{x:661,y:531,t:1526930122753};\\\", \\\"{x:663,y:522,t:1526930122770};\\\", \\\"{x:663,y:517,t:1526930122785};\\\", \\\"{x:660,y:513,t:1526930122802};\\\", \\\"{x:648,y:508,t:1526930122819};\\\", \\\"{x:642,y:504,t:1526930122836};\\\", \\\"{x:640,y:504,t:1526930122852};\\\", \\\"{x:638,y:503,t:1526930122869};\\\", \\\"{x:636,y:502,t:1526930122886};\\\", \\\"{x:633,y:502,t:1526930122901};\\\", \\\"{x:632,y:501,t:1526930122918};\\\", \\\"{x:630,y:500,t:1526930122936};\\\", \\\"{x:629,y:500,t:1526930122953};\\\", \\\"{x:626,y:499,t:1526930122968};\\\", \\\"{x:625,y:499,t:1526930123009};\\\", \\\"{x:623,y:498,t:1526930123041};\\\", \\\"{x:622,y:497,t:1526930123065};\\\", \\\"{x:622,y:506,t:1526930123482};\\\", \\\"{x:622,y:520,t:1526930123491};\\\", \\\"{x:625,y:537,t:1526930123504};\\\", \\\"{x:644,y:565,t:1526930123519};\\\", \\\"{x:671,y:587,t:1526930123536};\\\", \\\"{x:729,y:614,t:1526930123552};\\\", \\\"{x:864,y:663,t:1526930123569};\\\", \\\"{x:957,y:694,t:1526930123585};\\\", \\\"{x:1052,y:730,t:1526930123602};\\\", \\\"{x:1134,y:758,t:1526930123619};\\\", \\\"{x:1193,y:779,t:1526930123636};\\\", \\\"{x:1224,y:789,t:1526930123652};\\\", \\\"{x:1236,y:795,t:1526930123669};\\\", \\\"{x:1237,y:795,t:1526930123686};\\\", \\\"{x:1239,y:795,t:1526930124171};\\\", \\\"{x:1242,y:795,t:1526930124184};\\\", \\\"{x:1259,y:786,t:1526930124202};\\\", \\\"{x:1286,y:769,t:1526930124218};\\\", \\\"{x:1338,y:745,t:1526930124235};\\\", \\\"{x:1404,y:719,t:1526930124251};\\\", \\\"{x:1445,y:707,t:1526930124268};\\\", \\\"{x:1471,y:703,t:1526930124284};\\\", \\\"{x:1484,y:698,t:1526930124301};\\\", \\\"{x:1488,y:697,t:1526930124319};\\\", \\\"{x:1488,y:696,t:1526930124338};\\\", \\\"{x:1486,y:693,t:1526930124352};\\\", \\\"{x:1481,y:692,t:1526930124367};\\\", \\\"{x:1476,y:689,t:1526930124384};\\\", \\\"{x:1464,y:684,t:1526930124402};\\\", \\\"{x:1445,y:679,t:1526930124418};\\\", \\\"{x:1426,y:673,t:1526930124434};\\\", \\\"{x:1406,y:669,t:1526930124451};\\\", \\\"{x:1390,y:666,t:1526930124467};\\\", \\\"{x:1366,y:660,t:1526930124485};\\\", \\\"{x:1350,y:653,t:1526930124502};\\\", \\\"{x:1339,y:651,t:1526930124517};\\\", \\\"{x:1328,y:648,t:1526930124535};\\\", \\\"{x:1321,y:647,t:1526930124551};\\\", \\\"{x:1316,y:646,t:1526930124567};\\\", \\\"{x:1313,y:644,t:1526930124584};\\\", \\\"{x:1311,y:643,t:1526930124600};\\\", \\\"{x:1310,y:642,t:1526930124617};\\\", \\\"{x:1307,y:641,t:1526930124633};\\\", \\\"{x:1303,y:640,t:1526930124650};\\\", \\\"{x:1294,y:637,t:1526930124667};\\\", \\\"{x:1286,y:636,t:1526930124683};\\\", \\\"{x:1280,y:636,t:1526930124700};\\\", \\\"{x:1278,y:636,t:1526930124717};\\\", \\\"{x:1275,y:636,t:1526930124733};\\\", \\\"{x:1272,y:636,t:1526930124750};\\\", \\\"{x:1269,y:641,t:1526930124767};\\\", \\\"{x:1265,y:650,t:1526930124783};\\\", \\\"{x:1255,y:665,t:1526930124800};\\\", \\\"{x:1234,y:701,t:1526930124816};\\\", \\\"{x:1226,y:721,t:1526930124833};\\\", \\\"{x:1218,y:740,t:1526930124850};\\\", \\\"{x:1214,y:750,t:1526930124867};\\\", \\\"{x:1211,y:756,t:1526930124884};\\\", \\\"{x:1211,y:757,t:1526930124900};\\\", \\\"{x:1209,y:759,t:1526930124921};\\\", \\\"{x:1209,y:760,t:1526930124938};\\\", \\\"{x:1207,y:764,t:1526930124949};\\\", \\\"{x:1203,y:768,t:1526930124966};\\\", \\\"{x:1200,y:770,t:1526930124983};\\\", \\\"{x:1199,y:772,t:1526930124999};\\\", \\\"{x:1195,y:774,t:1526930125016};\\\", \\\"{x:1185,y:777,t:1526930125034};\\\", \\\"{x:1172,y:781,t:1526930125050};\\\", \\\"{x:1157,y:784,t:1526930125067};\\\", \\\"{x:1148,y:784,t:1526930125083};\\\", \\\"{x:1147,y:784,t:1526930125099};\\\", \\\"{x:1146,y:784,t:1526930125146};\\\", \\\"{x:1146,y:783,t:1526930125161};\\\", \\\"{x:1146,y:782,t:1526930125169};\\\", \\\"{x:1146,y:781,t:1526930125186};\\\", \\\"{x:1146,y:780,t:1526930125210};\\\", \\\"{x:1146,y:779,t:1526930125226};\\\", \\\"{x:1147,y:778,t:1526930125234};\\\", \\\"{x:1148,y:777,t:1526930125249};\\\", \\\"{x:1149,y:776,t:1526930125273};\\\", \\\"{x:1149,y:775,t:1526930125282};\\\", \\\"{x:1150,y:775,t:1526930125300};\\\", \\\"{x:1153,y:774,t:1526930125315};\\\", \\\"{x:1156,y:773,t:1526930125333};\\\", \\\"{x:1160,y:771,t:1526930125349};\\\", \\\"{x:1165,y:770,t:1526930125366};\\\", \\\"{x:1166,y:770,t:1526930125382};\\\", \\\"{x:1167,y:770,t:1526930125400};\\\", \\\"{x:1168,y:770,t:1526930125418};\\\", \\\"{x:1170,y:771,t:1526930125626};\\\", \\\"{x:1172,y:777,t:1526930125634};\\\", \\\"{x:1177,y:783,t:1526930125648};\\\", \\\"{x:1188,y:801,t:1526930125665};\\\", \\\"{x:1194,y:812,t:1526930125681};\\\", \\\"{x:1199,y:822,t:1526930125698};\\\", \\\"{x:1212,y:831,t:1526930125716};\\\", \\\"{x:1214,y:835,t:1526930125731};\\\", \\\"{x:1215,y:835,t:1526930125748};\\\", \\\"{x:1217,y:833,t:1526930126050};\\\", \\\"{x:1217,y:828,t:1526930126064};\\\", \\\"{x:1220,y:818,t:1526930126081};\\\", \\\"{x:1229,y:802,t:1526930126098};\\\", \\\"{x:1236,y:787,t:1526930126115};\\\", \\\"{x:1249,y:763,t:1526930126131};\\\", \\\"{x:1278,y:723,t:1526930126148};\\\", \\\"{x:1306,y:693,t:1526930126165};\\\", \\\"{x:1328,y:675,t:1526930126181};\\\", \\\"{x:1346,y:665,t:1526930126198};\\\", \\\"{x:1355,y:662,t:1526930126214};\\\", \\\"{x:1359,y:661,t:1526930126230};\\\", \\\"{x:1360,y:662,t:1526930126411};\\\", \\\"{x:1360,y:664,t:1526930126418};\\\", \\\"{x:1360,y:665,t:1526930126431};\\\", \\\"{x:1358,y:668,t:1526930126447};\\\", \\\"{x:1358,y:669,t:1526930126463};\\\", \\\"{x:1358,y:670,t:1526930126602};\\\", \\\"{x:1358,y:671,t:1526930126970};\\\", \\\"{x:1358,y:673,t:1526930127002};\\\", \\\"{x:1357,y:675,t:1526930127013};\\\", \\\"{x:1357,y:678,t:1526930127029};\\\", \\\"{x:1355,y:681,t:1526930127046};\\\", \\\"{x:1355,y:682,t:1526930127062};\\\", \\\"{x:1355,y:683,t:1526930127079};\\\", \\\"{x:1355,y:684,t:1526930127106};\\\", \\\"{x:1355,y:685,t:1526930127195};\\\", \\\"{x:1355,y:686,t:1526930127209};\\\", \\\"{x:1353,y:687,t:1526930127786};\\\", \\\"{x:1350,y:690,t:1526930127794};\\\", \\\"{x:1342,y:696,t:1526930127811};\\\", \\\"{x:1330,y:704,t:1526930127829};\\\", \\\"{x:1321,y:710,t:1526930127843};\\\", \\\"{x:1311,y:717,t:1526930127861};\\\", \\\"{x:1299,y:725,t:1526930127877};\\\", \\\"{x:1287,y:739,t:1526930127893};\\\", \\\"{x:1272,y:759,t:1526930127911};\\\", \\\"{x:1259,y:779,t:1526930127928};\\\", \\\"{x:1247,y:797,t:1526930127944};\\\", \\\"{x:1241,y:805,t:1526930127960};\\\", \\\"{x:1239,y:809,t:1526930127977};\\\", \\\"{x:1238,y:810,t:1526930127994};\\\", \\\"{x:1237,y:811,t:1526930128339};\\\", \\\"{x:1234,y:814,t:1526930128345};\\\", \\\"{x:1231,y:818,t:1526930128360};\\\", \\\"{x:1224,y:822,t:1526930128377};\\\", \\\"{x:1216,y:828,t:1526930128393};\\\", \\\"{x:1210,y:832,t:1526930128410};\\\", \\\"{x:1209,y:832,t:1526930128449};\\\", \\\"{x:1209,y:833,t:1526930129323};\\\", \\\"{x:1210,y:830,t:1526930129642};\\\", \\\"{x:1211,y:825,t:1526930129656};\\\", \\\"{x:1211,y:806,t:1526930129675};\\\", \\\"{x:1200,y:791,t:1526930129690};\\\", \\\"{x:1187,y:777,t:1526930129707};\\\", \\\"{x:1171,y:766,t:1526930129724};\\\", \\\"{x:1161,y:759,t:1526930129739};\\\", \\\"{x:1160,y:758,t:1526930129757};\\\", \\\"{x:1164,y:757,t:1526930130034};\\\", \\\"{x:1175,y:736,t:1526930130042};\\\", \\\"{x:1193,y:704,t:1526930130056};\\\", \\\"{x:1241,y:611,t:1526930130073};\\\", \\\"{x:1321,y:489,t:1526930130089};\\\", \\\"{x:1359,y:452,t:1526930130106};\\\", \\\"{x:1378,y:434,t:1526930130123};\\\", \\\"{x:1384,y:429,t:1526930130139};\\\", \\\"{x:1384,y:431,t:1526930130218};\\\", \\\"{x:1384,y:440,t:1526930130225};\\\", \\\"{x:1384,y:445,t:1526930130239};\\\", \\\"{x:1381,y:460,t:1526930130256};\\\", \\\"{x:1371,y:481,t:1526930130273};\\\", \\\"{x:1360,y:502,t:1526930130289};\\\", \\\"{x:1341,y:532,t:1526930130306};\\\", \\\"{x:1327,y:551,t:1526930130322};\\\", \\\"{x:1316,y:566,t:1526930130339};\\\", \\\"{x:1309,y:577,t:1526930130356};\\\", \\\"{x:1300,y:592,t:1526930130372};\\\", \\\"{x:1294,y:601,t:1526930130388};\\\", \\\"{x:1291,y:607,t:1526930130406};\\\", \\\"{x:1290,y:609,t:1526930130422};\\\", \\\"{x:1290,y:607,t:1526930130578};\\\", \\\"{x:1290,y:606,t:1526930130588};\\\", \\\"{x:1291,y:604,t:1526930130605};\\\", \\\"{x:1291,y:603,t:1526930130622};\\\", \\\"{x:1292,y:602,t:1526930130637};\\\", \\\"{x:1292,y:601,t:1526930130655};\\\", \\\"{x:1293,y:601,t:1526930130682};\\\", \\\"{x:1293,y:600,t:1526930130794};\\\", \\\"{x:1294,y:600,t:1526930130850};\\\", \\\"{x:1293,y:600,t:1526930131024};\\\", \\\"{x:1285,y:600,t:1526930131037};\\\", \\\"{x:1260,y:604,t:1526930131053};\\\", \\\"{x:1206,y:604,t:1526930131070};\\\", \\\"{x:1109,y:604,t:1526930131087};\\\", \\\"{x:992,y:608,t:1526930131103};\\\", \\\"{x:855,y:614,t:1526930131121};\\\", \\\"{x:706,y:632,t:1526930131137};\\\", \\\"{x:534,y:671,t:1526930131153};\\\", \\\"{x:454,y:701,t:1526930131175};\\\", \\\"{x:425,y:717,t:1526930131192};\\\", \\\"{x:412,y:729,t:1526930131208};\\\", \\\"{x:411,y:731,t:1526930131224};\\\", \\\"{x:408,y:733,t:1526930131241};\\\", \\\"{x:402,y:737,t:1526930131258};\\\", \\\"{x:391,y:741,t:1526930131275};\\\", \\\"{x:383,y:746,t:1526930131291};\\\", \\\"{x:372,y:754,t:1526930131309};\\\", \\\"{x:368,y:758,t:1526930131325};\\\", \\\"{x:367,y:759,t:1526930131341};\\\", \\\"{x:368,y:759,t:1526930131369};\\\", \\\"{x:370,y:759,t:1526930131378};\\\", \\\"{x:373,y:759,t:1526930131392};\\\", \\\"{x:377,y:759,t:1526930131409};\\\", \\\"{x:386,y:760,t:1526930131425};\\\", \\\"{x:402,y:760,t:1526930131441};\\\", \\\"{x:411,y:760,t:1526930131458};\\\", \\\"{x:414,y:760,t:1526930131475};\\\", \\\"{x:420,y:760,t:1526930131492};\\\", \\\"{x:426,y:760,t:1526930131509};\\\", \\\"{x:437,y:759,t:1526930131525};\\\", \\\"{x:449,y:756,t:1526930131542};\\\", \\\"{x:460,y:755,t:1526930131559};\\\", \\\"{x:464,y:754,t:1526930131576};\\\", \\\"{x:465,y:754,t:1526930131625};\\\", \\\"{x:468,y:754,t:1526930132145};\\\", \\\"{x:475,y:754,t:1526930132160};\\\", \\\"{x:495,y:755,t:1526930132176};\\\", \\\"{x:561,y:744,t:1526930132193};\\\", \\\"{x:653,y:717,t:1526930132209};\\\", \\\"{x:753,y:685,t:1526930132227};\\\", \\\"{x:859,y:655,t:1526930132244};\\\", \\\"{x:952,y:631,t:1526930132259};\\\", \\\"{x:1020,y:619,t:1526930132276};\\\", \\\"{x:1055,y:613,t:1526930132294};\\\", \\\"{x:1070,y:611,t:1526930132309};\\\", \\\"{x:1073,y:611,t:1526930132327};\\\" ] }, { \\\"rt\\\": 24317, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 480934, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -I -10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1075,y:610,t:1526930133891};\\\", \\\"{x:1092,y:608,t:1526930133909};\\\", \\\"{x:1094,y:605,t:1526930133915};\\\", \\\"{x:1097,y:605,t:1526930135506};\\\", \\\"{x:1100,y:605,t:1526930135513};\\\", \\\"{x:1107,y:605,t:1526930135529};\\\", \\\"{x:1112,y:604,t:1526930135546};\\\", \\\"{x:1116,y:602,t:1526930135562};\\\", \\\"{x:1119,y:601,t:1526930135579};\\\", \\\"{x:1121,y:600,t:1526930135596};\\\", \\\"{x:1127,y:597,t:1526930135612};\\\", \\\"{x:1131,y:596,t:1526930135629};\\\", \\\"{x:1137,y:594,t:1526930135646};\\\", \\\"{x:1139,y:593,t:1526930135663};\\\", \\\"{x:1145,y:591,t:1526930135679};\\\", \\\"{x:1155,y:589,t:1526930135696};\\\", \\\"{x:1161,y:589,t:1526930135713};\\\", \\\"{x:1175,y:587,t:1526930135729};\\\", \\\"{x:1187,y:583,t:1526930135745};\\\", \\\"{x:1200,y:579,t:1526930135762};\\\", \\\"{x:1216,y:575,t:1526930135779};\\\", \\\"{x:1228,y:573,t:1526930135796};\\\", \\\"{x:1248,y:569,t:1526930135813};\\\", \\\"{x:1280,y:562,t:1526930135832};\\\", \\\"{x:1325,y:549,t:1526930135846};\\\", \\\"{x:1396,y:535,t:1526930135863};\\\", \\\"{x:1460,y:518,t:1526930135878};\\\", \\\"{x:1512,y:505,t:1526930135895};\\\", \\\"{x:1554,y:497,t:1526930135913};\\\", \\\"{x:1561,y:494,t:1526930135928};\\\", \\\"{x:1563,y:493,t:1526930135945};\\\", \\\"{x:1560,y:490,t:1526930136098};\\\", \\\"{x:1553,y:488,t:1526930136113};\\\", \\\"{x:1530,y:475,t:1526930136129};\\\", \\\"{x:1518,y:471,t:1526930136146};\\\", \\\"{x:1512,y:468,t:1526930136162};\\\", \\\"{x:1509,y:467,t:1526930136179};\\\", \\\"{x:1507,y:466,t:1526930136196};\\\", \\\"{x:1506,y:466,t:1526930136213};\\\", \\\"{x:1504,y:466,t:1526930136230};\\\", \\\"{x:1504,y:465,t:1526930136247};\\\", \\\"{x:1502,y:465,t:1526930136263};\\\", \\\"{x:1501,y:464,t:1526930136280};\\\", \\\"{x:1499,y:463,t:1526930136297};\\\", \\\"{x:1496,y:462,t:1526930136313};\\\", \\\"{x:1495,y:461,t:1526930136337};\\\", \\\"{x:1494,y:460,t:1526930136426};\\\", \\\"{x:1493,y:460,t:1526930136449};\\\", \\\"{x:1491,y:460,t:1526930136462};\\\", \\\"{x:1489,y:460,t:1526930136480};\\\", \\\"{x:1479,y:460,t:1526930136496};\\\", \\\"{x:1440,y:481,t:1526930136514};\\\", \\\"{x:1397,y:523,t:1526930136529};\\\", \\\"{x:1364,y:570,t:1526930136546};\\\", \\\"{x:1338,y:605,t:1526930136563};\\\", \\\"{x:1325,y:624,t:1526930136580};\\\", \\\"{x:1318,y:632,t:1526930136597};\\\", \\\"{x:1315,y:635,t:1526930136613};\\\", \\\"{x:1312,y:639,t:1526930136630};\\\", \\\"{x:1309,y:653,t:1526930136647};\\\", \\\"{x:1303,y:677,t:1526930136662};\\\", \\\"{x:1293,y:710,t:1526930136679};\\\", \\\"{x:1278,y:753,t:1526930136697};\\\", \\\"{x:1215,y:836,t:1526930136713};\\\", \\\"{x:1188,y:873,t:1526930136729};\\\", \\\"{x:1175,y:889,t:1526930136747};\\\", \\\"{x:1172,y:895,t:1526930136763};\\\", \\\"{x:1170,y:896,t:1526930136780};\\\", \\\"{x:1169,y:897,t:1526930136843};\\\", \\\"{x:1167,y:897,t:1526930136850};\\\", \\\"{x:1163,y:897,t:1526930136863};\\\", \\\"{x:1148,y:890,t:1526930136879};\\\", \\\"{x:1135,y:867,t:1526930136897};\\\", \\\"{x:1134,y:867,t:1526930137450};\\\", \\\"{x:1134,y:866,t:1526930137698};\\\", \\\"{x:1134,y:865,t:1526930137721};\\\", \\\"{x:1134,y:864,t:1526930137731};\\\", \\\"{x:1136,y:862,t:1526930137747};\\\", \\\"{x:1137,y:861,t:1526930137825};\\\", \\\"{x:1138,y:861,t:1526930138786};\\\", \\\"{x:1144,y:856,t:1526930138798};\\\", \\\"{x:1153,y:850,t:1526930138816};\\\", \\\"{x:1159,y:846,t:1526930138831};\\\", \\\"{x:1165,y:842,t:1526930138848};\\\", \\\"{x:1176,y:829,t:1526930138865};\\\", \\\"{x:1181,y:819,t:1526930138882};\\\", \\\"{x:1186,y:810,t:1526930138898};\\\", \\\"{x:1187,y:804,t:1526930138915};\\\", \\\"{x:1189,y:801,t:1526930138932};\\\", \\\"{x:1189,y:800,t:1526930138948};\\\", \\\"{x:1189,y:799,t:1526930138977};\\\", \\\"{x:1189,y:797,t:1526930139034};\\\", \\\"{x:1190,y:793,t:1526930139048};\\\", \\\"{x:1191,y:780,t:1526930139066};\\\", \\\"{x:1191,y:771,t:1526930139082};\\\", \\\"{x:1191,y:765,t:1526930139099};\\\", \\\"{x:1191,y:761,t:1526930139116};\\\", \\\"{x:1191,y:760,t:1526930139132};\\\", \\\"{x:1191,y:759,t:1526930139148};\\\", \\\"{x:1191,y:758,t:1526930139165};\\\", \\\"{x:1191,y:757,t:1526930141690};\\\", \\\"{x:1190,y:757,t:1526930141701};\\\", \\\"{x:1188,y:757,t:1526930141969};\\\", \\\"{x:1186,y:761,t:1526930141984};\\\", \\\"{x:1186,y:767,t:1526930142001};\\\", \\\"{x:1186,y:769,t:1526930142017};\\\", \\\"{x:1186,y:771,t:1526930142034};\\\", \\\"{x:1186,y:772,t:1526930142266};\\\", \\\"{x:1183,y:771,t:1526930142285};\\\", \\\"{x:1181,y:770,t:1526930142301};\\\", \\\"{x:1180,y:770,t:1526930142318};\\\", \\\"{x:1180,y:771,t:1526930142961};\\\", \\\"{x:1180,y:773,t:1526930142969};\\\", \\\"{x:1180,y:775,t:1526930142984};\\\", \\\"{x:1180,y:782,t:1526930143000};\\\", \\\"{x:1180,y:785,t:1526930143018};\\\", \\\"{x:1180,y:787,t:1526930143033};\\\", \\\"{x:1180,y:789,t:1526930143051};\\\", \\\"{x:1180,y:796,t:1526930143067};\\\", \\\"{x:1181,y:804,t:1526930143084};\\\", \\\"{x:1184,y:819,t:1526930143101};\\\", \\\"{x:1186,y:829,t:1526930143118};\\\", \\\"{x:1188,y:837,t:1526930143134};\\\", \\\"{x:1189,y:842,t:1526930143151};\\\", \\\"{x:1190,y:845,t:1526930143168};\\\", \\\"{x:1191,y:849,t:1526930143184};\\\", \\\"{x:1192,y:858,t:1526930143201};\\\", \\\"{x:1193,y:865,t:1526930143218};\\\", \\\"{x:1194,y:876,t:1526930143234};\\\", \\\"{x:1197,y:894,t:1526930143251};\\\", \\\"{x:1199,y:915,t:1526930143268};\\\", \\\"{x:1205,y:932,t:1526930143284};\\\", \\\"{x:1210,y:946,t:1526930143301};\\\", \\\"{x:1216,y:962,t:1526930143318};\\\", \\\"{x:1219,y:969,t:1526930143335};\\\", \\\"{x:1220,y:971,t:1526930143351};\\\", \\\"{x:1220,y:972,t:1526930143578};\\\", \\\"{x:1220,y:971,t:1526930143641};\\\", \\\"{x:1220,y:969,t:1526930143651};\\\", \\\"{x:1220,y:961,t:1526930143669};\\\", \\\"{x:1220,y:958,t:1526930143685};\\\", \\\"{x:1218,y:955,t:1526930143701};\\\", \\\"{x:1218,y:953,t:1526930143718};\\\", \\\"{x:1218,y:952,t:1526930143735};\\\", \\\"{x:1218,y:948,t:1526930143752};\\\", \\\"{x:1218,y:945,t:1526930143769};\\\", \\\"{x:1215,y:937,t:1526930143785};\\\", \\\"{x:1213,y:933,t:1526930143802};\\\", \\\"{x:1211,y:927,t:1526930143817};\\\", \\\"{x:1206,y:916,t:1526930143835};\\\", \\\"{x:1201,y:901,t:1526930143852};\\\", \\\"{x:1196,y:888,t:1526930143868};\\\", \\\"{x:1191,y:876,t:1526930143886};\\\", \\\"{x:1189,y:862,t:1526930143902};\\\", \\\"{x:1185,y:848,t:1526930143918};\\\", \\\"{x:1182,y:835,t:1526930143935};\\\", \\\"{x:1181,y:823,t:1526930143952};\\\", \\\"{x:1181,y:817,t:1526930143968};\\\", \\\"{x:1181,y:806,t:1526930143985};\\\", \\\"{x:1181,y:800,t:1526930144002};\\\", \\\"{x:1182,y:793,t:1526930144018};\\\", \\\"{x:1185,y:784,t:1526930144035};\\\", \\\"{x:1188,y:774,t:1526930144052};\\\", \\\"{x:1190,y:766,t:1526930144068};\\\", \\\"{x:1192,y:757,t:1526930144084};\\\", \\\"{x:1194,y:751,t:1526930144102};\\\", \\\"{x:1195,y:747,t:1526930144117};\\\", \\\"{x:1195,y:746,t:1526930144135};\\\", \\\"{x:1194,y:746,t:1526930144314};\\\", \\\"{x:1193,y:747,t:1526930144322};\\\", \\\"{x:1192,y:748,t:1526930144338};\\\", \\\"{x:1191,y:749,t:1526930144352};\\\", \\\"{x:1190,y:754,t:1526930144369};\\\", \\\"{x:1190,y:756,t:1526930144386};\\\", \\\"{x:1189,y:757,t:1526930144402};\\\", \\\"{x:1189,y:758,t:1526930144419};\\\", \\\"{x:1188,y:759,t:1526930152880};\\\", \\\"{x:1166,y:756,t:1526930152891};\\\", \\\"{x:1113,y:735,t:1526930152908};\\\", \\\"{x:1075,y:720,t:1526930152925};\\\", \\\"{x:1022,y:695,t:1526930152941};\\\", \\\"{x:980,y:675,t:1526930152958};\\\", \\\"{x:960,y:663,t:1526930152975};\\\", \\\"{x:937,y:650,t:1526930152991};\\\", \\\"{x:923,y:642,t:1526930153007};\\\", \\\"{x:908,y:630,t:1526930153025};\\\", \\\"{x:897,y:621,t:1526930153041};\\\", \\\"{x:888,y:614,t:1526930153058};\\\", \\\"{x:881,y:610,t:1526930153071};\\\", \\\"{x:866,y:599,t:1526930153087};\\\", \\\"{x:848,y:589,t:1526930153105};\\\", \\\"{x:836,y:583,t:1526930153126};\\\", \\\"{x:825,y:577,t:1526930153142};\\\", \\\"{x:816,y:573,t:1526930153159};\\\", \\\"{x:811,y:568,t:1526930153176};\\\", \\\"{x:809,y:567,t:1526930153193};\\\", \\\"{x:808,y:567,t:1526930153777};\\\", \\\"{x:807,y:567,t:1526930153809};\\\", \\\"{x:806,y:567,t:1526930153833};\\\", \\\"{x:805,y:567,t:1526930153873};\\\", \\\"{x:803,y:566,t:1526930154553};\\\", \\\"{x:799,y:563,t:1526930154560};\\\", \\\"{x:789,y:560,t:1526930154578};\\\", \\\"{x:775,y:553,t:1526930154595};\\\", \\\"{x:763,y:548,t:1526930154608};\\\", \\\"{x:743,y:546,t:1526930154624};\\\", \\\"{x:717,y:542,t:1526930154641};\\\", \\\"{x:706,y:537,t:1526930154658};\\\", \\\"{x:692,y:534,t:1526930154677};\\\", \\\"{x:689,y:533,t:1526930154694};\\\", \\\"{x:688,y:532,t:1526930154833};\\\", \\\"{x:687,y:532,t:1526930154844};\\\", \\\"{x:684,y:530,t:1526930154861};\\\", \\\"{x:676,y:525,t:1526930154878};\\\", \\\"{x:669,y:520,t:1526930154895};\\\", \\\"{x:662,y:516,t:1526930154911};\\\", \\\"{x:658,y:515,t:1526930154927};\\\", \\\"{x:656,y:513,t:1526930154943};\\\", \\\"{x:657,y:513,t:1526930154984};\\\", \\\"{x:660,y:513,t:1526930155000};\\\", \\\"{x:664,y:513,t:1526930155011};\\\", \\\"{x:672,y:513,t:1526930155027};\\\", \\\"{x:679,y:514,t:1526930155044};\\\", \\\"{x:686,y:517,t:1526930155062};\\\", \\\"{x:691,y:518,t:1526930155078};\\\", \\\"{x:697,y:521,t:1526930155094};\\\", \\\"{x:703,y:523,t:1526930155111};\\\", \\\"{x:710,y:527,t:1526930155128};\\\", \\\"{x:718,y:543,t:1526930155144};\\\", \\\"{x:718,y:565,t:1526930155162};\\\", \\\"{x:712,y:586,t:1526930155177};\\\", \\\"{x:701,y:598,t:1526930155195};\\\", \\\"{x:692,y:604,t:1526930155211};\\\", \\\"{x:669,y:606,t:1526930155227};\\\", \\\"{x:633,y:606,t:1526930155244};\\\", \\\"{x:591,y:609,t:1526930155261};\\\", \\\"{x:535,y:609,t:1526930155277};\\\", \\\"{x:515,y:609,t:1526930155295};\\\", \\\"{x:509,y:609,t:1526930155311};\\\", \\\"{x:508,y:608,t:1526930155352};\\\", \\\"{x:503,y:606,t:1526930155360};\\\", \\\"{x:501,y:602,t:1526930155378};\\\", \\\"{x:480,y:567,t:1526930155395};\\\", \\\"{x:451,y:527,t:1526930155413};\\\", \\\"{x:444,y:509,t:1526930155429};\\\", \\\"{x:443,y:502,t:1526930155444};\\\", \\\"{x:441,y:500,t:1526930155480};\\\", \\\"{x:439,y:499,t:1526930155496};\\\", \\\"{x:438,y:499,t:1526930155553};\\\", \\\"{x:436,y:499,t:1526930155569};\\\", \\\"{x:434,y:499,t:1526930155578};\\\", \\\"{x:431,y:499,t:1526930155594};\\\", \\\"{x:424,y:502,t:1526930155611};\\\", \\\"{x:407,y:510,t:1526930155629};\\\", \\\"{x:369,y:533,t:1526930155645};\\\", \\\"{x:297,y:542,t:1526930155661};\\\", \\\"{x:284,y:542,t:1526930155678};\\\", \\\"{x:274,y:537,t:1526930155694};\\\", \\\"{x:274,y:535,t:1526930155712};\\\", \\\"{x:270,y:532,t:1526930155730};\\\", \\\"{x:266,y:530,t:1526930155744};\\\", \\\"{x:263,y:527,t:1526930156016};\\\", \\\"{x:262,y:526,t:1526930156028};\\\", \\\"{x:258,y:521,t:1526930156046};\\\", \\\"{x:256,y:518,t:1526930156061};\\\", \\\"{x:252,y:515,t:1526930156079};\\\", \\\"{x:247,y:513,t:1526930156095};\\\", \\\"{x:240,y:510,t:1526930156111};\\\", \\\"{x:221,y:506,t:1526930156128};\\\", \\\"{x:204,y:502,t:1526930156145};\\\", \\\"{x:183,y:500,t:1526930156162};\\\", \\\"{x:164,y:497,t:1526930156179};\\\", \\\"{x:145,y:497,t:1526930156196};\\\", \\\"{x:128,y:497,t:1526930156211};\\\", \\\"{x:113,y:496,t:1526930156228};\\\", \\\"{x:108,y:495,t:1526930156245};\\\", \\\"{x:107,y:495,t:1526930156262};\\\", \\\"{x:110,y:495,t:1526930156353};\\\", \\\"{x:120,y:497,t:1526930156362};\\\", \\\"{x:133,y:499,t:1526930156378};\\\", \\\"{x:144,y:500,t:1526930156396};\\\", \\\"{x:151,y:501,t:1526930156413};\\\", \\\"{x:153,y:502,t:1526930156429};\\\", \\\"{x:156,y:502,t:1526930156445};\\\", \\\"{x:157,y:502,t:1526930156462};\\\", \\\"{x:158,y:503,t:1526930156480};\\\", \\\"{x:169,y:505,t:1526930156721};\\\", \\\"{x:186,y:517,t:1526930156729};\\\", \\\"{x:259,y:571,t:1526930156745};\\\", \\\"{x:355,y:646,t:1526930156763};\\\", \\\"{x:462,y:741,t:1526930156780};\\\", \\\"{x:565,y:832,t:1526930156796};\\\", \\\"{x:655,y:884,t:1526930156812};\\\", \\\"{x:682,y:898,t:1526930156829};\\\", \\\"{x:694,y:902,t:1526930156845};\\\", \\\"{x:695,y:902,t:1526930156863};\\\", \\\"{x:693,y:892,t:1526930156879};\\\", \\\"{x:667,y:869,t:1526930156896};\\\", \\\"{x:647,y:853,t:1526930156912};\\\", \\\"{x:629,y:841,t:1526930156930};\\\", \\\"{x:621,y:836,t:1526930156946};\\\", \\\"{x:619,y:834,t:1526930156963};\\\", \\\"{x:617,y:830,t:1526930156980};\\\", \\\"{x:617,y:826,t:1526930156996};\\\", \\\"{x:616,y:821,t:1526930157013};\\\", \\\"{x:615,y:815,t:1526930157029};\\\", \\\"{x:606,y:804,t:1526930157046};\\\", \\\"{x:593,y:791,t:1526930157064};\\\", \\\"{x:566,y:770,t:1526930157081};\\\", \\\"{x:553,y:761,t:1526930157097};\\\", \\\"{x:544,y:754,t:1526930157114};\\\", \\\"{x:543,y:752,t:1526930157130};\\\", \\\"{x:541,y:751,t:1526930157144};\\\", \\\"{x:540,y:749,t:1526930157168};\\\", \\\"{x:539,y:748,t:1526930157178};\\\", \\\"{x:526,y:741,t:1526930157194};\\\", \\\"{x:512,y:733,t:1526930157211};\\\", \\\"{x:508,y:729,t:1526930157227};\\\", \\\"{x:506,y:729,t:1526930157244};\\\", \\\"{x:508,y:730,t:1526930157577};\\\", \\\"{x:511,y:732,t:1526930157585};\\\", \\\"{x:518,y:735,t:1526930157596};\\\", \\\"{x:533,y:741,t:1526930157612};\\\", \\\"{x:554,y:748,t:1526930157629};\\\", \\\"{x:581,y:758,t:1526930157646};\\\", \\\"{x:610,y:763,t:1526930157662};\\\", \\\"{x:637,y:768,t:1526930157679};\\\", \\\"{x:664,y:768,t:1526930157696};\\\", \\\"{x:677,y:768,t:1526930157712};\\\" ] }, { \\\"rt\\\": 30728, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 512865, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -F -F -B -F -E -E -F -E -E -F -F -X -X -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:678,y:768,t:1526930159586};\\\", \\\"{x:677,y:770,t:1526930159946};\\\", \\\"{x:676,y:770,t:1526930159960};\\\", \\\"{x:676,y:769,t:1526930160065};\\\", \\\"{x:676,y:765,t:1526930160082};\\\", \\\"{x:678,y:757,t:1526930160099};\\\", \\\"{x:688,y:743,t:1526930160115};\\\", \\\"{x:706,y:728,t:1526930160131};\\\", \\\"{x:733,y:711,t:1526930160149};\\\", \\\"{x:816,y:684,t:1526930160165};\\\", \\\"{x:964,y:658,t:1526930160181};\\\", \\\"{x:1135,y:634,t:1526930160199};\\\", \\\"{x:1340,y:604,t:1526930160215};\\\", \\\"{x:1522,y:584,t:1526930160232};\\\", \\\"{x:1786,y:568,t:1526930160249};\\\", \\\"{x:1905,y:568,t:1526930160266};\\\", \\\"{x:1919,y:568,t:1526930160281};\\\", \\\"{x:1918,y:568,t:1526930160433};\\\", \\\"{x:1916,y:568,t:1526930160449};\\\", \\\"{x:1914,y:567,t:1526930160466};\\\", \\\"{x:1910,y:565,t:1526930160483};\\\", \\\"{x:1906,y:564,t:1526930160498};\\\", \\\"{x:1902,y:562,t:1526930160516};\\\", \\\"{x:1901,y:561,t:1526930160532};\\\", \\\"{x:1895,y:561,t:1526930160889};\\\", \\\"{x:1892,y:561,t:1526930160899};\\\", \\\"{x:1874,y:556,t:1526930160915};\\\", \\\"{x:1853,y:551,t:1526930160933};\\\", \\\"{x:1843,y:546,t:1526930160948};\\\", \\\"{x:1837,y:545,t:1526930160966};\\\", \\\"{x:1835,y:545,t:1526930160983};\\\", \\\"{x:1833,y:545,t:1526930160998};\\\", \\\"{x:1832,y:545,t:1526930161152};\\\", \\\"{x:1830,y:545,t:1526930161165};\\\", \\\"{x:1822,y:566,t:1526930161183};\\\", \\\"{x:1804,y:661,t:1526930161199};\\\", \\\"{x:1786,y:778,t:1526930161216};\\\", \\\"{x:1775,y:895,t:1526930161233};\\\", \\\"{x:1774,y:914,t:1526930161249};\\\", \\\"{x:1774,y:919,t:1526930161265};\\\", \\\"{x:1772,y:925,t:1526930161283};\\\", \\\"{x:1768,y:929,t:1526930161300};\\\", \\\"{x:1767,y:932,t:1526930161316};\\\", \\\"{x:1761,y:933,t:1526930161332};\\\", \\\"{x:1756,y:933,t:1526930161350};\\\", \\\"{x:1749,y:929,t:1526930161365};\\\", \\\"{x:1712,y:913,t:1526930161383};\\\", \\\"{x:1681,y:897,t:1526930161400};\\\", \\\"{x:1650,y:881,t:1526930161416};\\\", \\\"{x:1618,y:862,t:1526930161433};\\\", \\\"{x:1605,y:851,t:1526930161449};\\\", \\\"{x:1592,y:842,t:1526930161466};\\\", \\\"{x:1581,y:834,t:1526930161483};\\\", \\\"{x:1566,y:824,t:1526930161500};\\\", \\\"{x:1548,y:816,t:1526930161516};\\\", \\\"{x:1514,y:806,t:1526930161533};\\\", \\\"{x:1466,y:792,t:1526930161550};\\\", \\\"{x:1405,y:773,t:1526930161566};\\\", \\\"{x:1346,y:757,t:1526930161583};\\\", \\\"{x:1294,y:734,t:1526930161600};\\\", \\\"{x:1267,y:723,t:1526930161616};\\\", \\\"{x:1253,y:715,t:1526930161633};\\\", \\\"{x:1251,y:714,t:1526930161650};\\\", \\\"{x:1251,y:713,t:1526930161667};\\\", \\\"{x:1251,y:705,t:1526930161683};\\\", \\\"{x:1251,y:697,t:1526930161700};\\\", \\\"{x:1254,y:688,t:1526930161717};\\\", \\\"{x:1257,y:678,t:1526930161733};\\\", \\\"{x:1261,y:667,t:1526930161749};\\\", \\\"{x:1268,y:650,t:1526930161767};\\\", \\\"{x:1278,y:633,t:1526930161783};\\\", \\\"{x:1298,y:619,t:1526930161800};\\\", \\\"{x:1339,y:607,t:1526930161817};\\\", \\\"{x:1363,y:605,t:1526930161833};\\\", \\\"{x:1373,y:605,t:1526930161850};\\\", \\\"{x:1374,y:605,t:1526930161867};\\\", \\\"{x:1374,y:612,t:1526930161905};\\\", \\\"{x:1370,y:622,t:1526930161917};\\\", \\\"{x:1362,y:644,t:1526930161933};\\\", \\\"{x:1353,y:668,t:1526930161950};\\\", \\\"{x:1346,y:683,t:1526930161968};\\\", \\\"{x:1345,y:686,t:1526930161982};\\\", \\\"{x:1344,y:687,t:1526930162033};\\\", \\\"{x:1338,y:700,t:1526930162051};\\\", \\\"{x:1331,y:711,t:1526930162067};\\\", \\\"{x:1331,y:715,t:1526930162083};\\\", \\\"{x:1331,y:717,t:1526930162105};\\\", \\\"{x:1333,y:717,t:1526930162193};\\\", \\\"{x:1334,y:717,t:1526930162210};\\\", \\\"{x:1337,y:717,t:1526930162218};\\\", \\\"{x:1345,y:713,t:1526930162234};\\\", \\\"{x:1354,y:707,t:1526930162250};\\\", \\\"{x:1360,y:701,t:1526930162267};\\\", \\\"{x:1361,y:696,t:1526930162284};\\\", \\\"{x:1362,y:696,t:1526930162305};\\\", \\\"{x:1361,y:694,t:1526930162514};\\\", \\\"{x:1360,y:692,t:1526930162545};\\\", \\\"{x:1359,y:692,t:1526930162569};\\\", \\\"{x:1358,y:692,t:1526930162584};\\\", \\\"{x:1356,y:692,t:1526930162601};\\\", \\\"{x:1354,y:694,t:1526930162617};\\\", \\\"{x:1353,y:695,t:1526930162637};\\\", \\\"{x:1353,y:696,t:1526930162666};\\\", \\\"{x:1353,y:697,t:1526930162683};\\\", \\\"{x:1353,y:698,t:1526930162701};\\\", \\\"{x:1352,y:699,t:1526930162905};\\\", \\\"{x:1351,y:700,t:1526930162917};\\\", \\\"{x:1350,y:700,t:1526930162934};\\\", \\\"{x:1350,y:701,t:1526930162951};\\\", \\\"{x:1352,y:701,t:1526930165331};\\\", \\\"{x:1355,y:701,t:1526930165337};\\\", \\\"{x:1358,y:701,t:1526930165352};\\\", \\\"{x:1363,y:700,t:1526930165368};\\\", \\\"{x:1364,y:700,t:1526930165385};\\\", \\\"{x:1364,y:698,t:1526930165722};\\\", \\\"{x:1360,y:696,t:1526930165736};\\\", \\\"{x:1353,y:694,t:1526930165753};\\\", \\\"{x:1351,y:693,t:1526930165769};\\\", \\\"{x:1352,y:693,t:1526930165817};\\\", \\\"{x:1352,y:694,t:1526930165825};\\\", \\\"{x:1353,y:694,t:1526930165835};\\\", \\\"{x:1355,y:694,t:1526930165854};\\\", \\\"{x:1355,y:695,t:1526930165994};\\\", \\\"{x:1354,y:695,t:1526930166003};\\\", \\\"{x:1351,y:696,t:1526930166020};\\\", \\\"{x:1350,y:696,t:1526930166035};\\\", \\\"{x:1349,y:697,t:1526930166264};\\\", \\\"{x:1349,y:699,t:1526930166304};\\\", \\\"{x:1349,y:700,t:1526930166319};\\\", \\\"{x:1349,y:702,t:1526930166336};\\\", \\\"{x:1349,y:703,t:1526930166353};\\\", \\\"{x:1349,y:704,t:1526930166369};\\\", \\\"{x:1349,y:705,t:1526930166401};\\\", \\\"{x:1349,y:706,t:1526930166425};\\\", \\\"{x:1349,y:707,t:1526930166441};\\\", \\\"{x:1349,y:709,t:1526930166453};\\\", \\\"{x:1349,y:712,t:1526930166470};\\\", \\\"{x:1349,y:717,t:1526930166487};\\\", \\\"{x:1349,y:723,t:1526930166503};\\\", \\\"{x:1349,y:728,t:1526930166520};\\\", \\\"{x:1349,y:734,t:1526930166537};\\\", \\\"{x:1344,y:739,t:1526930166553};\\\", \\\"{x:1342,y:739,t:1526930166570};\\\", \\\"{x:1341,y:739,t:1526930166600};\\\", \\\"{x:1341,y:740,t:1526930166889};\\\", \\\"{x:1339,y:738,t:1526930166937};\\\", \\\"{x:1336,y:735,t:1526930166954};\\\", \\\"{x:1334,y:733,t:1526930166970};\\\", \\\"{x:1334,y:732,t:1526930166993};\\\", \\\"{x:1334,y:731,t:1526930167004};\\\", \\\"{x:1334,y:730,t:1526930167020};\\\", \\\"{x:1334,y:727,t:1526930167037};\\\", \\\"{x:1334,y:724,t:1526930167055};\\\", \\\"{x:1334,y:722,t:1526930167070};\\\", \\\"{x:1334,y:719,t:1526930167087};\\\", \\\"{x:1335,y:715,t:1526930167104};\\\", \\\"{x:1335,y:712,t:1526930167121};\\\", \\\"{x:1335,y:710,t:1526930167137};\\\", \\\"{x:1337,y:708,t:1526930167155};\\\", \\\"{x:1338,y:707,t:1526930167185};\\\", \\\"{x:1339,y:706,t:1526930167201};\\\", \\\"{x:1340,y:706,t:1526930167209};\\\", \\\"{x:1341,y:705,t:1526930167225};\\\", \\\"{x:1343,y:705,t:1526930167257};\\\", \\\"{x:1344,y:705,t:1526930167378};\\\", \\\"{x:1346,y:705,t:1526930167386};\\\", \\\"{x:1349,y:705,t:1526930167404};\\\", \\\"{x:1350,y:720,t:1526930167421};\\\", \\\"{x:1351,y:740,t:1526930167437};\\\", \\\"{x:1355,y:754,t:1526930167454};\\\", \\\"{x:1356,y:758,t:1526930167470};\\\", \\\"{x:1356,y:760,t:1526930167486};\\\", \\\"{x:1356,y:762,t:1526930167504};\\\", \\\"{x:1356,y:763,t:1526930167521};\\\", \\\"{x:1356,y:764,t:1526930167537};\\\", \\\"{x:1356,y:766,t:1526930167554};\\\", \\\"{x:1354,y:768,t:1526930167571};\\\", \\\"{x:1350,y:771,t:1526930167587};\\\", \\\"{x:1349,y:771,t:1526930167604};\\\", \\\"{x:1348,y:771,t:1526930167621};\\\", \\\"{x:1348,y:770,t:1526930167721};\\\", \\\"{x:1348,y:767,t:1526930167738};\\\", \\\"{x:1348,y:764,t:1526930167754};\\\", \\\"{x:1347,y:762,t:1526930167771};\\\", \\\"{x:1346,y:761,t:1526930167787};\\\", \\\"{x:1344,y:759,t:1526930167804};\\\", \\\"{x:1343,y:758,t:1526930168107};\\\", \\\"{x:1343,y:741,t:1526930168121};\\\", \\\"{x:1344,y:714,t:1526930168138};\\\", \\\"{x:1349,y:685,t:1526930168154};\\\", \\\"{x:1351,y:670,t:1526930168171};\\\", \\\"{x:1353,y:663,t:1526930168189};\\\", \\\"{x:1355,y:660,t:1526930168204};\\\", \\\"{x:1355,y:661,t:1526930168369};\\\", \\\"{x:1354,y:664,t:1526930168378};\\\", \\\"{x:1353,y:668,t:1526930168388};\\\", \\\"{x:1353,y:670,t:1526930168405};\\\", \\\"{x:1352,y:672,t:1526930168421};\\\", \\\"{x:1352,y:673,t:1526930168456};\\\", \\\"{x:1351,y:673,t:1526930168657};\\\", \\\"{x:1350,y:673,t:1526930168671};\\\", \\\"{x:1348,y:673,t:1526930168688};\\\", \\\"{x:1344,y:672,t:1526930168705};\\\", \\\"{x:1343,y:671,t:1526930168722};\\\", \\\"{x:1342,y:670,t:1526930168738};\\\", \\\"{x:1338,y:668,t:1526930168756};\\\", \\\"{x:1330,y:663,t:1526930168772};\\\", \\\"{x:1311,y:639,t:1526930168788};\\\", \\\"{x:1287,y:620,t:1526930168805};\\\", \\\"{x:1266,y:600,t:1526930168822};\\\", \\\"{x:1252,y:588,t:1526930168838};\\\", \\\"{x:1241,y:577,t:1526930168854};\\\", \\\"{x:1239,y:572,t:1526930168872};\\\", \\\"{x:1239,y:571,t:1526930168888};\\\", \\\"{x:1240,y:568,t:1526930168905};\\\", \\\"{x:1241,y:567,t:1526930168922};\\\", \\\"{x:1242,y:564,t:1526930168938};\\\", \\\"{x:1244,y:563,t:1526930168955};\\\", \\\"{x:1247,y:560,t:1526930168972};\\\", \\\"{x:1250,y:558,t:1526930168988};\\\", \\\"{x:1253,y:556,t:1526930169006};\\\", \\\"{x:1257,y:554,t:1526930169023};\\\", \\\"{x:1259,y:554,t:1526930169039};\\\", \\\"{x:1261,y:554,t:1526930169055};\\\", \\\"{x:1262,y:554,t:1526930169072};\\\", \\\"{x:1263,y:554,t:1526930169089};\\\", \\\"{x:1265,y:554,t:1526930169105};\\\", \\\"{x:1266,y:554,t:1526930169123};\\\", \\\"{x:1268,y:554,t:1526930169138};\\\", \\\"{x:1271,y:554,t:1526930169155};\\\", \\\"{x:1273,y:555,t:1526930169172};\\\", \\\"{x:1274,y:555,t:1526930169377};\\\", \\\"{x:1275,y:556,t:1526930169389};\\\", \\\"{x:1277,y:557,t:1526930169406};\\\", \\\"{x:1280,y:558,t:1526930169423};\\\", \\\"{x:1280,y:559,t:1526930169439};\\\", \\\"{x:1281,y:559,t:1526930170274};\\\", \\\"{x:1281,y:560,t:1526930170537};\\\", \\\"{x:1282,y:560,t:1526930170665};\\\", \\\"{x:1283,y:560,t:1526930170689};\\\", \\\"{x:1285,y:567,t:1526930170713};\\\", \\\"{x:1287,y:574,t:1526930170724};\\\", \\\"{x:1289,y:584,t:1526930170740};\\\", \\\"{x:1294,y:604,t:1526930170757};\\\", \\\"{x:1300,y:626,t:1526930170773};\\\", \\\"{x:1311,y:652,t:1526930170790};\\\", \\\"{x:1321,y:674,t:1526930170806};\\\", \\\"{x:1332,y:699,t:1526930170822};\\\", \\\"{x:1345,y:721,t:1526930170840};\\\", \\\"{x:1349,y:725,t:1526930170856};\\\", \\\"{x:1354,y:729,t:1526930170873};\\\", \\\"{x:1355,y:729,t:1526930170953};\\\", \\\"{x:1356,y:729,t:1526930170960};\\\", \\\"{x:1357,y:729,t:1526930170973};\\\", \\\"{x:1359,y:727,t:1526930170993};\\\", \\\"{x:1359,y:725,t:1526930171113};\\\", \\\"{x:1359,y:724,t:1526930171129};\\\", \\\"{x:1359,y:723,t:1526930171140};\\\", \\\"{x:1359,y:722,t:1526930171157};\\\", \\\"{x:1359,y:721,t:1526930171172};\\\", \\\"{x:1357,y:717,t:1526930171190};\\\", \\\"{x:1353,y:714,t:1526930171208};\\\", \\\"{x:1349,y:710,t:1526930171223};\\\", \\\"{x:1348,y:709,t:1526930171241};\\\", \\\"{x:1347,y:708,t:1526930171257};\\\", \\\"{x:1347,y:705,t:1526930171361};\\\", \\\"{x:1347,y:704,t:1526930171434};\\\", \\\"{x:1347,y:703,t:1526930171441};\\\", \\\"{x:1347,y:701,t:1526930171458};\\\", \\\"{x:1348,y:700,t:1526930171473};\\\", \\\"{x:1348,y:699,t:1526930171490};\\\", \\\"{x:1349,y:699,t:1526930171507};\\\", \\\"{x:1349,y:698,t:1526930171529};\\\", \\\"{x:1346,y:698,t:1526930172301};\\\", \\\"{x:1335,y:693,t:1526930172312};\\\", \\\"{x:1309,y:681,t:1526930172328};\\\", \\\"{x:1282,y:669,t:1526930172345};\\\", \\\"{x:1270,y:663,t:1526930172362};\\\", \\\"{x:1267,y:661,t:1526930172378};\\\", \\\"{x:1265,y:659,t:1526930172395};\\\", \\\"{x:1264,y:652,t:1526930172411};\\\", \\\"{x:1264,y:645,t:1526930172428};\\\", \\\"{x:1264,y:634,t:1526930172444};\\\", \\\"{x:1264,y:628,t:1526930172461};\\\", \\\"{x:1268,y:621,t:1526930172478};\\\", \\\"{x:1273,y:612,t:1526930172495};\\\", \\\"{x:1281,y:604,t:1526930172511};\\\", \\\"{x:1285,y:597,t:1526930172528};\\\", \\\"{x:1288,y:587,t:1526930172545};\\\", \\\"{x:1288,y:575,t:1526930172561};\\\", \\\"{x:1288,y:566,t:1526930172578};\\\", \\\"{x:1288,y:557,t:1526930172596};\\\", \\\"{x:1288,y:549,t:1526930172612};\\\", \\\"{x:1288,y:548,t:1526930172629};\\\", \\\"{x:1287,y:547,t:1526930172645};\\\", \\\"{x:1287,y:546,t:1526930172662};\\\", \\\"{x:1286,y:545,t:1526930172679};\\\", \\\"{x:1284,y:544,t:1526930172696};\\\", \\\"{x:1283,y:544,t:1526930172717};\\\", \\\"{x:1282,y:544,t:1526930172733};\\\", \\\"{x:1280,y:543,t:1526930172746};\\\", \\\"{x:1279,y:543,t:1526930172762};\\\", \\\"{x:1276,y:543,t:1526930172778};\\\", \\\"{x:1275,y:542,t:1526930172795};\\\", \\\"{x:1273,y:542,t:1526930172812};\\\", \\\"{x:1271,y:546,t:1526930172829};\\\", \\\"{x:1271,y:551,t:1526930172845};\\\", \\\"{x:1271,y:555,t:1526930172862};\\\", \\\"{x:1271,y:557,t:1526930172878};\\\", \\\"{x:1271,y:559,t:1526930172895};\\\", \\\"{x:1273,y:561,t:1526930172949};\\\", \\\"{x:1274,y:562,t:1526930172989};\\\", \\\"{x:1276,y:562,t:1526930173045};\\\", \\\"{x:1277,y:564,t:1526930173079};\\\", \\\"{x:1278,y:564,t:1526930173101};\\\", \\\"{x:1279,y:566,t:1526930173116};\\\", \\\"{x:1279,y:570,t:1526930173130};\\\", \\\"{x:1279,y:581,t:1526930173145};\\\", \\\"{x:1279,y:596,t:1526930173162};\\\", \\\"{x:1279,y:613,t:1526930173179};\\\", \\\"{x:1279,y:628,t:1526930173195};\\\", \\\"{x:1282,y:640,t:1526930173211};\\\", \\\"{x:1284,y:649,t:1526930173228};\\\", \\\"{x:1288,y:658,t:1526930173245};\\\", \\\"{x:1292,y:666,t:1526930173261};\\\", \\\"{x:1297,y:674,t:1526930173279};\\\", \\\"{x:1303,y:688,t:1526930173294};\\\", \\\"{x:1314,y:701,t:1526930173312};\\\", \\\"{x:1318,y:709,t:1526930173329};\\\", \\\"{x:1321,y:712,t:1526930173345};\\\", \\\"{x:1323,y:712,t:1526930173364};\\\", \\\"{x:1324,y:712,t:1526930173413};\\\", \\\"{x:1327,y:713,t:1526930173428};\\\", \\\"{x:1328,y:714,t:1526930173445};\\\", \\\"{x:1329,y:714,t:1526930173461};\\\", \\\"{x:1330,y:714,t:1526930173484};\\\", \\\"{x:1331,y:714,t:1526930173516};\\\", \\\"{x:1333,y:714,t:1526930173529};\\\", \\\"{x:1334,y:713,t:1526930173546};\\\", \\\"{x:1336,y:710,t:1526930173562};\\\", \\\"{x:1337,y:708,t:1526930173579};\\\", \\\"{x:1337,y:706,t:1526930173596};\\\", \\\"{x:1338,y:703,t:1526930173613};\\\", \\\"{x:1338,y:702,t:1526930173741};\\\", \\\"{x:1336,y:701,t:1526930173748};\\\", \\\"{x:1333,y:700,t:1526930173762};\\\", \\\"{x:1328,y:699,t:1526930173780};\\\", \\\"{x:1315,y:697,t:1526930173797};\\\", \\\"{x:1301,y:703,t:1526930173812};\\\", \\\"{x:1285,y:710,t:1526930173829};\\\", \\\"{x:1271,y:717,t:1526930173846};\\\", \\\"{x:1260,y:722,t:1526930173862};\\\", \\\"{x:1257,y:723,t:1526930173879};\\\", \\\"{x:1251,y:726,t:1526930173896};\\\", \\\"{x:1245,y:729,t:1526930173913};\\\", \\\"{x:1243,y:731,t:1526930173929};\\\", \\\"{x:1241,y:733,t:1526930173946};\\\", \\\"{x:1238,y:735,t:1526930173962};\\\", \\\"{x:1236,y:738,t:1526930173980};\\\", \\\"{x:1233,y:743,t:1526930173996};\\\", \\\"{x:1229,y:749,t:1526930174013};\\\", \\\"{x:1225,y:755,t:1526930174029};\\\", \\\"{x:1223,y:760,t:1526930174046};\\\", \\\"{x:1221,y:764,t:1526930174063};\\\", \\\"{x:1218,y:768,t:1526930174079};\\\", \\\"{x:1217,y:773,t:1526930174096};\\\", \\\"{x:1216,y:779,t:1526930174113};\\\", \\\"{x:1214,y:787,t:1526930174129};\\\", \\\"{x:1214,y:791,t:1526930174146};\\\", \\\"{x:1214,y:793,t:1526930174164};\\\", \\\"{x:1214,y:795,t:1526930174179};\\\", \\\"{x:1214,y:797,t:1526930174205};\\\", \\\"{x:1214,y:795,t:1526930174357};\\\", \\\"{x:1223,y:783,t:1526930174364};\\\", \\\"{x:1232,y:769,t:1526930174379};\\\", \\\"{x:1266,y:730,t:1526930174397};\\\", \\\"{x:1286,y:714,t:1526930174413};\\\", \\\"{x:1303,y:702,t:1526930174429};\\\", \\\"{x:1315,y:693,t:1526930174447};\\\", \\\"{x:1323,y:686,t:1526930174463};\\\", \\\"{x:1325,y:684,t:1526930174479};\\\", \\\"{x:1327,y:684,t:1526930174496};\\\", \\\"{x:1329,y:682,t:1526930174513};\\\", \\\"{x:1330,y:681,t:1526930174530};\\\", \\\"{x:1332,y:680,t:1526930174546};\\\", \\\"{x:1333,y:679,t:1526930174564};\\\", \\\"{x:1334,y:679,t:1526930174581};\\\", \\\"{x:1335,y:679,t:1526930174636};\\\", \\\"{x:1336,y:679,t:1526930174660};\\\", \\\"{x:1337,y:679,t:1526930174668};\\\", \\\"{x:1339,y:679,t:1526930174875};\\\", \\\"{x:1340,y:679,t:1526930174891};\\\", \\\"{x:1341,y:680,t:1526930174899};\\\", \\\"{x:1343,y:681,t:1526930174912};\\\", \\\"{x:1345,y:682,t:1526930174930};\\\", \\\"{x:1346,y:683,t:1526930175003};\\\", \\\"{x:1346,y:685,t:1526930175020};\\\", \\\"{x:1346,y:687,t:1526930175030};\\\", \\\"{x:1346,y:688,t:1526930175046};\\\", \\\"{x:1346,y:689,t:1526930175063};\\\", \\\"{x:1346,y:690,t:1526930175565};\\\", \\\"{x:1347,y:690,t:1526930175580};\\\", \\\"{x:1348,y:691,t:1526930175597};\\\", \\\"{x:1349,y:692,t:1526930175621};\\\", \\\"{x:1351,y:694,t:1526930175805};\\\", \\\"{x:1355,y:707,t:1526930175816};\\\", \\\"{x:1362,y:738,t:1526930175830};\\\", \\\"{x:1371,y:771,t:1526930175847};\\\", \\\"{x:1383,y:803,t:1526930175864};\\\", \\\"{x:1388,y:822,t:1526930175880};\\\", \\\"{x:1390,y:836,t:1526930175897};\\\", \\\"{x:1393,y:845,t:1526930175914};\\\", \\\"{x:1394,y:850,t:1526930175931};\\\", \\\"{x:1395,y:856,t:1526930175948};\\\", \\\"{x:1397,y:866,t:1526930175965};\\\", \\\"{x:1397,y:873,t:1526930175980};\\\", \\\"{x:1398,y:878,t:1526930175996};\\\", \\\"{x:1398,y:879,t:1526930176013};\\\", \\\"{x:1398,y:880,t:1526930176031};\\\", \\\"{x:1398,y:883,t:1526930176046};\\\", \\\"{x:1398,y:892,t:1526930176063};\\\", \\\"{x:1395,y:905,t:1526930176080};\\\", \\\"{x:1390,y:916,t:1526930176097};\\\", \\\"{x:1388,y:918,t:1526930176114};\\\", \\\"{x:1387,y:920,t:1526930176130};\\\", \\\"{x:1388,y:917,t:1526930176181};\\\", \\\"{x:1392,y:906,t:1526930176197};\\\", \\\"{x:1393,y:892,t:1526930176214};\\\", \\\"{x:1393,y:883,t:1526930176231};\\\", \\\"{x:1393,y:882,t:1526930176247};\\\", \\\"{x:1393,y:879,t:1526930176717};\\\", \\\"{x:1393,y:866,t:1526930176731};\\\", \\\"{x:1393,y:817,t:1526930176749};\\\", \\\"{x:1393,y:785,t:1526930176764};\\\", \\\"{x:1390,y:761,t:1526930176781};\\\", \\\"{x:1382,y:740,t:1526930176797};\\\", \\\"{x:1378,y:723,t:1526930176814};\\\", \\\"{x:1376,y:718,t:1526930176830};\\\", \\\"{x:1375,y:714,t:1526930176848};\\\", \\\"{x:1375,y:713,t:1526930176865};\\\", \\\"{x:1375,y:712,t:1526930176884};\\\", \\\"{x:1374,y:712,t:1526930176940};\\\", \\\"{x:1372,y:710,t:1526930176948};\\\", \\\"{x:1365,y:703,t:1526930176965};\\\", \\\"{x:1362,y:701,t:1526930176981};\\\", \\\"{x:1361,y:701,t:1526930176998};\\\", \\\"{x:1360,y:700,t:1526930177036};\\\", \\\"{x:1359,y:700,t:1526930177048};\\\", \\\"{x:1360,y:700,t:1526930177157};\\\", \\\"{x:1363,y:701,t:1526930177164};\\\", \\\"{x:1367,y:704,t:1526930177182};\\\", \\\"{x:1371,y:717,t:1526930177199};\\\", \\\"{x:1374,y:740,t:1526930177216};\\\", \\\"{x:1378,y:766,t:1526930177231};\\\", \\\"{x:1381,y:788,t:1526930177248};\\\", \\\"{x:1382,y:812,t:1526930177266};\\\", \\\"{x:1382,y:827,t:1526930177281};\\\", \\\"{x:1382,y:836,t:1526930177298};\\\", \\\"{x:1382,y:848,t:1526930177316};\\\", \\\"{x:1382,y:854,t:1526930177332};\\\", \\\"{x:1382,y:859,t:1526930177348};\\\", \\\"{x:1384,y:865,t:1526930177366};\\\", \\\"{x:1386,y:868,t:1526930177382};\\\", \\\"{x:1386,y:870,t:1526930177398};\\\", \\\"{x:1388,y:877,t:1526930177415};\\\", \\\"{x:1389,y:883,t:1526930177433};\\\", \\\"{x:1390,y:886,t:1526930177448};\\\", \\\"{x:1390,y:887,t:1526930177476};\\\", \\\"{x:1390,y:888,t:1526930177485};\\\", \\\"{x:1390,y:890,t:1526930177499};\\\", \\\"{x:1391,y:891,t:1526930177516};\\\", \\\"{x:1397,y:891,t:1526930177573};\\\", \\\"{x:1403,y:886,t:1526930177582};\\\", \\\"{x:1419,y:875,t:1526930177598};\\\", \\\"{x:1441,y:864,t:1526930177615};\\\", \\\"{x:1458,y:858,t:1526930177632};\\\", \\\"{x:1474,y:852,t:1526930177648};\\\", \\\"{x:1490,y:845,t:1526930177665};\\\", \\\"{x:1502,y:840,t:1526930177682};\\\", \\\"{x:1512,y:838,t:1526930177698};\\\", \\\"{x:1516,y:836,t:1526930177715};\\\", \\\"{x:1519,y:834,t:1526930177731};\\\", \\\"{x:1519,y:832,t:1526930177821};\\\", \\\"{x:1518,y:830,t:1526930177832};\\\", \\\"{x:1512,y:827,t:1526930177849};\\\", \\\"{x:1506,y:824,t:1526930177865};\\\", \\\"{x:1500,y:819,t:1526930177883};\\\", \\\"{x:1496,y:818,t:1526930177899};\\\", \\\"{x:1491,y:818,t:1526930177916};\\\", \\\"{x:1487,y:818,t:1526930177933};\\\", \\\"{x:1486,y:818,t:1526930177949};\\\", \\\"{x:1485,y:818,t:1526930177972};\\\", \\\"{x:1484,y:819,t:1526930177996};\\\", \\\"{x:1483,y:819,t:1526930178020};\\\", \\\"{x:1483,y:820,t:1526930178053};\\\", \\\"{x:1482,y:821,t:1526930178065};\\\", \\\"{x:1477,y:823,t:1526930178082};\\\", \\\"{x:1473,y:824,t:1526930178100};\\\", \\\"{x:1472,y:824,t:1526930178115};\\\", \\\"{x:1471,y:825,t:1526930178133};\\\", \\\"{x:1471,y:826,t:1526930178189};\\\", \\\"{x:1472,y:827,t:1526930178205};\\\", \\\"{x:1473,y:827,t:1526930178260};\\\", \\\"{x:1474,y:827,t:1526930178268};\\\", \\\"{x:1475,y:827,t:1526930178292};\\\", \\\"{x:1476,y:829,t:1526930178299};\\\", \\\"{x:1477,y:829,t:1526930178316};\\\", \\\"{x:1478,y:829,t:1526930178531};\\\", \\\"{x:1478,y:830,t:1526930178756};\\\", \\\"{x:1476,y:830,t:1526930179413};\\\", \\\"{x:1452,y:824,t:1526930179422};\\\", \\\"{x:1406,y:806,t:1526930179434};\\\", \\\"{x:1213,y:748,t:1526930179450};\\\", \\\"{x:976,y:680,t:1526930179466};\\\", \\\"{x:739,y:616,t:1526930179484};\\\", \\\"{x:493,y:571,t:1526930179500};\\\", \\\"{x:452,y:559,t:1526930179516};\\\", \\\"{x:456,y:558,t:1526930179550};\\\", \\\"{x:457,y:558,t:1526930179567};\\\", \\\"{x:455,y:558,t:1526930179619};\\\", \\\"{x:450,y:558,t:1526930179634};\\\", \\\"{x:439,y:555,t:1526930179651};\\\", \\\"{x:427,y:551,t:1526930179667};\\\", \\\"{x:429,y:552,t:1526930179700};\\\", \\\"{x:436,y:553,t:1526930179707};\\\", \\\"{x:444,y:557,t:1526930179717};\\\", \\\"{x:460,y:563,t:1526930179735};\\\", \\\"{x:478,y:567,t:1526930179751};\\\", \\\"{x:514,y:573,t:1526930179769};\\\", \\\"{x:563,y:582,t:1526930179784};\\\", \\\"{x:602,y:587,t:1526930179801};\\\", \\\"{x:630,y:592,t:1526930179818};\\\", \\\"{x:644,y:593,t:1526930179834};\\\", \\\"{x:646,y:594,t:1526930179851};\\\", \\\"{x:641,y:594,t:1526930179867};\\\", \\\"{x:635,y:592,t:1526930179884};\\\", \\\"{x:628,y:589,t:1526930179901};\\\", \\\"{x:627,y:588,t:1526930179995};\\\", \\\"{x:624,y:587,t:1526930180004};\\\", \\\"{x:619,y:584,t:1526930180018};\\\", \\\"{x:611,y:582,t:1526930180034};\\\", \\\"{x:610,y:581,t:1526930180051};\\\", \\\"{x:609,y:581,t:1526930180100};\\\", \\\"{x:613,y:581,t:1526930180484};\\\", \\\"{x:655,y:599,t:1526930180503};\\\", \\\"{x:728,y:632,t:1526930180518};\\\", \\\"{x:817,y:663,t:1526930180535};\\\", \\\"{x:930,y:691,t:1526930180550};\\\", \\\"{x:1053,y:714,t:1526930180568};\\\", \\\"{x:1191,y:734,t:1526930180585};\\\", \\\"{x:1322,y:752,t:1526930180601};\\\", \\\"{x:1450,y:773,t:1526930180618};\\\", \\\"{x:1560,y:787,t:1526930180635};\\\", \\\"{x:1650,y:803,t:1526930180651};\\\", \\\"{x:1694,y:815,t:1526930180667};\\\", \\\"{x:1705,y:820,t:1526930180685};\\\", \\\"{x:1708,y:821,t:1526930180701};\\\", \\\"{x:1708,y:822,t:1526930180718};\\\", \\\"{x:1707,y:822,t:1526930180788};\\\", \\\"{x:1704,y:822,t:1526930180802};\\\", \\\"{x:1691,y:818,t:1526930180818};\\\", \\\"{x:1668,y:814,t:1526930180836};\\\", \\\"{x:1615,y:812,t:1526930180853};\\\", \\\"{x:1565,y:812,t:1526930180869};\\\", \\\"{x:1533,y:809,t:1526930180886};\\\", \\\"{x:1520,y:809,t:1526930180903};\\\", \\\"{x:1517,y:809,t:1526930180919};\\\", \\\"{x:1516,y:808,t:1526930180957};\\\", \\\"{x:1515,y:808,t:1526930180973};\\\", \\\"{x:1514,y:808,t:1526930180986};\\\", \\\"{x:1512,y:807,t:1526930181002};\\\", \\\"{x:1509,y:806,t:1526930181019};\\\", \\\"{x:1507,y:805,t:1526930181035};\\\", \\\"{x:1507,y:804,t:1526930181117};\\\", \\\"{x:1508,y:803,t:1526930181124};\\\", \\\"{x:1510,y:802,t:1526930181136};\\\", \\\"{x:1513,y:799,t:1526930181152};\\\", \\\"{x:1516,y:795,t:1526930181168};\\\", \\\"{x:1518,y:794,t:1526930181185};\\\", \\\"{x:1520,y:792,t:1526930181203};\\\", \\\"{x:1520,y:791,t:1526930181365};\\\", \\\"{x:1520,y:790,t:1526930181379};\\\", \\\"{x:1519,y:790,t:1526930181395};\\\", \\\"{x:1518,y:796,t:1526930181404};\\\", \\\"{x:1517,y:796,t:1526930181418};\\\", \\\"{x:1517,y:791,t:1526930181524};\\\", \\\"{x:1517,y:787,t:1526930181535};\\\", \\\"{x:1514,y:774,t:1526930181552};\\\", \\\"{x:1514,y:765,t:1526930181569};\\\", \\\"{x:1513,y:761,t:1526930181585};\\\", \\\"{x:1513,y:760,t:1526930181602};\\\", \\\"{x:1513,y:759,t:1526930181885};\\\", \\\"{x:1514,y:759,t:1526930182116};\\\", \\\"{x:1515,y:761,t:1526930182140};\\\", \\\"{x:1516,y:761,t:1526930182284};\\\", \\\"{x:1516,y:765,t:1526930182349};\\\", \\\"{x:1516,y:778,t:1526930182358};\\\", \\\"{x:1516,y:795,t:1526930182369};\\\", \\\"{x:1516,y:825,t:1526930182386};\\\", \\\"{x:1516,y:844,t:1526930182401};\\\", \\\"{x:1516,y:854,t:1526930182419};\\\", \\\"{x:1516,y:861,t:1526930182435};\\\", \\\"{x:1515,y:863,t:1526930182452};\\\", \\\"{x:1515,y:867,t:1526930182469};\\\", \\\"{x:1515,y:872,t:1526930182486};\\\", \\\"{x:1515,y:878,t:1526930182501};\\\", \\\"{x:1515,y:882,t:1526930182519};\\\", \\\"{x:1515,y:884,t:1526930182536};\\\", \\\"{x:1515,y:885,t:1526930182620};\\\", \\\"{x:1515,y:888,t:1526930182636};\\\", \\\"{x:1515,y:890,t:1526930182653};\\\", \\\"{x:1515,y:892,t:1526930182669};\\\", \\\"{x:1515,y:894,t:1526930182686};\\\", \\\"{x:1515,y:895,t:1526930182702};\\\", \\\"{x:1515,y:898,t:1526930182719};\\\", \\\"{x:1515,y:900,t:1526930182736};\\\", \\\"{x:1516,y:904,t:1526930182753};\\\", \\\"{x:1517,y:907,t:1526930182769};\\\", \\\"{x:1518,y:909,t:1526930182787};\\\", \\\"{x:1519,y:910,t:1526930182803};\\\", \\\"{x:1520,y:912,t:1526930182820};\\\", \\\"{x:1520,y:910,t:1526930182981};\\\", \\\"{x:1520,y:907,t:1526930182989};\\\", \\\"{x:1520,y:904,t:1526930183004};\\\", \\\"{x:1518,y:895,t:1526930183020};\\\", \\\"{x:1514,y:874,t:1526930183037};\\\", \\\"{x:1513,y:861,t:1526930183053};\\\", \\\"{x:1512,y:847,t:1526930183070};\\\", \\\"{x:1509,y:836,t:1526930183087};\\\", \\\"{x:1509,y:826,t:1526930183103};\\\", \\\"{x:1509,y:818,t:1526930183119};\\\", \\\"{x:1509,y:813,t:1526930183136};\\\", \\\"{x:1509,y:807,t:1526930183153};\\\", \\\"{x:1510,y:804,t:1526930183169};\\\", \\\"{x:1510,y:801,t:1526930183186};\\\", \\\"{x:1510,y:798,t:1526930183203};\\\", \\\"{x:1510,y:797,t:1526930183220};\\\", \\\"{x:1511,y:793,t:1526930183237};\\\", \\\"{x:1511,y:791,t:1526930183253};\\\", \\\"{x:1512,y:790,t:1526930183270};\\\", \\\"{x:1513,y:787,t:1526930183287};\\\", \\\"{x:1513,y:786,t:1526930183317};\\\", \\\"{x:1513,y:785,t:1526930183324};\\\", \\\"{x:1513,y:784,t:1526930183356};\\\", \\\"{x:1513,y:783,t:1526930183381};\\\", \\\"{x:1514,y:781,t:1526930183389};\\\", \\\"{x:1514,y:780,t:1526930183780};\\\", \\\"{x:1514,y:778,t:1526930183788};\\\", \\\"{x:1514,y:777,t:1526930183804};\\\", \\\"{x:1514,y:775,t:1526930183821};\\\", \\\"{x:1514,y:774,t:1526930184485};\\\", \\\"{x:1515,y:774,t:1526930184493};\\\", \\\"{x:1516,y:774,t:1526930184508};\\\", \\\"{x:1517,y:774,t:1526930184524};\\\", \\\"{x:1517,y:773,t:1526930184538};\\\", \\\"{x:1519,y:772,t:1526930184554};\\\", \\\"{x:1520,y:771,t:1526930184571};\\\", \\\"{x:1521,y:771,t:1526930184589};\\\", \\\"{x:1522,y:771,t:1526930184604};\\\", \\\"{x:1523,y:771,t:1526930184829};\\\", \\\"{x:1524,y:771,t:1526930184838};\\\", \\\"{x:1525,y:771,t:1526930184855};\\\", \\\"{x:1526,y:771,t:1526930184871};\\\", \\\"{x:1528,y:771,t:1526930184887};\\\", \\\"{x:1527,y:771,t:1526930185093};\\\", \\\"{x:1525,y:770,t:1526930185104};\\\", \\\"{x:1522,y:770,t:1526930185121};\\\", \\\"{x:1520,y:770,t:1526930185189};\\\", \\\"{x:1518,y:778,t:1526930185205};\\\", \\\"{x:1515,y:788,t:1526930185221};\\\", \\\"{x:1511,y:801,t:1526930185238};\\\", \\\"{x:1507,y:817,t:1526930185254};\\\", \\\"{x:1502,y:831,t:1526930185271};\\\", \\\"{x:1498,y:842,t:1526930185288};\\\", \\\"{x:1493,y:851,t:1526930185304};\\\", \\\"{x:1491,y:855,t:1526930185322};\\\", \\\"{x:1487,y:860,t:1526930185338};\\\", \\\"{x:1485,y:862,t:1526930185355};\\\", \\\"{x:1484,y:863,t:1526930185372};\\\", \\\"{x:1482,y:863,t:1526930185387};\\\", \\\"{x:1478,y:863,t:1526930185404};\\\", \\\"{x:1471,y:861,t:1526930185422};\\\", \\\"{x:1464,y:857,t:1526930185438};\\\", \\\"{x:1460,y:853,t:1526930185455};\\\", \\\"{x:1459,y:849,t:1526930185472};\\\", \\\"{x:1459,y:846,t:1526930185488};\\\", \\\"{x:1459,y:844,t:1526930185504};\\\", \\\"{x:1459,y:842,t:1526930185521};\\\", \\\"{x:1463,y:840,t:1526930185538};\\\", \\\"{x:1470,y:837,t:1526930185554};\\\", \\\"{x:1473,y:835,t:1526930185572};\\\", \\\"{x:1475,y:834,t:1526930185588};\\\", \\\"{x:1476,y:834,t:1526930185605};\\\", \\\"{x:1477,y:834,t:1526930185661};\\\", \\\"{x:1477,y:833,t:1526930187629};\\\", \\\"{x:1477,y:832,t:1526930187639};\\\", \\\"{x:1458,y:840,t:1526930187657};\\\", \\\"{x:1441,y:852,t:1526930187673};\\\", \\\"{x:1421,y:863,t:1526930187689};\\\", \\\"{x:1406,y:868,t:1526930187706};\\\", \\\"{x:1394,y:873,t:1526930187723};\\\", \\\"{x:1382,y:877,t:1526930187739};\\\", \\\"{x:1366,y:877,t:1526930187756};\\\", \\\"{x:1354,y:876,t:1526930187772};\\\", \\\"{x:1336,y:867,t:1526930187788};\\\", \\\"{x:1308,y:847,t:1526930187805};\\\", \\\"{x:1246,y:802,t:1526930187822};\\\", \\\"{x:1158,y:746,t:1526930187839};\\\", \\\"{x:1049,y:687,t:1526930187855};\\\", \\\"{x:920,y:633,t:1526930187872};\\\", \\\"{x:803,y:598,t:1526930187889};\\\", \\\"{x:693,y:567,t:1526930187905};\\\", \\\"{x:605,y:544,t:1526930187923};\\\", \\\"{x:539,y:541,t:1526930187939};\\\", \\\"{x:489,y:540,t:1526930187956};\\\", \\\"{x:489,y:539,t:1526930187974};\\\", \\\"{x:490,y:539,t:1526930188261};\\\", \\\"{x:490,y:540,t:1526930188275};\\\", \\\"{x:490,y:542,t:1526930188291};\\\", \\\"{x:492,y:542,t:1526930188341};\\\", \\\"{x:491,y:542,t:1526930188357};\\\", \\\"{x:492,y:548,t:1526930188732};\\\", \\\"{x:492,y:559,t:1526930188743};\\\", \\\"{x:496,y:592,t:1526930188758};\\\", \\\"{x:499,y:627,t:1526930188775};\\\", \\\"{x:500,y:670,t:1526930188792};\\\", \\\"{x:500,y:709,t:1526930188808};\\\", \\\"{x:507,y:752,t:1526930188825};\\\", \\\"{x:509,y:784,t:1526930188842};\\\", \\\"{x:513,y:800,t:1526930188858};\\\", \\\"{x:513,y:804,t:1526930188874};\\\", \\\"{x:514,y:805,t:1526930188933};\\\", \\\"{x:515,y:803,t:1526930188941};\\\", \\\"{x:515,y:799,t:1526930188958};\\\", \\\"{x:515,y:793,t:1526930188976};\\\", \\\"{x:515,y:785,t:1526930188991};\\\", \\\"{x:516,y:774,t:1526930189008};\\\", \\\"{x:516,y:765,t:1526930189025};\\\", \\\"{x:516,y:756,t:1526930189041};\\\", \\\"{x:516,y:752,t:1526930189059};\\\", \\\"{x:515,y:746,t:1526930189076};\\\", \\\"{x:515,y:743,t:1526930189091};\\\", \\\"{x:515,y:742,t:1526930189108};\\\", \\\"{x:515,y:740,t:1526930189124};\\\", \\\"{x:515,y:739,t:1526930189148};\\\", \\\"{x:515,y:737,t:1526930189163};\\\", \\\"{x:515,y:736,t:1526930189179};\\\", \\\"{x:517,y:735,t:1526930189492};\\\", \\\"{x:560,y:730,t:1526930189509};\\\", \\\"{x:629,y:713,t:1526930189525};\\\", \\\"{x:714,y:692,t:1526930189542};\\\", \\\"{x:773,y:682,t:1526930189558};\\\", \\\"{x:818,y:677,t:1526930189575};\\\", \\\"{x:843,y:671,t:1526930189593};\\\", \\\"{x:850,y:669,t:1526930189608};\\\", \\\"{x:851,y:669,t:1526930189626};\\\" ] }, { \\\"rt\\\": 11238, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 525357, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:847,y:665,t:1526930191861};\\\", \\\"{x:834,y:650,t:1526930191877};\\\", \\\"{x:832,y:647,t:1526930191909};\\\", \\\"{x:832,y:645,t:1526930192011};\\\", \\\"{x:832,y:643,t:1526930192348};\\\", \\\"{x:832,y:642,t:1526930193476};\\\", \\\"{x:835,y:642,t:1526930193836};\\\", \\\"{x:851,y:654,t:1526930193846};\\\", \\\"{x:911,y:726,t:1526930193862};\\\", \\\"{x:986,y:797,t:1526930193879};\\\", \\\"{x:1076,y:865,t:1526930193896};\\\", \\\"{x:1186,y:930,t:1526930193912};\\\", \\\"{x:1306,y:996,t:1526930193929};\\\", \\\"{x:1430,y:1050,t:1526930193946};\\\", \\\"{x:1536,y:1084,t:1526930193962};\\\", \\\"{x:1606,y:1108,t:1526930193979};\\\", \\\"{x:1652,y:1127,t:1526930193996};\\\", \\\"{x:1657,y:1131,t:1526930194012};\\\", \\\"{x:1658,y:1132,t:1526930194029};\\\", \\\"{x:1659,y:1134,t:1526930194068};\\\", \\\"{x:1660,y:1136,t:1526930194078};\\\", \\\"{x:1661,y:1140,t:1526930194096};\\\", \\\"{x:1661,y:1141,t:1526930194112};\\\", \\\"{x:1652,y:1135,t:1526930194156};\\\", \\\"{x:1642,y:1128,t:1526930194164};\\\", \\\"{x:1625,y:1118,t:1526930194179};\\\", \\\"{x:1550,y:1080,t:1526930194196};\\\", \\\"{x:1494,y:1056,t:1526930194212};\\\", \\\"{x:1436,y:1031,t:1526930194229};\\\", \\\"{x:1391,y:1009,t:1526930194246};\\\", \\\"{x:1344,y:987,t:1526930194262};\\\", \\\"{x:1321,y:974,t:1526930194279};\\\", \\\"{x:1306,y:967,t:1526930194296};\\\", \\\"{x:1298,y:964,t:1526930194313};\\\", \\\"{x:1296,y:963,t:1526930194329};\\\", \\\"{x:1296,y:961,t:1526930194437};\\\", \\\"{x:1297,y:959,t:1526930194446};\\\", \\\"{x:1306,y:957,t:1526930194463};\\\", \\\"{x:1314,y:957,t:1526930194480};\\\", \\\"{x:1323,y:956,t:1526930194496};\\\", \\\"{x:1327,y:956,t:1526930194513};\\\", \\\"{x:1328,y:956,t:1526930194529};\\\", \\\"{x:1330,y:956,t:1526930194693};\\\", \\\"{x:1331,y:956,t:1526930194700};\\\", \\\"{x:1332,y:957,t:1526930194740};\\\", \\\"{x:1333,y:957,t:1526930194764};\\\", \\\"{x:1335,y:959,t:1526930194780};\\\", \\\"{x:1337,y:961,t:1526930194797};\\\", \\\"{x:1338,y:962,t:1526930194813};\\\", \\\"{x:1338,y:963,t:1526930194830};\\\", \\\"{x:1339,y:964,t:1526930194846};\\\", \\\"{x:1340,y:966,t:1526930194863};\\\", \\\"{x:1340,y:967,t:1526930194880};\\\", \\\"{x:1341,y:968,t:1526930194896};\\\", \\\"{x:1342,y:967,t:1526930195093};\\\", \\\"{x:1342,y:964,t:1526930195101};\\\", \\\"{x:1342,y:961,t:1526930195113};\\\", \\\"{x:1342,y:954,t:1526930195130};\\\", \\\"{x:1342,y:945,t:1526930195146};\\\", \\\"{x:1342,y:932,t:1526930195163};\\\", \\\"{x:1342,y:914,t:1526930195180};\\\", \\\"{x:1342,y:907,t:1526930195197};\\\", \\\"{x:1342,y:900,t:1526930195213};\\\", \\\"{x:1342,y:894,t:1526930195230};\\\", \\\"{x:1340,y:890,t:1526930195246};\\\", \\\"{x:1340,y:888,t:1526930195263};\\\", \\\"{x:1338,y:882,t:1526930195280};\\\", \\\"{x:1338,y:878,t:1526930195297};\\\", \\\"{x:1336,y:872,t:1526930195313};\\\", \\\"{x:1336,y:866,t:1526930195330};\\\", \\\"{x:1335,y:862,t:1526930195347};\\\", \\\"{x:1334,y:858,t:1526930195363};\\\", \\\"{x:1332,y:841,t:1526930195380};\\\", \\\"{x:1331,y:833,t:1526930195396};\\\", \\\"{x:1330,y:827,t:1526930195414};\\\", \\\"{x:1329,y:821,t:1526930195430};\\\", \\\"{x:1328,y:816,t:1526930195447};\\\", \\\"{x:1326,y:812,t:1526930195463};\\\", \\\"{x:1326,y:810,t:1526930195480};\\\", \\\"{x:1326,y:809,t:1526930195497};\\\", \\\"{x:1326,y:807,t:1526930195513};\\\", \\\"{x:1326,y:806,t:1526930195530};\\\", \\\"{x:1326,y:804,t:1526930195556};\\\", \\\"{x:1326,y:802,t:1526930195572};\\\", \\\"{x:1326,y:800,t:1526930195580};\\\", \\\"{x:1326,y:795,t:1526930195597};\\\", \\\"{x:1326,y:788,t:1526930195613};\\\", \\\"{x:1326,y:785,t:1526930195630};\\\", \\\"{x:1326,y:784,t:1526930195647};\\\", \\\"{x:1326,y:782,t:1526930195663};\\\", \\\"{x:1326,y:780,t:1526930195680};\\\", \\\"{x:1326,y:779,t:1526930195697};\\\", \\\"{x:1326,y:778,t:1526930195714};\\\", \\\"{x:1326,y:775,t:1526930195730};\\\", \\\"{x:1326,y:773,t:1526930195747};\\\", \\\"{x:1326,y:770,t:1526930195764};\\\", \\\"{x:1326,y:769,t:1526930195780};\\\", \\\"{x:1326,y:766,t:1526930195797};\\\", \\\"{x:1326,y:763,t:1526930195814};\\\", \\\"{x:1326,y:759,t:1526930195831};\\\", \\\"{x:1326,y:757,t:1526930195847};\\\", \\\"{x:1326,y:753,t:1526930195864};\\\", \\\"{x:1326,y:751,t:1526930195880};\\\", \\\"{x:1327,y:749,t:1526930195897};\\\", \\\"{x:1327,y:748,t:1526930195914};\\\", \\\"{x:1327,y:746,t:1526930195930};\\\", \\\"{x:1328,y:744,t:1526930195947};\\\", \\\"{x:1329,y:742,t:1526930195964};\\\", \\\"{x:1329,y:741,t:1526930195988};\\\", \\\"{x:1329,y:740,t:1526930196012};\\\", \\\"{x:1328,y:739,t:1526930196277};\\\", \\\"{x:1321,y:735,t:1526930196284};\\\", \\\"{x:1312,y:733,t:1526930196297};\\\", \\\"{x:1295,y:724,t:1526930196314};\\\", \\\"{x:1263,y:716,t:1526930196331};\\\", \\\"{x:1210,y:708,t:1526930196346};\\\", \\\"{x:1127,y:697,t:1526930196363};\\\", \\\"{x:1071,y:688,t:1526930196381};\\\", \\\"{x:1033,y:685,t:1526930196396};\\\", \\\"{x:1007,y:681,t:1526930196414};\\\", \\\"{x:992,y:677,t:1526930196430};\\\", \\\"{x:991,y:677,t:1526930196446};\\\", \\\"{x:990,y:677,t:1526930196463};\\\", \\\"{x:989,y:677,t:1526930196515};\\\", \\\"{x:988,y:676,t:1526930196539};\\\", \\\"{x:985,y:675,t:1526930196548};\\\", \\\"{x:975,y:673,t:1526930196563};\\\", \\\"{x:960,y:672,t:1526930196581};\\\", \\\"{x:935,y:667,t:1526930196597};\\\", \\\"{x:926,y:661,t:1526930196614};\\\", \\\"{x:920,y:660,t:1526930196630};\\\", \\\"{x:921,y:660,t:1526930196972};\\\", \\\"{x:921,y:661,t:1526930196996};\\\", \\\"{x:921,y:662,t:1526930197004};\\\", \\\"{x:919,y:662,t:1526930197020};\\\", \\\"{x:917,y:662,t:1526930197031};\\\", \\\"{x:913,y:662,t:1526930197048};\\\", \\\"{x:909,y:662,t:1526930197064};\\\", \\\"{x:906,y:662,t:1526930197081};\\\", \\\"{x:903,y:661,t:1526930197098};\\\", \\\"{x:896,y:660,t:1526930197115};\\\", \\\"{x:887,y:656,t:1526930197131};\\\", \\\"{x:855,y:650,t:1526930197148};\\\", \\\"{x:805,y:639,t:1526930197164};\\\", \\\"{x:727,y:627,t:1526930197185};\\\", \\\"{x:636,y:607,t:1526930197198};\\\", \\\"{x:544,y:590,t:1526930197215};\\\", \\\"{x:475,y:581,t:1526930197232};\\\", \\\"{x:407,y:571,t:1526930197248};\\\", \\\"{x:376,y:567,t:1526930197264};\\\", \\\"{x:352,y:564,t:1526930197281};\\\", \\\"{x:338,y:561,t:1526930197297};\\\", \\\"{x:331,y:561,t:1526930197314};\\\", \\\"{x:328,y:560,t:1526930197331};\\\", \\\"{x:327,y:560,t:1526930197347};\\\", \\\"{x:325,y:559,t:1526930197364};\\\", \\\"{x:320,y:558,t:1526930197382};\\\", \\\"{x:306,y:556,t:1526930197397};\\\", \\\"{x:295,y:553,t:1526930197415};\\\", \\\"{x:281,y:551,t:1526930197431};\\\", \\\"{x:266,y:548,t:1526930197448};\\\", \\\"{x:258,y:547,t:1526930197465};\\\", \\\"{x:254,y:546,t:1526930197481};\\\", \\\"{x:258,y:549,t:1526930197676};\\\", \\\"{x:265,y:554,t:1526930197683};\\\", \\\"{x:268,y:559,t:1526930197699};\\\", \\\"{x:280,y:569,t:1526930197715};\\\", \\\"{x:298,y:579,t:1526930197731};\\\", \\\"{x:308,y:581,t:1526930197749};\\\", \\\"{x:322,y:583,t:1526930197764};\\\", \\\"{x:336,y:584,t:1526930197781};\\\", \\\"{x:352,y:585,t:1526930197798};\\\", \\\"{x:363,y:586,t:1526930197815};\\\", \\\"{x:376,y:588,t:1526930197831};\\\", \\\"{x:381,y:588,t:1526930197849};\\\", \\\"{x:389,y:588,t:1526930197865};\\\", \\\"{x:402,y:588,t:1526930197882};\\\", \\\"{x:417,y:588,t:1526930197899};\\\", \\\"{x:438,y:588,t:1526930197915};\\\", \\\"{x:470,y:588,t:1526930197931};\\\", \\\"{x:492,y:589,t:1526930197948};\\\", \\\"{x:514,y:592,t:1526930197966};\\\", \\\"{x:530,y:595,t:1526930197982};\\\", \\\"{x:545,y:597,t:1526930197999};\\\", \\\"{x:555,y:600,t:1526930198015};\\\", \\\"{x:560,y:601,t:1526930198033};\\\", \\\"{x:564,y:601,t:1526930198048};\\\", \\\"{x:566,y:601,t:1526930198065};\\\", \\\"{x:567,y:601,t:1526930198081};\\\", \\\"{x:573,y:601,t:1526930198098};\\\", \\\"{x:581,y:599,t:1526930198116};\\\", \\\"{x:602,y:589,t:1526930198132};\\\", \\\"{x:626,y:577,t:1526930198148};\\\", \\\"{x:658,y:565,t:1526930198165};\\\", \\\"{x:691,y:555,t:1526930198182};\\\", \\\"{x:722,y:547,t:1526930198198};\\\", \\\"{x:750,y:541,t:1526930198216};\\\", \\\"{x:765,y:539,t:1526930198232};\\\", \\\"{x:773,y:538,t:1526930198248};\\\", \\\"{x:774,y:538,t:1526930198266};\\\", \\\"{x:775,y:537,t:1526930198281};\\\", \\\"{x:776,y:537,t:1526930198308};\\\", \\\"{x:777,y:537,t:1526930198315};\\\", \\\"{x:778,y:537,t:1526930198339};\\\", \\\"{x:779,y:537,t:1526930198349};\\\", \\\"{x:780,y:537,t:1526930198366};\\\", \\\"{x:782,y:537,t:1526930198382};\\\", \\\"{x:782,y:536,t:1526930198399};\\\", \\\"{x:764,y:528,t:1526930198415};\\\", \\\"{x:751,y:526,t:1526930198432};\\\", \\\"{x:669,y:527,t:1526930198449};\\\", \\\"{x:525,y:544,t:1526930198466};\\\", \\\"{x:364,y:551,t:1526930198483};\\\", \\\"{x:220,y:551,t:1526930198500};\\\", \\\"{x:95,y:553,t:1526930198515};\\\", \\\"{x:82,y:553,t:1526930198532};\\\", \\\"{x:83,y:553,t:1526930198571};\\\", \\\"{x:88,y:554,t:1526930198582};\\\", \\\"{x:98,y:557,t:1526930198599};\\\", \\\"{x:101,y:557,t:1526930198616};\\\", \\\"{x:102,y:558,t:1526930198632};\\\", \\\"{x:102,y:559,t:1526930198649};\\\", \\\"{x:102,y:560,t:1526930198665};\\\", \\\"{x:103,y:561,t:1526930198716};\\\", \\\"{x:114,y:559,t:1526930198732};\\\", \\\"{x:128,y:553,t:1526930198751};\\\", \\\"{x:133,y:550,t:1526930198766};\\\", \\\"{x:140,y:549,t:1526930198782};\\\", \\\"{x:144,y:548,t:1526930198799};\\\", \\\"{x:150,y:544,t:1526930199157};\\\", \\\"{x:176,y:539,t:1526930199167};\\\", \\\"{x:291,y:529,t:1526930199183};\\\", \\\"{x:435,y:529,t:1526930199199};\\\", \\\"{x:584,y:526,t:1526930199216};\\\", \\\"{x:714,y:526,t:1526930199233};\\\", \\\"{x:809,y:526,t:1526930199249};\\\", \\\"{x:859,y:526,t:1526930199265};\\\", \\\"{x:886,y:526,t:1526930199283};\\\", \\\"{x:895,y:526,t:1526930199299};\\\", \\\"{x:898,y:527,t:1526930199323};\\\", \\\"{x:901,y:528,t:1526930199339};\\\", \\\"{x:903,y:528,t:1526930199349};\\\", \\\"{x:906,y:528,t:1526930199367};\\\", \\\"{x:907,y:528,t:1526930199383};\\\", \\\"{x:908,y:526,t:1526930199400};\\\", \\\"{x:908,y:523,t:1526930199417};\\\", \\\"{x:908,y:521,t:1526930199432};\\\", \\\"{x:906,y:519,t:1526930199450};\\\", \\\"{x:899,y:514,t:1526930199468};\\\", \\\"{x:887,y:509,t:1526930199482};\\\", \\\"{x:872,y:502,t:1526930199499};\\\", \\\"{x:869,y:501,t:1526930199517};\\\", \\\"{x:867,y:500,t:1526930199533};\\\", \\\"{x:862,y:498,t:1526930199549};\\\", \\\"{x:857,y:496,t:1526930199567};\\\", \\\"{x:853,y:494,t:1526930199582};\\\", \\\"{x:849,y:493,t:1526930199599};\\\", \\\"{x:846,y:492,t:1526930199617};\\\", \\\"{x:844,y:492,t:1526930199633};\\\", \\\"{x:845,y:493,t:1526930199859};\\\", \\\"{x:846,y:493,t:1526930199892};\\\", \\\"{x:847,y:494,t:1526930199900};\\\", \\\"{x:848,y:495,t:1526930199916};\\\", \\\"{x:850,y:495,t:1526930199933};\\\", \\\"{x:850,y:496,t:1526930199955};\\\", \\\"{x:851,y:496,t:1526930199996};\\\", \\\"{x:852,y:496,t:1526930200044};\\\", \\\"{x:852,y:497,t:1526930200110};\\\", \\\"{x:846,y:500,t:1526930200118};\\\", \\\"{x:819,y:511,t:1526930200135};\\\", \\\"{x:756,y:524,t:1526930200151};\\\", \\\"{x:638,y:537,t:1526930200167};\\\", \\\"{x:537,y:538,t:1526930200184};\\\", \\\"{x:413,y:538,t:1526930200201};\\\", \\\"{x:294,y:538,t:1526930200216};\\\", \\\"{x:197,y:538,t:1526930200234};\\\", \\\"{x:133,y:538,t:1526930200250};\\\", \\\"{x:111,y:541,t:1526930200266};\\\", \\\"{x:107,y:541,t:1526930200283};\\\", \\\"{x:106,y:541,t:1526930200307};\\\", \\\"{x:107,y:541,t:1526930200317};\\\", \\\"{x:108,y:542,t:1526930200338};\\\", \\\"{x:109,y:542,t:1526930200363};\\\", \\\"{x:110,y:542,t:1526930200395};\\\", \\\"{x:110,y:543,t:1526930200403};\\\", \\\"{x:111,y:544,t:1526930200417};\\\", \\\"{x:113,y:544,t:1526930200443};\\\", \\\"{x:114,y:544,t:1526930200459};\\\", \\\"{x:116,y:544,t:1526930200468};\\\", \\\"{x:117,y:544,t:1526930200484};\\\", \\\"{x:120,y:543,t:1526930200501};\\\", \\\"{x:124,y:541,t:1526930200517};\\\", \\\"{x:126,y:540,t:1526930200534};\\\", \\\"{x:127,y:539,t:1526930200580};\\\", \\\"{x:131,y:538,t:1526930200595};\\\", \\\"{x:133,y:538,t:1526930200612};\\\", \\\"{x:133,y:537,t:1526930200620};\\\", \\\"{x:135,y:536,t:1526930200635};\\\", \\\"{x:141,y:536,t:1526930200651};\\\", \\\"{x:150,y:534,t:1526930200669};\\\", \\\"{x:151,y:534,t:1526930200955};\\\", \\\"{x:157,y:540,t:1526930200967};\\\", \\\"{x:182,y:578,t:1526930200985};\\\", \\\"{x:237,y:628,t:1526930201001};\\\", \\\"{x:313,y:685,t:1526930201018};\\\", \\\"{x:383,y:732,t:1526930201034};\\\", \\\"{x:450,y:766,t:1526930201051};\\\", \\\"{x:539,y:811,t:1526930201067};\\\", \\\"{x:596,y:833,t:1526930201084};\\\", \\\"{x:625,y:837,t:1526930201101};\\\", \\\"{x:632,y:839,t:1526930201118};\\\", \\\"{x:633,y:839,t:1526930201135};\\\", \\\"{x:630,y:834,t:1526930201151};\\\", \\\"{x:618,y:829,t:1526930201169};\\\", \\\"{x:609,y:822,t:1526930201185};\\\", \\\"{x:606,y:819,t:1526930201201};\\\", \\\"{x:605,y:813,t:1526930201218};\\\", \\\"{x:599,y:805,t:1526930201235};\\\", \\\"{x:591,y:793,t:1526930201251};\\\", \\\"{x:584,y:780,t:1526930201268};\\\", \\\"{x:584,y:777,t:1526930201284};\\\", \\\"{x:583,y:773,t:1526930201301};\\\", \\\"{x:583,y:771,t:1526930201317};\\\", \\\"{x:582,y:771,t:1526930201372};\\\", \\\"{x:579,y:771,t:1526930201385};\\\", \\\"{x:577,y:771,t:1526930201401};\\\", \\\"{x:576,y:770,t:1526930201418};\\\", \\\"{x:575,y:770,t:1526930201435};\\\", \\\"{x:574,y:770,t:1526930201451};\\\", \\\"{x:569,y:767,t:1526930201467};\\\", \\\"{x:561,y:763,t:1526930201485};\\\", \\\"{x:553,y:760,t:1526930201501};\\\", \\\"{x:549,y:757,t:1526930201518};\\\", \\\"{x:548,y:757,t:1526930201535};\\\", \\\"{x:547,y:756,t:1526930201555};\\\", \\\"{x:545,y:754,t:1526930201569};\\\", \\\"{x:539,y:751,t:1526930201585};\\\", \\\"{x:528,y:744,t:1526930201601};\\\", \\\"{x:524,y:742,t:1526930201618};\\\", \\\"{x:531,y:743,t:1526930201932};\\\", \\\"{x:541,y:746,t:1526930201939};\\\", \\\"{x:553,y:748,t:1526930201951};\\\", \\\"{x:582,y:752,t:1526930201968};\\\", \\\"{x:610,y:752,t:1526930201985};\\\", \\\"{x:644,y:753,t:1526930202002};\\\", \\\"{x:678,y:753,t:1526930202018};\\\", \\\"{x:700,y:753,t:1526930202035};\\\", \\\"{x:710,y:753,t:1526930202051};\\\" ] }, { \\\"rt\\\": 8228, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 534845, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -B -M -M -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:718,y:753,t:1526930204308};\\\", \\\"{x:739,y:761,t:1526930204323};\\\", \\\"{x:822,y:786,t:1526930204337};\\\", \\\"{x:926,y:806,t:1526930204354};\\\", \\\"{x:1105,y:831,t:1526930204376};\\\", \\\"{x:1159,y:837,t:1526930204387};\\\", \\\"{x:1302,y:848,t:1526930204403};\\\", \\\"{x:1361,y:848,t:1526930204420};\\\", \\\"{x:1392,y:848,t:1526930204437};\\\", \\\"{x:1413,y:848,t:1526930204454};\\\", \\\"{x:1424,y:848,t:1526930204470};\\\", \\\"{x:1434,y:842,t:1526930204487};\\\", \\\"{x:1448,y:835,t:1526930204504};\\\", \\\"{x:1464,y:828,t:1526930204520};\\\", \\\"{x:1482,y:822,t:1526930204537};\\\", \\\"{x:1495,y:815,t:1526930204554};\\\", \\\"{x:1499,y:812,t:1526930204570};\\\", \\\"{x:1499,y:811,t:1526930204587};\\\", \\\"{x:1498,y:809,t:1526930204603};\\\", \\\"{x:1494,y:806,t:1526930204620};\\\", \\\"{x:1492,y:805,t:1526930204637};\\\", \\\"{x:1491,y:804,t:1526930204853};\\\", \\\"{x:1490,y:802,t:1526930204860};\\\", \\\"{x:1482,y:797,t:1526930204871};\\\", \\\"{x:1469,y:788,t:1526930204888};\\\", \\\"{x:1441,y:776,t:1526930204904};\\\", \\\"{x:1414,y:760,t:1526930204922};\\\", \\\"{x:1380,y:737,t:1526930204937};\\\", \\\"{x:1346,y:713,t:1526930204954};\\\", \\\"{x:1325,y:698,t:1526930204972};\\\", \\\"{x:1309,y:684,t:1526930204987};\\\", \\\"{x:1303,y:674,t:1526930205004};\\\", \\\"{x:1302,y:672,t:1526930205021};\\\", \\\"{x:1302,y:671,t:1526930205140};\\\", \\\"{x:1303,y:671,t:1526930205155};\\\", \\\"{x:1305,y:671,t:1526930205172};\\\", \\\"{x:1306,y:671,t:1526930205188};\\\", \\\"{x:1307,y:671,t:1526930205205};\\\", \\\"{x:1309,y:671,t:1526930205222};\\\", \\\"{x:1312,y:673,t:1526930205239};\\\", \\\"{x:1314,y:673,t:1526930205254};\\\", \\\"{x:1316,y:674,t:1526930205271};\\\", \\\"{x:1318,y:674,t:1526930205289};\\\", \\\"{x:1319,y:675,t:1526930205304};\\\", \\\"{x:1320,y:676,t:1526930205389};\\\", \\\"{x:1321,y:677,t:1526930205851};\\\", \\\"{x:1323,y:678,t:1526930205859};\\\", \\\"{x:1323,y:686,t:1526930205871};\\\", \\\"{x:1328,y:699,t:1526930205888};\\\", \\\"{x:1332,y:709,t:1526930205905};\\\", \\\"{x:1336,y:720,t:1526930205921};\\\", \\\"{x:1339,y:727,t:1526930205939};\\\", \\\"{x:1341,y:731,t:1526930205956};\\\", \\\"{x:1342,y:732,t:1526930205971};\\\", \\\"{x:1342,y:734,t:1526930205988};\\\", \\\"{x:1342,y:737,t:1526930206005};\\\", \\\"{x:1342,y:741,t:1526930206021};\\\", \\\"{x:1342,y:746,t:1526930206038};\\\", \\\"{x:1342,y:751,t:1526930206055};\\\", \\\"{x:1342,y:754,t:1526930206072};\\\", \\\"{x:1342,y:758,t:1526930206088};\\\", \\\"{x:1342,y:760,t:1526930206106};\\\", \\\"{x:1342,y:762,t:1526930206124};\\\", \\\"{x:1342,y:763,t:1526930206500};\\\", \\\"{x:1344,y:764,t:1526930206508};\\\", \\\"{x:1344,y:765,t:1526930206524};\\\", \\\"{x:1344,y:766,t:1526930206765};\\\", \\\"{x:1344,y:767,t:1526930206780};\\\", \\\"{x:1344,y:768,t:1526930208181};\\\", \\\"{x:1345,y:776,t:1526930208191};\\\", \\\"{x:1352,y:799,t:1526930208207};\\\", \\\"{x:1360,y:820,t:1526930208224};\\\", \\\"{x:1366,y:837,t:1526930208240};\\\", \\\"{x:1371,y:848,t:1526930208256};\\\", \\\"{x:1376,y:862,t:1526930208273};\\\", \\\"{x:1378,y:874,t:1526930208290};\\\", \\\"{x:1381,y:887,t:1526930208306};\\\", \\\"{x:1382,y:897,t:1526930208324};\\\", \\\"{x:1382,y:909,t:1526930208341};\\\", \\\"{x:1382,y:916,t:1526930208357};\\\", \\\"{x:1382,y:919,t:1526930208373};\\\", \\\"{x:1382,y:921,t:1526930208390};\\\", \\\"{x:1380,y:921,t:1526930208412};\\\", \\\"{x:1375,y:921,t:1526930208423};\\\", \\\"{x:1356,y:912,t:1526930208440};\\\", \\\"{x:1304,y:878,t:1526930208456};\\\", \\\"{x:1210,y:821,t:1526930208474};\\\", \\\"{x:1088,y:761,t:1526930208490};\\\", \\\"{x:950,y:697,t:1526930208506};\\\", \\\"{x:784,y:629,t:1526930208525};\\\", \\\"{x:727,y:609,t:1526930208540};\\\", \\\"{x:710,y:601,t:1526930208557};\\\", \\\"{x:707,y:600,t:1526930208575};\\\", \\\"{x:706,y:599,t:1526930208635};\\\", \\\"{x:706,y:598,t:1526930208659};\\\", \\\"{x:706,y:597,t:1526930208674};\\\", \\\"{x:706,y:594,t:1526930208689};\\\", \\\"{x:708,y:591,t:1526930208707};\\\", \\\"{x:708,y:590,t:1526930208724};\\\", \\\"{x:709,y:588,t:1526930208740};\\\", \\\"{x:710,y:587,t:1526930208757};\\\", \\\"{x:711,y:586,t:1526930208773};\\\", \\\"{x:712,y:585,t:1526930208789};\\\", \\\"{x:712,y:582,t:1526930208807};\\\", \\\"{x:697,y:574,t:1526930208824};\\\", \\\"{x:675,y:564,t:1526930208840};\\\", \\\"{x:638,y:555,t:1526930208858};\\\", \\\"{x:599,y:550,t:1526930208873};\\\", \\\"{x:559,y:549,t:1526930208890};\\\", \\\"{x:497,y:548,t:1526930208908};\\\", \\\"{x:467,y:548,t:1526930208924};\\\", \\\"{x:449,y:548,t:1526930208940};\\\", \\\"{x:435,y:548,t:1526930208957};\\\", \\\"{x:426,y:552,t:1526930208973};\\\", \\\"{x:414,y:554,t:1526930208990};\\\", \\\"{x:401,y:556,t:1526930209008};\\\", \\\"{x:381,y:556,t:1526930209024};\\\", \\\"{x:361,y:556,t:1526930209041};\\\", \\\"{x:347,y:556,t:1526930209057};\\\", \\\"{x:334,y:556,t:1526930209073};\\\", \\\"{x:315,y:556,t:1526930209091};\\\", \\\"{x:308,y:556,t:1526930209107};\\\", \\\"{x:280,y:556,t:1526930209124};\\\", \\\"{x:238,y:552,t:1526930209141};\\\", \\\"{x:190,y:546,t:1526930209158};\\\", \\\"{x:163,y:546,t:1526930209174};\\\", \\\"{x:148,y:545,t:1526930209192};\\\", \\\"{x:147,y:545,t:1526930209207};\\\", \\\"{x:148,y:545,t:1526930209644};\\\", \\\"{x:149,y:545,t:1526930209661};\\\", \\\"{x:151,y:545,t:1526930209723};\\\", \\\"{x:153,y:545,t:1526930209763};\\\", \\\"{x:154,y:546,t:1526930209779};\\\", \\\"{x:157,y:547,t:1526930209791};\\\", \\\"{x:159,y:547,t:1526930209808};\\\", \\\"{x:160,y:547,t:1526930209825};\\\", \\\"{x:162,y:548,t:1526930209843};\\\", \\\"{x:162,y:549,t:1526930209867};\\\", \\\"{x:164,y:549,t:1526930209876};\\\", \\\"{x:173,y:556,t:1526930209892};\\\", \\\"{x:181,y:561,t:1526930209908};\\\", \\\"{x:186,y:563,t:1526930209926};\\\", \\\"{x:187,y:563,t:1526930209947};\\\", \\\"{x:188,y:563,t:1526930209979};\\\", \\\"{x:188,y:562,t:1526930210012};\\\", \\\"{x:188,y:560,t:1526930210025};\\\", \\\"{x:188,y:557,t:1526930210041};\\\", \\\"{x:188,y:554,t:1526930210059};\\\", \\\"{x:185,y:550,t:1526930210075};\\\", \\\"{x:182,y:549,t:1526930210091};\\\", \\\"{x:179,y:548,t:1526930210108};\\\", \\\"{x:177,y:547,t:1526930210131};\\\", \\\"{x:176,y:547,t:1526930210187};\\\", \\\"{x:175,y:547,t:1526930210564};\\\", \\\"{x:173,y:547,t:1526930210575};\\\", \\\"{x:170,y:547,t:1526930210592};\\\", \\\"{x:169,y:547,t:1526930210609};\\\", \\\"{x:169,y:549,t:1526930210625};\\\", \\\"{x:180,y:555,t:1526930210642};\\\", \\\"{x:198,y:566,t:1526930210659};\\\", \\\"{x:309,y:620,t:1526930210676};\\\", \\\"{x:435,y:673,t:1526930210693};\\\", \\\"{x:580,y:722,t:1526930210709};\\\", \\\"{x:694,y:761,t:1526930210725};\\\", \\\"{x:750,y:780,t:1526930210742};\\\", \\\"{x:781,y:787,t:1526930210758};\\\", \\\"{x:786,y:790,t:1526930210775};\\\", \\\"{x:781,y:790,t:1526930210795};\\\", \\\"{x:774,y:790,t:1526930210808};\\\", \\\"{x:755,y:789,t:1526930210825};\\\", \\\"{x:746,y:788,t:1526930210841};\\\", \\\"{x:723,y:785,t:1526930210858};\\\", \\\"{x:677,y:776,t:1526930210875};\\\", \\\"{x:612,y:757,t:1526930210891};\\\", \\\"{x:569,y:750,t:1526930210908};\\\", \\\"{x:553,y:746,t:1526930210926};\\\", \\\"{x:545,y:742,t:1526930210941};\\\", \\\"{x:543,y:741,t:1526930210958};\\\", \\\"{x:543,y:740,t:1526930210996};\\\", \\\"{x:543,y:739,t:1526930211019};\\\", \\\"{x:543,y:738,t:1526930211035};\\\", \\\"{x:543,y:737,t:1526930211043};\\\", \\\"{x:542,y:736,t:1526930211091};\\\", \\\"{x:546,y:736,t:1526930211419};\\\", \\\"{x:555,y:736,t:1526930211427};\\\", \\\"{x:574,y:736,t:1526930211442};\\\", \\\"{x:677,y:738,t:1526930211459};\\\", \\\"{x:775,y:737,t:1526930211475};\\\", \\\"{x:874,y:737,t:1526930211492};\\\", \\\"{x:947,y:737,t:1526930211509};\\\", \\\"{x:985,y:737,t:1526930211526};\\\", \\\"{x:1001,y:737,t:1526930211542};\\\" ] }, { \\\"rt\\\": 30374, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 566420, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -Z -04 PM-Z -Z -Z -X -X -O -X -Z -X -X -01 PM-01 PM-F -M -M -B -B -12 PM-B -B -B -F -F -F -F -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1002,y:736,t:1526930212755};\\\", \\\"{x:999,y:735,t:1526930212763};\\\", \\\"{x:990,y:730,t:1526930212777};\\\", \\\"{x:974,y:719,t:1526930212793};\\\", \\\"{x:942,y:708,t:1526930212811};\\\", \\\"{x:897,y:695,t:1526930212827};\\\", \\\"{x:872,y:688,t:1526930212844};\\\", \\\"{x:856,y:685,t:1526930212928};\\\", \\\"{x:857,y:685,t:1526930213756};\\\", \\\"{x:858,y:685,t:1526930213763};\\\", \\\"{x:860,y:686,t:1526930213777};\\\", \\\"{x:863,y:687,t:1526930213794};\\\", \\\"{x:871,y:691,t:1526930213811};\\\", \\\"{x:876,y:693,t:1526930213827};\\\", \\\"{x:880,y:694,t:1526930213844};\\\", \\\"{x:883,y:695,t:1526930213861};\\\", \\\"{x:887,y:696,t:1526930213877};\\\", \\\"{x:892,y:698,t:1526930213894};\\\", \\\"{x:897,y:699,t:1526930213912};\\\", \\\"{x:912,y:700,t:1526930213927};\\\", \\\"{x:923,y:702,t:1526930213945};\\\", \\\"{x:935,y:703,t:1526930213962};\\\", \\\"{x:939,y:705,t:1526930213978};\\\", \\\"{x:942,y:705,t:1526930213994};\\\", \\\"{x:948,y:706,t:1526930214012};\\\", \\\"{x:951,y:707,t:1526930214027};\\\", \\\"{x:957,y:709,t:1526930214045};\\\", \\\"{x:960,y:709,t:1526930214062};\\\", \\\"{x:961,y:709,t:1526930214078};\\\", \\\"{x:962,y:709,t:1526930214095};\\\", \\\"{x:964,y:709,t:1526930214212};\\\", \\\"{x:984,y:709,t:1526930214228};\\\", \\\"{x:1023,y:714,t:1526930214245};\\\", \\\"{x:1101,y:718,t:1526930214261};\\\", \\\"{x:1188,y:720,t:1526930214279};\\\", \\\"{x:1291,y:724,t:1526930214294};\\\", \\\"{x:1414,y:728,t:1526930214311};\\\", \\\"{x:1528,y:730,t:1526930214328};\\\", \\\"{x:1630,y:730,t:1526930214344};\\\", \\\"{x:1704,y:733,t:1526930214361};\\\", \\\"{x:1742,y:733,t:1526930214378};\\\", \\\"{x:1761,y:733,t:1526930214395};\\\", \\\"{x:1766,y:733,t:1526930214411};\\\", \\\"{x:1763,y:733,t:1526930214451};\\\", \\\"{x:1762,y:733,t:1526930214467};\\\", \\\"{x:1761,y:732,t:1526930214479};\\\", \\\"{x:1759,y:732,t:1526930214495};\\\", \\\"{x:1759,y:731,t:1526930214511};\\\", \\\"{x:1757,y:731,t:1526930214528};\\\", \\\"{x:1756,y:730,t:1526930214546};\\\", \\\"{x:1752,y:728,t:1526930214561};\\\", \\\"{x:1749,y:726,t:1526930214579};\\\", \\\"{x:1745,y:724,t:1526930214595};\\\", \\\"{x:1743,y:724,t:1526930214612};\\\", \\\"{x:1739,y:722,t:1526930214628};\\\", \\\"{x:1733,y:720,t:1526930214645};\\\", \\\"{x:1723,y:715,t:1526930214661};\\\", \\\"{x:1704,y:710,t:1526930214679};\\\", \\\"{x:1680,y:703,t:1526930214696};\\\", \\\"{x:1656,y:698,t:1526930214711};\\\", \\\"{x:1640,y:697,t:1526930214728};\\\", \\\"{x:1623,y:694,t:1526930214745};\\\", \\\"{x:1607,y:692,t:1526930214762};\\\", \\\"{x:1594,y:688,t:1526930214779};\\\", \\\"{x:1579,y:684,t:1526930214796};\\\", \\\"{x:1574,y:683,t:1526930214812};\\\", \\\"{x:1570,y:682,t:1526930214828};\\\", \\\"{x:1567,y:681,t:1526930214846};\\\", \\\"{x:1563,y:679,t:1526930214862};\\\", \\\"{x:1558,y:678,t:1526930214879};\\\", \\\"{x:1553,y:677,t:1526930214896};\\\", \\\"{x:1548,y:675,t:1526930214912};\\\", \\\"{x:1544,y:675,t:1526930214928};\\\", \\\"{x:1540,y:673,t:1526930214945};\\\", \\\"{x:1537,y:673,t:1526930214962};\\\", \\\"{x:1535,y:673,t:1526930214979};\\\", \\\"{x:1534,y:677,t:1526930215060};\\\", \\\"{x:1531,y:685,t:1526930215068};\\\", \\\"{x:1528,y:692,t:1526930215079};\\\", \\\"{x:1522,y:712,t:1526930215095};\\\", \\\"{x:1518,y:735,t:1526930215113};\\\", \\\"{x:1517,y:757,t:1526930215129};\\\", \\\"{x:1517,y:772,t:1526930215147};\\\", \\\"{x:1517,y:781,t:1526930215162};\\\", \\\"{x:1519,y:786,t:1526930215178};\\\", \\\"{x:1520,y:791,t:1526930215195};\\\", \\\"{x:1520,y:792,t:1526930215212};\\\", \\\"{x:1520,y:794,t:1526930215229};\\\", \\\"{x:1520,y:799,t:1526930215246};\\\", \\\"{x:1520,y:806,t:1526930215263};\\\", \\\"{x:1520,y:811,t:1526930215278};\\\", \\\"{x:1520,y:814,t:1526930215295};\\\", \\\"{x:1520,y:816,t:1526930215313};\\\", \\\"{x:1520,y:817,t:1526930215328};\\\", \\\"{x:1520,y:821,t:1526930215346};\\\", \\\"{x:1520,y:825,t:1526930215363};\\\", \\\"{x:1522,y:830,t:1526930215379};\\\", \\\"{x:1523,y:834,t:1526930215396};\\\", \\\"{x:1524,y:837,t:1526930215413};\\\", \\\"{x:1527,y:840,t:1526930215429};\\\", \\\"{x:1535,y:844,t:1526930215445};\\\", \\\"{x:1548,y:847,t:1526930215462};\\\", \\\"{x:1568,y:848,t:1526930215479};\\\", \\\"{x:1589,y:849,t:1526930215496};\\\", \\\"{x:1616,y:849,t:1526930215512};\\\", \\\"{x:1650,y:849,t:1526930215529};\\\", \\\"{x:1676,y:849,t:1526930215546};\\\", \\\"{x:1696,y:849,t:1526930215563};\\\", \\\"{x:1710,y:849,t:1526930215579};\\\", \\\"{x:1712,y:849,t:1526930215595};\\\", \\\"{x:1712,y:845,t:1526930215613};\\\", \\\"{x:1712,y:840,t:1526930215630};\\\", \\\"{x:1712,y:826,t:1526930215646};\\\", \\\"{x:1707,y:804,t:1526930215663};\\\", \\\"{x:1684,y:764,t:1526930215680};\\\", \\\"{x:1636,y:697,t:1526930215696};\\\", \\\"{x:1569,y:620,t:1526930215713};\\\", \\\"{x:1494,y:551,t:1526930215730};\\\", \\\"{x:1421,y:499,t:1526930215746};\\\", \\\"{x:1363,y:464,t:1526930215763};\\\", \\\"{x:1329,y:440,t:1526930215780};\\\", \\\"{x:1324,y:437,t:1526930215796};\\\", \\\"{x:1323,y:435,t:1526930215813};\\\", \\\"{x:1323,y:433,t:1526930215830};\\\", \\\"{x:1323,y:429,t:1526930215845};\\\", \\\"{x:1323,y:427,t:1526930215863};\\\", \\\"{x:1323,y:424,t:1526930215880};\\\", \\\"{x:1324,y:421,t:1526930215897};\\\", \\\"{x:1332,y:417,t:1526930215913};\\\", \\\"{x:1353,y:411,t:1526930215930};\\\", \\\"{x:1384,y:407,t:1526930215947};\\\", \\\"{x:1419,y:407,t:1526930215963};\\\", \\\"{x:1475,y:407,t:1526930215979};\\\", \\\"{x:1504,y:407,t:1526930215997};\\\", \\\"{x:1529,y:407,t:1526930216013};\\\", \\\"{x:1548,y:408,t:1526930216030};\\\", \\\"{x:1558,y:410,t:1526930216047};\\\", \\\"{x:1561,y:411,t:1526930216063};\\\", \\\"{x:1563,y:412,t:1526930216079};\\\", \\\"{x:1563,y:414,t:1526930216164};\\\", \\\"{x:1563,y:415,t:1526930216180};\\\", \\\"{x:1563,y:417,t:1526930216196};\\\", \\\"{x:1563,y:423,t:1526930216213};\\\", \\\"{x:1563,y:435,t:1526930216230};\\\", \\\"{x:1566,y:453,t:1526930216247};\\\", \\\"{x:1575,y:489,t:1526930216263};\\\", \\\"{x:1592,y:545,t:1526930216280};\\\", \\\"{x:1612,y:601,t:1526930216297};\\\", \\\"{x:1628,y:636,t:1526930216313};\\\", \\\"{x:1638,y:652,t:1526930216330};\\\", \\\"{x:1642,y:659,t:1526930216347};\\\", \\\"{x:1645,y:663,t:1526930216364};\\\", \\\"{x:1645,y:664,t:1526930216380};\\\", \\\"{x:1646,y:667,t:1526930216397};\\\", \\\"{x:1647,y:675,t:1526930216414};\\\", \\\"{x:1649,y:682,t:1526930216430};\\\", \\\"{x:1650,y:691,t:1526930216447};\\\", \\\"{x:1650,y:695,t:1526930216464};\\\", \\\"{x:1650,y:703,t:1526930216479};\\\", \\\"{x:1650,y:711,t:1526930216497};\\\", \\\"{x:1647,y:720,t:1526930216514};\\\", \\\"{x:1644,y:725,t:1526930216530};\\\", \\\"{x:1638,y:728,t:1526930216547};\\\", \\\"{x:1629,y:729,t:1526930216564};\\\", \\\"{x:1625,y:729,t:1526930216580};\\\", \\\"{x:1622,y:729,t:1526930216597};\\\", \\\"{x:1621,y:729,t:1526930216660};\\\", \\\"{x:1619,y:726,t:1526930216668};\\\", \\\"{x:1619,y:725,t:1526930216685};\\\", \\\"{x:1618,y:722,t:1526930216697};\\\", \\\"{x:1617,y:719,t:1526930216714};\\\", \\\"{x:1617,y:718,t:1526930216729};\\\", \\\"{x:1617,y:715,t:1526930216747};\\\", \\\"{x:1617,y:712,t:1526930216764};\\\", \\\"{x:1617,y:709,t:1526930216779};\\\", \\\"{x:1614,y:705,t:1526930216796};\\\", \\\"{x:1612,y:703,t:1526930216813};\\\", \\\"{x:1612,y:702,t:1526930216875};\\\", \\\"{x:1611,y:701,t:1526930216949};\\\", \\\"{x:1611,y:706,t:1526930217189};\\\", \\\"{x:1611,y:712,t:1526930217197};\\\", \\\"{x:1612,y:726,t:1526930217214};\\\", \\\"{x:1612,y:740,t:1526930217231};\\\", \\\"{x:1613,y:755,t:1526930217247};\\\", \\\"{x:1614,y:765,t:1526930217264};\\\", \\\"{x:1614,y:771,t:1526930217281};\\\", \\\"{x:1614,y:775,t:1526930217297};\\\", \\\"{x:1614,y:780,t:1526930217314};\\\", \\\"{x:1614,y:787,t:1526930217331};\\\", \\\"{x:1613,y:805,t:1526930217348};\\\", \\\"{x:1610,y:823,t:1526930217364};\\\", \\\"{x:1605,y:846,t:1526930217381};\\\", \\\"{x:1600,y:865,t:1526930217398};\\\", \\\"{x:1599,y:877,t:1526930217413};\\\", \\\"{x:1599,y:887,t:1526930217431};\\\", \\\"{x:1599,y:896,t:1526930217448};\\\", \\\"{x:1597,y:896,t:1526930217464};\\\", \\\"{x:1597,y:897,t:1526930217492};\\\", \\\"{x:1597,y:898,t:1526930217556};\\\", \\\"{x:1597,y:899,t:1526930217628};\\\", \\\"{x:1597,y:900,t:1526930217636};\\\", \\\"{x:1597,y:902,t:1526930218357};\\\", \\\"{x:1597,y:905,t:1526930218365};\\\", \\\"{x:1598,y:909,t:1526930218382};\\\", \\\"{x:1602,y:922,t:1526930218398};\\\", \\\"{x:1605,y:938,t:1526930218415};\\\", \\\"{x:1606,y:949,t:1526930218431};\\\", \\\"{x:1607,y:960,t:1526930218448};\\\", \\\"{x:1608,y:968,t:1526930218465};\\\", \\\"{x:1610,y:975,t:1526930218482};\\\", \\\"{x:1611,y:984,t:1526930218498};\\\", \\\"{x:1612,y:993,t:1526930218515};\\\", \\\"{x:1612,y:997,t:1526930218532};\\\", \\\"{x:1612,y:998,t:1526930218548};\\\", \\\"{x:1612,y:999,t:1526930218580};\\\", \\\"{x:1612,y:1000,t:1526930218596};\\\", \\\"{x:1612,y:1001,t:1526930218612};\\\", \\\"{x:1611,y:1001,t:1526930218620};\\\", \\\"{x:1609,y:1001,t:1526930218632};\\\", \\\"{x:1605,y:999,t:1526930218648};\\\", \\\"{x:1604,y:999,t:1526930218664};\\\", \\\"{x:1602,y:998,t:1526930218692};\\\", \\\"{x:1601,y:997,t:1526930218700};\\\", \\\"{x:1599,y:994,t:1526930218715};\\\", \\\"{x:1591,y:974,t:1526930218732};\\\", \\\"{x:1578,y:939,t:1526930218748};\\\", \\\"{x:1556,y:882,t:1526930218765};\\\", \\\"{x:1529,y:821,t:1526930218782};\\\", \\\"{x:1515,y:773,t:1526930218799};\\\", \\\"{x:1507,y:726,t:1526930218815};\\\", \\\"{x:1507,y:686,t:1526930218832};\\\", \\\"{x:1507,y:666,t:1526930218849};\\\", \\\"{x:1507,y:653,t:1526930218865};\\\", \\\"{x:1513,y:645,t:1526930218882};\\\", \\\"{x:1518,y:642,t:1526930218899};\\\", \\\"{x:1522,y:639,t:1526930218915};\\\", \\\"{x:1530,y:634,t:1526930218932};\\\", \\\"{x:1537,y:633,t:1526930218948};\\\", \\\"{x:1545,y:633,t:1526930218965};\\\", \\\"{x:1550,y:634,t:1526930218982};\\\", \\\"{x:1554,y:635,t:1526930218999};\\\", \\\"{x:1555,y:635,t:1526930219015};\\\", \\\"{x:1557,y:635,t:1526930219032};\\\", \\\"{x:1559,y:637,t:1526930219049};\\\", \\\"{x:1566,y:644,t:1526930219065};\\\", \\\"{x:1574,y:652,t:1526930219082};\\\", \\\"{x:1580,y:657,t:1526930219099};\\\", \\\"{x:1583,y:661,t:1526930219115};\\\", \\\"{x:1587,y:668,t:1526930219132};\\\", \\\"{x:1598,y:680,t:1526930219149};\\\", \\\"{x:1607,y:686,t:1526930219165};\\\", \\\"{x:1619,y:694,t:1526930219182};\\\", \\\"{x:1629,y:697,t:1526930219200};\\\", \\\"{x:1637,y:701,t:1526930219215};\\\", \\\"{x:1640,y:702,t:1526930219232};\\\", \\\"{x:1641,y:702,t:1526930219249};\\\", \\\"{x:1641,y:703,t:1526930219348};\\\", \\\"{x:1640,y:703,t:1526930219372};\\\", \\\"{x:1637,y:703,t:1526930219382};\\\", \\\"{x:1631,y:700,t:1526930219399};\\\", \\\"{x:1627,y:700,t:1526930219416};\\\", \\\"{x:1624,y:700,t:1526930219432};\\\", \\\"{x:1623,y:700,t:1526930219448};\\\", \\\"{x:1621,y:700,t:1526930220221};\\\", \\\"{x:1620,y:700,t:1526930220260};\\\", \\\"{x:1618,y:699,t:1526930220268};\\\", \\\"{x:1612,y:696,t:1526930220283};\\\", \\\"{x:1608,y:694,t:1526930220301};\\\", \\\"{x:1607,y:693,t:1526930220317};\\\", \\\"{x:1606,y:693,t:1526930220333};\\\", \\\"{x:1608,y:693,t:1526930220509};\\\", \\\"{x:1609,y:693,t:1526930220524};\\\", \\\"{x:1612,y:694,t:1526930220564};\\\", \\\"{x:1613,y:694,t:1526930222427};\\\", \\\"{x:1615,y:695,t:1526930222468};\\\", \\\"{x:1616,y:695,t:1526930222500};\\\", \\\"{x:1616,y:696,t:1526930222515};\\\", \\\"{x:1618,y:696,t:1526930222596};\\\", \\\"{x:1618,y:697,t:1526930222612};\\\", \\\"{x:1619,y:699,t:1526930222619};\\\", \\\"{x:1619,y:705,t:1526930222636};\\\", \\\"{x:1620,y:723,t:1526930222651};\\\", \\\"{x:1623,y:792,t:1526930222668};\\\", \\\"{x:1610,y:889,t:1526930222685};\\\", \\\"{x:1591,y:985,t:1526930222702};\\\", \\\"{x:1580,y:1000,t:1526930222718};\\\", \\\"{x:1580,y:1001,t:1526930222740};\\\", \\\"{x:1579,y:1001,t:1526930222764};\\\", \\\"{x:1577,y:1001,t:1526930222821};\\\", \\\"{x:1577,y:997,t:1526930222835};\\\", \\\"{x:1573,y:969,t:1526930222851};\\\", \\\"{x:1546,y:928,t:1526930222868};\\\", \\\"{x:1510,y:896,t:1526930222886};\\\", \\\"{x:1474,y:871,t:1526930222901};\\\", \\\"{x:1455,y:859,t:1526930222918};\\\", \\\"{x:1447,y:849,t:1526930222935};\\\", \\\"{x:1444,y:841,t:1526930222951};\\\", \\\"{x:1441,y:835,t:1526930222968};\\\", \\\"{x:1441,y:833,t:1526930222985};\\\", \\\"{x:1441,y:832,t:1526930223004};\\\", \\\"{x:1443,y:831,t:1526930223020};\\\", \\\"{x:1444,y:830,t:1526930223035};\\\", \\\"{x:1448,y:825,t:1526930223052};\\\", \\\"{x:1450,y:822,t:1526930223068};\\\", \\\"{x:1459,y:811,t:1526930223085};\\\", \\\"{x:1467,y:805,t:1526930223102};\\\", \\\"{x:1475,y:803,t:1526930223118};\\\", \\\"{x:1480,y:803,t:1526930223136};\\\", \\\"{x:1484,y:803,t:1526930223152};\\\", \\\"{x:1485,y:803,t:1526930223196};\\\", \\\"{x:1486,y:805,t:1526930223204};\\\", \\\"{x:1486,y:807,t:1526930223218};\\\", \\\"{x:1486,y:814,t:1526930223236};\\\", \\\"{x:1486,y:826,t:1526930223251};\\\", \\\"{x:1486,y:830,t:1526930223268};\\\", \\\"{x:1486,y:834,t:1526930223286};\\\", \\\"{x:1486,y:835,t:1526930223302};\\\", \\\"{x:1486,y:837,t:1526930223317};\\\", \\\"{x:1486,y:841,t:1526930223334};\\\", \\\"{x:1485,y:843,t:1526930223352};\\\", \\\"{x:1485,y:844,t:1526930223371};\\\", \\\"{x:1485,y:846,t:1526930223572};\\\", \\\"{x:1484,y:849,t:1526930223585};\\\", \\\"{x:1484,y:853,t:1526930223602};\\\", \\\"{x:1484,y:855,t:1526930223619};\\\", \\\"{x:1484,y:856,t:1526930223635};\\\", \\\"{x:1484,y:857,t:1526930223652};\\\", \\\"{x:1483,y:856,t:1526930223732};\\\", \\\"{x:1482,y:851,t:1526930223740};\\\", \\\"{x:1481,y:848,t:1526930223752};\\\", \\\"{x:1481,y:845,t:1526930223769};\\\", \\\"{x:1481,y:843,t:1526930223785};\\\", \\\"{x:1480,y:842,t:1526930223802};\\\", \\\"{x:1480,y:840,t:1526930223819};\\\", \\\"{x:1480,y:839,t:1526930223836};\\\", \\\"{x:1480,y:838,t:1526930223860};\\\", \\\"{x:1480,y:837,t:1526930223892};\\\", \\\"{x:1480,y:836,t:1526930223932};\\\", \\\"{x:1480,y:835,t:1526930223956};\\\", \\\"{x:1479,y:832,t:1526930223985};\\\", \\\"{x:1468,y:828,t:1526930224003};\\\", \\\"{x:1441,y:817,t:1526930224019};\\\", \\\"{x:1374,y:809,t:1526930224035};\\\", \\\"{x:1220,y:787,t:1526930224052};\\\", \\\"{x:1085,y:772,t:1526930224069};\\\", \\\"{x:930,y:746,t:1526930224086};\\\", \\\"{x:779,y:711,t:1526930224102};\\\", \\\"{x:638,y:674,t:1526930224119};\\\", \\\"{x:527,y:639,t:1526930224136};\\\", \\\"{x:468,y:621,t:1526930224154};\\\", \\\"{x:436,y:609,t:1526930224169};\\\", \\\"{x:430,y:607,t:1526930224185};\\\", \\\"{x:430,y:605,t:1526930224299};\\\", \\\"{x:433,y:598,t:1526930224307};\\\", \\\"{x:436,y:596,t:1526930224319};\\\", \\\"{x:452,y:589,t:1526930224336};\\\", \\\"{x:476,y:585,t:1526930224352};\\\", \\\"{x:514,y:585,t:1526930224370};\\\", \\\"{x:546,y:585,t:1526930224385};\\\", \\\"{x:563,y:585,t:1526930224402};\\\", \\\"{x:565,y:585,t:1526930224418};\\\", \\\"{x:566,y:585,t:1526930224508};\\\", \\\"{x:567,y:585,t:1526930224523};\\\", \\\"{x:568,y:585,t:1526930224536};\\\", \\\"{x:573,y:585,t:1526930224553};\\\", \\\"{x:586,y:585,t:1526930224570};\\\", \\\"{x:598,y:585,t:1526930224587};\\\", \\\"{x:610,y:585,t:1526930224604};\\\", \\\"{x:620,y:585,t:1526930224619};\\\", \\\"{x:620,y:584,t:1526930224636};\\\", \\\"{x:621,y:584,t:1526930224668};\\\", \\\"{x:621,y:583,t:1526930224764};\\\", \\\"{x:621,y:581,t:1526930224772};\\\", \\\"{x:622,y:581,t:1526930224787};\\\", \\\"{x:623,y:580,t:1526930224803};\\\", \\\"{x:623,y:581,t:1526930225340};\\\", \\\"{x:626,y:583,t:1526930225354};\\\", \\\"{x:648,y:593,t:1526930225372};\\\", \\\"{x:729,y:619,t:1526930225388};\\\", \\\"{x:844,y:648,t:1526930225404};\\\", \\\"{x:984,y:675,t:1526930225420};\\\", \\\"{x:1137,y:704,t:1526930225437};\\\", \\\"{x:1278,y:725,t:1526930225454};\\\", \\\"{x:1403,y:744,t:1526930225470};\\\", \\\"{x:1511,y:760,t:1526930225487};\\\", \\\"{x:1573,y:777,t:1526930225504};\\\", \\\"{x:1603,y:786,t:1526930225520};\\\", \\\"{x:1618,y:794,t:1526930225536};\\\", \\\"{x:1629,y:802,t:1526930225554};\\\", \\\"{x:1637,y:814,t:1526930225571};\\\", \\\"{x:1643,y:830,t:1526930225587};\\\", \\\"{x:1647,y:852,t:1526930225604};\\\", \\\"{x:1650,y:869,t:1526930225621};\\\", \\\"{x:1650,y:889,t:1526930225637};\\\", \\\"{x:1650,y:910,t:1526930225654};\\\", \\\"{x:1650,y:918,t:1526930225671};\\\", \\\"{x:1650,y:935,t:1526930225687};\\\", \\\"{x:1648,y:948,t:1526930225704};\\\", \\\"{x:1643,y:955,t:1526930225721};\\\", \\\"{x:1638,y:957,t:1526930225737};\\\", \\\"{x:1626,y:958,t:1526930225754};\\\", \\\"{x:1603,y:959,t:1526930225771};\\\", \\\"{x:1593,y:959,t:1526930225788};\\\", \\\"{x:1559,y:958,t:1526930225804};\\\", \\\"{x:1533,y:951,t:1526930225821};\\\", \\\"{x:1509,y:946,t:1526930225837};\\\", \\\"{x:1497,y:945,t:1526930225854};\\\", \\\"{x:1493,y:945,t:1526930225871};\\\", \\\"{x:1493,y:946,t:1526930225932};\\\", \\\"{x:1493,y:950,t:1526930225940};\\\", \\\"{x:1493,y:954,t:1526930225954};\\\", \\\"{x:1493,y:962,t:1526930225972};\\\", \\\"{x:1493,y:965,t:1526930225988};\\\", \\\"{x:1492,y:966,t:1526930226091};\\\", \\\"{x:1491,y:966,t:1526930226107};\\\", \\\"{x:1489,y:964,t:1526930226123};\\\", \\\"{x:1489,y:962,t:1526930226138};\\\", \\\"{x:1488,y:958,t:1526930226154};\\\", \\\"{x:1485,y:950,t:1526930226171};\\\", \\\"{x:1481,y:941,t:1526930226187};\\\", \\\"{x:1478,y:933,t:1526930226204};\\\", \\\"{x:1475,y:927,t:1526930226221};\\\", \\\"{x:1474,y:920,t:1526930226238};\\\", \\\"{x:1472,y:913,t:1526930226254};\\\", \\\"{x:1472,y:904,t:1526930226271};\\\", \\\"{x:1470,y:894,t:1526930226288};\\\", \\\"{x:1470,y:884,t:1526930226304};\\\", \\\"{x:1470,y:877,t:1526930226321};\\\", \\\"{x:1470,y:868,t:1526930226337};\\\", \\\"{x:1471,y:856,t:1526930226355};\\\", \\\"{x:1477,y:833,t:1526930226372};\\\", \\\"{x:1485,y:817,t:1526930226388};\\\", \\\"{x:1492,y:806,t:1526930226404};\\\", \\\"{x:1499,y:798,t:1526930226421};\\\", \\\"{x:1513,y:789,t:1526930226438};\\\", \\\"{x:1529,y:782,t:1526930226455};\\\", \\\"{x:1548,y:772,t:1526930226471};\\\", \\\"{x:1569,y:759,t:1526930226488};\\\", \\\"{x:1587,y:749,t:1526930226504};\\\", \\\"{x:1601,y:741,t:1526930226521};\\\", \\\"{x:1613,y:737,t:1526930226538};\\\", \\\"{x:1622,y:732,t:1526930226555};\\\", \\\"{x:1624,y:730,t:1526930226572};\\\", \\\"{x:1627,y:726,t:1526930226588};\\\", \\\"{x:1629,y:725,t:1526930226606};\\\", \\\"{x:1632,y:722,t:1526930226621};\\\", \\\"{x:1633,y:719,t:1526930226638};\\\", \\\"{x:1634,y:715,t:1526930226656};\\\", \\\"{x:1634,y:707,t:1526930226671};\\\", \\\"{x:1634,y:703,t:1526930226688};\\\", \\\"{x:1629,y:695,t:1526930226704};\\\", \\\"{x:1627,y:692,t:1526930226721};\\\", \\\"{x:1626,y:691,t:1526930226885};\\\", \\\"{x:1625,y:691,t:1526930226899};\\\", \\\"{x:1625,y:690,t:1526930226923};\\\", \\\"{x:1624,y:690,t:1526930227036};\\\", \\\"{x:1623,y:690,t:1526930227044};\\\", \\\"{x:1622,y:690,t:1526930227056};\\\", \\\"{x:1619,y:688,t:1526930227071};\\\", \\\"{x:1616,y:688,t:1526930227088};\\\", \\\"{x:1615,y:688,t:1526930227105};\\\", \\\"{x:1613,y:687,t:1526930227122};\\\", \\\"{x:1612,y:687,t:1526930227147};\\\", \\\"{x:1611,y:687,t:1526930227156};\\\", \\\"{x:1603,y:689,t:1526930227173};\\\", \\\"{x:1588,y:703,t:1526930227188};\\\", \\\"{x:1571,y:724,t:1526930227205};\\\", \\\"{x:1554,y:750,t:1526930227222};\\\", \\\"{x:1537,y:775,t:1526930227238};\\\", \\\"{x:1525,y:795,t:1526930227255};\\\", \\\"{x:1510,y:821,t:1526930227272};\\\", \\\"{x:1505,y:838,t:1526930227288};\\\", \\\"{x:1502,y:849,t:1526930227305};\\\", \\\"{x:1501,y:858,t:1526930227322};\\\", \\\"{x:1498,y:862,t:1526930227338};\\\", \\\"{x:1497,y:864,t:1526930227355};\\\", \\\"{x:1495,y:865,t:1526930227372};\\\", \\\"{x:1489,y:865,t:1526930227388};\\\", \\\"{x:1481,y:861,t:1526930227405};\\\", \\\"{x:1471,y:858,t:1526930227422};\\\", \\\"{x:1465,y:858,t:1526930227438};\\\", \\\"{x:1464,y:857,t:1526930227508};\\\", \\\"{x:1464,y:855,t:1526930227522};\\\", \\\"{x:1464,y:853,t:1526930227538};\\\", \\\"{x:1467,y:848,t:1526930227556};\\\", \\\"{x:1471,y:844,t:1526930227572};\\\", \\\"{x:1476,y:838,t:1526930227589};\\\", \\\"{x:1481,y:834,t:1526930227606};\\\", \\\"{x:1483,y:832,t:1526930227622};\\\", \\\"{x:1484,y:830,t:1526930227639};\\\", \\\"{x:1484,y:829,t:1526930228685};\\\", \\\"{x:1484,y:827,t:1526930228691};\\\", \\\"{x:1482,y:827,t:1526930228706};\\\", \\\"{x:1481,y:826,t:1526930228723};\\\", \\\"{x:1481,y:825,t:1526930229820};\\\", \\\"{x:1481,y:815,t:1526930229829};\\\", \\\"{x:1480,y:803,t:1526930229841};\\\", \\\"{x:1477,y:781,t:1526930229857};\\\", \\\"{x:1474,y:759,t:1526930229874};\\\", \\\"{x:1470,y:738,t:1526930229890};\\\", \\\"{x:1465,y:710,t:1526930229908};\\\", \\\"{x:1462,y:691,t:1526930229923};\\\", \\\"{x:1458,y:676,t:1526930229941};\\\", \\\"{x:1454,y:667,t:1526930229958};\\\", \\\"{x:1453,y:660,t:1526930229974};\\\", \\\"{x:1450,y:654,t:1526930229990};\\\", \\\"{x:1447,y:648,t:1526930230008};\\\", \\\"{x:1446,y:643,t:1526930230024};\\\", \\\"{x:1441,y:634,t:1526930230041};\\\", \\\"{x:1439,y:627,t:1526930230058};\\\", \\\"{x:1436,y:622,t:1526930230074};\\\", \\\"{x:1433,y:615,t:1526930230091};\\\", \\\"{x:1431,y:611,t:1526930230108};\\\", \\\"{x:1431,y:609,t:1526930230124};\\\", \\\"{x:1430,y:608,t:1526930230148};\\\", \\\"{x:1430,y:607,t:1526930230180};\\\", \\\"{x:1430,y:606,t:1526930230212};\\\", \\\"{x:1429,y:606,t:1526930230224};\\\", \\\"{x:1428,y:606,t:1526930230240};\\\", \\\"{x:1428,y:605,t:1526930230258};\\\", \\\"{x:1427,y:604,t:1526930230274};\\\", \\\"{x:1426,y:603,t:1526930230290};\\\", \\\"{x:1423,y:600,t:1526930230308};\\\", \\\"{x:1421,y:598,t:1526930230324};\\\", \\\"{x:1420,y:597,t:1526930230341};\\\", \\\"{x:1418,y:595,t:1526930230358};\\\", \\\"{x:1416,y:590,t:1526930230375};\\\", \\\"{x:1414,y:584,t:1526930230390};\\\", \\\"{x:1412,y:576,t:1526930230407};\\\", \\\"{x:1409,y:570,t:1526930230425};\\\", \\\"{x:1406,y:566,t:1526930230440};\\\", \\\"{x:1406,y:561,t:1526930230457};\\\", \\\"{x:1406,y:560,t:1526930230474};\\\", \\\"{x:1406,y:558,t:1526930230491};\\\", \\\"{x:1406,y:556,t:1526930230508};\\\", \\\"{x:1406,y:555,t:1526930230531};\\\", \\\"{x:1405,y:560,t:1526930231556};\\\", \\\"{x:1403,y:565,t:1526930231563};\\\", \\\"{x:1402,y:571,t:1526930231575};\\\", \\\"{x:1402,y:581,t:1526930231591};\\\", \\\"{x:1402,y:585,t:1526930231609};\\\", \\\"{x:1401,y:589,t:1526930231625};\\\", \\\"{x:1401,y:593,t:1526930231642};\\\", \\\"{x:1401,y:602,t:1526930231659};\\\", \\\"{x:1401,y:617,t:1526930231674};\\\", \\\"{x:1405,y:648,t:1526930231691};\\\", \\\"{x:1407,y:674,t:1526930231708};\\\", \\\"{x:1407,y:697,t:1526930231724};\\\", \\\"{x:1407,y:721,t:1526930231742};\\\", \\\"{x:1407,y:746,t:1526930231758};\\\", \\\"{x:1407,y:775,t:1526930231776};\\\", \\\"{x:1407,y:807,t:1526930231792};\\\", \\\"{x:1411,y:843,t:1526930231808};\\\", \\\"{x:1416,y:885,t:1526930231824};\\\", \\\"{x:1422,y:919,t:1526930231841};\\\", \\\"{x:1426,y:941,t:1526930231858};\\\", \\\"{x:1429,y:966,t:1526930231874};\\\", \\\"{x:1432,y:975,t:1526930231891};\\\", \\\"{x:1432,y:980,t:1526930231908};\\\", \\\"{x:1433,y:988,t:1526930231925};\\\", \\\"{x:1433,y:994,t:1526930231941};\\\", \\\"{x:1435,y:999,t:1526930231958};\\\", \\\"{x:1436,y:1003,t:1526930231975};\\\", \\\"{x:1436,y:1005,t:1526930231991};\\\", \\\"{x:1436,y:1009,t:1526930232008};\\\", \\\"{x:1436,y:1010,t:1526930232025};\\\", \\\"{x:1436,y:1011,t:1526930232041};\\\", \\\"{x:1436,y:1008,t:1526930232140};\\\", \\\"{x:1435,y:1004,t:1526930232148};\\\", \\\"{x:1434,y:1000,t:1526930232158};\\\", \\\"{x:1432,y:996,t:1526930232176};\\\", \\\"{x:1431,y:994,t:1526930232196};\\\", \\\"{x:1430,y:990,t:1526930232213};\\\", \\\"{x:1430,y:989,t:1526930232229};\\\", \\\"{x:1430,y:988,t:1526930232248};\\\", \\\"{x:1430,y:987,t:1526930232264};\\\", \\\"{x:1430,y:986,t:1526930232280};\\\", \\\"{x:1429,y:985,t:1526930232296};\\\", \\\"{x:1429,y:984,t:1526930232313};\\\", \\\"{x:1429,y:983,t:1526930232329};\\\", \\\"{x:1429,y:981,t:1526930232346};\\\", \\\"{x:1428,y:981,t:1526930232362};\\\", \\\"{x:1428,y:980,t:1526930232383};\\\", \\\"{x:1427,y:978,t:1526930232407};\\\", \\\"{x:1427,y:977,t:1526930232415};\\\", \\\"{x:1427,y:976,t:1526930232429};\\\", \\\"{x:1426,y:975,t:1526930232446};\\\", \\\"{x:1425,y:974,t:1526930232462};\\\", \\\"{x:1425,y:973,t:1526930232519};\\\", \\\"{x:1425,y:972,t:1526930232551};\\\", \\\"{x:1425,y:970,t:1526930232615};\\\", \\\"{x:1425,y:969,t:1526930232647};\\\", \\\"{x:1424,y:968,t:1526930232663};\\\", \\\"{x:1424,y:967,t:1526930232776};\\\", \\\"{x:1422,y:966,t:1526930232792};\\\", \\\"{x:1420,y:965,t:1526930232800};\\\", \\\"{x:1418,y:963,t:1526930232814};\\\", \\\"{x:1413,y:962,t:1526930232830};\\\", \\\"{x:1410,y:958,t:1526930232847};\\\", \\\"{x:1406,y:950,t:1526930232864};\\\", \\\"{x:1400,y:943,t:1526930232879};\\\", \\\"{x:1393,y:931,t:1526930232897};\\\", \\\"{x:1389,y:908,t:1526930232914};\\\", \\\"{x:1384,y:875,t:1526930232930};\\\", \\\"{x:1376,y:824,t:1526930232946};\\\", \\\"{x:1368,y:771,t:1526930232964};\\\", \\\"{x:1354,y:713,t:1526930232980};\\\", \\\"{x:1348,y:685,t:1526930232996};\\\", \\\"{x:1348,y:659,t:1526930233015};\\\", \\\"{x:1349,y:643,t:1526930233030};\\\", \\\"{x:1352,y:634,t:1526930233047};\\\", \\\"{x:1354,y:630,t:1526930233064};\\\", \\\"{x:1355,y:629,t:1526930233177};\\\", \\\"{x:1356,y:629,t:1526930233192};\\\", \\\"{x:1359,y:632,t:1526930233200};\\\", \\\"{x:1359,y:643,t:1526930233213};\\\", \\\"{x:1362,y:683,t:1526930233230};\\\", \\\"{x:1364,y:718,t:1526930233247};\\\", \\\"{x:1372,y:766,t:1526930233263};\\\", \\\"{x:1377,y:797,t:1526930233280};\\\", \\\"{x:1380,y:822,t:1526930233297};\\\", \\\"{x:1382,y:840,t:1526930233314};\\\", \\\"{x:1383,y:850,t:1526930233330};\\\", \\\"{x:1383,y:858,t:1526930233346};\\\", \\\"{x:1383,y:865,t:1526930233364};\\\", \\\"{x:1383,y:872,t:1526930233381};\\\", \\\"{x:1383,y:877,t:1526930233397};\\\", \\\"{x:1383,y:880,t:1526930233414};\\\", \\\"{x:1383,y:884,t:1526930233431};\\\", \\\"{x:1383,y:889,t:1526930233447};\\\", \\\"{x:1383,y:895,t:1526930233464};\\\", \\\"{x:1383,y:896,t:1526930233480};\\\", \\\"{x:1383,y:897,t:1526930233872};\\\", \\\"{x:1382,y:897,t:1526930233880};\\\", \\\"{x:1379,y:897,t:1526930233897};\\\", \\\"{x:1374,y:886,t:1526930233913};\\\", \\\"{x:1367,y:865,t:1526930233930};\\\", \\\"{x:1356,y:831,t:1526930233947};\\\", \\\"{x:1347,y:800,t:1526930233963};\\\", \\\"{x:1336,y:775,t:1526930233980};\\\", \\\"{x:1329,y:757,t:1526930233997};\\\", \\\"{x:1326,y:747,t:1526930234013};\\\", \\\"{x:1326,y:743,t:1526930234030};\\\", \\\"{x:1326,y:739,t:1526930234047};\\\", \\\"{x:1327,y:739,t:1526930234096};\\\", \\\"{x:1328,y:739,t:1526930234103};\\\", \\\"{x:1329,y:739,t:1526930234120};\\\", \\\"{x:1330,y:739,t:1526930234130};\\\", \\\"{x:1333,y:739,t:1526930234148};\\\", \\\"{x:1336,y:739,t:1526930234164};\\\", \\\"{x:1339,y:739,t:1526930234181};\\\", \\\"{x:1340,y:739,t:1526930234199};\\\", \\\"{x:1341,y:739,t:1526930234213};\\\", \\\"{x:1342,y:739,t:1526930234232};\\\", \\\"{x:1342,y:741,t:1526930234248};\\\", \\\"{x:1343,y:746,t:1526930234264};\\\", \\\"{x:1343,y:751,t:1526930234281};\\\", \\\"{x:1343,y:752,t:1526930234298};\\\", \\\"{x:1343,y:753,t:1526930234314};\\\", \\\"{x:1343,y:754,t:1526930234330};\\\", \\\"{x:1343,y:755,t:1526930234347};\\\", \\\"{x:1343,y:756,t:1526930234364};\\\", \\\"{x:1343,y:757,t:1526930234381};\\\", \\\"{x:1343,y:758,t:1526930234528};\\\", \\\"{x:1344,y:759,t:1526930234552};\\\", \\\"{x:1345,y:760,t:1526930234565};\\\", \\\"{x:1345,y:761,t:1526930234581};\\\", \\\"{x:1346,y:763,t:1526930234598};\\\", \\\"{x:1347,y:765,t:1526930234615};\\\", \\\"{x:1347,y:766,t:1526930234640};\\\", \\\"{x:1348,y:766,t:1526930235272};\\\", \\\"{x:1348,y:768,t:1526930235281};\\\", \\\"{x:1348,y:772,t:1526930235299};\\\", \\\"{x:1348,y:775,t:1526930235315};\\\", \\\"{x:1348,y:776,t:1526930235384};\\\", \\\"{x:1348,y:778,t:1526930235399};\\\", \\\"{x:1348,y:779,t:1526930235415};\\\", \\\"{x:1348,y:780,t:1526930235432};\\\", \\\"{x:1348,y:781,t:1526930235449};\\\", \\\"{x:1348,y:782,t:1526930235577};\\\", \\\"{x:1348,y:783,t:1526930235616};\\\", \\\"{x:1348,y:784,t:1526930235639};\\\", \\\"{x:1348,y:785,t:1526930235680};\\\", \\\"{x:1348,y:786,t:1526930235689};\\\", \\\"{x:1348,y:788,t:1526930235704};\\\", \\\"{x:1348,y:790,t:1526930235728};\\\", \\\"{x:1348,y:791,t:1526930235736};\\\", \\\"{x:1348,y:793,t:1526930235752};\\\", \\\"{x:1348,y:794,t:1526930235768};\\\", \\\"{x:1348,y:796,t:1526930235784};\\\", \\\"{x:1348,y:797,t:1526930235800};\\\", \\\"{x:1348,y:799,t:1526930236120};\\\", \\\"{x:1348,y:804,t:1526930236132};\\\", \\\"{x:1348,y:820,t:1526930236149};\\\", \\\"{x:1348,y:836,t:1526930236166};\\\", \\\"{x:1348,y:851,t:1526930236182};\\\", \\\"{x:1348,y:864,t:1526930236199};\\\", \\\"{x:1348,y:878,t:1526930236216};\\\", \\\"{x:1348,y:886,t:1526930236231};\\\", \\\"{x:1348,y:893,t:1526930236248};\\\", \\\"{x:1348,y:898,t:1526930236266};\\\", \\\"{x:1348,y:902,t:1526930236282};\\\", \\\"{x:1348,y:908,t:1526930236299};\\\", \\\"{x:1348,y:912,t:1526930236316};\\\", \\\"{x:1348,y:917,t:1526930236332};\\\", \\\"{x:1348,y:923,t:1526930236349};\\\", \\\"{x:1348,y:928,t:1526930236366};\\\", \\\"{x:1348,y:932,t:1526930236382};\\\", \\\"{x:1348,y:939,t:1526930236398};\\\", \\\"{x:1348,y:952,t:1526930236416};\\\", \\\"{x:1349,y:955,t:1526930236433};\\\", \\\"{x:1349,y:959,t:1526930236448};\\\", \\\"{x:1350,y:962,t:1526930236466};\\\", \\\"{x:1350,y:964,t:1526930236483};\\\", \\\"{x:1350,y:965,t:1526930236499};\\\", \\\"{x:1350,y:969,t:1526930236516};\\\", \\\"{x:1352,y:971,t:1526930236533};\\\", \\\"{x:1352,y:972,t:1526930236548};\\\", \\\"{x:1352,y:969,t:1526930236704};\\\", \\\"{x:1352,y:965,t:1526930236716};\\\", \\\"{x:1349,y:949,t:1526930236733};\\\", \\\"{x:1344,y:939,t:1526930236749};\\\", \\\"{x:1340,y:926,t:1526930236766};\\\", \\\"{x:1335,y:911,t:1526930236783};\\\", \\\"{x:1331,y:893,t:1526930236798};\\\", \\\"{x:1326,y:873,t:1526930236816};\\\", \\\"{x:1325,y:861,t:1526930236833};\\\", \\\"{x:1322,y:850,t:1526930236848};\\\", \\\"{x:1322,y:836,t:1526930236865};\\\", \\\"{x:1322,y:817,t:1526930236882};\\\", \\\"{x:1320,y:795,t:1526930236899};\\\", \\\"{x:1320,y:781,t:1526930236915};\\\", \\\"{x:1320,y:771,t:1526930236932};\\\", \\\"{x:1320,y:763,t:1526930236949};\\\", \\\"{x:1321,y:757,t:1526930236966};\\\", \\\"{x:1326,y:749,t:1526930236983};\\\", \\\"{x:1330,y:737,t:1526930236999};\\\", \\\"{x:1333,y:732,t:1526930237015};\\\", \\\"{x:1336,y:732,t:1526930237033};\\\", \\\"{x:1338,y:730,t:1526930237050};\\\", \\\"{x:1339,y:730,t:1526930237089};\\\", \\\"{x:1340,y:730,t:1526930237103};\\\", \\\"{x:1341,y:730,t:1526930237116};\\\", \\\"{x:1344,y:730,t:1526930237133};\\\", \\\"{x:1345,y:730,t:1526930237150};\\\", \\\"{x:1346,y:731,t:1526930237165};\\\", \\\"{x:1346,y:733,t:1526930237183};\\\", \\\"{x:1346,y:751,t:1526930237199};\\\", \\\"{x:1346,y:759,t:1526930237216};\\\", \\\"{x:1346,y:762,t:1526930237232};\\\", \\\"{x:1347,y:761,t:1526930237336};\\\", \\\"{x:1348,y:753,t:1526930237351};\\\", \\\"{x:1348,y:732,t:1526930237367};\\\", \\\"{x:1348,y:714,t:1526930237383};\\\", \\\"{x:1348,y:694,t:1526930237400};\\\", \\\"{x:1348,y:688,t:1526930237417};\\\", \\\"{x:1348,y:685,t:1526930237433};\\\", \\\"{x:1349,y:685,t:1526930237496};\\\", \\\"{x:1350,y:684,t:1526930237728};\\\", \\\"{x:1349,y:684,t:1526930237752};\\\", \\\"{x:1348,y:683,t:1526930237767};\\\", \\\"{x:1343,y:680,t:1526930237782};\\\", \\\"{x:1326,y:660,t:1526930237800};\\\", \\\"{x:1309,y:640,t:1526930237817};\\\", \\\"{x:1289,y:620,t:1526930237833};\\\", \\\"{x:1268,y:603,t:1526930237849};\\\", \\\"{x:1255,y:590,t:1526930237867};\\\", \\\"{x:1248,y:584,t:1526930237883};\\\", \\\"{x:1249,y:584,t:1526930237912};\\\", \\\"{x:1253,y:584,t:1526930237919};\\\", \\\"{x:1258,y:588,t:1526930237933};\\\", \\\"{x:1261,y:589,t:1526930237950};\\\", \\\"{x:1265,y:591,t:1526930237967};\\\", \\\"{x:1274,y:609,t:1526930237983};\\\", \\\"{x:1279,y:632,t:1526930238000};\\\", \\\"{x:1286,y:662,t:1526930238017};\\\", \\\"{x:1294,y:689,t:1526930238034};\\\", \\\"{x:1299,y:701,t:1526930238050};\\\", \\\"{x:1303,y:707,t:1526930238066};\\\", \\\"{x:1306,y:709,t:1526930238084};\\\", \\\"{x:1308,y:710,t:1526930238144};\\\", \\\"{x:1310,y:710,t:1526930238159};\\\", \\\"{x:1313,y:711,t:1526930238167};\\\", \\\"{x:1314,y:712,t:1526930238183};\\\", \\\"{x:1315,y:712,t:1526930238199};\\\", \\\"{x:1319,y:712,t:1526930238217};\\\", \\\"{x:1320,y:711,t:1526930238240};\\\", \\\"{x:1323,y:711,t:1526930238250};\\\", \\\"{x:1328,y:709,t:1526930238267};\\\", \\\"{x:1333,y:707,t:1526930238284};\\\", \\\"{x:1339,y:704,t:1526930238300};\\\", \\\"{x:1343,y:703,t:1526930238317};\\\", \\\"{x:1345,y:700,t:1526930238334};\\\", \\\"{x:1349,y:697,t:1526930238350};\\\", \\\"{x:1350,y:697,t:1526930238366};\\\", \\\"{x:1350,y:696,t:1526930238383};\\\", \\\"{x:1350,y:695,t:1526930238431};\\\", \\\"{x:1350,y:694,t:1526930238447};\\\", \\\"{x:1350,y:693,t:1526930238471};\\\", \\\"{x:1349,y:693,t:1526930238484};\\\", \\\"{x:1347,y:691,t:1526930238502};\\\", \\\"{x:1346,y:691,t:1526930238728};\\\", \\\"{x:1346,y:695,t:1526930238736};\\\", \\\"{x:1346,y:704,t:1526930238752};\\\", \\\"{x:1346,y:717,t:1526930238767};\\\", \\\"{x:1346,y:747,t:1526930238783};\\\", \\\"{x:1346,y:773,t:1526930238801};\\\", \\\"{x:1346,y:795,t:1526930238817};\\\", \\\"{x:1346,y:817,t:1526930238834};\\\", \\\"{x:1349,y:840,t:1526930238851};\\\", \\\"{x:1353,y:860,t:1526930238867};\\\", \\\"{x:1354,y:870,t:1526930238884};\\\", \\\"{x:1355,y:875,t:1526930238901};\\\", \\\"{x:1355,y:879,t:1526930238917};\\\", \\\"{x:1355,y:881,t:1526930238934};\\\", \\\"{x:1355,y:882,t:1526930238951};\\\", \\\"{x:1355,y:885,t:1526930238967};\\\", \\\"{x:1355,y:895,t:1526930238984};\\\", \\\"{x:1353,y:901,t:1526930239001};\\\", \\\"{x:1353,y:908,t:1526930239017};\\\", \\\"{x:1353,y:915,t:1526930239034};\\\", \\\"{x:1353,y:921,t:1526930239051};\\\", \\\"{x:1353,y:926,t:1526930239068};\\\", \\\"{x:1353,y:932,t:1526930239084};\\\", \\\"{x:1352,y:940,t:1526930239101};\\\", \\\"{x:1352,y:944,t:1526930239117};\\\", \\\"{x:1351,y:949,t:1526930239133};\\\", \\\"{x:1349,y:954,t:1526930239150};\\\", \\\"{x:1349,y:959,t:1526930239167};\\\", \\\"{x:1349,y:962,t:1526930239183};\\\", \\\"{x:1348,y:964,t:1526930239201};\\\", \\\"{x:1345,y:959,t:1526930239255};\\\", \\\"{x:1343,y:952,t:1526930239267};\\\", \\\"{x:1334,y:930,t:1526930239284};\\\", \\\"{x:1312,y:896,t:1526930239300};\\\", \\\"{x:1269,y:846,t:1526930239318};\\\", \\\"{x:1207,y:798,t:1526930239333};\\\", \\\"{x:1104,y:747,t:1526930239350};\\\", \\\"{x:924,y:680,t:1526930239368};\\\", \\\"{x:805,y:646,t:1526930239384};\\\", \\\"{x:710,y:627,t:1526930239401};\\\", \\\"{x:654,y:612,t:1526930239417};\\\", \\\"{x:630,y:604,t:1526930239433};\\\", \\\"{x:623,y:600,t:1526930239453};\\\", \\\"{x:623,y:599,t:1526930239478};\\\", \\\"{x:623,y:597,t:1526930239487};\\\", \\\"{x:623,y:594,t:1526930239502};\\\", \\\"{x:623,y:585,t:1526930239519};\\\", \\\"{x:621,y:576,t:1526930239535};\\\", \\\"{x:619,y:565,t:1526930239552};\\\", \\\"{x:617,y:558,t:1526930239569};\\\", \\\"{x:617,y:556,t:1526930239585};\\\", \\\"{x:618,y:554,t:1526930239603};\\\", \\\"{x:622,y:554,t:1526930239618};\\\", \\\"{x:624,y:554,t:1526930239635};\\\", \\\"{x:624,y:553,t:1526930239663};\\\", \\\"{x:624,y:552,t:1526930239679};\\\", \\\"{x:621,y:550,t:1526930239687};\\\", \\\"{x:617,y:548,t:1526930239703};\\\", \\\"{x:590,y:543,t:1526930239720};\\\", \\\"{x:564,y:543,t:1526930239736};\\\", \\\"{x:541,y:543,t:1526930239753};\\\", \\\"{x:533,y:542,t:1526930239770};\\\", \\\"{x:536,y:543,t:1526930239791};\\\", \\\"{x:542,y:543,t:1526930239802};\\\", \\\"{x:554,y:543,t:1526930239819};\\\", \\\"{x:563,y:541,t:1526930239835};\\\", \\\"{x:566,y:541,t:1526930239853};\\\", \\\"{x:568,y:540,t:1526930239870};\\\", \\\"{x:569,y:538,t:1526930239886};\\\", \\\"{x:571,y:536,t:1526930239903};\\\", \\\"{x:574,y:535,t:1526930239919};\\\", \\\"{x:575,y:534,t:1526930239936};\\\", \\\"{x:575,y:532,t:1526930239992};\\\", \\\"{x:570,y:532,t:1526930240003};\\\", \\\"{x:548,y:527,t:1526930240019};\\\", \\\"{x:506,y:527,t:1526930240036};\\\", \\\"{x:426,y:527,t:1526930240057};\\\", \\\"{x:367,y:527,t:1526930240070};\\\", \\\"{x:359,y:525,t:1526930240086};\\\", \\\"{x:360,y:525,t:1526930240103};\\\", \\\"{x:362,y:523,t:1526930240120};\\\", \\\"{x:365,y:525,t:1526930240136};\\\", \\\"{x:366,y:526,t:1526930240152};\\\", \\\"{x:367,y:527,t:1526930240169};\\\", \\\"{x:368,y:527,t:1526930240206};\\\", \\\"{x:369,y:527,t:1526930240231};\\\", \\\"{x:371,y:527,t:1526930240247};\\\", \\\"{x:372,y:527,t:1526930240255};\\\", \\\"{x:373,y:528,t:1526930240270};\\\", \\\"{x:375,y:530,t:1526930240286};\\\", \\\"{x:386,y:543,t:1526930240302};\\\", \\\"{x:393,y:554,t:1526930240319};\\\", \\\"{x:399,y:563,t:1526930240337};\\\", \\\"{x:401,y:572,t:1526930240352};\\\", \\\"{x:404,y:586,t:1526930240369};\\\", \\\"{x:407,y:595,t:1526930240387};\\\", \\\"{x:409,y:601,t:1526930240403};\\\", \\\"{x:418,y:611,t:1526930240419};\\\", \\\"{x:433,y:620,t:1526930240437};\\\", \\\"{x:451,y:625,t:1526930240454};\\\", \\\"{x:485,y:626,t:1526930240469};\\\", \\\"{x:574,y:626,t:1526930240487};\\\", \\\"{x:773,y:626,t:1526930240503};\\\", \\\"{x:950,y:626,t:1526930240519};\\\", \\\"{x:1072,y:626,t:1526930240538};\\\", \\\"{x:1138,y:626,t:1526930240553};\\\", \\\"{x:1150,y:626,t:1526930240570};\\\", \\\"{x:1146,y:624,t:1526930240587};\\\", \\\"{x:1128,y:616,t:1526930240603};\\\", \\\"{x:1115,y:608,t:1526930240620};\\\", \\\"{x:1090,y:598,t:1526930240637};\\\", \\\"{x:1066,y:588,t:1526930240654};\\\", \\\"{x:1051,y:579,t:1526930240670};\\\", \\\"{x:1029,y:566,t:1526930240687};\\\", \\\"{x:1010,y:558,t:1526930240704};\\\", \\\"{x:989,y:547,t:1526930240721};\\\", \\\"{x:962,y:537,t:1526930240737};\\\", \\\"{x:939,y:530,t:1526930240755};\\\", \\\"{x:908,y:524,t:1526930240771};\\\", \\\"{x:882,y:519,t:1526930240787};\\\", \\\"{x:865,y:515,t:1526930240804};\\\", \\\"{x:850,y:513,t:1526930240819};\\\", \\\"{x:838,y:510,t:1526930240837};\\\", \\\"{x:832,y:509,t:1526930240853};\\\", \\\"{x:831,y:509,t:1526930240869};\\\", \\\"{x:827,y:509,t:1526930240942};\\\", \\\"{x:828,y:509,t:1526930241624};\\\", \\\"{x:829,y:509,t:1526930241640};\\\", \\\"{x:830,y:509,t:1526930241654};\\\", \\\"{x:831,y:509,t:1526930241671};\\\", \\\"{x:833,y:508,t:1526930241688};\\\", \\\"{x:834,y:508,t:1526930241736};\\\", \\\"{x:835,y:507,t:1526930241768};\\\", \\\"{x:836,y:507,t:1526930241792};\\\", \\\"{x:837,y:506,t:1526930241804};\\\", \\\"{x:840,y:506,t:1526930241880};\\\", \\\"{x:844,y:506,t:1526930241889};\\\", \\\"{x:853,y:509,t:1526930241905};\\\", \\\"{x:859,y:546,t:1526930241921};\\\", \\\"{x:859,y:597,t:1526930241937};\\\", \\\"{x:859,y:639,t:1526930241954};\\\", \\\"{x:855,y:666,t:1526930241971};\\\", \\\"{x:851,y:678,t:1526930241987};\\\", \\\"{x:850,y:681,t:1526930242004};\\\", \\\"{x:850,y:676,t:1526930242038};\\\", \\\"{x:850,y:668,t:1526930242055};\\\", \\\"{x:859,y:631,t:1526930242071};\\\", \\\"{x:864,y:601,t:1526930242088};\\\", \\\"{x:866,y:581,t:1526930242105};\\\", \\\"{x:869,y:562,t:1526930242122};\\\", \\\"{x:871,y:547,t:1526930242138};\\\", \\\"{x:872,y:539,t:1526930242154};\\\", \\\"{x:872,y:533,t:1526930242170};\\\", \\\"{x:872,y:529,t:1526930242187};\\\", \\\"{x:872,y:523,t:1526930242205};\\\", \\\"{x:872,y:518,t:1526930242220};\\\", \\\"{x:872,y:517,t:1526930242239};\\\", \\\"{x:872,y:516,t:1526930242254};\\\", \\\"{x:866,y:516,t:1526930242271};\\\", \\\"{x:847,y:522,t:1526930242290};\\\", \\\"{x:808,y:562,t:1526930242304};\\\", \\\"{x:733,y:616,t:1526930242322};\\\", \\\"{x:619,y:691,t:1526930242338};\\\", \\\"{x:487,y:750,t:1526930242356};\\\", \\\"{x:402,y:784,t:1526930242372};\\\", \\\"{x:392,y:789,t:1526930242388};\\\", \\\"{x:392,y:791,t:1526930242404};\\\", \\\"{x:392,y:792,t:1526930242422};\\\", \\\"{x:393,y:792,t:1526930242437};\\\", \\\"{x:402,y:783,t:1526930242454};\\\", \\\"{x:403,y:780,t:1526930242470};\\\", \\\"{x:403,y:776,t:1526930242487};\\\", \\\"{x:403,y:774,t:1526930242504};\\\", \\\"{x:403,y:773,t:1526930242521};\\\", \\\"{x:405,y:771,t:1526930242537};\\\", \\\"{x:406,y:770,t:1526930242555};\\\", \\\"{x:410,y:768,t:1526930242571};\\\", \\\"{x:413,y:765,t:1526930242587};\\\", \\\"{x:416,y:762,t:1526930242605};\\\", \\\"{x:420,y:759,t:1526930242621};\\\", \\\"{x:423,y:757,t:1526930242638};\\\", \\\"{x:430,y:753,t:1526930242655};\\\", \\\"{x:449,y:737,t:1526930242672};\\\", \\\"{x:469,y:727,t:1526930242688};\\\", \\\"{x:481,y:722,t:1526930242703};\\\", \\\"{x:484,y:722,t:1526930242720};\\\", \\\"{x:485,y:722,t:1526930243015};\\\", \\\"{x:493,y:722,t:1526930243023};\\\", \\\"{x:504,y:725,t:1526930243039};\\\", \\\"{x:556,y:732,t:1526930243054};\\\", \\\"{x:676,y:732,t:1526930243071};\\\", \\\"{x:776,y:732,t:1526930243088};\\\", \\\"{x:862,y:732,t:1526930243104};\\\", \\\"{x:915,y:732,t:1526930243122};\\\", \\\"{x:940,y:732,t:1526930243139};\\\", \\\"{x:946,y:732,t:1526930243155};\\\" ] }, { \\\"rt\\\": 29205, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 596985, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X -M -M -O -B -B -12 PM-B -E -11 AM-J -E -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:945,y:730,t:1526930244195};\\\", \\\"{x:943,y:730,t:1526930244598};\\\", \\\"{x:941,y:730,t:1526930244606};\\\", \\\"{x:938,y:728,t:1526930244622};\\\", \\\"{x:932,y:726,t:1526930244639};\\\", \\\"{x:919,y:718,t:1526930244656};\\\", \\\"{x:888,y:700,t:1526930244672};\\\", \\\"{x:838,y:666,t:1526930244689};\\\", \\\"{x:773,y:616,t:1526930244707};\\\", \\\"{x:711,y:573,t:1526930244723};\\\", \\\"{x:670,y:548,t:1526930244740};\\\", \\\"{x:650,y:537,t:1526930244756};\\\", \\\"{x:645,y:531,t:1526930244772};\\\", \\\"{x:645,y:528,t:1526930244789};\\\", \\\"{x:646,y:525,t:1526930244806};\\\", \\\"{x:652,y:523,t:1526930244823};\\\", \\\"{x:658,y:523,t:1526930244840};\\\", \\\"{x:670,y:523,t:1526930244857};\\\", \\\"{x:689,y:523,t:1526930244873};\\\", \\\"{x:715,y:524,t:1526930244889};\\\", \\\"{x:768,y:531,t:1526930244907};\\\", \\\"{x:866,y:553,t:1526930244923};\\\", \\\"{x:978,y:573,t:1526930244940};\\\", \\\"{x:1096,y:596,t:1526930244957};\\\", \\\"{x:1200,y:624,t:1526930244973};\\\", \\\"{x:1267,y:644,t:1526930244989};\\\", \\\"{x:1311,y:661,t:1526930245007};\\\", \\\"{x:1318,y:666,t:1526930245024};\\\", \\\"{x:1319,y:666,t:1526930245040};\\\", \\\"{x:1319,y:667,t:1526930245057};\\\", \\\"{x:1319,y:668,t:1526930245074};\\\", \\\"{x:1316,y:668,t:1526930245090};\\\", \\\"{x:1314,y:668,t:1526930245107};\\\", \\\"{x:1316,y:668,t:1526930245480};\\\", \\\"{x:1322,y:672,t:1526930245491};\\\", \\\"{x:1343,y:684,t:1526930245507};\\\", \\\"{x:1387,y:706,t:1526930245524};\\\", \\\"{x:1435,y:730,t:1526930245541};\\\", \\\"{x:1467,y:747,t:1526930245557};\\\", \\\"{x:1498,y:767,t:1526930245575};\\\", \\\"{x:1530,y:797,t:1526930245592};\\\", \\\"{x:1548,y:819,t:1526930245607};\\\", \\\"{x:1567,y:850,t:1526930245624};\\\", \\\"{x:1583,y:876,t:1526930245641};\\\", \\\"{x:1590,y:892,t:1526930245658};\\\", \\\"{x:1593,y:901,t:1526930245674};\\\", \\\"{x:1594,y:907,t:1526930245691};\\\", \\\"{x:1594,y:912,t:1526930245708};\\\", \\\"{x:1594,y:916,t:1526930245724};\\\", \\\"{x:1594,y:919,t:1526930245741};\\\", \\\"{x:1591,y:921,t:1526930245758};\\\", \\\"{x:1583,y:921,t:1526930245774};\\\", \\\"{x:1569,y:921,t:1526930245791};\\\", \\\"{x:1559,y:921,t:1526930245808};\\\", \\\"{x:1547,y:919,t:1526930245824};\\\", \\\"{x:1536,y:917,t:1526930245841};\\\", \\\"{x:1519,y:911,t:1526930245858};\\\", \\\"{x:1498,y:906,t:1526930245874};\\\", \\\"{x:1479,y:901,t:1526930245891};\\\", \\\"{x:1466,y:896,t:1526930245908};\\\", \\\"{x:1457,y:891,t:1526930245924};\\\", \\\"{x:1454,y:888,t:1526930245941};\\\", \\\"{x:1452,y:885,t:1526930245958};\\\", \\\"{x:1452,y:881,t:1526930245975};\\\", \\\"{x:1452,y:873,t:1526930245992};\\\", \\\"{x:1452,y:869,t:1526930246008};\\\", \\\"{x:1452,y:861,t:1526930246025};\\\", \\\"{x:1455,y:855,t:1526930246041};\\\", \\\"{x:1458,y:849,t:1526930246058};\\\", \\\"{x:1464,y:840,t:1526930246075};\\\", \\\"{x:1468,y:835,t:1526930246091};\\\", \\\"{x:1471,y:833,t:1526930246108};\\\", \\\"{x:1473,y:832,t:1526930246126};\\\", \\\"{x:1474,y:832,t:1526930246141};\\\", \\\"{x:1475,y:832,t:1526930246208};\\\", \\\"{x:1477,y:832,t:1526930246227};\\\", \\\"{x:1478,y:832,t:1526930246241};\\\", \\\"{x:1479,y:832,t:1526930246258};\\\", \\\"{x:1480,y:832,t:1526930246424};\\\", \\\"{x:1480,y:833,t:1526930246479};\\\", \\\"{x:1480,y:834,t:1526930246592};\\\", \\\"{x:1480,y:838,t:1526930246609};\\\", \\\"{x:1481,y:843,t:1526930246626};\\\", \\\"{x:1481,y:847,t:1526930246642};\\\", \\\"{x:1481,y:853,t:1526930246658};\\\", \\\"{x:1481,y:858,t:1526930246675};\\\", \\\"{x:1481,y:865,t:1526930246692};\\\", \\\"{x:1481,y:867,t:1526930246708};\\\", \\\"{x:1481,y:868,t:1526930246725};\\\", \\\"{x:1481,y:867,t:1526930246807};\\\", \\\"{x:1481,y:864,t:1526930246815};\\\", \\\"{x:1481,y:859,t:1526930246825};\\\", \\\"{x:1480,y:851,t:1526930246842};\\\", \\\"{x:1480,y:846,t:1526930246859};\\\", \\\"{x:1480,y:842,t:1526930246874};\\\", \\\"{x:1480,y:841,t:1526930246892};\\\", \\\"{x:1480,y:839,t:1526930246909};\\\", \\\"{x:1480,y:838,t:1526930246924};\\\", \\\"{x:1480,y:837,t:1526930246941};\\\", \\\"{x:1478,y:837,t:1526930247032};\\\", \\\"{x:1472,y:841,t:1526930247042};\\\", \\\"{x:1455,y:859,t:1526930247059};\\\", \\\"{x:1438,y:875,t:1526930247075};\\\", \\\"{x:1422,y:889,t:1526930247092};\\\", \\\"{x:1410,y:896,t:1526930247109};\\\", \\\"{x:1402,y:902,t:1526930247125};\\\", \\\"{x:1402,y:903,t:1526930247160};\\\", \\\"{x:1402,y:904,t:1526930247216};\\\", \\\"{x:1398,y:906,t:1526930247280};\\\", \\\"{x:1395,y:906,t:1526930247292};\\\", \\\"{x:1387,y:906,t:1526930247310};\\\", \\\"{x:1381,y:906,t:1526930247326};\\\", \\\"{x:1375,y:906,t:1526930247342};\\\", \\\"{x:1374,y:906,t:1526930247360};\\\", \\\"{x:1373,y:906,t:1526930247416};\\\", \\\"{x:1373,y:904,t:1526930247431};\\\", \\\"{x:1374,y:902,t:1526930247448};\\\", \\\"{x:1376,y:901,t:1526930247459};\\\", \\\"{x:1378,y:898,t:1526930247477};\\\", \\\"{x:1380,y:896,t:1526930247492};\\\", \\\"{x:1382,y:895,t:1526930247509};\\\", \\\"{x:1382,y:894,t:1526930247526};\\\", \\\"{x:1382,y:893,t:1526930247920};\\\", \\\"{x:1382,y:889,t:1526930247928};\\\", \\\"{x:1383,y:877,t:1526930247944};\\\", \\\"{x:1383,y:864,t:1526930247959};\\\", \\\"{x:1380,y:850,t:1526930247976};\\\", \\\"{x:1373,y:836,t:1526930247993};\\\", \\\"{x:1361,y:820,t:1526930248010};\\\", \\\"{x:1351,y:805,t:1526930248026};\\\", \\\"{x:1343,y:794,t:1526930248043};\\\", \\\"{x:1339,y:788,t:1526930248060};\\\", \\\"{x:1338,y:787,t:1526930248076};\\\", \\\"{x:1338,y:786,t:1526930248111};\\\", \\\"{x:1339,y:785,t:1526930248136};\\\", \\\"{x:1341,y:785,t:1526930248151};\\\", \\\"{x:1343,y:785,t:1526930248159};\\\", \\\"{x:1356,y:784,t:1526930248176};\\\", \\\"{x:1372,y:784,t:1526930248193};\\\", \\\"{x:1397,y:781,t:1526930248210};\\\", \\\"{x:1433,y:775,t:1526930248227};\\\", \\\"{x:1465,y:774,t:1526930248243};\\\", \\\"{x:1489,y:773,t:1526930248260};\\\", \\\"{x:1502,y:773,t:1526930248276};\\\", \\\"{x:1505,y:772,t:1526930248293};\\\", \\\"{x:1505,y:770,t:1526930248311};\\\", \\\"{x:1502,y:768,t:1526930248326};\\\", \\\"{x:1501,y:767,t:1526930248344};\\\", \\\"{x:1499,y:766,t:1526930248368};\\\", \\\"{x:1499,y:765,t:1526930248378};\\\", \\\"{x:1499,y:764,t:1526930248394};\\\", \\\"{x:1500,y:763,t:1526930248410};\\\", \\\"{x:1502,y:763,t:1526930248427};\\\", \\\"{x:1503,y:763,t:1526930248444};\\\", \\\"{x:1504,y:763,t:1526930248520};\\\", \\\"{x:1505,y:763,t:1526930248528};\\\", \\\"{x:1506,y:763,t:1526930248552};\\\", \\\"{x:1507,y:763,t:1526930248624};\\\", \\\"{x:1508,y:763,t:1526930248816};\\\", \\\"{x:1509,y:763,t:1526930248828};\\\", \\\"{x:1510,y:764,t:1526930248860};\\\", \\\"{x:1511,y:764,t:1526930248879};\\\", \\\"{x:1512,y:764,t:1526930248895};\\\", \\\"{x:1509,y:764,t:1526930249064};\\\", \\\"{x:1502,y:763,t:1526930249078};\\\", \\\"{x:1483,y:763,t:1526930249094};\\\", \\\"{x:1459,y:768,t:1526930249112};\\\", \\\"{x:1449,y:775,t:1526930249128};\\\", \\\"{x:1446,y:778,t:1526930249145};\\\", \\\"{x:1445,y:780,t:1526930249161};\\\", \\\"{x:1445,y:781,t:1526930249178};\\\", \\\"{x:1443,y:782,t:1526930249256};\\\", \\\"{x:1440,y:782,t:1526930249271};\\\", \\\"{x:1436,y:782,t:1526930249280};\\\", \\\"{x:1431,y:782,t:1526930249294};\\\", \\\"{x:1404,y:777,t:1526930249312};\\\", \\\"{x:1374,y:772,t:1526930249327};\\\", \\\"{x:1346,y:768,t:1526930249345};\\\", \\\"{x:1316,y:760,t:1526930249362};\\\", \\\"{x:1284,y:749,t:1526930249377};\\\", \\\"{x:1263,y:744,t:1526930249393};\\\", \\\"{x:1251,y:744,t:1526930249411};\\\", \\\"{x:1249,y:743,t:1526930249427};\\\", \\\"{x:1249,y:742,t:1526930249443};\\\", \\\"{x:1250,y:742,t:1526930249462};\\\", \\\"{x:1252,y:742,t:1526930249478};\\\", \\\"{x:1254,y:742,t:1526930249494};\\\", \\\"{x:1269,y:740,t:1526930249511};\\\", \\\"{x:1287,y:740,t:1526930249528};\\\", \\\"{x:1302,y:740,t:1526930249544};\\\", \\\"{x:1310,y:740,t:1526930249561};\\\", \\\"{x:1313,y:740,t:1526930249578};\\\", \\\"{x:1314,y:740,t:1526930249640};\\\", \\\"{x:1318,y:742,t:1526930249647};\\\", \\\"{x:1318,y:743,t:1526930249660};\\\", \\\"{x:1321,y:747,t:1526930249678};\\\", \\\"{x:1324,y:750,t:1526930249694};\\\", \\\"{x:1330,y:755,t:1526930249711};\\\", \\\"{x:1333,y:757,t:1526930249728};\\\", \\\"{x:1337,y:760,t:1526930249744};\\\", \\\"{x:1339,y:761,t:1526930249761};\\\", \\\"{x:1340,y:761,t:1526930249896};\\\", \\\"{x:1341,y:761,t:1526930249911};\\\", \\\"{x:1342,y:760,t:1526930249928};\\\", \\\"{x:1343,y:759,t:1526930249945};\\\", \\\"{x:1344,y:759,t:1526930249961};\\\", \\\"{x:1345,y:759,t:1526930250040};\\\", \\\"{x:1346,y:759,t:1526930250047};\\\", \\\"{x:1347,y:759,t:1526930250061};\\\", \\\"{x:1353,y:766,t:1526930250079};\\\", \\\"{x:1363,y:783,t:1526930250095};\\\", \\\"{x:1367,y:792,t:1526930250111};\\\", \\\"{x:1368,y:797,t:1526930250129};\\\", \\\"{x:1368,y:799,t:1526930250145};\\\", \\\"{x:1368,y:800,t:1526930250184};\\\", \\\"{x:1367,y:799,t:1526930250199};\\\", \\\"{x:1367,y:797,t:1526930250216};\\\", \\\"{x:1365,y:794,t:1526930250229};\\\", \\\"{x:1364,y:788,t:1526930250246};\\\", \\\"{x:1362,y:783,t:1526930250262};\\\", \\\"{x:1360,y:778,t:1526930250278};\\\", \\\"{x:1357,y:774,t:1526930250295};\\\", \\\"{x:1357,y:773,t:1526930250311};\\\", \\\"{x:1357,y:772,t:1526930250328};\\\", \\\"{x:1357,y:771,t:1526930250345};\\\", \\\"{x:1356,y:770,t:1526930250362};\\\", \\\"{x:1355,y:768,t:1526930250408};\\\", \\\"{x:1354,y:767,t:1526930250432};\\\", \\\"{x:1354,y:768,t:1526930250576};\\\", \\\"{x:1354,y:776,t:1526930250584};\\\", \\\"{x:1354,y:781,t:1526930250595};\\\", \\\"{x:1354,y:794,t:1526930250613};\\\", \\\"{x:1354,y:800,t:1526930250630};\\\", \\\"{x:1354,y:805,t:1526930250645};\\\", \\\"{x:1354,y:806,t:1526930250663};\\\", \\\"{x:1354,y:808,t:1526930250679};\\\", \\\"{x:1354,y:809,t:1526930250695};\\\", \\\"{x:1354,y:810,t:1526930250712};\\\", \\\"{x:1354,y:812,t:1526930250729};\\\", \\\"{x:1354,y:813,t:1526930250745};\\\", \\\"{x:1354,y:815,t:1526930250762};\\\", \\\"{x:1354,y:816,t:1526930250780};\\\", \\\"{x:1354,y:821,t:1526930250796};\\\", \\\"{x:1354,y:827,t:1526930250813};\\\", \\\"{x:1354,y:838,t:1526930250829};\\\", \\\"{x:1354,y:848,t:1526930250845};\\\", \\\"{x:1354,y:863,t:1526930250863};\\\", \\\"{x:1354,y:885,t:1526930250880};\\\", \\\"{x:1355,y:903,t:1526930250895};\\\", \\\"{x:1358,y:919,t:1526930250913};\\\", \\\"{x:1359,y:929,t:1526930250930};\\\", \\\"{x:1363,y:940,t:1526930250945};\\\", \\\"{x:1364,y:948,t:1526930250962};\\\", \\\"{x:1366,y:959,t:1526930250979};\\\", \\\"{x:1366,y:963,t:1526930250996};\\\", \\\"{x:1366,y:967,t:1526930251013};\\\", \\\"{x:1366,y:968,t:1526930251029};\\\", \\\"{x:1366,y:970,t:1526930251046};\\\", \\\"{x:1366,y:971,t:1526930251062};\\\", \\\"{x:1366,y:972,t:1526930251080};\\\", \\\"{x:1365,y:972,t:1526930251166};\\\", \\\"{x:1364,y:972,t:1526930251179};\\\", \\\"{x:1358,y:971,t:1526930251195};\\\", \\\"{x:1355,y:969,t:1526930251212};\\\", \\\"{x:1353,y:968,t:1526930251229};\\\", \\\"{x:1353,y:967,t:1526930251616};\\\", \\\"{x:1353,y:965,t:1526930251629};\\\", \\\"{x:1338,y:957,t:1526930251647};\\\", \\\"{x:1271,y:920,t:1526930251664};\\\", \\\"{x:1179,y:877,t:1526930251680};\\\", \\\"{x:1063,y:819,t:1526930251696};\\\", \\\"{x:935,y:750,t:1526930251714};\\\", \\\"{x:803,y:671,t:1526930251729};\\\", \\\"{x:685,y:607,t:1526930251747};\\\", \\\"{x:606,y:560,t:1526930251763};\\\", \\\"{x:568,y:530,t:1526930251796};\\\", \\\"{x:568,y:528,t:1526930251807};\\\", \\\"{x:575,y:527,t:1526930251825};\\\", \\\"{x:584,y:525,t:1526930251841};\\\", \\\"{x:585,y:524,t:1526930251858};\\\", \\\"{x:588,y:521,t:1526930251874};\\\", \\\"{x:592,y:517,t:1526930251895};\\\", \\\"{x:604,y:514,t:1526930251911};\\\", \\\"{x:620,y:513,t:1526930251929};\\\", \\\"{x:643,y:513,t:1526930251945};\\\", \\\"{x:672,y:513,t:1526930251962};\\\", \\\"{x:699,y:513,t:1526930251979};\\\", \\\"{x:724,y:521,t:1526930251996};\\\", \\\"{x:744,y:528,t:1526930252012};\\\", \\\"{x:754,y:533,t:1526930252029};\\\", \\\"{x:758,y:537,t:1526930252045};\\\", \\\"{x:762,y:546,t:1526930252062};\\\", \\\"{x:764,y:557,t:1526930252079};\\\", \\\"{x:766,y:562,t:1526930252095};\\\", \\\"{x:768,y:563,t:1526930252112};\\\", \\\"{x:768,y:564,t:1526930252143};\\\", \\\"{x:773,y:563,t:1526930252151};\\\", \\\"{x:773,y:562,t:1526930252162};\\\", \\\"{x:774,y:561,t:1526930252179};\\\", \\\"{x:775,y:565,t:1526930252481};\\\", \\\"{x:775,y:575,t:1526930252494};\\\", \\\"{x:775,y:583,t:1526930252513};\\\", \\\"{x:775,y:593,t:1526930252529};\\\", \\\"{x:775,y:606,t:1526930252547};\\\", \\\"{x:771,y:615,t:1526930252562};\\\", \\\"{x:766,y:622,t:1526930252579};\\\", \\\"{x:763,y:625,t:1526930252596};\\\", \\\"{x:761,y:627,t:1526930252613};\\\", \\\"{x:766,y:627,t:1526930252672};\\\", \\\"{x:777,y:627,t:1526930252679};\\\", \\\"{x:802,y:621,t:1526930252696};\\\", \\\"{x:826,y:614,t:1526930252714};\\\", \\\"{x:844,y:608,t:1526930252729};\\\", \\\"{x:851,y:603,t:1526930252746};\\\", \\\"{x:853,y:601,t:1526930252763};\\\", \\\"{x:853,y:598,t:1526930252779};\\\", \\\"{x:853,y:593,t:1526930252796};\\\", \\\"{x:851,y:587,t:1526930252813};\\\", \\\"{x:849,y:578,t:1526930252829};\\\", \\\"{x:844,y:568,t:1526930252845};\\\", \\\"{x:833,y:553,t:1526930252863};\\\", \\\"{x:820,y:543,t:1526930252879};\\\", \\\"{x:806,y:531,t:1526930252895};\\\", \\\"{x:771,y:517,t:1526930252914};\\\", \\\"{x:655,y:491,t:1526930252930};\\\", \\\"{x:517,y:476,t:1526930252946};\\\", \\\"{x:371,y:476,t:1526930252963};\\\", \\\"{x:265,y:476,t:1526930252980};\\\", \\\"{x:217,y:483,t:1526930252995};\\\", \\\"{x:204,y:487,t:1526930253013};\\\", \\\"{x:204,y:489,t:1526930253030};\\\", \\\"{x:207,y:491,t:1526930253045};\\\", \\\"{x:224,y:501,t:1526930253063};\\\", \\\"{x:238,y:513,t:1526930253079};\\\", \\\"{x:247,y:525,t:1526930253097};\\\", \\\"{x:257,y:540,t:1526930253113};\\\", \\\"{x:270,y:554,t:1526930253130};\\\", \\\"{x:280,y:561,t:1526930253147};\\\", \\\"{x:288,y:563,t:1526930253164};\\\", \\\"{x:295,y:565,t:1526930253180};\\\", \\\"{x:299,y:566,t:1526930253195};\\\", \\\"{x:301,y:567,t:1526930253213};\\\", \\\"{x:301,y:568,t:1526930253255};\\\", \\\"{x:299,y:569,t:1526930253263};\\\", \\\"{x:279,y:570,t:1526930253280};\\\", \\\"{x:233,y:570,t:1526930253298};\\\", \\\"{x:166,y:570,t:1526930253312};\\\", \\\"{x:140,y:568,t:1526930253330};\\\", \\\"{x:130,y:567,t:1526930253347};\\\", \\\"{x:128,y:566,t:1526930253363};\\\", \\\"{x:128,y:565,t:1526930253379};\\\", \\\"{x:129,y:564,t:1526930253396};\\\", \\\"{x:137,y:563,t:1526930253413};\\\", \\\"{x:146,y:558,t:1526930253431};\\\", \\\"{x:155,y:555,t:1526930253447};\\\", \\\"{x:158,y:553,t:1526930253463};\\\", \\\"{x:158,y:551,t:1526930253487};\\\", \\\"{x:156,y:549,t:1526930253502};\\\", \\\"{x:156,y:548,t:1526930253559};\\\", \\\"{x:157,y:547,t:1526930253599};\\\", \\\"{x:158,y:547,t:1526930253613};\\\", \\\"{x:158,y:546,t:1526930253630};\\\", \\\"{x:159,y:545,t:1526930253647};\\\", \\\"{x:159,y:544,t:1526930253664};\\\", \\\"{x:160,y:544,t:1526930253703};\\\", \\\"{x:161,y:543,t:1526930253719};\\\", \\\"{x:162,y:541,t:1526930253743};\\\", \\\"{x:163,y:541,t:1526930253768};\\\", \\\"{x:171,y:543,t:1526930254184};\\\", \\\"{x:193,y:550,t:1526930254199};\\\", \\\"{x:299,y:582,t:1526930254214};\\\", \\\"{x:459,y:627,t:1526930254230};\\\", \\\"{x:773,y:713,t:1526930254247};\\\", \\\"{x:985,y:769,t:1526930254264};\\\", \\\"{x:1167,y:817,t:1526930254280};\\\", \\\"{x:1299,y:847,t:1526930254297};\\\", \\\"{x:1366,y:866,t:1526930254314};\\\", \\\"{x:1386,y:875,t:1526930254330};\\\", \\\"{x:1388,y:876,t:1526930254346};\\\", \\\"{x:1388,y:877,t:1526930254363};\\\", \\\"{x:1388,y:882,t:1526930254380};\\\", \\\"{x:1388,y:884,t:1526930254398};\\\", \\\"{x:1388,y:887,t:1526930254414};\\\", \\\"{x:1387,y:889,t:1526930254430};\\\", \\\"{x:1386,y:886,t:1526930254520};\\\", \\\"{x:1386,y:877,t:1526930254530};\\\", \\\"{x:1381,y:862,t:1526930254547};\\\", \\\"{x:1375,y:845,t:1526930254563};\\\", \\\"{x:1371,y:830,t:1526930254579};\\\", \\\"{x:1369,y:815,t:1526930254597};\\\", \\\"{x:1365,y:802,t:1526930254612};\\\", \\\"{x:1361,y:790,t:1526930254629};\\\", \\\"{x:1359,y:780,t:1526930254647};\\\", \\\"{x:1359,y:779,t:1526930254662};\\\", \\\"{x:1359,y:777,t:1526930254679};\\\", \\\"{x:1358,y:775,t:1526930254696};\\\", \\\"{x:1358,y:773,t:1526930254727};\\\", \\\"{x:1357,y:771,t:1526930254736};\\\", \\\"{x:1355,y:768,t:1526930254752};\\\", \\\"{x:1354,y:767,t:1526930254763};\\\", \\\"{x:1351,y:765,t:1526930254779};\\\", \\\"{x:1351,y:764,t:1526930254795};\\\", \\\"{x:1349,y:764,t:1526930254815};\\\", \\\"{x:1347,y:764,t:1526930254831};\\\", \\\"{x:1347,y:763,t:1526930254847};\\\", \\\"{x:1346,y:763,t:1526930254951};\\\", \\\"{x:1345,y:763,t:1526930254999};\\\", \\\"{x:1344,y:763,t:1526930255011};\\\", \\\"{x:1335,y:764,t:1526930255029};\\\", \\\"{x:1316,y:778,t:1526930255044};\\\", \\\"{x:1287,y:793,t:1526930255062};\\\", \\\"{x:1240,y:815,t:1526930255078};\\\", \\\"{x:1201,y:826,t:1526930255094};\\\", \\\"{x:1174,y:835,t:1526930255110};\\\", \\\"{x:1169,y:838,t:1526930255127};\\\", \\\"{x:1169,y:839,t:1526930255158};\\\", \\\"{x:1170,y:840,t:1526930255190};\\\", \\\"{x:1171,y:840,t:1526930255215};\\\", \\\"{x:1175,y:839,t:1526930255247};\\\", \\\"{x:1179,y:831,t:1526930255260};\\\", \\\"{x:1190,y:807,t:1526930255277};\\\", \\\"{x:1209,y:762,t:1526930255293};\\\", \\\"{x:1227,y:709,t:1526930255310};\\\", \\\"{x:1240,y:664,t:1526930255326};\\\", \\\"{x:1250,y:633,t:1526930255343};\\\", \\\"{x:1252,y:624,t:1526930255360};\\\", \\\"{x:1254,y:618,t:1526930255377};\\\", \\\"{x:1258,y:616,t:1526930255393};\\\", \\\"{x:1262,y:614,t:1526930255410};\\\", \\\"{x:1269,y:614,t:1526930255425};\\\", \\\"{x:1273,y:613,t:1526930255443};\\\", \\\"{x:1274,y:613,t:1526930255459};\\\", \\\"{x:1274,y:611,t:1526930255510};\\\", \\\"{x:1274,y:610,t:1526930255526};\\\", \\\"{x:1278,y:605,t:1526930255542};\\\", \\\"{x:1283,y:595,t:1526930255558};\\\", \\\"{x:1285,y:590,t:1526930255576};\\\", \\\"{x:1287,y:585,t:1526930255592};\\\", \\\"{x:1287,y:580,t:1526930255609};\\\", \\\"{x:1292,y:578,t:1526930255625};\\\", \\\"{x:1298,y:575,t:1526930255642};\\\", \\\"{x:1304,y:574,t:1526930255659};\\\", \\\"{x:1309,y:572,t:1526930255675};\\\", \\\"{x:1310,y:572,t:1526930255693};\\\", \\\"{x:1310,y:571,t:1526930255768};\\\", \\\"{x:1309,y:570,t:1526930255783};\\\", \\\"{x:1304,y:567,t:1526930255792};\\\", \\\"{x:1291,y:563,t:1526930255809};\\\", \\\"{x:1283,y:559,t:1526930255826};\\\", \\\"{x:1280,y:558,t:1526930255841};\\\", \\\"{x:1281,y:558,t:1526930255904};\\\", \\\"{x:1282,y:558,t:1526930255912};\\\", \\\"{x:1283,y:558,t:1526930255924};\\\", \\\"{x:1283,y:559,t:1526930257039};\\\", \\\"{x:1283,y:576,t:1526930257057};\\\", \\\"{x:1283,y:589,t:1526930257071};\\\", \\\"{x:1283,y:600,t:1526930257087};\\\", \\\"{x:1283,y:604,t:1526930257103};\\\", \\\"{x:1283,y:606,t:1526930257121};\\\", \\\"{x:1283,y:607,t:1526930257256};\\\", \\\"{x:1283,y:610,t:1526930257270};\\\", \\\"{x:1283,y:613,t:1526930257287};\\\", \\\"{x:1282,y:626,t:1526930257303};\\\", \\\"{x:1282,y:639,t:1526930257319};\\\", \\\"{x:1282,y:658,t:1526930257336};\\\", \\\"{x:1282,y:676,t:1526930257352};\\\", \\\"{x:1282,y:689,t:1526930257369};\\\", \\\"{x:1280,y:700,t:1526930257387};\\\", \\\"{x:1280,y:706,t:1526930257403};\\\", \\\"{x:1280,y:712,t:1526930257420};\\\", \\\"{x:1280,y:718,t:1526930257436};\\\", \\\"{x:1280,y:724,t:1526930257453};\\\", \\\"{x:1280,y:734,t:1526930257470};\\\", \\\"{x:1280,y:744,t:1526930257485};\\\", \\\"{x:1280,y:751,t:1526930257502};\\\", \\\"{x:1283,y:762,t:1526930257519};\\\", \\\"{x:1283,y:767,t:1526930257536};\\\", \\\"{x:1285,y:772,t:1526930257552};\\\", \\\"{x:1285,y:779,t:1526930257568};\\\", \\\"{x:1285,y:789,t:1526930257585};\\\", \\\"{x:1285,y:807,t:1526930257603};\\\", \\\"{x:1285,y:825,t:1526930257618};\\\", \\\"{x:1285,y:845,t:1526930257635};\\\", \\\"{x:1285,y:863,t:1526930257652};\\\", \\\"{x:1285,y:881,t:1526930257668};\\\", \\\"{x:1285,y:898,t:1526930257686};\\\", \\\"{x:1285,y:919,t:1526930257701};\\\", \\\"{x:1283,y:936,t:1526930257718};\\\", \\\"{x:1280,y:951,t:1526930257735};\\\", \\\"{x:1279,y:968,t:1526930257751};\\\", \\\"{x:1277,y:977,t:1526930257769};\\\", \\\"{x:1277,y:980,t:1526930257784};\\\", \\\"{x:1276,y:982,t:1526930257801};\\\", \\\"{x:1275,y:981,t:1526930257975};\\\", \\\"{x:1275,y:979,t:1526930257984};\\\", \\\"{x:1275,y:977,t:1526930258000};\\\", \\\"{x:1275,y:976,t:1526930258018};\\\", \\\"{x:1275,y:975,t:1526930258033};\\\", \\\"{x:1275,y:973,t:1526930258051};\\\", \\\"{x:1275,y:972,t:1526930258071};\\\", \\\"{x:1275,y:971,t:1526930258872};\\\", \\\"{x:1275,y:970,t:1526930259264};\\\", \\\"{x:1275,y:969,t:1526930259280};\\\", \\\"{x:1274,y:967,t:1526930259296};\\\", \\\"{x:1274,y:955,t:1526930262328};\\\", \\\"{x:1276,y:928,t:1526930262335};\\\", \\\"{x:1280,y:863,t:1526930262352};\\\", \\\"{x:1285,y:767,t:1526930262369};\\\", \\\"{x:1285,y:684,t:1526930262385};\\\", \\\"{x:1289,y:608,t:1526930262402};\\\", \\\"{x:1289,y:552,t:1526930262418};\\\", \\\"{x:1286,y:523,t:1526930262435};\\\", \\\"{x:1285,y:511,t:1526930262452};\\\", \\\"{x:1285,y:510,t:1526930262468};\\\", \\\"{x:1282,y:512,t:1526930262632};\\\", \\\"{x:1279,y:519,t:1526930262639};\\\", \\\"{x:1275,y:527,t:1526930262651};\\\", \\\"{x:1269,y:538,t:1526930262668};\\\", \\\"{x:1262,y:547,t:1526930262684};\\\", \\\"{x:1259,y:558,t:1526930262700};\\\", \\\"{x:1256,y:565,t:1526930262716};\\\", \\\"{x:1256,y:571,t:1526930262734};\\\", \\\"{x:1255,y:578,t:1526930262751};\\\", \\\"{x:1255,y:581,t:1526930262767};\\\", \\\"{x:1254,y:581,t:1526930262791};\\\", \\\"{x:1254,y:582,t:1526930262800};\\\", \\\"{x:1254,y:583,t:1526930262817};\\\", \\\"{x:1254,y:585,t:1526930262834};\\\", \\\"{x:1253,y:588,t:1526930262850};\\\", \\\"{x:1253,y:592,t:1526930262867};\\\", \\\"{x:1252,y:597,t:1526930262883};\\\", \\\"{x:1251,y:605,t:1526930262900};\\\", \\\"{x:1247,y:617,t:1526930262917};\\\", \\\"{x:1244,y:633,t:1526930262932};\\\", \\\"{x:1242,y:648,t:1526930262949};\\\", \\\"{x:1236,y:664,t:1526930262965};\\\", \\\"{x:1232,y:679,t:1526930262982};\\\", \\\"{x:1229,y:688,t:1526930263000};\\\", \\\"{x:1229,y:693,t:1526930263015};\\\", \\\"{x:1228,y:698,t:1526930263032};\\\", \\\"{x:1227,y:704,t:1526930263048};\\\", \\\"{x:1227,y:714,t:1526930263065};\\\", \\\"{x:1225,y:719,t:1526930263083};\\\", \\\"{x:1224,y:726,t:1526930263098};\\\", \\\"{x:1223,y:733,t:1526930263115};\\\", \\\"{x:1223,y:738,t:1526930263131};\\\", \\\"{x:1221,y:743,t:1526930263149};\\\", \\\"{x:1221,y:751,t:1526930263165};\\\", \\\"{x:1221,y:759,t:1526930263181};\\\", \\\"{x:1220,y:773,t:1526930263199};\\\", \\\"{x:1217,y:784,t:1526930263215};\\\", \\\"{x:1216,y:789,t:1526930263232};\\\", \\\"{x:1216,y:792,t:1526930263249};\\\", \\\"{x:1216,y:794,t:1526930263264};\\\", \\\"{x:1216,y:795,t:1526930263282};\\\", \\\"{x:1216,y:796,t:1526930263299};\\\", \\\"{x:1216,y:797,t:1526930263407};\\\", \\\"{x:1216,y:798,t:1526930263415};\\\", \\\"{x:1216,y:799,t:1526930263431};\\\", \\\"{x:1216,y:801,t:1526930263448};\\\", \\\"{x:1216,y:802,t:1526930263464};\\\", \\\"{x:1216,y:806,t:1526930263480};\\\", \\\"{x:1216,y:809,t:1526930263499};\\\", \\\"{x:1216,y:813,t:1526930263514};\\\", \\\"{x:1216,y:814,t:1526930263531};\\\", \\\"{x:1216,y:816,t:1526930263548};\\\", \\\"{x:1216,y:818,t:1526930263564};\\\", \\\"{x:1215,y:818,t:1526930263631};\\\", \\\"{x:1214,y:818,t:1526930263695};\\\", \\\"{x:1214,y:819,t:1526930263911};\\\", \\\"{x:1213,y:821,t:1526930263959};\\\", \\\"{x:1213,y:822,t:1526930263991};\\\", \\\"{x:1212,y:823,t:1526930264248};\\\", \\\"{x:1214,y:817,t:1526930264262};\\\", \\\"{x:1222,y:794,t:1526930264278};\\\", \\\"{x:1245,y:740,t:1526930264295};\\\", \\\"{x:1253,y:717,t:1526930264311};\\\", \\\"{x:1262,y:695,t:1526930264328};\\\", \\\"{x:1271,y:676,t:1526930264346};\\\", \\\"{x:1276,y:658,t:1526930264361};\\\", \\\"{x:1280,y:646,t:1526930264378};\\\", \\\"{x:1281,y:637,t:1526930264395};\\\", \\\"{x:1283,y:631,t:1526930264411};\\\", \\\"{x:1283,y:627,t:1526930264427};\\\", \\\"{x:1281,y:621,t:1526930264444};\\\", \\\"{x:1278,y:614,t:1526930264461};\\\", \\\"{x:1274,y:606,t:1526930264478};\\\", \\\"{x:1274,y:601,t:1526930264494};\\\", \\\"{x:1270,y:589,t:1526930264511};\\\", \\\"{x:1268,y:577,t:1526930264527};\\\", \\\"{x:1266,y:565,t:1526930264543};\\\", \\\"{x:1266,y:557,t:1526930264560};\\\", \\\"{x:1267,y:551,t:1526930264576};\\\", \\\"{x:1269,y:545,t:1526930264594};\\\", \\\"{x:1271,y:542,t:1526930264609};\\\", \\\"{x:1271,y:541,t:1526930264626};\\\", \\\"{x:1271,y:540,t:1526930264662};\\\", \\\"{x:1272,y:540,t:1526930264792};\\\", \\\"{x:1273,y:541,t:1526930264823};\\\", \\\"{x:1273,y:543,t:1526930264879};\\\", \\\"{x:1273,y:544,t:1526930265087};\\\", \\\"{x:1273,y:548,t:1526930265095};\\\", \\\"{x:1273,y:550,t:1526930265108};\\\", \\\"{x:1274,y:553,t:1526930265124};\\\", \\\"{x:1274,y:554,t:1526930265142};\\\", \\\"{x:1274,y:555,t:1526930265158};\\\", \\\"{x:1274,y:556,t:1526930265175};\\\", \\\"{x:1274,y:557,t:1526930265280};\\\", \\\"{x:1276,y:559,t:1526930265295};\\\", \\\"{x:1276,y:560,t:1526930265310};\\\", \\\"{x:1276,y:561,t:1526930265324};\\\", \\\"{x:1276,y:563,t:1526930265340};\\\", \\\"{x:1276,y:566,t:1526930265357};\\\", \\\"{x:1275,y:568,t:1526930265373};\\\", \\\"{x:1267,y:576,t:1526930265391};\\\", \\\"{x:1261,y:581,t:1526930265407};\\\", \\\"{x:1256,y:588,t:1526930265423};\\\", \\\"{x:1254,y:592,t:1526930265441};\\\", \\\"{x:1252,y:595,t:1526930265456};\\\", \\\"{x:1251,y:597,t:1526930265474};\\\", \\\"{x:1249,y:605,t:1526930265490};\\\", \\\"{x:1243,y:626,t:1526930265506};\\\", \\\"{x:1235,y:648,t:1526930265524};\\\", \\\"{x:1231,y:667,t:1526930265540};\\\", \\\"{x:1227,y:678,t:1526930265557};\\\", \\\"{x:1227,y:682,t:1526930265573};\\\", \\\"{x:1227,y:685,t:1526930265590};\\\", \\\"{x:1231,y:688,t:1526930265607};\\\", \\\"{x:1234,y:689,t:1526930265623};\\\", \\\"{x:1235,y:689,t:1526930265647};\\\", \\\"{x:1236,y:689,t:1526930266496};\\\", \\\"{x:1236,y:699,t:1526930269296};\\\", \\\"{x:1233,y:721,t:1526930269310};\\\", \\\"{x:1223,y:770,t:1526930269327};\\\", \\\"{x:1218,y:788,t:1526930269344};\\\", \\\"{x:1216,y:805,t:1526930269361};\\\", \\\"{x:1215,y:817,t:1526930269378};\\\", \\\"{x:1212,y:829,t:1526930269394};\\\", \\\"{x:1212,y:835,t:1526930269410};\\\", \\\"{x:1212,y:842,t:1526930269427};\\\", \\\"{x:1212,y:846,t:1526930269443};\\\", \\\"{x:1211,y:850,t:1526930269460};\\\", \\\"{x:1209,y:854,t:1526930269476};\\\", \\\"{x:1209,y:855,t:1526930269493};\\\", \\\"{x:1209,y:857,t:1526930269509};\\\", \\\"{x:1209,y:858,t:1526930269526};\\\", \\\"{x:1208,y:863,t:1526930269543};\\\", \\\"{x:1206,y:867,t:1526930269559};\\\", \\\"{x:1205,y:867,t:1526930269575};\\\", \\\"{x:1204,y:867,t:1526930270032};\\\", \\\"{x:1205,y:867,t:1526930270079};\\\", \\\"{x:1205,y:865,t:1526930270095};\\\", \\\"{x:1205,y:862,t:1526930270107};\\\", \\\"{x:1209,y:855,t:1526930270124};\\\", \\\"{x:1210,y:850,t:1526930270140};\\\", \\\"{x:1210,y:848,t:1526930270157};\\\", \\\"{x:1210,y:845,t:1526930270174};\\\", \\\"{x:1210,y:841,t:1526930270190};\\\", \\\"{x:1210,y:839,t:1526930270207};\\\", \\\"{x:1209,y:839,t:1526930272200};\\\", \\\"{x:1187,y:834,t:1526930272216};\\\", \\\"{x:1122,y:809,t:1526930272233};\\\", \\\"{x:1024,y:776,t:1526930272249};\\\", \\\"{x:908,y:727,t:1526930272266};\\\", \\\"{x:782,y:674,t:1526930272284};\\\", \\\"{x:663,y:623,t:1526930272300};\\\", \\\"{x:553,y:579,t:1526930272315};\\\", \\\"{x:369,y:502,t:1526930272345};\\\", \\\"{x:322,y:482,t:1526930272362};\\\", \\\"{x:313,y:478,t:1526930272377};\\\", \\\"{x:312,y:478,t:1526930272406};\\\", \\\"{x:313,y:480,t:1526930272470};\\\", \\\"{x:315,y:481,t:1526930272478};\\\", \\\"{x:318,y:483,t:1526930272494};\\\", \\\"{x:321,y:485,t:1526930272511};\\\", \\\"{x:325,y:488,t:1526930272528};\\\", \\\"{x:340,y:503,t:1526930272544};\\\", \\\"{x:370,y:527,t:1526930272563};\\\", \\\"{x:409,y:561,t:1526930272579};\\\", \\\"{x:449,y:602,t:1526930272595};\\\", \\\"{x:479,y:644,t:1526930272612};\\\", \\\"{x:494,y:671,t:1526930272629};\\\", \\\"{x:506,y:696,t:1526930272645};\\\", \\\"{x:510,y:713,t:1526930272661};\\\", \\\"{x:512,y:723,t:1526930272679};\\\", \\\"{x:509,y:726,t:1526930272695};\\\", \\\"{x:509,y:728,t:1526930272711};\\\", \\\"{x:509,y:730,t:1526930272729};\\\", \\\"{x:509,y:733,t:1526930272744};\\\", \\\"{x:509,y:735,t:1526930272761};\\\", \\\"{x:510,y:735,t:1526930272778};\\\", \\\"{x:510,y:737,t:1526930272855};\\\", \\\"{x:510,y:738,t:1526930272862};\\\", \\\"{x:511,y:738,t:1526930272983};\\\", \\\"{x:512,y:738,t:1526930273127};\\\", \\\"{x:513,y:738,t:1526930273191};\\\", \\\"{x:515,y:738,t:1526930273311};\\\", \\\"{x:515,y:738,t:1526930273418};\\\", \\\"{x:516,y:737,t:1526930273727};\\\", \\\"{x:521,y:729,t:1526930273735};\\\", \\\"{x:529,y:723,t:1526930273745};\\\", \\\"{x:544,y:708,t:1526930273762};\\\", \\\"{x:557,y:697,t:1526930273778};\\\", \\\"{x:568,y:688,t:1526930273795};\\\", \\\"{x:574,y:682,t:1526930273813};\\\", \\\"{x:577,y:679,t:1526930273829};\\\", \\\"{x:577,y:678,t:1526930273846};\\\", \\\"{x:578,y:677,t:1526930273863};\\\" ] }, { \\\"rt\\\": 33667, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 631981, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -02 PM-02 PM-M -M -M -B -B -B -12 PM-B -B -F -F -F -E -E -11 AM-I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:549,t:1526930275311};\\\", \\\"{x:484,y:488,t:1526930275330};\\\", \\\"{x:463,y:459,t:1526930275346};\\\", \\\"{x:454,y:447,t:1526930275364};\\\", \\\"{x:452,y:442,t:1526930275381};\\\", \\\"{x:452,y:440,t:1526930275397};\\\", \\\"{x:452,y:438,t:1526930275414};\\\", \\\"{x:453,y:432,t:1526930275430};\\\", \\\"{x:454,y:428,t:1526930275447};\\\", \\\"{x:457,y:424,t:1526930275463};\\\", \\\"{x:461,y:419,t:1526930275480};\\\", \\\"{x:464,y:416,t:1526930275496};\\\", \\\"{x:469,y:413,t:1526930275514};\\\", \\\"{x:472,y:412,t:1526930275531};\\\", \\\"{x:473,y:412,t:1526930275547};\\\", \\\"{x:474,y:411,t:1526930276623};\\\", \\\"{x:474,y:410,t:1526930276696};\\\", \\\"{x:479,y:406,t:1526930276702};\\\", \\\"{x:496,y:402,t:1526930276715};\\\", \\\"{x:544,y:397,t:1526930276733};\\\", \\\"{x:599,y:392,t:1526930276749};\\\", \\\"{x:671,y:392,t:1526930276765};\\\", \\\"{x:764,y:401,t:1526930276782};\\\", \\\"{x:895,y:444,t:1526930276799};\\\", \\\"{x:1148,y:560,t:1526930276815};\\\", \\\"{x:1330,y:645,t:1526930276832};\\\", \\\"{x:1490,y:720,t:1526930276848};\\\", \\\"{x:1627,y:794,t:1526930276865};\\\", \\\"{x:1723,y:849,t:1526930276882};\\\", \\\"{x:1777,y:893,t:1526930276898};\\\", \\\"{x:1796,y:922,t:1526930276915};\\\", \\\"{x:1799,y:935,t:1526930276933};\\\", \\\"{x:1797,y:943,t:1526930276949};\\\", \\\"{x:1791,y:947,t:1526930276965};\\\", \\\"{x:1789,y:950,t:1526930276982};\\\", \\\"{x:1788,y:950,t:1526930277304};\\\", \\\"{x:1785,y:951,t:1526930277316};\\\", \\\"{x:1783,y:953,t:1526930277332};\\\", \\\"{x:1775,y:955,t:1526930277349};\\\", \\\"{x:1765,y:955,t:1526930277365};\\\", \\\"{x:1734,y:954,t:1526930277382};\\\", \\\"{x:1701,y:945,t:1526930277399};\\\", \\\"{x:1637,y:928,t:1526930277415};\\\", \\\"{x:1540,y:900,t:1526930277432};\\\", \\\"{x:1445,y:882,t:1526930277450};\\\", \\\"{x:1367,y:870,t:1526930277465};\\\", \\\"{x:1325,y:865,t:1526930277482};\\\", \\\"{x:1309,y:865,t:1526930277499};\\\", \\\"{x:1305,y:866,t:1526930277515};\\\", \\\"{x:1308,y:880,t:1526930277532};\\\", \\\"{x:1318,y:891,t:1526930277549};\\\", \\\"{x:1332,y:902,t:1526930277566};\\\", \\\"{x:1343,y:910,t:1526930277582};\\\", \\\"{x:1360,y:921,t:1526930277599};\\\", \\\"{x:1372,y:922,t:1526930277617};\\\", \\\"{x:1382,y:922,t:1526930277632};\\\", \\\"{x:1397,y:918,t:1526930277649};\\\", \\\"{x:1413,y:911,t:1526930277667};\\\", \\\"{x:1424,y:906,t:1526930277681};\\\", \\\"{x:1433,y:900,t:1526930277699};\\\", \\\"{x:1442,y:895,t:1526930277716};\\\", \\\"{x:1450,y:889,t:1526930277732};\\\", \\\"{x:1455,y:884,t:1526930277749};\\\", \\\"{x:1462,y:877,t:1526930277766};\\\", \\\"{x:1464,y:871,t:1526930277782};\\\", \\\"{x:1466,y:868,t:1526930277799};\\\", \\\"{x:1467,y:867,t:1526930277816};\\\", \\\"{x:1467,y:866,t:1526930277832};\\\", \\\"{x:1467,y:865,t:1526930277849};\\\", \\\"{x:1467,y:861,t:1526930277866};\\\", \\\"{x:1467,y:858,t:1526930277882};\\\", \\\"{x:1467,y:854,t:1526930277899};\\\", \\\"{x:1467,y:852,t:1526930277916};\\\", \\\"{x:1467,y:850,t:1526930277932};\\\", \\\"{x:1467,y:849,t:1526930277951};\\\", \\\"{x:1467,y:848,t:1526930277967};\\\", \\\"{x:1467,y:847,t:1526930277982};\\\", \\\"{x:1467,y:846,t:1526930278135};\\\", \\\"{x:1467,y:843,t:1526930278832};\\\", \\\"{x:1472,y:837,t:1526930278850};\\\", \\\"{x:1475,y:833,t:1526930278866};\\\", \\\"{x:1478,y:831,t:1526930278886};\\\", \\\"{x:1481,y:830,t:1526930278900};\\\", \\\"{x:1482,y:828,t:1526930278916};\\\", \\\"{x:1484,y:828,t:1526930279783};\\\", \\\"{x:1486,y:852,t:1526930279802};\\\", \\\"{x:1486,y:897,t:1526930279818};\\\", \\\"{x:1486,y:939,t:1526930279834};\\\", \\\"{x:1487,y:966,t:1526930279851};\\\", \\\"{x:1487,y:984,t:1526930279868};\\\", \\\"{x:1488,y:993,t:1526930279885};\\\", \\\"{x:1488,y:994,t:1526930279902};\\\", \\\"{x:1485,y:989,t:1526930280055};\\\", \\\"{x:1485,y:986,t:1526930280067};\\\", \\\"{x:1479,y:974,t:1526930280085};\\\", \\\"{x:1473,y:957,t:1526930280102};\\\", \\\"{x:1468,y:939,t:1526930280118};\\\", \\\"{x:1463,y:931,t:1526930280134};\\\", \\\"{x:1463,y:929,t:1526930280152};\\\", \\\"{x:1464,y:929,t:1526930280183};\\\", \\\"{x:1466,y:929,t:1526930280191};\\\", \\\"{x:1467,y:930,t:1526930280202};\\\", \\\"{x:1468,y:930,t:1526930280217};\\\", \\\"{x:1469,y:931,t:1526930280263};\\\", \\\"{x:1469,y:932,t:1526930280271};\\\", \\\"{x:1471,y:935,t:1526930280284};\\\", \\\"{x:1471,y:939,t:1526930280302};\\\", \\\"{x:1471,y:943,t:1526930280318};\\\", \\\"{x:1470,y:945,t:1526930280334};\\\", \\\"{x:1469,y:948,t:1526930280351};\\\", \\\"{x:1469,y:950,t:1526930280368};\\\", \\\"{x:1468,y:950,t:1526930280424};\\\", \\\"{x:1467,y:950,t:1526930280511};\\\", \\\"{x:1463,y:948,t:1526930280519};\\\", \\\"{x:1448,y:942,t:1526930280535};\\\", \\\"{x:1430,y:931,t:1526930280551};\\\", \\\"{x:1410,y:919,t:1526930280569};\\\", \\\"{x:1392,y:907,t:1526930280585};\\\", \\\"{x:1381,y:899,t:1526930280602};\\\", \\\"{x:1375,y:894,t:1526930280619};\\\", \\\"{x:1374,y:893,t:1526930280634};\\\", \\\"{x:1374,y:892,t:1526930280663};\\\", \\\"{x:1374,y:891,t:1526930280687};\\\", \\\"{x:1374,y:890,t:1526930280702};\\\", \\\"{x:1374,y:888,t:1526930280719};\\\", \\\"{x:1373,y:886,t:1526930280734};\\\", \\\"{x:1373,y:884,t:1526930280752};\\\", \\\"{x:1373,y:883,t:1526930280775};\\\", \\\"{x:1372,y:882,t:1526930280785};\\\", \\\"{x:1374,y:882,t:1526930280959};\\\", \\\"{x:1376,y:882,t:1526930280974};\\\", \\\"{x:1377,y:884,t:1526930280985};\\\", \\\"{x:1379,y:887,t:1526930281001};\\\", \\\"{x:1381,y:893,t:1526930281019};\\\", \\\"{x:1382,y:895,t:1526930281035};\\\", \\\"{x:1382,y:898,t:1526930281051};\\\", \\\"{x:1382,y:900,t:1526930281069};\\\", \\\"{x:1382,y:899,t:1526930281463};\\\", \\\"{x:1382,y:897,t:1526930281479};\\\", \\\"{x:1382,y:896,t:1526930281486};\\\", \\\"{x:1382,y:895,t:1526930281502};\\\", \\\"{x:1382,y:894,t:1526930281519};\\\", \\\"{x:1382,y:893,t:1526930281535};\\\", \\\"{x:1384,y:892,t:1526930282143};\\\", \\\"{x:1385,y:892,t:1526930282152};\\\", \\\"{x:1386,y:892,t:1526930282170};\\\", \\\"{x:1387,y:892,t:1526930282185};\\\", \\\"{x:1388,y:893,t:1526930282202};\\\", \\\"{x:1389,y:893,t:1526930282222};\\\", \\\"{x:1391,y:893,t:1526930282235};\\\", \\\"{x:1394,y:896,t:1526930282253};\\\", \\\"{x:1395,y:896,t:1526930282270};\\\", \\\"{x:1397,y:897,t:1526930282287};\\\", \\\"{x:1398,y:897,t:1526930282303};\\\", \\\"{x:1399,y:898,t:1526930282320};\\\", \\\"{x:1401,y:899,t:1526930282337};\\\", \\\"{x:1402,y:899,t:1526930282359};\\\", \\\"{x:1403,y:901,t:1526930282369};\\\", \\\"{x:1405,y:905,t:1526930282387};\\\", \\\"{x:1407,y:908,t:1526930282403};\\\", \\\"{x:1410,y:912,t:1526930282420};\\\", \\\"{x:1414,y:916,t:1526930282437};\\\", \\\"{x:1417,y:921,t:1526930282453};\\\", \\\"{x:1422,y:924,t:1526930282470};\\\", \\\"{x:1430,y:926,t:1526930282487};\\\", \\\"{x:1435,y:930,t:1526930282503};\\\", \\\"{x:1440,y:932,t:1526930282519};\\\", \\\"{x:1449,y:934,t:1526930282536};\\\", \\\"{x:1460,y:938,t:1526930282552};\\\", \\\"{x:1470,y:938,t:1526930282569};\\\", \\\"{x:1480,y:939,t:1526930282587};\\\", \\\"{x:1489,y:939,t:1526930282603};\\\", \\\"{x:1498,y:941,t:1526930282620};\\\", \\\"{x:1501,y:941,t:1526930282637};\\\", \\\"{x:1503,y:942,t:1526930282652};\\\", \\\"{x:1504,y:942,t:1526930282687};\\\", \\\"{x:1504,y:941,t:1526930283304};\\\", \\\"{x:1499,y:933,t:1526930283321};\\\", \\\"{x:1489,y:922,t:1526930283336};\\\", \\\"{x:1470,y:904,t:1526930283354};\\\", \\\"{x:1443,y:881,t:1526930283371};\\\", \\\"{x:1416,y:860,t:1526930283387};\\\", \\\"{x:1398,y:845,t:1526930283404};\\\", \\\"{x:1391,y:837,t:1526930283421};\\\", \\\"{x:1389,y:833,t:1526930283437};\\\", \\\"{x:1389,y:832,t:1526930283454};\\\", \\\"{x:1391,y:832,t:1526930283471};\\\", \\\"{x:1392,y:832,t:1526930283487};\\\", \\\"{x:1393,y:832,t:1526930283568};\\\", \\\"{x:1394,y:832,t:1526930283615};\\\", \\\"{x:1394,y:829,t:1526930283623};\\\", \\\"{x:1394,y:825,t:1526930283637};\\\", \\\"{x:1394,y:821,t:1526930283654};\\\", \\\"{x:1393,y:808,t:1526930283671};\\\", \\\"{x:1383,y:798,t:1526930283686};\\\", \\\"{x:1371,y:787,t:1526930283704};\\\", \\\"{x:1363,y:781,t:1526930283720};\\\", \\\"{x:1358,y:777,t:1526930283738};\\\", \\\"{x:1355,y:774,t:1526930283754};\\\", \\\"{x:1353,y:773,t:1526930283771};\\\", \\\"{x:1350,y:771,t:1526930283787};\\\", \\\"{x:1349,y:770,t:1526930283804};\\\", \\\"{x:1349,y:768,t:1526930283912};\\\", \\\"{x:1348,y:766,t:1526930283938};\\\", \\\"{x:1348,y:764,t:1526930283953};\\\", \\\"{x:1347,y:762,t:1526930283970};\\\", \\\"{x:1347,y:761,t:1526930283987};\\\", \\\"{x:1346,y:758,t:1526930284003};\\\", \\\"{x:1345,y:757,t:1526930284021};\\\", \\\"{x:1347,y:757,t:1526930284454};\\\", \\\"{x:1349,y:758,t:1526930284470};\\\", \\\"{x:1350,y:759,t:1526930284487};\\\", \\\"{x:1352,y:759,t:1526930284504};\\\", \\\"{x:1352,y:760,t:1526930284520};\\\", \\\"{x:1352,y:762,t:1526930284537};\\\", \\\"{x:1352,y:764,t:1526930284554};\\\", \\\"{x:1354,y:767,t:1526930284571};\\\", \\\"{x:1354,y:768,t:1526930284587};\\\", \\\"{x:1354,y:771,t:1526930284604};\\\", \\\"{x:1354,y:774,t:1526930284621};\\\", \\\"{x:1353,y:782,t:1526930284638};\\\", \\\"{x:1352,y:801,t:1526930284654};\\\", \\\"{x:1349,y:819,t:1526930284670};\\\", \\\"{x:1341,y:856,t:1526930284687};\\\", \\\"{x:1329,y:891,t:1526930284705};\\\", \\\"{x:1319,y:927,t:1526930284721};\\\", \\\"{x:1314,y:961,t:1526930284737};\\\", \\\"{x:1314,y:979,t:1526930284754};\\\", \\\"{x:1314,y:991,t:1526930284771};\\\", \\\"{x:1314,y:996,t:1526930284787};\\\", \\\"{x:1314,y:997,t:1526930284804};\\\", \\\"{x:1314,y:998,t:1526930284832};\\\", \\\"{x:1314,y:999,t:1526930284855};\\\", \\\"{x:1315,y:1000,t:1526930284871};\\\", \\\"{x:1316,y:1001,t:1526930284887};\\\", \\\"{x:1319,y:1003,t:1526930284904};\\\", \\\"{x:1321,y:1003,t:1526930284922};\\\", \\\"{x:1326,y:1003,t:1526930284937};\\\", \\\"{x:1332,y:1001,t:1526930284955};\\\", \\\"{x:1339,y:997,t:1526930284972};\\\", \\\"{x:1343,y:992,t:1526930284988};\\\", \\\"{x:1344,y:990,t:1526930285004};\\\", \\\"{x:1344,y:987,t:1526930285022};\\\", \\\"{x:1346,y:984,t:1526930285038};\\\", \\\"{x:1346,y:977,t:1526930285054};\\\", \\\"{x:1346,y:974,t:1526930285071};\\\", \\\"{x:1346,y:972,t:1526930285088};\\\", \\\"{x:1346,y:969,t:1526930285105};\\\", \\\"{x:1346,y:968,t:1526930285122};\\\", \\\"{x:1346,y:966,t:1526930285139};\\\", \\\"{x:1346,y:965,t:1526930285154};\\\", \\\"{x:1346,y:964,t:1526930285172};\\\", \\\"{x:1346,y:963,t:1526930285188};\\\", \\\"{x:1344,y:962,t:1526930285205};\\\", \\\"{x:1341,y:961,t:1526930285221};\\\", \\\"{x:1337,y:958,t:1526930285239};\\\", \\\"{x:1335,y:954,t:1526930285255};\\\", \\\"{x:1332,y:951,t:1526930285272};\\\", \\\"{x:1329,y:948,t:1526930285288};\\\", \\\"{x:1328,y:946,t:1526930285304};\\\", \\\"{x:1327,y:942,t:1526930285322};\\\", \\\"{x:1325,y:932,t:1526930285338};\\\", \\\"{x:1320,y:914,t:1526930285355};\\\", \\\"{x:1317,y:894,t:1526930285372};\\\", \\\"{x:1313,y:871,t:1526930285388};\\\", \\\"{x:1309,y:851,t:1526930285405};\\\", \\\"{x:1308,y:839,t:1526930285422};\\\", \\\"{x:1308,y:824,t:1526930285438};\\\", \\\"{x:1313,y:813,t:1526930285455};\\\", \\\"{x:1318,y:802,t:1526930285472};\\\", \\\"{x:1322,y:794,t:1526930285489};\\\", \\\"{x:1328,y:787,t:1526930285505};\\\", \\\"{x:1333,y:781,t:1526930285522};\\\", \\\"{x:1338,y:775,t:1526930285538};\\\", \\\"{x:1341,y:772,t:1526930285555};\\\", \\\"{x:1344,y:768,t:1526930285571};\\\", \\\"{x:1345,y:766,t:1526930285589};\\\", \\\"{x:1346,y:765,t:1526930285605};\\\", \\\"{x:1347,y:764,t:1526930285622};\\\", \\\"{x:1348,y:763,t:1526930285639};\\\", \\\"{x:1349,y:762,t:1526930285654};\\\", \\\"{x:1349,y:761,t:1526930285678};\\\", \\\"{x:1350,y:761,t:1526930285703};\\\", \\\"{x:1350,y:760,t:1526930285719};\\\", \\\"{x:1350,y:758,t:1526930285735};\\\", \\\"{x:1350,y:757,t:1526930285760};\\\", \\\"{x:1350,y:755,t:1526930285783};\\\", \\\"{x:1350,y:754,t:1526930285798};\\\", \\\"{x:1350,y:752,t:1526930285814};\\\", \\\"{x:1350,y:751,t:1526930286182};\\\", \\\"{x:1351,y:751,t:1526930286399};\\\", \\\"{x:1352,y:751,t:1526930286407};\\\", \\\"{x:1352,y:748,t:1526930286671};\\\", \\\"{x:1352,y:744,t:1526930286679};\\\", \\\"{x:1351,y:741,t:1526930286690};\\\", \\\"{x:1351,y:732,t:1526930286706};\\\", \\\"{x:1351,y:727,t:1526930286723};\\\", \\\"{x:1351,y:720,t:1526930286739};\\\", \\\"{x:1351,y:719,t:1526930286756};\\\", \\\"{x:1351,y:717,t:1526930286773};\\\", \\\"{x:1351,y:716,t:1526930286815};\\\", \\\"{x:1351,y:714,t:1526930286864};\\\", \\\"{x:1351,y:713,t:1526930286872};\\\", \\\"{x:1351,y:709,t:1526930286890};\\\", \\\"{x:1348,y:703,t:1526930286906};\\\", \\\"{x:1346,y:697,t:1526930286924};\\\", \\\"{x:1343,y:693,t:1526930286939};\\\", \\\"{x:1341,y:691,t:1526930286956};\\\", \\\"{x:1340,y:690,t:1526930286975};\\\", \\\"{x:1341,y:690,t:1526930287167};\\\", \\\"{x:1342,y:690,t:1526930287175};\\\", \\\"{x:1343,y:690,t:1526930287190};\\\", \\\"{x:1344,y:691,t:1526930287207};\\\", \\\"{x:1344,y:693,t:1526930287223};\\\", \\\"{x:1344,y:702,t:1526930287241};\\\", \\\"{x:1344,y:717,t:1526930287257};\\\", \\\"{x:1337,y:739,t:1526930287273};\\\", \\\"{x:1331,y:762,t:1526930287290};\\\", \\\"{x:1323,y:790,t:1526930287307};\\\", \\\"{x:1318,y:819,t:1526930287322};\\\", \\\"{x:1314,y:848,t:1526930287340};\\\", \\\"{x:1314,y:878,t:1526930287357};\\\", \\\"{x:1313,y:906,t:1526930287373};\\\", \\\"{x:1313,y:922,t:1526930287390};\\\", \\\"{x:1314,y:932,t:1526930287407};\\\", \\\"{x:1315,y:934,t:1526930287463};\\\", \\\"{x:1316,y:934,t:1526930287486};\\\", \\\"{x:1317,y:935,t:1526930287503};\\\", \\\"{x:1318,y:936,t:1526930287519};\\\", \\\"{x:1319,y:936,t:1526930287527};\\\", \\\"{x:1321,y:937,t:1526930287540};\\\", \\\"{x:1322,y:938,t:1526930287559};\\\", \\\"{x:1323,y:939,t:1526930287591};\\\", \\\"{x:1324,y:939,t:1526930287606};\\\", \\\"{x:1324,y:940,t:1526930287639};\\\", \\\"{x:1325,y:941,t:1526930287657};\\\", \\\"{x:1325,y:942,t:1526930287674};\\\", \\\"{x:1325,y:943,t:1526930287690};\\\", \\\"{x:1325,y:944,t:1526930287707};\\\", \\\"{x:1325,y:945,t:1526930287724};\\\", \\\"{x:1325,y:946,t:1526930287759};\\\", \\\"{x:1321,y:942,t:1526930287911};\\\", \\\"{x:1312,y:932,t:1526930287924};\\\", \\\"{x:1273,y:890,t:1526930287940};\\\", \\\"{x:1207,y:831,t:1526930287957};\\\", \\\"{x:1107,y:762,t:1526930287974};\\\", \\\"{x:941,y:674,t:1526930287990};\\\", \\\"{x:852,y:630,t:1526930288008};\\\", \\\"{x:787,y:598,t:1526930288024};\\\", \\\"{x:745,y:579,t:1526930288040};\\\", \\\"{x:723,y:569,t:1526930288057};\\\", \\\"{x:715,y:566,t:1526930288074};\\\", \\\"{x:712,y:564,t:1526930288090};\\\", \\\"{x:716,y:565,t:1526930288142};\\\", \\\"{x:719,y:566,t:1526930288157};\\\", \\\"{x:720,y:566,t:1526930288174};\\\", \\\"{x:720,y:567,t:1526930288190};\\\", \\\"{x:721,y:568,t:1526930288799};\\\", \\\"{x:722,y:568,t:1526930288951};\\\", \\\"{x:726,y:567,t:1526930289528};\\\", \\\"{x:735,y:565,t:1526930289541};\\\", \\\"{x:763,y:556,t:1526930289558};\\\", \\\"{x:789,y:554,t:1526930289576};\\\", \\\"{x:808,y:551,t:1526930289593};\\\", \\\"{x:829,y:548,t:1526930289609};\\\", \\\"{x:845,y:545,t:1526930289626};\\\", \\\"{x:854,y:544,t:1526930289641};\\\", \\\"{x:856,y:544,t:1526930289659};\\\", \\\"{x:857,y:543,t:1526930289727};\\\", \\\"{x:857,y:542,t:1526930289742};\\\", \\\"{x:844,y:536,t:1526930289759};\\\", \\\"{x:828,y:528,t:1526930289776};\\\", \\\"{x:813,y:525,t:1526930289792};\\\", \\\"{x:796,y:520,t:1526930289808};\\\", \\\"{x:785,y:519,t:1526930289825};\\\", \\\"{x:771,y:519,t:1526930289842};\\\", \\\"{x:756,y:519,t:1526930289858};\\\", \\\"{x:743,y:522,t:1526930289875};\\\", \\\"{x:737,y:524,t:1526930289893};\\\", \\\"{x:732,y:526,t:1526930289909};\\\", \\\"{x:730,y:527,t:1526930289925};\\\", \\\"{x:729,y:527,t:1526930289943};\\\", \\\"{x:729,y:528,t:1526930289982};\\\", \\\"{x:730,y:528,t:1526930289992};\\\", \\\"{x:731,y:529,t:1526930290010};\\\", \\\"{x:729,y:529,t:1526930290079};\\\", \\\"{x:720,y:529,t:1526930290095};\\\", \\\"{x:675,y:518,t:1526930290109};\\\", \\\"{x:611,y:509,t:1526930290126};\\\", \\\"{x:517,y:500,t:1526930290142};\\\", \\\"{x:490,y:500,t:1526930290159};\\\", \\\"{x:485,y:500,t:1526930290175};\\\", \\\"{x:484,y:500,t:1526930290192};\\\", \\\"{x:483,y:500,t:1526930290214};\\\", \\\"{x:483,y:501,t:1526930290226};\\\", \\\"{x:486,y:503,t:1526930290242};\\\", \\\"{x:494,y:506,t:1526930290260};\\\", \\\"{x:506,y:511,t:1526930290276};\\\", \\\"{x:519,y:518,t:1526930290292};\\\", \\\"{x:536,y:523,t:1526930290309};\\\", \\\"{x:557,y:529,t:1526930290326};\\\", \\\"{x:596,y:535,t:1526930290342};\\\", \\\"{x:642,y:535,t:1526930290360};\\\", \\\"{x:697,y:535,t:1526930290375};\\\", \\\"{x:756,y:535,t:1526930290392};\\\", \\\"{x:795,y:535,t:1526930290409};\\\", \\\"{x:820,y:535,t:1526930290426};\\\", \\\"{x:832,y:533,t:1526930290442};\\\", \\\"{x:835,y:532,t:1526930290460};\\\", \\\"{x:836,y:531,t:1526930290512};\\\", \\\"{x:838,y:530,t:1526930290525};\\\", \\\"{x:851,y:524,t:1526930290543};\\\", \\\"{x:856,y:523,t:1526930290559};\\\", \\\"{x:858,y:522,t:1526930290575};\\\", \\\"{x:858,y:521,t:1526930290607};\\\", \\\"{x:856,y:520,t:1526930290622};\\\", \\\"{x:854,y:519,t:1526930290638};\\\", \\\"{x:853,y:519,t:1526930290647};\\\", \\\"{x:852,y:518,t:1526930290660};\\\", \\\"{x:849,y:517,t:1526930290675};\\\", \\\"{x:848,y:517,t:1526930290693};\\\", \\\"{x:848,y:516,t:1526930290710};\\\", \\\"{x:847,y:516,t:1526930290743};\\\", \\\"{x:846,y:515,t:1526930290775};\\\", \\\"{x:846,y:515,t:1526930290862};\\\", \\\"{x:848,y:515,t:1526930291111};\\\", \\\"{x:853,y:518,t:1526930291125};\\\", \\\"{x:862,y:522,t:1526930291142};\\\", \\\"{x:867,y:524,t:1526930291159};\\\", \\\"{x:879,y:533,t:1526930291175};\\\", \\\"{x:905,y:555,t:1526930291193};\\\", \\\"{x:960,y:603,t:1526930291210};\\\", \\\"{x:1039,y:664,t:1526930291226};\\\", \\\"{x:1120,y:724,t:1526930291243};\\\", \\\"{x:1187,y:770,t:1526930291259};\\\", \\\"{x:1247,y:806,t:1526930291277};\\\", \\\"{x:1275,y:824,t:1526930291293};\\\", \\\"{x:1291,y:835,t:1526930291309};\\\", \\\"{x:1294,y:836,t:1526930291326};\\\", \\\"{x:1293,y:836,t:1526930291488};\\\", \\\"{x:1293,y:835,t:1526930291495};\\\", \\\"{x:1293,y:834,t:1526930291967};\\\", \\\"{x:1292,y:832,t:1526930291977};\\\", \\\"{x:1289,y:831,t:1526930291993};\\\", \\\"{x:1286,y:830,t:1526930292011};\\\", \\\"{x:1283,y:828,t:1526930292028};\\\", \\\"{x:1277,y:826,t:1526930292044};\\\", \\\"{x:1275,y:823,t:1526930292061};\\\", \\\"{x:1270,y:820,t:1526930292078};\\\", \\\"{x:1260,y:814,t:1526930292095};\\\", \\\"{x:1238,y:804,t:1526930292111};\\\", \\\"{x:1225,y:791,t:1526930292128};\\\", \\\"{x:1219,y:780,t:1526930292144};\\\", \\\"{x:1219,y:774,t:1526930292161};\\\", \\\"{x:1219,y:767,t:1526930292178};\\\", \\\"{x:1221,y:759,t:1526930292198};\\\", \\\"{x:1228,y:749,t:1526930292215};\\\", \\\"{x:1245,y:734,t:1526930292232};\\\", \\\"{x:1276,y:717,t:1526930292248};\\\", \\\"{x:1321,y:698,t:1526930292265};\\\", \\\"{x:1399,y:667,t:1526930292282};\\\", \\\"{x:1414,y:661,t:1526930292298};\\\", \\\"{x:1458,y:642,t:1526930292315};\\\", \\\"{x:1475,y:636,t:1526930292332};\\\", \\\"{x:1480,y:634,t:1526930292348};\\\", \\\"{x:1482,y:633,t:1526930292365};\\\", \\\"{x:1482,y:632,t:1526930292387};\\\", \\\"{x:1483,y:631,t:1526930292398};\\\", \\\"{x:1484,y:627,t:1526930292415};\\\", \\\"{x:1485,y:623,t:1526930292431};\\\", \\\"{x:1485,y:618,t:1526930292448};\\\", \\\"{x:1485,y:610,t:1526930292465};\\\", \\\"{x:1481,y:603,t:1526930292482};\\\", \\\"{x:1473,y:595,t:1526930292497};\\\", \\\"{x:1457,y:587,t:1526930292514};\\\", \\\"{x:1439,y:580,t:1526930292531};\\\", \\\"{x:1425,y:575,t:1526930292548};\\\", \\\"{x:1416,y:571,t:1526930292564};\\\", \\\"{x:1415,y:570,t:1526930292582};\\\", \\\"{x:1413,y:570,t:1526930292602};\\\", \\\"{x:1410,y:569,t:1526930292614};\\\", \\\"{x:1404,y:567,t:1526930292631};\\\", \\\"{x:1396,y:566,t:1526930292649};\\\", \\\"{x:1387,y:562,t:1526930292664};\\\", \\\"{x:1377,y:562,t:1526930292681};\\\", \\\"{x:1356,y:561,t:1526930292698};\\\", \\\"{x:1335,y:561,t:1526930292715};\\\", \\\"{x:1306,y:561,t:1526930292731};\\\", \\\"{x:1283,y:561,t:1526930292749};\\\", \\\"{x:1269,y:561,t:1526930292765};\\\", \\\"{x:1261,y:563,t:1526930292781};\\\", \\\"{x:1257,y:564,t:1526930292799};\\\", \\\"{x:1257,y:565,t:1526930292818};\\\", \\\"{x:1257,y:566,t:1526930292875};\\\", \\\"{x:1257,y:567,t:1526930292890};\\\", \\\"{x:1258,y:568,t:1526930292906};\\\", \\\"{x:1261,y:569,t:1526930292915};\\\", \\\"{x:1265,y:571,t:1526930292931};\\\", \\\"{x:1269,y:571,t:1526930292948};\\\", \\\"{x:1270,y:571,t:1526930292966};\\\", \\\"{x:1272,y:573,t:1526930292981};\\\", \\\"{x:1274,y:573,t:1526930292998};\\\", \\\"{x:1275,y:573,t:1526930293015};\\\", \\\"{x:1277,y:573,t:1526930293031};\\\", \\\"{x:1277,y:570,t:1526930293186};\\\", \\\"{x:1277,y:567,t:1526930293198};\\\", \\\"{x:1277,y:564,t:1526930293215};\\\", \\\"{x:1278,y:561,t:1526930293231};\\\", \\\"{x:1278,y:560,t:1526930293249};\\\", \\\"{x:1279,y:560,t:1526930293595};\\\", \\\"{x:1280,y:560,t:1526930293602};\\\", \\\"{x:1281,y:560,t:1526930293616};\\\", \\\"{x:1281,y:561,t:1526930293633};\\\", \\\"{x:1281,y:563,t:1526930293648};\\\", \\\"{x:1281,y:566,t:1526930293665};\\\", \\\"{x:1281,y:569,t:1526930293682};\\\", \\\"{x:1281,y:571,t:1526930293700};\\\", \\\"{x:1281,y:572,t:1526930293715};\\\", \\\"{x:1281,y:574,t:1526930293732};\\\", \\\"{x:1281,y:576,t:1526930293748};\\\", \\\"{x:1281,y:579,t:1526930293766};\\\", \\\"{x:1281,y:582,t:1526930293783};\\\", \\\"{x:1281,y:586,t:1526930293799};\\\", \\\"{x:1281,y:593,t:1526930293816};\\\", \\\"{x:1281,y:597,t:1526930293833};\\\", \\\"{x:1281,y:603,t:1526930293849};\\\", \\\"{x:1281,y:609,t:1526930293866};\\\", \\\"{x:1281,y:626,t:1526930293883};\\\", \\\"{x:1280,y:638,t:1526930293900};\\\", \\\"{x:1278,y:650,t:1526930293915};\\\", \\\"{x:1276,y:661,t:1526930293933};\\\", \\\"{x:1275,y:673,t:1526930293950};\\\", \\\"{x:1274,y:686,t:1526930293965};\\\", \\\"{x:1274,y:704,t:1526930293983};\\\", \\\"{x:1270,y:723,t:1526930294000};\\\", \\\"{x:1270,y:741,t:1526930294016};\\\", \\\"{x:1270,y:759,t:1526930294033};\\\", \\\"{x:1270,y:776,t:1526930294050};\\\", \\\"{x:1270,y:796,t:1526930294066};\\\", \\\"{x:1274,y:827,t:1526930294083};\\\", \\\"{x:1278,y:846,t:1526930294100};\\\", \\\"{x:1279,y:868,t:1526930294116};\\\", \\\"{x:1283,y:888,t:1526930294133};\\\", \\\"{x:1285,y:909,t:1526930294149};\\\", \\\"{x:1287,y:923,t:1526930294166};\\\", \\\"{x:1287,y:937,t:1526930294182};\\\", \\\"{x:1288,y:944,t:1526930294200};\\\", \\\"{x:1288,y:949,t:1526930294216};\\\", \\\"{x:1288,y:953,t:1526930294233};\\\", \\\"{x:1288,y:958,t:1526930294250};\\\", \\\"{x:1288,y:964,t:1526930294266};\\\", \\\"{x:1288,y:973,t:1526930294283};\\\", \\\"{x:1288,y:977,t:1526930294300};\\\", \\\"{x:1287,y:979,t:1526930294316};\\\", \\\"{x:1287,y:980,t:1526930294338};\\\", \\\"{x:1287,y:981,t:1526930294818};\\\", \\\"{x:1287,y:982,t:1526930294833};\\\", \\\"{x:1287,y:981,t:1526930294882};\\\", \\\"{x:1287,y:980,t:1526930294906};\\\", \\\"{x:1287,y:979,t:1526930295539};\\\", \\\"{x:1285,y:978,t:1526930297875};\\\", \\\"{x:1275,y:971,t:1526930297886};\\\", \\\"{x:1231,y:937,t:1526930297902};\\\", \\\"{x:1180,y:899,t:1526930297920};\\\", \\\"{x:1124,y:863,t:1526930297936};\\\", \\\"{x:1065,y:818,t:1526930297952};\\\", \\\"{x:1014,y:767,t:1526930297969};\\\", \\\"{x:948,y:672,t:1526930297986};\\\", \\\"{x:916,y:622,t:1526930298003};\\\", \\\"{x:903,y:594,t:1526930298018};\\\", \\\"{x:902,y:581,t:1526930298035};\\\", \\\"{x:901,y:572,t:1526930298053};\\\", \\\"{x:900,y:563,t:1526930298070};\\\", \\\"{x:898,y:552,t:1526930298085};\\\", \\\"{x:893,y:542,t:1526930298102};\\\", \\\"{x:885,y:531,t:1526930298118};\\\", \\\"{x:876,y:516,t:1526930298135};\\\", \\\"{x:865,y:497,t:1526930298153};\\\", \\\"{x:832,y:459,t:1526930298169};\\\", \\\"{x:816,y:444,t:1526930298185};\\\", \\\"{x:813,y:439,t:1526930298202};\\\", \\\"{x:814,y:439,t:1526930298250};\\\", \\\"{x:816,y:439,t:1526930298265};\\\", \\\"{x:817,y:439,t:1526930298274};\\\", \\\"{x:819,y:441,t:1526930298286};\\\", \\\"{x:820,y:449,t:1526930298303};\\\", \\\"{x:820,y:464,t:1526930298320};\\\", \\\"{x:821,y:482,t:1526930298336};\\\", \\\"{x:822,y:492,t:1526930298353};\\\", \\\"{x:824,y:497,t:1526930298370};\\\", \\\"{x:825,y:500,t:1526930298386};\\\", \\\"{x:826,y:500,t:1526930298410};\\\", \\\"{x:827,y:500,t:1526930298435};\\\", \\\"{x:827,y:501,t:1526930298492};\\\", \\\"{x:829,y:501,t:1526930298503};\\\", \\\"{x:831,y:502,t:1526930298519};\\\", \\\"{x:832,y:503,t:1526930298535};\\\", \\\"{x:833,y:504,t:1526930298553};\\\", \\\"{x:834,y:507,t:1526930298578};\\\", \\\"{x:832,y:508,t:1526930299418};\\\", \\\"{x:817,y:518,t:1526930299426};\\\", \\\"{x:796,y:527,t:1526930299436};\\\", \\\"{x:737,y:547,t:1526930299453};\\\", \\\"{x:654,y:570,t:1526930299470};\\\", \\\"{x:594,y:582,t:1526930299486};\\\", \\\"{x:564,y:586,t:1526930299503};\\\", \\\"{x:558,y:586,t:1526930299520};\\\", \\\"{x:557,y:586,t:1526930299538};\\\", \\\"{x:558,y:582,t:1526930299553};\\\", \\\"{x:562,y:576,t:1526930299570};\\\", \\\"{x:566,y:572,t:1526930299587};\\\", \\\"{x:567,y:571,t:1526930299604};\\\", \\\"{x:568,y:567,t:1526930299620};\\\", \\\"{x:570,y:561,t:1526930299636};\\\", \\\"{x:572,y:555,t:1526930299653};\\\", \\\"{x:577,y:546,t:1526930299671};\\\", \\\"{x:578,y:542,t:1526930299686};\\\", \\\"{x:582,y:538,t:1526930299704};\\\", \\\"{x:582,y:535,t:1526930299721};\\\", \\\"{x:584,y:531,t:1526930299737};\\\", \\\"{x:588,y:526,t:1526930299754};\\\", \\\"{x:590,y:523,t:1526930299770};\\\", \\\"{x:592,y:522,t:1526930299787};\\\", \\\"{x:595,y:521,t:1526930299804};\\\", \\\"{x:596,y:520,t:1526930299820};\\\", \\\"{x:599,y:518,t:1526930299837};\\\", \\\"{x:601,y:517,t:1526930299855};\\\", \\\"{x:604,y:516,t:1526930299870};\\\", \\\"{x:606,y:515,t:1526930299886};\\\", \\\"{x:607,y:515,t:1526930299903};\\\", \\\"{x:607,y:517,t:1526930300169};\\\", \\\"{x:592,y:566,t:1526930300189};\\\", \\\"{x:575,y:638,t:1526930300204};\\\", \\\"{x:560,y:693,t:1526930300222};\\\", \\\"{x:554,y:735,t:1526930300238};\\\", \\\"{x:552,y:760,t:1526930300253};\\\", \\\"{x:550,y:778,t:1526930300270};\\\", \\\"{x:550,y:789,t:1526930300287};\\\", \\\"{x:550,y:794,t:1526930300303};\\\", \\\"{x:551,y:795,t:1526930300320};\\\", \\\"{x:552,y:795,t:1526930300410};\\\", \\\"{x:552,y:793,t:1526930300442};\\\", \\\"{x:552,y:791,t:1526930300454};\\\", \\\"{x:552,y:784,t:1526930300471};\\\", \\\"{x:552,y:776,t:1526930300488};\\\", \\\"{x:546,y:762,t:1526930300504};\\\", \\\"{x:543,y:757,t:1526930300520};\\\", \\\"{x:542,y:753,t:1526930300537};\\\", \\\"{x:541,y:752,t:1526930300562};\\\", \\\"{x:541,y:751,t:1526930300602};\\\", \\\"{x:541,y:750,t:1526930300610};\\\", \\\"{x:541,y:748,t:1526930300626};\\\", \\\"{x:541,y:747,t:1526930300637};\\\", \\\"{x:541,y:746,t:1526930300654};\\\", \\\"{x:541,y:744,t:1526930300672};\\\", \\\"{x:540,y:743,t:1526930300687};\\\", \\\"{x:544,y:743,t:1526930301410};\\\", \\\"{x:552,y:744,t:1526930301422};\\\", \\\"{x:564,y:750,t:1526930301439};\\\", \\\"{x:579,y:756,t:1526930301454};\\\", \\\"{x:600,y:765,t:1526930301471};\\\", \\\"{x:635,y:780,t:1526930301489};\\\", \\\"{x:681,y:795,t:1526930301504};\\\", \\\"{x:744,y:824,t:1526930301521};\\\", \\\"{x:782,y:839,t:1526930301538};\\\", \\\"{x:818,y:854,t:1526930301554};\\\", \\\"{x:840,y:865,t:1526930301571};\\\", \\\"{x:856,y:870,t:1526930301589};\\\", \\\"{x:861,y:871,t:1526930301604};\\\", \\\"{x:861,y:871,t:1526930301771};\\\", \\\"{x:869,y:870,t:1526930302636};\\\", \\\"{x:894,y:858,t:1526930302642};\\\", \\\"{x:933,y:845,t:1526930302656};\\\", \\\"{x:1018,y:814,t:1526930302674};\\\", \\\"{x:1181,y:769,t:1526930302690};\\\", \\\"{x:1293,y:730,t:1526930302707};\\\", \\\"{x:1387,y:703,t:1526930302723};\\\", \\\"{x:1456,y:674,t:1526930302740};\\\", \\\"{x:1486,y:659,t:1526930302756};\\\", \\\"{x:1495,y:653,t:1526930302773};\\\", \\\"{x:1496,y:649,t:1526930302790};\\\", \\\"{x:1498,y:645,t:1526930302807};\\\", \\\"{x:1499,y:637,t:1526930302823};\\\", \\\"{x:1499,y:630,t:1526930302840};\\\", \\\"{x:1497,y:620,t:1526930302856};\\\", \\\"{x:1480,y:606,t:1526930302873};\\\", \\\"{x:1447,y:585,t:1526930302890};\\\", \\\"{x:1423,y:571,t:1526930302906};\\\", \\\"{x:1399,y:560,t:1526930302924};\\\", \\\"{x:1382,y:554,t:1526930302940};\\\", \\\"{x:1374,y:553,t:1526930302956};\\\", \\\"{x:1369,y:553,t:1526930302973};\\\", \\\"{x:1361,y:553,t:1526930302990};\\\", \\\"{x:1352,y:553,t:1526930303006};\\\", \\\"{x:1341,y:553,t:1526930303023};\\\", \\\"{x:1327,y:554,t:1526930303040};\\\", \\\"{x:1310,y:558,t:1526930303056};\\\", \\\"{x:1294,y:562,t:1526930303073};\\\", \\\"{x:1278,y:565,t:1526930303090};\\\", \\\"{x:1273,y:568,t:1526930303107};\\\", \\\"{x:1272,y:569,t:1526930303123};\\\", \\\"{x:1272,y:570,t:1526930303140};\\\", \\\"{x:1272,y:571,t:1526930303170};\\\", \\\"{x:1273,y:571,t:1526930303178};\\\", \\\"{x:1273,y:572,t:1526930303203};\\\", \\\"{x:1275,y:572,t:1526930303218};\\\", \\\"{x:1276,y:573,t:1526930303243};\\\", \\\"{x:1277,y:574,t:1526930303257};\\\", \\\"{x:1278,y:574,t:1526930303273};\\\", \\\"{x:1279,y:575,t:1526930303290};\\\", \\\"{x:1280,y:575,t:1526930303570};\\\", \\\"{x:1281,y:577,t:1526930303594};\\\", \\\"{x:1282,y:577,t:1526930303610};\\\", \\\"{x:1282,y:578,t:1526930303803};\\\", \\\"{x:1283,y:578,t:1526930303836};\\\", \\\"{x:1283,y:579,t:1526930303843};\\\", \\\"{x:1283,y:581,t:1526930303858};\\\", \\\"{x:1283,y:584,t:1526930303874};\\\", \\\"{x:1283,y:590,t:1526930303890};\\\", \\\"{x:1283,y:595,t:1526930303907};\\\", \\\"{x:1283,y:598,t:1526930303924};\\\", \\\"{x:1283,y:603,t:1526930303941};\\\", \\\"{x:1283,y:605,t:1526930303957};\\\", \\\"{x:1283,y:609,t:1526930303974};\\\", \\\"{x:1283,y:613,t:1526930303990};\\\", \\\"{x:1283,y:619,t:1526930304007};\\\", \\\"{x:1282,y:624,t:1526930304025};\\\", \\\"{x:1282,y:626,t:1526930304041};\\\", \\\"{x:1282,y:628,t:1526930304057};\\\", \\\"{x:1281,y:630,t:1526930304074};\\\", \\\"{x:1281,y:631,t:1526930304131};\\\", \\\"{x:1281,y:632,t:1526930304141};\\\", \\\"{x:1281,y:633,t:1526930304157};\\\", \\\"{x:1281,y:635,t:1526930304173};\\\", \\\"{x:1281,y:636,t:1526930304191};\\\", \\\"{x:1280,y:640,t:1526930304207};\\\", \\\"{x:1279,y:644,t:1526930304223};\\\", \\\"{x:1278,y:649,t:1526930304240};\\\", \\\"{x:1278,y:658,t:1526930304256};\\\", \\\"{x:1276,y:674,t:1526930304273};\\\", \\\"{x:1274,y:685,t:1526930304291};\\\", \\\"{x:1273,y:695,t:1526930304307};\\\", \\\"{x:1271,y:707,t:1526930304324};\\\", \\\"{x:1269,y:719,t:1526930304341};\\\", \\\"{x:1267,y:732,t:1526930304356};\\\", \\\"{x:1266,y:747,t:1526930304373};\\\", \\\"{x:1263,y:763,t:1526930304391};\\\", \\\"{x:1262,y:780,t:1526930304407};\\\", \\\"{x:1262,y:782,t:1526930304423};\\\", \\\"{x:1261,y:785,t:1526930304771};\\\", \\\"{x:1261,y:787,t:1526930304778};\\\", \\\"{x:1261,y:791,t:1526930304791};\\\", \\\"{x:1258,y:807,t:1526930304808};\\\", \\\"{x:1257,y:823,t:1526930304824};\\\", \\\"{x:1252,y:844,t:1526930304841};\\\", \\\"{x:1248,y:877,t:1526930304858};\\\", \\\"{x:1248,y:896,t:1526930304874};\\\", \\\"{x:1248,y:912,t:1526930304892};\\\", \\\"{x:1248,y:924,t:1526930304908};\\\", \\\"{x:1250,y:933,t:1526930304924};\\\", \\\"{x:1252,y:941,t:1526930304941};\\\", \\\"{x:1253,y:942,t:1526930304958};\\\", \\\"{x:1253,y:943,t:1526930304974};\\\", \\\"{x:1254,y:944,t:1526930304991};\\\", \\\"{x:1254,y:945,t:1526930305008};\\\", \\\"{x:1255,y:949,t:1526930305025};\\\", \\\"{x:1257,y:952,t:1526930305041};\\\", \\\"{x:1259,y:954,t:1526930305058};\\\", \\\"{x:1260,y:955,t:1526930305075};\\\", \\\"{x:1262,y:957,t:1526930305091};\\\", \\\"{x:1263,y:958,t:1526930305108};\\\", \\\"{x:1264,y:959,t:1526930305125};\\\", \\\"{x:1262,y:958,t:1526930305299};\\\", \\\"{x:1257,y:956,t:1526930305309};\\\", \\\"{x:1244,y:950,t:1526930305325};\\\", \\\"{x:1227,y:942,t:1526930305342};\\\", \\\"{x:1207,y:932,t:1526930305358};\\\", \\\"{x:1177,y:920,t:1526930305375};\\\", \\\"{x:1149,y:912,t:1526930305391};\\\", \\\"{x:1101,y:896,t:1526930305408};\\\", \\\"{x:1023,y:876,t:1526930305425};\\\", \\\"{x:937,y:849,t:1526930305442};\\\", \\\"{x:819,y:821,t:1526930305457};\\\", \\\"{x:753,y:805,t:1526930305474};\\\", \\\"{x:691,y:793,t:1526930305491};\\\", \\\"{x:639,y:781,t:1526930305507};\\\", \\\"{x:607,y:772,t:1526930305525};\\\", \\\"{x:598,y:769,t:1526930305542};\\\", \\\"{x:597,y:768,t:1526930305557};\\\", \\\"{x:596,y:768,t:1526930306650};\\\", \\\"{x:596,y:767,t:1526930307859};\\\", \\\"{x:591,y:765,t:1526930307866};\\\", \\\"{x:582,y:761,t:1526930307876};\\\", \\\"{x:566,y:751,t:1526930307893};\\\", \\\"{x:554,y:746,t:1526930307911};\\\", \\\"{x:541,y:740,t:1526930307927};\\\", \\\"{x:532,y:736,t:1526930307943};\\\", \\\"{x:529,y:735,t:1526930307959};\\\", \\\"{x:529,y:736,t:1526930307985};\\\", \\\"{x:529,y:738,t:1526930307993};\\\", \\\"{x:531,y:739,t:1526930308010};\\\", \\\"{x:532,y:739,t:1526930308146};\\\", \\\"{x:533,y:741,t:1526930308160};\\\", \\\"{x:538,y:743,t:1526930308177};\\\", \\\"{x:541,y:744,t:1526930308194};\\\", \\\"{x:541,y:745,t:1526930308250};\\\", \\\"{x:542,y:745,t:1526930308609};\\\", \\\"{x:550,y:747,t:1526930308618};\\\", \\\"{x:561,y:750,t:1526930308627};\\\", \\\"{x:583,y:753,t:1526930308644};\\\", \\\"{x:619,y:753,t:1526930308661};\\\", \\\"{x:646,y:753,t:1526930308676};\\\", \\\"{x:673,y:753,t:1526930308694};\\\", \\\"{x:691,y:754,t:1526930308711};\\\", \\\"{x:699,y:756,t:1526930308727};\\\", \\\"{x:700,y:756,t:1526930308744};\\\" ] }, { \\\"rt\\\": 20801, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 654089, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"lOOK AT THE X-AXIS FOR 12 PM AND SEE THE DOTS THAT MATCH UP WITH IT.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6940, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"TAIWAN\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 662036, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 11291, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 674343, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 10710, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 686141, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"EGP0T\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"EGP0T\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 191, dom: 963, initialDom: 1052",
  "javascriptErrors": []
}