var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4ee213417f204fc82af6e0b10b7783b2",
  "created": "2018-05-24T12:03:45.7146529-07:00",
  "lastActivity": "2018-05-24T12:05:50.7869382-07:00",
  "pageViews": [
    {
      "id": "05244517cf8bc5ae031d9232d4d6b4c244b6b63f",
      "startTime": "2018-05-24T12:03:45.7146529-07:00",
      "endTime": "2018-05-24T12:05:50.7869382-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 125208,
      "engagementTime": 76129,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 125208,
  "engagementTime": 76129,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eda92c57e8fb767ad91feea3acc0d3fb",
  "gdpr": false
}