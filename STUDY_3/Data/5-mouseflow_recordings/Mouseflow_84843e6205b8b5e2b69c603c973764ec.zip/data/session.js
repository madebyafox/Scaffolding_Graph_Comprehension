var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "84843e6205b8b5e2b69c603c973764ec",
  "created": "2018-05-21T12:22:50.9653379-07:00",
  "lastActivity": "2018-05-21T12:23:32.0938811-07:00",
  "pageViews": [
    {
      "id": "052151236e9be2e7b1ea54d3d327893ef8318eb7",
      "startTime": "2018-05-21T12:22:50.9758811-07:00",
      "endTime": "2018-05-21T12:23:32.0938811-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 41118,
      "engagementTime": 41016,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 41118,
  "engagementTime": 41016,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J1JP6",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "acadb5d7e37545c8fa8c0476f6faf194",
  "gdpr": false
}