var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b29cec2b5c3900188c37aeafd06cafda",
  "created": "2018-05-29T10:10:02.8308576-07:00",
  "lastActivity": "2018-05-29T10:10:18.2288576-07:00",
  "pageViews": [
    {
      "id": "052903633c77ff634396ea44ff456a2c409c52aa",
      "startTime": "2018-05-29T10:10:02.8308576-07:00",
      "endTime": "2018-05-29T10:10:18.2288576-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 15398,
      "engagementTime": 15398,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15398,
  "engagementTime": 15398,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TGOML",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ff13348b3a5f6b745c9b252dbb7c00d1",
  "gdpr": false
}