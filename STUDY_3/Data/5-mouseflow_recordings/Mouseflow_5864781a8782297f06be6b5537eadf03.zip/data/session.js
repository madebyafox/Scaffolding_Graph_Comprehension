var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5864781a8782297f06be6b5537eadf03",
  "created": "2018-05-25T10:17:20.6692583-07:00",
  "lastActivity": "2018-05-25T10:18:46.4492583-07:00",
  "pageViews": [
    {
      "id": "05252043b4458ab0bd699eebcc6950b8544c4ad2",
      "startTime": "2018-05-25T10:17:20.6692583-07:00",
      "endTime": "2018-05-25T10:18:46.4492583-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 85780,
      "engagementTime": 82625,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 85780,
  "engagementTime": 82625,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=85HJP",
    "CONDITION=1/5"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1abbfd319d5097309bb95019f1f6bbed",
  "gdpr": false
}