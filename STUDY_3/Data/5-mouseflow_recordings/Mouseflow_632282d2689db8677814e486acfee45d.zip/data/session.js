var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "632282d2689db8677814e486acfee45d",
  "created": "2018-06-04T12:18:04.5770658-07:00",
  "lastActivity": "2018-06-04T12:19:34.5219642-07:00",
  "pageViews": [
    {
      "id": "0604049843ee8f6daeea642ec30ffaef6bd45722",
      "startTime": "2018-06-04T12:18:04.7172576-07:00",
      "endTime": "2018-06-04T12:19:34.5219642-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 89927,
      "engagementTime": 61435,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 89927,
  "engagementTime": 61435,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=BK993",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d1b50dbea2023e01a2c1f1879bc465b7",
  "gdpr": false
}