var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cd9bf4f8d2c45a5cc5b00b7a339b2e19",
  "created": "2018-06-04T13:17:50.7841239-07:00",
  "lastActivity": "2018-06-04T13:18:11.8101239-07:00",
  "pageViews": [
    {
      "id": "06045198804ce3660e6dd2c925c8fadd032394e3",
      "startTime": "2018-06-04T13:17:50.7841239-07:00",
      "endTime": "2018-06-04T13:18:11.8101239-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 21026,
      "engagementTime": 21026,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21026,
  "engagementTime": 21026,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Z5GWP",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "24815663bf37e7c19f1f9fe5c0a10040",
  "gdpr": false
}