var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "da2d80efb8997e42d03c60a2b00dcc57",
  "created": "2018-06-01T11:19:17.5563199-07:00",
  "lastActivity": "2018-06-01T11:19:39.7683199-07:00",
  "pageViews": [
    {
      "id": "06011745812bacff7cd08ed5de98d0b04b199140",
      "startTime": "2018-06-01T11:19:17.5563199-07:00",
      "endTime": "2018-06-01T11:19:39.7683199-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 22212,
      "engagementTime": 22212,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22212,
  "engagementTime": 22212,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "59fcd85211e2e80ecc851e934652b9ad",
  "gdpr": false
}