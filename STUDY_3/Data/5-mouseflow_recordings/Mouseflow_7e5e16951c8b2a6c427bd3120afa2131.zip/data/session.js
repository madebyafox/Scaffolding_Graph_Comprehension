var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7e5e16951c8b2a6c427bd3120afa2131",
  "created": "2018-05-15T17:08:14.0310954-07:00",
  "lastActivity": "2018-05-15T17:08:25.8933833-07:00",
  "pageViews": [
    {
      "id": "051514590f7618843afb96b0b4f2773839c8876f",
      "startTime": "2018-05-15T17:08:14.2873833-07:00",
      "endTime": "2018-05-15T17:08:25.8933833-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 11606,
      "engagementTime": 11584,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11606,
  "engagementTime": 11584,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TVQKD",
    "CONDITION=121",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b02d53354d0f5a5d666d5e04a8e64352",
  "gdpr": false
}