var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "602a1d22e990fa3c7627f92e6401e213",
  "created": "2018-06-04T12:14:41.5646837-07:00",
  "lastActivity": "2018-06-04T12:15:27.4432302-07:00",
  "pageViews": [
    {
      "id": "060441937b9a27addad8a682b8c6fe4b8b61ce5d",
      "startTime": "2018-06-04T12:14:41.5646837-07:00",
      "endTime": "2018-06-04T12:15:27.4666837-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 45902,
      "engagementTime": 39902,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 45902,
  "engagementTime": 39902,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZEPVG",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b16412f216d2dd2275121d96b577f5dc",
  "gdpr": false
}