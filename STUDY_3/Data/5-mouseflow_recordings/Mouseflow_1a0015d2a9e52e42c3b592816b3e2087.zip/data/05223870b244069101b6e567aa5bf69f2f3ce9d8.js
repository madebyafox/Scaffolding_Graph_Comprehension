var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05223870b244069101b6e567aa5bf69f2f3ce9d8"] = {
  "startTime": "2018-05-22T21:12:38.3788398Z",
  "websitePageUrl": "/16",
  "visitTime": 87397,
  "engagementTime": 85430,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1a0015d2a9e52e42c3b592816b3e2087",
    "created": "2018-05-22T21:12:38.3788398+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=D3LUH",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "fe51f02cf8b13b2fc12b90b551ce688b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1a0015d2a9e52e42c3b592816b3e2087/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 667,
      "e": 667,
      "ty": 2,
      "x": 551,
      "y": 733
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 554,
      "y": 732
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 51698,
      "y": 39996,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 557,
      "y": 730
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 533,
      "y": 714
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 45515,
      "y": 37503,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 484,
      "y": 666
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 479,
      "y": 634
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 479,
      "y": 608
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 42930,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 1506,
      "e": 1506,
      "ty": 6,
      "x": 479,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 481,
      "y": 597
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 481,
      "y": 596
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 43154,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 485,
      "y": 581
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 485,
      "y": 578
    },
    {
      "t": 1988,
      "e": 1988,
      "ty": 3,
      "x": 485,
      "y": 578,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1989,
      "e": 1989,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 43604,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2067,
      "e": 2067,
      "ty": 4,
      "x": 43604,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2068,
      "e": 2068,
      "ty": 5,
      "x": 485,
      "y": 578,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 554,
      "y": 574
    },
    {
      "t": 2476,
      "e": 2476,
      "ty": 7,
      "x": 701,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 718,
      "y": 574
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 2175,
      "y": 30956,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 770,
      "y": 580
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 784,
      "y": 563
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 705,
      "y": 26357,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 796,
      "y": 465
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 799,
      "y": 438
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 808,
      "y": 434
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 1551,
      "y": 21200,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 1149,
      "y": 749
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 31288,
      "y": 48631,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 1263,
      "y": 854
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 1266,
      "y": 878
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 1257,
      "y": 896
    },
    {
      "t": 8390,
      "e": 8390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8560,
      "e": 8560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8560,
      "e": 8560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8623,
      "e": 8623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 8638,
      "e": 8638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 8703,
      "e": 8703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8703,
      "e": 8703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8871,
      "e": 8871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 8873,
      "e": 8873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8873,
      "e": 8873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8902,
      "e": 8902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8902,
      "e": 8902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8943,
      "e": 8943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 9014,
      "e": 9014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9022,
      "e": 9022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9022,
      "e": 9022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9142,
      "e": 9142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 9247,
      "e": 9247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 9247,
      "e": 9247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9344,
      "e": 9344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9344,
      "e": 9344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9406,
      "e": 9406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9406,
      "e": 9406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9415,
      "e": 9415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ine"
    },
    {
      "t": 9498,
      "e": 9498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9499,
      "e": 9499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 9499,
      "e": 9499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9566,
      "e": 9566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 9590,
      "e": 9590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9591,
      "e": 9591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9607,
      "e": 9607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9655,
      "e": 9655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10439,
      "e": 10439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10439,
      "e": 10439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10679,
      "e": 10679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10680,
      "e": 10680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10790,
      "e": 10790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 10815,
      "e": 10815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10816,
      "e": 10816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10919,
      "e": 10919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10920,
      "e": 10920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10951,
      "e": 10951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 10998,
      "e": 10998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11023,
      "e": 11023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11023,
      "e": 11023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11103,
      "e": 11103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11279,
      "e": 11279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11280,
      "e": 11280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11383,
      "e": 11383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 11463,
      "e": 11463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11466,
      "e": 11466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11534,
      "e": 11534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 11535,
      "e": 11535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11622,
      "e": 11622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 11631,
      "e": 11631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11799,
      "e": 11799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11800,
      "e": 11800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11871,
      "e": 11871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11872,
      "e": 11872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11895,
      "e": 11895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 11959,
      "e": 11959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12015,
      "e": 12015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12015,
      "e": 12015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12095,
      "e": 12095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12203,
      "e": 12203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come o"
    },
    {
      "t": 12239,
      "e": 12239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 12240,
      "e": 12240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12342,
      "e": 12342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 12343,
      "e": 12343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12343,
      "e": 12343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12391,
      "e": 12391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12399,
      "e": 12399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12399,
      "e": 12399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12495,
      "e": 12495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12559,
      "e": 12559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12560,
      "e": 12560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12614,
      "e": 12614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12614,
      "e": 12614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12646,
      "e": 12646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 12678,
      "e": 12678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12678,
      "e": 12678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12695,
      "e": 12695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12759,
      "e": 12759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14654,
      "e": 14654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 14655,
      "e": 14655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14759,
      "e": 14759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 14759,
      "e": 14759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14798,
      "e": 14798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 14814,
      "e": 14814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14871,
      "e": 14871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14872,
      "e": 14872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14927,
      "e": 14927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15111,
      "e": 15111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15112,
      "e": 15112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15174,
      "e": 15174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 15295,
      "e": 15295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15296,
      "e": 15296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15367,
      "e": 15367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 16136,
      "e": 16136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16136,
      "e": 16136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16216,
      "e": 16216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16303,
      "e": 16303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16304,
      "e": 16304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16367,
      "e": 16367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16367,
      "e": 16367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16382,
      "e": 16382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 16423,
      "e": 16423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16511,
      "e": 16511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16512,
      "e": 16512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16574,
      "e": 16574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16575,
      "e": 16575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16614,
      "e": 16614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16614,
      "e": 16614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16630,
      "e": 16630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ing"
    },
    {
      "t": 16687,
      "e": 16687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16687,
      "e": 16687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16710,
      "e": 16710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16718,
      "e": 16718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16767,
      "e": 16767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16831,
      "e": 16831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16832,
      "e": 16832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16878,
      "e": 16878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16879,
      "e": 16879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16895,
      "e": 16895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 16976,
      "e": 16976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16976,
      "e": 16976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16977,
      "e": 16977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17030,
      "e": 17030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17086,
      "e": 17086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17086,
      "e": 17086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17175,
      "e": 17175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17256,
      "e": 17256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17257,
      "e": 17257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17351,
      "e": 17351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17351,
      "e": 17351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17351,
      "e": 17351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17439,
      "e": 17439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17440,
      "e": 17440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17470,
      "e": 17470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 17519,
      "e": 17519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17567,
      "e": 17567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17568,
      "e": 17568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17663,
      "e": 17663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 17767,
      "e": 17767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17768,
      "e": 17768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17847,
      "e": 17847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17847,
      "e": 17847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17855,
      "e": 17855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 17927,
      "e": 17927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17935,
      "e": 17935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17936,
      "e": 17936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18015,
      "e": 18015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18016,
      "e": 18016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18031,
      "e": 18031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 18079,
      "e": 18079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18079,
      "e": 18079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18134,
      "e": 18134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18175,
      "e": 18175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18207,
      "e": 18207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18208,
      "e": 18208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18279,
      "e": 18279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18280,
      "e": 18280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18303,
      "e": 18303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 18361,
      "e": 18305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18363,
      "e": 18307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18398,
      "e": 18342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18439,
      "e": 18383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18648,
      "e": 18592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18649,
      "e": 18593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18719,
      "e": 18663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18839,
      "e": 18783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18839,
      "e": 18783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18910,
      "e": 18854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18911,
      "e": 18855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18951,
      "e": 18895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18951,
      "e": 18895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18982,
      "e": 18926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ine"
    },
    {
      "t": 19022,
      "e": 18966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19102,
      "e": 19046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19103,
      "e": 19047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19167,
      "e": 19111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19248,
      "e": 19192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19255,
      "e": 19199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19256,
      "e": 19200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19296,
      "e": 19240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19403,
      "e": 19347,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines "
    },
    {
      "t": 19463,
      "e": 19407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19464,
      "e": 19408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19527,
      "e": 19471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19671,
      "e": 19615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19672,
      "e": 19616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19750,
      "e": 19694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19750,
      "e": 19694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19751,
      "e": 19695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19831,
      "e": 19775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19831,
      "e": 19775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19886,
      "e": 19830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 19903,
      "e": 19847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19904,
      "e": 19848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19935,
      "e": 19879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19983,
      "e": 19927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20386,
      "e": 20330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20387,
      "e": 20331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20456,
      "e": 20400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20457,
      "e": 20401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20497,
      "e": 20441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 20602,
      "e": 20546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20602,
      "e": 20546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 20602,
      "e": 20546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20657,
      "e": 20601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20657,
      "e": 20601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20689,
      "e": 20633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 20785,
      "e": 20729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20786,
      "e": 20730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20825,
      "e": 20769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20833,
      "e": 20777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20833,
      "e": 20777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20866,
      "e": 20810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20978,
      "e": 20922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20978,
      "e": 20922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21001,
      "e": 20945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21049,
      "e": 20993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21097,
      "e": 21041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21097,
      "e": 21041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21205,
      "e": 21149,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a s"
    },
    {
      "t": 21209,
      "e": 21153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21226,
      "e": 21170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21226,
      "e": 21170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21313,
      "e": 21257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21313,
      "e": 21257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21345,
      "e": 21289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 21401,
      "e": 21345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21402,
      "e": 21346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21425,
      "e": 21369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 21482,
      "e": 21426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21586,
      "e": 21530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21587,
      "e": 21531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21689,
      "e": 21633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21689,
      "e": 21633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21697,
      "e": 21641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 21769,
      "e": 21713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21825,
      "e": 21769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21826,
      "e": 21770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21977,
      "e": 21921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22001,
      "e": 21945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22001,
      "e": 21945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22073,
      "e": 22017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22130,
      "e": 22074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22130,
      "e": 22074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22233,
      "e": 22177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22233,
      "e": 22177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22234,
      "e": 22178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22321,
      "e": 22265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22322,
      "e": 22266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22353,
      "e": 22297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 22409,
      "e": 22353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 22409,
      "e": 22353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22417,
      "e": 22361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 22497,
      "e": 22441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22513,
      "e": 22457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22513,
      "e": 22457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22586,
      "e": 22530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22778,
      "e": 22722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 22779,
      "e": 22723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22809,
      "e": 22753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 23409,
      "e": 23353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23481,
      "e": 23425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23481,
      "e": 23425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23529,
      "e": 23473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 23569,
      "e": 23513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23690,
      "e": 23634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23690,
      "e": 23634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23769,
      "e": 23713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23770,
      "e": 23714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23793,
      "e": 23737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23793,
      "e": 23737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23817,
      "e": 23761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ine"
    },
    {
      "t": 23849,
      "e": 23793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23850,
      "e": 23794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23882,
      "e": 23795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23913,
      "e": 23826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23938,
      "e": 23851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23938,
      "e": 23851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23969,
      "e": 23882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23985,
      "e": 23898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24034,
      "e": 23947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24034,
      "e": 23947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24129,
      "e": 24042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 24169,
      "e": 24082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24169,
      "e": 24082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24217,
      "e": 24130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24305,
      "e": 24218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24306,
      "e": 24219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24393,
      "e": 24306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24393,
      "e": 24306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24433,
      "e": 24346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24433,
      "e": 24346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24449,
      "e": 24362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ing"
    },
    {
      "t": 24498,
      "e": 24411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24498,
      "e": 24411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24506,
      "e": 24419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24521,
      "e": 24434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24570,
      "e": 24483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24682,
      "e": 24595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24683,
      "e": 24596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24737,
      "e": 24650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24745,
      "e": 24658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24745,
      "e": 24658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24809,
      "e": 24722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24809,
      "e": 24722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24849,
      "e": 24762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 24873,
      "e": 24786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24913,
      "e": 24826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24914,
      "e": 24827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24978,
      "e": 24891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24993,
      "e": 24906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24994,
      "e": 24907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25081,
      "e": 24994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25082,
      "e": 24995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25088,
      "e": 25001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 25129,
      "e": 25042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25129,
      "e": 25042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25153,
      "e": 25066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25193,
      "e": 25106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25249,
      "e": 25162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25250,
      "e": 25163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25297,
      "e": 25210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25297,
      "e": 25210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25337,
      "e": 25250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 25337,
      "e": 25250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25360,
      "e": 25273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lef"
    },
    {
      "t": 25378,
      "e": 25291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25425,
      "e": 25338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25537,
      "e": 25450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25538,
      "e": 25451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25617,
      "e": 25530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25633,
      "e": 25546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25633,
      "e": 25546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25714,
      "e": 25627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25809,
      "e": 25722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25810,
      "e": 25723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25913,
      "e": 25826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25921,
      "e": 25834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25922,
      "e": 25835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26098,
      "e": 26011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26106,
      "e": 26019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 26107,
      "e": 26020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26169,
      "e": 26082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 26442,
      "e": 26355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26505,
      "e": 26418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going to the left ha"
    },
    {
      "t": 26601,
      "e": 26514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26648,
      "e": 26561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going to the left h"
    },
    {
      "t": 26737,
      "e": 26650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27237,
      "e": 27150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27269,
      "e": 27182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27302,
      "e": 27215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27335,
      "e": 27248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27369,
      "e": 27282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27401,
      "e": 27314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27435,
      "e": 27348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27468,
      "e": 27381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27500,
      "e": 27413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27513,
      "e": 27426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going to "
    },
    {
      "t": 27953,
      "e": 27866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28002,
      "e": 27867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going to"
    },
    {
      "t": 28097,
      "e": 27962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28153,
      "e": 28018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going t"
    },
    {
      "t": 28233,
      "e": 28098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28280,
      "e": 28145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going "
    },
    {
      "t": 28403,
      "e": 28268,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to the right is lines that have a shift start. \nLines going "
    },
    {
      "t": 28914,
      "e": 28779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28915,
      "e": 28780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28977,
      "e": 28842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28977,
      "e": 28842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29000,
      "e": 28865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 29065,
      "e": 28930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29066,
      "e": 28931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29089,
      "e": 28954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29129,
      "e": 28994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29145,
      "e": 29010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29146,
      "e": 29011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29216,
      "e": 29081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29217,
      "e": 29082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29241,
      "e": 29106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 29289,
      "e": 29154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29289,
      "e": 29154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29329,
      "e": 29194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 29353,
      "e": 29218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29353,
      "e": 29218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29386,
      "e": 29251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29418,
      "e": 29283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29538,
      "e": 29403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29539,
      "e": 29404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29617,
      "e": 29482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29617,
      "e": 29482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29625,
      "e": 29490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 29665,
      "e": 29530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29665,
      "e": 29530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29697,
      "e": 29562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29737,
      "e": 29602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30169,
      "e": 30034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30170,
      "e": 30035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30241,
      "e": 30106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30241,
      "e": 30106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30249,
      "e": 30114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 30337,
      "e": 30202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30361,
      "e": 30226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30362,
      "e": 30227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30481,
      "e": 30346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30505,
      "e": 30370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30506,
      "e": 30371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30593,
      "e": 30458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30673,
      "e": 30538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30674,
      "e": 30539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30729,
      "e": 30594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30729,
      "e": 30594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30777,
      "e": 30642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30777,
      "e": 30642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30793,
      "e": 30658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lef"
    },
    {
      "t": 30825,
      "e": 30690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30864,
      "e": 30729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30954,
      "e": 30819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30955,
      "e": 30820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31050,
      "e": 30915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31051,
      "e": 30916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31058,
      "e": 30923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 31136,
      "e": 31001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31257,
      "e": 31122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31257,
      "e": 31122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31370,
      "e": 31235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31371,
      "e": 31236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31385,
      "e": 31250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 31456,
      "e": 31321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31457,
      "e": 31322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31529,
      "e": 31394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31553,
      "e": 31418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31553,
      "e": 31418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31585,
      "e": 31450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31650,
      "e": 31515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31729,
      "e": 31594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31729,
      "e": 31594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31825,
      "e": 31690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31825,
      "e": 31690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31841,
      "e": 31706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 31889,
      "e": 31754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31889,
      "e": 31754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31929,
      "e": 31754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32025,
      "e": 31850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32586,
      "e": 32411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32586,
      "e": 32411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32641,
      "e": 32466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 32721,
      "e": 32546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32721,
      "e": 32546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32809,
      "e": 32634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32825,
      "e": 32650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32825,
      "e": 32650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32888,
      "e": 32713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32945,
      "e": 32770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32945,
      "e": 32770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33033,
      "e": 32858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33057,
      "e": 32882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33057,
      "e": 32882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33129,
      "e": 32954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33154,
      "e": 32979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33156,
      "e": 32981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33217,
      "e": 33042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33217,
      "e": 33042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33225,
      "e": 33050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 33281,
      "e": 33106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33281,
      "e": 33106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 33281,
      "e": 33106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33360,
      "e": 33185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 33385,
      "e": 33210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33385,
      "e": 33210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33433,
      "e": 33258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34002,
      "e": 33827,
      "ty": 2,
      "x": 1218,
      "y": 884
    },
    {
      "t": 34003,
      "e": 33828,
      "ty": 41,
      "x": 30443,
      "y": 53430,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34102,
      "e": 33927,
      "ty": 2,
      "x": 1008,
      "y": 780
    },
    {
      "t": 34202,
      "e": 34027,
      "ty": 2,
      "x": 1005,
      "y": 778
    },
    {
      "t": 34252,
      "e": 34077,
      "ty": 41,
      "x": 4088,
      "y": 50494,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34303,
      "e": 34128,
      "ty": 2,
      "x": 560,
      "y": 685
    },
    {
      "t": 34321,
      "e": 34146,
      "ty": 6,
      "x": 311,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34338,
      "e": 34163,
      "ty": 7,
      "x": 175,
      "y": 474,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34402,
      "e": 34227,
      "ty": 2,
      "x": 0,
      "y": 338
    },
    {
      "t": 34502,
      "e": 34327,
      "ty": 2,
      "x": 115,
      "y": 356
    },
    {
      "t": 34502,
      "e": 34327,
      "ty": 41,
      "x": 2012,
      "y": 19278,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 34602,
      "e": 34427,
      "ty": 2,
      "x": 391,
      "y": 395
    },
    {
      "t": 34702,
      "e": 34527,
      "ty": 2,
      "x": 407,
      "y": 424
    },
    {
      "t": 34753,
      "e": 34578,
      "ty": 41,
      "x": 37534,
      "y": 25815,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 34802,
      "e": 34627,
      "ty": 2,
      "x": 434,
      "y": 479
    },
    {
      "t": 34903,
      "e": 34728,
      "ty": 2,
      "x": 463,
      "y": 517
    },
    {
      "t": 34906,
      "e": 34731,
      "ty": 6,
      "x": 469,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35003,
      "e": 34828,
      "ty": 2,
      "x": 471,
      "y": 524
    },
    {
      "t": 35003,
      "e": 34828,
      "ty": 41,
      "x": 42030,
      "y": 1023,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35102,
      "e": 34927,
      "ty": 2,
      "x": 477,
      "y": 531
    },
    {
      "t": 35202,
      "e": 35027,
      "ty": 2,
      "x": 481,
      "y": 536
    },
    {
      "t": 35252,
      "e": 35077,
      "ty": 41,
      "x": 43154,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35402,
      "e": 35227,
      "ty": 2,
      "x": 486,
      "y": 536
    },
    {
      "t": 35503,
      "e": 35328,
      "ty": 2,
      "x": 496,
      "y": 536
    },
    {
      "t": 35503,
      "e": 35328,
      "ty": 41,
      "x": 44841,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35602,
      "e": 35427,
      "ty": 2,
      "x": 494,
      "y": 536
    },
    {
      "t": 35703,
      "e": 35528,
      "ty": 2,
      "x": 459,
      "y": 536
    },
    {
      "t": 35753,
      "e": 35578,
      "ty": 41,
      "x": 40232,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35803,
      "e": 35628,
      "ty": 2,
      "x": 454,
      "y": 533
    },
    {
      "t": 35903,
      "e": 35728,
      "ty": 2,
      "x": 433,
      "y": 532
    },
    {
      "t": 36002,
      "e": 35827,
      "ty": 2,
      "x": 427,
      "y": 532
    },
    {
      "t": 36002,
      "e": 35827,
      "ty": 41,
      "x": 37084,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37134,
      "e": 36959,
      "ty": 3,
      "x": 427,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37189,
      "e": 37014,
      "ty": 4,
      "x": 37084,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37189,
      "e": 37014,
      "ty": 5,
      "x": 427,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37252,
      "e": 37077,
      "ty": 41,
      "x": 37309,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37302,
      "e": 37127,
      "ty": 2,
      "x": 429,
      "y": 532
    },
    {
      "t": 37402,
      "e": 37227,
      "ty": 2,
      "x": 434,
      "y": 532
    },
    {
      "t": 37503,
      "e": 37328,
      "ty": 41,
      "x": 37871,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38082,
      "e": 37907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38113,
      "e": 37938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to th right is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 38224,
      "e": 38049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38273,
      "e": 38098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to t right is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 38406,
      "e": 38231,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to t right is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 38530,
      "e": 38355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38562,
      "e": 38356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to  right is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 39122,
      "e": 38916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39177,
      "e": 38971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 39898,
      "e": 39692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40001,
      "e": 39795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40081,
      "e": 39875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40137,
      "e": 39931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40208,
      "e": 40002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40265,
      "e": 40059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40337,
      "e": 40131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40384,
      "e": 40178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40473,
      "e": 40267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40529,
      "e": 40323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40569,
      "e": 40363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40649,
      "e": 40443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40706,
      "e": 40500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 40770,
      "e": 40564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41442,
      "e": 41236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 41489,
      "e": 41283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41994,
      "e": 41788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41995,
      "e": 41789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42081,
      "e": 41875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right  is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 42137,
      "e": 41931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42138,
      "e": 41932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42209,
      "e": 42003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right a is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 42217,
      "e": 42011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42217,
      "e": 42011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42265,
      "e": 42059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right an is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 42272,
      "e": 42066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 42273,
      "e": 42067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42321,
      "e": 42115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42321,
      "e": 42115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42354,
      "e": 42116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right and  is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 42418,
      "e": 42180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43641,
      "e": 43403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 43642,
      "e": 43404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43704,
      "e": 43466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 43705,
      "e": 43467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43729,
      "e": 43491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right and up is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 43793,
      "e": 43555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44703,
      "e": 44465,
      "ty": 2,
      "x": 461,
      "y": 538
    },
    {
      "t": 44753,
      "e": 44515,
      "ty": 41,
      "x": 40906,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44802,
      "e": 44564,
      "ty": 2,
      "x": 468,
      "y": 547
    },
    {
      "t": 44903,
      "e": 44665,
      "ty": 2,
      "x": 474,
      "y": 552
    },
    {
      "t": 45004,
      "e": 44766,
      "ty": 41,
      "x": 42368,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45203,
      "e": 44965,
      "ty": 2,
      "x": 475,
      "y": 554
    },
    {
      "t": 45253,
      "e": 45015,
      "ty": 41,
      "x": 42480,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45262,
      "e": 45024,
      "ty": 3,
      "x": 475,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45340,
      "e": 45102,
      "ty": 4,
      "x": 42480,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45341,
      "e": 45103,
      "ty": 5,
      "x": 475,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45603,
      "e": 45365,
      "ty": 2,
      "x": 494,
      "y": 546
    },
    {
      "t": 45703,
      "e": 45465,
      "ty": 2,
      "x": 542,
      "y": 523
    },
    {
      "t": 45752,
      "e": 45514,
      "ty": 41,
      "x": 50124,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45780,
      "e": 45542,
      "ty": 7,
      "x": 550,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45803,
      "e": 45565,
      "ty": 2,
      "x": 554,
      "y": 518
    },
    {
      "t": 45903,
      "e": 45665,
      "ty": 2,
      "x": 557,
      "y": 517
    },
    {
      "t": 45950,
      "e": 45712,
      "ty": 6,
      "x": 558,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46003,
      "e": 45765,
      "ty": 2,
      "x": 558,
      "y": 523
    },
    {
      "t": 46003,
      "e": 45765,
      "ty": 41,
      "x": 51810,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46103,
      "e": 45865,
      "ty": 2,
      "x": 554,
      "y": 528
    },
    {
      "t": 46203,
      "e": 45965,
      "ty": 2,
      "x": 546,
      "y": 536
    },
    {
      "t": 46253,
      "e": 46015,
      "ty": 41,
      "x": 50461,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46303,
      "e": 46065,
      "ty": 2,
      "x": 546,
      "y": 537
    },
    {
      "t": 46502,
      "e": 46264,
      "ty": 2,
      "x": 506,
      "y": 538
    },
    {
      "t": 46502,
      "e": 46264,
      "ty": 41,
      "x": 45965,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46752,
      "e": 46514,
      "ty": 41,
      "x": 46077,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46802,
      "e": 46564,
      "ty": 2,
      "x": 507,
      "y": 538
    },
    {
      "t": 47102,
      "e": 46864,
      "ty": 2,
      "x": 514,
      "y": 535
    },
    {
      "t": 47202,
      "e": 46964,
      "ty": 2,
      "x": 525,
      "y": 529
    },
    {
      "t": 47253,
      "e": 47015,
      "ty": 41,
      "x": 48100,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47262,
      "e": 47024,
      "ty": 3,
      "x": 525,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47402,
      "e": 47164,
      "ty": 2,
      "x": 536,
      "y": 529
    },
    {
      "t": 47502,
      "e": 47264,
      "ty": 2,
      "x": 560,
      "y": 533
    },
    {
      "t": 47502,
      "e": 47264,
      "ty": 41,
      "x": 52035,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47602,
      "e": 47364,
      "ty": 2,
      "x": 562,
      "y": 533
    },
    {
      "t": 47752,
      "e": 47514,
      "ty": 41,
      "x": 52260,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47757,
      "e": 47519,
      "ty": 4,
      "x": 52260,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47758,
      "e": 47520,
      "ty": 5,
      "x": 562,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47902,
      "e": 47664,
      "ty": 2,
      "x": 561,
      "y": 554
    },
    {
      "t": 48002,
      "e": 47764,
      "ty": 2,
      "x": 557,
      "y": 561
    },
    {
      "t": 48002,
      "e": 47764,
      "ty": 41,
      "x": 51698,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48014,
      "e": 47776,
      "ty": 3,
      "x": 557,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48078,
      "e": 47840,
      "ty": 4,
      "x": 51698,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48078,
      "e": 47840,
      "ty": 5,
      "x": 557,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48202,
      "e": 47964,
      "ty": 2,
      "x": 566,
      "y": 557
    },
    {
      "t": 48252,
      "e": 48014,
      "ty": 41,
      "x": 53046,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48302,
      "e": 48064,
      "ty": 2,
      "x": 569,
      "y": 556
    },
    {
      "t": 48383,
      "e": 48145,
      "ty": 7,
      "x": 370,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48402,
      "e": 48164,
      "ty": 2,
      "x": 288,
      "y": 512
    },
    {
      "t": 48502,
      "e": 48264,
      "ty": 2,
      "x": 0,
      "y": 499
    },
    {
      "t": 48502,
      "e": 48264,
      "ty": 41,
      "x": 0,
      "y": 27643,
      "ta": "html"
    },
    {
      "t": 48602,
      "e": 48364,
      "ty": 2,
      "x": 0,
      "y": 513
    },
    {
      "t": 48668,
      "e": 48430,
      "ty": 6,
      "x": 129,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48702,
      "e": 48464,
      "ty": 2,
      "x": 242,
      "y": 548
    },
    {
      "t": 48752,
      "e": 48514,
      "ty": 41,
      "x": 20560,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48802,
      "e": 48564,
      "ty": 2,
      "x": 277,
      "y": 548
    },
    {
      "t": 48902,
      "e": 48664,
      "ty": 2,
      "x": 247,
      "y": 545
    },
    {
      "t": 49002,
      "e": 48764,
      "ty": 2,
      "x": 237,
      "y": 549
    },
    {
      "t": 49002,
      "e": 48764,
      "ty": 41,
      "x": 15726,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49252,
      "e": 49014,
      "ty": 41,
      "x": 22134,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49302,
      "e": 49064,
      "ty": 2,
      "x": 386,
      "y": 586
    },
    {
      "t": 49402,
      "e": 49164,
      "ty": 2,
      "x": 421,
      "y": 587
    },
    {
      "t": 49433,
      "e": 49195,
      "ty": 7,
      "x": 421,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49467,
      "e": 49229,
      "ty": 6,
      "x": 430,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 49483,
      "e": 49245,
      "ty": 7,
      "x": 436,
      "y": 697,
      "ta": "#strategyButton"
    },
    {
      "t": 49502,
      "e": 49264,
      "ty": 2,
      "x": 437,
      "y": 702
    },
    {
      "t": 49502,
      "e": 49264,
      "ty": 41,
      "x": 55426,
      "y": 52602,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 49602,
      "e": 49364,
      "ty": 2,
      "x": 437,
      "y": 706
    },
    {
      "t": 49702,
      "e": 49464,
      "ty": 2,
      "x": 436,
      "y": 701
    },
    {
      "t": 49751,
      "e": 49513,
      "ty": 6,
      "x": 432,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 49753,
      "e": 49515,
      "ty": 41,
      "x": 51011,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 49802,
      "e": 49564,
      "ty": 2,
      "x": 432,
      "y": 686
    },
    {
      "t": 49902,
      "e": 49664,
      "ty": 2,
      "x": 432,
      "y": 682
    },
    {
      "t": 50003,
      "e": 49765,
      "ty": 41,
      "x": 51011,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 50003,
      "e": 49765,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50202,
      "e": 49964,
      "ty": 2,
      "x": 429,
      "y": 668
    },
    {
      "t": 50252,
      "e": 50014,
      "ty": 41,
      "x": 49373,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 50285,
      "e": 50047,
      "ty": 3,
      "x": 429,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 50286,
      "e": 50048,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The lines that come out of 12 pm going to right and up is lines that have a shift start. \nLines going up and to the left are shift ends. "
    },
    {
      "t": 50287,
      "e": 50049,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50289,
      "e": 50051,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 50364,
      "e": 50126,
      "ty": 4,
      "x": 49373,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 50376,
      "e": 50138,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 50378,
      "e": 50140,
      "ty": 5,
      "x": 429,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 50388,
      "e": 50150,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 51385,
      "e": 51147,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 52002,
      "e": 51764,
      "ty": 41,
      "x": 21007,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 52002,
      "e": 51764,
      "ty": 2,
      "x": 618,
      "y": 684
    },
    {
      "t": 52102,
      "e": 51864,
      "ty": 2,
      "x": 817,
      "y": 672
    },
    {
      "t": 52103,
      "e": 51865,
      "ty": 6,
      "x": 835,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52169,
      "e": 51931,
      "ty": 7,
      "x": 856,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52202,
      "e": 51964,
      "ty": 2,
      "x": 857,
      "y": 629
    },
    {
      "t": 52252,
      "e": 52014,
      "ty": 41,
      "x": 12328,
      "y": 4681,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 52302,
      "e": 52064,
      "ty": 2,
      "x": 873,
      "y": 576
    },
    {
      "t": 52337,
      "e": 52099,
      "ty": 6,
      "x": 877,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52403,
      "e": 52165,
      "ty": 2,
      "x": 877,
      "y": 574
    },
    {
      "t": 52502,
      "e": 52264,
      "ty": 41,
      "x": 14923,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52861,
      "e": 52623,
      "ty": 3,
      "x": 877,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52863,
      "e": 52625,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52956,
      "e": 52718,
      "ty": 4,
      "x": 14923,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52957,
      "e": 52719,
      "ty": 5,
      "x": 877,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53473,
      "e": 53235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 53475,
      "e": 53237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53569,
      "e": 53331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 53625,
      "e": 53387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 53626,
      "e": 53388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53713,
      "e": 53475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 54450,
      "e": 54212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 54451,
      "e": 54213,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 54451,
      "e": 54213,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54452,
      "e": 54214,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54537,
      "e": 54299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 55641,
      "e": 55403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 55777,
      "e": 55539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 55778,
      "e": 55540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55801,
      "e": 55563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 55860,
      "e": 55622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 55860,
      "e": 55622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55864,
      "e": 55626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ir"
    },
    {
      "t": 55961,
      "e": 55723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ir"
    },
    {
      "t": 55985,
      "e": 55747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 55985,
      "e": 55747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56074,
      "e": 55836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ira"
    },
    {
      "t": 56209,
      "e": 55971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "81"
    },
    {
      "t": 56210,
      "e": 55972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56273,
      "e": 56035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Iraq"
    },
    {
      "t": 56404,
      "e": 56166,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Iraq"
    },
    {
      "t": 56753,
      "e": 56515,
      "ty": 41,
      "x": 17735,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56803,
      "e": 56565,
      "ty": 2,
      "x": 1048,
      "y": 574
    },
    {
      "t": 56840,
      "e": 56602,
      "ty": 7,
      "x": 1007,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56902,
      "e": 56664,
      "ty": 2,
      "x": 743,
      "y": 648
    },
    {
      "t": 57002,
      "e": 56764,
      "ty": 2,
      "x": 734,
      "y": 703
    },
    {
      "t": 57002,
      "e": 56764,
      "ty": 41,
      "x": 25001,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 57102,
      "e": 56864,
      "ty": 2,
      "x": 898,
      "y": 780
    },
    {
      "t": 57203,
      "e": 56965,
      "ty": 2,
      "x": 933,
      "y": 746
    },
    {
      "t": 57253,
      "e": 57015,
      "ty": 41,
      "x": 31923,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 57290,
      "e": 57052,
      "ty": 6,
      "x": 939,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57302,
      "e": 57064,
      "ty": 2,
      "x": 939,
      "y": 707
    },
    {
      "t": 57422,
      "e": 57184,
      "ty": 3,
      "x": 939,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57423,
      "e": 57185,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Iraq"
    },
    {
      "t": 57424,
      "e": 57186,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57424,
      "e": 57186,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57476,
      "e": 57238,
      "ty": 4,
      "x": 22202,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57477,
      "e": 57239,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57477,
      "e": 57239,
      "ty": 5,
      "x": 939,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57477,
      "e": 57239,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 57503,
      "e": 57265,
      "ty": 41,
      "x": 32061,
      "y": 38722,
      "ta": "html > body"
    },
    {
      "t": 58491,
      "e": 58253,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 59103,
      "e": 58865,
      "ty": 2,
      "x": 916,
      "y": 465
    },
    {
      "t": 59203,
      "e": 58965,
      "ty": 2,
      "x": 853,
      "y": 120
    },
    {
      "t": 59253,
      "e": 59015,
      "ty": 41,
      "x": 29099,
      "y": 6204,
      "ta": "html > body"
    },
    {
      "t": 59403,
      "e": 59165,
      "ty": 2,
      "x": 847,
      "y": 168
    },
    {
      "t": 59502,
      "e": 59264,
      "ty": 2,
      "x": 842,
      "y": 181
    },
    {
      "t": 59503,
      "e": 59265,
      "ty": 41,
      "x": 4883,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 59602,
      "e": 59364,
      "ty": 2,
      "x": 839,
      "y": 202
    },
    {
      "t": 59702,
      "e": 59464,
      "ty": 2,
      "x": 838,
      "y": 211
    },
    {
      "t": 59742,
      "e": 59504,
      "ty": 6,
      "x": 838,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59753,
      "e": 59515,
      "ty": 41,
      "x": 58367,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59777,
      "e": 59539,
      "ty": 7,
      "x": 835,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59802,
      "e": 59564,
      "ty": 2,
      "x": 835,
      "y": 246
    },
    {
      "t": 60005,
      "e": 59566,
      "ty": 41,
      "x": 11118,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60374,
      "e": 59935,
      "ty": 3,
      "x": 835,
      "y": 246,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 61003,
      "e": 60564,
      "ty": 2,
      "x": 835,
      "y": 254
    },
    {
      "t": 61003,
      "e": 60564,
      "ty": 41,
      "x": 3222,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 61102,
      "e": 60663,
      "ty": 4,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 61103,
      "e": 60664,
      "ty": 2,
      "x": 835,
      "y": 256
    },
    {
      "t": 61160,
      "e": 60721,
      "ty": 6,
      "x": 835,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61178,
      "e": 60739,
      "ty": 7,
      "x": 835,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 61195,
      "e": 60756,
      "ty": 6,
      "x": 834,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 61202,
      "e": 60763,
      "ty": 2,
      "x": 834,
      "y": 288
    },
    {
      "t": 61228,
      "e": 60789,
      "ty": 7,
      "x": 829,
      "y": 308,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 61252,
      "e": 60813,
      "ty": 41,
      "x": 1561,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 61302,
      "e": 60863,
      "ty": 2,
      "x": 828,
      "y": 313
    },
    {
      "t": 61357,
      "e": 60918,
      "ty": 6,
      "x": 828,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61403,
      "e": 60964,
      "ty": 2,
      "x": 828,
      "y": 316
    },
    {
      "t": 61502,
      "e": 61063,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61574,
      "e": 61135,
      "ty": 3,
      "x": 828,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61575,
      "e": 61136,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61629,
      "e": 61190,
      "ty": 4,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61629,
      "e": 61190,
      "ty": 5,
      "x": 828,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 61629,
      "e": 61190,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 61802,
      "e": 61363,
      "ty": 2,
      "x": 828,
      "y": 318
    },
    {
      "t": 61903,
      "e": 61464,
      "ty": 2,
      "x": 829,
      "y": 323
    },
    {
      "t": 61973,
      "e": 61534,
      "ty": 3,
      "x": 829,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62003,
      "e": 61564,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62053,
      "e": 61614,
      "ty": 4,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62053,
      "e": 61614,
      "ty": 5,
      "x": 829,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62595,
      "e": 62156,
      "ty": 7,
      "x": 823,
      "y": 313,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62602,
      "e": 62163,
      "ty": 2,
      "x": 823,
      "y": 313
    },
    {
      "t": 62703,
      "e": 62264,
      "ty": 2,
      "x": 751,
      "y": 286
    },
    {
      "t": 62753,
      "e": 62314,
      "ty": 41,
      "x": 25587,
      "y": 15400,
      "ta": "html > body"
    },
    {
      "t": 62893,
      "e": 62454,
      "ty": 3,
      "x": 751,
      "y": 286,
      "ta": "html > body"
    },
    {
      "t": 62894,
      "e": 62455,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 62948,
      "e": 62509,
      "ty": 4,
      "x": 25587,
      "y": 15400,
      "ta": "html > body"
    },
    {
      "t": 62948,
      "e": 62509,
      "ty": 5,
      "x": 751,
      "y": 286,
      "ta": "html > body"
    },
    {
      "t": 63203,
      "e": 62764,
      "ty": 2,
      "x": 829,
      "y": 337
    },
    {
      "t": 63253,
      "e": 62814,
      "ty": 41,
      "x": 10342,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 63303,
      "e": 62864,
      "ty": 2,
      "x": 865,
      "y": 390
    },
    {
      "t": 63402,
      "e": 62963,
      "ty": 2,
      "x": 859,
      "y": 416
    },
    {
      "t": 63503,
      "e": 63064,
      "ty": 2,
      "x": 855,
      "y": 413
    },
    {
      "t": 63503,
      "e": 63064,
      "ty": 41,
      "x": 39306,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 63602,
      "e": 63163,
      "ty": 2,
      "x": 844,
      "y": 383
    },
    {
      "t": 63753,
      "e": 63314,
      "ty": 41,
      "x": 5358,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 64203,
      "e": 63764,
      "ty": 2,
      "x": 843,
      "y": 399
    },
    {
      "t": 64253,
      "e": 63814,
      "ty": 41,
      "x": 25259,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 64303,
      "e": 63864,
      "ty": 2,
      "x": 843,
      "y": 417
    },
    {
      "t": 64403,
      "e": 63964,
      "ty": 2,
      "x": 842,
      "y": 421
    },
    {
      "t": 64503,
      "e": 64064,
      "ty": 2,
      "x": 840,
      "y": 424
    },
    {
      "t": 64503,
      "e": 64064,
      "ty": 41,
      "x": 21747,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 64603,
      "e": 64164,
      "ty": 2,
      "x": 839,
      "y": 426
    },
    {
      "t": 64753,
      "e": 64314,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 65003,
      "e": 64564,
      "ty": 2,
      "x": 832,
      "y": 432
    },
    {
      "t": 65003,
      "e": 64564,
      "ty": 41,
      "x": 2510,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 66432,
      "e": 64564,
      "ty": 6,
      "x": 832,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66503,
      "e": 64635,
      "ty": 2,
      "x": 833,
      "y": 442
    },
    {
      "t": 66503,
      "e": 64635,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66902,
      "e": 65034,
      "ty": 7,
      "x": 834,
      "y": 434,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66903,
      "e": 65035,
      "ty": 2,
      "x": 834,
      "y": 434
    },
    {
      "t": 66965,
      "e": 65097,
      "ty": 6,
      "x": 837,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67003,
      "e": 65135,
      "ty": 2,
      "x": 837,
      "y": 411
    },
    {
      "t": 67003,
      "e": 65135,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67165,
      "e": 65297,
      "ty": 7,
      "x": 837,
      "y": 432,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67183,
      "e": 65315,
      "ty": 6,
      "x": 837,
      "y": 441,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67203,
      "e": 65335,
      "ty": 2,
      "x": 837,
      "y": 445
    },
    {
      "t": 67252,
      "e": 65384,
      "ty": 41,
      "x": 53325,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67294,
      "e": 65426,
      "ty": 7,
      "x": 837,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67303,
      "e": 65435,
      "ty": 2,
      "x": 837,
      "y": 450
    },
    {
      "t": 67403,
      "e": 65535,
      "ty": 2,
      "x": 837,
      "y": 459
    },
    {
      "t": 67450,
      "e": 65582,
      "ty": 6,
      "x": 837,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67503,
      "e": 65635,
      "ty": 2,
      "x": 836,
      "y": 473
    },
    {
      "t": 67503,
      "e": 65635,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67733,
      "e": 65865,
      "ty": 3,
      "x": 836,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67735,
      "e": 65867,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67805,
      "e": 65937,
      "ty": 4,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67807,
      "e": 65939,
      "ty": 5,
      "x": 836,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67807,
      "e": 65939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 67832,
      "e": 65964,
      "ty": 7,
      "x": 840,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67903,
      "e": 66035,
      "ty": 2,
      "x": 864,
      "y": 501
    },
    {
      "t": 68003,
      "e": 66135,
      "ty": 2,
      "x": 864,
      "y": 547
    },
    {
      "t": 68003,
      "e": 66135,
      "ty": 41,
      "x": 29052,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 68102,
      "e": 66234,
      "ty": 2,
      "x": 864,
      "y": 743
    },
    {
      "t": 68202,
      "e": 66334,
      "ty": 2,
      "x": 873,
      "y": 799
    },
    {
      "t": 68252,
      "e": 66384,
      "ty": 41,
      "x": 12240,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 68603,
      "e": 66735,
      "ty": 2,
      "x": 867,
      "y": 776
    },
    {
      "t": 68702,
      "e": 66834,
      "ty": 2,
      "x": 866,
      "y": 747
    },
    {
      "t": 68752,
      "e": 66884,
      "ty": 41,
      "x": 12694,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 68802,
      "e": 66934,
      "ty": 2,
      "x": 872,
      "y": 724
    },
    {
      "t": 68902,
      "e": 67034,
      "ty": 2,
      "x": 872,
      "y": 709
    },
    {
      "t": 69001,
      "e": 67133,
      "ty": 2,
      "x": 872,
      "y": 679
    },
    {
      "t": 69002,
      "e": 67134,
      "ty": 41,
      "x": 13580,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 69102,
      "e": 67234,
      "ty": 2,
      "x": 872,
      "y": 674
    },
    {
      "t": 69202,
      "e": 67334,
      "ty": 2,
      "x": 872,
      "y": 649
    },
    {
      "t": 69252,
      "e": 67384,
      "ty": 41,
      "x": 12003,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 69302,
      "e": 67434,
      "ty": 2,
      "x": 872,
      "y": 644
    },
    {
      "t": 69502,
      "e": 67634,
      "ty": 41,
      "x": 12003,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 69752,
      "e": 67884,
      "ty": 41,
      "x": 12478,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 69802,
      "e": 67934,
      "ty": 2,
      "x": 883,
      "y": 644
    },
    {
      "t": 69902,
      "e": 68034,
      "ty": 2,
      "x": 886,
      "y": 644
    },
    {
      "t": 70003,
      "e": 68135,
      "ty": 41,
      "x": 15325,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 70102,
      "e": 68234,
      "ty": 2,
      "x": 877,
      "y": 660
    },
    {
      "t": 70202,
      "e": 68334,
      "ty": 2,
      "x": 875,
      "y": 664
    },
    {
      "t": 70252,
      "e": 68384,
      "ty": 41,
      "x": 12715,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 70502,
      "e": 68634,
      "ty": 2,
      "x": 873,
      "y": 668
    },
    {
      "t": 70502,
      "e": 68634,
      "ty": 41,
      "x": 13848,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70601,
      "e": 68733,
      "ty": 2,
      "x": 873,
      "y": 685
    },
    {
      "t": 70702,
      "e": 68834,
      "ty": 2,
      "x": 876,
      "y": 698
    },
    {
      "t": 70753,
      "e": 68835,
      "ty": 41,
      "x": 14004,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 70802,
      "e": 68884,
      "ty": 2,
      "x": 877,
      "y": 709
    },
    {
      "t": 70902,
      "e": 68984,
      "ty": 2,
      "x": 878,
      "y": 720
    },
    {
      "t": 71002,
      "e": 69084,
      "ty": 2,
      "x": 872,
      "y": 718
    },
    {
      "t": 71002,
      "e": 69084,
      "ty": 41,
      "x": 12003,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 71102,
      "e": 69184,
      "ty": 2,
      "x": 865,
      "y": 715
    },
    {
      "t": 71202,
      "e": 69284,
      "ty": 2,
      "x": 864,
      "y": 715
    },
    {
      "t": 71253,
      "e": 69335,
      "ty": 41,
      "x": 9867,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 71302,
      "e": 69384,
      "ty": 2,
      "x": 863,
      "y": 722
    },
    {
      "t": 71402,
      "e": 69484,
      "ty": 2,
      "x": 859,
      "y": 731
    },
    {
      "t": 71502,
      "e": 69584,
      "ty": 2,
      "x": 850,
      "y": 750
    },
    {
      "t": 71503,
      "e": 69585,
      "ty": 41,
      "x": 11924,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71602,
      "e": 69684,
      "ty": 2,
      "x": 849,
      "y": 755
    },
    {
      "t": 71753,
      "e": 69835,
      "ty": 41,
      "x": 11507,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 72302,
      "e": 70384,
      "ty": 2,
      "x": 849,
      "y": 756
    },
    {
      "t": 72502,
      "e": 70584,
      "ty": 2,
      "x": 851,
      "y": 768
    },
    {
      "t": 72503,
      "e": 70585,
      "ty": 41,
      "x": 12341,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 72602,
      "e": 70684,
      "ty": 2,
      "x": 854,
      "y": 787
    },
    {
      "t": 72702,
      "e": 70784,
      "ty": 2,
      "x": 854,
      "y": 795
    },
    {
      "t": 72752,
      "e": 70834,
      "ty": 41,
      "x": 7731,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 72802,
      "e": 70884,
      "ty": 2,
      "x": 854,
      "y": 804
    },
    {
      "t": 73002,
      "e": 71084,
      "ty": 41,
      "x": 7731,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 73252,
      "e": 71334,
      "ty": 41,
      "x": 7731,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 73302,
      "e": 71384,
      "ty": 2,
      "x": 854,
      "y": 796
    },
    {
      "t": 73402,
      "e": 71484,
      "ty": 2,
      "x": 848,
      "y": 765
    },
    {
      "t": 73503,
      "e": 71585,
      "ty": 2,
      "x": 843,
      "y": 712
    },
    {
      "t": 73503,
      "e": 71585,
      "ty": 41,
      "x": 5437,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 73603,
      "e": 71685,
      "ty": 2,
      "x": 841,
      "y": 696
    },
    {
      "t": 73753,
      "e": 71835,
      "ty": 41,
      "x": 4933,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74002,
      "e": 72084,
      "ty": 2,
      "x": 841,
      "y": 694
    },
    {
      "t": 74002,
      "e": 72084,
      "ty": 41,
      "x": 4933,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74703,
      "e": 72785,
      "ty": 2,
      "x": 862,
      "y": 707
    },
    {
      "t": 74752,
      "e": 72834,
      "ty": 41,
      "x": 10476,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74802,
      "e": 72884,
      "ty": 2,
      "x": 865,
      "y": 710
    },
    {
      "t": 75002,
      "e": 73084,
      "ty": 2,
      "x": 870,
      "y": 716
    },
    {
      "t": 75002,
      "e": 73084,
      "ty": 41,
      "x": 11528,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 75102,
      "e": 73184,
      "ty": 2,
      "x": 900,
      "y": 744
    },
    {
      "t": 75202,
      "e": 73284,
      "ty": 2,
      "x": 901,
      "y": 745
    },
    {
      "t": 75252,
      "e": 73334,
      "ty": 41,
      "x": 18885,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 75702,
      "e": 73784,
      "ty": 2,
      "x": 894,
      "y": 742
    },
    {
      "t": 75753,
      "e": 73835,
      "ty": 41,
      "x": 12694,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 75802,
      "e": 73884,
      "ty": 2,
      "x": 870,
      "y": 733
    },
    {
      "t": 75846,
      "e": 73928,
      "ty": 3,
      "x": 870,
      "y": 733,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 75847,
      "e": 73929,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 75924,
      "e": 74006,
      "ty": 4,
      "x": 12192,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 75924,
      "e": 74006,
      "ty": 5,
      "x": 870,
      "y": 733,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 75924,
      "e": 74006,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 75925,
      "e": 74007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 76003,
      "e": 74085,
      "ty": 41,
      "x": 12192,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76303,
      "e": 74385,
      "ty": 2,
      "x": 862,
      "y": 733
    },
    {
      "t": 76402,
      "e": 74484,
      "ty": 2,
      "x": 419,
      "y": 952
    },
    {
      "t": 76503,
      "e": 74585,
      "ty": 2,
      "x": 381,
      "y": 992
    },
    {
      "t": 76503,
      "e": 74585,
      "ty": 41,
      "x": 12845,
      "y": 54510,
      "ta": "html > body"
    },
    {
      "t": 76518,
      "e": 74600,
      "ty": 3,
      "x": 381,
      "y": 992,
      "ta": "html > body"
    },
    {
      "t": 76518,
      "e": 74600,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 76580,
      "e": 74662,
      "ty": 4,
      "x": 12845,
      "y": 54510,
      "ta": "html > body"
    },
    {
      "t": 76580,
      "e": 74662,
      "ty": 5,
      "x": 381,
      "y": 992,
      "ta": "html > body"
    },
    {
      "t": 78203,
      "e": 76285,
      "ty": 2,
      "x": 576,
      "y": 1002
    },
    {
      "t": 78253,
      "e": 76335,
      "ty": 41,
      "x": 5832,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 78302,
      "e": 76384,
      "ty": 2,
      "x": 979,
      "y": 910
    },
    {
      "t": 78402,
      "e": 76484,
      "ty": 2,
      "x": 1024,
      "y": 881
    },
    {
      "t": 78503,
      "e": 76585,
      "ty": 2,
      "x": 996,
      "y": 877
    },
    {
      "t": 78503,
      "e": 76585,
      "ty": 41,
      "x": 41431,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 78602,
      "e": 76684,
      "ty": 2,
      "x": 925,
      "y": 911
    },
    {
      "t": 78703,
      "e": 76785,
      "ty": 2,
      "x": 906,
      "y": 927
    },
    {
      "t": 78752,
      "e": 76834,
      "ty": 41,
      "x": 17699,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 78802,
      "e": 76884,
      "ty": 2,
      "x": 893,
      "y": 934
    },
    {
      "t": 78903,
      "e": 76985,
      "ty": 2,
      "x": 882,
      "y": 934
    },
    {
      "t": 79003,
      "e": 77085,
      "ty": 2,
      "x": 870,
      "y": 933
    },
    {
      "t": 79003,
      "e": 77085,
      "ty": 41,
      "x": 53059,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 79102,
      "e": 77184,
      "ty": 2,
      "x": 857,
      "y": 933
    },
    {
      "t": 79202,
      "e": 77284,
      "ty": 2,
      "x": 851,
      "y": 937
    },
    {
      "t": 79253,
      "e": 77335,
      "ty": 41,
      "x": 32306,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 79377,
      "e": 77459,
      "ty": 6,
      "x": 839,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79402,
      "e": 77484,
      "ty": 2,
      "x": 839,
      "y": 934
    },
    {
      "t": 79492,
      "e": 77574,
      "ty": 3,
      "x": 837,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79493,
      "e": 77575,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79502,
      "e": 77584,
      "ty": 2,
      "x": 837,
      "y": 933
    },
    {
      "t": 79502,
      "e": 77584,
      "ty": 41,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79557,
      "e": 77639,
      "ty": 4,
      "x": 53325,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79557,
      "e": 77639,
      "ty": 5,
      "x": 837,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79557,
      "e": 77639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 79702,
      "e": 77784,
      "ty": 2,
      "x": 837,
      "y": 936
    },
    {
      "t": 79709,
      "e": 77791,
      "ty": 7,
      "x": 837,
      "y": 944,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 79726,
      "e": 77808,
      "ty": 6,
      "x": 837,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79752,
      "e": 77834,
      "ty": 41,
      "x": 53325,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79759,
      "e": 77841,
      "ty": 7,
      "x": 837,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79803,
      "e": 77885,
      "ty": 2,
      "x": 837,
      "y": 977
    },
    {
      "t": 79809,
      "e": 77891,
      "ty": 6,
      "x": 839,
      "y": 986,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 79826,
      "e": 77908,
      "ty": 7,
      "x": 840,
      "y": 992,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 79893,
      "e": 77975,
      "ty": 6,
      "x": 844,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79902,
      "e": 77984,
      "ty": 2,
      "x": 844,
      "y": 1007
    },
    {
      "t": 80002,
      "e": 78084,
      "ty": 2,
      "x": 849,
      "y": 1012
    },
    {
      "t": 80003,
      "e": 78085,
      "ty": 41,
      "x": 10090,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80103,
      "e": 78185,
      "ty": 2,
      "x": 854,
      "y": 1018
    },
    {
      "t": 80202,
      "e": 78284,
      "ty": 2,
      "x": 860,
      "y": 1024
    },
    {
      "t": 80257,
      "e": 78339,
      "ty": 41,
      "x": 15759,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80425,
      "e": 78507,
      "ty": 3,
      "x": 860,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80425,
      "e": 78507,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 80425,
      "e": 78507,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80504,
      "e": 78586,
      "ty": 4,
      "x": 15759,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80504,
      "e": 78586,
      "ty": 5,
      "x": 860,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80507,
      "e": 78589,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80507,
      "e": 78589,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80509,
      "e": 78591,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 81106,
      "e": 79188,
      "ty": 2,
      "x": 860,
      "y": 1019
    },
    {
      "t": 81207,
      "e": 79289,
      "ty": 2,
      "x": 860,
      "y": 1016
    },
    {
      "t": 81257,
      "e": 79339,
      "ty": 41,
      "x": 29340,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 81866,
      "e": 79948,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 82507,
      "e": 80589,
      "ty": 2,
      "x": 844,
      "y": 821
    },
    {
      "t": 82507,
      "e": 80589,
      "ty": 41,
      "x": 27085,
      "y": 26349,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 82607,
      "e": 80689,
      "ty": 2,
      "x": 754,
      "y": 441
    },
    {
      "t": 82707,
      "e": 80789,
      "ty": 2,
      "x": 761,
      "y": 407
    },
    {
      "t": 82756,
      "e": 80838,
      "ty": 41,
      "x": 23001,
      "y": 20686,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 82906,
      "e": 80988,
      "ty": 2,
      "x": 794,
      "y": 493
    },
    {
      "t": 83006,
      "e": 81088,
      "ty": 2,
      "x": 900,
      "y": 672
    },
    {
      "t": 83007,
      "e": 81089,
      "ty": 41,
      "x": 29840,
      "y": 2057,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83106,
      "e": 81188,
      "ty": 2,
      "x": 906,
      "y": 687
    },
    {
      "t": 83256,
      "e": 81338,
      "ty": 41,
      "x": 30135,
      "y": 10834,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83606,
      "e": 81688,
      "ty": 2,
      "x": 949,
      "y": 754
    },
    {
      "t": 83706,
      "e": 81788,
      "ty": 2,
      "x": 965,
      "y": 788
    },
    {
      "t": 83756,
      "e": 81838,
      "ty": 41,
      "x": 33038,
      "y": 52858,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 83806,
      "e": 81888,
      "ty": 2,
      "x": 973,
      "y": 806
    },
    {
      "t": 83906,
      "e": 81988,
      "ty": 2,
      "x": 1003,
      "y": 926
    },
    {
      "t": 84007,
      "e": 82089,
      "ty": 2,
      "x": 1031,
      "y": 1076
    },
    {
      "t": 84007,
      "e": 82089,
      "ty": 41,
      "x": 35229,
      "y": 59164,
      "ta": "> div.masterdiv"
    },
    {
      "t": 84106,
      "e": 82188,
      "ty": 2,
      "x": 1032,
      "y": 1096
    },
    {
      "t": 84146,
      "e": 82228,
      "ty": 6,
      "x": 1029,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 84207,
      "e": 82289,
      "ty": 2,
      "x": 1023,
      "y": 1102
    },
    {
      "t": 84256,
      "e": 82289,
      "ty": 41,
      "x": 56523,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 84307,
      "e": 82340,
      "ty": 2,
      "x": 1010,
      "y": 1096
    },
    {
      "t": 84506,
      "e": 82539,
      "ty": 41,
      "x": 54885,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 85114,
      "e": 83147,
      "ty": 3,
      "x": 1010,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 85114,
      "e": 83147,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85168,
      "e": 83201,
      "ty": 4,
      "x": 54885,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 85169,
      "e": 83202,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85169,
      "e": 83202,
      "ty": 5,
      "x": 1010,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 85170,
      "e": 83203,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 86196,
      "e": 84229,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 86805,
      "e": 84838,
      "ty": 2,
      "x": 1012,
      "y": 1076
    },
    {
      "t": 86805,
      "e": 84838,
      "ty": 41,
      "x": 35040,
      "y": 32901,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 86858,
      "e": 84891,
      "ty": 2,
      "x": 1014,
      "y": 1073
    },
    {
      "t": 86907,
      "e": 84940,
      "ty": 2,
      "x": 1017,
      "y": 1065
    },
    {
      "t": 87007,
      "e": 85040,
      "ty": 2,
      "x": 1020,
      "y": 1039
    },
    {
      "t": 87007,
      "e": 85040,
      "ty": 41,
      "x": 35386,
      "y": 32891,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 87106,
      "e": 85139,
      "ty": 2,
      "x": 1021,
      "y": 1026
    },
    {
      "t": 87206,
      "e": 85239,
      "ty": 2,
      "x": 1021,
      "y": 1016
    },
    {
      "t": 87257,
      "e": 85290,
      "ty": 41,
      "x": 35429,
      "y": 32885,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 87397,
      "e": 85430,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 24521, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 24526, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 190526, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 216152, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8521, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 225680, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 18015, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 245027, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11418, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 257446, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 61056, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 319882, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-C -C -I -A -11 AM-A -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:874,y:908,t:1527023237484};\\\", \\\"{x:872,y:906,t:1527023237862};\\\", \\\"{x:870,y:906,t:1527023237873};\\\", \\\"{x:864,y:906,t:1527023237890};\\\", \\\"{x:854,y:902,t:1527023237906};\\\", \\\"{x:824,y:885,t:1527023237922};\\\", \\\"{x:757,y:851,t:1527023237940};\\\", \\\"{x:676,y:812,t:1527023237956};\\\", \\\"{x:601,y:779,t:1527023237973};\\\", \\\"{x:328,y:644,t:1527023238085};\\\", \\\"{x:328,y:643,t:1527023238101};\\\", \\\"{x:328,y:642,t:1527023238109};\\\", \\\"{x:328,y:641,t:1527023238125};\\\", \\\"{x:328,y:639,t:1527023238139};\\\", \\\"{x:329,y:632,t:1527023238156};\\\", \\\"{x:330,y:619,t:1527023238173};\\\", \\\"{x:330,y:617,t:1527023238190};\\\", \\\"{x:330,y:616,t:1527023238942};\\\", \\\"{x:332,y:614,t:1527023238958};\\\", \\\"{x:345,y:611,t:1527023238974};\\\", \\\"{x:361,y:611,t:1527023238991};\\\", \\\"{x:378,y:612,t:1527023239006};\\\", \\\"{x:390,y:616,t:1527023239024};\\\", \\\"{x:396,y:618,t:1527023239041};\\\", \\\"{x:399,y:619,t:1527023239057};\\\", \\\"{x:402,y:619,t:1527023239074};\\\", \\\"{x:406,y:619,t:1527023239091};\\\", \\\"{x:407,y:619,t:1527023239107};\\\", \\\"{x:409,y:619,t:1527023239159};\\\", \\\"{x:410,y:619,t:1527023239174};\\\", \\\"{x:414,y:619,t:1527023239191};\\\", \\\"{x:421,y:617,t:1527023239207};\\\", \\\"{x:428,y:609,t:1527023239225};\\\", \\\"{x:441,y:591,t:1527023239241};\\\", \\\"{x:477,y:549,t:1527023239259};\\\", \\\"{x:567,y:439,t:1527023239274};\\\", \\\"{x:657,y:344,t:1527023239290};\\\", \\\"{x:730,y:295,t:1527023239308};\\\", \\\"{x:770,y:278,t:1527023239324};\\\", \\\"{x:799,y:269,t:1527023239340};\\\", \\\"{x:811,y:268,t:1527023239357};\\\", \\\"{x:812,y:268,t:1527023239406};\\\", \\\"{x:813,y:269,t:1527023239447};\\\", \\\"{x:813,y:274,t:1527023239458};\\\", \\\"{x:819,y:283,t:1527023239475};\\\", \\\"{x:830,y:298,t:1527023239491};\\\", \\\"{x:842,y:312,t:1527023239509};\\\", \\\"{x:857,y:330,t:1527023239524};\\\", \\\"{x:890,y:353,t:1527023239541};\\\", \\\"{x:992,y:406,t:1527023239558};\\\", \\\"{x:1071,y:446,t:1527023239574};\\\", \\\"{x:1131,y:472,t:1527023239592};\\\", \\\"{x:1160,y:486,t:1527023239608};\\\", \\\"{x:1171,y:494,t:1527023239624};\\\", \\\"{x:1175,y:497,t:1527023239641};\\\", \\\"{x:1179,y:499,t:1527023239658};\\\", \\\"{x:1181,y:500,t:1527023239675};\\\", \\\"{x:1181,y:501,t:1527023239691};\\\", \\\"{x:1181,y:502,t:1527023242750};\\\", \\\"{x:1181,y:504,t:1527023242761};\\\", \\\"{x:1180,y:504,t:1527023242778};\\\", \\\"{x:1180,y:505,t:1527023242806};\\\", \\\"{x:1180,y:506,t:1527023242830};\\\", \\\"{x:1180,y:507,t:1527023242845};\\\", \\\"{x:1179,y:508,t:1527023242861};\\\", \\\"{x:1179,y:513,t:1527023242878};\\\", \\\"{x:1178,y:516,t:1527023242893};\\\", \\\"{x:1178,y:521,t:1527023242911};\\\", \\\"{x:1176,y:528,t:1527023242927};\\\", \\\"{x:1176,y:534,t:1527023242944};\\\", \\\"{x:1176,y:548,t:1527023242960};\\\", \\\"{x:1176,y:567,t:1527023242977};\\\", \\\"{x:1176,y:586,t:1527023242994};\\\", \\\"{x:1176,y:605,t:1527023243011};\\\", \\\"{x:1174,y:623,t:1527023243028};\\\", \\\"{x:1170,y:644,t:1527023243044};\\\", \\\"{x:1164,y:664,t:1527023243061};\\\", \\\"{x:1155,y:684,t:1527023243078};\\\", \\\"{x:1141,y:711,t:1527023243094};\\\", \\\"{x:1130,y:730,t:1527023243111};\\\", \\\"{x:1121,y:746,t:1527023243128};\\\", \\\"{x:1117,y:763,t:1527023243145};\\\", \\\"{x:1117,y:778,t:1527023243161};\\\", \\\"{x:1117,y:795,t:1527023243177};\\\", \\\"{x:1119,y:809,t:1527023243194};\\\", \\\"{x:1124,y:826,t:1527023243212};\\\", \\\"{x:1128,y:839,t:1527023243227};\\\", \\\"{x:1138,y:853,t:1527023243244};\\\", \\\"{x:1152,y:869,t:1527023243262};\\\", \\\"{x:1163,y:879,t:1527023243278};\\\", \\\"{x:1173,y:888,t:1527023243294};\\\", \\\"{x:1176,y:893,t:1527023243312};\\\", \\\"{x:1181,y:900,t:1527023243327};\\\", \\\"{x:1186,y:905,t:1527023243345};\\\", \\\"{x:1189,y:908,t:1527023243362};\\\", \\\"{x:1190,y:909,t:1527023243377};\\\", \\\"{x:1190,y:910,t:1527023243394};\\\", \\\"{x:1190,y:913,t:1527023243412};\\\", \\\"{x:1190,y:915,t:1527023243427};\\\", \\\"{x:1189,y:917,t:1527023243445};\\\", \\\"{x:1181,y:920,t:1527023243462};\\\", \\\"{x:1175,y:925,t:1527023243478};\\\", \\\"{x:1168,y:929,t:1527023243494};\\\", \\\"{x:1164,y:933,t:1527023243511};\\\", \\\"{x:1163,y:934,t:1527023243528};\\\", \\\"{x:1162,y:935,t:1527023243545};\\\", \\\"{x:1162,y:936,t:1527023243562};\\\", \\\"{x:1162,y:940,t:1527023243578};\\\", \\\"{x:1163,y:941,t:1527023243594};\\\", \\\"{x:1165,y:944,t:1527023243612};\\\", \\\"{x:1166,y:948,t:1527023243628};\\\", \\\"{x:1169,y:950,t:1527023243644};\\\", \\\"{x:1173,y:953,t:1527023243662};\\\", \\\"{x:1180,y:956,t:1527023243678};\\\", \\\"{x:1187,y:958,t:1527023243695};\\\", \\\"{x:1193,y:959,t:1527023243712};\\\", \\\"{x:1198,y:960,t:1527023243729};\\\", \\\"{x:1203,y:961,t:1527023243745};\\\", \\\"{x:1207,y:962,t:1527023243762};\\\", \\\"{x:1211,y:962,t:1527023243778};\\\", \\\"{x:1211,y:963,t:1527023243795};\\\", \\\"{x:1213,y:963,t:1527023243812};\\\", \\\"{x:1214,y:963,t:1527023243829};\\\", \\\"{x:1220,y:963,t:1527023243845};\\\", \\\"{x:1229,y:963,t:1527023243861};\\\", \\\"{x:1236,y:964,t:1527023243878};\\\", \\\"{x:1242,y:965,t:1527023243895};\\\", \\\"{x:1245,y:965,t:1527023243911};\\\", \\\"{x:1251,y:965,t:1527023243929};\\\", \\\"{x:1258,y:965,t:1527023243945};\\\", \\\"{x:1263,y:965,t:1527023243962};\\\", \\\"{x:1267,y:965,t:1527023243979};\\\", \\\"{x:1270,y:965,t:1527023243995};\\\", \\\"{x:1271,y:965,t:1527023244038};\\\", \\\"{x:1275,y:965,t:1527023244046};\\\", \\\"{x:1294,y:965,t:1527023244061};\\\", \\\"{x:1305,y:965,t:1527023244078};\\\", \\\"{x:1307,y:965,t:1527023244096};\\\", \\\"{x:1304,y:965,t:1527023244271};\\\", \\\"{x:1301,y:965,t:1527023244278};\\\", \\\"{x:1297,y:965,t:1527023244295};\\\", \\\"{x:1295,y:965,t:1527023244312};\\\", \\\"{x:1294,y:965,t:1527023244342};\\\", \\\"{x:1293,y:965,t:1527023244599};\\\", \\\"{x:1291,y:965,t:1527023244612};\\\", \\\"{x:1285,y:960,t:1527023244629};\\\", \\\"{x:1283,y:958,t:1527023244646};\\\", \\\"{x:1281,y:958,t:1527023244663};\\\", \\\"{x:1280,y:957,t:1527023244679};\\\", \\\"{x:1279,y:957,t:1527023244695};\\\", \\\"{x:1279,y:955,t:1527023245334};\\\", \\\"{x:1279,y:952,t:1527023245346};\\\", \\\"{x:1279,y:947,t:1527023245363};\\\", \\\"{x:1279,y:936,t:1527023245379};\\\", \\\"{x:1276,y:919,t:1527023245396};\\\", \\\"{x:1275,y:902,t:1527023245413};\\\", \\\"{x:1273,y:879,t:1527023245430};\\\", \\\"{x:1271,y:859,t:1527023245446};\\\", \\\"{x:1264,y:825,t:1527023245462};\\\", \\\"{x:1256,y:790,t:1527023245480};\\\", \\\"{x:1248,y:759,t:1527023245497};\\\", \\\"{x:1240,y:734,t:1527023245513};\\\", \\\"{x:1234,y:714,t:1527023245530};\\\", \\\"{x:1228,y:688,t:1527023245547};\\\", \\\"{x:1225,y:670,t:1527023245563};\\\", \\\"{x:1223,y:656,t:1527023245579};\\\", \\\"{x:1223,y:641,t:1527023245596};\\\", \\\"{x:1223,y:628,t:1527023245612};\\\", \\\"{x:1223,y:609,t:1527023245629};\\\", \\\"{x:1225,y:600,t:1527023245646};\\\", \\\"{x:1229,y:589,t:1527023245662};\\\", \\\"{x:1231,y:584,t:1527023245679};\\\", \\\"{x:1232,y:580,t:1527023245696};\\\", \\\"{x:1233,y:575,t:1527023245713};\\\", \\\"{x:1236,y:569,t:1527023245729};\\\", \\\"{x:1239,y:561,t:1527023245747};\\\", \\\"{x:1241,y:552,t:1527023245763};\\\", \\\"{x:1242,y:549,t:1527023245779};\\\", \\\"{x:1245,y:544,t:1527023245797};\\\", \\\"{x:1245,y:542,t:1527023245812};\\\", \\\"{x:1247,y:541,t:1527023245832};\\\", \\\"{x:1247,y:540,t:1527023245868};\\\", \\\"{x:1248,y:539,t:1527023245893};\\\", \\\"{x:1250,y:538,t:1527023245965};\\\", \\\"{x:1251,y:539,t:1527023245989};\\\", \\\"{x:1252,y:540,t:1527023245997};\\\", \\\"{x:1253,y:543,t:1527023246013};\\\", \\\"{x:1254,y:545,t:1527023246029};\\\", \\\"{x:1255,y:549,t:1527023246046};\\\", \\\"{x:1256,y:551,t:1527023246063};\\\", \\\"{x:1256,y:552,t:1527023246079};\\\", \\\"{x:1256,y:553,t:1527023246096};\\\", \\\"{x:1256,y:556,t:1527023246113};\\\", \\\"{x:1261,y:558,t:1527023246130};\\\", \\\"{x:1263,y:559,t:1527023246146};\\\", \\\"{x:1264,y:560,t:1527023246163};\\\", \\\"{x:1265,y:561,t:1527023246179};\\\", \\\"{x:1266,y:562,t:1527023246196};\\\", \\\"{x:1267,y:563,t:1527023246213};\\\", \\\"{x:1267,y:564,t:1527023246237};\\\", \\\"{x:1268,y:564,t:1527023246247};\\\", \\\"{x:1268,y:565,t:1527023246311};\\\", \\\"{x:1269,y:566,t:1527023246423};\\\", \\\"{x:1271,y:566,t:1527023246455};\\\", \\\"{x:1271,y:567,t:1527023246469};\\\", \\\"{x:1272,y:567,t:1527023246480};\\\", \\\"{x:1273,y:568,t:1527023246501};\\\", \\\"{x:1274,y:568,t:1527023246533};\\\", \\\"{x:1276,y:571,t:1527023246687};\\\", \\\"{x:1277,y:574,t:1527023246697};\\\", \\\"{x:1279,y:583,t:1527023246713};\\\", \\\"{x:1279,y:592,t:1527023246731};\\\", \\\"{x:1282,y:601,t:1527023246748};\\\", \\\"{x:1282,y:609,t:1527023246764};\\\", \\\"{x:1282,y:623,t:1527023246780};\\\", \\\"{x:1280,y:644,t:1527023246798};\\\", \\\"{x:1280,y:658,t:1527023246814};\\\", \\\"{x:1280,y:668,t:1527023246831};\\\", \\\"{x:1280,y:673,t:1527023246848};\\\", \\\"{x:1280,y:678,t:1527023246864};\\\", \\\"{x:1279,y:683,t:1527023246881};\\\", \\\"{x:1278,y:686,t:1527023246898};\\\", \\\"{x:1278,y:690,t:1527023246914};\\\", \\\"{x:1278,y:694,t:1527023246931};\\\", \\\"{x:1278,y:698,t:1527023246948};\\\", \\\"{x:1278,y:704,t:1527023246964};\\\", \\\"{x:1278,y:709,t:1527023246980};\\\", \\\"{x:1278,y:712,t:1527023246998};\\\", \\\"{x:1278,y:715,t:1527023247014};\\\", \\\"{x:1278,y:716,t:1527023247030};\\\", \\\"{x:1278,y:721,t:1527023247048};\\\", \\\"{x:1278,y:731,t:1527023247064};\\\", \\\"{x:1278,y:741,t:1527023247080};\\\", \\\"{x:1278,y:747,t:1527023247098};\\\", \\\"{x:1278,y:750,t:1527023247114};\\\", \\\"{x:1278,y:755,t:1527023247132};\\\", \\\"{x:1278,y:766,t:1527023247147};\\\", \\\"{x:1278,y:793,t:1527023247163};\\\", \\\"{x:1276,y:818,t:1527023247180};\\\", \\\"{x:1276,y:833,t:1527023247197};\\\", \\\"{x:1276,y:843,t:1527023247214};\\\", \\\"{x:1276,y:848,t:1527023247230};\\\", \\\"{x:1277,y:855,t:1527023247247};\\\", \\\"{x:1278,y:864,t:1527023247264};\\\", \\\"{x:1281,y:876,t:1527023247280};\\\", \\\"{x:1281,y:886,t:1527023247297};\\\", \\\"{x:1281,y:893,t:1527023247314};\\\", \\\"{x:1282,y:899,t:1527023247331};\\\", \\\"{x:1283,y:907,t:1527023247347};\\\", \\\"{x:1284,y:909,t:1527023247365};\\\", \\\"{x:1284,y:913,t:1527023247381};\\\", \\\"{x:1284,y:924,t:1527023247397};\\\", \\\"{x:1284,y:941,t:1527023247414};\\\", \\\"{x:1284,y:953,t:1527023247431};\\\", \\\"{x:1281,y:961,t:1527023247447};\\\", \\\"{x:1281,y:963,t:1527023247465};\\\", \\\"{x:1280,y:965,t:1527023247481};\\\", \\\"{x:1280,y:967,t:1527023247498};\\\", \\\"{x:1279,y:968,t:1527023247515};\\\", \\\"{x:1280,y:968,t:1527023247974};\\\", \\\"{x:1281,y:969,t:1527023251221};\\\", \\\"{x:1283,y:973,t:1527023251233};\\\", \\\"{x:1289,y:980,t:1527023251250};\\\", \\\"{x:1292,y:983,t:1527023251267};\\\", \\\"{x:1297,y:990,t:1527023251284};\\\", \\\"{x:1297,y:991,t:1527023251367};\\\", \\\"{x:1297,y:992,t:1527023251534};\\\", \\\"{x:1295,y:991,t:1527023251550};\\\", \\\"{x:1288,y:982,t:1527023251568};\\\", \\\"{x:1285,y:977,t:1527023251584};\\\", \\\"{x:1283,y:972,t:1527023251601};\\\", \\\"{x:1283,y:971,t:1527023251618};\\\", \\\"{x:1282,y:970,t:1527023251633};\\\", \\\"{x:1281,y:968,t:1527023251651};\\\", \\\"{x:1281,y:967,t:1527023251686};\\\", \\\"{x:1280,y:967,t:1527023251702};\\\", \\\"{x:1280,y:965,t:1527023251791};\\\", \\\"{x:1280,y:964,t:1527023254654};\\\", \\\"{x:1280,y:960,t:1527023254670};\\\", \\\"{x:1280,y:958,t:1527023254687};\\\", \\\"{x:1280,y:957,t:1527023254710};\\\", \\\"{x:1280,y:955,t:1527023254734};\\\", \\\"{x:1280,y:954,t:1527023254750};\\\", \\\"{x:1280,y:952,t:1527023254774};\\\", \\\"{x:1279,y:951,t:1527023254798};\\\", \\\"{x:1278,y:950,t:1527023254805};\\\", \\\"{x:1278,y:949,t:1527023254821};\\\", \\\"{x:1278,y:945,t:1527023254838};\\\", \\\"{x:1278,y:941,t:1527023254855};\\\", \\\"{x:1278,y:938,t:1527023254870};\\\", \\\"{x:1278,y:934,t:1527023254887};\\\", \\\"{x:1278,y:930,t:1527023254905};\\\", \\\"{x:1278,y:926,t:1527023254920};\\\", \\\"{x:1278,y:922,t:1527023254937};\\\", \\\"{x:1278,y:919,t:1527023254955};\\\", \\\"{x:1278,y:910,t:1527023254970};\\\", \\\"{x:1278,y:903,t:1527023254988};\\\", \\\"{x:1278,y:897,t:1527023255004};\\\", \\\"{x:1278,y:892,t:1527023255021};\\\", \\\"{x:1278,y:885,t:1527023255038};\\\", \\\"{x:1278,y:882,t:1527023255054};\\\", \\\"{x:1278,y:880,t:1527023255094};\\\", \\\"{x:1278,y:879,t:1527023255110};\\\", \\\"{x:1278,y:878,t:1527023255141};\\\", \\\"{x:1278,y:877,t:1527023255155};\\\", \\\"{x:1278,y:875,t:1527023255170};\\\", \\\"{x:1278,y:872,t:1527023255187};\\\", \\\"{x:1278,y:870,t:1527023255204};\\\", \\\"{x:1278,y:866,t:1527023255221};\\\", \\\"{x:1278,y:864,t:1527023255237};\\\", \\\"{x:1278,y:860,t:1527023255254};\\\", \\\"{x:1278,y:851,t:1527023255271};\\\", \\\"{x:1278,y:842,t:1527023255288};\\\", \\\"{x:1278,y:838,t:1527023255305};\\\", \\\"{x:1278,y:835,t:1527023255322};\\\", \\\"{x:1278,y:832,t:1527023255337};\\\", \\\"{x:1278,y:830,t:1527023255355};\\\", \\\"{x:1278,y:828,t:1527023255371};\\\", \\\"{x:1278,y:827,t:1527023255388};\\\", \\\"{x:1278,y:825,t:1527023255405};\\\", \\\"{x:1278,y:822,t:1527023255421};\\\", \\\"{x:1278,y:818,t:1527023255437};\\\", \\\"{x:1278,y:815,t:1527023255455};\\\", \\\"{x:1278,y:813,t:1527023255471};\\\", \\\"{x:1278,y:812,t:1527023255487};\\\", \\\"{x:1278,y:810,t:1527023255505};\\\", \\\"{x:1278,y:806,t:1527023255521};\\\", \\\"{x:1278,y:804,t:1527023255537};\\\", \\\"{x:1278,y:802,t:1527023255555};\\\", \\\"{x:1278,y:801,t:1527023255571};\\\", \\\"{x:1278,y:799,t:1527023255587};\\\", \\\"{x:1278,y:797,t:1527023255604};\\\", \\\"{x:1278,y:793,t:1527023255622};\\\", \\\"{x:1278,y:792,t:1527023255638};\\\", \\\"{x:1278,y:791,t:1527023255654};\\\", \\\"{x:1278,y:790,t:1527023255678};\\\", \\\"{x:1278,y:789,t:1527023255694};\\\", \\\"{x:1278,y:788,t:1527023255704};\\\", \\\"{x:1278,y:787,t:1527023255742};\\\", \\\"{x:1278,y:786,t:1527023255758};\\\", \\\"{x:1278,y:785,t:1527023255771};\\\", \\\"{x:1278,y:782,t:1527023255788};\\\", \\\"{x:1278,y:779,t:1527023255804};\\\", \\\"{x:1278,y:778,t:1527023255822};\\\", \\\"{x:1278,y:776,t:1527023255838};\\\", \\\"{x:1278,y:775,t:1527023255854};\\\", \\\"{x:1278,y:774,t:1527023255871};\\\", \\\"{x:1278,y:773,t:1527023255888};\\\", \\\"{x:1278,y:772,t:1527023255905};\\\", \\\"{x:1279,y:770,t:1527023255922};\\\", \\\"{x:1279,y:767,t:1527023255938};\\\", \\\"{x:1279,y:761,t:1527023255954};\\\", \\\"{x:1281,y:758,t:1527023255971};\\\", \\\"{x:1281,y:757,t:1527023255989};\\\", \\\"{x:1281,y:756,t:1527023256004};\\\", \\\"{x:1281,y:755,t:1527023256030};\\\", \\\"{x:1282,y:755,t:1527023256038};\\\", \\\"{x:1282,y:754,t:1527023256055};\\\", \\\"{x:1282,y:753,t:1527023256071};\\\", \\\"{x:1282,y:752,t:1527023256089};\\\", \\\"{x:1282,y:751,t:1527023256105};\\\", \\\"{x:1282,y:750,t:1527023256121};\\\", \\\"{x:1282,y:749,t:1527023256138};\\\", \\\"{x:1282,y:746,t:1527023256154};\\\", \\\"{x:1282,y:744,t:1527023256170};\\\", \\\"{x:1282,y:743,t:1527023256187};\\\", \\\"{x:1282,y:741,t:1527023256204};\\\", \\\"{x:1282,y:740,t:1527023256221};\\\", \\\"{x:1282,y:737,t:1527023256238};\\\", \\\"{x:1282,y:734,t:1527023256254};\\\", \\\"{x:1282,y:733,t:1527023256271};\\\", \\\"{x:1282,y:732,t:1527023256293};\\\", \\\"{x:1282,y:731,t:1527023256305};\\\", \\\"{x:1282,y:728,t:1527023256321};\\\", \\\"{x:1282,y:725,t:1527023256337};\\\", \\\"{x:1281,y:722,t:1527023256355};\\\", \\\"{x:1280,y:715,t:1527023256370};\\\", \\\"{x:1279,y:709,t:1527023256388};\\\", \\\"{x:1278,y:701,t:1527023256405};\\\", \\\"{x:1277,y:699,t:1527023256420};\\\", \\\"{x:1277,y:694,t:1527023256437};\\\", \\\"{x:1276,y:690,t:1527023256455};\\\", \\\"{x:1276,y:689,t:1527023256471};\\\", \\\"{x:1276,y:686,t:1527023256488};\\\", \\\"{x:1276,y:681,t:1527023256505};\\\", \\\"{x:1276,y:671,t:1527023256522};\\\", \\\"{x:1276,y:666,t:1527023256538};\\\", \\\"{x:1276,y:659,t:1527023256555};\\\", \\\"{x:1276,y:650,t:1527023256572};\\\", \\\"{x:1276,y:646,t:1527023256588};\\\", \\\"{x:1276,y:642,t:1527023256606};\\\", \\\"{x:1276,y:636,t:1527023256622};\\\", \\\"{x:1276,y:631,t:1527023256639};\\\", \\\"{x:1277,y:625,t:1527023256656};\\\", \\\"{x:1277,y:620,t:1527023256672};\\\", \\\"{x:1278,y:614,t:1527023256688};\\\", \\\"{x:1279,y:609,t:1527023256705};\\\", \\\"{x:1279,y:604,t:1527023256722};\\\", \\\"{x:1281,y:597,t:1527023256738};\\\", \\\"{x:1281,y:591,t:1527023256755};\\\", \\\"{x:1282,y:586,t:1527023256773};\\\", \\\"{x:1283,y:579,t:1527023256788};\\\", \\\"{x:1286,y:573,t:1527023256806};\\\", \\\"{x:1287,y:562,t:1527023256822};\\\", \\\"{x:1289,y:558,t:1527023256838};\\\", \\\"{x:1290,y:554,t:1527023256856};\\\", \\\"{x:1291,y:552,t:1527023256872};\\\", \\\"{x:1291,y:551,t:1527023256888};\\\", \\\"{x:1292,y:549,t:1527023256905};\\\", \\\"{x:1292,y:548,t:1527023256922};\\\", \\\"{x:1293,y:547,t:1527023256942};\\\", \\\"{x:1293,y:548,t:1527023257205};\\\", \\\"{x:1293,y:550,t:1527023257222};\\\", \\\"{x:1292,y:554,t:1527023257239};\\\", \\\"{x:1291,y:555,t:1527023257254};\\\", \\\"{x:1291,y:557,t:1527023257272};\\\", \\\"{x:1290,y:558,t:1527023257289};\\\", \\\"{x:1289,y:559,t:1527023257622};\\\", \\\"{x:1288,y:561,t:1527023257639};\\\", \\\"{x:1287,y:561,t:1527023257662};\\\", \\\"{x:1287,y:562,t:1527023257677};\\\", \\\"{x:1286,y:562,t:1527023257702};\\\", \\\"{x:1286,y:563,t:1527023257742};\\\", \\\"{x:1286,y:564,t:1527023258935};\\\", \\\"{x:1285,y:565,t:1527023258949};\\\", \\\"{x:1284,y:565,t:1527023260103};\\\", \\\"{x:1284,y:567,t:1527023264006};\\\", \\\"{x:1284,y:568,t:1527023264014};\\\", \\\"{x:1284,y:570,t:1527023264028};\\\", \\\"{x:1284,y:573,t:1527023264044};\\\", \\\"{x:1284,y:575,t:1527023264062};\\\", \\\"{x:1284,y:576,t:1527023264078};\\\", \\\"{x:1284,y:578,t:1527023264094};\\\", \\\"{x:1284,y:580,t:1527023264112};\\\", \\\"{x:1284,y:583,t:1527023264128};\\\", \\\"{x:1284,y:586,t:1527023264144};\\\", \\\"{x:1284,y:590,t:1527023264162};\\\", \\\"{x:1284,y:593,t:1527023264178};\\\", \\\"{x:1284,y:596,t:1527023264194};\\\", \\\"{x:1284,y:600,t:1527023264212};\\\", \\\"{x:1284,y:603,t:1527023264228};\\\", \\\"{x:1284,y:608,t:1527023264245};\\\", \\\"{x:1284,y:620,t:1527023264262};\\\", \\\"{x:1284,y:625,t:1527023264278};\\\", \\\"{x:1284,y:628,t:1527023264297};\\\", \\\"{x:1283,y:630,t:1527023264311};\\\", \\\"{x:1283,y:632,t:1527023264327};\\\", \\\"{x:1282,y:634,t:1527023264344};\\\", \\\"{x:1282,y:638,t:1527023264361};\\\", \\\"{x:1280,y:643,t:1527023264377};\\\", \\\"{x:1279,y:648,t:1527023264394};\\\", \\\"{x:1278,y:652,t:1527023264411};\\\", \\\"{x:1278,y:657,t:1527023264427};\\\", \\\"{x:1276,y:664,t:1527023264444};\\\", \\\"{x:1274,y:677,t:1527023264461};\\\", \\\"{x:1273,y:686,t:1527023264477};\\\", \\\"{x:1272,y:693,t:1527023264494};\\\", \\\"{x:1272,y:703,t:1527023264511};\\\", \\\"{x:1272,y:708,t:1527023264528};\\\", \\\"{x:1272,y:715,t:1527023264544};\\\", \\\"{x:1272,y:722,t:1527023264561};\\\", \\\"{x:1272,y:731,t:1527023264578};\\\", \\\"{x:1272,y:743,t:1527023264594};\\\", \\\"{x:1272,y:758,t:1527023264611};\\\", \\\"{x:1270,y:779,t:1527023264629};\\\", \\\"{x:1270,y:784,t:1527023264644};\\\", \\\"{x:1266,y:795,t:1527023264662};\\\", \\\"{x:1266,y:806,t:1527023264678};\\\", \\\"{x:1266,y:815,t:1527023264695};\\\", \\\"{x:1266,y:823,t:1527023264712};\\\", \\\"{x:1265,y:835,t:1527023264729};\\\", \\\"{x:1264,y:847,t:1527023264745};\\\", \\\"{x:1264,y:858,t:1527023264761};\\\", \\\"{x:1262,y:870,t:1527023264778};\\\", \\\"{x:1262,y:880,t:1527023264795};\\\", \\\"{x:1262,y:886,t:1527023264811};\\\", \\\"{x:1262,y:892,t:1527023264828};\\\", \\\"{x:1263,y:901,t:1527023264845};\\\", \\\"{x:1267,y:916,t:1527023264861};\\\", \\\"{x:1267,y:922,t:1527023264879};\\\", \\\"{x:1270,y:926,t:1527023264895};\\\", \\\"{x:1271,y:928,t:1527023264911};\\\", \\\"{x:1271,y:930,t:1527023264928};\\\", \\\"{x:1273,y:932,t:1527023264947};\\\", \\\"{x:1274,y:936,t:1527023264962};\\\", \\\"{x:1275,y:941,t:1527023264979};\\\", \\\"{x:1276,y:944,t:1527023264996};\\\", \\\"{x:1277,y:947,t:1527023265012};\\\", \\\"{x:1278,y:947,t:1527023265029};\\\", \\\"{x:1280,y:952,t:1527023265045};\\\", \\\"{x:1281,y:955,t:1527023265062};\\\", \\\"{x:1282,y:958,t:1527023265078};\\\", \\\"{x:1285,y:961,t:1527023265095};\\\", \\\"{x:1285,y:963,t:1527023265112};\\\", \\\"{x:1285,y:964,t:1527023265130};\\\", \\\"{x:1285,y:965,t:1527023265158};\\\", \\\"{x:1285,y:966,t:1527023265174};\\\", \\\"{x:1285,y:967,t:1527023265366};\\\", \\\"{x:1283,y:966,t:1527023265379};\\\", \\\"{x:1280,y:963,t:1527023265396};\\\", \\\"{x:1273,y:953,t:1527023265413};\\\", \\\"{x:1263,y:942,t:1527023265429};\\\", \\\"{x:1246,y:922,t:1527023265446};\\\", \\\"{x:1234,y:904,t:1527023265462};\\\", \\\"{x:1222,y:889,t:1527023265479};\\\", \\\"{x:1211,y:875,t:1527023265496};\\\", \\\"{x:1206,y:867,t:1527023265513};\\\", \\\"{x:1201,y:861,t:1527023265528};\\\", \\\"{x:1198,y:856,t:1527023265545};\\\", \\\"{x:1196,y:852,t:1527023265562};\\\", \\\"{x:1196,y:850,t:1527023265579};\\\", \\\"{x:1195,y:849,t:1527023265596};\\\", \\\"{x:1195,y:846,t:1527023265613};\\\", \\\"{x:1193,y:839,t:1527023265630};\\\", \\\"{x:1191,y:831,t:1527023265645};\\\", \\\"{x:1191,y:828,t:1527023265662};\\\", \\\"{x:1191,y:826,t:1527023265679};\\\", \\\"{x:1191,y:824,t:1527023265696};\\\", \\\"{x:1191,y:819,t:1527023265713};\\\", \\\"{x:1192,y:816,t:1527023265729};\\\", \\\"{x:1192,y:814,t:1527023265745};\\\", \\\"{x:1192,y:813,t:1527023265763};\\\", \\\"{x:1193,y:813,t:1527023265879};\\\", \\\"{x:1202,y:814,t:1527023265896};\\\", \\\"{x:1207,y:815,t:1527023265913};\\\", \\\"{x:1209,y:816,t:1527023265930};\\\", \\\"{x:1211,y:817,t:1527023265946};\\\", \\\"{x:1212,y:817,t:1527023265963};\\\", \\\"{x:1213,y:819,t:1527023265980};\\\", \\\"{x:1214,y:820,t:1527023265995};\\\", \\\"{x:1215,y:824,t:1527023266013};\\\", \\\"{x:1215,y:825,t:1527023266057};\\\", \\\"{x:1217,y:827,t:1527023266173};\\\", \\\"{x:1217,y:828,t:1527023266181};\\\", \\\"{x:1217,y:829,t:1527023266195};\\\", \\\"{x:1218,y:830,t:1527023266212};\\\", \\\"{x:1218,y:834,t:1527023271790};\\\", \\\"{x:1218,y:841,t:1527023271802};\\\", \\\"{x:1216,y:855,t:1527023271817};\\\", \\\"{x:1214,y:869,t:1527023271834};\\\", \\\"{x:1210,y:878,t:1527023271851};\\\", \\\"{x:1209,y:885,t:1527023271868};\\\", \\\"{x:1207,y:893,t:1527023271884};\\\", \\\"{x:1207,y:900,t:1527023271901};\\\", \\\"{x:1206,y:913,t:1527023271917};\\\", \\\"{x:1205,y:928,t:1527023271933};\\\", \\\"{x:1209,y:940,t:1527023271951};\\\", \\\"{x:1212,y:947,t:1527023271967};\\\", \\\"{x:1216,y:950,t:1527023271984};\\\", \\\"{x:1219,y:951,t:1527023272001};\\\", \\\"{x:1222,y:953,t:1527023272018};\\\", \\\"{x:1226,y:954,t:1527023272034};\\\", \\\"{x:1229,y:955,t:1527023272051};\\\", \\\"{x:1231,y:955,t:1527023272068};\\\", \\\"{x:1232,y:955,t:1527023272084};\\\", \\\"{x:1233,y:955,t:1527023272142};\\\", \\\"{x:1232,y:955,t:1527023272310};\\\", \\\"{x:1232,y:956,t:1527023272317};\\\", \\\"{x:1231,y:957,t:1527023272333};\\\", \\\"{x:1230,y:959,t:1527023272351};\\\", \\\"{x:1229,y:960,t:1527023272368};\\\", \\\"{x:1229,y:962,t:1527023272384};\\\", \\\"{x:1229,y:963,t:1527023272401};\\\", \\\"{x:1228,y:964,t:1527023272418};\\\", \\\"{x:1228,y:965,t:1527023272438};\\\", \\\"{x:1226,y:966,t:1527023272451};\\\", \\\"{x:1226,y:967,t:1527023272468};\\\", \\\"{x:1225,y:967,t:1527023272485};\\\", \\\"{x:1225,y:968,t:1527023272518};\\\", \\\"{x:1226,y:968,t:1527023272598};\\\", \\\"{x:1230,y:968,t:1527023272606};\\\", \\\"{x:1235,y:968,t:1527023272618};\\\", \\\"{x:1243,y:968,t:1527023272635};\\\", \\\"{x:1251,y:968,t:1527023272651};\\\", \\\"{x:1258,y:967,t:1527023272668};\\\", \\\"{x:1260,y:966,t:1527023272685};\\\", \\\"{x:1261,y:965,t:1527023272701};\\\", \\\"{x:1262,y:964,t:1527023272718};\\\", \\\"{x:1263,y:964,t:1527023272934};\\\", \\\"{x:1265,y:964,t:1527023272952};\\\", \\\"{x:1267,y:964,t:1527023272968};\\\", \\\"{x:1269,y:964,t:1527023272985};\\\", \\\"{x:1270,y:964,t:1527023273002};\\\", \\\"{x:1272,y:964,t:1527023273018};\\\", \\\"{x:1273,y:964,t:1527023273046};\\\", \\\"{x:1274,y:964,t:1527023273061};\\\", \\\"{x:1275,y:964,t:1527023273069};\\\", \\\"{x:1277,y:964,t:1527023273254};\\\", \\\"{x:1278,y:964,t:1527023273269};\\\", \\\"{x:1280,y:964,t:1527023273285};\\\", \\\"{x:1281,y:964,t:1527023273308};\\\", \\\"{x:1282,y:962,t:1527023275734};\\\", \\\"{x:1282,y:960,t:1527023275741};\\\", \\\"{x:1282,y:958,t:1527023275755};\\\", \\\"{x:1282,y:954,t:1527023275770};\\\", \\\"{x:1282,y:950,t:1527023275787};\\\", \\\"{x:1282,y:947,t:1527023275804};\\\", \\\"{x:1282,y:943,t:1527023275820};\\\", \\\"{x:1282,y:942,t:1527023275837};\\\", \\\"{x:1281,y:934,t:1527023275853};\\\", \\\"{x:1280,y:930,t:1527023275870};\\\", \\\"{x:1279,y:925,t:1527023275887};\\\", \\\"{x:1279,y:922,t:1527023275904};\\\", \\\"{x:1279,y:916,t:1527023275920};\\\", \\\"{x:1277,y:911,t:1527023275937};\\\", \\\"{x:1276,y:908,t:1527023275954};\\\", \\\"{x:1276,y:899,t:1527023275970};\\\", \\\"{x:1275,y:893,t:1527023275987};\\\", \\\"{x:1272,y:888,t:1527023276004};\\\", \\\"{x:1272,y:883,t:1527023276022};\\\", \\\"{x:1272,y:876,t:1527023276037};\\\", \\\"{x:1272,y:867,t:1527023276054};\\\", \\\"{x:1272,y:861,t:1527023276071};\\\", \\\"{x:1272,y:854,t:1527023276087};\\\", \\\"{x:1272,y:847,t:1527023276104};\\\", \\\"{x:1272,y:842,t:1527023276122};\\\", \\\"{x:1271,y:839,t:1527023276137};\\\", \\\"{x:1271,y:837,t:1527023276154};\\\", \\\"{x:1271,y:832,t:1527023276171};\\\", \\\"{x:1271,y:827,t:1527023276187};\\\", \\\"{x:1271,y:822,t:1527023276204};\\\", \\\"{x:1271,y:815,t:1527023276222};\\\", \\\"{x:1271,y:800,t:1527023276237};\\\", \\\"{x:1271,y:786,t:1527023276254};\\\", \\\"{x:1271,y:779,t:1527023276271};\\\", \\\"{x:1271,y:771,t:1527023276287};\\\", \\\"{x:1271,y:768,t:1527023276304};\\\", \\\"{x:1271,y:763,t:1527023276322};\\\", \\\"{x:1271,y:758,t:1527023276337};\\\", \\\"{x:1271,y:752,t:1527023276354};\\\", \\\"{x:1271,y:744,t:1527023276371};\\\", \\\"{x:1271,y:737,t:1527023276387};\\\", \\\"{x:1271,y:731,t:1527023276404};\\\", \\\"{x:1271,y:720,t:1527023276421};\\\", \\\"{x:1274,y:689,t:1527023276437};\\\", \\\"{x:1274,y:678,t:1527023276454};\\\", \\\"{x:1275,y:666,t:1527023276471};\\\", \\\"{x:1276,y:651,t:1527023276488};\\\", \\\"{x:1278,y:637,t:1527023276505};\\\", \\\"{x:1279,y:618,t:1527023276521};\\\", \\\"{x:1279,y:603,t:1527023276538};\\\", \\\"{x:1279,y:590,t:1527023276554};\\\", \\\"{x:1279,y:575,t:1527023276572};\\\", \\\"{x:1279,y:561,t:1527023276589};\\\", \\\"{x:1279,y:554,t:1527023276604};\\\", \\\"{x:1280,y:544,t:1527023276621};\\\", \\\"{x:1280,y:539,t:1527023276637};\\\", \\\"{x:1280,y:534,t:1527023276655};\\\", \\\"{x:1280,y:530,t:1527023276671};\\\", \\\"{x:1280,y:528,t:1527023276688};\\\", \\\"{x:1280,y:527,t:1527023276705};\\\", \\\"{x:1280,y:525,t:1527023276721};\\\", \\\"{x:1280,y:524,t:1527023276738};\\\", \\\"{x:1280,y:523,t:1527023276755};\\\", \\\"{x:1280,y:522,t:1527023276771};\\\", \\\"{x:1282,y:522,t:1527023277222};\\\", \\\"{x:1287,y:522,t:1527023277238};\\\", \\\"{x:1297,y:525,t:1527023277255};\\\", \\\"{x:1310,y:527,t:1527023277272};\\\", \\\"{x:1325,y:528,t:1527023277287};\\\", \\\"{x:1348,y:528,t:1527023277304};\\\", \\\"{x:1376,y:531,t:1527023277322};\\\", \\\"{x:1398,y:531,t:1527023277337};\\\", \\\"{x:1419,y:531,t:1527023277354};\\\", \\\"{x:1437,y:534,t:1527023277372};\\\", \\\"{x:1462,y:534,t:1527023277388};\\\", \\\"{x:1470,y:534,t:1527023277405};\\\", \\\"{x:1473,y:534,t:1527023277421};\\\", \\\"{x:1477,y:534,t:1527023277438};\\\", \\\"{x:1483,y:534,t:1527023277455};\\\", \\\"{x:1486,y:534,t:1527023277472};\\\", \\\"{x:1487,y:534,t:1527023277493};\\\", \\\"{x:1485,y:534,t:1527023278118};\\\", \\\"{x:1483,y:534,t:1527023278126};\\\", \\\"{x:1481,y:534,t:1527023278142};\\\", \\\"{x:1477,y:534,t:1527023278155};\\\", \\\"{x:1470,y:534,t:1527023278172};\\\", \\\"{x:1466,y:534,t:1527023278190};\\\", \\\"{x:1464,y:534,t:1527023278205};\\\", \\\"{x:1461,y:534,t:1527023278221};\\\", \\\"{x:1457,y:532,t:1527023278239};\\\", \\\"{x:1453,y:532,t:1527023278255};\\\", \\\"{x:1447,y:530,t:1527023278272};\\\", \\\"{x:1438,y:528,t:1527023278289};\\\", \\\"{x:1430,y:527,t:1527023278305};\\\", \\\"{x:1422,y:526,t:1527023278322};\\\", \\\"{x:1418,y:526,t:1527023278339};\\\", \\\"{x:1412,y:524,t:1527023278358};\\\", \\\"{x:1408,y:523,t:1527023278375};\\\", \\\"{x:1394,y:519,t:1527023278392};\\\", \\\"{x:1388,y:517,t:1527023278408};\\\", \\\"{x:1381,y:515,t:1527023278425};\\\", \\\"{x:1376,y:514,t:1527023278442};\\\", \\\"{x:1371,y:514,t:1527023278459};\\\", \\\"{x:1367,y:514,t:1527023278474};\\\", \\\"{x:1363,y:514,t:1527023278491};\\\", \\\"{x:1359,y:518,t:1527023278508};\\\", \\\"{x:1355,y:522,t:1527023278524};\\\", \\\"{x:1354,y:525,t:1527023278541};\\\", \\\"{x:1353,y:527,t:1527023278558};\\\", \\\"{x:1352,y:530,t:1527023278574};\\\", \\\"{x:1351,y:531,t:1527023278689};\\\", \\\"{x:1349,y:531,t:1527023278696};\\\", \\\"{x:1347,y:528,t:1527023278709};\\\", \\\"{x:1341,y:518,t:1527023278726};\\\", \\\"{x:1338,y:514,t:1527023278742};\\\", \\\"{x:1335,y:510,t:1527023278758};\\\", \\\"{x:1333,y:507,t:1527023278776};\\\", \\\"{x:1325,y:500,t:1527023278792};\\\", \\\"{x:1322,y:498,t:1527023278809};\\\", \\\"{x:1321,y:497,t:1527023279081};\\\", \\\"{x:1320,y:496,t:1527023279093};\\\", \\\"{x:1319,y:496,t:1527023279126};\\\", \\\"{x:1316,y:495,t:1527023279143};\\\", \\\"{x:1313,y:493,t:1527023279159};\\\", \\\"{x:1311,y:493,t:1527023279200};\\\", \\\"{x:1310,y:492,t:1527023279314};\\\", \\\"{x:1309,y:492,t:1527023279328};\\\", \\\"{x:1308,y:492,t:1527023279465};\\\", \\\"{x:1308,y:493,t:1527023279929};\\\", \\\"{x:1305,y:507,t:1527023279942};\\\", \\\"{x:1297,y:596,t:1527023279959};\\\", \\\"{x:1296,y:639,t:1527023279975};\\\", \\\"{x:1296,y:662,t:1527023279992};\\\", \\\"{x:1296,y:674,t:1527023280009};\\\", \\\"{x:1296,y:683,t:1527023280027};\\\", \\\"{x:1298,y:691,t:1527023280042};\\\", \\\"{x:1298,y:697,t:1527023280059};\\\", \\\"{x:1302,y:709,t:1527023280077};\\\", \\\"{x:1305,y:722,t:1527023280093};\\\", \\\"{x:1310,y:734,t:1527023280110};\\\", \\\"{x:1314,y:743,t:1527023280126};\\\", \\\"{x:1317,y:750,t:1527023280143};\\\", \\\"{x:1321,y:760,t:1527023280161};\\\", \\\"{x:1322,y:763,t:1527023280177};\\\", \\\"{x:1322,y:765,t:1527023280193};\\\", \\\"{x:1324,y:766,t:1527023280210};\\\", \\\"{x:1325,y:768,t:1527023280227};\\\", \\\"{x:1326,y:770,t:1527023280244};\\\", \\\"{x:1326,y:771,t:1527023280841};\\\", \\\"{x:1325,y:771,t:1527023280849};\\\", \\\"{x:1325,y:773,t:1527023280881};\\\", \\\"{x:1325,y:774,t:1527023280920};\\\", \\\"{x:1325,y:776,t:1527023280969};\\\", \\\"{x:1325,y:777,t:1527023280984};\\\", \\\"{x:1325,y:778,t:1527023280994};\\\", \\\"{x:1325,y:781,t:1527023281011};\\\", \\\"{x:1327,y:786,t:1527023281028};\\\", \\\"{x:1327,y:789,t:1527023281044};\\\", \\\"{x:1329,y:791,t:1527023281061};\\\", \\\"{x:1330,y:796,t:1527023281077};\\\", \\\"{x:1333,y:800,t:1527023281094};\\\", \\\"{x:1337,y:811,t:1527023281112};\\\", \\\"{x:1337,y:817,t:1527023281128};\\\", \\\"{x:1338,y:820,t:1527023281144};\\\", \\\"{x:1339,y:824,t:1527023281161};\\\", \\\"{x:1339,y:825,t:1527023281177};\\\", \\\"{x:1339,y:827,t:1527023281194};\\\", \\\"{x:1340,y:830,t:1527023281211};\\\", \\\"{x:1340,y:832,t:1527023281227};\\\", \\\"{x:1340,y:836,t:1527023281244};\\\", \\\"{x:1340,y:840,t:1527023281262};\\\", \\\"{x:1340,y:848,t:1527023281278};\\\", \\\"{x:1341,y:856,t:1527023281294};\\\", \\\"{x:1341,y:860,t:1527023281311};\\\", \\\"{x:1341,y:868,t:1527023281328};\\\", \\\"{x:1341,y:874,t:1527023281344};\\\", \\\"{x:1341,y:880,t:1527023281362};\\\", \\\"{x:1340,y:889,t:1527023281378};\\\", \\\"{x:1340,y:896,t:1527023281395};\\\", \\\"{x:1339,y:901,t:1527023281412};\\\", \\\"{x:1339,y:904,t:1527023281428};\\\", \\\"{x:1337,y:910,t:1527023281444};\\\", \\\"{x:1336,y:916,t:1527023281461};\\\", \\\"{x:1336,y:922,t:1527023281479};\\\", \\\"{x:1336,y:925,t:1527023281494};\\\", \\\"{x:1336,y:928,t:1527023281512};\\\", \\\"{x:1335,y:934,t:1527023281529};\\\", \\\"{x:1334,y:937,t:1527023281544};\\\", \\\"{x:1332,y:939,t:1527023281561};\\\", \\\"{x:1332,y:941,t:1527023281578};\\\", \\\"{x:1332,y:942,t:1527023281595};\\\", \\\"{x:1332,y:944,t:1527023281612};\\\", \\\"{x:1332,y:945,t:1527023281628};\\\", \\\"{x:1330,y:947,t:1527023281644};\\\", \\\"{x:1329,y:950,t:1527023281661};\\\", \\\"{x:1329,y:953,t:1527023281678};\\\", \\\"{x:1327,y:954,t:1527023281694};\\\", \\\"{x:1326,y:955,t:1527023281711};\\\", \\\"{x:1325,y:956,t:1527023281728};\\\", \\\"{x:1324,y:957,t:1527023281768};\\\", \\\"{x:1324,y:958,t:1527023281777};\\\", \\\"{x:1322,y:959,t:1527023281794};\\\", \\\"{x:1321,y:960,t:1527023281810};\\\", \\\"{x:1318,y:961,t:1527023281827};\\\", \\\"{x:1317,y:963,t:1527023281845};\\\", \\\"{x:1315,y:963,t:1527023281861};\\\", \\\"{x:1315,y:964,t:1527023281920};\\\", \\\"{x:1314,y:964,t:1527023281928};\\\", \\\"{x:1315,y:965,t:1527023284041};\\\", \\\"{x:1315,y:968,t:1527023284048};\\\", \\\"{x:1309,y:971,t:1527023284063};\\\", \\\"{x:1283,y:989,t:1527023284081};\\\", \\\"{x:1271,y:996,t:1527023284096};\\\", \\\"{x:1268,y:1001,t:1527023284113};\\\", \\\"{x:1266,y:1003,t:1527023284130};\\\", \\\"{x:1266,y:1002,t:1527023284256};\\\", \\\"{x:1266,y:1000,t:1527023284265};\\\", \\\"{x:1270,y:993,t:1527023284280};\\\", \\\"{x:1277,y:987,t:1527023284297};\\\", \\\"{x:1280,y:984,t:1527023284314};\\\", \\\"{x:1283,y:981,t:1527023284331};\\\", \\\"{x:1285,y:979,t:1527023284346};\\\", \\\"{x:1285,y:978,t:1527023284363};\\\", \\\"{x:1285,y:976,t:1527023284513};\\\", \\\"{x:1281,y:969,t:1527023284530};\\\", \\\"{x:1278,y:965,t:1527023284548};\\\", \\\"{x:1275,y:960,t:1527023284564};\\\", \\\"{x:1273,y:955,t:1527023284580};\\\", \\\"{x:1274,y:955,t:1527023284857};\\\", \\\"{x:1275,y:955,t:1527023284872};\\\", \\\"{x:1276,y:956,t:1527023284888};\\\", \\\"{x:1276,y:957,t:1527023284905};\\\", \\\"{x:1277,y:957,t:1527023286600};\\\", \\\"{x:1278,y:958,t:1527023286615};\\\", \\\"{x:1279,y:959,t:1527023286632};\\\", \\\"{x:1281,y:960,t:1527023286648};\\\", \\\"{x:1283,y:961,t:1527023286753};\\\", \\\"{x:1284,y:962,t:1527023286937};\\\", \\\"{x:1285,y:962,t:1527023286949};\\\", \\\"{x:1286,y:963,t:1527023286985};\\\", \\\"{x:1283,y:961,t:1527023288873};\\\", \\\"{x:1283,y:958,t:1527023288884};\\\", \\\"{x:1277,y:951,t:1527023288901};\\\", \\\"{x:1274,y:945,t:1527023288918};\\\", \\\"{x:1271,y:937,t:1527023288934};\\\", \\\"{x:1266,y:928,t:1527023288950};\\\", \\\"{x:1263,y:918,t:1527023288967};\\\", \\\"{x:1260,y:909,t:1527023288984};\\\", \\\"{x:1257,y:902,t:1527023289000};\\\", \\\"{x:1256,y:897,t:1527023289018};\\\", \\\"{x:1253,y:890,t:1527023289033};\\\", \\\"{x:1253,y:885,t:1527023289050};\\\", \\\"{x:1252,y:881,t:1527023289068};\\\", \\\"{x:1250,y:876,t:1527023289084};\\\", \\\"{x:1249,y:872,t:1527023289106};\\\", \\\"{x:1248,y:867,t:1527023289117};\\\", \\\"{x:1246,y:862,t:1527023289133};\\\", \\\"{x:1246,y:859,t:1527023289150};\\\", \\\"{x:1244,y:853,t:1527023289167};\\\", \\\"{x:1241,y:848,t:1527023289182};\\\", \\\"{x:1241,y:847,t:1527023289200};\\\", \\\"{x:1240,y:845,t:1527023289216};\\\", \\\"{x:1239,y:843,t:1527023289234};\\\", \\\"{x:1238,y:841,t:1527023289250};\\\", \\\"{x:1237,y:840,t:1527023289267};\\\", \\\"{x:1236,y:838,t:1527023289283};\\\", \\\"{x:1234,y:837,t:1527023289300};\\\", \\\"{x:1234,y:835,t:1527023289328};\\\", \\\"{x:1233,y:835,t:1527023289369};\\\", \\\"{x:1232,y:835,t:1527023289392};\\\", \\\"{x:1231,y:835,t:1527023289401};\\\", \\\"{x:1230,y:835,t:1527023289417};\\\", \\\"{x:1229,y:835,t:1527023289440};\\\", \\\"{x:1228,y:835,t:1527023289451};\\\", \\\"{x:1227,y:835,t:1527023289468};\\\", \\\"{x:1225,y:835,t:1527023289656};\\\", \\\"{x:1224,y:835,t:1527023289668};\\\", \\\"{x:1223,y:835,t:1527023289685};\\\", \\\"{x:1222,y:835,t:1527023289701};\\\", \\\"{x:1221,y:835,t:1527023289718};\\\", \\\"{x:1220,y:835,t:1527023289744};\\\", \\\"{x:1219,y:835,t:1527023289809};\\\", \\\"{x:1218,y:836,t:1527023289833};\\\", \\\"{x:1217,y:836,t:1527023289873};\\\", \\\"{x:1216,y:837,t:1527023290217};\\\", \\\"{x:1216,y:838,t:1527023290224};\\\", \\\"{x:1219,y:841,t:1527023290235};\\\", \\\"{x:1225,y:843,t:1527023290252};\\\", \\\"{x:1227,y:844,t:1527023290268};\\\", \\\"{x:1228,y:845,t:1527023290288};\\\", \\\"{x:1230,y:846,t:1527023290344};\\\", \\\"{x:1231,y:846,t:1527023290352};\\\", \\\"{x:1238,y:846,t:1527023290368};\\\", \\\"{x:1264,y:846,t:1527023290385};\\\", \\\"{x:1280,y:846,t:1527023290401};\\\", \\\"{x:1287,y:846,t:1527023290419};\\\", \\\"{x:1296,y:846,t:1527023290434};\\\", \\\"{x:1303,y:846,t:1527023290451};\\\", \\\"{x:1305,y:846,t:1527023290468};\\\", \\\"{x:1307,y:846,t:1527023290485};\\\", \\\"{x:1308,y:846,t:1527023290504};\\\", \\\"{x:1309,y:846,t:1527023290521};\\\", \\\"{x:1310,y:846,t:1527023290536};\\\", \\\"{x:1311,y:846,t:1527023290552};\\\", \\\"{x:1315,y:846,t:1527023290568};\\\", \\\"{x:1318,y:846,t:1527023290584};\\\", \\\"{x:1319,y:846,t:1527023290608};\\\", \\\"{x:1320,y:845,t:1527023290619};\\\", \\\"{x:1321,y:845,t:1527023290689};\\\", \\\"{x:1322,y:845,t:1527023290702};\\\", \\\"{x:1323,y:845,t:1527023290719};\\\", \\\"{x:1326,y:845,t:1527023290736};\\\", \\\"{x:1328,y:845,t:1527023290768};\\\", \\\"{x:1329,y:844,t:1527023290786};\\\", \\\"{x:1332,y:842,t:1527023290802};\\\", \\\"{x:1334,y:841,t:1527023290819};\\\", \\\"{x:1335,y:840,t:1527023290836};\\\", \\\"{x:1336,y:839,t:1527023290851};\\\", \\\"{x:1337,y:838,t:1527023290869};\\\", \\\"{x:1338,y:838,t:1527023290977};\\\", \\\"{x:1339,y:838,t:1527023291000};\\\", \\\"{x:1341,y:836,t:1527023291019};\\\", \\\"{x:1342,y:836,t:1527023291041};\\\", \\\"{x:1343,y:836,t:1527023291321};\\\", \\\"{x:1344,y:836,t:1527023291352};\\\", \\\"{x:1345,y:836,t:1527023293617};\\\", \\\"{x:1345,y:835,t:1527023293624};\\\", \\\"{x:1343,y:835,t:1527023293638};\\\", \\\"{x:1342,y:835,t:1527023293654};\\\", \\\"{x:1339,y:835,t:1527023293671};\\\", \\\"{x:1334,y:836,t:1527023293688};\\\", \\\"{x:1328,y:838,t:1527023293704};\\\", \\\"{x:1325,y:839,t:1527023293721};\\\", \\\"{x:1325,y:840,t:1527023293738};\\\", \\\"{x:1322,y:840,t:1527023293755};\\\", \\\"{x:1319,y:841,t:1527023293770};\\\", \\\"{x:1318,y:841,t:1527023293788};\\\", \\\"{x:1317,y:842,t:1527023293804};\\\", \\\"{x:1315,y:843,t:1527023293821};\\\", \\\"{x:1314,y:843,t:1527023293838};\\\", \\\"{x:1312,y:844,t:1527023293855};\\\", \\\"{x:1311,y:844,t:1527023293871};\\\", \\\"{x:1309,y:843,t:1527023294001};\\\", \\\"{x:1309,y:842,t:1527023294009};\\\", \\\"{x:1309,y:840,t:1527023294021};\\\", \\\"{x:1309,y:839,t:1527023294038};\\\", \\\"{x:1309,y:837,t:1527023294055};\\\", \\\"{x:1309,y:836,t:1527023294136};\\\", \\\"{x:1309,y:834,t:1527023294155};\\\", \\\"{x:1309,y:833,t:1527023294201};\\\", \\\"{x:1311,y:833,t:1527023294473};\\\", \\\"{x:1313,y:832,t:1527023294488};\\\", \\\"{x:1326,y:828,t:1527023294505};\\\", \\\"{x:1329,y:827,t:1527023294522};\\\", \\\"{x:1330,y:826,t:1527023294538};\\\", \\\"{x:1331,y:825,t:1527023294555};\\\", \\\"{x:1331,y:822,t:1527023294572};\\\", \\\"{x:1331,y:819,t:1527023294588};\\\", \\\"{x:1326,y:804,t:1527023294605};\\\", \\\"{x:1321,y:783,t:1527023294622};\\\", \\\"{x:1312,y:756,t:1527023294639};\\\", \\\"{x:1299,y:723,t:1527023294655};\\\", \\\"{x:1273,y:676,t:1527023294673};\\\", \\\"{x:1267,y:658,t:1527023294688};\\\", \\\"{x:1259,y:636,t:1527023294705};\\\", \\\"{x:1252,y:618,t:1527023294722};\\\", \\\"{x:1249,y:608,t:1527023294739};\\\", \\\"{x:1246,y:594,t:1527023294755};\\\", \\\"{x:1240,y:579,t:1527023294772};\\\", \\\"{x:1238,y:575,t:1527023294789};\\\", \\\"{x:1237,y:574,t:1527023294805};\\\", \\\"{x:1238,y:573,t:1527023295024};\\\", \\\"{x:1244,y:570,t:1527023295039};\\\", \\\"{x:1271,y:565,t:1527023295056};\\\", \\\"{x:1279,y:560,t:1527023295072};\\\", \\\"{x:1293,y:551,t:1527023295089};\\\", \\\"{x:1304,y:541,t:1527023295106};\\\", \\\"{x:1309,y:536,t:1527023295122};\\\", \\\"{x:1310,y:534,t:1527023295138};\\\", \\\"{x:1310,y:533,t:1527023295155};\\\", \\\"{x:1310,y:532,t:1527023295176};\\\", \\\"{x:1310,y:530,t:1527023295188};\\\", \\\"{x:1303,y:528,t:1527023295206};\\\", \\\"{x:1288,y:528,t:1527023295222};\\\", \\\"{x:1267,y:535,t:1527023295238};\\\", \\\"{x:1205,y:574,t:1527023295255};\\\", \\\"{x:1137,y:627,t:1527023295272};\\\", \\\"{x:1029,y:699,t:1527023295288};\\\", \\\"{x:918,y:769,t:1527023295305};\\\", \\\"{x:833,y:820,t:1527023295322};\\\", \\\"{x:780,y:847,t:1527023295338};\\\", \\\"{x:764,y:853,t:1527023295355};\\\", \\\"{x:760,y:856,t:1527023295371};\\\", \\\"{x:757,y:857,t:1527023295388};\\\", \\\"{x:755,y:859,t:1527023295405};\\\", \\\"{x:749,y:859,t:1527023295421};\\\", \\\"{x:740,y:859,t:1527023295439};\\\", \\\"{x:712,y:848,t:1527023295456};\\\", \\\"{x:683,y:832,t:1527023295472};\\\", \\\"{x:639,y:812,t:1527023295488};\\\", \\\"{x:605,y:796,t:1527023295506};\\\", \\\"{x:582,y:781,t:1527023295523};\\\", \\\"{x:573,y:767,t:1527023295539};\\\", \\\"{x:567,y:742,t:1527023295556};\\\", \\\"{x:562,y:711,t:1527023295575};\\\", \\\"{x:557,y:683,t:1527023295589};\\\", \\\"{x:549,y:659,t:1527023295605};\\\", \\\"{x:538,y:633,t:1527023295625};\\\", \\\"{x:531,y:624,t:1527023295641};\\\", \\\"{x:524,y:620,t:1527023295658};\\\", \\\"{x:510,y:614,t:1527023295674};\\\", \\\"{x:488,y:610,t:1527023295691};\\\", \\\"{x:469,y:603,t:1527023295708};\\\", \\\"{x:453,y:599,t:1527023295724};\\\", \\\"{x:440,y:595,t:1527023295741};\\\", \\\"{x:426,y:591,t:1527023295758};\\\", \\\"{x:399,y:582,t:1527023295775};\\\", \\\"{x:381,y:577,t:1527023295791};\\\", \\\"{x:366,y:573,t:1527023295808};\\\", \\\"{x:357,y:570,t:1527023295824};\\\", \\\"{x:350,y:568,t:1527023295841};\\\", \\\"{x:348,y:568,t:1527023295858};\\\", \\\"{x:346,y:567,t:1527023295875};\\\", \\\"{x:342,y:565,t:1527023295891};\\\", \\\"{x:338,y:563,t:1527023295908};\\\", \\\"{x:337,y:563,t:1527023295960};\\\", \\\"{x:337,y:561,t:1527023295974};\\\", \\\"{x:347,y:556,t:1527023295992};\\\", \\\"{x:377,y:545,t:1527023296008};\\\", \\\"{x:419,y:535,t:1527023296028};\\\", \\\"{x:461,y:530,t:1527023296042};\\\", \\\"{x:508,y:530,t:1527023296061};\\\", \\\"{x:546,y:529,t:1527023296075};\\\", \\\"{x:570,y:525,t:1527023296091};\\\", \\\"{x:581,y:523,t:1527023296108};\\\", \\\"{x:583,y:521,t:1527023296125};\\\", \\\"{x:585,y:521,t:1527023296344};\\\", \\\"{x:587,y:521,t:1527023296359};\\\", \\\"{x:590,y:519,t:1527023296376};\\\", \\\"{x:591,y:519,t:1527023296393};\\\", \\\"{x:592,y:519,t:1527023296409};\\\", \\\"{x:593,y:519,t:1527023296464};\\\", \\\"{x:593,y:519,t:1527023296531};\\\", \\\"{x:585,y:519,t:1527023296576};\\\", \\\"{x:562,y:523,t:1527023296593};\\\", \\\"{x:520,y:524,t:1527023296609};\\\", \\\"{x:464,y:524,t:1527023296627};\\\", \\\"{x:427,y:524,t:1527023296642};\\\", \\\"{x:407,y:524,t:1527023296658};\\\", \\\"{x:393,y:524,t:1527023296675};\\\", \\\"{x:388,y:524,t:1527023296692};\\\", \\\"{x:387,y:525,t:1527023296727};\\\", \\\"{x:386,y:525,t:1527023296743};\\\", \\\"{x:385,y:525,t:1527023296799};\\\", \\\"{x:386,y:525,t:1527023297183};\\\", \\\"{x:395,y:525,t:1527023297192};\\\", \\\"{x:424,y:525,t:1527023297209};\\\", \\\"{x:463,y:525,t:1527023297226};\\\", \\\"{x:505,y:525,t:1527023297242};\\\", \\\"{x:542,y:525,t:1527023297259};\\\", \\\"{x:564,y:525,t:1527023297276};\\\", \\\"{x:571,y:525,t:1527023297292};\\\", \\\"{x:572,y:525,t:1527023297309};\\\", \\\"{x:574,y:525,t:1527023297326};\\\", \\\"{x:574,y:524,t:1527023297456};\\\", \\\"{x:575,y:523,t:1527023297480};\\\", \\\"{x:577,y:521,t:1527023297497};\\\", \\\"{x:579,y:520,t:1527023297510};\\\", \\\"{x:586,y:516,t:1527023297527};\\\", \\\"{x:591,y:515,t:1527023297543};\\\", \\\"{x:597,y:512,t:1527023297560};\\\", \\\"{x:600,y:512,t:1527023297576};\\\", \\\"{x:601,y:512,t:1527023297593};\\\", \\\"{x:603,y:512,t:1527023297610};\\\", \\\"{x:605,y:512,t:1527023297627};\\\", \\\"{x:607,y:512,t:1527023297643};\\\", \\\"{x:611,y:512,t:1527023297659};\\\", \\\"{x:613,y:512,t:1527023297676};\\\", \\\"{x:613,y:518,t:1527023297911};\\\", \\\"{x:613,y:528,t:1527023297927};\\\", \\\"{x:604,y:573,t:1527023297943};\\\", \\\"{x:597,y:619,t:1527023297960};\\\", \\\"{x:594,y:667,t:1527023297976};\\\", \\\"{x:593,y:697,t:1527023297994};\\\", \\\"{x:593,y:715,t:1527023298010};\\\", \\\"{x:592,y:725,t:1527023298027};\\\", \\\"{x:592,y:731,t:1527023298044};\\\", \\\"{x:592,y:738,t:1527023298060};\\\", \\\"{x:591,y:747,t:1527023298076};\\\", \\\"{x:587,y:757,t:1527023298093};\\\", \\\"{x:582,y:768,t:1527023298110};\\\", \\\"{x:580,y:777,t:1527023298127};\\\", \\\"{x:579,y:778,t:1527023298144};\\\", \\\"{x:577,y:778,t:1527023298201};\\\", \\\"{x:574,y:778,t:1527023298211};\\\", \\\"{x:568,y:778,t:1527023298227};\\\", \\\"{x:557,y:771,t:1527023298244};\\\", \\\"{x:543,y:758,t:1527023298261};\\\", \\\"{x:534,y:749,t:1527023298277};\\\", \\\"{x:531,y:743,t:1527023298294};\\\", \\\"{x:528,y:737,t:1527023298311};\\\", \\\"{x:527,y:733,t:1527023298328};\\\", \\\"{x:527,y:728,t:1527023298343};\\\", \\\"{x:527,y:727,t:1527023298361};\\\", \\\"{x:527,y:725,t:1527023299009};\\\", \\\"{x:527,y:723,t:1527023299016};\\\", \\\"{x:530,y:719,t:1527023299028};\\\", \\\"{x:544,y:714,t:1527023299045};\\\", \\\"{x:554,y:712,t:1527023299060};\\\", \\\"{x:563,y:709,t:1527023299078};\\\", \\\"{x:572,y:706,t:1527023299094};\\\", \\\"{x:575,y:702,t:1527023299111};\\\", \\\"{x:577,y:700,t:1527023299128};\\\" ] }, { \\\"rt\\\": 16965, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 338440, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -G -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:577,y:699,t:1527023302064};\\\", \\\"{x:584,y:694,t:1527023302505};\\\", \\\"{x:595,y:688,t:1527023302514};\\\", \\\"{x:632,y:671,t:1527023302531};\\\", \\\"{x:688,y:657,t:1527023302548};\\\", \\\"{x:771,y:632,t:1527023302564};\\\", \\\"{x:860,y:621,t:1527023302581};\\\", \\\"{x:967,y:613,t:1527023302597};\\\", \\\"{x:1055,y:613,t:1527023302614};\\\", \\\"{x:1139,y:613,t:1527023302631};\\\", \\\"{x:1211,y:613,t:1527023302647};\\\", \\\"{x:1260,y:614,t:1527023302664};\\\", \\\"{x:1279,y:614,t:1527023302681};\\\", \\\"{x:1288,y:614,t:1527023302698};\\\", \\\"{x:1289,y:614,t:1527023302720};\\\", \\\"{x:1290,y:614,t:1527023302800};\\\", \\\"{x:1291,y:614,t:1527023302814};\\\", \\\"{x:1292,y:614,t:1527023302865};\\\", \\\"{x:1294,y:614,t:1527023302881};\\\", \\\"{x:1297,y:614,t:1527023302898};\\\", \\\"{x:1301,y:614,t:1527023302914};\\\", \\\"{x:1309,y:614,t:1527023302931};\\\", \\\"{x:1324,y:611,t:1527023302948};\\\", \\\"{x:1353,y:602,t:1527023302964};\\\", \\\"{x:1409,y:577,t:1527023302981};\\\", \\\"{x:1473,y:558,t:1527023302998};\\\", \\\"{x:1516,y:547,t:1527023303014};\\\", \\\"{x:1532,y:541,t:1527023303031};\\\", \\\"{x:1565,y:527,t:1527023303049};\\\", \\\"{x:1582,y:521,t:1527023303064};\\\", \\\"{x:1607,y:500,t:1527023303081};\\\", \\\"{x:1628,y:484,t:1527023303098};\\\", \\\"{x:1635,y:478,t:1527023303114};\\\", \\\"{x:1636,y:475,t:1527023303131};\\\", \\\"{x:1638,y:469,t:1527023303148};\\\", \\\"{x:1639,y:465,t:1527023303164};\\\", \\\"{x:1639,y:462,t:1527023303181};\\\", \\\"{x:1639,y:461,t:1527023303198};\\\", \\\"{x:1639,y:459,t:1527023303214};\\\", \\\"{x:1640,y:458,t:1527023303232};\\\", \\\"{x:1643,y:449,t:1527023303248};\\\", \\\"{x:1643,y:446,t:1527023303265};\\\", \\\"{x:1643,y:443,t:1527023303281};\\\", \\\"{x:1643,y:442,t:1527023303304};\\\", \\\"{x:1642,y:440,t:1527023303315};\\\", \\\"{x:1640,y:439,t:1527023303332};\\\", \\\"{x:1635,y:436,t:1527023303348};\\\", \\\"{x:1634,y:435,t:1527023303365};\\\", \\\"{x:1632,y:434,t:1527023303381};\\\", \\\"{x:1631,y:433,t:1527023303398};\\\", \\\"{x:1630,y:432,t:1527023303415};\\\", \\\"{x:1628,y:432,t:1527023303431};\\\", \\\"{x:1627,y:432,t:1527023303600};\\\", \\\"{x:1625,y:432,t:1527023303615};\\\", \\\"{x:1622,y:432,t:1527023303630};\\\", \\\"{x:1621,y:432,t:1527023303647};\\\", \\\"{x:1619,y:432,t:1527023303666};\\\", \\\"{x:1617,y:432,t:1527023303697};\\\", \\\"{x:1617,y:435,t:1527023303912};\\\", \\\"{x:1617,y:436,t:1527023303921};\\\", \\\"{x:1617,y:441,t:1527023303932};\\\", \\\"{x:1617,y:447,t:1527023303949};\\\", \\\"{x:1617,y:453,t:1527023303965};\\\", \\\"{x:1617,y:463,t:1527023303982};\\\", \\\"{x:1617,y:473,t:1527023303998};\\\", \\\"{x:1617,y:482,t:1527023304015};\\\", \\\"{x:1620,y:496,t:1527023304032};\\\", \\\"{x:1620,y:503,t:1527023304048};\\\", \\\"{x:1621,y:510,t:1527023304065};\\\", \\\"{x:1623,y:520,t:1527023304082};\\\", \\\"{x:1623,y:526,t:1527023304099};\\\", \\\"{x:1623,y:533,t:1527023304115};\\\", \\\"{x:1623,y:537,t:1527023304132};\\\", \\\"{x:1623,y:543,t:1527023304149};\\\", \\\"{x:1624,y:550,t:1527023304166};\\\", \\\"{x:1624,y:556,t:1527023304182};\\\", \\\"{x:1624,y:564,t:1527023304199};\\\", \\\"{x:1624,y:570,t:1527023304215};\\\", \\\"{x:1625,y:580,t:1527023304231};\\\", \\\"{x:1625,y:584,t:1527023304248};\\\", \\\"{x:1625,y:587,t:1527023304264};\\\", \\\"{x:1625,y:592,t:1527023304282};\\\", \\\"{x:1625,y:597,t:1527023304298};\\\", \\\"{x:1625,y:601,t:1527023304315};\\\", \\\"{x:1625,y:606,t:1527023304332};\\\", \\\"{x:1625,y:608,t:1527023304349};\\\", \\\"{x:1625,y:609,t:1527023304365};\\\", \\\"{x:1625,y:611,t:1527023304382};\\\", \\\"{x:1625,y:612,t:1527023304398};\\\", \\\"{x:1625,y:617,t:1527023304415};\\\", \\\"{x:1623,y:623,t:1527023304432};\\\", \\\"{x:1623,y:627,t:1527023304449};\\\", \\\"{x:1623,y:629,t:1527023304465};\\\", \\\"{x:1623,y:630,t:1527023304482};\\\", \\\"{x:1622,y:632,t:1527023304499};\\\", \\\"{x:1622,y:633,t:1527023304515};\\\", \\\"{x:1622,y:635,t:1527023304532};\\\", \\\"{x:1621,y:638,t:1527023304548};\\\", \\\"{x:1620,y:639,t:1527023304566};\\\", \\\"{x:1619,y:641,t:1527023304582};\\\", \\\"{x:1619,y:643,t:1527023304599};\\\", \\\"{x:1619,y:644,t:1527023304617};\\\", \\\"{x:1619,y:645,t:1527023304632};\\\", \\\"{x:1619,y:646,t:1527023304649};\\\", \\\"{x:1619,y:647,t:1527023304666};\\\", \\\"{x:1619,y:646,t:1527023304832};\\\", \\\"{x:1617,y:645,t:1527023304849};\\\", \\\"{x:1617,y:641,t:1527023304866};\\\", \\\"{x:1617,y:637,t:1527023304883};\\\", \\\"{x:1617,y:629,t:1527023304899};\\\", \\\"{x:1617,y:618,t:1527023304916};\\\", \\\"{x:1617,y:605,t:1527023304932};\\\", \\\"{x:1615,y:586,t:1527023304949};\\\", \\\"{x:1611,y:571,t:1527023304966};\\\", \\\"{x:1610,y:553,t:1527023304983};\\\", \\\"{x:1609,y:534,t:1527023304999};\\\", \\\"{x:1609,y:518,t:1527023305015};\\\", \\\"{x:1609,y:512,t:1527023305033};\\\", \\\"{x:1609,y:510,t:1527023305048};\\\", \\\"{x:1609,y:508,t:1527023305066};\\\", \\\"{x:1609,y:505,t:1527023305215};\\\", \\\"{x:1609,y:500,t:1527023305233};\\\", \\\"{x:1609,y:494,t:1527023305249};\\\", \\\"{x:1609,y:488,t:1527023305266};\\\", \\\"{x:1609,y:479,t:1527023305283};\\\", \\\"{x:1609,y:471,t:1527023305299};\\\", \\\"{x:1611,y:462,t:1527023305316};\\\", \\\"{x:1611,y:460,t:1527023305333};\\\", \\\"{x:1611,y:457,t:1527023305349};\\\", \\\"{x:1611,y:456,t:1527023305365};\\\", \\\"{x:1612,y:453,t:1527023305383};\\\", \\\"{x:1612,y:451,t:1527023305400};\\\", \\\"{x:1612,y:449,t:1527023305416};\\\", \\\"{x:1612,y:447,t:1527023305519};\\\", \\\"{x:1612,y:445,t:1527023305533};\\\", \\\"{x:1613,y:443,t:1527023305550};\\\", \\\"{x:1613,y:441,t:1527023305566};\\\", \\\"{x:1613,y:439,t:1527023305582};\\\", \\\"{x:1613,y:434,t:1527023305600};\\\", \\\"{x:1613,y:433,t:1527023305616};\\\", \\\"{x:1613,y:432,t:1527023305632};\\\", \\\"{x:1614,y:432,t:1527023306824};\\\", \\\"{x:1615,y:434,t:1527023306834};\\\", \\\"{x:1616,y:442,t:1527023306852};\\\", \\\"{x:1616,y:450,t:1527023306867};\\\", \\\"{x:1616,y:457,t:1527023306884};\\\", \\\"{x:1616,y:462,t:1527023306902};\\\", \\\"{x:1616,y:467,t:1527023306918};\\\", \\\"{x:1616,y:473,t:1527023306934};\\\", \\\"{x:1616,y:477,t:1527023306952};\\\", \\\"{x:1616,y:480,t:1527023306967};\\\", \\\"{x:1616,y:484,t:1527023306984};\\\", \\\"{x:1616,y:487,t:1527023307001};\\\", \\\"{x:1616,y:489,t:1527023307018};\\\", \\\"{x:1616,y:491,t:1527023307034};\\\", \\\"{x:1616,y:492,t:1527023307051};\\\", \\\"{x:1616,y:496,t:1527023307068};\\\", \\\"{x:1617,y:499,t:1527023307085};\\\", \\\"{x:1617,y:502,t:1527023307101};\\\", \\\"{x:1617,y:506,t:1527023307117};\\\", \\\"{x:1618,y:511,t:1527023307135};\\\", \\\"{x:1619,y:515,t:1527023307151};\\\", \\\"{x:1619,y:518,t:1527023307168};\\\", \\\"{x:1620,y:523,t:1527023307184};\\\", \\\"{x:1620,y:525,t:1527023307201};\\\", \\\"{x:1620,y:532,t:1527023307219};\\\", \\\"{x:1620,y:538,t:1527023307233};\\\", \\\"{x:1620,y:544,t:1527023307251};\\\", \\\"{x:1620,y:549,t:1527023307267};\\\", \\\"{x:1620,y:554,t:1527023307284};\\\", \\\"{x:1619,y:558,t:1527023307301};\\\", \\\"{x:1619,y:562,t:1527023307318};\\\", \\\"{x:1619,y:567,t:1527023307333};\\\", \\\"{x:1617,y:576,t:1527023307351};\\\", \\\"{x:1615,y:586,t:1527023307367};\\\", \\\"{x:1614,y:590,t:1527023307384};\\\", \\\"{x:1614,y:595,t:1527023307401};\\\", \\\"{x:1613,y:599,t:1527023307418};\\\", \\\"{x:1611,y:604,t:1527023307434};\\\", \\\"{x:1609,y:609,t:1527023307451};\\\", \\\"{x:1609,y:613,t:1527023307467};\\\", \\\"{x:1607,y:618,t:1527023307484};\\\", \\\"{x:1606,y:621,t:1527023307501};\\\", \\\"{x:1606,y:622,t:1527023307518};\\\", \\\"{x:1606,y:627,t:1527023307534};\\\", \\\"{x:1606,y:632,t:1527023307551};\\\", \\\"{x:1606,y:636,t:1527023307569};\\\", \\\"{x:1605,y:639,t:1527023307584};\\\", \\\"{x:1605,y:640,t:1527023307601};\\\", \\\"{x:1605,y:643,t:1527023307618};\\\", \\\"{x:1605,y:645,t:1527023307635};\\\", \\\"{x:1605,y:648,t:1527023307652};\\\", \\\"{x:1605,y:652,t:1527023307668};\\\", \\\"{x:1605,y:656,t:1527023307685};\\\", \\\"{x:1605,y:658,t:1527023307702};\\\", \\\"{x:1605,y:663,t:1527023307719};\\\", \\\"{x:1605,y:665,t:1527023307736};\\\", \\\"{x:1605,y:666,t:1527023307752};\\\", \\\"{x:1605,y:670,t:1527023307768};\\\", \\\"{x:1605,y:674,t:1527023307785};\\\", \\\"{x:1605,y:679,t:1527023307801};\\\", \\\"{x:1606,y:683,t:1527023307819};\\\", \\\"{x:1606,y:687,t:1527023307835};\\\", \\\"{x:1606,y:689,t:1527023307852};\\\", \\\"{x:1608,y:700,t:1527023307868};\\\", \\\"{x:1608,y:716,t:1527023307885};\\\", \\\"{x:1609,y:727,t:1527023307901};\\\", \\\"{x:1611,y:734,t:1527023307919};\\\", \\\"{x:1611,y:738,t:1527023307935};\\\", \\\"{x:1611,y:743,t:1527023307951};\\\", \\\"{x:1611,y:762,t:1527023307968};\\\", \\\"{x:1612,y:781,t:1527023307986};\\\", \\\"{x:1612,y:799,t:1527023308002};\\\", \\\"{x:1612,y:809,t:1527023308018};\\\", \\\"{x:1612,y:812,t:1527023308036};\\\", \\\"{x:1612,y:816,t:1527023308052};\\\", \\\"{x:1612,y:818,t:1527023308068};\\\", \\\"{x:1613,y:822,t:1527023308086};\\\", \\\"{x:1613,y:826,t:1527023308102};\\\", \\\"{x:1613,y:831,t:1527023308119};\\\", \\\"{x:1612,y:836,t:1527023308135};\\\", \\\"{x:1611,y:843,t:1527023308152};\\\", \\\"{x:1611,y:846,t:1527023308169};\\\", \\\"{x:1611,y:848,t:1527023308186};\\\", \\\"{x:1611,y:849,t:1527023308202};\\\", \\\"{x:1611,y:852,t:1527023308219};\\\", \\\"{x:1611,y:854,t:1527023308236};\\\", \\\"{x:1611,y:858,t:1527023308252};\\\", \\\"{x:1611,y:863,t:1527023308268};\\\", \\\"{x:1611,y:871,t:1527023308285};\\\", \\\"{x:1611,y:874,t:1527023308303};\\\", \\\"{x:1611,y:876,t:1527023308318};\\\", \\\"{x:1610,y:878,t:1527023308336};\\\", \\\"{x:1610,y:883,t:1527023308352};\\\", \\\"{x:1611,y:889,t:1527023308368};\\\", \\\"{x:1613,y:897,t:1527023308385};\\\", \\\"{x:1613,y:905,t:1527023308402};\\\", \\\"{x:1613,y:906,t:1527023308419};\\\", \\\"{x:1613,y:908,t:1527023308435};\\\", \\\"{x:1615,y:912,t:1527023308452};\\\", \\\"{x:1615,y:914,t:1527023308469};\\\", \\\"{x:1616,y:916,t:1527023308485};\\\", \\\"{x:1616,y:920,t:1527023308503};\\\", \\\"{x:1618,y:924,t:1527023308519};\\\", \\\"{x:1619,y:933,t:1527023308536};\\\", \\\"{x:1619,y:941,t:1527023308552};\\\", \\\"{x:1619,y:946,t:1527023308569};\\\", \\\"{x:1619,y:948,t:1527023308585};\\\", \\\"{x:1619,y:949,t:1527023308602};\\\", \\\"{x:1619,y:951,t:1527023308619};\\\", \\\"{x:1619,y:954,t:1527023308636};\\\", \\\"{x:1619,y:956,t:1527023308652};\\\", \\\"{x:1620,y:960,t:1527023308669};\\\", \\\"{x:1622,y:962,t:1527023308685};\\\", \\\"{x:1622,y:957,t:1527023308760};\\\", \\\"{x:1622,y:946,t:1527023308770};\\\", \\\"{x:1622,y:919,t:1527023308786};\\\", \\\"{x:1623,y:890,t:1527023308802};\\\", \\\"{x:1625,y:860,t:1527023308820};\\\", \\\"{x:1626,y:838,t:1527023308835};\\\", \\\"{x:1630,y:822,t:1527023308852};\\\", \\\"{x:1634,y:811,t:1527023308869};\\\", \\\"{x:1636,y:803,t:1527023308886};\\\", \\\"{x:1639,y:789,t:1527023308903};\\\", \\\"{x:1644,y:765,t:1527023308920};\\\", \\\"{x:1649,y:739,t:1527023308936};\\\", \\\"{x:1653,y:722,t:1527023308952};\\\", \\\"{x:1654,y:721,t:1527023308969};\\\", \\\"{x:1655,y:719,t:1527023308992};\\\", \\\"{x:1655,y:718,t:1527023309008};\\\", \\\"{x:1655,y:717,t:1527023309020};\\\", \\\"{x:1655,y:716,t:1527023309036};\\\", \\\"{x:1655,y:715,t:1527023309056};\\\", \\\"{x:1655,y:713,t:1527023309360};\\\", \\\"{x:1655,y:703,t:1527023309369};\\\", \\\"{x:1655,y:681,t:1527023309386};\\\", \\\"{x:1655,y:631,t:1527023309402};\\\", \\\"{x:1655,y:586,t:1527023309419};\\\", \\\"{x:1660,y:563,t:1527023309437};\\\", \\\"{x:1662,y:554,t:1527023309453};\\\", \\\"{x:1663,y:549,t:1527023309470};\\\", \\\"{x:1664,y:545,t:1527023309487};\\\", \\\"{x:1667,y:542,t:1527023309504};\\\", \\\"{x:1667,y:538,t:1527023309519};\\\", \\\"{x:1668,y:537,t:1527023309537};\\\", \\\"{x:1668,y:535,t:1527023309553};\\\", \\\"{x:1668,y:534,t:1527023309569};\\\", \\\"{x:1670,y:533,t:1527023309586};\\\", \\\"{x:1671,y:533,t:1527023309751};\\\", \\\"{x:1674,y:533,t:1527023309759};\\\", \\\"{x:1675,y:534,t:1527023309769};\\\", \\\"{x:1678,y:539,t:1527023309786};\\\", \\\"{x:1679,y:541,t:1527023309803};\\\", \\\"{x:1682,y:544,t:1527023309819};\\\", \\\"{x:1683,y:545,t:1527023309836};\\\", \\\"{x:1683,y:547,t:1527023309853};\\\", \\\"{x:1684,y:547,t:1527023309880};\\\", \\\"{x:1684,y:548,t:1527023309887};\\\", \\\"{x:1685,y:548,t:1527023309903};\\\", \\\"{x:1685,y:550,t:1527023309920};\\\", \\\"{x:1687,y:552,t:1527023310040};\\\", \\\"{x:1688,y:554,t:1527023310054};\\\", \\\"{x:1688,y:555,t:1527023310072};\\\", \\\"{x:1688,y:557,t:1527023310144};\\\", \\\"{x:1689,y:557,t:1527023310168};\\\", \\\"{x:1688,y:557,t:1527023310424};\\\", \\\"{x:1684,y:554,t:1527023310437};\\\", \\\"{x:1675,y:545,t:1527023310453};\\\", \\\"{x:1663,y:535,t:1527023310470};\\\", \\\"{x:1651,y:526,t:1527023310487};\\\", \\\"{x:1630,y:511,t:1527023310503};\\\", \\\"{x:1611,y:496,t:1527023310520};\\\", \\\"{x:1593,y:487,t:1527023310537};\\\", \\\"{x:1575,y:478,t:1527023310553};\\\", \\\"{x:1552,y:474,t:1527023310569};\\\", \\\"{x:1519,y:471,t:1527023310587};\\\", \\\"{x:1463,y:478,t:1527023310603};\\\", \\\"{x:1412,y:494,t:1527023310620};\\\", \\\"{x:1343,y:513,t:1527023310637};\\\", \\\"{x:1255,y:532,t:1527023310653};\\\", \\\"{x:1182,y:547,t:1527023310670};\\\", \\\"{x:1131,y:556,t:1527023310687};\\\", \\\"{x:1060,y:579,t:1527023310704};\\\", \\\"{x:1050,y:584,t:1527023310721};\\\", \\\"{x:1040,y:584,t:1527023310737};\\\", \\\"{x:1013,y:585,t:1527023310754};\\\", \\\"{x:996,y:589,t:1527023310771};\\\", \\\"{x:973,y:588,t:1527023310787};\\\", \\\"{x:959,y:587,t:1527023310804};\\\", \\\"{x:944,y:586,t:1527023310824};\\\", \\\"{x:936,y:583,t:1527023310837};\\\", \\\"{x:930,y:581,t:1527023310854};\\\", \\\"{x:921,y:578,t:1527023310871};\\\", \\\"{x:913,y:576,t:1527023310887};\\\", \\\"{x:908,y:576,t:1527023310904};\\\", \\\"{x:904,y:575,t:1527023310921};\\\", \\\"{x:898,y:574,t:1527023310937};\\\", \\\"{x:894,y:573,t:1527023310954};\\\", \\\"{x:893,y:572,t:1527023310970};\\\", \\\"{x:892,y:572,t:1527023310987};\\\", \\\"{x:891,y:572,t:1527023311120};\\\", \\\"{x:888,y:572,t:1527023311137};\\\", \\\"{x:883,y:572,t:1527023311154};\\\", \\\"{x:878,y:572,t:1527023311170};\\\", \\\"{x:871,y:573,t:1527023311187};\\\", \\\"{x:862,y:576,t:1527023311204};\\\", \\\"{x:856,y:577,t:1527023311220};\\\", \\\"{x:854,y:577,t:1527023311238};\\\", \\\"{x:853,y:577,t:1527023311255};\\\", \\\"{x:852,y:578,t:1527023311528};\\\", \\\"{x:850,y:579,t:1527023311768};\\\", \\\"{x:849,y:580,t:1527023311784};\\\", \\\"{x:848,y:581,t:1527023311792};\\\", \\\"{x:847,y:582,t:1527023311807};\\\", \\\"{x:847,y:584,t:1527023311822};\\\", \\\"{x:846,y:586,t:1527023311839};\\\", \\\"{x:845,y:586,t:1527023311871};\\\", \\\"{x:845,y:587,t:1527023313279};\\\", \\\"{x:847,y:588,t:1527023313289};\\\", \\\"{x:880,y:590,t:1527023313306};\\\", \\\"{x:930,y:590,t:1527023313323};\\\", \\\"{x:1038,y:590,t:1527023313337};\\\", \\\"{x:1222,y:552,t:1527023313354};\\\", \\\"{x:1426,y:496,t:1527023313373};\\\", \\\"{x:1608,y:449,t:1527023313389};\\\", \\\"{x:1707,y:419,t:1527023313406};\\\", \\\"{x:1771,y:403,t:1527023313423};\\\", \\\"{x:1783,y:398,t:1527023313440};\\\", \\\"{x:1786,y:397,t:1527023313456};\\\", \\\"{x:1786,y:396,t:1527023313495};\\\", \\\"{x:1783,y:396,t:1527023313506};\\\", \\\"{x:1779,y:394,t:1527023313523};\\\", \\\"{x:1778,y:394,t:1527023313541};\\\", \\\"{x:1776,y:393,t:1527023313557};\\\", \\\"{x:1773,y:389,t:1527023313574};\\\", \\\"{x:1768,y:384,t:1527023313590};\\\", \\\"{x:1756,y:376,t:1527023313607};\\\", \\\"{x:1731,y:367,t:1527023313624};\\\", \\\"{x:1717,y:365,t:1527023313639};\\\", \\\"{x:1702,y:364,t:1527023313657};\\\", \\\"{x:1691,y:364,t:1527023313674};\\\", \\\"{x:1680,y:369,t:1527023313691};\\\", \\\"{x:1671,y:377,t:1527023313706};\\\", \\\"{x:1666,y:385,t:1527023313723};\\\", \\\"{x:1663,y:392,t:1527023313741};\\\", \\\"{x:1662,y:396,t:1527023313757};\\\", \\\"{x:1661,y:401,t:1527023313773};\\\", \\\"{x:1660,y:407,t:1527023313791};\\\", \\\"{x:1659,y:417,t:1527023313808};\\\", \\\"{x:1658,y:420,t:1527023313824};\\\", \\\"{x:1658,y:422,t:1527023313840};\\\", \\\"{x:1658,y:423,t:1527023313857};\\\", \\\"{x:1657,y:423,t:1527023313960};\\\", \\\"{x:1657,y:424,t:1527023313974};\\\", \\\"{x:1656,y:424,t:1527023313991};\\\", \\\"{x:1651,y:428,t:1527023314009};\\\", \\\"{x:1646,y:431,t:1527023314024};\\\", \\\"{x:1622,y:450,t:1527023314040};\\\", \\\"{x:1610,y:459,t:1527023314057};\\\", \\\"{x:1602,y:465,t:1527023314074};\\\", \\\"{x:1598,y:468,t:1527023314091};\\\", \\\"{x:1595,y:472,t:1527023314107};\\\", \\\"{x:1591,y:479,t:1527023314124};\\\", \\\"{x:1581,y:492,t:1527023314141};\\\", \\\"{x:1567,y:510,t:1527023314158};\\\", \\\"{x:1552,y:530,t:1527023314173};\\\", \\\"{x:1535,y:550,t:1527023314190};\\\", \\\"{x:1513,y:574,t:1527023314208};\\\", \\\"{x:1501,y:586,t:1527023314223};\\\", \\\"{x:1494,y:597,t:1527023314241};\\\", \\\"{x:1485,y:608,t:1527023314258};\\\", \\\"{x:1480,y:619,t:1527023314274};\\\", \\\"{x:1475,y:632,t:1527023314291};\\\", \\\"{x:1471,y:639,t:1527023314308};\\\", \\\"{x:1470,y:641,t:1527023314324};\\\", \\\"{x:1469,y:642,t:1527023314341};\\\", \\\"{x:1469,y:644,t:1527023314384};\\\", \\\"{x:1471,y:645,t:1527023314392};\\\", \\\"{x:1475,y:647,t:1527023314408};\\\", \\\"{x:1479,y:649,t:1527023314423};\\\", \\\"{x:1483,y:649,t:1527023314440};\\\", \\\"{x:1492,y:649,t:1527023314458};\\\", \\\"{x:1495,y:650,t:1527023314475};\\\", \\\"{x:1496,y:650,t:1527023314491};\\\", \\\"{x:1497,y:650,t:1527023314712};\\\", \\\"{x:1498,y:650,t:1527023314728};\\\", \\\"{x:1498,y:649,t:1527023314744};\\\", \\\"{x:1500,y:648,t:1527023314758};\\\", \\\"{x:1500,y:647,t:1527023314774};\\\", \\\"{x:1502,y:647,t:1527023314791};\\\", \\\"{x:1502,y:646,t:1527023314810};\\\", \\\"{x:1502,y:645,t:1527023314840};\\\", \\\"{x:1503,y:644,t:1527023314864};\\\", \\\"{x:1503,y:643,t:1527023314968};\\\", \\\"{x:1504,y:642,t:1527023315009};\\\", \\\"{x:1505,y:641,t:1527023315025};\\\", \\\"{x:1505,y:640,t:1527023315192};\\\", \\\"{x:1499,y:642,t:1527023315208};\\\", \\\"{x:1471,y:644,t:1527023315225};\\\", \\\"{x:1420,y:644,t:1527023315241};\\\", \\\"{x:1314,y:646,t:1527023315258};\\\", \\\"{x:1178,y:646,t:1527023315275};\\\", \\\"{x:1037,y:646,t:1527023315292};\\\", \\\"{x:915,y:646,t:1527023315309};\\\", \\\"{x:827,y:646,t:1527023315325};\\\", \\\"{x:774,y:646,t:1527023315341};\\\", \\\"{x:753,y:646,t:1527023315359};\\\", \\\"{x:750,y:646,t:1527023315374};\\\", \\\"{x:749,y:646,t:1527023315544};\\\", \\\"{x:745,y:644,t:1527023315559};\\\", \\\"{x:736,y:640,t:1527023315574};\\\", \\\"{x:716,y:634,t:1527023315593};\\\", \\\"{x:702,y:630,t:1527023315608};\\\", \\\"{x:687,y:625,t:1527023315624};\\\", \\\"{x:677,y:623,t:1527023315641};\\\", \\\"{x:668,y:622,t:1527023315658};\\\", \\\"{x:660,y:620,t:1527023315675};\\\", \\\"{x:652,y:620,t:1527023315691};\\\", \\\"{x:647,y:620,t:1527023315708};\\\", \\\"{x:641,y:620,t:1527023315725};\\\", \\\"{x:636,y:620,t:1527023315742};\\\", \\\"{x:626,y:620,t:1527023315758};\\\", \\\"{x:601,y:622,t:1527023315775};\\\", \\\"{x:580,y:626,t:1527023315791};\\\", \\\"{x:562,y:627,t:1527023315808};\\\", \\\"{x:551,y:627,t:1527023315825};\\\", \\\"{x:540,y:627,t:1527023315842};\\\", \\\"{x:530,y:627,t:1527023315859};\\\", \\\"{x:515,y:625,t:1527023315875};\\\", \\\"{x:500,y:621,t:1527023315892};\\\", \\\"{x:485,y:617,t:1527023315910};\\\", \\\"{x:469,y:609,t:1527023315925};\\\", \\\"{x:453,y:603,t:1527023315943};\\\", \\\"{x:438,y:597,t:1527023315958};\\\", \\\"{x:430,y:590,t:1527023315975};\\\", \\\"{x:429,y:589,t:1527023315992};\\\", \\\"{x:426,y:589,t:1527023316032};\\\", \\\"{x:425,y:589,t:1527023316042};\\\", \\\"{x:419,y:589,t:1527023316058};\\\", \\\"{x:409,y:589,t:1527023316076};\\\", \\\"{x:401,y:589,t:1527023316092};\\\", \\\"{x:395,y:589,t:1527023316108};\\\", \\\"{x:393,y:589,t:1527023316125};\\\", \\\"{x:392,y:589,t:1527023316142};\\\", \\\"{x:390,y:590,t:1527023316160};\\\", \\\"{x:388,y:590,t:1527023316175};\\\", \\\"{x:388,y:591,t:1527023316192};\\\", \\\"{x:387,y:591,t:1527023316216};\\\", \\\"{x:386,y:592,t:1527023316240};\\\", \\\"{x:389,y:597,t:1527023316439};\\\", \\\"{x:401,y:614,t:1527023316448};\\\", \\\"{x:414,y:639,t:1527023316460};\\\", \\\"{x:439,y:675,t:1527023316476};\\\", \\\"{x:463,y:712,t:1527023316493};\\\", \\\"{x:481,y:734,t:1527023316509};\\\", \\\"{x:497,y:755,t:1527023316526};\\\", \\\"{x:507,y:766,t:1527023316542};\\\", \\\"{x:512,y:772,t:1527023316559};\\\", \\\"{x:512,y:773,t:1527023316575};\\\", \\\"{x:512,y:771,t:1527023316704};\\\", \\\"{x:512,y:768,t:1527023316712};\\\", \\\"{x:511,y:764,t:1527023316726};\\\", \\\"{x:507,y:752,t:1527023316743};\\\", \\\"{x:504,y:743,t:1527023316760};\\\", \\\"{x:504,y:740,t:1527023316777};\\\", \\\"{x:504,y:738,t:1527023316794};\\\", \\\"{x:504,y:737,t:1527023316815};\\\", \\\"{x:504,y:736,t:1527023316827};\\\", \\\"{x:504,y:734,t:1527023316845};\\\", \\\"{x:504,y:733,t:1527023316860};\\\", \\\"{x:504,y:732,t:1527023316876};\\\", \\\"{x:504,y:731,t:1527023316892};\\\", \\\"{x:504,y:730,t:1527023316909};\\\", \\\"{x:504,y:729,t:1527023316926};\\\", \\\"{x:504,y:728,t:1527023316951};\\\", \\\"{x:504,y:727,t:1527023316967};\\\", \\\"{x:508,y:727,t:1527023318328};\\\" ] }, { \\\"rt\\\": 28029, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 367824, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -C -09 AM-11 AM-C -C -O -09 AM-11 AM-12 PM-12 PM-O -O -C -C -11 AM-F -F -C -11 AM-11 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:990,y:881,t:1527023318451};\\\", \\\"{x:1033,y:901,t:1527023318461};\\\", \\\"{x:1116,y:937,t:1527023318477};\\\", \\\"{x:1179,y:964,t:1527023318494};\\\", \\\"{x:1233,y:983,t:1527023318510};\\\", \\\"{x:1290,y:1001,t:1527023318543};\\\", \\\"{x:1304,y:1006,t:1527023318560};\\\", \\\"{x:1316,y:1011,t:1527023318577};\\\", \\\"{x:1331,y:1016,t:1527023318594};\\\", \\\"{x:1342,y:1019,t:1527023318610};\\\", \\\"{x:1349,y:1019,t:1527023318627};\\\", \\\"{x:1354,y:1020,t:1527023318644};\\\", \\\"{x:1357,y:1021,t:1527023318660};\\\", \\\"{x:1358,y:1021,t:1527023319928};\\\", \\\"{x:1360,y:1004,t:1527023319945};\\\", \\\"{x:1367,y:1000,t:1527023319962};\\\", \\\"{x:1368,y:999,t:1527023319979};\\\", \\\"{x:1367,y:999,t:1527023320832};\\\", \\\"{x:1366,y:999,t:1527023320846};\\\", \\\"{x:1365,y:998,t:1527023320863};\\\", \\\"{x:1362,y:998,t:1527023320879};\\\", \\\"{x:1362,y:997,t:1527023320896};\\\", \\\"{x:1360,y:996,t:1527023320913};\\\", \\\"{x:1359,y:996,t:1527023320936};\\\", \\\"{x:1357,y:996,t:1527023320951};\\\", \\\"{x:1356,y:996,t:1527023320968};\\\", \\\"{x:1354,y:995,t:1527023320980};\\\", \\\"{x:1352,y:995,t:1527023320996};\\\", \\\"{x:1349,y:995,t:1527023321012};\\\", \\\"{x:1344,y:995,t:1527023321030};\\\", \\\"{x:1341,y:995,t:1527023321046};\\\", \\\"{x:1336,y:995,t:1527023321062};\\\", \\\"{x:1329,y:993,t:1527023321079};\\\", \\\"{x:1325,y:993,t:1527023321096};\\\", \\\"{x:1320,y:991,t:1527023321113};\\\", \\\"{x:1312,y:989,t:1527023321130};\\\", \\\"{x:1302,y:986,t:1527023321146};\\\", \\\"{x:1293,y:982,t:1527023321163};\\\", \\\"{x:1282,y:978,t:1527023321179};\\\", \\\"{x:1271,y:973,t:1527023321196};\\\", \\\"{x:1259,y:968,t:1527023321213};\\\", \\\"{x:1252,y:961,t:1527023321229};\\\", \\\"{x:1248,y:958,t:1527023321245};\\\", \\\"{x:1245,y:953,t:1527023321263};\\\", \\\"{x:1240,y:932,t:1527023321279};\\\", \\\"{x:1238,y:897,t:1527023321295};\\\", \\\"{x:1237,y:867,t:1527023321312};\\\", \\\"{x:1237,y:838,t:1527023321329};\\\", \\\"{x:1237,y:807,t:1527023321345};\\\", \\\"{x:1241,y:768,t:1527023321362};\\\", \\\"{x:1248,y:728,t:1527023321380};\\\", \\\"{x:1257,y:689,t:1527023321395};\\\", \\\"{x:1266,y:655,t:1527023321413};\\\", \\\"{x:1273,y:630,t:1527023321430};\\\", \\\"{x:1281,y:608,t:1527023321446};\\\", \\\"{x:1286,y:593,t:1527023321463};\\\", \\\"{x:1293,y:579,t:1527023321480};\\\", \\\"{x:1294,y:575,t:1527023321496};\\\", \\\"{x:1296,y:572,t:1527023321513};\\\", \\\"{x:1296,y:571,t:1527023321530};\\\", \\\"{x:1296,y:570,t:1527023321547};\\\", \\\"{x:1297,y:569,t:1527023321563};\\\", \\\"{x:1299,y:568,t:1527023321975};\\\", \\\"{x:1303,y:566,t:1527023321982};\\\", \\\"{x:1307,y:564,t:1527023321996};\\\", \\\"{x:1315,y:560,t:1527023322014};\\\", \\\"{x:1319,y:559,t:1527023322029};\\\", \\\"{x:1323,y:556,t:1527023322046};\\\", \\\"{x:1328,y:552,t:1527023322063};\\\", \\\"{x:1329,y:551,t:1527023322087};\\\", \\\"{x:1330,y:549,t:1527023322143};\\\", \\\"{x:1331,y:549,t:1527023322159};\\\", \\\"{x:1331,y:548,t:1527023322167};\\\", \\\"{x:1332,y:547,t:1527023322192};\\\", \\\"{x:1333,y:547,t:1527023322199};\\\", \\\"{x:1333,y:546,t:1527023322213};\\\", \\\"{x:1334,y:545,t:1527023322230};\\\", \\\"{x:1335,y:542,t:1527023322246};\\\", \\\"{x:1335,y:540,t:1527023322263};\\\", \\\"{x:1335,y:537,t:1527023322280};\\\", \\\"{x:1335,y:535,t:1527023322297};\\\", \\\"{x:1335,y:531,t:1527023322313};\\\", \\\"{x:1335,y:526,t:1527023322330};\\\", \\\"{x:1337,y:519,t:1527023322347};\\\", \\\"{x:1338,y:514,t:1527023322364};\\\", \\\"{x:1339,y:510,t:1527023322381};\\\", \\\"{x:1339,y:508,t:1527023322400};\\\", \\\"{x:1338,y:508,t:1527023322472};\\\", \\\"{x:1335,y:510,t:1527023322488};\\\", \\\"{x:1330,y:515,t:1527023322497};\\\", \\\"{x:1324,y:526,t:1527023322514};\\\", \\\"{x:1314,y:543,t:1527023322531};\\\", \\\"{x:1303,y:561,t:1527023322547};\\\", \\\"{x:1292,y:576,t:1527023322565};\\\", \\\"{x:1286,y:589,t:1527023322581};\\\", \\\"{x:1280,y:601,t:1527023322596};\\\", \\\"{x:1275,y:617,t:1527023322613};\\\", \\\"{x:1271,y:630,t:1527023322630};\\\", \\\"{x:1269,y:639,t:1527023322646};\\\", \\\"{x:1267,y:656,t:1527023322663};\\\", \\\"{x:1267,y:666,t:1527023322680};\\\", \\\"{x:1266,y:671,t:1527023322696};\\\", \\\"{x:1266,y:676,t:1527023322713};\\\", \\\"{x:1267,y:684,t:1527023322731};\\\", \\\"{x:1272,y:693,t:1527023322746};\\\", \\\"{x:1282,y:712,t:1527023322763};\\\", \\\"{x:1291,y:733,t:1527023322781};\\\", \\\"{x:1299,y:746,t:1527023322797};\\\", \\\"{x:1307,y:755,t:1527023322813};\\\", \\\"{x:1318,y:762,t:1527023322832};\\\", \\\"{x:1323,y:767,t:1527023322847};\\\", \\\"{x:1326,y:770,t:1527023322864};\\\", \\\"{x:1328,y:771,t:1527023322881};\\\", \\\"{x:1329,y:773,t:1527023322898};\\\", \\\"{x:1329,y:774,t:1527023322936};\\\", \\\"{x:1330,y:776,t:1527023322951};\\\", \\\"{x:1331,y:778,t:1527023322964};\\\", \\\"{x:1332,y:780,t:1527023322981};\\\", \\\"{x:1334,y:781,t:1527023322998};\\\", \\\"{x:1336,y:784,t:1527023323014};\\\", \\\"{x:1336,y:786,t:1527023323031};\\\", \\\"{x:1336,y:791,t:1527023323048};\\\", \\\"{x:1336,y:792,t:1527023323305};\\\", \\\"{x:1336,y:793,t:1527023323400};\\\", \\\"{x:1330,y:793,t:1527023323415};\\\", \\\"{x:1317,y:793,t:1527023323431};\\\", \\\"{x:1295,y:793,t:1527023323448};\\\", \\\"{x:1289,y:793,t:1527023323465};\\\", \\\"{x:1287,y:793,t:1527023323481};\\\", \\\"{x:1285,y:793,t:1527023323576};\\\", \\\"{x:1284,y:794,t:1527023323592};\\\", \\\"{x:1283,y:795,t:1527023323600};\\\", \\\"{x:1279,y:796,t:1527023323615};\\\", \\\"{x:1275,y:799,t:1527023323631};\\\", \\\"{x:1266,y:804,t:1527023323647};\\\", \\\"{x:1263,y:804,t:1527023323665};\\\", \\\"{x:1262,y:804,t:1527023323712};\\\", \\\"{x:1259,y:806,t:1527023323728};\\\", \\\"{x:1258,y:806,t:1527023323735};\\\", \\\"{x:1254,y:809,t:1527023323748};\\\", \\\"{x:1245,y:813,t:1527023323764};\\\", \\\"{x:1236,y:819,t:1527023323781};\\\", \\\"{x:1232,y:820,t:1527023323798};\\\", \\\"{x:1231,y:820,t:1527023323815};\\\", \\\"{x:1229,y:821,t:1527023323832};\\\", \\\"{x:1227,y:821,t:1527023323928};\\\", \\\"{x:1226,y:823,t:1527023323936};\\\", \\\"{x:1225,y:823,t:1527023323948};\\\", \\\"{x:1223,y:825,t:1527023323965};\\\", \\\"{x:1222,y:826,t:1527023323982};\\\", \\\"{x:1221,y:826,t:1527023323998};\\\", \\\"{x:1220,y:826,t:1527023324097};\\\", \\\"{x:1219,y:826,t:1527023324112};\\\", \\\"{x:1219,y:827,t:1527023324368};\\\", \\\"{x:1219,y:831,t:1527023324382};\\\", \\\"{x:1228,y:839,t:1527023324400};\\\", \\\"{x:1233,y:847,t:1527023324415};\\\", \\\"{x:1240,y:859,t:1527023324432};\\\", \\\"{x:1243,y:869,t:1527023324449};\\\", \\\"{x:1246,y:877,t:1527023324465};\\\", \\\"{x:1249,y:885,t:1527023324482};\\\", \\\"{x:1252,y:892,t:1527023324499};\\\", \\\"{x:1253,y:898,t:1527023324515};\\\", \\\"{x:1254,y:905,t:1527023324533};\\\", \\\"{x:1257,y:911,t:1527023324549};\\\", \\\"{x:1260,y:916,t:1527023324565};\\\", \\\"{x:1261,y:916,t:1527023324592};\\\", \\\"{x:1261,y:917,t:1527023324600};\\\", \\\"{x:1263,y:921,t:1527023324615};\\\", \\\"{x:1265,y:925,t:1527023324632};\\\", \\\"{x:1274,y:939,t:1527023324650};\\\", \\\"{x:1278,y:947,t:1527023324665};\\\", \\\"{x:1280,y:949,t:1527023324682};\\\", \\\"{x:1281,y:953,t:1527023324699};\\\", \\\"{x:1282,y:954,t:1527023324715};\\\", \\\"{x:1283,y:955,t:1527023324733};\\\", \\\"{x:1283,y:957,t:1527023324749};\\\", \\\"{x:1284,y:959,t:1527023324766};\\\", \\\"{x:1284,y:960,t:1527023324783};\\\", \\\"{x:1285,y:962,t:1527023324799};\\\", \\\"{x:1285,y:964,t:1527023324816};\\\", \\\"{x:1285,y:965,t:1527023324840};\\\", \\\"{x:1286,y:965,t:1527023324872};\\\", \\\"{x:1286,y:966,t:1527023324882};\\\", \\\"{x:1285,y:967,t:1527023327049};\\\", \\\"{x:1281,y:963,t:1527023327056};\\\", \\\"{x:1279,y:960,t:1527023327067};\\\", \\\"{x:1273,y:951,t:1527023327085};\\\", \\\"{x:1265,y:940,t:1527023327100};\\\", \\\"{x:1257,y:927,t:1527023327117};\\\", \\\"{x:1248,y:912,t:1527023327135};\\\", \\\"{x:1242,y:888,t:1527023327151};\\\", \\\"{x:1228,y:840,t:1527023327167};\\\", \\\"{x:1204,y:762,t:1527023327183};\\\", \\\"{x:1191,y:744,t:1527023327202};\\\", \\\"{x:1183,y:732,t:1527023327218};\\\", \\\"{x:1182,y:731,t:1527023327234};\\\", \\\"{x:1180,y:730,t:1527023327252};\\\", \\\"{x:1179,y:730,t:1527023327313};\\\", \\\"{x:1173,y:738,t:1527023327320};\\\", \\\"{x:1167,y:756,t:1527023327335};\\\", \\\"{x:1142,y:840,t:1527023327352};\\\", \\\"{x:1130,y:871,t:1527023327368};\\\", \\\"{x:1120,y:950,t:1527023327383};\\\", \\\"{x:1120,y:982,t:1527023327401};\\\", \\\"{x:1120,y:1003,t:1527023327418};\\\", \\\"{x:1123,y:1016,t:1527023327434};\\\", \\\"{x:1126,y:1020,t:1527023327452};\\\", \\\"{x:1126,y:1021,t:1527023327504};\\\", \\\"{x:1130,y:1020,t:1527023327517};\\\", \\\"{x:1139,y:1001,t:1527023327534};\\\", \\\"{x:1153,y:971,t:1527023327552};\\\", \\\"{x:1171,y:932,t:1527023327568};\\\", \\\"{x:1196,y:889,t:1527023327585};\\\", \\\"{x:1205,y:875,t:1527023327601};\\\", \\\"{x:1209,y:867,t:1527023327617};\\\", \\\"{x:1210,y:866,t:1527023327634};\\\", \\\"{x:1210,y:863,t:1527023327652};\\\", \\\"{x:1210,y:862,t:1527023327668};\\\", \\\"{x:1210,y:861,t:1527023327685};\\\", \\\"{x:1212,y:864,t:1527023327744};\\\", \\\"{x:1220,y:876,t:1527023327752};\\\", \\\"{x:1240,y:903,t:1527023327768};\\\", \\\"{x:1256,y:931,t:1527023327784};\\\", \\\"{x:1272,y:952,t:1527023327801};\\\", \\\"{x:1279,y:964,t:1527023327818};\\\", \\\"{x:1283,y:970,t:1527023327835};\\\", \\\"{x:1287,y:973,t:1527023327851};\\\", \\\"{x:1286,y:968,t:1527023327960};\\\", \\\"{x:1284,y:964,t:1527023327969};\\\", \\\"{x:1277,y:945,t:1527023327984};\\\", \\\"{x:1259,y:911,t:1527023328002};\\\", \\\"{x:1239,y:869,t:1527023328019};\\\", \\\"{x:1209,y:831,t:1527023328035};\\\", \\\"{x:1199,y:819,t:1527023328052};\\\", \\\"{x:1198,y:814,t:1527023328068};\\\", \\\"{x:1196,y:810,t:1527023328084};\\\", \\\"{x:1193,y:803,t:1527023328102};\\\", \\\"{x:1192,y:798,t:1527023328119};\\\", \\\"{x:1190,y:795,t:1527023328136};\\\", \\\"{x:1190,y:794,t:1527023328174};\\\", \\\"{x:1189,y:794,t:1527023328185};\\\", \\\"{x:1183,y:796,t:1527023328201};\\\", \\\"{x:1172,y:812,t:1527023328218};\\\", \\\"{x:1162,y:838,t:1527023328235};\\\", \\\"{x:1156,y:863,t:1527023328251};\\\", \\\"{x:1149,y:884,t:1527023328268};\\\", \\\"{x:1148,y:899,t:1527023328285};\\\", \\\"{x:1146,y:907,t:1527023328300};\\\", \\\"{x:1146,y:909,t:1527023328318};\\\", \\\"{x:1146,y:911,t:1527023328335};\\\", \\\"{x:1148,y:907,t:1527023328415};\\\", \\\"{x:1153,y:900,t:1527023328423};\\\", \\\"{x:1162,y:889,t:1527023328435};\\\", \\\"{x:1175,y:869,t:1527023328451};\\\", \\\"{x:1192,y:845,t:1527023328468};\\\", \\\"{x:1208,y:830,t:1527023328485};\\\", \\\"{x:1216,y:822,t:1527023328501};\\\", \\\"{x:1220,y:821,t:1527023328519};\\\", \\\"{x:1221,y:819,t:1527023328536};\\\", \\\"{x:1225,y:814,t:1527023328729};\\\", \\\"{x:1226,y:809,t:1527023328736};\\\", \\\"{x:1229,y:798,t:1527023328752};\\\", \\\"{x:1232,y:774,t:1527023328769};\\\", \\\"{x:1237,y:734,t:1527023328785};\\\", \\\"{x:1244,y:689,t:1527023328802};\\\", \\\"{x:1248,y:665,t:1527023328819};\\\", \\\"{x:1254,y:651,t:1527023328836};\\\", \\\"{x:1255,y:645,t:1527023328853};\\\", \\\"{x:1256,y:641,t:1527023328869};\\\", \\\"{x:1256,y:640,t:1527023328885};\\\", \\\"{x:1256,y:639,t:1527023328902};\\\", \\\"{x:1257,y:637,t:1527023328919};\\\", \\\"{x:1257,y:636,t:1527023328935};\\\", \\\"{x:1258,y:633,t:1527023328952};\\\", \\\"{x:1259,y:630,t:1527023328968};\\\", \\\"{x:1259,y:627,t:1527023328986};\\\", \\\"{x:1259,y:625,t:1527023329002};\\\", \\\"{x:1258,y:625,t:1527023329560};\\\", \\\"{x:1256,y:625,t:1527023329576};\\\", \\\"{x:1255,y:625,t:1527023329586};\\\", \\\"{x:1254,y:625,t:1527023329602};\\\", \\\"{x:1252,y:625,t:1527023329619};\\\", \\\"{x:1252,y:627,t:1527023330335};\\\", \\\"{x:1248,y:631,t:1527023330353};\\\", \\\"{x:1247,y:633,t:1527023330369};\\\", \\\"{x:1247,y:635,t:1527023330386};\\\", \\\"{x:1245,y:636,t:1527023330405};\\\", \\\"{x:1245,y:638,t:1527023330420};\\\", \\\"{x:1244,y:640,t:1527023330436};\\\", \\\"{x:1241,y:646,t:1527023330453};\\\", \\\"{x:1236,y:656,t:1527023330470};\\\", \\\"{x:1229,y:676,t:1527023330486};\\\", \\\"{x:1220,y:699,t:1527023330503};\\\", \\\"{x:1213,y:714,t:1527023330520};\\\", \\\"{x:1209,y:730,t:1527023330537};\\\", \\\"{x:1201,y:752,t:1527023330553};\\\", \\\"{x:1189,y:781,t:1527023330570};\\\", \\\"{x:1174,y:813,t:1527023330586};\\\", \\\"{x:1157,y:849,t:1527023330604};\\\", \\\"{x:1145,y:880,t:1527023330621};\\\", \\\"{x:1134,y:899,t:1527023330637};\\\", \\\"{x:1127,y:915,t:1527023330653};\\\", \\\"{x:1124,y:929,t:1527023330670};\\\", \\\"{x:1123,y:938,t:1527023330686};\\\", \\\"{x:1123,y:948,t:1527023330704};\\\", \\\"{x:1123,y:953,t:1527023330720};\\\", \\\"{x:1123,y:958,t:1527023330736};\\\", \\\"{x:1123,y:963,t:1527023330754};\\\", \\\"{x:1121,y:968,t:1527023330770};\\\", \\\"{x:1121,y:969,t:1527023330787};\\\", \\\"{x:1121,y:970,t:1527023330803};\\\", \\\"{x:1121,y:971,t:1527023330820};\\\", \\\"{x:1122,y:972,t:1527023330837};\\\", \\\"{x:1123,y:972,t:1527023330854};\\\", \\\"{x:1124,y:972,t:1527023330871};\\\", \\\"{x:1127,y:974,t:1527023330886};\\\", \\\"{x:1131,y:974,t:1527023330904};\\\", \\\"{x:1135,y:973,t:1527023330919};\\\", \\\"{x:1139,y:970,t:1527023330936};\\\", \\\"{x:1142,y:970,t:1527023330953};\\\", \\\"{x:1145,y:969,t:1527023330970};\\\", \\\"{x:1147,y:968,t:1527023331001};\\\", \\\"{x:1148,y:967,t:1527023331016};\\\", \\\"{x:1149,y:966,t:1527023331032};\\\", \\\"{x:1150,y:965,t:1527023331056};\\\", \\\"{x:1152,y:965,t:1527023331144};\\\", \\\"{x:1155,y:965,t:1527023331153};\\\", \\\"{x:1162,y:965,t:1527023331170};\\\", \\\"{x:1168,y:968,t:1527023331187};\\\", \\\"{x:1174,y:969,t:1527023331202};\\\", \\\"{x:1179,y:970,t:1527023331220};\\\", \\\"{x:1186,y:970,t:1527023331237};\\\", \\\"{x:1189,y:970,t:1527023331253};\\\", \\\"{x:1191,y:969,t:1527023331288};\\\", \\\"{x:1193,y:968,t:1527023331303};\\\", \\\"{x:1194,y:967,t:1527023331320};\\\", \\\"{x:1195,y:966,t:1527023331336};\\\", \\\"{x:1196,y:966,t:1527023331584};\\\", \\\"{x:1199,y:966,t:1527023331591};\\\", \\\"{x:1201,y:966,t:1527023331604};\\\", \\\"{x:1208,y:966,t:1527023331621};\\\", \\\"{x:1219,y:966,t:1527023331637};\\\", \\\"{x:1227,y:967,t:1527023331654};\\\", \\\"{x:1236,y:967,t:1527023331670};\\\", \\\"{x:1247,y:967,t:1527023331687};\\\", \\\"{x:1252,y:965,t:1527023331704};\\\", \\\"{x:1255,y:963,t:1527023331720};\\\", \\\"{x:1256,y:962,t:1527023331738};\\\", \\\"{x:1256,y:961,t:1527023331755};\\\", \\\"{x:1258,y:958,t:1527023331770};\\\", \\\"{x:1258,y:956,t:1527023331787};\\\", \\\"{x:1258,y:955,t:1527023331805};\\\", \\\"{x:1259,y:953,t:1527023331820};\\\", \\\"{x:1259,y:952,t:1527023331856};\\\", \\\"{x:1260,y:952,t:1527023331888};\\\", \\\"{x:1260,y:951,t:1527023331912};\\\", \\\"{x:1261,y:951,t:1527023331921};\\\", \\\"{x:1262,y:952,t:1527023332128};\\\", \\\"{x:1265,y:954,t:1527023332137};\\\", \\\"{x:1272,y:958,t:1527023332154};\\\", \\\"{x:1280,y:964,t:1527023332171};\\\", \\\"{x:1291,y:971,t:1527023332187};\\\", \\\"{x:1302,y:977,t:1527023332204};\\\", \\\"{x:1307,y:978,t:1527023332221};\\\", \\\"{x:1309,y:979,t:1527023332237};\\\", \\\"{x:1309,y:980,t:1527023332271};\\\", \\\"{x:1311,y:980,t:1527023332312};\\\", \\\"{x:1312,y:980,t:1527023332321};\\\", \\\"{x:1315,y:979,t:1527023332337};\\\", \\\"{x:1319,y:977,t:1527023332354};\\\", \\\"{x:1324,y:975,t:1527023332371};\\\", \\\"{x:1326,y:973,t:1527023332387};\\\", \\\"{x:1328,y:972,t:1527023332405};\\\", \\\"{x:1330,y:972,t:1527023332421};\\\", \\\"{x:1331,y:969,t:1527023332438};\\\", \\\"{x:1332,y:967,t:1527023332455};\\\", \\\"{x:1333,y:964,t:1527023332472};\\\", \\\"{x:1334,y:963,t:1527023332488};\\\", \\\"{x:1335,y:962,t:1527023332505};\\\", \\\"{x:1336,y:962,t:1527023332672};\\\", \\\"{x:1340,y:965,t:1527023332688};\\\", \\\"{x:1346,y:968,t:1527023332705};\\\", \\\"{x:1351,y:970,t:1527023332721};\\\", \\\"{x:1360,y:972,t:1527023332739};\\\", \\\"{x:1369,y:972,t:1527023332755};\\\", \\\"{x:1376,y:972,t:1527023332772};\\\", \\\"{x:1380,y:972,t:1527023332788};\\\", \\\"{x:1384,y:972,t:1527023332804};\\\", \\\"{x:1388,y:971,t:1527023332821};\\\", \\\"{x:1390,y:970,t:1527023332839};\\\", \\\"{x:1391,y:969,t:1527023332855};\\\", \\\"{x:1393,y:967,t:1527023332872};\\\", \\\"{x:1393,y:965,t:1527023332888};\\\", \\\"{x:1394,y:962,t:1527023332905};\\\", \\\"{x:1396,y:960,t:1527023332922};\\\", \\\"{x:1397,y:958,t:1527023332938};\\\", \\\"{x:1398,y:957,t:1527023332968};\\\", \\\"{x:1400,y:956,t:1527023333024};\\\", \\\"{x:1400,y:955,t:1527023333047};\\\", \\\"{x:1402,y:955,t:1527023333056};\\\", \\\"{x:1403,y:954,t:1527023333072};\\\", \\\"{x:1404,y:954,t:1527023333136};\\\", \\\"{x:1405,y:954,t:1527023333151};\\\", \\\"{x:1406,y:954,t:1527023333183};\\\", \\\"{x:1408,y:954,t:1527023333247};\\\", \\\"{x:1408,y:953,t:1527023333311};\\\", \\\"{x:1408,y:950,t:1527023333321};\\\", \\\"{x:1403,y:938,t:1527023333338};\\\", \\\"{x:1388,y:920,t:1527023333354};\\\", \\\"{x:1370,y:893,t:1527023333371};\\\", \\\"{x:1345,y:852,t:1527023333387};\\\", \\\"{x:1323,y:820,t:1527023333405};\\\", \\\"{x:1310,y:804,t:1527023333421};\\\", \\\"{x:1302,y:794,t:1527023333438};\\\", \\\"{x:1297,y:782,t:1527023333455};\\\", \\\"{x:1291,y:762,t:1527023333471};\\\", \\\"{x:1286,y:742,t:1527023333487};\\\", \\\"{x:1278,y:724,t:1527023333505};\\\", \\\"{x:1275,y:711,t:1527023333522};\\\", \\\"{x:1271,y:700,t:1527023333538};\\\", \\\"{x:1265,y:688,t:1527023333555};\\\", \\\"{x:1261,y:679,t:1527023333572};\\\", \\\"{x:1254,y:667,t:1527023333589};\\\", \\\"{x:1247,y:647,t:1527023333605};\\\", \\\"{x:1240,y:622,t:1527023333622};\\\", \\\"{x:1235,y:601,t:1527023333638};\\\", \\\"{x:1230,y:583,t:1527023333655};\\\", \\\"{x:1229,y:580,t:1527023333672};\\\", \\\"{x:1228,y:578,t:1527023333688};\\\", \\\"{x:1228,y:579,t:1527023333912};\\\", \\\"{x:1228,y:584,t:1527023333923};\\\", \\\"{x:1233,y:593,t:1527023333938};\\\", \\\"{x:1233,y:595,t:1527023333955};\\\", \\\"{x:1235,y:597,t:1527023333972};\\\", \\\"{x:1236,y:599,t:1527023333989};\\\", \\\"{x:1237,y:601,t:1527023334005};\\\", \\\"{x:1239,y:605,t:1527023334022};\\\", \\\"{x:1240,y:609,t:1527023334040};\\\", \\\"{x:1240,y:610,t:1527023334056};\\\", \\\"{x:1240,y:612,t:1527023334072};\\\", \\\"{x:1241,y:616,t:1527023334089};\\\", \\\"{x:1244,y:622,t:1527023334106};\\\", \\\"{x:1246,y:624,t:1527023334123};\\\", \\\"{x:1246,y:625,t:1527023334140};\\\", \\\"{x:1248,y:626,t:1527023334816};\\\", \\\"{x:1250,y:629,t:1527023334824};\\\", \\\"{x:1252,y:631,t:1527023334839};\\\", \\\"{x:1253,y:633,t:1527023334857};\\\", \\\"{x:1254,y:634,t:1527023334874};\\\", \\\"{x:1254,y:635,t:1527023334890};\\\", \\\"{x:1254,y:636,t:1527023335248};\\\", \\\"{x:1254,y:637,t:1527023336040};\\\", \\\"{x:1250,y:661,t:1527023336057};\\\", \\\"{x:1243,y:706,t:1527023336073};\\\", \\\"{x:1230,y:749,t:1527023336090};\\\", \\\"{x:1220,y:800,t:1527023336108};\\\", \\\"{x:1217,y:829,t:1527023336124};\\\", \\\"{x:1216,y:845,t:1527023336142};\\\", \\\"{x:1215,y:856,t:1527023336157};\\\", \\\"{x:1215,y:863,t:1527023336173};\\\", \\\"{x:1215,y:866,t:1527023336190};\\\", \\\"{x:1215,y:868,t:1527023336207};\\\", \\\"{x:1215,y:866,t:1527023336311};\\\", \\\"{x:1215,y:860,t:1527023336323};\\\", \\\"{x:1213,y:847,t:1527023336341};\\\", \\\"{x:1212,y:837,t:1527023336357};\\\", \\\"{x:1211,y:835,t:1527023336375};\\\", \\\"{x:1211,y:834,t:1527023336408};\\\", \\\"{x:1215,y:835,t:1527023337000};\\\", \\\"{x:1224,y:847,t:1527023337009};\\\", \\\"{x:1245,y:880,t:1527023337025};\\\", \\\"{x:1291,y:944,t:1527023337042};\\\", \\\"{x:1323,y:982,t:1527023337058};\\\", \\\"{x:1334,y:1000,t:1527023337074};\\\", \\\"{x:1342,y:1009,t:1527023337091};\\\", \\\"{x:1343,y:1010,t:1527023337108};\\\", \\\"{x:1345,y:1013,t:1527023337125};\\\", \\\"{x:1345,y:1015,t:1527023337143};\\\", \\\"{x:1345,y:1017,t:1527023337160};\\\", \\\"{x:1345,y:1018,t:1527023337175};\\\", \\\"{x:1349,y:1028,t:1527023337191};\\\", \\\"{x:1350,y:1030,t:1527023337208};\\\", \\\"{x:1349,y:1031,t:1527023337280};\\\", \\\"{x:1346,y:1029,t:1527023337292};\\\", \\\"{x:1335,y:1017,t:1527023337309};\\\", \\\"{x:1326,y:1003,t:1527023337324};\\\", \\\"{x:1323,y:999,t:1527023337343};\\\", \\\"{x:1321,y:998,t:1527023337358};\\\", \\\"{x:1321,y:997,t:1527023337375};\\\", \\\"{x:1321,y:996,t:1527023337392};\\\", \\\"{x:1320,y:995,t:1527023337408};\\\", \\\"{x:1319,y:993,t:1527023337424};\\\", \\\"{x:1318,y:989,t:1527023337442};\\\", \\\"{x:1317,y:989,t:1527023337458};\\\", \\\"{x:1317,y:986,t:1527023337475};\\\", \\\"{x:1316,y:985,t:1527023337492};\\\", \\\"{x:1313,y:983,t:1527023337508};\\\", \\\"{x:1312,y:983,t:1527023337525};\\\", \\\"{x:1310,y:982,t:1527023337576};\\\", \\\"{x:1309,y:982,t:1527023337607};\\\", \\\"{x:1308,y:982,t:1527023337625};\\\", \\\"{x:1304,y:982,t:1527023337642};\\\", \\\"{x:1303,y:982,t:1527023337664};\\\", \\\"{x:1302,y:982,t:1527023337680};\\\", \\\"{x:1301,y:982,t:1527023337692};\\\", \\\"{x:1299,y:982,t:1527023337709};\\\", \\\"{x:1296,y:980,t:1527023337726};\\\", \\\"{x:1294,y:980,t:1527023337743};\\\", \\\"{x:1294,y:979,t:1527023337759};\\\", \\\"{x:1291,y:977,t:1527023337775};\\\", \\\"{x:1289,y:974,t:1527023337791};\\\", \\\"{x:1288,y:974,t:1527023337808};\\\", \\\"{x:1288,y:973,t:1527023337920};\\\", \\\"{x:1287,y:972,t:1527023337927};\\\", \\\"{x:1287,y:971,t:1527023337943};\\\", \\\"{x:1287,y:970,t:1527023337984};\\\", \\\"{x:1287,y:968,t:1527023338000};\\\", \\\"{x:1286,y:967,t:1527023338008};\\\", \\\"{x:1286,y:966,t:1527023338151};\\\", \\\"{x:1286,y:965,t:1527023338159};\\\", \\\"{x:1288,y:963,t:1527023338175};\\\", \\\"{x:1289,y:961,t:1527023338192};\\\", \\\"{x:1290,y:959,t:1527023338209};\\\", \\\"{x:1291,y:958,t:1527023338225};\\\", \\\"{x:1292,y:957,t:1527023338242};\\\", \\\"{x:1293,y:955,t:1527023338288};\\\", \\\"{x:1293,y:954,t:1527023338304};\\\", \\\"{x:1295,y:952,t:1527023338311};\\\", \\\"{x:1296,y:951,t:1527023338325};\\\", \\\"{x:1296,y:950,t:1527023338343};\\\", \\\"{x:1296,y:949,t:1527023338362};\\\", \\\"{x:1297,y:948,t:1527023338379};\\\", \\\"{x:1298,y:946,t:1527023338397};\\\", \\\"{x:1299,y:945,t:1527023338412};\\\", \\\"{x:1299,y:944,t:1527023338429};\\\", \\\"{x:1299,y:942,t:1527023338498};\\\", \\\"{x:1299,y:941,t:1527023338511};\\\", \\\"{x:1302,y:935,t:1527023338529};\\\", \\\"{x:1303,y:929,t:1527023338546};\\\", \\\"{x:1306,y:920,t:1527023338562};\\\", \\\"{x:1311,y:908,t:1527023338579};\\\", \\\"{x:1318,y:876,t:1527023338596};\\\", \\\"{x:1338,y:804,t:1527023338611};\\\", \\\"{x:1349,y:732,t:1527023338628};\\\", \\\"{x:1354,y:703,t:1527023338645};\\\", \\\"{x:1358,y:693,t:1527023338662};\\\", \\\"{x:1359,y:689,t:1527023338679};\\\", \\\"{x:1361,y:683,t:1527023338696};\\\", \\\"{x:1361,y:679,t:1527023338712};\\\", \\\"{x:1361,y:677,t:1527023338728};\\\", \\\"{x:1361,y:676,t:1527023338746};\\\", \\\"{x:1361,y:675,t:1527023338763};\\\", \\\"{x:1361,y:680,t:1527023338852};\\\", \\\"{x:1363,y:695,t:1527023338863};\\\", \\\"{x:1370,y:724,t:1527023338880};\\\", \\\"{x:1375,y:742,t:1527023338897};\\\", \\\"{x:1377,y:751,t:1527023338913};\\\", \\\"{x:1378,y:753,t:1527023338929};\\\", \\\"{x:1378,y:754,t:1527023339323};\\\", \\\"{x:1378,y:756,t:1527023339355};\\\", \\\"{x:1378,y:757,t:1527023339659};\\\", \\\"{x:1378,y:759,t:1527023339692};\\\", \\\"{x:1378,y:760,t:1527023341435};\\\", \\\"{x:1369,y:760,t:1527023341450};\\\", \\\"{x:1344,y:758,t:1527023341465};\\\", \\\"{x:1307,y:752,t:1527023341481};\\\", \\\"{x:1253,y:743,t:1527023341498};\\\", \\\"{x:1217,y:732,t:1527023341515};\\\", \\\"{x:1181,y:719,t:1527023341531};\\\", \\\"{x:1157,y:712,t:1527023341548};\\\", \\\"{x:1131,y:707,t:1527023341564};\\\", \\\"{x:1106,y:698,t:1527023341581};\\\", \\\"{x:1079,y:690,t:1527023341598};\\\", \\\"{x:1039,y:680,t:1527023341616};\\\", \\\"{x:987,y:669,t:1527023341631};\\\", \\\"{x:957,y:664,t:1527023341649};\\\", \\\"{x:932,y:656,t:1527023341666};\\\", \\\"{x:886,y:647,t:1527023341681};\\\", \\\"{x:835,y:638,t:1527023341698};\\\", \\\"{x:779,y:632,t:1527023341715};\\\", \\\"{x:696,y:621,t:1527023341733};\\\", \\\"{x:600,y:614,t:1527023341748};\\\", \\\"{x:488,y:595,t:1527023341765};\\\", \\\"{x:378,y:581,t:1527023341780};\\\", \\\"{x:283,y:566,t:1527023341797};\\\", \\\"{x:229,y:563,t:1527023341817};\\\", \\\"{x:197,y:558,t:1527023341834};\\\", \\\"{x:165,y:554,t:1527023341850};\\\", \\\"{x:161,y:554,t:1527023341867};\\\", \\\"{x:160,y:554,t:1527023341883};\\\", \\\"{x:161,y:554,t:1527023342124};\\\", \\\"{x:163,y:554,t:1527023342134};\\\", \\\"{x:174,y:554,t:1527023342150};\\\", \\\"{x:196,y:554,t:1527023342167};\\\", \\\"{x:227,y:553,t:1527023342183};\\\", \\\"{x:281,y:551,t:1527023342201};\\\", \\\"{x:345,y:551,t:1527023342218};\\\", \\\"{x:401,y:551,t:1527023342234};\\\", \\\"{x:448,y:551,t:1527023342251};\\\", \\\"{x:458,y:551,t:1527023342268};\\\", \\\"{x:461,y:551,t:1527023342283};\\\", \\\"{x:460,y:551,t:1527023342403};\\\", \\\"{x:452,y:551,t:1527023342418};\\\", \\\"{x:426,y:549,t:1527023342435};\\\", \\\"{x:414,y:547,t:1527023342452};\\\", \\\"{x:406,y:545,t:1527023342469};\\\", \\\"{x:403,y:545,t:1527023342485};\\\", \\\"{x:400,y:545,t:1527023342546};\\\", \\\"{x:399,y:546,t:1527023342554};\\\", \\\"{x:397,y:546,t:1527023342568};\\\", \\\"{x:396,y:548,t:1527023342585};\\\", \\\"{x:395,y:550,t:1527023342602};\\\", \\\"{x:397,y:553,t:1527023342866};\\\", \\\"{x:403,y:555,t:1527023342874};\\\", \\\"{x:413,y:559,t:1527023342885};\\\", \\\"{x:435,y:564,t:1527023342901};\\\", \\\"{x:480,y:574,t:1527023342918};\\\", \\\"{x:567,y:593,t:1527023342936};\\\", \\\"{x:664,y:621,t:1527023342953};\\\", \\\"{x:775,y:654,t:1527023342969};\\\", \\\"{x:889,y:689,t:1527023342985};\\\", \\\"{x:1014,y:732,t:1527023343001};\\\", \\\"{x:1151,y:786,t:1527023343018};\\\", \\\"{x:1339,y:856,t:1527023343034};\\\", \\\"{x:1431,y:886,t:1527023343052};\\\", \\\"{x:1484,y:902,t:1527023343068};\\\", \\\"{x:1509,y:912,t:1527023343086};\\\", \\\"{x:1518,y:917,t:1527023343102};\\\", \\\"{x:1522,y:920,t:1527023343118};\\\", \\\"{x:1522,y:924,t:1527023343135};\\\", \\\"{x:1522,y:931,t:1527023343152};\\\", \\\"{x:1521,y:937,t:1527023343168};\\\", \\\"{x:1517,y:940,t:1527023343186};\\\", \\\"{x:1509,y:940,t:1527023343202};\\\", \\\"{x:1497,y:940,t:1527023343218};\\\", \\\"{x:1463,y:932,t:1527023343235};\\\", \\\"{x:1435,y:920,t:1527023343252};\\\", \\\"{x:1386,y:901,t:1527023343268};\\\", \\\"{x:1334,y:880,t:1527023343286};\\\", \\\"{x:1282,y:858,t:1527023343303};\\\", \\\"{x:1241,y:841,t:1527023343319};\\\", \\\"{x:1219,y:834,t:1527023343336};\\\", \\\"{x:1210,y:831,t:1527023343353};\\\", \\\"{x:1209,y:831,t:1527023343368};\\\", \\\"{x:1208,y:831,t:1527023343429};\\\", \\\"{x:1207,y:831,t:1527023343435};\\\", \\\"{x:1206,y:830,t:1527023343476};\\\", \\\"{x:1204,y:829,t:1527023343485};\\\", \\\"{x:1199,y:826,t:1527023343503};\\\", \\\"{x:1198,y:825,t:1527023343519};\\\", \\\"{x:1200,y:826,t:1527023343579};\\\", \\\"{x:1204,y:832,t:1527023343587};\\\", \\\"{x:1211,y:840,t:1527023343603};\\\", \\\"{x:1233,y:873,t:1527023343620};\\\", \\\"{x:1248,y:900,t:1527023343635};\\\", \\\"{x:1267,y:939,t:1527023343652};\\\", \\\"{x:1284,y:980,t:1527023343669};\\\", \\\"{x:1297,y:1011,t:1527023343685};\\\", \\\"{x:1307,y:1030,t:1527023343702};\\\", \\\"{x:1312,y:1037,t:1527023343719};\\\", \\\"{x:1313,y:1040,t:1527023343735};\\\", \\\"{x:1313,y:1038,t:1527023343796};\\\", \\\"{x:1312,y:1037,t:1527023343819};\\\", \\\"{x:1311,y:1035,t:1527023343835};\\\", \\\"{x:1309,y:1030,t:1527023343853};\\\", \\\"{x:1307,y:1024,t:1527023343870};\\\", \\\"{x:1305,y:1013,t:1527023343886};\\\", \\\"{x:1300,y:998,t:1527023343903};\\\", \\\"{x:1298,y:988,t:1527023343919};\\\", \\\"{x:1297,y:983,t:1527023343936};\\\", \\\"{x:1296,y:975,t:1527023343952};\\\", \\\"{x:1293,y:960,t:1527023343969};\\\", \\\"{x:1292,y:948,t:1527023343986};\\\", \\\"{x:1292,y:937,t:1527023344002};\\\", \\\"{x:1292,y:924,t:1527023344019};\\\", \\\"{x:1293,y:919,t:1527023344037};\\\", \\\"{x:1294,y:916,t:1527023344053};\\\", \\\"{x:1297,y:912,t:1527023344070};\\\", \\\"{x:1297,y:905,t:1527023344086};\\\", \\\"{x:1301,y:894,t:1527023344103};\\\", \\\"{x:1303,y:887,t:1527023344120};\\\", \\\"{x:1307,y:882,t:1527023344137};\\\", \\\"{x:1311,y:876,t:1527023344153};\\\", \\\"{x:1314,y:869,t:1527023344170};\\\", \\\"{x:1315,y:865,t:1527023344187};\\\", \\\"{x:1320,y:858,t:1527023344204};\\\", \\\"{x:1326,y:845,t:1527023344219};\\\", \\\"{x:1333,y:827,t:1527023344237};\\\", \\\"{x:1339,y:814,t:1527023344253};\\\", \\\"{x:1344,y:806,t:1527023344269};\\\", \\\"{x:1348,y:804,t:1527023344287};\\\", \\\"{x:1351,y:801,t:1527023344303};\\\", \\\"{x:1353,y:798,t:1527023344320};\\\", \\\"{x:1355,y:796,t:1527023344337};\\\", \\\"{x:1357,y:792,t:1527023344354};\\\", \\\"{x:1358,y:790,t:1527023344370};\\\", \\\"{x:1359,y:789,t:1527023344386};\\\", \\\"{x:1361,y:787,t:1527023344459};\\\", \\\"{x:1362,y:786,t:1527023344475};\\\", \\\"{x:1363,y:785,t:1527023344486};\\\", \\\"{x:1364,y:784,t:1527023344524};\\\", \\\"{x:1365,y:783,t:1527023344556};\\\", \\\"{x:1366,y:782,t:1527023344579};\\\", \\\"{x:1367,y:781,t:1527023344652};\\\", \\\"{x:1368,y:781,t:1527023344667};\\\", \\\"{x:1369,y:780,t:1527023344675};\\\", \\\"{x:1370,y:779,t:1527023344691};\\\", \\\"{x:1370,y:778,t:1527023344703};\\\", \\\"{x:1370,y:777,t:1527023344731};\\\", \\\"{x:1371,y:777,t:1527023344747};\\\", \\\"{x:1371,y:776,t:1527023344755};\\\", \\\"{x:1373,y:775,t:1527023344771};\\\", \\\"{x:1373,y:774,t:1527023344787};\\\", \\\"{x:1374,y:772,t:1527023344900};\\\", \\\"{x:1374,y:771,t:1527023344915};\\\", \\\"{x:1374,y:770,t:1527023344931};\\\", \\\"{x:1375,y:770,t:1527023344939};\\\", \\\"{x:1375,y:769,t:1527023344955};\\\", \\\"{x:1375,y:768,t:1527023344979};\\\", \\\"{x:1375,y:767,t:1527023344995};\\\", \\\"{x:1376,y:766,t:1527023345004};\\\", \\\"{x:1376,y:765,t:1527023345036};\\\", \\\"{x:1376,y:764,t:1527023345053};\\\", \\\"{x:1376,y:763,t:1527023345075};\\\", \\\"{x:1376,y:762,t:1527023345202};\\\", \\\"{x:1376,y:761,t:1527023345210};\\\", \\\"{x:1376,y:760,t:1527023345226};\\\", \\\"{x:1377,y:759,t:1527023345250};\\\", \\\"{x:1377,y:758,t:1527023345291};\\\", \\\"{x:1377,y:757,t:1527023345612};\\\", \\\"{x:1369,y:755,t:1527023345621};\\\", \\\"{x:1325,y:748,t:1527023345637};\\\", \\\"{x:1233,y:735,t:1527023345654};\\\", \\\"{x:1142,y:727,t:1527023345670};\\\", \\\"{x:1053,y:725,t:1527023345687};\\\", \\\"{x:984,y:733,t:1527023345704};\\\", \\\"{x:946,y:734,t:1527023345721};\\\", \\\"{x:923,y:737,t:1527023345737};\\\", \\\"{x:906,y:739,t:1527023345754};\\\", \\\"{x:887,y:744,t:1527023345771};\\\", \\\"{x:852,y:749,t:1527023345787};\\\", \\\"{x:830,y:749,t:1527023345804};\\\", \\\"{x:806,y:749,t:1527023345821};\\\", \\\"{x:779,y:749,t:1527023345837};\\\", \\\"{x:752,y:748,t:1527023345854};\\\", \\\"{x:725,y:748,t:1527023345871};\\\", \\\"{x:695,y:748,t:1527023345887};\\\", \\\"{x:664,y:748,t:1527023345904};\\\", \\\"{x:636,y:747,t:1527023345921};\\\", \\\"{x:608,y:746,t:1527023345938};\\\", \\\"{x:586,y:743,t:1527023345954};\\\", \\\"{x:559,y:740,t:1527023345971};\\\", \\\"{x:547,y:738,t:1527023345987};\\\", \\\"{x:545,y:738,t:1527023346004};\\\", \\\"{x:544,y:738,t:1527023346116};\\\", \\\"{x:542,y:736,t:1527023346123};\\\", \\\"{x:539,y:733,t:1527023346139};\\\", \\\"{x:534,y:726,t:1527023346154};\\\", \\\"{x:530,y:720,t:1527023346171};\\\", \\\"{x:526,y:713,t:1527023346187};\\\", \\\"{x:525,y:711,t:1527023346204};\\\", \\\"{x:524,y:709,t:1527023346221};\\\", \\\"{x:524,y:707,t:1527023346237};\\\", \\\"{x:524,y:706,t:1527023346254};\\\" ] }, { \\\"rt\\\": 7968, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 377075, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:702,t:1527023348963};\\\", \\\"{x:540,y:698,t:1527023348975};\\\", \\\"{x:579,y:698,t:1527023348989};\\\", \\\"{x:635,y:698,t:1527023349006};\\\", \\\"{x:727,y:698,t:1527023349024};\\\", \\\"{x:815,y:689,t:1527023349040};\\\", \\\"{x:862,y:689,t:1527023349057};\\\", \\\"{x:891,y:687,t:1527023349074};\\\", \\\"{x:931,y:686,t:1527023349091};\\\", \\\"{x:973,y:686,t:1527023349106};\\\", \\\"{x:1029,y:686,t:1527023349124};\\\", \\\"{x:1071,y:686,t:1527023349141};\\\", \\\"{x:1094,y:686,t:1527023349158};\\\", \\\"{x:1111,y:686,t:1527023349174};\\\", \\\"{x:1128,y:686,t:1527023349190};\\\", \\\"{x:1140,y:686,t:1527023349207};\\\", \\\"{x:1147,y:686,t:1527023349224};\\\", \\\"{x:1151,y:686,t:1527023349241};\\\", \\\"{x:1163,y:687,t:1527023349258};\\\", \\\"{x:1176,y:695,t:1527023349274};\\\", \\\"{x:1198,y:706,t:1527023349291};\\\", \\\"{x:1214,y:715,t:1527023349307};\\\", \\\"{x:1231,y:726,t:1527023349325};\\\", \\\"{x:1243,y:736,t:1527023349341};\\\", \\\"{x:1258,y:753,t:1527023349357};\\\", \\\"{x:1275,y:775,t:1527023349375};\\\", \\\"{x:1287,y:794,t:1527023349391};\\\", \\\"{x:1294,y:811,t:1527023349407};\\\", \\\"{x:1298,y:818,t:1527023349425};\\\", \\\"{x:1300,y:819,t:1527023349441};\\\", \\\"{x:1301,y:820,t:1527023349458};\\\", \\\"{x:1302,y:820,t:1527023349515};\\\", \\\"{x:1304,y:819,t:1527023349531};\\\", \\\"{x:1306,y:817,t:1527023349541};\\\", \\\"{x:1312,y:813,t:1527023349558};\\\", \\\"{x:1318,y:809,t:1527023349575};\\\", \\\"{x:1325,y:805,t:1527023349592};\\\", \\\"{x:1328,y:802,t:1527023349608};\\\", \\\"{x:1329,y:800,t:1527023349624};\\\", \\\"{x:1330,y:799,t:1527023349642};\\\", \\\"{x:1330,y:798,t:1527023349658};\\\", \\\"{x:1330,y:792,t:1527023349675};\\\", \\\"{x:1332,y:788,t:1527023349691};\\\", \\\"{x:1332,y:785,t:1527023349708};\\\", \\\"{x:1333,y:784,t:1527023349725};\\\", \\\"{x:1333,y:783,t:1527023349741};\\\", \\\"{x:1333,y:784,t:1527023349907};\\\", \\\"{x:1324,y:793,t:1527023349925};\\\", \\\"{x:1305,y:804,t:1527023349942};\\\", \\\"{x:1281,y:814,t:1527023349959};\\\", \\\"{x:1250,y:826,t:1527023349974};\\\", \\\"{x:1224,y:841,t:1527023349991};\\\", \\\"{x:1205,y:853,t:1527023350009};\\\", \\\"{x:1193,y:859,t:1527023350025};\\\", \\\"{x:1186,y:862,t:1527023350042};\\\", \\\"{x:1181,y:862,t:1527023350059};\\\", \\\"{x:1178,y:863,t:1527023350075};\\\", \\\"{x:1177,y:863,t:1527023350092};\\\", \\\"{x:1178,y:863,t:1527023350187};\\\", \\\"{x:1187,y:862,t:1527023350196};\\\", \\\"{x:1197,y:861,t:1527023350209};\\\", \\\"{x:1235,y:855,t:1527023350225};\\\", \\\"{x:1291,y:847,t:1527023350242};\\\", \\\"{x:1351,y:840,t:1527023350259};\\\", \\\"{x:1380,y:840,t:1527023350275};\\\", \\\"{x:1398,y:840,t:1527023350292};\\\", \\\"{x:1407,y:842,t:1527023350309};\\\", \\\"{x:1408,y:844,t:1527023350428};\\\", \\\"{x:1409,y:845,t:1527023350443};\\\", \\\"{x:1409,y:847,t:1527023350459};\\\", \\\"{x:1411,y:851,t:1527023350475};\\\", \\\"{x:1415,y:856,t:1527023350492};\\\", \\\"{x:1420,y:865,t:1527023350509};\\\", \\\"{x:1425,y:873,t:1527023350526};\\\", \\\"{x:1426,y:878,t:1527023350543};\\\", \\\"{x:1428,y:884,t:1527023350559};\\\", \\\"{x:1429,y:888,t:1527023350576};\\\", \\\"{x:1432,y:892,t:1527023350593};\\\", \\\"{x:1434,y:899,t:1527023350609};\\\", \\\"{x:1437,y:906,t:1527023350626};\\\", \\\"{x:1441,y:917,t:1527023350643};\\\", \\\"{x:1443,y:920,t:1527023350659};\\\", \\\"{x:1443,y:922,t:1527023350676};\\\", \\\"{x:1444,y:926,t:1527023350693};\\\", \\\"{x:1446,y:936,t:1527023350709};\\\", \\\"{x:1450,y:952,t:1527023350726};\\\", \\\"{x:1452,y:963,t:1527023350743};\\\", \\\"{x:1452,y:970,t:1527023350761};\\\", \\\"{x:1452,y:973,t:1527023350776};\\\", \\\"{x:1452,y:975,t:1527023350844};\\\", \\\"{x:1450,y:975,t:1527023350860};\\\", \\\"{x:1443,y:978,t:1527023350875};\\\", \\\"{x:1435,y:978,t:1527023350893};\\\", \\\"{x:1428,y:978,t:1527023350910};\\\", \\\"{x:1418,y:978,t:1527023350926};\\\", \\\"{x:1407,y:978,t:1527023350943};\\\", \\\"{x:1396,y:978,t:1527023350959};\\\", \\\"{x:1386,y:977,t:1527023350978};\\\", \\\"{x:1380,y:976,t:1527023350993};\\\", \\\"{x:1379,y:976,t:1527023351011};\\\", \\\"{x:1381,y:975,t:1527023351148};\\\", \\\"{x:1387,y:975,t:1527023351160};\\\", \\\"{x:1409,y:975,t:1527023351177};\\\", \\\"{x:1437,y:973,t:1527023351194};\\\", \\\"{x:1468,y:970,t:1527023351210};\\\", \\\"{x:1504,y:966,t:1527023351228};\\\", \\\"{x:1521,y:966,t:1527023351243};\\\", \\\"{x:1535,y:966,t:1527023351261};\\\", \\\"{x:1540,y:966,t:1527023351277};\\\", \\\"{x:1542,y:966,t:1527023351294};\\\", \\\"{x:1543,y:966,t:1527023351355};\\\", \\\"{x:1545,y:966,t:1527023351363};\\\", \\\"{x:1547,y:966,t:1527023351380};\\\", \\\"{x:1550,y:966,t:1527023351394};\\\", \\\"{x:1554,y:966,t:1527023351410};\\\", \\\"{x:1561,y:966,t:1527023351427};\\\", \\\"{x:1564,y:965,t:1527023351444};\\\", \\\"{x:1565,y:965,t:1527023351460};\\\", \\\"{x:1567,y:965,t:1527023351477};\\\", \\\"{x:1570,y:965,t:1527023351493};\\\", \\\"{x:1575,y:965,t:1527023351512};\\\", \\\"{x:1579,y:965,t:1527023351527};\\\", \\\"{x:1586,y:965,t:1527023351544};\\\", \\\"{x:1594,y:965,t:1527023351561};\\\", \\\"{x:1599,y:965,t:1527023351577};\\\", \\\"{x:1602,y:965,t:1527023351594};\\\", \\\"{x:1605,y:965,t:1527023351611};\\\", \\\"{x:1607,y:965,t:1527023351627};\\\", \\\"{x:1608,y:965,t:1527023351716};\\\", \\\"{x:1610,y:965,t:1527023351732};\\\", \\\"{x:1611,y:963,t:1527023351744};\\\", \\\"{x:1612,y:963,t:1527023351772};\\\", \\\"{x:1613,y:963,t:1527023351787};\\\", \\\"{x:1614,y:962,t:1527023351844};\\\", \\\"{x:1615,y:962,t:1527023352107};\\\", \\\"{x:1615,y:960,t:1527023352116};\\\", \\\"{x:1614,y:958,t:1527023352128};\\\", \\\"{x:1612,y:954,t:1527023352145};\\\", \\\"{x:1606,y:947,t:1527023352161};\\\", \\\"{x:1602,y:942,t:1527023352178};\\\", \\\"{x:1593,y:929,t:1527023352195};\\\", \\\"{x:1587,y:919,t:1527023352211};\\\", \\\"{x:1582,y:909,t:1527023352228};\\\", \\\"{x:1573,y:893,t:1527023352245};\\\", \\\"{x:1566,y:880,t:1527023352261};\\\", \\\"{x:1559,y:868,t:1527023352278};\\\", \\\"{x:1554,y:854,t:1527023352295};\\\", \\\"{x:1550,y:844,t:1527023352312};\\\", \\\"{x:1544,y:829,t:1527023352328};\\\", \\\"{x:1541,y:816,t:1527023352345};\\\", \\\"{x:1539,y:806,t:1527023352362};\\\", \\\"{x:1536,y:794,t:1527023352378};\\\", \\\"{x:1531,y:778,t:1527023352396};\\\", \\\"{x:1527,y:772,t:1527023352411};\\\", \\\"{x:1527,y:768,t:1527023352428};\\\", \\\"{x:1526,y:766,t:1527023352445};\\\", \\\"{x:1525,y:764,t:1527023352462};\\\", \\\"{x:1524,y:762,t:1527023352478};\\\", \\\"{x:1524,y:761,t:1527023352495};\\\", \\\"{x:1523,y:759,t:1527023352513};\\\", \\\"{x:1523,y:758,t:1527023352528};\\\", \\\"{x:1521,y:754,t:1527023352545};\\\", \\\"{x:1519,y:751,t:1527023352562};\\\", \\\"{x:1517,y:749,t:1527023352578};\\\", \\\"{x:1513,y:743,t:1527023352595};\\\", \\\"{x:1511,y:741,t:1527023352612};\\\", \\\"{x:1508,y:737,t:1527023352629};\\\", \\\"{x:1505,y:734,t:1527023352645};\\\", \\\"{x:1501,y:731,t:1527023352662};\\\", \\\"{x:1500,y:730,t:1527023352679};\\\", \\\"{x:1499,y:729,t:1527023352695};\\\", \\\"{x:1498,y:728,t:1527023352712};\\\", \\\"{x:1497,y:727,t:1527023352731};\\\", \\\"{x:1496,y:724,t:1527023352755};\\\", \\\"{x:1494,y:723,t:1527023352763};\\\", \\\"{x:1493,y:719,t:1527023352780};\\\", \\\"{x:1492,y:718,t:1527023352795};\\\", \\\"{x:1491,y:716,t:1527023352812};\\\", \\\"{x:1490,y:713,t:1527023352852};\\\", \\\"{x:1489,y:710,t:1527023352862};\\\", \\\"{x:1486,y:703,t:1527023352879};\\\", \\\"{x:1484,y:697,t:1527023352896};\\\", \\\"{x:1480,y:690,t:1527023352912};\\\", \\\"{x:1480,y:689,t:1527023352929};\\\", \\\"{x:1479,y:686,t:1527023352946};\\\", \\\"{x:1478,y:685,t:1527023352962};\\\", \\\"{x:1476,y:680,t:1527023352979};\\\", \\\"{x:1474,y:677,t:1527023352996};\\\", \\\"{x:1471,y:670,t:1527023353012};\\\", \\\"{x:1469,y:665,t:1527023353029};\\\", \\\"{x:1467,y:662,t:1527023353046};\\\", \\\"{x:1467,y:661,t:1527023353062};\\\", \\\"{x:1465,y:659,t:1527023353079};\\\", \\\"{x:1464,y:656,t:1527023353096};\\\", \\\"{x:1462,y:651,t:1527023353113};\\\", \\\"{x:1460,y:647,t:1527023353129};\\\", \\\"{x:1459,y:644,t:1527023353146};\\\", \\\"{x:1456,y:637,t:1527023353163};\\\", \\\"{x:1453,y:633,t:1527023353179};\\\", \\\"{x:1451,y:629,t:1527023353196};\\\", \\\"{x:1450,y:627,t:1527023353213};\\\", \\\"{x:1448,y:624,t:1527023353229};\\\", \\\"{x:1444,y:618,t:1527023353246};\\\", \\\"{x:1441,y:614,t:1527023353263};\\\", \\\"{x:1439,y:611,t:1527023353279};\\\", \\\"{x:1438,y:609,t:1527023353296};\\\", \\\"{x:1437,y:608,t:1527023353314};\\\", \\\"{x:1435,y:605,t:1527023353329};\\\", \\\"{x:1431,y:601,t:1527023353346};\\\", \\\"{x:1425,y:596,t:1527023353363};\\\", \\\"{x:1420,y:591,t:1527023353379};\\\", \\\"{x:1416,y:588,t:1527023353396};\\\", \\\"{x:1414,y:585,t:1527023353413};\\\", \\\"{x:1413,y:584,t:1527023353429};\\\", \\\"{x:1412,y:583,t:1527023353446};\\\", \\\"{x:1410,y:579,t:1527023353462};\\\", \\\"{x:1409,y:577,t:1527023353480};\\\", \\\"{x:1409,y:576,t:1527023353496};\\\", \\\"{x:1409,y:572,t:1527023353512};\\\", \\\"{x:1409,y:569,t:1527023353530};\\\", \\\"{x:1409,y:567,t:1527023353545};\\\", \\\"{x:1409,y:566,t:1527023353563};\\\", \\\"{x:1408,y:565,t:1527023353716};\\\", \\\"{x:1406,y:565,t:1527023353730};\\\", \\\"{x:1375,y:567,t:1527023353747};\\\", \\\"{x:1331,y:573,t:1527023353763};\\\", \\\"{x:1226,y:587,t:1527023353780};\\\", \\\"{x:1069,y:607,t:1527023353797};\\\", \\\"{x:891,y:618,t:1527023353813};\\\", \\\"{x:746,y:620,t:1527023353830};\\\", \\\"{x:638,y:620,t:1527023353849};\\\", \\\"{x:591,y:620,t:1527023353863};\\\", \\\"{x:570,y:620,t:1527023353879};\\\", \\\"{x:566,y:620,t:1527023353894};\\\", \\\"{x:564,y:620,t:1527023353911};\\\", \\\"{x:564,y:618,t:1527023354043};\\\", \\\"{x:571,y:615,t:1527023354061};\\\", \\\"{x:577,y:612,t:1527023354078};\\\", \\\"{x:586,y:606,t:1527023354094};\\\", \\\"{x:592,y:603,t:1527023354111};\\\", \\\"{x:593,y:602,t:1527023354127};\\\", \\\"{x:595,y:601,t:1527023354146};\\\", \\\"{x:596,y:600,t:1527023354160};\\\", \\\"{x:597,y:596,t:1527023354177};\\\", \\\"{x:600,y:591,t:1527023354195};\\\", \\\"{x:600,y:589,t:1527023354226};\\\", \\\"{x:600,y:588,t:1527023354242};\\\", \\\"{x:600,y:586,t:1527023354251};\\\", \\\"{x:600,y:585,t:1527023354261};\\\", \\\"{x:600,y:581,t:1527023354279};\\\", \\\"{x:600,y:579,t:1527023354294};\\\", \\\"{x:600,y:578,t:1527023354311};\\\", \\\"{x:600,y:577,t:1527023354327};\\\", \\\"{x:600,y:575,t:1527023354344};\\\", \\\"{x:600,y:572,t:1527023354362};\\\", \\\"{x:600,y:570,t:1527023354377};\\\", \\\"{x:600,y:568,t:1527023354466};\\\", \\\"{x:601,y:568,t:1527023354477};\\\", \\\"{x:601,y:567,t:1527023354506};\\\", \\\"{x:602,y:566,t:1527023354547};\\\", \\\"{x:606,y:566,t:1527023354954};\\\", \\\"{x:607,y:566,t:1527023354963};\\\", \\\"{x:614,y:566,t:1527023354979};\\\", \\\"{x:624,y:566,t:1527023354995};\\\", \\\"{x:633,y:568,t:1527023355012};\\\", \\\"{x:647,y:571,t:1527023355029};\\\", \\\"{x:657,y:573,t:1527023355044};\\\", \\\"{x:668,y:576,t:1527023355062};\\\", \\\"{x:681,y:582,t:1527023355078};\\\", \\\"{x:697,y:591,t:1527023355094};\\\", \\\"{x:716,y:602,t:1527023355111};\\\", \\\"{x:730,y:614,t:1527023355129};\\\", \\\"{x:738,y:629,t:1527023355145};\\\", \\\"{x:744,y:650,t:1527023355162};\\\", \\\"{x:744,y:676,t:1527023355178};\\\", \\\"{x:733,y:694,t:1527023355195};\\\", \\\"{x:711,y:714,t:1527023355211};\\\", \\\"{x:672,y:741,t:1527023355229};\\\", \\\"{x:622,y:764,t:1527023355246};\\\", \\\"{x:577,y:773,t:1527023355261};\\\", \\\"{x:546,y:777,t:1527023355278};\\\", \\\"{x:509,y:777,t:1527023355296};\\\", \\\"{x:485,y:777,t:1527023355312};\\\", \\\"{x:473,y:775,t:1527023355329};\\\", \\\"{x:471,y:773,t:1527023355346};\\\", \\\"{x:469,y:773,t:1527023355362};\\\", \\\"{x:469,y:769,t:1527023355379};\\\", \\\"{x:470,y:766,t:1527023355395};\\\", \\\"{x:472,y:764,t:1527023355412};\\\", \\\"{x:472,y:762,t:1527023355429};\\\", \\\"{x:473,y:762,t:1527023355446};\\\", \\\"{x:473,y:760,t:1527023355491};\\\", \\\"{x:476,y:757,t:1527023355499};\\\", \\\"{x:477,y:755,t:1527023355512};\\\", \\\"{x:481,y:749,t:1527023355529};\\\", \\\"{x:487,y:741,t:1527023355546};\\\", \\\"{x:490,y:738,t:1527023355562};\\\", \\\"{x:493,y:731,t:1527023355580};\\\", \\\"{x:495,y:726,t:1527023355595};\\\", \\\"{x:495,y:724,t:1527023355613};\\\" ] }, { \\\"rt\\\": 15482, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 393801, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:723,t:1527023358059};\\\", \\\"{x:490,y:719,t:1527023358073};\\\", \\\"{x:484,y:718,t:1527023358082};\\\", \\\"{x:469,y:709,t:1527023358099};\\\", \\\"{x:457,y:705,t:1527023358115};\\\", \\\"{x:446,y:701,t:1527023358131};\\\", \\\"{x:436,y:698,t:1527023358147};\\\", \\\"{x:433,y:696,t:1527023358164};\\\", \\\"{x:430,y:690,t:1527023358180};\\\", \\\"{x:429,y:675,t:1527023358198};\\\", \\\"{x:428,y:651,t:1527023358214};\\\", \\\"{x:427,y:631,t:1527023358231};\\\", \\\"{x:427,y:618,t:1527023358249};\\\", \\\"{x:427,y:607,t:1527023358264};\\\", \\\"{x:427,y:591,t:1527023358281};\\\", \\\"{x:427,y:574,t:1527023358299};\\\", \\\"{x:427,y:542,t:1527023358315};\\\", \\\"{x:427,y:521,t:1527023358331};\\\", \\\"{x:432,y:505,t:1527023358348};\\\", \\\"{x:435,y:494,t:1527023358366};\\\", \\\"{x:439,y:482,t:1527023358381};\\\", \\\"{x:441,y:475,t:1527023358398};\\\", \\\"{x:444,y:467,t:1527023358414};\\\", \\\"{x:449,y:458,t:1527023358431};\\\", \\\"{x:453,y:449,t:1527023358448};\\\", \\\"{x:457,y:443,t:1527023358465};\\\", \\\"{x:458,y:440,t:1527023358482};\\\", \\\"{x:459,y:438,t:1527023358498};\\\", \\\"{x:460,y:437,t:1527023358522};\\\", \\\"{x:461,y:436,t:1527023358539};\\\", \\\"{x:462,y:435,t:1527023358586};\\\", \\\"{x:464,y:435,t:1527023358876};\\\", \\\"{x:474,y:435,t:1527023358883};\\\", \\\"{x:490,y:438,t:1527023358900};\\\", \\\"{x:496,y:440,t:1527023358916};\\\", \\\"{x:501,y:441,t:1527023358933};\\\", \\\"{x:504,y:441,t:1527023358950};\\\", \\\"{x:505,y:441,t:1527023358966};\\\", \\\"{x:506,y:441,t:1527023358983};\\\", \\\"{x:508,y:441,t:1527023359000};\\\", \\\"{x:511,y:441,t:1527023359017};\\\", \\\"{x:515,y:441,t:1527023359033};\\\", \\\"{x:523,y:441,t:1527023359050};\\\", \\\"{x:531,y:442,t:1527023359066};\\\", \\\"{x:534,y:443,t:1527023359083};\\\", \\\"{x:537,y:443,t:1527023359100};\\\", \\\"{x:538,y:443,t:1527023359118};\\\", \\\"{x:539,y:444,t:1527023359133};\\\", \\\"{x:540,y:444,t:1527023359163};\\\", \\\"{x:541,y:444,t:1527023359171};\\\", \\\"{x:546,y:444,t:1527023359184};\\\", \\\"{x:554,y:444,t:1527023359200};\\\", \\\"{x:557,y:444,t:1527023359217};\\\", \\\"{x:559,y:444,t:1527023359234};\\\", \\\"{x:563,y:444,t:1527023359251};\\\", \\\"{x:569,y:444,t:1527023359267};\\\", \\\"{x:575,y:444,t:1527023359284};\\\", \\\"{x:584,y:445,t:1527023359301};\\\", \\\"{x:597,y:446,t:1527023359317};\\\", \\\"{x:608,y:446,t:1527023359334};\\\", \\\"{x:614,y:446,t:1527023359351};\\\", \\\"{x:618,y:446,t:1527023359367};\\\", \\\"{x:621,y:446,t:1527023359384};\\\", \\\"{x:622,y:446,t:1527023359401};\\\", \\\"{x:624,y:446,t:1527023359419};\\\", \\\"{x:625,y:446,t:1527023359459};\\\", \\\"{x:627,y:446,t:1527023359483};\\\", \\\"{x:628,y:446,t:1527023359499};\\\", \\\"{x:630,y:446,t:1527023359523};\\\", \\\"{x:631,y:446,t:1527023359547};\\\", \\\"{x:631,y:449,t:1527023359699};\\\", \\\"{x:627,y:451,t:1527023359707};\\\", \\\"{x:623,y:454,t:1527023359718};\\\", \\\"{x:611,y:465,t:1527023359735};\\\", \\\"{x:597,y:475,t:1527023359752};\\\", \\\"{x:584,y:484,t:1527023359768};\\\", \\\"{x:569,y:489,t:1527023359785};\\\", \\\"{x:561,y:491,t:1527023359802};\\\", \\\"{x:556,y:493,t:1527023359818};\\\", \\\"{x:554,y:493,t:1527023359842};\\\", \\\"{x:551,y:494,t:1527023359852};\\\", \\\"{x:546,y:494,t:1527023359868};\\\", \\\"{x:545,y:494,t:1527023359890};\\\", \\\"{x:543,y:494,t:1527023359907};\\\", \\\"{x:541,y:494,t:1527023359922};\\\", \\\"{x:539,y:494,t:1527023359936};\\\", \\\"{x:535,y:494,t:1527023359952};\\\", \\\"{x:533,y:494,t:1527023359968};\\\", \\\"{x:531,y:494,t:1527023359986};\\\", \\\"{x:528,y:494,t:1527023360002};\\\", \\\"{x:526,y:494,t:1527023360019};\\\", \\\"{x:524,y:494,t:1527023360036};\\\", \\\"{x:526,y:494,t:1527023360131};\\\", \\\"{x:527,y:493,t:1527023360139};\\\", \\\"{x:529,y:492,t:1527023360153};\\\", \\\"{x:532,y:490,t:1527023360171};\\\", \\\"{x:534,y:490,t:1527023360186};\\\", \\\"{x:539,y:489,t:1527023360202};\\\", \\\"{x:542,y:489,t:1527023360220};\\\", \\\"{x:547,y:489,t:1527023360236};\\\", \\\"{x:553,y:489,t:1527023360253};\\\", \\\"{x:557,y:489,t:1527023360270};\\\", \\\"{x:560,y:489,t:1527023360286};\\\", \\\"{x:564,y:489,t:1527023360303};\\\", \\\"{x:568,y:488,t:1527023360320};\\\", \\\"{x:573,y:488,t:1527023360337};\\\", \\\"{x:581,y:488,t:1527023360353};\\\", \\\"{x:593,y:488,t:1527023360370};\\\", \\\"{x:611,y:488,t:1527023360387};\\\", \\\"{x:620,y:488,t:1527023360403};\\\", \\\"{x:630,y:488,t:1527023360420};\\\", \\\"{x:638,y:488,t:1527023360437};\\\", \\\"{x:646,y:488,t:1527023360454};\\\", \\\"{x:660,y:488,t:1527023360470};\\\", \\\"{x:686,y:488,t:1527023360487};\\\", \\\"{x:711,y:491,t:1527023360505};\\\", \\\"{x:724,y:497,t:1527023360520};\\\", \\\"{x:726,y:499,t:1527023361539};\\\", \\\"{x:727,y:499,t:1527023362203};\\\", \\\"{x:729,y:499,t:1527023362211};\\\", \\\"{x:732,y:499,t:1527023362226};\\\", \\\"{x:752,y:499,t:1527023362243};\\\", \\\"{x:787,y:499,t:1527023362258};\\\", \\\"{x:813,y:499,t:1527023362275};\\\", \\\"{x:815,y:496,t:1527023362292};\\\", \\\"{x:822,y:502,t:1527023362540};\\\", \\\"{x:836,y:510,t:1527023362547};\\\", \\\"{x:849,y:514,t:1527023362559};\\\", \\\"{x:887,y:532,t:1527023362578};\\\", \\\"{x:948,y:558,t:1527023362593};\\\", \\\"{x:1035,y:591,t:1527023362609};\\\", \\\"{x:1291,y:694,t:1527023362635};\\\", \\\"{x:1407,y:727,t:1527023362652};\\\", \\\"{x:1488,y:751,t:1527023362668};\\\", \\\"{x:1516,y:755,t:1527023362685};\\\", \\\"{x:1515,y:755,t:1527023363044};\\\", \\\"{x:1506,y:753,t:1527023363052};\\\", \\\"{x:1500,y:751,t:1527023363070};\\\", \\\"{x:1497,y:749,t:1527023363085};\\\", \\\"{x:1494,y:748,t:1527023363103};\\\", \\\"{x:1490,y:746,t:1527023363120};\\\", \\\"{x:1487,y:744,t:1527023363136};\\\", \\\"{x:1479,y:739,t:1527023363152};\\\", \\\"{x:1466,y:730,t:1527023363169};\\\", \\\"{x:1444,y:714,t:1527023363185};\\\", \\\"{x:1416,y:695,t:1527023363202};\\\", \\\"{x:1374,y:673,t:1527023363219};\\\", \\\"{x:1353,y:660,t:1527023363235};\\\", \\\"{x:1343,y:653,t:1527023363253};\\\", \\\"{x:1337,y:644,t:1527023363270};\\\", \\\"{x:1328,y:631,t:1527023363286};\\\", \\\"{x:1317,y:606,t:1527023363302};\\\", \\\"{x:1304,y:580,t:1527023363318};\\\", \\\"{x:1296,y:566,t:1527023363335};\\\", \\\"{x:1292,y:560,t:1527023363352};\\\", \\\"{x:1290,y:555,t:1527023363369};\\\", \\\"{x:1289,y:553,t:1527023363386};\\\", \\\"{x:1287,y:549,t:1527023363402};\\\", \\\"{x:1287,y:547,t:1527023363419};\\\", \\\"{x:1287,y:543,t:1527023363436};\\\", \\\"{x:1288,y:536,t:1527023363451};\\\", \\\"{x:1288,y:521,t:1527023363469};\\\", \\\"{x:1288,y:514,t:1527023363486};\\\", \\\"{x:1288,y:512,t:1527023363502};\\\", \\\"{x:1289,y:511,t:1527023363519};\\\", \\\"{x:1289,y:509,t:1527023363536};\\\", \\\"{x:1291,y:505,t:1527023363552};\\\", \\\"{x:1293,y:502,t:1527023363569};\\\", \\\"{x:1294,y:500,t:1527023363586};\\\", \\\"{x:1294,y:499,t:1527023363602};\\\", \\\"{x:1295,y:498,t:1527023363619};\\\", \\\"{x:1295,y:497,t:1527023363651};\\\", \\\"{x:1296,y:497,t:1527023363667};\\\", \\\"{x:1297,y:497,t:1527023363675};\\\", \\\"{x:1298,y:496,t:1527023363699};\\\", \\\"{x:1300,y:495,t:1527023363715};\\\", \\\"{x:1302,y:494,t:1527023363723};\\\", \\\"{x:1305,y:494,t:1527023363736};\\\", \\\"{x:1309,y:494,t:1527023363755};\\\", \\\"{x:1312,y:494,t:1527023363769};\\\", \\\"{x:1313,y:494,t:1527023363785};\\\", \\\"{x:1314,y:494,t:1527023363802};\\\", \\\"{x:1315,y:494,t:1527023365514};\\\", \\\"{x:1315,y:497,t:1527023365522};\\\", \\\"{x:1315,y:500,t:1527023365537};\\\", \\\"{x:1315,y:510,t:1527023365555};\\\", \\\"{x:1315,y:515,t:1527023365571};\\\", \\\"{x:1315,y:518,t:1527023365588};\\\", \\\"{x:1315,y:523,t:1527023365603};\\\", \\\"{x:1315,y:526,t:1527023365621};\\\", \\\"{x:1315,y:529,t:1527023365638};\\\", \\\"{x:1315,y:540,t:1527023365678};\\\", \\\"{x:1315,y:541,t:1527023365688};\\\", \\\"{x:1315,y:543,t:1527023365704};\\\", \\\"{x:1315,y:549,t:1527023365720};\\\", \\\"{x:1315,y:554,t:1527023365738};\\\", \\\"{x:1314,y:558,t:1527023365753};\\\", \\\"{x:1314,y:563,t:1527023365771};\\\", \\\"{x:1314,y:571,t:1527023365788};\\\", \\\"{x:1314,y:575,t:1527023365804};\\\", \\\"{x:1314,y:581,t:1527023365821};\\\", \\\"{x:1313,y:586,t:1527023365838};\\\", \\\"{x:1312,y:590,t:1527023365853};\\\", \\\"{x:1312,y:595,t:1527023365870};\\\", \\\"{x:1312,y:600,t:1527023365887};\\\", \\\"{x:1312,y:602,t:1527023365905};\\\", \\\"{x:1311,y:604,t:1527023365921};\\\", \\\"{x:1310,y:611,t:1527023365937};\\\", \\\"{x:1310,y:614,t:1527023365954};\\\", \\\"{x:1310,y:618,t:1527023365970};\\\", \\\"{x:1310,y:621,t:1527023365988};\\\", \\\"{x:1308,y:623,t:1527023366005};\\\", \\\"{x:1308,y:624,t:1527023366021};\\\", \\\"{x:1308,y:626,t:1527023366038};\\\", \\\"{x:1308,y:627,t:1527023366055};\\\", \\\"{x:1308,y:629,t:1527023366074};\\\", \\\"{x:1308,y:630,t:1527023366090};\\\", \\\"{x:1308,y:632,t:1527023366105};\\\", \\\"{x:1308,y:634,t:1527023366121};\\\", \\\"{x:1308,y:637,t:1527023366138};\\\", \\\"{x:1308,y:640,t:1527023366154};\\\", \\\"{x:1308,y:644,t:1527023366171};\\\", \\\"{x:1307,y:647,t:1527023366187};\\\", \\\"{x:1307,y:654,t:1527023366204};\\\", \\\"{x:1307,y:661,t:1527023366221};\\\", \\\"{x:1307,y:670,t:1527023366237};\\\", \\\"{x:1306,y:680,t:1527023366255};\\\", \\\"{x:1306,y:695,t:1527023366276};\\\", \\\"{x:1304,y:709,t:1527023366298};\\\", \\\"{x:1304,y:712,t:1527023366306};\\\", \\\"{x:1304,y:715,t:1527023366321};\\\", \\\"{x:1304,y:722,t:1527023366338};\\\", \\\"{x:1304,y:727,t:1527023366355};\\\", \\\"{x:1304,y:734,t:1527023366372};\\\", \\\"{x:1303,y:741,t:1527023366387};\\\", \\\"{x:1303,y:750,t:1527023366405};\\\", \\\"{x:1303,y:759,t:1527023366421};\\\", \\\"{x:1303,y:766,t:1527023366437};\\\", \\\"{x:1303,y:771,t:1527023366454};\\\", \\\"{x:1303,y:774,t:1527023366472};\\\", \\\"{x:1303,y:777,t:1527023366488};\\\", \\\"{x:1303,y:780,t:1527023366505};\\\", \\\"{x:1303,y:790,t:1527023366522};\\\", \\\"{x:1304,y:798,t:1527023366538};\\\", \\\"{x:1304,y:806,t:1527023366555};\\\", \\\"{x:1304,y:811,t:1527023366571};\\\", \\\"{x:1305,y:817,t:1527023366588};\\\", \\\"{x:1306,y:823,t:1527023366605};\\\", \\\"{x:1306,y:830,t:1527023366621};\\\", \\\"{x:1307,y:836,t:1527023366638};\\\", \\\"{x:1308,y:841,t:1527023366655};\\\", \\\"{x:1309,y:846,t:1527023366672};\\\", \\\"{x:1309,y:852,t:1527023366689};\\\", \\\"{x:1309,y:857,t:1527023366705};\\\", \\\"{x:1311,y:863,t:1527023366722};\\\", \\\"{x:1312,y:866,t:1527023366738};\\\", \\\"{x:1312,y:868,t:1527023366755};\\\", \\\"{x:1312,y:870,t:1527023366771};\\\", \\\"{x:1313,y:879,t:1527023366789};\\\", \\\"{x:1316,y:892,t:1527023366805};\\\", \\\"{x:1316,y:896,t:1527023366822};\\\", \\\"{x:1316,y:897,t:1527023366839};\\\", \\\"{x:1316,y:899,t:1527023366858};\\\", \\\"{x:1316,y:900,t:1527023366873};\\\", \\\"{x:1316,y:901,t:1527023366889};\\\", \\\"{x:1316,y:902,t:1527023366905};\\\", \\\"{x:1316,y:906,t:1527023366922};\\\", \\\"{x:1316,y:910,t:1527023366939};\\\", \\\"{x:1316,y:913,t:1527023366955};\\\", \\\"{x:1316,y:916,t:1527023366972};\\\", \\\"{x:1319,y:920,t:1527023366989};\\\", \\\"{x:1319,y:924,t:1527023367005};\\\", \\\"{x:1319,y:927,t:1527023367022};\\\", \\\"{x:1319,y:930,t:1527023367039};\\\", \\\"{x:1319,y:933,t:1527023367055};\\\", \\\"{x:1319,y:936,t:1527023367072};\\\", \\\"{x:1320,y:937,t:1527023367089};\\\", \\\"{x:1320,y:939,t:1527023367105};\\\", \\\"{x:1320,y:943,t:1527023367122};\\\", \\\"{x:1320,y:947,t:1527023367139};\\\", \\\"{x:1320,y:954,t:1527023367156};\\\", \\\"{x:1320,y:957,t:1527023367172};\\\", \\\"{x:1320,y:958,t:1527023367189};\\\", \\\"{x:1320,y:960,t:1527023367218};\\\", \\\"{x:1320,y:961,t:1527023367234};\\\", \\\"{x:1320,y:962,t:1527023367251};\\\", \\\"{x:1320,y:963,t:1527023367332};\\\", \\\"{x:1320,y:964,t:1527023367339};\\\", \\\"{x:1319,y:965,t:1527023367740};\\\", \\\"{x:1317,y:965,t:1527023367859};\\\", \\\"{x:1315,y:965,t:1527023367874};\\\", \\\"{x:1313,y:965,t:1527023367891};\\\", \\\"{x:1300,y:965,t:1527023369123};\\\", \\\"{x:1241,y:954,t:1527023369142};\\\", \\\"{x:1169,y:934,t:1527023369158};\\\", \\\"{x:1078,y:907,t:1527023369174};\\\", \\\"{x:968,y:882,t:1527023369192};\\\", \\\"{x:859,y:862,t:1527023369208};\\\", \\\"{x:765,y:850,t:1527023369224};\\\", \\\"{x:678,y:835,t:1527023369241};\\\", \\\"{x:596,y:817,t:1527023369257};\\\", \\\"{x:495,y:787,t:1527023369275};\\\", \\\"{x:461,y:769,t:1527023369291};\\\", \\\"{x:430,y:756,t:1527023369308};\\\", \\\"{x:409,y:746,t:1527023369325};\\\", \\\"{x:390,y:737,t:1527023369342};\\\", \\\"{x:369,y:728,t:1527023369357};\\\", \\\"{x:343,y:716,t:1527023369375};\\\", \\\"{x:302,y:700,t:1527023369391};\\\", \\\"{x:266,y:683,t:1527023369407};\\\", \\\"{x:232,y:667,t:1527023369424};\\\", \\\"{x:210,y:654,t:1527023369444};\\\", \\\"{x:202,y:646,t:1527023369458};\\\", \\\"{x:201,y:646,t:1527023369490};\\\", \\\"{x:201,y:642,t:1527023369502};\\\", \\\"{x:217,y:628,t:1527023369520};\\\", \\\"{x:234,y:617,t:1527023369537};\\\", \\\"{x:251,y:600,t:1527023369557};\\\", \\\"{x:256,y:596,t:1527023369574};\\\", \\\"{x:258,y:596,t:1527023369594};\\\", \\\"{x:259,y:591,t:1527023369608};\\\", \\\"{x:263,y:582,t:1527023369625};\\\", \\\"{x:272,y:573,t:1527023369641};\\\", \\\"{x:277,y:564,t:1527023369658};\\\", \\\"{x:279,y:559,t:1527023369674};\\\", \\\"{x:279,y:557,t:1527023369698};\\\", \\\"{x:282,y:555,t:1527023369714};\\\", \\\"{x:283,y:553,t:1527023369724};\\\", \\\"{x:288,y:548,t:1527023369740};\\\", \\\"{x:290,y:545,t:1527023369758};\\\", \\\"{x:292,y:545,t:1527023369802};\\\", \\\"{x:295,y:545,t:1527023369810};\\\", \\\"{x:301,y:545,t:1527023369824};\\\", \\\"{x:309,y:544,t:1527023369842};\\\", \\\"{x:316,y:544,t:1527023369857};\\\", \\\"{x:317,y:544,t:1527023369875};\\\", \\\"{x:318,y:544,t:1527023369915};\\\", \\\"{x:321,y:544,t:1527023369924};\\\", \\\"{x:325,y:544,t:1527023369941};\\\", \\\"{x:326,y:544,t:1527023369959};\\\", \\\"{x:327,y:544,t:1527023369974};\\\", \\\"{x:329,y:544,t:1527023369992};\\\", \\\"{x:333,y:544,t:1527023370009};\\\", \\\"{x:334,y:544,t:1527023370027};\\\", \\\"{x:336,y:544,t:1527023370041};\\\", \\\"{x:339,y:544,t:1527023370058};\\\", \\\"{x:344,y:544,t:1527023370074};\\\", \\\"{x:353,y:544,t:1527023370092};\\\", \\\"{x:359,y:544,t:1527023370109};\\\", \\\"{x:363,y:544,t:1527023370125};\\\", \\\"{x:367,y:544,t:1527023370142};\\\", \\\"{x:369,y:542,t:1527023370259};\\\", \\\"{x:371,y:540,t:1527023370275};\\\", \\\"{x:374,y:540,t:1527023370580};\\\", \\\"{x:383,y:552,t:1527023370593};\\\", \\\"{x:417,y:598,t:1527023370609};\\\", \\\"{x:467,y:653,t:1527023370625};\\\", \\\"{x:519,y:707,t:1527023370641};\\\", \\\"{x:582,y:763,t:1527023370658};\\\", \\\"{x:597,y:779,t:1527023370675};\\\", \\\"{x:604,y:784,t:1527023370691};\\\", \\\"{x:607,y:785,t:1527023370708};\\\", \\\"{x:606,y:782,t:1527023370842};\\\", \\\"{x:588,y:761,t:1527023370858};\\\", \\\"{x:553,y:720,t:1527023370875};\\\", \\\"{x:504,y:667,t:1527023370892};\\\", \\\"{x:461,y:610,t:1527023370908};\\\", \\\"{x:420,y:551,t:1527023370925};\\\", \\\"{x:385,y:510,t:1527023370942};\\\", \\\"{x:378,y:501,t:1527023370958};\\\", \\\"{x:379,y:505,t:1527023371171};\\\", \\\"{x:379,y:509,t:1527023371179};\\\", \\\"{x:380,y:512,t:1527023371192};\\\", \\\"{x:381,y:516,t:1527023371208};\\\", \\\"{x:381,y:518,t:1527023371225};\\\", \\\"{x:381,y:519,t:1527023371515};\\\", \\\"{x:383,y:522,t:1527023371526};\\\", \\\"{x:383,y:526,t:1527023371540};\\\", \\\"{x:385,y:529,t:1527023371559};\\\", \\\"{x:386,y:533,t:1527023371575};\\\", \\\"{x:387,y:536,t:1527023371592};\\\", \\\"{x:388,y:538,t:1527023371609};\\\", \\\"{x:388,y:540,t:1527023371626};\\\", \\\"{x:391,y:549,t:1527023371842};\\\", \\\"{x:408,y:604,t:1527023371859};\\\", \\\"{x:436,y:665,t:1527023371877};\\\", \\\"{x:471,y:723,t:1527023371893};\\\", \\\"{x:500,y:765,t:1527023371910};\\\", \\\"{x:517,y:786,t:1527023371926};\\\", \\\"{x:526,y:794,t:1527023371942};\\\", \\\"{x:527,y:794,t:1527023371959};\\\", \\\"{x:525,y:792,t:1527023372067};\\\", \\\"{x:520,y:787,t:1527023372077};\\\", \\\"{x:514,y:782,t:1527023372092};\\\", \\\"{x:509,y:778,t:1527023372110};\\\", \\\"{x:505,y:772,t:1527023372127};\\\", \\\"{x:503,y:767,t:1527023372142};\\\", \\\"{x:501,y:765,t:1527023372159};\\\", \\\"{x:500,y:765,t:1527023372211};\\\", \\\"{x:500,y:759,t:1527023372227};\\\", \\\"{x:500,y:751,t:1527023372243};\\\", \\\"{x:498,y:747,t:1527023372261};\\\", \\\"{x:497,y:744,t:1527023372276};\\\", \\\"{x:497,y:740,t:1527023372293};\\\", \\\"{x:496,y:737,t:1527023372310};\\\" ] }, { \\\"rt\\\": 9763, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 404818, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-09 AM-08 AM-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:736,t:1527023375436};\\\", \\\"{x:561,y:736,t:1527023375454};\\\", \\\"{x:595,y:736,t:1527023375462};\\\", \\\"{x:702,y:726,t:1527023375479};\\\", \\\"{x:821,y:707,t:1527023375495};\\\", \\\"{x:972,y:675,t:1527023375513};\\\", \\\"{x:1097,y:656,t:1527023375528};\\\", \\\"{x:1198,y:636,t:1527023375546};\\\", \\\"{x:1291,y:633,t:1527023375562};\\\", \\\"{x:1311,y:633,t:1527023375578};\\\", \\\"{x:1318,y:633,t:1527023375595};\\\", \\\"{x:1323,y:636,t:1527023375613};\\\", \\\"{x:1327,y:644,t:1527023375628};\\\", \\\"{x:1330,y:653,t:1527023375645};\\\", \\\"{x:1334,y:671,t:1527023375663};\\\", \\\"{x:1340,y:690,t:1527023375679};\\\", \\\"{x:1342,y:704,t:1527023375696};\\\", \\\"{x:1343,y:722,t:1527023375713};\\\", \\\"{x:1341,y:744,t:1527023375729};\\\", \\\"{x:1329,y:761,t:1527023375746};\\\", \\\"{x:1304,y:794,t:1527023375762};\\\", \\\"{x:1289,y:813,t:1527023375780};\\\", \\\"{x:1280,y:828,t:1527023375796};\\\", \\\"{x:1274,y:837,t:1527023375813};\\\", \\\"{x:1273,y:838,t:1527023375830};\\\", \\\"{x:1272,y:839,t:1527023375859};\\\", \\\"{x:1272,y:840,t:1527023375867};\\\", \\\"{x:1271,y:843,t:1527023375880};\\\", \\\"{x:1269,y:850,t:1527023375896};\\\", \\\"{x:1265,y:865,t:1527023375913};\\\", \\\"{x:1264,y:888,t:1527023375929};\\\", \\\"{x:1261,y:905,t:1527023375946};\\\", \\\"{x:1254,y:920,t:1527023375962};\\\", \\\"{x:1246,y:931,t:1527023375980};\\\", \\\"{x:1233,y:945,t:1527023375996};\\\", \\\"{x:1217,y:959,t:1527023376013};\\\", \\\"{x:1207,y:972,t:1527023376030};\\\", \\\"{x:1200,y:983,t:1527023376046};\\\", \\\"{x:1198,y:985,t:1527023376064};\\\", \\\"{x:1197,y:985,t:1527023376083};\\\", \\\"{x:1196,y:985,t:1527023376096};\\\", \\\"{x:1193,y:985,t:1527023376113};\\\", \\\"{x:1190,y:985,t:1527023376130};\\\", \\\"{x:1189,y:985,t:1527023376147};\\\", \\\"{x:1188,y:985,t:1527023376171};\\\", \\\"{x:1187,y:984,t:1527023376187};\\\", \\\"{x:1187,y:983,t:1527023376203};\\\", \\\"{x:1187,y:982,t:1527023376213};\\\", \\\"{x:1187,y:979,t:1527023376231};\\\", \\\"{x:1187,y:976,t:1527023376247};\\\", \\\"{x:1187,y:973,t:1527023376263};\\\", \\\"{x:1186,y:971,t:1527023376280};\\\", \\\"{x:1185,y:970,t:1527023376297};\\\", \\\"{x:1185,y:969,t:1527023376364};\\\", \\\"{x:1184,y:969,t:1527023376403};\\\", \\\"{x:1182,y:969,t:1527023376413};\\\", \\\"{x:1177,y:969,t:1527023376430};\\\", \\\"{x:1174,y:969,t:1527023376447};\\\", \\\"{x:1170,y:969,t:1527023376463};\\\", \\\"{x:1161,y:969,t:1527023376480};\\\", \\\"{x:1148,y:971,t:1527023376497};\\\", \\\"{x:1132,y:972,t:1527023376513};\\\", \\\"{x:1118,y:975,t:1527023376530};\\\", \\\"{x:1103,y:976,t:1527023376547};\\\", \\\"{x:1095,y:977,t:1527023376564};\\\", \\\"{x:1088,y:979,t:1527023376580};\\\", \\\"{x:1085,y:980,t:1527023376597};\\\", \\\"{x:1080,y:981,t:1527023376614};\\\", \\\"{x:1077,y:981,t:1527023376630};\\\", \\\"{x:1074,y:981,t:1527023376647};\\\", \\\"{x:1073,y:981,t:1527023376664};\\\", \\\"{x:1072,y:981,t:1527023376699};\\\", \\\"{x:1071,y:981,t:1527023376779};\\\", \\\"{x:1071,y:979,t:1527023376810};\\\", \\\"{x:1071,y:978,t:1527023376827};\\\", \\\"{x:1071,y:977,t:1527023376851};\\\", \\\"{x:1072,y:976,t:1527023376875};\\\", \\\"{x:1073,y:974,t:1527023376890};\\\", \\\"{x:1074,y:973,t:1527023376906};\\\", \\\"{x:1075,y:969,t:1527023377251};\\\", \\\"{x:1076,y:964,t:1527023377264};\\\", \\\"{x:1076,y:957,t:1527023377282};\\\", \\\"{x:1079,y:941,t:1527023377297};\\\", \\\"{x:1081,y:919,t:1527023377314};\\\", \\\"{x:1080,y:856,t:1527023377331};\\\", \\\"{x:1066,y:791,t:1527023377347};\\\", \\\"{x:1050,y:732,t:1527023377363};\\\", \\\"{x:1042,y:694,t:1527023377381};\\\", \\\"{x:1036,y:652,t:1527023377398};\\\", \\\"{x:1032,y:628,t:1527023377414};\\\", \\\"{x:1029,y:609,t:1527023377431};\\\", \\\"{x:1028,y:596,t:1527023377449};\\\", \\\"{x:1026,y:583,t:1527023377464};\\\", \\\"{x:1028,y:558,t:1527023377481};\\\", \\\"{x:1040,y:511,t:1527023377498};\\\", \\\"{x:1043,y:490,t:1527023377514};\\\", \\\"{x:1049,y:474,t:1527023377531};\\\", \\\"{x:1053,y:467,t:1527023377547};\\\", \\\"{x:1055,y:464,t:1527023377564};\\\", \\\"{x:1055,y:463,t:1527023377581};\\\", \\\"{x:1057,y:460,t:1527023377598};\\\", \\\"{x:1058,y:460,t:1527023377613};\\\", \\\"{x:1059,y:462,t:1527023377674};\\\", \\\"{x:1062,y:469,t:1527023377682};\\\", \\\"{x:1063,y:474,t:1527023377698};\\\", \\\"{x:1065,y:486,t:1527023377714};\\\", \\\"{x:1065,y:511,t:1527023377731};\\\", \\\"{x:1065,y:530,t:1527023377747};\\\", \\\"{x:1068,y:543,t:1527023377764};\\\", \\\"{x:1069,y:547,t:1527023377781};\\\", \\\"{x:1071,y:548,t:1527023377798};\\\", \\\"{x:1071,y:549,t:1527023377891};\\\", \\\"{x:1073,y:550,t:1527023377899};\\\", \\\"{x:1075,y:552,t:1527023377915};\\\", \\\"{x:1077,y:552,t:1527023377931};\\\", \\\"{x:1078,y:552,t:1527023377948};\\\", \\\"{x:1080,y:552,t:1527023377971};\\\", \\\"{x:1081,y:552,t:1527023377987};\\\", \\\"{x:1082,y:552,t:1527023377998};\\\", \\\"{x:1086,y:552,t:1527023378016};\\\", \\\"{x:1088,y:552,t:1527023378031};\\\", \\\"{x:1097,y:552,t:1527023378048};\\\", \\\"{x:1112,y:552,t:1527023378065};\\\", \\\"{x:1127,y:552,t:1527023378082};\\\", \\\"{x:1144,y:552,t:1527023378099};\\\", \\\"{x:1158,y:553,t:1527023378115};\\\", \\\"{x:1171,y:554,t:1527023378131};\\\", \\\"{x:1183,y:554,t:1527023378148};\\\", \\\"{x:1193,y:554,t:1527023378166};\\\", \\\"{x:1209,y:555,t:1527023378181};\\\", \\\"{x:1218,y:555,t:1527023378199};\\\", \\\"{x:1220,y:555,t:1527023378215};\\\", \\\"{x:1221,y:555,t:1527023378232};\\\", \\\"{x:1223,y:555,t:1527023378248};\\\", \\\"{x:1224,y:555,t:1527023378291};\\\", \\\"{x:1226,y:555,t:1527023378347};\\\", \\\"{x:1230,y:555,t:1527023378366};\\\", \\\"{x:1238,y:555,t:1527023378382};\\\", \\\"{x:1246,y:555,t:1527023378398};\\\", \\\"{x:1258,y:555,t:1527023378415};\\\", \\\"{x:1269,y:556,t:1527023378432};\\\", \\\"{x:1278,y:556,t:1527023378448};\\\", \\\"{x:1288,y:558,t:1527023378466};\\\", \\\"{x:1303,y:560,t:1527023378482};\\\", \\\"{x:1320,y:561,t:1527023378498};\\\", \\\"{x:1347,y:563,t:1527023378515};\\\", \\\"{x:1365,y:563,t:1527023378532};\\\", \\\"{x:1382,y:563,t:1527023378548};\\\", \\\"{x:1385,y:563,t:1527023378565};\\\", \\\"{x:1386,y:563,t:1527023378643};\\\", \\\"{x:1388,y:563,t:1527023378651};\\\", \\\"{x:1389,y:563,t:1527023378674};\\\", \\\"{x:1390,y:563,t:1527023378707};\\\", \\\"{x:1392,y:563,t:1527023378715};\\\", \\\"{x:1393,y:563,t:1527023378732};\\\", \\\"{x:1394,y:563,t:1527023378748};\\\", \\\"{x:1395,y:562,t:1527023378765};\\\", \\\"{x:1396,y:562,t:1527023379716};\\\", \\\"{x:1396,y:561,t:1527023379908};\\\", \\\"{x:1387,y:561,t:1527023379916};\\\", \\\"{x:1346,y:561,t:1527023379934};\\\", \\\"{x:1247,y:555,t:1527023379949};\\\", \\\"{x:1135,y:547,t:1527023379966};\\\", \\\"{x:1005,y:547,t:1527023379984};\\\", \\\"{x:867,y:547,t:1527023380001};\\\", \\\"{x:759,y:547,t:1527023380016};\\\", \\\"{x:660,y:552,t:1527023380034};\\\", \\\"{x:556,y:564,t:1527023380050};\\\", \\\"{x:467,y:575,t:1527023380067};\\\", \\\"{x:404,y:585,t:1527023380083};\\\", \\\"{x:389,y:587,t:1527023380100};\\\", \\\"{x:386,y:587,t:1527023380116};\\\", \\\"{x:383,y:587,t:1527023380132};\\\", \\\"{x:381,y:587,t:1527023380149};\\\", \\\"{x:378,y:587,t:1527023380166};\\\", \\\"{x:376,y:587,t:1527023380183};\\\", \\\"{x:375,y:587,t:1527023380199};\\\", \\\"{x:374,y:586,t:1527023380216};\\\", \\\"{x:370,y:585,t:1527023380233};\\\", \\\"{x:364,y:582,t:1527023380250};\\\", \\\"{x:359,y:578,t:1527023380265};\\\", \\\"{x:358,y:578,t:1527023380283};\\\", \\\"{x:356,y:577,t:1527023380300};\\\", \\\"{x:351,y:575,t:1527023380317};\\\", \\\"{x:344,y:571,t:1527023380334};\\\", \\\"{x:336,y:569,t:1527023380349};\\\", \\\"{x:331,y:565,t:1527023380366};\\\", \\\"{x:331,y:563,t:1527023380384};\\\", \\\"{x:331,y:559,t:1527023380400};\\\", \\\"{x:331,y:552,t:1527023380417};\\\", \\\"{x:334,y:545,t:1527023380433};\\\", \\\"{x:340,y:538,t:1527023380449};\\\", \\\"{x:359,y:533,t:1527023380466};\\\", \\\"{x:402,y:525,t:1527023380483};\\\", \\\"{x:483,y:516,t:1527023380501};\\\", \\\"{x:547,y:508,t:1527023380518};\\\", \\\"{x:594,y:502,t:1527023380534};\\\", \\\"{x:627,y:499,t:1527023380550};\\\", \\\"{x:643,y:496,t:1527023380567};\\\", \\\"{x:645,y:496,t:1527023380583};\\\", \\\"{x:645,y:495,t:1527023380603};\\\", \\\"{x:646,y:495,t:1527023380619};\\\", \\\"{x:646,y:494,t:1527023380700};\\\", \\\"{x:644,y:493,t:1527023380714};\\\", \\\"{x:641,y:493,t:1527023380724};\\\", \\\"{x:640,y:493,t:1527023380734};\\\", \\\"{x:637,y:493,t:1527023380750};\\\", \\\"{x:634,y:493,t:1527023380767};\\\", \\\"{x:631,y:493,t:1527023380783};\\\", \\\"{x:630,y:493,t:1527023380800};\\\", \\\"{x:631,y:494,t:1527023381122};\\\", \\\"{x:633,y:495,t:1527023381134};\\\", \\\"{x:638,y:498,t:1527023381150};\\\", \\\"{x:654,y:503,t:1527023381167};\\\", \\\"{x:683,y:507,t:1527023381183};\\\", \\\"{x:747,y:512,t:1527023381202};\\\", \\\"{x:774,y:512,t:1527023381217};\\\", \\\"{x:793,y:512,t:1527023381234};\\\", \\\"{x:811,y:518,t:1527023381251};\\\", \\\"{x:813,y:518,t:1527023381267};\\\", \\\"{x:814,y:521,t:1527023381411};\\\", \\\"{x:815,y:527,t:1527023381420};\\\", \\\"{x:815,y:540,t:1527023381434};\\\", \\\"{x:816,y:545,t:1527023381451};\\\", \\\"{x:817,y:547,t:1527023381467};\\\", \\\"{x:818,y:547,t:1527023381522};\\\", \\\"{x:820,y:547,t:1527023381534};\\\", \\\"{x:822,y:547,t:1527023381551};\\\", \\\"{x:823,y:545,t:1527023381568};\\\", \\\"{x:821,y:547,t:1527023381762};\\\", \\\"{x:812,y:555,t:1527023381771};\\\", \\\"{x:792,y:566,t:1527023381785};\\\", \\\"{x:744,y:600,t:1527023381801};\\\", \\\"{x:688,y:641,t:1527023381818};\\\", \\\"{x:659,y:657,t:1527023381834};\\\", \\\"{x:643,y:663,t:1527023381850};\\\", \\\"{x:635,y:668,t:1527023381867};\\\", \\\"{x:629,y:672,t:1527023381885};\\\", \\\"{x:627,y:675,t:1527023381901};\\\", \\\"{x:624,y:679,t:1527023381918};\\\", \\\"{x:621,y:687,t:1527023381935};\\\", \\\"{x:615,y:696,t:1527023381951};\\\", \\\"{x:606,y:704,t:1527023381968};\\\", \\\"{x:594,y:714,t:1527023381985};\\\", \\\"{x:579,y:724,t:1527023382001};\\\", \\\"{x:559,y:734,t:1527023382018};\\\", \\\"{x:542,y:740,t:1527023382035};\\\", \\\"{x:540,y:740,t:1527023382050};\\\", \\\"{x:545,y:737,t:1527023382068};\\\", \\\"{x:583,y:686,t:1527023382085};\\\", \\\"{x:647,y:611,t:1527023382102};\\\", \\\"{x:706,y:556,t:1527023382118};\\\", \\\"{x:754,y:531,t:1527023382135};\\\", \\\"{x:792,y:518,t:1527023382151};\\\", \\\"{x:811,y:513,t:1527023382168};\\\", \\\"{x:827,y:510,t:1527023382185};\\\", \\\"{x:831,y:510,t:1527023382202};\\\", \\\"{x:832,y:509,t:1527023382218};\\\", \\\"{x:833,y:509,t:1527023382258};\\\", \\\"{x:834,y:509,t:1527023382268};\\\", \\\"{x:838,y:509,t:1527023382285};\\\", \\\"{x:840,y:509,t:1527023382301};\\\", \\\"{x:842,y:511,t:1527023382317};\\\", \\\"{x:846,y:515,t:1527023382335};\\\", \\\"{x:849,y:520,t:1527023382353};\\\", \\\"{x:852,y:526,t:1527023382368};\\\", \\\"{x:853,y:531,t:1527023382385};\\\", \\\"{x:853,y:537,t:1527023382402};\\\", \\\"{x:853,y:544,t:1527023382417};\\\", \\\"{x:852,y:548,t:1527023382435};\\\", \\\"{x:852,y:549,t:1527023382810};\\\", \\\"{x:850,y:549,t:1527023382843};\\\", \\\"{x:849,y:549,t:1527023382858};\\\", \\\"{x:847,y:549,t:1527023382874};\\\", \\\"{x:844,y:548,t:1527023382885};\\\", \\\"{x:831,y:548,t:1527023382902};\\\", \\\"{x:812,y:548,t:1527023382921};\\\", \\\"{x:778,y:558,t:1527023382936};\\\", \\\"{x:731,y:578,t:1527023382952};\\\", \\\"{x:682,y:599,t:1527023382968};\\\", \\\"{x:624,y:620,t:1527023382985};\\\", \\\"{x:501,y:678,t:1527023383002};\\\", \\\"{x:421,y:708,t:1527023383019};\\\", \\\"{x:386,y:722,t:1527023383035};\\\", \\\"{x:380,y:725,t:1527023383051};\\\", \\\"{x:383,y:728,t:1527023383162};\\\", \\\"{x:387,y:730,t:1527023383170};\\\", \\\"{x:392,y:737,t:1527023383185};\\\", \\\"{x:402,y:746,t:1527023383202};\\\", \\\"{x:424,y:756,t:1527023383218};\\\", \\\"{x:441,y:759,t:1527023383234};\\\", \\\"{x:448,y:759,t:1527023383252};\\\", \\\"{x:460,y:756,t:1527023383269};\\\", \\\"{x:473,y:752,t:1527023383286};\\\", \\\"{x:484,y:747,t:1527023383302};\\\", \\\"{x:490,y:744,t:1527023383318};\\\" ] }, { \\\"rt\\\": 34879, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 440950, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:567,y:592,t:1527023384726};\\\", \\\"{x:582,y:555,t:1527023384737};\\\", \\\"{x:653,y:445,t:1527023384754};\\\", \\\"{x:708,y:372,t:1527023384770};\\\", \\\"{x:777,y:313,t:1527023384786};\\\", \\\"{x:864,y:241,t:1527023384816};\\\", \\\"{x:899,y:218,t:1527023384819};\\\", \\\"{x:961,y:186,t:1527023384836};\\\", \\\"{x:1007,y:171,t:1527023384854};\\\", \\\"{x:1019,y:167,t:1527023384870};\\\", \\\"{x:1019,y:177,t:1527023384938};\\\", \\\"{x:1020,y:192,t:1527023384953};\\\", \\\"{x:1020,y:226,t:1527023384970};\\\", \\\"{x:1022,y:236,t:1527023384987};\\\", \\\"{x:1022,y:237,t:1527023385283};\\\", \\\"{x:1024,y:238,t:1527023385290};\\\", \\\"{x:1024,y:240,t:1527023385303};\\\", \\\"{x:1032,y:258,t:1527023385320};\\\", \\\"{x:1037,y:282,t:1527023385337};\\\", \\\"{x:1039,y:304,t:1527023385353};\\\", \\\"{x:1034,y:367,t:1527023385370};\\\", \\\"{x:1013,y:421,t:1527023385386};\\\", \\\"{x:975,y:472,t:1527023385403};\\\", \\\"{x:922,y:519,t:1527023385420};\\\", \\\"{x:863,y:562,t:1527023385437};\\\", \\\"{x:810,y:600,t:1527023385453};\\\", \\\"{x:775,y:628,t:1527023385471};\\\", \\\"{x:758,y:641,t:1527023385487};\\\", \\\"{x:757,y:643,t:1527023385504};\\\", \\\"{x:757,y:644,t:1527023385522};\\\", \\\"{x:756,y:644,t:1527023386307};\\\", \\\"{x:755,y:644,t:1527023386322};\\\", \\\"{x:753,y:644,t:1527023386435};\\\", \\\"{x:751,y:646,t:1527023386458};\\\", \\\"{x:750,y:646,t:1527023386483};\\\", \\\"{x:749,y:647,t:1527023386490};\\\", \\\"{x:748,y:647,t:1527023386506};\\\", \\\"{x:746,y:647,t:1527023386522};\\\", \\\"{x:743,y:649,t:1527023386539};\\\", \\\"{x:742,y:649,t:1527023386556};\\\", \\\"{x:740,y:649,t:1527023386572};\\\", \\\"{x:739,y:649,t:1527023386588};\\\", \\\"{x:738,y:649,t:1527023386605};\\\", \\\"{x:737,y:649,t:1527023386621};\\\", \\\"{x:736,y:649,t:1527023386638};\\\", \\\"{x:735,y:649,t:1527023387027};\\\", \\\"{x:734,y:649,t:1527023387038};\\\", \\\"{x:733,y:649,t:1527023387055};\\\", \\\"{x:730,y:649,t:1527023387073};\\\", \\\"{x:728,y:649,t:1527023387088};\\\", \\\"{x:727,y:649,t:1527023387105};\\\", \\\"{x:721,y:649,t:1527023387122};\\\", \\\"{x:713,y:649,t:1527023387138};\\\", \\\"{x:705,y:649,t:1527023387155};\\\", \\\"{x:698,y:648,t:1527023387173};\\\", \\\"{x:690,y:644,t:1527023387189};\\\", \\\"{x:680,y:635,t:1527023387205};\\\", \\\"{x:664,y:617,t:1527023387224};\\\", \\\"{x:650,y:603,t:1527023387239};\\\", \\\"{x:634,y:591,t:1527023387255};\\\", \\\"{x:621,y:580,t:1527023387272};\\\", \\\"{x:610,y:571,t:1527023387289};\\\", \\\"{x:590,y:552,t:1527023387306};\\\", \\\"{x:577,y:539,t:1527023387323};\\\", \\\"{x:568,y:527,t:1527023387339};\\\", \\\"{x:563,y:521,t:1527023387356};\\\", \\\"{x:560,y:518,t:1527023387372};\\\", \\\"{x:557,y:515,t:1527023387390};\\\", \\\"{x:555,y:513,t:1527023387406};\\\", \\\"{x:548,y:509,t:1527023387422};\\\", \\\"{x:539,y:503,t:1527023387439};\\\", \\\"{x:525,y:497,t:1527023387456};\\\", \\\"{x:509,y:492,t:1527023387472};\\\", \\\"{x:497,y:487,t:1527023387489};\\\", \\\"{x:489,y:483,t:1527023387506};\\\", \\\"{x:482,y:480,t:1527023387523};\\\", \\\"{x:477,y:478,t:1527023387539};\\\", \\\"{x:470,y:474,t:1527023387555};\\\", \\\"{x:466,y:473,t:1527023387572};\\\", \\\"{x:464,y:472,t:1527023387589};\\\", \\\"{x:463,y:472,t:1527023387606};\\\", \\\"{x:462,y:471,t:1527023387651};\\\", \\\"{x:461,y:471,t:1527023387811};\\\", \\\"{x:459,y:471,t:1527023387875};\\\", \\\"{x:458,y:470,t:1527023387907};\\\", \\\"{x:457,y:470,t:1527023387947};\\\", \\\"{x:456,y:469,t:1527023387956};\\\", \\\"{x:455,y:469,t:1527023387974};\\\", \\\"{x:453,y:468,t:1527023387989};\\\", \\\"{x:453,y:467,t:1527023388107};\\\", \\\"{x:453,y:466,t:1527023388130};\\\", \\\"{x:453,y:465,t:1527023388154};\\\", \\\"{x:453,y:464,t:1527023388171};\\\", \\\"{x:454,y:463,t:1527023388187};\\\", \\\"{x:455,y:462,t:1527023388211};\\\", \\\"{x:456,y:462,t:1527023388234};\\\", \\\"{x:457,y:461,t:1527023388283};\\\", \\\"{x:458,y:460,t:1527023388315};\\\", \\\"{x:459,y:460,t:1527023388347};\\\", \\\"{x:460,y:460,t:1527023388357};\\\", \\\"{x:461,y:459,t:1527023388373};\\\", \\\"{x:463,y:459,t:1527023388391};\\\", \\\"{x:466,y:459,t:1527023388407};\\\", \\\"{x:470,y:459,t:1527023388423};\\\", \\\"{x:473,y:458,t:1527023388440};\\\", \\\"{x:475,y:458,t:1527023388457};\\\", \\\"{x:477,y:458,t:1527023388473};\\\", \\\"{x:483,y:458,t:1527023388490};\\\", \\\"{x:488,y:457,t:1527023388507};\\\", \\\"{x:491,y:456,t:1527023388524};\\\", \\\"{x:495,y:456,t:1527023388541};\\\", \\\"{x:500,y:455,t:1527023388558};\\\", \\\"{x:505,y:455,t:1527023388573};\\\", \\\"{x:506,y:455,t:1527023388591};\\\", \\\"{x:508,y:454,t:1527023388607};\\\", \\\"{x:509,y:454,t:1527023388627};\\\", \\\"{x:510,y:454,t:1527023388641};\\\", \\\"{x:512,y:453,t:1527023388657};\\\", \\\"{x:514,y:453,t:1527023388673};\\\", \\\"{x:519,y:451,t:1527023388691};\\\", \\\"{x:534,y:451,t:1527023388707};\\\", \\\"{x:564,y:451,t:1527023388724};\\\", \\\"{x:597,y:447,t:1527023388740};\\\", \\\"{x:613,y:443,t:1527023388758};\\\", \\\"{x:614,y:443,t:1527023389107};\\\", \\\"{x:616,y:443,t:1527023389275};\\\", \\\"{x:619,y:443,t:1527023389291};\\\", \\\"{x:620,y:443,t:1527023389308};\\\", \\\"{x:621,y:443,t:1527023389324};\\\", \\\"{x:621,y:444,t:1527023392043};\\\", \\\"{x:621,y:445,t:1527023392483};\\\", \\\"{x:622,y:445,t:1527023392493};\\\", \\\"{x:624,y:445,t:1527023392511};\\\", \\\"{x:626,y:445,t:1527023392527};\\\", \\\"{x:627,y:445,t:1527023392544};\\\", \\\"{x:629,y:445,t:1527023392560};\\\", \\\"{x:630,y:445,t:1527023392576};\\\", \\\"{x:632,y:445,t:1527023392593};\\\", \\\"{x:637,y:445,t:1527023392610};\\\", \\\"{x:642,y:444,t:1527023392627};\\\", \\\"{x:649,y:443,t:1527023392643};\\\", \\\"{x:656,y:440,t:1527023392661};\\\", \\\"{x:663,y:438,t:1527023392677};\\\", \\\"{x:667,y:437,t:1527023392693};\\\", \\\"{x:674,y:435,t:1527023392711};\\\", \\\"{x:680,y:434,t:1527023392727};\\\", \\\"{x:687,y:432,t:1527023392743};\\\", \\\"{x:689,y:430,t:1527023392760};\\\", \\\"{x:691,y:429,t:1527023392777};\\\", \\\"{x:689,y:429,t:1527023394682};\\\", \\\"{x:684,y:429,t:1527023394695};\\\", \\\"{x:675,y:430,t:1527023394712};\\\", \\\"{x:666,y:431,t:1527023394729};\\\", \\\"{x:659,y:433,t:1527023394745};\\\", \\\"{x:653,y:434,t:1527023394761};\\\", \\\"{x:642,y:435,t:1527023394778};\\\", \\\"{x:634,y:437,t:1527023394795};\\\", \\\"{x:629,y:439,t:1527023394812};\\\", \\\"{x:622,y:441,t:1527023394829};\\\", \\\"{x:618,y:442,t:1527023394845};\\\", \\\"{x:613,y:443,t:1527023394862};\\\", \\\"{x:610,y:443,t:1527023394879};\\\", \\\"{x:609,y:443,t:1527023394898};\\\", \\\"{x:608,y:444,t:1527023394912};\\\", \\\"{x:608,y:445,t:1527023395259};\\\", \\\"{x:620,y:441,t:1527023395267};\\\", \\\"{x:650,y:436,t:1527023395280};\\\", \\\"{x:750,y:422,t:1527023395296};\\\", \\\"{x:860,y:412,t:1527023395313};\\\", \\\"{x:970,y:396,t:1527023395329};\\\", \\\"{x:1100,y:381,t:1527023395346};\\\", \\\"{x:1326,y:370,t:1527023395363};\\\", \\\"{x:1469,y:370,t:1527023395379};\\\", \\\"{x:1617,y:371,t:1527023395396};\\\", \\\"{x:1750,y:393,t:1527023395413};\\\", \\\"{x:1851,y:412,t:1527023395429};\\\", \\\"{x:1898,y:422,t:1527023395445};\\\", \\\"{x:1919,y:429,t:1527023395462};\\\", \\\"{x:1919,y:439,t:1527023395479};\\\", \\\"{x:1919,y:454,t:1527023395495};\\\", \\\"{x:1919,y:472,t:1527023395512};\\\", \\\"{x:1919,y:486,t:1527023395529};\\\", \\\"{x:1919,y:504,t:1527023395546};\\\", \\\"{x:1917,y:518,t:1527023395564};\\\", \\\"{x:1905,y:535,t:1527023395579};\\\", \\\"{x:1887,y:552,t:1527023395597};\\\", \\\"{x:1870,y:565,t:1527023395613};\\\", \\\"{x:1852,y:575,t:1527023395629};\\\", \\\"{x:1830,y:583,t:1527023395647};\\\", \\\"{x:1806,y:588,t:1527023395663};\\\", \\\"{x:1779,y:593,t:1527023395680};\\\", \\\"{x:1760,y:597,t:1527023395697};\\\", \\\"{x:1745,y:597,t:1527023395713};\\\", \\\"{x:1723,y:597,t:1527023395730};\\\", \\\"{x:1696,y:597,t:1527023395747};\\\", \\\"{x:1680,y:596,t:1527023395763};\\\", \\\"{x:1661,y:595,t:1527023395780};\\\", \\\"{x:1645,y:595,t:1527023395797};\\\", \\\"{x:1632,y:594,t:1527023395812};\\\", \\\"{x:1622,y:593,t:1527023395830};\\\", \\\"{x:1617,y:592,t:1527023395846};\\\", \\\"{x:1608,y:591,t:1527023395862};\\\", \\\"{x:1598,y:590,t:1527023395880};\\\", \\\"{x:1585,y:587,t:1527023395897};\\\", \\\"{x:1567,y:585,t:1527023395912};\\\", \\\"{x:1544,y:583,t:1527023395929};\\\", \\\"{x:1501,y:583,t:1527023395946};\\\", \\\"{x:1459,y:583,t:1527023395963};\\\", \\\"{x:1412,y:583,t:1527023395980};\\\", \\\"{x:1364,y:583,t:1527023395997};\\\", \\\"{x:1327,y:583,t:1527023396013};\\\", \\\"{x:1302,y:583,t:1527023396029};\\\", \\\"{x:1266,y:583,t:1527023396047};\\\", \\\"{x:1227,y:583,t:1527023396063};\\\", \\\"{x:1196,y:583,t:1527023396080};\\\", \\\"{x:1174,y:584,t:1527023396097};\\\", \\\"{x:1162,y:585,t:1527023396114};\\\", \\\"{x:1154,y:585,t:1527023396130};\\\", \\\"{x:1153,y:585,t:1527023396147};\\\", \\\"{x:1152,y:585,t:1527023396194};\\\", \\\"{x:1151,y:585,t:1527023396243};\\\", \\\"{x:1150,y:585,t:1527023396259};\\\", \\\"{x:1149,y:585,t:1527023396267};\\\", \\\"{x:1147,y:585,t:1527023396283};\\\", \\\"{x:1146,y:585,t:1527023396297};\\\", \\\"{x:1140,y:590,t:1527023396314};\\\", \\\"{x:1132,y:605,t:1527023396330};\\\", \\\"{x:1124,y:616,t:1527023396346};\\\", \\\"{x:1116,y:628,t:1527023396364};\\\", \\\"{x:1111,y:640,t:1527023396379};\\\", \\\"{x:1106,y:652,t:1527023396396};\\\", \\\"{x:1105,y:666,t:1527023396413};\\\", \\\"{x:1104,y:677,t:1527023396431};\\\", \\\"{x:1101,y:689,t:1527023396446};\\\", \\\"{x:1100,y:701,t:1527023396464};\\\", \\\"{x:1099,y:709,t:1527023396481};\\\", \\\"{x:1097,y:717,t:1527023396496};\\\", \\\"{x:1097,y:728,t:1527023396513};\\\", \\\"{x:1094,y:748,t:1527023396530};\\\", \\\"{x:1090,y:761,t:1527023396547};\\\", \\\"{x:1086,y:771,t:1527023396563};\\\", \\\"{x:1084,y:779,t:1527023396580};\\\", \\\"{x:1082,y:787,t:1527023396597};\\\", \\\"{x:1081,y:798,t:1527023396613};\\\", \\\"{x:1081,y:806,t:1527023396631};\\\", \\\"{x:1081,y:813,t:1527023396647};\\\", \\\"{x:1081,y:821,t:1527023396664};\\\", \\\"{x:1081,y:829,t:1527023396681};\\\", \\\"{x:1081,y:834,t:1527023396697};\\\", \\\"{x:1078,y:841,t:1527023396714};\\\", \\\"{x:1077,y:848,t:1527023396730};\\\", \\\"{x:1077,y:854,t:1527023396747};\\\", \\\"{x:1077,y:865,t:1527023396763};\\\", \\\"{x:1077,y:874,t:1527023396781};\\\", \\\"{x:1076,y:879,t:1527023396797};\\\", \\\"{x:1074,y:882,t:1527023396814};\\\", \\\"{x:1074,y:885,t:1527023396831};\\\", \\\"{x:1074,y:887,t:1527023396847};\\\", \\\"{x:1074,y:890,t:1527023396864};\\\", \\\"{x:1074,y:892,t:1527023396882};\\\", \\\"{x:1074,y:894,t:1527023396898};\\\", \\\"{x:1074,y:895,t:1527023396915};\\\", \\\"{x:1074,y:898,t:1527023396930};\\\", \\\"{x:1075,y:902,t:1527023396948};\\\", \\\"{x:1075,y:903,t:1527023396964};\\\", \\\"{x:1075,y:904,t:1527023396981};\\\", \\\"{x:1075,y:905,t:1527023396998};\\\", \\\"{x:1077,y:906,t:1527023397014};\\\", \\\"{x:1077,y:907,t:1527023397031};\\\", \\\"{x:1077,y:906,t:1527023397450};\\\", \\\"{x:1077,y:905,t:1527023397467};\\\", \\\"{x:1077,y:904,t:1527023397483};\\\", \\\"{x:1077,y:902,t:1527023397498};\\\", \\\"{x:1077,y:901,t:1527023397515};\\\", \\\"{x:1077,y:900,t:1527023397531};\\\", \\\"{x:1077,y:899,t:1527023397578};\\\", \\\"{x:1076,y:898,t:1527023397627};\\\", \\\"{x:1076,y:897,t:1527023397651};\\\", \\\"{x:1076,y:896,t:1527023397691};\\\", \\\"{x:1076,y:894,t:1527023397699};\\\", \\\"{x:1076,y:893,t:1527023397771};\\\", \\\"{x:1076,y:892,t:1527023397795};\\\", \\\"{x:1076,y:891,t:1527023397803};\\\", \\\"{x:1076,y:890,t:1527023397819};\\\", \\\"{x:1076,y:889,t:1527023397851};\\\", \\\"{x:1076,y:888,t:1527023397883};\\\", \\\"{x:1075,y:887,t:1527023397923};\\\", \\\"{x:1074,y:885,t:1527023398355};\\\", \\\"{x:1074,y:884,t:1527023398373};\\\", \\\"{x:1074,y:882,t:1527023398398};\\\", \\\"{x:1074,y:880,t:1527023398590};\\\", \\\"{x:1074,y:878,t:1527023398602};\\\", \\\"{x:1074,y:876,t:1527023398619};\\\", \\\"{x:1075,y:872,t:1527023398635};\\\", \\\"{x:1075,y:868,t:1527023398652};\\\", \\\"{x:1075,y:865,t:1527023398669};\\\", \\\"{x:1075,y:860,t:1527023398685};\\\", \\\"{x:1075,y:853,t:1527023398701};\\\", \\\"{x:1075,y:848,t:1527023398719};\\\", \\\"{x:1075,y:843,t:1527023398735};\\\", \\\"{x:1075,y:838,t:1527023398752};\\\", \\\"{x:1075,y:835,t:1527023398769};\\\", \\\"{x:1075,y:832,t:1527023398785};\\\", \\\"{x:1075,y:831,t:1527023398813};\\\", \\\"{x:1075,y:830,t:1527023398845};\\\", \\\"{x:1076,y:830,t:1527023400566};\\\", \\\"{x:1077,y:830,t:1527023400574};\\\", \\\"{x:1078,y:830,t:1527023400587};\\\", \\\"{x:1079,y:830,t:1527023400603};\\\", \\\"{x:1080,y:830,t:1527023400620};\\\", \\\"{x:1082,y:830,t:1527023400637};\\\", \\\"{x:1083,y:829,t:1527023400750};\\\", \\\"{x:1083,y:828,t:1527023400838};\\\", \\\"{x:1082,y:827,t:1527023400855};\\\", \\\"{x:1079,y:825,t:1527023400870};\\\", \\\"{x:1079,y:824,t:1527023400887};\\\", \\\"{x:1076,y:821,t:1527023400904};\\\", \\\"{x:1073,y:816,t:1527023400920};\\\", \\\"{x:1067,y:809,t:1527023400937};\\\", \\\"{x:1062,y:799,t:1527023400954};\\\", \\\"{x:1057,y:789,t:1527023400970};\\\", \\\"{x:1050,y:774,t:1527023400987};\\\", \\\"{x:1045,y:758,t:1527023401004};\\\", \\\"{x:1040,y:740,t:1527023401020};\\\", \\\"{x:1036,y:719,t:1527023401037};\\\", \\\"{x:1036,y:699,t:1527023401053};\\\", \\\"{x:1036,y:692,t:1527023401070};\\\", \\\"{x:1036,y:688,t:1527023401087};\\\", \\\"{x:1036,y:683,t:1527023401104};\\\", \\\"{x:1036,y:679,t:1527023401120};\\\", \\\"{x:1036,y:675,t:1527023401137};\\\", \\\"{x:1037,y:670,t:1527023401154};\\\", \\\"{x:1037,y:667,t:1527023401170};\\\", \\\"{x:1038,y:663,t:1527023401187};\\\", \\\"{x:1038,y:659,t:1527023401204};\\\", \\\"{x:1039,y:653,t:1527023401220};\\\", \\\"{x:1041,y:649,t:1527023401237};\\\", \\\"{x:1045,y:640,t:1527023401253};\\\", \\\"{x:1046,y:636,t:1527023401270};\\\", \\\"{x:1046,y:633,t:1527023401287};\\\", \\\"{x:1048,y:631,t:1527023401304};\\\", \\\"{x:1048,y:630,t:1527023401373};\\\", \\\"{x:1049,y:629,t:1527023401388};\\\", \\\"{x:1049,y:627,t:1527023401412};\\\", \\\"{x:1049,y:626,t:1527023401429};\\\", \\\"{x:1051,y:624,t:1527023401436};\\\", \\\"{x:1051,y:621,t:1527023401453};\\\", \\\"{x:1051,y:619,t:1527023401471};\\\", \\\"{x:1051,y:617,t:1527023401487};\\\", \\\"{x:1052,y:617,t:1527023401504};\\\", \\\"{x:1052,y:616,t:1527023401606};\\\", \\\"{x:1052,y:614,t:1527023401638};\\\", \\\"{x:1057,y:618,t:1527023402941};\\\", \\\"{x:1076,y:632,t:1527023402955};\\\", \\\"{x:1150,y:662,t:1527023402972};\\\", \\\"{x:1230,y:696,t:1527023402988};\\\", \\\"{x:1340,y:734,t:1527023403005};\\\", \\\"{x:1393,y:751,t:1527023403021};\\\", \\\"{x:1414,y:756,t:1527023403039};\\\", \\\"{x:1432,y:759,t:1527023403055};\\\", \\\"{x:1441,y:759,t:1527023403072};\\\", \\\"{x:1443,y:759,t:1527023403090};\\\", \\\"{x:1444,y:758,t:1527023403150};\\\", \\\"{x:1445,y:756,t:1527023403158};\\\", \\\"{x:1445,y:753,t:1527023403172};\\\", \\\"{x:1446,y:741,t:1527023403189};\\\", \\\"{x:1446,y:737,t:1527023403205};\\\", \\\"{x:1439,y:727,t:1527023403221};\\\", \\\"{x:1429,y:721,t:1527023403239};\\\", \\\"{x:1419,y:716,t:1527023403255};\\\", \\\"{x:1403,y:711,t:1527023403272};\\\", \\\"{x:1389,y:709,t:1527023403289};\\\", \\\"{x:1379,y:708,t:1527023403305};\\\", \\\"{x:1372,y:707,t:1527023403322};\\\", \\\"{x:1370,y:705,t:1527023403339};\\\", \\\"{x:1368,y:705,t:1527023403356};\\\", \\\"{x:1367,y:705,t:1527023403372};\\\", \\\"{x:1366,y:705,t:1527023403389};\\\", \\\"{x:1365,y:705,t:1527023403405};\\\", \\\"{x:1365,y:704,t:1527023403646};\\\", \\\"{x:1363,y:704,t:1527023403656};\\\", \\\"{x:1360,y:701,t:1527023403672};\\\", \\\"{x:1358,y:700,t:1527023403689};\\\", \\\"{x:1356,y:699,t:1527023403706};\\\", \\\"{x:1354,y:699,t:1527023404901};\\\", \\\"{x:1352,y:699,t:1527023404912};\\\", \\\"{x:1350,y:701,t:1527023407789};\\\", \\\"{x:1350,y:704,t:1527023407799};\\\", \\\"{x:1349,y:706,t:1527023407809};\\\", \\\"{x:1348,y:711,t:1527023407825};\\\", \\\"{x:1347,y:715,t:1527023407842};\\\", \\\"{x:1346,y:720,t:1527023407859};\\\", \\\"{x:1344,y:724,t:1527023407876};\\\", \\\"{x:1343,y:727,t:1527023407892};\\\", \\\"{x:1338,y:740,t:1527023407910};\\\", \\\"{x:1322,y:759,t:1527023407925};\\\", \\\"{x:1302,y:781,t:1527023407942};\\\", \\\"{x:1270,y:811,t:1527023407959};\\\", \\\"{x:1248,y:831,t:1527023407976};\\\", \\\"{x:1225,y:846,t:1527023407992};\\\", \\\"{x:1204,y:857,t:1527023408010};\\\", \\\"{x:1189,y:863,t:1527023408026};\\\", \\\"{x:1182,y:866,t:1527023408043};\\\", \\\"{x:1181,y:867,t:1527023408059};\\\", \\\"{x:1182,y:868,t:1527023408125};\\\", \\\"{x:1184,y:869,t:1527023408142};\\\", \\\"{x:1187,y:869,t:1527023408159};\\\", \\\"{x:1196,y:869,t:1527023408177};\\\", \\\"{x:1212,y:869,t:1527023408193};\\\", \\\"{x:1229,y:863,t:1527023408210};\\\", \\\"{x:1242,y:859,t:1527023408226};\\\", \\\"{x:1251,y:857,t:1527023408242};\\\", \\\"{x:1257,y:853,t:1527023408260};\\\", \\\"{x:1261,y:851,t:1527023408276};\\\", \\\"{x:1262,y:850,t:1527023408292};\\\", \\\"{x:1263,y:848,t:1527023408310};\\\", \\\"{x:1264,y:847,t:1527023408333};\\\", \\\"{x:1264,y:846,t:1527023408342};\\\", \\\"{x:1266,y:843,t:1527023408359};\\\", \\\"{x:1267,y:842,t:1527023408376};\\\", \\\"{x:1267,y:840,t:1527023408397};\\\", \\\"{x:1268,y:840,t:1527023408413};\\\", \\\"{x:1268,y:839,t:1527023408429};\\\", \\\"{x:1269,y:838,t:1527023408453};\\\", \\\"{x:1270,y:837,t:1527023408494};\\\", \\\"{x:1270,y:836,t:1527023408542};\\\", \\\"{x:1271,y:836,t:1527023408549};\\\", \\\"{x:1272,y:835,t:1527023408559};\\\", \\\"{x:1274,y:834,t:1527023408577};\\\", \\\"{x:1280,y:832,t:1527023408593};\\\", \\\"{x:1284,y:828,t:1527023408609};\\\", \\\"{x:1292,y:826,t:1527023408626};\\\", \\\"{x:1300,y:822,t:1527023408643};\\\", \\\"{x:1309,y:817,t:1527023408659};\\\", \\\"{x:1319,y:809,t:1527023408677};\\\", \\\"{x:1331,y:801,t:1527023408694};\\\", \\\"{x:1341,y:790,t:1527023408709};\\\", \\\"{x:1347,y:783,t:1527023408726};\\\", \\\"{x:1351,y:776,t:1527023408744};\\\", \\\"{x:1356,y:769,t:1527023408760};\\\", \\\"{x:1358,y:765,t:1527023408776};\\\", \\\"{x:1358,y:764,t:1527023408794};\\\", \\\"{x:1359,y:764,t:1527023408811};\\\", \\\"{x:1359,y:763,t:1527023408827};\\\", \\\"{x:1359,y:762,t:1527023408854};\\\", \\\"{x:1359,y:761,t:1527023408861};\\\", \\\"{x:1359,y:760,t:1527023408894};\\\", \\\"{x:1359,y:759,t:1527023409590};\\\", \\\"{x:1359,y:758,t:1527023409598};\\\", \\\"{x:1358,y:758,t:1527023409645};\\\", \\\"{x:1358,y:759,t:1527023409661};\\\", \\\"{x:1357,y:759,t:1527023409677};\\\", \\\"{x:1356,y:760,t:1527023409702};\\\", \\\"{x:1356,y:761,t:1527023411461};\\\", \\\"{x:1363,y:762,t:1527023411478};\\\", \\\"{x:1372,y:765,t:1527023411495};\\\", \\\"{x:1389,y:770,t:1527023411512};\\\", \\\"{x:1410,y:776,t:1527023411528};\\\", \\\"{x:1432,y:782,t:1527023411545};\\\", \\\"{x:1458,y:789,t:1527023411562};\\\", \\\"{x:1483,y:796,t:1527023411578};\\\", \\\"{x:1501,y:800,t:1527023411595};\\\", \\\"{x:1509,y:803,t:1527023411612};\\\", \\\"{x:1517,y:804,t:1527023411628};\\\", \\\"{x:1518,y:804,t:1527023411645};\\\", \\\"{x:1517,y:804,t:1527023411782};\\\", \\\"{x:1513,y:805,t:1527023411795};\\\", \\\"{x:1507,y:805,t:1527023411813};\\\", \\\"{x:1501,y:807,t:1527023411829};\\\", \\\"{x:1498,y:807,t:1527023411845};\\\", \\\"{x:1497,y:807,t:1527023411926};\\\", \\\"{x:1497,y:804,t:1527023411933};\\\", \\\"{x:1497,y:798,t:1527023411946};\\\", \\\"{x:1499,y:786,t:1527023411962};\\\", \\\"{x:1499,y:780,t:1527023411980};\\\", \\\"{x:1499,y:776,t:1527023411996};\\\", \\\"{x:1499,y:774,t:1527023412013};\\\", \\\"{x:1499,y:773,t:1527023412029};\\\", \\\"{x:1500,y:773,t:1527023412150};\\\", \\\"{x:1500,y:772,t:1527023412189};\\\", \\\"{x:1501,y:771,t:1527023412197};\\\", \\\"{x:1503,y:770,t:1527023412229};\\\", \\\"{x:1504,y:770,t:1527023412246};\\\", \\\"{x:1505,y:770,t:1527023412262};\\\", \\\"{x:1505,y:769,t:1527023412280};\\\", \\\"{x:1506,y:768,t:1527023412296};\\\", \\\"{x:1507,y:768,t:1527023412318};\\\", \\\"{x:1508,y:768,t:1527023412330};\\\", \\\"{x:1510,y:767,t:1527023412346};\\\", \\\"{x:1511,y:767,t:1527023412362};\\\", \\\"{x:1509,y:768,t:1527023415295};\\\", \\\"{x:1503,y:770,t:1527023415301};\\\", \\\"{x:1490,y:777,t:1527023415314};\\\", \\\"{x:1443,y:801,t:1527023415331};\\\", \\\"{x:1367,y:838,t:1527023415348};\\\", \\\"{x:1259,y:867,t:1527023415364};\\\", \\\"{x:1026,y:900,t:1527023415381};\\\", \\\"{x:868,y:900,t:1527023415398};\\\", \\\"{x:735,y:900,t:1527023415414};\\\", \\\"{x:629,y:897,t:1527023415431};\\\", \\\"{x:548,y:882,t:1527023415448};\\\", \\\"{x:482,y:868,t:1527023415464};\\\", \\\"{x:443,y:857,t:1527023415481};\\\", \\\"{x:419,y:843,t:1527023415498};\\\", \\\"{x:408,y:837,t:1527023415515};\\\", \\\"{x:404,y:834,t:1527023415531};\\\", \\\"{x:402,y:833,t:1527023415548};\\\", \\\"{x:397,y:827,t:1527023415565};\\\", \\\"{x:393,y:823,t:1527023415581};\\\", \\\"{x:388,y:812,t:1527023415598};\\\", \\\"{x:384,y:803,t:1527023415616};\\\", \\\"{x:383,y:790,t:1527023415632};\\\", \\\"{x:383,y:779,t:1527023415648};\\\", \\\"{x:386,y:763,t:1527023415665};\\\", \\\"{x:392,y:745,t:1527023415681};\\\", \\\"{x:399,y:733,t:1527023415698};\\\", \\\"{x:404,y:718,t:1527023415715};\\\", \\\"{x:409,y:701,t:1527023415731};\\\", \\\"{x:413,y:682,t:1527023415748};\\\", \\\"{x:418,y:665,t:1527023415766};\\\", \\\"{x:418,y:662,t:1527023415781};\\\", \\\"{x:419,y:658,t:1527023415797};\\\", \\\"{x:420,y:654,t:1527023415815};\\\", \\\"{x:420,y:650,t:1527023415832};\\\", \\\"{x:418,y:646,t:1527023415849};\\\", \\\"{x:415,y:643,t:1527023415865};\\\", \\\"{x:414,y:641,t:1527023415882};\\\", \\\"{x:412,y:638,t:1527023415899};\\\", \\\"{x:410,y:634,t:1527023415916};\\\", \\\"{x:406,y:626,t:1527023415933};\\\", \\\"{x:402,y:618,t:1527023415949};\\\", \\\"{x:396,y:607,t:1527023415966};\\\", \\\"{x:391,y:598,t:1527023415983};\\\", \\\"{x:387,y:592,t:1527023416000};\\\", \\\"{x:386,y:588,t:1527023416017};\\\", \\\"{x:386,y:584,t:1527023416033};\\\", \\\"{x:384,y:578,t:1527023416049};\\\", \\\"{x:384,y:574,t:1527023416066};\\\", \\\"{x:384,y:571,t:1527023416083};\\\", \\\"{x:384,y:570,t:1527023416108};\\\", \\\"{x:384,y:568,t:1527023416124};\\\", \\\"{x:384,y:567,t:1527023416141};\\\", \\\"{x:384,y:566,t:1527023416150};\\\", \\\"{x:384,y:565,t:1527023416167};\\\", \\\"{x:384,y:564,t:1527023416183};\\\", \\\"{x:387,y:562,t:1527023416200};\\\", \\\"{x:401,y:560,t:1527023416216};\\\", \\\"{x:430,y:559,t:1527023416233};\\\", \\\"{x:462,y:559,t:1527023416249};\\\", \\\"{x:512,y:559,t:1527023416266};\\\", \\\"{x:563,y:559,t:1527023416283};\\\", \\\"{x:586,y:559,t:1527023416299};\\\", \\\"{x:594,y:559,t:1527023416315};\\\", \\\"{x:597,y:559,t:1527023416333};\\\", \\\"{x:598,y:559,t:1527023416413};\\\", \\\"{x:601,y:559,t:1527023416421};\\\", \\\"{x:605,y:559,t:1527023416433};\\\", \\\"{x:614,y:562,t:1527023416450};\\\", \\\"{x:627,y:562,t:1527023416467};\\\", \\\"{x:637,y:563,t:1527023416484};\\\", \\\"{x:641,y:565,t:1527023416500};\\\", \\\"{x:641,y:567,t:1527023416534};\\\", \\\"{x:641,y:570,t:1527023416550};\\\", \\\"{x:638,y:573,t:1527023416566};\\\", \\\"{x:636,y:575,t:1527023416584};\\\", \\\"{x:633,y:578,t:1527023416601};\\\", \\\"{x:630,y:582,t:1527023416616};\\\", \\\"{x:629,y:583,t:1527023416633};\\\", \\\"{x:629,y:584,t:1527023416650};\\\", \\\"{x:627,y:584,t:1527023416758};\\\", \\\"{x:625,y:582,t:1527023416767};\\\", \\\"{x:622,y:577,t:1527023416784};\\\", \\\"{x:619,y:572,t:1527023416801};\\\", \\\"{x:619,y:571,t:1527023416817};\\\", \\\"{x:627,y:571,t:1527023416989};\\\", \\\"{x:638,y:571,t:1527023417000};\\\", \\\"{x:676,y:571,t:1527023417018};\\\", \\\"{x:718,y:571,t:1527023417033};\\\", \\\"{x:768,y:571,t:1527023417050};\\\", \\\"{x:811,y:571,t:1527023417066};\\\", \\\"{x:842,y:571,t:1527023417083};\\\", \\\"{x:874,y:571,t:1527023417100};\\\", \\\"{x:878,y:570,t:1527023417117};\\\", \\\"{x:878,y:569,t:1527023417140};\\\", \\\"{x:877,y:569,t:1527023417269};\\\", \\\"{x:874,y:569,t:1527023417285};\\\", \\\"{x:866,y:570,t:1527023417301};\\\", \\\"{x:853,y:572,t:1527023417317};\\\", \\\"{x:840,y:572,t:1527023417334};\\\", \\\"{x:834,y:572,t:1527023417351};\\\", \\\"{x:832,y:572,t:1527023417367};\\\", \\\"{x:825,y:576,t:1527023417980};\\\", \\\"{x:818,y:582,t:1527023417989};\\\", \\\"{x:809,y:590,t:1527023418001};\\\", \\\"{x:784,y:613,t:1527023418018};\\\", \\\"{x:757,y:641,t:1527023418034};\\\", \\\"{x:721,y:692,t:1527023418051};\\\", \\\"{x:684,y:736,t:1527023418067};\\\", \\\"{x:626,y:782,t:1527023418084};\\\", \\\"{x:604,y:798,t:1527023418100};\\\", \\\"{x:585,y:812,t:1527023418118};\\\", \\\"{x:578,y:816,t:1527023418134};\\\", \\\"{x:572,y:818,t:1527023418151};\\\", \\\"{x:569,y:820,t:1527023418168};\\\", \\\"{x:567,y:820,t:1527023418184};\\\", \\\"{x:561,y:822,t:1527023418201};\\\", \\\"{x:557,y:824,t:1527023418218};\\\", \\\"{x:554,y:826,t:1527023418235};\\\", \\\"{x:553,y:826,t:1527023418251};\\\", \\\"{x:553,y:827,t:1527023418293};\\\", \\\"{x:551,y:826,t:1527023418301};\\\", \\\"{x:549,y:816,t:1527023418318};\\\", \\\"{x:544,y:802,t:1527023418335};\\\", \\\"{x:539,y:783,t:1527023418351};\\\", \\\"{x:532,y:767,t:1527023418368};\\\", \\\"{x:528,y:756,t:1527023418385};\\\", \\\"{x:526,y:755,t:1527023418401};\\\", \\\"{x:526,y:754,t:1527023418421};\\\", \\\"{x:526,y:753,t:1527023418500};\\\", \\\"{x:526,y:751,t:1527023418572};\\\", \\\"{x:526,y:750,t:1527023418584};\\\", \\\"{x:526,y:749,t:1527023418600};\\\", \\\"{x:526,y:748,t:1527023418618};\\\", \\\"{x:526,y:745,t:1527023419437};\\\", \\\"{x:527,y:738,t:1527023419449};\\\", \\\"{x:527,y:725,t:1527023419467};\\\", \\\"{x:527,y:724,t:1527023419482};\\\" ] }, { \\\"rt\\\": 15847, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 458035, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:720,t:1527023422477};\\\", \\\"{x:559,y:615,t:1527023422502};\\\", \\\"{x:574,y:578,t:1527023422509};\\\", \\\"{x:586,y:544,t:1527023422522};\\\", \\\"{x:608,y:487,t:1527023422537};\\\", \\\"{x:633,y:434,t:1527023422555};\\\", \\\"{x:664,y:386,t:1527023422571};\\\", \\\"{x:688,y:346,t:1527023422588};\\\", \\\"{x:698,y:333,t:1527023422605};\\\", \\\"{x:700,y:328,t:1527023422622};\\\", \\\"{x:701,y:327,t:1527023422639};\\\", \\\"{x:705,y:327,t:1527023425461};\\\", \\\"{x:721,y:339,t:1527023425469};\\\", \\\"{x:739,y:354,t:1527023425483};\\\", \\\"{x:800,y:397,t:1527023425499};\\\", \\\"{x:869,y:442,t:1527023425517};\\\", \\\"{x:956,y:491,t:1527023425533};\\\", \\\"{x:1011,y:514,t:1527023425550};\\\", \\\"{x:1079,y:539,t:1527023425566};\\\", \\\"{x:1164,y:570,t:1527023425583};\\\", \\\"{x:1253,y:595,t:1527023425600};\\\", \\\"{x:1336,y:619,t:1527023425616};\\\", \\\"{x:1383,y:633,t:1527023425633};\\\", \\\"{x:1412,y:645,t:1527023425650};\\\", \\\"{x:1428,y:649,t:1527023425666};\\\", \\\"{x:1433,y:650,t:1527023425682};\\\", \\\"{x:1436,y:651,t:1527023425699};\\\", \\\"{x:1436,y:652,t:1527023425958};\\\", \\\"{x:1435,y:653,t:1527023425968};\\\", \\\"{x:1431,y:659,t:1527023425984};\\\", \\\"{x:1427,y:666,t:1527023426001};\\\", \\\"{x:1423,y:674,t:1527023426018};\\\", \\\"{x:1419,y:687,t:1527023426035};\\\", \\\"{x:1414,y:701,t:1527023426052};\\\", \\\"{x:1409,y:720,t:1527023426068};\\\", \\\"{x:1396,y:741,t:1527023426085};\\\", \\\"{x:1386,y:753,t:1527023426101};\\\", \\\"{x:1373,y:765,t:1527023426118};\\\", \\\"{x:1361,y:777,t:1527023426135};\\\", \\\"{x:1346,y:788,t:1527023426152};\\\", \\\"{x:1332,y:795,t:1527023426168};\\\", \\\"{x:1319,y:800,t:1527023426186};\\\", \\\"{x:1304,y:807,t:1527023426202};\\\", \\\"{x:1291,y:811,t:1527023426218};\\\", \\\"{x:1283,y:816,t:1527023426235};\\\", \\\"{x:1272,y:820,t:1527023426252};\\\", \\\"{x:1267,y:821,t:1527023426269};\\\", \\\"{x:1268,y:821,t:1527023426341};\\\", \\\"{x:1271,y:821,t:1527023426352};\\\", \\\"{x:1279,y:818,t:1527023426369};\\\", \\\"{x:1283,y:815,t:1527023426386};\\\", \\\"{x:1288,y:811,t:1527023426403};\\\", \\\"{x:1293,y:807,t:1527023426419};\\\", \\\"{x:1299,y:802,t:1527023426437};\\\", \\\"{x:1301,y:799,t:1527023426453};\\\", \\\"{x:1303,y:794,t:1527023426469};\\\", \\\"{x:1304,y:788,t:1527023426486};\\\", \\\"{x:1307,y:783,t:1527023426503};\\\", \\\"{x:1307,y:780,t:1527023426520};\\\", \\\"{x:1308,y:778,t:1527023426536};\\\", \\\"{x:1309,y:777,t:1527023426590};\\\", \\\"{x:1310,y:776,t:1527023426606};\\\", \\\"{x:1313,y:774,t:1527023426620};\\\", \\\"{x:1316,y:773,t:1527023426638};\\\", \\\"{x:1317,y:773,t:1527023426654};\\\", \\\"{x:1318,y:771,t:1527023426671};\\\", \\\"{x:1320,y:771,t:1527023426688};\\\", \\\"{x:1323,y:771,t:1527023426704};\\\", \\\"{x:1327,y:770,t:1527023426721};\\\", \\\"{x:1329,y:769,t:1527023426737};\\\", \\\"{x:1331,y:768,t:1527023426754};\\\", \\\"{x:1333,y:766,t:1527023426771};\\\", \\\"{x:1334,y:765,t:1527023426797};\\\", \\\"{x:1334,y:764,t:1527023426821};\\\", \\\"{x:1334,y:763,t:1527023426958};\\\", \\\"{x:1336,y:762,t:1527023426997};\\\", \\\"{x:1333,y:762,t:1527023427533};\\\", \\\"{x:1328,y:762,t:1527023427541};\\\", \\\"{x:1317,y:763,t:1527023427557};\\\", \\\"{x:1303,y:764,t:1527023427574};\\\", \\\"{x:1285,y:766,t:1527023427590};\\\", \\\"{x:1267,y:767,t:1527023427607};\\\", \\\"{x:1246,y:768,t:1527023427623};\\\", \\\"{x:1235,y:771,t:1527023427640};\\\", \\\"{x:1223,y:773,t:1527023427657};\\\", \\\"{x:1218,y:774,t:1527023427674};\\\", \\\"{x:1211,y:775,t:1527023427690};\\\", \\\"{x:1208,y:776,t:1527023427707};\\\", \\\"{x:1206,y:776,t:1527023427724};\\\", \\\"{x:1206,y:773,t:1527023427853};\\\", \\\"{x:1206,y:771,t:1527023427861};\\\", \\\"{x:1206,y:768,t:1527023427874};\\\", \\\"{x:1208,y:766,t:1527023427891};\\\", \\\"{x:1212,y:763,t:1527023427908};\\\", \\\"{x:1218,y:760,t:1527023427925};\\\", \\\"{x:1221,y:760,t:1527023427940};\\\", \\\"{x:1224,y:760,t:1527023427958};\\\", \\\"{x:1227,y:760,t:1527023427975};\\\", \\\"{x:1228,y:760,t:1527023427992};\\\", \\\"{x:1230,y:760,t:1527023428008};\\\", \\\"{x:1231,y:760,t:1527023428037};\\\", \\\"{x:1232,y:760,t:1527023428070};\\\", \\\"{x:1234,y:760,t:1527023428093};\\\", \\\"{x:1235,y:762,t:1527023428934};\\\", \\\"{x:1236,y:766,t:1527023428945};\\\", \\\"{x:1238,y:768,t:1527023428963};\\\", \\\"{x:1239,y:769,t:1527023428979};\\\", \\\"{x:1242,y:773,t:1527023428995};\\\", \\\"{x:1245,y:776,t:1527023429013};\\\", \\\"{x:1246,y:777,t:1527023429028};\\\", \\\"{x:1247,y:777,t:1527023429045};\\\", \\\"{x:1248,y:777,t:1527023431206};\\\", \\\"{x:1250,y:777,t:1527023431221};\\\", \\\"{x:1254,y:775,t:1527023431236};\\\", \\\"{x:1269,y:766,t:1527023431254};\\\", \\\"{x:1285,y:759,t:1527023431271};\\\", \\\"{x:1301,y:748,t:1527023431287};\\\", \\\"{x:1326,y:730,t:1527023431303};\\\", \\\"{x:1346,y:710,t:1527023431321};\\\", \\\"{x:1370,y:678,t:1527023431337};\\\", \\\"{x:1404,y:635,t:1527023431353};\\\", \\\"{x:1422,y:611,t:1527023431371};\\\", \\\"{x:1434,y:593,t:1527023431388};\\\", \\\"{x:1442,y:582,t:1527023431405};\\\", \\\"{x:1445,y:577,t:1527023431420};\\\", \\\"{x:1448,y:571,t:1527023431437};\\\", \\\"{x:1448,y:569,t:1527023431455};\\\", \\\"{x:1448,y:568,t:1527023431638};\\\", \\\"{x:1448,y:567,t:1527023431655};\\\", \\\"{x:1448,y:566,t:1527023431672};\\\", \\\"{x:1447,y:566,t:1527023431688};\\\", \\\"{x:1446,y:566,t:1527023431733};\\\", \\\"{x:1444,y:566,t:1527023431869};\\\", \\\"{x:1443,y:567,t:1527023431885};\\\", \\\"{x:1441,y:567,t:1527023431893};\\\", \\\"{x:1440,y:567,t:1527023431905};\\\", \\\"{x:1438,y:568,t:1527023431923};\\\", \\\"{x:1437,y:569,t:1527023431940};\\\", \\\"{x:1434,y:569,t:1527023431957};\\\", \\\"{x:1431,y:570,t:1527023431972};\\\", \\\"{x:1430,y:570,t:1527023431989};\\\", \\\"{x:1428,y:570,t:1527023432006};\\\", \\\"{x:1427,y:570,t:1527023432023};\\\", \\\"{x:1425,y:570,t:1527023432190};\\\", \\\"{x:1423,y:570,t:1527023432207};\\\", \\\"{x:1421,y:568,t:1527023432223};\\\", \\\"{x:1420,y:567,t:1527023432241};\\\", \\\"{x:1417,y:564,t:1527023432260};\\\", \\\"{x:1417,y:563,t:1527023432290};\\\", \\\"{x:1416,y:563,t:1527023432306};\\\", \\\"{x:1410,y:563,t:1527023434582};\\\", \\\"{x:1337,y:581,t:1527023434600};\\\", \\\"{x:1214,y:590,t:1527023434615};\\\", \\\"{x:1095,y:590,t:1527023434632};\\\", \\\"{x:1006,y:590,t:1527023434649};\\\", \\\"{x:959,y:590,t:1527023434665};\\\", \\\"{x:931,y:590,t:1527023434684};\\\", \\\"{x:896,y:590,t:1527023434699};\\\", \\\"{x:853,y:590,t:1527023434714};\\\", \\\"{x:828,y:590,t:1527023434731};\\\", \\\"{x:798,y:589,t:1527023434748};\\\", \\\"{x:791,y:589,t:1527023434765};\\\", \\\"{x:789,y:589,t:1527023434782};\\\", \\\"{x:787,y:588,t:1527023434797};\\\", \\\"{x:781,y:588,t:1527023434815};\\\", \\\"{x:774,y:588,t:1527023434831};\\\", \\\"{x:766,y:588,t:1527023434848};\\\", \\\"{x:754,y:588,t:1527023434865};\\\", \\\"{x:739,y:585,t:1527023434882};\\\", \\\"{x:723,y:583,t:1527023434899};\\\", \\\"{x:713,y:581,t:1527023434915};\\\", \\\"{x:710,y:581,t:1527023434931};\\\", \\\"{x:709,y:581,t:1527023434948};\\\", \\\"{x:717,y:574,t:1527023434965};\\\", \\\"{x:738,y:567,t:1527023434983};\\\", \\\"{x:761,y:562,t:1527023434998};\\\", \\\"{x:788,y:558,t:1527023435015};\\\", \\\"{x:812,y:554,t:1527023435032};\\\", \\\"{x:827,y:552,t:1527023435048};\\\", \\\"{x:836,y:551,t:1527023435065};\\\", \\\"{x:837,y:551,t:1527023435082};\\\", \\\"{x:839,y:551,t:1527023435541};\\\", \\\"{x:846,y:551,t:1527023435550};\\\", \\\"{x:879,y:551,t:1527023435566};\\\", \\\"{x:940,y:567,t:1527023435582};\\\", \\\"{x:1015,y:587,t:1527023435600};\\\", \\\"{x:1122,y:616,t:1527023435616};\\\", \\\"{x:1214,y:643,t:1527023435632};\\\", \\\"{x:1290,y:669,t:1527023435649};\\\", \\\"{x:1342,y:690,t:1527023435666};\\\", \\\"{x:1381,y:715,t:1527023435683};\\\", \\\"{x:1397,y:730,t:1527023435699};\\\", \\\"{x:1409,y:743,t:1527023435717};\\\", \\\"{x:1409,y:746,t:1527023435733};\\\", \\\"{x:1409,y:750,t:1527023435749};\\\", \\\"{x:1406,y:757,t:1527023435766};\\\", \\\"{x:1395,y:768,t:1527023435783};\\\", \\\"{x:1376,y:782,t:1527023435800};\\\", \\\"{x:1356,y:794,t:1527023435816};\\\", \\\"{x:1334,y:802,t:1527023435833};\\\", \\\"{x:1313,y:808,t:1527023435849};\\\", \\\"{x:1276,y:809,t:1527023435866};\\\", \\\"{x:1206,y:809,t:1527023435883};\\\", \\\"{x:1109,y:809,t:1527023435899};\\\", \\\"{x:961,y:790,t:1527023435916};\\\", \\\"{x:868,y:773,t:1527023435932};\\\", \\\"{x:800,y:759,t:1527023435949};\\\", \\\"{x:757,y:750,t:1527023435966};\\\", \\\"{x:725,y:744,t:1527023435983};\\\", \\\"{x:701,y:739,t:1527023435999};\\\", \\\"{x:682,y:732,t:1527023436016};\\\", \\\"{x:668,y:726,t:1527023436033};\\\", \\\"{x:657,y:723,t:1527023436050};\\\", \\\"{x:642,y:723,t:1527023436066};\\\", \\\"{x:618,y:723,t:1527023436084};\\\", \\\"{x:584,y:732,t:1527023436100};\\\", \\\"{x:531,y:746,t:1527023436118};\\\", \\\"{x:487,y:753,t:1527023436133};\\\", \\\"{x:467,y:757,t:1527023436148};\\\", \\\"{x:456,y:757,t:1527023436165};\\\", \\\"{x:447,y:757,t:1527023436183};\\\", \\\"{x:445,y:757,t:1527023436200};\\\", \\\"{x:444,y:756,t:1527023436454};\\\", \\\"{x:444,y:754,t:1527023436467};\\\", \\\"{x:455,y:745,t:1527023436485};\\\", \\\"{x:464,y:739,t:1527023436500};\\\", \\\"{x:467,y:737,t:1527023436517};\\\", \\\"{x:468,y:736,t:1527023436533};\\\" ] }, { \\\"rt\\\": 23762, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 483025, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:469,y:735,t:1527023441622};\\\", \\\"{x:516,y:724,t:1527023441638};\\\", \\\"{x:572,y:717,t:1527023441657};\\\", \\\"{x:621,y:712,t:1527023441671};\\\", \\\"{x:666,y:705,t:1527023441688};\\\", \\\"{x:760,y:695,t:1527023441703};\\\", \\\"{x:846,y:695,t:1527023441720};\\\", \\\"{x:927,y:695,t:1527023441736};\\\", \\\"{x:1016,y:695,t:1527023441754};\\\", \\\"{x:1099,y:695,t:1527023441771};\\\", \\\"{x:1168,y:695,t:1527023441786};\\\", \\\"{x:1224,y:695,t:1527023441803};\\\", \\\"{x:1276,y:695,t:1527023441821};\\\", \\\"{x:1301,y:695,t:1527023441836};\\\", \\\"{x:1320,y:695,t:1527023441854};\\\", \\\"{x:1329,y:695,t:1527023441870};\\\", \\\"{x:1331,y:695,t:1527023441887};\\\", \\\"{x:1332,y:695,t:1527023441903};\\\", \\\"{x:1333,y:696,t:1527023441980};\\\", \\\"{x:1335,y:698,t:1527023441988};\\\", \\\"{x:1336,y:699,t:1527023442003};\\\", \\\"{x:1337,y:702,t:1527023442020};\\\", \\\"{x:1337,y:707,t:1527023442036};\\\", \\\"{x:1337,y:710,t:1527023442053};\\\", \\\"{x:1337,y:715,t:1527023442070};\\\", \\\"{x:1337,y:719,t:1527023442086};\\\", \\\"{x:1337,y:723,t:1527023442103};\\\", \\\"{x:1334,y:729,t:1527023442120};\\\", \\\"{x:1324,y:735,t:1527023442136};\\\", \\\"{x:1311,y:742,t:1527023442154};\\\", \\\"{x:1289,y:750,t:1527023442170};\\\", \\\"{x:1275,y:753,t:1527023442186};\\\", \\\"{x:1265,y:756,t:1527023442203};\\\", \\\"{x:1251,y:758,t:1527023442220};\\\", \\\"{x:1246,y:759,t:1527023442237};\\\", \\\"{x:1240,y:761,t:1527023442253};\\\", \\\"{x:1237,y:761,t:1527023442270};\\\", \\\"{x:1232,y:763,t:1527023442286};\\\", \\\"{x:1229,y:764,t:1527023442304};\\\", \\\"{x:1225,y:767,t:1527023442321};\\\", \\\"{x:1221,y:769,t:1527023442336};\\\", \\\"{x:1216,y:771,t:1527023442353};\\\", \\\"{x:1209,y:774,t:1527023442370};\\\", \\\"{x:1206,y:776,t:1527023442387};\\\", \\\"{x:1200,y:779,t:1527023442403};\\\", \\\"{x:1197,y:786,t:1527023442420};\\\", \\\"{x:1197,y:791,t:1527023442436};\\\", \\\"{x:1198,y:795,t:1527023442453};\\\", \\\"{x:1202,y:799,t:1527023442470};\\\", \\\"{x:1206,y:803,t:1527023442488};\\\", \\\"{x:1213,y:810,t:1527023442504};\\\", \\\"{x:1218,y:817,t:1527023442521};\\\", \\\"{x:1219,y:821,t:1527023442537};\\\", \\\"{x:1220,y:823,t:1527023442554};\\\", \\\"{x:1221,y:823,t:1527023442581};\\\", \\\"{x:1221,y:824,t:1527023442654};\\\", \\\"{x:1221,y:825,t:1527023442671};\\\", \\\"{x:1222,y:825,t:1527023442688};\\\", \\\"{x:1224,y:825,t:1527023443206};\\\", \\\"{x:1226,y:825,t:1527023443221};\\\", \\\"{x:1228,y:825,t:1527023443238};\\\", \\\"{x:1233,y:825,t:1527023443255};\\\", \\\"{x:1235,y:824,t:1527023443271};\\\", \\\"{x:1236,y:824,t:1527023443325};\\\", \\\"{x:1239,y:824,t:1527023443338};\\\", \\\"{x:1243,y:824,t:1527023443355};\\\", \\\"{x:1250,y:824,t:1527023443371};\\\", \\\"{x:1256,y:824,t:1527023443388};\\\", \\\"{x:1267,y:824,t:1527023443405};\\\", \\\"{x:1274,y:824,t:1527023443421};\\\", \\\"{x:1275,y:824,t:1527023443438};\\\", \\\"{x:1276,y:824,t:1527023443469};\\\", \\\"{x:1277,y:824,t:1527023443686};\\\", \\\"{x:1279,y:824,t:1527023443693};\\\", \\\"{x:1280,y:825,t:1527023443724};\\\", \\\"{x:1281,y:826,t:1527023450150};\\\", \\\"{x:1282,y:828,t:1527023453038};\\\", \\\"{x:1282,y:829,t:1527023453061};\\\", \\\"{x:1283,y:831,t:1527023453077};\\\", \\\"{x:1284,y:833,t:1527023453092};\\\", \\\"{x:1285,y:835,t:1527023453109};\\\", \\\"{x:1282,y:838,t:1527023453428};\\\", \\\"{x:1278,y:838,t:1527023453442};\\\", \\\"{x:1269,y:839,t:1527023453459};\\\", \\\"{x:1263,y:839,t:1527023453476};\\\", \\\"{x:1258,y:839,t:1527023453493};\\\", \\\"{x:1256,y:839,t:1527023453509};\\\", \\\"{x:1255,y:839,t:1527023453565};\\\", \\\"{x:1252,y:839,t:1527023453576};\\\", \\\"{x:1244,y:839,t:1527023453593};\\\", \\\"{x:1241,y:839,t:1527023453609};\\\", \\\"{x:1237,y:839,t:1527023453627};\\\", \\\"{x:1230,y:839,t:1527023453644};\\\", \\\"{x:1226,y:839,t:1527023453659};\\\", \\\"{x:1222,y:839,t:1527023453676};\\\", \\\"{x:1220,y:839,t:1527023453694};\\\", \\\"{x:1219,y:839,t:1527023453709};\\\", \\\"{x:1218,y:839,t:1527023453727};\\\", \\\"{x:1216,y:839,t:1527023453743};\\\", \\\"{x:1215,y:839,t:1527023453765};\\\", \\\"{x:1214,y:839,t:1527023453805};\\\", \\\"{x:1213,y:839,t:1527023453829};\\\", \\\"{x:1212,y:838,t:1527023454396};\\\", \\\"{x:1215,y:838,t:1527023454460};\\\", \\\"{x:1221,y:838,t:1527023454476};\\\", \\\"{x:1228,y:836,t:1527023454493};\\\", \\\"{x:1238,y:836,t:1527023454510};\\\", \\\"{x:1248,y:836,t:1527023454526};\\\", \\\"{x:1255,y:836,t:1527023454542};\\\", \\\"{x:1262,y:836,t:1527023454560};\\\", \\\"{x:1266,y:836,t:1527023454576};\\\", \\\"{x:1268,y:836,t:1527023454593};\\\", \\\"{x:1270,y:836,t:1527023454610};\\\", \\\"{x:1272,y:836,t:1527023454626};\\\", \\\"{x:1273,y:835,t:1527023454643};\\\", \\\"{x:1276,y:835,t:1527023454660};\\\", \\\"{x:1280,y:834,t:1527023454676};\\\", \\\"{x:1283,y:834,t:1527023454693};\\\", \\\"{x:1286,y:833,t:1527023454711};\\\", \\\"{x:1288,y:833,t:1527023454726};\\\", \\\"{x:1289,y:832,t:1527023454743};\\\", \\\"{x:1289,y:831,t:1527023455925};\\\", \\\"{x:1289,y:830,t:1527023455958};\\\", \\\"{x:1288,y:829,t:1527023455973};\\\", \\\"{x:1287,y:829,t:1527023455980};\\\", \\\"{x:1286,y:829,t:1527023455997};\\\", \\\"{x:1284,y:829,t:1527023456021};\\\", \\\"{x:1285,y:829,t:1527023456853};\\\", \\\"{x:1288,y:829,t:1527023456861};\\\", \\\"{x:1293,y:833,t:1527023456878};\\\", \\\"{x:1302,y:834,t:1527023456895};\\\", \\\"{x:1307,y:838,t:1527023456912};\\\", \\\"{x:1310,y:838,t:1527023456927};\\\", \\\"{x:1312,y:840,t:1527023456945};\\\", \\\"{x:1314,y:841,t:1527023456962};\\\", \\\"{x:1317,y:841,t:1527023456977};\\\", \\\"{x:1321,y:843,t:1527023456994};\\\", \\\"{x:1322,y:844,t:1527023457021};\\\", \\\"{x:1323,y:844,t:1527023457277};\\\", \\\"{x:1329,y:848,t:1527023457294};\\\", \\\"{x:1335,y:852,t:1527023457312};\\\", \\\"{x:1343,y:856,t:1527023457329};\\\", \\\"{x:1353,y:861,t:1527023457345};\\\", \\\"{x:1368,y:870,t:1527023457362};\\\", \\\"{x:1380,y:875,t:1527023457379};\\\", \\\"{x:1392,y:880,t:1527023457394};\\\", \\\"{x:1396,y:882,t:1527023457411};\\\", \\\"{x:1400,y:885,t:1527023457429};\\\", \\\"{x:1401,y:885,t:1527023457574};\\\", \\\"{x:1401,y:886,t:1527023457589};\\\", \\\"{x:1402,y:886,t:1527023457597};\\\", \\\"{x:1402,y:887,t:1527023457613};\\\", \\\"{x:1402,y:888,t:1527023457629};\\\", \\\"{x:1403,y:890,t:1527023457644};\\\", \\\"{x:1403,y:891,t:1527023457661};\\\", \\\"{x:1403,y:894,t:1527023457678};\\\", \\\"{x:1403,y:898,t:1527023457695};\\\", \\\"{x:1402,y:904,t:1527023457715};\\\", \\\"{x:1402,y:906,t:1527023457728};\\\", \\\"{x:1401,y:907,t:1527023457744};\\\", \\\"{x:1401,y:908,t:1527023457761};\\\", \\\"{x:1400,y:909,t:1527023457778};\\\", \\\"{x:1399,y:910,t:1527023457804};\\\", \\\"{x:1398,y:910,t:1527023457812};\\\", \\\"{x:1397,y:912,t:1527023457828};\\\", \\\"{x:1397,y:913,t:1527023457844};\\\", \\\"{x:1396,y:914,t:1527023457861};\\\", \\\"{x:1395,y:914,t:1527023458912};\\\", \\\"{x:1391,y:911,t:1527023458921};\\\", \\\"{x:1386,y:907,t:1527023458932};\\\", \\\"{x:1375,y:900,t:1527023458949};\\\", \\\"{x:1362,y:892,t:1527023458965};\\\", \\\"{x:1348,y:883,t:1527023458981};\\\", \\\"{x:1334,y:877,t:1527023458999};\\\", \\\"{x:1324,y:874,t:1527023459016};\\\", \\\"{x:1323,y:874,t:1527023459032};\\\", \\\"{x:1322,y:874,t:1527023459079};\\\", \\\"{x:1322,y:876,t:1527023459087};\\\", \\\"{x:1322,y:878,t:1527023459098};\\\", \\\"{x:1324,y:881,t:1527023459115};\\\", \\\"{x:1324,y:882,t:1527023459131};\\\", \\\"{x:1325,y:883,t:1527023459148};\\\", \\\"{x:1326,y:885,t:1527023459166};\\\", \\\"{x:1328,y:884,t:1527023459208};\\\", \\\"{x:1333,y:875,t:1527023459215};\\\", \\\"{x:1344,y:842,t:1527023459231};\\\", \\\"{x:1347,y:810,t:1527023459248};\\\", \\\"{x:1347,y:786,t:1527023459266};\\\", \\\"{x:1344,y:769,t:1527023459282};\\\", \\\"{x:1342,y:757,t:1527023459298};\\\", \\\"{x:1342,y:746,t:1527023459317};\\\", \\\"{x:1339,y:735,t:1527023459332};\\\", \\\"{x:1338,y:725,t:1527023459348};\\\", \\\"{x:1338,y:717,t:1527023459365};\\\", \\\"{x:1338,y:710,t:1527023459383};\\\", \\\"{x:1338,y:706,t:1527023459399};\\\", \\\"{x:1338,y:698,t:1527023459416};\\\", \\\"{x:1340,y:702,t:1527023459487};\\\", \\\"{x:1343,y:714,t:1527023459498};\\\", \\\"{x:1356,y:754,t:1527023459515};\\\", \\\"{x:1376,y:798,t:1527023459533};\\\", \\\"{x:1397,y:838,t:1527023459549};\\\", \\\"{x:1407,y:861,t:1527023459566};\\\", \\\"{x:1415,y:886,t:1527023459583};\\\", \\\"{x:1435,y:925,t:1527023459599};\\\", \\\"{x:1442,y:950,t:1527023459615};\\\", \\\"{x:1442,y:952,t:1527023459632};\\\", \\\"{x:1441,y:952,t:1527023459688};\\\", \\\"{x:1440,y:951,t:1527023459699};\\\", \\\"{x:1439,y:949,t:1527023459718};\\\", \\\"{x:1434,y:942,t:1527023459732};\\\", \\\"{x:1425,y:930,t:1527023459749};\\\", \\\"{x:1414,y:916,t:1527023459765};\\\", \\\"{x:1407,y:908,t:1527023459782};\\\", \\\"{x:1405,y:906,t:1527023459798};\\\", \\\"{x:1404,y:904,t:1527023459815};\\\", \\\"{x:1402,y:902,t:1527023459960};\\\", \\\"{x:1396,y:902,t:1527023459968};\\\", \\\"{x:1382,y:902,t:1527023459984};\\\", \\\"{x:1329,y:890,t:1527023459999};\\\", \\\"{x:1163,y:843,t:1527023460016};\\\", \\\"{x:1008,y:796,t:1527023460032};\\\", \\\"{x:761,y:739,t:1527023460049};\\\", \\\"{x:511,y:684,t:1527023460066};\\\", \\\"{x:349,y:644,t:1527023460084};\\\", \\\"{x:253,y:627,t:1527023460100};\\\", \\\"{x:211,y:620,t:1527023460116};\\\", \\\"{x:185,y:614,t:1527023460139};\\\", \\\"{x:181,y:613,t:1527023460156};\\\", \\\"{x:186,y:612,t:1527023460303};\\\", \\\"{x:193,y:610,t:1527023460313};\\\", \\\"{x:198,y:610,t:1527023460323};\\\", \\\"{x:201,y:609,t:1527023460341};\\\", \\\"{x:205,y:608,t:1527023460356};\\\", \\\"{x:214,y:604,t:1527023460373};\\\", \\\"{x:223,y:601,t:1527023460390};\\\", \\\"{x:226,y:601,t:1527023460407};\\\", \\\"{x:228,y:601,t:1527023460424};\\\", \\\"{x:228,y:600,t:1527023460441};\\\", \\\"{x:232,y:600,t:1527023460456};\\\", \\\"{x:242,y:600,t:1527023460473};\\\", \\\"{x:260,y:597,t:1527023460491};\\\", \\\"{x:279,y:597,t:1527023460506};\\\", \\\"{x:302,y:597,t:1527023460523};\\\", \\\"{x:331,y:597,t:1527023460540};\\\", \\\"{x:377,y:589,t:1527023460558};\\\", \\\"{x:410,y:587,t:1527023460574};\\\", \\\"{x:420,y:586,t:1527023460591};\\\", \\\"{x:426,y:584,t:1527023460607};\\\", \\\"{x:426,y:583,t:1527023460647};\\\", \\\"{x:425,y:583,t:1527023460658};\\\", \\\"{x:421,y:582,t:1527023460673};\\\", \\\"{x:414,y:582,t:1527023460691};\\\", \\\"{x:404,y:578,t:1527023460707};\\\", \\\"{x:397,y:576,t:1527023460724};\\\", \\\"{x:395,y:574,t:1527023460740};\\\", \\\"{x:394,y:574,t:1527023460759};\\\", \\\"{x:393,y:573,t:1527023460773};\\\", \\\"{x:392,y:571,t:1527023460790};\\\", \\\"{x:392,y:567,t:1527023460807};\\\", \\\"{x:391,y:563,t:1527023460824};\\\", \\\"{x:391,y:561,t:1527023460841};\\\", \\\"{x:390,y:559,t:1527023460858};\\\", \\\"{x:390,y:558,t:1527023460874};\\\", \\\"{x:390,y:556,t:1527023460891};\\\", \\\"{x:389,y:554,t:1527023460908};\\\", \\\"{x:388,y:549,t:1527023460924};\\\", \\\"{x:387,y:547,t:1527023460941};\\\", \\\"{x:387,y:545,t:1527023460957};\\\", \\\"{x:387,y:542,t:1527023460974};\\\", \\\"{x:385,y:540,t:1527023460990};\\\", \\\"{x:385,y:550,t:1527023461191};\\\", \\\"{x:410,y:594,t:1527023461208};\\\", \\\"{x:431,y:631,t:1527023461225};\\\", \\\"{x:448,y:663,t:1527023461240};\\\", \\\"{x:459,y:687,t:1527023461258};\\\", \\\"{x:472,y:707,t:1527023461274};\\\", \\\"{x:480,y:720,t:1527023461291};\\\", \\\"{x:486,y:727,t:1527023461308};\\\", \\\"{x:487,y:727,t:1527023461324};\\\", \\\"{x:488,y:730,t:1527023461341};\\\", \\\"{x:488,y:731,t:1527023461367};\\\", \\\"{x:489,y:734,t:1527023461472};\\\" ] }, { \\\"rt\\\": 14271, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 498647, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:733,t:1527023465432};\\\", \\\"{x:507,y:720,t:1527023465447};\\\", \\\"{x:570,y:711,t:1527023465466};\\\", \\\"{x:657,y:692,t:1527023465482};\\\", \\\"{x:763,y:640,t:1527023465498};\\\", \\\"{x:823,y:608,t:1527023465510};\\\", \\\"{x:944,y:553,t:1527023465527};\\\", \\\"{x:1128,y:489,t:1527023465545};\\\", \\\"{x:1216,y:470,t:1527023465561};\\\", \\\"{x:1272,y:460,t:1527023465578};\\\", \\\"{x:1301,y:454,t:1527023465595};\\\", \\\"{x:1310,y:452,t:1527023465612};\\\", \\\"{x:1313,y:451,t:1527023465627};\\\", \\\"{x:1312,y:451,t:1527023465736};\\\", \\\"{x:1311,y:454,t:1527023465745};\\\", \\\"{x:1308,y:465,t:1527023465762};\\\", \\\"{x:1299,y:489,t:1527023465779};\\\", \\\"{x:1291,y:533,t:1527023465795};\\\", \\\"{x:1283,y:581,t:1527023465812};\\\", \\\"{x:1282,y:614,t:1527023465829};\\\", \\\"{x:1278,y:650,t:1527023465845};\\\", \\\"{x:1278,y:682,t:1527023465862};\\\", \\\"{x:1278,y:709,t:1527023465879};\\\", \\\"{x:1278,y:724,t:1527023465895};\\\", \\\"{x:1278,y:728,t:1527023465912};\\\", \\\"{x:1278,y:729,t:1527023465976};\\\", \\\"{x:1279,y:729,t:1527023465984};\\\", \\\"{x:1283,y:729,t:1527023465996};\\\", \\\"{x:1298,y:726,t:1527023466012};\\\", \\\"{x:1311,y:718,t:1527023466029};\\\", \\\"{x:1321,y:710,t:1527023466046};\\\", \\\"{x:1327,y:705,t:1527023466062};\\\", \\\"{x:1332,y:702,t:1527023466080};\\\", \\\"{x:1335,y:698,t:1527023466096};\\\", \\\"{x:1337,y:697,t:1527023467249};\\\", \\\"{x:1340,y:697,t:1527023467266};\\\", \\\"{x:1341,y:697,t:1527023467282};\\\", \\\"{x:1342,y:697,t:1527023467301};\\\", \\\"{x:1344,y:697,t:1527023467315};\\\", \\\"{x:1338,y:697,t:1527023473200};\\\", \\\"{x:1330,y:697,t:1527023473208};\\\", \\\"{x:1319,y:697,t:1527023473225};\\\", \\\"{x:1308,y:697,t:1527023473242};\\\", \\\"{x:1299,y:697,t:1527023473259};\\\", \\\"{x:1298,y:697,t:1527023473275};\\\", \\\"{x:1295,y:697,t:1527023473376};\\\", \\\"{x:1282,y:697,t:1527023473392};\\\", \\\"{x:1269,y:693,t:1527023473410};\\\", \\\"{x:1248,y:692,t:1527023473426};\\\", \\\"{x:1223,y:690,t:1527023473442};\\\", \\\"{x:1197,y:686,t:1527023473459};\\\", \\\"{x:1168,y:682,t:1527023473476};\\\", \\\"{x:1147,y:677,t:1527023473492};\\\", \\\"{x:1129,y:675,t:1527023473509};\\\", \\\"{x:1116,y:672,t:1527023473527};\\\", \\\"{x:1104,y:670,t:1527023473543};\\\", \\\"{x:1092,y:666,t:1527023473560};\\\", \\\"{x:1086,y:665,t:1527023473576};\\\", \\\"{x:1080,y:662,t:1527023473592};\\\", \\\"{x:1069,y:657,t:1527023473609};\\\", \\\"{x:1046,y:647,t:1527023473626};\\\", \\\"{x:1014,y:634,t:1527023473643};\\\", \\\"{x:981,y:625,t:1527023473660};\\\", \\\"{x:944,y:615,t:1527023473678};\\\", \\\"{x:907,y:602,t:1527023473693};\\\", \\\"{x:873,y:593,t:1527023473710};\\\", \\\"{x:862,y:590,t:1527023473718};\\\", \\\"{x:826,y:581,t:1527023473735};\\\", \\\"{x:802,y:573,t:1527023473751};\\\", \\\"{x:780,y:566,t:1527023473767};\\\", \\\"{x:764,y:561,t:1527023473785};\\\", \\\"{x:751,y:556,t:1527023473801};\\\", \\\"{x:739,y:552,t:1527023473819};\\\", \\\"{x:724,y:545,t:1527023473835};\\\", \\\"{x:715,y:542,t:1527023473851};\\\", \\\"{x:707,y:539,t:1527023473868};\\\", \\\"{x:703,y:537,t:1527023473885};\\\", \\\"{x:699,y:535,t:1527023473901};\\\", \\\"{x:696,y:532,t:1527023473918};\\\", \\\"{x:691,y:526,t:1527023473935};\\\", \\\"{x:683,y:522,t:1527023473952};\\\", \\\"{x:672,y:518,t:1527023473968};\\\", \\\"{x:664,y:515,t:1527023473986};\\\", \\\"{x:657,y:512,t:1527023474002};\\\", \\\"{x:652,y:511,t:1527023474018};\\\", \\\"{x:646,y:509,t:1527023474035};\\\", \\\"{x:639,y:508,t:1527023474052};\\\", \\\"{x:632,y:506,t:1527023474068};\\\", \\\"{x:624,y:504,t:1527023474084};\\\", \\\"{x:617,y:503,t:1527023474102};\\\", \\\"{x:614,y:503,t:1527023474117};\\\", \\\"{x:611,y:502,t:1527023474135};\\\", \\\"{x:614,y:502,t:1527023474600};\\\", \\\"{x:626,y:506,t:1527023474608};\\\", \\\"{x:639,y:511,t:1527023474619};\\\", \\\"{x:668,y:525,t:1527023474636};\\\", \\\"{x:727,y:542,t:1527023474653};\\\", \\\"{x:817,y:561,t:1527023474670};\\\", \\\"{x:914,y:586,t:1527023474686};\\\", \\\"{x:1002,y:607,t:1527023474703};\\\", \\\"{x:1123,y:639,t:1527023474719};\\\", \\\"{x:1201,y:663,t:1527023474735};\\\", \\\"{x:1270,y:679,t:1527023474752};\\\", \\\"{x:1313,y:686,t:1527023474769};\\\", \\\"{x:1342,y:692,t:1527023474785};\\\", \\\"{x:1359,y:698,t:1527023474802};\\\", \\\"{x:1376,y:703,t:1527023474819};\\\", \\\"{x:1384,y:705,t:1527023474835};\\\", \\\"{x:1391,y:708,t:1527023474852};\\\", \\\"{x:1394,y:709,t:1527023474869};\\\", \\\"{x:1399,y:711,t:1527023474886};\\\", \\\"{x:1403,y:713,t:1527023474903};\\\", \\\"{x:1408,y:716,t:1527023474919};\\\", \\\"{x:1409,y:717,t:1527023474935};\\\", \\\"{x:1410,y:718,t:1527023474952};\\\", \\\"{x:1410,y:719,t:1527023475016};\\\", \\\"{x:1410,y:720,t:1527023475024};\\\", \\\"{x:1410,y:722,t:1527023475036};\\\", \\\"{x:1410,y:726,t:1527023475052};\\\", \\\"{x:1410,y:731,t:1527023475070};\\\", \\\"{x:1409,y:736,t:1527023475087};\\\", \\\"{x:1409,y:737,t:1527023475104};\\\", \\\"{x:1409,y:739,t:1527023475119};\\\", \\\"{x:1409,y:742,t:1527023475135};\\\", \\\"{x:1409,y:747,t:1527023475153};\\\", \\\"{x:1409,y:753,t:1527023475170};\\\", \\\"{x:1409,y:759,t:1527023475187};\\\", \\\"{x:1409,y:764,t:1527023475203};\\\", \\\"{x:1409,y:771,t:1527023475220};\\\", \\\"{x:1410,y:776,t:1527023475237};\\\", \\\"{x:1411,y:781,t:1527023475253};\\\", \\\"{x:1412,y:785,t:1527023475270};\\\", \\\"{x:1412,y:788,t:1527023475286};\\\", \\\"{x:1413,y:793,t:1527023475303};\\\", \\\"{x:1415,y:800,t:1527023475319};\\\", \\\"{x:1415,y:806,t:1527023475336};\\\", \\\"{x:1415,y:810,t:1527023475352};\\\", \\\"{x:1417,y:813,t:1527023475369};\\\", \\\"{x:1417,y:815,t:1527023475387};\\\", \\\"{x:1417,y:819,t:1527023475402};\\\", \\\"{x:1416,y:822,t:1527023475419};\\\", \\\"{x:1416,y:826,t:1527023475437};\\\", \\\"{x:1413,y:829,t:1527023475453};\\\", \\\"{x:1413,y:835,t:1527023475470};\\\", \\\"{x:1411,y:838,t:1527023475486};\\\", \\\"{x:1409,y:840,t:1527023475503};\\\", \\\"{x:1404,y:845,t:1527023475520};\\\", \\\"{x:1398,y:849,t:1527023475536};\\\", \\\"{x:1386,y:854,t:1527023475554};\\\", \\\"{x:1371,y:857,t:1527023475570};\\\", \\\"{x:1347,y:860,t:1527023475587};\\\", \\\"{x:1323,y:862,t:1527023475604};\\\", \\\"{x:1294,y:862,t:1527023475620};\\\", \\\"{x:1241,y:862,t:1527023475636};\\\", \\\"{x:1182,y:862,t:1527023475653};\\\", \\\"{x:1114,y:860,t:1527023475670};\\\", \\\"{x:1055,y:850,t:1527023475687};\\\", \\\"{x:975,y:836,t:1527023475704};\\\", \\\"{x:921,y:826,t:1527023475719};\\\", \\\"{x:887,y:819,t:1527023475736};\\\", \\\"{x:841,y:808,t:1527023475753};\\\", \\\"{x:809,y:802,t:1527023475770};\\\", \\\"{x:780,y:797,t:1527023475787};\\\", \\\"{x:756,y:791,t:1527023475804};\\\", \\\"{x:731,y:784,t:1527023475819};\\\", \\\"{x:710,y:778,t:1527023475836};\\\", \\\"{x:692,y:773,t:1527023475853};\\\", \\\"{x:681,y:768,t:1527023475869};\\\", \\\"{x:673,y:766,t:1527023475886};\\\", \\\"{x:667,y:764,t:1527023475904};\\\", \\\"{x:664,y:763,t:1527023475920};\\\", \\\"{x:659,y:761,t:1527023475937};\\\", \\\"{x:650,y:756,t:1527023475954};\\\", \\\"{x:640,y:754,t:1527023475969};\\\", \\\"{x:633,y:750,t:1527023475987};\\\", \\\"{x:623,y:747,t:1527023476003};\\\", \\\"{x:613,y:745,t:1527023476020};\\\", \\\"{x:598,y:741,t:1527023476037};\\\", \\\"{x:583,y:736,t:1527023476054};\\\", \\\"{x:571,y:734,t:1527023476069};\\\", \\\"{x:558,y:731,t:1527023476087};\\\", \\\"{x:537,y:730,t:1527023476103};\\\", \\\"{x:532,y:730,t:1527023476115};\\\", \\\"{x:524,y:730,t:1527023476132};\\\", \\\"{x:519,y:729,t:1527023476148};\\\", \\\"{x:517,y:729,t:1527023476165};\\\", \\\"{x:514,y:729,t:1527023476181};\\\", \\\"{x:512,y:729,t:1527023476198};\\\", \\\"{x:511,y:729,t:1527023476215};\\\", \\\"{x:510,y:729,t:1527023476231};\\\", \\\"{x:509,y:729,t:1527023476279};\\\", \\\"{x:508,y:730,t:1527023476504};\\\", \\\"{x:508,y:731,t:1527023476519};\\\", \\\"{x:508,y:733,t:1527023476560};\\\", \\\"{x:507,y:734,t:1527023476575};\\\", \\\"{x:507,y:735,t:1527023476607};\\\" ] }, { \\\"rt\\\": 16491, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 516404, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -B -01 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:735,t:1527023479392};\\\", \\\"{x:517,y:732,t:1527023479407};\\\", \\\"{x:610,y:712,t:1527023479425};\\\", \\\"{x:723,y:685,t:1527023479439};\\\", \\\"{x:867,y:662,t:1527023479456};\\\", \\\"{x:1052,y:641,t:1527023479474};\\\", \\\"{x:1220,y:639,t:1527023479489};\\\", \\\"{x:1386,y:639,t:1527023479506};\\\", \\\"{x:1543,y:656,t:1527023479524};\\\", \\\"{x:1663,y:676,t:1527023479539};\\\", \\\"{x:1760,y:688,t:1527023479556};\\\", \\\"{x:1800,y:694,t:1527023479574};\\\", \\\"{x:1820,y:696,t:1527023479590};\\\", \\\"{x:1821,y:696,t:1527023479607};\\\", \\\"{x:1822,y:696,t:1527023479623};\\\", \\\"{x:1823,y:697,t:1527023479648};\\\", \\\"{x:1823,y:698,t:1527023479656};\\\", \\\"{x:1823,y:699,t:1527023479673};\\\", \\\"{x:1822,y:700,t:1527023479689};\\\", \\\"{x:1820,y:701,t:1527023479744};\\\", \\\"{x:1819,y:701,t:1527023479783};\\\", \\\"{x:1818,y:701,t:1527023479791};\\\", \\\"{x:1817,y:701,t:1527023479807};\\\", \\\"{x:1816,y:701,t:1527023479823};\\\", \\\"{x:1815,y:701,t:1527023479847};\\\", \\\"{x:1814,y:701,t:1527023479856};\\\", \\\"{x:1811,y:701,t:1527023479873};\\\", \\\"{x:1808,y:701,t:1527023479890};\\\", \\\"{x:1803,y:701,t:1527023479907};\\\", \\\"{x:1797,y:701,t:1527023479923};\\\", \\\"{x:1792,y:701,t:1527023479940};\\\", \\\"{x:1784,y:701,t:1527023479956};\\\", \\\"{x:1776,y:701,t:1527023479973};\\\", \\\"{x:1767,y:701,t:1527023479991};\\\", \\\"{x:1763,y:701,t:1527023480007};\\\", \\\"{x:1751,y:701,t:1527023480023};\\\", \\\"{x:1740,y:701,t:1527023480040};\\\", \\\"{x:1729,y:701,t:1527023480057};\\\", \\\"{x:1714,y:701,t:1527023480073};\\\", \\\"{x:1700,y:701,t:1527023480091};\\\", \\\"{x:1682,y:701,t:1527023480106};\\\", \\\"{x:1666,y:700,t:1527023480124};\\\", \\\"{x:1642,y:696,t:1527023480141};\\\", \\\"{x:1615,y:694,t:1527023480160};\\\", \\\"{x:1589,y:693,t:1527023480174};\\\", \\\"{x:1556,y:691,t:1527023480190};\\\", \\\"{x:1511,y:705,t:1527023480207};\\\", \\\"{x:1461,y:726,t:1527023480223};\\\", \\\"{x:1394,y:746,t:1527023480240};\\\", \\\"{x:1349,y:767,t:1527023480258};\\\", \\\"{x:1314,y:787,t:1527023480273};\\\", \\\"{x:1283,y:803,t:1527023480291};\\\", \\\"{x:1258,y:818,t:1527023480307};\\\", \\\"{x:1237,y:827,t:1527023480324};\\\", \\\"{x:1229,y:831,t:1527023480340};\\\", \\\"{x:1224,y:834,t:1527023480358};\\\", \\\"{x:1219,y:835,t:1527023480374};\\\", \\\"{x:1212,y:838,t:1527023480390};\\\", \\\"{x:1201,y:842,t:1527023480407};\\\", \\\"{x:1190,y:843,t:1527023480423};\\\", \\\"{x:1181,y:844,t:1527023480441};\\\", \\\"{x:1175,y:845,t:1527023480458};\\\", \\\"{x:1167,y:845,t:1527023480474};\\\", \\\"{x:1160,y:845,t:1527023480491};\\\", \\\"{x:1152,y:845,t:1527023480508};\\\", \\\"{x:1146,y:845,t:1527023480524};\\\", \\\"{x:1143,y:845,t:1527023480541};\\\", \\\"{x:1141,y:845,t:1527023480558};\\\", \\\"{x:1140,y:845,t:1527023480574};\\\", \\\"{x:1139,y:845,t:1527023480591};\\\", \\\"{x:1137,y:843,t:1527023480607};\\\", \\\"{x:1137,y:838,t:1527023480623};\\\", \\\"{x:1137,y:829,t:1527023480640};\\\", \\\"{x:1137,y:817,t:1527023480657};\\\", \\\"{x:1137,y:812,t:1527023480675};\\\", \\\"{x:1140,y:808,t:1527023480691};\\\", \\\"{x:1141,y:805,t:1527023480708};\\\", \\\"{x:1143,y:801,t:1527023480725};\\\", \\\"{x:1144,y:799,t:1527023480740};\\\", \\\"{x:1145,y:797,t:1527023480767};\\\", \\\"{x:1146,y:797,t:1527023480776};\\\", \\\"{x:1146,y:795,t:1527023480791};\\\", \\\"{x:1151,y:790,t:1527023480808};\\\", \\\"{x:1153,y:787,t:1527023480825};\\\", \\\"{x:1155,y:785,t:1527023480841};\\\", \\\"{x:1157,y:783,t:1527023480858};\\\", \\\"{x:1160,y:780,t:1527023480875};\\\", \\\"{x:1161,y:778,t:1527023480891};\\\", \\\"{x:1164,y:776,t:1527023480908};\\\", \\\"{x:1164,y:775,t:1527023480924};\\\", \\\"{x:1165,y:773,t:1527023480941};\\\", \\\"{x:1166,y:773,t:1527023482729};\\\", \\\"{x:1171,y:773,t:1527023482744};\\\", \\\"{x:1197,y:773,t:1527023482759};\\\", \\\"{x:1255,y:776,t:1527023482776};\\\", \\\"{x:1325,y:786,t:1527023482793};\\\", \\\"{x:1394,y:795,t:1527023482810};\\\", \\\"{x:1461,y:803,t:1527023482826};\\\", \\\"{x:1517,y:811,t:1527023482843};\\\", \\\"{x:1554,y:818,t:1527023482860};\\\", \\\"{x:1583,y:820,t:1527023482876};\\\", \\\"{x:1605,y:828,t:1527023482892};\\\", \\\"{x:1619,y:828,t:1527023482909};\\\", \\\"{x:1626,y:829,t:1527023482925};\\\", \\\"{x:1631,y:829,t:1527023482942};\\\", \\\"{x:1635,y:829,t:1527023482959};\\\", \\\"{x:1637,y:829,t:1527023482975};\\\", \\\"{x:1639,y:829,t:1527023482993};\\\", \\\"{x:1640,y:829,t:1527023483016};\\\", \\\"{x:1641,y:829,t:1527023483026};\\\", \\\"{x:1642,y:829,t:1527023483048};\\\", \\\"{x:1642,y:827,t:1527023483352};\\\", \\\"{x:1642,y:826,t:1527023483360};\\\", \\\"{x:1642,y:825,t:1527023483377};\\\", \\\"{x:1642,y:823,t:1527023483393};\\\", \\\"{x:1642,y:822,t:1527023483410};\\\", \\\"{x:1642,y:821,t:1527023483448};\\\", \\\"{x:1642,y:819,t:1527023483464};\\\", \\\"{x:1641,y:816,t:1527023483480};\\\", \\\"{x:1639,y:812,t:1527023483493};\\\", \\\"{x:1637,y:807,t:1527023483510};\\\", \\\"{x:1632,y:797,t:1527023483527};\\\", \\\"{x:1627,y:775,t:1527023483543};\\\", \\\"{x:1618,y:677,t:1527023483560};\\\", \\\"{x:1614,y:568,t:1527023483577};\\\", \\\"{x:1612,y:440,t:1527023483593};\\\", \\\"{x:1608,y:337,t:1527023483610};\\\", \\\"{x:1595,y:277,t:1527023483627};\\\", \\\"{x:1588,y:246,t:1527023483643};\\\", \\\"{x:1584,y:226,t:1527023483660};\\\", \\\"{x:1581,y:215,t:1527023483677};\\\", \\\"{x:1579,y:212,t:1527023483693};\\\", \\\"{x:1576,y:212,t:1527023484025};\\\", \\\"{x:1561,y:228,t:1527023484032};\\\", \\\"{x:1537,y:253,t:1527023484044};\\\", \\\"{x:1442,y:327,t:1527023484060};\\\", \\\"{x:1303,y:426,t:1527023484077};\\\", \\\"{x:1149,y:526,t:1527023484094};\\\", \\\"{x:999,y:595,t:1527023484110};\\\", \\\"{x:859,y:654,t:1527023484127};\\\", \\\"{x:711,y:704,t:1527023484144};\\\", \\\"{x:656,y:710,t:1527023484161};\\\", \\\"{x:602,y:718,t:1527023484177};\\\", \\\"{x:569,y:722,t:1527023484194};\\\", \\\"{x:550,y:723,t:1527023484211};\\\", \\\"{x:535,y:723,t:1527023484226};\\\", \\\"{x:529,y:723,t:1527023484243};\\\", \\\"{x:524,y:723,t:1527023484260};\\\", \\\"{x:520,y:722,t:1527023484276};\\\", \\\"{x:512,y:717,t:1527023484294};\\\", \\\"{x:502,y:713,t:1527023484310};\\\", \\\"{x:489,y:700,t:1527023484326};\\\", \\\"{x:478,y:685,t:1527023484344};\\\", \\\"{x:468,y:666,t:1527023484361};\\\", \\\"{x:457,y:647,t:1527023484377};\\\", \\\"{x:447,y:628,t:1527023484394};\\\", \\\"{x:443,y:621,t:1527023484410};\\\", \\\"{x:439,y:617,t:1527023484427};\\\", \\\"{x:437,y:614,t:1527023484443};\\\", \\\"{x:435,y:612,t:1527023484460};\\\", \\\"{x:434,y:611,t:1527023484478};\\\", \\\"{x:432,y:609,t:1527023484493};\\\", \\\"{x:432,y:608,t:1527023484527};\\\", \\\"{x:432,y:605,t:1527023484544};\\\", \\\"{x:432,y:598,t:1527023484560};\\\", \\\"{x:432,y:594,t:1527023484578};\\\", \\\"{x:432,y:588,t:1527023484593};\\\", \\\"{x:432,y:586,t:1527023484610};\\\", \\\"{x:432,y:583,t:1527023484627};\\\", \\\"{x:432,y:580,t:1527023484643};\\\", \\\"{x:432,y:577,t:1527023484660};\\\", \\\"{x:432,y:576,t:1527023484678};\\\", \\\"{x:431,y:574,t:1527023484693};\\\", \\\"{x:430,y:573,t:1527023484710};\\\", \\\"{x:426,y:572,t:1527023484727};\\\", \\\"{x:418,y:571,t:1527023484744};\\\", \\\"{x:409,y:571,t:1527023484761};\\\", \\\"{x:402,y:571,t:1527023484777};\\\", \\\"{x:400,y:571,t:1527023484794};\\\", \\\"{x:395,y:571,t:1527023484810};\\\", \\\"{x:391,y:572,t:1527023484827};\\\", \\\"{x:385,y:574,t:1527023484844};\\\", \\\"{x:377,y:578,t:1527023484860};\\\", \\\"{x:371,y:579,t:1527023484878};\\\", \\\"{x:369,y:581,t:1527023484894};\\\", \\\"{x:367,y:581,t:1527023484910};\\\", \\\"{x:364,y:581,t:1527023484927};\\\", \\\"{x:364,y:582,t:1527023484945};\\\", \\\"{x:362,y:582,t:1527023485046};\\\", \\\"{x:361,y:582,t:1527023485063};\\\", \\\"{x:360,y:582,t:1527023485077};\\\", \\\"{x:359,y:582,t:1527023485127};\\\", \\\"{x:358,y:581,t:1527023485175};\\\", \\\"{x:357,y:581,t:1527023485688};\\\", \\\"{x:355,y:581,t:1527023485695};\\\", \\\"{x:350,y:579,t:1527023485712};\\\", \\\"{x:347,y:577,t:1527023485729};\\\", \\\"{x:343,y:575,t:1527023485746};\\\", \\\"{x:336,y:573,t:1527023485762};\\\", \\\"{x:330,y:571,t:1527023485779};\\\", \\\"{x:328,y:569,t:1527023485795};\\\", \\\"{x:325,y:569,t:1527023485811};\\\", \\\"{x:319,y:566,t:1527023485829};\\\", \\\"{x:314,y:563,t:1527023485846};\\\", \\\"{x:310,y:562,t:1527023485863};\\\", \\\"{x:304,y:559,t:1527023485878};\\\", \\\"{x:296,y:557,t:1527023485895};\\\", \\\"{x:294,y:555,t:1527023485912};\\\", \\\"{x:293,y:554,t:1527023485959};\\\", \\\"{x:296,y:555,t:1527023486072};\\\", \\\"{x:299,y:555,t:1527023486079};\\\", \\\"{x:320,y:557,t:1527023486096};\\\", \\\"{x:345,y:560,t:1527023486111};\\\", \\\"{x:379,y:561,t:1527023486129};\\\", \\\"{x:417,y:563,t:1527023486146};\\\", \\\"{x:490,y:563,t:1527023486161};\\\", \\\"{x:570,y:563,t:1527023486179};\\\", \\\"{x:654,y:563,t:1527023486195};\\\", \\\"{x:742,y:563,t:1527023486212};\\\", \\\"{x:815,y:563,t:1527023486229};\\\", \\\"{x:887,y:563,t:1527023486246};\\\", \\\"{x:954,y:555,t:1527023486262};\\\", \\\"{x:1028,y:546,t:1527023486279};\\\", \\\"{x:1151,y:520,t:1527023486295};\\\", \\\"{x:1248,y:492,t:1527023486312};\\\", \\\"{x:1363,y:472,t:1527023486329};\\\", \\\"{x:1469,y:454,t:1527023486346};\\\", \\\"{x:1560,y:443,t:1527023486362};\\\", \\\"{x:1622,y:439,t:1527023486378};\\\", \\\"{x:1652,y:437,t:1527023486396};\\\", \\\"{x:1661,y:437,t:1527023486412};\\\", \\\"{x:1663,y:437,t:1527023486428};\\\", \\\"{x:1664,y:437,t:1527023486472};\\\", \\\"{x:1664,y:441,t:1527023486488};\\\", \\\"{x:1663,y:448,t:1527023486496};\\\", \\\"{x:1657,y:459,t:1527023486513};\\\", \\\"{x:1653,y:468,t:1527023486530};\\\", \\\"{x:1647,y:480,t:1527023486546};\\\", \\\"{x:1639,y:491,t:1527023486564};\\\", \\\"{x:1632,y:501,t:1527023486580};\\\", \\\"{x:1626,y:514,t:1527023486596};\\\", \\\"{x:1619,y:521,t:1527023486613};\\\", \\\"{x:1609,y:530,t:1527023486630};\\\", \\\"{x:1592,y:545,t:1527023486646};\\\", \\\"{x:1570,y:565,t:1527023486663};\\\", \\\"{x:1549,y:582,t:1527023486679};\\\", \\\"{x:1528,y:612,t:1527023486696};\\\", \\\"{x:1518,y:627,t:1527023486713};\\\", \\\"{x:1513,y:638,t:1527023486729};\\\", \\\"{x:1509,y:647,t:1527023486746};\\\", \\\"{x:1504,y:662,t:1527023486763};\\\", \\\"{x:1498,y:675,t:1527023486779};\\\", \\\"{x:1491,y:694,t:1527023486796};\\\", \\\"{x:1483,y:712,t:1527023486813};\\\", \\\"{x:1476,y:728,t:1527023486829};\\\", \\\"{x:1470,y:743,t:1527023486847};\\\", \\\"{x:1466,y:757,t:1527023486863};\\\", \\\"{x:1463,y:774,t:1527023486880};\\\", \\\"{x:1463,y:787,t:1527023486896};\\\", \\\"{x:1463,y:798,t:1527023486913};\\\", \\\"{x:1467,y:814,t:1527023486930};\\\", \\\"{x:1469,y:826,t:1527023486946};\\\", \\\"{x:1473,y:837,t:1527023486963};\\\", \\\"{x:1479,y:850,t:1527023486981};\\\", \\\"{x:1485,y:860,t:1527023486997};\\\", \\\"{x:1489,y:867,t:1527023487013};\\\", \\\"{x:1489,y:875,t:1527023487030};\\\", \\\"{x:1489,y:885,t:1527023487046};\\\", \\\"{x:1489,y:893,t:1527023487064};\\\", \\\"{x:1489,y:902,t:1527023487080};\\\", \\\"{x:1489,y:903,t:1527023487096};\\\", \\\"{x:1491,y:904,t:1527023487120};\\\", \\\"{x:1492,y:905,t:1527023487136};\\\", \\\"{x:1493,y:906,t:1527023487146};\\\", \\\"{x:1494,y:907,t:1527023487163};\\\", \\\"{x:1495,y:907,t:1527023487180};\\\", \\\"{x:1498,y:909,t:1527023487196};\\\", \\\"{x:1504,y:911,t:1527023487213};\\\", \\\"{x:1513,y:914,t:1527023487230};\\\", \\\"{x:1520,y:916,t:1527023487246};\\\", \\\"{x:1528,y:919,t:1527023487263};\\\", \\\"{x:1540,y:926,t:1527023487280};\\\", \\\"{x:1551,y:930,t:1527023487297};\\\", \\\"{x:1555,y:933,t:1527023487313};\\\", \\\"{x:1561,y:936,t:1527023487330};\\\", \\\"{x:1566,y:937,t:1527023487348};\\\", \\\"{x:1571,y:940,t:1527023487363};\\\", \\\"{x:1577,y:941,t:1527023487380};\\\", \\\"{x:1582,y:945,t:1527023487397};\\\", \\\"{x:1587,y:945,t:1527023487413};\\\", \\\"{x:1590,y:948,t:1527023487431};\\\", \\\"{x:1594,y:951,t:1527023487448};\\\", \\\"{x:1596,y:951,t:1527023487463};\\\", \\\"{x:1599,y:953,t:1527023487480};\\\", \\\"{x:1600,y:954,t:1527023487497};\\\", \\\"{x:1601,y:954,t:1527023487536};\\\", \\\"{x:1602,y:954,t:1527023487551};\\\", \\\"{x:1603,y:954,t:1527023487563};\\\", \\\"{x:1604,y:955,t:1527023487581};\\\", \\\"{x:1603,y:955,t:1527023487671};\\\", \\\"{x:1598,y:955,t:1527023487679};\\\", \\\"{x:1576,y:955,t:1527023487697};\\\", \\\"{x:1556,y:954,t:1527023487714};\\\", \\\"{x:1539,y:953,t:1527023487729};\\\", \\\"{x:1529,y:953,t:1527023487746};\\\", \\\"{x:1524,y:952,t:1527023487764};\\\", \\\"{x:1523,y:951,t:1527023487807};\\\", \\\"{x:1522,y:951,t:1527023487896};\\\", \\\"{x:1520,y:950,t:1527023487914};\\\", \\\"{x:1515,y:949,t:1527023487929};\\\", \\\"{x:1508,y:949,t:1527023487946};\\\", \\\"{x:1501,y:949,t:1527023487964};\\\", \\\"{x:1493,y:947,t:1527023487979};\\\", \\\"{x:1487,y:947,t:1527023487996};\\\", \\\"{x:1484,y:946,t:1527023488014};\\\", \\\"{x:1483,y:945,t:1527023488030};\\\", \\\"{x:1483,y:946,t:1527023488224};\\\", \\\"{x:1483,y:947,t:1527023488360};\\\", \\\"{x:1483,y:948,t:1527023488384};\\\", \\\"{x:1483,y:949,t:1527023488408};\\\", \\\"{x:1483,y:950,t:1527023488423};\\\", \\\"{x:1482,y:952,t:1527023488440};\\\", \\\"{x:1481,y:952,t:1527023488456};\\\", \\\"{x:1481,y:953,t:1527023488465};\\\", \\\"{x:1479,y:954,t:1527023488481};\\\", \\\"{x:1477,y:956,t:1527023488497};\\\", \\\"{x:1475,y:956,t:1527023488514};\\\", \\\"{x:1472,y:956,t:1527023488532};\\\", \\\"{x:1470,y:957,t:1527023488548};\\\", \\\"{x:1469,y:958,t:1527023488565};\\\", \\\"{x:1468,y:958,t:1527023488581};\\\", \\\"{x:1465,y:959,t:1527023488597};\\\", \\\"{x:1461,y:960,t:1527023488615};\\\", \\\"{x:1459,y:961,t:1527023488632};\\\", \\\"{x:1457,y:961,t:1527023488648};\\\", \\\"{x:1455,y:961,t:1527023488664};\\\", \\\"{x:1451,y:963,t:1527023488682};\\\", \\\"{x:1446,y:964,t:1527023488698};\\\", \\\"{x:1443,y:965,t:1527023488715};\\\", \\\"{x:1436,y:967,t:1527023488731};\\\", \\\"{x:1433,y:968,t:1527023488748};\\\", \\\"{x:1428,y:969,t:1527023488765};\\\", \\\"{x:1424,y:969,t:1527023488782};\\\", \\\"{x:1420,y:969,t:1527023488799};\\\", \\\"{x:1412,y:969,t:1527023488814};\\\", \\\"{x:1400,y:970,t:1527023488832};\\\", \\\"{x:1394,y:970,t:1527023488849};\\\", \\\"{x:1389,y:970,t:1527023488864};\\\", \\\"{x:1382,y:968,t:1527023488880};\\\", \\\"{x:1379,y:967,t:1527023488898};\\\", \\\"{x:1375,y:966,t:1527023488914};\\\", \\\"{x:1373,y:964,t:1527023488931};\\\", \\\"{x:1371,y:963,t:1527023488959};\\\", \\\"{x:1370,y:963,t:1527023488975};\\\", \\\"{x:1368,y:963,t:1527023488983};\\\", \\\"{x:1365,y:963,t:1527023488997};\\\", \\\"{x:1361,y:963,t:1527023489014};\\\", \\\"{x:1355,y:963,t:1527023489030};\\\", \\\"{x:1350,y:963,t:1527023489047};\\\", \\\"{x:1349,y:963,t:1527023489065};\\\", \\\"{x:1347,y:963,t:1527023489081};\\\", \\\"{x:1346,y:963,t:1527023489098};\\\", \\\"{x:1346,y:962,t:1527023489361};\\\", \\\"{x:1346,y:961,t:1527023489367};\\\", \\\"{x:1347,y:959,t:1527023489424};\\\", \\\"{x:1348,y:959,t:1527023489432};\\\", \\\"{x:1348,y:958,t:1527023489448};\\\", \\\"{x:1350,y:955,t:1527023489465};\\\", \\\"{x:1351,y:954,t:1527023489481};\\\", \\\"{x:1352,y:951,t:1527023489498};\\\", \\\"{x:1354,y:948,t:1527023489515};\\\", \\\"{x:1354,y:947,t:1527023489532};\\\", \\\"{x:1357,y:944,t:1527023489549};\\\", \\\"{x:1357,y:943,t:1527023489567};\\\", \\\"{x:1357,y:942,t:1527023489582};\\\", \\\"{x:1357,y:940,t:1527023489599};\\\", \\\"{x:1360,y:936,t:1527023489615};\\\", \\\"{x:1361,y:932,t:1527023489632};\\\", \\\"{x:1361,y:929,t:1527023489649};\\\", \\\"{x:1363,y:927,t:1527023489666};\\\", \\\"{x:1363,y:926,t:1527023489683};\\\", \\\"{x:1364,y:925,t:1527023489698};\\\", \\\"{x:1367,y:922,t:1527023489715};\\\", \\\"{x:1369,y:918,t:1527023489732};\\\", \\\"{x:1371,y:917,t:1527023489748};\\\", \\\"{x:1371,y:916,t:1527023489768};\\\", \\\"{x:1371,y:915,t:1527023489792};\\\", \\\"{x:1373,y:913,t:1527023489800};\\\", \\\"{x:1373,y:912,t:1527023489815};\\\", \\\"{x:1376,y:908,t:1527023489832};\\\", \\\"{x:1377,y:905,t:1527023489849};\\\", \\\"{x:1377,y:903,t:1527023489866};\\\", \\\"{x:1378,y:902,t:1527023489882};\\\", \\\"{x:1379,y:901,t:1527023489898};\\\", \\\"{x:1380,y:899,t:1527023489915};\\\", \\\"{x:1381,y:898,t:1527023489932};\\\", \\\"{x:1381,y:897,t:1527023489949};\\\", \\\"{x:1381,y:896,t:1527023489966};\\\", \\\"{x:1382,y:896,t:1527023489984};\\\", \\\"{x:1382,y:895,t:1527023489999};\\\", \\\"{x:1382,y:894,t:1527023492312};\\\", \\\"{x:1375,y:894,t:1527023492320};\\\", \\\"{x:1358,y:892,t:1527023492334};\\\", \\\"{x:1323,y:886,t:1527023492351};\\\", \\\"{x:1263,y:864,t:1527023492368};\\\", \\\"{x:1198,y:845,t:1527023492383};\\\", \\\"{x:1131,y:824,t:1527023492401};\\\", \\\"{x:1069,y:803,t:1527023492417};\\\", \\\"{x:1003,y:773,t:1527023492435};\\\", \\\"{x:925,y:720,t:1527023492450};\\\", \\\"{x:860,y:672,t:1527023492468};\\\", \\\"{x:829,y:650,t:1527023492484};\\\", \\\"{x:811,y:641,t:1527023492501};\\\", \\\"{x:794,y:628,t:1527023492519};\\\", \\\"{x:772,y:615,t:1527023492533};\\\", \\\"{x:748,y:596,t:1527023492551};\\\", \\\"{x:727,y:581,t:1527023492562};\\\", \\\"{x:704,y:566,t:1527023492579};\\\", \\\"{x:668,y:550,t:1527023492597};\\\", \\\"{x:625,y:529,t:1527023492617};\\\", \\\"{x:608,y:522,t:1527023492634};\\\", \\\"{x:601,y:519,t:1527023492650};\\\", \\\"{x:593,y:516,t:1527023492668};\\\", \\\"{x:592,y:515,t:1527023492683};\\\", \\\"{x:592,y:514,t:1527023492710};\\\", \\\"{x:592,y:513,t:1527023492928};\\\", \\\"{x:593,y:512,t:1527023493056};\\\", \\\"{x:594,y:512,t:1527023493072};\\\", \\\"{x:592,y:512,t:1527023493248};\\\", \\\"{x:581,y:517,t:1527023493256};\\\", \\\"{x:569,y:522,t:1527023493269};\\\", \\\"{x:540,y:531,t:1527023493284};\\\", \\\"{x:515,y:535,t:1527023493302};\\\", \\\"{x:485,y:544,t:1527023493318};\\\", \\\"{x:427,y:547,t:1527023493335};\\\", \\\"{x:400,y:547,t:1527023493351};\\\", \\\"{x:381,y:547,t:1527023493368};\\\", \\\"{x:369,y:547,t:1527023493385};\\\", \\\"{x:364,y:547,t:1527023493400};\\\", \\\"{x:363,y:548,t:1527023493417};\\\", \\\"{x:362,y:548,t:1527023493435};\\\", \\\"{x:362,y:549,t:1527023493451};\\\", \\\"{x:361,y:550,t:1527023493467};\\\", \\\"{x:360,y:550,t:1527023493485};\\\", \\\"{x:359,y:551,t:1527023493500};\\\", \\\"{x:358,y:552,t:1527023493518};\\\", \\\"{x:359,y:552,t:1527023493591};\\\", \\\"{x:361,y:552,t:1527023493601};\\\", \\\"{x:362,y:551,t:1527023493618};\\\", \\\"{x:365,y:549,t:1527023493635};\\\", \\\"{x:367,y:548,t:1527023493652};\\\", \\\"{x:370,y:545,t:1527023493668};\\\", \\\"{x:374,y:542,t:1527023493685};\\\", \\\"{x:376,y:540,t:1527023493702};\\\", \\\"{x:377,y:540,t:1527023493815};\\\", \\\"{x:377,y:540,t:1527023493851};\\\", \\\"{x:378,y:540,t:1527023493871};\\\", \\\"{x:380,y:542,t:1527023493983};\\\", \\\"{x:382,y:545,t:1527023493991};\\\", \\\"{x:383,y:549,t:1527023494002};\\\", \\\"{x:383,y:563,t:1527023494020};\\\", \\\"{x:384,y:573,t:1527023494035};\\\", \\\"{x:384,y:582,t:1527023494052};\\\", \\\"{x:384,y:590,t:1527023494069};\\\", \\\"{x:384,y:595,t:1527023494085};\\\", \\\"{x:383,y:600,t:1527023494102};\\\", \\\"{x:382,y:605,t:1527023494119};\\\", \\\"{x:382,y:606,t:1527023494143};\\\", \\\"{x:382,y:607,t:1527023494167};\\\", \\\"{x:382,y:608,t:1527023494183};\\\", \\\"{x:382,y:610,t:1527023494199};\\\", \\\"{x:382,y:611,t:1527023494207};\\\", \\\"{x:382,y:612,t:1527023494219};\\\", \\\"{x:381,y:614,t:1527023494236};\\\", \\\"{x:381,y:619,t:1527023494487};\\\", \\\"{x:388,y:626,t:1527023494502};\\\", \\\"{x:427,y:654,t:1527023494519};\\\", \\\"{x:451,y:673,t:1527023494536};\\\", \\\"{x:485,y:703,t:1527023494552};\\\", \\\"{x:508,y:725,t:1527023494569};\\\", \\\"{x:519,y:738,t:1527023494585};\\\", \\\"{x:523,y:743,t:1527023494602};\\\", \\\"{x:526,y:750,t:1527023494619};\\\", \\\"{x:526,y:754,t:1527023494636};\\\", \\\"{x:526,y:755,t:1527023494652};\\\", \\\"{x:526,y:756,t:1527023494687};\\\", \\\"{x:527,y:757,t:1527023494702};\\\", \\\"{x:527,y:754,t:1527023494833};\\\", \\\"{x:526,y:749,t:1527023494853};\\\", \\\"{x:525,y:743,t:1527023494869};\\\", \\\"{x:525,y:742,t:1527023494886};\\\", \\\"{x:525,y:739,t:1527023494903};\\\", \\\"{x:525,y:737,t:1527023494919};\\\", \\\"{x:525,y:736,t:1527023494936};\\\", \\\"{x:525,y:735,t:1527023495432};\\\", \\\"{x:526,y:735,t:1527023495447};\\\", \\\"{x:527,y:735,t:1527023495455};\\\", \\\"{x:529,y:734,t:1527023495487};\\\", \\\"{x:531,y:734,t:1527023495799};\\\", \\\"{x:532,y:734,t:1527023495808};\\\", \\\"{x:533,y:734,t:1527023495847};\\\" ] }, { \\\"rt\\\": 7929, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 525599, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:734,t:1527023498288};\\\", \\\"{x:536,y:734,t:1527023498295};\\\", \\\"{x:538,y:731,t:1527023498307};\\\", \\\"{x:544,y:727,t:1527023498324};\\\", \\\"{x:548,y:723,t:1527023498340};\\\", \\\"{x:555,y:718,t:1527023498358};\\\", \\\"{x:570,y:710,t:1527023498374};\\\", \\\"{x:586,y:702,t:1527023498390};\\\", \\\"{x:614,y:689,t:1527023498407};\\\", \\\"{x:630,y:687,t:1527023498422};\\\", \\\"{x:698,y:678,t:1527023498438};\\\", \\\"{x:735,y:673,t:1527023498455};\\\", \\\"{x:779,y:671,t:1527023498472};\\\", \\\"{x:841,y:671,t:1527023498489};\\\", \\\"{x:896,y:671,t:1527023498505};\\\", \\\"{x:958,y:671,t:1527023498522};\\\", \\\"{x:1024,y:679,t:1527023498539};\\\", \\\"{x:1102,y:690,t:1527023498556};\\\", \\\"{x:1152,y:702,t:1527023498573};\\\", \\\"{x:1181,y:708,t:1527023498589};\\\", \\\"{x:1209,y:715,t:1527023498606};\\\", \\\"{x:1238,y:721,t:1527023498623};\\\", \\\"{x:1265,y:727,t:1527023498640};\\\", \\\"{x:1277,y:732,t:1527023498656};\\\", \\\"{x:1286,y:737,t:1527023498673};\\\", \\\"{x:1289,y:739,t:1527023498689};\\\", \\\"{x:1292,y:741,t:1527023498706};\\\", \\\"{x:1293,y:742,t:1527023498723};\\\", \\\"{x:1296,y:746,t:1527023498739};\\\", \\\"{x:1298,y:748,t:1527023498756};\\\", \\\"{x:1301,y:751,t:1527023498772};\\\", \\\"{x:1303,y:752,t:1527023498789};\\\", \\\"{x:1305,y:752,t:1527023498840};\\\", \\\"{x:1305,y:753,t:1527023498856};\\\", \\\"{x:1307,y:753,t:1527023498952};\\\", \\\"{x:1307,y:748,t:1527023498960};\\\", \\\"{x:1309,y:741,t:1527023498974};\\\", \\\"{x:1311,y:733,t:1527023498989};\\\", \\\"{x:1314,y:726,t:1527023499007};\\\", \\\"{x:1315,y:723,t:1527023499024};\\\", \\\"{x:1317,y:720,t:1527023499039};\\\", \\\"{x:1319,y:717,t:1527023499056};\\\", \\\"{x:1322,y:714,t:1527023499072};\\\", \\\"{x:1324,y:712,t:1527023499089};\\\", \\\"{x:1325,y:711,t:1527023499106};\\\", \\\"{x:1328,y:710,t:1527023499127};\\\", \\\"{x:1328,y:709,t:1527023499139};\\\", \\\"{x:1329,y:708,t:1527023499156};\\\", \\\"{x:1330,y:706,t:1527023499190};\\\", \\\"{x:1331,y:706,t:1527023499207};\\\", \\\"{x:1335,y:704,t:1527023499223};\\\", \\\"{x:1337,y:702,t:1527023499239};\\\", \\\"{x:1338,y:701,t:1527023499256};\\\", \\\"{x:1339,y:700,t:1527023499296};\\\", \\\"{x:1340,y:699,t:1527023499312};\\\", \\\"{x:1341,y:698,t:1527023499324};\\\", \\\"{x:1341,y:697,t:1527023499339};\\\", \\\"{x:1342,y:697,t:1527023499357};\\\", \\\"{x:1343,y:696,t:1527023499423};\\\", \\\"{x:1343,y:694,t:1527023499496};\\\", \\\"{x:1344,y:693,t:1527023499527};\\\", \\\"{x:1344,y:692,t:1527023499551};\\\", \\\"{x:1344,y:693,t:1527023501792};\\\", \\\"{x:1333,y:696,t:1527023501811};\\\", \\\"{x:1317,y:699,t:1527023501827};\\\", \\\"{x:1296,y:701,t:1527023501842};\\\", \\\"{x:1254,y:703,t:1527023501859};\\\", \\\"{x:1195,y:703,t:1527023501876};\\\", \\\"{x:1143,y:700,t:1527023501892};\\\", \\\"{x:1082,y:692,t:1527023501909};\\\", \\\"{x:1002,y:673,t:1527023501926};\\\", \\\"{x:950,y:658,t:1527023501943};\\\", \\\"{x:889,y:643,t:1527023501958};\\\", \\\"{x:830,y:631,t:1527023501977};\\\", \\\"{x:799,y:627,t:1527023501992};\\\", \\\"{x:777,y:624,t:1527023502008};\\\", \\\"{x:756,y:622,t:1527023502025};\\\", \\\"{x:738,y:617,t:1527023502042};\\\", \\\"{x:716,y:614,t:1527023502059};\\\", \\\"{x:687,y:612,t:1527023502075};\\\", \\\"{x:658,y:607,t:1527023502092};\\\", \\\"{x:620,y:602,t:1527023502108};\\\", \\\"{x:577,y:599,t:1527023502126};\\\", \\\"{x:516,y:590,t:1527023502143};\\\", \\\"{x:458,y:582,t:1527023502159};\\\", \\\"{x:428,y:577,t:1527023502175};\\\", \\\"{x:407,y:574,t:1527023502192};\\\", \\\"{x:392,y:573,t:1527023502209};\\\", \\\"{x:377,y:573,t:1527023502225};\\\", \\\"{x:363,y:572,t:1527023502243};\\\", \\\"{x:359,y:572,t:1527023502259};\\\", \\\"{x:356,y:572,t:1527023502275};\\\", \\\"{x:352,y:573,t:1527023502292};\\\", \\\"{x:342,y:574,t:1527023502309};\\\", \\\"{x:328,y:574,t:1527023502325};\\\", \\\"{x:314,y:578,t:1527023502342};\\\", \\\"{x:300,y:580,t:1527023502359};\\\", \\\"{x:295,y:580,t:1527023502375};\\\", \\\"{x:289,y:580,t:1527023502393};\\\", \\\"{x:279,y:582,t:1527023502409};\\\", \\\"{x:266,y:582,t:1527023502426};\\\", \\\"{x:254,y:582,t:1527023502442};\\\", \\\"{x:245,y:582,t:1527023502458};\\\", \\\"{x:239,y:582,t:1527023502475};\\\", \\\"{x:231,y:582,t:1527023502492};\\\", \\\"{x:223,y:582,t:1527023502509};\\\", \\\"{x:214,y:582,t:1527023502525};\\\", \\\"{x:209,y:584,t:1527023502542};\\\", \\\"{x:207,y:585,t:1527023502558};\\\", \\\"{x:209,y:585,t:1527023502703};\\\", \\\"{x:219,y:583,t:1527023502711};\\\", \\\"{x:234,y:581,t:1527023502725};\\\", \\\"{x:293,y:581,t:1527023502744};\\\", \\\"{x:379,y:581,t:1527023502759};\\\", \\\"{x:512,y:581,t:1527023502778};\\\", \\\"{x:601,y:581,t:1527023502792};\\\", \\\"{x:687,y:581,t:1527023502810};\\\", \\\"{x:745,y:581,t:1527023502827};\\\", \\\"{x:776,y:581,t:1527023502842};\\\", \\\"{x:795,y:581,t:1527023502860};\\\", \\\"{x:798,y:581,t:1527023502876};\\\", \\\"{x:799,y:580,t:1527023502892};\\\", \\\"{x:800,y:579,t:1527023502926};\\\", \\\"{x:802,y:577,t:1527023502942};\\\", \\\"{x:806,y:575,t:1527023502959};\\\", \\\"{x:807,y:574,t:1527023502976};\\\", \\\"{x:811,y:572,t:1527023502992};\\\", \\\"{x:816,y:570,t:1527023503010};\\\", \\\"{x:819,y:567,t:1527023503026};\\\", \\\"{x:821,y:567,t:1527023503044};\\\", \\\"{x:822,y:566,t:1527023503060};\\\", \\\"{x:823,y:565,t:1527023503088};\\\", \\\"{x:824,y:564,t:1527023503095};\\\", \\\"{x:825,y:562,t:1527023503111};\\\", \\\"{x:826,y:558,t:1527023503126};\\\", \\\"{x:828,y:554,t:1527023503145};\\\", \\\"{x:830,y:552,t:1527023503159};\\\", \\\"{x:831,y:550,t:1527023503177};\\\", \\\"{x:832,y:545,t:1527023503193};\\\", \\\"{x:833,y:544,t:1527023503209};\\\", \\\"{x:834,y:541,t:1527023503226};\\\", \\\"{x:834,y:538,t:1527023503243};\\\", \\\"{x:835,y:537,t:1527023503259};\\\", \\\"{x:831,y:538,t:1527023503599};\\\", \\\"{x:822,y:547,t:1527023503610};\\\", \\\"{x:802,y:566,t:1527023503627};\\\", \\\"{x:786,y:579,t:1527023503644};\\\", \\\"{x:771,y:590,t:1527023503660};\\\", \\\"{x:756,y:600,t:1527023503677};\\\", \\\"{x:742,y:609,t:1527023503693};\\\", \\\"{x:727,y:618,t:1527023503710};\\\", \\\"{x:695,y:640,t:1527023503727};\\\", \\\"{x:676,y:654,t:1527023503743};\\\", \\\"{x:659,y:664,t:1527023503760};\\\", \\\"{x:648,y:669,t:1527023503776};\\\", \\\"{x:636,y:675,t:1527023503794};\\\", \\\"{x:631,y:677,t:1527023503810};\\\", \\\"{x:629,y:679,t:1527023503827};\\\", \\\"{x:627,y:679,t:1527023503844};\\\", \\\"{x:624,y:683,t:1527023503860};\\\", \\\"{x:615,y:688,t:1527023503877};\\\", \\\"{x:605,y:691,t:1527023503894};\\\", \\\"{x:596,y:694,t:1527023503911};\\\", \\\"{x:589,y:694,t:1527023503928};\\\", \\\"{x:585,y:694,t:1527023503967};\\\", \\\"{x:582,y:696,t:1527023503978};\\\", \\\"{x:569,y:705,t:1527023503994};\\\", \\\"{x:552,y:715,t:1527023504011};\\\", \\\"{x:536,y:720,t:1527023504029};\\\", \\\"{x:522,y:723,t:1527023504043};\\\", \\\"{x:509,y:727,t:1527023504060};\\\", \\\"{x:502,y:728,t:1527023504077};\\\", \\\"{x:501,y:729,t:1527023504093};\\\", \\\"{x:501,y:730,t:1527023504177};\\\", \\\"{x:501,y:730,t:1527023504274};\\\" ] }, { \\\"rt\\\": 12745, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 539552, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:731,t:1527023507808};\\\", \\\"{x:515,y:727,t:1527023507815};\\\", \\\"{x:528,y:717,t:1527023507829};\\\", \\\"{x:587,y:688,t:1527023507844};\\\", \\\"{x:663,y:660,t:1527023507861};\\\", \\\"{x:752,y:635,t:1527023507880};\\\", \\\"{x:838,y:628,t:1527023507897};\\\", \\\"{x:919,y:626,t:1527023507913};\\\", \\\"{x:1003,y:611,t:1527023507930};\\\", \\\"{x:1083,y:602,t:1527023507947};\\\", \\\"{x:1169,y:577,t:1527023507971};\\\", \\\"{x:1201,y:573,t:1527023507981};\\\", \\\"{x:1254,y:572,t:1527023507997};\\\", \\\"{x:1309,y:568,t:1527023508013};\\\", \\\"{x:1345,y:568,t:1527023508030};\\\", \\\"{x:1364,y:568,t:1527023508047};\\\", \\\"{x:1379,y:570,t:1527023508063};\\\", \\\"{x:1388,y:573,t:1527023508081};\\\", \\\"{x:1391,y:575,t:1527023508097};\\\", \\\"{x:1392,y:575,t:1527023508114};\\\", \\\"{x:1394,y:577,t:1527023508130};\\\", \\\"{x:1396,y:582,t:1527023508147};\\\", \\\"{x:1398,y:590,t:1527023508164};\\\", \\\"{x:1403,y:604,t:1527023508181};\\\", \\\"{x:1412,y:623,t:1527023508198};\\\", \\\"{x:1421,y:642,t:1527023508213};\\\", \\\"{x:1424,y:656,t:1527023508231};\\\", \\\"{x:1424,y:668,t:1527023508247};\\\", \\\"{x:1424,y:679,t:1527023508264};\\\", \\\"{x:1421,y:694,t:1527023508281};\\\", \\\"{x:1413,y:712,t:1527023508298};\\\", \\\"{x:1406,y:726,t:1527023508314};\\\", \\\"{x:1397,y:735,t:1527023508330};\\\", \\\"{x:1389,y:741,t:1527023508348};\\\", \\\"{x:1381,y:745,t:1527023508364};\\\", \\\"{x:1374,y:750,t:1527023508381};\\\", \\\"{x:1368,y:756,t:1527023508398};\\\", \\\"{x:1363,y:761,t:1527023508414};\\\", \\\"{x:1361,y:767,t:1527023508431};\\\", \\\"{x:1361,y:772,t:1527023508448};\\\", \\\"{x:1361,y:778,t:1527023508464};\\\", \\\"{x:1366,y:793,t:1527023508482};\\\", \\\"{x:1374,y:808,t:1527023508498};\\\", \\\"{x:1381,y:820,t:1527023508513};\\\", \\\"{x:1389,y:828,t:1527023508531};\\\", \\\"{x:1395,y:835,t:1527023508548};\\\", \\\"{x:1402,y:841,t:1527023508565};\\\", \\\"{x:1410,y:851,t:1527023508581};\\\", \\\"{x:1413,y:858,t:1527023508597};\\\", \\\"{x:1413,y:862,t:1527023508615};\\\", \\\"{x:1413,y:864,t:1527023508631};\\\", \\\"{x:1413,y:865,t:1527023508647};\\\", \\\"{x:1413,y:868,t:1527023508665};\\\", \\\"{x:1412,y:870,t:1527023508680};\\\", \\\"{x:1411,y:872,t:1527023508697};\\\", \\\"{x:1410,y:874,t:1527023508714};\\\", \\\"{x:1410,y:876,t:1527023508731};\\\", \\\"{x:1410,y:878,t:1527023508747};\\\", \\\"{x:1410,y:879,t:1527023508765};\\\", \\\"{x:1410,y:880,t:1527023508791};\\\", \\\"{x:1414,y:881,t:1527023508800};\\\", \\\"{x:1431,y:883,t:1527023508815};\\\", \\\"{x:1457,y:883,t:1527023508832};\\\", \\\"{x:1482,y:883,t:1527023508848};\\\", \\\"{x:1515,y:880,t:1527023508866};\\\", \\\"{x:1540,y:877,t:1527023508881};\\\", \\\"{x:1570,y:872,t:1527023508898};\\\", \\\"{x:1588,y:870,t:1527023508915};\\\", \\\"{x:1597,y:867,t:1527023508932};\\\", \\\"{x:1602,y:867,t:1527023508948};\\\", \\\"{x:1603,y:866,t:1527023509056};\\\", \\\"{x:1604,y:865,t:1527023509080};\\\", \\\"{x:1605,y:864,t:1527023509095};\\\", \\\"{x:1605,y:863,t:1527023509128};\\\", \\\"{x:1606,y:863,t:1527023509144};\\\", \\\"{x:1607,y:861,t:1527023509152};\\\", \\\"{x:1607,y:859,t:1527023509165};\\\", \\\"{x:1607,y:849,t:1527023509182};\\\", \\\"{x:1607,y:839,t:1527023509199};\\\", \\\"{x:1607,y:825,t:1527023509215};\\\", \\\"{x:1608,y:808,t:1527023509231};\\\", \\\"{x:1608,y:787,t:1527023509249};\\\", \\\"{x:1608,y:765,t:1527023509265};\\\", \\\"{x:1608,y:751,t:1527023509282};\\\", \\\"{x:1606,y:742,t:1527023509298};\\\", \\\"{x:1605,y:735,t:1527023509315};\\\", \\\"{x:1604,y:726,t:1527023509332};\\\", \\\"{x:1604,y:719,t:1527023509348};\\\", \\\"{x:1604,y:714,t:1527023509365};\\\", \\\"{x:1604,y:710,t:1527023509382};\\\", \\\"{x:1604,y:708,t:1527023509398};\\\", \\\"{x:1604,y:707,t:1527023509415};\\\", \\\"{x:1604,y:705,t:1527023509432};\\\", \\\"{x:1604,y:704,t:1527023509456};\\\", \\\"{x:1604,y:703,t:1527023509471};\\\", \\\"{x:1604,y:702,t:1527023509496};\\\", \\\"{x:1604,y:701,t:1527023509527};\\\", \\\"{x:1604,y:700,t:1527023509608};\\\", \\\"{x:1605,y:700,t:1527023509664};\\\", \\\"{x:1607,y:700,t:1527023509688};\\\", \\\"{x:1608,y:700,t:1527023509752};\\\", \\\"{x:1609,y:699,t:1527023509768};\\\", \\\"{x:1610,y:699,t:1527023509781};\\\", \\\"{x:1611,y:698,t:1527023509799};\\\", \\\"{x:1613,y:697,t:1527023509863};\\\", \\\"{x:1606,y:698,t:1527023513042};\\\", \\\"{x:1587,y:699,t:1527023513052};\\\", \\\"{x:1514,y:701,t:1527023513069};\\\", \\\"{x:1406,y:701,t:1527023513085};\\\", \\\"{x:1350,y:703,t:1527023513102};\\\", \\\"{x:1320,y:703,t:1527023513118};\\\", \\\"{x:1207,y:706,t:1527023513136};\\\", \\\"{x:1141,y:706,t:1527023513152};\\\", \\\"{x:1063,y:706,t:1527023513169};\\\", \\\"{x:983,y:698,t:1527023513186};\\\", \\\"{x:931,y:687,t:1527023513202};\\\", \\\"{x:905,y:680,t:1527023513218};\\\", \\\"{x:895,y:677,t:1527023513235};\\\", \\\"{x:889,y:677,t:1527023513251};\\\", \\\"{x:885,y:677,t:1527023513268};\\\", \\\"{x:883,y:677,t:1527023513285};\\\", \\\"{x:878,y:676,t:1527023513302};\\\", \\\"{x:874,y:673,t:1527023513318};\\\", \\\"{x:863,y:667,t:1527023513336};\\\", \\\"{x:855,y:662,t:1527023513351};\\\", \\\"{x:844,y:655,t:1527023513368};\\\", \\\"{x:836,y:650,t:1527023513385};\\\", \\\"{x:826,y:643,t:1527023513402};\\\", \\\"{x:804,y:629,t:1527023513420};\\\", \\\"{x:769,y:613,t:1527023513434};\\\", \\\"{x:740,y:600,t:1527023513452};\\\", \\\"{x:727,y:597,t:1527023513461};\\\", \\\"{x:708,y:589,t:1527023513478};\\\", \\\"{x:688,y:583,t:1527023513494};\\\", \\\"{x:666,y:571,t:1527023513519};\\\", \\\"{x:665,y:570,t:1527023513535};\\\", \\\"{x:665,y:569,t:1527023513559};\\\", \\\"{x:667,y:568,t:1527023513568};\\\", \\\"{x:669,y:566,t:1527023513584};\\\", \\\"{x:671,y:566,t:1527023513601};\\\", \\\"{x:673,y:564,t:1527023513619};\\\", \\\"{x:674,y:562,t:1527023513635};\\\", \\\"{x:678,y:559,t:1527023513652};\\\", \\\"{x:680,y:557,t:1527023513669};\\\", \\\"{x:688,y:552,t:1527023513688};\\\", \\\"{x:700,y:547,t:1527023513702};\\\", \\\"{x:715,y:541,t:1527023513718};\\\", \\\"{x:724,y:539,t:1527023513735};\\\", \\\"{x:731,y:538,t:1527023513752};\\\", \\\"{x:735,y:537,t:1527023513769};\\\", \\\"{x:741,y:535,t:1527023513785};\\\", \\\"{x:743,y:534,t:1527023513802};\\\", \\\"{x:747,y:533,t:1527023513819};\\\", \\\"{x:750,y:531,t:1527023513835};\\\", \\\"{x:751,y:531,t:1527023513852};\\\", \\\"{x:753,y:531,t:1527023513869};\\\", \\\"{x:756,y:531,t:1527023513885};\\\", \\\"{x:760,y:530,t:1527023513902};\\\", \\\"{x:766,y:529,t:1527023513919};\\\", \\\"{x:769,y:529,t:1527023513935};\\\", \\\"{x:773,y:527,t:1527023513952};\\\", \\\"{x:775,y:526,t:1527023513970};\\\", \\\"{x:777,y:525,t:1527023513986};\\\", \\\"{x:780,y:522,t:1527023514003};\\\", \\\"{x:784,y:520,t:1527023514019};\\\", \\\"{x:788,y:519,t:1527023514036};\\\", \\\"{x:793,y:516,t:1527023514052};\\\", \\\"{x:796,y:515,t:1527023514069};\\\", \\\"{x:799,y:514,t:1527023514086};\\\", \\\"{x:803,y:511,t:1527023514102};\\\", \\\"{x:807,y:509,t:1527023514119};\\\", \\\"{x:810,y:508,t:1527023514136};\\\", \\\"{x:811,y:508,t:1527023514174};\\\", \\\"{x:813,y:507,t:1527023514207};\\\", \\\"{x:814,y:506,t:1527023514239};\\\", \\\"{x:814,y:505,t:1527023514510};\\\", \\\"{x:810,y:506,t:1527023514519};\\\", \\\"{x:802,y:507,t:1527023514535};\\\", \\\"{x:791,y:511,t:1527023514553};\\\", \\\"{x:782,y:514,t:1527023514568};\\\", \\\"{x:775,y:516,t:1527023514586};\\\", \\\"{x:766,y:517,t:1527023514603};\\\", \\\"{x:761,y:518,t:1527023514620};\\\", \\\"{x:758,y:519,t:1527023514636};\\\", \\\"{x:755,y:520,t:1527023514653};\\\", \\\"{x:750,y:522,t:1527023514670};\\\", \\\"{x:743,y:523,t:1527023514686};\\\", \\\"{x:730,y:528,t:1527023514704};\\\", \\\"{x:718,y:531,t:1527023514720};\\\", \\\"{x:711,y:531,t:1527023514736};\\\", \\\"{x:706,y:531,t:1527023514753};\\\", \\\"{x:704,y:531,t:1527023514769};\\\", \\\"{x:700,y:531,t:1527023514786};\\\", \\\"{x:693,y:531,t:1527023514803};\\\", \\\"{x:688,y:531,t:1527023514820};\\\", \\\"{x:685,y:531,t:1527023514835};\\\", \\\"{x:683,y:530,t:1527023514853};\\\", \\\"{x:682,y:530,t:1527023514870};\\\", \\\"{x:682,y:529,t:1527023514886};\\\", \\\"{x:681,y:528,t:1527023514902};\\\", \\\"{x:681,y:526,t:1527023514935};\\\", \\\"{x:681,y:525,t:1527023514942};\\\", \\\"{x:681,y:524,t:1527023514953};\\\", \\\"{x:686,y:521,t:1527023514970};\\\", \\\"{x:702,y:517,t:1527023514987};\\\", \\\"{x:723,y:514,t:1527023515002};\\\", \\\"{x:746,y:511,t:1527023515020};\\\", \\\"{x:768,y:510,t:1527023515036};\\\", \\\"{x:784,y:510,t:1527023515053};\\\", \\\"{x:798,y:510,t:1527023515069};\\\", \\\"{x:807,y:510,t:1527023515086};\\\", \\\"{x:811,y:509,t:1527023515102};\\\", \\\"{x:812,y:509,t:1527023515127};\\\", \\\"{x:813,y:508,t:1527023515143};\\\", \\\"{x:813,y:507,t:1527023515153};\\\", \\\"{x:816,y:506,t:1527023515170};\\\", \\\"{x:818,y:504,t:1527023515186};\\\", \\\"{x:821,y:503,t:1527023515203};\\\", \\\"{x:824,y:501,t:1527023515240};\\\", \\\"{x:825,y:501,t:1527023515255};\\\", \\\"{x:826,y:501,t:1527023515272};\\\", \\\"{x:824,y:501,t:1527023515447};\\\", \\\"{x:820,y:501,t:1527023515455};\\\", \\\"{x:814,y:503,t:1527023515470};\\\", \\\"{x:791,y:506,t:1527023515486};\\\", \\\"{x:778,y:509,t:1527023515503};\\\", \\\"{x:764,y:509,t:1527023515520};\\\", \\\"{x:752,y:509,t:1527023515537};\\\", \\\"{x:738,y:509,t:1527023515553};\\\", \\\"{x:724,y:509,t:1527023515570};\\\", \\\"{x:710,y:509,t:1527023515588};\\\", \\\"{x:702,y:509,t:1527023515604};\\\", \\\"{x:695,y:509,t:1527023515619};\\\", \\\"{x:686,y:509,t:1527023515637};\\\", \\\"{x:678,y:509,t:1527023515654};\\\", \\\"{x:665,y:509,t:1527023515670};\\\", \\\"{x:658,y:509,t:1527023515687};\\\", \\\"{x:653,y:509,t:1527023515704};\\\", \\\"{x:650,y:509,t:1527023515721};\\\", \\\"{x:649,y:509,t:1527023515751};\\\", \\\"{x:648,y:509,t:1527023515784};\\\", \\\"{x:647,y:509,t:1527023515791};\\\", \\\"{x:646,y:509,t:1527023515831};\\\", \\\"{x:646,y:508,t:1527023515839};\\\", \\\"{x:644,y:508,t:1527023515855};\\\", \\\"{x:634,y:506,t:1527023515872};\\\", \\\"{x:624,y:505,t:1527023515888};\\\", \\\"{x:617,y:503,t:1527023515904};\\\", \\\"{x:607,y:499,t:1527023515920};\\\", \\\"{x:600,y:497,t:1527023515937};\\\", \\\"{x:598,y:497,t:1527023515955};\\\", \\\"{x:597,y:497,t:1527023515970};\\\", \\\"{x:596,y:496,t:1527023515987};\\\", \\\"{x:597,y:496,t:1527023516775};\\\", \\\"{x:598,y:496,t:1527023516788};\\\", \\\"{x:599,y:496,t:1527023516805};\\\", \\\"{x:600,y:498,t:1527023516822};\\\", \\\"{x:601,y:499,t:1527023516838};\\\", \\\"{x:602,y:501,t:1527023516854};\\\", \\\"{x:603,y:502,t:1527023516878};\\\", \\\"{x:603,y:504,t:1527023516888};\\\", \\\"{x:603,y:510,t:1527023516905};\\\", \\\"{x:603,y:520,t:1527023516921};\\\", \\\"{x:603,y:532,t:1527023516938};\\\", \\\"{x:603,y:549,t:1527023516955};\\\", \\\"{x:597,y:570,t:1527023516972};\\\", \\\"{x:585,y:603,t:1527023516989};\\\", \\\"{x:568,y:638,t:1527023517005};\\\", \\\"{x:560,y:658,t:1527023517021};\\\", \\\"{x:556,y:665,t:1527023517038};\\\", \\\"{x:556,y:666,t:1527023517063};\\\", \\\"{x:558,y:665,t:1527023517095};\\\", \\\"{x:561,y:659,t:1527023517106};\\\", \\\"{x:571,y:638,t:1527023517122};\\\", \\\"{x:582,y:605,t:1527023517139};\\\", \\\"{x:594,y:558,t:1527023517157};\\\", \\\"{x:602,y:522,t:1527023517172};\\\", \\\"{x:606,y:512,t:1527023517188};\\\", \\\"{x:607,y:508,t:1527023517205};\\\", \\\"{x:608,y:505,t:1527023517221};\\\", \\\"{x:609,y:503,t:1527023517238};\\\", \\\"{x:609,y:502,t:1527023517255};\\\", \\\"{x:609,y:501,t:1527023517271};\\\", \\\"{x:608,y:505,t:1527023517583};\\\", \\\"{x:598,y:526,t:1527023517591};\\\", \\\"{x:590,y:557,t:1527023517606};\\\", \\\"{x:571,y:606,t:1527023517622};\\\", \\\"{x:551,y:641,t:1527023517638};\\\", \\\"{x:530,y:676,t:1527023517655};\\\", \\\"{x:523,y:691,t:1527023517672};\\\", \\\"{x:518,y:702,t:1527023517688};\\\", \\\"{x:513,y:717,t:1527023517704};\\\", \\\"{x:506,y:730,t:1527023517722};\\\", \\\"{x:503,y:734,t:1527023517739};\\\", \\\"{x:500,y:738,t:1527023517755};\\\", \\\"{x:499,y:739,t:1527023517775};\\\", \\\"{x:499,y:740,t:1527023517799};\\\", \\\"{x:498,y:740,t:1527023517806};\\\", \\\"{x:497,y:741,t:1527023517823};\\\", \\\"{x:497,y:742,t:1527023517871};\\\", \\\"{x:497,y:745,t:1527023517879};\\\", \\\"{x:497,y:748,t:1527023517889};\\\", \\\"{x:497,y:753,t:1527023517907};\\\", \\\"{x:497,y:756,t:1527023517925};\\\", \\\"{x:497,y:757,t:1527023517940};\\\", \\\"{x:498,y:756,t:1527023518015};\\\", \\\"{x:498,y:754,t:1527023518023};\\\", \\\"{x:499,y:751,t:1527023518039};\\\", \\\"{x:500,y:750,t:1527023518055};\\\" ] }, { \\\"rt\\\": 12170, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 552940, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -G -03 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:748,t:1527023520058};\\\", \\\"{x:516,y:736,t:1527023520066};\\\", \\\"{x:545,y:722,t:1527023520079};\\\", \\\"{x:614,y:693,t:1527023520095};\\\", \\\"{x:705,y:654,t:1527023520112};\\\", \\\"{x:827,y:592,t:1527023520128};\\\", \\\"{x:985,y:513,t:1527023520146};\\\", \\\"{x:1162,y:428,t:1527023520161};\\\", \\\"{x:1336,y:345,t:1527023520178};\\\", \\\"{x:1500,y:256,t:1527023520194};\\\", \\\"{x:1731,y:146,t:1527023520211};\\\", \\\"{x:1843,y:107,t:1527023520227};\\\", \\\"{x:1911,y:94,t:1527023520245};\\\", \\\"{x:1919,y:90,t:1527023520261};\\\", \\\"{x:1915,y:93,t:1527023520627};\\\", \\\"{x:1898,y:106,t:1527023520645};\\\", \\\"{x:1879,y:117,t:1527023520662};\\\", \\\"{x:1853,y:130,t:1527023520678};\\\", \\\"{x:1826,y:142,t:1527023520696};\\\", \\\"{x:1802,y:152,t:1527023520713};\\\", \\\"{x:1774,y:156,t:1527023520729};\\\", \\\"{x:1751,y:159,t:1527023520745};\\\", \\\"{x:1728,y:161,t:1527023520763};\\\", \\\"{x:1711,y:163,t:1527023520779};\\\", \\\"{x:1695,y:163,t:1527023520794};\\\", \\\"{x:1693,y:163,t:1527023520812};\\\", \\\"{x:1692,y:168,t:1527023521364};\\\", \\\"{x:1692,y:218,t:1527023521379};\\\", \\\"{x:1692,y:279,t:1527023521396};\\\", \\\"{x:1718,y:339,t:1527023521413};\\\", \\\"{x:1776,y:380,t:1527023521430};\\\", \\\"{x:1780,y:380,t:1527023521446};\\\", \\\"{x:1780,y:381,t:1527023522324};\\\", \\\"{x:1780,y:384,t:1527023522331};\\\", \\\"{x:1780,y:388,t:1527023522346};\\\", \\\"{x:1780,y:405,t:1527023522363};\\\", \\\"{x:1775,y:417,t:1527023522381};\\\", \\\"{x:1768,y:435,t:1527023522396};\\\", \\\"{x:1759,y:455,t:1527023522413};\\\", \\\"{x:1751,y:478,t:1527023522431};\\\", \\\"{x:1739,y:507,t:1527023522446};\\\", \\\"{x:1726,y:533,t:1527023522464};\\\", \\\"{x:1715,y:553,t:1527023522480};\\\", \\\"{x:1705,y:568,t:1527023522497};\\\", \\\"{x:1691,y:589,t:1527023522513};\\\", \\\"{x:1670,y:620,t:1527023522530};\\\", \\\"{x:1630,y:670,t:1527023522547};\\\", \\\"{x:1610,y:692,t:1527023522563};\\\", \\\"{x:1587,y:713,t:1527023522581};\\\", \\\"{x:1558,y:730,t:1527023522597};\\\", \\\"{x:1541,y:740,t:1527023522614};\\\", \\\"{x:1526,y:748,t:1527023522630};\\\", \\\"{x:1516,y:751,t:1527023522648};\\\", \\\"{x:1509,y:752,t:1527023522665};\\\", \\\"{x:1507,y:752,t:1527023522681};\\\", \\\"{x:1505,y:754,t:1527023522971};\\\", \\\"{x:1504,y:754,t:1527023522981};\\\", \\\"{x:1499,y:754,t:1527023522998};\\\", \\\"{x:1485,y:747,t:1527023523014};\\\", \\\"{x:1462,y:733,t:1527023523031};\\\", \\\"{x:1441,y:719,t:1527023523047};\\\", \\\"{x:1429,y:710,t:1527023523064};\\\", \\\"{x:1428,y:709,t:1527023523081};\\\", \\\"{x:1427,y:709,t:1527023523098};\\\", \\\"{x:1421,y:703,t:1527023523114};\\\", \\\"{x:1415,y:697,t:1527023523131};\\\", \\\"{x:1409,y:688,t:1527023523147};\\\", \\\"{x:1408,y:680,t:1527023523164};\\\", \\\"{x:1408,y:665,t:1527023523180};\\\", \\\"{x:1408,y:652,t:1527023523197};\\\", \\\"{x:1406,y:643,t:1527023523215};\\\", \\\"{x:1403,y:637,t:1527023523231};\\\", \\\"{x:1402,y:632,t:1527023523247};\\\", \\\"{x:1401,y:630,t:1527023523265};\\\", \\\"{x:1401,y:626,t:1527023523281};\\\", \\\"{x:1401,y:620,t:1527023523298};\\\", \\\"{x:1401,y:613,t:1527023523315};\\\", \\\"{x:1403,y:603,t:1527023523331};\\\", \\\"{x:1407,y:578,t:1527023523348};\\\", \\\"{x:1409,y:561,t:1527023523367};\\\", \\\"{x:1412,y:538,t:1527023523380};\\\", \\\"{x:1415,y:520,t:1527023523397};\\\", \\\"{x:1418,y:505,t:1527023523414};\\\", \\\"{x:1419,y:490,t:1527023523431};\\\", \\\"{x:1421,y:481,t:1527023523447};\\\", \\\"{x:1422,y:472,t:1527023523464};\\\", \\\"{x:1424,y:463,t:1527023523481};\\\", \\\"{x:1427,y:451,t:1527023523497};\\\", \\\"{x:1427,y:443,t:1527023523514};\\\", \\\"{x:1427,y:428,t:1527023523530};\\\", \\\"{x:1427,y:414,t:1527023523547};\\\", \\\"{x:1427,y:404,t:1527023523564};\\\", \\\"{x:1427,y:396,t:1527023523582};\\\", \\\"{x:1428,y:386,t:1527023523597};\\\", \\\"{x:1432,y:375,t:1527023523614};\\\", \\\"{x:1434,y:366,t:1527023523631};\\\", \\\"{x:1437,y:356,t:1527023523647};\\\", \\\"{x:1442,y:346,t:1527023523664};\\\", \\\"{x:1446,y:340,t:1527023523681};\\\", \\\"{x:1448,y:332,t:1527023523697};\\\", \\\"{x:1450,y:330,t:1527023523714};\\\", \\\"{x:1452,y:327,t:1527023523731};\\\", \\\"{x:1453,y:326,t:1527023523747};\\\", \\\"{x:1453,y:325,t:1527023523764};\\\", \\\"{x:1454,y:323,t:1527023523781};\\\", \\\"{x:1456,y:320,t:1527023523797};\\\", \\\"{x:1458,y:319,t:1527023523814};\\\", \\\"{x:1459,y:317,t:1527023523831};\\\", \\\"{x:1459,y:316,t:1527023523848};\\\", \\\"{x:1460,y:315,t:1527023523908};\\\", \\\"{x:1461,y:315,t:1527023523915};\\\", \\\"{x:1461,y:314,t:1527023523932};\\\", \\\"{x:1462,y:313,t:1527023523948};\\\", \\\"{x:1463,y:313,t:1527023523971};\\\", \\\"{x:1464,y:312,t:1527023524019};\\\", \\\"{x:1465,y:311,t:1527023524124};\\\", \\\"{x:1470,y:312,t:1527023524131};\\\", \\\"{x:1477,y:324,t:1527023524149};\\\", \\\"{x:1485,y:347,t:1527023524165};\\\", \\\"{x:1492,y:382,t:1527023524182};\\\", \\\"{x:1496,y:429,t:1527023524198};\\\", \\\"{x:1502,y:479,t:1527023524215};\\\", \\\"{x:1511,y:519,t:1527023524231};\\\", \\\"{x:1518,y:559,t:1527023524249};\\\", \\\"{x:1520,y:592,t:1527023524265};\\\", \\\"{x:1520,y:626,t:1527023524282};\\\", \\\"{x:1521,y:659,t:1527023524298};\\\", \\\"{x:1521,y:711,t:1527023524315};\\\", \\\"{x:1521,y:742,t:1527023524332};\\\", \\\"{x:1521,y:776,t:1527023524348};\\\", \\\"{x:1521,y:814,t:1527023524365};\\\", \\\"{x:1513,y:849,t:1527023524382};\\\", \\\"{x:1506,y:876,t:1527023524399};\\\", \\\"{x:1492,y:901,t:1527023524415};\\\", \\\"{x:1483,y:914,t:1527023524432};\\\", \\\"{x:1473,y:921,t:1527023524449};\\\", \\\"{x:1461,y:925,t:1527023524466};\\\", \\\"{x:1449,y:930,t:1527023524482};\\\", \\\"{x:1430,y:932,t:1527023524499};\\\", \\\"{x:1407,y:938,t:1527023524515};\\\", \\\"{x:1399,y:940,t:1527023524532};\\\", \\\"{x:1394,y:940,t:1527023524548};\\\", \\\"{x:1392,y:940,t:1527023524566};\\\", \\\"{x:1391,y:940,t:1527023524587};\\\", \\\"{x:1390,y:940,t:1527023524611};\\\", \\\"{x:1389,y:940,t:1527023524620};\\\", \\\"{x:1388,y:940,t:1527023524632};\\\", \\\"{x:1386,y:940,t:1527023524649};\\\", \\\"{x:1385,y:940,t:1527023524665};\\\", \\\"{x:1383,y:940,t:1527023524682};\\\", \\\"{x:1380,y:941,t:1527023524699};\\\", \\\"{x:1375,y:942,t:1527023524715};\\\", \\\"{x:1374,y:944,t:1527023524732};\\\", \\\"{x:1373,y:944,t:1527023524763};\\\", \\\"{x:1373,y:946,t:1527023524779};\\\", \\\"{x:1378,y:947,t:1527023524787};\\\", \\\"{x:1382,y:948,t:1527023524798};\\\", \\\"{x:1396,y:949,t:1527023524815};\\\", \\\"{x:1407,y:953,t:1527023524833};\\\", \\\"{x:1419,y:954,t:1527023524849};\\\", \\\"{x:1437,y:957,t:1527023524866};\\\", \\\"{x:1469,y:961,t:1527023524883};\\\", \\\"{x:1477,y:962,t:1527023524898};\\\", \\\"{x:1512,y:963,t:1527023524916};\\\", \\\"{x:1532,y:965,t:1527023524933};\\\", \\\"{x:1545,y:965,t:1527023524948};\\\", \\\"{x:1551,y:965,t:1527023524965};\\\", \\\"{x:1555,y:966,t:1527023524983};\\\", \\\"{x:1558,y:967,t:1527023524998};\\\", \\\"{x:1559,y:968,t:1527023525015};\\\", \\\"{x:1561,y:968,t:1527023525032};\\\", \\\"{x:1562,y:968,t:1527023525049};\\\", \\\"{x:1565,y:968,t:1527023525065};\\\", \\\"{x:1568,y:968,t:1527023525082};\\\", \\\"{x:1575,y:970,t:1527023525099};\\\", \\\"{x:1580,y:970,t:1527023525115};\\\", \\\"{x:1586,y:971,t:1527023525133};\\\", \\\"{x:1588,y:971,t:1527023525149};\\\", \\\"{x:1589,y:971,t:1527023525165};\\\", \\\"{x:1588,y:971,t:1527023525219};\\\", \\\"{x:1585,y:971,t:1527023525232};\\\", \\\"{x:1574,y:971,t:1527023525249};\\\", \\\"{x:1555,y:969,t:1527023525265};\\\", \\\"{x:1525,y:962,t:1527023525283};\\\", \\\"{x:1512,y:958,t:1527023525299};\\\", \\\"{x:1506,y:958,t:1527023525315};\\\", \\\"{x:1506,y:957,t:1527023525332};\\\", \\\"{x:1505,y:956,t:1527023525387};\\\", \\\"{x:1506,y:955,t:1527023525467};\\\", \\\"{x:1507,y:955,t:1527023525491};\\\", \\\"{x:1508,y:955,t:1527023525499};\\\", \\\"{x:1510,y:955,t:1527023525516};\\\", \\\"{x:1517,y:955,t:1527023525533};\\\", \\\"{x:1524,y:955,t:1527023525549};\\\", \\\"{x:1530,y:952,t:1527023525566};\\\", \\\"{x:1535,y:951,t:1527023525582};\\\", \\\"{x:1539,y:951,t:1527023525599};\\\", \\\"{x:1542,y:951,t:1527023525617};\\\", \\\"{x:1543,y:951,t:1527023525635};\\\", \\\"{x:1543,y:949,t:1527023525748};\\\", \\\"{x:1543,y:948,t:1527023525755};\\\", \\\"{x:1543,y:946,t:1527023525767};\\\", \\\"{x:1541,y:940,t:1527023525783};\\\", \\\"{x:1537,y:934,t:1527023525800};\\\", \\\"{x:1533,y:930,t:1527023525817};\\\", \\\"{x:1530,y:926,t:1527023525833};\\\", \\\"{x:1527,y:921,t:1527023525850};\\\", \\\"{x:1522,y:912,t:1527023525867};\\\", \\\"{x:1519,y:903,t:1527023525883};\\\", \\\"{x:1513,y:886,t:1527023525899};\\\", \\\"{x:1508,y:873,t:1527023525917};\\\", \\\"{x:1505,y:865,t:1527023525933};\\\", \\\"{x:1502,y:860,t:1527023525950};\\\", \\\"{x:1501,y:856,t:1527023525966};\\\", \\\"{x:1500,y:852,t:1527023525983};\\\", \\\"{x:1499,y:848,t:1527023525999};\\\", \\\"{x:1497,y:841,t:1527023526017};\\\", \\\"{x:1494,y:834,t:1527023526034};\\\", \\\"{x:1493,y:828,t:1527023526050};\\\", \\\"{x:1491,y:824,t:1527023526067};\\\", \\\"{x:1491,y:823,t:1527023526083};\\\", \\\"{x:1488,y:821,t:1527023526179};\\\", \\\"{x:1488,y:820,t:1527023526187};\\\", \\\"{x:1486,y:819,t:1527023526200};\\\", \\\"{x:1482,y:816,t:1527023526217};\\\", \\\"{x:1479,y:814,t:1527023526233};\\\", \\\"{x:1478,y:814,t:1527023526250};\\\", \\\"{x:1477,y:814,t:1527023526315};\\\", \\\"{x:1476,y:815,t:1527023526331};\\\", \\\"{x:1475,y:817,t:1527023526339};\\\", \\\"{x:1475,y:820,t:1527023526350};\\\", \\\"{x:1475,y:822,t:1527023526367};\\\", \\\"{x:1475,y:823,t:1527023526387};\\\", \\\"{x:1475,y:825,t:1527023526403};\\\", \\\"{x:1475,y:826,t:1527023526416};\\\", \\\"{x:1478,y:830,t:1527023526434};\\\", \\\"{x:1479,y:831,t:1527023526450};\\\", \\\"{x:1481,y:831,t:1527023528027};\\\", \\\"{x:1479,y:831,t:1527023528034};\\\", \\\"{x:1448,y:830,t:1527023528053};\\\", \\\"{x:1364,y:815,t:1527023528068};\\\", \\\"{x:1253,y:799,t:1527023528085};\\\", \\\"{x:1128,y:774,t:1527023528102};\\\", \\\"{x:1003,y:740,t:1527023528119};\\\", \\\"{x:887,y:709,t:1527023528135};\\\", \\\"{x:790,y:681,t:1527023528152};\\\", \\\"{x:718,y:661,t:1527023528168};\\\", \\\"{x:695,y:653,t:1527023528185};\\\", \\\"{x:684,y:650,t:1527023528202};\\\", \\\"{x:673,y:645,t:1527023528219};\\\", \\\"{x:663,y:640,t:1527023528235};\\\", \\\"{x:661,y:640,t:1527023528251};\\\", \\\"{x:652,y:637,t:1527023528269};\\\", \\\"{x:633,y:629,t:1527023528285};\\\", \\\"{x:611,y:620,t:1527023528302};\\\", \\\"{x:597,y:611,t:1527023528318};\\\", \\\"{x:589,y:605,t:1527023528334};\\\", \\\"{x:582,y:600,t:1527023528352};\\\", \\\"{x:574,y:594,t:1527023528368};\\\", \\\"{x:569,y:591,t:1527023528384};\\\", \\\"{x:559,y:588,t:1527023528401};\\\", \\\"{x:533,y:588,t:1527023528418};\\\", \\\"{x:508,y:588,t:1527023528434};\\\", \\\"{x:480,y:583,t:1527023528452};\\\", \\\"{x:440,y:576,t:1527023528468};\\\", \\\"{x:406,y:573,t:1527023528485};\\\", \\\"{x:380,y:569,t:1527023528501};\\\", \\\"{x:353,y:568,t:1527023528519};\\\", \\\"{x:332,y:564,t:1527023528534};\\\", \\\"{x:319,y:562,t:1527023528552};\\\", \\\"{x:313,y:562,t:1527023528568};\\\", \\\"{x:311,y:562,t:1527023528584};\\\", \\\"{x:309,y:562,t:1527023528601};\\\", \\\"{x:313,y:563,t:1527023528668};\\\", \\\"{x:319,y:565,t:1527023528685};\\\", \\\"{x:330,y:569,t:1527023528701};\\\", \\\"{x:343,y:574,t:1527023528718};\\\", \\\"{x:358,y:575,t:1527023528735};\\\", \\\"{x:375,y:578,t:1527023528751};\\\", \\\"{x:393,y:580,t:1527023528768};\\\", \\\"{x:412,y:583,t:1527023528785};\\\", \\\"{x:426,y:583,t:1527023528801};\\\", \\\"{x:433,y:583,t:1527023528818};\\\", \\\"{x:434,y:583,t:1527023528842};\\\", \\\"{x:436,y:583,t:1527023528858};\\\", \\\"{x:437,y:582,t:1527023528868};\\\", \\\"{x:442,y:582,t:1527023528885};\\\", \\\"{x:454,y:579,t:1527023528902};\\\", \\\"{x:474,y:578,t:1527023528918};\\\", \\\"{x:502,y:574,t:1527023528936};\\\", \\\"{x:528,y:572,t:1527023528952};\\\", \\\"{x:549,y:568,t:1527023528969};\\\", \\\"{x:567,y:567,t:1527023528985};\\\", \\\"{x:581,y:564,t:1527023529002};\\\", \\\"{x:588,y:563,t:1527023529018};\\\", \\\"{x:589,y:563,t:1527023529036};\\\", \\\"{x:590,y:563,t:1527023529053};\\\", \\\"{x:592,y:562,t:1527023529069};\\\", \\\"{x:593,y:562,t:1527023529091};\\\", \\\"{x:593,y:561,t:1527023529107};\\\", \\\"{x:594,y:561,t:1527023529139};\\\", \\\"{x:595,y:561,t:1527023529163};\\\", \\\"{x:596,y:561,t:1527023529171};\\\", \\\"{x:597,y:561,t:1527023529185};\\\", \\\"{x:600,y:561,t:1527023529202};\\\", \\\"{x:604,y:562,t:1527023529219};\\\", \\\"{x:606,y:567,t:1527023529237};\\\", \\\"{x:608,y:571,t:1527023529253};\\\", \\\"{x:611,y:577,t:1527023529268};\\\", \\\"{x:612,y:579,t:1527023529285};\\\", \\\"{x:613,y:581,t:1527023529302};\\\", \\\"{x:614,y:581,t:1527023529378};\\\", \\\"{x:615,y:581,t:1527023529386};\\\", \\\"{x:615,y:581,t:1527023529478};\\\", \\\"{x:616,y:583,t:1527023529755};\\\", \\\"{x:616,y:587,t:1527023529769};\\\", \\\"{x:616,y:598,t:1527023529786};\\\", \\\"{x:616,y:615,t:1527023529802};\\\", \\\"{x:616,y:628,t:1527023529820};\\\", \\\"{x:616,y:641,t:1527023529837};\\\", \\\"{x:615,y:652,t:1527023529852};\\\", \\\"{x:613,y:659,t:1527023529869};\\\", \\\"{x:609,y:666,t:1527023529887};\\\", \\\"{x:605,y:674,t:1527023529902};\\\", \\\"{x:599,y:686,t:1527023529919};\\\", \\\"{x:590,y:698,t:1527023529936};\\\", \\\"{x:583,y:707,t:1527023529952};\\\", \\\"{x:580,y:711,t:1527023529969};\\\", \\\"{x:576,y:715,t:1527023529986};\\\", \\\"{x:571,y:717,t:1527023530002};\\\", \\\"{x:569,y:719,t:1527023530019};\\\", \\\"{x:566,y:722,t:1527023530036};\\\", \\\"{x:563,y:724,t:1527023530053};\\\", \\\"{x:559,y:726,t:1527023530069};\\\", \\\"{x:558,y:726,t:1527023530091};\\\", \\\"{x:558,y:727,t:1527023530147};\\\", \\\"{x:557,y:727,t:1527023530154};\\\", \\\"{x:556,y:727,t:1527023530171};\\\", \\\"{x:554,y:728,t:1527023530187};\\\", \\\"{x:553,y:728,t:1527023530203};\\\", \\\"{x:548,y:728,t:1527023530219};\\\", \\\"{x:546,y:728,t:1527023530236};\\\", \\\"{x:544,y:728,t:1527023530323};\\\", \\\"{x:543,y:728,t:1527023530339};\\\", \\\"{x:541,y:728,t:1527023530379};\\\", \\\"{x:539,y:727,t:1527023530394};\\\" ] }, { \\\"rt\\\": 24779, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 578986, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -11 AM-12 PM-F -01 PM-02 PM-X -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:722,t:1527023537331};\\\", \\\"{x:535,y:710,t:1527023537343};\\\", \\\"{x:534,y:703,t:1527023537359};\\\", \\\"{x:529,y:685,t:1527023537377};\\\", \\\"{x:523,y:662,t:1527023537392};\\\", \\\"{x:519,y:644,t:1527023537411};\\\", \\\"{x:517,y:626,t:1527023537426};\\\", \\\"{x:517,y:600,t:1527023537442};\\\", \\\"{x:517,y:558,t:1527023537459};\\\", \\\"{x:521,y:529,t:1527023537476};\\\", \\\"{x:528,y:502,t:1527023537493};\\\", \\\"{x:533,y:477,t:1527023537509};\\\", \\\"{x:539,y:456,t:1527023537526};\\\", \\\"{x:544,y:439,t:1527023537542};\\\", \\\"{x:548,y:425,t:1527023537559};\\\", \\\"{x:552,y:414,t:1527023537576};\\\", \\\"{x:555,y:407,t:1527023537592};\\\", \\\"{x:558,y:400,t:1527023537609};\\\", \\\"{x:559,y:398,t:1527023537625};\\\", \\\"{x:560,y:398,t:1527023537770};\\\", \\\"{x:562,y:400,t:1527023537778};\\\", \\\"{x:566,y:406,t:1527023537793};\\\", \\\"{x:571,y:418,t:1527023537808};\\\", \\\"{x:572,y:426,t:1527023537825};\\\", \\\"{x:576,y:439,t:1527023537843};\\\", \\\"{x:578,y:444,t:1527023537859};\\\", \\\"{x:578,y:447,t:1527023537876};\\\", \\\"{x:578,y:448,t:1527023537893};\\\", \\\"{x:578,y:450,t:1527023537910};\\\", \\\"{x:579,y:451,t:1527023537926};\\\", \\\"{x:580,y:453,t:1527023538203};\\\", \\\"{x:582,y:457,t:1527023538211};\\\", \\\"{x:585,y:463,t:1527023538227};\\\", \\\"{x:587,y:467,t:1527023538243};\\\", \\\"{x:589,y:472,t:1527023538260};\\\", \\\"{x:592,y:475,t:1527023538277};\\\", \\\"{x:594,y:479,t:1527023538293};\\\", \\\"{x:595,y:480,t:1527023538310};\\\", \\\"{x:595,y:481,t:1527023538327};\\\", \\\"{x:596,y:481,t:1527023538531};\\\", \\\"{x:596,y:480,t:1527023538543};\\\", \\\"{x:596,y:478,t:1527023538560};\\\", \\\"{x:597,y:476,t:1527023538578};\\\", \\\"{x:597,y:474,t:1527023538594};\\\", \\\"{x:598,y:473,t:1527023538610};\\\", \\\"{x:599,y:472,t:1527023538627};\\\", \\\"{x:598,y:471,t:1527023539235};\\\", \\\"{x:597,y:470,t:1527023539362};\\\", \\\"{x:598,y:468,t:1527023539378};\\\", \\\"{x:601,y:467,t:1527023539393};\\\", \\\"{x:623,y:458,t:1527023539410};\\\", \\\"{x:654,y:456,t:1527023539428};\\\", \\\"{x:713,y:456,t:1527023539443};\\\", \\\"{x:799,y:456,t:1527023539461};\\\", \\\"{x:910,y:456,t:1527023539477};\\\", \\\"{x:1032,y:456,t:1527023539494};\\\", \\\"{x:1153,y:456,t:1527023539511};\\\", \\\"{x:1258,y:465,t:1527023539528};\\\", \\\"{x:1347,y:476,t:1527023539544};\\\", \\\"{x:1410,y:492,t:1527023539561};\\\", \\\"{x:1449,y:503,t:1527023539577};\\\", \\\"{x:1465,y:510,t:1527023539594};\\\", \\\"{x:1471,y:513,t:1527023539611};\\\", \\\"{x:1472,y:514,t:1527023539628};\\\", \\\"{x:1472,y:516,t:1527023539651};\\\", \\\"{x:1472,y:517,t:1527023539661};\\\", \\\"{x:1470,y:518,t:1527023539679};\\\", \\\"{x:1468,y:520,t:1527023539695};\\\", \\\"{x:1466,y:523,t:1527023539711};\\\", \\\"{x:1465,y:528,t:1527023539728};\\\", \\\"{x:1463,y:531,t:1527023539744};\\\", \\\"{x:1459,y:535,t:1527023539761};\\\", \\\"{x:1451,y:544,t:1527023539778};\\\", \\\"{x:1444,y:554,t:1527023539795};\\\", \\\"{x:1438,y:565,t:1527023539811};\\\", \\\"{x:1432,y:575,t:1527023539829};\\\", \\\"{x:1423,y:588,t:1527023539844};\\\", \\\"{x:1412,y:603,t:1527023539862};\\\", \\\"{x:1400,y:620,t:1527023539879};\\\", \\\"{x:1387,y:636,t:1527023539895};\\\", \\\"{x:1378,y:651,t:1527023539912};\\\", \\\"{x:1369,y:663,t:1527023539928};\\\", \\\"{x:1362,y:679,t:1527023539945};\\\", \\\"{x:1353,y:698,t:1527023539964};\\\", \\\"{x:1344,y:717,t:1527023539979};\\\", \\\"{x:1333,y:785,t:1527023539995};\\\", \\\"{x:1319,y:848,t:1527023540011};\\\", \\\"{x:1310,y:896,t:1527023540029};\\\", \\\"{x:1306,y:926,t:1527023540045};\\\", \\\"{x:1306,y:948,t:1527023540062};\\\", \\\"{x:1304,y:964,t:1527023540079};\\\", \\\"{x:1303,y:969,t:1527023540095};\\\", \\\"{x:1300,y:974,t:1527023540112};\\\", \\\"{x:1297,y:977,t:1527023540128};\\\", \\\"{x:1297,y:978,t:1527023540147};\\\", \\\"{x:1298,y:978,t:1527023540235};\\\", \\\"{x:1301,y:976,t:1527023540245};\\\", \\\"{x:1308,y:974,t:1527023540262};\\\", \\\"{x:1317,y:972,t:1527023540278};\\\", \\\"{x:1323,y:970,t:1527023540295};\\\", \\\"{x:1330,y:969,t:1527023540311};\\\", \\\"{x:1339,y:968,t:1527023540329};\\\", \\\"{x:1347,y:968,t:1527023540345};\\\", \\\"{x:1356,y:964,t:1527023540362};\\\", \\\"{x:1358,y:963,t:1527023540379};\\\", \\\"{x:1362,y:961,t:1527023540395};\\\", \\\"{x:1363,y:960,t:1527023540412};\\\", \\\"{x:1364,y:959,t:1527023540539};\\\", \\\"{x:1366,y:958,t:1527023540546};\\\", \\\"{x:1367,y:957,t:1527023540562};\\\", \\\"{x:1368,y:957,t:1527023540578};\\\", \\\"{x:1371,y:957,t:1527023540595};\\\", \\\"{x:1372,y:957,t:1527023540612};\\\", \\\"{x:1374,y:955,t:1527023540629};\\\", \\\"{x:1375,y:955,t:1527023540645};\\\", \\\"{x:1376,y:955,t:1527023540662};\\\", \\\"{x:1379,y:955,t:1527023540678};\\\", \\\"{x:1381,y:955,t:1527023540695};\\\", \\\"{x:1385,y:955,t:1527023540712};\\\", \\\"{x:1388,y:955,t:1527023540728};\\\", \\\"{x:1389,y:955,t:1527023540745};\\\", \\\"{x:1391,y:955,t:1527023540819};\\\", \\\"{x:1392,y:955,t:1527023540830};\\\", \\\"{x:1394,y:955,t:1527023540845};\\\", \\\"{x:1395,y:955,t:1527023540862};\\\", \\\"{x:1399,y:955,t:1527023540879};\\\", \\\"{x:1400,y:955,t:1527023540895};\\\", \\\"{x:1401,y:955,t:1527023541139};\\\", \\\"{x:1404,y:955,t:1527023541147};\\\", \\\"{x:1407,y:954,t:1527023541162};\\\", \\\"{x:1420,y:954,t:1527023541179};\\\", \\\"{x:1437,y:954,t:1527023541196};\\\", \\\"{x:1449,y:954,t:1527023541212};\\\", \\\"{x:1466,y:954,t:1527023541230};\\\", \\\"{x:1474,y:954,t:1527023541246};\\\", \\\"{x:1476,y:954,t:1527023541262};\\\", \\\"{x:1478,y:954,t:1527023541280};\\\", \\\"{x:1479,y:954,t:1527023541296};\\\", \\\"{x:1480,y:954,t:1527023541387};\\\", \\\"{x:1481,y:954,t:1527023541396};\\\", \\\"{x:1482,y:954,t:1527023541427};\\\", \\\"{x:1481,y:951,t:1527023541731};\\\", \\\"{x:1476,y:947,t:1527023541747};\\\", \\\"{x:1467,y:939,t:1527023541763};\\\", \\\"{x:1457,y:928,t:1527023541779};\\\", \\\"{x:1445,y:914,t:1527023541797};\\\", \\\"{x:1427,y:894,t:1527023541813};\\\", \\\"{x:1410,y:868,t:1527023541830};\\\", \\\"{x:1402,y:852,t:1527023541846};\\\", \\\"{x:1399,y:842,t:1527023541864};\\\", \\\"{x:1395,y:830,t:1527023541880};\\\", \\\"{x:1391,y:816,t:1527023541897};\\\", \\\"{x:1389,y:810,t:1527023541914};\\\", \\\"{x:1389,y:807,t:1527023541929};\\\", \\\"{x:1389,y:804,t:1527023541947};\\\", \\\"{x:1387,y:796,t:1527023541963};\\\", \\\"{x:1387,y:791,t:1527023541979};\\\", \\\"{x:1386,y:782,t:1527023541996};\\\", \\\"{x:1383,y:772,t:1527023542014};\\\", \\\"{x:1382,y:766,t:1527023542030};\\\", \\\"{x:1379,y:759,t:1527023542047};\\\", \\\"{x:1378,y:754,t:1527023542064};\\\", \\\"{x:1376,y:750,t:1527023542079};\\\", \\\"{x:1374,y:746,t:1527023542097};\\\", \\\"{x:1371,y:740,t:1527023542113};\\\", \\\"{x:1367,y:733,t:1527023542132};\\\", \\\"{x:1367,y:732,t:1527023542147};\\\", \\\"{x:1365,y:728,t:1527023542164};\\\", \\\"{x:1364,y:727,t:1527023542181};\\\", \\\"{x:1363,y:724,t:1527023542196};\\\", \\\"{x:1360,y:720,t:1527023542213};\\\", \\\"{x:1357,y:714,t:1527023542230};\\\", \\\"{x:1356,y:712,t:1527023542247};\\\", \\\"{x:1355,y:709,t:1527023542264};\\\", \\\"{x:1353,y:708,t:1527023542281};\\\", \\\"{x:1352,y:706,t:1527023542296};\\\", \\\"{x:1351,y:705,t:1527023542316};\\\", \\\"{x:1351,y:704,t:1527023542355};\\\", \\\"{x:1350,y:702,t:1527023542637};\\\", \\\"{x:1349,y:700,t:1527023542647};\\\", \\\"{x:1348,y:698,t:1527023542662};\\\", \\\"{x:1348,y:697,t:1527023542680};\\\", \\\"{x:1347,y:695,t:1527023542698};\\\", \\\"{x:1347,y:694,t:1527023548299};\\\", \\\"{x:1347,y:696,t:1527023548475};\\\", \\\"{x:1362,y:716,t:1527023548486};\\\", \\\"{x:1372,y:733,t:1527023548501};\\\", \\\"{x:1374,y:747,t:1527023548519};\\\", \\\"{x:1378,y:759,t:1527023548535};\\\", \\\"{x:1383,y:774,t:1527023548552};\\\", \\\"{x:1388,y:786,t:1527023548569};\\\", \\\"{x:1391,y:795,t:1527023548585};\\\", \\\"{x:1392,y:802,t:1527023548601};\\\", \\\"{x:1394,y:822,t:1527023548619};\\\", \\\"{x:1394,y:828,t:1527023548635};\\\", \\\"{x:1394,y:832,t:1527023548652};\\\", \\\"{x:1394,y:834,t:1527023548674};\\\", \\\"{x:1394,y:837,t:1527023548685};\\\", \\\"{x:1394,y:849,t:1527023548702};\\\", \\\"{x:1397,y:868,t:1527023548719};\\\", \\\"{x:1403,y:890,t:1527023548735};\\\", \\\"{x:1407,y:906,t:1527023548752};\\\", \\\"{x:1408,y:919,t:1527023548769};\\\", \\\"{x:1410,y:928,t:1527023548786};\\\", \\\"{x:1413,y:933,t:1527023548802};\\\", \\\"{x:1416,y:941,t:1527023548819};\\\", \\\"{x:1416,y:942,t:1527023548836};\\\", \\\"{x:1416,y:944,t:1527023548899};\\\", \\\"{x:1416,y:945,t:1527023548915};\\\", \\\"{x:1417,y:946,t:1527023548923};\\\", \\\"{x:1417,y:947,t:1527023548939};\\\", \\\"{x:1419,y:948,t:1527023548955};\\\", \\\"{x:1420,y:950,t:1527023548971};\\\", \\\"{x:1421,y:951,t:1527023548986};\\\", \\\"{x:1421,y:956,t:1527023549001};\\\", \\\"{x:1423,y:964,t:1527023549019};\\\", \\\"{x:1424,y:968,t:1527023549035};\\\", \\\"{x:1424,y:969,t:1527023549052};\\\", \\\"{x:1424,y:972,t:1527023549068};\\\", \\\"{x:1424,y:978,t:1527023549085};\\\", \\\"{x:1425,y:983,t:1527023549101};\\\", \\\"{x:1426,y:984,t:1527023549118};\\\", \\\"{x:1428,y:984,t:1527023549138};\\\", \\\"{x:1431,y:983,t:1527023549152};\\\", \\\"{x:1439,y:979,t:1527023549168};\\\", \\\"{x:1446,y:972,t:1527023549185};\\\", \\\"{x:1457,y:960,t:1527023549202};\\\", \\\"{x:1462,y:957,t:1527023549218};\\\", \\\"{x:1464,y:955,t:1527023549235};\\\", \\\"{x:1467,y:955,t:1527023549299};\\\", \\\"{x:1469,y:955,t:1527023549307};\\\", \\\"{x:1472,y:955,t:1527023549319};\\\", \\\"{x:1478,y:956,t:1527023549336};\\\", \\\"{x:1482,y:958,t:1527023549352};\\\", \\\"{x:1485,y:961,t:1527023549369};\\\", \\\"{x:1489,y:964,t:1527023549386};\\\", \\\"{x:1491,y:972,t:1527023549402};\\\", \\\"{x:1491,y:974,t:1527023549435};\\\", \\\"{x:1490,y:974,t:1527023549507};\\\", \\\"{x:1490,y:971,t:1527023549519};\\\", \\\"{x:1487,y:965,t:1527023549536};\\\", \\\"{x:1487,y:963,t:1527023549553};\\\", \\\"{x:1487,y:962,t:1527023549569};\\\", \\\"{x:1485,y:960,t:1527023549586};\\\", \\\"{x:1484,y:959,t:1527023549611};\\\", \\\"{x:1483,y:958,t:1527023549667};\\\", \\\"{x:1482,y:958,t:1527023549788};\\\", \\\"{x:1481,y:958,t:1527023549803};\\\", \\\"{x:1478,y:956,t:1527023549820};\\\", \\\"{x:1477,y:955,t:1527023549835};\\\", \\\"{x:1475,y:953,t:1527023549853};\\\", \\\"{x:1475,y:952,t:1527023549891};\\\", \\\"{x:1475,y:951,t:1527023549906};\\\", \\\"{x:1475,y:950,t:1527023549931};\\\", \\\"{x:1475,y:949,t:1527023549940};\\\", \\\"{x:1475,y:948,t:1527023549955};\\\", \\\"{x:1475,y:947,t:1527023549978};\\\", \\\"{x:1475,y:945,t:1527023549986};\\\", \\\"{x:1475,y:942,t:1527023550002};\\\", \\\"{x:1476,y:938,t:1527023550020};\\\", \\\"{x:1478,y:934,t:1527023550036};\\\", \\\"{x:1478,y:929,t:1527023550053};\\\", \\\"{x:1480,y:922,t:1527023550070};\\\", \\\"{x:1480,y:914,t:1527023550087};\\\", \\\"{x:1480,y:907,t:1527023550103};\\\", \\\"{x:1480,y:899,t:1527023550120};\\\", \\\"{x:1477,y:886,t:1527023550137};\\\", \\\"{x:1474,y:877,t:1527023550153};\\\", \\\"{x:1473,y:872,t:1527023550170};\\\", \\\"{x:1473,y:868,t:1527023550187};\\\", \\\"{x:1473,y:866,t:1527023550203};\\\", \\\"{x:1473,y:865,t:1527023550219};\\\", \\\"{x:1473,y:862,t:1527023550237};\\\", \\\"{x:1473,y:860,t:1527023550253};\\\", \\\"{x:1473,y:858,t:1527023550270};\\\", \\\"{x:1473,y:856,t:1527023550287};\\\", \\\"{x:1473,y:852,t:1527023550303};\\\", \\\"{x:1473,y:850,t:1527023550320};\\\", \\\"{x:1473,y:849,t:1527023550337};\\\", \\\"{x:1473,y:846,t:1527023550353};\\\", \\\"{x:1473,y:845,t:1527023550369};\\\", \\\"{x:1473,y:844,t:1527023550388};\\\", \\\"{x:1473,y:843,t:1527023550498};\\\", \\\"{x:1473,y:842,t:1527023550506};\\\", \\\"{x:1472,y:842,t:1527023550554};\\\", \\\"{x:1472,y:841,t:1527023550570};\\\", \\\"{x:1472,y:840,t:1527023550618};\\\", \\\"{x:1472,y:839,t:1527023550651};\\\", \\\"{x:1472,y:838,t:1527023550658};\\\", \\\"{x:1472,y:837,t:1527023550723};\\\", \\\"{x:1472,y:836,t:1527023551579};\\\", \\\"{x:1472,y:835,t:1527023551595};\\\", \\\"{x:1472,y:833,t:1527023551611};\\\", \\\"{x:1472,y:832,t:1527023551621};\\\", \\\"{x:1473,y:830,t:1527023551637};\\\", \\\"{x:1474,y:828,t:1527023551653};\\\", \\\"{x:1474,y:823,t:1527023551671};\\\", \\\"{x:1477,y:815,t:1527023551688};\\\", \\\"{x:1477,y:810,t:1527023551704};\\\", \\\"{x:1478,y:806,t:1527023551720};\\\", \\\"{x:1478,y:803,t:1527023551738};\\\", \\\"{x:1478,y:799,t:1527023551907};\\\", \\\"{x:1478,y:795,t:1527023551921};\\\", \\\"{x:1478,y:785,t:1527023551938};\\\", \\\"{x:1473,y:768,t:1527023551955};\\\", \\\"{x:1470,y:751,t:1527023551971};\\\", \\\"{x:1467,y:738,t:1527023551988};\\\", \\\"{x:1466,y:726,t:1527023552005};\\\", \\\"{x:1463,y:716,t:1527023552021};\\\", \\\"{x:1462,y:710,t:1527023552038};\\\", \\\"{x:1462,y:709,t:1527023552055};\\\", \\\"{x:1462,y:704,t:1527023552070};\\\", \\\"{x:1462,y:703,t:1527023552088};\\\", \\\"{x:1462,y:702,t:1527023552104};\\\", \\\"{x:1462,y:701,t:1527023552121};\\\", \\\"{x:1462,y:700,t:1527023552162};\\\", \\\"{x:1462,y:699,t:1527023552178};\\\", \\\"{x:1462,y:697,t:1527023552187};\\\", \\\"{x:1462,y:695,t:1527023552204};\\\", \\\"{x:1463,y:693,t:1527023552221};\\\", \\\"{x:1464,y:687,t:1527023552238};\\\", \\\"{x:1466,y:684,t:1527023552254};\\\", \\\"{x:1467,y:682,t:1527023552271};\\\", \\\"{x:1467,y:680,t:1527023552287};\\\", \\\"{x:1469,y:679,t:1527023552304};\\\", \\\"{x:1469,y:677,t:1527023552321};\\\", \\\"{x:1469,y:676,t:1527023552347};\\\", \\\"{x:1469,y:674,t:1527023552355};\\\", \\\"{x:1469,y:671,t:1527023552371};\\\", \\\"{x:1470,y:665,t:1527023552388};\\\", \\\"{x:1470,y:661,t:1527023552405};\\\", \\\"{x:1470,y:659,t:1527023552579};\\\", \\\"{x:1471,y:658,t:1527023552588};\\\", \\\"{x:1471,y:655,t:1527023552605};\\\", \\\"{x:1471,y:645,t:1527023552622};\\\", \\\"{x:1472,y:640,t:1527023552637};\\\", \\\"{x:1473,y:635,t:1527023552654};\\\", \\\"{x:1473,y:631,t:1527023552671};\\\", \\\"{x:1474,y:628,t:1527023552687};\\\", \\\"{x:1474,y:626,t:1527023552704};\\\", \\\"{x:1474,y:624,t:1527023552721};\\\", \\\"{x:1474,y:619,t:1527023552737};\\\", \\\"{x:1474,y:613,t:1527023552754};\\\", \\\"{x:1474,y:611,t:1527023552772};\\\", \\\"{x:1474,y:610,t:1527023552789};\\\", \\\"{x:1474,y:607,t:1527023552804};\\\", \\\"{x:1474,y:602,t:1527023552821};\\\", \\\"{x:1474,y:598,t:1527023552838};\\\", \\\"{x:1474,y:595,t:1527023552855};\\\", \\\"{x:1474,y:589,t:1527023552871};\\\", \\\"{x:1474,y:582,t:1527023552888};\\\", \\\"{x:1474,y:572,t:1527023552904};\\\", \\\"{x:1474,y:568,t:1527023552921};\\\", \\\"{x:1476,y:560,t:1527023552939};\\\", \\\"{x:1478,y:553,t:1527023552955};\\\", \\\"{x:1480,y:548,t:1527023552972};\\\", \\\"{x:1480,y:546,t:1527023553003};\\\", \\\"{x:1481,y:545,t:1527023553011};\\\", \\\"{x:1482,y:542,t:1527023553022};\\\", \\\"{x:1482,y:538,t:1527023553039};\\\", \\\"{x:1484,y:533,t:1527023553054};\\\", \\\"{x:1485,y:531,t:1527023553071};\\\", \\\"{x:1485,y:528,t:1527023553088};\\\", \\\"{x:1488,y:523,t:1527023553104};\\\", \\\"{x:1488,y:519,t:1527023553121};\\\", \\\"{x:1488,y:517,t:1527023553138};\\\", \\\"{x:1488,y:514,t:1527023553156};\\\", \\\"{x:1489,y:509,t:1527023553172};\\\", \\\"{x:1490,y:502,t:1527023553188};\\\", \\\"{x:1492,y:488,t:1527023553206};\\\", \\\"{x:1494,y:479,t:1527023553222};\\\", \\\"{x:1495,y:475,t:1527023553238};\\\", \\\"{x:1495,y:473,t:1527023553255};\\\", \\\"{x:1495,y:472,t:1527023553323};\\\", \\\"{x:1495,y:471,t:1527023553403};\\\", \\\"{x:1495,y:469,t:1527023553411};\\\", \\\"{x:1495,y:467,t:1527023553422};\\\", \\\"{x:1497,y:462,t:1527023553438};\\\", \\\"{x:1497,y:461,t:1527023553455};\\\", \\\"{x:1497,y:460,t:1527023553472};\\\", \\\"{x:1497,y:462,t:1527023553779};\\\", \\\"{x:1497,y:487,t:1527023553789};\\\", \\\"{x:1497,y:579,t:1527023553806};\\\", \\\"{x:1497,y:651,t:1527023553823};\\\", \\\"{x:1505,y:704,t:1527023553839};\\\", \\\"{x:1510,y:736,t:1527023553856};\\\", \\\"{x:1512,y:752,t:1527023553873};\\\", \\\"{x:1512,y:758,t:1527023553889};\\\", \\\"{x:1512,y:767,t:1527023553906};\\\", \\\"{x:1512,y:784,t:1527023553924};\\\", \\\"{x:1510,y:796,t:1527023553939};\\\", \\\"{x:1506,y:815,t:1527023553957};\\\", \\\"{x:1506,y:840,t:1527023553973};\\\", \\\"{x:1506,y:855,t:1527023553989};\\\", \\\"{x:1506,y:856,t:1527023554006};\\\", \\\"{x:1506,y:850,t:1527023554076};\\\", \\\"{x:1503,y:838,t:1527023554089};\\\", \\\"{x:1497,y:805,t:1527023554107};\\\", \\\"{x:1481,y:723,t:1527023554123};\\\", \\\"{x:1456,y:632,t:1527023554140};\\\", \\\"{x:1432,y:533,t:1527023554156};\\\", \\\"{x:1411,y:448,t:1527023554173};\\\", \\\"{x:1402,y:370,t:1527023554190};\\\", \\\"{x:1397,y:291,t:1527023554206};\\\", \\\"{x:1397,y:246,t:1527023554223};\\\", \\\"{x:1397,y:210,t:1527023554240};\\\", \\\"{x:1397,y:167,t:1527023554256};\\\", \\\"{x:1397,y:146,t:1527023554274};\\\", \\\"{x:1397,y:131,t:1527023554290};\\\", \\\"{x:1397,y:122,t:1527023554306};\\\", \\\"{x:1397,y:118,t:1527023554323};\\\", \\\"{x:1400,y:130,t:1527023554403};\\\", \\\"{x:1413,y:146,t:1527023554411};\\\", \\\"{x:1420,y:164,t:1527023554423};\\\", \\\"{x:1425,y:192,t:1527023554440};\\\", \\\"{x:1428,y:218,t:1527023554456};\\\", \\\"{x:1431,y:233,t:1527023554473};\\\", \\\"{x:1432,y:242,t:1527023554490};\\\", \\\"{x:1432,y:246,t:1527023554506};\\\", \\\"{x:1433,y:247,t:1527023554523};\\\", \\\"{x:1425,y:251,t:1527023554540};\\\", \\\"{x:1410,y:264,t:1527023554557};\\\", \\\"{x:1381,y:289,t:1527023554573};\\\", \\\"{x:1303,y:329,t:1527023554590};\\\", \\\"{x:1189,y:369,t:1527023554607};\\\", \\\"{x:1059,y:403,t:1527023554623};\\\", \\\"{x:939,y:421,t:1527023554641};\\\", \\\"{x:871,y:427,t:1527023554657};\\\", \\\"{x:829,y:427,t:1527023554673};\\\", \\\"{x:752,y:436,t:1527023554690};\\\", \\\"{x:592,y:462,t:1527023554706};\\\", \\\"{x:480,y:482,t:1527023554723};\\\", \\\"{x:402,y:502,t:1527023554742};\\\", \\\"{x:380,y:515,t:1527023554757};\\\", \\\"{x:363,y:533,t:1527023554773};\\\", \\\"{x:345,y:556,t:1527023554791};\\\", \\\"{x:336,y:581,t:1527023554807};\\\", \\\"{x:336,y:608,t:1527023554824};\\\", \\\"{x:341,y:632,t:1527023554841};\\\", \\\"{x:343,y:647,t:1527023554858};\\\", \\\"{x:343,y:652,t:1527023554873};\\\", \\\"{x:342,y:657,t:1527023554891};\\\", \\\"{x:340,y:659,t:1527023554907};\\\", \\\"{x:339,y:661,t:1527023554923};\\\", \\\"{x:339,y:663,t:1527023554940};\\\", \\\"{x:342,y:666,t:1527023554957};\\\", \\\"{x:349,y:666,t:1527023554973};\\\", \\\"{x:356,y:662,t:1527023554991};\\\", \\\"{x:367,y:654,t:1527023555006};\\\", \\\"{x:373,y:650,t:1527023555024};\\\", \\\"{x:385,y:649,t:1527023555041};\\\", \\\"{x:403,y:646,t:1527023555057};\\\", \\\"{x:420,y:641,t:1527023555074};\\\", \\\"{x:443,y:630,t:1527023555090};\\\", \\\"{x:452,y:624,t:1527023555108};\\\", \\\"{x:461,y:620,t:1527023555123};\\\", \\\"{x:465,y:619,t:1527023555140};\\\", \\\"{x:466,y:618,t:1527023555157};\\\", \\\"{x:467,y:618,t:1527023555211};\\\", \\\"{x:469,y:617,t:1527023555224};\\\", \\\"{x:474,y:615,t:1527023555240};\\\", \\\"{x:477,y:615,t:1527023555257};\\\", \\\"{x:481,y:613,t:1527023555274};\\\", \\\"{x:489,y:611,t:1527023555290};\\\", \\\"{x:494,y:608,t:1527023555308};\\\", \\\"{x:504,y:605,t:1527023555325};\\\", \\\"{x:512,y:602,t:1527023555342};\\\", \\\"{x:517,y:600,t:1527023555357};\\\", \\\"{x:519,y:600,t:1527023555374};\\\", \\\"{x:520,y:600,t:1527023555394};\\\", \\\"{x:521,y:600,t:1527023555410};\\\", \\\"{x:522,y:600,t:1527023555425};\\\", \\\"{x:523,y:599,t:1527023555440};\\\", \\\"{x:526,y:598,t:1527023555458};\\\", \\\"{x:529,y:598,t:1527023555474};\\\", \\\"{x:538,y:598,t:1527023555490};\\\", \\\"{x:554,y:598,t:1527023555508};\\\", \\\"{x:578,y:598,t:1527023555524};\\\", \\\"{x:600,y:598,t:1527023555542};\\\", \\\"{x:626,y:598,t:1527023555558};\\\", \\\"{x:650,y:598,t:1527023555575};\\\", \\\"{x:667,y:596,t:1527023555592};\\\", \\\"{x:679,y:594,t:1527023555607};\\\", \\\"{x:681,y:593,t:1527023555625};\\\", \\\"{x:682,y:592,t:1527023555641};\\\", \\\"{x:680,y:592,t:1527023555666};\\\", \\\"{x:676,y:592,t:1527023555674};\\\", \\\"{x:667,y:590,t:1527023555691};\\\", \\\"{x:660,y:587,t:1527023555707};\\\", \\\"{x:652,y:586,t:1527023555725};\\\", \\\"{x:645,y:586,t:1527023555742};\\\", \\\"{x:637,y:586,t:1527023555758};\\\", \\\"{x:631,y:586,t:1527023555775};\\\", \\\"{x:624,y:586,t:1527023555792};\\\", \\\"{x:619,y:586,t:1527023555808};\\\", \\\"{x:616,y:586,t:1527023555825};\\\", \\\"{x:614,y:586,t:1527023556146};\\\", \\\"{x:612,y:586,t:1527023556158};\\\", \\\"{x:606,y:588,t:1527023556174};\\\", \\\"{x:599,y:589,t:1527023556192};\\\", \\\"{x:594,y:589,t:1527023556208};\\\", \\\"{x:591,y:591,t:1527023556225};\\\", \\\"{x:590,y:591,t:1527023556347};\\\", \\\"{x:587,y:594,t:1527023556363};\\\", \\\"{x:580,y:596,t:1527023556374};\\\", \\\"{x:559,y:602,t:1527023556392};\\\", \\\"{x:523,y:606,t:1527023556409};\\\", \\\"{x:483,y:606,t:1527023556426};\\\", \\\"{x:452,y:606,t:1527023556442};\\\", \\\"{x:415,y:606,t:1527023556458};\\\", \\\"{x:411,y:606,t:1527023556475};\\\", \\\"{x:410,y:605,t:1527023556498};\\\", \\\"{x:410,y:604,t:1527023556522};\\\", \\\"{x:410,y:603,t:1527023556538};\\\", \\\"{x:411,y:602,t:1527023556586};\\\", \\\"{x:411,y:601,t:1527023556610};\\\", \\\"{x:411,y:600,t:1527023556626};\\\", \\\"{x:411,y:599,t:1527023556650};\\\", \\\"{x:411,y:597,t:1527023556658};\\\", \\\"{x:408,y:596,t:1527023556676};\\\", \\\"{x:405,y:594,t:1527023556692};\\\", \\\"{x:402,y:594,t:1527023556708};\\\", \\\"{x:397,y:594,t:1527023556726};\\\", \\\"{x:396,y:594,t:1527023556742};\\\", \\\"{x:396,y:593,t:1527023556787};\\\", \\\"{x:395,y:593,t:1527023556986};\\\", \\\"{x:398,y:606,t:1527023556994};\\\", \\\"{x:405,y:623,t:1527023557008};\\\", \\\"{x:420,y:659,t:1527023557026};\\\", \\\"{x:440,y:687,t:1527023557042};\\\", \\\"{x:454,y:702,t:1527023557058};\\\", \\\"{x:466,y:717,t:1527023557075};\\\", \\\"{x:473,y:730,t:1527023557092};\\\", \\\"{x:480,y:741,t:1527023557109};\\\", \\\"{x:485,y:747,t:1527023557126};\\\", \\\"{x:488,y:751,t:1527023557142};\\\", \\\"{x:493,y:756,t:1527023557159};\\\", \\\"{x:495,y:760,t:1527023557176};\\\", \\\"{x:499,y:764,t:1527023557193};\\\", \\\"{x:501,y:766,t:1527023557209};\\\", \\\"{x:501,y:767,t:1527023557226};\\\", \\\"{x:502,y:768,t:1527023557242};\\\", \\\"{x:502,y:767,t:1527023557443};\\\", \\\"{x:502,y:762,t:1527023557460};\\\", \\\"{x:502,y:760,t:1527023557482};\\\", \\\"{x:502,y:759,t:1527023557506};\\\" ] }, { \\\"rt\\\": 50123, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 630380, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The lines that come out of 12 pm going to right and up is lines that have a shift start. \\\\nLines going up and to the left are shift ends. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6093, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Iraq\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 637480, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 22017, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 660510, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3311, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 665172, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"D3LUH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"D3LUH\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 196, dom: 953, initialDom: 1072",
  "javascriptErrors": []
}