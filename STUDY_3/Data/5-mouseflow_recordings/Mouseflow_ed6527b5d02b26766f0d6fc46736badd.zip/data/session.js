var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ed6527b5d02b26766f0d6fc46736badd",
  "created": "2018-05-18T11:16:11.8566167-07:00",
  "lastActivity": "2018-05-18T11:17:33.5586167-07:00",
  "pageViews": [
    {
      "id": "051811922f3b7c18d45fb1aa790047bc27d29f4f",
      "startTime": "2018-05-18T11:16:11.8566167-07:00",
      "endTime": "2018-05-18T11:17:33.5586167-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 81702,
      "engagementTime": 67252,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 81702,
  "engagementTime": 67252,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.51",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T2OHS",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fb7316339859fda8921115c8d44872b5",
  "gdpr": false
}