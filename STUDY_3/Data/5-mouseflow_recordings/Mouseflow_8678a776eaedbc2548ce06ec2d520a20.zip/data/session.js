var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8678a776eaedbc2548ce06ec2d520a20",
  "created": "2018-06-01T10:06:54.99621-07:00",
  "lastActivity": "2018-06-01T10:09:01.4578266-07:00",
  "pageViews": [
    {
      "id": "06015430fd743d1e15e9951f510f5f4e9df286fa",
      "startTime": "2018-06-01T10:06:55.2741093-07:00",
      "endTime": "2018-06-01T10:09:01.4578266-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 126635,
      "engagementTime": 86273,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 126635,
  "engagementTime": 86273,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0b1c90e2e925b8d5c312f71d7fc1538f",
  "gdpr": false
}