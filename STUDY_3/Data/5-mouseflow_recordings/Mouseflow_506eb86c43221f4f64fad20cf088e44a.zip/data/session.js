var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "506eb86c43221f4f64fad20cf088e44a",
  "created": "2018-05-29T16:09:48.0218368-07:00",
  "lastActivity": "2018-05-29T16:11:02.9298833-07:00",
  "pageViews": [
    {
      "id": "05294849ed99c9d9af2838c6ce0a03b3e58d94d3",
      "startTime": "2018-05-29T16:09:48.2559888-07:00",
      "endTime": "2018-05-29T16:11:02.9298833-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 74689,
      "engagementTime": 66835,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 74689,
  "engagementTime": 66835,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8FE87",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7dd48a1ed822a998f2fabae8d470c249",
  "gdpr": false
}