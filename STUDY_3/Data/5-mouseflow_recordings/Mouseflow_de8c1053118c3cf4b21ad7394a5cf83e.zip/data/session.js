var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "de8c1053118c3cf4b21ad7394a5cf83e",
  "created": "2018-06-01T11:13:13.8738948-07:00",
  "lastActivity": "2018-06-01T11:14:11.4578948-07:00",
  "pageViews": [
    {
      "id": "06011407d0b9e10311dfe9efae33a7f3e6e4d4c3",
      "startTime": "2018-06-01T11:13:13.8738948-07:00",
      "endTime": "2018-06-01T11:14:11.4578948-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 57584,
      "engagementTime": 30581,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 57584,
  "engagementTime": 30581,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=41Y1H",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4284bd99057cf5b0af9472bd959d7215",
  "gdpr": false
}