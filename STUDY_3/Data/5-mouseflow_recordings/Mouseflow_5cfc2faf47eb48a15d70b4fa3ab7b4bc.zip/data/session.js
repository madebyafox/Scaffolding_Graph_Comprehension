var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5cfc2faf47eb48a15d70b4fa3ab7b4bc",
  "created": "2018-06-01T11:23:57.6099644-07:00",
  "lastActivity": "2018-06-01T11:25:11.9131676-07:00",
  "pageViews": [
    {
      "id": "060157152e740f14007dc04a1b9a87b2a5e5850d",
      "startTime": "2018-06-01T11:23:57.7870265-07:00",
      "endTime": "2018-06-01T11:25:11.9131676-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 74272,
      "engagementTime": 71351,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 74272,
  "engagementTime": 71351,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=CE3B9",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a15fd04ae5d9fb573fed640dc35e7f44",
  "gdpr": false
}