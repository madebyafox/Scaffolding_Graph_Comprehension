var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "01e430579e52a4623e10ddeee32b5bfb",
  "created": "2018-05-15T14:07:47.8497552-07:00",
  "lastActivity": "2018-05-15T14:08:29.4777552-07:00",
  "pageViews": [
    {
      "id": "05154858d73ebd0459658fef0fae87dcfdc948d6",
      "startTime": "2018-05-15T14:07:47.8497552-07:00",
      "endTime": "2018-05-15T14:08:29.4777552-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 41628,
      "engagementTime": 41628,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 41628,
  "engagementTime": 41628,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B4LD9",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b4c688e026a4fea8149a9c20fde244e0",
  "gdpr": false
}