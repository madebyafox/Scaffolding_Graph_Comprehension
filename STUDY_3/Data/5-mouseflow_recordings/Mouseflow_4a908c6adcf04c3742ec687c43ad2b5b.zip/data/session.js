var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4a908c6adcf04c3742ec687c43ad2b5b",
  "created": "2018-05-31T12:14:27.8828977-07:00",
  "lastActivity": "2018-05-31T12:15:29.2238977-07:00",
  "pageViews": [
    {
      "id": "05312753fb155a51082b64d26349b901ea5440f6",
      "startTime": "2018-05-31T12:14:27.8828977-07:00",
      "endTime": "2018-05-31T12:15:29.2238977-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 61341,
      "engagementTime": 17383,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 61341,
  "engagementTime": 17383,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=03QKB",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d4a7eea8a50c2e507b7117e71786bae8",
  "gdpr": false
}