var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060423481b46cac4efe3d725e00f64062a119480"] = {
  "startTime": "2018-06-04T19:21:23.516289Z",
  "websitePageUrl": "/16",
  "visitTime": 147094,
  "engagementTime": 129815,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d3c96624c6213d4192a37a2f9f8f5843",
    "created": "2018-06-04T19:21:23.2796686+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=13RHM",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "af4f1403257e4edf22eaa5aaee2b3442",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d3c96624c6213d4192a37a2f9f8f5843/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 258,
      "e": 258,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 258,
      "e": 258,
      "ty": 2,
      "x": 597,
      "y": 751
    },
    {
      "t": 259,
      "e": 259,
      "ty": 41,
      "x": 56194,
      "y": 41160,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 583,
      "y": 747
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 576,
      "y": 741
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 53833,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 575,
      "y": 740
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 53721,
      "y": 40550,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 460,
      "y": 695
    },
    {
      "t": 948,
      "e": 948,
      "ty": 6,
      "x": 330,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 982,
      "e": 982,
      "ty": 7,
      "x": 270,
      "y": 516,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 264,
      "y": 509
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 18761,
      "y": 33389,
      "ta": "#.strategy > p"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 262,
      "y": 505
    },
    {
      "t": 1182,
      "e": 1182,
      "ty": 6,
      "x": 289,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 295,
      "y": 536
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 22471,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 297,
      "y": 549
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 293,
      "y": 552
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 22021,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2732,
      "e": 2732,
      "ty": 3,
      "x": 293,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2733,
      "e": 2733,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2850,
      "e": 2850,
      "ty": 4,
      "x": 22021,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2851,
      "e": 2851,
      "ty": 5,
      "x": 293,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 324,
      "y": 540
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 476,
      "y": 531
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 42592,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 530,
      "y": 525
    },
    {
      "t": 3634,
      "e": 3634,
      "ty": 7,
      "x": 556,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3668,
      "e": 3668,
      "ty": 6,
      "x": 569,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 575,
      "y": 523
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 54508,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 582,
      "y": 526
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 583,
      "y": 526
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 54620,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 591,
      "y": 524
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 64850,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4253,
      "e": 4253,
      "ty": 7,
      "x": 696,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 857,
      "y": 656
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1393,
      "y": 1001
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1516,
      "y": 1143
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 51932,
      "y": 62875,
      "ta": "> div.stimulus"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1517,
      "y": 1144
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1221,
      "y": 988
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 27483,
      "y": 60020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1175,
      "y": 981
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1167,
      "y": 995
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1143,
      "y": 982
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 16309,
      "y": 53503,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1144,
      "y": 977
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1148,
      "y": 972
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 27650,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1151,
      "y": 964
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1155,
      "y": 960
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1158,
      "y": 955
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 26215,
      "y": 58515,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1159,
      "y": 954
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1160,
      "y": 953
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 26356,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1159,
      "y": 947
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1150,
      "y": 935
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 25651,
      "y": 57083,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1148,
      "y": 925
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 25510,
      "y": 56152,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1149,
      "y": 919
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1153,
      "y": 893
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1153,
      "y": 866
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 25862,
      "y": 52141,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1149,
      "y": 857
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1149,
      "y": 854
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 25862,
      "y": 50350,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1157,
      "y": 821
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1163,
      "y": 798
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1163,
      "y": 795
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 26567,
      "y": 47056,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1162,
      "y": 786
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1149,
      "y": 761
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 25299,
      "y": 43833,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1141,
      "y": 739
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1140,
      "y": 728
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1148,
      "y": 710
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 25510,
      "y": 40968,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1155,
      "y": 692
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 45595,
      "y": 9102,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[6] > circle"
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 60287,
      "y": 63999,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[6] > text"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1019,
      "y": 703
    },
    {
      "t": 8370,
      "e": 8370,
      "ty": 6,
      "x": 321,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 287,
      "y": 579
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 277,
      "y": 579
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 20223,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 303,
      "y": 584
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 23145,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9600,
      "e": 9600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9695,
      "e": 9695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9743,
      "e": 9743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10030,
      "e": 10030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10030,
      "e": 10030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10158,
      "e": 10158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "e"
    },
    {
      "t": 10166,
      "e": 10166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "e"
    },
    {
      "t": 10215,
      "e": 10215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 10215,
      "e": 10215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10294,
      "e": 10294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "eV"
    },
    {
      "t": 10343,
      "e": 10343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10344,
      "e": 10344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10455,
      "e": 10455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "eVE"
    },
    {
      "t": 10495,
      "e": 10495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10496,
      "e": 10496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10583,
      "e": 10583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "eVEN"
    },
    {
      "t": 10679,
      "e": 10679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10679,
      "e": 10679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10774,
      "e": 10774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 10822,
      "e": 10822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10823,
      "e": 10823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10926,
      "e": 10926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10950,
      "e": 10950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11086,
      "e": 11086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11086,
      "e": 11086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11202,
      "e": 11202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "eVENT f"
    },
    {
      "t": 11222,
      "e": 11222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 11270,
      "e": 11270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11270,
      "e": 11270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11318,
      "e": 11318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11350,
      "e": 11350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11519,
      "e": 11519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11520,
      "e": 11520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11607,
      "e": 11607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 11759,
      "e": 11759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11759,
      "e": 11759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11838,
      "e": 11838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 12359,
      "e": 12359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12859,
      "e": 12859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12891,
      "e": 12891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12923,
      "e": 12923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12956,
      "e": 12956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12990,
      "e": 12990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13023,
      "e": 13023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13055,
      "e": 13055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13089,
      "e": 13089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13121,
      "e": 13121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13155,
      "e": 13155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13188,
      "e": 13188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13220,
      "e": 13220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13254,
      "e": 13254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13287,
      "e": 13287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13303,
      "e": 13303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 13807,
      "e": 13807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13808,
      "e": 13808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13934,
      "e": 13934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 14278,
      "e": 14278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 14280,
      "e": 14280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14366,
      "e": 14366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EV"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14542,
      "e": 14542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVE"
    },
    {
      "t": 14646,
      "e": 14646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14647,
      "e": 14647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14735,
      "e": 14735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVEN"
    },
    {
      "t": 14814,
      "e": 14814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14815,
      "e": 14815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14894,
      "e": 14894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 14990,
      "e": 14990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14991,
      "e": 14991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15038,
      "e": 15038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15223,
      "e": 15223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15224,
      "e": 15224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15317,
      "e": 15317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 15350,
      "e": 15350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15351,
      "e": 15351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15414,
      "e": 15414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15462,
      "e": 15462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15464,
      "e": 15464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15550,
      "e": 15550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 15558,
      "e": 15558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15558,
      "e": 15558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15630,
      "e": 15630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 15743,
      "e": 15743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15743,
      "e": 15743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15831,
      "e": 15831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 15878,
      "e": 15878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15880,
      "e": 15880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16004,
      "e": 16004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND "
    },
    {
      "t": 16007,
      "e": 16007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 16008,
      "e": 16008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16022,
      "e": 16022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| B"
    },
    {
      "t": 16110,
      "e": 16110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16206,
      "e": 16206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16207,
      "e": 16207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16279,
      "e": 16279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16405,
      "e": 16405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B "
    },
    {
      "t": 17718,
      "e": 17718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17719,
      "e": 17719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17806,
      "e": 17806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 17854,
      "e": 17854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17854,
      "e": 17854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17950,
      "e": 17950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 18015,
      "e": 18015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18016,
      "e": 18016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18077,
      "e": 18077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 18174,
      "e": 18174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18174,
      "e": 18174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18238,
      "e": 18238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 18255,
      "e": 18255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18255,
      "e": 18255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18342,
      "e": 18342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 18381,
      "e": 18381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18383,
      "e": 18383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18486,
      "e": 18486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 18518,
      "e": 18518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18520,
      "e": 18520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18607,
      "e": 18607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18631,
      "e": 18631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18632,
      "e": 18632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18766,
      "e": 18766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 18871,
      "e": 18871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18871,
      "e": 18871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18950,
      "e": 18950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 19191,
      "e": 19191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19192,
      "e": 19192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19278,
      "e": 19278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19904,
      "e": 19904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 19904,
      "e": 19904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20062,
      "e": 20062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 20062,
      "e": 20062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20070,
      "e": 20070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 20158,
      "e": 20158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20239,
      "e": 20239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20239,
      "e": 20239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20326,
      "e": 20326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 20463,
      "e": 20463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20463,
      "e": 20463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20542,
      "e": 20542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 20678,
      "e": 20678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20679,
      "e": 20679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20775,
      "e": 20775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20799,
      "e": 20799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20800,
      "e": 20800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20894,
      "e": 20894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 20901,
      "e": 20901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20902,
      "e": 20902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20981,
      "e": 20981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 20990,
      "e": 20990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20990,
      "e": 20990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21077,
      "e": 21077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 21134,
      "e": 21134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21134,
      "e": 21134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21182,
      "e": 21182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21207,
      "e": 21207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21278,
      "e": 21278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 21318,
      "e": 21318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21319,
      "e": 21319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21430,
      "e": 21430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 21454,
      "e": 21454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21455,
      "e": 21455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21502,
      "e": 21502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21502,
      "e": 21502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21523,
      "e": 21523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||IS"
    },
    {
      "t": 21606,
      "e": 21606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21614,
      "e": 21614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21615,
      "e": 21615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21710,
      "e": 21710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21734,
      "e": 21734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 21734,
      "e": 21734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21783,
      "e": 21783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21784,
      "e": 21784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21814,
      "e": 21814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||CA"
    },
    {
      "t": 21870,
      "e": 21870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21870,
      "e": 21870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21893,
      "e": 21893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 21958,
      "e": 21958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21958,
      "e": 21958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21966,
      "e": 21966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22086,
      "e": 22086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22094,
      "e": 22094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 22094,
      "e": 22094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22166,
      "e": 22166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 22182,
      "e": 22182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22182,
      "e": 22182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22295,
      "e": 22295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22295,
      "e": 22295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22301,
      "e": 22301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E "
    },
    {
      "t": 22390,
      "e": 22390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22598,
      "e": 22598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22600,
      "e": 22600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22719,
      "e": 22719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 22806,
      "e": 22806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22808,
      "e": 22808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22901,
      "e": 22901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22902,
      "e": 22902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22926,
      "e": 22926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ET"
    },
    {
      "t": 23022,
      "e": 23022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23038,
      "e": 23038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23039,
      "e": 23039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23150,
      "e": 23150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23150,
      "e": 23150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23198,
      "e": 23198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ER"
    },
    {
      "t": 23239,
      "e": 23239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23264,
      "e": 23264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23264,
      "e": 23264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23333,
      "e": 23333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 23422,
      "e": 23422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23422,
      "e": 23422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23503,
      "e": 23503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 23559,
      "e": 23559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23559,
      "e": 23559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23630,
      "e": 23630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 23661,
      "e": 23661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23662,
      "e": 23662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23774,
      "e": 23774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23775,
      "e": 23775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23805,
      "e": 23805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ED"
    },
    {
      "t": 23870,
      "e": 23870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23893,
      "e": 23893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23894,
      "e": 23894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24003,
      "e": 24003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED "
    },
    {
      "t": 24022,
      "e": 24022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24103,
      "e": 24103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 24103,
      "e": 24103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24238,
      "e": 24238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 24239,
      "e": 24239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24245,
      "e": 24245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||BY"
    },
    {
      "t": 24350,
      "e": 24350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24439,
      "e": 24439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24439,
      "e": 24439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24542,
      "e": 24542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 29542,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30775,
      "e": 29542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30775,
      "e": 29542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30886,
      "e": 29653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 31038,
      "e": 29805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31039,
      "e": 29806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31118,
      "e": 29885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 31359,
      "e": 30126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31359,
      "e": 30126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31430,
      "e": 30197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 31526,
      "e": 30293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31527,
      "e": 30294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31589,
      "e": 30356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 31702,
      "e": 30469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31703,
      "e": 30470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31806,
      "e": 30573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 31926,
      "e": 30693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31927,
      "e": 30694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32021,
      "e": 30788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 32038,
      "e": 30805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32038,
      "e": 30805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32118,
      "e": 30885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 32215,
      "e": 30982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32215,
      "e": 30982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32302,
      "e": 31069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 32318,
      "e": 31085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32319,
      "e": 31086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32438,
      "e": 31205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 32454,
      "e": 31221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32454,
      "e": 31221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32558,
      "e": 31325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32575,
      "e": 31342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 32576,
      "e": 31343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32702,
      "e": 31469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32703,
      "e": 31470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32710,
      "e": 31477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||WH"
    },
    {
      "t": 32797,
      "e": 31564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32854,
      "e": 31621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32855,
      "e": 31622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32959,
      "e": 31726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32959,
      "e": 31726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32998,
      "e": 31765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AT"
    },
    {
      "t": 33077,
      "e": 31844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33325,
      "e": 32092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33326,
      "e": 32093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33518,
      "e": 32285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33766,
      "e": 32533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33767,
      "e": 32534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33853,
      "e": 32620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 33974,
      "e": 32741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33975,
      "e": 32742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34062,
      "e": 32829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 34166,
      "e": 32933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34167,
      "e": 32934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34255,
      "e": 33022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 34351,
      "e": 33118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34351,
      "e": 33118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34437,
      "e": 33204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 34518,
      "e": 33285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34518,
      "e": 33285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34670,
      "e": 33437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 34678,
      "e": 33445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34679,
      "e": 33446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34757,
      "e": 33524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34758,
      "e": 33525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34774,
      "e": 33541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S "
    },
    {
      "t": 34886,
      "e": 33653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34982,
      "e": 33749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34983,
      "e": 33750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35086,
      "e": 33853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 35102,
      "e": 33869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35102,
      "e": 33869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35174,
      "e": 33941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 35302,
      "e": 34069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 35303,
      "e": 34070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35381,
      "e": 34148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 35453,
      "e": 34220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 35453,
      "e": 34220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35518,
      "e": 34285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 35630,
      "e": 34397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35631,
      "e": 34398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35710,
      "e": 34477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 35712,
      "e": 34479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35718,
      "e": 34485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||OW"
    },
    {
      "t": 35814,
      "e": 34581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35837,
      "e": 34604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35838,
      "e": 34605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35958,
      "e": 34725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36149,
      "e": 34916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 36150,
      "e": 34917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36253,
      "e": 35020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 36253,
      "e": 35020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36254,
      "e": 35021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36342,
      "e": 35109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 36430,
      "e": 35197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36431,
      "e": 35198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36485,
      "e": 35252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36486,
      "e": 35253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36517,
      "e": 35284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 36589,
      "e": 35356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36590,
      "e": 35357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36613,
      "e": 35380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 36678,
      "e": 35445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36758,
      "e": 35525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36759,
      "e": 35526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36878,
      "e": 35645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 36934,
      "e": 35701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36935,
      "e": 35702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37038,
      "e": 35805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37070,
      "e": 35837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37070,
      "e": 35837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37174,
      "e": 35941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 37198,
      "e": 35965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37199,
      "e": 35966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37302,
      "e": 36069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 37357,
      "e": 36124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37358,
      "e": 36125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37446,
      "e": 36213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 37639,
      "e": 36406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37639,
      "e": 36406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37741,
      "e": 36508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39223,
      "e": 37990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 39223,
      "e": 37990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39309,
      "e": 38076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||V"
    },
    {
      "t": 39373,
      "e": 38140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39373,
      "e": 38140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39518,
      "e": 38285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39519,
      "e": 38286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39559,
      "e": 38326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ER"
    },
    {
      "t": 39630,
      "e": 38397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39758,
      "e": 38525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39759,
      "e": 38526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39807,
      "e": 38527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 39870,
      "e": 38590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39871,
      "e": 38591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39941,
      "e": 38661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 40062,
      "e": 38782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40062,
      "e": 38782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40198,
      "e": 38918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40198,
      "e": 38918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40222,
      "e": 38942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||CA"
    },
    {
      "t": 40318,
      "e": 39038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40374,
      "e": 39094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40375,
      "e": 39095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40477,
      "e": 39197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 40958,
      "e": 39678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41457,
      "e": 40177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41490,
      "e": 40210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41522,
      "e": 40242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41555,
      "e": 40275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41589,
      "e": 40309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41621,
      "e": 40341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41654,
      "e": 40374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41687,
      "e": 40407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41720,
      "e": 40440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41754,
      "e": 40474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41787,
      "e": 40507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41813,
      "e": 40533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN "
    },
    {
      "t": 42366,
      "e": 41086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42366,
      "e": 41086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42437,
      "e": 41157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 42525,
      "e": 41245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42526,
      "e": 41246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42693,
      "e": 41413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42725,
      "e": 41445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42726,
      "e": 41446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42830,
      "e": 41550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 42894,
      "e": 41614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 42895,
      "e": 41615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43008,
      "e": 41728,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HY"
    },
    {
      "t": 43010,
      "e": 41730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 43883,
      "e": 42603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 43883,
      "e": 42603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43962,
      "e": 42682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 44074,
      "e": 42794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44074,
      "e": 42794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44178,
      "e": 42898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 44185,
      "e": 42905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44185,
      "e": 42905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44314,
      "e": 43034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 44442,
      "e": 43162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44443,
      "e": 43163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44539,
      "e": 43259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 44586,
      "e": 43306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44587,
      "e": 43307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44658,
      "e": 43378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 44753,
      "e": 43473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44754,
      "e": 43474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44858,
      "e": 43578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 44986,
      "e": 43706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44987,
      "e": 43707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45057,
      "e": 43777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 45170,
      "e": 43890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 45170,
      "e": 43890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45306,
      "e": 44026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||C"
    },
    {
      "t": 45418,
      "e": 44138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45418,
      "e": 44138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45489,
      "e": 44209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 45546,
      "e": 44266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45550,
      "e": 44270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45602,
      "e": 44322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 45737,
      "e": 44457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45739,
      "e": 44459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45817,
      "e": 44537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46634,
      "e": 45354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46697,
      "e": 45417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEHTICAL"
    },
    {
      "t": 46801,
      "e": 45521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46873,
      "e": 45593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEHTICA"
    },
    {
      "t": 46987,
      "e": 45594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47058,
      "e": 45665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEHTIC"
    },
    {
      "t": 47170,
      "e": 45777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47233,
      "e": 45840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEHTI"
    },
    {
      "t": 47353,
      "e": 45960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47401,
      "e": 46008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEHT"
    },
    {
      "t": 47522,
      "e": 46129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47594,
      "e": 46201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTEH"
    },
    {
      "t": 47818,
      "e": 46425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47897,
      "e": 46504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTE"
    },
    {
      "t": 48007,
      "e": 46614,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTE"
    },
    {
      "t": 48298,
      "e": 46905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48378,
      "e": 46985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOT"
    },
    {
      "t": 48530,
      "e": 47137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48531,
      "e": 47138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48633,
      "e": 47240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 48706,
      "e": 47313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48706,
      "e": 47313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48807,
      "e": 47414,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTHE"
    },
    {
      "t": 48818,
      "e": 47425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48819,
      "e": 47426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48849,
      "e": 47456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ET"
    },
    {
      "t": 48906,
      "e": 47513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48995,
      "e": 47514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48998,
      "e": 47517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49097,
      "e": 47616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 49114,
      "e": 47633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 49114,
      "e": 47633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49201,
      "e": 47720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49202,
      "e": 47721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49265,
      "e": 47784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||CA"
    },
    {
      "t": 49329,
      "e": 47848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49329,
      "e": 47848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49330,
      "e": 47849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49434,
      "e": 47953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 49450,
      "e": 47969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49451,
      "e": 47970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49594,
      "e": 48113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49610,
      "e": 48129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 49611,
      "e": 48130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49681,
      "e": 48200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||V"
    },
    {
      "t": 49807,
      "e": 48326,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL V"
    },
    {
      "t": 49890,
      "e": 48409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49891,
      "e": 48410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49985,
      "e": 48504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49986,
      "e": 48505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50018,
      "e": 48537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ER"
    },
    {
      "t": 50057,
      "e": 48576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50162,
      "e": 48681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50162,
      "e": 48681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50233,
      "e": 48752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 50265,
      "e": 48784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50266,
      "e": 48785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50369,
      "e": 48888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 50434,
      "e": 48953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 50435,
      "e": 48954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50522,
      "e": 49041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50522,
      "e": 49041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50585,
      "e": 49104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||CA"
    },
    {
      "t": 50665,
      "e": 49184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50673,
      "e": 49192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50674,
      "e": 49193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50777,
      "e": 49296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 50817,
      "e": 49336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50817,
      "e": 49336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50913,
      "e": 49432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 50914,
      "e": 49433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50970,
      "e": 49489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| L"
    },
    {
      "t": 51009,
      "e": 49528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51107,
      "e": 49626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51107,
      "e": 49626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51185,
      "e": 49704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 51281,
      "e": 49800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51282,
      "e": 49801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51362,
      "e": 49881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51362,
      "e": 49881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51370,
      "e": 49889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||NE"
    },
    {
      "t": 51457,
      "e": 49976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51489,
      "e": 50008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51490,
      "e": 50009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51593,
      "e": 50112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52105,
      "e": 50624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 52106,
      "e": 50625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52234,
      "e": 50753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 52594,
      "e": 51113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52594,
      "e": 51113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52714,
      "e": 51233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52714,
      "e": 51233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52737,
      "e": 51256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||RA"
    },
    {
      "t": 52825,
      "e": 51344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 52826,
      "e": 51345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52849,
      "e": 51368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 52970,
      "e": 51489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53010,
      "e": 51529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53010,
      "e": 51529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53113,
      "e": 51632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 53489,
      "e": 52008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53491,
      "e": 52010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53593,
      "e": 52112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57434,
      "e": 55953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57435,
      "e": 55954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57531,
      "e": 56050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 57569,
      "e": 56088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57570,
      "e": 56089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57633,
      "e": 56152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H"
    },
    {
      "t": 57689,
      "e": 56208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57690,
      "e": 56209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57786,
      "e": 56305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 57802,
      "e": 56321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 57802,
      "e": 56321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57881,
      "e": 56400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 57993,
      "e": 56512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 57994,
      "e": 56513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58089,
      "e": 56608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||U"
    },
    {
      "t": 58145,
      "e": 56664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 58145,
      "e": 56664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58202,
      "e": 56721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58202,
      "e": 56721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58241,
      "e": 56760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||GH"
    },
    {
      "t": 58297,
      "e": 56816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58298,
      "e": 56817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58313,
      "e": 56832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58409,
      "e": 56928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58441,
      "e": 56960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58443,
      "e": 56962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58545,
      "e": 57064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58545,
      "e": 57064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58553,
      "e": 57072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 58626,
      "e": 57145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58641,
      "e": 57160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58641,
      "e": 57160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58745,
      "e": 57264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 58753,
      "e": 57272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58754,
      "e": 57273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58842,
      "e": 57361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58985,
      "e": 57504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 58987,
      "e": 57506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59097,
      "e": 57616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 59185,
      "e": 57704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59187,
      "e": 57706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59282,
      "e": 57801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59403,
      "e": 57803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59404,
      "e": 57804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59513,
      "e": 57913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 59650,
      "e": 58050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 59650,
      "e": 58050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59753,
      "e": 58153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 59793,
      "e": 58193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59794,
      "e": 58194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59890,
      "e": 58290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 59938,
      "e": 58338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59939,
      "e": 58339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60041,
      "e": 58441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 60098,
      "e": 58498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60099,
      "e": 58499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60201,
      "e": 58601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60234,
      "e": 58634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 60234,
      "e": 58634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60322,
      "e": 58722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 60417,
      "e": 58817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60418,
      "e": 58818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60521,
      "e": 58921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 60553,
      "e": 58953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60553,
      "e": 58953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60617,
      "e": 59017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 60722,
      "e": 59122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 60722,
      "e": 59122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60825,
      "e": 59225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60825,
      "e": 59225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60849,
      "e": 59249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M "
    },
    {
      "t": 60937,
      "e": 59337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61314,
      "e": 59714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 61316,
      "e": 59716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61368,
      "e": 59768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 61754,
      "e": 60154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 61754,
      "e": 60154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61873,
      "e": 60273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 62105,
      "e": 60505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 62106,
      "e": 60506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62177,
      "e": 60577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 62314,
      "e": 60714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 62314,
      "e": 60714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62393,
      "e": 60793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 62602,
      "e": 61002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62603,
      "e": 61003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62681,
      "e": 61081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63570,
      "e": 61970,
      "ty": 7,
      "x": 644,
      "y": 479,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63605,
      "e": 62005,
      "ty": 2,
      "x": 865,
      "y": 386
    },
    {
      "t": 63704,
      "e": 62104,
      "ty": 2,
      "x": 950,
      "y": 308
    },
    {
      "t": 63755,
      "e": 62155,
      "ty": 41,
      "x": 10994,
      "y": 13894,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 63805,
      "e": 62205,
      "ty": 2,
      "x": 894,
      "y": 378
    },
    {
      "t": 63905,
      "e": 62305,
      "ty": 2,
      "x": 738,
      "y": 500
    },
    {
      "t": 63971,
      "e": 62371,
      "ty": 6,
      "x": 636,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64005,
      "e": 62405,
      "ty": 2,
      "x": 618,
      "y": 529
    },
    {
      "t": 64005,
      "e": 62405,
      "ty": 41,
      "x": 58555,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64105,
      "e": 62505,
      "ty": 2,
      "x": 607,
      "y": 534
    },
    {
      "t": 64206,
      "e": 62606,
      "ty": 2,
      "x": 579,
      "y": 542
    },
    {
      "t": 64255,
      "e": 62655,
      "ty": 41,
      "x": 54171,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64404,
      "e": 62804,
      "ty": 2,
      "x": 593,
      "y": 534
    },
    {
      "t": 64505,
      "e": 62905,
      "ty": 2,
      "x": 605,
      "y": 531
    },
    {
      "t": 64506,
      "e": 62906,
      "ty": 41,
      "x": 57093,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65005,
      "e": 63405,
      "ty": 2,
      "x": 605,
      "y": 536
    },
    {
      "t": 65005,
      "e": 63405,
      "ty": 41,
      "x": 57093,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65105,
      "e": 63505,
      "ty": 2,
      "x": 603,
      "y": 543
    },
    {
      "t": 65204,
      "e": 63604,
      "ty": 2,
      "x": 602,
      "y": 545
    },
    {
      "t": 65256,
      "e": 63656,
      "ty": 41,
      "x": 56531,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65305,
      "e": 63705,
      "ty": 2,
      "x": 601,
      "y": 546
    },
    {
      "t": 65405,
      "e": 63805,
      "ty": 2,
      "x": 603,
      "y": 544
    },
    {
      "t": 65505,
      "e": 63905,
      "ty": 2,
      "x": 605,
      "y": 543
    },
    {
      "t": 65505,
      "e": 63905,
      "ty": 41,
      "x": 57093,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65605,
      "e": 64005,
      "ty": 2,
      "x": 606,
      "y": 538
    },
    {
      "t": 65705,
      "e": 64105,
      "ty": 2,
      "x": 603,
      "y": 533
    },
    {
      "t": 65755,
      "e": 64155,
      "ty": 41,
      "x": 56531,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65805,
      "e": 64205,
      "ty": 2,
      "x": 600,
      "y": 532
    },
    {
      "t": 65905,
      "e": 64305,
      "ty": 2,
      "x": 599,
      "y": 532
    },
    {
      "t": 66005,
      "e": 64405,
      "ty": 41,
      "x": 56419,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66031,
      "e": 64431,
      "ty": 3,
      "x": 599,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66117,
      "e": 64517,
      "ty": 4,
      "x": 56419,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66117,
      "e": 64517,
      "ty": 5,
      "x": 599,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66810,
      "e": 65210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66881,
      "e": 65281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWIN WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 66994,
      "e": 65394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67056,
      "e": 65456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOWI WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 67169,
      "e": 65569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67233,
      "e": 65569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLOW WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 67329,
      "e": 65665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67393,
      "e": 65729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLLO WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 67505,
      "e": 65841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67560,
      "e": 65896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOLL WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 67665,
      "e": 66001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67729,
      "e": 66065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FOL WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 67978,
      "e": 66314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68041,
      "e": 66377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY FO WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 68185,
      "e": 66521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68265,
      "e": 66601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY F WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 68731,
      "e": 66603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68793,
      "e": 66665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY  WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 69385,
      "e": 67257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69386,
      "e": 67258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69482,
      "e": 67354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY N WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 69584,
      "e": 67456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69584,
      "e": 67456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69657,
      "e": 67529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NO WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 69761,
      "e": 67633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69762,
      "e": 67634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69825,
      "e": 67697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOT WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 69841,
      "e": 67713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69841,
      "e": 67713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69929,
      "e": 67801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTI WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 70010,
      "e": 67882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70010,
      "e": 67882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70073,
      "e": 67883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTIN WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 70129,
      "e": 67939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 70129,
      "e": 67939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70233,
      "e": 68043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM 12PM "
    },
    {
      "t": 71076,
      "e": 68886,
      "ty": 7,
      "x": 525,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71105,
      "e": 68915,
      "ty": 2,
      "x": 502,
      "y": 650
    },
    {
      "t": 71205,
      "e": 69015,
      "ty": 2,
      "x": 491,
      "y": 666
    },
    {
      "t": 71255,
      "e": 69065,
      "ty": 41,
      "x": 44166,
      "y": 36506,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 71305,
      "e": 69115,
      "ty": 2,
      "x": 487,
      "y": 667
    },
    {
      "t": 71405,
      "e": 69215,
      "ty": 2,
      "x": 480,
      "y": 667
    },
    {
      "t": 71506,
      "e": 69316,
      "ty": 2,
      "x": 480,
      "y": 668
    },
    {
      "t": 71506,
      "e": 69316,
      "ty": 41,
      "x": 43042,
      "y": 36562,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 71605,
      "e": 69415,
      "ty": 2,
      "x": 467,
      "y": 674
    },
    {
      "t": 71643,
      "e": 69453,
      "ty": 6,
      "x": 457,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 71705,
      "e": 69515,
      "ty": 2,
      "x": 453,
      "y": 676
    },
    {
      "t": 71755,
      "e": 69565,
      "ty": 41,
      "x": 61387,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 71805,
      "e": 69615,
      "ty": 2,
      "x": 444,
      "y": 673
    },
    {
      "t": 71905,
      "e": 69715,
      "ty": 2,
      "x": 421,
      "y": 673
    },
    {
      "t": 71992,
      "e": 69802,
      "ty": 7,
      "x": 468,
      "y": 651,
      "ta": "#strategyButton"
    },
    {
      "t": 72005,
      "e": 69815,
      "ty": 2,
      "x": 468,
      "y": 651
    },
    {
      "t": 72005,
      "e": 69815,
      "ty": 41,
      "x": 41693,
      "y": 35620,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 72059,
      "e": 69869,
      "ty": 6,
      "x": 582,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72105,
      "e": 69915,
      "ty": 2,
      "x": 618,
      "y": 580
    },
    {
      "t": 72205,
      "e": 70015,
      "ty": 2,
      "x": 639,
      "y": 550
    },
    {
      "t": 72255,
      "e": 70065,
      "ty": 41,
      "x": 61365,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72305,
      "e": 70115,
      "ty": 2,
      "x": 645,
      "y": 527
    },
    {
      "t": 72405,
      "e": 70215,
      "ty": 2,
      "x": 633,
      "y": 541
    },
    {
      "t": 72505,
      "e": 70315,
      "ty": 2,
      "x": 620,
      "y": 558
    },
    {
      "t": 72505,
      "e": 70315,
      "ty": 41,
      "x": 58779,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72705,
      "e": 70515,
      "ty": 2,
      "x": 622,
      "y": 554
    },
    {
      "t": 72755,
      "e": 70565,
      "ty": 41,
      "x": 59117,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72805,
      "e": 70615,
      "ty": 2,
      "x": 625,
      "y": 551
    },
    {
      "t": 72905,
      "e": 70715,
      "ty": 2,
      "x": 630,
      "y": 541
    },
    {
      "t": 73005,
      "e": 70815,
      "ty": 2,
      "x": 630,
      "y": 540
    },
    {
      "t": 73006,
      "e": 70816,
      "ty": 41,
      "x": 59903,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73087,
      "e": 70897,
      "ty": 3,
      "x": 630,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73245,
      "e": 71055,
      "ty": 4,
      "x": 59903,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73245,
      "e": 71055,
      "ty": 5,
      "x": 630,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73505,
      "e": 71315,
      "ty": 2,
      "x": 635,
      "y": 543
    },
    {
      "t": 73505,
      "e": 71315,
      "ty": 41,
      "x": 60466,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73605,
      "e": 71415,
      "ty": 2,
      "x": 656,
      "y": 570
    },
    {
      "t": 73705,
      "e": 71515,
      "ty": 2,
      "x": 659,
      "y": 570
    },
    {
      "t": 73756,
      "e": 71566,
      "ty": 41,
      "x": 63163,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73806,
      "e": 71616,
      "ty": 2,
      "x": 655,
      "y": 566
    },
    {
      "t": 73905,
      "e": 71715,
      "ty": 2,
      "x": 657,
      "y": 561
    },
    {
      "t": 74006,
      "e": 71816,
      "ty": 2,
      "x": 660,
      "y": 558
    },
    {
      "t": 74006,
      "e": 71816,
      "ty": 41,
      "x": 63276,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74105,
      "e": 71915,
      "ty": 2,
      "x": 665,
      "y": 553
    },
    {
      "t": 74205,
      "e": 72015,
      "ty": 2,
      "x": 670,
      "y": 550
    },
    {
      "t": 74255,
      "e": 72065,
      "ty": 41,
      "x": 64400,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74534,
      "e": 72344,
      "ty": 3,
      "x": 670,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74653,
      "e": 72463,
      "ty": 4,
      "x": 64400,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74653,
      "e": 72463,
      "ty": 5,
      "x": 670,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74805,
      "e": 72615,
      "ty": 2,
      "x": 653,
      "y": 550
    },
    {
      "t": 74905,
      "e": 72715,
      "ty": 2,
      "x": 636,
      "y": 552
    },
    {
      "t": 75005,
      "e": 72815,
      "ty": 2,
      "x": 634,
      "y": 552
    },
    {
      "t": 75006,
      "e": 72816,
      "ty": 41,
      "x": 60353,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75105,
      "e": 72915,
      "ty": 2,
      "x": 632,
      "y": 552
    },
    {
      "t": 75253,
      "e": 73063,
      "ty": 3,
      "x": 632,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75256,
      "e": 73066,
      "ty": 41,
      "x": 60128,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75365,
      "e": 73175,
      "ty": 4,
      "x": 60128,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75365,
      "e": 73175,
      "ty": 5,
      "x": 632,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75977,
      "e": 73787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75978,
      "e": 73788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76072,
      "e": 73882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM T12PM "
    },
    {
      "t": 76104,
      "e": 73914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 76104,
      "e": 73914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76193,
      "e": 73914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM TH12PM "
    },
    {
      "t": 76217,
      "e": 73938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76217,
      "e": 73938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76338,
      "e": 74059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM THE12PM "
    },
    {
      "t": 76369,
      "e": 74090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76370,
      "e": 74091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76433,
      "e": 74154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM THE 12PM "
    },
    {
      "t": 77197,
      "e": 74918,
      "ty": 7,
      "x": 505,
      "y": 619,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77204,
      "e": 74925,
      "ty": 2,
      "x": 505,
      "y": 619
    },
    {
      "t": 77255,
      "e": 74976,
      "ty": 41,
      "x": 42787,
      "y": 13281,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 77305,
      "e": 75026,
      "ty": 2,
      "x": 373,
      "y": 614
    },
    {
      "t": 77397,
      "e": 75118,
      "ty": 6,
      "x": 359,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77404,
      "e": 75125,
      "ty": 2,
      "x": 359,
      "y": 600
    },
    {
      "t": 77505,
      "e": 75226,
      "ty": 2,
      "x": 207,
      "y": 559
    },
    {
      "t": 77505,
      "e": 75226,
      "ty": 41,
      "x": 12354,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77605,
      "e": 75326,
      "ty": 2,
      "x": 186,
      "y": 554
    },
    {
      "t": 77756,
      "e": 75477,
      "ty": 41,
      "x": 9881,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77805,
      "e": 75526,
      "ty": 2,
      "x": 185,
      "y": 562
    },
    {
      "t": 77906,
      "e": 75627,
      "ty": 2,
      "x": 186,
      "y": 563
    },
    {
      "t": 78005,
      "e": 75726,
      "ty": 2,
      "x": 186,
      "y": 566
    },
    {
      "t": 78006,
      "e": 75727,
      "ty": 41,
      "x": 9993,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78038,
      "e": 75759,
      "ty": 3,
      "x": 186,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78140,
      "e": 75861,
      "ty": 4,
      "x": 9993,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78141,
      "e": 75862,
      "ty": 5,
      "x": 186,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78841,
      "e": 76562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 78842,
      "e": 76563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78928,
      "e": 76649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 79017,
      "e": 76738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79017,
      "e": 76738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79106,
      "e": 76827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 79193,
      "e": 76914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 79194,
      "e": 76915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79264,
      "e": 76985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 79353,
      "e": 77074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79353,
      "e": 77074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79450,
      "e": 77171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 79489,
      "e": 77210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 79490,
      "e": 77211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79576,
      "e": 77297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 79576,
      "e": 77297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79577,
      "e": 77298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79656,
      "e": 77377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79657,
      "e": 77378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79729,
      "e": 77450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| O"
    },
    {
      "t": 79744,
      "e": 77465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79810,
      "e": 77531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79810,
      "e": 77531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79864,
      "e": 77585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79864,
      "e": 77585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79897,
      "e": 77618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N "
    },
    {
      "t": 79976,
      "e": 77697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79976,
      "e": 77697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 79977,
      "e": 77698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80065,
      "e": 77786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 80065,
      "e": 77786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80088,
      "e": 77809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 80153,
      "e": 77874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80160,
      "e": 77881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 80161,
      "e": 77882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80273,
      "e": 77994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 80280,
      "e": 78001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80281,
      "e": 78002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80369,
      "e": 78090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80450,
      "e": 78171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 80451,
      "e": 78172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80569,
      "e": 78290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 80698,
      "e": 78419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80698,
      "e": 78419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80785,
      "e": 78506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80785,
      "e": 78506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80793,
      "e": 78507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| A"
    },
    {
      "t": 80889,
      "e": 78603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81082,
      "e": 78796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 81082,
      "e": 78796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81200,
      "e": 78914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 81201,
      "e": 78915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81208,
      "e": 78922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||XI"
    },
    {
      "t": 81281,
      "e": 78995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81297,
      "e": 79011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 81297,
      "e": 79011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81401,
      "e": 79115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 82002,
      "e": 79716,
      "ty": 7,
      "x": 201,
      "y": 626,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82004,
      "e": 79718,
      "ty": 2,
      "x": 201,
      "y": 626
    },
    {
      "t": 82005,
      "e": 79719,
      "ty": 41,
      "x": 11680,
      "y": 34235,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 82106,
      "e": 79820,
      "ty": 2,
      "x": 260,
      "y": 662
    },
    {
      "t": 82204,
      "e": 79918,
      "ty": 2,
      "x": 273,
      "y": 656
    },
    {
      "t": 82255,
      "e": 79969,
      "ty": 41,
      "x": 20560,
      "y": 35897,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 82305,
      "e": 80019,
      "ty": 2,
      "x": 313,
      "y": 656
    },
    {
      "t": 82352,
      "e": 80066,
      "ty": 6,
      "x": 344,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 82406,
      "e": 80120,
      "ty": 2,
      "x": 354,
      "y": 656
    },
    {
      "t": 82505,
      "e": 80219,
      "ty": 2,
      "x": 376,
      "y": 660
    },
    {
      "t": 82506,
      "e": 80220,
      "ty": 41,
      "x": 20428,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 82550,
      "e": 80264,
      "ty": 3,
      "x": 376,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 82552,
      "e": 80266,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM THE 12PM POINT ON THE X AXIS"
    },
    {
      "t": 82553,
      "e": 80267,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82554,
      "e": 80268,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 82636,
      "e": 80350,
      "ty": 4,
      "x": 20428,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 82647,
      "e": 80361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 82648,
      "e": 80362,
      "ty": 5,
      "x": 376,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 82653,
      "e": 80367,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 83655,
      "e": 81369,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 84405,
      "e": 82119,
      "ty": 2,
      "x": 443,
      "y": 635
    },
    {
      "t": 84505,
      "e": 82219,
      "ty": 2,
      "x": 750,
      "y": 568
    },
    {
      "t": 84506,
      "e": 82220,
      "ty": 41,
      "x": 25552,
      "y": 31022,
      "ta": "html > body"
    },
    {
      "t": 84605,
      "e": 82319,
      "ty": 2,
      "x": 768,
      "y": 589
    },
    {
      "t": 84704,
      "e": 82418,
      "ty": 2,
      "x": 839,
      "y": 607
    },
    {
      "t": 84756,
      "e": 82470,
      "ty": 41,
      "x": 8002,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 84806,
      "e": 82520,
      "ty": 2,
      "x": 847,
      "y": 595
    },
    {
      "t": 84906,
      "e": 82620,
      "ty": 2,
      "x": 851,
      "y": 594
    },
    {
      "t": 85005,
      "e": 82719,
      "ty": 2,
      "x": 853,
      "y": 585
    },
    {
      "t": 85005,
      "e": 82719,
      "ty": 41,
      "x": 9732,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 85104,
      "e": 82818,
      "ty": 2,
      "x": 853,
      "y": 584
    },
    {
      "t": 85204,
      "e": 82918,
      "ty": 2,
      "x": 853,
      "y": 583
    },
    {
      "t": 85254,
      "e": 82968,
      "ty": 6,
      "x": 852,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85255,
      "e": 82969,
      "ty": 41,
      "x": 9516,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85305,
      "e": 83019,
      "ty": 2,
      "x": 852,
      "y": 567
    },
    {
      "t": 85421,
      "e": 83135,
      "ty": 3,
      "x": 852,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85421,
      "e": 83135,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85501,
      "e": 83215,
      "ty": 4,
      "x": 9516,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85501,
      "e": 83215,
      "ty": 5,
      "x": 852,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85506,
      "e": 83220,
      "ty": 41,
      "x": 9516,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86322,
      "e": 84036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 86322,
      "e": 84036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86432,
      "e": 84146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 86914,
      "e": 84628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 86914,
      "e": 84628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87016,
      "e": 84730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 87873,
      "e": 85587,
      "ty": 7,
      "x": 847,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87905,
      "e": 85619,
      "ty": 2,
      "x": 841,
      "y": 616
    },
    {
      "t": 87923,
      "e": 85637,
      "ty": 6,
      "x": 832,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87973,
      "e": 85687,
      "ty": 7,
      "x": 825,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88005,
      "e": 85719,
      "ty": 2,
      "x": 824,
      "y": 670
    },
    {
      "t": 88005,
      "e": 85719,
      "ty": 41,
      "x": 3460,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 88105,
      "e": 85819,
      "ty": 2,
      "x": 821,
      "y": 673
    },
    {
      "t": 88205,
      "e": 85919,
      "ty": 2,
      "x": 821,
      "y": 675
    },
    {
      "t": 88255,
      "e": 85969,
      "ty": 41,
      "x": 2811,
      "y": 64830,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 88341,
      "e": 86055,
      "ty": 6,
      "x": 821,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88404,
      "e": 86118,
      "ty": 2,
      "x": 821,
      "y": 658
    },
    {
      "t": 88505,
      "e": 86219,
      "ty": 2,
      "x": 821,
      "y": 657
    },
    {
      "t": 88505,
      "e": 86219,
      "ty": 41,
      "x": 2811,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88661,
      "e": 86375,
      "ty": 3,
      "x": 821,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88663,
      "e": 86377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 88663,
      "e": 86377,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88664,
      "e": 86378,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88773,
      "e": 86487,
      "ty": 4,
      "x": 2811,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88774,
      "e": 86488,
      "ty": 5,
      "x": 821,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89936,
      "e": 87650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 90005,
      "e": 87719,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90072,
      "e": 87786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "74"
    },
    {
      "t": 90072,
      "e": 87786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90128,
      "e": 87842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "j"
    },
    {
      "t": 90136,
      "e": 87850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "j"
    },
    {
      "t": 90232,
      "e": 87946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 90233,
      "e": 87947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90320,
      "e": 88034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 90320,
      "e": 88034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90329,
      "e": 88043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jAP"
    },
    {
      "t": 90413,
      "e": 88127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jAP"
    },
    {
      "t": 90440,
      "e": 88154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 90441,
      "e": 88155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90520,
      "e": 88234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jAPA"
    },
    {
      "t": 90536,
      "e": 88250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 90537,
      "e": 88251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90600,
      "e": 88314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||N"
    },
    {
      "t": 91577,
      "e": 89291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 91649,
      "e": 89363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jAPA"
    },
    {
      "t": 91744,
      "e": 89458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 91809,
      "e": 89523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jAP"
    },
    {
      "t": 91889,
      "e": 89603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 91969,
      "e": 89683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "jA"
    },
    {
      "t": 92049,
      "e": 89763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 92120,
      "e": 89834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "j"
    },
    {
      "t": 92208,
      "e": 89922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 92273,
      "e": 89987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 92406,
      "e": 90120,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 92809,
      "e": 90523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "74"
    },
    {
      "t": 92810,
      "e": 90524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92896,
      "e": 90610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "J"
    },
    {
      "t": 92952,
      "e": 90666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 92952,
      "e": 90666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93049,
      "e": 90763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 93049,
      "e": 90763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93056,
      "e": 90770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "JAP"
    },
    {
      "t": 93137,
      "e": 90851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "JAP"
    },
    {
      "t": 93144,
      "e": 90858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 93144,
      "e": 90858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93240,
      "e": 90954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "JAPA"
    },
    {
      "t": 93249,
      "e": 90963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 93249,
      "e": 90963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93329,
      "e": 91043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||N"
    },
    {
      "t": 94080,
      "e": 91794,
      "ty": 7,
      "x": 853,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94105,
      "e": 91819,
      "ty": 2,
      "x": 874,
      "y": 670
    },
    {
      "t": 94111,
      "e": 91825,
      "ty": 6,
      "x": 891,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94205,
      "e": 91919,
      "ty": 2,
      "x": 905,
      "y": 666
    },
    {
      "t": 94255,
      "e": 91969,
      "ty": 41,
      "x": 20979,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94341,
      "e": 92055,
      "ty": 7,
      "x": 905,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94361,
      "e": 92075,
      "ty": 6,
      "x": 909,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94404,
      "e": 92118,
      "ty": 2,
      "x": 917,
      "y": 690
    },
    {
      "t": 94505,
      "e": 92219,
      "ty": 2,
      "x": 930,
      "y": 705
    },
    {
      "t": 94505,
      "e": 92219,
      "ty": 41,
      "x": 17563,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94604,
      "e": 92318,
      "ty": 2,
      "x": 932,
      "y": 705
    },
    {
      "t": 94613,
      "e": 92327,
      "ty": 3,
      "x": 936,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94613,
      "e": 92327,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "JAPAN"
    },
    {
      "t": 94613,
      "e": 92327,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94613,
      "e": 92327,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94705,
      "e": 92419,
      "ty": 2,
      "x": 944,
      "y": 704
    },
    {
      "t": 94708,
      "e": 92422,
      "ty": 4,
      "x": 24778,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94709,
      "e": 92423,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94709,
      "e": 92423,
      "ty": 5,
      "x": 944,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 94709,
      "e": 92423,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 94754,
      "e": 92468,
      "ty": 41,
      "x": 32233,
      "y": 38556,
      "ta": "html > body"
    },
    {
      "t": 95720,
      "e": 93434,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 96605,
      "e": 94319,
      "ty": 2,
      "x": 898,
      "y": 497
    },
    {
      "t": 96705,
      "e": 94419,
      "ty": 2,
      "x": 821,
      "y": 312
    },
    {
      "t": 96755,
      "e": 94469,
      "ty": 41,
      "x": 27722,
      "y": 15566,
      "ta": "html > body"
    },
    {
      "t": 96804,
      "e": 94518,
      "ty": 2,
      "x": 814,
      "y": 283
    },
    {
      "t": 96905,
      "e": 94619,
      "ty": 2,
      "x": 822,
      "y": 274
    },
    {
      "t": 96981,
      "e": 94695,
      "ty": 6,
      "x": 828,
      "y": 266,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 97005,
      "e": 94719,
      "ty": 2,
      "x": 830,
      "y": 264
    },
    {
      "t": 97005,
      "e": 94719,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 97105,
      "e": 94819,
      "ty": 2,
      "x": 831,
      "y": 262
    },
    {
      "t": 97147,
      "e": 94861,
      "ty": 7,
      "x": 834,
      "y": 259,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 97204,
      "e": 94918,
      "ty": 2,
      "x": 834,
      "y": 256
    },
    {
      "t": 97255,
      "e": 94969,
      "ty": 41,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 97304,
      "e": 95018,
      "ty": 2,
      "x": 835,
      "y": 256
    },
    {
      "t": 97505,
      "e": 95219,
      "ty": 2,
      "x": 835,
      "y": 251
    },
    {
      "t": 97506,
      "e": 95220,
      "ty": 41,
      "x": 3222,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 97605,
      "e": 95319,
      "ty": 2,
      "x": 829,
      "y": 246
    },
    {
      "t": 97705,
      "e": 95419,
      "ty": 2,
      "x": 829,
      "y": 245
    },
    {
      "t": 97756,
      "e": 95470,
      "ty": 41,
      "x": 6205,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 97757,
      "e": 95471,
      "ty": 6,
      "x": 829,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 97805,
      "e": 95519,
      "ty": 2,
      "x": 829,
      "y": 243
    },
    {
      "t": 97905,
      "e": 95619,
      "ty": 2,
      "x": 829,
      "y": 240
    },
    {
      "t": 98005,
      "e": 95719,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98105,
      "e": 95819,
      "ty": 2,
      "x": 829,
      "y": 239
    },
    {
      "t": 98255,
      "e": 95969,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98316,
      "e": 96030,
      "ty": 3,
      "x": 829,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98317,
      "e": 96031,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98460,
      "e": 96174,
      "ty": 4,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98461,
      "e": 96175,
      "ty": 5,
      "x": 829,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98461,
      "e": 96175,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 98853,
      "e": 96567,
      "ty": 7,
      "x": 831,
      "y": 249,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98905,
      "e": 96567,
      "ty": 2,
      "x": 844,
      "y": 277
    },
    {
      "t": 99005,
      "e": 96667,
      "ty": 2,
      "x": 862,
      "y": 337
    },
    {
      "t": 99005,
      "e": 96667,
      "ty": 41,
      "x": 9630,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 99105,
      "e": 96767,
      "ty": 2,
      "x": 866,
      "y": 374
    },
    {
      "t": 99205,
      "e": 96867,
      "ty": 2,
      "x": 865,
      "y": 400
    },
    {
      "t": 99255,
      "e": 96917,
      "ty": 41,
      "x": 46329,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 99305,
      "e": 96967,
      "ty": 2,
      "x": 859,
      "y": 411
    },
    {
      "t": 99405,
      "e": 97067,
      "ty": 2,
      "x": 854,
      "y": 419
    },
    {
      "t": 99505,
      "e": 97167,
      "ty": 2,
      "x": 847,
      "y": 376
    },
    {
      "t": 99505,
      "e": 97167,
      "ty": 41,
      "x": 6070,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 99605,
      "e": 97267,
      "ty": 2,
      "x": 838,
      "y": 348
    },
    {
      "t": 99756,
      "e": 97418,
      "ty": 41,
      "x": 3934,
      "y": 13973,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 99905,
      "e": 97567,
      "ty": 2,
      "x": 838,
      "y": 351
    },
    {
      "t": 100005,
      "e": 97667,
      "ty": 2,
      "x": 850,
      "y": 377
    },
    {
      "t": 100006,
      "e": 97668,
      "ty": 41,
      "x": 6782,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 100105,
      "e": 97767,
      "ty": 2,
      "x": 854,
      "y": 394
    },
    {
      "t": 100205,
      "e": 97867,
      "ty": 2,
      "x": 854,
      "y": 410
    },
    {
      "t": 100255,
      "e": 97917,
      "ty": 41,
      "x": 38135,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 100305,
      "e": 97967,
      "ty": 2,
      "x": 854,
      "y": 414
    },
    {
      "t": 100405,
      "e": 98067,
      "ty": 2,
      "x": 852,
      "y": 414
    },
    {
      "t": 100506,
      "e": 98168,
      "ty": 2,
      "x": 849,
      "y": 414
    },
    {
      "t": 100506,
      "e": 98168,
      "ty": 41,
      "x": 32282,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 100605,
      "e": 98267,
      "ty": 2,
      "x": 847,
      "y": 414
    },
    {
      "t": 100705,
      "e": 98367,
      "ty": 2,
      "x": 846,
      "y": 414
    },
    {
      "t": 100756,
      "e": 98418,
      "ty": 41,
      "x": 28771,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 100905,
      "e": 98567,
      "ty": 2,
      "x": 840,
      "y": 414
    },
    {
      "t": 100917,
      "e": 98579,
      "ty": 6,
      "x": 839,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101005,
      "e": 98667,
      "ty": 2,
      "x": 833,
      "y": 411
    },
    {
      "t": 101005,
      "e": 98667,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101105,
      "e": 98767,
      "ty": 2,
      "x": 831,
      "y": 409
    },
    {
      "t": 101165,
      "e": 98827,
      "ty": 3,
      "x": 831,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101167,
      "e": 98829,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 101167,
      "e": 98829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101255,
      "e": 98917,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101292,
      "e": 98954,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101292,
      "e": 98954,
      "ty": 5,
      "x": 831,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101292,
      "e": 98954,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 101705,
      "e": 99367,
      "ty": 2,
      "x": 828,
      "y": 412
    },
    {
      "t": 101717,
      "e": 99379,
      "ty": 7,
      "x": 828,
      "y": 421,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 101755,
      "e": 99417,
      "ty": 41,
      "x": 5254,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 101766,
      "e": 99428,
      "ty": 6,
      "x": 829,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101805,
      "e": 99467,
      "ty": 2,
      "x": 829,
      "y": 442
    },
    {
      "t": 101850,
      "e": 99512,
      "ty": 7,
      "x": 838,
      "y": 456,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101905,
      "e": 99567,
      "ty": 2,
      "x": 845,
      "y": 474
    },
    {
      "t": 102005,
      "e": 99667,
      "ty": 2,
      "x": 870,
      "y": 524
    },
    {
      "t": 102005,
      "e": 99667,
      "ty": 41,
      "x": 56849,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 102105,
      "e": 99767,
      "ty": 2,
      "x": 873,
      "y": 528
    },
    {
      "t": 102256,
      "e": 99918,
      "ty": 41,
      "x": 60360,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 102405,
      "e": 100067,
      "ty": 2,
      "x": 894,
      "y": 553
    },
    {
      "t": 102505,
      "e": 100167,
      "ty": 2,
      "x": 945,
      "y": 611
    },
    {
      "t": 102505,
      "e": 100167,
      "ty": 41,
      "x": 29328,
      "y": 33626,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102606,
      "e": 100268,
      "ty": 2,
      "x": 963,
      "y": 650
    },
    {
      "t": 102705,
      "e": 100367,
      "ty": 2,
      "x": 966,
      "y": 698
    },
    {
      "t": 102755,
      "e": 100417,
      "ty": 41,
      "x": 34311,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 102805,
      "e": 100467,
      "ty": 2,
      "x": 963,
      "y": 734
    },
    {
      "t": 102905,
      "e": 100567,
      "ty": 2,
      "x": 950,
      "y": 765
    },
    {
      "t": 103005,
      "e": 100667,
      "ty": 2,
      "x": 939,
      "y": 782
    },
    {
      "t": 103005,
      "e": 100667,
      "ty": 41,
      "x": 27904,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 103109,
      "e": 100771,
      "ty": 2,
      "x": 926,
      "y": 791
    },
    {
      "t": 103209,
      "e": 100871,
      "ty": 2,
      "x": 910,
      "y": 806
    },
    {
      "t": 103261,
      "e": 100873,
      "ty": 41,
      "x": 48740,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 103309,
      "e": 100921,
      "ty": 2,
      "x": 901,
      "y": 818
    },
    {
      "t": 103409,
      "e": 101021,
      "ty": 2,
      "x": 897,
      "y": 828
    },
    {
      "t": 103509,
      "e": 101121,
      "ty": 2,
      "x": 892,
      "y": 837
    },
    {
      "t": 103509,
      "e": 101121,
      "ty": 41,
      "x": 49726,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 103609,
      "e": 101221,
      "ty": 2,
      "x": 889,
      "y": 839
    },
    {
      "t": 103709,
      "e": 101321,
      "ty": 2,
      "x": 888,
      "y": 840
    },
    {
      "t": 103760,
      "e": 101372,
      "ty": 41,
      "x": 46908,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 104009,
      "e": 101621,
      "ty": 2,
      "x": 885,
      "y": 819
    },
    {
      "t": 104009,
      "e": 101621,
      "ty": 41,
      "x": 37526,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 104109,
      "e": 101721,
      "ty": 2,
      "x": 879,
      "y": 786
    },
    {
      "t": 104209,
      "e": 101821,
      "ty": 2,
      "x": 876,
      "y": 770
    },
    {
      "t": 104259,
      "e": 101871,
      "ty": 41,
      "x": 22355,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 104309,
      "e": 101921,
      "ty": 2,
      "x": 875,
      "y": 767
    },
    {
      "t": 104409,
      "e": 102021,
      "ty": 2,
      "x": 869,
      "y": 746
    },
    {
      "t": 104508,
      "e": 102120,
      "ty": 2,
      "x": 851,
      "y": 693
    },
    {
      "t": 104509,
      "e": 102121,
      "ty": 41,
      "x": 7453,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 104609,
      "e": 102221,
      "ty": 2,
      "x": 849,
      "y": 689
    },
    {
      "t": 104710,
      "e": 102322,
      "ty": 2,
      "x": 845,
      "y": 689
    },
    {
      "t": 104760,
      "e": 102372,
      "ty": 41,
      "x": 4681,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 104791,
      "e": 102403,
      "ty": 6,
      "x": 839,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 104809,
      "e": 102421,
      "ty": 2,
      "x": 839,
      "y": 696
    },
    {
      "t": 104909,
      "e": 102521,
      "ty": 2,
      "x": 837,
      "y": 698
    },
    {
      "t": 105010,
      "e": 102622,
      "ty": 41,
      "x": 53325,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105210,
      "e": 102822,
      "ty": 2,
      "x": 833,
      "y": 703
    },
    {
      "t": 105259,
      "e": 102871,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105310,
      "e": 102922,
      "ty": 2,
      "x": 832,
      "y": 703
    },
    {
      "t": 105801,
      "e": 103413,
      "ty": 3,
      "x": 832,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105802,
      "e": 103414,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 105804,
      "e": 103416,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105936,
      "e": 103548,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105936,
      "e": 103548,
      "ty": 5,
      "x": 832,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 105937,
      "e": 103549,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 106192,
      "e": 103804,
      "ty": 7,
      "x": 833,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106208,
      "e": 103820,
      "ty": 2,
      "x": 840,
      "y": 739
    },
    {
      "t": 106259,
      "e": 103871,
      "ty": 41,
      "x": 31033,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 106309,
      "e": 103921,
      "ty": 2,
      "x": 881,
      "y": 814
    },
    {
      "t": 106409,
      "e": 104021,
      "ty": 2,
      "x": 879,
      "y": 818
    },
    {
      "t": 106509,
      "e": 104121,
      "ty": 2,
      "x": 860,
      "y": 836
    },
    {
      "t": 106509,
      "e": 104121,
      "ty": 41,
      "x": 27180,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 106609,
      "e": 104221,
      "ty": 2,
      "x": 843,
      "y": 836
    },
    {
      "t": 106641,
      "e": 104253,
      "ty": 6,
      "x": 835,
      "y": 810,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 106658,
      "e": 104270,
      "ty": 7,
      "x": 832,
      "y": 794,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 106675,
      "e": 104287,
      "ty": 6,
      "x": 830,
      "y": 785,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 106709,
      "e": 104321,
      "ty": 7,
      "x": 828,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 106710,
      "e": 104322,
      "ty": 2,
      "x": 828,
      "y": 779
    },
    {
      "t": 106760,
      "e": 104372,
      "ty": 41,
      "x": 3682,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 106770,
      "e": 104372,
      "ty": 6,
      "x": 828,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 106808,
      "e": 104410,
      "ty": 7,
      "x": 828,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 106808,
      "e": 104410,
      "ty": 2,
      "x": 828,
      "y": 793
    },
    {
      "t": 106858,
      "e": 104460,
      "ty": 6,
      "x": 833,
      "y": 813,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 106892,
      "e": 104494,
      "ty": 7,
      "x": 834,
      "y": 823,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 106909,
      "e": 104511,
      "ty": 2,
      "x": 834,
      "y": 827
    },
    {
      "t": 107009,
      "e": 104611,
      "ty": 2,
      "x": 835,
      "y": 833
    },
    {
      "t": 107010,
      "e": 104612,
      "ty": 41,
      "x": 9566,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 107033,
      "e": 104635,
      "ty": 6,
      "x": 835,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107109,
      "e": 104711,
      "ty": 2,
      "x": 833,
      "y": 840
    },
    {
      "t": 107201,
      "e": 104803,
      "ty": 3,
      "x": 833,
      "y": 840,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107202,
      "e": 104804,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107203,
      "e": 104805,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107259,
      "e": 104861,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107320,
      "e": 104922,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107320,
      "e": 104922,
      "ty": 5,
      "x": 832,
      "y": 841,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107320,
      "e": 104922,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf",
      "v": "Fine Arts"
    },
    {
      "t": 107409,
      "e": 105011,
      "ty": 2,
      "x": 831,
      "y": 841
    },
    {
      "t": 107509,
      "e": 105111,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107601,
      "e": 105203,
      "ty": 7,
      "x": 836,
      "y": 834,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 107610,
      "e": 105212,
      "ty": 2,
      "x": 836,
      "y": 834
    },
    {
      "t": 107709,
      "e": 105311,
      "ty": 2,
      "x": 860,
      "y": 776
    },
    {
      "t": 107759,
      "e": 105361,
      "ty": 41,
      "x": 16096,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 107809,
      "e": 105411,
      "ty": 2,
      "x": 860,
      "y": 750
    },
    {
      "t": 107859,
      "e": 105461,
      "ty": 6,
      "x": 838,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 107909,
      "e": 105511,
      "ty": 2,
      "x": 828,
      "y": 730
    },
    {
      "t": 108009,
      "e": 105611,
      "ty": 2,
      "x": 826,
      "y": 728
    },
    {
      "t": 108009,
      "e": 105611,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 108047,
      "e": 105649,
      "ty": 7,
      "x": 826,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 108109,
      "e": 105711,
      "ty": 2,
      "x": 829,
      "y": 721
    },
    {
      "t": 108209,
      "e": 105811,
      "ty": 2,
      "x": 838,
      "y": 711
    },
    {
      "t": 108260,
      "e": 105862,
      "ty": 41,
      "x": 4177,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108310,
      "e": 105912,
      "ty": 2,
      "x": 840,
      "y": 707
    },
    {
      "t": 108509,
      "e": 106111,
      "ty": 41,
      "x": 4681,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108578,
      "e": 106180,
      "ty": 6,
      "x": 839,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 108609,
      "e": 106211,
      "ty": 2,
      "x": 836,
      "y": 701
    },
    {
      "t": 108644,
      "e": 106246,
      "ty": 7,
      "x": 827,
      "y": 694,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 108709,
      "e": 106311,
      "ty": 2,
      "x": 826,
      "y": 694
    },
    {
      "t": 108759,
      "e": 106361,
      "ty": 41,
      "x": 1153,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108889,
      "e": 106491,
      "ty": 3,
      "x": 826,
      "y": 694,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 108890,
      "e": 106492,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 109031,
      "e": 106633,
      "ty": 4,
      "x": 1153,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 109032,
      "e": 106634,
      "ty": 5,
      "x": 826,
      "y": 694,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 109032,
      "e": 106634,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109033,
      "e": 106635,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 109210,
      "e": 106812,
      "ty": 2,
      "x": 825,
      "y": 694
    },
    {
      "t": 109259,
      "e": 106861,
      "ty": 41,
      "x": 397,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 109309,
      "e": 106911,
      "ty": 2,
      "x": 823,
      "y": 694
    },
    {
      "t": 109361,
      "e": 106963,
      "ty": 6,
      "x": 827,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109409,
      "e": 107011,
      "ty": 2,
      "x": 830,
      "y": 698
    },
    {
      "t": 109509,
      "e": 107111,
      "ty": 41,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109609,
      "e": 107211,
      "ty": 3,
      "x": 831,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109610,
      "e": 107212,
      "ty": 2,
      "x": 831,
      "y": 698
    },
    {
      "t": 109721,
      "e": 107323,
      "ty": 4,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109721,
      "e": 107323,
      "ty": 5,
      "x": 831,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109722,
      "e": 107324,
      "ty": 7,
      "x": 831,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109722,
      "e": 107324,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 109759,
      "e": 107361,
      "ty": 41,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109832,
      "e": 107434,
      "ty": 6,
      "x": 833,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109845,
      "e": 107447,
      "ty": 7,
      "x": 837,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109909,
      "e": 107511,
      "ty": 2,
      "x": 874,
      "y": 791
    },
    {
      "t": 110009,
      "e": 107611,
      "ty": 2,
      "x": 891,
      "y": 840
    },
    {
      "t": 110010,
      "e": 107612,
      "ty": 41,
      "x": 49021,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 110109,
      "e": 107711,
      "ty": 2,
      "x": 891,
      "y": 841
    },
    {
      "t": 110209,
      "e": 107811,
      "ty": 2,
      "x": 879,
      "y": 859
    },
    {
      "t": 110260,
      "e": 107862,
      "ty": 41,
      "x": 12003,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 110309,
      "e": 107911,
      "ty": 2,
      "x": 866,
      "y": 914
    },
    {
      "t": 110410,
      "e": 108012,
      "ty": 2,
      "x": 854,
      "y": 956
    },
    {
      "t": 110478,
      "e": 108080,
      "ty": 6,
      "x": 837,
      "y": 987,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 110509,
      "e": 108111,
      "ty": 2,
      "x": 836,
      "y": 992
    },
    {
      "t": 110509,
      "e": 108111,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 110609,
      "e": 108211,
      "ty": 2,
      "x": 834,
      "y": 995
    },
    {
      "t": 110760,
      "e": 108362,
      "ty": 41,
      "x": 23079,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 110809,
      "e": 108411,
      "ty": 2,
      "x": 831,
      "y": 987
    },
    {
      "t": 110829,
      "e": 108431,
      "ty": 7,
      "x": 831,
      "y": 983,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 110909,
      "e": 108511,
      "ty": 2,
      "x": 827,
      "y": 971
    },
    {
      "t": 110945,
      "e": 108547,
      "ty": 6,
      "x": 826,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110962,
      "e": 108564,
      "ty": 7,
      "x": 825,
      "y": 967,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111009,
      "e": 108611,
      "ty": 2,
      "x": 825,
      "y": 966
    },
    {
      "t": 111010,
      "e": 108612,
      "ty": 41,
      "x": 2894,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 111109,
      "e": 108711,
      "ty": 2,
      "x": 825,
      "y": 960
    },
    {
      "t": 111121,
      "e": 108723,
      "ty": 6,
      "x": 826,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111210,
      "e": 108812,
      "ty": 2,
      "x": 827,
      "y": 959
    },
    {
      "t": 111261,
      "e": 108813,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111309,
      "e": 108861,
      "ty": 2,
      "x": 830,
      "y": 958
    },
    {
      "t": 111409,
      "e": 108961,
      "ty": 2,
      "x": 831,
      "y": 958
    },
    {
      "t": 111424,
      "e": 108976,
      "ty": 3,
      "x": 834,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111425,
      "e": 108977,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 111426,
      "e": 108978,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111509,
      "e": 109061,
      "ty": 2,
      "x": 835,
      "y": 956
    },
    {
      "t": 111509,
      "e": 109061,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111560,
      "e": 109112,
      "ty": 4,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111560,
      "e": 109112,
      "ty": 5,
      "x": 835,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111560,
      "e": 109112,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 111879,
      "e": 109431,
      "ty": 7,
      "x": 842,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111909,
      "e": 109461,
      "ty": 2,
      "x": 856,
      "y": 978
    },
    {
      "t": 112008,
      "e": 109560,
      "ty": 2,
      "x": 875,
      "y": 996
    },
    {
      "t": 112008,
      "e": 109560,
      "ty": 41,
      "x": 53188,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 112109,
      "e": 109661,
      "ty": 2,
      "x": 875,
      "y": 1000
    },
    {
      "t": 112210,
      "e": 109762,
      "ty": 2,
      "x": 876,
      "y": 1004
    },
    {
      "t": 112260,
      "e": 109812,
      "ty": 41,
      "x": 12952,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 112369,
      "e": 109921,
      "ty": 6,
      "x": 877,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112409,
      "e": 109961,
      "ty": 2,
      "x": 877,
      "y": 1005
    },
    {
      "t": 112510,
      "e": 110062,
      "ty": 41,
      "x": 24521,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113409,
      "e": 110961,
      "ty": 2,
      "x": 883,
      "y": 1010
    },
    {
      "t": 113510,
      "e": 111062,
      "ty": 41,
      "x": 27613,
      "y": 9929,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113909,
      "e": 111461,
      "ty": 2,
      "x": 883,
      "y": 1011
    },
    {
      "t": 113985,
      "e": 111537,
      "ty": 3,
      "x": 883,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113987,
      "e": 111539,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 113988,
      "e": 111540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114010,
      "e": 111562,
      "ty": 41,
      "x": 27613,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114072,
      "e": 111624,
      "ty": 4,
      "x": 27613,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114073,
      "e": 111625,
      "ty": 5,
      "x": 883,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114078,
      "e": 111630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114078,
      "e": 111630,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 114079,
      "e": 111631,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 115473,
      "e": 113025,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 120008,
      "e": 116630,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 133909,
      "e": 116630,
      "ty": 2,
      "x": 1002,
      "y": 839
    },
    {
      "t": 134009,
      "e": 116730,
      "ty": 2,
      "x": 1011,
      "y": 777
    },
    {
      "t": 134010,
      "e": 116731,
      "ty": 41,
      "x": 35301,
      "y": 63496,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 134109,
      "e": 116830,
      "ty": 2,
      "x": 971,
      "y": 658
    },
    {
      "t": 134209,
      "e": 116930,
      "ty": 2,
      "x": 994,
      "y": 569
    },
    {
      "t": 134259,
      "e": 116980,
      "ty": 41,
      "x": 34612,
      "y": 30238,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 134309,
      "e": 117030,
      "ty": 2,
      "x": 997,
      "y": 560
    },
    {
      "t": 134409,
      "e": 117130,
      "ty": 2,
      "x": 1011,
      "y": 551
    },
    {
      "t": 134510,
      "e": 117231,
      "ty": 2,
      "x": 1015,
      "y": 546
    },
    {
      "t": 134510,
      "e": 117231,
      "ty": 41,
      "x": 35497,
      "y": 24776,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 136710,
      "e": 119431,
      "ty": 2,
      "x": 1015,
      "y": 545
    },
    {
      "t": 136760,
      "e": 119481,
      "ty": 41,
      "x": 35497,
      "y": 24386,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 137209,
      "e": 119930,
      "ty": 2,
      "x": 1010,
      "y": 546
    },
    {
      "t": 137259,
      "e": 119980,
      "ty": 41,
      "x": 35251,
      "y": 25166,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 137309,
      "e": 120030,
      "ty": 2,
      "x": 1010,
      "y": 547
    },
    {
      "t": 137509,
      "e": 120230,
      "ty": 2,
      "x": 1031,
      "y": 568
    },
    {
      "t": 137510,
      "e": 120231,
      "ty": 41,
      "x": 36285,
      "y": 33358,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 137608,
      "e": 120329,
      "ty": 2,
      "x": 1027,
      "y": 570
    },
    {
      "t": 137709,
      "e": 120430,
      "ty": 2,
      "x": 1024,
      "y": 570
    },
    {
      "t": 137760,
      "e": 120481,
      "ty": 41,
      "x": 35940,
      "y": 34138,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 138259,
      "e": 120980,
      "ty": 41,
      "x": 35891,
      "y": 33748,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 138309,
      "e": 121030,
      "ty": 2,
      "x": 1023,
      "y": 569
    },
    {
      "t": 138410,
      "e": 121131,
      "ty": 2,
      "x": 992,
      "y": 575
    },
    {
      "t": 138509,
      "e": 121230,
      "ty": 2,
      "x": 901,
      "y": 578
    },
    {
      "t": 138509,
      "e": 121230,
      "ty": 41,
      "x": 29889,
      "y": 37259,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 138609,
      "e": 121330,
      "ty": 2,
      "x": 760,
      "y": 561
    },
    {
      "t": 138710,
      "e": 121431,
      "ty": 2,
      "x": 633,
      "y": 547
    },
    {
      "t": 138760,
      "e": 121481,
      "ty": 41,
      "x": 13802,
      "y": 22826,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 138809,
      "e": 121530,
      "ty": 2,
      "x": 534,
      "y": 543
    },
    {
      "t": 138909,
      "e": 121630,
      "ty": 2,
      "x": 505,
      "y": 546
    },
    {
      "t": 139009,
      "e": 121730,
      "ty": 2,
      "x": 565,
      "y": 603
    },
    {
      "t": 139009,
      "e": 121730,
      "ty": 41,
      "x": 13359,
      "y": 47011,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 139109,
      "e": 121830,
      "ty": 2,
      "x": 652,
      "y": 635
    },
    {
      "t": 139209,
      "e": 121930,
      "ty": 2,
      "x": 694,
      "y": 640
    },
    {
      "t": 139259,
      "e": 121980,
      "ty": 41,
      "x": 19902,
      "y": 58714,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 139310,
      "e": 122031,
      "ty": 2,
      "x": 702,
      "y": 623
    },
    {
      "t": 139410,
      "e": 122131,
      "ty": 2,
      "x": 738,
      "y": 587
    },
    {
      "t": 139510,
      "e": 122231,
      "ty": 2,
      "x": 762,
      "y": 572
    },
    {
      "t": 139510,
      "e": 122231,
      "ty": 41,
      "x": 23051,
      "y": 34919,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 139609,
      "e": 122330,
      "ty": 2,
      "x": 791,
      "y": 586
    },
    {
      "t": 139709,
      "e": 122430,
      "ty": 2,
      "x": 813,
      "y": 612
    },
    {
      "t": 139759,
      "e": 122480,
      "ty": 41,
      "x": 25756,
      "y": 50522,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 139810,
      "e": 122531,
      "ty": 2,
      "x": 822,
      "y": 612
    },
    {
      "t": 139909,
      "e": 122630,
      "ty": 2,
      "x": 848,
      "y": 601
    },
    {
      "t": 140009,
      "e": 122730,
      "ty": 2,
      "x": 850,
      "y": 599
    },
    {
      "t": 140009,
      "e": 122730,
      "ty": 41,
      "x": 27380,
      "y": 45451,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 140009,
      "e": 122730,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140109,
      "e": 122830,
      "ty": 2,
      "x": 843,
      "y": 601
    },
    {
      "t": 140209,
      "e": 122930,
      "ty": 2,
      "x": 768,
      "y": 604
    },
    {
      "t": 140259,
      "e": 122980,
      "ty": 41,
      "x": 23297,
      "y": 47401,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 140309,
      "e": 123030,
      "ty": 2,
      "x": 760,
      "y": 614
    },
    {
      "t": 140409,
      "e": 123130,
      "ty": 2,
      "x": 714,
      "y": 633
    },
    {
      "t": 140510,
      "e": 123231,
      "ty": 2,
      "x": 675,
      "y": 639
    },
    {
      "t": 140510,
      "e": 123231,
      "ty": 41,
      "x": 18770,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 140609,
      "e": 123330,
      "ty": 2,
      "x": 653,
      "y": 646
    },
    {
      "t": 140709,
      "e": 123430,
      "ty": 2,
      "x": 645,
      "y": 651
    },
    {
      "t": 140759,
      "e": 123480,
      "ty": 41,
      "x": 17295,
      "y": 36763,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 140810,
      "e": 123531,
      "ty": 2,
      "x": 645,
      "y": 652
    },
    {
      "t": 140910,
      "e": 123631,
      "ty": 2,
      "x": 646,
      "y": 662
    },
    {
      "t": 141009,
      "e": 123730,
      "ty": 2,
      "x": 712,
      "y": 706
    },
    {
      "t": 141010,
      "e": 123731,
      "ty": 41,
      "x": 20591,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 141109,
      "e": 123830,
      "ty": 2,
      "x": 734,
      "y": 713
    },
    {
      "t": 141209,
      "e": 123930,
      "ty": 2,
      "x": 740,
      "y": 712
    },
    {
      "t": 141260,
      "e": 123981,
      "ty": 41,
      "x": 22067,
      "y": 25462,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 141309,
      "e": 124030,
      "ty": 2,
      "x": 745,
      "y": 710
    },
    {
      "t": 141409,
      "e": 124130,
      "ty": 2,
      "x": 772,
      "y": 696
    },
    {
      "t": 141509,
      "e": 124230,
      "ty": 2,
      "x": 801,
      "y": 677
    },
    {
      "t": 141510,
      "e": 124231,
      "ty": 41,
      "x": 24969,
      "y": 4982,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 141610,
      "e": 124331,
      "ty": 2,
      "x": 852,
      "y": 676
    },
    {
      "t": 141710,
      "e": 124431,
      "ty": 2,
      "x": 921,
      "y": 687
    },
    {
      "t": 141760,
      "e": 124481,
      "ty": 41,
      "x": 32103,
      "y": 19611,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 141809,
      "e": 124530,
      "ty": 2,
      "x": 978,
      "y": 719
    },
    {
      "t": 141909,
      "e": 124630,
      "ty": 2,
      "x": 1004,
      "y": 730
    },
    {
      "t": 142010,
      "e": 124731,
      "ty": 2,
      "x": 1006,
      "y": 731
    },
    {
      "t": 142010,
      "e": 124731,
      "ty": 41,
      "x": 35055,
      "y": 36580,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142110,
      "e": 124831,
      "ty": 2,
      "x": 1004,
      "y": 732
    },
    {
      "t": 142260,
      "e": 124981,
      "ty": 41,
      "x": 34956,
      "y": 37165,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142509,
      "e": 125230,
      "ty": 2,
      "x": 1000,
      "y": 732
    },
    {
      "t": 142510,
      "e": 125231,
      "ty": 41,
      "x": 34759,
      "y": 37165,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142609,
      "e": 125330,
      "ty": 2,
      "x": 946,
      "y": 714
    },
    {
      "t": 142709,
      "e": 125430,
      "ty": 2,
      "x": 934,
      "y": 713
    },
    {
      "t": 142759,
      "e": 125480,
      "ty": 41,
      "x": 29889,
      "y": 38920,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142809,
      "e": 125530,
      "ty": 2,
      "x": 866,
      "y": 778
    },
    {
      "t": 142909,
      "e": 125630,
      "ty": 2,
      "x": 848,
      "y": 805
    },
    {
      "t": 143009,
      "e": 125730,
      "ty": 2,
      "x": 849,
      "y": 850
    },
    {
      "t": 143010,
      "e": 125731,
      "ty": 41,
      "x": 27331,
      "y": 60287,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 143109,
      "e": 125830,
      "ty": 2,
      "x": 857,
      "y": 862
    },
    {
      "t": 143210,
      "e": 125931,
      "ty": 2,
      "x": 861,
      "y": 864
    },
    {
      "t": 143260,
      "e": 125981,
      "ty": 41,
      "x": 28610,
      "y": 17590,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 143310,
      "e": 126031,
      "ty": 2,
      "x": 901,
      "y": 913
    },
    {
      "t": 143410,
      "e": 126131,
      "ty": 2,
      "x": 948,
      "y": 1011
    },
    {
      "t": 143478,
      "e": 126199,
      "ty": 6,
      "x": 993,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 143509,
      "e": 126230,
      "ty": 2,
      "x": 999,
      "y": 1097
    },
    {
      "t": 143509,
      "e": 126230,
      "ty": 41,
      "x": 48878,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 143511,
      "e": 126232,
      "ty": 7,
      "x": 1007,
      "y": 1113,
      "ta": "#start"
    },
    {
      "t": 143610,
      "e": 126331,
      "ty": 2,
      "x": 1029,
      "y": 1154
    },
    {
      "t": 143760,
      "e": 126481,
      "ty": 41,
      "x": 65300,
      "y": 45046,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 143809,
      "e": 126530,
      "ty": 2,
      "x": 1028,
      "y": 1151
    },
    {
      "t": 143909,
      "e": 126630,
      "ty": 2,
      "x": 1019,
      "y": 1123
    },
    {
      "t": 144008,
      "e": 126729,
      "ty": 2,
      "x": 1014,
      "y": 1115
    },
    {
      "t": 144009,
      "e": 126730,
      "ty": 41,
      "x": 58279,
      "y": 23440,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 144055,
      "e": 126776,
      "ty": 6,
      "x": 1006,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 144110,
      "e": 126831,
      "ty": 2,
      "x": 982,
      "y": 1086
    },
    {
      "t": 144210,
      "e": 126931,
      "ty": 2,
      "x": 965,
      "y": 1082
    },
    {
      "t": 144259,
      "e": 126980,
      "ty": 41,
      "x": 29763,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 144309,
      "e": 127030,
      "ty": 2,
      "x": 962,
      "y": 1084
    },
    {
      "t": 144410,
      "e": 127131,
      "ty": 2,
      "x": 961,
      "y": 1085
    },
    {
      "t": 144466,
      "e": 127187,
      "ty": 3,
      "x": 961,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 144466,
      "e": 127187,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 144510,
      "e": 127231,
      "ty": 41,
      "x": 28125,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 144568,
      "e": 127289,
      "ty": 4,
      "x": 28125,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 144569,
      "e": 127290,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 144570,
      "e": 127291,
      "ty": 5,
      "x": 961,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 144571,
      "e": 127292,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 145618,
      "e": 128339,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 147094,
      "e": 129815,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 335141, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 335148, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 20143, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 356687, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 15392, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 373088, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 18532, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 392726, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13177, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 406904, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 55647, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 463979, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -A -C -A -A -A -O -O -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:953,y:1081,t:1528139587079};\\\", \\\"{x:953,y:1054,t:1528139587087};\\\", \\\"{x:953,y:1026,t:1528139587101};\\\", \\\"{x:943,y:948,t:1528139587117};\\\", \\\"{x:934,y:821,t:1528139587133};\\\", \\\"{x:915,y:736,t:1528139587150};\\\", \\\"{x:878,y:625,t:1528139587168};\\\", \\\"{x:809,y:501,t:1528139587185};\\\", \\\"{x:696,y:380,t:1528139587199};\\\", \\\"{x:591,y:283,t:1528139587217};\\\", \\\"{x:504,y:223,t:1528139587233};\\\", \\\"{x:443,y:163,t:1528139587250};\\\", \\\"{x:408,y:122,t:1528139587267};\\\", \\\"{x:380,y:103,t:1528139587283};\\\", \\\"{x:363,y:91,t:1528139587300};\\\", \\\"{x:331,y:89,t:1528139587317};\\\", \\\"{x:316,y:103,t:1528139587334};\\\", \\\"{x:300,y:122,t:1528139587350};\\\", \\\"{x:286,y:154,t:1528139587367};\\\", \\\"{x:278,y:171,t:1528139587384};\\\", \\\"{x:269,y:203,t:1528139587400};\\\", \\\"{x:263,y:223,t:1528139587417};\\\", \\\"{x:258,y:238,t:1528139587434};\\\", \\\"{x:256,y:257,t:1528139587451};\\\", \\\"{x:259,y:281,t:1528139587468};\\\", \\\"{x:268,y:297,t:1528139587484};\\\", \\\"{x:270,y:299,t:1528139587501};\\\", \\\"{x:275,y:309,t:1528139587517};\\\", \\\"{x:275,y:310,t:1528139587662};\\\", \\\"{x:274,y:310,t:1528139587677};\\\", \\\"{x:274,y:311,t:1528139587688};\\\", \\\"{x:274,y:312,t:1528139587700};\\\", \\\"{x:273,y:319,t:1528139587717};\\\", \\\"{x:274,y:322,t:1528139587734};\\\", \\\"{x:275,y:324,t:1528139587749};\\\", \\\"{x:275,y:325,t:1528139587886};\\\", \\\"{x:275,y:322,t:1528139589830};\\\", \\\"{x:275,y:324,t:1528139590342};\\\", \\\"{x:275,y:328,t:1528139590353};\\\", \\\"{x:275,y:342,t:1528139590370};\\\", \\\"{x:283,y:368,t:1528139590386};\\\", \\\"{x:297,y:400,t:1528139590403};\\\", \\\"{x:314,y:432,t:1528139590420};\\\", \\\"{x:328,y:454,t:1528139590437};\\\", \\\"{x:339,y:470,t:1528139590453};\\\", \\\"{x:353,y:490,t:1528139590470};\\\", \\\"{x:358,y:501,t:1528139590488};\\\", \\\"{x:363,y:511,t:1528139590503};\\\", \\\"{x:369,y:520,t:1528139590519};\\\", \\\"{x:373,y:530,t:1528139590537};\\\", \\\"{x:379,y:542,t:1528139590554};\\\", \\\"{x:385,y:554,t:1528139590569};\\\", \\\"{x:390,y:561,t:1528139590586};\\\", \\\"{x:393,y:565,t:1528139590603};\\\", \\\"{x:394,y:567,t:1528139590620};\\\", \\\"{x:395,y:567,t:1528139590637};\\\", \\\"{x:395,y:568,t:1528139590862};\\\", \\\"{x:395,y:569,t:1528139590871};\\\", \\\"{x:396,y:570,t:1528139590894};\\\", \\\"{x:397,y:570,t:1528139591005};\\\", \\\"{x:398,y:570,t:1528139591461};\\\", \\\"{x:398,y:570,t:1528139591519};\\\", \\\"{x:398,y:569,t:1528139592254};\\\", \\\"{x:398,y:567,t:1528139592271};\\\", \\\"{x:398,y:565,t:1528139592290};\\\", \\\"{x:398,y:559,t:1528139592304};\\\", \\\"{x:397,y:559,t:1528139592321};\\\", \\\"{x:396,y:559,t:1528139592573};\\\", \\\"{x:395,y:559,t:1528139592589};\\\", \\\"{x:394,y:559,t:1528139592606};\\\", \\\"{x:392,y:559,t:1528139592622};\\\", \\\"{x:391,y:559,t:1528139592639};\\\", \\\"{x:400,y:559,t:1528139593398};\\\", \\\"{x:406,y:563,t:1528139593405};\\\", \\\"{x:436,y:578,t:1528139593423};\\\", \\\"{x:506,y:605,t:1528139593441};\\\", \\\"{x:582,y:629,t:1528139593456};\\\", \\\"{x:661,y:648,t:1528139593472};\\\", \\\"{x:761,y:674,t:1528139593489};\\\", \\\"{x:865,y:698,t:1528139593505};\\\", \\\"{x:953,y:731,t:1528139593522};\\\", \\\"{x:1031,y:759,t:1528139593539};\\\", \\\"{x:1113,y:787,t:1528139593555};\\\", \\\"{x:1225,y:824,t:1528139593572};\\\", \\\"{x:1321,y:848,t:1528139593590};\\\", \\\"{x:1426,y:878,t:1528139593606};\\\", \\\"{x:1515,y:903,t:1528139593622};\\\", \\\"{x:1587,y:923,t:1528139593640};\\\", \\\"{x:1659,y:943,t:1528139593657};\\\", \\\"{x:1690,y:957,t:1528139593673};\\\", \\\"{x:1704,y:961,t:1528139593689};\\\", \\\"{x:1708,y:962,t:1528139593706};\\\", \\\"{x:1709,y:962,t:1528139593723};\\\", \\\"{x:1705,y:962,t:1528139593798};\\\", \\\"{x:1699,y:959,t:1528139593807};\\\", \\\"{x:1682,y:948,t:1528139593823};\\\", \\\"{x:1633,y:931,t:1528139593840};\\\", \\\"{x:1564,y:904,t:1528139593857};\\\", \\\"{x:1502,y:881,t:1528139593874};\\\", \\\"{x:1430,y:863,t:1528139593890};\\\", \\\"{x:1377,y:845,t:1528139593906};\\\", \\\"{x:1346,y:833,t:1528139593923};\\\", \\\"{x:1334,y:827,t:1528139593939};\\\", \\\"{x:1333,y:827,t:1528139593956};\\\", \\\"{x:1332,y:827,t:1528139594053};\\\", \\\"{x:1331,y:827,t:1528139594117};\\\", \\\"{x:1330,y:827,t:1528139594125};\\\", \\\"{x:1329,y:827,t:1528139594140};\\\", \\\"{x:1325,y:828,t:1528139594157};\\\", \\\"{x:1322,y:828,t:1528139594174};\\\", \\\"{x:1315,y:828,t:1528139594190};\\\", \\\"{x:1307,y:828,t:1528139594206};\\\", \\\"{x:1301,y:828,t:1528139594224};\\\", \\\"{x:1293,y:824,t:1528139594240};\\\", \\\"{x:1283,y:823,t:1528139594256};\\\", \\\"{x:1276,y:822,t:1528139594273};\\\", \\\"{x:1273,y:822,t:1528139594291};\\\", \\\"{x:1272,y:822,t:1528139594307};\\\", \\\"{x:1270,y:822,t:1528139594469};\\\", \\\"{x:1272,y:822,t:1528139594605};\\\", \\\"{x:1273,y:822,t:1528139594742};\\\", \\\"{x:1276,y:823,t:1528139594757};\\\", \\\"{x:1277,y:823,t:1528139594774};\\\", \\\"{x:1278,y:823,t:1528139594829};\\\", \\\"{x:1279,y:823,t:1528139594887};\\\", \\\"{x:1279,y:824,t:1528139594998};\\\", \\\"{x:1279,y:825,t:1528139595110};\\\", \\\"{x:1279,y:826,t:1528139595189};\\\", \\\"{x:1278,y:827,t:1528139595220};\\\", \\\"{x:1276,y:830,t:1528139602373};\\\", \\\"{x:1276,y:831,t:1528139602389};\\\", \\\"{x:1275,y:832,t:1528139602400};\\\", \\\"{x:1275,y:833,t:1528139602468};\\\", \\\"{x:1275,y:834,t:1528139602500};\\\", \\\"{x:1275,y:835,t:1528139602512};\\\", \\\"{x:1275,y:836,t:1528139602529};\\\", \\\"{x:1274,y:836,t:1528139602546};\\\", \\\"{x:1273,y:840,t:1528139602563};\\\", \\\"{x:1272,y:840,t:1528139602580};\\\", \\\"{x:1272,y:843,t:1528139602597};\\\", \\\"{x:1271,y:846,t:1528139602613};\\\", \\\"{x:1271,y:847,t:1528139602630};\\\", \\\"{x:1269,y:850,t:1528139602647};\\\", \\\"{x:1269,y:851,t:1528139602669};\\\", \\\"{x:1269,y:852,t:1528139602680};\\\", \\\"{x:1269,y:853,t:1528139602697};\\\", \\\"{x:1268,y:857,t:1528139602713};\\\", \\\"{x:1268,y:860,t:1528139602729};\\\", \\\"{x:1267,y:866,t:1528139602746};\\\", \\\"{x:1267,y:868,t:1528139602763};\\\", \\\"{x:1266,y:870,t:1528139602780};\\\", \\\"{x:1266,y:873,t:1528139602797};\\\", \\\"{x:1265,y:877,t:1528139602814};\\\", \\\"{x:1265,y:880,t:1528139602829};\\\", \\\"{x:1265,y:882,t:1528139602847};\\\", \\\"{x:1263,y:881,t:1528139603078};\\\", \\\"{x:1262,y:880,t:1528139603086};\\\", \\\"{x:1260,y:878,t:1528139603097};\\\", \\\"{x:1258,y:876,t:1528139603114};\\\", \\\"{x:1257,y:874,t:1528139603130};\\\", \\\"{x:1255,y:872,t:1528139603147};\\\", \\\"{x:1255,y:870,t:1528139603164};\\\", \\\"{x:1254,y:869,t:1528139603180};\\\", \\\"{x:1252,y:869,t:1528139603197};\\\", \\\"{x:1251,y:867,t:1528139603214};\\\", \\\"{x:1249,y:866,t:1528139603231};\\\", \\\"{x:1246,y:863,t:1528139603248};\\\", \\\"{x:1240,y:860,t:1528139603264};\\\", \\\"{x:1233,y:854,t:1528139603281};\\\", \\\"{x:1230,y:852,t:1528139603297};\\\", \\\"{x:1227,y:850,t:1528139603315};\\\", \\\"{x:1226,y:849,t:1528139603331};\\\", \\\"{x:1225,y:847,t:1528139603347};\\\", \\\"{x:1223,y:847,t:1528139603364};\\\", \\\"{x:1221,y:845,t:1528139603381};\\\", \\\"{x:1220,y:845,t:1528139603397};\\\", \\\"{x:1218,y:843,t:1528139603414};\\\", \\\"{x:1217,y:841,t:1528139603431};\\\", \\\"{x:1213,y:839,t:1528139603447};\\\", \\\"{x:1212,y:838,t:1528139603590};\\\", \\\"{x:1211,y:837,t:1528139603598};\\\", \\\"{x:1210,y:835,t:1528139603615};\\\", \\\"{x:1209,y:835,t:1528139603637};\\\", \\\"{x:1209,y:834,t:1528139603710};\\\", \\\"{x:1209,y:833,t:1528139603853};\\\", \\\"{x:1209,y:831,t:1528139603990};\\\", \\\"{x:1210,y:830,t:1528139604157};\\\", \\\"{x:1210,y:829,t:1528139604180};\\\", \\\"{x:1212,y:829,t:1528139606838};\\\", \\\"{x:1217,y:826,t:1528139606850};\\\", \\\"{x:1246,y:821,t:1528139606870};\\\", \\\"{x:1273,y:820,t:1528139606882};\\\", \\\"{x:1291,y:820,t:1528139606899};\\\", \\\"{x:1301,y:820,t:1528139606916};\\\", \\\"{x:1302,y:820,t:1528139607142};\\\", \\\"{x:1302,y:822,t:1528139607157};\\\", \\\"{x:1302,y:823,t:1528139607168};\\\", \\\"{x:1301,y:826,t:1528139607185};\\\", \\\"{x:1297,y:829,t:1528139607200};\\\", \\\"{x:1295,y:830,t:1528139607218};\\\", \\\"{x:1295,y:831,t:1528139607235};\\\", \\\"{x:1294,y:831,t:1528139607277};\\\", \\\"{x:1293,y:831,t:1528139607342};\\\", \\\"{x:1292,y:831,t:1528139607397};\\\", \\\"{x:1291,y:831,t:1528139607429};\\\", \\\"{x:1289,y:831,t:1528139607518};\\\", \\\"{x:1287,y:831,t:1528139607534};\\\", \\\"{x:1285,y:831,t:1528139607556};\\\", \\\"{x:1281,y:832,t:1528139607567};\\\", \\\"{x:1277,y:834,t:1528139607583};\\\", \\\"{x:1277,y:835,t:1528139608412};\\\", \\\"{x:1278,y:835,t:1528139608436};\\\", \\\"{x:1279,y:835,t:1528139608510};\\\", \\\"{x:1280,y:834,t:1528139608580};\\\", \\\"{x:1281,y:832,t:1528139608620};\\\", \\\"{x:1281,y:831,t:1528139608643};\\\", \\\"{x:1282,y:830,t:1528139608660};\\\", \\\"{x:1282,y:829,t:1528139608685};\\\", \\\"{x:1283,y:828,t:1528139615245};\\\", \\\"{x:1283,y:824,t:1528139615259};\\\", \\\"{x:1285,y:809,t:1528139615273};\\\", \\\"{x:1295,y:786,t:1528139615290};\\\", \\\"{x:1305,y:769,t:1528139615307};\\\", \\\"{x:1308,y:751,t:1528139615323};\\\", \\\"{x:1311,y:736,t:1528139615340};\\\", \\\"{x:1312,y:730,t:1528139615357};\\\", \\\"{x:1315,y:720,t:1528139615373};\\\", \\\"{x:1315,y:710,t:1528139615390};\\\", \\\"{x:1319,y:702,t:1528139615407};\\\", \\\"{x:1319,y:698,t:1528139615423};\\\", \\\"{x:1323,y:688,t:1528139615440};\\\", \\\"{x:1323,y:681,t:1528139615457};\\\", \\\"{x:1324,y:675,t:1528139615473};\\\", \\\"{x:1325,y:672,t:1528139615490};\\\", \\\"{x:1326,y:668,t:1528139615507};\\\", \\\"{x:1326,y:663,t:1528139615523};\\\", \\\"{x:1326,y:659,t:1528139615540};\\\", \\\"{x:1325,y:657,t:1528139615558};\\\", \\\"{x:1325,y:655,t:1528139615573};\\\", \\\"{x:1325,y:653,t:1528139615590};\\\", \\\"{x:1325,y:652,t:1528139615607};\\\", \\\"{x:1325,y:650,t:1528139615624};\\\", \\\"{x:1325,y:646,t:1528139615640};\\\", \\\"{x:1325,y:643,t:1528139615657};\\\", \\\"{x:1323,y:637,t:1528139615674};\\\", \\\"{x:1322,y:630,t:1528139615690};\\\", \\\"{x:1321,y:627,t:1528139615707};\\\", \\\"{x:1320,y:622,t:1528139615723};\\\", \\\"{x:1319,y:618,t:1528139615740};\\\", \\\"{x:1319,y:617,t:1528139615757};\\\", \\\"{x:1319,y:616,t:1528139615774};\\\", \\\"{x:1318,y:616,t:1528139615790};\\\", \\\"{x:1318,y:615,t:1528139615807};\\\", \\\"{x:1317,y:615,t:1528139615918};\\\", \\\"{x:1316,y:615,t:1528139615949};\\\", \\\"{x:1315,y:616,t:1528139615964};\\\", \\\"{x:1314,y:617,t:1528139615980};\\\", \\\"{x:1313,y:618,t:1528139615991};\\\", \\\"{x:1313,y:622,t:1528139616007};\\\", \\\"{x:1310,y:625,t:1528139616025};\\\", \\\"{x:1310,y:629,t:1528139616045};\\\", \\\"{x:1309,y:630,t:1528139616057};\\\", \\\"{x:1309,y:632,t:1528139616073};\\\", \\\"{x:1308,y:633,t:1528139616092};\\\", \\\"{x:1307,y:634,t:1528139616107};\\\", \\\"{x:1307,y:636,t:1528139616124};\\\", \\\"{x:1306,y:636,t:1528139616236};\\\", \\\"{x:1307,y:635,t:1528139616484};\\\", \\\"{x:1308,y:635,t:1528139617022};\\\", \\\"{x:1312,y:637,t:1528139617037};\\\", \\\"{x:1312,y:640,t:1528139617045};\\\", \\\"{x:1316,y:645,t:1528139617059};\\\", \\\"{x:1317,y:652,t:1528139617075};\\\", \\\"{x:1320,y:657,t:1528139617091};\\\", \\\"{x:1321,y:668,t:1528139617107};\\\", \\\"{x:1324,y:673,t:1528139617125};\\\", \\\"{x:1328,y:678,t:1528139617141};\\\", \\\"{x:1331,y:685,t:1528139617158};\\\", \\\"{x:1334,y:693,t:1528139617175};\\\", \\\"{x:1338,y:705,t:1528139617191};\\\", \\\"{x:1343,y:720,t:1528139617208};\\\", \\\"{x:1348,y:736,t:1528139617225};\\\", \\\"{x:1350,y:745,t:1528139617241};\\\", \\\"{x:1352,y:755,t:1528139617258};\\\", \\\"{x:1352,y:766,t:1528139617275};\\\", \\\"{x:1353,y:772,t:1528139617292};\\\", \\\"{x:1352,y:784,t:1528139617307};\\\", \\\"{x:1353,y:792,t:1528139617325};\\\", \\\"{x:1356,y:804,t:1528139617342};\\\", \\\"{x:1359,y:813,t:1528139617358};\\\", \\\"{x:1360,y:815,t:1528139617375};\\\", \\\"{x:1361,y:816,t:1528139617404};\\\", \\\"{x:1362,y:816,t:1528139617469};\\\", \\\"{x:1364,y:816,t:1528139617476};\\\", \\\"{x:1368,y:812,t:1528139617492};\\\", \\\"{x:1372,y:807,t:1528139617508};\\\", \\\"{x:1374,y:805,t:1528139617525};\\\", \\\"{x:1376,y:802,t:1528139617542};\\\", \\\"{x:1377,y:799,t:1528139617558};\\\", \\\"{x:1377,y:797,t:1528139617575};\\\", \\\"{x:1378,y:796,t:1528139617593};\\\", \\\"{x:1378,y:795,t:1528139617609};\\\", \\\"{x:1378,y:794,t:1528139617625};\\\", \\\"{x:1379,y:793,t:1528139617642};\\\", \\\"{x:1379,y:792,t:1528139617676};\\\", \\\"{x:1380,y:789,t:1528139617693};\\\", \\\"{x:1380,y:786,t:1528139617709};\\\", \\\"{x:1380,y:782,t:1528139617726};\\\", \\\"{x:1383,y:778,t:1528139617743};\\\", \\\"{x:1383,y:774,t:1528139617759};\\\", \\\"{x:1383,y:772,t:1528139617776};\\\", \\\"{x:1383,y:771,t:1528139617793};\\\", \\\"{x:1383,y:769,t:1528139617810};\\\", \\\"{x:1384,y:767,t:1528139618122};\\\", \\\"{x:1384,y:763,t:1528139618142};\\\", \\\"{x:1384,y:762,t:1528139618159};\\\", \\\"{x:1384,y:760,t:1528139618176};\\\", \\\"{x:1384,y:759,t:1528139618192};\\\", \\\"{x:1384,y:758,t:1528139618429};\\\", \\\"{x:1383,y:758,t:1528139625493};\\\", \\\"{x:1372,y:760,t:1528139625503};\\\", \\\"{x:1330,y:762,t:1528139625516};\\\", \\\"{x:1250,y:756,t:1528139625532};\\\", \\\"{x:1142,y:740,t:1528139625548};\\\", \\\"{x:1015,y:709,t:1528139625564};\\\", \\\"{x:853,y:673,t:1528139625581};\\\", \\\"{x:686,y:640,t:1528139625598};\\\", \\\"{x:535,y:605,t:1528139625615};\\\", \\\"{x:426,y:563,t:1528139625632};\\\", \\\"{x:336,y:532,t:1528139625649};\\\", \\\"{x:289,y:515,t:1528139625665};\\\", \\\"{x:277,y:513,t:1528139625681};\\\", \\\"{x:276,y:513,t:1528139625698};\\\", \\\"{x:276,y:514,t:1528139625764};\\\", \\\"{x:277,y:516,t:1528139625780};\\\", \\\"{x:278,y:518,t:1528139625788};\\\", \\\"{x:280,y:520,t:1528139625804};\\\", \\\"{x:282,y:521,t:1528139625816};\\\", \\\"{x:290,y:526,t:1528139625833};\\\", \\\"{x:303,y:531,t:1528139625848};\\\", \\\"{x:309,y:531,t:1528139625866};\\\", \\\"{x:325,y:536,t:1528139625882};\\\", \\\"{x:341,y:540,t:1528139625899};\\\", \\\"{x:359,y:546,t:1528139625918};\\\", \\\"{x:378,y:552,t:1528139625932};\\\", \\\"{x:385,y:553,t:1528139625948};\\\", \\\"{x:388,y:553,t:1528139625965};\\\", \\\"{x:390,y:555,t:1528139625983};\\\", \\\"{x:391,y:556,t:1528139625998};\\\", \\\"{x:392,y:556,t:1528139626015};\\\", \\\"{x:393,y:556,t:1528139626060};\\\", \\\"{x:396,y:557,t:1528139626068};\\\", \\\"{x:397,y:557,t:1528139626156};\\\", \\\"{x:398,y:557,t:1528139626245};\\\", \\\"{x:399,y:557,t:1528139626252};\\\", \\\"{x:401,y:557,t:1528139626284};\\\", \\\"{x:402,y:557,t:1528139626373};\\\", \\\"{x:399,y:557,t:1528139626971};\\\", \\\"{x:396,y:557,t:1528139626983};\\\", \\\"{x:392,y:557,t:1528139627000};\\\", \\\"{x:388,y:557,t:1528139627016};\\\", \\\"{x:385,y:557,t:1528139627033};\\\", \\\"{x:384,y:557,t:1528139627050};\\\", \\\"{x:383,y:557,t:1528139627132};\\\", \\\"{x:382,y:557,t:1528139627140};\\\", \\\"{x:385,y:557,t:1528139627765};\\\", \\\"{x:404,y:557,t:1528139627780};\\\", \\\"{x:472,y:578,t:1528139627798};\\\", \\\"{x:495,y:585,t:1528139627814};\\\", \\\"{x:519,y:593,t:1528139627830};\\\", \\\"{x:534,y:599,t:1528139627850};\\\", \\\"{x:545,y:600,t:1528139627866};\\\", \\\"{x:550,y:602,t:1528139627884};\\\", \\\"{x:551,y:602,t:1528139627972};\\\", \\\"{x:553,y:602,t:1528139627983};\\\", \\\"{x:557,y:602,t:1528139628000};\\\", \\\"{x:559,y:604,t:1528139628017};\\\", \\\"{x:562,y:604,t:1528139628034};\\\", \\\"{x:567,y:607,t:1528139628050};\\\", \\\"{x:572,y:607,t:1528139628068};\\\", \\\"{x:575,y:607,t:1528139628084};\\\", \\\"{x:576,y:607,t:1528139628100};\\\", \\\"{x:576,y:609,t:1528139628181};\\\", \\\"{x:576,y:612,t:1528139628190};\\\", \\\"{x:578,y:614,t:1528139628201};\\\", \\\"{x:577,y:621,t:1528139628218};\\\", \\\"{x:573,y:626,t:1528139628233};\\\", \\\"{x:568,y:630,t:1528139628250};\\\", \\\"{x:552,y:635,t:1528139628267};\\\", \\\"{x:548,y:638,t:1528139628284};\\\", \\\"{x:538,y:638,t:1528139628300};\\\", \\\"{x:524,y:642,t:1528139628317};\\\", \\\"{x:509,y:642,t:1528139628333};\\\", \\\"{x:490,y:642,t:1528139628351};\\\", \\\"{x:469,y:642,t:1528139628367};\\\", \\\"{x:454,y:641,t:1528139628383};\\\", \\\"{x:440,y:640,t:1528139628401};\\\", \\\"{x:436,y:640,t:1528139628417};\\\", \\\"{x:427,y:637,t:1528139628434};\\\", \\\"{x:420,y:636,t:1528139628450};\\\", \\\"{x:407,y:632,t:1528139628467};\\\", \\\"{x:396,y:627,t:1528139628483};\\\", \\\"{x:383,y:623,t:1528139628500};\\\", \\\"{x:373,y:619,t:1528139628518};\\\", \\\"{x:370,y:616,t:1528139628534};\\\", \\\"{x:367,y:615,t:1528139628552};\\\", \\\"{x:366,y:611,t:1528139628568};\\\", \\\"{x:364,y:609,t:1528139628584};\\\", \\\"{x:362,y:606,t:1528139628600};\\\", \\\"{x:360,y:601,t:1528139628617};\\\", \\\"{x:359,y:599,t:1528139628634};\\\", \\\"{x:359,y:598,t:1528139628659};\\\", \\\"{x:359,y:597,t:1528139628691};\\\", \\\"{x:359,y:596,t:1528139628708};\\\", \\\"{x:360,y:594,t:1528139628717};\\\", \\\"{x:365,y:593,t:1528139628734};\\\", \\\"{x:369,y:590,t:1528139628750};\\\", \\\"{x:372,y:590,t:1528139628772};\\\", \\\"{x:376,y:590,t:1528139628785};\\\", \\\"{x:383,y:590,t:1528139628800};\\\", \\\"{x:387,y:590,t:1528139628818};\\\", \\\"{x:389,y:590,t:1528139628835};\\\", \\\"{x:390,y:590,t:1528139628851};\\\", \\\"{x:393,y:592,t:1528139629309};\\\", \\\"{x:401,y:603,t:1528139629319};\\\", \\\"{x:414,y:624,t:1528139629336};\\\", \\\"{x:431,y:643,t:1528139629351};\\\", \\\"{x:452,y:664,t:1528139629369};\\\", \\\"{x:471,y:682,t:1528139629384};\\\", \\\"{x:491,y:699,t:1528139629402};\\\", \\\"{x:508,y:711,t:1528139629418};\\\", \\\"{x:513,y:716,t:1528139629434};\\\", \\\"{x:515,y:716,t:1528139629451};\\\", \\\"{x:516,y:716,t:1528139629483};\\\", \\\"{x:516,y:718,t:1528139629596};\\\", \\\"{x:516,y:720,t:1528139629612};\\\", \\\"{x:516,y:721,t:1528139629620};\\\", \\\"{x:516,y:724,t:1528139629635};\\\", \\\"{x:517,y:733,t:1528139629651};\\\", \\\"{x:518,y:737,t:1528139629670};\\\", \\\"{x:521,y:745,t:1528139629686};\\\", \\\"{x:521,y:747,t:1528139629702};\\\", \\\"{x:521,y:748,t:1528139629962};\\\", \\\"{x:521,y:753,t:1528139630204};\\\", \\\"{x:521,y:760,t:1528139630219};\\\", \\\"{x:518,y:780,t:1528139630235};\\\", \\\"{x:518,y:802,t:1528139630252};\\\", \\\"{x:518,y:813,t:1528139630269};\\\", \\\"{x:518,y:824,t:1528139630286};\\\", \\\"{x:520,y:832,t:1528139630301};\\\", \\\"{x:520,y:841,t:1528139630318};\\\", \\\"{x:520,y:848,t:1528139630335};\\\", \\\"{x:521,y:856,t:1528139630353};\\\", \\\"{x:521,y:864,t:1528139630369};\\\", \\\"{x:521,y:870,t:1528139630385};\\\", \\\"{x:521,y:872,t:1528139630402};\\\", \\\"{x:521,y:874,t:1528139630419};\\\", \\\"{x:522,y:878,t:1528139630436};\\\", \\\"{x:522,y:883,t:1528139630452};\\\", \\\"{x:524,y:890,t:1528139630469};\\\", \\\"{x:524,y:893,t:1528139630485};\\\" ] }, { \\\"rt\\\": 40666, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 505917, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -D -K -K -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:891,t:1528139631931};\\\", \\\"{x:524,y:887,t:1528139631940};\\\", \\\"{x:523,y:884,t:1528139631953};\\\", \\\"{x:523,y:878,t:1528139631969};\\\", \\\"{x:522,y:874,t:1528139631986};\\\", \\\"{x:521,y:873,t:1528139632012};\\\", \\\"{x:521,y:872,t:1528139632060};\\\", \\\"{x:521,y:871,t:1528139632070};\\\", \\\"{x:521,y:868,t:1528139632086};\\\", \\\"{x:521,y:865,t:1528139632103};\\\", \\\"{x:521,y:863,t:1528139632120};\\\", \\\"{x:522,y:860,t:1528139632137};\\\", \\\"{x:522,y:859,t:1528139632164};\\\", \\\"{x:522,y:858,t:1528139632196};\\\", \\\"{x:522,y:857,t:1528139632228};\\\", \\\"{x:522,y:855,t:1528139632244};\\\", \\\"{x:522,y:854,t:1528139632260};\\\", \\\"{x:522,y:853,t:1528139632324};\\\", \\\"{x:524,y:852,t:1528139632336};\\\", \\\"{x:525,y:852,t:1528139632354};\\\", \\\"{x:528,y:850,t:1528139632371};\\\", \\\"{x:530,y:850,t:1528139632386};\\\", \\\"{x:535,y:847,t:1528139632404};\\\", \\\"{x:538,y:846,t:1528139632420};\\\", \\\"{x:545,y:846,t:1528139632437};\\\", \\\"{x:553,y:846,t:1528139632454};\\\", \\\"{x:560,y:846,t:1528139632471};\\\", \\\"{x:567,y:844,t:1528139632487};\\\", \\\"{x:576,y:842,t:1528139632504};\\\", \\\"{x:584,y:842,t:1528139632521};\\\", \\\"{x:594,y:839,t:1528139632538};\\\", \\\"{x:601,y:835,t:1528139632554};\\\", \\\"{x:604,y:833,t:1528139632571};\\\", \\\"{x:613,y:830,t:1528139632588};\\\", \\\"{x:618,y:828,t:1528139632604};\\\", \\\"{x:622,y:827,t:1528139632621};\\\", \\\"{x:628,y:824,t:1528139632638};\\\", \\\"{x:635,y:820,t:1528139632654};\\\", \\\"{x:642,y:817,t:1528139632670};\\\", \\\"{x:647,y:815,t:1528139632687};\\\", \\\"{x:657,y:810,t:1528139632703};\\\", \\\"{x:666,y:804,t:1528139632721};\\\", \\\"{x:676,y:798,t:1528139632737};\\\", \\\"{x:687,y:792,t:1528139632754};\\\", \\\"{x:695,y:787,t:1528139632771};\\\", \\\"{x:701,y:783,t:1528139632788};\\\", \\\"{x:702,y:783,t:1528139632869};\\\", \\\"{x:703,y:782,t:1528139632876};\\\", \\\"{x:706,y:782,t:1528139632888};\\\", \\\"{x:709,y:782,t:1528139632904};\\\", \\\"{x:710,y:780,t:1528139632920};\\\", \\\"{x:712,y:779,t:1528139632938};\\\", \\\"{x:714,y:777,t:1528139632954};\\\", \\\"{x:715,y:776,t:1528139632971};\\\", \\\"{x:717,y:775,t:1528139632988};\\\", \\\"{x:719,y:774,t:1528139633004};\\\", \\\"{x:720,y:774,t:1528139633021};\\\", \\\"{x:722,y:773,t:1528139633038};\\\", \\\"{x:724,y:772,t:1528139633055};\\\", \\\"{x:726,y:770,t:1528139633071};\\\", \\\"{x:729,y:769,t:1528139633088};\\\", \\\"{x:735,y:767,t:1528139633105};\\\", \\\"{x:748,y:764,t:1528139633120};\\\", \\\"{x:765,y:760,t:1528139633138};\\\", \\\"{x:782,y:754,t:1528139633155};\\\", \\\"{x:795,y:751,t:1528139633171};\\\", \\\"{x:798,y:750,t:1528139633188};\\\", \\\"{x:799,y:749,t:1528139633244};\\\", \\\"{x:801,y:749,t:1528139634163};\\\", \\\"{x:811,y:745,t:1528139634171};\\\", \\\"{x:831,y:734,t:1528139634188};\\\", \\\"{x:872,y:720,t:1528139634205};\\\", \\\"{x:928,y:705,t:1528139634222};\\\", \\\"{x:986,y:691,t:1528139634238};\\\", \\\"{x:1050,y:673,t:1528139634254};\\\", \\\"{x:1105,y:657,t:1528139634271};\\\", \\\"{x:1152,y:646,t:1528139634288};\\\", \\\"{x:1189,y:634,t:1528139634305};\\\", \\\"{x:1219,y:628,t:1528139634322};\\\", \\\"{x:1252,y:615,t:1528139634339};\\\", \\\"{x:1271,y:604,t:1528139634355};\\\", \\\"{x:1297,y:598,t:1528139634372};\\\", \\\"{x:1313,y:593,t:1528139634389};\\\", \\\"{x:1326,y:590,t:1528139634406};\\\", \\\"{x:1338,y:585,t:1528139634422};\\\", \\\"{x:1344,y:584,t:1528139634439};\\\", \\\"{x:1353,y:579,t:1528139634455};\\\", \\\"{x:1364,y:577,t:1528139634472};\\\", \\\"{x:1366,y:576,t:1528139634489};\\\", \\\"{x:1370,y:574,t:1528139634506};\\\", \\\"{x:1375,y:573,t:1528139634522};\\\", \\\"{x:1378,y:573,t:1528139634539};\\\", \\\"{x:1390,y:568,t:1528139634556};\\\", \\\"{x:1396,y:565,t:1528139634573};\\\", \\\"{x:1398,y:564,t:1528139634589};\\\", \\\"{x:1400,y:562,t:1528139634606};\\\", \\\"{x:1402,y:561,t:1528139634622};\\\", \\\"{x:1405,y:558,t:1528139634639};\\\", \\\"{x:1407,y:556,t:1528139634656};\\\", \\\"{x:1410,y:551,t:1528139634673};\\\", \\\"{x:1411,y:550,t:1528139634689};\\\", \\\"{x:1411,y:549,t:1528139634706};\\\", \\\"{x:1411,y:548,t:1528139634723};\\\", \\\"{x:1411,y:551,t:1528139634804};\\\", \\\"{x:1407,y:557,t:1528139634813};\\\", \\\"{x:1402,y:562,t:1528139634823};\\\", \\\"{x:1399,y:570,t:1528139634839};\\\", \\\"{x:1394,y:577,t:1528139634856};\\\", \\\"{x:1390,y:585,t:1528139634872};\\\", \\\"{x:1385,y:595,t:1528139634890};\\\", \\\"{x:1385,y:599,t:1528139634906};\\\", \\\"{x:1385,y:601,t:1528139634923};\\\", \\\"{x:1384,y:609,t:1528139634939};\\\", \\\"{x:1384,y:620,t:1528139634956};\\\", \\\"{x:1384,y:623,t:1528139634972};\\\", \\\"{x:1384,y:628,t:1528139634989};\\\", \\\"{x:1384,y:633,t:1528139635006};\\\", \\\"{x:1384,y:638,t:1528139635023};\\\", \\\"{x:1384,y:644,t:1528139635039};\\\", \\\"{x:1386,y:650,t:1528139635056};\\\", \\\"{x:1387,y:659,t:1528139635072};\\\", \\\"{x:1390,y:664,t:1528139635089};\\\", \\\"{x:1394,y:668,t:1528139635106};\\\", \\\"{x:1397,y:675,t:1528139635123};\\\", \\\"{x:1403,y:682,t:1528139635139};\\\", \\\"{x:1414,y:691,t:1528139635156};\\\", \\\"{x:1419,y:695,t:1528139635172};\\\", \\\"{x:1424,y:700,t:1528139635189};\\\", \\\"{x:1426,y:701,t:1528139635206};\\\", \\\"{x:1429,y:705,t:1528139635223};\\\", \\\"{x:1433,y:708,t:1528139635240};\\\", \\\"{x:1437,y:711,t:1528139635256};\\\", \\\"{x:1441,y:716,t:1528139635273};\\\", \\\"{x:1445,y:720,t:1528139635289};\\\", \\\"{x:1448,y:723,t:1528139635307};\\\", \\\"{x:1454,y:732,t:1528139635323};\\\", \\\"{x:1458,y:741,t:1528139635339};\\\", \\\"{x:1460,y:745,t:1528139635356};\\\", \\\"{x:1462,y:747,t:1528139635373};\\\", \\\"{x:1462,y:752,t:1528139635391};\\\", \\\"{x:1459,y:757,t:1528139635406};\\\", \\\"{x:1457,y:762,t:1528139635424};\\\", \\\"{x:1450,y:769,t:1528139635440};\\\", \\\"{x:1446,y:772,t:1528139635456};\\\", \\\"{x:1443,y:775,t:1528139635473};\\\", \\\"{x:1440,y:776,t:1528139635491};\\\", \\\"{x:1439,y:777,t:1528139635506};\\\", \\\"{x:1438,y:778,t:1528139635523};\\\", \\\"{x:1440,y:777,t:1528139635605};\\\", \\\"{x:1444,y:773,t:1528139635623};\\\", \\\"{x:1450,y:770,t:1528139635641};\\\", \\\"{x:1454,y:768,t:1528139635656};\\\", \\\"{x:1455,y:767,t:1528139635673};\\\", \\\"{x:1456,y:767,t:1528139635690};\\\", \\\"{x:1459,y:764,t:1528139635706};\\\", \\\"{x:1461,y:763,t:1528139635723};\\\", \\\"{x:1462,y:762,t:1528139635740};\\\", \\\"{x:1463,y:762,t:1528139635756};\\\", \\\"{x:1464,y:762,t:1528139635773};\\\", \\\"{x:1465,y:763,t:1528139636517};\\\", \\\"{x:1467,y:767,t:1528139636525};\\\", \\\"{x:1468,y:780,t:1528139636540};\\\", \\\"{x:1469,y:787,t:1528139636557};\\\", \\\"{x:1471,y:791,t:1528139636574};\\\", \\\"{x:1473,y:797,t:1528139636590};\\\", \\\"{x:1474,y:800,t:1528139636607};\\\", \\\"{x:1471,y:795,t:1528139636837};\\\", \\\"{x:1465,y:787,t:1528139636844};\\\", \\\"{x:1461,y:780,t:1528139636858};\\\", \\\"{x:1448,y:761,t:1528139636875};\\\", \\\"{x:1433,y:743,t:1528139636891};\\\", \\\"{x:1420,y:727,t:1528139636907};\\\", \\\"{x:1402,y:707,t:1528139636924};\\\", \\\"{x:1395,y:696,t:1528139636941};\\\", \\\"{x:1387,y:686,t:1528139636958};\\\", \\\"{x:1381,y:674,t:1528139636973};\\\", \\\"{x:1377,y:671,t:1528139636991};\\\", \\\"{x:1375,y:670,t:1528139637007};\\\", \\\"{x:1375,y:669,t:1528139637052};\\\", \\\"{x:1375,y:668,t:1528139637060};\\\", \\\"{x:1375,y:666,t:1528139637085};\\\", \\\"{x:1374,y:666,t:1528139637092};\\\", \\\"{x:1374,y:665,t:1528139637108};\\\", \\\"{x:1374,y:664,t:1528139637140};\\\", \\\"{x:1373,y:661,t:1528139637157};\\\", \\\"{x:1372,y:660,t:1528139637174};\\\", \\\"{x:1371,y:660,t:1528139637204};\\\", \\\"{x:1370,y:659,t:1528139637227};\\\", \\\"{x:1370,y:658,t:1528139637241};\\\", \\\"{x:1369,y:658,t:1528139637564};\\\", \\\"{x:1368,y:658,t:1528139637580};\\\", \\\"{x:1367,y:658,t:1528139637916};\\\", \\\"{x:1365,y:658,t:1528139642237};\\\", \\\"{x:1356,y:658,t:1528139642244};\\\", \\\"{x:1331,y:658,t:1528139642261};\\\", \\\"{x:1304,y:653,t:1528139642279};\\\", \\\"{x:1281,y:646,t:1528139642295};\\\", \\\"{x:1242,y:634,t:1528139642311};\\\", \\\"{x:1200,y:622,t:1528139642329};\\\", \\\"{x:1163,y:612,t:1528139642345};\\\", \\\"{x:1146,y:606,t:1528139642362};\\\", \\\"{x:1138,y:602,t:1528139642378};\\\", \\\"{x:1115,y:595,t:1528139642394};\\\", \\\"{x:1093,y:589,t:1528139642411};\\\", \\\"{x:1063,y:580,t:1528139642428};\\\", \\\"{x:1043,y:573,t:1528139642445};\\\", \\\"{x:1010,y:563,t:1528139642462};\\\", \\\"{x:982,y:553,t:1528139642479};\\\", \\\"{x:916,y:540,t:1528139642495};\\\", \\\"{x:807,y:519,t:1528139642512};\\\", \\\"{x:706,y:493,t:1528139642529};\\\", \\\"{x:625,y:481,t:1528139642545};\\\", \\\"{x:572,y:468,t:1528139642561};\\\", \\\"{x:537,y:459,t:1528139642579};\\\", \\\"{x:515,y:457,t:1528139642595};\\\", \\\"{x:500,y:455,t:1528139642611};\\\", \\\"{x:495,y:455,t:1528139642627};\\\", \\\"{x:494,y:456,t:1528139642645};\\\", \\\"{x:491,y:461,t:1528139642661};\\\", \\\"{x:490,y:466,t:1528139642679};\\\", \\\"{x:488,y:471,t:1528139642695};\\\", \\\"{x:488,y:473,t:1528139642711};\\\", \\\"{x:488,y:474,t:1528139642728};\\\", \\\"{x:488,y:475,t:1528139642748};\\\", \\\"{x:488,y:477,t:1528139642804};\\\", \\\"{x:488,y:478,t:1528139642812};\\\", \\\"{x:489,y:481,t:1528139642828};\\\", \\\"{x:491,y:483,t:1528139642845};\\\", \\\"{x:493,y:485,t:1528139642861};\\\", \\\"{x:497,y:489,t:1528139642878};\\\", \\\"{x:503,y:496,t:1528139642895};\\\", \\\"{x:520,y:506,t:1528139642912};\\\", \\\"{x:543,y:516,t:1528139642929};\\\", \\\"{x:559,y:522,t:1528139642945};\\\", \\\"{x:575,y:527,t:1528139642962};\\\", \\\"{x:591,y:534,t:1528139642978};\\\", \\\"{x:608,y:539,t:1528139642995};\\\", \\\"{x:627,y:543,t:1528139643013};\\\", \\\"{x:637,y:543,t:1528139643028};\\\", \\\"{x:643,y:543,t:1528139643044};\\\", \\\"{x:644,y:543,t:1528139643061};\\\", \\\"{x:646,y:543,t:1528139643079};\\\", \\\"{x:648,y:543,t:1528139643096};\\\", \\\"{x:651,y:541,t:1528139643113};\\\", \\\"{x:657,y:538,t:1528139643128};\\\", \\\"{x:663,y:537,t:1528139643145};\\\", \\\"{x:670,y:534,t:1528139643163};\\\", \\\"{x:675,y:532,t:1528139643178};\\\", \\\"{x:681,y:530,t:1528139643195};\\\", \\\"{x:687,y:527,t:1528139643212};\\\", \\\"{x:688,y:526,t:1528139643229};\\\", \\\"{x:689,y:526,t:1528139643246};\\\", \\\"{x:693,y:523,t:1528139644037};\\\", \\\"{x:698,y:522,t:1528139644046};\\\", \\\"{x:707,y:517,t:1528139644063};\\\", \\\"{x:718,y:512,t:1528139644080};\\\", \\\"{x:732,y:511,t:1528139644096};\\\", \\\"{x:745,y:508,t:1528139644113};\\\", \\\"{x:756,y:508,t:1528139644130};\\\", \\\"{x:765,y:508,t:1528139644147};\\\", \\\"{x:781,y:509,t:1528139644164};\\\", \\\"{x:806,y:519,t:1528139644180};\\\", \\\"{x:817,y:523,t:1528139644197};\\\", \\\"{x:840,y:533,t:1528139644214};\\\", \\\"{x:867,y:545,t:1528139644232};\\\", \\\"{x:893,y:562,t:1528139644247};\\\", \\\"{x:930,y:576,t:1528139644263};\\\", \\\"{x:979,y:597,t:1528139644279};\\\", \\\"{x:1022,y:611,t:1528139644296};\\\", \\\"{x:1074,y:629,t:1528139644313};\\\", \\\"{x:1127,y:647,t:1528139644330};\\\", \\\"{x:1198,y:674,t:1528139644347};\\\", \\\"{x:1247,y:700,t:1528139644363};\\\", \\\"{x:1283,y:726,t:1528139644380};\\\", \\\"{x:1295,y:734,t:1528139644397};\\\", \\\"{x:1303,y:745,t:1528139644413};\\\", \\\"{x:1309,y:753,t:1528139644430};\\\", \\\"{x:1316,y:763,t:1528139644447};\\\", \\\"{x:1323,y:773,t:1528139644463};\\\", \\\"{x:1329,y:784,t:1528139644480};\\\", \\\"{x:1335,y:793,t:1528139644497};\\\", \\\"{x:1341,y:801,t:1528139644514};\\\", \\\"{x:1345,y:807,t:1528139644530};\\\", \\\"{x:1352,y:819,t:1528139644547};\\\", \\\"{x:1362,y:829,t:1528139644563};\\\", \\\"{x:1365,y:833,t:1528139644580};\\\", \\\"{x:1365,y:834,t:1528139644597};\\\", \\\"{x:1365,y:835,t:1528139644724};\\\", \\\"{x:1367,y:835,t:1528139648911};\\\", \\\"{x:1389,y:805,t:1528139648928};\\\", \\\"{x:1430,y:771,t:1528139648944};\\\", \\\"{x:1461,y:742,t:1528139648961};\\\", \\\"{x:1489,y:711,t:1528139648978};\\\", \\\"{x:1507,y:690,t:1528139648994};\\\", \\\"{x:1518,y:674,t:1528139649011};\\\", \\\"{x:1528,y:659,t:1528139649028};\\\", \\\"{x:1539,y:644,t:1528139649044};\\\", \\\"{x:1549,y:629,t:1528139649060};\\\", \\\"{x:1559,y:616,t:1528139649077};\\\", \\\"{x:1570,y:603,t:1528139649093};\\\", \\\"{x:1579,y:596,t:1528139649110};\\\", \\\"{x:1584,y:589,t:1528139649127};\\\", \\\"{x:1589,y:582,t:1528139649144};\\\", \\\"{x:1594,y:576,t:1528139649160};\\\", \\\"{x:1598,y:567,t:1528139649177};\\\", \\\"{x:1601,y:556,t:1528139649194};\\\", \\\"{x:1608,y:541,t:1528139649210};\\\", \\\"{x:1613,y:528,t:1528139649227};\\\", \\\"{x:1618,y:515,t:1528139649244};\\\", \\\"{x:1622,y:501,t:1528139649260};\\\", \\\"{x:1624,y:488,t:1528139649278};\\\", \\\"{x:1626,y:479,t:1528139649293};\\\", \\\"{x:1627,y:475,t:1528139649310};\\\", \\\"{x:1627,y:471,t:1528139649327};\\\", \\\"{x:1628,y:464,t:1528139649344};\\\", \\\"{x:1628,y:460,t:1528139649361};\\\", \\\"{x:1629,y:455,t:1528139649378};\\\", \\\"{x:1629,y:453,t:1528139649394};\\\", \\\"{x:1631,y:447,t:1528139649410};\\\", \\\"{x:1631,y:446,t:1528139649438};\\\", \\\"{x:1631,y:445,t:1528139649487};\\\", \\\"{x:1631,y:444,t:1528139649542};\\\", \\\"{x:1631,y:443,t:1528139649549};\\\", \\\"{x:1631,y:442,t:1528139649561};\\\", \\\"{x:1631,y:441,t:1528139649582};\\\", \\\"{x:1631,y:439,t:1528139649598};\\\", \\\"{x:1631,y:437,t:1528139649613};\\\", \\\"{x:1630,y:435,t:1528139649638};\\\", \\\"{x:1629,y:435,t:1528139649661};\\\", \\\"{x:1629,y:434,t:1528139649678};\\\", \\\"{x:1627,y:433,t:1528139649695};\\\", \\\"{x:1626,y:432,t:1528139649712};\\\", \\\"{x:1624,y:430,t:1528139649728};\\\", \\\"{x:1622,y:429,t:1528139649745};\\\", \\\"{x:1620,y:428,t:1528139649774};\\\", \\\"{x:1615,y:428,t:1528139649793};\\\", \\\"{x:1614,y:428,t:1528139649811};\\\", \\\"{x:1613,y:427,t:1528139649828};\\\", \\\"{x:1612,y:427,t:1528139649853};\\\", \\\"{x:1611,y:427,t:1528139649893};\\\", \\\"{x:1610,y:427,t:1528139649949};\\\", \\\"{x:1609,y:427,t:1528139649962};\\\", \\\"{x:1607,y:427,t:1528139652913};\\\", \\\"{x:1606,y:428,t:1528139652930};\\\", \\\"{x:1604,y:429,t:1528139652965};\\\", \\\"{x:1603,y:430,t:1528139652981};\\\", \\\"{x:1602,y:431,t:1528139652997};\\\", \\\"{x:1600,y:433,t:1528139653013};\\\", \\\"{x:1596,y:437,t:1528139653030};\\\", \\\"{x:1595,y:439,t:1528139653047};\\\", \\\"{x:1593,y:442,t:1528139653063};\\\", \\\"{x:1591,y:444,t:1528139653081};\\\", \\\"{x:1589,y:446,t:1528139653097};\\\", \\\"{x:1586,y:451,t:1528139653113};\\\", \\\"{x:1583,y:454,t:1528139653130};\\\", \\\"{x:1580,y:459,t:1528139653147};\\\", \\\"{x:1577,y:462,t:1528139653163};\\\", \\\"{x:1575,y:468,t:1528139653181};\\\", \\\"{x:1569,y:477,t:1528139653197};\\\", \\\"{x:1563,y:485,t:1528139653213};\\\", \\\"{x:1557,y:496,t:1528139653231};\\\", \\\"{x:1551,y:508,t:1528139653248};\\\", \\\"{x:1546,y:518,t:1528139653264};\\\", \\\"{x:1540,y:529,t:1528139653281};\\\", \\\"{x:1538,y:538,t:1528139653297};\\\", \\\"{x:1532,y:550,t:1528139653314};\\\", \\\"{x:1526,y:568,t:1528139653330};\\\", \\\"{x:1522,y:578,t:1528139653347};\\\", \\\"{x:1516,y:595,t:1528139653364};\\\", \\\"{x:1512,y:605,t:1528139653380};\\\", \\\"{x:1507,y:615,t:1528139653397};\\\", \\\"{x:1506,y:617,t:1528139653415};\\\", \\\"{x:1506,y:618,t:1528139653430};\\\", \\\"{x:1506,y:620,t:1528139653502};\\\", \\\"{x:1506,y:621,t:1528139653526};\\\", \\\"{x:1506,y:622,t:1528139653534};\\\", \\\"{x:1506,y:623,t:1528139653582};\\\", \\\"{x:1508,y:625,t:1528139653598};\\\", \\\"{x:1510,y:628,t:1528139653618};\\\", \\\"{x:1513,y:631,t:1528139653630};\\\", \\\"{x:1516,y:632,t:1528139653652};\\\", \\\"{x:1517,y:632,t:1528139653765};\\\", \\\"{x:1519,y:633,t:1528139653780};\\\", \\\"{x:1520,y:633,t:1528139653845};\\\", \\\"{x:1519,y:633,t:1528139654366};\\\", \\\"{x:1516,y:635,t:1528139658477};\\\", \\\"{x:1507,y:638,t:1528139658485};\\\", \\\"{x:1470,y:653,t:1528139658502};\\\", \\\"{x:1426,y:670,t:1528139658518};\\\", \\\"{x:1343,y:693,t:1528139658534};\\\", \\\"{x:1265,y:717,t:1528139658552};\\\", \\\"{x:1197,y:740,t:1528139658569};\\\", \\\"{x:1139,y:765,t:1528139658585};\\\", \\\"{x:1088,y:785,t:1528139658602};\\\", \\\"{x:1053,y:795,t:1528139658619};\\\", \\\"{x:1039,y:806,t:1528139658634};\\\", \\\"{x:1029,y:813,t:1528139658651};\\\", \\\"{x:1015,y:818,t:1528139658669};\\\", \\\"{x:1001,y:826,t:1528139658685};\\\", \\\"{x:997,y:827,t:1528139658702};\\\", \\\"{x:992,y:828,t:1528139658719};\\\", \\\"{x:989,y:830,t:1528139658736};\\\", \\\"{x:979,y:830,t:1528139658752};\\\", \\\"{x:964,y:827,t:1528139658769};\\\", \\\"{x:939,y:820,t:1528139658786};\\\", \\\"{x:916,y:808,t:1528139658802};\\\", \\\"{x:882,y:784,t:1528139658819};\\\", \\\"{x:814,y:749,t:1528139658835};\\\", \\\"{x:746,y:711,t:1528139658852};\\\", \\\"{x:699,y:678,t:1528139658869};\\\", \\\"{x:640,y:639,t:1528139658886};\\\", \\\"{x:607,y:618,t:1528139658902};\\\", \\\"{x:588,y:607,t:1528139658919};\\\", \\\"{x:572,y:595,t:1528139658935};\\\", \\\"{x:557,y:587,t:1528139658951};\\\", \\\"{x:551,y:581,t:1528139658969};\\\", \\\"{x:549,y:577,t:1528139658986};\\\", \\\"{x:547,y:575,t:1528139659001};\\\", \\\"{x:546,y:574,t:1528139659029};\\\", \\\"{x:546,y:573,t:1528139659037};\\\", \\\"{x:543,y:573,t:1528139659052};\\\", \\\"{x:537,y:571,t:1528139659068};\\\", \\\"{x:520,y:571,t:1528139659086};\\\", \\\"{x:512,y:571,t:1528139659101};\\\", \\\"{x:502,y:573,t:1528139659118};\\\", \\\"{x:494,y:576,t:1528139659135};\\\", \\\"{x:487,y:577,t:1528139659152};\\\", \\\"{x:478,y:579,t:1528139659168};\\\", \\\"{x:471,y:580,t:1528139659186};\\\", \\\"{x:468,y:581,t:1528139659203};\\\", \\\"{x:467,y:581,t:1528139659218};\\\", \\\"{x:462,y:584,t:1528139659235};\\\", \\\"{x:456,y:584,t:1528139659251};\\\", \\\"{x:441,y:587,t:1528139659269};\\\", \\\"{x:426,y:590,t:1528139659285};\\\", \\\"{x:415,y:593,t:1528139659302};\\\", \\\"{x:398,y:598,t:1528139659318};\\\", \\\"{x:394,y:598,t:1528139659336};\\\", \\\"{x:392,y:598,t:1528139659351};\\\", \\\"{x:391,y:599,t:1528139659369};\\\", \\\"{x:390,y:599,t:1528139659413};\\\", \\\"{x:388,y:601,t:1528139659421};\\\", \\\"{x:387,y:602,t:1528139659437};\\\", \\\"{x:382,y:605,t:1528139659453};\\\", \\\"{x:381,y:605,t:1528139659477};\\\", \\\"{x:380,y:605,t:1528139659485};\\\", \\\"{x:379,y:606,t:1528139659501};\\\", \\\"{x:377,y:608,t:1528139659519};\\\", \\\"{x:373,y:610,t:1528139659536};\\\", \\\"{x:368,y:612,t:1528139659553};\\\", \\\"{x:363,y:614,t:1528139659569};\\\", \\\"{x:359,y:616,t:1528139659585};\\\", \\\"{x:358,y:617,t:1528139659603};\\\", \\\"{x:357,y:617,t:1528139659620};\\\", \\\"{x:358,y:619,t:1528139659703};\\\", \\\"{x:364,y:620,t:1528139659720};\\\", \\\"{x:367,y:621,t:1528139659735};\\\", \\\"{x:372,y:623,t:1528139659752};\\\", \\\"{x:373,y:623,t:1528139659769};\\\", \\\"{x:374,y:624,t:1528139659785};\\\", \\\"{x:376,y:624,t:1528139659877};\\\", \\\"{x:377,y:624,t:1528139659909};\\\", \\\"{x:379,y:624,t:1528139660013};\\\", \\\"{x:386,y:622,t:1528139661007};\\\", \\\"{x:400,y:616,t:1528139661020};\\\", \\\"{x:466,y:596,t:1528139661036};\\\", \\\"{x:556,y:594,t:1528139661054};\\\", \\\"{x:664,y:594,t:1528139661070};\\\", \\\"{x:777,y:601,t:1528139661087};\\\", \\\"{x:806,y:607,t:1528139661103};\\\", \\\"{x:809,y:608,t:1528139661121};\\\", \\\"{x:854,y:620,t:1528139661137};\\\", \\\"{x:901,y:624,t:1528139661153};\\\", \\\"{x:959,y:629,t:1528139661171};\\\", \\\"{x:982,y:633,t:1528139661186};\\\", \\\"{x:1003,y:639,t:1528139661203};\\\", \\\"{x:1022,y:644,t:1528139661220};\\\", \\\"{x:1037,y:644,t:1528139661237};\\\", \\\"{x:1044,y:644,t:1528139661254};\\\", \\\"{x:1049,y:644,t:1528139661270};\\\", \\\"{x:1052,y:644,t:1528139661288};\\\", \\\"{x:1056,y:644,t:1528139661304};\\\", \\\"{x:1063,y:642,t:1528139661321};\\\", \\\"{x:1076,y:642,t:1528139661338};\\\", \\\"{x:1096,y:642,t:1528139661354};\\\", \\\"{x:1121,y:642,t:1528139661370};\\\", \\\"{x:1154,y:642,t:1528139661388};\\\", \\\"{x:1183,y:642,t:1528139661403};\\\", \\\"{x:1207,y:646,t:1528139661420};\\\", \\\"{x:1241,y:649,t:1528139661437};\\\", \\\"{x:1268,y:649,t:1528139661454};\\\", \\\"{x:1304,y:649,t:1528139661470};\\\", \\\"{x:1347,y:650,t:1528139661488};\\\", \\\"{x:1373,y:651,t:1528139661503};\\\", \\\"{x:1402,y:653,t:1528139661520};\\\", \\\"{x:1426,y:653,t:1528139661537};\\\", \\\"{x:1451,y:653,t:1528139661553};\\\", \\\"{x:1463,y:653,t:1528139661571};\\\", \\\"{x:1478,y:653,t:1528139661588};\\\", \\\"{x:1493,y:653,t:1528139661604};\\\", \\\"{x:1498,y:653,t:1528139661620};\\\", \\\"{x:1508,y:653,t:1528139661637};\\\", \\\"{x:1511,y:650,t:1528139661654};\\\", \\\"{x:1512,y:650,t:1528139661670};\\\", \\\"{x:1514,y:649,t:1528139661688};\\\", \\\"{x:1514,y:647,t:1528139661705};\\\", \\\"{x:1514,y:646,t:1528139661725};\\\", \\\"{x:1514,y:644,t:1528139661737};\\\", \\\"{x:1516,y:641,t:1528139661755};\\\", \\\"{x:1520,y:641,t:1528139661771};\\\", \\\"{x:1524,y:639,t:1528139661788};\\\", \\\"{x:1534,y:634,t:1528139661805};\\\", \\\"{x:1544,y:632,t:1528139661822};\\\", \\\"{x:1546,y:630,t:1528139661845};\\\", \\\"{x:1548,y:629,t:1528139661855};\\\", \\\"{x:1551,y:627,t:1528139661871};\\\", \\\"{x:1552,y:626,t:1528139661888};\\\", \\\"{x:1553,y:626,t:1528139661904};\\\", \\\"{x:1552,y:626,t:1528139662022};\\\", \\\"{x:1549,y:626,t:1528139662037};\\\", \\\"{x:1546,y:626,t:1528139662055};\\\", \\\"{x:1542,y:628,t:1528139662094};\\\", \\\"{x:1541,y:631,t:1528139662109};\\\", \\\"{x:1540,y:631,t:1528139662121};\\\", \\\"{x:1536,y:633,t:1528139662138};\\\", \\\"{x:1533,y:635,t:1528139662155};\\\", \\\"{x:1530,y:636,t:1528139662173};\\\", \\\"{x:1529,y:636,t:1528139662188};\\\", \\\"{x:1527,y:637,t:1528139662222};\\\", \\\"{x:1526,y:637,t:1528139662245};\\\", \\\"{x:1522,y:638,t:1528139662255};\\\", \\\"{x:1521,y:638,t:1528139662285};\\\", \\\"{x:1518,y:638,t:1528139662294};\\\", \\\"{x:1517,y:638,t:1528139662306};\\\", \\\"{x:1516,y:638,t:1528139662322};\\\", \\\"{x:1514,y:638,t:1528139662338};\\\", \\\"{x:1513,y:638,t:1528139662355};\\\", \\\"{x:1512,y:638,t:1528139662382};\\\", \\\"{x:1510,y:638,t:1528139662390};\\\", \\\"{x:1509,y:638,t:1528139662406};\\\", \\\"{x:1507,y:638,t:1528139662422};\\\", \\\"{x:1506,y:638,t:1528139662438};\\\", \\\"{x:1505,y:637,t:1528139662542};\\\", \\\"{x:1505,y:636,t:1528139662590};\\\", \\\"{x:1505,y:635,t:1528139662630};\\\", \\\"{x:1505,y:634,t:1528139662797};\\\", \\\"{x:1505,y:633,t:1528139662814};\\\", \\\"{x:1505,y:632,t:1528139662927};\\\", \\\"{x:1505,y:631,t:1528139662942};\\\", \\\"{x:1505,y:630,t:1528139662974};\\\", \\\"{x:1505,y:629,t:1528139663014};\\\", \\\"{x:1505,y:628,t:1528139663046};\\\", \\\"{x:1505,y:627,t:1528139663118};\\\", \\\"{x:1505,y:626,t:1528139663150};\\\", \\\"{x:1505,y:625,t:1528139663158};\\\", \\\"{x:1505,y:624,t:1528139663172};\\\", \\\"{x:1506,y:623,t:1528139663189};\\\", \\\"{x:1508,y:621,t:1528139663206};\\\", \\\"{x:1510,y:620,t:1528139663221};\\\", \\\"{x:1512,y:618,t:1528139663238};\\\", \\\"{x:1513,y:617,t:1528139663255};\\\", \\\"{x:1513,y:618,t:1528139663782};\\\", \\\"{x:1513,y:619,t:1528139663814};\\\", \\\"{x:1512,y:620,t:1528139663823};\\\", \\\"{x:1512,y:623,t:1528139663839};\\\", \\\"{x:1512,y:624,t:1528139663856};\\\", \\\"{x:1512,y:627,t:1528139663877};\\\", \\\"{x:1512,y:629,t:1528139663905};\\\", \\\"{x:1510,y:631,t:1528139670238};\\\", \\\"{x:1483,y:637,t:1528139670248};\\\", \\\"{x:1374,y:660,t:1528139670260};\\\", \\\"{x:1257,y:678,t:1528139670276};\\\", \\\"{x:1137,y:699,t:1528139670293};\\\", \\\"{x:1008,y:711,t:1528139670310};\\\", \\\"{x:876,y:722,t:1528139670328};\\\", \\\"{x:723,y:728,t:1528139670344};\\\", \\\"{x:555,y:752,t:1528139670361};\\\", \\\"{x:378,y:775,t:1528139670378};\\\", \\\"{x:249,y:785,t:1528139670394};\\\", \\\"{x:188,y:791,t:1528139670411};\\\", \\\"{x:168,y:798,t:1528139670428};\\\", \\\"{x:168,y:799,t:1528139670509};\\\", \\\"{x:168,y:800,t:1528139670517};\\\", \\\"{x:170,y:802,t:1528139670528};\\\", \\\"{x:171,y:803,t:1528139670545};\\\", \\\"{x:184,y:803,t:1528139670561};\\\", \\\"{x:201,y:803,t:1528139670578};\\\", \\\"{x:236,y:803,t:1528139670595};\\\", \\\"{x:280,y:797,t:1528139670611};\\\", \\\"{x:337,y:787,t:1528139670628};\\\", \\\"{x:465,y:774,t:1528139670645};\\\", \\\"{x:496,y:771,t:1528139670663};\\\", \\\"{x:517,y:769,t:1528139670678};\\\", \\\"{x:530,y:766,t:1528139670695};\\\", \\\"{x:536,y:765,t:1528139670711};\\\", \\\"{x:542,y:762,t:1528139670727};\\\", \\\"{x:547,y:762,t:1528139670745};\\\", \\\"{x:550,y:761,t:1528139670761};\\\", \\\"{x:555,y:761,t:1528139670778};\\\", \\\"{x:563,y:760,t:1528139670794};\\\", \\\"{x:575,y:760,t:1528139670812};\\\", \\\"{x:588,y:760,t:1528139670829};\\\", \\\"{x:599,y:760,t:1528139670845};\\\", \\\"{x:606,y:760,t:1528139670861};\\\", \\\"{x:610,y:760,t:1528139670877};\\\", \\\"{x:612,y:760,t:1528139670895};\\\", \\\"{x:612,y:761,t:1528139670917};\\\", \\\"{x:613,y:761,t:1528139670928};\\\", \\\"{x:617,y:761,t:1528139670945};\\\", \\\"{x:619,y:759,t:1528139670962};\\\", \\\"{x:623,y:757,t:1528139670978};\\\", \\\"{x:624,y:756,t:1528139670995};\\\", \\\"{x:627,y:753,t:1528139671012};\\\", \\\"{x:628,y:752,t:1528139671028};\\\", \\\"{x:629,y:751,t:1528139671045};\\\", \\\"{x:628,y:751,t:1528139671116};\\\", \\\"{x:626,y:751,t:1528139671128};\\\", \\\"{x:623,y:751,t:1528139671144};\\\", \\\"{x:621,y:751,t:1528139671164};\\\", \\\"{x:617,y:751,t:1528139671178};\\\", \\\"{x:615,y:752,t:1528139671195};\\\", \\\"{x:610,y:755,t:1528139671212};\\\", \\\"{x:591,y:755,t:1528139671229};\\\", \\\"{x:572,y:755,t:1528139671245};\\\", \\\"{x:548,y:753,t:1528139671264};\\\", \\\"{x:514,y:744,t:1528139671279};\\\", \\\"{x:497,y:743,t:1528139671295};\\\", \\\"{x:482,y:743,t:1528139671311};\\\", \\\"{x:472,y:742,t:1528139671329};\\\", \\\"{x:468,y:742,t:1528139671344};\\\", \\\"{x:467,y:742,t:1528139671361};\\\", \\\"{x:471,y:742,t:1528139671524};\\\", \\\"{x:474,y:742,t:1528139671533};\\\", \\\"{x:476,y:742,t:1528139671545};\\\", \\\"{x:480,y:743,t:1528139671562};\\\", \\\"{x:484,y:744,t:1528139671579};\\\", \\\"{x:488,y:746,t:1528139671594};\\\", \\\"{x:491,y:746,t:1528139671612};\\\", \\\"{x:492,y:747,t:1528139671628};\\\", \\\"{x:493,y:747,t:1528139671645};\\\", \\\"{x:494,y:747,t:1528139671662};\\\", \\\"{x:494,y:751,t:1528139672390};\\\", \\\"{x:492,y:758,t:1528139672397};\\\", \\\"{x:491,y:760,t:1528139672413};\\\", \\\"{x:487,y:767,t:1528139672429};\\\", \\\"{x:486,y:771,t:1528139672446};\\\" ] }, { \\\"rt\\\": 14160, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 521324, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -C -11 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:778,t:1528139673903};\\\", \\\"{x:482,y:797,t:1528139673914};\\\", \\\"{x:480,y:828,t:1528139673931};\\\", \\\"{x:480,y:860,t:1528139673946};\\\", \\\"{x:492,y:882,t:1528139673964};\\\", \\\"{x:514,y:917,t:1528139673980};\\\", \\\"{x:520,y:931,t:1528139673997};\\\", \\\"{x:530,y:942,t:1528139674014};\\\", \\\"{x:546,y:955,t:1528139674031};\\\", \\\"{x:561,y:965,t:1528139674047};\\\", \\\"{x:562,y:966,t:1528139674064};\\\", \\\"{x:565,y:966,t:1528139674081};\\\", \\\"{x:568,y:968,t:1528139674098};\\\", \\\"{x:570,y:968,t:1528139674113};\\\", \\\"{x:572,y:968,t:1528139674131};\\\", \\\"{x:575,y:966,t:1528139674147};\\\", \\\"{x:576,y:965,t:1528139674165};\\\", \\\"{x:577,y:964,t:1528139674181};\\\", \\\"{x:578,y:963,t:1528139674197};\\\", \\\"{x:578,y:962,t:1528139674214};\\\", \\\"{x:579,y:961,t:1528139674231};\\\", \\\"{x:579,y:960,t:1528139674248};\\\", \\\"{x:580,y:959,t:1528139674264};\\\", \\\"{x:581,y:959,t:1528139674301};\\\", \\\"{x:581,y:957,t:1528139674317};\\\", \\\"{x:581,y:956,t:1528139674331};\\\", \\\"{x:583,y:955,t:1528139674349};\\\", \\\"{x:580,y:957,t:1528139675182};\\\", \\\"{x:586,y:951,t:1528139676421};\\\", \\\"{x:586,y:949,t:1528139676433};\\\", \\\"{x:598,y:941,t:1528139676450};\\\", \\\"{x:617,y:938,t:1528139676466};\\\", \\\"{x:637,y:929,t:1528139676483};\\\", \\\"{x:657,y:922,t:1528139676499};\\\", \\\"{x:733,y:893,t:1528139676518};\\\", \\\"{x:788,y:879,t:1528139676533};\\\", \\\"{x:871,y:858,t:1528139676549};\\\", \\\"{x:943,y:839,t:1528139676566};\\\", \\\"{x:1037,y:823,t:1528139676583};\\\", \\\"{x:1135,y:809,t:1528139676600};\\\", \\\"{x:1221,y:798,t:1528139676616};\\\", \\\"{x:1302,y:783,t:1528139676633};\\\", \\\"{x:1394,y:781,t:1528139676649};\\\", \\\"{x:1454,y:777,t:1528139676666};\\\", \\\"{x:1492,y:777,t:1528139676683};\\\", \\\"{x:1500,y:777,t:1528139676699};\\\", \\\"{x:1502,y:777,t:1528139676725};\\\", \\\"{x:1502,y:779,t:1528139676741};\\\", \\\"{x:1502,y:782,t:1528139676750};\\\", \\\"{x:1502,y:791,t:1528139676767};\\\", \\\"{x:1502,y:807,t:1528139676784};\\\", \\\"{x:1489,y:832,t:1528139676801};\\\", \\\"{x:1474,y:849,t:1528139676817};\\\", \\\"{x:1450,y:867,t:1528139676833};\\\", \\\"{x:1433,y:879,t:1528139676851};\\\", \\\"{x:1420,y:887,t:1528139676866};\\\", \\\"{x:1401,y:892,t:1528139676884};\\\", \\\"{x:1384,y:894,t:1528139676901};\\\", \\\"{x:1374,y:895,t:1528139676916};\\\", \\\"{x:1345,y:895,t:1528139676939};\\\", \\\"{x:1329,y:895,t:1528139676951};\\\", \\\"{x:1312,y:891,t:1528139676966};\\\", \\\"{x:1299,y:890,t:1528139676983};\\\", \\\"{x:1290,y:890,t:1528139677000};\\\", \\\"{x:1289,y:890,t:1528139677060};\\\", \\\"{x:1287,y:890,t:1528139677069};\\\", \\\"{x:1286,y:890,t:1528139677083};\\\", \\\"{x:1283,y:888,t:1528139677100};\\\", \\\"{x:1265,y:885,t:1528139677116};\\\", \\\"{x:1253,y:881,t:1528139677132};\\\", \\\"{x:1240,y:877,t:1528139677150};\\\", \\\"{x:1225,y:872,t:1528139677166};\\\", \\\"{x:1213,y:870,t:1528139677183};\\\", \\\"{x:1207,y:867,t:1528139677200};\\\", \\\"{x:1206,y:866,t:1528139677216};\\\", \\\"{x:1206,y:865,t:1528139677237};\\\", \\\"{x:1206,y:864,t:1528139677250};\\\", \\\"{x:1205,y:864,t:1528139677334};\\\", \\\"{x:1204,y:863,t:1528139677350};\\\", \\\"{x:1203,y:861,t:1528139677367};\\\", \\\"{x:1202,y:858,t:1528139677383};\\\", \\\"{x:1201,y:855,t:1528139677400};\\\", \\\"{x:1201,y:854,t:1528139677417};\\\", \\\"{x:1201,y:852,t:1528139677433};\\\", \\\"{x:1199,y:849,t:1528139677450};\\\", \\\"{x:1200,y:847,t:1528139677467};\\\", \\\"{x:1203,y:843,t:1528139677483};\\\", \\\"{x:1209,y:839,t:1528139677500};\\\", \\\"{x:1211,y:838,t:1528139677517};\\\", \\\"{x:1211,y:837,t:1528139677541};\\\", \\\"{x:1212,y:837,t:1528139677565};\\\", \\\"{x:1212,y:836,t:1528139677581};\\\", \\\"{x:1212,y:835,t:1528139677616};\\\", \\\"{x:1212,y:834,t:1528139677649};\\\", \\\"{x:1213,y:833,t:1528139677684};\\\", \\\"{x:1213,y:832,t:1528139677814};\\\", \\\"{x:1214,y:831,t:1528139679765};\\\", \\\"{x:1218,y:829,t:1528139679773};\\\", \\\"{x:1230,y:829,t:1528139679788};\\\", \\\"{x:1290,y:855,t:1528139679802};\\\", \\\"{x:1359,y:882,t:1528139679819};\\\", \\\"{x:1418,y:914,t:1528139679834};\\\", \\\"{x:1464,y:941,t:1528139679852};\\\", \\\"{x:1508,y:982,t:1528139679868};\\\", \\\"{x:1517,y:999,t:1528139679885};\\\", \\\"{x:1517,y:1004,t:1528139679902};\\\", \\\"{x:1517,y:1009,t:1528139679919};\\\", \\\"{x:1516,y:1012,t:1528139679935};\\\", \\\"{x:1514,y:1013,t:1528139679952};\\\", \\\"{x:1512,y:1014,t:1528139679969};\\\", \\\"{x:1510,y:1015,t:1528139679985};\\\", \\\"{x:1498,y:1015,t:1528139680002};\\\", \\\"{x:1477,y:1013,t:1528139680019};\\\", \\\"{x:1436,y:1007,t:1528139680035};\\\", \\\"{x:1375,y:992,t:1528139680052};\\\", \\\"{x:1330,y:987,t:1528139680068};\\\", \\\"{x:1307,y:981,t:1528139680085};\\\", \\\"{x:1298,y:979,t:1528139680102};\\\", \\\"{x:1297,y:978,t:1528139680119};\\\", \\\"{x:1296,y:977,t:1528139680206};\\\", \\\"{x:1296,y:976,t:1528139680220};\\\", \\\"{x:1296,y:971,t:1528139680236};\\\", \\\"{x:1296,y:966,t:1528139680253};\\\", \\\"{x:1297,y:955,t:1528139680269};\\\", \\\"{x:1298,y:950,t:1528139680286};\\\", \\\"{x:1299,y:946,t:1528139680302};\\\", \\\"{x:1301,y:935,t:1528139680320};\\\", \\\"{x:1308,y:926,t:1528139680335};\\\", \\\"{x:1311,y:918,t:1528139680353};\\\", \\\"{x:1314,y:913,t:1528139680369};\\\", \\\"{x:1314,y:912,t:1528139680389};\\\", \\\"{x:1315,y:912,t:1528139680405};\\\", \\\"{x:1316,y:911,t:1528139680453};\\\", \\\"{x:1318,y:909,t:1528139680469};\\\", \\\"{x:1319,y:907,t:1528139680487};\\\", \\\"{x:1322,y:903,t:1528139680503};\\\", \\\"{x:1324,y:898,t:1528139680519};\\\", \\\"{x:1330,y:890,t:1528139680536};\\\", \\\"{x:1335,y:882,t:1528139680552};\\\", \\\"{x:1339,y:872,t:1528139680570};\\\", \\\"{x:1342,y:866,t:1528139680587};\\\", \\\"{x:1344,y:860,t:1528139680602};\\\", \\\"{x:1347,y:855,t:1528139680620};\\\", \\\"{x:1349,y:852,t:1528139680637};\\\", \\\"{x:1353,y:846,t:1528139680652};\\\", \\\"{x:1358,y:834,t:1528139680669};\\\", \\\"{x:1364,y:825,t:1528139680686};\\\", \\\"{x:1367,y:820,t:1528139680703};\\\", \\\"{x:1372,y:814,t:1528139680719};\\\", \\\"{x:1375,y:808,t:1528139680737};\\\", \\\"{x:1377,y:806,t:1528139680753};\\\", \\\"{x:1379,y:801,t:1528139680769};\\\", \\\"{x:1380,y:798,t:1528139680786};\\\", \\\"{x:1381,y:796,t:1528139680803};\\\", \\\"{x:1381,y:793,t:1528139680820};\\\", \\\"{x:1386,y:788,t:1528139680837};\\\", \\\"{x:1386,y:785,t:1528139680854};\\\", \\\"{x:1389,y:781,t:1528139680869};\\\", \\\"{x:1389,y:779,t:1528139680886};\\\", \\\"{x:1392,y:777,t:1528139680903};\\\", \\\"{x:1393,y:774,t:1528139680919};\\\", \\\"{x:1394,y:771,t:1528139680936};\\\", \\\"{x:1395,y:770,t:1528139680953};\\\", \\\"{x:1396,y:766,t:1528139680969};\\\", \\\"{x:1397,y:764,t:1528139680986};\\\", \\\"{x:1397,y:763,t:1528139681003};\\\", \\\"{x:1397,y:762,t:1528139681019};\\\", \\\"{x:1398,y:761,t:1528139681036};\\\", \\\"{x:1398,y:760,t:1528139681197};\\\", \\\"{x:1397,y:759,t:1528139681229};\\\", \\\"{x:1397,y:758,t:1528139681253};\\\", \\\"{x:1396,y:758,t:1528139681270};\\\", \\\"{x:1395,y:758,t:1528139681293};\\\", \\\"{x:1394,y:757,t:1528139681304};\\\", \\\"{x:1393,y:757,t:1528139681321};\\\", \\\"{x:1393,y:756,t:1528139681382};\\\", \\\"{x:1393,y:755,t:1528139681430};\\\", \\\"{x:1392,y:754,t:1528139681438};\\\", \\\"{x:1389,y:752,t:1528139681453};\\\", \\\"{x:1386,y:752,t:1528139681470};\\\", \\\"{x:1382,y:749,t:1528139681486};\\\", \\\"{x:1381,y:749,t:1528139682054};\\\", \\\"{x:1379,y:749,t:1528139682071};\\\", \\\"{x:1377,y:749,t:1528139682088};\\\", \\\"{x:1377,y:750,t:1528139682103};\\\", \\\"{x:1376,y:752,t:1528139682120};\\\", \\\"{x:1376,y:753,t:1528139682138};\\\", \\\"{x:1375,y:755,t:1528139682158};\\\", \\\"{x:1374,y:756,t:1528139682182};\\\", \\\"{x:1374,y:757,t:1528139682189};\\\", \\\"{x:1372,y:759,t:1528139682213};\\\", \\\"{x:1371,y:760,t:1528139682221};\\\", \\\"{x:1370,y:761,t:1528139682253};\\\", \\\"{x:1371,y:762,t:1528139682501};\\\", \\\"{x:1371,y:763,t:1528139682518};\\\", \\\"{x:1372,y:763,t:1528139682525};\\\", \\\"{x:1373,y:763,t:1528139682538};\\\", \\\"{x:1375,y:764,t:1528139682555};\\\", \\\"{x:1376,y:764,t:1528139682575};\\\", \\\"{x:1378,y:765,t:1528139682603};\\\", \\\"{x:1379,y:765,t:1528139682636};\\\", \\\"{x:1380,y:765,t:1528139682644};\\\", \\\"{x:1381,y:766,t:1528139682668};\\\", \\\"{x:1382,y:770,t:1528139685256};\\\", \\\"{x:1304,y:812,t:1528139685273};\\\", \\\"{x:1170,y:859,t:1528139685289};\\\", \\\"{x:1001,y:911,t:1528139685306};\\\", \\\"{x:855,y:948,t:1528139685323};\\\", \\\"{x:725,y:965,t:1528139685339};\\\", \\\"{x:588,y:963,t:1528139685356};\\\", \\\"{x:554,y:950,t:1528139685373};\\\", \\\"{x:554,y:949,t:1528139685389};\\\", \\\"{x:554,y:942,t:1528139685412};\\\", \\\"{x:556,y:938,t:1528139685423};\\\", \\\"{x:564,y:927,t:1528139685439};\\\", \\\"{x:576,y:915,t:1528139685456};\\\", \\\"{x:592,y:904,t:1528139685473};\\\", \\\"{x:608,y:892,t:1528139685489};\\\", \\\"{x:612,y:890,t:1528139685506};\\\", \\\"{x:618,y:881,t:1528139685524};\\\", \\\"{x:623,y:875,t:1528139685539};\\\", \\\"{x:630,y:864,t:1528139685556};\\\", \\\"{x:631,y:855,t:1528139685574};\\\", \\\"{x:631,y:848,t:1528139685590};\\\", \\\"{x:630,y:843,t:1528139685606};\\\", \\\"{x:625,y:835,t:1528139685624};\\\", \\\"{x:615,y:831,t:1528139685640};\\\", \\\"{x:602,y:819,t:1528139685656};\\\", \\\"{x:580,y:809,t:1528139685674};\\\", \\\"{x:551,y:793,t:1528139685691};\\\", \\\"{x:514,y:775,t:1528139685706};\\\", \\\"{x:483,y:759,t:1528139685724};\\\", \\\"{x:432,y:738,t:1528139685741};\\\", \\\"{x:413,y:728,t:1528139685756};\\\", \\\"{x:402,y:723,t:1528139685773};\\\", \\\"{x:399,y:719,t:1528139685790};\\\", \\\"{x:397,y:713,t:1528139685807};\\\", \\\"{x:396,y:709,t:1528139685823};\\\", \\\"{x:396,y:705,t:1528139685840};\\\", \\\"{x:397,y:696,t:1528139685857};\\\", \\\"{x:400,y:686,t:1528139685873};\\\", \\\"{x:401,y:678,t:1528139685891};\\\", \\\"{x:403,y:666,t:1528139685907};\\\", \\\"{x:406,y:653,t:1528139685923};\\\", \\\"{x:406,y:635,t:1528139685941};\\\", \\\"{x:407,y:626,t:1528139685957};\\\", \\\"{x:407,y:621,t:1528139685973};\\\", \\\"{x:407,y:614,t:1528139685991};\\\", \\\"{x:407,y:604,t:1528139686008};\\\", \\\"{x:405,y:592,t:1528139686024};\\\", \\\"{x:404,y:587,t:1528139686040};\\\", \\\"{x:401,y:581,t:1528139686058};\\\", \\\"{x:400,y:578,t:1528139686075};\\\", \\\"{x:399,y:577,t:1528139686090};\\\", \\\"{x:399,y:574,t:1528139686107};\\\", \\\"{x:398,y:573,t:1528139686123};\\\", \\\"{x:396,y:571,t:1528139686141};\\\", \\\"{x:394,y:570,t:1528139686157};\\\", \\\"{x:392,y:570,t:1528139686173};\\\", \\\"{x:391,y:570,t:1528139686190};\\\", \\\"{x:389,y:570,t:1528139686220};\\\", \\\"{x:387,y:571,t:1528139686252};\\\", \\\"{x:385,y:571,t:1528139686260};\\\", \\\"{x:384,y:574,t:1528139686274};\\\", \\\"{x:382,y:576,t:1528139686291};\\\", \\\"{x:381,y:579,t:1528139686307};\\\", \\\"{x:380,y:581,t:1528139686325};\\\", \\\"{x:379,y:583,t:1528139686341};\\\", \\\"{x:378,y:585,t:1528139686388};\\\", \\\"{x:378,y:588,t:1528139686404};\\\", \\\"{x:378,y:589,t:1528139686412};\\\", \\\"{x:378,y:591,t:1528139686424};\\\", \\\"{x:377,y:592,t:1528139686440};\\\", \\\"{x:377,y:593,t:1528139686460};\\\", \\\"{x:379,y:596,t:1528139686716};\\\", \\\"{x:385,y:605,t:1528139686723};\\\", \\\"{x:394,y:623,t:1528139686741};\\\", \\\"{x:401,y:632,t:1528139686757};\\\", \\\"{x:417,y:652,t:1528139686774};\\\", \\\"{x:434,y:666,t:1528139686791};\\\", \\\"{x:450,y:679,t:1528139686807};\\\", \\\"{x:463,y:689,t:1528139686825};\\\", \\\"{x:465,y:693,t:1528139686841};\\\", \\\"{x:468,y:696,t:1528139686857};\\\", \\\"{x:472,y:697,t:1528139686875};\\\", \\\"{x:473,y:699,t:1528139686891};\\\", \\\"{x:476,y:702,t:1528139686907};\\\", \\\"{x:480,y:711,t:1528139686924};\\\", \\\"{x:485,y:717,t:1528139686941};\\\", \\\"{x:491,y:723,t:1528139686957};\\\", \\\"{x:496,y:729,t:1528139686975};\\\", \\\"{x:503,y:736,t:1528139686991};\\\", \\\"{x:510,y:742,t:1528139687008};\\\", \\\"{x:515,y:749,t:1528139687024};\\\", \\\"{x:517,y:752,t:1528139687041};\\\", \\\"{x:518,y:753,t:1528139687058};\\\", \\\"{x:518,y:756,t:1528139687372};\\\", \\\"{x:520,y:765,t:1528139687380};\\\", \\\"{x:524,y:779,t:1528139687391};\\\", \\\"{x:533,y:820,t:1528139687408};\\\", \\\"{x:547,y:863,t:1528139687424};\\\", \\\"{x:556,y:886,t:1528139687441};\\\", \\\"{x:562,y:925,t:1528139687459};\\\", \\\"{x:569,y:960,t:1528139687474};\\\", \\\"{x:576,y:1002,t:1528139687491};\\\", \\\"{x:580,y:1063,t:1528139687508};\\\", \\\"{x:580,y:1093,t:1528139687524};\\\", \\\"{x:580,y:1101,t:1528139687541};\\\", \\\"{x:581,y:1116,t:1528139687558};\\\", \\\"{x:581,y:1130,t:1528139687575};\\\", \\\"{x:581,y:1136,t:1528139687591};\\\", \\\"{x:581,y:1143,t:1528139687608};\\\", \\\"{x:581,y:1147,t:1528139687624};\\\", \\\"{x:581,y:1151,t:1528139687641};\\\", \\\"{x:581,y:1155,t:1528139687658};\\\", \\\"{x:581,y:1158,t:1528139687674};\\\", \\\"{x:581,y:1161,t:1528139687691};\\\", \\\"{x:581,y:1165,t:1528139687708};\\\", \\\"{x:580,y:1168,t:1528139687724};\\\", \\\"{x:579,y:1170,t:1528139687741};\\\", \\\"{x:579,y:1171,t:1528139687758};\\\", \\\"{x:579,y:1172,t:1528139687775};\\\", \\\"{x:578,y:1174,t:1528139687792};\\\", \\\"{x:578,y:1175,t:1528139687808};\\\" ] }, { \\\"rt\\\": 16698, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 539259, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-04 PM-H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:1171,t:1528139689565};\\\", \\\"{x:579,y:1166,t:1528139689578};\\\", \\\"{x:584,y:1152,t:1528139689594};\\\", \\\"{x:592,y:1136,t:1528139689609};\\\", \\\"{x:600,y:1118,t:1528139689626};\\\", \\\"{x:608,y:1102,t:1528139689643};\\\", \\\"{x:618,y:1083,t:1528139689659};\\\", \\\"{x:636,y:1049,t:1528139689676};\\\", \\\"{x:648,y:1022,t:1528139689693};\\\", \\\"{x:658,y:997,t:1528139689710};\\\", \\\"{x:667,y:980,t:1528139689727};\\\", \\\"{x:672,y:967,t:1528139689743};\\\", \\\"{x:678,y:959,t:1528139689760};\\\", \\\"{x:682,y:951,t:1528139689777};\\\", \\\"{x:683,y:951,t:1528139689794};\\\", \\\"{x:685,y:949,t:1528139689853};\\\", \\\"{x:687,y:946,t:1528139689861};\\\", \\\"{x:700,y:938,t:1528139689876};\\\", \\\"{x:712,y:929,t:1528139689893};\\\", \\\"{x:722,y:922,t:1528139689910};\\\", \\\"{x:728,y:918,t:1528139689926};\\\", \\\"{x:729,y:918,t:1528139689943};\\\", \\\"{x:730,y:917,t:1528139689960};\\\", \\\"{x:735,y:916,t:1528139690237};\\\", \\\"{x:752,y:916,t:1528139690244};\\\", \\\"{x:830,y:927,t:1528139690260};\\\", \\\"{x:903,y:949,t:1528139690277};\\\", \\\"{x:989,y:974,t:1528139690293};\\\", \\\"{x:1091,y:1002,t:1528139690311};\\\", \\\"{x:1218,y:1036,t:1528139690327};\\\", \\\"{x:1362,y:1077,t:1528139690343};\\\", \\\"{x:1502,y:1134,t:1528139690360};\\\", \\\"{x:1580,y:1172,t:1528139690377};\\\", \\\"{x:1669,y:1199,t:1528139690393};\\\", \\\"{x:1723,y:1199,t:1528139690411};\\\", \\\"{x:1759,y:1199,t:1528139690428};\\\", \\\"{x:1784,y:1199,t:1528139690444};\\\", \\\"{x:1791,y:1198,t:1528139690461};\\\", \\\"{x:1800,y:1192,t:1528139690478};\\\", \\\"{x:1811,y:1172,t:1528139690494};\\\", \\\"{x:1824,y:1140,t:1528139690510};\\\", \\\"{x:1837,y:1085,t:1528139690527};\\\", \\\"{x:1846,y:1008,t:1528139690544};\\\", \\\"{x:1848,y:944,t:1528139690560};\\\", \\\"{x:1846,y:920,t:1528139690578};\\\", \\\"{x:1841,y:899,t:1528139690595};\\\", \\\"{x:1838,y:891,t:1528139690611};\\\", \\\"{x:1838,y:886,t:1528139690627};\\\", \\\"{x:1837,y:885,t:1528139690644};\\\", \\\"{x:1834,y:885,t:1528139690709};\\\", \\\"{x:1832,y:885,t:1528139690717};\\\", \\\"{x:1829,y:888,t:1528139690727};\\\", \\\"{x:1818,y:894,t:1528139690744};\\\", \\\"{x:1810,y:901,t:1528139690760};\\\", \\\"{x:1801,y:912,t:1528139690777};\\\", \\\"{x:1792,y:926,t:1528139690794};\\\", \\\"{x:1782,y:938,t:1528139690811};\\\", \\\"{x:1777,y:949,t:1528139690827};\\\", \\\"{x:1766,y:966,t:1528139690844};\\\", \\\"{x:1761,y:974,t:1528139690860};\\\", \\\"{x:1757,y:982,t:1528139690877};\\\", \\\"{x:1751,y:990,t:1528139690895};\\\", \\\"{x:1738,y:999,t:1528139690911};\\\", \\\"{x:1729,y:1005,t:1528139690927};\\\", \\\"{x:1712,y:1014,t:1528139690945};\\\", \\\"{x:1695,y:1018,t:1528139690960};\\\", \\\"{x:1680,y:1021,t:1528139690978};\\\", \\\"{x:1672,y:1023,t:1528139690994};\\\", \\\"{x:1665,y:1023,t:1528139691012};\\\", \\\"{x:1659,y:1023,t:1528139691028};\\\", \\\"{x:1653,y:1023,t:1528139691045};\\\", \\\"{x:1650,y:1023,t:1528139691061};\\\", \\\"{x:1649,y:1023,t:1528139691077};\\\", \\\"{x:1648,y:1023,t:1528139691094};\\\", \\\"{x:1647,y:1023,t:1528139691112};\\\", \\\"{x:1646,y:1023,t:1528139691133};\\\", \\\"{x:1641,y:1021,t:1528139691148};\\\", \\\"{x:1640,y:1020,t:1528139691161};\\\", \\\"{x:1633,y:1015,t:1528139691177};\\\", \\\"{x:1625,y:1007,t:1528139691195};\\\", \\\"{x:1623,y:1004,t:1528139691212};\\\", \\\"{x:1621,y:999,t:1528139691228};\\\", \\\"{x:1616,y:989,t:1528139691244};\\\", \\\"{x:1611,y:977,t:1528139691262};\\\", \\\"{x:1605,y:960,t:1528139691278};\\\", \\\"{x:1595,y:945,t:1528139691295};\\\", \\\"{x:1592,y:940,t:1528139691312};\\\", \\\"{x:1590,y:937,t:1528139691327};\\\", \\\"{x:1589,y:936,t:1528139691344};\\\", \\\"{x:1587,y:933,t:1528139691362};\\\", \\\"{x:1588,y:933,t:1528139691517};\\\", \\\"{x:1589,y:933,t:1528139691529};\\\", \\\"{x:1591,y:933,t:1528139691545};\\\", \\\"{x:1591,y:934,t:1528139691701};\\\", \\\"{x:1591,y:936,t:1528139691712};\\\", \\\"{x:1591,y:937,t:1528139691765};\\\", \\\"{x:1591,y:939,t:1528139691779};\\\", \\\"{x:1591,y:943,t:1528139691795};\\\", \\\"{x:1591,y:946,t:1528139691812};\\\", \\\"{x:1591,y:948,t:1528139691869};\\\", \\\"{x:1592,y:948,t:1528139691901};\\\", \\\"{x:1593,y:948,t:1528139691912};\\\", \\\"{x:1595,y:948,t:1528139691929};\\\", \\\"{x:1598,y:948,t:1528139691946};\\\", \\\"{x:1601,y:947,t:1528139691961};\\\", \\\"{x:1602,y:947,t:1528139691980};\\\", \\\"{x:1602,y:946,t:1528139691995};\\\", \\\"{x:1603,y:946,t:1528139692011};\\\", \\\"{x:1605,y:945,t:1528139692028};\\\", \\\"{x:1606,y:944,t:1528139692045};\\\", \\\"{x:1607,y:944,t:1528139692067};\\\", \\\"{x:1607,y:943,t:1528139692389};\\\", \\\"{x:1607,y:942,t:1528139692405};\\\", \\\"{x:1606,y:941,t:1528139692412};\\\", \\\"{x:1606,y:940,t:1528139692453};\\\", \\\"{x:1605,y:939,t:1528139692686};\\\", \\\"{x:1605,y:938,t:1528139692696};\\\", \\\"{x:1604,y:937,t:1528139692741};\\\", \\\"{x:1604,y:936,t:1528139692749};\\\", \\\"{x:1604,y:935,t:1528139692762};\\\", \\\"{x:1603,y:934,t:1528139692780};\\\", \\\"{x:1603,y:933,t:1528139692796};\\\", \\\"{x:1603,y:932,t:1528139692813};\\\", \\\"{x:1602,y:932,t:1528139692830};\\\", \\\"{x:1602,y:931,t:1528139692861};\\\", \\\"{x:1602,y:930,t:1528139692950};\\\", \\\"{x:1601,y:930,t:1528139692963};\\\", \\\"{x:1600,y:929,t:1528139693021};\\\", \\\"{x:1600,y:928,t:1528139693901};\\\", \\\"{x:1601,y:928,t:1528139694669};\\\", \\\"{x:1601,y:925,t:1528139694709};\\\", \\\"{x:1602,y:925,t:1528139694894};\\\", \\\"{x:1598,y:924,t:1528139694949};\\\", \\\"{x:1571,y:912,t:1528139694964};\\\", \\\"{x:1384,y:859,t:1528139694981};\\\", \\\"{x:1200,y:787,t:1528139694998};\\\", \\\"{x:1005,y:718,t:1528139695015};\\\", \\\"{x:822,y:651,t:1528139695031};\\\", \\\"{x:659,y:584,t:1528139695050};\\\", \\\"{x:547,y:538,t:1528139695065};\\\", \\\"{x:525,y:525,t:1528139695080};\\\", \\\"{x:522,y:523,t:1528139695095};\\\", \\\"{x:521,y:522,t:1528139695113};\\\", \\\"{x:525,y:524,t:1528139695140};\\\", \\\"{x:530,y:529,t:1528139695148};\\\", \\\"{x:534,y:538,t:1528139695163};\\\", \\\"{x:551,y:552,t:1528139695179};\\\", \\\"{x:563,y:565,t:1528139695195};\\\", \\\"{x:580,y:590,t:1528139695215};\\\", \\\"{x:596,y:608,t:1528139695230};\\\", \\\"{x:604,y:618,t:1528139695249};\\\", \\\"{x:610,y:626,t:1528139695265};\\\", \\\"{x:612,y:628,t:1528139695281};\\\", \\\"{x:612,y:629,t:1528139695297};\\\", \\\"{x:612,y:627,t:1528139695412};\\\", \\\"{x:612,y:622,t:1528139695421};\\\", \\\"{x:612,y:617,t:1528139695432};\\\", \\\"{x:612,y:608,t:1528139695448};\\\", \\\"{x:606,y:596,t:1528139695465};\\\", \\\"{x:605,y:587,t:1528139695481};\\\", \\\"{x:603,y:585,t:1528139695497};\\\", \\\"{x:601,y:581,t:1528139695515};\\\", \\\"{x:601,y:580,t:1528139695653};\\\", \\\"{x:600,y:580,t:1528139695668};\\\", \\\"{x:599,y:582,t:1528139695685};\\\", \\\"{x:599,y:583,t:1528139695813};\\\", \\\"{x:599,y:584,t:1528139695821};\\\", \\\"{x:600,y:585,t:1528139695832};\\\", \\\"{x:600,y:586,t:1528139695850};\\\", \\\"{x:602,y:588,t:1528139695865};\\\", \\\"{x:602,y:589,t:1528139695881};\\\", \\\"{x:605,y:590,t:1528139696581};\\\", \\\"{x:629,y:597,t:1528139696596};\\\", \\\"{x:715,y:621,t:1528139696613};\\\", \\\"{x:828,y:662,t:1528139696629};\\\", \\\"{x:918,y:691,t:1528139696648};\\\", \\\"{x:1002,y:724,t:1528139696666};\\\", \\\"{x:1052,y:737,t:1528139696683};\\\", \\\"{x:1097,y:750,t:1528139696699};\\\", \\\"{x:1110,y:751,t:1528139696715};\\\", \\\"{x:1120,y:749,t:1528139696731};\\\", \\\"{x:1122,y:748,t:1528139696748};\\\", \\\"{x:1127,y:745,t:1528139696766};\\\", \\\"{x:1135,y:742,t:1528139696783};\\\", \\\"{x:1149,y:733,t:1528139696798};\\\", \\\"{x:1164,y:725,t:1528139696815};\\\", \\\"{x:1182,y:717,t:1528139696832};\\\", \\\"{x:1198,y:710,t:1528139696849};\\\", \\\"{x:1228,y:703,t:1528139696865};\\\", \\\"{x:1260,y:695,t:1528139696882};\\\", \\\"{x:1313,y:687,t:1528139696899};\\\", \\\"{x:1340,y:680,t:1528139696916};\\\", \\\"{x:1371,y:663,t:1528139696933};\\\", \\\"{x:1382,y:655,t:1528139696949};\\\", \\\"{x:1387,y:653,t:1528139696966};\\\", \\\"{x:1388,y:650,t:1528139696983};\\\", \\\"{x:1388,y:647,t:1528139697046};\\\", \\\"{x:1388,y:645,t:1528139697053};\\\", \\\"{x:1388,y:641,t:1528139697066};\\\", \\\"{x:1388,y:633,t:1528139697083};\\\", \\\"{x:1388,y:623,t:1528139697100};\\\", \\\"{x:1386,y:608,t:1528139697116};\\\", \\\"{x:1380,y:589,t:1528139697133};\\\", \\\"{x:1378,y:576,t:1528139697150};\\\", \\\"{x:1376,y:563,t:1528139697166};\\\", \\\"{x:1376,y:551,t:1528139697183};\\\", \\\"{x:1376,y:538,t:1528139697200};\\\", \\\"{x:1377,y:532,t:1528139697216};\\\", \\\"{x:1379,y:527,t:1528139697233};\\\", \\\"{x:1381,y:526,t:1528139697251};\\\", \\\"{x:1381,y:524,t:1528139697266};\\\", \\\"{x:1383,y:523,t:1528139697309};\\\", \\\"{x:1386,y:523,t:1528139697323};\\\", \\\"{x:1387,y:523,t:1528139697333};\\\", \\\"{x:1389,y:523,t:1528139697349};\\\", \\\"{x:1394,y:523,t:1528139697366};\\\", \\\"{x:1400,y:527,t:1528139697383};\\\", \\\"{x:1403,y:529,t:1528139697400};\\\", \\\"{x:1406,y:534,t:1528139697416};\\\", \\\"{x:1410,y:539,t:1528139697432};\\\", \\\"{x:1411,y:540,t:1528139697450};\\\", \\\"{x:1413,y:543,t:1528139697467};\\\", \\\"{x:1414,y:547,t:1528139697483};\\\", \\\"{x:1417,y:549,t:1528139697500};\\\", \\\"{x:1420,y:550,t:1528139697573};\\\", \\\"{x:1421,y:551,t:1528139697583};\\\", \\\"{x:1423,y:557,t:1528139697601};\\\", \\\"{x:1425,y:559,t:1528139697617};\\\", \\\"{x:1426,y:560,t:1528139697634};\\\", \\\"{x:1427,y:561,t:1528139697650};\\\", \\\"{x:1427,y:562,t:1528139697668};\\\", \\\"{x:1427,y:563,t:1528139697845};\\\", \\\"{x:1427,y:564,t:1528139697853};\\\", \\\"{x:1426,y:565,t:1528139697868};\\\", \\\"{x:1425,y:565,t:1528139697885};\\\", \\\"{x:1424,y:566,t:1528139697916};\\\", \\\"{x:1424,y:567,t:1528139697933};\\\", \\\"{x:1422,y:567,t:1528139697950};\\\", \\\"{x:1420,y:569,t:1528139698013};\\\", \\\"{x:1419,y:569,t:1528139698045};\\\", \\\"{x:1418,y:569,t:1528139698133};\\\", \\\"{x:1417,y:569,t:1528139698254};\\\", \\\"{x:1415,y:569,t:1528139698388};\\\", \\\"{x:1415,y:568,t:1528139698414};\\\", \\\"{x:1414,y:564,t:1528139698621};\\\", \\\"{x:1413,y:562,t:1528139704172};\\\", \\\"{x:1411,y:561,t:1528139704220};\\\", \\\"{x:1391,y:564,t:1528139704239};\\\", \\\"{x:1361,y:567,t:1528139704255};\\\", \\\"{x:1302,y:567,t:1528139704271};\\\", \\\"{x:1229,y:565,t:1528139704287};\\\", \\\"{x:1127,y:553,t:1528139704305};\\\", \\\"{x:1007,y:532,t:1528139704322};\\\", \\\"{x:914,y:513,t:1528139704338};\\\", \\\"{x:823,y:499,t:1528139704354};\\\", \\\"{x:784,y:490,t:1528139704372};\\\", \\\"{x:776,y:493,t:1528139704388};\\\", \\\"{x:768,y:497,t:1528139704405};\\\", \\\"{x:764,y:509,t:1528139704422};\\\", \\\"{x:754,y:529,t:1528139704438};\\\", \\\"{x:751,y:549,t:1528139704456};\\\", \\\"{x:747,y:578,t:1528139704472};\\\", \\\"{x:742,y:603,t:1528139704490};\\\", \\\"{x:738,y:623,t:1528139704506};\\\", \\\"{x:736,y:639,t:1528139704521};\\\", \\\"{x:733,y:651,t:1528139704539};\\\", \\\"{x:729,y:661,t:1528139704555};\\\", \\\"{x:722,y:675,t:1528139704572};\\\", \\\"{x:714,y:688,t:1528139704589};\\\", \\\"{x:704,y:704,t:1528139704604};\\\", \\\"{x:693,y:717,t:1528139704622};\\\", \\\"{x:680,y:730,t:1528139704639};\\\", \\\"{x:669,y:739,t:1528139704654};\\\", \\\"{x:661,y:742,t:1528139704672};\\\", \\\"{x:651,y:747,t:1528139704689};\\\", \\\"{x:644,y:748,t:1528139704705};\\\", \\\"{x:629,y:755,t:1528139704722};\\\", \\\"{x:615,y:760,t:1528139704739};\\\", \\\"{x:581,y:766,t:1528139704756};\\\", \\\"{x:559,y:768,t:1528139704773};\\\", \\\"{x:544,y:769,t:1528139704789};\\\", \\\"{x:530,y:771,t:1528139704806};\\\", \\\"{x:520,y:771,t:1528139704822};\\\", \\\"{x:511,y:770,t:1528139704839};\\\", \\\"{x:503,y:770,t:1528139704856};\\\", \\\"{x:501,y:770,t:1528139704872};\\\", \\\"{x:498,y:770,t:1528139704889};\\\", \\\"{x:496,y:770,t:1528139704906};\\\", \\\"{x:495,y:770,t:1528139704922};\\\", \\\"{x:496,y:770,t:1528139704997};\\\", \\\"{x:497,y:776,t:1528139705437};\\\", \\\"{x:497,y:787,t:1528139705444};\\\", \\\"{x:497,y:804,t:1528139705456};\\\", \\\"{x:485,y:840,t:1528139705473};\\\", \\\"{x:471,y:902,t:1528139705489};\\\", \\\"{x:458,y:931,t:1528139705506};\\\", \\\"{x:434,y:988,t:1528139705523};\\\", \\\"{x:410,y:1041,t:1528139705539};\\\", \\\"{x:381,y:1100,t:1528139705556};\\\", \\\"{x:362,y:1149,t:1528139705573};\\\", \\\"{x:351,y:1175,t:1528139705589};\\\", \\\"{x:328,y:1199,t:1528139705606};\\\", \\\"{x:316,y:1199,t:1528139705622};\\\", \\\"{x:304,y:1199,t:1528139705638};\\\", \\\"{x:299,y:1199,t:1528139705655};\\\", \\\"{x:298,y:1199,t:1528139705673};\\\", \\\"{x:300,y:1198,t:1528139706087};\\\", \\\"{x:301,y:1191,t:1528139706100};\\\", \\\"{x:309,y:1178,t:1528139706117};\\\", \\\"{x:316,y:1162,t:1528139706134};\\\", \\\"{x:333,y:1132,t:1528139706151};\\\", \\\"{x:342,y:1120,t:1528139706167};\\\", \\\"{x:348,y:1115,t:1528139706183};\\\", \\\"{x:354,y:1105,t:1528139706200};\\\", \\\"{x:361,y:1090,t:1528139706218};\\\", \\\"{x:371,y:1072,t:1528139706233};\\\", \\\"{x:394,y:1021,t:1528139706256};\\\", \\\"{x:405,y:992,t:1528139706267};\\\", \\\"{x:429,y:953,t:1528139706283};\\\", \\\"{x:444,y:923,t:1528139706300};\\\", \\\"{x:461,y:895,t:1528139706317};\\\", \\\"{x:478,y:865,t:1528139706333};\\\", \\\"{x:504,y:817,t:1528139706350};\\\" ] }, { \\\"rt\\\": 28282, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 568847, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:556,y:715,t:1528139706526};\\\", \\\"{x:558,y:717,t:1528139707046};\\\", \\\"{x:579,y:738,t:1528139707064};\\\", \\\"{x:591,y:748,t:1528139707070};\\\", \\\"{x:604,y:755,t:1528139707084};\\\", \\\"{x:634,y:768,t:1528139707100};\\\", \\\"{x:658,y:778,t:1528139707118};\\\", \\\"{x:686,y:785,t:1528139707133};\\\", \\\"{x:696,y:787,t:1528139707151};\\\", \\\"{x:700,y:787,t:1528139707168};\\\", \\\"{x:702,y:788,t:1528139707184};\\\", \\\"{x:704,y:790,t:1528139707271};\\\", \\\"{x:704,y:795,t:1528139707284};\\\", \\\"{x:705,y:815,t:1528139707301};\\\", \\\"{x:705,y:835,t:1528139707317};\\\", \\\"{x:705,y:864,t:1528139707334};\\\", \\\"{x:705,y:880,t:1528139707351};\\\", \\\"{x:705,y:895,t:1528139707367};\\\", \\\"{x:704,y:906,t:1528139707385};\\\", \\\"{x:701,y:916,t:1528139707402};\\\", \\\"{x:700,y:921,t:1528139707418};\\\", \\\"{x:697,y:923,t:1528139707434};\\\", \\\"{x:697,y:924,t:1528139707452};\\\", \\\"{x:701,y:923,t:1528139717135};\\\", \\\"{x:702,y:923,t:1528139717143};\\\", \\\"{x:703,y:923,t:1528139717158};\\\", \\\"{x:704,y:921,t:1528139717174};\\\", \\\"{x:705,y:921,t:1528139717191};\\\", \\\"{x:705,y:919,t:1528139717207};\\\", \\\"{x:708,y:917,t:1528139717224};\\\", \\\"{x:712,y:914,t:1528139717242};\\\", \\\"{x:716,y:914,t:1528139717257};\\\", \\\"{x:720,y:911,t:1528139717274};\\\", \\\"{x:727,y:905,t:1528139717291};\\\", \\\"{x:738,y:899,t:1528139717307};\\\", \\\"{x:744,y:893,t:1528139717324};\\\", \\\"{x:754,y:884,t:1528139717341};\\\", \\\"{x:767,y:875,t:1528139717357};\\\", \\\"{x:791,y:853,t:1528139717374};\\\", \\\"{x:835,y:816,t:1528139717390};\\\", \\\"{x:871,y:777,t:1528139717407};\\\", \\\"{x:946,y:725,t:1528139717424};\\\", \\\"{x:1031,y:674,t:1528139717441};\\\", \\\"{x:1097,y:615,t:1528139717457};\\\", \\\"{x:1165,y:562,t:1528139717474};\\\", \\\"{x:1228,y:524,t:1528139717491};\\\", \\\"{x:1293,y:488,t:1528139717507};\\\", \\\"{x:1348,y:467,t:1528139717524};\\\", \\\"{x:1376,y:449,t:1528139717540};\\\", \\\"{x:1399,y:436,t:1528139717558};\\\", \\\"{x:1401,y:436,t:1528139717574};\\\", \\\"{x:1402,y:437,t:1528139717606};\\\", \\\"{x:1405,y:447,t:1528139717614};\\\", \\\"{x:1405,y:464,t:1528139717623};\\\", \\\"{x:1397,y:498,t:1528139717641};\\\", \\\"{x:1386,y:518,t:1528139717658};\\\", \\\"{x:1378,y:529,t:1528139717673};\\\", \\\"{x:1376,y:531,t:1528139717692};\\\", \\\"{x:1374,y:531,t:1528139717719};\\\", \\\"{x:1373,y:532,t:1528139717727};\\\", \\\"{x:1372,y:533,t:1528139717741};\\\", \\\"{x:1361,y:534,t:1528139717759};\\\", \\\"{x:1355,y:534,t:1528139717774};\\\", \\\"{x:1351,y:534,t:1528139717791};\\\", \\\"{x:1341,y:526,t:1528139717809};\\\", \\\"{x:1336,y:524,t:1528139717825};\\\", \\\"{x:1324,y:521,t:1528139717842};\\\", \\\"{x:1317,y:516,t:1528139717859};\\\", \\\"{x:1315,y:514,t:1528139717875};\\\", \\\"{x:1311,y:508,t:1528139717891};\\\", \\\"{x:1310,y:506,t:1528139717908};\\\", \\\"{x:1310,y:505,t:1528139718191};\\\", \\\"{x:1310,y:504,t:1528139718208};\\\", \\\"{x:1310,y:503,t:1528139718226};\\\", \\\"{x:1310,y:502,t:1528139718241};\\\", \\\"{x:1310,y:500,t:1528139718259};\\\", \\\"{x:1311,y:500,t:1528139718275};\\\", \\\"{x:1312,y:499,t:1528139718290};\\\", \\\"{x:1312,y:498,t:1528139718447};\\\", \\\"{x:1312,y:497,t:1528139718486};\\\", \\\"{x:1315,y:537,t:1528139723216};\\\", \\\"{x:1318,y:557,t:1528139723234};\\\", \\\"{x:1320,y:569,t:1528139723247};\\\", \\\"{x:1321,y:573,t:1528139723264};\\\", \\\"{x:1324,y:581,t:1528139723280};\\\", \\\"{x:1324,y:583,t:1528139723297};\\\", \\\"{x:1324,y:592,t:1528139723314};\\\", \\\"{x:1324,y:595,t:1528139723331};\\\", \\\"{x:1324,y:600,t:1528139723347};\\\", \\\"{x:1324,y:604,t:1528139723364};\\\", \\\"{x:1323,y:606,t:1528139723381};\\\", \\\"{x:1322,y:608,t:1528139723422};\\\", \\\"{x:1321,y:610,t:1528139723438};\\\", \\\"{x:1321,y:611,t:1528139723448};\\\", \\\"{x:1320,y:613,t:1528139723464};\\\", \\\"{x:1320,y:615,t:1528139723481};\\\", \\\"{x:1320,y:617,t:1528139723498};\\\", \\\"{x:1317,y:619,t:1528139723514};\\\", \\\"{x:1317,y:620,t:1528139723530};\\\", \\\"{x:1317,y:621,t:1528139723548};\\\", \\\"{x:1316,y:622,t:1528139723566};\\\", \\\"{x:1313,y:624,t:1528139723582};\\\", \\\"{x:1313,y:625,t:1528139723600};\\\", \\\"{x:1312,y:625,t:1528139723631};\\\", \\\"{x:1312,y:626,t:1528139723702};\\\", \\\"{x:1311,y:628,t:1528139723718};\\\", \\\"{x:1306,y:631,t:1528139731177};\\\", \\\"{x:1261,y:634,t:1528139731202};\\\", \\\"{x:1237,y:636,t:1528139731220};\\\", \\\"{x:1209,y:636,t:1528139731237};\\\", \\\"{x:1191,y:631,t:1528139731253};\\\", \\\"{x:1177,y:627,t:1528139731270};\\\", \\\"{x:1164,y:626,t:1528139731287};\\\", \\\"{x:1152,y:623,t:1528139731304};\\\", \\\"{x:1150,y:619,t:1528139731320};\\\", \\\"{x:1146,y:617,t:1528139731337};\\\", \\\"{x:1141,y:615,t:1528139731354};\\\", \\\"{x:1136,y:615,t:1528139731371};\\\", \\\"{x:1132,y:613,t:1528139731387};\\\", \\\"{x:1125,y:610,t:1528139731404};\\\", \\\"{x:1109,y:603,t:1528139731420};\\\", \\\"{x:1107,y:601,t:1528139731437};\\\", \\\"{x:1098,y:600,t:1528139731470};\\\", \\\"{x:1088,y:601,t:1528139731487};\\\", \\\"{x:1078,y:596,t:1528139731504};\\\", \\\"{x:1065,y:590,t:1528139731521};\\\", \\\"{x:1062,y:590,t:1528139731537};\\\", \\\"{x:1061,y:591,t:1528139731558};\\\", \\\"{x:1059,y:591,t:1528139731570};\\\", \\\"{x:1057,y:591,t:1528139731588};\\\", \\\"{x:1051,y:592,t:1528139731605};\\\", \\\"{x:1046,y:593,t:1528139731621};\\\", \\\"{x:1034,y:594,t:1528139731638};\\\", \\\"{x:1032,y:594,t:1528139731718};\\\", \\\"{x:1032,y:595,t:1528139731782};\\\", \\\"{x:1031,y:595,t:1528139731791};\\\", \\\"{x:1028,y:595,t:1528139731857};\\\", \\\"{x:1027,y:595,t:1528139731887};\\\", \\\"{x:1020,y:597,t:1528139732814};\\\", \\\"{x:1010,y:596,t:1528139732822};\\\", \\\"{x:993,y:594,t:1528139732838};\\\", \\\"{x:978,y:592,t:1528139732855};\\\", \\\"{x:951,y:592,t:1528139732872};\\\", \\\"{x:929,y:592,t:1528139732888};\\\", \\\"{x:898,y:591,t:1528139732905};\\\", \\\"{x:856,y:591,t:1528139732922};\\\", \\\"{x:816,y:591,t:1528139732938};\\\", \\\"{x:776,y:591,t:1528139732955};\\\", \\\"{x:746,y:591,t:1528139732971};\\\", \\\"{x:730,y:594,t:1528139732990};\\\", \\\"{x:727,y:595,t:1528139733005};\\\", \\\"{x:726,y:596,t:1528139733022};\\\", \\\"{x:726,y:590,t:1528139733071};\\\", \\\"{x:725,y:583,t:1528139733088};\\\", \\\"{x:723,y:579,t:1528139733106};\\\", \\\"{x:721,y:574,t:1528139733122};\\\", \\\"{x:728,y:565,t:1528139733139};\\\", \\\"{x:737,y:559,t:1528139733155};\\\", \\\"{x:744,y:555,t:1528139733172};\\\", \\\"{x:750,y:552,t:1528139733189};\\\", \\\"{x:753,y:551,t:1528139733221};\\\", \\\"{x:756,y:551,t:1528139733240};\\\", \\\"{x:757,y:550,t:1528139733255};\\\", \\\"{x:759,y:550,t:1528139733272};\\\", \\\"{x:761,y:549,t:1528139733289};\\\", \\\"{x:763,y:549,t:1528139733305};\\\", \\\"{x:768,y:549,t:1528139733322};\\\", \\\"{x:769,y:549,t:1528139733339};\\\", \\\"{x:770,y:550,t:1528139733357};\\\", \\\"{x:773,y:550,t:1528139733372};\\\", \\\"{x:782,y:553,t:1528139733390};\\\", \\\"{x:787,y:554,t:1528139733406};\\\", \\\"{x:791,y:556,t:1528139733423};\\\", \\\"{x:794,y:557,t:1528139733439};\\\", \\\"{x:796,y:557,t:1528139733455};\\\", \\\"{x:797,y:557,t:1528139733477};\\\", \\\"{x:798,y:558,t:1528139733489};\\\", \\\"{x:800,y:559,t:1528139733505};\\\", \\\"{x:801,y:563,t:1528139733522};\\\", \\\"{x:807,y:564,t:1528139733539};\\\", \\\"{x:812,y:568,t:1528139733555};\\\", \\\"{x:816,y:569,t:1528139733572};\\\", \\\"{x:816,y:570,t:1528139733590};\\\", \\\"{x:817,y:570,t:1528139733718};\\\", \\\"{x:819,y:570,t:1528139733727};\\\", \\\"{x:820,y:571,t:1528139733751};\\\", \\\"{x:821,y:571,t:1528139733758};\\\", \\\"{x:822,y:571,t:1528139733774};\\\", \\\"{x:829,y:571,t:1528139733790};\\\", \\\"{x:836,y:571,t:1528139733806};\\\", \\\"{x:837,y:571,t:1528139733822};\\\", \\\"{x:838,y:571,t:1528139733840};\\\", \\\"{x:839,y:571,t:1528139733959};\\\", \\\"{x:840,y:574,t:1528139734173};\\\", \\\"{x:829,y:596,t:1528139734190};\\\", \\\"{x:806,y:618,t:1528139734206};\\\", \\\"{x:778,y:649,t:1528139734223};\\\", \\\"{x:735,y:694,t:1528139734239};\\\", \\\"{x:694,y:729,t:1528139734256};\\\", \\\"{x:662,y:750,t:1528139734273};\\\", \\\"{x:639,y:757,t:1528139734289};\\\", \\\"{x:623,y:758,t:1528139734306};\\\", \\\"{x:620,y:758,t:1528139734323};\\\", \\\"{x:614,y:758,t:1528139734340};\\\", \\\"{x:605,y:761,t:1528139734356};\\\", \\\"{x:590,y:765,t:1528139734374};\\\", \\\"{x:581,y:768,t:1528139734389};\\\", \\\"{x:564,y:772,t:1528139734407};\\\", \\\"{x:562,y:772,t:1528139734423};\\\", \\\"{x:561,y:772,t:1528139734478};\\\", \\\"{x:560,y:772,t:1528139734502};\\\", \\\"{x:559,y:772,t:1528139734510};\\\", \\\"{x:557,y:772,t:1528139734523};\\\", \\\"{x:554,y:772,t:1528139734539};\\\", \\\"{x:548,y:772,t:1528139734556};\\\", \\\"{x:547,y:772,t:1528139734582};\\\", \\\"{x:545,y:772,t:1528139734590};\\\", \\\"{x:541,y:772,t:1528139734606};\\\", \\\"{x:537,y:772,t:1528139734622};\\\", \\\"{x:536,y:772,t:1528139734705};\\\", \\\"{x:534,y:772,t:1528139734825};\\\", \\\"{x:533,y:772,t:1528139734840};\\\", \\\"{x:532,y:772,t:1528139734856};\\\", \\\"{x:531,y:771,t:1528139734893};\\\" ] }, { \\\"rt\\\": 43279, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 613375, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -F -C -M -J -E -E -5-6-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:770,t:1528139737327};\\\", \\\"{x:561,y:770,t:1528139737343};\\\", \\\"{x:625,y:765,t:1528139737360};\\\", \\\"{x:706,y:765,t:1528139737375};\\\", \\\"{x:775,y:765,t:1528139737393};\\\", \\\"{x:856,y:765,t:1528139737408};\\\", \\\"{x:895,y:765,t:1528139737425};\\\", \\\"{x:917,y:765,t:1528139737442};\\\", \\\"{x:928,y:764,t:1528139737458};\\\", \\\"{x:929,y:763,t:1528139737475};\\\", \\\"{x:930,y:763,t:1528139737493};\\\", \\\"{x:930,y:762,t:1528139737510};\\\", \\\"{x:936,y:761,t:1528139737525};\\\", \\\"{x:944,y:758,t:1528139737542};\\\", \\\"{x:955,y:753,t:1528139737558};\\\", \\\"{x:958,y:751,t:1528139737575};\\\", \\\"{x:959,y:751,t:1528139737592};\\\", \\\"{x:962,y:750,t:1528139737609};\\\", \\\"{x:963,y:749,t:1528139737626};\\\", \\\"{x:965,y:748,t:1528139737642};\\\", \\\"{x:969,y:746,t:1528139737659};\\\", \\\"{x:973,y:742,t:1528139737676};\\\", \\\"{x:977,y:739,t:1528139737693};\\\", \\\"{x:978,y:737,t:1528139737709};\\\", \\\"{x:980,y:737,t:1528139737726};\\\", \\\"{x:981,y:736,t:1528139741119};\\\", \\\"{x:987,y:736,t:1528139741129};\\\", \\\"{x:1009,y:725,t:1528139741145};\\\", \\\"{x:1027,y:717,t:1528139741162};\\\", \\\"{x:1038,y:714,t:1528139741179};\\\", \\\"{x:1046,y:712,t:1528139741196};\\\", \\\"{x:1059,y:709,t:1528139741212};\\\", \\\"{x:1075,y:705,t:1528139741229};\\\", \\\"{x:1087,y:701,t:1528139741246};\\\", \\\"{x:1107,y:694,t:1528139741262};\\\", \\\"{x:1123,y:689,t:1528139741278};\\\", \\\"{x:1136,y:686,t:1528139741295};\\\", \\\"{x:1152,y:684,t:1528139741312};\\\", \\\"{x:1169,y:684,t:1528139741329};\\\", \\\"{x:1184,y:684,t:1528139741345};\\\", \\\"{x:1194,y:686,t:1528139741362};\\\", \\\"{x:1207,y:688,t:1528139741379};\\\", \\\"{x:1221,y:692,t:1528139741395};\\\", \\\"{x:1235,y:694,t:1528139741412};\\\", \\\"{x:1247,y:699,t:1528139741430};\\\", \\\"{x:1258,y:701,t:1528139741445};\\\", \\\"{x:1260,y:703,t:1528139741462};\\\", \\\"{x:1262,y:703,t:1528139741518};\\\", \\\"{x:1268,y:703,t:1528139741529};\\\", \\\"{x:1277,y:705,t:1528139741546};\\\", \\\"{x:1290,y:705,t:1528139741563};\\\", \\\"{x:1303,y:705,t:1528139741579};\\\", \\\"{x:1305,y:705,t:1528139741597};\\\", \\\"{x:1308,y:706,t:1528139741613};\\\", \\\"{x:1309,y:706,t:1528139741648};\\\", \\\"{x:1310,y:706,t:1528139741774};\\\", \\\"{x:1312,y:705,t:1528139741782};\\\", \\\"{x:1313,y:704,t:1528139741796};\\\", \\\"{x:1316,y:702,t:1528139741812};\\\", \\\"{x:1317,y:701,t:1528139741829};\\\", \\\"{x:1322,y:697,t:1528139741847};\\\", \\\"{x:1325,y:695,t:1528139741863};\\\", \\\"{x:1327,y:694,t:1528139741880};\\\", \\\"{x:1329,y:694,t:1528139741896};\\\", \\\"{x:1330,y:693,t:1528139741912};\\\", \\\"{x:1332,y:693,t:1528139741935};\\\", \\\"{x:1333,y:693,t:1528139742255};\\\", \\\"{x:1333,y:692,t:1528139742294};\\\", \\\"{x:1334,y:692,t:1528139742406};\\\", \\\"{x:1335,y:693,t:1528139742414};\\\", \\\"{x:1335,y:694,t:1528139742429};\\\", \\\"{x:1336,y:697,t:1528139742447};\\\", \\\"{x:1337,y:698,t:1528139742463};\\\", \\\"{x:1337,y:699,t:1528139742534};\\\", \\\"{x:1339,y:700,t:1528139742550};\\\", \\\"{x:1340,y:701,t:1528139742563};\\\", \\\"{x:1345,y:705,t:1528139742580};\\\", \\\"{x:1348,y:705,t:1528139742597};\\\", \\\"{x:1349,y:706,t:1528139742613};\\\", \\\"{x:1350,y:706,t:1528139742630};\\\", \\\"{x:1351,y:707,t:1528139742655};\\\", \\\"{x:1351,y:708,t:1528139742727};\\\", \\\"{x:1351,y:709,t:1528139742758};\\\", \\\"{x:1351,y:710,t:1528139742766};\\\", \\\"{x:1351,y:711,t:1528139742780};\\\", \\\"{x:1351,y:712,t:1528139742796};\\\", \\\"{x:1351,y:713,t:1528139742814};\\\", \\\"{x:1351,y:714,t:1528139742830};\\\", \\\"{x:1351,y:715,t:1528139742879};\\\", \\\"{x:1351,y:716,t:1528139742894};\\\", \\\"{x:1351,y:717,t:1528139742910};\\\", \\\"{x:1350,y:717,t:1528139742919};\\\", \\\"{x:1350,y:718,t:1528139742950};\\\", \\\"{x:1349,y:719,t:1528139742966};\\\", \\\"{x:1349,y:720,t:1528139742980};\\\", \\\"{x:1347,y:721,t:1528139742996};\\\", \\\"{x:1347,y:719,t:1528139743318};\\\", \\\"{x:1348,y:718,t:1528139743330};\\\", \\\"{x:1348,y:717,t:1528139743347};\\\", \\\"{x:1348,y:714,t:1528139743363};\\\", \\\"{x:1350,y:712,t:1528139743381};\\\", \\\"{x:1350,y:710,t:1528139743397};\\\", \\\"{x:1351,y:707,t:1528139743415};\\\", \\\"{x:1351,y:705,t:1528139743551};\\\", \\\"{x:1351,y:704,t:1528139743566};\\\", \\\"{x:1351,y:702,t:1528139743580};\\\", \\\"{x:1351,y:701,t:1528139743600};\\\", \\\"{x:1351,y:700,t:1528139743638};\\\", \\\"{x:1351,y:698,t:1528139743870};\\\", \\\"{x:1351,y:695,t:1528139743886};\\\", \\\"{x:1351,y:694,t:1528139743897};\\\", \\\"{x:1350,y:692,t:1528139743914};\\\", \\\"{x:1348,y:689,t:1528139743933};\\\", \\\"{x:1348,y:688,t:1528139743950};\\\", \\\"{x:1347,y:687,t:1528139744095};\\\", \\\"{x:1346,y:687,t:1528139744189};\\\", \\\"{x:1346,y:688,t:1528139744205};\\\", \\\"{x:1346,y:690,t:1528139744229};\\\", \\\"{x:1346,y:692,t:1528139744471};\\\", \\\"{x:1346,y:693,t:1528139744498};\\\", \\\"{x:1346,y:694,t:1528139744558};\\\", \\\"{x:1346,y:695,t:1528139744582};\\\", \\\"{x:1346,y:696,t:1528139744597};\\\", \\\"{x:1346,y:699,t:1528139744614};\\\", \\\"{x:1346,y:700,t:1528139744631};\\\", \\\"{x:1346,y:699,t:1528139745222};\\\", \\\"{x:1347,y:699,t:1528139745231};\\\", \\\"{x:1347,y:698,t:1528139745743};\\\", \\\"{x:1347,y:696,t:1528139745782};\\\", \\\"{x:1347,y:694,t:1528139745799};\\\", \\\"{x:1347,y:692,t:1528139745815};\\\", \\\"{x:1347,y:691,t:1528139745833};\\\", \\\"{x:1347,y:690,t:1528139745854};\\\", \\\"{x:1347,y:689,t:1528139745933};\\\", \\\"{x:1347,y:690,t:1528139746142};\\\", \\\"{x:1348,y:692,t:1528139746151};\\\", \\\"{x:1349,y:693,t:1528139746165};\\\", \\\"{x:1357,y:696,t:1528139746182};\\\", \\\"{x:1373,y:696,t:1528139746199};\\\", \\\"{x:1398,y:696,t:1528139746215};\\\", \\\"{x:1429,y:692,t:1528139746233};\\\", \\\"{x:1455,y:679,t:1528139746249};\\\", \\\"{x:1474,y:668,t:1528139746266};\\\", \\\"{x:1488,y:655,t:1528139746283};\\\", \\\"{x:1498,y:646,t:1528139746299};\\\", \\\"{x:1503,y:638,t:1528139746317};\\\", \\\"{x:1506,y:630,t:1528139746332};\\\", \\\"{x:1507,y:626,t:1528139746350};\\\", \\\"{x:1508,y:623,t:1528139746366};\\\", \\\"{x:1508,y:622,t:1528139746383};\\\", \\\"{x:1508,y:621,t:1528139746414};\\\", \\\"{x:1508,y:620,t:1528139746422};\\\", \\\"{x:1506,y:620,t:1528139746433};\\\", \\\"{x:1499,y:616,t:1528139746449};\\\", \\\"{x:1486,y:612,t:1528139746467};\\\", \\\"{x:1470,y:607,t:1528139746483};\\\", \\\"{x:1457,y:606,t:1528139746499};\\\", \\\"{x:1443,y:604,t:1528139746517};\\\", \\\"{x:1436,y:602,t:1528139746533};\\\", \\\"{x:1432,y:602,t:1528139746550};\\\", \\\"{x:1431,y:602,t:1528139746566};\\\", \\\"{x:1429,y:603,t:1528139746582};\\\", \\\"{x:1428,y:606,t:1528139746599};\\\", \\\"{x:1426,y:607,t:1528139746616};\\\", \\\"{x:1424,y:609,t:1528139746632};\\\", \\\"{x:1422,y:613,t:1528139746662};\\\", \\\"{x:1421,y:615,t:1528139746670};\\\", \\\"{x:1421,y:616,t:1528139746683};\\\", \\\"{x:1421,y:620,t:1528139746699};\\\", \\\"{x:1421,y:622,t:1528139746716};\\\", \\\"{x:1421,y:626,t:1528139746733};\\\", \\\"{x:1423,y:628,t:1528139746749};\\\", \\\"{x:1424,y:629,t:1528139746767};\\\", \\\"{x:1424,y:630,t:1528139746783};\\\", \\\"{x:1425,y:630,t:1528139746814};\\\", \\\"{x:1426,y:630,t:1528139746822};\\\", \\\"{x:1428,y:630,t:1528139746838};\\\", \\\"{x:1430,y:630,t:1528139746894};\\\", \\\"{x:1431,y:630,t:1528139746902};\\\", \\\"{x:1433,y:630,t:1528139746917};\\\", \\\"{x:1436,y:630,t:1528139746933};\\\", \\\"{x:1438,y:629,t:1528139746950};\\\", \\\"{x:1441,y:628,t:1528139746967};\\\", \\\"{x:1443,y:628,t:1528139747023};\\\", \\\"{x:1444,y:628,t:1528139747049};\\\", \\\"{x:1446,y:628,t:1528139747065};\\\", \\\"{x:1448,y:628,t:1528139747082};\\\", \\\"{x:1449,y:628,t:1528139747109};\\\", \\\"{x:1450,y:628,t:1528139747165};\\\", \\\"{x:1452,y:628,t:1528139747222};\\\", \\\"{x:1448,y:628,t:1528139747887};\\\", \\\"{x:1443,y:630,t:1528139747900};\\\", \\\"{x:1424,y:635,t:1528139747919};\\\", \\\"{x:1401,y:640,t:1528139747933};\\\", \\\"{x:1367,y:643,t:1528139747950};\\\", \\\"{x:1344,y:646,t:1528139747967};\\\", \\\"{x:1317,y:649,t:1528139747983};\\\", \\\"{x:1291,y:659,t:1528139748000};\\\", \\\"{x:1263,y:668,t:1528139748017};\\\", \\\"{x:1246,y:678,t:1528139748034};\\\", \\\"{x:1232,y:689,t:1528139748051};\\\", \\\"{x:1225,y:697,t:1528139748067};\\\", \\\"{x:1221,y:704,t:1528139748084};\\\", \\\"{x:1217,y:712,t:1528139748100};\\\", \\\"{x:1212,y:721,t:1528139748118};\\\", \\\"{x:1212,y:727,t:1528139748133};\\\", \\\"{x:1211,y:735,t:1528139748150};\\\", \\\"{x:1211,y:741,t:1528139748168};\\\", \\\"{x:1210,y:747,t:1528139748185};\\\", \\\"{x:1207,y:761,t:1528139748201};\\\", \\\"{x:1205,y:773,t:1528139748217};\\\", \\\"{x:1200,y:785,t:1528139748235};\\\", \\\"{x:1196,y:796,t:1528139748250};\\\", \\\"{x:1191,y:805,t:1528139748267};\\\", \\\"{x:1188,y:806,t:1528139748285};\\\", \\\"{x:1187,y:812,t:1528139748300};\\\", \\\"{x:1185,y:813,t:1528139748318};\\\", \\\"{x:1172,y:817,t:1528139748334};\\\", \\\"{x:1155,y:821,t:1528139748350};\\\", \\\"{x:1126,y:821,t:1528139748367};\\\", \\\"{x:1087,y:821,t:1528139748384};\\\", \\\"{x:1047,y:821,t:1528139748400};\\\", \\\"{x:952,y:818,t:1528139748417};\\\", \\\"{x:865,y:814,t:1528139748434};\\\", \\\"{x:752,y:800,t:1528139748451};\\\", \\\"{x:640,y:780,t:1528139748467};\\\", \\\"{x:565,y:771,t:1528139748484};\\\", \\\"{x:546,y:771,t:1528139748500};\\\", \\\"{x:539,y:771,t:1528139748517};\\\", \\\"{x:539,y:772,t:1528139748574};\\\", \\\"{x:546,y:773,t:1528139748584};\\\", \\\"{x:569,y:777,t:1528139748601};\\\", \\\"{x:601,y:789,t:1528139748617};\\\", \\\"{x:636,y:800,t:1528139748634};\\\", \\\"{x:699,y:812,t:1528139748651};\\\", \\\"{x:743,y:824,t:1528139748667};\\\", \\\"{x:774,y:831,t:1528139748684};\\\", \\\"{x:795,y:839,t:1528139748701};\\\", \\\"{x:804,y:840,t:1528139748717};\\\", \\\"{x:819,y:848,t:1528139748733};\\\", \\\"{x:825,y:855,t:1528139748752};\\\", \\\"{x:830,y:864,t:1528139748767};\\\", \\\"{x:841,y:876,t:1528139748784};\\\", \\\"{x:856,y:883,t:1528139748801};\\\", \\\"{x:897,y:894,t:1528139748817};\\\", \\\"{x:998,y:911,t:1528139748835};\\\", \\\"{x:1122,y:924,t:1528139748851};\\\", \\\"{x:1250,y:930,t:1528139748866};\\\", \\\"{x:1322,y:930,t:1528139748883};\\\", \\\"{x:1357,y:930,t:1528139748901};\\\", \\\"{x:1367,y:928,t:1528139748917};\\\", \\\"{x:1378,y:920,t:1528139748934};\\\", \\\"{x:1380,y:918,t:1528139748950};\\\", \\\"{x:1381,y:918,t:1528139748967};\\\", \\\"{x:1382,y:913,t:1528139748984};\\\", \\\"{x:1383,y:910,t:1528139749001};\\\", \\\"{x:1383,y:907,t:1528139749017};\\\", \\\"{x:1381,y:892,t:1528139749035};\\\", \\\"{x:1359,y:857,t:1528139749052};\\\", \\\"{x:1338,y:841,t:1528139749068};\\\", \\\"{x:1316,y:834,t:1528139749084};\\\", \\\"{x:1299,y:830,t:1528139749101};\\\", \\\"{x:1271,y:828,t:1528139749117};\\\", \\\"{x:1259,y:828,t:1528139749134};\\\", \\\"{x:1244,y:831,t:1528139749151};\\\", \\\"{x:1228,y:832,t:1528139749168};\\\", \\\"{x:1221,y:833,t:1528139749184};\\\", \\\"{x:1217,y:834,t:1528139749201};\\\", \\\"{x:1216,y:834,t:1528139749234};\\\", \\\"{x:1215,y:835,t:1528139749251};\\\", \\\"{x:1214,y:835,t:1528139749982};\\\", \\\"{x:1206,y:835,t:1528139749991};\\\", \\\"{x:1190,y:832,t:1528139750003};\\\", \\\"{x:1145,y:827,t:1528139750018};\\\", \\\"{x:1063,y:808,t:1528139750035};\\\", \\\"{x:963,y:790,t:1528139750053};\\\", \\\"{x:856,y:770,t:1528139750068};\\\", \\\"{x:792,y:749,t:1528139750085};\\\", \\\"{x:706,y:720,t:1528139750102};\\\", \\\"{x:665,y:710,t:1528139750118};\\\", \\\"{x:641,y:693,t:1528139750135};\\\", \\\"{x:628,y:689,t:1528139750152};\\\", \\\"{x:623,y:687,t:1528139750169};\\\", \\\"{x:622,y:687,t:1528139750185};\\\", \\\"{x:621,y:686,t:1528139767688};\\\", \\\"{x:622,y:681,t:1528139767695};\\\", \\\"{x:631,y:678,t:1528139767707};\\\", \\\"{x:645,y:654,t:1528139767724};\\\", \\\"{x:660,y:610,t:1528139767743};\\\", \\\"{x:671,y:586,t:1528139767757};\\\", \\\"{x:677,y:571,t:1528139767773};\\\", \\\"{x:685,y:542,t:1528139767793};\\\", \\\"{x:686,y:519,t:1528139767809};\\\", \\\"{x:687,y:488,t:1528139767827};\\\", \\\"{x:688,y:466,t:1528139767843};\\\", \\\"{x:700,y:425,t:1528139767860};\\\", \\\"{x:713,y:393,t:1528139767876};\\\", \\\"{x:726,y:371,t:1528139767893};\\\", \\\"{x:742,y:353,t:1528139767910};\\\", \\\"{x:764,y:338,t:1528139767926};\\\", \\\"{x:783,y:328,t:1528139767942};\\\", \\\"{x:795,y:326,t:1528139767959};\\\", \\\"{x:814,y:325,t:1528139767976};\\\", \\\"{x:836,y:325,t:1528139767993};\\\", \\\"{x:887,y:339,t:1528139768010};\\\", \\\"{x:939,y:352,t:1528139768026};\\\", \\\"{x:975,y:365,t:1528139768043};\\\", \\\"{x:981,y:373,t:1528139768060};\\\", \\\"{x:1025,y:393,t:1528139768077};\\\", \\\"{x:1086,y:421,t:1528139768094};\\\", \\\"{x:1143,y:452,t:1528139768111};\\\", \\\"{x:1201,y:487,t:1528139768127};\\\", \\\"{x:1234,y:516,t:1528139768144};\\\", \\\"{x:1251,y:545,t:1528139768160};\\\", \\\"{x:1267,y:572,t:1528139768178};\\\", \\\"{x:1276,y:586,t:1528139768193};\\\", \\\"{x:1282,y:592,t:1528139768211};\\\", \\\"{x:1285,y:592,t:1528139768227};\\\", \\\"{x:1289,y:592,t:1528139768243};\\\", \\\"{x:1292,y:592,t:1528139768261};\\\", \\\"{x:1294,y:592,t:1528139768277};\\\", \\\"{x:1295,y:592,t:1528139768408};\\\", \\\"{x:1296,y:592,t:1528139768439};\\\", \\\"{x:1296,y:591,t:1528139768448};\\\", \\\"{x:1296,y:590,t:1528139768461};\\\", \\\"{x:1299,y:586,t:1528139768477};\\\", \\\"{x:1299,y:583,t:1528139768494};\\\", \\\"{x:1299,y:580,t:1528139768511};\\\", \\\"{x:1299,y:579,t:1528139768552};\\\", \\\"{x:1298,y:577,t:1528139768567};\\\", \\\"{x:1297,y:577,t:1528139768591};\\\", \\\"{x:1293,y:574,t:1528139768599};\\\", \\\"{x:1292,y:574,t:1528139768631};\\\", \\\"{x:1292,y:573,t:1528139768645};\\\", \\\"{x:1291,y:572,t:1528139768928};\\\", \\\"{x:1290,y:570,t:1528139768945};\\\", \\\"{x:1288,y:567,t:1528139768983};\\\", \\\"{x:1288,y:566,t:1528139768995};\\\", \\\"{x:1287,y:564,t:1528139769012};\\\", \\\"{x:1285,y:560,t:1528139769028};\\\", \\\"{x:1284,y:559,t:1528139769044};\\\", \\\"{x:1283,y:559,t:1528139769061};\\\", \\\"{x:1283,y:558,t:1528139769087};\\\", \\\"{x:1279,y:557,t:1528139771320};\\\", \\\"{x:1254,y:558,t:1528139771331};\\\", \\\"{x:1209,y:559,t:1528139771347};\\\", \\\"{x:1153,y:553,t:1528139771364};\\\", \\\"{x:1040,y:548,t:1528139771380};\\\", \\\"{x:904,y:545,t:1528139771398};\\\", \\\"{x:778,y:523,t:1528139771414};\\\", \\\"{x:678,y:493,t:1528139771429};\\\", \\\"{x:540,y:443,t:1528139771446};\\\", \\\"{x:439,y:408,t:1528139771462};\\\", \\\"{x:393,y:383,t:1528139771479};\\\", \\\"{x:377,y:373,t:1528139771496};\\\", \\\"{x:375,y:372,t:1528139771512};\\\", \\\"{x:375,y:371,t:1528139771529};\\\", \\\"{x:375,y:372,t:1528139771550};\\\", \\\"{x:381,y:376,t:1528139771562};\\\", \\\"{x:394,y:384,t:1528139771579};\\\", \\\"{x:408,y:394,t:1528139771596};\\\", \\\"{x:414,y:400,t:1528139771612};\\\", \\\"{x:426,y:413,t:1528139771630};\\\", \\\"{x:442,y:433,t:1528139771646};\\\", \\\"{x:454,y:442,t:1528139771663};\\\", \\\"{x:464,y:447,t:1528139771679};\\\", \\\"{x:477,y:454,t:1528139771696};\\\", \\\"{x:497,y:460,t:1528139771713};\\\", \\\"{x:503,y:464,t:1528139771729};\\\", \\\"{x:519,y:469,t:1528139771746};\\\", \\\"{x:535,y:474,t:1528139771764};\\\", \\\"{x:542,y:476,t:1528139771779};\\\", \\\"{x:546,y:479,t:1528139771797};\\\", \\\"{x:549,y:479,t:1528139771813};\\\", \\\"{x:550,y:481,t:1528139771830};\\\", \\\"{x:553,y:483,t:1528139771846};\\\", \\\"{x:557,y:485,t:1528139771863};\\\", \\\"{x:561,y:487,t:1528139771880};\\\", \\\"{x:563,y:487,t:1528139771896};\\\", \\\"{x:566,y:490,t:1528139771913};\\\", \\\"{x:570,y:494,t:1528139771929};\\\", \\\"{x:581,y:498,t:1528139771946};\\\", \\\"{x:589,y:502,t:1528139771963};\\\", \\\"{x:592,y:504,t:1528139771980};\\\", \\\"{x:593,y:505,t:1528139771996};\\\", \\\"{x:596,y:505,t:1528139772519};\\\", \\\"{x:605,y:505,t:1528139772531};\\\", \\\"{x:631,y:512,t:1528139772548};\\\", \\\"{x:687,y:527,t:1528139772565};\\\", \\\"{x:767,y:547,t:1528139772581};\\\", \\\"{x:845,y:573,t:1528139772597};\\\", \\\"{x:910,y:594,t:1528139772614};\\\", \\\"{x:954,y:614,t:1528139772630};\\\", \\\"{x:966,y:619,t:1528139772647};\\\", \\\"{x:969,y:620,t:1528139772663};\\\", \\\"{x:968,y:622,t:1528139772766};\\\", \\\"{x:964,y:622,t:1528139772781};\\\", \\\"{x:953,y:622,t:1528139772797};\\\", \\\"{x:915,y:609,t:1528139772816};\\\", \\\"{x:862,y:584,t:1528139772831};\\\", \\\"{x:799,y:557,t:1528139772846};\\\", \\\"{x:748,y:531,t:1528139772863};\\\", \\\"{x:724,y:522,t:1528139772880};\\\", \\\"{x:707,y:510,t:1528139772898};\\\", \\\"{x:698,y:503,t:1528139772914};\\\", \\\"{x:694,y:501,t:1528139772930};\\\", \\\"{x:694,y:500,t:1528139772950};\\\", \\\"{x:692,y:500,t:1528139772998};\\\", \\\"{x:686,y:500,t:1528139773015};\\\", \\\"{x:678,y:501,t:1528139773030};\\\", \\\"{x:675,y:501,t:1528139773055};\\\", \\\"{x:673,y:501,t:1528139773064};\\\", \\\"{x:664,y:502,t:1528139773080};\\\", \\\"{x:653,y:505,t:1528139773097};\\\", \\\"{x:640,y:505,t:1528139773115};\\\", \\\"{x:638,y:505,t:1528139773130};\\\", \\\"{x:628,y:505,t:1528139773147};\\\", \\\"{x:624,y:504,t:1528139773165};\\\", \\\"{x:622,y:502,t:1528139773180};\\\", \\\"{x:620,y:502,t:1528139773199};\\\", \\\"{x:619,y:502,t:1528139773264};\\\", \\\"{x:617,y:502,t:1528139773271};\\\", \\\"{x:616,y:502,t:1528139773351};\\\", \\\"{x:615,y:502,t:1528139773430};\\\", \\\"{x:615,y:502,t:1528139773543};\\\", \\\"{x:623,y:502,t:1528139773622};\\\", \\\"{x:634,y:504,t:1528139773631};\\\", \\\"{x:661,y:510,t:1528139773648};\\\", \\\"{x:694,y:518,t:1528139773665};\\\", \\\"{x:750,y:527,t:1528139773682};\\\", \\\"{x:777,y:537,t:1528139773698};\\\", \\\"{x:808,y:554,t:1528139773714};\\\", \\\"{x:824,y:564,t:1528139773732};\\\", \\\"{x:850,y:575,t:1528139773748};\\\", \\\"{x:871,y:581,t:1528139773765};\\\", \\\"{x:880,y:585,t:1528139773781};\\\", \\\"{x:887,y:587,t:1528139773798};\\\", \\\"{x:882,y:585,t:1528139774006};\\\", \\\"{x:874,y:581,t:1528139774014};\\\", \\\"{x:861,y:575,t:1528139774032};\\\", \\\"{x:852,y:566,t:1528139774048};\\\", \\\"{x:846,y:561,t:1528139774065};\\\", \\\"{x:842,y:557,t:1528139774081};\\\", \\\"{x:841,y:555,t:1528139774098};\\\", \\\"{x:840,y:554,t:1528139774114};\\\", \\\"{x:839,y:551,t:1528139774131};\\\", \\\"{x:839,y:550,t:1528139774158};\\\", \\\"{x:839,y:549,t:1528139774198};\\\", \\\"{x:839,y:548,t:1528139774231};\\\", \\\"{x:839,y:547,t:1528139774246};\\\", \\\"{x:839,y:546,t:1528139774951};\\\", \\\"{x:859,y:549,t:1528139774967};\\\", \\\"{x:889,y:567,t:1528139774983};\\\", \\\"{x:913,y:581,t:1528139774999};\\\", \\\"{x:956,y:603,t:1528139775015};\\\", \\\"{x:1001,y:618,t:1528139775032};\\\", \\\"{x:1043,y:629,t:1528139775048};\\\", \\\"{x:1056,y:633,t:1528139775065};\\\", \\\"{x:1064,y:636,t:1528139775082};\\\", \\\"{x:1066,y:635,t:1528139775174};\\\", \\\"{x:1069,y:631,t:1528139775182};\\\", \\\"{x:1078,y:624,t:1528139775199};\\\", \\\"{x:1085,y:617,t:1528139775215};\\\", \\\"{x:1087,y:614,t:1528139775233};\\\", \\\"{x:1087,y:611,t:1528139775250};\\\", \\\"{x:1089,y:609,t:1528139775266};\\\", \\\"{x:1089,y:606,t:1528139775282};\\\", \\\"{x:1089,y:600,t:1528139775300};\\\", \\\"{x:1086,y:595,t:1528139775315};\\\", \\\"{x:1082,y:590,t:1528139775333};\\\", \\\"{x:1076,y:584,t:1528139775350};\\\", \\\"{x:1071,y:581,t:1528139775366};\\\", \\\"{x:1065,y:575,t:1528139775383};\\\", \\\"{x:1060,y:570,t:1528139775400};\\\", \\\"{x:1049,y:563,t:1528139775416};\\\", \\\"{x:1041,y:556,t:1528139775433};\\\", \\\"{x:1037,y:553,t:1528139775450};\\\", \\\"{x:1036,y:552,t:1528139775466};\\\", \\\"{x:1036,y:551,t:1528139775567};\\\", \\\"{x:1036,y:549,t:1528139775600};\\\", \\\"{x:1037,y:548,t:1528139775616};\\\", \\\"{x:1038,y:548,t:1528139775639};\\\", \\\"{x:1041,y:547,t:1528139775663};\\\", \\\"{x:1042,y:546,t:1528139775703};\\\", \\\"{x:1043,y:546,t:1528139775719};\\\", \\\"{x:1044,y:545,t:1528139775733};\\\", \\\"{x:1045,y:545,t:1528139775750};\\\", \\\"{x:1046,y:545,t:1528139775767};\\\", \\\"{x:1047,y:544,t:1528139775783};\\\", \\\"{x:1049,y:544,t:1528139775799};\\\", \\\"{x:1053,y:544,t:1528139775817};\\\", \\\"{x:1058,y:545,t:1528139775832};\\\", \\\"{x:1067,y:547,t:1528139775850};\\\", \\\"{x:1074,y:548,t:1528139775867};\\\", \\\"{x:1080,y:550,t:1528139775883};\\\", \\\"{x:1082,y:550,t:1528139775900};\\\", \\\"{x:1083,y:553,t:1528139775917};\\\", \\\"{x:1089,y:553,t:1528139775932};\\\", \\\"{x:1093,y:554,t:1528139775950};\\\", \\\"{x:1100,y:555,t:1528139775967};\\\", \\\"{x:1105,y:555,t:1528139775983};\\\", \\\"{x:1109,y:555,t:1528139775999};\\\", \\\"{x:1117,y:555,t:1528139776017};\\\", \\\"{x:1124,y:555,t:1528139776033};\\\", \\\"{x:1133,y:555,t:1528139776050};\\\", \\\"{x:1142,y:555,t:1528139776067};\\\", \\\"{x:1154,y:555,t:1528139776084};\\\", \\\"{x:1164,y:555,t:1528139776100};\\\", \\\"{x:1172,y:557,t:1528139776117};\\\", \\\"{x:1177,y:557,t:1528139776134};\\\", \\\"{x:1180,y:559,t:1528139776150};\\\", \\\"{x:1188,y:562,t:1528139776167};\\\", \\\"{x:1192,y:562,t:1528139776184};\\\", \\\"{x:1194,y:563,t:1528139776200};\\\", \\\"{x:1195,y:563,t:1528139776217};\\\", \\\"{x:1197,y:564,t:1528139776234};\\\", \\\"{x:1206,y:566,t:1528139776250};\\\", \\\"{x:1218,y:570,t:1528139776267};\\\", \\\"{x:1228,y:575,t:1528139776283};\\\", \\\"{x:1242,y:582,t:1528139776299};\\\", \\\"{x:1255,y:587,t:1528139776316};\\\", \\\"{x:1268,y:589,t:1528139776334};\\\", \\\"{x:1282,y:589,t:1528139776349};\\\", \\\"{x:1289,y:589,t:1528139776366};\\\", \\\"{x:1289,y:587,t:1528139776446};\\\", \\\"{x:1290,y:586,t:1528139776454};\\\", \\\"{x:1292,y:585,t:1528139776466};\\\", \\\"{x:1295,y:585,t:1528139776483};\\\", \\\"{x:1300,y:582,t:1528139776500};\\\", \\\"{x:1304,y:579,t:1528139776516};\\\", \\\"{x:1306,y:578,t:1528139776534};\\\", \\\"{x:1311,y:577,t:1528139776550};\\\", \\\"{x:1314,y:575,t:1528139776567};\\\", \\\"{x:1316,y:574,t:1528139776623};\\\", \\\"{x:1317,y:574,t:1528139776656};\\\", \\\"{x:1318,y:574,t:1528139776667};\\\", \\\"{x:1324,y:572,t:1528139776683};\\\", \\\"{x:1328,y:570,t:1528139776701};\\\", \\\"{x:1337,y:567,t:1528139776716};\\\", \\\"{x:1349,y:564,t:1528139776734};\\\", \\\"{x:1357,y:560,t:1528139776751};\\\", \\\"{x:1364,y:557,t:1528139776767};\\\", \\\"{x:1371,y:555,t:1528139776784};\\\", \\\"{x:1375,y:554,t:1528139776800};\\\", \\\"{x:1378,y:553,t:1528139776817};\\\", \\\"{x:1381,y:553,t:1528139776834};\\\", \\\"{x:1383,y:552,t:1528139776850};\\\", \\\"{x:1385,y:552,t:1528139776867};\\\", \\\"{x:1386,y:552,t:1528139776883};\\\", \\\"{x:1388,y:551,t:1528139776901};\\\", \\\"{x:1393,y:551,t:1528139776917};\\\", \\\"{x:1395,y:550,t:1528139776934};\\\", \\\"{x:1402,y:550,t:1528139776951};\\\", \\\"{x:1405,y:548,t:1528139776967};\\\", \\\"{x:1409,y:548,t:1528139776984};\\\", \\\"{x:1410,y:548,t:1528139777007};\\\", \\\"{x:1411,y:548,t:1528139777017};\\\", \\\"{x:1414,y:548,t:1528139777034};\\\", \\\"{x:1418,y:548,t:1528139777051};\\\", \\\"{x:1421,y:548,t:1528139777068};\\\", \\\"{x:1427,y:548,t:1528139777084};\\\", \\\"{x:1430,y:549,t:1528139777101};\\\", \\\"{x:1432,y:551,t:1528139777118};\\\", \\\"{x:1439,y:552,t:1528139777134};\\\", \\\"{x:1447,y:553,t:1528139777151};\\\", \\\"{x:1450,y:553,t:1528139777168};\\\", \\\"{x:1458,y:555,t:1528139777184};\\\", \\\"{x:1469,y:561,t:1528139777201};\\\", \\\"{x:1476,y:565,t:1528139777218};\\\", \\\"{x:1482,y:567,t:1528139777234};\\\", \\\"{x:1488,y:568,t:1528139777251};\\\", \\\"{x:1493,y:568,t:1528139777268};\\\", \\\"{x:1499,y:568,t:1528139777284};\\\", \\\"{x:1500,y:568,t:1528139777301};\\\", \\\"{x:1503,y:568,t:1528139777318};\\\", \\\"{x:1506,y:568,t:1528139777334};\\\", \\\"{x:1510,y:568,t:1528139777351};\\\", \\\"{x:1513,y:568,t:1528139777367};\\\", \\\"{x:1516,y:568,t:1528139777385};\\\", \\\"{x:1520,y:567,t:1528139777401};\\\", \\\"{x:1527,y:567,t:1528139777418};\\\", \\\"{x:1534,y:567,t:1528139777434};\\\", \\\"{x:1543,y:567,t:1528139777451};\\\", \\\"{x:1548,y:567,t:1528139777468};\\\", \\\"{x:1556,y:567,t:1528139777485};\\\", \\\"{x:1562,y:567,t:1528139777501};\\\", \\\"{x:1564,y:567,t:1528139777518};\\\", \\\"{x:1566,y:567,t:1528139777535};\\\", \\\"{x:1567,y:567,t:1528139777551};\\\", \\\"{x:1570,y:567,t:1528139777568};\\\", \\\"{x:1574,y:567,t:1528139777585};\\\", \\\"{x:1579,y:565,t:1528139777601};\\\", \\\"{x:1583,y:565,t:1528139777618};\\\", \\\"{x:1586,y:564,t:1528139777635};\\\", \\\"{x:1589,y:564,t:1528139777650};\\\", \\\"{x:1591,y:564,t:1528139777667};\\\", \\\"{x:1595,y:561,t:1528139777685};\\\", \\\"{x:1599,y:561,t:1528139777701};\\\", \\\"{x:1604,y:558,t:1528139777718};\\\", \\\"{x:1609,y:557,t:1528139777734};\\\", \\\"{x:1614,y:554,t:1528139777751};\\\", \\\"{x:1617,y:554,t:1528139777768};\\\", \\\"{x:1624,y:553,t:1528139777785};\\\", \\\"{x:1629,y:552,t:1528139777801};\\\", \\\"{x:1637,y:550,t:1528139777818};\\\", \\\"{x:1640,y:550,t:1528139777835};\\\", \\\"{x:1643,y:550,t:1528139777851};\\\", \\\"{x:1646,y:547,t:1528139777867};\\\", \\\"{x:1649,y:545,t:1528139777884};\\\", \\\"{x:1654,y:545,t:1528139777901};\\\", \\\"{x:1658,y:545,t:1528139777918};\\\", \\\"{x:1664,y:544,t:1528139777934};\\\", \\\"{x:1667,y:542,t:1528139777952};\\\", \\\"{x:1668,y:542,t:1528139777974};\\\", \\\"{x:1669,y:542,t:1528139777999};\\\", \\\"{x:1671,y:541,t:1528139778007};\\\", \\\"{x:1672,y:541,t:1528139778018};\\\", \\\"{x:1672,y:540,t:1528139778034};\\\", \\\"{x:1673,y:539,t:1528139778051};\\\", \\\"{x:1674,y:539,t:1528139778087};\\\", \\\"{x:1669,y:539,t:1528139778184};\\\", \\\"{x:1656,y:550,t:1528139778191};\\\", \\\"{x:1625,y:578,t:1528139778201};\\\", \\\"{x:1528,y:639,t:1528139778218};\\\", \\\"{x:1373,y:711,t:1528139778234};\\\", \\\"{x:1164,y:762,t:1528139778252};\\\", \\\"{x:939,y:812,t:1528139778268};\\\", \\\"{x:744,y:856,t:1528139778285};\\\", \\\"{x:650,y:867,t:1528139778302};\\\", \\\"{x:605,y:870,t:1528139778317};\\\", \\\"{x:580,y:866,t:1528139778334};\\\", \\\"{x:574,y:859,t:1528139778352};\\\", \\\"{x:574,y:857,t:1528139778374};\\\", \\\"{x:574,y:853,t:1528139778384};\\\", \\\"{x:576,y:849,t:1528139778402};\\\", \\\"{x:581,y:843,t:1528139778419};\\\", \\\"{x:588,y:838,t:1528139778434};\\\", \\\"{x:596,y:831,t:1528139778452};\\\", \\\"{x:600,y:825,t:1528139778468};\\\", \\\"{x:606,y:813,t:1528139778485};\\\", \\\"{x:609,y:801,t:1528139778501};\\\", \\\"{x:611,y:793,t:1528139778518};\\\", \\\"{x:611,y:786,t:1528139778534};\\\", \\\"{x:611,y:779,t:1528139778551};\\\", \\\"{x:608,y:774,t:1528139778568};\\\", \\\"{x:606,y:771,t:1528139778585};\\\", \\\"{x:605,y:767,t:1528139778601};\\\", \\\"{x:602,y:763,t:1528139778618};\\\", \\\"{x:599,y:759,t:1528139778634};\\\", \\\"{x:593,y:754,t:1528139778651};\\\", \\\"{x:584,y:748,t:1528139778668};\\\", \\\"{x:574,y:742,t:1528139778685};\\\", \\\"{x:560,y:736,t:1528139778703};\\\", \\\"{x:539,y:729,t:1528139778718};\\\", \\\"{x:522,y:724,t:1528139778734};\\\", \\\"{x:509,y:720,t:1528139778751};\\\", \\\"{x:499,y:717,t:1528139778769};\\\", \\\"{x:496,y:716,t:1528139778785};\\\", \\\"{x:494,y:716,t:1528139778802};\\\", \\\"{x:493,y:716,t:1528139778818};\\\", \\\"{x:492,y:717,t:1528139779023};\\\", \\\"{x:492,y:719,t:1528139779038};\\\", \\\"{x:493,y:723,t:1528139779054};\\\", \\\"{x:493,y:729,t:1528139779551};\\\", \\\"{x:493,y:735,t:1528139779558};\\\", \\\"{x:493,y:745,t:1528139779569};\\\", \\\"{x:491,y:764,t:1528139779585};\\\", \\\"{x:493,y:790,t:1528139779602};\\\", \\\"{x:503,y:817,t:1528139779619};\\\", \\\"{x:516,y:837,t:1528139779635};\\\", \\\"{x:530,y:870,t:1528139779653};\\\", \\\"{x:552,y:911,t:1528139779669};\\\", \\\"{x:575,y:942,t:1528139779685};\\\", \\\"{x:598,y:983,t:1528139779702};\\\", \\\"{x:609,y:1001,t:1528139779719};\\\", \\\"{x:617,y:1015,t:1528139779735};\\\", \\\"{x:620,y:1017,t:1528139779752};\\\", \\\"{x:621,y:1018,t:1528139779769};\\\", \\\"{x:621,y:1016,t:1528139779863};\\\", \\\"{x:621,y:1015,t:1528139779871};\\\", \\\"{x:620,y:1014,t:1528139779886};\\\" ] }, { \\\"rt\\\": 77450, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 692080, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -10 AM-10 AM-F -F -F -F -F -I -11 AM-M -M -M -M -01 PM-12 PM-M -M -M -B -B -N -N -O -X -X -X -O -J -X -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:621,y:1011,t:1528139782319};\\\", \\\"{x:627,y:999,t:1528139782326};\\\", \\\"{x:628,y:992,t:1528139782338};\\\", \\\"{x:633,y:981,t:1528139782355};\\\", \\\"{x:637,y:970,t:1528139782372};\\\", \\\"{x:643,y:955,t:1528139782388};\\\", \\\"{x:647,y:936,t:1528139782405};\\\", \\\"{x:649,y:924,t:1528139782422};\\\", \\\"{x:651,y:913,t:1528139782438};\\\", \\\"{x:657,y:891,t:1528139782454};\\\", \\\"{x:658,y:880,t:1528139782472};\\\", \\\"{x:658,y:863,t:1528139782488};\\\", \\\"{x:661,y:844,t:1528139782504};\\\", \\\"{x:665,y:828,t:1528139782522};\\\", \\\"{x:665,y:822,t:1528139782538};\\\", \\\"{x:666,y:805,t:1528139782554};\\\", \\\"{x:666,y:788,t:1528139782572};\\\", \\\"{x:668,y:771,t:1528139782588};\\\", \\\"{x:667,y:765,t:1528139782605};\\\", \\\"{x:662,y:762,t:1528139782622};\\\", \\\"{x:631,y:749,t:1528139782639};\\\", \\\"{x:605,y:737,t:1528139782655};\\\", \\\"{x:578,y:727,t:1528139782672};\\\", \\\"{x:553,y:722,t:1528139782691};\\\", \\\"{x:529,y:715,t:1528139782705};\\\", \\\"{x:512,y:711,t:1528139782721};\\\", \\\"{x:497,y:708,t:1528139782739};\\\", \\\"{x:477,y:702,t:1528139782755};\\\", \\\"{x:463,y:694,t:1528139782772};\\\", \\\"{x:448,y:689,t:1528139782788};\\\", \\\"{x:443,y:688,t:1528139782805};\\\", \\\"{x:442,y:685,t:1528139782830};\\\", \\\"{x:445,y:674,t:1528139782838};\\\", \\\"{x:456,y:651,t:1528139782856};\\\", \\\"{x:458,y:632,t:1528139782872};\\\", \\\"{x:447,y:594,t:1528139782888};\\\", \\\"{x:430,y:558,t:1528139782904};\\\", \\\"{x:417,y:529,t:1528139782923};\\\", \\\"{x:406,y:512,t:1528139782939};\\\", \\\"{x:398,y:497,t:1528139782954};\\\", \\\"{x:393,y:486,t:1528139782972};\\\", \\\"{x:387,y:478,t:1528139782989};\\\", \\\"{x:382,y:469,t:1528139783005};\\\", \\\"{x:373,y:456,t:1528139783022};\\\", \\\"{x:369,y:451,t:1528139783039};\\\", \\\"{x:368,y:450,t:1528139783055};\\\", \\\"{x:366,y:450,t:1528139783255};\\\", \\\"{x:363,y:450,t:1528139783262};\\\", \\\"{x:359,y:450,t:1528139783273};\\\", \\\"{x:354,y:450,t:1528139783290};\\\", \\\"{x:352,y:450,t:1528139783307};\\\", \\\"{x:353,y:450,t:1528139783399};\\\", \\\"{x:356,y:448,t:1528139783406};\\\", \\\"{x:359,y:447,t:1528139783424};\\\", \\\"{x:363,y:446,t:1528139783440};\\\", \\\"{x:365,y:444,t:1528139783457};\\\", \\\"{x:367,y:444,t:1528139783474};\\\", \\\"{x:370,y:444,t:1528139783491};\\\", \\\"{x:373,y:444,t:1528139783507};\\\", \\\"{x:377,y:444,t:1528139783524};\\\", \\\"{x:390,y:444,t:1528139783541};\\\", \\\"{x:406,y:445,t:1528139783558};\\\", \\\"{x:428,y:449,t:1528139783575};\\\", \\\"{x:441,y:451,t:1528139783590};\\\", \\\"{x:452,y:453,t:1528139783608};\\\", \\\"{x:460,y:455,t:1528139783624};\\\", \\\"{x:462,y:456,t:1528139783641};\\\", \\\"{x:463,y:457,t:1528139783807};\\\", \\\"{x:464,y:456,t:1528139783894};\\\", \\\"{x:466,y:455,t:1528139783909};\\\", \\\"{x:467,y:454,t:1528139783924};\\\", \\\"{x:468,y:454,t:1528139783941};\\\", \\\"{x:472,y:453,t:1528139783957};\\\", \\\"{x:475,y:453,t:1528139783976};\\\", \\\"{x:479,y:453,t:1528139783991};\\\", \\\"{x:484,y:453,t:1528139784008};\\\", \\\"{x:486,y:453,t:1528139784025};\\\", \\\"{x:489,y:453,t:1528139784042};\\\", \\\"{x:492,y:453,t:1528139784059};\\\", \\\"{x:498,y:451,t:1528139784076};\\\", \\\"{x:502,y:451,t:1528139784092};\\\", \\\"{x:505,y:451,t:1528139784109};\\\", \\\"{x:508,y:451,t:1528139784126};\\\", \\\"{x:512,y:450,t:1528139784142};\\\", \\\"{x:514,y:450,t:1528139784160};\\\", \\\"{x:518,y:448,t:1528139784176};\\\", \\\"{x:519,y:448,t:1528139784193};\\\", \\\"{x:523,y:447,t:1528139784209};\\\", \\\"{x:525,y:446,t:1528139784225};\\\", \\\"{x:530,y:446,t:1528139784242};\\\", \\\"{x:534,y:446,t:1528139784259};\\\", \\\"{x:543,y:444,t:1528139784277};\\\", \\\"{x:553,y:444,t:1528139784293};\\\", \\\"{x:563,y:443,t:1528139784309};\\\", \\\"{x:583,y:442,t:1528139784326};\\\", \\\"{x:600,y:439,t:1528139784343};\\\", \\\"{x:613,y:437,t:1528139784359};\\\", \\\"{x:625,y:434,t:1528139784377};\\\", \\\"{x:626,y:433,t:1528139784393};\\\", \\\"{x:628,y:433,t:1528139784410};\\\", \\\"{x:629,y:434,t:1528139784590};\\\", \\\"{x:630,y:434,t:1528139784599};\\\", \\\"{x:632,y:435,t:1528139784611};\\\", \\\"{x:635,y:437,t:1528139784628};\\\", \\\"{x:637,y:437,t:1528139784644};\\\", \\\"{x:638,y:437,t:1528139784661};\\\", \\\"{x:639,y:438,t:1528139784687};\\\", \\\"{x:640,y:438,t:1528139784711};\\\", \\\"{x:641,y:439,t:1528139784767};\\\", \\\"{x:642,y:439,t:1528139784782};\\\", \\\"{x:642,y:440,t:1528139784798};\\\", \\\"{x:643,y:440,t:1528139784812};\\\", \\\"{x:651,y:442,t:1528139784828};\\\", \\\"{x:661,y:444,t:1528139784845};\\\", \\\"{x:670,y:444,t:1528139784862};\\\", \\\"{x:677,y:445,t:1528139784878};\\\", \\\"{x:685,y:448,t:1528139784895};\\\", \\\"{x:689,y:449,t:1528139784912};\\\", \\\"{x:691,y:450,t:1528139784929};\\\", \\\"{x:692,y:450,t:1528139785071};\\\", \\\"{x:692,y:452,t:1528139785078};\\\", \\\"{x:685,y:453,t:1528139785096};\\\", \\\"{x:681,y:456,t:1528139785113};\\\", \\\"{x:680,y:456,t:1528139785129};\\\", \\\"{x:680,y:455,t:1528139785527};\\\", \\\"{x:684,y:454,t:1528139785534};\\\", \\\"{x:685,y:454,t:1528139785548};\\\", \\\"{x:704,y:456,t:1528139785564};\\\", \\\"{x:727,y:457,t:1528139785581};\\\", \\\"{x:748,y:461,t:1528139785598};\\\", \\\"{x:783,y:461,t:1528139785614};\\\", \\\"{x:814,y:470,t:1528139785631};\\\", \\\"{x:840,y:481,t:1528139785648};\\\", \\\"{x:863,y:494,t:1528139785665};\\\", \\\"{x:879,y:501,t:1528139785681};\\\", \\\"{x:890,y:508,t:1528139785697};\\\", \\\"{x:910,y:519,t:1528139785720};\\\", \\\"{x:917,y:526,t:1528139785737};\\\", \\\"{x:921,y:530,t:1528139785754};\\\", \\\"{x:926,y:537,t:1528139785774};\\\", \\\"{x:951,y:564,t:1528139785791};\\\", \\\"{x:973,y:585,t:1528139785807};\\\", \\\"{x:1003,y:614,t:1528139785824};\\\", \\\"{x:1033,y:641,t:1528139785841};\\\", \\\"{x:1068,y:667,t:1528139785857};\\\", \\\"{x:1088,y:681,t:1528139785875};\\\", \\\"{x:1104,y:692,t:1528139785891};\\\", \\\"{x:1114,y:697,t:1528139785908};\\\", \\\"{x:1116,y:697,t:1528139785925};\\\", \\\"{x:1117,y:697,t:1528139786031};\\\", \\\"{x:1116,y:694,t:1528139786041};\\\", \\\"{x:1110,y:685,t:1528139786059};\\\", \\\"{x:1092,y:668,t:1528139786075};\\\", \\\"{x:1074,y:656,t:1528139786091};\\\", \\\"{x:1066,y:647,t:1528139786108};\\\", \\\"{x:1060,y:643,t:1528139786125};\\\", \\\"{x:1059,y:642,t:1528139786141};\\\", \\\"{x:1057,y:641,t:1528139786159};\\\", \\\"{x:1055,y:639,t:1528139786175};\\\", \\\"{x:1053,y:638,t:1528139786392};\\\", \\\"{x:1053,y:637,t:1528139786447};\\\", \\\"{x:1053,y:636,t:1528139786462};\\\", \\\"{x:1053,y:634,t:1528139786478};\\\", \\\"{x:1053,y:633,t:1528139786559};\\\", \\\"{x:1053,y:632,t:1528139786712};\\\", \\\"{x:1053,y:631,t:1528139787759};\\\", \\\"{x:1056,y:640,t:1528139787776};\\\", \\\"{x:1062,y:649,t:1528139787793};\\\", \\\"{x:1069,y:658,t:1528139787810};\\\", \\\"{x:1076,y:666,t:1528139787825};\\\", \\\"{x:1079,y:670,t:1528139787842};\\\", \\\"{x:1079,y:671,t:1528139787860};\\\", \\\"{x:1080,y:672,t:1528139787878};\\\", \\\"{x:1080,y:673,t:1528139787918};\\\", \\\"{x:1080,y:675,t:1528139787926};\\\", \\\"{x:1080,y:676,t:1528139787943};\\\", \\\"{x:1080,y:678,t:1528139787960};\\\", \\\"{x:1081,y:681,t:1528139787976};\\\", \\\"{x:1081,y:683,t:1528139787992};\\\", \\\"{x:1081,y:685,t:1528139788009};\\\", \\\"{x:1081,y:690,t:1528139788026};\\\", \\\"{x:1081,y:694,t:1528139788043};\\\", \\\"{x:1082,y:697,t:1528139788060};\\\", \\\"{x:1082,y:698,t:1528139788078};\\\", \\\"{x:1082,y:699,t:1528139788183};\\\", \\\"{x:1082,y:700,t:1528139788199};\\\", \\\"{x:1082,y:701,t:1528139788230};\\\", \\\"{x:1083,y:701,t:1528139791367};\\\", \\\"{x:1089,y:696,t:1528139791380};\\\", \\\"{x:1093,y:693,t:1528139791396};\\\", \\\"{x:1098,y:691,t:1528139791413};\\\", \\\"{x:1107,y:684,t:1528139791429};\\\", \\\"{x:1128,y:679,t:1528139791446};\\\", \\\"{x:1143,y:679,t:1528139791463};\\\", \\\"{x:1156,y:679,t:1528139791480};\\\", \\\"{x:1171,y:681,t:1528139791496};\\\", \\\"{x:1182,y:684,t:1528139791513};\\\", \\\"{x:1189,y:684,t:1528139791531};\\\", \\\"{x:1193,y:686,t:1528139791547};\\\", \\\"{x:1195,y:687,t:1528139791564};\\\", \\\"{x:1196,y:687,t:1528139791639};\\\", \\\"{x:1197,y:687,t:1528139791646};\\\", \\\"{x:1202,y:687,t:1528139791663};\\\", \\\"{x:1205,y:688,t:1528139791681};\\\", \\\"{x:1209,y:689,t:1528139791696};\\\", \\\"{x:1215,y:691,t:1528139791714};\\\", \\\"{x:1219,y:692,t:1528139791730};\\\", \\\"{x:1221,y:692,t:1528139791746};\\\", \\\"{x:1223,y:692,t:1528139791763};\\\", \\\"{x:1225,y:692,t:1528139791780};\\\", \\\"{x:1226,y:692,t:1528139791855};\\\", \\\"{x:1227,y:692,t:1528139791870};\\\", \\\"{x:1228,y:692,t:1528139791895};\\\", \\\"{x:1231,y:693,t:1528139791903};\\\", \\\"{x:1235,y:693,t:1528139791913};\\\", \\\"{x:1239,y:695,t:1528139791931};\\\", \\\"{x:1243,y:695,t:1528139791948};\\\", \\\"{x:1253,y:695,t:1528139791964};\\\", \\\"{x:1265,y:695,t:1528139791980};\\\", \\\"{x:1274,y:695,t:1528139791998};\\\", \\\"{x:1277,y:696,t:1528139792013};\\\", \\\"{x:1282,y:697,t:1528139792031};\\\", \\\"{x:1283,y:697,t:1528139792055};\\\", \\\"{x:1284,y:697,t:1528139792070};\\\", \\\"{x:1286,y:697,t:1528139792081};\\\", \\\"{x:1289,y:699,t:1528139792098};\\\", \\\"{x:1291,y:699,t:1528139792113};\\\", \\\"{x:1293,y:700,t:1528139792134};\\\", \\\"{x:1294,y:700,t:1528139792147};\\\", \\\"{x:1295,y:701,t:1528139792163};\\\", \\\"{x:1296,y:701,t:1528139792180};\\\", \\\"{x:1297,y:701,t:1528139792197};\\\", \\\"{x:1300,y:702,t:1528139792214};\\\", \\\"{x:1310,y:707,t:1528139792231};\\\", \\\"{x:1317,y:707,t:1528139792247};\\\", \\\"{x:1324,y:707,t:1528139792263};\\\", \\\"{x:1327,y:707,t:1528139792280};\\\", \\\"{x:1328,y:707,t:1528139792318};\\\", \\\"{x:1329,y:707,t:1528139792331};\\\", \\\"{x:1330,y:706,t:1528139792399};\\\", \\\"{x:1331,y:706,t:1528139792414};\\\", \\\"{x:1332,y:705,t:1528139792430};\\\", \\\"{x:1332,y:704,t:1528139792448};\\\", \\\"{x:1333,y:703,t:1528139792567};\\\", \\\"{x:1333,y:702,t:1528139792647};\\\", \\\"{x:1333,y:701,t:1528139792678};\\\", \\\"{x:1335,y:700,t:1528139792686};\\\", \\\"{x:1335,y:699,t:1528139792702};\\\", \\\"{x:1336,y:699,t:1528139792714};\\\", \\\"{x:1337,y:699,t:1528139792731};\\\", \\\"{x:1339,y:698,t:1528139792748};\\\", \\\"{x:1343,y:697,t:1528139792767};\\\", \\\"{x:1344,y:697,t:1528139792797};\\\", \\\"{x:1345,y:696,t:1528139792814};\\\", \\\"{x:1346,y:696,t:1528139792831};\\\", \\\"{x:1347,y:696,t:1528139792846};\\\", \\\"{x:1348,y:696,t:1528139792864};\\\", \\\"{x:1350,y:694,t:1528139792881};\\\", \\\"{x:1351,y:693,t:1528139792926};\\\", \\\"{x:1352,y:693,t:1528139807239};\\\", \\\"{x:1351,y:693,t:1528139807246};\\\", \\\"{x:1349,y:693,t:1528139807263};\\\", \\\"{x:1348,y:693,t:1528139807278};\\\", \\\"{x:1347,y:693,t:1528139807294};\\\", \\\"{x:1344,y:694,t:1528139807694};\\\", \\\"{x:1343,y:695,t:1528139809670};\\\", \\\"{x:1341,y:696,t:1528139809682};\\\", \\\"{x:1322,y:713,t:1528139809697};\\\", \\\"{x:1302,y:736,t:1528139809713};\\\", \\\"{x:1279,y:758,t:1528139809730};\\\", \\\"{x:1265,y:771,t:1528139809747};\\\", \\\"{x:1253,y:789,t:1528139809763};\\\", \\\"{x:1245,y:802,t:1528139809780};\\\", \\\"{x:1240,y:819,t:1528139809797};\\\", \\\"{x:1232,y:847,t:1528139809813};\\\", \\\"{x:1226,y:912,t:1528139809831};\\\", \\\"{x:1224,y:973,t:1528139809846};\\\", \\\"{x:1216,y:1032,t:1528139809864};\\\", \\\"{x:1216,y:1062,t:1528139809880};\\\", \\\"{x:1216,y:1082,t:1528139809896};\\\", \\\"{x:1218,y:1095,t:1528139809913};\\\", \\\"{x:1218,y:1102,t:1528139809930};\\\", \\\"{x:1220,y:1105,t:1528139809947};\\\", \\\"{x:1220,y:1107,t:1528139809964};\\\", \\\"{x:1222,y:1107,t:1528139810022};\\\", \\\"{x:1226,y:1106,t:1528139810030};\\\", \\\"{x:1229,y:1088,t:1528139810047};\\\", \\\"{x:1229,y:1068,t:1528139810064};\\\", \\\"{x:1226,y:1049,t:1528139810081};\\\", \\\"{x:1218,y:1032,t:1528139810097};\\\", \\\"{x:1208,y:1012,t:1528139810114};\\\", \\\"{x:1200,y:999,t:1528139810130};\\\", \\\"{x:1198,y:990,t:1528139810147};\\\", \\\"{x:1195,y:983,t:1528139810165};\\\", \\\"{x:1195,y:980,t:1528139810180};\\\", \\\"{x:1195,y:979,t:1528139810197};\\\", \\\"{x:1195,y:978,t:1528139810335};\\\", \\\"{x:1196,y:978,t:1528139810347};\\\", \\\"{x:1197,y:978,t:1528139810364};\\\", \\\"{x:1197,y:976,t:1528139810381};\\\", \\\"{x:1198,y:975,t:1528139810398};\\\", \\\"{x:1201,y:973,t:1528139810414};\\\", \\\"{x:1207,y:968,t:1528139810431};\\\", \\\"{x:1209,y:967,t:1528139810447};\\\", \\\"{x:1213,y:964,t:1528139810464};\\\", \\\"{x:1214,y:963,t:1528139810481};\\\", \\\"{x:1216,y:963,t:1528139810498};\\\", \\\"{x:1217,y:961,t:1528139810550};\\\", \\\"{x:1218,y:958,t:1528139811191};\\\", \\\"{x:1220,y:954,t:1528139811198};\\\", \\\"{x:1222,y:950,t:1528139811214};\\\", \\\"{x:1227,y:944,t:1528139811231};\\\", \\\"{x:1230,y:941,t:1528139811248};\\\", \\\"{x:1235,y:936,t:1528139811265};\\\", \\\"{x:1238,y:932,t:1528139811280};\\\", \\\"{x:1241,y:930,t:1528139811298};\\\", \\\"{x:1244,y:927,t:1528139811315};\\\", \\\"{x:1246,y:925,t:1528139811331};\\\", \\\"{x:1248,y:923,t:1528139811348};\\\", \\\"{x:1250,y:921,t:1528139811365};\\\", \\\"{x:1250,y:920,t:1528139811381};\\\", \\\"{x:1250,y:919,t:1528139811414};\\\", \\\"{x:1251,y:919,t:1528139811431};\\\", \\\"{x:1252,y:916,t:1528139811462};\\\", \\\"{x:1254,y:914,t:1528139811486};\\\", \\\"{x:1255,y:912,t:1528139811498};\\\", \\\"{x:1255,y:910,t:1528139811519};\\\", \\\"{x:1255,y:907,t:1528139811533};\\\", \\\"{x:1255,y:903,t:1528139811548};\\\", \\\"{x:1259,y:898,t:1528139811565};\\\", \\\"{x:1260,y:890,t:1528139811581};\\\", \\\"{x:1262,y:885,t:1528139811598};\\\", \\\"{x:1264,y:878,t:1528139811615};\\\", \\\"{x:1267,y:874,t:1528139811631};\\\", \\\"{x:1267,y:871,t:1528139811648};\\\", \\\"{x:1269,y:866,t:1528139811664};\\\", \\\"{x:1270,y:859,t:1528139811681};\\\", \\\"{x:1271,y:853,t:1528139811697};\\\", \\\"{x:1272,y:850,t:1528139811715};\\\", \\\"{x:1272,y:844,t:1528139811732};\\\", \\\"{x:1273,y:840,t:1528139811748};\\\", \\\"{x:1274,y:836,t:1528139811764};\\\", \\\"{x:1275,y:832,t:1528139811781};\\\", \\\"{x:1278,y:827,t:1528139811797};\\\", \\\"{x:1280,y:825,t:1528139811814};\\\", \\\"{x:1281,y:821,t:1528139811831};\\\", \\\"{x:1284,y:815,t:1528139811849};\\\", \\\"{x:1284,y:813,t:1528139811865};\\\", \\\"{x:1286,y:811,t:1528139811882};\\\", \\\"{x:1289,y:807,t:1528139811899};\\\", \\\"{x:1290,y:804,t:1528139811915};\\\", \\\"{x:1292,y:801,t:1528139811931};\\\", \\\"{x:1293,y:797,t:1528139811949};\\\", \\\"{x:1294,y:796,t:1528139811965};\\\", \\\"{x:1302,y:788,t:1528139811982};\\\", \\\"{x:1308,y:779,t:1528139811998};\\\", \\\"{x:1311,y:775,t:1528139812015};\\\", \\\"{x:1315,y:769,t:1528139812032};\\\", \\\"{x:1318,y:766,t:1528139812049};\\\", \\\"{x:1323,y:762,t:1528139812065};\\\", \\\"{x:1329,y:757,t:1528139812082};\\\", \\\"{x:1333,y:753,t:1528139812099};\\\", \\\"{x:1335,y:751,t:1528139812115};\\\", \\\"{x:1339,y:744,t:1528139812132};\\\", \\\"{x:1341,y:742,t:1528139812149};\\\", \\\"{x:1343,y:737,t:1528139812165};\\\", \\\"{x:1344,y:737,t:1528139812182};\\\", \\\"{x:1345,y:737,t:1528139812199};\\\", \\\"{x:1347,y:735,t:1528139812215};\\\", \\\"{x:1348,y:733,t:1528139812232};\\\", \\\"{x:1350,y:731,t:1528139812249};\\\", \\\"{x:1353,y:730,t:1528139812266};\\\", \\\"{x:1353,y:729,t:1528139812284};\\\", \\\"{x:1354,y:727,t:1528139812299};\\\", \\\"{x:1356,y:725,t:1528139812315};\\\", \\\"{x:1356,y:723,t:1528139812331};\\\", \\\"{x:1357,y:723,t:1528139812365};\\\", \\\"{x:1358,y:722,t:1528139812381};\\\", \\\"{x:1360,y:718,t:1528139812398};\\\", \\\"{x:1361,y:712,t:1528139812415};\\\", \\\"{x:1362,y:707,t:1528139812431};\\\", \\\"{x:1362,y:705,t:1528139812448};\\\", \\\"{x:1362,y:702,t:1528139812466};\\\", \\\"{x:1362,y:700,t:1528139812481};\\\", \\\"{x:1362,y:698,t:1528139812509};\\\", \\\"{x:1361,y:697,t:1528139812541};\\\", \\\"{x:1358,y:697,t:1528139813006};\\\", \\\"{x:1356,y:697,t:1528139813046};\\\", \\\"{x:1353,y:697,t:1528139813071};\\\", \\\"{x:1350,y:698,t:1528139813100};\\\", \\\"{x:1346,y:698,t:1528139813116};\\\", \\\"{x:1342,y:698,t:1528139813133};\\\", \\\"{x:1336,y:698,t:1528139813151};\\\", \\\"{x:1335,y:698,t:1528139813166};\\\", \\\"{x:1333,y:698,t:1528139813183};\\\", \\\"{x:1332,y:699,t:1528139813200};\\\", \\\"{x:1330,y:700,t:1528139813216};\\\", \\\"{x:1329,y:700,t:1528139813238};\\\", \\\"{x:1329,y:701,t:1528139813254};\\\", \\\"{x:1331,y:701,t:1528139813622};\\\", \\\"{x:1332,y:701,t:1528139813646};\\\", \\\"{x:1333,y:701,t:1528139813678};\\\", \\\"{x:1333,y:700,t:1528139813686};\\\", \\\"{x:1335,y:699,t:1528139813710};\\\", \\\"{x:1335,y:698,t:1528139813718};\\\", \\\"{x:1336,y:698,t:1528139813750};\\\", \\\"{x:1336,y:696,t:1528139813767};\\\", \\\"{x:1338,y:694,t:1528139813785};\\\", \\\"{x:1339,y:693,t:1528139813806};\\\", \\\"{x:1340,y:692,t:1528139813817};\\\", \\\"{x:1340,y:691,t:1528139813837};\\\", \\\"{x:1341,y:691,t:1528139813853};\\\", \\\"{x:1341,y:690,t:1528139813877};\\\", \\\"{x:1343,y:690,t:1528139817287};\\\", \\\"{x:1345,y:690,t:1528139817303};\\\", \\\"{x:1348,y:689,t:1528139817390};\\\", \\\"{x:1349,y:689,t:1528139817414};\\\", \\\"{x:1350,y:689,t:1528139817439};\\\", \\\"{x:1350,y:690,t:1528139817742};\\\", \\\"{x:1349,y:690,t:1528139817758};\\\", \\\"{x:1348,y:692,t:1528139817771};\\\", \\\"{x:1343,y:696,t:1528139817787};\\\", \\\"{x:1340,y:697,t:1528139817804};\\\", \\\"{x:1336,y:700,t:1528139817819};\\\", \\\"{x:1335,y:701,t:1528139817836};\\\", \\\"{x:1334,y:701,t:1528139817853};\\\", \\\"{x:1335,y:701,t:1528139818102};\\\", \\\"{x:1336,y:701,t:1528139818110};\\\", \\\"{x:1337,y:701,t:1528139818127};\\\", \\\"{x:1338,y:701,t:1528139818137};\\\", \\\"{x:1340,y:701,t:1528139818155};\\\", \\\"{x:1342,y:701,t:1528139818494};\\\", \\\"{x:1342,y:700,t:1528139818534};\\\", \\\"{x:1343,y:700,t:1528139818558};\\\", \\\"{x:1343,y:699,t:1528139818631};\\\", \\\"{x:1344,y:699,t:1528139818638};\\\", \\\"{x:1345,y:699,t:1528139818655};\\\", \\\"{x:1343,y:699,t:1528139818990};\\\", \\\"{x:1341,y:699,t:1528139819007};\\\", \\\"{x:1333,y:699,t:1528139819021};\\\", \\\"{x:1311,y:709,t:1528139819038};\\\", \\\"{x:1288,y:726,t:1528139819055};\\\", \\\"{x:1253,y:746,t:1528139819073};\\\", \\\"{x:1236,y:755,t:1528139819089};\\\", \\\"{x:1217,y:764,t:1528139819105};\\\", \\\"{x:1203,y:772,t:1528139819122};\\\", \\\"{x:1185,y:785,t:1528139819139};\\\", \\\"{x:1172,y:794,t:1528139819155};\\\", \\\"{x:1164,y:799,t:1528139819173};\\\", \\\"{x:1160,y:803,t:1528139819188};\\\", \\\"{x:1159,y:805,t:1528139819205};\\\", \\\"{x:1157,y:806,t:1528139819230};\\\", \\\"{x:1156,y:807,t:1528139819245};\\\", \\\"{x:1156,y:806,t:1528139819349};\\\", \\\"{x:1156,y:804,t:1528139819356};\\\", \\\"{x:1157,y:799,t:1528139819372};\\\", \\\"{x:1162,y:789,t:1528139819389};\\\", \\\"{x:1168,y:783,t:1528139819405};\\\", \\\"{x:1171,y:780,t:1528139819422};\\\", \\\"{x:1173,y:779,t:1528139819439};\\\", \\\"{x:1173,y:778,t:1528139819598};\\\", \\\"{x:1173,y:777,t:1528139819614};\\\", \\\"{x:1173,y:776,t:1528139819622};\\\", \\\"{x:1173,y:773,t:1528139819639};\\\", \\\"{x:1174,y:769,t:1528139819656};\\\", \\\"{x:1176,y:766,t:1528139819672};\\\", \\\"{x:1177,y:764,t:1528139819706};\\\", \\\"{x:1177,y:763,t:1528139819767};\\\", \\\"{x:1178,y:762,t:1528139819831};\\\", \\\"{x:1182,y:769,t:1528139824471};\\\", \\\"{x:1192,y:773,t:1528139824478};\\\", \\\"{x:1199,y:777,t:1528139824493};\\\", \\\"{x:1200,y:778,t:1528139824510};\\\", \\\"{x:1201,y:778,t:1528139824775};\\\", \\\"{x:1206,y:778,t:1528139824782};\\\", \\\"{x:1212,y:784,t:1528139824793};\\\", \\\"{x:1215,y:788,t:1528139824811};\\\", \\\"{x:1229,y:795,t:1528139824828};\\\", \\\"{x:1235,y:797,t:1528139824843};\\\", \\\"{x:1250,y:797,t:1528139824861};\\\", \\\"{x:1276,y:795,t:1528139824878};\\\", \\\"{x:1309,y:795,t:1528139824893};\\\", \\\"{x:1332,y:795,t:1528139824911};\\\", \\\"{x:1352,y:798,t:1528139824927};\\\", \\\"{x:1370,y:804,t:1528139824944};\\\", \\\"{x:1394,y:811,t:1528139824960};\\\", \\\"{x:1464,y:819,t:1528139824978};\\\", \\\"{x:1556,y:835,t:1528139824994};\\\", \\\"{x:1628,y:846,t:1528139825010};\\\", \\\"{x:1675,y:858,t:1528139825027};\\\", \\\"{x:1694,y:863,t:1528139825045};\\\", \\\"{x:1706,y:871,t:1528139825060};\\\", \\\"{x:1715,y:878,t:1528139825077};\\\", \\\"{x:1715,y:879,t:1528139825094};\\\", \\\"{x:1715,y:880,t:1528139825134};\\\", \\\"{x:1713,y:882,t:1528139825145};\\\", \\\"{x:1695,y:892,t:1528139825161};\\\", \\\"{x:1676,y:906,t:1528139825178};\\\", \\\"{x:1615,y:934,t:1528139825195};\\\", \\\"{x:1534,y:962,t:1528139825210};\\\", \\\"{x:1454,y:985,t:1528139825228};\\\", \\\"{x:1389,y:995,t:1528139825245};\\\", \\\"{x:1350,y:997,t:1528139825260};\\\", \\\"{x:1316,y:986,t:1528139825277};\\\", \\\"{x:1300,y:980,t:1528139825294};\\\", \\\"{x:1291,y:979,t:1528139825310};\\\", \\\"{x:1287,y:976,t:1528139825327};\\\", \\\"{x:1286,y:974,t:1528139825391};\\\", \\\"{x:1284,y:972,t:1528139825398};\\\", \\\"{x:1284,y:970,t:1528139825411};\\\", \\\"{x:1278,y:963,t:1528139825428};\\\", \\\"{x:1267,y:957,t:1528139825445};\\\", \\\"{x:1261,y:952,t:1528139825462};\\\", \\\"{x:1261,y:951,t:1528139825486};\\\", \\\"{x:1261,y:948,t:1528139825495};\\\", \\\"{x:1274,y:938,t:1528139825512};\\\", \\\"{x:1286,y:931,t:1528139825528};\\\", \\\"{x:1312,y:927,t:1528139825544};\\\", \\\"{x:1331,y:923,t:1528139825562};\\\", \\\"{x:1344,y:921,t:1528139825578};\\\", \\\"{x:1358,y:920,t:1528139825594};\\\", \\\"{x:1362,y:918,t:1528139825612};\\\", \\\"{x:1363,y:918,t:1528139825628};\\\", \\\"{x:1362,y:918,t:1528139825685};\\\", \\\"{x:1360,y:918,t:1528139825694};\\\", \\\"{x:1349,y:927,t:1528139825712};\\\", \\\"{x:1340,y:937,t:1528139825727};\\\", \\\"{x:1333,y:942,t:1528139825744};\\\", \\\"{x:1335,y:942,t:1528139825918};\\\", \\\"{x:1337,y:942,t:1528139825929};\\\", \\\"{x:1340,y:942,t:1528139825945};\\\", \\\"{x:1349,y:938,t:1528139825962};\\\", \\\"{x:1354,y:936,t:1528139825978};\\\", \\\"{x:1356,y:935,t:1528139825994};\\\", \\\"{x:1357,y:935,t:1528139826012};\\\", \\\"{x:1358,y:935,t:1528139826070};\\\", \\\"{x:1360,y:935,t:1528139826238};\\\", \\\"{x:1360,y:933,t:1528139826246};\\\", \\\"{x:1363,y:932,t:1528139826272};\\\", \\\"{x:1367,y:924,t:1528139826288};\\\", \\\"{x:1368,y:921,t:1528139826305};\\\", \\\"{x:1369,y:917,t:1528139826320};\\\", \\\"{x:1370,y:915,t:1528139826338};\\\", \\\"{x:1370,y:912,t:1528139826355};\\\", \\\"{x:1371,y:910,t:1528139826371};\\\", \\\"{x:1371,y:909,t:1528139826388};\\\", \\\"{x:1371,y:908,t:1528139826405};\\\", \\\"{x:1371,y:907,t:1528139826422};\\\", \\\"{x:1371,y:906,t:1528139826463};\\\", \\\"{x:1371,y:905,t:1528139826479};\\\", \\\"{x:1372,y:905,t:1528139826489};\\\", \\\"{x:1372,y:903,t:1528139826505};\\\", \\\"{x:1374,y:901,t:1528139826522};\\\", \\\"{x:1375,y:897,t:1528139826538};\\\", \\\"{x:1377,y:892,t:1528139826555};\\\", \\\"{x:1378,y:891,t:1528139826573};\\\", \\\"{x:1378,y:888,t:1528139826588};\\\", \\\"{x:1379,y:888,t:1528139826605};\\\", \\\"{x:1381,y:884,t:1528139826622};\\\", \\\"{x:1382,y:882,t:1528139826638};\\\", \\\"{x:1384,y:879,t:1528139826655};\\\", \\\"{x:1384,y:878,t:1528139826672};\\\", \\\"{x:1384,y:877,t:1528139826700};\\\", \\\"{x:1385,y:877,t:1528139826719};\\\", \\\"{x:1385,y:876,t:1528139826767};\\\", \\\"{x:1384,y:876,t:1528139827680};\\\", \\\"{x:1383,y:877,t:1528139827689};\\\", \\\"{x:1382,y:878,t:1528139827707};\\\", \\\"{x:1381,y:879,t:1528139827724};\\\", \\\"{x:1380,y:881,t:1528139827740};\\\", \\\"{x:1380,y:884,t:1528139827756};\\\", \\\"{x:1378,y:889,t:1528139827773};\\\", \\\"{x:1378,y:891,t:1528139827789};\\\", \\\"{x:1378,y:892,t:1528139827807};\\\", \\\"{x:1377,y:894,t:1528139827823};\\\", \\\"{x:1377,y:896,t:1528139827839};\\\", \\\"{x:1377,y:897,t:1528139827864};\\\", \\\"{x:1377,y:899,t:1528139827873};\\\", \\\"{x:1377,y:902,t:1528139827891};\\\", \\\"{x:1376,y:906,t:1528139827907};\\\", \\\"{x:1376,y:908,t:1528139827924};\\\", \\\"{x:1376,y:912,t:1528139827940};\\\", \\\"{x:1380,y:922,t:1528139827956};\\\", \\\"{x:1383,y:928,t:1528139827974};\\\", \\\"{x:1393,y:935,t:1528139827990};\\\", \\\"{x:1408,y:949,t:1528139828007};\\\", \\\"{x:1417,y:968,t:1528139828024};\\\", \\\"{x:1420,y:971,t:1528139828040};\\\", \\\"{x:1420,y:972,t:1528139828056};\\\", \\\"{x:1420,y:974,t:1528139828144};\\\", \\\"{x:1420,y:975,t:1528139828160};\\\", \\\"{x:1418,y:976,t:1528139828173};\\\", \\\"{x:1413,y:977,t:1528139828190};\\\", \\\"{x:1407,y:978,t:1528139828207};\\\", \\\"{x:1400,y:980,t:1528139828223};\\\", \\\"{x:1391,y:981,t:1528139828241};\\\", \\\"{x:1385,y:983,t:1528139828257};\\\", \\\"{x:1380,y:984,t:1528139828273};\\\", \\\"{x:1375,y:984,t:1528139828291};\\\", \\\"{x:1374,y:984,t:1528139828307};\\\", \\\"{x:1373,y:984,t:1528139828323};\\\", \\\"{x:1372,y:984,t:1528139828341};\\\", \\\"{x:1371,y:984,t:1528139828456};\\\", \\\"{x:1370,y:984,t:1528139828464};\\\", \\\"{x:1368,y:982,t:1528139828480};\\\", \\\"{x:1366,y:981,t:1528139828491};\\\", \\\"{x:1354,y:975,t:1528139828507};\\\", \\\"{x:1349,y:971,t:1528139828524};\\\", \\\"{x:1343,y:967,t:1528139828541};\\\", \\\"{x:1341,y:967,t:1528139828557};\\\", \\\"{x:1341,y:966,t:1528139828656};\\\", \\\"{x:1341,y:965,t:1528139828674};\\\", \\\"{x:1341,y:962,t:1528139828691};\\\", \\\"{x:1341,y:961,t:1528139828720};\\\", \\\"{x:1342,y:959,t:1528139828792};\\\", \\\"{x:1343,y:959,t:1528139828807};\\\", \\\"{x:1344,y:956,t:1528139828824};\\\", \\\"{x:1345,y:956,t:1528139828841};\\\", \\\"{x:1347,y:954,t:1528139828858};\\\", \\\"{x:1349,y:952,t:1528139828875};\\\", \\\"{x:1351,y:949,t:1528139828891};\\\", \\\"{x:1354,y:945,t:1528139828908};\\\", \\\"{x:1359,y:940,t:1528139828925};\\\", \\\"{x:1361,y:937,t:1528139828940};\\\", \\\"{x:1363,y:932,t:1528139828958};\\\", \\\"{x:1368,y:926,t:1528139828975};\\\", \\\"{x:1370,y:925,t:1528139828991};\\\", \\\"{x:1372,y:923,t:1528139829007};\\\", \\\"{x:1372,y:920,t:1528139829025};\\\", \\\"{x:1372,y:919,t:1528139829041};\\\", \\\"{x:1372,y:918,t:1528139829057};\\\", \\\"{x:1372,y:917,t:1528139829075};\\\", \\\"{x:1372,y:916,t:1528139829104};\\\", \\\"{x:1372,y:915,t:1528139829111};\\\", \\\"{x:1373,y:913,t:1528139829125};\\\", \\\"{x:1375,y:910,t:1528139829142};\\\", \\\"{x:1377,y:906,t:1528139829157};\\\", \\\"{x:1378,y:903,t:1528139829174};\\\", \\\"{x:1381,y:897,t:1528139829192};\\\", \\\"{x:1383,y:894,t:1528139829206};\\\", \\\"{x:1384,y:892,t:1528139829224};\\\", \\\"{x:1385,y:890,t:1528139829241};\\\", \\\"{x:1386,y:890,t:1528139829257};\\\", \\\"{x:1378,y:893,t:1528139829440};\\\", \\\"{x:1366,y:899,t:1528139829458};\\\", \\\"{x:1356,y:906,t:1528139829474};\\\", \\\"{x:1349,y:907,t:1528139829492};\\\", \\\"{x:1344,y:909,t:1528139829507};\\\", \\\"{x:1344,y:910,t:1528139829524};\\\", \\\"{x:1342,y:910,t:1528139829544};\\\", \\\"{x:1341,y:911,t:1528139829559};\\\", \\\"{x:1335,y:914,t:1528139829575};\\\", \\\"{x:1320,y:921,t:1528139829592};\\\", \\\"{x:1310,y:925,t:1528139829607};\\\", \\\"{x:1302,y:930,t:1528139829625};\\\", \\\"{x:1297,y:933,t:1528139829641};\\\", \\\"{x:1291,y:935,t:1528139829659};\\\", \\\"{x:1287,y:938,t:1528139829675};\\\", \\\"{x:1284,y:941,t:1528139829692};\\\", \\\"{x:1282,y:943,t:1528139829709};\\\", \\\"{x:1280,y:943,t:1528139829724};\\\", \\\"{x:1275,y:945,t:1528139829741};\\\", \\\"{x:1274,y:946,t:1528139829758};\\\", \\\"{x:1270,y:947,t:1528139829774};\\\", \\\"{x:1268,y:948,t:1528139829791};\\\", \\\"{x:1267,y:948,t:1528139829808};\\\", \\\"{x:1266,y:948,t:1528139829825};\\\", \\\"{x:1266,y:949,t:1528139829842};\\\", \\\"{x:1266,y:951,t:1528139829880};\\\", \\\"{x:1265,y:951,t:1528139829920};\\\", \\\"{x:1264,y:952,t:1528139829961};\\\", \\\"{x:1263,y:953,t:1528139829976};\\\", \\\"{x:1261,y:955,t:1528139830000};\\\", \\\"{x:1260,y:956,t:1528139830016};\\\", \\\"{x:1258,y:956,t:1528139830026};\\\", \\\"{x:1254,y:957,t:1528139830042};\\\", \\\"{x:1251,y:957,t:1528139830058};\\\", \\\"{x:1249,y:957,t:1528139830075};\\\", \\\"{x:1244,y:957,t:1528139830092};\\\", \\\"{x:1241,y:956,t:1528139830108};\\\", \\\"{x:1238,y:956,t:1528139830125};\\\", \\\"{x:1235,y:956,t:1528139830142};\\\", \\\"{x:1231,y:955,t:1528139830158};\\\", \\\"{x:1226,y:953,t:1528139830176};\\\", \\\"{x:1222,y:952,t:1528139830191};\\\", \\\"{x:1217,y:951,t:1528139830209};\\\", \\\"{x:1210,y:948,t:1528139830226};\\\", \\\"{x:1207,y:948,t:1528139830242};\\\", \\\"{x:1205,y:947,t:1528139830259};\\\", \\\"{x:1204,y:947,t:1528139830276};\\\", \\\"{x:1203,y:945,t:1528139830471};\\\", \\\"{x:1203,y:944,t:1528139830479};\\\", \\\"{x:1204,y:941,t:1528139830492};\\\", \\\"{x:1210,y:937,t:1528139830508};\\\", \\\"{x:1217,y:931,t:1528139830525};\\\", \\\"{x:1220,y:927,t:1528139830542};\\\", \\\"{x:1225,y:923,t:1528139830559};\\\", \\\"{x:1236,y:913,t:1528139830575};\\\", \\\"{x:1239,y:910,t:1528139830592};\\\", \\\"{x:1246,y:900,t:1528139830608};\\\", \\\"{x:1252,y:889,t:1528139830625};\\\", \\\"{x:1263,y:878,t:1528139830643};\\\", \\\"{x:1270,y:868,t:1528139830659};\\\", \\\"{x:1285,y:853,t:1528139830675};\\\", \\\"{x:1295,y:843,t:1528139830692};\\\", \\\"{x:1311,y:826,t:1528139830710};\\\", \\\"{x:1324,y:812,t:1528139830726};\\\", \\\"{x:1336,y:796,t:1528139830743};\\\", \\\"{x:1339,y:788,t:1528139830760};\\\", \\\"{x:1340,y:782,t:1528139830776};\\\", \\\"{x:1341,y:777,t:1528139830792};\\\", \\\"{x:1343,y:773,t:1528139830809};\\\", \\\"{x:1347,y:768,t:1528139830825};\\\", \\\"{x:1347,y:767,t:1528139831856};\\\", \\\"{x:1346,y:767,t:1528139832616};\\\", \\\"{x:1344,y:767,t:1528139832648};\\\", \\\"{x:1342,y:767,t:1528139832809};\\\", \\\"{x:1341,y:767,t:1528139832831};\\\", \\\"{x:1339,y:767,t:1528139832871};\\\", \\\"{x:1339,y:766,t:1528139833144};\\\", \\\"{x:1340,y:764,t:1528139833600};\\\", \\\"{x:1340,y:761,t:1528139833612};\\\", \\\"{x:1337,y:754,t:1528139833628};\\\", \\\"{x:1327,y:745,t:1528139833645};\\\", \\\"{x:1316,y:735,t:1528139833661};\\\", \\\"{x:1305,y:723,t:1528139833679};\\\", \\\"{x:1293,y:714,t:1528139833695};\\\", \\\"{x:1286,y:706,t:1528139833712};\\\", \\\"{x:1284,y:704,t:1528139833729};\\\", \\\"{x:1284,y:703,t:1528139833784};\\\", \\\"{x:1286,y:706,t:1528139833968};\\\", \\\"{x:1286,y:709,t:1528139833979};\\\", \\\"{x:1290,y:715,t:1528139833996};\\\", \\\"{x:1296,y:723,t:1528139834012};\\\", \\\"{x:1301,y:730,t:1528139834028};\\\", \\\"{x:1305,y:735,t:1528139834046};\\\", \\\"{x:1309,y:741,t:1528139834063};\\\", \\\"{x:1311,y:745,t:1528139834079};\\\", \\\"{x:1313,y:746,t:1528139834096};\\\", \\\"{x:1315,y:747,t:1528139834113};\\\", \\\"{x:1315,y:749,t:1528139834192};\\\", \\\"{x:1317,y:749,t:1528139834232};\\\", \\\"{x:1318,y:750,t:1528139834246};\\\", \\\"{x:1319,y:752,t:1528139834263};\\\", \\\"{x:1321,y:752,t:1528139834279};\\\", \\\"{x:1322,y:753,t:1528139834463};\\\", \\\"{x:1320,y:747,t:1528139834496};\\\", \\\"{x:1311,y:738,t:1528139834513};\\\", \\\"{x:1302,y:726,t:1528139834530};\\\", \\\"{x:1295,y:717,t:1528139834546};\\\", \\\"{x:1291,y:713,t:1528139834563};\\\", \\\"{x:1290,y:710,t:1528139834580};\\\", \\\"{x:1289,y:709,t:1528139834596};\\\", \\\"{x:1289,y:707,t:1528139834672};\\\", \\\"{x:1291,y:707,t:1528139834688};\\\", \\\"{x:1293,y:707,t:1528139834728};\\\", \\\"{x:1295,y:706,t:1528139834751};\\\", \\\"{x:1296,y:705,t:1528139834768};\\\", \\\"{x:1297,y:705,t:1528139834784};\\\", \\\"{x:1298,y:705,t:1528139834808};\\\", \\\"{x:1298,y:704,t:1528139834839};\\\", \\\"{x:1299,y:703,t:1528139834848};\\\", \\\"{x:1300,y:703,t:1528139834863};\\\", \\\"{x:1301,y:700,t:1528139834880};\\\", \\\"{x:1301,y:698,t:1528139834896};\\\", \\\"{x:1302,y:696,t:1528139834913};\\\", \\\"{x:1304,y:692,t:1528139834930};\\\", \\\"{x:1305,y:690,t:1528139834947};\\\", \\\"{x:1306,y:687,t:1528139834963};\\\", \\\"{x:1306,y:686,t:1528139834979};\\\", \\\"{x:1307,y:685,t:1528139834997};\\\", \\\"{x:1308,y:683,t:1528139835012};\\\", \\\"{x:1308,y:682,t:1528139835029};\\\", \\\"{x:1308,y:681,t:1528139835128};\\\", \\\"{x:1308,y:682,t:1528139835231};\\\", \\\"{x:1308,y:686,t:1528139835247};\\\", \\\"{x:1312,y:700,t:1528139835264};\\\", \\\"{x:1315,y:708,t:1528139835280};\\\", \\\"{x:1318,y:714,t:1528139835297};\\\", \\\"{x:1326,y:722,t:1528139835313};\\\", \\\"{x:1328,y:728,t:1528139835329};\\\", \\\"{x:1331,y:734,t:1528139835346};\\\", \\\"{x:1333,y:740,t:1528139835363};\\\", \\\"{x:1335,y:746,t:1528139835379};\\\", \\\"{x:1337,y:750,t:1528139835396};\\\", \\\"{x:1338,y:752,t:1528139835413};\\\", \\\"{x:1338,y:754,t:1528139835430};\\\", \\\"{x:1339,y:756,t:1528139835446};\\\", \\\"{x:1340,y:757,t:1528139835463};\\\", \\\"{x:1341,y:757,t:1528139835487};\\\", \\\"{x:1342,y:759,t:1528139835503};\\\", \\\"{x:1343,y:761,t:1528139835520};\\\", \\\"{x:1344,y:763,t:1528139835546};\\\", \\\"{x:1345,y:764,t:1528139835564};\\\", \\\"{x:1345,y:766,t:1528139835581};\\\", \\\"{x:1346,y:771,t:1528139835598};\\\", \\\"{x:1347,y:772,t:1528139835614};\\\", \\\"{x:1348,y:774,t:1528139835631};\\\", \\\"{x:1349,y:777,t:1528139835647};\\\", \\\"{x:1351,y:779,t:1528139835664};\\\", \\\"{x:1352,y:781,t:1528139835680};\\\", \\\"{x:1353,y:782,t:1528139835697};\\\", \\\"{x:1354,y:785,t:1528139835714};\\\", \\\"{x:1357,y:789,t:1528139835731};\\\", \\\"{x:1358,y:792,t:1528139835747};\\\", \\\"{x:1359,y:799,t:1528139835763};\\\", \\\"{x:1361,y:803,t:1528139835781};\\\", \\\"{x:1364,y:805,t:1528139835797};\\\", \\\"{x:1364,y:808,t:1528139835814};\\\", \\\"{x:1364,y:810,t:1528139835831};\\\", \\\"{x:1365,y:810,t:1528139835847};\\\", \\\"{x:1367,y:817,t:1528139835863};\\\", \\\"{x:1368,y:820,t:1528139835881};\\\", \\\"{x:1369,y:822,t:1528139835898};\\\", \\\"{x:1369,y:824,t:1528139835913};\\\", \\\"{x:1369,y:826,t:1528139835931};\\\", \\\"{x:1369,y:830,t:1528139835948};\\\", \\\"{x:1372,y:834,t:1528139835964};\\\", \\\"{x:1372,y:837,t:1528139835981};\\\", \\\"{x:1375,y:840,t:1528139835998};\\\", \\\"{x:1375,y:841,t:1528139836014};\\\", \\\"{x:1377,y:845,t:1528139836031};\\\", \\\"{x:1379,y:852,t:1528139836047};\\\", \\\"{x:1380,y:855,t:1528139836064};\\\", \\\"{x:1382,y:864,t:1528139836080};\\\", \\\"{x:1387,y:875,t:1528139836098};\\\", \\\"{x:1390,y:881,t:1528139836114};\\\", \\\"{x:1390,y:883,t:1528139836131};\\\", \\\"{x:1391,y:884,t:1528139836152};\\\", \\\"{x:1392,y:884,t:1528139836175};\\\", \\\"{x:1394,y:884,t:1528139836183};\\\", \\\"{x:1396,y:886,t:1528139836200};\\\", \\\"{x:1397,y:889,t:1528139836214};\\\", \\\"{x:1403,y:894,t:1528139836231};\\\", \\\"{x:1410,y:906,t:1528139836248};\\\", \\\"{x:1415,y:912,t:1528139836265};\\\", \\\"{x:1417,y:914,t:1528139836281};\\\", \\\"{x:1418,y:915,t:1528139836298};\\\", \\\"{x:1418,y:917,t:1528139836360};\\\", \\\"{x:1419,y:918,t:1528139836368};\\\", \\\"{x:1420,y:919,t:1528139836384};\\\", \\\"{x:1420,y:920,t:1528139836398};\\\", \\\"{x:1420,y:921,t:1528139836415};\\\", \\\"{x:1422,y:926,t:1528139836431};\\\", \\\"{x:1424,y:929,t:1528139836447};\\\", \\\"{x:1426,y:932,t:1528139836465};\\\", \\\"{x:1428,y:934,t:1528139836481};\\\", \\\"{x:1429,y:937,t:1528139836498};\\\", \\\"{x:1430,y:938,t:1528139836515};\\\", \\\"{x:1430,y:939,t:1528139836792};\\\", \\\"{x:1429,y:940,t:1528139836799};\\\", \\\"{x:1426,y:942,t:1528139836815};\\\", \\\"{x:1424,y:942,t:1528139836832};\\\", \\\"{x:1423,y:942,t:1528139836847};\\\", \\\"{x:1422,y:942,t:1528139836865};\\\", \\\"{x:1421,y:943,t:1528139836896};\\\", \\\"{x:1421,y:944,t:1528139836903};\\\", \\\"{x:1419,y:944,t:1528139836915};\\\", \\\"{x:1417,y:944,t:1528139836932};\\\", \\\"{x:1414,y:944,t:1528139836948};\\\", \\\"{x:1413,y:944,t:1528139836965};\\\", \\\"{x:1414,y:944,t:1528139837080};\\\", \\\"{x:1416,y:942,t:1528139837088};\\\", \\\"{x:1418,y:941,t:1528139837099};\\\", \\\"{x:1425,y:937,t:1528139837115};\\\", \\\"{x:1433,y:930,t:1528139837132};\\\", \\\"{x:1436,y:920,t:1528139837149};\\\", \\\"{x:1439,y:913,t:1528139837164};\\\", \\\"{x:1440,y:912,t:1528139837182};\\\", \\\"{x:1440,y:911,t:1528139837198};\\\", \\\"{x:1440,y:910,t:1528139837248};\\\", \\\"{x:1424,y:900,t:1528139837265};\\\", \\\"{x:1406,y:895,t:1528139837282};\\\", \\\"{x:1390,y:888,t:1528139837299};\\\", \\\"{x:1373,y:883,t:1528139837315};\\\", \\\"{x:1363,y:879,t:1528139837332};\\\", \\\"{x:1360,y:877,t:1528139837349};\\\", \\\"{x:1359,y:877,t:1528139837365};\\\", \\\"{x:1359,y:876,t:1528139837520};\\\", \\\"{x:1362,y:875,t:1528139837532};\\\", \\\"{x:1370,y:871,t:1528139837549};\\\", \\\"{x:1379,y:868,t:1528139837566};\\\", \\\"{x:1391,y:861,t:1528139837582};\\\", \\\"{x:1398,y:859,t:1528139837599};\\\", \\\"{x:1418,y:850,t:1528139837615};\\\", \\\"{x:1430,y:847,t:1528139837631};\\\", \\\"{x:1450,y:843,t:1528139837649};\\\", \\\"{x:1474,y:840,t:1528139837666};\\\", \\\"{x:1502,y:836,t:1528139837682};\\\", \\\"{x:1523,y:836,t:1528139837699};\\\", \\\"{x:1541,y:832,t:1528139837716};\\\", \\\"{x:1552,y:828,t:1528139837732};\\\", \\\"{x:1559,y:825,t:1528139837749};\\\", \\\"{x:1573,y:818,t:1528139837766};\\\", \\\"{x:1582,y:815,t:1528139837783};\\\", \\\"{x:1596,y:808,t:1528139837799};\\\", \\\"{x:1612,y:803,t:1528139837815};\\\", \\\"{x:1625,y:800,t:1528139837833};\\\", \\\"{x:1638,y:798,t:1528139837849};\\\", \\\"{x:1640,y:797,t:1528139837865};\\\", \\\"{x:1642,y:797,t:1528139837883};\\\", \\\"{x:1643,y:797,t:1528139837899};\\\", \\\"{x:1644,y:796,t:1528139837916};\\\", \\\"{x:1646,y:796,t:1528139837933};\\\", \\\"{x:1648,y:796,t:1528139837949};\\\", \\\"{x:1657,y:802,t:1528139837966};\\\", \\\"{x:1670,y:812,t:1528139837983};\\\", \\\"{x:1681,y:823,t:1528139837999};\\\", \\\"{x:1692,y:835,t:1528139838016};\\\", \\\"{x:1698,y:840,t:1528139838033};\\\", \\\"{x:1705,y:848,t:1528139838049};\\\", \\\"{x:1715,y:856,t:1528139838066};\\\", \\\"{x:1717,y:857,t:1528139838083};\\\", \\\"{x:1718,y:857,t:1528139838099};\\\", \\\"{x:1721,y:857,t:1528139838264};\\\", \\\"{x:1721,y:854,t:1528139838272};\\\", \\\"{x:1721,y:850,t:1528139838283};\\\", \\\"{x:1720,y:844,t:1528139838300};\\\", \\\"{x:1718,y:840,t:1528139838316};\\\", \\\"{x:1717,y:839,t:1528139838333};\\\", \\\"{x:1715,y:837,t:1528139838352};\\\", \\\"{x:1714,y:837,t:1528139838376};\\\", \\\"{x:1713,y:836,t:1528139838448};\\\", \\\"{x:1712,y:836,t:1528139838472};\\\", \\\"{x:1710,y:835,t:1528139838483};\\\", \\\"{x:1705,y:834,t:1528139838500};\\\", \\\"{x:1698,y:832,t:1528139838516};\\\", \\\"{x:1688,y:828,t:1528139838533};\\\", \\\"{x:1686,y:826,t:1528139838550};\\\", \\\"{x:1684,y:826,t:1528139839608};\\\", \\\"{x:1683,y:826,t:1528139840023};\\\", \\\"{x:1681,y:826,t:1528139840034};\\\", \\\"{x:1676,y:827,t:1528139840050};\\\", \\\"{x:1675,y:828,t:1528139840069};\\\", \\\"{x:1674,y:828,t:1528139840085};\\\", \\\"{x:1672,y:829,t:1528139840101};\\\", \\\"{x:1670,y:830,t:1528139840959};\\\", \\\"{x:1669,y:830,t:1528139840999};\\\", \\\"{x:1670,y:829,t:1528139841448};\\\", \\\"{x:1670,y:828,t:1528139841456};\\\", \\\"{x:1670,y:827,t:1528139841472};\\\", \\\"{x:1671,y:825,t:1528139841488};\\\", \\\"{x:1671,y:824,t:1528139841502};\\\", \\\"{x:1673,y:816,t:1528139841519};\\\", \\\"{x:1673,y:805,t:1528139841536};\\\", \\\"{x:1663,y:789,t:1528139841553};\\\", \\\"{x:1645,y:772,t:1528139841570};\\\", \\\"{x:1632,y:761,t:1528139841586};\\\", \\\"{x:1615,y:752,t:1528139841602};\\\", \\\"{x:1598,y:746,t:1528139841618};\\\", \\\"{x:1586,y:740,t:1528139841636};\\\", \\\"{x:1574,y:736,t:1528139841653};\\\", \\\"{x:1564,y:734,t:1528139841669};\\\", \\\"{x:1558,y:733,t:1528139841685};\\\", \\\"{x:1550,y:733,t:1528139841702};\\\", \\\"{x:1547,y:736,t:1528139841719};\\\", \\\"{x:1544,y:737,t:1528139841735};\\\", \\\"{x:1540,y:739,t:1528139841753};\\\", \\\"{x:1540,y:740,t:1528139841769};\\\", \\\"{x:1539,y:742,t:1528139841785};\\\", \\\"{x:1538,y:744,t:1528139841803};\\\", \\\"{x:1538,y:745,t:1528139841819};\\\", \\\"{x:1537,y:746,t:1528139841836};\\\", \\\"{x:1537,y:748,t:1528139841853};\\\", \\\"{x:1535,y:751,t:1528139841869};\\\", \\\"{x:1533,y:753,t:1528139841886};\\\", \\\"{x:1531,y:756,t:1528139841903};\\\", \\\"{x:1530,y:760,t:1528139841919};\\\", \\\"{x:1526,y:762,t:1528139841935};\\\", \\\"{x:1524,y:764,t:1528139841953};\\\", \\\"{x:1522,y:766,t:1528139841970};\\\", \\\"{x:1519,y:768,t:1528139841986};\\\", \\\"{x:1518,y:769,t:1528139842007};\\\", \\\"{x:1518,y:770,t:1528139842020};\\\", \\\"{x:1517,y:770,t:1528139842040};\\\", \\\"{x:1516,y:770,t:1528139842360};\\\", \\\"{x:1516,y:768,t:1528139842921};\\\", \\\"{x:1516,y:766,t:1528139842937};\\\", \\\"{x:1516,y:765,t:1528139842959};\\\", \\\"{x:1516,y:764,t:1528139842976};\\\", \\\"{x:1515,y:764,t:1528139843288};\\\", \\\"{x:1514,y:764,t:1528139843312};\\\", \\\"{x:1513,y:765,t:1528139843321};\\\", \\\"{x:1513,y:766,t:1528139843337};\\\", \\\"{x:1511,y:768,t:1528139843355};\\\", \\\"{x:1510,y:769,t:1528139843371};\\\", \\\"{x:1509,y:770,t:1528139843392};\\\", \\\"{x:1508,y:771,t:1528139843424};\\\", \\\"{x:1508,y:772,t:1528139843440};\\\", \\\"{x:1507,y:772,t:1528139843455};\\\", \\\"{x:1507,y:773,t:1528139843479};\\\", \\\"{x:1507,y:774,t:1528139843487};\\\", \\\"{x:1507,y:775,t:1528139843503};\\\", \\\"{x:1507,y:776,t:1528139843520};\\\", \\\"{x:1507,y:777,t:1528139843551};\\\", \\\"{x:1506,y:780,t:1528139843574};\\\", \\\"{x:1505,y:780,t:1528139843591};\\\", \\\"{x:1504,y:781,t:1528139843603};\\\", \\\"{x:1504,y:783,t:1528139843623};\\\", \\\"{x:1503,y:785,t:1528139843647};\\\", \\\"{x:1502,y:786,t:1528139843679};\\\", \\\"{x:1501,y:787,t:1528139843719};\\\", \\\"{x:1501,y:788,t:1528139843744};\\\", \\\"{x:1500,y:789,t:1528139843760};\\\", \\\"{x:1499,y:792,t:1528139843791};\\\", \\\"{x:1498,y:792,t:1528139843815};\\\", \\\"{x:1498,y:794,t:1528139843831};\\\", \\\"{x:1498,y:795,t:1528139843840};\\\", \\\"{x:1495,y:798,t:1528139843856};\\\", \\\"{x:1494,y:799,t:1528139843871};\\\", \\\"{x:1493,y:802,t:1528139843887};\\\", \\\"{x:1491,y:806,t:1528139843906};\\\", \\\"{x:1489,y:809,t:1528139843921};\\\", \\\"{x:1487,y:811,t:1528139843938};\\\", \\\"{x:1486,y:813,t:1528139843955};\\\", \\\"{x:1484,y:816,t:1528139843971};\\\", \\\"{x:1481,y:820,t:1528139843988};\\\", \\\"{x:1480,y:821,t:1528139844004};\\\", \\\"{x:1478,y:823,t:1528139844021};\\\", \\\"{x:1477,y:824,t:1528139844039};\\\", \\\"{x:1476,y:824,t:1528139844095};\\\", \\\"{x:1475,y:826,t:1528139844105};\\\", \\\"{x:1474,y:827,t:1528139844121};\\\", \\\"{x:1473,y:828,t:1528139844144};\\\", \\\"{x:1473,y:829,t:1528139844160};\\\", \\\"{x:1472,y:829,t:1528139844172};\\\", \\\"{x:1471,y:831,t:1528139844188};\\\", \\\"{x:1471,y:832,t:1528139844205};\\\", \\\"{x:1469,y:833,t:1528139844222};\\\", \\\"{x:1468,y:836,t:1528139844248};\\\", \\\"{x:1467,y:838,t:1528139844255};\\\", \\\"{x:1466,y:840,t:1528139844272};\\\", \\\"{x:1465,y:842,t:1528139844287};\\\", \\\"{x:1463,y:843,t:1528139844304};\\\", \\\"{x:1463,y:845,t:1528139844350};\\\", \\\"{x:1462,y:845,t:1528139844366};\\\", \\\"{x:1461,y:846,t:1528139844374};\\\", \\\"{x:1461,y:847,t:1528139844387};\\\", \\\"{x:1458,y:852,t:1528139844405};\\\", \\\"{x:1456,y:853,t:1528139844422};\\\", \\\"{x:1455,y:857,t:1528139844438};\\\", \\\"{x:1453,y:860,t:1528139844455};\\\", \\\"{x:1450,y:864,t:1528139844471};\\\", \\\"{x:1450,y:865,t:1528139844488};\\\", \\\"{x:1450,y:867,t:1528139844511};\\\", \\\"{x:1449,y:867,t:1528139844522};\\\", \\\"{x:1448,y:870,t:1528139844539};\\\", \\\"{x:1447,y:871,t:1528139844560};\\\", \\\"{x:1446,y:871,t:1528139844572};\\\", \\\"{x:1444,y:874,t:1528139844591};\\\", \\\"{x:1444,y:875,t:1528139844607};\\\", \\\"{x:1444,y:876,t:1528139844623};\\\", \\\"{x:1443,y:878,t:1528139844639};\\\", \\\"{x:1442,y:880,t:1528139844655};\\\", \\\"{x:1441,y:880,t:1528139844671};\\\", \\\"{x:1441,y:882,t:1528139844689};\\\", \\\"{x:1441,y:884,t:1528139844705};\\\", \\\"{x:1440,y:887,t:1528139844722};\\\", \\\"{x:1439,y:891,t:1528139844739};\\\", \\\"{x:1438,y:896,t:1528139844755};\\\", \\\"{x:1436,y:899,t:1528139844773};\\\", \\\"{x:1434,y:904,t:1528139844790};\\\", \\\"{x:1433,y:906,t:1528139844805};\\\", \\\"{x:1432,y:909,t:1528139844823};\\\", \\\"{x:1431,y:913,t:1528139844840};\\\", \\\"{x:1430,y:914,t:1528139844856};\\\", \\\"{x:1429,y:915,t:1528139844873};\\\", \\\"{x:1427,y:919,t:1528139844889};\\\", \\\"{x:1426,y:921,t:1528139844906};\\\", \\\"{x:1426,y:924,t:1528139844922};\\\", \\\"{x:1425,y:927,t:1528139844939};\\\", \\\"{x:1424,y:931,t:1528139844956};\\\", \\\"{x:1422,y:935,t:1528139844972};\\\", \\\"{x:1421,y:937,t:1528139844989};\\\", \\\"{x:1420,y:940,t:1528139845007};\\\", \\\"{x:1419,y:941,t:1528139845022};\\\", \\\"{x:1418,y:943,t:1528139845040};\\\", \\\"{x:1418,y:946,t:1528139845056};\\\", \\\"{x:1416,y:947,t:1528139845072};\\\", \\\"{x:1416,y:948,t:1528139845089};\\\", \\\"{x:1416,y:949,t:1528139845106};\\\", \\\"{x:1415,y:952,t:1528139845122};\\\", \\\"{x:1414,y:953,t:1528139845139};\\\", \\\"{x:1413,y:955,t:1528139845156};\\\", \\\"{x:1412,y:956,t:1528139845183};\\\", \\\"{x:1412,y:959,t:1528139845224};\\\", \\\"{x:1415,y:958,t:1528139845352};\\\", \\\"{x:1417,y:956,t:1528139845359};\\\", \\\"{x:1422,y:953,t:1528139845373};\\\", \\\"{x:1427,y:949,t:1528139845389};\\\", \\\"{x:1433,y:945,t:1528139845406};\\\", \\\"{x:1438,y:939,t:1528139845424};\\\", \\\"{x:1442,y:936,t:1528139845439};\\\", \\\"{x:1445,y:929,t:1528139845456};\\\", \\\"{x:1448,y:926,t:1528139845473};\\\", \\\"{x:1451,y:924,t:1528139845489};\\\", \\\"{x:1451,y:923,t:1528139845631};\\\", \\\"{x:1451,y:922,t:1528139845639};\\\", \\\"{x:1452,y:919,t:1528139845656};\\\", \\\"{x:1453,y:916,t:1528139845673};\\\", \\\"{x:1454,y:911,t:1528139845690};\\\", \\\"{x:1456,y:904,t:1528139845706};\\\", \\\"{x:1459,y:897,t:1528139845723};\\\", \\\"{x:1459,y:894,t:1528139845741};\\\", \\\"{x:1461,y:890,t:1528139845756};\\\", \\\"{x:1462,y:888,t:1528139845784};\\\", \\\"{x:1462,y:887,t:1528139845800};\\\", \\\"{x:1462,y:886,t:1528139845807};\\\", \\\"{x:1462,y:884,t:1528139845823};\\\", \\\"{x:1462,y:882,t:1528139845839};\\\", \\\"{x:1462,y:880,t:1528139845856};\\\", \\\"{x:1463,y:876,t:1528139845873};\\\", \\\"{x:1465,y:874,t:1528139845890};\\\", \\\"{x:1465,y:870,t:1528139845906};\\\", \\\"{x:1466,y:868,t:1528139845923};\\\", \\\"{x:1467,y:866,t:1528139845941};\\\", \\\"{x:1468,y:863,t:1528139845956};\\\", \\\"{x:1468,y:859,t:1528139845973};\\\", \\\"{x:1469,y:852,t:1528139845990};\\\", \\\"{x:1469,y:849,t:1528139846006};\\\", \\\"{x:1473,y:841,t:1528139846023};\\\", \\\"{x:1473,y:839,t:1528139846039};\\\", \\\"{x:1474,y:836,t:1528139846056};\\\", \\\"{x:1476,y:832,t:1528139846073};\\\", \\\"{x:1476,y:830,t:1528139846090};\\\", \\\"{x:1476,y:827,t:1528139846107};\\\", \\\"{x:1477,y:826,t:1528139846123};\\\", \\\"{x:1477,y:824,t:1528139846140};\\\", \\\"{x:1477,y:823,t:1528139846157};\\\", \\\"{x:1478,y:821,t:1528139846173};\\\", \\\"{x:1479,y:820,t:1528139846190};\\\", \\\"{x:1479,y:818,t:1528139846207};\\\", \\\"{x:1479,y:817,t:1528139846231};\\\", \\\"{x:1480,y:816,t:1528139846239};\\\", \\\"{x:1480,y:815,t:1528139846257};\\\", \\\"{x:1481,y:813,t:1528139846273};\\\", \\\"{x:1482,y:812,t:1528139846290};\\\", \\\"{x:1484,y:808,t:1528139846307};\\\", \\\"{x:1485,y:808,t:1528139846323};\\\", \\\"{x:1487,y:805,t:1528139846340};\\\", \\\"{x:1487,y:803,t:1528139846357};\\\", \\\"{x:1489,y:799,t:1528139846373};\\\", \\\"{x:1490,y:797,t:1528139846390};\\\", \\\"{x:1491,y:795,t:1528139846407};\\\", \\\"{x:1492,y:793,t:1528139846424};\\\", \\\"{x:1493,y:792,t:1528139846448};\\\", \\\"{x:1493,y:791,t:1528139846463};\\\", \\\"{x:1494,y:790,t:1528139846475};\\\", \\\"{x:1496,y:788,t:1528139846491};\\\", \\\"{x:1496,y:787,t:1528139846507};\\\", \\\"{x:1497,y:784,t:1528139846524};\\\", \\\"{x:1498,y:784,t:1528139846540};\\\", \\\"{x:1498,y:783,t:1528139846557};\\\", \\\"{x:1498,y:781,t:1528139846574};\\\", \\\"{x:1499,y:780,t:1528139846590};\\\", \\\"{x:1500,y:777,t:1528139846606};\\\", \\\"{x:1502,y:774,t:1528139846624};\\\", \\\"{x:1502,y:772,t:1528139846639};\\\", \\\"{x:1504,y:770,t:1528139846656};\\\", \\\"{x:1504,y:769,t:1528139846674};\\\", \\\"{x:1505,y:768,t:1528139846703};\\\", \\\"{x:1507,y:766,t:1528139846719};\\\", \\\"{x:1509,y:764,t:1528139846734};\\\", \\\"{x:1509,y:763,t:1528139846783};\\\", \\\"{x:1508,y:763,t:1528139847688};\\\", \\\"{x:1507,y:763,t:1528139847719};\\\", \\\"{x:1506,y:765,t:1528139847736};\\\", \\\"{x:1506,y:768,t:1528139847744};\\\", \\\"{x:1505,y:771,t:1528139847759};\\\", \\\"{x:1502,y:778,t:1528139847776};\\\", \\\"{x:1502,y:783,t:1528139847791};\\\", \\\"{x:1502,y:788,t:1528139847808};\\\", \\\"{x:1502,y:791,t:1528139847825};\\\", \\\"{x:1501,y:796,t:1528139847841};\\\", \\\"{x:1501,y:798,t:1528139847858};\\\", \\\"{x:1499,y:802,t:1528139847875};\\\", \\\"{x:1499,y:805,t:1528139847891};\\\", \\\"{x:1499,y:809,t:1528139847908};\\\", \\\"{x:1499,y:815,t:1528139847925};\\\", \\\"{x:1499,y:819,t:1528139847941};\\\", \\\"{x:1499,y:823,t:1528139847958};\\\", \\\"{x:1499,y:828,t:1528139847975};\\\", \\\"{x:1499,y:830,t:1528139847992};\\\", \\\"{x:1498,y:837,t:1528139848008};\\\", \\\"{x:1497,y:841,t:1528139848025};\\\", \\\"{x:1495,y:847,t:1528139848043};\\\", \\\"{x:1494,y:853,t:1528139848058};\\\", \\\"{x:1494,y:856,t:1528139848075};\\\", \\\"{x:1492,y:858,t:1528139848092};\\\", \\\"{x:1491,y:860,t:1528139848108};\\\", \\\"{x:1490,y:863,t:1528139848125};\\\", \\\"{x:1488,y:867,t:1528139848142};\\\", \\\"{x:1486,y:870,t:1528139848159};\\\", \\\"{x:1480,y:882,t:1528139848175};\\\", \\\"{x:1474,y:891,t:1528139848192};\\\", \\\"{x:1469,y:899,t:1528139848208};\\\", \\\"{x:1464,y:907,t:1528139848225};\\\", \\\"{x:1458,y:916,t:1528139848242};\\\", \\\"{x:1456,y:920,t:1528139848258};\\\", \\\"{x:1454,y:924,t:1528139848276};\\\", \\\"{x:1451,y:926,t:1528139848292};\\\", \\\"{x:1449,y:930,t:1528139848309};\\\", \\\"{x:1447,y:932,t:1528139848325};\\\", \\\"{x:1445,y:934,t:1528139848342};\\\", \\\"{x:1444,y:937,t:1528139848358};\\\", \\\"{x:1438,y:943,t:1528139848375};\\\", \\\"{x:1436,y:948,t:1528139848392};\\\", \\\"{x:1434,y:950,t:1528139848409};\\\", \\\"{x:1434,y:949,t:1528139848543};\\\", \\\"{x:1439,y:937,t:1528139848559};\\\", \\\"{x:1446,y:923,t:1528139848575};\\\", \\\"{x:1456,y:911,t:1528139848592};\\\", \\\"{x:1464,y:900,t:1528139848609};\\\", \\\"{x:1475,y:887,t:1528139848625};\\\", \\\"{x:1477,y:881,t:1528139848642};\\\", \\\"{x:1483,y:874,t:1528139848659};\\\", \\\"{x:1487,y:866,t:1528139848676};\\\", \\\"{x:1490,y:861,t:1528139848692};\\\", \\\"{x:1494,y:855,t:1528139848709};\\\", \\\"{x:1497,y:850,t:1528139848727};\\\", \\\"{x:1497,y:849,t:1528139848743};\\\", \\\"{x:1498,y:846,t:1528139848759};\\\", \\\"{x:1500,y:842,t:1528139848776};\\\", \\\"{x:1502,y:837,t:1528139848792};\\\", \\\"{x:1503,y:833,t:1528139848809};\\\", \\\"{x:1504,y:829,t:1528139848826};\\\", \\\"{x:1505,y:825,t:1528139848842};\\\", \\\"{x:1505,y:817,t:1528139848859};\\\", \\\"{x:1507,y:810,t:1528139848876};\\\", \\\"{x:1508,y:800,t:1528139848892};\\\", \\\"{x:1508,y:793,t:1528139848909};\\\", \\\"{x:1509,y:783,t:1528139848926};\\\", \\\"{x:1509,y:779,t:1528139848942};\\\", \\\"{x:1509,y:772,t:1528139848959};\\\", \\\"{x:1509,y:770,t:1528139848976};\\\", \\\"{x:1509,y:769,t:1528139848993};\\\", \\\"{x:1500,y:769,t:1528139849063};\\\", \\\"{x:1477,y:776,t:1528139849077};\\\", \\\"{x:1363,y:797,t:1528139849094};\\\", \\\"{x:1211,y:821,t:1528139849109};\\\", \\\"{x:1114,y:819,t:1528139849127};\\\", \\\"{x:1029,y:819,t:1528139849143};\\\", \\\"{x:1025,y:819,t:1528139849159};\\\", \\\"{x:1021,y:815,t:1528139849176};\\\", \\\"{x:1020,y:814,t:1528139849193};\\\", \\\"{x:1018,y:813,t:1528139849210};\\\", \\\"{x:1018,y:811,t:1528139849226};\\\", \\\"{x:1019,y:807,t:1528139849243};\\\", \\\"{x:1019,y:798,t:1528139849259};\\\", \\\"{x:1023,y:783,t:1528139849276};\\\", \\\"{x:1037,y:764,t:1528139849294};\\\", \\\"{x:1050,y:750,t:1528139849309};\\\", \\\"{x:1069,y:731,t:1528139849326};\\\", \\\"{x:1103,y:696,t:1528139849343};\\\", \\\"{x:1110,y:687,t:1528139849360};\\\", \\\"{x:1113,y:682,t:1528139849376};\\\", \\\"{x:1112,y:673,t:1528139849394};\\\", \\\"{x:1103,y:659,t:1528139849410};\\\", \\\"{x:1095,y:641,t:1528139849426};\\\", \\\"{x:1078,y:627,t:1528139849443};\\\", \\\"{x:1058,y:614,t:1528139849460};\\\", \\\"{x:1035,y:601,t:1528139849476};\\\", \\\"{x:1003,y:583,t:1528139849494};\\\", \\\"{x:977,y:575,t:1528139849510};\\\", \\\"{x:949,y:562,t:1528139849526};\\\", \\\"{x:866,y:532,t:1528139849544};\\\", \\\"{x:821,y:525,t:1528139849559};\\\", \\\"{x:793,y:518,t:1528139849576};\\\", \\\"{x:782,y:518,t:1528139849586};\\\", \\\"{x:766,y:515,t:1528139849603};\\\", \\\"{x:759,y:514,t:1528139849619};\\\", \\\"{x:756,y:514,t:1528139849635};\\\", \\\"{x:754,y:517,t:1528139849652};\\\", \\\"{x:754,y:519,t:1528139849668};\\\", \\\"{x:753,y:521,t:1528139849685};\\\", \\\"{x:751,y:524,t:1528139849702};\\\", \\\"{x:751,y:527,t:1528139849719};\\\", \\\"{x:751,y:531,t:1528139849736};\\\", \\\"{x:751,y:534,t:1528139849752};\\\", \\\"{x:752,y:538,t:1528139849769};\\\", \\\"{x:755,y:540,t:1528139849785};\\\", \\\"{x:758,y:541,t:1528139849806};\\\", \\\"{x:759,y:542,t:1528139849819};\\\", \\\"{x:762,y:545,t:1528139849835};\\\", \\\"{x:768,y:548,t:1528139849852};\\\", \\\"{x:772,y:551,t:1528139849869};\\\", \\\"{x:779,y:555,t:1528139849886};\\\", \\\"{x:787,y:559,t:1528139849904};\\\", \\\"{x:793,y:560,t:1528139849919};\\\", \\\"{x:797,y:561,t:1528139849935};\\\", \\\"{x:802,y:562,t:1528139849953};\\\", \\\"{x:803,y:562,t:1528139849975};\\\", \\\"{x:803,y:563,t:1528139849986};\\\", \\\"{x:805,y:563,t:1528139850003};\\\", \\\"{x:806,y:563,t:1528139850018};\\\", \\\"{x:807,y:563,t:1528139850036};\\\", \\\"{x:812,y:564,t:1528139850053};\\\", \\\"{x:820,y:567,t:1528139850070};\\\", \\\"{x:827,y:570,t:1528139850086};\\\", \\\"{x:849,y:582,t:1528139850104};\\\", \\\"{x:868,y:592,t:1528139850120};\\\", \\\"{x:879,y:603,t:1528139850138};\\\", \\\"{x:881,y:605,t:1528139850153};\\\", \\\"{x:880,y:605,t:1528139850383};\\\", \\\"{x:879,y:605,t:1528139850391};\\\", \\\"{x:878,y:605,t:1528139850402};\\\", \\\"{x:877,y:604,t:1528139850420};\\\", \\\"{x:876,y:603,t:1528139850436};\\\", \\\"{x:873,y:601,t:1528139850452};\\\", \\\"{x:870,y:599,t:1528139850470};\\\", \\\"{x:866,y:598,t:1528139850486};\\\", \\\"{x:864,y:596,t:1528139850503};\\\", \\\"{x:863,y:596,t:1528139850520};\\\", \\\"{x:861,y:596,t:1528139850535};\\\", \\\"{x:860,y:596,t:1528139850553};\\\", \\\"{x:859,y:595,t:1528139850570};\\\", \\\"{x:855,y:594,t:1528139850585};\\\", \\\"{x:853,y:594,t:1528139850603};\\\", \\\"{x:849,y:593,t:1528139850621};\\\", \\\"{x:847,y:593,t:1528139850635};\\\", \\\"{x:844,y:591,t:1528139850652};\\\", \\\"{x:843,y:590,t:1528139850670};\\\", \\\"{x:839,y:588,t:1528139850689};\\\", \\\"{x:839,y:587,t:1528139850703};\\\", \\\"{x:837,y:586,t:1528139850720};\\\", \\\"{x:836,y:585,t:1528139850736};\\\", \\\"{x:836,y:584,t:1528139850758};\\\", \\\"{x:836,y:583,t:1528139850774};\\\", \\\"{x:836,y:582,t:1528139850814};\\\", \\\"{x:831,y:587,t:1528139851110};\\\", \\\"{x:825,y:589,t:1528139851121};\\\", \\\"{x:804,y:599,t:1528139851137};\\\", \\\"{x:780,y:605,t:1528139851154};\\\", \\\"{x:748,y:612,t:1528139851170};\\\", \\\"{x:724,y:616,t:1528139851187};\\\", \\\"{x:665,y:616,t:1528139851204};\\\", \\\"{x:614,y:617,t:1528139851220};\\\", \\\"{x:558,y:622,t:1528139851237};\\\", \\\"{x:525,y:626,t:1528139851254};\\\", \\\"{x:520,y:626,t:1528139851270};\\\", \\\"{x:519,y:626,t:1528139851286};\\\", \\\"{x:518,y:626,t:1528139851367};\\\", \\\"{x:519,y:626,t:1528139851374};\\\", \\\"{x:521,y:624,t:1528139851388};\\\", \\\"{x:526,y:620,t:1528139851404};\\\", \\\"{x:537,y:618,t:1528139851421};\\\", \\\"{x:545,y:615,t:1528139851437};\\\", \\\"{x:557,y:612,t:1528139851455};\\\", \\\"{x:565,y:611,t:1528139851471};\\\", \\\"{x:570,y:609,t:1528139851487};\\\", \\\"{x:577,y:608,t:1528139851504};\\\", \\\"{x:585,y:608,t:1528139851521};\\\", \\\"{x:606,y:608,t:1528139851537};\\\", \\\"{x:622,y:608,t:1528139851554};\\\", \\\"{x:637,y:608,t:1528139851571};\\\", \\\"{x:657,y:610,t:1528139851588};\\\", \\\"{x:667,y:613,t:1528139851604};\\\", \\\"{x:672,y:615,t:1528139851621};\\\", \\\"{x:672,y:617,t:1528139851637};\\\", \\\"{x:673,y:620,t:1528139851654};\\\", \\\"{x:673,y:626,t:1528139851670};\\\", \\\"{x:673,y:627,t:1528139851735};\\\", \\\"{x:672,y:627,t:1528139851759};\\\", \\\"{x:668,y:626,t:1528139851770};\\\", \\\"{x:663,y:621,t:1528139851789};\\\", \\\"{x:655,y:615,t:1528139851804};\\\", \\\"{x:653,y:611,t:1528139851821};\\\", \\\"{x:649,y:602,t:1528139851838};\\\", \\\"{x:643,y:587,t:1528139851856};\\\", \\\"{x:635,y:569,t:1528139851871};\\\", \\\"{x:631,y:561,t:1528139851888};\\\", \\\"{x:628,y:556,t:1528139851903};\\\", \\\"{x:627,y:555,t:1528139851921};\\\", \\\"{x:624,y:555,t:1528139851983};\\\", \\\"{x:622,y:556,t:1528139851990};\\\", \\\"{x:622,y:557,t:1528139852003};\\\", \\\"{x:620,y:558,t:1528139852021};\\\", \\\"{x:619,y:559,t:1528139852037};\\\", \\\"{x:619,y:560,t:1528139852095};\\\", \\\"{x:617,y:562,t:1528139852110};\\\", \\\"{x:616,y:563,t:1528139852128};\\\", \\\"{x:616,y:564,t:1528139852138};\\\", \\\"{x:616,y:565,t:1528139852154};\\\", \\\"{x:616,y:566,t:1528139852171};\\\", \\\"{x:616,y:568,t:1528139852187};\\\", \\\"{x:616,y:570,t:1528139852205};\\\", \\\"{x:616,y:572,t:1528139852221};\\\", \\\"{x:616,y:574,t:1528139852238};\\\", \\\"{x:616,y:576,t:1528139852254};\\\", \\\"{x:616,y:577,t:1528139852271};\\\", \\\"{x:622,y:580,t:1528139853000};\\\", \\\"{x:642,y:586,t:1528139853007};\\\", \\\"{x:692,y:602,t:1528139853024};\\\", \\\"{x:871,y:666,t:1528139853038};\\\", \\\"{x:1021,y:714,t:1528139853055};\\\", \\\"{x:1168,y:742,t:1528139853072};\\\", \\\"{x:1320,y:782,t:1528139853087};\\\", \\\"{x:1446,y:811,t:1528139853104};\\\", \\\"{x:1543,y:837,t:1528139853122};\\\", \\\"{x:1618,y:849,t:1528139853138};\\\", \\\"{x:1647,y:857,t:1528139853155};\\\", \\\"{x:1663,y:857,t:1528139853172};\\\", \\\"{x:1676,y:853,t:1528139853189};\\\", \\\"{x:1687,y:847,t:1528139853205};\\\", \\\"{x:1700,y:841,t:1528139853222};\\\", \\\"{x:1718,y:834,t:1528139853239};\\\", \\\"{x:1725,y:828,t:1528139853255};\\\", \\\"{x:1733,y:817,t:1528139853272};\\\", \\\"{x:1736,y:812,t:1528139853289};\\\", \\\"{x:1736,y:811,t:1528139853305};\\\", \\\"{x:1736,y:810,t:1528139853322};\\\", \\\"{x:1734,y:809,t:1528139853339};\\\", \\\"{x:1729,y:809,t:1528139853355};\\\", \\\"{x:1715,y:809,t:1528139853372};\\\", \\\"{x:1699,y:809,t:1528139853390};\\\", \\\"{x:1682,y:809,t:1528139853405};\\\", \\\"{x:1671,y:811,t:1528139853422};\\\", \\\"{x:1643,y:816,t:1528139853439};\\\", \\\"{x:1626,y:820,t:1528139853456};\\\", \\\"{x:1605,y:825,t:1528139853472};\\\", \\\"{x:1580,y:832,t:1528139853489};\\\", \\\"{x:1555,y:838,t:1528139853505};\\\", \\\"{x:1542,y:843,t:1528139853523};\\\", \\\"{x:1519,y:848,t:1528139853540};\\\", \\\"{x:1493,y:853,t:1528139853555};\\\", \\\"{x:1479,y:855,t:1528139853573};\\\", \\\"{x:1474,y:856,t:1528139853590};\\\", \\\"{x:1474,y:855,t:1528139853664};\\\", \\\"{x:1474,y:853,t:1528139853673};\\\", \\\"{x:1474,y:846,t:1528139853690};\\\", \\\"{x:1474,y:838,t:1528139853706};\\\", \\\"{x:1475,y:834,t:1528139853723};\\\", \\\"{x:1475,y:831,t:1528139853740};\\\", \\\"{x:1475,y:830,t:1528139853848};\\\", \\\"{x:1475,y:829,t:1528139853887};\\\", \\\"{x:1475,y:828,t:1528139853895};\\\", \\\"{x:1476,y:828,t:1528139853919};\\\", \\\"{x:1477,y:827,t:1528139853939};\\\", \\\"{x:1478,y:827,t:1528139853956};\\\", \\\"{x:1480,y:826,t:1528139853973};\\\", \\\"{x:1481,y:826,t:1528139853990};\\\", \\\"{x:1483,y:825,t:1528139854006};\\\", \\\"{x:1485,y:824,t:1528139854025};\\\", \\\"{x:1486,y:824,t:1528139854039};\\\", \\\"{x:1487,y:824,t:1528139854057};\\\", \\\"{x:1487,y:823,t:1528139854073};\\\", \\\"{x:1488,y:823,t:1528139854090};\\\", \\\"{x:1490,y:822,t:1528139854200};\\\", \\\"{x:1490,y:819,t:1528139854240};\\\", \\\"{x:1490,y:818,t:1528139854257};\\\", \\\"{x:1491,y:814,t:1528139854274};\\\", \\\"{x:1491,y:812,t:1528139854290};\\\", \\\"{x:1493,y:808,t:1528139854306};\\\", \\\"{x:1495,y:807,t:1528139854322};\\\", \\\"{x:1495,y:806,t:1528139854339};\\\", \\\"{x:1495,y:805,t:1528139854356};\\\", \\\"{x:1495,y:803,t:1528139854374};\\\", \\\"{x:1495,y:802,t:1528139854391};\\\", \\\"{x:1495,y:800,t:1528139854406};\\\", \\\"{x:1497,y:798,t:1528139854422};\\\", \\\"{x:1498,y:797,t:1528139854439};\\\", \\\"{x:1499,y:795,t:1528139854463};\\\", \\\"{x:1500,y:795,t:1528139854473};\\\", \\\"{x:1501,y:793,t:1528139854489};\\\", \\\"{x:1504,y:792,t:1528139854506};\\\", \\\"{x:1504,y:790,t:1528139854523};\\\", \\\"{x:1506,y:786,t:1528139854539};\\\", \\\"{x:1509,y:782,t:1528139854556};\\\", \\\"{x:1510,y:780,t:1528139854573};\\\", \\\"{x:1512,y:777,t:1528139854589};\\\", \\\"{x:1512,y:776,t:1528139854606};\\\", \\\"{x:1514,y:773,t:1528139854622};\\\", \\\"{x:1514,y:772,t:1528139854640};\\\", \\\"{x:1515,y:770,t:1528139854657};\\\", \\\"{x:1515,y:767,t:1528139854674};\\\", \\\"{x:1516,y:765,t:1528139854690};\\\", \\\"{x:1517,y:763,t:1528139854706};\\\", \\\"{x:1517,y:762,t:1528139854724};\\\", \\\"{x:1517,y:760,t:1528139854760};\\\", \\\"{x:1516,y:760,t:1528139854895};\\\", \\\"{x:1516,y:761,t:1528139854906};\\\", \\\"{x:1513,y:764,t:1528139854923};\\\", \\\"{x:1510,y:768,t:1528139854941};\\\", \\\"{x:1506,y:773,t:1528139854957};\\\", \\\"{x:1504,y:779,t:1528139854973};\\\", \\\"{x:1502,y:781,t:1528139854990};\\\", \\\"{x:1502,y:783,t:1528139855007};\\\", \\\"{x:1500,y:787,t:1528139855023};\\\", \\\"{x:1498,y:790,t:1528139855041};\\\", \\\"{x:1495,y:795,t:1528139855056};\\\", \\\"{x:1491,y:802,t:1528139855074};\\\", \\\"{x:1486,y:810,t:1528139855091};\\\", \\\"{x:1486,y:811,t:1528139855107};\\\", \\\"{x:1484,y:814,t:1528139855124};\\\", \\\"{x:1483,y:815,t:1528139855141};\\\", \\\"{x:1482,y:817,t:1528139855156};\\\", \\\"{x:1481,y:819,t:1528139855173};\\\", \\\"{x:1479,y:823,t:1528139855190};\\\", \\\"{x:1476,y:828,t:1528139855206};\\\", \\\"{x:1474,y:832,t:1528139855223};\\\", \\\"{x:1473,y:832,t:1528139855240};\\\", \\\"{x:1472,y:834,t:1528139855257};\\\", \\\"{x:1470,y:837,t:1528139855272};\\\", \\\"{x:1469,y:841,t:1528139855290};\\\", \\\"{x:1464,y:850,t:1528139855307};\\\", \\\"{x:1461,y:856,t:1528139855323};\\\", \\\"{x:1457,y:861,t:1528139855340};\\\", \\\"{x:1453,y:867,t:1528139855357};\\\", \\\"{x:1452,y:869,t:1528139855373};\\\", \\\"{x:1451,y:871,t:1528139855390};\\\", \\\"{x:1448,y:878,t:1528139855407};\\\", \\\"{x:1445,y:883,t:1528139855423};\\\", \\\"{x:1442,y:891,t:1528139855440};\\\", \\\"{x:1439,y:899,t:1528139855458};\\\", \\\"{x:1435,y:906,t:1528139855473};\\\", \\\"{x:1433,y:914,t:1528139855490};\\\", \\\"{x:1431,y:919,t:1528139855507};\\\", \\\"{x:1428,y:924,t:1528139855524};\\\", \\\"{x:1425,y:929,t:1528139855540};\\\", \\\"{x:1423,y:936,t:1528139855557};\\\", \\\"{x:1420,y:944,t:1528139855573};\\\", \\\"{x:1417,y:950,t:1528139855590};\\\", \\\"{x:1416,y:953,t:1528139855607};\\\", \\\"{x:1414,y:956,t:1528139855623};\\\", \\\"{x:1412,y:959,t:1528139855640};\\\", \\\"{x:1411,y:960,t:1528139855658};\\\", \\\"{x:1411,y:961,t:1528139855673};\\\", \\\"{x:1410,y:963,t:1528139855691};\\\", \\\"{x:1409,y:965,t:1528139855707};\\\", \\\"{x:1408,y:966,t:1528139855727};\\\", \\\"{x:1407,y:967,t:1528139855743};\\\", \\\"{x:1406,y:968,t:1528139855757};\\\", \\\"{x:1407,y:966,t:1528139855840};\\\", \\\"{x:1416,y:954,t:1528139855857};\\\", \\\"{x:1429,y:937,t:1528139855874};\\\", \\\"{x:1444,y:922,t:1528139855891};\\\", \\\"{x:1451,y:906,t:1528139855907};\\\", \\\"{x:1461,y:896,t:1528139855923};\\\", \\\"{x:1469,y:885,t:1528139855940};\\\", \\\"{x:1477,y:871,t:1528139855957};\\\", \\\"{x:1479,y:861,t:1528139855974};\\\", \\\"{x:1481,y:852,t:1528139855990};\\\", \\\"{x:1484,y:844,t:1528139856007};\\\", \\\"{x:1485,y:839,t:1528139856024};\\\", \\\"{x:1490,y:830,t:1528139856041};\\\", \\\"{x:1493,y:821,t:1528139856057};\\\", \\\"{x:1495,y:815,t:1528139856074};\\\", \\\"{x:1498,y:808,t:1528139856090};\\\", \\\"{x:1500,y:800,t:1528139856107};\\\", \\\"{x:1502,y:795,t:1528139856124};\\\", \\\"{x:1505,y:793,t:1528139856141};\\\", \\\"{x:1505,y:790,t:1528139856157};\\\", \\\"{x:1506,y:788,t:1528139856208};\\\", \\\"{x:1507,y:788,t:1528139856224};\\\", \\\"{x:1507,y:787,t:1528139856241};\\\", \\\"{x:1508,y:786,t:1528139856257};\\\", \\\"{x:1508,y:783,t:1528139856275};\\\", \\\"{x:1508,y:782,t:1528139856292};\\\", \\\"{x:1509,y:781,t:1528139856308};\\\", \\\"{x:1509,y:780,t:1528139856325};\\\", \\\"{x:1509,y:779,t:1528139856341};\\\", \\\"{x:1509,y:778,t:1528139856358};\\\", \\\"{x:1510,y:776,t:1528139856375};\\\", \\\"{x:1512,y:772,t:1528139856391};\\\", \\\"{x:1512,y:771,t:1528139856407};\\\", \\\"{x:1510,y:770,t:1528139856903};\\\", \\\"{x:1498,y:775,t:1528139856911};\\\", \\\"{x:1477,y:790,t:1528139856924};\\\", \\\"{x:1425,y:817,t:1528139856941};\\\", \\\"{x:1296,y:850,t:1528139856958};\\\", \\\"{x:1196,y:866,t:1528139856974};\\\", \\\"{x:1133,y:866,t:1528139856991};\\\", \\\"{x:1097,y:857,t:1528139857008};\\\", \\\"{x:1066,y:851,t:1528139857025};\\\", \\\"{x:1042,y:836,t:1528139857041};\\\", \\\"{x:1021,y:822,t:1528139857058};\\\", \\\"{x:999,y:806,t:1528139857074};\\\", \\\"{x:977,y:794,t:1528139857091};\\\", \\\"{x:950,y:775,t:1528139857108};\\\", \\\"{x:924,y:762,t:1528139857125};\\\", \\\"{x:900,y:756,t:1528139857141};\\\", \\\"{x:875,y:747,t:1528139857158};\\\", \\\"{x:843,y:737,t:1528139857175};\\\", \\\"{x:831,y:731,t:1528139857191};\\\", \\\"{x:829,y:731,t:1528139857209};\\\", \\\"{x:828,y:731,t:1528139857255};\\\", \\\"{x:823,y:730,t:1528139857263};\\\", \\\"{x:814,y:728,t:1528139857274};\\\", \\\"{x:789,y:723,t:1528139857291};\\\", \\\"{x:760,y:715,t:1528139857308};\\\", \\\"{x:729,y:701,t:1528139857325};\\\", \\\"{x:693,y:691,t:1528139857342};\\\", \\\"{x:639,y:671,t:1528139857359};\\\", \\\"{x:568,y:654,t:1528139857375};\\\", \\\"{x:558,y:649,t:1528139857391};\\\", \\\"{x:538,y:644,t:1528139857409};\\\", \\\"{x:524,y:641,t:1528139857425};\\\", \\\"{x:518,y:641,t:1528139857441};\\\", \\\"{x:516,y:641,t:1528139857458};\\\", \\\"{x:516,y:644,t:1528139857512};\\\", \\\"{x:516,y:648,t:1528139857526};\\\", \\\"{x:514,y:655,t:1528139857542};\\\", \\\"{x:514,y:664,t:1528139857559};\\\", \\\"{x:514,y:669,t:1528139857575};\\\", \\\"{x:514,y:675,t:1528139857591};\\\", \\\"{x:514,y:684,t:1528139857609};\\\", \\\"{x:513,y:689,t:1528139857626};\\\", \\\"{x:513,y:696,t:1528139857641};\\\", \\\"{x:513,y:702,t:1528139857658};\\\", \\\"{x:513,y:705,t:1528139857676};\\\", \\\"{x:513,y:709,t:1528139857691};\\\", \\\"{x:513,y:713,t:1528139857709};\\\", \\\"{x:514,y:716,t:1528139857726};\\\", \\\"{x:515,y:718,t:1528139857742};\\\", \\\"{x:518,y:724,t:1528139857759};\\\", \\\"{x:521,y:728,t:1528139857775};\\\", \\\"{x:522,y:731,t:1528139857791};\\\", \\\"{x:526,y:737,t:1528139857809};\\\", \\\"{x:528,y:741,t:1528139857826};\\\", \\\"{x:529,y:741,t:1528139857841};\\\", \\\"{x:530,y:741,t:1528139857902};\\\", \\\"{x:531,y:741,t:1528139858023};\\\", \\\"{x:531,y:741,t:1528139858058};\\\", \\\"{x:533,y:744,t:1528139858303};\\\", \\\"{x:540,y:750,t:1528139858310};\\\", \\\"{x:546,y:759,t:1528139858326};\\\", \\\"{x:598,y:800,t:1528139858342};\\\", \\\"{x:647,y:836,t:1528139858359};\\\", \\\"{x:701,y:867,t:1528139858376};\\\", \\\"{x:739,y:897,t:1528139858393};\\\", \\\"{x:760,y:914,t:1528139858409};\\\", \\\"{x:784,y:939,t:1528139858426};\\\", \\\"{x:802,y:956,t:1528139858443};\\\", \\\"{x:814,y:967,t:1528139858459};\\\", \\\"{x:821,y:973,t:1528139858476};\\\", \\\"{x:823,y:975,t:1528139858493};\\\", \\\"{x:824,y:976,t:1528139858509};\\\", \\\"{x:825,y:977,t:1528139858526};\\\" ] }, { \\\"rt\\\": 74815, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 768472, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -X -F -B -B -E -E -F -F -F -F -I -F -F -F -B -F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:824,y:975,t:1528139860144};\\\", \\\"{x:807,y:969,t:1528139860161};\\\", \\\"{x:787,y:962,t:1528139860177};\\\", \\\"{x:770,y:954,t:1528139860194};\\\", \\\"{x:754,y:945,t:1528139860212};\\\", \\\"{x:741,y:939,t:1528139860227};\\\", \\\"{x:733,y:937,t:1528139860245};\\\", \\\"{x:731,y:937,t:1528139860261};\\\", \\\"{x:730,y:937,t:1528139860277};\\\", \\\"{x:729,y:937,t:1528139860294};\\\", \\\"{x:728,y:937,t:1528139860311};\\\", \\\"{x:725,y:937,t:1528139860327};\\\", \\\"{x:723,y:937,t:1528139860345};\\\", \\\"{x:719,y:935,t:1528139860361};\\\", \\\"{x:714,y:929,t:1528139860378};\\\", \\\"{x:696,y:919,t:1528139860394};\\\", \\\"{x:663,y:893,t:1528139860411};\\\", \\\"{x:630,y:858,t:1528139860427};\\\", \\\"{x:570,y:811,t:1528139860444};\\\", \\\"{x:477,y:737,t:1528139860464};\\\", \\\"{x:373,y:672,t:1528139860477};\\\", \\\"{x:195,y:551,t:1528139860495};\\\", \\\"{x:80,y:476,t:1528139860511};\\\", \\\"{x:0,y:403,t:1528139860528};\\\", \\\"{x:0,y:386,t:1528139860544};\\\", \\\"{x:0,y:375,t:1528139860561};\\\", \\\"{x:0,y:368,t:1528139860578};\\\", \\\"{x:0,y:367,t:1528139860614};\\\", \\\"{x:2,y:367,t:1528139860628};\\\", \\\"{x:18,y:367,t:1528139860645};\\\", \\\"{x:39,y:370,t:1528139860661};\\\", \\\"{x:71,y:379,t:1528139860678};\\\", \\\"{x:106,y:382,t:1528139860694};\\\", \\\"{x:135,y:386,t:1528139860711};\\\", \\\"{x:155,y:387,t:1528139860728};\\\", \\\"{x:176,y:387,t:1528139860745};\\\", \\\"{x:197,y:390,t:1528139860761};\\\", \\\"{x:211,y:391,t:1528139860778};\\\", \\\"{x:222,y:391,t:1528139860796};\\\", \\\"{x:227,y:391,t:1528139860812};\\\", \\\"{x:233,y:392,t:1528139860828};\\\", \\\"{x:236,y:393,t:1528139860845};\\\", \\\"{x:239,y:393,t:1528139860862};\\\", \\\"{x:241,y:393,t:1528139860894};\\\", \\\"{x:243,y:395,t:1528139860913};\\\", \\\"{x:248,y:398,t:1528139860930};\\\", \\\"{x:256,y:403,t:1528139860945};\\\", \\\"{x:266,y:407,t:1528139860962};\\\", \\\"{x:284,y:414,t:1528139860979};\\\", \\\"{x:301,y:420,t:1528139860996};\\\", \\\"{x:313,y:424,t:1528139861012};\\\", \\\"{x:330,y:429,t:1528139861029};\\\", \\\"{x:345,y:435,t:1528139861047};\\\", \\\"{x:354,y:438,t:1528139861063};\\\", \\\"{x:357,y:439,t:1528139861079};\\\", \\\"{x:360,y:439,t:1528139861096};\\\", \\\"{x:363,y:439,t:1528139861112};\\\", \\\"{x:365,y:439,t:1528139861129};\\\", \\\"{x:369,y:439,t:1528139861146};\\\", \\\"{x:370,y:438,t:1528139861162};\\\", \\\"{x:371,y:438,t:1528139861180};\\\", \\\"{x:371,y:437,t:1528139861197};\\\", \\\"{x:372,y:437,t:1528139861326};\\\", \\\"{x:374,y:437,t:1528139861374};\\\", \\\"{x:375,y:438,t:1528139861382};\\\", \\\"{x:377,y:438,t:1528139861396};\\\", \\\"{x:378,y:439,t:1528139861413};\\\", \\\"{x:380,y:439,t:1528139861430};\\\", \\\"{x:381,y:439,t:1528139861446};\\\", \\\"{x:382,y:439,t:1528139861478};\\\", \\\"{x:383,y:439,t:1528139861559};\\\", \\\"{x:384,y:440,t:1528139861576};\\\", \\\"{x:385,y:441,t:1528139861591};\\\", \\\"{x:385,y:444,t:1528139861599};\\\", \\\"{x:388,y:448,t:1528139861615};\\\", \\\"{x:393,y:452,t:1528139861631};\\\", \\\"{x:396,y:456,t:1528139861647};\\\", \\\"{x:400,y:462,t:1528139861665};\\\", \\\"{x:403,y:467,t:1528139861681};\\\", \\\"{x:409,y:473,t:1528139861698};\\\", \\\"{x:412,y:476,t:1528139861714};\\\", \\\"{x:412,y:477,t:1528139861731};\\\", \\\"{x:413,y:480,t:1528139861748};\\\", \\\"{x:415,y:482,t:1528139861765};\\\", \\\"{x:415,y:483,t:1528139861783};\\\", \\\"{x:416,y:485,t:1528139861798};\\\", \\\"{x:417,y:488,t:1528139861823};\\\", \\\"{x:418,y:488,t:1528139861838};\\\", \\\"{x:419,y:489,t:1528139861854};\\\", \\\"{x:421,y:489,t:1528139861870};\\\", \\\"{x:423,y:489,t:1528139861878};\\\", \\\"{x:426,y:489,t:1528139861895};\\\", \\\"{x:431,y:489,t:1528139861912};\\\", \\\"{x:436,y:489,t:1528139861929};\\\", \\\"{x:436,y:488,t:1528139861950};\\\", \\\"{x:441,y:486,t:1528139861967};\\\", \\\"{x:443,y:486,t:1528139861979};\\\", \\\"{x:449,y:486,t:1528139861995};\\\", \\\"{x:455,y:484,t:1528139862012};\\\", \\\"{x:456,y:483,t:1528139862029};\\\", \\\"{x:459,y:483,t:1528139862045};\\\", \\\"{x:461,y:483,t:1528139862062};\\\", \\\"{x:463,y:482,t:1528139862086};\\\", \\\"{x:464,y:481,t:1528139862102};\\\", \\\"{x:465,y:481,t:1528139862113};\\\", \\\"{x:466,y:480,t:1528139862129};\\\", \\\"{x:469,y:480,t:1528139862145};\\\", \\\"{x:471,y:479,t:1528139862167};\\\", \\\"{x:472,y:478,t:1528139862183};\\\", \\\"{x:473,y:477,t:1528139862231};\\\", \\\"{x:475,y:477,t:1528139862247};\\\", \\\"{x:477,y:476,t:1528139862263};\\\", \\\"{x:480,y:474,t:1528139862279};\\\", \\\"{x:486,y:472,t:1528139862297};\\\", \\\"{x:490,y:471,t:1528139862312};\\\", \\\"{x:496,y:471,t:1528139862330};\\\", \\\"{x:503,y:471,t:1528139862347};\\\", \\\"{x:511,y:472,t:1528139862362};\\\", \\\"{x:524,y:476,t:1528139862379};\\\", \\\"{x:541,y:483,t:1528139862397};\\\", \\\"{x:552,y:487,t:1528139862414};\\\", \\\"{x:569,y:496,t:1528139862429};\\\", \\\"{x:587,y:501,t:1528139862446};\\\", \\\"{x:594,y:502,t:1528139862462};\\\", \\\"{x:598,y:504,t:1528139862478};\\\", \\\"{x:599,y:504,t:1528139862496};\\\", \\\"{x:602,y:505,t:1528139862513};\\\", \\\"{x:604,y:505,t:1528139862534};\\\", \\\"{x:605,y:504,t:1528139862546};\\\", \\\"{x:607,y:504,t:1528139862574};\\\", \\\"{x:608,y:504,t:1528139862591};\\\", \\\"{x:609,y:504,t:1528139862615};\\\", \\\"{x:611,y:503,t:1528139862629};\\\", \\\"{x:616,y:500,t:1528139862647};\\\", \\\"{x:618,y:499,t:1528139862663};\\\", \\\"{x:622,y:498,t:1528139862679};\\\", \\\"{x:623,y:497,t:1528139862696};\\\", \\\"{x:625,y:496,t:1528139862713};\\\", \\\"{x:626,y:495,t:1528139862729};\\\", \\\"{x:628,y:495,t:1528139862746};\\\", \\\"{x:629,y:494,t:1528139862764};\\\", \\\"{x:631,y:493,t:1528139862779};\\\", \\\"{x:632,y:493,t:1528139862797};\\\", \\\"{x:634,y:492,t:1528139862814};\\\", \\\"{x:644,y:491,t:1528139862830};\\\", \\\"{x:691,y:491,t:1528139862847};\\\", \\\"{x:728,y:489,t:1528139862865};\\\", \\\"{x:760,y:489,t:1528139862879};\\\", \\\"{x:782,y:492,t:1528139862895};\\\", \\\"{x:816,y:497,t:1528139862913};\\\", \\\"{x:867,y:504,t:1528139862929};\\\", \\\"{x:885,y:510,t:1528139862946};\\\", \\\"{x:918,y:515,t:1528139862963};\\\", \\\"{x:942,y:521,t:1528139862979};\\\", \\\"{x:955,y:524,t:1528139862996};\\\", \\\"{x:961,y:526,t:1528139863013};\\\", \\\"{x:968,y:536,t:1528139863030};\\\", \\\"{x:977,y:551,t:1528139863046};\\\", \\\"{x:995,y:564,t:1528139863064};\\\", \\\"{x:998,y:576,t:1528139863081};\\\", \\\"{x:1000,y:576,t:1528139863599};\\\", \\\"{x:1008,y:578,t:1528139863614};\\\", \\\"{x:1072,y:597,t:1528139863631};\\\", \\\"{x:1125,y:615,t:1528139863647};\\\", \\\"{x:1181,y:631,t:1528139863664};\\\", \\\"{x:1228,y:647,t:1528139863681};\\\", \\\"{x:1249,y:656,t:1528139863698};\\\", \\\"{x:1280,y:665,t:1528139863714};\\\", \\\"{x:1305,y:671,t:1528139863730};\\\", \\\"{x:1332,y:683,t:1528139863748};\\\", \\\"{x:1361,y:698,t:1528139863763};\\\", \\\"{x:1385,y:714,t:1528139863781};\\\", \\\"{x:1404,y:722,t:1528139863797};\\\", \\\"{x:1423,y:734,t:1528139863814};\\\", \\\"{x:1436,y:744,t:1528139863831};\\\", \\\"{x:1442,y:751,t:1528139863847};\\\", \\\"{x:1445,y:753,t:1528139863864};\\\", \\\"{x:1446,y:756,t:1528139863881};\\\", \\\"{x:1446,y:761,t:1528139863898};\\\", \\\"{x:1446,y:763,t:1528139863914};\\\", \\\"{x:1444,y:765,t:1528139863967};\\\", \\\"{x:1443,y:767,t:1528139863980};\\\", \\\"{x:1436,y:775,t:1528139863998};\\\", \\\"{x:1425,y:785,t:1528139864015};\\\", \\\"{x:1416,y:790,t:1528139864031};\\\", \\\"{x:1409,y:793,t:1528139864048};\\\", \\\"{x:1404,y:794,t:1528139864065};\\\", \\\"{x:1396,y:794,t:1528139864081};\\\", \\\"{x:1393,y:794,t:1528139864098};\\\", \\\"{x:1386,y:791,t:1528139864114};\\\", \\\"{x:1381,y:787,t:1528139864131};\\\", \\\"{x:1375,y:781,t:1528139864148};\\\", \\\"{x:1373,y:779,t:1528139864165};\\\", \\\"{x:1369,y:776,t:1528139864181};\\\", \\\"{x:1366,y:769,t:1528139864198};\\\", \\\"{x:1360,y:764,t:1528139864215};\\\", \\\"{x:1356,y:759,t:1528139864231};\\\", \\\"{x:1354,y:757,t:1528139864248};\\\", \\\"{x:1353,y:757,t:1528139864265};\\\", \\\"{x:1352,y:756,t:1528139864430};\\\", \\\"{x:1355,y:753,t:1528139864454};\\\", \\\"{x:1356,y:753,t:1528139864465};\\\", \\\"{x:1356,y:754,t:1528139864783};\\\", \\\"{x:1356,y:755,t:1528139864798};\\\", \\\"{x:1353,y:759,t:1528139864815};\\\", \\\"{x:1352,y:760,t:1528139864834};\\\", \\\"{x:1351,y:761,t:1528139864942};\\\", \\\"{x:1350,y:762,t:1528139864950};\\\", \\\"{x:1349,y:763,t:1528139864966};\\\", \\\"{x:1347,y:764,t:1528139864990};\\\", \\\"{x:1346,y:764,t:1528139865014};\\\", \\\"{x:1344,y:764,t:1528139865071};\\\", \\\"{x:1343,y:764,t:1528139865086};\\\", \\\"{x:1351,y:766,t:1528139865303};\\\", \\\"{x:1353,y:767,t:1528139865316};\\\", \\\"{x:1371,y:772,t:1528139865332};\\\", \\\"{x:1397,y:778,t:1528139865348};\\\", \\\"{x:1422,y:786,t:1528139865366};\\\", \\\"{x:1445,y:792,t:1528139865381};\\\", \\\"{x:1453,y:795,t:1528139865398};\\\", \\\"{x:1461,y:798,t:1528139865415};\\\", \\\"{x:1468,y:800,t:1528139865431};\\\", \\\"{x:1471,y:801,t:1528139865449};\\\", \\\"{x:1475,y:801,t:1528139865466};\\\", \\\"{x:1477,y:802,t:1528139865760};\\\", \\\"{x:1477,y:803,t:1528139865767};\\\", \\\"{x:1477,y:805,t:1528139865782};\\\", \\\"{x:1477,y:807,t:1528139865799};\\\", \\\"{x:1480,y:809,t:1528139866327};\\\", \\\"{x:1480,y:811,t:1528139866335};\\\", \\\"{x:1484,y:813,t:1528139866349};\\\", \\\"{x:1489,y:818,t:1528139866366};\\\", \\\"{x:1495,y:822,t:1528139866383};\\\", \\\"{x:1495,y:823,t:1528139866399};\\\", \\\"{x:1496,y:823,t:1528139866416};\\\", \\\"{x:1497,y:823,t:1528139866623};\\\", \\\"{x:1498,y:823,t:1528139866687};\\\", \\\"{x:1499,y:823,t:1528139866700};\\\", \\\"{x:1500,y:823,t:1528139866716};\\\", \\\"{x:1501,y:823,t:1528139866733};\\\", \\\"{x:1502,y:823,t:1528139866767};\\\", \\\"{x:1503,y:823,t:1528139866791};\\\", \\\"{x:1504,y:824,t:1528139866800};\\\", \\\"{x:1505,y:825,t:1528139867007};\\\", \\\"{x:1505,y:826,t:1528139867017};\\\", \\\"{x:1505,y:827,t:1528139867033};\\\", \\\"{x:1504,y:828,t:1528139867050};\\\", \\\"{x:1502,y:828,t:1528139867067};\\\", \\\"{x:1500,y:828,t:1528139867083};\\\", \\\"{x:1498,y:829,t:1528139867100};\\\", \\\"{x:1497,y:830,t:1528139867117};\\\", \\\"{x:1496,y:830,t:1528139867175};\\\", \\\"{x:1495,y:831,t:1528139867480};\\\", \\\"{x:1494,y:831,t:1528139867519};\\\", \\\"{x:1492,y:832,t:1528139867535};\\\", \\\"{x:1491,y:833,t:1528139867550};\\\", \\\"{x:1489,y:833,t:1528139867567};\\\", \\\"{x:1487,y:833,t:1528139867583};\\\", \\\"{x:1486,y:833,t:1528139867600};\\\", \\\"{x:1484,y:833,t:1528139867617};\\\", \\\"{x:1483,y:833,t:1528139867634};\\\", \\\"{x:1482,y:833,t:1528139867650};\\\", \\\"{x:1481,y:833,t:1528139867687};\\\", \\\"{x:1479,y:833,t:1528139867711};\\\", \\\"{x:1478,y:833,t:1528139867726};\\\", \\\"{x:1477,y:833,t:1528139867743};\\\", \\\"{x:1476,y:833,t:1528139870320};\\\", \\\"{x:1475,y:816,t:1528139870336};\\\", \\\"{x:1474,y:796,t:1528139870352};\\\", \\\"{x:1472,y:783,t:1528139870369};\\\", \\\"{x:1470,y:774,t:1528139870386};\\\", \\\"{x:1467,y:768,t:1528139870402};\\\", \\\"{x:1465,y:761,t:1528139870419};\\\", \\\"{x:1462,y:755,t:1528139870436};\\\", \\\"{x:1461,y:752,t:1528139870452};\\\", \\\"{x:1458,y:749,t:1528139870469};\\\", \\\"{x:1456,y:745,t:1528139870486};\\\", \\\"{x:1450,y:740,t:1528139870502};\\\", \\\"{x:1433,y:729,t:1528139870519};\\\", \\\"{x:1413,y:721,t:1528139870536};\\\", \\\"{x:1396,y:714,t:1528139870552};\\\", \\\"{x:1373,y:707,t:1528139870570};\\\", \\\"{x:1351,y:701,t:1528139870587};\\\", \\\"{x:1337,y:696,t:1528139870604};\\\", \\\"{x:1325,y:693,t:1528139870619};\\\", \\\"{x:1315,y:693,t:1528139870636};\\\", \\\"{x:1303,y:698,t:1528139870653};\\\", \\\"{x:1288,y:706,t:1528139870669};\\\", \\\"{x:1282,y:711,t:1528139870686};\\\", \\\"{x:1266,y:736,t:1528139870703};\\\", \\\"{x:1259,y:757,t:1528139870719};\\\", \\\"{x:1256,y:768,t:1528139870736};\\\", \\\"{x:1256,y:772,t:1528139870753};\\\", \\\"{x:1256,y:774,t:1528139870769};\\\", \\\"{x:1256,y:775,t:1528139870786};\\\", \\\"{x:1257,y:776,t:1528139870803};\\\", \\\"{x:1265,y:776,t:1528139870819};\\\", \\\"{x:1284,y:779,t:1528139870836};\\\", \\\"{x:1296,y:780,t:1528139870853};\\\", \\\"{x:1321,y:785,t:1528139870869};\\\", \\\"{x:1334,y:785,t:1528139870887};\\\", \\\"{x:1357,y:785,t:1528139870901};\\\", \\\"{x:1365,y:785,t:1528139870919};\\\", \\\"{x:1373,y:785,t:1528139870935};\\\", \\\"{x:1377,y:782,t:1528139870952};\\\", \\\"{x:1379,y:780,t:1528139870969};\\\", \\\"{x:1381,y:777,t:1528139870986};\\\", \\\"{x:1381,y:773,t:1528139871002};\\\", \\\"{x:1379,y:767,t:1528139871019};\\\", \\\"{x:1375,y:761,t:1528139871036};\\\", \\\"{x:1371,y:758,t:1528139871053};\\\", \\\"{x:1367,y:755,t:1528139871070};\\\", \\\"{x:1365,y:753,t:1528139871086};\\\", \\\"{x:1363,y:752,t:1528139871102};\\\", \\\"{x:1362,y:752,t:1528139871135};\\\", \\\"{x:1360,y:752,t:1528139871153};\\\", \\\"{x:1357,y:750,t:1528139871169};\\\", \\\"{x:1356,y:750,t:1528139871186};\\\", \\\"{x:1353,y:750,t:1528139871202};\\\", \\\"{x:1352,y:750,t:1528139871263};\\\", \\\"{x:1350,y:751,t:1528139871271};\\\", \\\"{x:1349,y:751,t:1528139871295};\\\", \\\"{x:1348,y:751,t:1528139871302};\\\", \\\"{x:1347,y:751,t:1528139871319};\\\", \\\"{x:1345,y:752,t:1528139871390};\\\", \\\"{x:1345,y:753,t:1528139871403};\\\", \\\"{x:1345,y:754,t:1528139871423};\\\", \\\"{x:1344,y:754,t:1528139871435};\\\", \\\"{x:1343,y:754,t:1528139871453};\\\", \\\"{x:1343,y:755,t:1528139871469};\\\", \\\"{x:1342,y:756,t:1528139871487};\\\", \\\"{x:1341,y:758,t:1528139871511};\\\", \\\"{x:1340,y:758,t:1528139871599};\\\", \\\"{x:1340,y:759,t:1528139872135};\\\", \\\"{x:1344,y:760,t:1528139872143};\\\", \\\"{x:1347,y:760,t:1528139872154};\\\", \\\"{x:1351,y:762,t:1528139872170};\\\", \\\"{x:1352,y:762,t:1528139872190};\\\", \\\"{x:1351,y:760,t:1528139884743};\\\", \\\"{x:1332,y:734,t:1528139884751};\\\", \\\"{x:1298,y:705,t:1528139884764};\\\", \\\"{x:1224,y:661,t:1528139884779};\\\", \\\"{x:1148,y:622,t:1528139884797};\\\", \\\"{x:1064,y:574,t:1528139884813};\\\", \\\"{x:988,y:535,t:1528139884830};\\\", \\\"{x:856,y:467,t:1528139884846};\\\", \\\"{x:799,y:436,t:1528139884863};\\\", \\\"{x:762,y:410,t:1528139884879};\\\", \\\"{x:744,y:397,t:1528139884897};\\\", \\\"{x:742,y:394,t:1528139884913};\\\", \\\"{x:741,y:393,t:1528139884929};\\\", \\\"{x:742,y:393,t:1528139884966};\\\", \\\"{x:747,y:393,t:1528139884979};\\\", \\\"{x:753,y:393,t:1528139884996};\\\", \\\"{x:756,y:391,t:1528139885013};\\\", \\\"{x:762,y:389,t:1528139885029};\\\", \\\"{x:776,y:387,t:1528139885046};\\\", \\\"{x:801,y:387,t:1528139885063};\\\", \\\"{x:830,y:388,t:1528139885079};\\\", \\\"{x:868,y:397,t:1528139885096};\\\", \\\"{x:914,y:418,t:1528139885114};\\\", \\\"{x:974,y:442,t:1528139885130};\\\", \\\"{x:1027,y:460,t:1528139885146};\\\", \\\"{x:1065,y:474,t:1528139885164};\\\", \\\"{x:1085,y:485,t:1528139885181};\\\", \\\"{x:1100,y:492,t:1528139885196};\\\", \\\"{x:1107,y:496,t:1528139885213};\\\", \\\"{x:1108,y:497,t:1528139885271};\\\", \\\"{x:1108,y:498,t:1528139885303};\\\", \\\"{x:1107,y:499,t:1528139885314};\\\", \\\"{x:1101,y:501,t:1528139885330};\\\", \\\"{x:1096,y:502,t:1528139885346};\\\", \\\"{x:1093,y:502,t:1528139885363};\\\", \\\"{x:1092,y:502,t:1528139885381};\\\", \\\"{x:1091,y:502,t:1528139885396};\\\", \\\"{x:1090,y:502,t:1528139885422};\\\", \\\"{x:1089,y:502,t:1528139885430};\\\", \\\"{x:1086,y:502,t:1528139885447};\\\", \\\"{x:1084,y:502,t:1528139885527};\\\", \\\"{x:1082,y:502,t:1528139885542};\\\", \\\"{x:1082,y:501,t:1528139885550};\\\", \\\"{x:1081,y:501,t:1528139885563};\\\", \\\"{x:1077,y:498,t:1528139885581};\\\", \\\"{x:1076,y:497,t:1528139885597};\\\", \\\"{x:1074,y:495,t:1528139885614};\\\", \\\"{x:1074,y:493,t:1528139885751};\\\", \\\"{x:1074,y:492,t:1528139886616};\\\", \\\"{x:1074,y:491,t:1528139886624};\\\", \\\"{x:1078,y:488,t:1528139886641};\\\", \\\"{x:1083,y:486,t:1528139886657};\\\", \\\"{x:1085,y:485,t:1528139886674};\\\", \\\"{x:1087,y:484,t:1528139886691};\\\", \\\"{x:1088,y:484,t:1528139886707};\\\", \\\"{x:1090,y:484,t:1528139886724};\\\", \\\"{x:1091,y:483,t:1528139886742};\\\", \\\"{x:1094,y:482,t:1528139886757};\\\", \\\"{x:1098,y:480,t:1528139886774};\\\", \\\"{x:1102,y:477,t:1528139886791};\\\", \\\"{x:1111,y:477,t:1528139886807};\\\", \\\"{x:1131,y:478,t:1528139886824};\\\", \\\"{x:1146,y:484,t:1528139886841};\\\", \\\"{x:1162,y:489,t:1528139886857};\\\", \\\"{x:1172,y:491,t:1528139886874};\\\", \\\"{x:1191,y:499,t:1528139886891};\\\", \\\"{x:1204,y:504,t:1528139886907};\\\", \\\"{x:1220,y:506,t:1528139886924};\\\", \\\"{x:1233,y:510,t:1528139886941};\\\", \\\"{x:1237,y:510,t:1528139886957};\\\", \\\"{x:1240,y:511,t:1528139886974};\\\", \\\"{x:1241,y:511,t:1528139886992};\\\", \\\"{x:1243,y:511,t:1528139887007};\\\", \\\"{x:1250,y:511,t:1528139887024};\\\", \\\"{x:1257,y:514,t:1528139887042};\\\", \\\"{x:1264,y:516,t:1528139887057};\\\", \\\"{x:1267,y:516,t:1528139887074};\\\", \\\"{x:1274,y:517,t:1528139887091};\\\", \\\"{x:1278,y:517,t:1528139887108};\\\", \\\"{x:1286,y:517,t:1528139887124};\\\", \\\"{x:1291,y:512,t:1528139887141};\\\", \\\"{x:1298,y:508,t:1528139887159};\\\", \\\"{x:1304,y:504,t:1528139887174};\\\", \\\"{x:1311,y:500,t:1528139887192};\\\", \\\"{x:1320,y:496,t:1528139887208};\\\", \\\"{x:1328,y:495,t:1528139887224};\\\", \\\"{x:1333,y:493,t:1528139887241};\\\", \\\"{x:1334,y:491,t:1528139887258};\\\", \\\"{x:1335,y:491,t:1528139887274};\\\", \\\"{x:1337,y:490,t:1528139887291};\\\", \\\"{x:1339,y:490,t:1528139887308};\\\", \\\"{x:1342,y:488,t:1528139887324};\\\", \\\"{x:1345,y:488,t:1528139887342};\\\", \\\"{x:1348,y:486,t:1528139887358};\\\", \\\"{x:1349,y:486,t:1528139887374};\\\", \\\"{x:1352,y:485,t:1528139887392};\\\", \\\"{x:1353,y:485,t:1528139887408};\\\", \\\"{x:1354,y:485,t:1528139887448};\\\", \\\"{x:1355,y:484,t:1528139887464};\\\", \\\"{x:1356,y:484,t:1528139887474};\\\", \\\"{x:1357,y:484,t:1528139887491};\\\", \\\"{x:1358,y:483,t:1528139887508};\\\", \\\"{x:1360,y:482,t:1528139887525};\\\", \\\"{x:1358,y:484,t:1528139887744};\\\", \\\"{x:1357,y:486,t:1528139887761};\\\", \\\"{x:1356,y:486,t:1528139887776};\\\", \\\"{x:1356,y:487,t:1528139887791};\\\", \\\"{x:1354,y:489,t:1528139887808};\\\", \\\"{x:1352,y:489,t:1528139887825};\\\", \\\"{x:1351,y:490,t:1528139887842};\\\", \\\"{x:1351,y:492,t:1528139887858};\\\", \\\"{x:1349,y:492,t:1528139887875};\\\", \\\"{x:1349,y:493,t:1528139887891};\\\", \\\"{x:1348,y:494,t:1528139887908};\\\", \\\"{x:1346,y:496,t:1528139887925};\\\", \\\"{x:1345,y:497,t:1528139887942};\\\", \\\"{x:1344,y:499,t:1528139887958};\\\", \\\"{x:1343,y:500,t:1528139887992};\\\", \\\"{x:1341,y:502,t:1528139888008};\\\", \\\"{x:1339,y:505,t:1528139888025};\\\", \\\"{x:1337,y:506,t:1528139888043};\\\", \\\"{x:1332,y:510,t:1528139888058};\\\", \\\"{x:1327,y:513,t:1528139888075};\\\", \\\"{x:1324,y:517,t:1528139888093};\\\", \\\"{x:1323,y:519,t:1528139888108};\\\", \\\"{x:1316,y:527,t:1528139888124};\\\", \\\"{x:1308,y:530,t:1528139888141};\\\", \\\"{x:1303,y:536,t:1528139888158};\\\", \\\"{x:1299,y:539,t:1528139888175};\\\", \\\"{x:1295,y:542,t:1528139888191};\\\", \\\"{x:1293,y:543,t:1528139888207};\\\", \\\"{x:1291,y:545,t:1528139888224};\\\", \\\"{x:1289,y:546,t:1528139888242};\\\", \\\"{x:1288,y:547,t:1528139888258};\\\", \\\"{x:1287,y:549,t:1528139888275};\\\", \\\"{x:1285,y:551,t:1528139888292};\\\", \\\"{x:1283,y:552,t:1528139888308};\\\", \\\"{x:1282,y:553,t:1528139888336};\\\", \\\"{x:1281,y:554,t:1528139888360};\\\", \\\"{x:1280,y:554,t:1528139888384};\\\", \\\"{x:1279,y:555,t:1528139888440};\\\", \\\"{x:1278,y:555,t:1528139888480};\\\", \\\"{x:1277,y:556,t:1528139888491};\\\", \\\"{x:1276,y:557,t:1528139888511};\\\", \\\"{x:1275,y:557,t:1528139888527};\\\", \\\"{x:1274,y:558,t:1528139888551};\\\", \\\"{x:1273,y:559,t:1528139888583};\\\", \\\"{x:1272,y:559,t:1528139888591};\\\", \\\"{x:1271,y:560,t:1528139888623};\\\", \\\"{x:1273,y:560,t:1528139889295};\\\", \\\"{x:1274,y:560,t:1528139889343};\\\", \\\"{x:1279,y:560,t:1528139890657};\\\", \\\"{x:1279,y:561,t:1528139890904};\\\", \\\"{x:1279,y:562,t:1528139890920};\\\", \\\"{x:1279,y:563,t:1528139890936};\\\", \\\"{x:1279,y:564,t:1528139890943};\\\", \\\"{x:1278,y:566,t:1528139890984};\\\", \\\"{x:1278,y:567,t:1528139891040};\\\", \\\"{x:1278,y:566,t:1528139898040};\\\", \\\"{x:1279,y:566,t:1528139898080};\\\", \\\"{x:1280,y:564,t:1528139898127};\\\", \\\"{x:1275,y:564,t:1528139901969};\\\", \\\"{x:1191,y:583,t:1528139901985};\\\", \\\"{x:1094,y:599,t:1528139902002};\\\", \\\"{x:973,y:596,t:1528139902019};\\\", \\\"{x:835,y:579,t:1528139902037};\\\", \\\"{x:712,y:556,t:1528139902051};\\\", \\\"{x:627,y:537,t:1528139902068};\\\", \\\"{x:529,y:508,t:1528139902087};\\\", \\\"{x:501,y:496,t:1528139902104};\\\", \\\"{x:482,y:493,t:1528139902121};\\\", \\\"{x:466,y:493,t:1528139902136};\\\", \\\"{x:452,y:494,t:1528139902154};\\\", \\\"{x:442,y:499,t:1528139902171};\\\", \\\"{x:439,y:501,t:1528139902188};\\\", \\\"{x:442,y:500,t:1528139902239};\\\", \\\"{x:446,y:497,t:1528139902254};\\\", \\\"{x:466,y:487,t:1528139902271};\\\", \\\"{x:480,y:483,t:1528139902289};\\\", \\\"{x:498,y:481,t:1528139902304};\\\", \\\"{x:520,y:481,t:1528139902321};\\\", \\\"{x:534,y:481,t:1528139902337};\\\", \\\"{x:543,y:481,t:1528139902354};\\\", \\\"{x:547,y:481,t:1528139902371};\\\", \\\"{x:553,y:482,t:1528139902387};\\\", \\\"{x:559,y:484,t:1528139902404};\\\", \\\"{x:561,y:484,t:1528139902421};\\\", \\\"{x:564,y:485,t:1528139902438};\\\", \\\"{x:566,y:486,t:1528139902454};\\\", \\\"{x:570,y:490,t:1528139902472};\\\", \\\"{x:572,y:491,t:1528139902487};\\\", \\\"{x:577,y:494,t:1528139902504};\\\", \\\"{x:578,y:494,t:1528139902521};\\\", \\\"{x:580,y:494,t:1528139902538};\\\", \\\"{x:582,y:495,t:1528139902555};\\\", \\\"{x:583,y:495,t:1528139902607};\\\", \\\"{x:584,y:495,t:1528139902638};\\\", \\\"{x:585,y:495,t:1528139902879};\\\", \\\"{x:586,y:495,t:1528139902944};\\\", \\\"{x:587,y:495,t:1528139902960};\\\", \\\"{x:588,y:495,t:1528139902976};\\\", \\\"{x:590,y:495,t:1528139902992};\\\", \\\"{x:592,y:495,t:1528139903007};\\\", \\\"{x:593,y:495,t:1528139903024};\\\", \\\"{x:595,y:495,t:1528139903039};\\\", \\\"{x:597,y:495,t:1528139903120};\\\", \\\"{x:598,y:494,t:1528139903144};\\\", \\\"{x:599,y:494,t:1528139903240};\\\", \\\"{x:601,y:494,t:1528139903256};\\\", \\\"{x:602,y:494,t:1528139903279};\\\", \\\"{x:604,y:494,t:1528139903288};\\\", \\\"{x:605,y:494,t:1528139903305};\\\", \\\"{x:606,y:494,t:1528139903559};\\\", \\\"{x:606,y:494,t:1528139903675};\\\", \\\"{x:612,y:494,t:1528139904023};\\\", \\\"{x:638,y:505,t:1528139904040};\\\", \\\"{x:714,y:523,t:1528139904056};\\\", \\\"{x:798,y:552,t:1528139904073};\\\", \\\"{x:906,y:584,t:1528139904089};\\\", \\\"{x:1028,y:616,t:1528139904107};\\\", \\\"{x:1144,y:649,t:1528139904122};\\\", \\\"{x:1233,y:678,t:1528139904139};\\\", \\\"{x:1265,y:695,t:1528139904156};\\\", \\\"{x:1276,y:699,t:1528139904172};\\\", \\\"{x:1278,y:701,t:1528139904189};\\\", \\\"{x:1279,y:700,t:1528139904272};\\\", \\\"{x:1279,y:697,t:1528139904279};\\\", \\\"{x:1281,y:693,t:1528139904289};\\\", \\\"{x:1284,y:683,t:1528139904307};\\\", \\\"{x:1286,y:670,t:1528139904322};\\\", \\\"{x:1286,y:659,t:1528139904339};\\\", \\\"{x:1286,y:655,t:1528139904356};\\\", \\\"{x:1284,y:648,t:1528139904373};\\\", \\\"{x:1284,y:643,t:1528139904389};\\\", \\\"{x:1284,y:635,t:1528139904407};\\\", \\\"{x:1281,y:625,t:1528139904423};\\\", \\\"{x:1281,y:621,t:1528139904440};\\\", \\\"{x:1281,y:618,t:1528139904456};\\\", \\\"{x:1278,y:611,t:1528139904473};\\\", \\\"{x:1276,y:603,t:1528139904490};\\\", \\\"{x:1275,y:600,t:1528139904507};\\\", \\\"{x:1274,y:596,t:1528139904523};\\\", \\\"{x:1273,y:593,t:1528139904540};\\\", \\\"{x:1273,y:591,t:1528139904557};\\\", \\\"{x:1272,y:587,t:1528139904573};\\\", \\\"{x:1271,y:582,t:1528139904590};\\\", \\\"{x:1269,y:578,t:1528139904606};\\\", \\\"{x:1267,y:572,t:1528139904624};\\\", \\\"{x:1267,y:571,t:1528139904639};\\\", \\\"{x:1266,y:569,t:1528139904656};\\\", \\\"{x:1266,y:568,t:1528139904720};\\\", \\\"{x:1266,y:567,t:1528139904736};\\\", \\\"{x:1266,y:566,t:1528139904744};\\\", \\\"{x:1267,y:565,t:1528139904757};\\\", \\\"{x:1267,y:563,t:1528139904775};\\\", \\\"{x:1267,y:562,t:1528139904790};\\\", \\\"{x:1268,y:562,t:1528139904807};\\\", \\\"{x:1269,y:559,t:1528139904824};\\\", \\\"{x:1269,y:558,t:1528139904840};\\\", \\\"{x:1270,y:556,t:1528139904857};\\\", \\\"{x:1272,y:555,t:1528139904873};\\\", \\\"{x:1274,y:555,t:1528139906199};\\\", \\\"{x:1313,y:550,t:1528139906206};\\\", \\\"{x:1441,y:525,t:1528139906224};\\\", \\\"{x:1576,y:510,t:1528139906240};\\\", \\\"{x:1703,y:500,t:1528139906257};\\\", \\\"{x:1783,y:500,t:1528139906274};\\\", \\\"{x:1831,y:500,t:1528139906291};\\\", \\\"{x:1843,y:500,t:1528139906308};\\\", \\\"{x:1838,y:502,t:1528139906400};\\\", \\\"{x:1832,y:504,t:1528139906407};\\\", \\\"{x:1816,y:511,t:1528139906424};\\\", \\\"{x:1794,y:525,t:1528139906442};\\\", \\\"{x:1769,y:537,t:1528139906458};\\\", \\\"{x:1747,y:545,t:1528139906474};\\\", \\\"{x:1726,y:556,t:1528139906492};\\\", \\\"{x:1683,y:566,t:1528139906508};\\\", \\\"{x:1642,y:575,t:1528139906525};\\\", \\\"{x:1618,y:586,t:1528139906542};\\\", \\\"{x:1594,y:592,t:1528139906558};\\\", \\\"{x:1557,y:596,t:1528139906575};\\\", \\\"{x:1511,y:606,t:1528139906592};\\\", \\\"{x:1496,y:608,t:1528139906608};\\\", \\\"{x:1491,y:609,t:1528139906624};\\\", \\\"{x:1490,y:609,t:1528139906642};\\\", \\\"{x:1488,y:609,t:1528139906704};\\\", \\\"{x:1483,y:608,t:1528139906712};\\\", \\\"{x:1478,y:607,t:1528139906725};\\\", \\\"{x:1458,y:603,t:1528139906742};\\\", \\\"{x:1423,y:598,t:1528139906758};\\\", \\\"{x:1394,y:592,t:1528139906775};\\\", \\\"{x:1378,y:585,t:1528139906791};\\\", \\\"{x:1372,y:582,t:1528139906809};\\\", \\\"{x:1372,y:581,t:1528139906825};\\\", \\\"{x:1372,y:580,t:1528139906863};\\\", \\\"{x:1372,y:579,t:1528139906875};\\\", \\\"{x:1377,y:575,t:1528139906892};\\\", \\\"{x:1390,y:569,t:1528139906908};\\\", \\\"{x:1410,y:558,t:1528139906925};\\\", \\\"{x:1420,y:554,t:1528139906942};\\\", \\\"{x:1433,y:548,t:1528139906959};\\\", \\\"{x:1445,y:545,t:1528139906974};\\\", \\\"{x:1449,y:544,t:1528139906992};\\\", \\\"{x:1451,y:543,t:1528139907009};\\\", \\\"{x:1452,y:543,t:1528139907039};\\\", \\\"{x:1449,y:546,t:1528139907216};\\\", \\\"{x:1441,y:551,t:1528139907225};\\\", \\\"{x:1424,y:562,t:1528139907242};\\\", \\\"{x:1414,y:569,t:1528139907259};\\\", \\\"{x:1400,y:579,t:1528139907276};\\\", \\\"{x:1396,y:582,t:1528139907292};\\\", \\\"{x:1395,y:582,t:1528139907308};\\\", \\\"{x:1394,y:583,t:1528139907335};\\\", \\\"{x:1394,y:585,t:1528139907352};\\\", \\\"{x:1392,y:589,t:1528139907359};\\\", \\\"{x:1387,y:599,t:1528139907376};\\\", \\\"{x:1380,y:615,t:1528139907392};\\\", \\\"{x:1375,y:625,t:1528139907409};\\\", \\\"{x:1371,y:632,t:1528139907425};\\\", \\\"{x:1367,y:640,t:1528139907442};\\\", \\\"{x:1367,y:644,t:1528139907458};\\\", \\\"{x:1366,y:646,t:1528139907476};\\\", \\\"{x:1364,y:651,t:1528139907492};\\\", \\\"{x:1360,y:655,t:1528139907509};\\\", \\\"{x:1357,y:662,t:1528139907526};\\\", \\\"{x:1352,y:670,t:1528139907541};\\\", \\\"{x:1349,y:673,t:1528139907559};\\\", \\\"{x:1344,y:683,t:1528139907576};\\\", \\\"{x:1342,y:686,t:1528139907592};\\\", \\\"{x:1341,y:690,t:1528139907609};\\\", \\\"{x:1339,y:693,t:1528139907625};\\\", \\\"{x:1336,y:699,t:1528139907642};\\\", \\\"{x:1335,y:704,t:1528139907658};\\\", \\\"{x:1335,y:706,t:1528139907676};\\\", \\\"{x:1335,y:709,t:1528139907692};\\\", \\\"{x:1335,y:711,t:1528139907709};\\\", \\\"{x:1335,y:712,t:1528139907735};\\\", \\\"{x:1335,y:711,t:1528139907936};\\\", \\\"{x:1335,y:710,t:1528139907959};\\\", \\\"{x:1336,y:709,t:1528139907983};\\\", \\\"{x:1337,y:708,t:1528139908143};\\\", \\\"{x:1340,y:705,t:1528139908160};\\\", \\\"{x:1345,y:698,t:1528139908176};\\\", \\\"{x:1348,y:695,t:1528139908192};\\\", \\\"{x:1351,y:692,t:1528139908209};\\\", \\\"{x:1352,y:691,t:1528139908227};\\\", \\\"{x:1353,y:690,t:1528139908296};\\\", \\\"{x:1352,y:690,t:1528139908408};\\\", \\\"{x:1351,y:690,t:1528139908416};\\\", \\\"{x:1350,y:690,t:1528139908432};\\\", \\\"{x:1348,y:690,t:1528139908443};\\\", \\\"{x:1346,y:693,t:1528139908460};\\\", \\\"{x:1344,y:696,t:1528139908476};\\\", \\\"{x:1341,y:699,t:1528139908494};\\\", \\\"{x:1340,y:701,t:1528139908509};\\\", \\\"{x:1339,y:702,t:1528139908526};\\\", \\\"{x:1338,y:704,t:1528139908543};\\\", \\\"{x:1337,y:704,t:1528139908560};\\\", \\\"{x:1336,y:706,t:1528139908575};\\\", \\\"{x:1335,y:708,t:1528139908592};\\\", \\\"{x:1333,y:709,t:1528139908609};\\\", \\\"{x:1332,y:709,t:1528139908625};\\\", \\\"{x:1331,y:710,t:1528139908642};\\\", \\\"{x:1329,y:712,t:1528139908659};\\\", \\\"{x:1327,y:712,t:1528139908677};\\\", \\\"{x:1322,y:715,t:1528139908692};\\\", \\\"{x:1316,y:715,t:1528139908710};\\\", \\\"{x:1301,y:721,t:1528139908726};\\\", \\\"{x:1287,y:726,t:1528139908743};\\\", \\\"{x:1259,y:731,t:1528139908759};\\\", \\\"{x:1244,y:733,t:1528139908776};\\\", \\\"{x:1233,y:735,t:1528139908792};\\\", \\\"{x:1224,y:737,t:1528139908809};\\\", \\\"{x:1220,y:739,t:1528139908827};\\\", \\\"{x:1218,y:739,t:1528139908843};\\\", \\\"{x:1218,y:740,t:1528139908871};\\\", \\\"{x:1217,y:740,t:1528139909090};\\\", \\\"{x:1213,y:741,t:1528139909095};\\\", \\\"{x:1204,y:749,t:1528139909109};\\\", \\\"{x:1190,y:757,t:1528139909126};\\\", \\\"{x:1162,y:771,t:1528139909143};\\\", \\\"{x:1146,y:781,t:1528139909159};\\\", \\\"{x:1132,y:787,t:1528139909176};\\\", \\\"{x:1125,y:790,t:1528139909193};\\\", \\\"{x:1123,y:792,t:1528139909209};\\\", \\\"{x:1122,y:792,t:1528139909226};\\\", \\\"{x:1125,y:792,t:1528139909312};\\\", \\\"{x:1134,y:790,t:1528139909326};\\\", \\\"{x:1157,y:781,t:1528139909343};\\\", \\\"{x:1169,y:779,t:1528139909359};\\\", \\\"{x:1170,y:777,t:1528139909376};\\\", \\\"{x:1174,y:775,t:1528139909394};\\\", \\\"{x:1175,y:775,t:1528139909648};\\\", \\\"{x:1175,y:774,t:1528139911159};\\\", \\\"{x:1177,y:774,t:1528139911176};\\\", \\\"{x:1177,y:772,t:1528139911200};\\\", \\\"{x:1178,y:771,t:1528139911213};\\\", \\\"{x:1179,y:770,t:1528139911228};\\\", \\\"{x:1179,y:769,t:1528139911245};\\\", \\\"{x:1180,y:768,t:1528139911272};\\\", \\\"{x:1180,y:767,t:1528139911295};\\\", \\\"{x:1176,y:762,t:1528139920599};\\\", \\\"{x:1136,y:752,t:1528139920608};\\\", \\\"{x:1099,y:739,t:1528139920618};\\\", \\\"{x:958,y:700,t:1528139920636};\\\", \\\"{x:804,y:660,t:1528139920652};\\\", \\\"{x:646,y:616,t:1528139920669};\\\", \\\"{x:493,y:583,t:1528139920685};\\\", \\\"{x:363,y:549,t:1528139920702};\\\", \\\"{x:257,y:515,t:1528139920720};\\\", \\\"{x:240,y:508,t:1528139920736};\\\", \\\"{x:232,y:504,t:1528139920752};\\\", \\\"{x:233,y:504,t:1528139920854};\\\", \\\"{x:238,y:504,t:1528139920869};\\\", \\\"{x:251,y:505,t:1528139920885};\\\", \\\"{x:296,y:519,t:1528139920903};\\\", \\\"{x:344,y:526,t:1528139920920};\\\", \\\"{x:366,y:531,t:1528139920936};\\\", \\\"{x:384,y:537,t:1528139920954};\\\", \\\"{x:413,y:548,t:1528139920970};\\\", \\\"{x:429,y:553,t:1528139920986};\\\", \\\"{x:445,y:558,t:1528139921004};\\\", \\\"{x:454,y:562,t:1528139921019};\\\", \\\"{x:455,y:562,t:1528139921035};\\\", \\\"{x:454,y:563,t:1528139921104};\\\", \\\"{x:444,y:565,t:1528139921119};\\\", \\\"{x:424,y:568,t:1528139921135};\\\", \\\"{x:404,y:569,t:1528139921154};\\\", \\\"{x:381,y:569,t:1528139921170};\\\", \\\"{x:362,y:569,t:1528139921187};\\\", \\\"{x:348,y:569,t:1528139921203};\\\", \\\"{x:335,y:568,t:1528139921220};\\\", \\\"{x:325,y:565,t:1528139921236};\\\", \\\"{x:317,y:563,t:1528139921252};\\\", \\\"{x:307,y:558,t:1528139921271};\\\", \\\"{x:285,y:545,t:1528139921286};\\\", \\\"{x:269,y:536,t:1528139921303};\\\", \\\"{x:249,y:521,t:1528139921320};\\\", \\\"{x:221,y:506,t:1528139921337};\\\", \\\"{x:202,y:494,t:1528139921352};\\\", \\\"{x:183,y:484,t:1528139921370};\\\", \\\"{x:177,y:480,t:1528139921386};\\\", \\\"{x:175,y:480,t:1528139921462};\\\", \\\"{x:174,y:481,t:1528139921478};\\\", \\\"{x:173,y:483,t:1528139921486};\\\", \\\"{x:172,y:487,t:1528139921503};\\\", \\\"{x:171,y:487,t:1528139921520};\\\", \\\"{x:171,y:488,t:1528139921574};\\\", \\\"{x:170,y:489,t:1528139921598};\\\", \\\"{x:169,y:490,t:1528139921631};\\\", \\\"{x:169,y:491,t:1528139921639};\\\", \\\"{x:168,y:492,t:1528139921653};\\\", \\\"{x:168,y:493,t:1528139921670};\\\", \\\"{x:177,y:493,t:1528139922110};\\\", \\\"{x:204,y:493,t:1528139922121};\\\", \\\"{x:315,y:495,t:1528139922137};\\\", \\\"{x:376,y:503,t:1528139922154};\\\", \\\"{x:466,y:520,t:1528139922170};\\\", \\\"{x:519,y:533,t:1528139922187};\\\", \\\"{x:533,y:540,t:1528139922203};\\\", \\\"{x:555,y:547,t:1528139922221};\\\", \\\"{x:560,y:547,t:1528139922237};\\\", \\\"{x:561,y:547,t:1528139922304};\\\", \\\"{x:563,y:547,t:1528139922321};\\\", \\\"{x:566,y:545,t:1528139922336};\\\", \\\"{x:569,y:543,t:1528139922354};\\\", \\\"{x:571,y:543,t:1528139922371};\\\", \\\"{x:572,y:543,t:1528139922391};\\\", \\\"{x:573,y:543,t:1528139922404};\\\", \\\"{x:574,y:543,t:1528139922421};\\\", \\\"{x:576,y:544,t:1528139922463};\\\", \\\"{x:576,y:547,t:1528139922471};\\\", \\\"{x:577,y:553,t:1528139922486};\\\", \\\"{x:586,y:562,t:1528139922506};\\\", \\\"{x:605,y:569,t:1528139922525};\\\", \\\"{x:626,y:577,t:1528139922537};\\\", \\\"{x:678,y:586,t:1528139922553};\\\", \\\"{x:742,y:586,t:1528139922570};\\\", \\\"{x:804,y:586,t:1528139922587};\\\", \\\"{x:836,y:586,t:1528139922604};\\\", \\\"{x:857,y:576,t:1528139922621};\\\", \\\"{x:864,y:570,t:1528139922638};\\\", \\\"{x:867,y:567,t:1528139922653};\\\", \\\"{x:868,y:567,t:1528139922670};\\\", \\\"{x:868,y:565,t:1528139922840};\\\", \\\"{x:861,y:554,t:1528139922856};\\\", \\\"{x:851,y:536,t:1528139922872};\\\", \\\"{x:841,y:524,t:1528139922888};\\\", \\\"{x:830,y:511,t:1528139922905};\\\", \\\"{x:818,y:500,t:1528139922921};\\\", \\\"{x:808,y:492,t:1528139922937};\\\", \\\"{x:803,y:488,t:1528139922954};\\\", \\\"{x:804,y:488,t:1528139923047};\\\", \\\"{x:808,y:488,t:1528139923054};\\\", \\\"{x:812,y:488,t:1528139923071};\\\", \\\"{x:822,y:491,t:1528139923087};\\\", \\\"{x:828,y:493,t:1528139923105};\\\", \\\"{x:833,y:493,t:1528139923121};\\\", \\\"{x:841,y:494,t:1528139923137};\\\", \\\"{x:849,y:494,t:1528139923155};\\\", \\\"{x:853,y:496,t:1528139923171};\\\", \\\"{x:851,y:496,t:1528139923471};\\\", \\\"{x:846,y:497,t:1528139923488};\\\", \\\"{x:842,y:500,t:1528139923505};\\\", \\\"{x:839,y:500,t:1528139923522};\\\", \\\"{x:838,y:500,t:1528139923538};\\\", \\\"{x:848,y:501,t:1528139924264};\\\", \\\"{x:858,y:507,t:1528139924272};\\\", \\\"{x:909,y:524,t:1528139924291};\\\", \\\"{x:1007,y:558,t:1528139924305};\\\", \\\"{x:1120,y:604,t:1528139924322};\\\", \\\"{x:1219,y:646,t:1528139924339};\\\", \\\"{x:1312,y:684,t:1528139924356};\\\", \\\"{x:1383,y:711,t:1528139924371};\\\", \\\"{x:1408,y:726,t:1528139924388};\\\", \\\"{x:1424,y:734,t:1528139924405};\\\", \\\"{x:1428,y:736,t:1528139924422};\\\", \\\"{x:1426,y:736,t:1528139924504};\\\", \\\"{x:1421,y:736,t:1528139924511};\\\", \\\"{x:1415,y:736,t:1528139924523};\\\", \\\"{x:1402,y:734,t:1528139924539};\\\", \\\"{x:1392,y:733,t:1528139924556};\\\", \\\"{x:1380,y:731,t:1528139924573};\\\", \\\"{x:1367,y:729,t:1528139924589};\\\", \\\"{x:1356,y:727,t:1528139924606};\\\", \\\"{x:1344,y:727,t:1528139924623};\\\", \\\"{x:1332,y:727,t:1528139924639};\\\", \\\"{x:1328,y:727,t:1528139924657};\\\", \\\"{x:1327,y:724,t:1528139924735};\\\", \\\"{x:1327,y:721,t:1528139924743};\\\", \\\"{x:1327,y:720,t:1528139924758};\\\", \\\"{x:1326,y:717,t:1528139924773};\\\", \\\"{x:1325,y:714,t:1528139924789};\\\", \\\"{x:1325,y:712,t:1528139924806};\\\", \\\"{x:1325,y:709,t:1528139924823};\\\", \\\"{x:1325,y:707,t:1528139924839};\\\", \\\"{x:1325,y:706,t:1528139924880};\\\", \\\"{x:1326,y:706,t:1528139924889};\\\", \\\"{x:1330,y:705,t:1528139924905};\\\", \\\"{x:1334,y:704,t:1528139924923};\\\", \\\"{x:1339,y:703,t:1528139924939};\\\", \\\"{x:1343,y:702,t:1528139924956};\\\", \\\"{x:1345,y:701,t:1528139924972};\\\", \\\"{x:1348,y:701,t:1528139924988};\\\", \\\"{x:1349,y:700,t:1528139925006};\\\", \\\"{x:1350,y:700,t:1528139925023};\\\", \\\"{x:1351,y:700,t:1528139925039};\\\", \\\"{x:1352,y:699,t:1528139925056};\\\", \\\"{x:1355,y:699,t:1528139925080};\\\", \\\"{x:1354,y:699,t:1528139925311};\\\", \\\"{x:1351,y:701,t:1528139925323};\\\", \\\"{x:1342,y:707,t:1528139925341};\\\", \\\"{x:1341,y:708,t:1528139925357};\\\", \\\"{x:1339,y:710,t:1528139925373};\\\", \\\"{x:1338,y:710,t:1528139925390};\\\", \\\"{x:1338,y:712,t:1528139925406};\\\", \\\"{x:1336,y:715,t:1528139925423};\\\", \\\"{x:1335,y:715,t:1528139925440};\\\", \\\"{x:1333,y:719,t:1528139925456};\\\", \\\"{x:1332,y:721,t:1528139925474};\\\", \\\"{x:1332,y:722,t:1528139925491};\\\", \\\"{x:1332,y:723,t:1528139925506};\\\", \\\"{x:1329,y:726,t:1528139925523};\\\", \\\"{x:1329,y:727,t:1528139925541};\\\", \\\"{x:1328,y:729,t:1528139925558};\\\", \\\"{x:1328,y:730,t:1528139925574};\\\", \\\"{x:1327,y:732,t:1528139925590};\\\", \\\"{x:1327,y:730,t:1528139925735};\\\", \\\"{x:1331,y:726,t:1528139925743};\\\", \\\"{x:1332,y:723,t:1528139925757};\\\", \\\"{x:1336,y:717,t:1528139925773};\\\", \\\"{x:1341,y:712,t:1528139925791};\\\", \\\"{x:1343,y:707,t:1528139925807};\\\", \\\"{x:1345,y:704,t:1528139925824};\\\", \\\"{x:1346,y:703,t:1528139925952};\\\", \\\"{x:1347,y:702,t:1528139926120};\\\", \\\"{x:1347,y:703,t:1528139928993};\\\", \\\"{x:1347,y:704,t:1528139929015};\\\", \\\"{x:1346,y:704,t:1528139929031};\\\", \\\"{x:1346,y:706,t:1528139929094};\\\", \\\"{x:1346,y:707,t:1528139929117};\\\", \\\"{x:1346,y:709,t:1528139929142};\\\", \\\"{x:1346,y:711,t:1528139929174};\\\", \\\"{x:1346,y:712,t:1528139929182};\\\", \\\"{x:1346,y:713,t:1528139929199};\\\", \\\"{x:1346,y:715,t:1528139929209};\\\", \\\"{x:1346,y:716,t:1528139929226};\\\", \\\"{x:1346,y:719,t:1528139929243};\\\", \\\"{x:1346,y:722,t:1528139929260};\\\", \\\"{x:1346,y:723,t:1528139929276};\\\", \\\"{x:1346,y:726,t:1528139929293};\\\", \\\"{x:1346,y:729,t:1528139929309};\\\", \\\"{x:1346,y:731,t:1528139929326};\\\", \\\"{x:1346,y:732,t:1528139929343};\\\", \\\"{x:1346,y:733,t:1528139929359};\\\", \\\"{x:1346,y:735,t:1528139929376};\\\", \\\"{x:1346,y:737,t:1528139929393};\\\", \\\"{x:1347,y:740,t:1528139929409};\\\", \\\"{x:1348,y:743,t:1528139929426};\\\", \\\"{x:1348,y:744,t:1528139929444};\\\", \\\"{x:1348,y:745,t:1528139929460};\\\", \\\"{x:1348,y:746,t:1528139929477};\\\", \\\"{x:1348,y:747,t:1528139929495};\\\", \\\"{x:1349,y:748,t:1528139929511};\\\", \\\"{x:1349,y:751,t:1528139929527};\\\", \\\"{x:1349,y:752,t:1528139929542};\\\", \\\"{x:1349,y:753,t:1528139929575};\\\", \\\"{x:1349,y:755,t:1528139929591};\\\", \\\"{x:1349,y:756,t:1528139929655};\\\", \\\"{x:1349,y:754,t:1528139929799};\\\", \\\"{x:1349,y:751,t:1528139929810};\\\", \\\"{x:1350,y:746,t:1528139929826};\\\", \\\"{x:1350,y:739,t:1528139929844};\\\", \\\"{x:1349,y:736,t:1528139929861};\\\", \\\"{x:1349,y:732,t:1528139929877};\\\", \\\"{x:1349,y:731,t:1528139929894};\\\", \\\"{x:1349,y:730,t:1528139929911};\\\", \\\"{x:1349,y:729,t:1528139929935};\\\", \\\"{x:1349,y:727,t:1528139930015};\\\", \\\"{x:1349,y:725,t:1528139930031};\\\", \\\"{x:1349,y:724,t:1528139930043};\\\", \\\"{x:1349,y:720,t:1528139930061};\\\", \\\"{x:1349,y:717,t:1528139930077};\\\", \\\"{x:1349,y:715,t:1528139930094};\\\", \\\"{x:1348,y:712,t:1528139930110};\\\", \\\"{x:1348,y:708,t:1528139930127};\\\", \\\"{x:1348,y:705,t:1528139930144};\\\", \\\"{x:1347,y:701,t:1528139930160};\\\", \\\"{x:1347,y:698,t:1528139930177};\\\", \\\"{x:1346,y:695,t:1528139930193};\\\", \\\"{x:1345,y:693,t:1528139930210};\\\", \\\"{x:1344,y:691,t:1528139930228};\\\", \\\"{x:1344,y:690,t:1528139930244};\\\", \\\"{x:1343,y:689,t:1528139930456};\\\", \\\"{x:1342,y:688,t:1528139930463};\\\", \\\"{x:1342,y:687,t:1528139930478};\\\", \\\"{x:1342,y:685,t:1528139930494};\\\", \\\"{x:1342,y:684,t:1528139930519};\\\", \\\"{x:1342,y:683,t:1528139930728};\\\", \\\"{x:1341,y:683,t:1528139930745};\\\", \\\"{x:1338,y:683,t:1528139930761};\\\", \\\"{x:1334,y:691,t:1528139930778};\\\", \\\"{x:1333,y:697,t:1528139930795};\\\", \\\"{x:1330,y:706,t:1528139930812};\\\", \\\"{x:1330,y:711,t:1528139930827};\\\", \\\"{x:1330,y:714,t:1528139930844};\\\", \\\"{x:1330,y:717,t:1528139930862};\\\", \\\"{x:1329,y:720,t:1528139930878};\\\", \\\"{x:1329,y:723,t:1528139930895};\\\", \\\"{x:1329,y:726,t:1528139930911};\\\", \\\"{x:1329,y:732,t:1528139930927};\\\", \\\"{x:1329,y:735,t:1528139930944};\\\", \\\"{x:1329,y:739,t:1528139930961};\\\", \\\"{x:1329,y:745,t:1528139930977};\\\", \\\"{x:1331,y:747,t:1528139930993};\\\", \\\"{x:1331,y:748,t:1528139931011};\\\", \\\"{x:1334,y:749,t:1528139931135};\\\", \\\"{x:1335,y:750,t:1528139931145};\\\", \\\"{x:1338,y:751,t:1528139931161};\\\", \\\"{x:1341,y:753,t:1528139931178};\\\", \\\"{x:1342,y:754,t:1528139931194};\\\", \\\"{x:1344,y:755,t:1528139931211};\\\", \\\"{x:1345,y:755,t:1528139931228};\\\", \\\"{x:1347,y:756,t:1528139931245};\\\", \\\"{x:1350,y:756,t:1528139931261};\\\", \\\"{x:1352,y:757,t:1528139931279};\\\", \\\"{x:1352,y:758,t:1528139931655};\\\", \\\"{x:1352,y:759,t:1528139931728};\\\", \\\"{x:1352,y:761,t:1528139931761};\\\", \\\"{x:1352,y:763,t:1528139932055};\\\", \\\"{x:1350,y:764,t:1528139932062};\\\", \\\"{x:1346,y:768,t:1528139932078};\\\", \\\"{x:1344,y:769,t:1528139932096};\\\", \\\"{x:1343,y:770,t:1528139932112};\\\", \\\"{x:1341,y:771,t:1528139932128};\\\", \\\"{x:1339,y:772,t:1528139932145};\\\", \\\"{x:1339,y:774,t:1528139932163};\\\", \\\"{x:1338,y:774,t:1528139932179};\\\", \\\"{x:1336,y:776,t:1528139932196};\\\", \\\"{x:1334,y:777,t:1528139932215};\\\", \\\"{x:1334,y:778,t:1528139932229};\\\", \\\"{x:1333,y:778,t:1528139932246};\\\", \\\"{x:1332,y:779,t:1528139932263};\\\", \\\"{x:1331,y:780,t:1528139932278};\\\", \\\"{x:1329,y:781,t:1528139932295};\\\", \\\"{x:1328,y:783,t:1528139932313};\\\", \\\"{x:1327,y:785,t:1528139932328};\\\", \\\"{x:1324,y:787,t:1528139932346};\\\", \\\"{x:1324,y:788,t:1528139932375};\\\", \\\"{x:1322,y:789,t:1528139932383};\\\", \\\"{x:1322,y:790,t:1528139932398};\\\", \\\"{x:1321,y:790,t:1528139932413};\\\", \\\"{x:1319,y:792,t:1528139932429};\\\", \\\"{x:1317,y:794,t:1528139932446};\\\", \\\"{x:1312,y:798,t:1528139932463};\\\", \\\"{x:1306,y:807,t:1528139932479};\\\", \\\"{x:1300,y:812,t:1528139932495};\\\", \\\"{x:1292,y:819,t:1528139932512};\\\", \\\"{x:1287,y:823,t:1528139932529};\\\", \\\"{x:1286,y:825,t:1528139932545};\\\", \\\"{x:1283,y:829,t:1528139932562};\\\", \\\"{x:1281,y:832,t:1528139932578};\\\", \\\"{x:1278,y:836,t:1528139932595};\\\", \\\"{x:1275,y:839,t:1528139932611};\\\", \\\"{x:1273,y:844,t:1528139932628};\\\", \\\"{x:1271,y:847,t:1528139932645};\\\", \\\"{x:1269,y:850,t:1528139932662};\\\", \\\"{x:1268,y:851,t:1528139932678};\\\", \\\"{x:1268,y:854,t:1528139932695};\\\", \\\"{x:1267,y:857,t:1528139932712};\\\", \\\"{x:1266,y:861,t:1528139932729};\\\", \\\"{x:1264,y:864,t:1528139932745};\\\", \\\"{x:1263,y:867,t:1528139932762};\\\", \\\"{x:1261,y:870,t:1528139932779};\\\", \\\"{x:1259,y:874,t:1528139932794};\\\", \\\"{x:1258,y:878,t:1528139932812};\\\", \\\"{x:1258,y:882,t:1528139932829};\\\", \\\"{x:1255,y:888,t:1528139932845};\\\", \\\"{x:1251,y:896,t:1528139932863};\\\", \\\"{x:1246,y:902,t:1528139932879};\\\", \\\"{x:1245,y:910,t:1528139932896};\\\", \\\"{x:1241,y:918,t:1528139932912};\\\", \\\"{x:1240,y:923,t:1528139932929};\\\", \\\"{x:1239,y:926,t:1528139932947};\\\", \\\"{x:1238,y:928,t:1528139932962};\\\", \\\"{x:1238,y:931,t:1528139932979};\\\", \\\"{x:1238,y:935,t:1528139932997};\\\", \\\"{x:1236,y:939,t:1528139933013};\\\", \\\"{x:1235,y:942,t:1528139933030};\\\", \\\"{x:1235,y:944,t:1528139933055};\\\", \\\"{x:1237,y:943,t:1528139933167};\\\", \\\"{x:1239,y:939,t:1528139933179};\\\", \\\"{x:1246,y:930,t:1528139933196};\\\", \\\"{x:1253,y:918,t:1528139933213};\\\", \\\"{x:1261,y:905,t:1528139933229};\\\", \\\"{x:1270,y:886,t:1528139933247};\\\", \\\"{x:1274,y:874,t:1528139933263};\\\", \\\"{x:1276,y:857,t:1528139933279};\\\", \\\"{x:1276,y:844,t:1528139933296};\\\", \\\"{x:1279,y:831,t:1528139933313};\\\", \\\"{x:1279,y:829,t:1528139933330};\\\", \\\"{x:1277,y:829,t:1528139933384};\\\", \\\"{x:1273,y:829,t:1528139933396};\\\", \\\"{x:1244,y:829,t:1528139933413};\\\", \\\"{x:1198,y:824,t:1528139933429};\\\", \\\"{x:1031,y:805,t:1528139933446};\\\", \\\"{x:902,y:780,t:1528139933463};\\\", \\\"{x:783,y:740,t:1528139933479};\\\", \\\"{x:698,y:707,t:1528139933496};\\\", \\\"{x:666,y:684,t:1528139933513};\\\", \\\"{x:644,y:676,t:1528139933530};\\\", \\\"{x:640,y:674,t:1528139933546};\\\", \\\"{x:639,y:677,t:1528139933591};\\\", \\\"{x:643,y:689,t:1528139933599};\\\", \\\"{x:645,y:703,t:1528139933613};\\\", \\\"{x:647,y:728,t:1528139933629};\\\", \\\"{x:649,y:750,t:1528139933647};\\\", \\\"{x:645,y:761,t:1528139933663};\\\", \\\"{x:645,y:762,t:1528139933679};\\\", \\\"{x:645,y:763,t:1528139933719};\\\", \\\"{x:644,y:763,t:1528139933730};\\\", \\\"{x:638,y:763,t:1528139933746};\\\", \\\"{x:633,y:763,t:1528139933763};\\\", \\\"{x:625,y:763,t:1528139933780};\\\", \\\"{x:619,y:763,t:1528139933796};\\\", \\\"{x:611,y:763,t:1528139933813};\\\", \\\"{x:597,y:762,t:1528139933830};\\\", \\\"{x:585,y:760,t:1528139933846};\\\", \\\"{x:579,y:756,t:1528139933863};\\\", \\\"{x:569,y:756,t:1528139933881};\\\", \\\"{x:561,y:752,t:1528139933897};\\\", \\\"{x:560,y:752,t:1528139933913};\\\", \\\"{x:557,y:750,t:1528139933930};\\\", \\\"{x:555,y:750,t:1528139933946};\\\", \\\"{x:554,y:750,t:1528139933963};\\\", \\\"{x:550,y:749,t:1528139933980};\\\", \\\"{x:548,y:749,t:1528139933996};\\\", \\\"{x:547,y:749,t:1528139934013};\\\", \\\"{x:545,y:749,t:1528139934030};\\\", \\\"{x:544,y:749,t:1528139934046};\\\", \\\"{x:545,y:756,t:1528139934671};\\\", \\\"{x:545,y:760,t:1528139934680};\\\", \\\"{x:545,y:768,t:1528139934697};\\\", \\\"{x:545,y:773,t:1528139934714};\\\", \\\"{x:545,y:774,t:1528139934730};\\\", \\\"{x:548,y:780,t:1528139934747};\\\", \\\"{x:548,y:788,t:1528139934764};\\\", \\\"{x:548,y:799,t:1528139934780};\\\", \\\"{x:548,y:809,t:1528139934797};\\\", \\\"{x:548,y:816,t:1528139934814};\\\", \\\"{x:548,y:817,t:1528139934830};\\\" ] }, { \\\"rt\\\": 60922, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 830971, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J -J -J -J -J -E -E -E -E -F -J -J -I -E -E -B -B -B -10 AM-B -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:813,t:1528139938000};\\\", \\\"{x:556,y:771,t:1528139938016};\\\", \\\"{x:561,y:742,t:1528139938034};\\\", \\\"{x:562,y:734,t:1528139938049};\\\", \\\"{x:560,y:734,t:1528139938066};\\\", \\\"{x:562,y:725,t:1528139938082};\\\", \\\"{x:565,y:710,t:1528139938099};\\\", \\\"{x:569,y:690,t:1528139938116};\\\", \\\"{x:573,y:674,t:1528139938133};\\\", \\\"{x:578,y:649,t:1528139938150};\\\", \\\"{x:583,y:635,t:1528139938165};\\\", \\\"{x:589,y:620,t:1528139938184};\\\", \\\"{x:594,y:607,t:1528139938200};\\\", \\\"{x:602,y:590,t:1528139938217};\\\", \\\"{x:609,y:571,t:1528139938233};\\\", \\\"{x:614,y:562,t:1528139938251};\\\", \\\"{x:621,y:544,t:1528139938267};\\\", \\\"{x:626,y:529,t:1528139938283};\\\", \\\"{x:629,y:516,t:1528139938301};\\\", \\\"{x:631,y:506,t:1528139938317};\\\", \\\"{x:633,y:498,t:1528139938334};\\\", \\\"{x:635,y:482,t:1528139938350};\\\", \\\"{x:638,y:475,t:1528139938367};\\\", \\\"{x:638,y:469,t:1528139938383};\\\", \\\"{x:638,y:461,t:1528139938400};\\\", \\\"{x:638,y:450,t:1528139938417};\\\", \\\"{x:638,y:440,t:1528139938434};\\\", \\\"{x:638,y:434,t:1528139938451};\\\", \\\"{x:636,y:428,t:1528139938467};\\\", \\\"{x:629,y:420,t:1528139938483};\\\", \\\"{x:611,y:406,t:1528139938501};\\\", \\\"{x:574,y:383,t:1528139938517};\\\", \\\"{x:548,y:374,t:1528139938533};\\\", \\\"{x:527,y:374,t:1528139938550};\\\", \\\"{x:521,y:375,t:1528139938567};\\\", \\\"{x:516,y:375,t:1528139938584};\\\", \\\"{x:512,y:378,t:1528139938600};\\\", \\\"{x:511,y:378,t:1528139938617};\\\", \\\"{x:510,y:378,t:1528139938727};\\\", \\\"{x:511,y:380,t:1528139938734};\\\", \\\"{x:556,y:398,t:1528139938751};\\\", \\\"{x:642,y:423,t:1528139938768};\\\", \\\"{x:720,y:445,t:1528139938784};\\\", \\\"{x:822,y:475,t:1528139938801};\\\", \\\"{x:937,y:498,t:1528139938819};\\\", \\\"{x:1060,y:523,t:1528139938835};\\\", \\\"{x:1181,y:533,t:1528139938850};\\\", \\\"{x:1284,y:530,t:1528139938867};\\\", \\\"{x:1376,y:519,t:1528139938884};\\\", \\\"{x:1414,y:513,t:1528139938900};\\\", \\\"{x:1438,y:513,t:1528139938917};\\\", \\\"{x:1448,y:517,t:1528139938934};\\\", \\\"{x:1449,y:519,t:1528139938999};\\\", \\\"{x:1449,y:522,t:1528139939006};\\\", \\\"{x:1449,y:527,t:1528139939018};\\\", \\\"{x:1449,y:542,t:1528139939034};\\\", \\\"{x:1452,y:550,t:1528139939050};\\\", \\\"{x:1456,y:563,t:1528139939068};\\\", \\\"{x:1458,y:577,t:1528139939084};\\\", \\\"{x:1460,y:586,t:1528139939100};\\\", \\\"{x:1461,y:596,t:1528139939117};\\\", \\\"{x:1463,y:608,t:1528139939134};\\\", \\\"{x:1465,y:622,t:1528139939150};\\\", \\\"{x:1465,y:628,t:1528139939167};\\\", \\\"{x:1466,y:635,t:1528139939185};\\\", \\\"{x:1466,y:640,t:1528139939201};\\\", \\\"{x:1466,y:646,t:1528139939217};\\\", \\\"{x:1466,y:659,t:1528139939235};\\\", \\\"{x:1466,y:677,t:1528139939250};\\\", \\\"{x:1465,y:697,t:1528139939268};\\\", \\\"{x:1462,y:713,t:1528139939284};\\\", \\\"{x:1458,y:727,t:1528139939302};\\\", \\\"{x:1454,y:742,t:1528139939318};\\\", \\\"{x:1448,y:754,t:1528139939333};\\\", \\\"{x:1446,y:759,t:1528139939351};\\\", \\\"{x:1444,y:761,t:1528139939367};\\\", \\\"{x:1442,y:761,t:1528139939398};\\\", \\\"{x:1442,y:763,t:1528139939414};\\\", \\\"{x:1442,y:764,t:1528139939422};\\\", \\\"{x:1442,y:766,t:1528139939434};\\\", \\\"{x:1433,y:768,t:1528139939451};\\\", \\\"{x:1421,y:772,t:1528139939467};\\\", \\\"{x:1414,y:775,t:1528139939484};\\\", \\\"{x:1407,y:775,t:1528139939501};\\\", \\\"{x:1397,y:778,t:1528139939517};\\\", \\\"{x:1373,y:780,t:1528139939534};\\\", \\\"{x:1349,y:780,t:1528139939552};\\\", \\\"{x:1326,y:780,t:1528139939568};\\\", \\\"{x:1290,y:775,t:1528139939584};\\\", \\\"{x:1260,y:773,t:1528139939602};\\\", \\\"{x:1230,y:769,t:1528139939618};\\\", \\\"{x:1204,y:769,t:1528139939635};\\\", \\\"{x:1188,y:769,t:1528139939652};\\\", \\\"{x:1172,y:771,t:1528139939668};\\\", \\\"{x:1167,y:771,t:1528139939685};\\\", \\\"{x:1164,y:772,t:1528139939701};\\\", \\\"{x:1163,y:773,t:1528139939759};\\\", \\\"{x:1163,y:774,t:1528139939958};\\\", \\\"{x:1164,y:775,t:1528139939968};\\\", \\\"{x:1164,y:777,t:1528139939984};\\\", \\\"{x:1164,y:778,t:1528139941111};\\\", \\\"{x:1165,y:781,t:1528139941119};\\\", \\\"{x:1166,y:788,t:1528139941136};\\\", \\\"{x:1166,y:789,t:1528139941153};\\\", \\\"{x:1168,y:791,t:1528139941170};\\\", \\\"{x:1172,y:795,t:1528139941185};\\\", \\\"{x:1172,y:796,t:1528139941203};\\\", \\\"{x:1173,y:798,t:1528139941220};\\\", \\\"{x:1173,y:799,t:1528139941383};\\\", \\\"{x:1175,y:802,t:1528139941399};\\\", \\\"{x:1175,y:805,t:1528139941423};\\\", \\\"{x:1176,y:805,t:1528139941436};\\\", \\\"{x:1177,y:808,t:1528139941452};\\\", \\\"{x:1177,y:809,t:1528139941470};\\\", \\\"{x:1179,y:811,t:1528139941487};\\\", \\\"{x:1179,y:812,t:1528139941599};\\\", \\\"{x:1181,y:812,t:1528139941607};\\\", \\\"{x:1181,y:813,t:1528139941619};\\\", \\\"{x:1185,y:815,t:1528139941637};\\\", \\\"{x:1189,y:817,t:1528139941653};\\\", \\\"{x:1192,y:820,t:1528139941670};\\\", \\\"{x:1198,y:823,t:1528139941687};\\\", \\\"{x:1202,y:826,t:1528139941702};\\\", \\\"{x:1204,y:826,t:1528139941720};\\\", \\\"{x:1207,y:827,t:1528139941737};\\\", \\\"{x:1208,y:828,t:1528139941753};\\\", \\\"{x:1208,y:829,t:1528139941863};\\\", \\\"{x:1209,y:829,t:1528139941873};\\\", \\\"{x:1210,y:829,t:1528139942455};\\\", \\\"{x:1212,y:829,t:1528139942503};\\\", \\\"{x:1213,y:828,t:1528139942559};\\\", \\\"{x:1214,y:827,t:1528139942631};\\\", \\\"{x:1215,y:827,t:1528139942638};\\\", \\\"{x:1216,y:826,t:1528139943783};\\\", \\\"{x:1216,y:824,t:1528139943839};\\\", \\\"{x:1214,y:818,t:1528139943856};\\\", \\\"{x:1214,y:815,t:1528139943872};\\\", \\\"{x:1212,y:811,t:1528139943888};\\\", \\\"{x:1209,y:806,t:1528139943905};\\\", \\\"{x:1208,y:803,t:1528139943922};\\\", \\\"{x:1206,y:800,t:1528139943938};\\\", \\\"{x:1204,y:796,t:1528139943955};\\\", \\\"{x:1203,y:793,t:1528139943972};\\\", \\\"{x:1202,y:792,t:1528139943988};\\\", \\\"{x:1201,y:791,t:1528139944079};\\\", \\\"{x:1200,y:789,t:1528139944119};\\\", \\\"{x:1198,y:788,t:1528139944126};\\\", \\\"{x:1197,y:785,t:1528139944138};\\\", \\\"{x:1191,y:781,t:1528139944155};\\\", \\\"{x:1180,y:776,t:1528139944172};\\\", \\\"{x:1171,y:772,t:1528139944189};\\\", \\\"{x:1161,y:769,t:1528139944205};\\\", \\\"{x:1155,y:766,t:1528139944222};\\\", \\\"{x:1148,y:765,t:1528139944239};\\\", \\\"{x:1150,y:769,t:1528139944647};\\\", \\\"{x:1157,y:775,t:1528139944656};\\\", \\\"{x:1163,y:785,t:1528139944672};\\\", \\\"{x:1172,y:791,t:1528139944689};\\\", \\\"{x:1178,y:797,t:1528139944706};\\\", \\\"{x:1182,y:799,t:1528139944722};\\\", \\\"{x:1185,y:802,t:1528139945207};\\\", \\\"{x:1189,y:805,t:1528139945222};\\\", \\\"{x:1191,y:808,t:1528139945239};\\\", \\\"{x:1193,y:809,t:1528139945256};\\\", \\\"{x:1194,y:809,t:1528139945273};\\\", \\\"{x:1195,y:810,t:1528139945498};\\\", \\\"{x:1196,y:811,t:1528139945505};\\\", \\\"{x:1199,y:813,t:1528139945522};\\\", \\\"{x:1202,y:816,t:1528139945540};\\\", \\\"{x:1206,y:820,t:1528139945556};\\\", \\\"{x:1209,y:824,t:1528139945572};\\\", \\\"{x:1211,y:827,t:1528139945589};\\\", \\\"{x:1213,y:828,t:1528139945606};\\\", \\\"{x:1216,y:828,t:1528139945622};\\\", \\\"{x:1218,y:830,t:1528139945639};\\\", \\\"{x:1219,y:830,t:1528139945669};\\\", \\\"{x:1220,y:830,t:1528139945677};\\\", \\\"{x:1219,y:830,t:1528139946183};\\\", \\\"{x:1219,y:829,t:1528139947643};\\\", \\\"{x:1220,y:827,t:1528139947652};\\\", \\\"{x:1221,y:827,t:1528139947663};\\\", \\\"{x:1225,y:825,t:1528139947679};\\\", \\\"{x:1229,y:823,t:1528139947696};\\\", \\\"{x:1232,y:821,t:1528139947713};\\\", \\\"{x:1240,y:816,t:1528139947729};\\\", \\\"{x:1248,y:811,t:1528139947745};\\\", \\\"{x:1259,y:807,t:1528139947763};\\\", \\\"{x:1266,y:804,t:1528139947779};\\\", \\\"{x:1274,y:800,t:1528139947795};\\\", \\\"{x:1280,y:796,t:1528139947812};\\\", \\\"{x:1287,y:792,t:1528139947829};\\\", \\\"{x:1291,y:788,t:1528139947845};\\\", \\\"{x:1296,y:784,t:1528139947862};\\\", \\\"{x:1299,y:783,t:1528139947879};\\\", \\\"{x:1300,y:782,t:1528139947895};\\\", \\\"{x:1302,y:780,t:1528139947913};\\\", \\\"{x:1304,y:778,t:1528139947929};\\\", \\\"{x:1307,y:776,t:1528139947945};\\\", \\\"{x:1310,y:774,t:1528139947962};\\\", \\\"{x:1314,y:770,t:1528139947979};\\\", \\\"{x:1317,y:768,t:1528139947997};\\\", \\\"{x:1322,y:767,t:1528139948012};\\\", \\\"{x:1329,y:764,t:1528139948029};\\\", \\\"{x:1330,y:764,t:1528139948047};\\\", \\\"{x:1333,y:763,t:1528139948063};\\\", \\\"{x:1334,y:763,t:1528139948079};\\\", \\\"{x:1335,y:762,t:1528139948097};\\\", \\\"{x:1337,y:761,t:1528139948112};\\\", \\\"{x:1339,y:761,t:1528139948131};\\\", \\\"{x:1340,y:761,t:1528139948203};\\\", \\\"{x:1341,y:761,t:1528139949323};\\\", \\\"{x:1336,y:761,t:1528139951291};\\\", \\\"{x:1330,y:767,t:1528139951300};\\\", \\\"{x:1306,y:779,t:1528139951315};\\\", \\\"{x:1287,y:788,t:1528139951332};\\\", \\\"{x:1267,y:796,t:1528139951349};\\\", \\\"{x:1250,y:803,t:1528139951366};\\\", \\\"{x:1229,y:807,t:1528139951381};\\\", \\\"{x:1213,y:807,t:1528139951398};\\\", \\\"{x:1194,y:808,t:1528139951415};\\\", \\\"{x:1181,y:810,t:1528139951431};\\\", \\\"{x:1171,y:812,t:1528139951449};\\\", \\\"{x:1163,y:815,t:1528139951466};\\\", \\\"{x:1153,y:819,t:1528139951483};\\\", \\\"{x:1144,y:822,t:1528139951501};\\\", \\\"{x:1139,y:824,t:1528139951515};\\\", \\\"{x:1138,y:826,t:1528139951532};\\\", \\\"{x:1138,y:827,t:1528139951563};\\\", \\\"{x:1137,y:827,t:1528139951579};\\\", \\\"{x:1137,y:828,t:1528139951603};\\\", \\\"{x:1138,y:830,t:1528139951619};\\\", \\\"{x:1139,y:830,t:1528139951632};\\\", \\\"{x:1144,y:830,t:1528139951648};\\\", \\\"{x:1148,y:830,t:1528139951666};\\\", \\\"{x:1155,y:830,t:1528139951683};\\\", \\\"{x:1159,y:830,t:1528139951700};\\\", \\\"{x:1160,y:830,t:1528139951715};\\\", \\\"{x:1161,y:830,t:1528139951732};\\\", \\\"{x:1162,y:825,t:1528139951748};\\\", \\\"{x:1162,y:818,t:1528139951765};\\\", \\\"{x:1158,y:813,t:1528139951782};\\\", \\\"{x:1154,y:810,t:1528139951798};\\\", \\\"{x:1142,y:808,t:1528139951815};\\\", \\\"{x:1132,y:806,t:1528139951831};\\\", \\\"{x:1123,y:806,t:1528139951848};\\\", \\\"{x:1122,y:806,t:1528139951865};\\\", \\\"{x:1114,y:812,t:1528139951882};\\\", \\\"{x:1110,y:820,t:1528139951898};\\\", \\\"{x:1109,y:827,t:1528139951915};\\\", \\\"{x:1107,y:835,t:1528139951932};\\\", \\\"{x:1106,y:840,t:1528139951949};\\\", \\\"{x:1105,y:842,t:1528139951965};\\\", \\\"{x:1105,y:844,t:1528139951982};\\\", \\\"{x:1105,y:846,t:1528139951999};\\\", \\\"{x:1105,y:847,t:1528139952107};\\\", \\\"{x:1110,y:847,t:1528139952115};\\\", \\\"{x:1119,y:844,t:1528139952133};\\\", \\\"{x:1129,y:836,t:1528139952149};\\\", \\\"{x:1140,y:827,t:1528139952165};\\\", \\\"{x:1146,y:820,t:1528139952182};\\\", \\\"{x:1152,y:815,t:1528139952200};\\\", \\\"{x:1156,y:811,t:1528139952215};\\\", \\\"{x:1159,y:809,t:1528139952233};\\\", \\\"{x:1161,y:807,t:1528139952249};\\\", \\\"{x:1164,y:805,t:1528139952265};\\\", \\\"{x:1167,y:801,t:1528139952282};\\\", \\\"{x:1170,y:796,t:1528139952299};\\\", \\\"{x:1175,y:789,t:1528139952315};\\\", \\\"{x:1177,y:787,t:1528139952332};\\\", \\\"{x:1179,y:783,t:1528139952350};\\\", \\\"{x:1182,y:779,t:1528139952366};\\\", \\\"{x:1185,y:778,t:1528139952382};\\\", \\\"{x:1186,y:775,t:1528139952399};\\\", \\\"{x:1189,y:771,t:1528139952417};\\\", \\\"{x:1190,y:770,t:1528139952433};\\\", \\\"{x:1192,y:767,t:1528139952450};\\\", \\\"{x:1193,y:765,t:1528139952466};\\\", \\\"{x:1195,y:763,t:1528139952482};\\\", \\\"{x:1199,y:767,t:1528139952588};\\\", \\\"{x:1205,y:776,t:1528139952600};\\\", \\\"{x:1213,y:794,t:1528139952617};\\\", \\\"{x:1225,y:814,t:1528139952632};\\\", \\\"{x:1233,y:828,t:1528139952650};\\\", \\\"{x:1252,y:853,t:1528139952667};\\\", \\\"{x:1262,y:863,t:1528139952683};\\\", \\\"{x:1271,y:875,t:1528139952701};\\\", \\\"{x:1274,y:879,t:1528139952717};\\\", \\\"{x:1276,y:882,t:1528139952732};\\\", \\\"{x:1277,y:881,t:1528139952875};\\\", \\\"{x:1277,y:875,t:1528139952883};\\\", \\\"{x:1278,y:865,t:1528139952901};\\\", \\\"{x:1283,y:853,t:1528139952917};\\\", \\\"{x:1284,y:849,t:1528139952933};\\\", \\\"{x:1286,y:846,t:1528139952950};\\\", \\\"{x:1283,y:846,t:1528139953051};\\\", \\\"{x:1275,y:852,t:1528139953066};\\\", \\\"{x:1271,y:856,t:1528139953083};\\\", \\\"{x:1264,y:862,t:1528139953101};\\\", \\\"{x:1261,y:866,t:1528139953116};\\\", \\\"{x:1254,y:875,t:1528139953133};\\\", \\\"{x:1248,y:883,t:1528139953149};\\\", \\\"{x:1243,y:889,t:1528139953167};\\\", \\\"{x:1241,y:892,t:1528139953183};\\\", \\\"{x:1239,y:894,t:1528139953200};\\\", \\\"{x:1236,y:896,t:1528139953217};\\\", \\\"{x:1231,y:900,t:1528139953234};\\\", \\\"{x:1221,y:905,t:1528139953249};\\\", \\\"{x:1210,y:909,t:1528139953267};\\\", \\\"{x:1205,y:912,t:1528139953283};\\\", \\\"{x:1201,y:914,t:1528139953302};\\\", \\\"{x:1197,y:916,t:1528139953316};\\\", \\\"{x:1196,y:916,t:1528139953333};\\\", \\\"{x:1195,y:916,t:1528139953351};\\\", \\\"{x:1195,y:917,t:1528139953367};\\\", \\\"{x:1194,y:918,t:1528139953411};\\\", \\\"{x:1193,y:913,t:1528139953467};\\\", \\\"{x:1194,y:897,t:1528139953484};\\\", \\\"{x:1196,y:876,t:1528139953501};\\\", \\\"{x:1198,y:866,t:1528139953517};\\\", \\\"{x:1201,y:861,t:1528139953534};\\\", \\\"{x:1202,y:859,t:1528139953551};\\\", \\\"{x:1202,y:855,t:1528139953567};\\\", \\\"{x:1204,y:853,t:1528139953584};\\\", \\\"{x:1204,y:850,t:1528139953600};\\\", \\\"{x:1204,y:848,t:1528139953617};\\\", \\\"{x:1204,y:847,t:1528139953633};\\\", \\\"{x:1204,y:845,t:1528139953715};\\\", \\\"{x:1204,y:844,t:1528139953771};\\\", \\\"{x:1204,y:842,t:1528139953794};\\\", \\\"{x:1204,y:841,t:1528139953906};\\\", \\\"{x:1204,y:839,t:1528139953917};\\\", \\\"{x:1204,y:838,t:1528139953932};\\\", \\\"{x:1205,y:835,t:1528139953950};\\\", \\\"{x:1207,y:834,t:1528139953970};\\\", \\\"{x:1208,y:833,t:1528139953983};\\\", \\\"{x:1210,y:827,t:1528139954000};\\\", \\\"{x:1211,y:824,t:1528139954017};\\\", \\\"{x:1213,y:822,t:1528139954033};\\\", \\\"{x:1215,y:819,t:1528139954050};\\\", \\\"{x:1216,y:819,t:1528139954068};\\\", \\\"{x:1216,y:818,t:1528139954084};\\\", \\\"{x:1217,y:818,t:1528139954211};\\\", \\\"{x:1219,y:817,t:1528139954219};\\\", \\\"{x:1221,y:817,t:1528139954235};\\\", \\\"{x:1223,y:817,t:1528139954250};\\\", \\\"{x:1223,y:816,t:1528139954465};\\\", \\\"{x:1221,y:816,t:1528139954498};\\\", \\\"{x:1219,y:816,t:1528139954506};\\\", \\\"{x:1218,y:816,t:1528139954516};\\\", \\\"{x:1211,y:816,t:1528139954535};\\\", \\\"{x:1208,y:816,t:1528139954551};\\\", \\\"{x:1207,y:818,t:1528139954771};\\\", \\\"{x:1206,y:819,t:1528139954803};\\\", \\\"{x:1206,y:820,t:1528139954818};\\\", \\\"{x:1206,y:822,t:1528139954834};\\\", \\\"{x:1206,y:823,t:1528139954851};\\\", \\\"{x:1206,y:824,t:1528139954882};\\\", \\\"{x:1206,y:825,t:1528139954907};\\\", \\\"{x:1206,y:826,t:1528139955689};\\\", \\\"{x:1206,y:827,t:1528139955722};\\\", \\\"{x:1206,y:828,t:1528139955794};\\\", \\\"{x:1207,y:829,t:1528139955850};\\\", \\\"{x:1210,y:830,t:1528139955867};\\\", \\\"{x:1211,y:830,t:1528139955886};\\\", \\\"{x:1213,y:830,t:1528139955930};\\\", \\\"{x:1213,y:831,t:1528139955938};\\\", \\\"{x:1214,y:831,t:1528139955963};\\\", \\\"{x:1216,y:831,t:1528139955978};\\\", \\\"{x:1217,y:831,t:1528139956027};\\\", \\\"{x:1218,y:831,t:1528139956259};\\\", \\\"{x:1218,y:829,t:1528139956269};\\\", \\\"{x:1218,y:826,t:1528139956285};\\\", \\\"{x:1220,y:824,t:1528139956316};\\\", \\\"{x:1220,y:823,t:1528139956330};\\\", \\\"{x:1220,y:821,t:1528139956514};\\\", \\\"{x:1221,y:820,t:1528139956531};\\\", \\\"{x:1221,y:818,t:1528139956539};\\\", \\\"{x:1222,y:815,t:1528139956553};\\\", \\\"{x:1225,y:808,t:1528139956569};\\\", \\\"{x:1227,y:803,t:1528139956585};\\\", \\\"{x:1230,y:795,t:1528139956602};\\\", \\\"{x:1233,y:789,t:1528139956620};\\\", \\\"{x:1238,y:778,t:1528139956636};\\\", \\\"{x:1242,y:770,t:1528139956653};\\\", \\\"{x:1245,y:757,t:1528139956669};\\\", \\\"{x:1246,y:744,t:1528139956686};\\\", \\\"{x:1246,y:732,t:1528139956703};\\\", \\\"{x:1246,y:719,t:1528139956720};\\\", \\\"{x:1246,y:712,t:1528139956737};\\\", \\\"{x:1245,y:705,t:1528139956753};\\\", \\\"{x:1245,y:701,t:1528139956770};\\\", \\\"{x:1245,y:695,t:1528139956787};\\\", \\\"{x:1245,y:690,t:1528139956802};\\\", \\\"{x:1244,y:684,t:1528139956820};\\\", \\\"{x:1244,y:679,t:1528139956837};\\\", \\\"{x:1244,y:677,t:1528139956853};\\\", \\\"{x:1244,y:671,t:1528139956869};\\\", \\\"{x:1244,y:666,t:1528139956887};\\\", \\\"{x:1244,y:660,t:1528139956902};\\\", \\\"{x:1244,y:657,t:1528139956919};\\\", \\\"{x:1246,y:653,t:1528139956936};\\\", \\\"{x:1247,y:648,t:1528139956951};\\\", \\\"{x:1249,y:635,t:1528139956969};\\\", \\\"{x:1251,y:625,t:1528139956986};\\\", \\\"{x:1253,y:619,t:1528139957002};\\\", \\\"{x:1254,y:609,t:1528139957019};\\\", \\\"{x:1255,y:604,t:1528139957036};\\\", \\\"{x:1256,y:601,t:1528139957052};\\\", \\\"{x:1256,y:600,t:1528139957070};\\\", \\\"{x:1255,y:600,t:1528139957251};\\\", \\\"{x:1252,y:606,t:1528139957259};\\\", \\\"{x:1251,y:608,t:1528139957270};\\\", \\\"{x:1243,y:624,t:1528139957287};\\\", \\\"{x:1224,y:653,t:1528139957303};\\\", \\\"{x:1205,y:682,t:1528139957319};\\\", \\\"{x:1196,y:705,t:1528139957336};\\\", \\\"{x:1180,y:743,t:1528139957352};\\\", \\\"{x:1167,y:766,t:1528139957369};\\\", \\\"{x:1155,y:793,t:1528139957386};\\\", \\\"{x:1150,y:807,t:1528139957403};\\\", \\\"{x:1146,y:816,t:1528139957419};\\\", \\\"{x:1144,y:821,t:1528139957436};\\\", \\\"{x:1143,y:823,t:1528139957453};\\\", \\\"{x:1144,y:824,t:1528139957515};\\\", \\\"{x:1155,y:816,t:1528139957523};\\\", \\\"{x:1169,y:799,t:1528139957536};\\\", \\\"{x:1207,y:755,t:1528139957553};\\\", \\\"{x:1240,y:705,t:1528139957569};\\\", \\\"{x:1279,y:612,t:1528139957586};\\\", \\\"{x:1302,y:557,t:1528139957603};\\\", \\\"{x:1311,y:528,t:1528139957620};\\\", \\\"{x:1316,y:511,t:1528139957636};\\\", \\\"{x:1320,y:493,t:1528139957654};\\\", \\\"{x:1321,y:478,t:1528139957671};\\\", \\\"{x:1321,y:468,t:1528139957686};\\\", \\\"{x:1323,y:459,t:1528139957704};\\\", \\\"{x:1325,y:456,t:1528139957720};\\\", \\\"{x:1325,y:454,t:1528139957736};\\\", \\\"{x:1325,y:453,t:1528139957754};\\\", \\\"{x:1324,y:459,t:1528139957827};\\\", \\\"{x:1321,y:467,t:1528139957837};\\\", \\\"{x:1313,y:489,t:1528139957853};\\\", \\\"{x:1305,y:506,t:1528139957870};\\\", \\\"{x:1302,y:524,t:1528139957887};\\\", \\\"{x:1296,y:531,t:1528139957904};\\\", \\\"{x:1296,y:532,t:1528139957921};\\\", \\\"{x:1295,y:532,t:1528139957937};\\\", \\\"{x:1295,y:534,t:1528139958124};\\\", \\\"{x:1293,y:537,t:1528139958138};\\\", \\\"{x:1289,y:542,t:1528139958153};\\\", \\\"{x:1284,y:550,t:1528139958170};\\\", \\\"{x:1282,y:554,t:1528139958188};\\\", \\\"{x:1282,y:555,t:1528139958203};\\\", \\\"{x:1281,y:555,t:1528139958221};\\\", \\\"{x:1281,y:556,t:1528139958237};\\\", \\\"{x:1281,y:557,t:1528139958254};\\\", \\\"{x:1279,y:558,t:1528139958275};\\\", \\\"{x:1277,y:559,t:1528139958288};\\\", \\\"{x:1276,y:561,t:1528139958303};\\\", \\\"{x:1274,y:565,t:1528139958322};\\\", \\\"{x:1273,y:567,t:1528139958338};\\\", \\\"{x:1272,y:570,t:1528139958354};\\\", \\\"{x:1271,y:572,t:1528139958370};\\\", \\\"{x:1270,y:573,t:1528139958388};\\\", \\\"{x:1270,y:574,t:1528139958404};\\\", \\\"{x:1269,y:576,t:1528139958617};\\\", \\\"{x:1268,y:577,t:1528139958626};\\\", \\\"{x:1267,y:581,t:1528139958637};\\\", \\\"{x:1261,y:592,t:1528139958654};\\\", \\\"{x:1252,y:609,t:1528139958670};\\\", \\\"{x:1241,y:631,t:1528139958687};\\\", \\\"{x:1227,y:651,t:1528139958704};\\\", \\\"{x:1217,y:666,t:1528139958720};\\\", \\\"{x:1207,y:677,t:1528139958737};\\\", \\\"{x:1195,y:697,t:1528139958753};\\\", \\\"{x:1186,y:712,t:1528139958770};\\\", \\\"{x:1181,y:725,t:1528139958787};\\\", \\\"{x:1174,y:740,t:1528139958805};\\\", \\\"{x:1166,y:757,t:1528139958820};\\\", \\\"{x:1159,y:772,t:1528139958837};\\\", \\\"{x:1150,y:787,t:1528139958854};\\\", \\\"{x:1146,y:799,t:1528139958870};\\\", \\\"{x:1146,y:803,t:1528139958887};\\\", \\\"{x:1146,y:808,t:1528139958905};\\\", \\\"{x:1144,y:813,t:1528139958921};\\\", \\\"{x:1143,y:817,t:1528139958938};\\\", \\\"{x:1146,y:814,t:1528139959010};\\\", \\\"{x:1150,y:809,t:1528139959022};\\\", \\\"{x:1163,y:791,t:1528139959037};\\\", \\\"{x:1185,y:750,t:1528139959054};\\\", \\\"{x:1196,y:716,t:1528139959071};\\\", \\\"{x:1212,y:675,t:1528139959087};\\\", \\\"{x:1232,y:620,t:1528139959104};\\\", \\\"{x:1242,y:585,t:1528139959122};\\\", \\\"{x:1248,y:568,t:1528139959138};\\\", \\\"{x:1251,y:560,t:1528139959155};\\\", \\\"{x:1252,y:556,t:1528139959171};\\\", \\\"{x:1256,y:549,t:1528139959187};\\\", \\\"{x:1256,y:548,t:1528139959204};\\\", \\\"{x:1257,y:547,t:1528139959222};\\\", \\\"{x:1257,y:546,t:1528139959251};\\\", \\\"{x:1258,y:546,t:1528139959587};\\\", \\\"{x:1259,y:546,t:1528139959594};\\\", \\\"{x:1261,y:546,t:1528139959604};\\\", \\\"{x:1263,y:545,t:1528139959622};\\\", \\\"{x:1265,y:544,t:1528139959638};\\\", \\\"{x:1265,y:545,t:1528139959900};\\\", \\\"{x:1265,y:546,t:1528139959906};\\\", \\\"{x:1265,y:547,t:1528139959921};\\\", \\\"{x:1265,y:548,t:1528139959939};\\\", \\\"{x:1265,y:550,t:1528139960035};\\\", \\\"{x:1267,y:551,t:1528139960042};\\\", \\\"{x:1269,y:552,t:1528139960056};\\\", \\\"{x:1270,y:554,t:1528139960072};\\\", \\\"{x:1273,y:558,t:1528139960089};\\\", \\\"{x:1277,y:561,t:1528139960107};\\\", \\\"{x:1280,y:561,t:1528139960122};\\\", \\\"{x:1280,y:563,t:1528139960138};\\\", \\\"{x:1281,y:563,t:1528139960156};\\\", \\\"{x:1283,y:565,t:1528139960172};\\\", \\\"{x:1283,y:566,t:1528139960242};\\\", \\\"{x:1284,y:566,t:1528139960256};\\\", \\\"{x:1286,y:568,t:1528139960284};\\\", \\\"{x:1286,y:569,t:1528139960300};\\\", \\\"{x:1287,y:570,t:1528139960307};\\\", \\\"{x:1288,y:571,t:1528139960322};\\\", \\\"{x:1291,y:574,t:1528139960338};\\\", \\\"{x:1292,y:575,t:1528139960356};\\\", \\\"{x:1293,y:576,t:1528139960426};\\\", \\\"{x:1293,y:573,t:1528139960547};\\\", \\\"{x:1290,y:568,t:1528139960555};\\\", \\\"{x:1289,y:565,t:1528139960573};\\\", \\\"{x:1285,y:563,t:1528139960589};\\\", \\\"{x:1284,y:562,t:1528139960605};\\\", \\\"{x:1283,y:562,t:1528139960891};\\\", \\\"{x:1282,y:562,t:1528139960906};\\\", \\\"{x:1283,y:568,t:1528139960923};\\\", \\\"{x:1286,y:570,t:1528139960941};\\\", \\\"{x:1286,y:572,t:1528139960956};\\\", \\\"{x:1287,y:574,t:1528139960973};\\\", \\\"{x:1289,y:575,t:1528139960990};\\\", \\\"{x:1291,y:578,t:1528139961006};\\\", \\\"{x:1292,y:580,t:1528139961023};\\\", \\\"{x:1295,y:583,t:1528139961040};\\\", \\\"{x:1298,y:587,t:1528139961057};\\\", \\\"{x:1300,y:592,t:1528139961073};\\\", \\\"{x:1303,y:597,t:1528139961090};\\\", \\\"{x:1304,y:601,t:1528139961107};\\\", \\\"{x:1308,y:608,t:1528139961122};\\\", \\\"{x:1309,y:611,t:1528139961139};\\\", \\\"{x:1310,y:614,t:1528139961157};\\\", \\\"{x:1313,y:619,t:1528139961173};\\\", \\\"{x:1315,y:623,t:1528139961189};\\\", \\\"{x:1319,y:627,t:1528139961207};\\\", \\\"{x:1321,y:631,t:1528139961223};\\\", \\\"{x:1323,y:634,t:1528139961240};\\\", \\\"{x:1326,y:637,t:1528139961257};\\\", \\\"{x:1329,y:642,t:1528139961273};\\\", \\\"{x:1332,y:646,t:1528139961290};\\\", \\\"{x:1335,y:653,t:1528139961306};\\\", \\\"{x:1338,y:657,t:1528139961323};\\\", \\\"{x:1344,y:665,t:1528139961340};\\\", \\\"{x:1347,y:672,t:1528139961357};\\\", \\\"{x:1349,y:678,t:1528139961373};\\\", \\\"{x:1355,y:683,t:1528139961390};\\\", \\\"{x:1359,y:690,t:1528139961407};\\\", \\\"{x:1364,y:696,t:1528139961423};\\\", \\\"{x:1367,y:701,t:1528139961440};\\\", \\\"{x:1372,y:707,t:1528139961457};\\\", \\\"{x:1374,y:711,t:1528139961474};\\\", \\\"{x:1377,y:720,t:1528139961491};\\\", \\\"{x:1380,y:724,t:1528139961506};\\\", \\\"{x:1381,y:728,t:1528139961524};\\\", \\\"{x:1382,y:730,t:1528139961540};\\\", \\\"{x:1382,y:731,t:1528139961556};\\\", \\\"{x:1383,y:734,t:1528139961574};\\\", \\\"{x:1383,y:736,t:1528139961590};\\\", \\\"{x:1383,y:742,t:1528139961607};\\\", \\\"{x:1383,y:744,t:1528139961624};\\\", \\\"{x:1385,y:746,t:1528139961639};\\\", \\\"{x:1385,y:747,t:1528139961657};\\\", \\\"{x:1387,y:750,t:1528139961674};\\\", \\\"{x:1387,y:751,t:1528139961690};\\\", \\\"{x:1387,y:752,t:1528139961707};\\\", \\\"{x:1387,y:753,t:1528139961724};\\\", \\\"{x:1387,y:754,t:1528139961746};\\\", \\\"{x:1387,y:756,t:1528139961757};\\\", \\\"{x:1387,y:757,t:1528139961774};\\\", \\\"{x:1387,y:759,t:1528139961790};\\\", \\\"{x:1388,y:763,t:1528139961807};\\\", \\\"{x:1389,y:769,t:1528139961824};\\\", \\\"{x:1389,y:773,t:1528139961840};\\\", \\\"{x:1391,y:775,t:1528139961857};\\\", \\\"{x:1392,y:776,t:1528139961874};\\\", \\\"{x:1392,y:778,t:1528139961890};\\\", \\\"{x:1393,y:780,t:1528139961907};\\\", \\\"{x:1393,y:785,t:1528139961924};\\\", \\\"{x:1393,y:790,t:1528139961941};\\\", \\\"{x:1396,y:798,t:1528139961957};\\\", \\\"{x:1397,y:806,t:1528139961974};\\\", \\\"{x:1398,y:811,t:1528139961991};\\\", \\\"{x:1399,y:816,t:1528139962007};\\\", \\\"{x:1401,y:823,t:1528139962024};\\\", \\\"{x:1404,y:829,t:1528139962041};\\\", \\\"{x:1406,y:837,t:1528139962057};\\\", \\\"{x:1407,y:838,t:1528139962074};\\\", \\\"{x:1407,y:839,t:1528139962099};\\\", \\\"{x:1407,y:841,t:1528139962107};\\\", \\\"{x:1408,y:844,t:1528139962123};\\\", \\\"{x:1409,y:848,t:1528139962140};\\\", \\\"{x:1410,y:854,t:1528139962156};\\\", \\\"{x:1413,y:858,t:1528139962173};\\\", \\\"{x:1416,y:862,t:1528139962190};\\\", \\\"{x:1416,y:865,t:1528139962206};\\\", \\\"{x:1417,y:870,t:1528139962224};\\\", \\\"{x:1419,y:874,t:1528139962240};\\\", \\\"{x:1422,y:879,t:1528139962256};\\\", \\\"{x:1424,y:886,t:1528139962274};\\\", \\\"{x:1427,y:892,t:1528139962290};\\\", \\\"{x:1428,y:896,t:1528139962307};\\\", \\\"{x:1430,y:898,t:1528139962324};\\\", \\\"{x:1430,y:900,t:1528139962341};\\\", \\\"{x:1431,y:903,t:1528139962358};\\\", \\\"{x:1432,y:904,t:1528139962374};\\\", \\\"{x:1432,y:905,t:1528139962443};\\\", \\\"{x:1431,y:898,t:1528139966123};\\\", \\\"{x:1423,y:891,t:1528139966130};\\\", \\\"{x:1416,y:884,t:1528139966144};\\\", \\\"{x:1397,y:870,t:1528139966160};\\\", \\\"{x:1377,y:853,t:1528139966177};\\\", \\\"{x:1352,y:834,t:1528139966194};\\\", \\\"{x:1337,y:824,t:1528139966210};\\\", \\\"{x:1329,y:818,t:1528139966227};\\\", \\\"{x:1327,y:817,t:1528139966244};\\\", \\\"{x:1326,y:817,t:1528139966451};\\\", \\\"{x:1324,y:816,t:1528139966466};\\\", \\\"{x:1323,y:816,t:1528139966491};\\\", \\\"{x:1322,y:816,t:1528139966506};\\\", \\\"{x:1321,y:814,t:1528139966538};\\\", \\\"{x:1321,y:813,t:1528139966554};\\\", \\\"{x:1319,y:811,t:1528139966827};\\\", \\\"{x:1319,y:810,t:1528139966844};\\\", \\\"{x:1318,y:810,t:1528139966861};\\\", \\\"{x:1317,y:809,t:1528139966878};\\\", \\\"{x:1317,y:808,t:1528139966946};\\\", \\\"{x:1317,y:807,t:1528139967027};\\\", \\\"{x:1317,y:805,t:1528139967044};\\\", \\\"{x:1317,y:804,t:1528139967131};\\\", \\\"{x:1317,y:803,t:1528139967386};\\\", \\\"{x:1317,y:801,t:1528139967394};\\\", \\\"{x:1313,y:796,t:1528139967411};\\\", \\\"{x:1313,y:793,t:1528139967428};\\\", \\\"{x:1313,y:792,t:1528139967445};\\\", \\\"{x:1310,y:786,t:1528139967462};\\\", \\\"{x:1309,y:783,t:1528139967478};\\\", \\\"{x:1308,y:781,t:1528139967495};\\\", \\\"{x:1307,y:780,t:1528139967515};\\\", \\\"{x:1306,y:777,t:1528139967987};\\\", \\\"{x:1309,y:772,t:1528139967995};\\\", \\\"{x:1315,y:764,t:1528139968012};\\\", \\\"{x:1320,y:755,t:1528139968029};\\\", \\\"{x:1322,y:747,t:1528139968045};\\\", \\\"{x:1327,y:734,t:1528139968062};\\\", \\\"{x:1330,y:721,t:1528139968079};\\\", \\\"{x:1332,y:712,t:1528139968095};\\\", \\\"{x:1332,y:711,t:1528139968187};\\\", \\\"{x:1330,y:711,t:1528139968195};\\\", \\\"{x:1329,y:714,t:1528139968212};\\\", \\\"{x:1329,y:719,t:1528139968229};\\\", \\\"{x:1331,y:723,t:1528139968245};\\\", \\\"{x:1336,y:729,t:1528139968262};\\\", \\\"{x:1338,y:731,t:1528139968279};\\\", \\\"{x:1339,y:734,t:1528139968295};\\\", \\\"{x:1342,y:736,t:1528139968312};\\\", \\\"{x:1343,y:737,t:1528139968329};\\\", \\\"{x:1344,y:739,t:1528139968346};\\\", \\\"{x:1343,y:740,t:1528139968667};\\\", \\\"{x:1341,y:741,t:1528139968691};\\\", \\\"{x:1340,y:742,t:1528139968714};\\\", \\\"{x:1338,y:742,t:1528139968730};\\\", \\\"{x:1336,y:743,t:1528139968747};\\\", \\\"{x:1332,y:745,t:1528139968763};\\\", \\\"{x:1327,y:749,t:1528139968779};\\\", \\\"{x:1317,y:761,t:1528139968797};\\\", \\\"{x:1309,y:768,t:1528139968812};\\\", \\\"{x:1304,y:770,t:1528139968829};\\\", \\\"{x:1299,y:773,t:1528139968846};\\\", \\\"{x:1293,y:778,t:1528139968862};\\\", \\\"{x:1292,y:778,t:1528139968879};\\\", \\\"{x:1292,y:779,t:1528139968896};\\\", \\\"{x:1291,y:779,t:1528139968912};\\\", \\\"{x:1289,y:779,t:1528139968929};\\\", \\\"{x:1283,y:779,t:1528139968947};\\\", \\\"{x:1280,y:779,t:1528139968962};\\\", \\\"{x:1275,y:779,t:1528139968979};\\\", \\\"{x:1272,y:780,t:1528139968996};\\\", \\\"{x:1269,y:782,t:1528139969013};\\\", \\\"{x:1261,y:789,t:1528139969030};\\\", \\\"{x:1251,y:798,t:1528139969046};\\\", \\\"{x:1237,y:813,t:1528139969063};\\\", \\\"{x:1227,y:826,t:1528139969079};\\\", \\\"{x:1217,y:836,t:1528139969096};\\\", \\\"{x:1208,y:842,t:1528139969112};\\\", \\\"{x:1204,y:845,t:1528139969128};\\\", \\\"{x:1202,y:846,t:1528139969145};\\\", \\\"{x:1200,y:848,t:1528139969162};\\\", \\\"{x:1199,y:849,t:1528139969225};\\\", \\\"{x:1198,y:849,t:1528139969250};\\\", \\\"{x:1197,y:849,t:1528139969262};\\\", \\\"{x:1194,y:846,t:1528139969290};\\\", \\\"{x:1191,y:844,t:1528139969298};\\\", \\\"{x:1189,y:834,t:1528139969313};\\\", \\\"{x:1182,y:818,t:1528139969330};\\\", \\\"{x:1182,y:815,t:1528139969346};\\\", \\\"{x:1182,y:814,t:1528139969362};\\\", \\\"{x:1183,y:813,t:1528139969426};\\\", \\\"{x:1188,y:813,t:1528139969434};\\\", \\\"{x:1191,y:814,t:1528139969446};\\\", \\\"{x:1197,y:815,t:1528139969463};\\\", \\\"{x:1204,y:817,t:1528139969479};\\\", \\\"{x:1209,y:819,t:1528139969496};\\\", \\\"{x:1212,y:821,t:1528139969513};\\\", \\\"{x:1214,y:822,t:1528139969530};\\\", \\\"{x:1215,y:823,t:1528139969546};\\\", \\\"{x:1215,y:824,t:1528139969930};\\\", \\\"{x:1214,y:824,t:1528139969946};\\\", \\\"{x:1212,y:825,t:1528139969971};\\\", \\\"{x:1212,y:826,t:1528139970091};\\\", \\\"{x:1211,y:826,t:1528139970171};\\\", \\\"{x:1209,y:827,t:1528139970466};\\\", \\\"{x:1208,y:827,t:1528139970501};\\\", \\\"{x:1207,y:827,t:1528139970529};\\\", \\\"{x:1205,y:829,t:1528139970585};\\\", \\\"{x:1204,y:830,t:1528139970597};\\\", \\\"{x:1199,y:833,t:1528139970614};\\\", \\\"{x:1195,y:837,t:1528139970629};\\\", \\\"{x:1188,y:842,t:1528139970646};\\\", \\\"{x:1179,y:850,t:1528139970663};\\\", \\\"{x:1172,y:856,t:1528139970681};\\\", \\\"{x:1163,y:861,t:1528139970696};\\\", \\\"{x:1155,y:866,t:1528139970714};\\\", \\\"{x:1151,y:868,t:1528139970730};\\\", \\\"{x:1149,y:869,t:1528139970747};\\\", \\\"{x:1145,y:871,t:1528139970764};\\\", \\\"{x:1143,y:872,t:1528139970781};\\\", \\\"{x:1140,y:874,t:1528139970797};\\\", \\\"{x:1136,y:876,t:1528139970813};\\\", \\\"{x:1133,y:877,t:1528139970831};\\\", \\\"{x:1130,y:880,t:1528139970847};\\\", \\\"{x:1125,y:883,t:1528139970864};\\\", \\\"{x:1118,y:889,t:1528139970881};\\\", \\\"{x:1115,y:892,t:1528139970898};\\\", \\\"{x:1106,y:900,t:1528139970914};\\\", \\\"{x:1105,y:903,t:1528139970931};\\\", \\\"{x:1100,y:910,t:1528139970946};\\\", \\\"{x:1095,y:915,t:1528139970964};\\\", \\\"{x:1092,y:919,t:1528139970981};\\\", \\\"{x:1091,y:921,t:1528139970997};\\\", \\\"{x:1091,y:922,t:1528139971014};\\\", \\\"{x:1090,y:923,t:1528139971031};\\\", \\\"{x:1089,y:924,t:1528139971050};\\\", \\\"{x:1088,y:925,t:1528139971066};\\\", \\\"{x:1088,y:921,t:1528139971219};\\\", \\\"{x:1089,y:919,t:1528139971231};\\\", \\\"{x:1091,y:913,t:1528139971249};\\\", \\\"{x:1095,y:906,t:1528139971264};\\\", \\\"{x:1101,y:895,t:1528139971281};\\\", \\\"{x:1108,y:887,t:1528139971299};\\\", \\\"{x:1111,y:885,t:1528139971314};\\\", \\\"{x:1112,y:884,t:1528139971331};\\\", \\\"{x:1114,y:883,t:1528139971348};\\\", \\\"{x:1115,y:882,t:1528139971364};\\\", \\\"{x:1115,y:880,t:1528139971381};\\\", \\\"{x:1118,y:877,t:1528139971398};\\\", \\\"{x:1119,y:875,t:1528139971414};\\\", \\\"{x:1121,y:873,t:1528139971431};\\\", \\\"{x:1122,y:873,t:1528139971448};\\\", \\\"{x:1124,y:871,t:1528139971464};\\\", \\\"{x:1125,y:869,t:1528139971481};\\\", \\\"{x:1129,y:863,t:1528139971498};\\\", \\\"{x:1132,y:858,t:1528139971514};\\\", \\\"{x:1135,y:851,t:1528139971532};\\\", \\\"{x:1140,y:845,t:1528139971548};\\\", \\\"{x:1143,y:840,t:1528139971565};\\\", \\\"{x:1145,y:836,t:1528139971581};\\\", \\\"{x:1148,y:832,t:1528139971598};\\\", \\\"{x:1149,y:830,t:1528139971615};\\\", \\\"{x:1151,y:827,t:1528139971631};\\\", \\\"{x:1153,y:824,t:1528139971648};\\\", \\\"{x:1156,y:819,t:1528139971665};\\\", \\\"{x:1161,y:812,t:1528139971681};\\\", \\\"{x:1167,y:804,t:1528139971698};\\\", \\\"{x:1171,y:799,t:1528139971715};\\\", \\\"{x:1172,y:796,t:1528139971731};\\\", \\\"{x:1176,y:791,t:1528139971749};\\\", \\\"{x:1177,y:786,t:1528139971765};\\\", \\\"{x:1178,y:783,t:1528139971781};\\\", \\\"{x:1179,y:778,t:1528139971798};\\\", \\\"{x:1180,y:777,t:1528139971815};\\\", \\\"{x:1180,y:775,t:1528139971831};\\\", \\\"{x:1182,y:774,t:1528139971848};\\\", \\\"{x:1182,y:771,t:1528139971865};\\\", \\\"{x:1184,y:770,t:1528139971881};\\\", \\\"{x:1185,y:767,t:1528139971898};\\\", \\\"{x:1186,y:766,t:1528139971946};\\\", \\\"{x:1187,y:764,t:1528139971971};\\\", \\\"{x:1188,y:764,t:1528139971986};\\\", \\\"{x:1189,y:763,t:1528139971999};\\\", \\\"{x:1190,y:762,t:1528139972100};\\\", \\\"{x:1192,y:756,t:1528139972115};\\\", \\\"{x:1197,y:748,t:1528139972132};\\\", \\\"{x:1203,y:740,t:1528139972148};\\\", \\\"{x:1206,y:735,t:1528139972165};\\\", \\\"{x:1208,y:728,t:1528139972182};\\\", \\\"{x:1210,y:727,t:1528139972198};\\\", \\\"{x:1210,y:726,t:1528139972218};\\\", \\\"{x:1210,y:725,t:1528139972232};\\\", \\\"{x:1211,y:724,t:1528139972251};\\\", \\\"{x:1212,y:723,t:1528139972265};\\\", \\\"{x:1212,y:722,t:1528139972282};\\\", \\\"{x:1213,y:721,t:1528139972299};\\\", \\\"{x:1214,y:719,t:1528139972394};\\\", \\\"{x:1216,y:718,t:1528139972410};\\\", \\\"{x:1217,y:717,t:1528139972418};\\\", \\\"{x:1217,y:715,t:1528139972432};\\\", \\\"{x:1218,y:713,t:1528139972449};\\\", \\\"{x:1218,y:711,t:1528139972465};\\\", \\\"{x:1220,y:708,t:1528139972482};\\\", \\\"{x:1221,y:705,t:1528139972501};\\\", \\\"{x:1223,y:698,t:1528139972514};\\\", \\\"{x:1226,y:694,t:1528139972531};\\\", \\\"{x:1227,y:691,t:1528139972549};\\\", \\\"{x:1230,y:685,t:1528139972565};\\\", \\\"{x:1232,y:679,t:1528139972581};\\\", \\\"{x:1233,y:674,t:1528139972599};\\\", \\\"{x:1234,y:671,t:1528139972615};\\\", \\\"{x:1236,y:666,t:1528139972631};\\\", \\\"{x:1238,y:659,t:1528139972649};\\\", \\\"{x:1240,y:654,t:1528139972664};\\\", \\\"{x:1246,y:641,t:1528139972682};\\\", \\\"{x:1249,y:635,t:1528139972699};\\\", \\\"{x:1252,y:628,t:1528139972715};\\\", \\\"{x:1257,y:623,t:1528139972732};\\\", \\\"{x:1261,y:618,t:1528139972749};\\\", \\\"{x:1264,y:614,t:1528139972765};\\\", \\\"{x:1266,y:611,t:1528139972782};\\\", \\\"{x:1267,y:609,t:1528139972799};\\\", \\\"{x:1268,y:607,t:1528139972816};\\\", \\\"{x:1270,y:605,t:1528139972832};\\\", \\\"{x:1271,y:603,t:1528139972849};\\\", \\\"{x:1274,y:600,t:1528139972866};\\\", \\\"{x:1275,y:597,t:1528139972881};\\\", \\\"{x:1276,y:595,t:1528139972900};\\\", \\\"{x:1277,y:595,t:1528139972970};\\\", \\\"{x:1277,y:593,t:1528139972986};\\\", \\\"{x:1278,y:592,t:1528139972999};\\\", \\\"{x:1278,y:591,t:1528139973017};\\\", \\\"{x:1279,y:589,t:1528139973033};\\\", \\\"{x:1280,y:587,t:1528139973049};\\\", \\\"{x:1281,y:587,t:1528139973066};\\\", \\\"{x:1282,y:587,t:1528139973083};\\\", \\\"{x:1283,y:585,t:1528139973100};\\\", \\\"{x:1285,y:585,t:1528139973117};\\\", \\\"{x:1285,y:583,t:1528139973132};\\\", \\\"{x:1285,y:581,t:1528139973149};\\\", \\\"{x:1286,y:577,t:1528139973166};\\\", \\\"{x:1287,y:576,t:1528139973183};\\\", \\\"{x:1287,y:572,t:1528139973200};\\\", \\\"{x:1288,y:570,t:1528139973219};\\\", \\\"{x:1289,y:570,t:1528139973233};\\\", \\\"{x:1289,y:566,t:1528139973249};\\\", \\\"{x:1290,y:562,t:1528139973266};\\\", \\\"{x:1290,y:560,t:1528139973290};\\\", \\\"{x:1290,y:558,t:1528139973300};\\\", \\\"{x:1290,y:556,t:1528139973316};\\\", \\\"{x:1290,y:555,t:1528139973371};\\\", \\\"{x:1290,y:554,t:1528139973384};\\\", \\\"{x:1287,y:554,t:1528139974651};\\\", \\\"{x:1287,y:555,t:1528139974682};\\\", \\\"{x:1285,y:555,t:1528139974771};\\\", \\\"{x:1283,y:557,t:1528139974881};\\\", \\\"{x:1281,y:558,t:1528139975267};\\\", \\\"{x:1279,y:561,t:1528139975284};\\\", \\\"{x:1275,y:566,t:1528139975302};\\\", \\\"{x:1273,y:567,t:1528139975317};\\\", \\\"{x:1272,y:568,t:1528139975345};\\\", \\\"{x:1272,y:570,t:1528139975554};\\\", \\\"{x:1272,y:572,t:1528139975568};\\\", \\\"{x:1272,y:577,t:1528139975583};\\\", \\\"{x:1272,y:584,t:1528139975601};\\\", \\\"{x:1272,y:595,t:1528139975617};\\\", \\\"{x:1276,y:602,t:1528139975633};\\\", \\\"{x:1278,y:615,t:1528139975650};\\\", \\\"{x:1279,y:623,t:1528139975668};\\\", \\\"{x:1283,y:633,t:1528139975683};\\\", \\\"{x:1284,y:637,t:1528139975701};\\\", \\\"{x:1287,y:647,t:1528139975718};\\\", \\\"{x:1289,y:659,t:1528139975734};\\\", \\\"{x:1292,y:666,t:1528139975751};\\\", \\\"{x:1297,y:675,t:1528139975768};\\\", \\\"{x:1300,y:683,t:1528139975784};\\\", \\\"{x:1306,y:690,t:1528139975800};\\\", \\\"{x:1315,y:702,t:1528139975817};\\\", \\\"{x:1318,y:709,t:1528139975836};\\\", \\\"{x:1320,y:715,t:1528139975851};\\\", \\\"{x:1323,y:718,t:1528139975867};\\\", \\\"{x:1324,y:724,t:1528139975884};\\\", \\\"{x:1326,y:727,t:1528139975900};\\\", \\\"{x:1328,y:731,t:1528139975918};\\\", \\\"{x:1329,y:735,t:1528139975934};\\\", \\\"{x:1331,y:737,t:1528139975951};\\\", \\\"{x:1331,y:741,t:1528139975968};\\\", \\\"{x:1333,y:743,t:1528139975985};\\\", \\\"{x:1334,y:747,t:1528139976001};\\\", \\\"{x:1336,y:751,t:1528139976017};\\\", \\\"{x:1339,y:755,t:1528139976035};\\\", \\\"{x:1342,y:756,t:1528139976051};\\\", \\\"{x:1348,y:762,t:1528139976068};\\\", \\\"{x:1353,y:766,t:1528139976086};\\\", \\\"{x:1359,y:771,t:1528139976101};\\\", \\\"{x:1364,y:774,t:1528139976118};\\\", \\\"{x:1367,y:777,t:1528139976135};\\\", \\\"{x:1371,y:781,t:1528139976151};\\\", \\\"{x:1375,y:786,t:1528139976168};\\\", \\\"{x:1379,y:788,t:1528139976185};\\\", \\\"{x:1382,y:790,t:1528139976201};\\\", \\\"{x:1384,y:790,t:1528139976218};\\\", \\\"{x:1385,y:791,t:1528139976235};\\\", \\\"{x:1385,y:792,t:1528139976427};\\\", \\\"{x:1385,y:793,t:1528139976466};\\\", \\\"{x:1386,y:793,t:1528139976514};\\\", \\\"{x:1386,y:795,t:1528139976555};\\\", \\\"{x:1384,y:795,t:1528139977907};\\\", \\\"{x:1380,y:791,t:1528139977919};\\\", \\\"{x:1373,y:785,t:1528139977936};\\\", \\\"{x:1361,y:775,t:1528139977953};\\\", \\\"{x:1352,y:767,t:1528139977970};\\\", \\\"{x:1341,y:760,t:1528139977987};\\\", \\\"{x:1338,y:757,t:1528139978004};\\\", \\\"{x:1336,y:753,t:1528139978020};\\\", \\\"{x:1334,y:749,t:1528139978037};\\\", \\\"{x:1332,y:747,t:1528139978053};\\\", \\\"{x:1331,y:746,t:1528139978069};\\\", \\\"{x:1329,y:746,t:1528139978131};\\\", \\\"{x:1328,y:746,t:1528139978138};\\\", \\\"{x:1327,y:746,t:1528139978153};\\\", \\\"{x:1323,y:746,t:1528139978170};\\\", \\\"{x:1319,y:749,t:1528139978187};\\\", \\\"{x:1317,y:750,t:1528139978203};\\\", \\\"{x:1315,y:751,t:1528139978221};\\\", \\\"{x:1313,y:752,t:1528139978237};\\\", \\\"{x:1313,y:754,t:1528139978253};\\\", \\\"{x:1312,y:757,t:1528139978270};\\\", \\\"{x:1312,y:759,t:1528139978287};\\\", \\\"{x:1314,y:769,t:1528139978304};\\\", \\\"{x:1320,y:775,t:1528139978321};\\\", \\\"{x:1326,y:780,t:1528139978337};\\\", \\\"{x:1331,y:782,t:1528139978354};\\\", \\\"{x:1338,y:785,t:1528139978370};\\\", \\\"{x:1341,y:785,t:1528139978386};\\\", \\\"{x:1346,y:785,t:1528139978403};\\\", \\\"{x:1354,y:785,t:1528139978421};\\\", \\\"{x:1358,y:787,t:1528139978437};\\\", \\\"{x:1361,y:787,t:1528139978453};\\\", \\\"{x:1364,y:787,t:1528139978470};\\\", \\\"{x:1365,y:787,t:1528139978488};\\\", \\\"{x:1368,y:784,t:1528139978504};\\\", \\\"{x:1372,y:781,t:1528139978520};\\\", \\\"{x:1375,y:772,t:1528139978538};\\\", \\\"{x:1375,y:770,t:1528139978554};\\\", \\\"{x:1375,y:762,t:1528139978570};\\\", \\\"{x:1375,y:760,t:1528139978587};\\\", \\\"{x:1374,y:755,t:1528139978603};\\\", \\\"{x:1372,y:751,t:1528139978620};\\\", \\\"{x:1370,y:748,t:1528139978638};\\\", \\\"{x:1367,y:745,t:1528139978654};\\\", \\\"{x:1365,y:742,t:1528139978671};\\\", \\\"{x:1363,y:740,t:1528139978687};\\\", \\\"{x:1359,y:737,t:1528139978703};\\\", \\\"{x:1356,y:735,t:1528139978721};\\\", \\\"{x:1353,y:735,t:1528139978738};\\\", \\\"{x:1351,y:734,t:1528139978753};\\\", \\\"{x:1350,y:733,t:1528139978771};\\\", \\\"{x:1349,y:732,t:1528139978787};\\\", \\\"{x:1348,y:732,t:1528139978834};\\\", \\\"{x:1347,y:732,t:1528139978842};\\\", \\\"{x:1346,y:732,t:1528139978882};\\\", \\\"{x:1344,y:732,t:1528139978890};\\\", \\\"{x:1344,y:733,t:1528139978914};\\\", \\\"{x:1341,y:735,t:1528139978946};\\\", \\\"{x:1341,y:736,t:1528139978954};\\\", \\\"{x:1340,y:738,t:1528139978970};\\\", \\\"{x:1340,y:739,t:1528139978987};\\\", \\\"{x:1340,y:744,t:1528139979004};\\\", \\\"{x:1339,y:746,t:1528139979020};\\\", \\\"{x:1339,y:749,t:1528139979038};\\\", \\\"{x:1339,y:755,t:1528139979054};\\\", \\\"{x:1339,y:757,t:1528139979070};\\\", \\\"{x:1339,y:761,t:1528139979088};\\\", \\\"{x:1341,y:765,t:1528139979105};\\\", \\\"{x:1341,y:767,t:1528139979120};\\\", \\\"{x:1342,y:768,t:1528139979137};\\\", \\\"{x:1343,y:770,t:1528139979154};\\\", \\\"{x:1344,y:771,t:1528139979274};\\\", \\\"{x:1345,y:771,t:1528139979287};\\\", \\\"{x:1347,y:771,t:1528139979305};\\\", \\\"{x:1350,y:771,t:1528139979320};\\\", \\\"{x:1351,y:770,t:1528139979337};\\\", \\\"{x:1353,y:769,t:1528139979354};\\\", \\\"{x:1354,y:768,t:1528139979386};\\\", \\\"{x:1354,y:767,t:1528139979405};\\\", \\\"{x:1354,y:766,t:1528139979425};\\\", \\\"{x:1355,y:765,t:1528139979437};\\\", \\\"{x:1355,y:762,t:1528139979454};\\\", \\\"{x:1355,y:760,t:1528139979471};\\\", \\\"{x:1355,y:758,t:1528139979487};\\\", \\\"{x:1354,y:758,t:1528139979754};\\\", \\\"{x:1353,y:758,t:1528139979778};\\\", \\\"{x:1352,y:758,t:1528139979970};\\\", \\\"{x:1351,y:758,t:1528139980011};\\\", \\\"{x:1351,y:759,t:1528139980083};\\\", \\\"{x:1350,y:759,t:1528139980387};\\\", \\\"{x:1349,y:759,t:1528139980426};\\\", \\\"{x:1348,y:759,t:1528139980514};\\\", \\\"{x:1347,y:759,t:1528139981090};\\\", \\\"{x:1346,y:760,t:1528139981227};\\\", \\\"{x:1344,y:761,t:1528139981538};\\\", \\\"{x:1344,y:762,t:1528139981586};\\\", \\\"{x:1342,y:763,t:1528139981618};\\\", \\\"{x:1342,y:764,t:1528139981626};\\\", \\\"{x:1341,y:764,t:1528139981640};\\\", \\\"{x:1340,y:766,t:1528139981657};\\\", \\\"{x:1339,y:767,t:1528139981672};\\\", \\\"{x:1338,y:769,t:1528139981690};\\\", \\\"{x:1335,y:771,t:1528139981706};\\\", \\\"{x:1331,y:775,t:1528139981722};\\\", \\\"{x:1330,y:776,t:1528139981740};\\\", \\\"{x:1326,y:779,t:1528139981756};\\\", \\\"{x:1324,y:780,t:1528139981772};\\\", \\\"{x:1320,y:782,t:1528139981790};\\\", \\\"{x:1319,y:784,t:1528139981806};\\\", \\\"{x:1316,y:786,t:1528139981822};\\\", \\\"{x:1313,y:790,t:1528139981839};\\\", \\\"{x:1310,y:794,t:1528139981856};\\\", \\\"{x:1305,y:798,t:1528139981873};\\\", \\\"{x:1301,y:804,t:1528139981890};\\\", \\\"{x:1297,y:811,t:1528139981906};\\\", \\\"{x:1294,y:814,t:1528139981924};\\\", \\\"{x:1291,y:819,t:1528139981939};\\\", \\\"{x:1289,y:823,t:1528139981956};\\\", \\\"{x:1287,y:826,t:1528139981973};\\\", \\\"{x:1286,y:831,t:1528139981990};\\\", \\\"{x:1285,y:834,t:1528139982007};\\\", \\\"{x:1283,y:839,t:1528139982023};\\\", \\\"{x:1282,y:841,t:1528139982039};\\\", \\\"{x:1280,y:845,t:1528139982056};\\\", \\\"{x:1275,y:854,t:1528139982073};\\\", \\\"{x:1274,y:858,t:1528139982089};\\\", \\\"{x:1270,y:872,t:1528139982106};\\\", \\\"{x:1267,y:876,t:1528139982124};\\\", \\\"{x:1266,y:883,t:1528139982140};\\\", \\\"{x:1265,y:887,t:1528139982156};\\\", \\\"{x:1263,y:890,t:1528139982173};\\\", \\\"{x:1263,y:893,t:1528139982190};\\\", \\\"{x:1262,y:897,t:1528139982207};\\\", \\\"{x:1259,y:902,t:1528139982224};\\\", \\\"{x:1257,y:908,t:1528139982239};\\\", \\\"{x:1254,y:914,t:1528139982256};\\\", \\\"{x:1252,y:920,t:1528139982274};\\\", \\\"{x:1250,y:923,t:1528139982290};\\\", \\\"{x:1248,y:930,t:1528139982307};\\\", \\\"{x:1245,y:932,t:1528139982323};\\\", \\\"{x:1242,y:936,t:1528139982341};\\\", \\\"{x:1239,y:943,t:1528139982356};\\\", \\\"{x:1234,y:952,t:1528139982374};\\\", \\\"{x:1231,y:960,t:1528139982391};\\\", \\\"{x:1231,y:964,t:1528139982407};\\\", \\\"{x:1230,y:966,t:1528139982423};\\\", \\\"{x:1229,y:968,t:1528139982440};\\\", \\\"{x:1229,y:969,t:1528139982458};\\\", \\\"{x:1228,y:970,t:1528139982473};\\\", \\\"{x:1228,y:973,t:1528139982490};\\\", \\\"{x:1228,y:975,t:1528139982506};\\\", \\\"{x:1229,y:978,t:1528139982538};\\\", \\\"{x:1230,y:978,t:1528139982546};\\\", \\\"{x:1232,y:978,t:1528139982586};\\\", \\\"{x:1233,y:978,t:1528139982594};\\\", \\\"{x:1238,y:978,t:1528139982607};\\\", \\\"{x:1247,y:978,t:1528139982624};\\\", \\\"{x:1255,y:978,t:1528139982640};\\\", \\\"{x:1256,y:978,t:1528139982656};\\\", \\\"{x:1260,y:977,t:1528139982673};\\\", \\\"{x:1261,y:974,t:1528139982690};\\\", \\\"{x:1261,y:973,t:1528139982818};\\\", \\\"{x:1261,y:972,t:1528139982826};\\\", \\\"{x:1261,y:971,t:1528139982842};\\\", \\\"{x:1259,y:971,t:1528139982858};\\\", \\\"{x:1259,y:970,t:1528139982874};\\\", \\\"{x:1257,y:970,t:1528139982891};\\\", \\\"{x:1255,y:969,t:1528139982908};\\\", \\\"{x:1254,y:968,t:1528139982923};\\\", \\\"{x:1252,y:967,t:1528139982941};\\\", \\\"{x:1252,y:964,t:1528139982958};\\\", \\\"{x:1253,y:955,t:1528139982974};\\\", \\\"{x:1258,y:940,t:1528139982991};\\\", \\\"{x:1259,y:921,t:1528139983008};\\\", \\\"{x:1262,y:908,t:1528139983024};\\\", \\\"{x:1268,y:892,t:1528139983041};\\\", \\\"{x:1268,y:891,t:1528139983057};\\\", \\\"{x:1268,y:889,t:1528139983074};\\\", \\\"{x:1268,y:885,t:1528139983090};\\\", \\\"{x:1273,y:879,t:1528139983108};\\\", \\\"{x:1275,y:875,t:1528139983124};\\\", \\\"{x:1279,y:872,t:1528139983154};\\\", \\\"{x:1281,y:871,t:1528139983162};\\\", \\\"{x:1283,y:868,t:1528139983173};\\\", \\\"{x:1285,y:865,t:1528139983191};\\\", \\\"{x:1287,y:863,t:1528139983207};\\\", \\\"{x:1293,y:857,t:1528139983224};\\\", \\\"{x:1303,y:844,t:1528139983240};\\\", \\\"{x:1313,y:827,t:1528139983258};\\\", \\\"{x:1318,y:817,t:1528139983274};\\\", \\\"{x:1320,y:813,t:1528139983291};\\\", \\\"{x:1325,y:805,t:1528139983308};\\\", \\\"{x:1332,y:794,t:1528139983324};\\\", \\\"{x:1336,y:786,t:1528139983340};\\\", \\\"{x:1341,y:776,t:1528139983358};\\\", \\\"{x:1343,y:768,t:1528139983374};\\\", \\\"{x:1344,y:764,t:1528139983391};\\\", \\\"{x:1344,y:763,t:1528139983425};\\\", \\\"{x:1345,y:762,t:1528139983440};\\\", \\\"{x:1345,y:761,t:1528139983458};\\\", \\\"{x:1346,y:762,t:1528139983730};\\\", \\\"{x:1346,y:764,t:1528139983741};\\\", \\\"{x:1348,y:769,t:1528139983759};\\\", \\\"{x:1349,y:771,t:1528139983775};\\\", \\\"{x:1350,y:774,t:1528139983792};\\\", \\\"{x:1353,y:779,t:1528139983807};\\\", \\\"{x:1355,y:783,t:1528139983824};\\\", \\\"{x:1358,y:787,t:1528139983842};\\\", \\\"{x:1359,y:789,t:1528139983858};\\\", \\\"{x:1360,y:791,t:1528139983875};\\\", \\\"{x:1361,y:791,t:1528139983930};\\\", \\\"{x:1363,y:794,t:1528139983941};\\\", \\\"{x:1363,y:796,t:1528139983958};\\\", \\\"{x:1367,y:801,t:1528139983975};\\\", \\\"{x:1367,y:804,t:1528139983991};\\\", \\\"{x:1368,y:808,t:1528139984008};\\\", \\\"{x:1370,y:813,t:1528139984025};\\\", \\\"{x:1372,y:815,t:1528139984041};\\\", \\\"{x:1374,y:818,t:1528139984058};\\\", \\\"{x:1374,y:819,t:1528139984082};\\\", \\\"{x:1374,y:821,t:1528139984091};\\\", \\\"{x:1374,y:825,t:1528139984107};\\\", \\\"{x:1377,y:830,t:1528139984124};\\\", \\\"{x:1378,y:832,t:1528139984142};\\\", \\\"{x:1378,y:833,t:1528139984158};\\\", \\\"{x:1379,y:834,t:1528139984175};\\\", \\\"{x:1381,y:838,t:1528139984192};\\\", \\\"{x:1381,y:840,t:1528139984210};\\\", \\\"{x:1383,y:842,t:1528139984225};\\\", \\\"{x:1386,y:847,t:1528139984241};\\\", \\\"{x:1390,y:852,t:1528139984258};\\\", \\\"{x:1390,y:853,t:1528139984274};\\\", \\\"{x:1392,y:855,t:1528139984292};\\\", \\\"{x:1393,y:858,t:1528139984307};\\\", \\\"{x:1395,y:861,t:1528139984324};\\\", \\\"{x:1396,y:862,t:1528139984340};\\\", \\\"{x:1397,y:864,t:1528139984358};\\\", \\\"{x:1399,y:866,t:1528139984374};\\\", \\\"{x:1399,y:867,t:1528139984393};\\\", \\\"{x:1400,y:868,t:1528139984408};\\\", \\\"{x:1401,y:870,t:1528139984423};\\\", \\\"{x:1403,y:873,t:1528139984441};\\\", \\\"{x:1404,y:874,t:1528139984457};\\\", \\\"{x:1405,y:877,t:1528139984474};\\\", \\\"{x:1407,y:880,t:1528139984491};\\\", \\\"{x:1409,y:882,t:1528139984508};\\\", \\\"{x:1409,y:883,t:1528139984524};\\\", \\\"{x:1410,y:884,t:1528139984542};\\\", \\\"{x:1411,y:886,t:1528139984558};\\\", \\\"{x:1412,y:888,t:1528139984576};\\\", \\\"{x:1413,y:890,t:1528139984592};\\\", \\\"{x:1414,y:891,t:1528139984609};\\\", \\\"{x:1414,y:893,t:1528139984626};\\\", \\\"{x:1416,y:895,t:1528139984641};\\\", \\\"{x:1418,y:898,t:1528139984658};\\\", \\\"{x:1418,y:900,t:1528139984676};\\\", \\\"{x:1420,y:902,t:1528139984691};\\\", \\\"{x:1422,y:904,t:1528139984709};\\\", \\\"{x:1423,y:905,t:1528139984725};\\\", \\\"{x:1424,y:906,t:1528139984742};\\\", \\\"{x:1424,y:907,t:1528139984762};\\\", \\\"{x:1425,y:908,t:1528139984776};\\\", \\\"{x:1426,y:910,t:1528139984792};\\\", \\\"{x:1427,y:912,t:1528139984809};\\\", \\\"{x:1428,y:915,t:1528139984826};\\\", \\\"{x:1430,y:917,t:1528139984841};\\\", \\\"{x:1431,y:919,t:1528139984866};\\\", \\\"{x:1432,y:921,t:1528139984875};\\\", \\\"{x:1432,y:922,t:1528139984892};\\\", \\\"{x:1433,y:923,t:1528139984908};\\\", \\\"{x:1433,y:924,t:1528139985002};\\\", \\\"{x:1434,y:924,t:1528139985018};\\\", \\\"{x:1435,y:926,t:1528139985034};\\\", \\\"{x:1436,y:927,t:1528139985050};\\\", \\\"{x:1437,y:929,t:1528139985066};\\\", \\\"{x:1438,y:931,t:1528139985082};\\\", \\\"{x:1440,y:933,t:1528139985093};\\\", \\\"{x:1442,y:935,t:1528139985108};\\\", \\\"{x:1443,y:937,t:1528139985126};\\\", \\\"{x:1446,y:941,t:1528139985143};\\\", \\\"{x:1448,y:943,t:1528139985162};\\\", \\\"{x:1448,y:944,t:1528139985175};\\\", \\\"{x:1449,y:945,t:1528139985192};\\\", \\\"{x:1450,y:946,t:1528139985209};\\\", \\\"{x:1451,y:948,t:1528139985250};\\\", \\\"{x:1451,y:949,t:1528139985282};\\\", \\\"{x:1452,y:949,t:1528139985293};\\\", \\\"{x:1452,y:950,t:1528139985308};\\\", \\\"{x:1453,y:951,t:1528139985337};\\\", \\\"{x:1453,y:952,t:1528139985352};\\\", \\\"{x:1454,y:953,t:1528139985361};\\\", \\\"{x:1454,y:954,t:1528139985375};\\\", \\\"{x:1456,y:956,t:1528139985392};\\\", \\\"{x:1456,y:959,t:1528139985409};\\\", \\\"{x:1457,y:960,t:1528139985425};\\\", \\\"{x:1458,y:961,t:1528139985442};\\\", \\\"{x:1459,y:962,t:1528139985459};\\\", \\\"{x:1460,y:963,t:1528139985521};\\\", \\\"{x:1459,y:963,t:1528139986066};\\\", \\\"{x:1457,y:963,t:1528139986077};\\\", \\\"{x:1456,y:963,t:1528139986093};\\\", \\\"{x:1454,y:963,t:1528139986114};\\\", \\\"{x:1453,y:962,t:1528139986127};\\\", \\\"{x:1452,y:962,t:1528139986143};\\\", \\\"{x:1452,y:961,t:1528139986159};\\\", \\\"{x:1450,y:961,t:1528139986234};\\\", \\\"{x:1449,y:961,t:1528139986250};\\\", \\\"{x:1449,y:960,t:1528139986266};\\\", \\\"{x:1449,y:959,t:1528139986674};\\\", \\\"{x:1448,y:958,t:1528139986842};\\\", \\\"{x:1447,y:958,t:1528139986914};\\\", \\\"{x:1446,y:958,t:1528139986930};\\\", \\\"{x:1444,y:958,t:1528139986969};\\\", \\\"{x:1443,y:958,t:1528139987042};\\\", \\\"{x:1442,y:958,t:1528139987060};\\\", \\\"{x:1438,y:956,t:1528139987077};\\\", \\\"{x:1437,y:956,t:1528139987093};\\\", \\\"{x:1436,y:956,t:1528139987242};\\\", \\\"{x:1435,y:955,t:1528139987378};\\\", \\\"{x:1436,y:955,t:1528139987442};\\\", \\\"{x:1438,y:955,t:1528139987466};\\\", \\\"{x:1439,y:955,t:1528139987478};\\\", \\\"{x:1440,y:955,t:1528139987506};\\\", \\\"{x:1441,y:955,t:1528139987514};\\\", \\\"{x:1442,y:955,t:1528139987562};\\\", \\\"{x:1443,y:955,t:1528139987586};\\\", \\\"{x:1444,y:955,t:1528139987594};\\\", \\\"{x:1445,y:955,t:1528139987642};\\\", \\\"{x:1446,y:955,t:1528139987666};\\\", \\\"{x:1447,y:956,t:1528139987682};\\\", \\\"{x:1448,y:956,t:1528139988146};\\\", \\\"{x:1449,y:956,t:1528139988426};\\\", \\\"{x:1451,y:955,t:1528139988490};\\\", \\\"{x:1452,y:955,t:1528139988546};\\\", \\\"{x:1453,y:954,t:1528139988770};\\\", \\\"{x:1454,y:953,t:1528139988786};\\\", \\\"{x:1454,y:952,t:1528139988882};\\\", \\\"{x:1455,y:952,t:1528139989098};\\\", \\\"{x:1457,y:950,t:1528139989114};\\\", \\\"{x:1457,y:949,t:1528139989128};\\\", \\\"{x:1458,y:947,t:1528139989146};\\\", \\\"{x:1458,y:945,t:1528139989162};\\\", \\\"{x:1458,y:944,t:1528139989179};\\\", \\\"{x:1458,y:942,t:1528139989201};\\\", \\\"{x:1458,y:940,t:1528139989217};\\\", \\\"{x:1456,y:936,t:1528139989229};\\\", \\\"{x:1446,y:918,t:1528139989246};\\\", \\\"{x:1438,y:907,t:1528139989262};\\\", \\\"{x:1436,y:903,t:1528139989279};\\\", \\\"{x:1434,y:900,t:1528139989296};\\\", \\\"{x:1433,y:899,t:1528139989314};\\\", \\\"{x:1432,y:897,t:1528139989394};\\\", \\\"{x:1424,y:889,t:1528139989413};\\\", \\\"{x:1417,y:879,t:1528139989429};\\\", \\\"{x:1409,y:868,t:1528139989446};\\\", \\\"{x:1396,y:854,t:1528139989463};\\\", \\\"{x:1382,y:836,t:1528139989479};\\\", \\\"{x:1373,y:820,t:1528139989496};\\\", \\\"{x:1364,y:806,t:1528139989512};\\\", \\\"{x:1352,y:795,t:1528139989529};\\\", \\\"{x:1340,y:776,t:1528139989545};\\\", \\\"{x:1336,y:767,t:1528139989562};\\\", \\\"{x:1330,y:755,t:1528139989579};\\\", \\\"{x:1323,y:743,t:1528139989596};\\\", \\\"{x:1321,y:735,t:1528139989612};\\\", \\\"{x:1315,y:727,t:1528139989629};\\\", \\\"{x:1313,y:723,t:1528139989645};\\\", \\\"{x:1312,y:722,t:1528139989663};\\\", \\\"{x:1312,y:721,t:1528139989698};\\\", \\\"{x:1312,y:719,t:1528139989713};\\\", \\\"{x:1315,y:716,t:1528139989729};\\\", \\\"{x:1321,y:709,t:1528139989746};\\\", \\\"{x:1326,y:701,t:1528139989763};\\\", \\\"{x:1326,y:700,t:1528139989802};\\\", \\\"{x:1328,y:699,t:1528139989818};\\\", \\\"{x:1329,y:698,t:1528139989834};\\\", \\\"{x:1330,y:698,t:1528139989970};\\\", \\\"{x:1330,y:699,t:1528139989980};\\\", \\\"{x:1330,y:701,t:1528139989996};\\\", \\\"{x:1330,y:702,t:1528139990012};\\\", \\\"{x:1331,y:703,t:1528139990547};\\\", \\\"{x:1341,y:706,t:1528139990562};\\\", \\\"{x:1349,y:707,t:1528139990580};\\\", \\\"{x:1353,y:707,t:1528139990597};\\\", \\\"{x:1357,y:707,t:1528139990614};\\\", \\\"{x:1361,y:706,t:1528139990630};\\\", \\\"{x:1358,y:706,t:1528139990770};\\\", \\\"{x:1354,y:706,t:1528139990780};\\\", \\\"{x:1351,y:706,t:1528139990797};\\\", \\\"{x:1350,y:706,t:1528139990814};\\\", \\\"{x:1347,y:705,t:1528139990830};\\\", \\\"{x:1345,y:704,t:1528139990846};\\\", \\\"{x:1341,y:698,t:1528139990864};\\\", \\\"{x:1336,y:692,t:1528139990880};\\\", \\\"{x:1325,y:683,t:1528139990897};\\\", \\\"{x:1314,y:672,t:1528139990914};\\\", \\\"{x:1305,y:665,t:1528139990930};\\\", \\\"{x:1303,y:661,t:1528139990946};\\\", \\\"{x:1302,y:660,t:1528139990994};\\\", \\\"{x:1303,y:660,t:1528139991058};\\\", \\\"{x:1306,y:662,t:1528139991065};\\\", \\\"{x:1309,y:664,t:1528139991081};\\\", \\\"{x:1314,y:666,t:1528139991097};\\\", \\\"{x:1322,y:669,t:1528139991114};\\\", \\\"{x:1329,y:670,t:1528139991130};\\\", \\\"{x:1334,y:671,t:1528139991147};\\\", \\\"{x:1343,y:671,t:1528139991164};\\\", \\\"{x:1345,y:671,t:1528139991181};\\\", \\\"{x:1348,y:671,t:1528139991197};\\\", \\\"{x:1350,y:671,t:1528139991218};\\\", \\\"{x:1350,y:670,t:1528139991231};\\\", \\\"{x:1350,y:669,t:1528139991247};\\\", \\\"{x:1350,y:667,t:1528139991264};\\\", \\\"{x:1348,y:666,t:1528139991281};\\\", \\\"{x:1345,y:666,t:1528139991297};\\\", \\\"{x:1343,y:666,t:1528139991314};\\\", \\\"{x:1341,y:666,t:1528139991331};\\\", \\\"{x:1340,y:666,t:1528139991347};\\\", \\\"{x:1339,y:666,t:1528139991363};\\\", \\\"{x:1337,y:666,t:1528139991427};\\\", \\\"{x:1336,y:666,t:1528139991442};\\\", \\\"{x:1335,y:667,t:1528139991450};\\\", \\\"{x:1335,y:669,t:1528139991464};\\\", \\\"{x:1332,y:674,t:1528139991481};\\\", \\\"{x:1332,y:678,t:1528139991499};\\\", \\\"{x:1332,y:681,t:1528139991513};\\\", \\\"{x:1332,y:682,t:1528139991529};\\\", \\\"{x:1332,y:684,t:1528139991547};\\\", \\\"{x:1332,y:685,t:1528139991754};\\\", \\\"{x:1335,y:685,t:1528139991898};\\\", \\\"{x:1337,y:685,t:1528139991913};\\\", \\\"{x:1338,y:685,t:1528139991946};\\\", \\\"{x:1338,y:687,t:1528139992634};\\\", \\\"{x:1338,y:688,t:1528139992648};\\\", \\\"{x:1338,y:692,t:1528139992664};\\\", \\\"{x:1341,y:699,t:1528139992681};\\\", \\\"{x:1342,y:701,t:1528139992698};\\\", \\\"{x:1344,y:704,t:1528139992713};\\\", \\\"{x:1346,y:707,t:1528139992731};\\\", \\\"{x:1347,y:708,t:1528139992753};\\\", \\\"{x:1347,y:709,t:1528139992785};\\\", \\\"{x:1347,y:708,t:1528139992961};\\\", \\\"{x:1348,y:707,t:1528139992969};\\\", \\\"{x:1349,y:704,t:1528139992981};\\\", \\\"{x:1349,y:701,t:1528139992998};\\\", \\\"{x:1349,y:698,t:1528139993014};\\\", \\\"{x:1349,y:697,t:1528139993970};\\\", \\\"{x:1348,y:692,t:1528139994193};\\\", \\\"{x:1341,y:683,t:1528139994203};\\\", \\\"{x:1333,y:676,t:1528139994216};\\\", \\\"{x:1319,y:659,t:1528139994233};\\\", \\\"{x:1301,y:641,t:1528139994249};\\\", \\\"{x:1297,y:636,t:1528139994266};\\\", \\\"{x:1295,y:633,t:1528139994282};\\\", \\\"{x:1295,y:632,t:1528139994300};\\\", \\\"{x:1294,y:631,t:1528139994316};\\\", \\\"{x:1294,y:630,t:1528139994345};\\\", \\\"{x:1294,y:628,t:1528139994402};\\\", \\\"{x:1294,y:626,t:1528139994415};\\\", \\\"{x:1292,y:623,t:1528139994433};\\\", \\\"{x:1290,y:617,t:1528139994449};\\\", \\\"{x:1288,y:611,t:1528139994465};\\\", \\\"{x:1281,y:600,t:1528139994482};\\\", \\\"{x:1274,y:588,t:1528139994499};\\\", \\\"{x:1267,y:578,t:1528139994516};\\\", \\\"{x:1265,y:571,t:1528139994532};\\\", \\\"{x:1261,y:568,t:1528139994550};\\\", \\\"{x:1259,y:568,t:1528139994570};\\\", \\\"{x:1261,y:567,t:1528139994635};\\\", \\\"{x:1263,y:566,t:1528139994650};\\\", \\\"{x:1264,y:565,t:1528139994666};\\\", \\\"{x:1266,y:565,t:1528139994722};\\\", \\\"{x:1268,y:565,t:1528139994733};\\\", \\\"{x:1270,y:565,t:1528139994750};\\\", \\\"{x:1271,y:565,t:1528139994767};\\\", \\\"{x:1272,y:565,t:1528139994782};\\\", \\\"{x:1273,y:566,t:1528139994800};\\\", \\\"{x:1275,y:566,t:1528139994816};\\\", \\\"{x:1276,y:566,t:1528139994834};\\\", \\\"{x:1261,y:572,t:1528139995123};\\\", \\\"{x:1171,y:585,t:1528139995134};\\\", \\\"{x:910,y:650,t:1528139995150};\\\", \\\"{x:753,y:678,t:1528139995167};\\\", \\\"{x:752,y:683,t:1528139995184};\\\", \\\"{x:752,y:682,t:1528139995199};\\\", \\\"{x:746,y:675,t:1528139995217};\\\", \\\"{x:759,y:670,t:1528139995290};\\\", \\\"{x:774,y:664,t:1528139995300};\\\", \\\"{x:794,y:655,t:1528139995316};\\\", \\\"{x:809,y:646,t:1528139995334};\\\", \\\"{x:817,y:636,t:1528139995349};\\\", \\\"{x:817,y:625,t:1528139995367};\\\", \\\"{x:814,y:614,t:1528139995383};\\\", \\\"{x:802,y:603,t:1528139995400};\\\", \\\"{x:781,y:594,t:1528139995417};\\\", \\\"{x:750,y:586,t:1528139995434};\\\", \\\"{x:726,y:584,t:1528139995450};\\\", \\\"{x:720,y:581,t:1528139995468};\\\", \\\"{x:719,y:581,t:1528139995497};\\\", \\\"{x:719,y:580,t:1528139995504};\\\", \\\"{x:721,y:577,t:1528139995517};\\\", \\\"{x:736,y:572,t:1528139995533};\\\", \\\"{x:752,y:567,t:1528139995550};\\\", \\\"{x:764,y:561,t:1528139995567};\\\", \\\"{x:779,y:551,t:1528139995583};\\\", \\\"{x:788,y:543,t:1528139995600};\\\", \\\"{x:801,y:532,t:1528139995617};\\\", \\\"{x:803,y:526,t:1528139995633};\\\", \\\"{x:804,y:524,t:1528139995651};\\\", \\\"{x:804,y:519,t:1528139995668};\\\", \\\"{x:804,y:516,t:1528139995684};\\\", \\\"{x:803,y:514,t:1528139995700};\\\", \\\"{x:795,y:511,t:1528139995718};\\\", \\\"{x:778,y:508,t:1528139995734};\\\", \\\"{x:755,y:504,t:1528139995750};\\\", \\\"{x:724,y:499,t:1528139995767};\\\", \\\"{x:693,y:486,t:1528139995785};\\\", \\\"{x:661,y:480,t:1528139995800};\\\", \\\"{x:641,y:471,t:1528139995817};\\\", \\\"{x:638,y:471,t:1528139995834};\\\", \\\"{x:636,y:471,t:1528139995850};\\\", \\\"{x:634,y:471,t:1528139995921};\\\", \\\"{x:633,y:471,t:1528139995934};\\\", \\\"{x:630,y:471,t:1528139995950};\\\", \\\"{x:618,y:478,t:1528139995968};\\\", \\\"{x:614,y:481,t:1528139995984};\\\", \\\"{x:611,y:484,t:1528139996000};\\\", \\\"{x:611,y:486,t:1528139996017};\\\", \\\"{x:611,y:489,t:1528139996036};\\\", \\\"{x:611,y:492,t:1528139996051};\\\", \\\"{x:611,y:494,t:1528139996067};\\\", \\\"{x:611,y:496,t:1528139996084};\\\", \\\"{x:611,y:497,t:1528139996385};\\\", \\\"{x:611,y:500,t:1528139996399};\\\", \\\"{x:600,y:526,t:1528139996418};\\\", \\\"{x:588,y:546,t:1528139996434};\\\", \\\"{x:569,y:586,t:1528139996451};\\\", \\\"{x:560,y:620,t:1528139996468};\\\", \\\"{x:551,y:637,t:1528139996484};\\\", \\\"{x:548,y:653,t:1528139996501};\\\", \\\"{x:543,y:662,t:1528139996517};\\\", \\\"{x:543,y:670,t:1528139996534};\\\", \\\"{x:538,y:685,t:1528139996551};\\\", \\\"{x:536,y:700,t:1528139996567};\\\", \\\"{x:533,y:712,t:1528139996585};\\\", \\\"{x:531,y:720,t:1528139996601};\\\", \\\"{x:531,y:722,t:1528139996617};\\\", \\\"{x:530,y:727,t:1528139996634};\\\", \\\"{x:530,y:728,t:1528139997041};\\\", \\\"{x:532,y:731,t:1528139997105};\\\", \\\"{x:546,y:732,t:1528139997118};\\\", \\\"{x:555,y:734,t:1528139997134};\\\", \\\"{x:568,y:741,t:1528139997151};\\\", \\\"{x:586,y:751,t:1528139997168};\\\", \\\"{x:611,y:769,t:1528139997185};\\\", \\\"{x:626,y:777,t:1528139997201};\\\", \\\"{x:643,y:786,t:1528139997219};\\\", \\\"{x:653,y:796,t:1528139997236};\\\", \\\"{x:666,y:807,t:1528139997251};\\\", \\\"{x:679,y:818,t:1528139997269};\\\", \\\"{x:694,y:829,t:1528139997285};\\\", \\\"{x:713,y:839,t:1528139997301};\\\", \\\"{x:728,y:843,t:1528139997318};\\\", \\\"{x:740,y:845,t:1528139997335};\\\", \\\"{x:748,y:846,t:1528139997352};\\\", \\\"{x:758,y:846,t:1528139997368};\\\", \\\"{x:774,y:842,t:1528139997385};\\\", \\\"{x:788,y:836,t:1528139997401};\\\", \\\"{x:800,y:827,t:1528139997418};\\\", \\\"{x:814,y:817,t:1528139997436};\\\", \\\"{x:830,y:810,t:1528139997452};\\\", \\\"{x:841,y:805,t:1528139997468};\\\", \\\"{x:849,y:800,t:1528139997486};\\\", \\\"{x:852,y:798,t:1528139997501};\\\", \\\"{x:853,y:798,t:1528139997518};\\\", \\\"{x:854,y:797,t:1528139997537};\\\" ] }, { \\\"rt\\\": 9739, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 842288, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:852,y:797,t:1528139998929};\\\", \\\"{x:845,y:794,t:1528139998937};\\\", \\\"{x:828,y:792,t:1528139998953};\\\", \\\"{x:807,y:788,t:1528139998970};\\\", \\\"{x:787,y:779,t:1528139998987};\\\", \\\"{x:761,y:772,t:1528139999004};\\\", \\\"{x:737,y:762,t:1528139999019};\\\", \\\"{x:711,y:752,t:1528139999037};\\\", \\\"{x:695,y:748,t:1528139999054};\\\", \\\"{x:686,y:744,t:1528139999069};\\\", \\\"{x:678,y:742,t:1528139999087};\\\", \\\"{x:677,y:740,t:1528139999104};\\\", \\\"{x:676,y:740,t:1528139999119};\\\", \\\"{x:676,y:739,t:1528139999890};\\\", \\\"{x:676,y:738,t:1528139999914};\\\", \\\"{x:676,y:737,t:1528139999962};\\\", \\\"{x:676,y:736,t:1528139999970};\\\", \\\"{x:676,y:735,t:1528139999994};\\\", \\\"{x:676,y:734,t:1528140001969};\\\", \\\"{x:677,y:733,t:1528140001977};\\\", \\\"{x:684,y:729,t:1528140001989};\\\", \\\"{x:699,y:722,t:1528140002005};\\\", \\\"{x:719,y:715,t:1528140002022};\\\", \\\"{x:733,y:713,t:1528140002039};\\\", \\\"{x:742,y:710,t:1528140002056};\\\", \\\"{x:752,y:709,t:1528140002072};\\\", \\\"{x:779,y:717,t:1528140002089};\\\", \\\"{x:823,y:733,t:1528140002105};\\\", \\\"{x:854,y:747,t:1528140002122};\\\", \\\"{x:876,y:757,t:1528140002139};\\\", \\\"{x:903,y:767,t:1528140002156};\\\", \\\"{x:938,y:779,t:1528140002173};\\\", \\\"{x:952,y:784,t:1528140002189};\\\", \\\"{x:965,y:784,t:1528140002206};\\\", \\\"{x:972,y:785,t:1528140002223};\\\", \\\"{x:973,y:786,t:1528140002239};\\\", \\\"{x:975,y:786,t:1528140002256};\\\", \\\"{x:997,y:786,t:1528140002274};\\\", \\\"{x:1065,y:777,t:1528140002290};\\\", \\\"{x:1160,y:762,t:1528140002305};\\\", \\\"{x:1230,y:749,t:1528140002324};\\\", \\\"{x:1275,y:735,t:1528140002339};\\\", \\\"{x:1290,y:723,t:1528140002356};\\\", \\\"{x:1309,y:709,t:1528140002373};\\\", \\\"{x:1335,y:693,t:1528140002389};\\\", \\\"{x:1368,y:670,t:1528140002406};\\\", \\\"{x:1390,y:657,t:1528140002423};\\\", \\\"{x:1403,y:652,t:1528140002439};\\\", \\\"{x:1407,y:651,t:1528140002456};\\\", \\\"{x:1408,y:651,t:1528140002474};\\\", \\\"{x:1408,y:652,t:1528140002490};\\\", \\\"{x:1405,y:667,t:1528140002506};\\\", \\\"{x:1389,y:683,t:1528140002523};\\\", \\\"{x:1370,y:700,t:1528140002540};\\\", \\\"{x:1352,y:717,t:1528140002556};\\\", \\\"{x:1339,y:730,t:1528140002573};\\\", \\\"{x:1331,y:745,t:1528140002589};\\\", \\\"{x:1327,y:752,t:1528140002606};\\\", \\\"{x:1327,y:750,t:1528140002722};\\\", \\\"{x:1328,y:747,t:1528140002741};\\\", \\\"{x:1329,y:746,t:1528140002756};\\\", \\\"{x:1330,y:743,t:1528140002773};\\\", \\\"{x:1331,y:742,t:1528140002790};\\\", \\\"{x:1333,y:741,t:1528140002806};\\\", \\\"{x:1336,y:739,t:1528140002823};\\\", \\\"{x:1338,y:737,t:1528140002840};\\\", \\\"{x:1340,y:735,t:1528140002856};\\\", \\\"{x:1343,y:731,t:1528140002873};\\\", \\\"{x:1345,y:727,t:1528140002889};\\\", \\\"{x:1346,y:727,t:1528140002921};\\\", \\\"{x:1346,y:726,t:1528140002985};\\\", \\\"{x:1346,y:725,t:1528140002993};\\\", \\\"{x:1346,y:723,t:1528140003006};\\\", \\\"{x:1347,y:719,t:1528140003023};\\\", \\\"{x:1347,y:717,t:1528140003040};\\\", \\\"{x:1347,y:715,t:1528140003056};\\\", \\\"{x:1346,y:713,t:1528140003082};\\\", \\\"{x:1346,y:712,t:1528140003098};\\\", \\\"{x:1346,y:709,t:1528140003106};\\\", \\\"{x:1346,y:706,t:1528140003123};\\\", \\\"{x:1346,y:702,t:1528140003143};\\\", \\\"{x:1345,y:700,t:1528140003156};\\\", \\\"{x:1345,y:699,t:1528140003172};\\\", \\\"{x:1339,y:699,t:1528140005771};\\\", \\\"{x:1306,y:701,t:1528140005776};\\\", \\\"{x:1258,y:701,t:1528140005792};\\\", \\\"{x:1166,y:703,t:1528140005807};\\\", \\\"{x:981,y:703,t:1528140005824};\\\", \\\"{x:849,y:693,t:1528140005841};\\\", \\\"{x:746,y:666,t:1528140005858};\\\", \\\"{x:639,y:638,t:1528140005875};\\\", \\\"{x:536,y:607,t:1528140005892};\\\", \\\"{x:477,y:581,t:1528140005909};\\\", \\\"{x:429,y:571,t:1528140005924};\\\", \\\"{x:403,y:560,t:1528140005941};\\\", \\\"{x:393,y:557,t:1528140005958};\\\", \\\"{x:391,y:557,t:1528140005976};\\\", \\\"{x:390,y:559,t:1528140005992};\\\", \\\"{x:390,y:562,t:1528140006008};\\\", \\\"{x:390,y:567,t:1528140006026};\\\", \\\"{x:391,y:571,t:1528140006041};\\\", \\\"{x:394,y:573,t:1528140006059};\\\", \\\"{x:397,y:574,t:1528140006075};\\\", \\\"{x:401,y:575,t:1528140006092};\\\", \\\"{x:404,y:576,t:1528140006108};\\\", \\\"{x:405,y:576,t:1528140006125};\\\", \\\"{x:408,y:576,t:1528140006143};\\\", \\\"{x:410,y:576,t:1528140006158};\\\", \\\"{x:417,y:577,t:1528140006176};\\\", \\\"{x:431,y:583,t:1528140006193};\\\", \\\"{x:442,y:583,t:1528140006208};\\\", \\\"{x:455,y:582,t:1528140006226};\\\", \\\"{x:470,y:576,t:1528140006243};\\\", \\\"{x:486,y:572,t:1528140006260};\\\", \\\"{x:499,y:570,t:1528140006277};\\\", \\\"{x:504,y:569,t:1528140006293};\\\", \\\"{x:508,y:566,t:1528140006313};\\\", \\\"{x:515,y:563,t:1528140006330};\\\", \\\"{x:523,y:559,t:1528140006347};\\\", \\\"{x:528,y:556,t:1528140006363};\\\", \\\"{x:533,y:551,t:1528140006380};\\\", \\\"{x:535,y:548,t:1528140006397};\\\", \\\"{x:535,y:547,t:1528140006413};\\\", \\\"{x:536,y:547,t:1528140006437};\\\", \\\"{x:538,y:545,t:1528140006453};\\\", \\\"{x:539,y:544,t:1528140006463};\\\", \\\"{x:542,y:540,t:1528140006480};\\\", \\\"{x:547,y:535,t:1528140006497};\\\", \\\"{x:551,y:531,t:1528140006513};\\\", \\\"{x:555,y:528,t:1528140006530};\\\", \\\"{x:556,y:527,t:1528140006547};\\\", \\\"{x:557,y:526,t:1528140006564};\\\", \\\"{x:558,y:525,t:1528140006580};\\\", \\\"{x:564,y:522,t:1528140006598};\\\", \\\"{x:575,y:517,t:1528140006614};\\\", \\\"{x:580,y:516,t:1528140006630};\\\", \\\"{x:584,y:513,t:1528140006645};\\\", \\\"{x:586,y:512,t:1528140006663};\\\", \\\"{x:590,y:510,t:1528140006680};\\\", \\\"{x:592,y:508,t:1528140006696};\\\", \\\"{x:595,y:506,t:1528140006714};\\\", \\\"{x:597,y:504,t:1528140006730};\\\", \\\"{x:598,y:503,t:1528140006746};\\\", \\\"{x:599,y:500,t:1528140006764};\\\", \\\"{x:600,y:499,t:1528140006782};\\\", \\\"{x:601,y:499,t:1528140006838};\\\", \\\"{x:596,y:505,t:1528140007093};\\\", \\\"{x:588,y:515,t:1528140007101};\\\", \\\"{x:580,y:521,t:1528140007113};\\\", \\\"{x:568,y:539,t:1528140007129};\\\", \\\"{x:558,y:562,t:1528140007146};\\\", \\\"{x:548,y:585,t:1528140007164};\\\", \\\"{x:534,y:618,t:1528140007181};\\\", \\\"{x:526,y:640,t:1528140007197};\\\", \\\"{x:519,y:656,t:1528140007214};\\\", \\\"{x:515,y:681,t:1528140007230};\\\", \\\"{x:509,y:703,t:1528140007247};\\\", \\\"{x:505,y:718,t:1528140007264};\\\", \\\"{x:502,y:731,t:1528140007280};\\\", \\\"{x:500,y:742,t:1528140007297};\\\", \\\"{x:500,y:749,t:1528140007314};\\\", \\\"{x:498,y:753,t:1528140007331};\\\", \\\"{x:498,y:756,t:1528140007347};\\\", \\\"{x:498,y:759,t:1528140007363};\\\", \\\"{x:498,y:762,t:1528140007380};\\\", \\\"{x:498,y:763,t:1528140007397};\\\", \\\"{x:498,y:764,t:1528140007525};\\\", \\\"{x:498,y:763,t:1528140007534};\\\", \\\"{x:499,y:762,t:1528140007548};\\\", \\\"{x:502,y:756,t:1528140007565};\\\", \\\"{x:503,y:752,t:1528140007583};\\\", \\\"{x:505,y:751,t:1528140007598};\\\", \\\"{x:505,y:748,t:1528140007997};\\\", \\\"{x:505,y:743,t:1528140008005};\\\", \\\"{x:505,y:739,t:1528140008015};\\\", \\\"{x:505,y:733,t:1528140008031};\\\", \\\"{x:505,y:728,t:1528140008048};\\\", \\\"{x:505,y:727,t:1528140008065};\\\" ] }, { \\\"rt\\\": 11508, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 855012, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-M -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:724,t:1528140011150};\\\", \\\"{x:543,y:703,t:1528140011166};\\\", \\\"{x:594,y:663,t:1528140011184};\\\", \\\"{x:657,y:625,t:1528140011201};\\\", \\\"{x:682,y:606,t:1528140011217};\\\", \\\"{x:704,y:588,t:1528140011233};\\\", \\\"{x:740,y:569,t:1528140011250};\\\", \\\"{x:773,y:555,t:1528140011267};\\\", \\\"{x:792,y:541,t:1528140011284};\\\", \\\"{x:799,y:534,t:1528140011300};\\\", \\\"{x:801,y:533,t:1528140011316};\\\", \\\"{x:803,y:529,t:1528140011340};\\\", \\\"{x:806,y:521,t:1528140011352};\\\", \\\"{x:819,y:507,t:1528140011367};\\\", \\\"{x:834,y:492,t:1528140011385};\\\", \\\"{x:849,y:477,t:1528140011401};\\\", \\\"{x:861,y:464,t:1528140011417};\\\", \\\"{x:869,y:456,t:1528140011434};\\\", \\\"{x:879,y:450,t:1528140011451};\\\", \\\"{x:899,y:435,t:1528140011467};\\\", \\\"{x:918,y:425,t:1528140011485};\\\", \\\"{x:933,y:409,t:1528140011501};\\\", \\\"{x:950,y:386,t:1528140011517};\\\", \\\"{x:960,y:371,t:1528140011534};\\\", \\\"{x:970,y:355,t:1528140011550};\\\", \\\"{x:976,y:342,t:1528140011567};\\\", \\\"{x:982,y:333,t:1528140011584};\\\", \\\"{x:983,y:329,t:1528140011600};\\\", \\\"{x:984,y:319,t:1528140011617};\\\", \\\"{x:984,y:311,t:1528140011634};\\\", \\\"{x:986,y:303,t:1528140011650};\\\", \\\"{x:986,y:295,t:1528140011667};\\\", \\\"{x:987,y:287,t:1528140011684};\\\", \\\"{x:988,y:281,t:1528140011700};\\\", \\\"{x:989,y:274,t:1528140011717};\\\", \\\"{x:991,y:265,t:1528140011735};\\\", \\\"{x:993,y:256,t:1528140011751};\\\", \\\"{x:995,y:247,t:1528140011768};\\\", \\\"{x:997,y:241,t:1528140011785};\\\", \\\"{x:999,y:233,t:1528140011800};\\\", \\\"{x:1003,y:225,t:1528140011818};\\\", \\\"{x:1003,y:222,t:1528140011834};\\\", \\\"{x:1004,y:219,t:1528140011851};\\\", \\\"{x:1004,y:217,t:1528140011867};\\\", \\\"{x:1007,y:219,t:1528140012574};\\\", \\\"{x:1024,y:245,t:1528140012584};\\\", \\\"{x:1069,y:311,t:1528140012600};\\\", \\\"{x:1144,y:412,t:1528140012618};\\\", \\\"{x:1236,y:534,t:1528140012633};\\\", \\\"{x:1327,y:672,t:1528140012651};\\\", \\\"{x:1403,y:799,t:1528140012668};\\\", \\\"{x:1491,y:911,t:1528140012684};\\\", \\\"{x:1570,y:1002,t:1528140012701};\\\", \\\"{x:1617,y:1052,t:1528140012717};\\\", \\\"{x:1641,y:1072,t:1528140012734};\\\", \\\"{x:1644,y:1074,t:1528140012750};\\\", \\\"{x:1644,y:1073,t:1528140012830};\\\", \\\"{x:1644,y:1067,t:1528140012837};\\\", \\\"{x:1644,y:1065,t:1528140012850};\\\", \\\"{x:1641,y:1060,t:1528140012867};\\\", \\\"{x:1631,y:1050,t:1528140012885};\\\", \\\"{x:1611,y:1035,t:1528140012901};\\\", \\\"{x:1592,y:1021,t:1528140012917};\\\", \\\"{x:1572,y:1012,t:1528140012933};\\\", \\\"{x:1562,y:1007,t:1528140012951};\\\", \\\"{x:1554,y:1005,t:1528140012967};\\\", \\\"{x:1551,y:1004,t:1528140012984};\\\", \\\"{x:1548,y:1004,t:1528140013001};\\\", \\\"{x:1545,y:1004,t:1528140013017};\\\", \\\"{x:1540,y:1004,t:1528140013034};\\\", \\\"{x:1535,y:1004,t:1528140013051};\\\", \\\"{x:1524,y:1006,t:1528140013067};\\\", \\\"{x:1516,y:1006,t:1528140013083};\\\", \\\"{x:1507,y:1006,t:1528140013101};\\\", \\\"{x:1497,y:1003,t:1528140013117};\\\", \\\"{x:1467,y:994,t:1528140013134};\\\", \\\"{x:1441,y:985,t:1528140013151};\\\", \\\"{x:1404,y:971,t:1528140013167};\\\", \\\"{x:1381,y:959,t:1528140013185};\\\", \\\"{x:1368,y:954,t:1528140013200};\\\", \\\"{x:1352,y:949,t:1528140013217};\\\", \\\"{x:1345,y:946,t:1528140013234};\\\", \\\"{x:1337,y:943,t:1528140013250};\\\", \\\"{x:1335,y:943,t:1528140013267};\\\", \\\"{x:1334,y:942,t:1528140013283};\\\", \\\"{x:1333,y:942,t:1528140013318};\\\", \\\"{x:1331,y:943,t:1528140013334};\\\", \\\"{x:1330,y:943,t:1528140013350};\\\", \\\"{x:1328,y:944,t:1528140013367};\\\", \\\"{x:1326,y:944,t:1528140013390};\\\", \\\"{x:1326,y:946,t:1528140013526};\\\", \\\"{x:1325,y:946,t:1528140013541};\\\", \\\"{x:1324,y:948,t:1528140013558};\\\", \\\"{x:1324,y:950,t:1528140013567};\\\", \\\"{x:1325,y:950,t:1528140013584};\\\", \\\"{x:1326,y:950,t:1528140013638};\\\", \\\"{x:1328,y:951,t:1528140013653};\\\", \\\"{x:1328,y:952,t:1528140013677};\\\", \\\"{x:1329,y:952,t:1528140013693};\\\", \\\"{x:1330,y:952,t:1528140013709};\\\", \\\"{x:1331,y:951,t:1528140013725};\\\", \\\"{x:1333,y:951,t:1528140013741};\\\", \\\"{x:1335,y:951,t:1528140013765};\\\", \\\"{x:1337,y:949,t:1528140013784};\\\", \\\"{x:1340,y:949,t:1528140013800};\\\", \\\"{x:1341,y:948,t:1528140013817};\\\", \\\"{x:1343,y:948,t:1528140013834};\\\", \\\"{x:1344,y:948,t:1528140013850};\\\", \\\"{x:1346,y:948,t:1528140013870};\\\", \\\"{x:1347,y:948,t:1528140013974};\\\", \\\"{x:1350,y:946,t:1528140014158};\\\", \\\"{x:1351,y:945,t:1528140014167};\\\", \\\"{x:1353,y:943,t:1528140014183};\\\", \\\"{x:1355,y:940,t:1528140014199};\\\", \\\"{x:1357,y:938,t:1528140014217};\\\", \\\"{x:1357,y:936,t:1528140014233};\\\", \\\"{x:1358,y:935,t:1528140014253};\\\", \\\"{x:1359,y:935,t:1528140014278};\\\", \\\"{x:1359,y:934,t:1528140014302};\\\", \\\"{x:1360,y:932,t:1528140014316};\\\", \\\"{x:1362,y:929,t:1528140014334};\\\", \\\"{x:1363,y:927,t:1528140014349};\\\", \\\"{x:1364,y:926,t:1528140014367};\\\", \\\"{x:1364,y:925,t:1528140014383};\\\", \\\"{x:1365,y:925,t:1528140014399};\\\", \\\"{x:1365,y:923,t:1528140014417};\\\", \\\"{x:1366,y:921,t:1528140014432};\\\", \\\"{x:1367,y:920,t:1528140014449};\\\", \\\"{x:1369,y:919,t:1528140014466};\\\", \\\"{x:1370,y:918,t:1528140014482};\\\", \\\"{x:1371,y:917,t:1528140014499};\\\", \\\"{x:1371,y:916,t:1528140014515};\\\", \\\"{x:1373,y:915,t:1528140014532};\\\", \\\"{x:1374,y:913,t:1528140014549};\\\", \\\"{x:1375,y:913,t:1528140014605};\\\", \\\"{x:1376,y:912,t:1528140014653};\\\", \\\"{x:1377,y:911,t:1528140014709};\\\", \\\"{x:1378,y:910,t:1528140014798};\\\", \\\"{x:1379,y:909,t:1528140016166};\\\", \\\"{x:1381,y:907,t:1528140016182};\\\", \\\"{x:1381,y:904,t:1528140016199};\\\", \\\"{x:1383,y:902,t:1528140016216};\\\", \\\"{x:1383,y:901,t:1528140016234};\\\", \\\"{x:1383,y:899,t:1528140016249};\\\", \\\"{x:1383,y:897,t:1528140016266};\\\", \\\"{x:1385,y:894,t:1528140016281};\\\", \\\"{x:1386,y:893,t:1528140016300};\\\", \\\"{x:1386,y:890,t:1528140016316};\\\", \\\"{x:1389,y:888,t:1528140016332};\\\", \\\"{x:1390,y:887,t:1528140016349};\\\", \\\"{x:1393,y:882,t:1528140016365};\\\", \\\"{x:1395,y:878,t:1528140016382};\\\", \\\"{x:1397,y:875,t:1528140016399};\\\", \\\"{x:1399,y:871,t:1528140016415};\\\", \\\"{x:1400,y:869,t:1528140016432};\\\", \\\"{x:1401,y:866,t:1528140016449};\\\", \\\"{x:1403,y:860,t:1528140016465};\\\", \\\"{x:1405,y:856,t:1528140016482};\\\", \\\"{x:1406,y:851,t:1528140016499};\\\", \\\"{x:1407,y:850,t:1528140016515};\\\", \\\"{x:1407,y:849,t:1528140016531};\\\", \\\"{x:1408,y:847,t:1528140016549};\\\", \\\"{x:1408,y:846,t:1528140016565};\\\", \\\"{x:1409,y:842,t:1528140016582};\\\", \\\"{x:1411,y:839,t:1528140016598};\\\", \\\"{x:1412,y:834,t:1528140016615};\\\", \\\"{x:1414,y:831,t:1528140016632};\\\", \\\"{x:1417,y:826,t:1528140016649};\\\", \\\"{x:1419,y:820,t:1528140016666};\\\", \\\"{x:1421,y:816,t:1528140016682};\\\", \\\"{x:1425,y:811,t:1528140016699};\\\", \\\"{x:1429,y:806,t:1528140016715};\\\", \\\"{x:1431,y:801,t:1528140016732};\\\", \\\"{x:1433,y:795,t:1528140016749};\\\", \\\"{x:1439,y:787,t:1528140016765};\\\", \\\"{x:1443,y:783,t:1528140016782};\\\", \\\"{x:1448,y:778,t:1528140016799};\\\", \\\"{x:1452,y:771,t:1528140016815};\\\", \\\"{x:1455,y:767,t:1528140016832};\\\", \\\"{x:1458,y:763,t:1528140016849};\\\", \\\"{x:1461,y:760,t:1528140016864};\\\", \\\"{x:1463,y:756,t:1528140016881};\\\", \\\"{x:1463,y:755,t:1528140016899};\\\", \\\"{x:1465,y:752,t:1528140016915};\\\", \\\"{x:1466,y:750,t:1528140016931};\\\", \\\"{x:1468,y:748,t:1528140016948};\\\", \\\"{x:1469,y:743,t:1528140016964};\\\", \\\"{x:1469,y:741,t:1528140016980};\\\", \\\"{x:1472,y:738,t:1528140016998};\\\", \\\"{x:1472,y:736,t:1528140017014};\\\", \\\"{x:1473,y:733,t:1528140017032};\\\", \\\"{x:1475,y:730,t:1528140017048};\\\", \\\"{x:1476,y:725,t:1528140017064};\\\", \\\"{x:1477,y:721,t:1528140017082};\\\", \\\"{x:1481,y:715,t:1528140017098};\\\", \\\"{x:1483,y:707,t:1528140017114};\\\", \\\"{x:1487,y:701,t:1528140017132};\\\", \\\"{x:1492,y:691,t:1528140017147};\\\", \\\"{x:1493,y:685,t:1528140017165};\\\", \\\"{x:1501,y:673,t:1528140017182};\\\", \\\"{x:1505,y:666,t:1528140017198};\\\", \\\"{x:1506,y:663,t:1528140017215};\\\", \\\"{x:1510,y:658,t:1528140017232};\\\", \\\"{x:1510,y:656,t:1528140017247};\\\", \\\"{x:1513,y:652,t:1528140017264};\\\", \\\"{x:1514,y:648,t:1528140017282};\\\", \\\"{x:1515,y:645,t:1528140017297};\\\", \\\"{x:1517,y:642,t:1528140017314};\\\", \\\"{x:1518,y:639,t:1528140017331};\\\", \\\"{x:1520,y:635,t:1528140017348};\\\", \\\"{x:1521,y:627,t:1528140017364};\\\", \\\"{x:1524,y:623,t:1528140017381};\\\", \\\"{x:1526,y:617,t:1528140017398};\\\", \\\"{x:1528,y:612,t:1528140017415};\\\", \\\"{x:1530,y:608,t:1528140017431};\\\", \\\"{x:1532,y:603,t:1528140017447};\\\", \\\"{x:1533,y:598,t:1528140017465};\\\", \\\"{x:1534,y:594,t:1528140017482};\\\", \\\"{x:1536,y:590,t:1528140017498};\\\", \\\"{x:1537,y:585,t:1528140017515};\\\", \\\"{x:1539,y:581,t:1528140017531};\\\", \\\"{x:1541,y:574,t:1528140017547};\\\", \\\"{x:1543,y:569,t:1528140017564};\\\", \\\"{x:1544,y:563,t:1528140017580};\\\", \\\"{x:1547,y:558,t:1528140017597};\\\", \\\"{x:1547,y:555,t:1528140017614};\\\", \\\"{x:1549,y:550,t:1528140017631};\\\", \\\"{x:1551,y:545,t:1528140017648};\\\", \\\"{x:1553,y:541,t:1528140017664};\\\", \\\"{x:1556,y:537,t:1528140017680};\\\", \\\"{x:1557,y:533,t:1528140017698};\\\", \\\"{x:1558,y:526,t:1528140017715};\\\", \\\"{x:1560,y:522,t:1528140017731};\\\", \\\"{x:1562,y:516,t:1528140017748};\\\", \\\"{x:1564,y:513,t:1528140017765};\\\", \\\"{x:1565,y:510,t:1528140017781};\\\", \\\"{x:1568,y:504,t:1528140017798};\\\", \\\"{x:1571,y:498,t:1528140017815};\\\", \\\"{x:1572,y:496,t:1528140017831};\\\", \\\"{x:1574,y:493,t:1528140017848};\\\", \\\"{x:1576,y:490,t:1528140017865};\\\", \\\"{x:1581,y:483,t:1528140017881};\\\", \\\"{x:1587,y:475,t:1528140017898};\\\", \\\"{x:1592,y:470,t:1528140017914};\\\", \\\"{x:1595,y:465,t:1528140017930};\\\", \\\"{x:1599,y:459,t:1528140017948};\\\", \\\"{x:1602,y:454,t:1528140017965};\\\", \\\"{x:1603,y:453,t:1528140017981};\\\", \\\"{x:1603,y:452,t:1528140018029};\\\", \\\"{x:1602,y:452,t:1528140018125};\\\", \\\"{x:1592,y:456,t:1528140018132};\\\", \\\"{x:1582,y:464,t:1528140018148};\\\", \\\"{x:1554,y:485,t:1528140018163};\\\", \\\"{x:1451,y:546,t:1528140018180};\\\", \\\"{x:1337,y:603,t:1528140018198};\\\", \\\"{x:1192,y:658,t:1528140018213};\\\", \\\"{x:1036,y:709,t:1528140018230};\\\", \\\"{x:938,y:743,t:1528140018247};\\\", \\\"{x:902,y:753,t:1528140018264};\\\", \\\"{x:887,y:756,t:1528140018280};\\\", \\\"{x:877,y:757,t:1528140018297};\\\", \\\"{x:869,y:763,t:1528140018313};\\\", \\\"{x:859,y:767,t:1528140018330};\\\", \\\"{x:849,y:775,t:1528140018348};\\\", \\\"{x:833,y:782,t:1528140018363};\\\", \\\"{x:820,y:794,t:1528140018380};\\\", \\\"{x:807,y:800,t:1528140018397};\\\", \\\"{x:798,y:802,t:1528140018414};\\\", \\\"{x:790,y:798,t:1528140018430};\\\", \\\"{x:770,y:786,t:1528140018447};\\\", \\\"{x:753,y:778,t:1528140018463};\\\", \\\"{x:725,y:751,t:1528140018481};\\\", \\\"{x:691,y:727,t:1528140018497};\\\", \\\"{x:667,y:699,t:1528140018514};\\\", \\\"{x:643,y:681,t:1528140018531};\\\", \\\"{x:616,y:659,t:1528140018548};\\\", \\\"{x:586,y:635,t:1528140018563};\\\", \\\"{x:564,y:618,t:1528140018582};\\\", \\\"{x:515,y:588,t:1528140018597};\\\", \\\"{x:480,y:576,t:1528140018614};\\\", \\\"{x:421,y:559,t:1528140018640};\\\", \\\"{x:402,y:552,t:1528140018657};\\\", \\\"{x:392,y:548,t:1528140018673};\\\", \\\"{x:390,y:548,t:1528140018690};\\\", \\\"{x:388,y:546,t:1528140018733};\\\", \\\"{x:386,y:544,t:1528140018740};\\\", \\\"{x:385,y:537,t:1528140018757};\\\", \\\"{x:376,y:527,t:1528140018773};\\\", \\\"{x:371,y:522,t:1528140018791};\\\", \\\"{x:368,y:520,t:1528140018808};\\\", \\\"{x:367,y:520,t:1528140018823};\\\", \\\"{x:368,y:521,t:1528140019110};\\\", \\\"{x:369,y:523,t:1528140019125};\\\", \\\"{x:370,y:524,t:1528140019149};\\\", \\\"{x:371,y:525,t:1528140019207};\\\", \\\"{x:373,y:526,t:1528140019261};\\\", \\\"{x:373,y:527,t:1528140019273};\\\", \\\"{x:380,y:534,t:1528140019336};\\\", \\\"{x:381,y:535,t:1528140019348};\\\", \\\"{x:382,y:536,t:1528140019357};\\\", \\\"{x:382,y:537,t:1528140019380};\\\", \\\"{x:383,y:537,t:1528140019390};\\\", \\\"{x:386,y:545,t:1528140019596};\\\", \\\"{x:390,y:554,t:1528140019607};\\\", \\\"{x:396,y:569,t:1528140019625};\\\", \\\"{x:404,y:592,t:1528140019640};\\\", \\\"{x:407,y:610,t:1528140019658};\\\", \\\"{x:409,y:615,t:1528140019674};\\\", \\\"{x:411,y:619,t:1528140019690};\\\", \\\"{x:411,y:620,t:1528140019707};\\\", \\\"{x:411,y:622,t:1528140019724};\\\", \\\"{x:411,y:624,t:1528140019740};\\\", \\\"{x:411,y:625,t:1528140019773};\\\", \\\"{x:411,y:626,t:1528140019804};\\\", \\\"{x:410,y:627,t:1528140019813};\\\", \\\"{x:410,y:628,t:1528140019829};\\\", \\\"{x:409,y:628,t:1528140019841};\\\", \\\"{x:407,y:630,t:1528140019857};\\\", \\\"{x:406,y:632,t:1528140019902};\\\", \\\"{x:401,y:631,t:1528140019975};\\\", \\\"{x:400,y:629,t:1528140019991};\\\", \\\"{x:397,y:626,t:1528140020007};\\\", \\\"{x:397,y:625,t:1528140020024};\\\", \\\"{x:395,y:623,t:1528140020042};\\\", \\\"{x:394,y:622,t:1528140020057};\\\", \\\"{x:393,y:621,t:1528140020133};\\\", \\\"{x:392,y:620,t:1528140020149};\\\", \\\"{x:390,y:620,t:1528140020164};\\\", \\\"{x:389,y:619,t:1528140020174};\\\", \\\"{x:388,y:619,t:1528140020191};\\\", \\\"{x:386,y:617,t:1528140020207};\\\", \\\"{x:385,y:616,t:1528140020225};\\\", \\\"{x:384,y:616,t:1528140020300};\\\", \\\"{x:383,y:616,t:1528140020340};\\\", \\\"{x:383,y:616,t:1528140020385};\\\", \\\"{x:382,y:620,t:1528140020408};\\\", \\\"{x:383,y:630,t:1528140020424};\\\", \\\"{x:388,y:644,t:1528140020441};\\\", \\\"{x:393,y:657,t:1528140020458};\\\", \\\"{x:400,y:671,t:1528140020475};\\\", \\\"{x:409,y:681,t:1528140020491};\\\", \\\"{x:425,y:702,t:1528140020509};\\\", \\\"{x:433,y:709,t:1528140020525};\\\", \\\"{x:437,y:716,t:1528140020541};\\\", \\\"{x:441,y:720,t:1528140020559};\\\", \\\"{x:443,y:723,t:1528140020574};\\\", \\\"{x:445,y:725,t:1528140020592};\\\", \\\"{x:446,y:727,t:1528140020608};\\\", \\\"{x:449,y:730,t:1528140020624};\\\", \\\"{x:450,y:731,t:1528140020642};\\\", \\\"{x:451,y:731,t:1528140020659};\\\", \\\"{x:452,y:732,t:1528140020675};\\\", \\\"{x:453,y:732,t:1528140020692};\\\", \\\"{x:457,y:734,t:1528140020709};\\\", \\\"{x:462,y:737,t:1528140020725};\\\", \\\"{x:466,y:738,t:1528140020741};\\\", \\\"{x:471,y:740,t:1528140020758};\\\", \\\"{x:475,y:741,t:1528140020775};\\\", \\\"{x:477,y:741,t:1528140020869};\\\", \\\"{x:480,y:741,t:1528140020908};\\\", \\\"{x:480,y:741,t:1528140020998};\\\", \\\"{x:477,y:741,t:1528140021020};\\\", \\\"{x:472,y:744,t:1528140021028};\\\", \\\"{x:467,y:748,t:1528140021042};\\\", \\\"{x:457,y:761,t:1528140021058};\\\", \\\"{x:442,y:781,t:1528140021075};\\\", \\\"{x:426,y:806,t:1528140021091};\\\", \\\"{x:398,y:847,t:1528140021108};\\\", \\\"{x:376,y:864,t:1528140021125};\\\", \\\"{x:355,y:884,t:1528140021141};\\\", \\\"{x:335,y:904,t:1528140021158};\\\", \\\"{x:310,y:932,t:1528140021175};\\\", \\\"{x:292,y:951,t:1528140021191};\\\", \\\"{x:269,y:974,t:1528140021208};\\\", \\\"{x:251,y:990,t:1528140021225};\\\", \\\"{x:228,y:1012,t:1528140021242};\\\", \\\"{x:212,y:1025,t:1528140021258};\\\", \\\"{x:203,y:1032,t:1528140021276};\\\", \\\"{x:197,y:1037,t:1528140021292};\\\", \\\"{x:196,y:1039,t:1528140021309};\\\", \\\"{x:196,y:1041,t:1528140021461};\\\", \\\"{x:195,y:1041,t:1528140021475};\\\", \\\"{x:194,y:1042,t:1528140021493};\\\" ] }, { \\\"rt\\\": 7904, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 864257, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:204,y:1039,t:1528140023621};\\\", \\\"{x:213,y:1030,t:1528140023629};\\\", \\\"{x:226,y:1016,t:1528140023643};\\\", \\\"{x:321,y:962,t:1528140023661};\\\", \\\"{x:417,y:924,t:1528140023677};\\\", \\\"{x:541,y:895,t:1528140023694};\\\", \\\"{x:643,y:883,t:1528140023711};\\\", \\\"{x:762,y:883,t:1528140023728};\\\", \\\"{x:898,y:883,t:1528140023744};\\\", \\\"{x:1031,y:883,t:1528140023762};\\\", \\\"{x:1133,y:883,t:1528140023778};\\\", \\\"{x:1202,y:889,t:1528140023794};\\\", \\\"{x:1245,y:898,t:1528140023811};\\\", \\\"{x:1261,y:901,t:1528140023829};\\\", \\\"{x:1267,y:901,t:1528140023844};\\\", \\\"{x:1268,y:903,t:1528140023861};\\\", \\\"{x:1270,y:902,t:1528140023928};\\\", \\\"{x:1275,y:894,t:1528140023943};\\\", \\\"{x:1279,y:882,t:1528140023960};\\\", \\\"{x:1281,y:871,t:1528140023977};\\\", \\\"{x:1282,y:856,t:1528140023994};\\\", \\\"{x:1285,y:840,t:1528140024011};\\\", \\\"{x:1287,y:825,t:1528140024028};\\\", \\\"{x:1289,y:808,t:1528140024044};\\\", \\\"{x:1290,y:801,t:1528140024060};\\\", \\\"{x:1290,y:798,t:1528140024077};\\\", \\\"{x:1291,y:798,t:1528140024094};\\\", \\\"{x:1290,y:798,t:1528140024125};\\\", \\\"{x:1288,y:798,t:1528140024133};\\\", \\\"{x:1281,y:798,t:1528140024145};\\\", \\\"{x:1276,y:801,t:1528140024160};\\\", \\\"{x:1269,y:808,t:1528140024177};\\\", \\\"{x:1263,y:814,t:1528140024195};\\\", \\\"{x:1254,y:825,t:1528140024211};\\\", \\\"{x:1249,y:832,t:1528140024228};\\\", \\\"{x:1245,y:841,t:1528140024245};\\\", \\\"{x:1248,y:840,t:1528140024334};\\\", \\\"{x:1253,y:837,t:1528140024346};\\\", \\\"{x:1264,y:820,t:1528140024362};\\\", \\\"{x:1274,y:800,t:1528140024378};\\\", \\\"{x:1283,y:779,t:1528140024395};\\\", \\\"{x:1287,y:762,t:1528140024411};\\\", \\\"{x:1293,y:746,t:1528140024429};\\\", \\\"{x:1296,y:721,t:1528140024444};\\\", \\\"{x:1296,y:711,t:1528140024461};\\\", \\\"{x:1296,y:705,t:1528140024477};\\\", \\\"{x:1295,y:703,t:1528140024495};\\\", \\\"{x:1294,y:702,t:1528140024516};\\\", \\\"{x:1292,y:700,t:1528140024527};\\\", \\\"{x:1290,y:695,t:1528140024545};\\\", \\\"{x:1284,y:683,t:1528140024562};\\\", \\\"{x:1276,y:669,t:1528140024577};\\\", \\\"{x:1266,y:654,t:1528140024595};\\\", \\\"{x:1262,y:644,t:1528140024612};\\\", \\\"{x:1260,y:634,t:1528140024628};\\\", \\\"{x:1259,y:621,t:1528140024645};\\\", \\\"{x:1259,y:617,t:1528140024662};\\\", \\\"{x:1258,y:613,t:1528140024678};\\\", \\\"{x:1258,y:609,t:1528140024695};\\\", \\\"{x:1259,y:607,t:1528140024712};\\\", \\\"{x:1260,y:605,t:1528140024728};\\\", \\\"{x:1262,y:604,t:1528140024745};\\\", \\\"{x:1263,y:604,t:1528140024870};\\\", \\\"{x:1263,y:605,t:1528140024878};\\\", \\\"{x:1263,y:611,t:1528140024895};\\\", \\\"{x:1263,y:618,t:1528140024912};\\\", \\\"{x:1263,y:625,t:1528140024928};\\\", \\\"{x:1263,y:631,t:1528140024945};\\\", \\\"{x:1266,y:635,t:1528140024962};\\\", \\\"{x:1269,y:639,t:1528140024980};\\\", \\\"{x:1275,y:646,t:1528140024995};\\\", \\\"{x:1283,y:652,t:1528140025012};\\\", \\\"{x:1303,y:668,t:1528140025030};\\\", \\\"{x:1324,y:683,t:1528140025045};\\\", \\\"{x:1341,y:695,t:1528140025062};\\\", \\\"{x:1357,y:706,t:1528140025079};\\\", \\\"{x:1373,y:718,t:1528140025095};\\\", \\\"{x:1389,y:724,t:1528140025112};\\\", \\\"{x:1396,y:727,t:1528140025130};\\\", \\\"{x:1396,y:726,t:1528140025262};\\\", \\\"{x:1390,y:723,t:1528140025279};\\\", \\\"{x:1381,y:718,t:1528140025296};\\\", \\\"{x:1371,y:713,t:1528140025312};\\\", \\\"{x:1352,y:708,t:1528140025329};\\\", \\\"{x:1327,y:700,t:1528140025345};\\\", \\\"{x:1316,y:693,t:1528140025362};\\\", \\\"{x:1313,y:691,t:1528140025379};\\\", \\\"{x:1312,y:691,t:1528140025395};\\\", \\\"{x:1313,y:691,t:1528140025469};\\\", \\\"{x:1314,y:691,t:1528140025479};\\\", \\\"{x:1315,y:691,t:1528140025709};\\\", \\\"{x:1316,y:691,t:1528140025726};\\\", \\\"{x:1317,y:691,t:1528140025733};\\\", \\\"{x:1318,y:691,t:1528140025766};\\\", \\\"{x:1319,y:691,t:1528140025782};\\\", \\\"{x:1320,y:691,t:1528140025805};\\\", \\\"{x:1322,y:691,t:1528140025822};\\\", \\\"{x:1324,y:693,t:1528140025839};\\\", \\\"{x:1324,y:695,t:1528140025852};\\\", \\\"{x:1325,y:695,t:1528140025861};\\\", \\\"{x:1325,y:696,t:1528140025878};\\\", \\\"{x:1326,y:698,t:1528140025895};\\\", \\\"{x:1326,y:700,t:1528140025912};\\\", \\\"{x:1326,y:701,t:1528140025928};\\\", \\\"{x:1326,y:703,t:1528140025946};\\\", \\\"{x:1326,y:704,t:1528140025963};\\\", \\\"{x:1326,y:705,t:1528140026222};\\\", \\\"{x:1326,y:706,t:1528140026236};\\\", \\\"{x:1325,y:706,t:1528140026261};\\\", \\\"{x:1324,y:706,t:1528140026269};\\\", \\\"{x:1325,y:706,t:1528140026565};\\\", \\\"{x:1326,y:706,t:1528140026590};\\\", \\\"{x:1328,y:706,t:1528140026597};\\\", \\\"{x:1328,y:705,t:1528140026614};\\\", \\\"{x:1330,y:705,t:1528140026630};\\\", \\\"{x:1332,y:704,t:1528140026646};\\\", \\\"{x:1333,y:703,t:1528140026663};\\\", \\\"{x:1336,y:701,t:1528140026680};\\\", \\\"{x:1337,y:701,t:1528140026697};\\\", \\\"{x:1338,y:700,t:1528140026713};\\\", \\\"{x:1341,y:698,t:1528140026917};\\\", \\\"{x:1342,y:697,t:1528140026933};\\\", \\\"{x:1348,y:693,t:1528140026947};\\\", \\\"{x:1356,y:686,t:1528140026963};\\\", \\\"{x:1366,y:675,t:1528140026979};\\\", \\\"{x:1383,y:660,t:1528140026996};\\\", \\\"{x:1390,y:653,t:1528140027013};\\\", \\\"{x:1398,y:643,t:1528140027029};\\\", \\\"{x:1405,y:634,t:1528140027047};\\\", \\\"{x:1410,y:626,t:1528140027063};\\\", \\\"{x:1414,y:620,t:1528140027080};\\\", \\\"{x:1419,y:613,t:1528140027097};\\\", \\\"{x:1420,y:611,t:1528140027112};\\\", \\\"{x:1422,y:608,t:1528140027130};\\\", \\\"{x:1422,y:606,t:1528140027147};\\\", \\\"{x:1424,y:603,t:1528140027163};\\\", \\\"{x:1424,y:600,t:1528140027180};\\\", \\\"{x:1426,y:595,t:1528140027197};\\\", \\\"{x:1426,y:594,t:1528140027213};\\\", \\\"{x:1426,y:592,t:1528140027230};\\\", \\\"{x:1428,y:587,t:1528140027247};\\\", \\\"{x:1428,y:583,t:1528140027263};\\\", \\\"{x:1428,y:580,t:1528140027280};\\\", \\\"{x:1428,y:575,t:1528140027297};\\\", \\\"{x:1427,y:568,t:1528140027314};\\\", \\\"{x:1424,y:562,t:1528140027331};\\\", \\\"{x:1421,y:554,t:1528140027348};\\\", \\\"{x:1418,y:549,t:1528140027364};\\\", \\\"{x:1416,y:547,t:1528140027380};\\\", \\\"{x:1415,y:546,t:1528140027397};\\\", \\\"{x:1415,y:544,t:1528140027414};\\\", \\\"{x:1414,y:544,t:1528140027430};\\\", \\\"{x:1414,y:543,t:1528140027519};\\\", \\\"{x:1413,y:543,t:1528140027694};\\\", \\\"{x:1412,y:543,t:1528140027790};\\\", \\\"{x:1411,y:543,t:1528140027870};\\\", \\\"{x:1410,y:544,t:1528140027882};\\\", \\\"{x:1409,y:544,t:1528140027902};\\\", \\\"{x:1409,y:545,t:1528140027925};\\\", \\\"{x:1409,y:546,t:1528140027934};\\\", \\\"{x:1409,y:547,t:1528140027957};\\\", \\\"{x:1409,y:548,t:1528140027998};\\\", \\\"{x:1409,y:549,t:1528140028102};\\\", \\\"{x:1409,y:550,t:1528140028230};\\\", \\\"{x:1405,y:557,t:1528140028237};\\\", \\\"{x:1405,y:559,t:1528140028247};\\\", \\\"{x:1395,y:573,t:1528140028264};\\\", \\\"{x:1380,y:585,t:1528140028281};\\\", \\\"{x:1363,y:595,t:1528140028298};\\\", \\\"{x:1344,y:601,t:1528140028315};\\\", \\\"{x:1331,y:610,t:1528140028331};\\\", \\\"{x:1314,y:610,t:1528140028348};\\\", \\\"{x:1292,y:610,t:1528140028364};\\\", \\\"{x:1259,y:607,t:1528140028381};\\\", \\\"{x:1241,y:603,t:1528140028398};\\\", \\\"{x:1229,y:598,t:1528140028414};\\\", \\\"{x:1211,y:597,t:1528140028432};\\\", \\\"{x:1207,y:597,t:1528140028448};\\\", \\\"{x:1200,y:594,t:1528140028464};\\\", \\\"{x:1200,y:592,t:1528140028485};\\\", \\\"{x:1195,y:586,t:1528140028498};\\\", \\\"{x:1190,y:585,t:1528140028514};\\\", \\\"{x:1180,y:584,t:1528140028531};\\\", \\\"{x:1173,y:582,t:1528140028548};\\\", \\\"{x:1171,y:582,t:1528140028565};\\\", \\\"{x:1158,y:582,t:1528140028581};\\\", \\\"{x:1138,y:585,t:1528140028598};\\\", \\\"{x:1133,y:588,t:1528140028615};\\\", \\\"{x:1112,y:589,t:1528140028631};\\\", \\\"{x:1094,y:594,t:1528140028648};\\\", \\\"{x:1088,y:599,t:1528140028664};\\\", \\\"{x:1078,y:609,t:1528140028681};\\\", \\\"{x:1056,y:613,t:1528140028698};\\\", \\\"{x:1032,y:612,t:1528140028714};\\\", \\\"{x:1018,y:610,t:1528140028732};\\\", \\\"{x:1018,y:608,t:1528140028748};\\\", \\\"{x:1015,y:604,t:1528140028764};\\\", \\\"{x:1005,y:595,t:1528140028781};\\\", \\\"{x:993,y:587,t:1528140028798};\\\", \\\"{x:980,y:578,t:1528140028814};\\\", \\\"{x:964,y:568,t:1528140028830};\\\", \\\"{x:943,y:558,t:1528140028847};\\\", \\\"{x:926,y:548,t:1528140028865};\\\", \\\"{x:914,y:541,t:1528140028881};\\\", \\\"{x:896,y:533,t:1528140028897};\\\", \\\"{x:874,y:529,t:1528140028914};\\\", \\\"{x:851,y:526,t:1528140028932};\\\", \\\"{x:820,y:520,t:1528140028948};\\\", \\\"{x:810,y:519,t:1528140028964};\\\", \\\"{x:808,y:519,t:1528140028981};\\\", \\\"{x:807,y:521,t:1528140029052};\\\", \\\"{x:807,y:524,t:1528140029065};\\\", \\\"{x:813,y:533,t:1528140029083};\\\", \\\"{x:818,y:539,t:1528140029099};\\\", \\\"{x:821,y:542,t:1528140029115};\\\", \\\"{x:826,y:545,t:1528140029132};\\\", \\\"{x:828,y:546,t:1528140029149};\\\", \\\"{x:829,y:546,t:1528140029173};\\\", \\\"{x:830,y:546,t:1528140029181};\\\", \\\"{x:832,y:546,t:1528140029199};\\\", \\\"{x:833,y:546,t:1528140029253};\\\", \\\"{x:834,y:546,t:1528140029357};\\\", \\\"{x:834,y:546,t:1528140029464};\\\", \\\"{x:830,y:549,t:1528140029482};\\\", \\\"{x:820,y:554,t:1528140029498};\\\", \\\"{x:792,y:571,t:1528140029517};\\\", \\\"{x:733,y:601,t:1528140029532};\\\", \\\"{x:619,y:647,t:1528140029548};\\\", \\\"{x:565,y:665,t:1528140029566};\\\", \\\"{x:502,y:682,t:1528140029581};\\\", \\\"{x:466,y:696,t:1528140029599};\\\", \\\"{x:448,y:704,t:1528140029616};\\\", \\\"{x:430,y:712,t:1528140029631};\\\", \\\"{x:422,y:716,t:1528140029649};\\\", \\\"{x:421,y:717,t:1528140029665};\\\", \\\"{x:419,y:719,t:1528140029682};\\\", \\\"{x:417,y:723,t:1528140029699};\\\", \\\"{x:414,y:730,t:1528140029716};\\\", \\\"{x:410,y:736,t:1528140029731};\\\", \\\"{x:405,y:746,t:1528140029749};\\\", \\\"{x:402,y:750,t:1528140029765};\\\", \\\"{x:402,y:751,t:1528140029782};\\\", \\\"{x:402,y:753,t:1528140029799};\\\", \\\"{x:402,y:755,t:1528140029837};\\\", \\\"{x:403,y:755,t:1528140029853};\\\", \\\"{x:404,y:755,t:1528140029869};\\\", \\\"{x:406,y:755,t:1528140029885};\\\", \\\"{x:407,y:755,t:1528140029899};\\\", \\\"{x:412,y:755,t:1528140029916};\\\", \\\"{x:417,y:755,t:1528140029932};\\\", \\\"{x:434,y:753,t:1528140029949};\\\", \\\"{x:443,y:751,t:1528140029966};\\\", \\\"{x:452,y:748,t:1528140029983};\\\", \\\"{x:459,y:746,t:1528140029999};\\\", \\\"{x:472,y:742,t:1528140030015};\\\", \\\"{x:475,y:741,t:1528140030033};\\\", \\\"{x:476,y:740,t:1528140030133};\\\", \\\"{x:476,y:740,t:1528140030240};\\\", \\\"{x:474,y:748,t:1528140030308};\\\", \\\"{x:468,y:757,t:1528140030316};\\\", \\\"{x:435,y:826,t:1528140030332};\\\", \\\"{x:398,y:909,t:1528140030350};\\\", \\\"{x:368,y:983,t:1528140030365};\\\", \\\"{x:340,y:1059,t:1528140030382};\\\", \\\"{x:314,y:1140,t:1528140030400};\\\", \\\"{x:309,y:1195,t:1528140030415};\\\", \\\"{x:299,y:1199,t:1528140030433};\\\", \\\"{x:300,y:1199,t:1528140030460};\\\", \\\"{x:301,y:1199,t:1528140030468};\\\", \\\"{x:303,y:1199,t:1528140030482};\\\", \\\"{x:310,y:1199,t:1528140030499};\\\", \\\"{x:312,y:1199,t:1528140030515};\\\", \\\"{x:319,y:1199,t:1528140030532};\\\", \\\"{x:325,y:1199,t:1528140030550};\\\", \\\"{x:334,y:1199,t:1528140030566};\\\", \\\"{x:345,y:1199,t:1528140030582};\\\", \\\"{x:370,y:1192,t:1528140030600};\\\", \\\"{x:423,y:1175,t:1528140030616};\\\", \\\"{x:463,y:1164,t:1528140030632};\\\", \\\"{x:487,y:1152,t:1528140030650};\\\", \\\"{x:506,y:1142,t:1528140030666};\\\", \\\"{x:519,y:1136,t:1528140030682};\\\", \\\"{x:524,y:1135,t:1528140030700};\\\", \\\"{x:528,y:1134,t:1528140030716};\\\" ] }, { \\\"rt\\\": 24255, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 889819, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:1082,t:1528140032144};\\\", \\\"{x:547,y:1079,t:1528140032151};\\\", \\\"{x:547,y:1077,t:1528140032167};\\\", \\\"{x:547,y:1075,t:1528140032183};\\\", \\\"{x:549,y:1073,t:1528140032276};\\\", \\\"{x:554,y:1067,t:1528140032284};\\\", \\\"{x:561,y:1050,t:1528140032301};\\\", \\\"{x:576,y:1033,t:1528140032318};\\\", \\\"{x:586,y:1018,t:1528140032334};\\\", \\\"{x:593,y:1011,t:1528140032351};\\\", \\\"{x:600,y:999,t:1528140032368};\\\", \\\"{x:606,y:987,t:1528140032384};\\\", \\\"{x:610,y:978,t:1528140032401};\\\", \\\"{x:612,y:975,t:1528140032417};\\\", \\\"{x:613,y:974,t:1528140032434};\\\", \\\"{x:613,y:973,t:1528140032451};\\\", \\\"{x:614,y:972,t:1528140032468};\\\", \\\"{x:614,y:971,t:1528140032484};\\\", \\\"{x:614,y:970,t:1528140032557};\\\", \\\"{x:614,y:967,t:1528140032569};\\\", \\\"{x:599,y:958,t:1528140032585};\\\", \\\"{x:579,y:945,t:1528140032601};\\\", \\\"{x:542,y:926,t:1528140032618};\\\", \\\"{x:469,y:902,t:1528140032635};\\\", \\\"{x:423,y:880,t:1528140032651};\\\", \\\"{x:344,y:854,t:1528140032669};\\\", \\\"{x:318,y:842,t:1528140032684};\\\", \\\"{x:307,y:834,t:1528140032701};\\\", \\\"{x:305,y:831,t:1528140032718};\\\", \\\"{x:306,y:827,t:1528140032735};\\\", \\\"{x:319,y:811,t:1528140032751};\\\", \\\"{x:341,y:781,t:1528140032768};\\\", \\\"{x:372,y:733,t:1528140032785};\\\", \\\"{x:395,y:668,t:1528140032803};\\\", \\\"{x:404,y:627,t:1528140032818};\\\", \\\"{x:403,y:595,t:1528140032835};\\\", \\\"{x:396,y:565,t:1528140032853};\\\", \\\"{x:392,y:554,t:1528140032868};\\\", \\\"{x:367,y:519,t:1528140032885};\\\", \\\"{x:360,y:508,t:1528140032902};\\\", \\\"{x:352,y:493,t:1528140032918};\\\", \\\"{x:352,y:492,t:1528140032935};\\\", \\\"{x:353,y:491,t:1528140033004};\\\", \\\"{x:357,y:494,t:1528140033019};\\\", \\\"{x:363,y:500,t:1528140033035};\\\", \\\"{x:373,y:507,t:1528140033052};\\\", \\\"{x:387,y:511,t:1528140033068};\\\", \\\"{x:394,y:511,t:1528140033086};\\\", \\\"{x:402,y:511,t:1528140033102};\\\", \\\"{x:413,y:506,t:1528140033119};\\\", \\\"{x:421,y:499,t:1528140033137};\\\", \\\"{x:427,y:494,t:1528140033152};\\\", \\\"{x:430,y:491,t:1528140033169};\\\", \\\"{x:431,y:490,t:1528140033204};\\\", \\\"{x:431,y:488,t:1528140033219};\\\", \\\"{x:433,y:486,t:1528140033238};\\\", \\\"{x:435,y:486,t:1528140033253};\\\", \\\"{x:438,y:484,t:1528140033268};\\\", \\\"{x:442,y:481,t:1528140033285};\\\", \\\"{x:447,y:479,t:1528140033302};\\\", \\\"{x:460,y:475,t:1528140033319};\\\", \\\"{x:474,y:474,t:1528140033335};\\\", \\\"{x:492,y:472,t:1528140033352};\\\", \\\"{x:505,y:470,t:1528140033369};\\\", \\\"{x:523,y:469,t:1528140033386};\\\", \\\"{x:545,y:469,t:1528140033402};\\\", \\\"{x:561,y:469,t:1528140033419};\\\", \\\"{x:569,y:466,t:1528140033435};\\\", \\\"{x:573,y:466,t:1528140033452};\\\", \\\"{x:574,y:465,t:1528140033469};\\\", \\\"{x:574,y:464,t:1528140034830};\\\", \\\"{x:575,y:464,t:1528140034837};\\\", \\\"{x:576,y:463,t:1528140034853};\\\", \\\"{x:576,y:462,t:1528140034871};\\\", \\\"{x:576,y:459,t:1528140034886};\\\", \\\"{x:576,y:458,t:1528140034903};\\\", \\\"{x:577,y:458,t:1528140034920};\\\", \\\"{x:577,y:457,t:1528140034957};\\\", \\\"{x:578,y:456,t:1528140034971};\\\", \\\"{x:580,y:456,t:1528140035197};\\\", \\\"{x:589,y:458,t:1528140035205};\\\", \\\"{x:615,y:469,t:1528140035221};\\\", \\\"{x:643,y:482,t:1528140035237};\\\", \\\"{x:718,y:502,t:1528140035255};\\\", \\\"{x:814,y:528,t:1528140035270};\\\", \\\"{x:926,y:550,t:1528140035286};\\\", \\\"{x:1041,y:590,t:1528140035304};\\\", \\\"{x:1143,y:620,t:1528140035319};\\\", \\\"{x:1240,y:646,t:1528140035336};\\\", \\\"{x:1325,y:678,t:1528140035352};\\\", \\\"{x:1397,y:700,t:1528140035370};\\\", \\\"{x:1453,y:727,t:1528140035387};\\\", \\\"{x:1484,y:740,t:1528140035403};\\\", \\\"{x:1510,y:753,t:1528140035420};\\\", \\\"{x:1532,y:760,t:1528140035437};\\\", \\\"{x:1549,y:764,t:1528140035453};\\\", \\\"{x:1557,y:766,t:1528140035470};\\\", \\\"{x:1559,y:766,t:1528140035487};\\\", \\\"{x:1560,y:766,t:1528140035503};\\\", \\\"{x:1557,y:768,t:1528140035613};\\\", \\\"{x:1556,y:769,t:1528140035621};\\\", \\\"{x:1546,y:773,t:1528140035637};\\\", \\\"{x:1535,y:775,t:1528140035655};\\\", \\\"{x:1529,y:776,t:1528140035671};\\\", \\\"{x:1525,y:778,t:1528140035688};\\\", \\\"{x:1519,y:778,t:1528140035704};\\\", \\\"{x:1515,y:780,t:1528140035720};\\\", \\\"{x:1510,y:780,t:1528140035738};\\\", \\\"{x:1507,y:782,t:1528140035754};\\\", \\\"{x:1503,y:784,t:1528140035771};\\\", \\\"{x:1501,y:784,t:1528140035788};\\\", \\\"{x:1498,y:785,t:1528140035804};\\\", \\\"{x:1495,y:787,t:1528140035820};\\\", \\\"{x:1495,y:788,t:1528140035837};\\\", \\\"{x:1493,y:788,t:1528140035854};\\\", \\\"{x:1489,y:792,t:1528140035877};\\\", \\\"{x:1490,y:792,t:1528140035990};\\\", \\\"{x:1494,y:792,t:1528140036005};\\\", \\\"{x:1498,y:791,t:1528140036021};\\\", \\\"{x:1504,y:788,t:1528140036037};\\\", \\\"{x:1510,y:784,t:1528140036055};\\\", \\\"{x:1513,y:782,t:1528140036071};\\\", \\\"{x:1521,y:780,t:1528140036088};\\\", \\\"{x:1528,y:775,t:1528140036105};\\\", \\\"{x:1536,y:774,t:1528140036122};\\\", \\\"{x:1541,y:774,t:1528140036137};\\\", \\\"{x:1544,y:773,t:1528140036154};\\\", \\\"{x:1545,y:773,t:1528140036172};\\\", \\\"{x:1549,y:773,t:1528140036188};\\\", \\\"{x:1558,y:773,t:1528140036205};\\\", \\\"{x:1562,y:773,t:1528140036221};\\\", \\\"{x:1563,y:773,t:1528140036261};\\\", \\\"{x:1564,y:773,t:1528140036341};\\\", \\\"{x:1564,y:774,t:1528140036355};\\\", \\\"{x:1562,y:776,t:1528140036371};\\\", \\\"{x:1561,y:778,t:1528140036388};\\\", \\\"{x:1560,y:779,t:1528140036405};\\\", \\\"{x:1558,y:783,t:1528140036421};\\\", \\\"{x:1556,y:784,t:1528140036437};\\\", \\\"{x:1553,y:787,t:1528140036455};\\\", \\\"{x:1550,y:791,t:1528140036471};\\\", \\\"{x:1543,y:796,t:1528140036489};\\\", \\\"{x:1538,y:801,t:1528140036505};\\\", \\\"{x:1531,y:806,t:1528140036521};\\\", \\\"{x:1523,y:810,t:1528140036539};\\\", \\\"{x:1511,y:816,t:1528140036555};\\\", \\\"{x:1505,y:820,t:1528140036572};\\\", \\\"{x:1494,y:826,t:1528140036589};\\\", \\\"{x:1486,y:829,t:1528140036607};\\\", \\\"{x:1480,y:831,t:1528140036621};\\\", \\\"{x:1475,y:832,t:1528140036638};\\\", \\\"{x:1474,y:833,t:1528140036654};\\\", \\\"{x:1473,y:833,t:1528140036684};\\\", \\\"{x:1472,y:833,t:1528140036692};\\\", \\\"{x:1471,y:833,t:1528140036708};\\\", \\\"{x:1470,y:833,t:1528140036724};\\\", \\\"{x:1468,y:833,t:1528140036738};\\\", \\\"{x:1465,y:833,t:1528140036754};\\\", \\\"{x:1464,y:833,t:1528140036771};\\\", \\\"{x:1457,y:833,t:1528140036788};\\\", \\\"{x:1455,y:833,t:1528140036804};\\\", \\\"{x:1454,y:833,t:1528140036837};\\\", \\\"{x:1453,y:833,t:1528140036942};\\\", \\\"{x:1453,y:832,t:1528140036955};\\\", \\\"{x:1452,y:824,t:1528140036972};\\\", \\\"{x:1450,y:805,t:1528140036989};\\\", \\\"{x:1448,y:795,t:1528140037005};\\\", \\\"{x:1444,y:780,t:1528140037021};\\\", \\\"{x:1441,y:765,t:1528140037038};\\\", \\\"{x:1438,y:757,t:1528140037054};\\\", \\\"{x:1437,y:751,t:1528140037071};\\\", \\\"{x:1436,y:746,t:1528140037088};\\\", \\\"{x:1435,y:742,t:1528140037105};\\\", \\\"{x:1434,y:736,t:1528140037122};\\\", \\\"{x:1433,y:729,t:1528140037139};\\\", \\\"{x:1431,y:720,t:1528140037155};\\\", \\\"{x:1430,y:710,t:1528140037172};\\\", \\\"{x:1428,y:696,t:1528140037188};\\\", \\\"{x:1425,y:676,t:1528140037205};\\\", \\\"{x:1424,y:664,t:1528140037222};\\\", \\\"{x:1424,y:657,t:1528140037239};\\\", \\\"{x:1423,y:645,t:1528140037256};\\\", \\\"{x:1423,y:631,t:1528140037272};\\\", \\\"{x:1421,y:618,t:1528140037289};\\\", \\\"{x:1421,y:609,t:1528140037306};\\\", \\\"{x:1421,y:602,t:1528140037322};\\\", \\\"{x:1421,y:599,t:1528140037338};\\\", \\\"{x:1421,y:593,t:1528140037356};\\\", \\\"{x:1422,y:585,t:1528140037371};\\\", \\\"{x:1424,y:578,t:1528140037388};\\\", \\\"{x:1425,y:573,t:1528140037405};\\\", \\\"{x:1426,y:567,t:1528140037422};\\\", \\\"{x:1427,y:564,t:1528140037437};\\\", \\\"{x:1428,y:559,t:1528140037455};\\\", \\\"{x:1430,y:556,t:1528140037472};\\\", \\\"{x:1433,y:548,t:1528140037488};\\\", \\\"{x:1435,y:544,t:1528140037505};\\\", \\\"{x:1438,y:540,t:1528140037522};\\\", \\\"{x:1443,y:533,t:1528140037538};\\\", \\\"{x:1445,y:530,t:1528140037555};\\\", \\\"{x:1448,y:525,t:1528140037572};\\\", \\\"{x:1451,y:521,t:1528140037588};\\\", \\\"{x:1454,y:517,t:1528140037605};\\\", \\\"{x:1457,y:513,t:1528140037622};\\\", \\\"{x:1461,y:506,t:1528140037638};\\\", \\\"{x:1466,y:498,t:1528140037656};\\\", \\\"{x:1466,y:491,t:1528140037672};\\\", \\\"{x:1468,y:483,t:1528140037688};\\\", \\\"{x:1468,y:481,t:1528140037705};\\\", \\\"{x:1469,y:476,t:1528140037722};\\\", \\\"{x:1468,y:472,t:1528140037739};\\\", \\\"{x:1468,y:469,t:1528140037755};\\\", \\\"{x:1463,y:465,t:1528140037773};\\\", \\\"{x:1462,y:465,t:1528140037789};\\\", \\\"{x:1461,y:465,t:1528140037813};\\\", \\\"{x:1460,y:465,t:1528140037822};\\\", \\\"{x:1459,y:465,t:1528140037839};\\\", \\\"{x:1458,y:465,t:1528140037877};\\\", \\\"{x:1456,y:465,t:1528140037893};\\\", \\\"{x:1455,y:466,t:1528140037906};\\\", \\\"{x:1455,y:473,t:1528140037922};\\\", \\\"{x:1458,y:486,t:1528140037938};\\\", \\\"{x:1464,y:502,t:1528140037955};\\\", \\\"{x:1487,y:531,t:1528140037973};\\\", \\\"{x:1505,y:549,t:1528140037989};\\\", \\\"{x:1517,y:564,t:1528140038005};\\\", \\\"{x:1534,y:579,t:1528140038022};\\\", \\\"{x:1542,y:590,t:1528140038039};\\\", \\\"{x:1552,y:603,t:1528140038055};\\\", \\\"{x:1556,y:609,t:1528140038072};\\\", \\\"{x:1561,y:622,t:1528140038090};\\\", \\\"{x:1565,y:634,t:1528140038105};\\\", \\\"{x:1572,y:653,t:1528140038123};\\\", \\\"{x:1575,y:666,t:1528140038139};\\\", \\\"{x:1580,y:678,t:1528140038156};\\\", \\\"{x:1585,y:687,t:1528140038173};\\\", \\\"{x:1586,y:695,t:1528140038189};\\\", \\\"{x:1589,y:700,t:1528140038205};\\\", \\\"{x:1594,y:709,t:1528140038223};\\\", \\\"{x:1600,y:719,t:1528140038239};\\\", \\\"{x:1611,y:732,t:1528140038255};\\\", \\\"{x:1614,y:739,t:1528140038273};\\\", \\\"{x:1618,y:744,t:1528140038289};\\\", \\\"{x:1619,y:745,t:1528140038332};\\\", \\\"{x:1621,y:745,t:1528140038356};\\\", \\\"{x:1625,y:742,t:1528140038372};\\\", \\\"{x:1631,y:737,t:1528140038389};\\\", \\\"{x:1639,y:729,t:1528140038406};\\\", \\\"{x:1644,y:718,t:1528140038422};\\\", \\\"{x:1648,y:706,t:1528140038439};\\\", \\\"{x:1651,y:696,t:1528140038456};\\\", \\\"{x:1651,y:695,t:1528140038473};\\\", \\\"{x:1651,y:694,t:1528140038725};\\\", \\\"{x:1649,y:694,t:1528140038740};\\\", \\\"{x:1644,y:697,t:1528140038756};\\\", \\\"{x:1639,y:700,t:1528140038773};\\\", \\\"{x:1637,y:701,t:1528140038789};\\\", \\\"{x:1635,y:702,t:1528140038806};\\\", \\\"{x:1632,y:703,t:1528140038822};\\\", \\\"{x:1631,y:703,t:1528140038840};\\\", \\\"{x:1629,y:704,t:1528140038917};\\\", \\\"{x:1628,y:704,t:1528140038957};\\\", \\\"{x:1627,y:705,t:1528140038997};\\\", \\\"{x:1626,y:705,t:1528140039029};\\\", \\\"{x:1625,y:705,t:1528140039053};\\\", \\\"{x:1624,y:705,t:1528140039421};\\\", \\\"{x:1623,y:705,t:1528140040293};\\\", \\\"{x:1622,y:705,t:1528140041077};\\\", \\\"{x:1621,y:705,t:1528140041165};\\\", \\\"{x:1620,y:704,t:1528140041189};\\\", \\\"{x:1620,y:703,t:1528140041364};\\\", \\\"{x:1619,y:703,t:1528140042270};\\\", \\\"{x:1619,y:702,t:1528140047933};\\\", \\\"{x:1618,y:701,t:1528140047948};\\\", \\\"{x:1617,y:699,t:1528140047980};\\\", \\\"{x:1617,y:697,t:1528140047997};\\\", \\\"{x:1615,y:695,t:1528140048013};\\\", \\\"{x:1614,y:695,t:1528140048213};\\\", \\\"{x:1611,y:696,t:1528140048230};\\\", \\\"{x:1610,y:697,t:1528140048247};\\\", \\\"{x:1610,y:698,t:1528140048263};\\\", \\\"{x:1609,y:698,t:1528140048280};\\\", \\\"{x:1607,y:698,t:1528140048302};\\\", \\\"{x:1606,y:701,t:1528140048317};\\\", \\\"{x:1605,y:701,t:1528140048329};\\\", \\\"{x:1604,y:702,t:1528140048364};\\\", \\\"{x:1603,y:702,t:1528140048380};\\\", \\\"{x:1601,y:707,t:1528140048396};\\\", \\\"{x:1600,y:708,t:1528140048413};\\\", \\\"{x:1598,y:711,t:1528140048429};\\\", \\\"{x:1597,y:712,t:1528140048447};\\\", \\\"{x:1597,y:714,t:1528140048463};\\\", \\\"{x:1595,y:716,t:1528140048480};\\\", \\\"{x:1593,y:721,t:1528140048497};\\\", \\\"{x:1592,y:725,t:1528140048513};\\\", \\\"{x:1591,y:729,t:1528140048530};\\\", \\\"{x:1590,y:731,t:1528140048546};\\\", \\\"{x:1590,y:732,t:1528140048563};\\\", \\\"{x:1588,y:735,t:1528140048580};\\\", \\\"{x:1587,y:738,t:1528140048596};\\\", \\\"{x:1586,y:740,t:1528140048614};\\\", \\\"{x:1586,y:741,t:1528140048630};\\\", \\\"{x:1585,y:742,t:1528140048647};\\\", \\\"{x:1584,y:743,t:1528140048664};\\\", \\\"{x:1583,y:746,t:1528140048680};\\\", \\\"{x:1583,y:747,t:1528140048697};\\\", \\\"{x:1582,y:749,t:1528140048714};\\\", \\\"{x:1582,y:750,t:1528140048730};\\\", \\\"{x:1580,y:752,t:1528140048747};\\\", \\\"{x:1580,y:753,t:1528140048773};\\\", \\\"{x:1580,y:754,t:1528140048789};\\\", \\\"{x:1579,y:757,t:1528140048796};\\\", \\\"{x:1578,y:758,t:1528140048814};\\\", \\\"{x:1577,y:761,t:1528140048830};\\\", \\\"{x:1575,y:762,t:1528140048847};\\\", \\\"{x:1575,y:763,t:1528140048864};\\\", \\\"{x:1575,y:764,t:1528140048881};\\\", \\\"{x:1574,y:765,t:1528140048896};\\\", \\\"{x:1574,y:767,t:1528140048914};\\\", \\\"{x:1574,y:768,t:1528140048930};\\\", \\\"{x:1571,y:771,t:1528140048947};\\\", \\\"{x:1571,y:772,t:1528140048964};\\\", \\\"{x:1571,y:773,t:1528140048981};\\\", \\\"{x:1570,y:774,t:1528140048997};\\\", \\\"{x:1569,y:777,t:1528140049014};\\\", \\\"{x:1568,y:777,t:1528140049031};\\\", \\\"{x:1568,y:779,t:1528140049047};\\\", \\\"{x:1567,y:780,t:1528140049063};\\\", \\\"{x:1566,y:781,t:1528140049080};\\\", \\\"{x:1564,y:784,t:1528140049100};\\\", \\\"{x:1563,y:786,t:1528140049124};\\\", \\\"{x:1561,y:788,t:1528140049133};\\\", \\\"{x:1560,y:791,t:1528140049147};\\\", \\\"{x:1555,y:795,t:1528140049164};\\\", \\\"{x:1555,y:796,t:1528140049181};\\\", \\\"{x:1554,y:798,t:1528140049197};\\\", \\\"{x:1551,y:800,t:1528140049214};\\\", \\\"{x:1550,y:803,t:1528140049230};\\\", \\\"{x:1550,y:807,t:1528140049247};\\\", \\\"{x:1548,y:813,t:1528140049264};\\\", \\\"{x:1545,y:818,t:1528140049281};\\\", \\\"{x:1544,y:818,t:1528140049308};\\\", \\\"{x:1544,y:819,t:1528140049316};\\\", \\\"{x:1544,y:820,t:1528140049332};\\\", \\\"{x:1544,y:821,t:1528140049348};\\\", \\\"{x:1543,y:823,t:1528140049364};\\\", \\\"{x:1539,y:833,t:1528140049381};\\\", \\\"{x:1534,y:840,t:1528140049398};\\\", \\\"{x:1533,y:841,t:1528140049414};\\\", \\\"{x:1533,y:844,t:1528140049431};\\\", \\\"{x:1533,y:845,t:1528140049469};\\\", \\\"{x:1533,y:847,t:1528140049481};\\\", \\\"{x:1529,y:856,t:1528140049498};\\\", \\\"{x:1522,y:867,t:1528140049514};\\\", \\\"{x:1520,y:871,t:1528140049531};\\\", \\\"{x:1516,y:878,t:1528140049548};\\\", \\\"{x:1511,y:883,t:1528140049563};\\\", \\\"{x:1508,y:890,t:1528140049581};\\\", \\\"{x:1503,y:897,t:1528140049597};\\\", \\\"{x:1498,y:904,t:1528140049614};\\\", \\\"{x:1490,y:915,t:1528140049631};\\\", \\\"{x:1485,y:924,t:1528140049647};\\\", \\\"{x:1483,y:929,t:1528140049664};\\\", \\\"{x:1481,y:933,t:1528140049681};\\\", \\\"{x:1479,y:937,t:1528140049698};\\\", \\\"{x:1477,y:940,t:1528140049714};\\\", \\\"{x:1475,y:942,t:1528140049730};\\\", \\\"{x:1473,y:945,t:1528140049748};\\\", \\\"{x:1472,y:948,t:1528140049764};\\\", \\\"{x:1472,y:949,t:1528140049789};\\\", \\\"{x:1472,y:950,t:1528140049853};\\\", \\\"{x:1472,y:951,t:1528140049869};\\\", \\\"{x:1472,y:952,t:1528140049881};\\\", \\\"{x:1471,y:954,t:1528140049898};\\\", \\\"{x:1471,y:955,t:1528140049915};\\\", \\\"{x:1471,y:956,t:1528140049932};\\\", \\\"{x:1471,y:958,t:1528140049949};\\\", \\\"{x:1471,y:960,t:1528140049965};\\\", \\\"{x:1472,y:962,t:1528140050013};\\\", \\\"{x:1473,y:962,t:1528140050029};\\\", \\\"{x:1474,y:962,t:1528140050181};\\\", \\\"{x:1475,y:962,t:1528140050245};\\\", \\\"{x:1477,y:962,t:1528140050333};\\\", \\\"{x:1477,y:959,t:1528140050349};\\\", \\\"{x:1477,y:954,t:1528140050365};\\\", \\\"{x:1477,y:950,t:1528140050382};\\\", \\\"{x:1477,y:948,t:1528140050398};\\\", \\\"{x:1476,y:947,t:1528140050415};\\\", \\\"{x:1476,y:945,t:1528140050432};\\\", \\\"{x:1476,y:944,t:1528140050448};\\\", \\\"{x:1476,y:942,t:1528140050469};\\\", \\\"{x:1475,y:942,t:1528140050482};\\\", \\\"{x:1475,y:941,t:1528140050498};\\\", \\\"{x:1475,y:939,t:1528140050541};\\\", \\\"{x:1474,y:938,t:1528140050548};\\\", \\\"{x:1473,y:935,t:1528140050565};\\\", \\\"{x:1473,y:934,t:1528140050582};\\\", \\\"{x:1472,y:933,t:1528140050598};\\\", \\\"{x:1469,y:928,t:1528140050615};\\\", \\\"{x:1469,y:927,t:1528140050632};\\\", \\\"{x:1468,y:925,t:1528140050648};\\\", \\\"{x:1465,y:923,t:1528140050665};\\\", \\\"{x:1461,y:920,t:1528140050682};\\\", \\\"{x:1458,y:915,t:1528140050699};\\\", \\\"{x:1456,y:908,t:1528140050715};\\\", \\\"{x:1450,y:900,t:1528140050733};\\\", \\\"{x:1446,y:893,t:1528140050749};\\\", \\\"{x:1443,y:890,t:1528140050765};\\\", \\\"{x:1442,y:888,t:1528140050782};\\\", \\\"{x:1441,y:885,t:1528140050799};\\\", \\\"{x:1440,y:884,t:1528140050815};\\\", \\\"{x:1438,y:880,t:1528140050832};\\\", \\\"{x:1436,y:877,t:1528140050849};\\\", \\\"{x:1436,y:875,t:1528140050865};\\\", \\\"{x:1435,y:873,t:1528140050883};\\\", \\\"{x:1433,y:871,t:1528140050899};\\\", \\\"{x:1433,y:869,t:1528140050915};\\\", \\\"{x:1431,y:867,t:1528140050933};\\\", \\\"{x:1429,y:862,t:1528140050949};\\\", \\\"{x:1428,y:858,t:1528140050965};\\\", \\\"{x:1426,y:853,t:1528140050982};\\\", \\\"{x:1426,y:850,t:1528140050999};\\\", \\\"{x:1423,y:845,t:1528140051016};\\\", \\\"{x:1421,y:840,t:1528140051033};\\\", \\\"{x:1421,y:836,t:1528140051049};\\\", \\\"{x:1420,y:829,t:1528140051065};\\\", \\\"{x:1418,y:826,t:1528140051082};\\\", \\\"{x:1415,y:820,t:1528140051099};\\\", \\\"{x:1414,y:816,t:1528140051116};\\\", \\\"{x:1413,y:813,t:1528140051132};\\\", \\\"{x:1411,y:810,t:1528140051148};\\\", \\\"{x:1411,y:808,t:1528140051166};\\\", \\\"{x:1411,y:805,t:1528140051182};\\\", \\\"{x:1410,y:801,t:1528140051199};\\\", \\\"{x:1408,y:796,t:1528140051216};\\\", \\\"{x:1406,y:791,t:1528140051232};\\\", \\\"{x:1405,y:788,t:1528140051249};\\\", \\\"{x:1401,y:783,t:1528140051267};\\\", \\\"{x:1401,y:780,t:1528140051283};\\\", \\\"{x:1399,y:778,t:1528140051300};\\\", \\\"{x:1398,y:775,t:1528140051315};\\\", \\\"{x:1396,y:773,t:1528140051331};\\\", \\\"{x:1395,y:768,t:1528140051348};\\\", \\\"{x:1393,y:763,t:1528140051365};\\\", \\\"{x:1391,y:757,t:1528140051382};\\\", \\\"{x:1388,y:752,t:1528140051398};\\\", \\\"{x:1386,y:748,t:1528140051415};\\\", \\\"{x:1386,y:744,t:1528140051432};\\\", \\\"{x:1384,y:742,t:1528140051449};\\\", \\\"{x:1384,y:741,t:1528140051466};\\\", \\\"{x:1383,y:738,t:1528140051482};\\\", \\\"{x:1382,y:736,t:1528140051499};\\\", \\\"{x:1380,y:735,t:1528140051516};\\\", \\\"{x:1380,y:734,t:1528140051532};\\\", \\\"{x:1378,y:733,t:1528140051549};\\\", \\\"{x:1377,y:731,t:1528140051565};\\\", \\\"{x:1377,y:726,t:1528140051581};\\\", \\\"{x:1374,y:723,t:1528140051598};\\\", \\\"{x:1374,y:722,t:1528140051615};\\\", \\\"{x:1373,y:720,t:1528140051661};\\\", \\\"{x:1373,y:719,t:1528140051669};\\\", \\\"{x:1373,y:718,t:1528140051683};\\\", \\\"{x:1373,y:712,t:1528140051699};\\\", \\\"{x:1373,y:709,t:1528140051716};\\\", \\\"{x:1367,y:700,t:1528140051732};\\\", \\\"{x:1365,y:693,t:1528140051749};\\\", \\\"{x:1361,y:687,t:1528140051767};\\\", \\\"{x:1359,y:683,t:1528140051783};\\\", \\\"{x:1358,y:681,t:1528140051799};\\\", \\\"{x:1355,y:677,t:1528140051816};\\\", \\\"{x:1352,y:671,t:1528140051833};\\\", \\\"{x:1349,y:666,t:1528140051849};\\\", \\\"{x:1347,y:664,t:1528140051866};\\\", \\\"{x:1344,y:659,t:1528140051883};\\\", \\\"{x:1343,y:657,t:1528140051899};\\\", \\\"{x:1342,y:655,t:1528140051916};\\\", \\\"{x:1341,y:654,t:1528140051933};\\\", \\\"{x:1338,y:651,t:1528140051949};\\\", \\\"{x:1333,y:644,t:1528140051966};\\\", \\\"{x:1327,y:637,t:1528140051983};\\\", \\\"{x:1323,y:631,t:1528140051999};\\\", \\\"{x:1318,y:624,t:1528140052015};\\\", \\\"{x:1314,y:618,t:1528140052033};\\\", \\\"{x:1312,y:615,t:1528140052049};\\\", \\\"{x:1308,y:609,t:1528140052066};\\\", \\\"{x:1302,y:602,t:1528140052083};\\\", \\\"{x:1296,y:594,t:1528140052100};\\\", \\\"{x:1295,y:593,t:1528140052116};\\\", \\\"{x:1290,y:585,t:1528140052132};\\\", \\\"{x:1285,y:580,t:1528140052150};\\\", \\\"{x:1283,y:577,t:1528140052166};\\\", \\\"{x:1282,y:576,t:1528140052183};\\\", \\\"{x:1281,y:575,t:1528140052201};\\\", \\\"{x:1280,y:575,t:1528140052269};\\\", \\\"{x:1278,y:575,t:1528140052284};\\\", \\\"{x:1253,y:575,t:1528140052299};\\\", \\\"{x:1231,y:586,t:1528140052315};\\\", \\\"{x:1174,y:589,t:1528140052332};\\\", \\\"{x:1105,y:589,t:1528140052350};\\\", \\\"{x:1024,y:589,t:1528140052366};\\\", \\\"{x:940,y:588,t:1528140052383};\\\", \\\"{x:860,y:579,t:1528140052399};\\\", \\\"{x:813,y:567,t:1528140052415};\\\", \\\"{x:789,y:561,t:1528140052434};\\\", \\\"{x:774,y:552,t:1528140052451};\\\", \\\"{x:746,y:543,t:1528140052467};\\\", \\\"{x:741,y:540,t:1528140052483};\\\", \\\"{x:723,y:536,t:1528140052501};\\\", \\\"{x:707,y:534,t:1528140052517};\\\", \\\"{x:694,y:534,t:1528140052533};\\\", \\\"{x:675,y:531,t:1528140052550};\\\", \\\"{x:660,y:529,t:1528140052567};\\\", \\\"{x:656,y:529,t:1528140052583};\\\", \\\"{x:662,y:529,t:1528140052619};\\\", \\\"{x:666,y:530,t:1528140052634};\\\", \\\"{x:681,y:535,t:1528140052651};\\\", \\\"{x:694,y:538,t:1528140052668};\\\", \\\"{x:696,y:539,t:1528140052684};\\\", \\\"{x:699,y:540,t:1528140052700};\\\", \\\"{x:700,y:540,t:1528140052724};\\\", \\\"{x:696,y:543,t:1528140052789};\\\", \\\"{x:695,y:544,t:1528140052801};\\\", \\\"{x:685,y:549,t:1528140052818};\\\", \\\"{x:674,y:553,t:1528140052835};\\\", \\\"{x:665,y:554,t:1528140052851};\\\", \\\"{x:655,y:557,t:1528140052868};\\\", \\\"{x:651,y:557,t:1528140052885};\\\", \\\"{x:647,y:557,t:1528140052900};\\\", \\\"{x:643,y:557,t:1528140052917};\\\", \\\"{x:641,y:557,t:1528140052934};\\\", \\\"{x:638,y:552,t:1528140052950};\\\", \\\"{x:635,y:541,t:1528140052968};\\\", \\\"{x:633,y:534,t:1528140052984};\\\", \\\"{x:625,y:518,t:1528140053000};\\\", \\\"{x:617,y:509,t:1528140053018};\\\", \\\"{x:612,y:502,t:1528140053034};\\\", \\\"{x:610,y:500,t:1528140053050};\\\", \\\"{x:611,y:499,t:1528140053148};\\\", \\\"{x:611,y:498,t:1528140053156};\\\", \\\"{x:615,y:497,t:1528140053196};\\\", \\\"{x:624,y:494,t:1528140053204};\\\", \\\"{x:629,y:494,t:1528140053218};\\\", \\\"{x:642,y:498,t:1528140053234};\\\", \\\"{x:662,y:509,t:1528140053251};\\\", \\\"{x:677,y:512,t:1528140053268};\\\", \\\"{x:695,y:518,t:1528140053286};\\\", \\\"{x:708,y:521,t:1528140053301};\\\", \\\"{x:724,y:523,t:1528140053318};\\\", \\\"{x:731,y:523,t:1528140053335};\\\", \\\"{x:734,y:523,t:1528140053351};\\\", \\\"{x:736,y:522,t:1528140053435};\\\", \\\"{x:741,y:519,t:1528140053451};\\\", \\\"{x:749,y:517,t:1528140053469};\\\", \\\"{x:758,y:513,t:1528140053484};\\\", \\\"{x:766,y:510,t:1528140053502};\\\", \\\"{x:777,y:504,t:1528140053517};\\\", \\\"{x:784,y:502,t:1528140053535};\\\", \\\"{x:798,y:499,t:1528140053552};\\\", \\\"{x:819,y:497,t:1528140053568};\\\", \\\"{x:829,y:496,t:1528140053585};\\\", \\\"{x:836,y:494,t:1528140053602};\\\", \\\"{x:839,y:494,t:1528140053619};\\\", \\\"{x:840,y:494,t:1528140053635};\\\", \\\"{x:842,y:494,t:1528140053781};\\\", \\\"{x:843,y:494,t:1528140053788};\\\", \\\"{x:833,y:498,t:1528140053918};\\\", \\\"{x:804,y:508,t:1528140053936};\\\", \\\"{x:774,y:512,t:1528140053951};\\\", \\\"{x:756,y:516,t:1528140053969};\\\", \\\"{x:734,y:518,t:1528140053985};\\\", \\\"{x:724,y:519,t:1528140054001};\\\", \\\"{x:711,y:519,t:1528140054018};\\\", \\\"{x:697,y:521,t:1528140054035};\\\", \\\"{x:694,y:521,t:1528140054052};\\\", \\\"{x:692,y:521,t:1528140054068};\\\", \\\"{x:691,y:521,t:1528140054085};\\\", \\\"{x:688,y:521,t:1528140054116};\\\", \\\"{x:683,y:521,t:1528140054132};\\\", \\\"{x:682,y:521,t:1528140054140};\\\", \\\"{x:678,y:521,t:1528140054156};\\\", \\\"{x:669,y:521,t:1528140054169};\\\", \\\"{x:661,y:521,t:1528140054185};\\\", \\\"{x:654,y:519,t:1528140054201};\\\", \\\"{x:647,y:516,t:1528140054220};\\\", \\\"{x:642,y:514,t:1528140054235};\\\", \\\"{x:641,y:513,t:1528140054308};\\\", \\\"{x:640,y:513,t:1528140054318};\\\", \\\"{x:636,y:510,t:1528140054336};\\\", \\\"{x:633,y:509,t:1528140054352};\\\", \\\"{x:627,y:505,t:1528140054368};\\\", \\\"{x:616,y:501,t:1528140054386};\\\", \\\"{x:604,y:496,t:1528140054401};\\\", \\\"{x:595,y:492,t:1528140054420};\\\", \\\"{x:591,y:490,t:1528140054436};\\\", \\\"{x:588,y:488,t:1528140054452};\\\", \\\"{x:590,y:491,t:1528140054805};\\\", \\\"{x:592,y:491,t:1528140054819};\\\", \\\"{x:597,y:494,t:1528140054835};\\\", \\\"{x:602,y:499,t:1528140054854};\\\", \\\"{x:603,y:499,t:1528140054868};\\\", \\\"{x:604,y:500,t:1528140054891};\\\", \\\"{x:606,y:500,t:1528140055003};\\\", \\\"{x:607,y:501,t:1528140055140};\\\", \\\"{x:606,y:506,t:1528140055152};\\\", \\\"{x:601,y:525,t:1528140055170};\\\", \\\"{x:594,y:544,t:1528140055185};\\\", \\\"{x:587,y:562,t:1528140055203};\\\", \\\"{x:578,y:586,t:1528140055220};\\\", \\\"{x:572,y:606,t:1528140055236};\\\", \\\"{x:554,y:644,t:1528140055253};\\\", \\\"{x:530,y:689,t:1528140055269};\\\", \\\"{x:516,y:713,t:1528140055286};\\\", \\\"{x:507,y:731,t:1528140055303};\\\", \\\"{x:502,y:746,t:1528140055319};\\\", \\\"{x:501,y:751,t:1528140055335};\\\", \\\"{x:500,y:753,t:1528140055353};\\\", \\\"{x:503,y:753,t:1528140055500};\\\", \\\"{x:505,y:751,t:1528140055508};\\\", \\\"{x:506,y:751,t:1528140055520};\\\", \\\"{x:510,y:748,t:1528140055536};\\\", \\\"{x:517,y:743,t:1528140055552};\\\", \\\"{x:522,y:739,t:1528140055569};\\\", \\\"{x:525,y:738,t:1528140055586};\\\", \\\"{x:525,y:744,t:1528140055915};\\\", \\\"{x:522,y:754,t:1528140055924};\\\", \\\"{x:514,y:766,t:1528140055936};\\\", \\\"{x:505,y:787,t:1528140055953};\\\", \\\"{x:498,y:800,t:1528140055970};\\\", \\\"{x:486,y:828,t:1528140055986};\\\", \\\"{x:472,y:865,t:1528140056003};\\\", \\\"{x:467,y:885,t:1528140056019};\\\", \\\"{x:460,y:907,t:1528140056036};\\\", \\\"{x:456,y:920,t:1528140056054};\\\", \\\"{x:456,y:927,t:1528140056069};\\\", \\\"{x:454,y:930,t:1528140056086};\\\" ] }, { \\\"rt\\\": 7294, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 898338, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:457,y:929,t:1528140057600};\\\", \\\"{x:465,y:929,t:1528140058622};\\\", \\\"{x:576,y:945,t:1528140058639};\\\", \\\"{x:739,y:969,t:1528140058655};\\\", \\\"{x:962,y:1021,t:1528140058671};\\\", \\\"{x:1215,y:1081,t:1528140058689};\\\", \\\"{x:1477,y:1170,t:1528140058706};\\\", \\\"{x:1655,y:1199,t:1528140058722};\\\", \\\"{x:1805,y:1199,t:1528140058739};\\\", \\\"{x:1919,y:1199,t:1528140058756};\\\", \\\"{x:1919,y:1193,t:1528140058772};\\\", \\\"{x:1919,y:1176,t:1528140058789};\\\", \\\"{x:1915,y:1155,t:1528140058806};\\\", \\\"{x:1890,y:1108,t:1528140058824};\\\", \\\"{x:1821,y:1038,t:1528140058839};\\\", \\\"{x:1727,y:958,t:1528140058856};\\\", \\\"{x:1650,y:904,t:1528140058873};\\\", \\\"{x:1606,y:868,t:1528140058889};\\\", \\\"{x:1562,y:840,t:1528140058906};\\\", \\\"{x:1547,y:830,t:1528140058924};\\\", \\\"{x:1542,y:827,t:1528140058939};\\\", \\\"{x:1540,y:836,t:1528140058956};\\\", \\\"{x:1540,y:861,t:1528140058972};\\\", \\\"{x:1549,y:889,t:1528140058990};\\\", \\\"{x:1564,y:926,t:1528140059006};\\\", \\\"{x:1577,y:952,t:1528140059023};\\\", \\\"{x:1589,y:968,t:1528140059040};\\\", \\\"{x:1599,y:982,t:1528140059056};\\\", \\\"{x:1603,y:987,t:1528140059073};\\\", \\\"{x:1603,y:989,t:1528140059090};\\\", \\\"{x:1601,y:992,t:1528140059106};\\\", \\\"{x:1593,y:1000,t:1528140059122};\\\", \\\"{x:1589,y:1001,t:1528140059180};\\\", \\\"{x:1587,y:1005,t:1528140059189};\\\", \\\"{x:1586,y:1009,t:1528140059206};\\\", \\\"{x:1587,y:1009,t:1528140059252};\\\", \\\"{x:1588,y:1009,t:1528140059261};\\\", \\\"{x:1590,y:1009,t:1528140059273};\\\", \\\"{x:1599,y:1001,t:1528140059289};\\\", \\\"{x:1610,y:995,t:1528140059306};\\\", \\\"{x:1624,y:986,t:1528140059322};\\\", \\\"{x:1635,y:978,t:1528140059339};\\\", \\\"{x:1642,y:971,t:1528140059357};\\\", \\\"{x:1643,y:970,t:1528140059372};\\\", \\\"{x:1643,y:969,t:1528140059397};\\\", \\\"{x:1641,y:969,t:1528140059420};\\\", \\\"{x:1634,y:964,t:1528140059429};\\\", \\\"{x:1626,y:963,t:1528140059440};\\\", \\\"{x:1612,y:958,t:1528140059457};\\\", \\\"{x:1595,y:957,t:1528140059473};\\\", \\\"{x:1582,y:954,t:1528140059489};\\\", \\\"{x:1578,y:954,t:1528140059506};\\\", \\\"{x:1570,y:954,t:1528140059522};\\\", \\\"{x:1561,y:957,t:1528140059539};\\\", \\\"{x:1549,y:966,t:1528140059556};\\\", \\\"{x:1549,y:968,t:1528140059572};\\\", \\\"{x:1548,y:970,t:1528140059590};\\\", \\\"{x:1548,y:971,t:1528140059613};\\\", \\\"{x:1548,y:970,t:1528140059756};\\\", \\\"{x:1549,y:966,t:1528140059773};\\\", \\\"{x:1551,y:961,t:1528140059789};\\\", \\\"{x:1551,y:960,t:1528140059807};\\\", \\\"{x:1551,y:959,t:1528140059822};\\\", \\\"{x:1551,y:958,t:1528140059909};\\\", \\\"{x:1551,y:957,t:1528140059932};\\\", \\\"{x:1553,y:956,t:1528140059940};\\\", \\\"{x:1554,y:954,t:1528140059957};\\\", \\\"{x:1555,y:954,t:1528140059972};\\\", \\\"{x:1555,y:952,t:1528140059990};\\\", \\\"{x:1557,y:950,t:1528140060014};\\\", \\\"{x:1556,y:950,t:1528140060301};\\\", \\\"{x:1555,y:949,t:1528140060317};\\\", \\\"{x:1553,y:948,t:1528140060324};\\\", \\\"{x:1551,y:947,t:1528140060348};\\\", \\\"{x:1548,y:946,t:1528140060356};\\\", \\\"{x:1546,y:946,t:1528140060372};\\\", \\\"{x:1543,y:944,t:1528140060389};\\\", \\\"{x:1541,y:944,t:1528140060405};\\\", \\\"{x:1540,y:944,t:1528140060423};\\\", \\\"{x:1539,y:943,t:1528140060440};\\\", \\\"{x:1538,y:943,t:1528140060533};\\\", \\\"{x:1537,y:940,t:1528140060949};\\\", \\\"{x:1536,y:938,t:1528140060957};\\\", \\\"{x:1535,y:931,t:1528140060971};\\\", \\\"{x:1532,y:922,t:1528140060988};\\\", \\\"{x:1532,y:921,t:1528140061005};\\\", \\\"{x:1531,y:921,t:1528140061022};\\\", \\\"{x:1531,y:920,t:1528140061038};\\\", \\\"{x:1531,y:919,t:1528140061055};\\\", \\\"{x:1530,y:918,t:1528140061072};\\\", \\\"{x:1529,y:917,t:1528140061115};\\\", \\\"{x:1529,y:916,t:1528140061156};\\\", \\\"{x:1528,y:914,t:1528140061172};\\\", \\\"{x:1527,y:911,t:1528140061188};\\\", \\\"{x:1525,y:907,t:1528140061213};\\\", \\\"{x:1525,y:905,t:1528140061228};\\\", \\\"{x:1525,y:903,t:1528140061238};\\\", \\\"{x:1523,y:900,t:1528140061255};\\\", \\\"{x:1521,y:892,t:1528140061272};\\\", \\\"{x:1521,y:888,t:1528140061289};\\\", \\\"{x:1518,y:880,t:1528140061305};\\\", \\\"{x:1517,y:873,t:1528140061322};\\\", \\\"{x:1512,y:852,t:1528140061339};\\\", \\\"{x:1508,y:840,t:1528140061355};\\\", \\\"{x:1494,y:824,t:1528140061372};\\\", \\\"{x:1490,y:819,t:1528140061388};\\\", \\\"{x:1489,y:817,t:1528140061405};\\\", \\\"{x:1487,y:816,t:1528140061423};\\\", \\\"{x:1487,y:815,t:1528140061438};\\\", \\\"{x:1485,y:814,t:1528140061645};\\\", \\\"{x:1471,y:810,t:1528140061656};\\\", \\\"{x:1378,y:774,t:1528140061673};\\\", \\\"{x:1239,y:721,t:1528140061689};\\\", \\\"{x:1079,y:659,t:1528140061705};\\\", \\\"{x:952,y:598,t:1528140061722};\\\", \\\"{x:846,y:547,t:1528140061740};\\\", \\\"{x:789,y:517,t:1528140061757};\\\", \\\"{x:732,y:480,t:1528140061788};\\\", \\\"{x:733,y:480,t:1528140061851};\\\", \\\"{x:736,y:480,t:1528140061867};\\\", \\\"{x:738,y:480,t:1528140061876};\\\", \\\"{x:744,y:480,t:1528140061891};\\\", \\\"{x:750,y:480,t:1528140061908};\\\", \\\"{x:753,y:483,t:1528140061925};\\\", \\\"{x:756,y:487,t:1528140061942};\\\", \\\"{x:754,y:495,t:1528140061957};\\\", \\\"{x:753,y:503,t:1528140061974};\\\", \\\"{x:747,y:514,t:1528140061991};\\\", \\\"{x:737,y:527,t:1528140062009};\\\", \\\"{x:725,y:540,t:1528140062025};\\\", \\\"{x:718,y:550,t:1528140062043};\\\", \\\"{x:715,y:552,t:1528140062059};\\\", \\\"{x:711,y:554,t:1528140062074};\\\", \\\"{x:708,y:555,t:1528140062092};\\\", \\\"{x:706,y:556,t:1528140062132};\\\", \\\"{x:705,y:556,t:1528140062142};\\\", \\\"{x:703,y:558,t:1528140062158};\\\", \\\"{x:702,y:558,t:1528140062175};\\\", \\\"{x:697,y:559,t:1528140062192};\\\", \\\"{x:691,y:561,t:1528140062209};\\\", \\\"{x:685,y:562,t:1528140062225};\\\", \\\"{x:678,y:563,t:1528140062243};\\\", \\\"{x:674,y:566,t:1528140062258};\\\", \\\"{x:670,y:567,t:1528140062275};\\\", \\\"{x:663,y:571,t:1528140062291};\\\", \\\"{x:660,y:572,t:1528140062308};\\\", \\\"{x:658,y:573,t:1528140062325};\\\", \\\"{x:657,y:573,t:1528140062403};\\\", \\\"{x:656,y:573,t:1528140062411};\\\", \\\"{x:655,y:573,t:1528140062425};\\\", \\\"{x:650,y:576,t:1528140062442};\\\", \\\"{x:648,y:576,t:1528140062459};\\\", \\\"{x:646,y:576,t:1528140062475};\\\", \\\"{x:645,y:576,t:1528140062868};\\\", \\\"{x:644,y:579,t:1528140062876};\\\", \\\"{x:635,y:586,t:1528140062892};\\\", \\\"{x:628,y:595,t:1528140062910};\\\", \\\"{x:604,y:613,t:1528140062927};\\\", \\\"{x:590,y:621,t:1528140062942};\\\", \\\"{x:588,y:623,t:1528140062958};\\\", \\\"{x:588,y:622,t:1528140062995};\\\", \\\"{x:588,y:618,t:1528140063009};\\\", \\\"{x:589,y:609,t:1528140063026};\\\", \\\"{x:590,y:604,t:1528140063041};\\\", \\\"{x:590,y:599,t:1528140063059};\\\", \\\"{x:594,y:591,t:1528140063076};\\\", \\\"{x:600,y:583,t:1528140063093};\\\", \\\"{x:606,y:574,t:1528140063108};\\\", \\\"{x:610,y:571,t:1528140063126};\\\", \\\"{x:615,y:567,t:1528140063143};\\\", \\\"{x:617,y:566,t:1528140063159};\\\", \\\"{x:619,y:565,t:1528140063176};\\\", \\\"{x:619,y:564,t:1528140063235};\\\", \\\"{x:617,y:565,t:1528140063429};\\\", \\\"{x:613,y:570,t:1528140063444};\\\", \\\"{x:609,y:577,t:1528140063459};\\\", \\\"{x:607,y:581,t:1528140063476};\\\", \\\"{x:607,y:585,t:1528140063747};\\\", \\\"{x:603,y:595,t:1528140063760};\\\", \\\"{x:597,y:613,t:1528140063777};\\\", \\\"{x:589,y:636,t:1528140063793};\\\", \\\"{x:581,y:660,t:1528140063810};\\\", \\\"{x:575,y:686,t:1528140063826};\\\", \\\"{x:564,y:707,t:1528140063843};\\\", \\\"{x:557,y:725,t:1528140063861};\\\", \\\"{x:555,y:728,t:1528140063876};\\\", \\\"{x:555,y:729,t:1528140063964};\\\", \\\"{x:555,y:731,t:1528140063977};\\\", \\\"{x:552,y:736,t:1528140063993};\\\", \\\"{x:549,y:742,t:1528140064010};\\\", \\\"{x:544,y:745,t:1528140064027};\\\", \\\"{x:542,y:746,t:1528140064043};\\\", \\\"{x:541,y:746,t:1528140064164};\\\", \\\"{x:540,y:747,t:1528140064428};\\\", \\\"{x:540,y:753,t:1528140064443};\\\", \\\"{x:539,y:769,t:1528140064459};\\\", \\\"{x:535,y:795,t:1528140064477};\\\", \\\"{x:523,y:830,t:1528140064494};\\\", \\\"{x:517,y:847,t:1528140064510};\\\", \\\"{x:517,y:862,t:1528140064527};\\\", \\\"{x:517,y:873,t:1528140064544};\\\", \\\"{x:518,y:880,t:1528140064560};\\\", \\\"{x:519,y:889,t:1528140064577};\\\", \\\"{x:521,y:891,t:1528140064594};\\\", \\\"{x:521,y:892,t:1528140064627};\\\", \\\"{x:521,y:893,t:1528140064869};\\\" ] }, { \\\"rt\\\": 16740, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 916358, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-X -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:893,t:1528140070240};\\\", \\\"{x:529,y:889,t:1528140070252};\\\", \\\"{x:554,y:878,t:1528140070269};\\\", \\\"{x:605,y:860,t:1528140070285};\\\", \\\"{x:691,y:837,t:1528140070302};\\\", \\\"{x:785,y:826,t:1528140070319};\\\", \\\"{x:941,y:808,t:1528140070336};\\\", \\\"{x:1056,y:798,t:1528140070353};\\\", \\\"{x:1166,y:788,t:1528140070369};\\\", \\\"{x:1267,y:784,t:1528140070385};\\\", \\\"{x:1313,y:787,t:1528140070402};\\\", \\\"{x:1338,y:794,t:1528140070419};\\\", \\\"{x:1352,y:807,t:1528140070435};\\\", \\\"{x:1359,y:818,t:1528140070452};\\\", \\\"{x:1362,y:829,t:1528140070469};\\\", \\\"{x:1362,y:836,t:1528140070487};\\\", \\\"{x:1362,y:843,t:1528140070502};\\\", \\\"{x:1362,y:877,t:1528140070520};\\\", \\\"{x:1367,y:907,t:1528140070537};\\\", \\\"{x:1374,y:936,t:1528140070553};\\\", \\\"{x:1378,y:942,t:1528140070569};\\\", \\\"{x:1379,y:945,t:1528140070586};\\\", \\\"{x:1379,y:949,t:1528140070665};\\\", \\\"{x:1379,y:950,t:1528140070673};\\\", \\\"{x:1379,y:953,t:1528140070686};\\\", \\\"{x:1378,y:959,t:1528140070702};\\\", \\\"{x:1377,y:972,t:1528140070719};\\\", \\\"{x:1377,y:979,t:1528140070735};\\\", \\\"{x:1379,y:985,t:1528140070751};\\\", \\\"{x:1382,y:986,t:1528140070769};\\\", \\\"{x:1383,y:986,t:1528140070790};\\\", \\\"{x:1384,y:986,t:1528140070801};\\\", \\\"{x:1388,y:984,t:1528140070819};\\\", \\\"{x:1391,y:979,t:1528140070836};\\\", \\\"{x:1394,y:976,t:1528140070852};\\\", \\\"{x:1396,y:975,t:1528140070869};\\\", \\\"{x:1396,y:974,t:1528140070886};\\\", \\\"{x:1398,y:974,t:1528140070903};\\\", \\\"{x:1400,y:973,t:1528140070920};\\\", \\\"{x:1401,y:972,t:1528140070936};\\\", \\\"{x:1403,y:972,t:1528140070953};\\\", \\\"{x:1409,y:972,t:1528140070969};\\\", \\\"{x:1416,y:972,t:1528140070987};\\\", \\\"{x:1431,y:972,t:1528140071003};\\\", \\\"{x:1436,y:972,t:1528140071021};\\\", \\\"{x:1442,y:972,t:1528140071036};\\\", \\\"{x:1447,y:972,t:1528140071052};\\\", \\\"{x:1449,y:973,t:1528140071069};\\\", \\\"{x:1453,y:973,t:1528140071086};\\\", \\\"{x:1458,y:973,t:1528140071103};\\\", \\\"{x:1459,y:973,t:1528140071127};\\\", \\\"{x:1460,y:973,t:1528140071135};\\\", \\\"{x:1462,y:973,t:1528140071153};\\\", \\\"{x:1463,y:972,t:1528140071169};\\\", \\\"{x:1466,y:972,t:1528140071185};\\\", \\\"{x:1468,y:971,t:1528140071203};\\\", \\\"{x:1470,y:969,t:1528140071456};\\\", \\\"{x:1471,y:969,t:1528140071470};\\\", \\\"{x:1473,y:968,t:1528140071487};\\\", \\\"{x:1477,y:965,t:1528140071504};\\\", \\\"{x:1480,y:961,t:1528140071520};\\\", \\\"{x:1483,y:955,t:1528140071536};\\\", \\\"{x:1483,y:953,t:1528140071553};\\\", \\\"{x:1484,y:953,t:1528140071570};\\\", \\\"{x:1486,y:953,t:1528140071586};\\\", \\\"{x:1488,y:951,t:1528140071603};\\\", \\\"{x:1488,y:950,t:1528140071680};\\\", \\\"{x:1489,y:950,t:1528140071720};\\\", \\\"{x:1488,y:951,t:1528140071800};\\\", \\\"{x:1487,y:951,t:1528140071808};\\\", \\\"{x:1486,y:951,t:1528140071821};\\\", \\\"{x:1484,y:951,t:1528140071838};\\\", \\\"{x:1483,y:951,t:1528140071856};\\\", \\\"{x:1482,y:952,t:1528140071895};\\\", \\\"{x:1482,y:953,t:1528140072168};\\\", \\\"{x:1480,y:954,t:1528140072176};\\\", \\\"{x:1479,y:953,t:1528140072400};\\\", \\\"{x:1479,y:950,t:1528140072408};\\\", \\\"{x:1478,y:946,t:1528140072420};\\\", \\\"{x:1478,y:938,t:1528140072437};\\\", \\\"{x:1478,y:934,t:1528140072454};\\\", \\\"{x:1477,y:930,t:1528140072470};\\\", \\\"{x:1477,y:927,t:1528140072488};\\\", \\\"{x:1477,y:922,t:1528140072504};\\\", \\\"{x:1477,y:920,t:1528140072521};\\\", \\\"{x:1477,y:916,t:1528140072538};\\\", \\\"{x:1477,y:912,t:1528140072554};\\\", \\\"{x:1477,y:910,t:1528140072572};\\\", \\\"{x:1478,y:907,t:1528140072587};\\\", \\\"{x:1478,y:906,t:1528140072604};\\\", \\\"{x:1480,y:900,t:1528140072622};\\\", \\\"{x:1481,y:896,t:1528140072637};\\\", \\\"{x:1482,y:889,t:1528140072654};\\\", \\\"{x:1485,y:880,t:1528140072671};\\\", \\\"{x:1486,y:879,t:1528140072687};\\\", \\\"{x:1488,y:871,t:1528140072704};\\\", \\\"{x:1488,y:870,t:1528140072721};\\\", \\\"{x:1489,y:868,t:1528140072737};\\\", \\\"{x:1489,y:866,t:1528140072755};\\\", \\\"{x:1490,y:864,t:1528140072771};\\\", \\\"{x:1491,y:864,t:1528140072787};\\\", \\\"{x:1491,y:863,t:1528140072804};\\\", \\\"{x:1492,y:861,t:1528140072821};\\\", \\\"{x:1492,y:860,t:1528140072837};\\\", \\\"{x:1492,y:856,t:1528140072854};\\\", \\\"{x:1493,y:852,t:1528140072871};\\\", \\\"{x:1495,y:849,t:1528140072887};\\\", \\\"{x:1496,y:847,t:1528140072904};\\\", \\\"{x:1498,y:844,t:1528140072921};\\\", \\\"{x:1499,y:841,t:1528140072937};\\\", \\\"{x:1499,y:839,t:1528140072954};\\\", \\\"{x:1499,y:838,t:1528140072971};\\\", \\\"{x:1499,y:836,t:1528140072987};\\\", \\\"{x:1499,y:835,t:1528140073004};\\\", \\\"{x:1499,y:832,t:1528140073022};\\\", \\\"{x:1499,y:831,t:1528140073048};\\\", \\\"{x:1499,y:830,t:1528140073056};\\\", \\\"{x:1498,y:829,t:1528140073080};\\\", \\\"{x:1496,y:828,t:1528140073152};\\\", \\\"{x:1493,y:826,t:1528140073160};\\\", \\\"{x:1492,y:826,t:1528140073172};\\\", \\\"{x:1488,y:825,t:1528140073189};\\\", \\\"{x:1487,y:824,t:1528140073205};\\\", \\\"{x:1486,y:824,t:1528140073472};\\\", \\\"{x:1485,y:824,t:1528140073568};\\\", \\\"{x:1482,y:825,t:1528140073578};\\\", \\\"{x:1481,y:825,t:1528140073606};\\\", \\\"{x:1481,y:824,t:1528140074329};\\\", \\\"{x:1481,y:823,t:1528140074639};\\\", \\\"{x:1481,y:821,t:1528140074655};\\\", \\\"{x:1481,y:820,t:1528140074672};\\\", \\\"{x:1481,y:819,t:1528140074688};\\\", \\\"{x:1481,y:818,t:1528140074705};\\\", \\\"{x:1480,y:818,t:1528140074727};\\\", \\\"{x:1480,y:817,t:1528140074739};\\\", \\\"{x:1479,y:816,t:1528140075200};\\\", \\\"{x:1478,y:816,t:1528140075264};\\\", \\\"{x:1476,y:817,t:1528140075320};\\\", \\\"{x:1475,y:817,t:1528140075376};\\\", \\\"{x:1474,y:818,t:1528140075390};\\\", \\\"{x:1472,y:820,t:1528140075440};\\\", \\\"{x:1471,y:820,t:1528140075463};\\\", \\\"{x:1469,y:821,t:1528140075496};\\\", \\\"{x:1469,y:822,t:1528140075528};\\\", \\\"{x:1470,y:821,t:1528140075952};\\\", \\\"{x:1472,y:821,t:1528140075959};\\\", \\\"{x:1472,y:819,t:1528140075974};\\\", \\\"{x:1474,y:818,t:1528140075991};\\\", \\\"{x:1475,y:817,t:1528140076007};\\\", \\\"{x:1477,y:815,t:1528140076024};\\\", \\\"{x:1478,y:813,t:1528140076048};\\\", \\\"{x:1479,y:813,t:1528140076079};\\\", \\\"{x:1479,y:812,t:1528140076090};\\\", \\\"{x:1481,y:812,t:1528140076107};\\\", \\\"{x:1482,y:812,t:1528140076123};\\\", \\\"{x:1484,y:812,t:1528140076141};\\\", \\\"{x:1485,y:812,t:1528140076158};\\\", \\\"{x:1489,y:814,t:1528140076173};\\\", \\\"{x:1492,y:817,t:1528140076190};\\\", \\\"{x:1496,y:828,t:1528140076206};\\\", \\\"{x:1505,y:840,t:1528140076223};\\\", \\\"{x:1505,y:841,t:1528140076240};\\\", \\\"{x:1506,y:843,t:1528140076256};\\\", \\\"{x:1506,y:844,t:1528140076273};\\\", \\\"{x:1506,y:845,t:1528140076290};\\\", \\\"{x:1506,y:846,t:1528140076343};\\\", \\\"{x:1506,y:847,t:1528140076359};\\\", \\\"{x:1506,y:848,t:1528140076375};\\\", \\\"{x:1506,y:849,t:1528140076390};\\\", \\\"{x:1503,y:851,t:1528140076407};\\\", \\\"{x:1500,y:852,t:1528140076423};\\\", \\\"{x:1497,y:852,t:1528140076447};\\\", \\\"{x:1496,y:852,t:1528140076472};\\\", \\\"{x:1495,y:852,t:1528140076520};\\\", \\\"{x:1493,y:852,t:1528140076527};\\\", \\\"{x:1490,y:852,t:1528140076540};\\\", \\\"{x:1487,y:851,t:1528140076557};\\\", \\\"{x:1484,y:848,t:1528140076574};\\\", \\\"{x:1482,y:845,t:1528140076590};\\\", \\\"{x:1482,y:844,t:1528140076639};\\\", \\\"{x:1482,y:842,t:1528140076728};\\\", \\\"{x:1482,y:841,t:1528140076744};\\\", \\\"{x:1482,y:840,t:1528140076758};\\\", \\\"{x:1481,y:839,t:1528140076774};\\\", \\\"{x:1481,y:838,t:1528140076961};\\\", \\\"{x:1481,y:835,t:1528140076975};\\\", \\\"{x:1481,y:833,t:1528140076991};\\\", \\\"{x:1481,y:829,t:1528140077007};\\\", \\\"{x:1481,y:828,t:1528140077207};\\\", \\\"{x:1481,y:825,t:1528140077224};\\\", \\\"{x:1480,y:822,t:1528140077242};\\\", \\\"{x:1478,y:821,t:1528140077257};\\\", \\\"{x:1478,y:819,t:1528140077275};\\\", \\\"{x:1477,y:818,t:1528140077337};\\\", \\\"{x:1477,y:816,t:1528140077440};\\\", \\\"{x:1477,y:815,t:1528140077455};\\\", \\\"{x:1477,y:814,t:1528140077472};\\\", \\\"{x:1477,y:813,t:1528140077479};\\\", \\\"{x:1477,y:812,t:1528140077503};\\\", \\\"{x:1477,y:811,t:1528140077511};\\\", \\\"{x:1478,y:809,t:1528140077528};\\\", \\\"{x:1478,y:808,t:1528140077541};\\\", \\\"{x:1479,y:805,t:1528140077559};\\\", \\\"{x:1480,y:801,t:1528140077575};\\\", \\\"{x:1483,y:793,t:1528140077592};\\\", \\\"{x:1483,y:787,t:1528140077608};\\\", \\\"{x:1488,y:779,t:1528140077624};\\\", \\\"{x:1492,y:770,t:1528140077642};\\\", \\\"{x:1492,y:764,t:1528140077659};\\\", \\\"{x:1493,y:757,t:1528140077675};\\\", \\\"{x:1493,y:751,t:1528140077691};\\\", \\\"{x:1493,y:746,t:1528140077709};\\\", \\\"{x:1493,y:742,t:1528140077724};\\\", \\\"{x:1493,y:738,t:1528140077741};\\\", \\\"{x:1493,y:735,t:1528140077758};\\\", \\\"{x:1493,y:734,t:1528140077775};\\\", \\\"{x:1493,y:729,t:1528140077792};\\\", \\\"{x:1493,y:727,t:1528140077808};\\\", \\\"{x:1492,y:722,t:1528140077825};\\\", \\\"{x:1491,y:718,t:1528140077841};\\\", \\\"{x:1491,y:713,t:1528140077859};\\\", \\\"{x:1491,y:707,t:1528140077875};\\\", \\\"{x:1491,y:706,t:1528140077891};\\\", \\\"{x:1491,y:705,t:1528140077908};\\\", \\\"{x:1492,y:702,t:1528140077926};\\\", \\\"{x:1492,y:700,t:1528140077942};\\\", \\\"{x:1492,y:698,t:1528140077959};\\\", \\\"{x:1492,y:696,t:1528140077976};\\\", \\\"{x:1492,y:694,t:1528140077992};\\\", \\\"{x:1493,y:692,t:1528140078008};\\\", \\\"{x:1494,y:689,t:1528140078025};\\\", \\\"{x:1494,y:688,t:1528140078041};\\\", \\\"{x:1494,y:686,t:1528140078058};\\\", \\\"{x:1494,y:685,t:1528140078076};\\\", \\\"{x:1494,y:683,t:1528140078091};\\\", \\\"{x:1494,y:682,t:1528140078108};\\\", \\\"{x:1493,y:680,t:1528140078126};\\\", \\\"{x:1493,y:677,t:1528140078141};\\\", \\\"{x:1492,y:675,t:1528140078159};\\\", \\\"{x:1490,y:673,t:1528140078176};\\\", \\\"{x:1490,y:672,t:1528140078233};\\\", \\\"{x:1487,y:670,t:1528140078243};\\\", \\\"{x:1480,y:667,t:1528140078259};\\\", \\\"{x:1477,y:665,t:1528140078276};\\\", \\\"{x:1477,y:664,t:1528140078293};\\\", \\\"{x:1475,y:662,t:1528140078309};\\\", \\\"{x:1472,y:659,t:1528140078325};\\\", \\\"{x:1471,y:658,t:1528140078343};\\\", \\\"{x:1469,y:655,t:1528140078358};\\\", \\\"{x:1467,y:648,t:1528140078376};\\\", \\\"{x:1465,y:637,t:1528140078392};\\\", \\\"{x:1462,y:619,t:1528140078409};\\\", \\\"{x:1461,y:604,t:1528140078426};\\\", \\\"{x:1461,y:584,t:1528140078443};\\\", \\\"{x:1462,y:564,t:1528140078459};\\\", \\\"{x:1462,y:549,t:1528140078475};\\\", \\\"{x:1462,y:535,t:1528140078492};\\\", \\\"{x:1466,y:523,t:1528140078509};\\\", \\\"{x:1466,y:516,t:1528140078525};\\\", \\\"{x:1468,y:512,t:1528140078543};\\\", \\\"{x:1469,y:510,t:1528140078558};\\\", \\\"{x:1469,y:509,t:1528140078575};\\\", \\\"{x:1470,y:508,t:1528140078663};\\\", \\\"{x:1471,y:507,t:1528140078679};\\\", \\\"{x:1471,y:506,t:1528140078692};\\\", \\\"{x:1472,y:505,t:1528140078709};\\\", \\\"{x:1472,y:504,t:1528140078759};\\\", \\\"{x:1473,y:503,t:1528140078775};\\\", \\\"{x:1473,y:502,t:1528140078799};\\\", \\\"{x:1474,y:501,t:1528140078809};\\\", \\\"{x:1474,y:500,t:1528140078825};\\\", \\\"{x:1474,y:498,t:1528140078842};\\\", \\\"{x:1474,y:497,t:1528140078859};\\\", \\\"{x:1474,y:493,t:1528140078875};\\\", \\\"{x:1476,y:484,t:1528140078892};\\\", \\\"{x:1477,y:478,t:1528140078909};\\\", \\\"{x:1481,y:466,t:1528140078925};\\\", \\\"{x:1483,y:457,t:1528140078942};\\\", \\\"{x:1486,y:446,t:1528140078959};\\\", \\\"{x:1490,y:435,t:1528140078975};\\\", \\\"{x:1493,y:426,t:1528140078992};\\\", \\\"{x:1495,y:419,t:1528140079010};\\\", \\\"{x:1496,y:413,t:1528140079026};\\\", \\\"{x:1498,y:405,t:1528140079043};\\\", \\\"{x:1501,y:399,t:1528140079059};\\\", \\\"{x:1505,y:391,t:1528140079076};\\\", \\\"{x:1506,y:386,t:1528140079092};\\\", \\\"{x:1507,y:381,t:1528140079109};\\\", \\\"{x:1509,y:376,t:1528140079126};\\\", \\\"{x:1510,y:371,t:1528140079143};\\\", \\\"{x:1510,y:368,t:1528140079159};\\\", \\\"{x:1510,y:367,t:1528140079176};\\\", \\\"{x:1510,y:366,t:1528140079199};\\\", \\\"{x:1510,y:365,t:1528140079216};\\\", \\\"{x:1510,y:364,t:1528140079226};\\\", \\\"{x:1510,y:362,t:1528140079242};\\\", \\\"{x:1508,y:360,t:1528140079260};\\\", \\\"{x:1507,y:359,t:1528140079276};\\\", \\\"{x:1505,y:355,t:1528140079292};\\\", \\\"{x:1504,y:353,t:1528140079310};\\\", \\\"{x:1503,y:349,t:1528140079326};\\\", \\\"{x:1502,y:345,t:1528140079342};\\\", \\\"{x:1500,y:339,t:1528140079359};\\\", \\\"{x:1498,y:334,t:1528140079376};\\\", \\\"{x:1497,y:330,t:1528140079393};\\\", \\\"{x:1496,y:326,t:1528140079409};\\\", \\\"{x:1494,y:323,t:1528140079426};\\\", \\\"{x:1494,y:319,t:1528140079443};\\\", \\\"{x:1493,y:314,t:1528140079459};\\\", \\\"{x:1493,y:312,t:1528140079476};\\\", \\\"{x:1493,y:310,t:1528140079493};\\\", \\\"{x:1492,y:308,t:1528140079509};\\\", \\\"{x:1492,y:307,t:1528140079527};\\\", \\\"{x:1491,y:307,t:1528140079664};\\\", \\\"{x:1485,y:307,t:1528140079677};\\\", \\\"{x:1468,y:321,t:1528140079694};\\\", \\\"{x:1435,y:341,t:1528140079709};\\\", \\\"{x:1400,y:367,t:1528140079727};\\\", \\\"{x:1282,y:439,t:1528140079744};\\\", \\\"{x:1193,y:502,t:1528140079759};\\\", \\\"{x:1110,y:572,t:1528140079777};\\\", \\\"{x:997,y:652,t:1528140079793};\\\", \\\"{x:915,y:710,t:1528140079809};\\\", \\\"{x:864,y:741,t:1528140079826};\\\", \\\"{x:851,y:751,t:1528140079843};\\\", \\\"{x:850,y:752,t:1528140079860};\\\", \\\"{x:853,y:753,t:1528140079912};\\\", \\\"{x:856,y:754,t:1528140079926};\\\", \\\"{x:864,y:758,t:1528140079943};\\\", \\\"{x:865,y:760,t:1528140079959};\\\", \\\"{x:865,y:759,t:1528140080016};\\\", \\\"{x:864,y:749,t:1528140080027};\\\", \\\"{x:852,y:732,t:1528140080043};\\\", \\\"{x:818,y:700,t:1528140080061};\\\", \\\"{x:789,y:675,t:1528140080077};\\\", \\\"{x:766,y:660,t:1528140080093};\\\", \\\"{x:743,y:652,t:1528140080110};\\\", \\\"{x:722,y:645,t:1528140080128};\\\", \\\"{x:698,y:643,t:1528140080143};\\\", \\\"{x:678,y:642,t:1528140080160};\\\", \\\"{x:656,y:643,t:1528140080176};\\\", \\\"{x:634,y:643,t:1528140080192};\\\", \\\"{x:616,y:643,t:1528140080209};\\\", \\\"{x:606,y:641,t:1528140080226};\\\", \\\"{x:603,y:639,t:1528140080243};\\\", \\\"{x:602,y:638,t:1528140080260};\\\", \\\"{x:601,y:636,t:1528140080276};\\\", \\\"{x:601,y:631,t:1528140080293};\\\", \\\"{x:601,y:623,t:1528140080310};\\\", \\\"{x:597,y:606,t:1528140080327};\\\", \\\"{x:586,y:588,t:1528140080342};\\\", \\\"{x:584,y:584,t:1528140080359};\\\", \\\"{x:583,y:583,t:1528140080376};\\\", \\\"{x:583,y:581,t:1528140080393};\\\", \\\"{x:583,y:580,t:1528140080409};\\\", \\\"{x:586,y:579,t:1528140080439};\\\", \\\"{x:590,y:579,t:1528140080447};\\\", \\\"{x:592,y:579,t:1528140080460};\\\", \\\"{x:597,y:579,t:1528140080477};\\\", \\\"{x:598,y:579,t:1528140080493};\\\", \\\"{x:599,y:579,t:1528140080510};\\\", \\\"{x:602,y:581,t:1528140080528};\\\", \\\"{x:605,y:581,t:1528140080543};\\\", \\\"{x:606,y:583,t:1528140080561};\\\", \\\"{x:608,y:584,t:1528140080577};\\\", \\\"{x:611,y:585,t:1528140080593};\\\", \\\"{x:612,y:586,t:1528140080911};\\\", \\\"{x:606,y:591,t:1528140080926};\\\", \\\"{x:590,y:596,t:1528140080944};\\\", \\\"{x:561,y:597,t:1528140080959};\\\", \\\"{x:539,y:599,t:1528140080977};\\\", \\\"{x:512,y:599,t:1528140080994};\\\", \\\"{x:483,y:597,t:1528140081011};\\\", \\\"{x:460,y:596,t:1528140081027};\\\", \\\"{x:436,y:595,t:1528140081044};\\\", \\\"{x:416,y:595,t:1528140081060};\\\", \\\"{x:396,y:595,t:1528140081076};\\\", \\\"{x:384,y:595,t:1528140081095};\\\", \\\"{x:376,y:595,t:1528140081110};\\\", \\\"{x:367,y:592,t:1528140081127};\\\", \\\"{x:365,y:592,t:1528140081144};\\\", \\\"{x:364,y:592,t:1528140081223};\\\", \\\"{x:363,y:592,t:1528140081239};\\\", \\\"{x:363,y:591,t:1528140081416};\\\", \\\"{x:364,y:591,t:1528140081447};\\\", \\\"{x:366,y:591,t:1528140081462};\\\", \\\"{x:369,y:589,t:1528140081478};\\\", \\\"{x:370,y:589,t:1528140081495};\\\", \\\"{x:374,y:589,t:1528140081512};\\\", \\\"{x:376,y:589,t:1528140081527};\\\", \\\"{x:380,y:589,t:1528140081545};\\\", \\\"{x:382,y:588,t:1528140081562};\\\", \\\"{x:384,y:588,t:1528140081577};\\\", \\\"{x:385,y:588,t:1528140081594};\\\", \\\"{x:386,y:587,t:1528140081648};\\\", \\\"{x:388,y:587,t:1528140081798};\\\", \\\"{x:391,y:595,t:1528140081810};\\\", \\\"{x:400,y:618,t:1528140081829};\\\", \\\"{x:413,y:636,t:1528140081844};\\\", \\\"{x:433,y:655,t:1528140081861};\\\", \\\"{x:449,y:673,t:1528140081877};\\\", \\\"{x:466,y:687,t:1528140081894};\\\", \\\"{x:498,y:711,t:1528140081910};\\\", \\\"{x:512,y:720,t:1528140081928};\\\", \\\"{x:518,y:726,t:1528140081945};\\\", \\\"{x:524,y:729,t:1528140081961};\\\", \\\"{x:525,y:729,t:1528140081978};\\\", \\\"{x:525,y:730,t:1528140082031};\\\", \\\"{x:526,y:732,t:1528140082044};\\\", \\\"{x:528,y:739,t:1528140082062};\\\", \\\"{x:534,y:748,t:1528140082078};\\\", \\\"{x:538,y:756,t:1528140082094};\\\", \\\"{x:541,y:762,t:1528140082111};\\\", \\\"{x:543,y:764,t:1528140082128};\\\", \\\"{x:544,y:767,t:1528140082145};\\\", \\\"{x:544,y:768,t:1528140082161};\\\", \\\"{x:544,y:770,t:1528140082607};\\\", \\\"{x:541,y:775,t:1528140082615};\\\", \\\"{x:538,y:786,t:1528140082628};\\\", \\\"{x:528,y:805,t:1528140082646};\\\", \\\"{x:521,y:828,t:1528140082662};\\\", \\\"{x:515,y:849,t:1528140082678};\\\", \\\"{x:506,y:872,t:1528140082695};\\\", \\\"{x:501,y:890,t:1528140082712};\\\", \\\"{x:495,y:918,t:1528140082729};\\\", \\\"{x:489,y:946,t:1528140082745};\\\", \\\"{x:483,y:962,t:1528140082761};\\\", \\\"{x:479,y:975,t:1528140082778};\\\", \\\"{x:476,y:985,t:1528140082795};\\\", \\\"{x:476,y:990,t:1528140082812};\\\", \\\"{x:475,y:991,t:1528140082828};\\\", \\\"{x:475,y:992,t:1528140082845};\\\", \\\"{x:475,y:993,t:1528140082863};\\\", \\\"{x:476,y:993,t:1528140082959};\\\", \\\"{x:478,y:993,t:1528140083120};\\\", \\\"{x:480,y:993,t:1528140083129};\\\", \\\"{x:482,y:993,t:1528140083146};\\\", \\\"{x:489,y:989,t:1528140083162};\\\", \\\"{x:495,y:986,t:1528140083179};\\\", \\\"{x:495,y:985,t:1528140083196};\\\", \\\"{x:497,y:985,t:1528140083212};\\\", \\\"{x:499,y:983,t:1528140083229};\\\", \\\"{x:511,y:976,t:1528140083246};\\\", \\\"{x:524,y:967,t:1528140083263};\\\", \\\"{x:539,y:956,t:1528140083279};\\\", \\\"{x:543,y:950,t:1528140083296};\\\", \\\"{x:545,y:948,t:1528140083312};\\\", \\\"{x:547,y:946,t:1528140083330};\\\", \\\"{x:548,y:945,t:1528140083350};\\\", \\\"{x:549,y:944,t:1528140083367};\\\", \\\"{x:551,y:942,t:1528140083382};\\\", \\\"{x:554,y:938,t:1528140083396};\\\", \\\"{x:560,y:922,t:1528140083412};\\\", \\\"{x:568,y:905,t:1528140083429};\\\" ] }, { \\\"rt\\\": 82385, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1000024, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"EVENT F AND B HAPPEN AT 12PM AND THIS CAN BE DETERMINED BY NOTING WHAT POINTS FOLLOW WITHIN A HYPOTHETICAL VERTICAL LINE DRAWN THROUGH THE Y AXIS FROM THE 12PM POINT ON THE X AXIS\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11054, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"JAPAN\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1012085, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 18359, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1031454, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 29101, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1061946, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"13RHM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"13RHM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 269, dom: 985, initialDom: 1275",
  "javascriptErrors": []
}