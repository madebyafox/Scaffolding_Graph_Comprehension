var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9c0146f516c939121ca1ff2575e3c752",
  "created": "2018-05-18T11:14:34.2105681-07:00",
  "lastActivity": "2018-05-18T11:15:39.1575681-07:00",
  "pageViews": [
    {
      "id": "05183401901b8782b6c9d0626bdabe05846a4d11",
      "startTime": "2018-05-18T11:14:34.2105681-07:00",
      "endTime": "2018-05-18T11:15:39.1575681-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 64947,
      "engagementTime": 58200,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 64947,
  "engagementTime": 58200,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VXAHZ",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e5e071a4ec5de979b5c49e68e051b8f6",
  "gdpr": false
}