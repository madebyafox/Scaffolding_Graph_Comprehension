var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052954060fa575defceae3e509b3ea99041ae501"] = {
  "startTime": "2018-05-29T22:16:54.0943073Z",
  "websitePageUrl": "/16",
  "visitTime": 240963,
  "engagementTime": 224196,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "dde820a4e327ab024f193a934469d7b0",
    "created": "2018-05-29T22:16:54.0943073+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=FA2ZF",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5859985dd2e5d80e925afea5715e853f",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/dde820a4e327ab024f193a934469d7b0/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 888,
      "e": 888,
      "ty": 6,
      "x": 427,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 427,
      "y": 591
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 358,
      "y": 529
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 29328,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 345,
      "y": 534
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 339,
      "y": 542
    },
    {
      "t": 1503,
      "e": 1503,
      "ty": 41,
      "x": 27192,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3893,
      "e": 3893,
      "ty": 3,
      "x": 339,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3894,
      "e": 3894,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3987,
      "e": 3987,
      "ty": 4,
      "x": 27192,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3987,
      "e": 3987,
      "ty": 5,
      "x": 339,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 388,
      "y": 546
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 32925,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 422,
      "y": 555
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 460,
      "y": 587
    },
    {
      "t": 5926,
      "e": 5926,
      "ty": 7,
      "x": 478,
      "y": 618,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 524,
      "y": 691
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 47988,
      "y": 37836,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 533,
      "y": 837
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 545,
      "y": 840
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 50349,
      "y": 46090,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 560,
      "y": 837
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 644,
      "y": 823
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 61477,
      "y": 45148,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 686,
      "y": 819
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 688,
      "y": 829
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 166,
      "y": 49843,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 677,
      "y": 845
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 666,
      "y": 846
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 642,
      "y": 832
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 61252,
      "y": 45647,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 979,
      "y": 834
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 13601,
      "y": 49849,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 993,
      "y": 845
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 993,
      "y": 855
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 14587,
      "y": 51568,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 999,
      "y": 861
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1036,
      "y": 873
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1045,
      "y": 875
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 18252,
      "y": 52786,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1182,
      "y": 900
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1198,
      "y": 905
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 29104,
      "y": 55292,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1196,
      "y": 922
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1174,
      "y": 936
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 1160,
      "y": 946
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 26356,
      "y": 57871,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1155,
      "y": 949
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1155,
      "y": 950
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 26285,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 1170,
      "y": 931
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1175,
      "y": 921
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 1179,
      "y": 903
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 27694,
      "y": 54791,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 1182,
      "y": 894
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 11007,
      "y": 20024,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 25369,
      "y": 52213,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 2,
      "x": 987,
      "y": 790
    },
    {
      "t": 11362,
      "e": 11362,
      "ty": 6,
      "x": 553,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 470,
      "y": 555
    },
    {
      "t": 11447,
      "e": 11447,
      "ty": 7,
      "x": 440,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 420,
      "y": 507
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 41,
      "x": 36297,
      "y": 28708,
      "ta": "#.strategy > p"
    },
    {
      "t": 11601,
      "e": 11601,
      "ty": 2,
      "x": 415,
      "y": 504
    },
    {
      "t": 11680,
      "e": 11680,
      "ty": 6,
      "x": 414,
      "y": 538,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11700,
      "e": 11700,
      "ty": 2,
      "x": 414,
      "y": 549
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 35398,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11802,
      "e": 11802,
      "ty": 2,
      "x": 412,
      "y": 561
    },
    {
      "t": 11948,
      "e": 11948,
      "ty": 3,
      "x": 412,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 35398,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12036,
      "e": 12036,
      "ty": 4,
      "x": 35398,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12036,
      "e": 12036,
      "ty": 5,
      "x": 412,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 35511,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12301,
      "e": 12301,
      "ty": 2,
      "x": 413,
      "y": 560
    },
    {
      "t": 13072,
      "e": 13072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13073,
      "e": 13073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13135,
      "e": 13135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 13759,
      "e": 13759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13815,
      "e": 13815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 14017,
      "e": 14017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14151,
      "e": 14151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14152,
      "e": 14152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14215,
      "e": 14215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14271,
      "e": 14271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14759,
      "e": 14759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14760,
      "e": 14760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14807,
      "e": 14807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 14902,
      "e": 14902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14904,
      "e": 14904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14967,
      "e": 14967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 15047,
      "e": 15047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15048,
      "e": 15048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15111,
      "e": 15111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 15238,
      "e": 15238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 15239,
      "e": 15239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15295,
      "e": 15295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 15366,
      "e": 15366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15367,
      "e": 15367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15423,
      "e": 15423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15527,
      "e": 15527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15531,
      "e": 15531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15583,
      "e": 15583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 15686,
      "e": 15686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15687,
      "e": 15687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15727,
      "e": 15727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15831,
      "e": 15831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15832,
      "e": 15832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15878,
      "e": 15878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16003,
      "e": 16003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The verti"
    },
    {
      "t": 16007,
      "e": 16007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 16007,
      "e": 16007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16071,
      "e": 16071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 16167,
      "e": 16167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16168,
      "e": 16168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16247,
      "e": 16247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16383,
      "e": 16383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 16480,
      "e": 16480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16480,
      "e": 16480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16542,
      "e": 16542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16599,
      "e": 16599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16599,
      "e": 16599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16663,
      "e": 16663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16927,
      "e": 16927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16929,
      "e": 16929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17007,
      "e": 17007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17672,
      "e": 17672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17673,
      "e": 17673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17727,
      "e": 17727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17879,
      "e": 17879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17880,
      "e": 17880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17951,
      "e": 17951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18127,
      "e": 18127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18128,
      "e": 18128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18184,
      "e": 18184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22704,
      "e": 22704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22705,
      "e": 22705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22751,
      "e": 22751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22824,
      "e": 22824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22824,
      "e": 22824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22903,
      "e": 22903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22991,
      "e": 22991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22992,
      "e": 22992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23047,
      "e": 23047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23191,
      "e": 23191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23192,
      "e": 23192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23255,
      "e": 23255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23367,
      "e": 23367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23367,
      "e": 23367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23415,
      "e": 23415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23495,
      "e": 23495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23496,
      "e": 23496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23550,
      "e": 23550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23631,
      "e": 23631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23631,
      "e": 23631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23703,
      "e": 23703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23804,
      "e": 23804,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the "
    },
    {
      "t": 24752,
      "e": 24752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24753,
      "e": 24753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24806,
      "e": 24806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24910,
      "e": 24910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24911,
      "e": 24911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24967,
      "e": 24967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25071,
      "e": 25071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25072,
      "e": 25072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25134,
      "e": 25134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25222,
      "e": 25222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25223,
      "e": 25223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25295,
      "e": 25295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25360,
      "e": 25360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25360,
      "e": 25360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25415,
      "e": 25415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25647,
      "e": 25647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25648,
      "e": 25648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25695,
      "e": 25695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 25774,
      "e": 25774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 25775,
      "e": 25775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25823,
      "e": 25823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 25975,
      "e": 25975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25976,
      "e": 25976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26023,
      "e": 26023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26135,
      "e": 26135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26137,
      "e": 26137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26224,
      "e": 26224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26479,
      "e": 26479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26480,
      "e": 26480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26534,
      "e": 26534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26634,
      "e": 26634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26634,
      "e": 26634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26690,
      "e": 26690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26787,
      "e": 26787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26788,
      "e": 26788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26850,
      "e": 26850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26938,
      "e": 26938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26938,
      "e": 26938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26994,
      "e": 26994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27083,
      "e": 27083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27083,
      "e": 27083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27138,
      "e": 27138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27226,
      "e": 27226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27227,
      "e": 27227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27307,
      "e": 27307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27379,
      "e": 27379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27379,
      "e": 27379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27442,
      "e": 27442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27514,
      "e": 27514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27515,
      "e": 27515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27587,
      "e": 27587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27691,
      "e": 27691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27692,
      "e": 27692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27754,
      "e": 27754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30005,
      "e": 30005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30683,
      "e": 30683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30684,
      "e": 30684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30746,
      "e": 30746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30810,
      "e": 30810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30810,
      "e": 30810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30866,
      "e": 30866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30963,
      "e": 30963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30964,
      "e": 30964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31026,
      "e": 31026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31122,
      "e": 31122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31122,
      "e": 31122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31171,
      "e": 31171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31331,
      "e": 31331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31332,
      "e": 31332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31386,
      "e": 31386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31490,
      "e": 31490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31492,
      "e": 31492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31554,
      "e": 31554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31682,
      "e": 31682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31683,
      "e": 31683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31738,
      "e": 31738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31834,
      "e": 31834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31835,
      "e": 31835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31899,
      "e": 31899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31963,
      "e": 31963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31963,
      "e": 31963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32034,
      "e": 32034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32156,
      "e": 32156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32156,
      "e": 32156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32219,
      "e": 32219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33058,
      "e": 33058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33130,
      "e": 33130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the point"
    },
    {
      "t": 33258,
      "e": 33258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33258,
      "e": 33258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33346,
      "e": 33346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34027,
      "e": 34027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34027,
      "e": 34027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34066,
      "e": 34066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34206,
      "e": 34206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points "
    },
    {
      "t": 34427,
      "e": 34427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34428,
      "e": 34428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34514,
      "e": 34514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34659,
      "e": 34659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34659,
      "e": 34659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34738,
      "e": 34738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 34947,
      "e": 34947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34949,
      "e": 34949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35010,
      "e": 35010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35163,
      "e": 35163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35164,
      "e": 35164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35218,
      "e": 35218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38883,
      "e": 38883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38938,
      "e": 38938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points are"
    },
    {
      "t": 39050,
      "e": 39050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39131,
      "e": 39131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points ar"
    },
    {
      "t": 39226,
      "e": 39226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39290,
      "e": 39290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points a"
    },
    {
      "t": 39407,
      "e": 39407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points a"
    },
    {
      "t": 39419,
      "e": 39419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39467,
      "e": 39467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points "
    },
    {
      "t": 39607,
      "e": 39607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points "
    },
    {
      "t": 40004,
      "e": 40004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40122,
      "e": 40122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40122,
      "e": 40122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40178,
      "e": 40178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 40323,
      "e": 40323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40323,
      "e": 40323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40369,
      "e": 40369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40514,
      "e": 40514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40514,
      "e": 40514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40571,
      "e": 40571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40659,
      "e": 40659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40659,
      "e": 40659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40722,
      "e": 40722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40970,
      "e": 40970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40971,
      "e": 40971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41026,
      "e": 41026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41170,
      "e": 41170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 41171,
      "e": 41171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41235,
      "e": 41235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 41619,
      "e": 41619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41682,
      "e": 41682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points corre"
    },
    {
      "t": 41806,
      "e": 41806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points corre"
    },
    {
      "t": 41810,
      "e": 41810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42008,
      "e": 42008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and the points corr"
    },
    {
      "t": 42310,
      "e": 42310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42342,
      "e": 42342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42375,
      "e": 42375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42408,
      "e": 42408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42441,
      "e": 42441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42474,
      "e": 42474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42507,
      "e": 42507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42540,
      "e": 42540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42573,
      "e": 42573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42606,
      "e": 42606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42639,
      "e": 42639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42672,
      "e": 42672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42705,
      "e": 42705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42738,
      "e": 42738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42772,
      "e": 42772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42803,
      "e": 42803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and "
    },
    {
      "t": 43995,
      "e": 43995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43995,
      "e": 43995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44058,
      "e": 44058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44146,
      "e": 44146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44146,
      "e": 44146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44201,
      "e": 44201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44306,
      "e": 44306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 44307,
      "e": 44307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44378,
      "e": 44378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 44469,
      "e": 44469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44470,
      "e": 44470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44514,
      "e": 44514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44618,
      "e": 44618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44619,
      "e": 44619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44683,
      "e": 44683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44807,
      "e": 44807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each "
    },
    {
      "t": 44939,
      "e": 44939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 44939,
      "e": 44939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44986,
      "e": 44986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 45099,
      "e": 45099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45102,
      "e": 45102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45154,
      "e": 45154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45275,
      "e": 45275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45275,
      "e": 45275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45330,
      "e": 45330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45427,
      "e": 45427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45427,
      "e": 45427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45482,
      "e": 45482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45537,
      "e": 45537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45538,
      "e": 45538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45602,
      "e": 45602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45682,
      "e": 45682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45684,
      "e": 45684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45738,
      "e": 45738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45923,
      "e": 45923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 45924,
      "e": 45924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45978,
      "e": 45978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 46058,
      "e": 46058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46058,
      "e": 46058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46106,
      "e": 46106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 46208,
      "e": 46208,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point co"
    },
    {
      "t": 46282,
      "e": 46282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46283,
      "e": 46283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46345,
      "e": 46345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46426,
      "e": 46426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46427,
      "e": 46427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46482,
      "e": 46482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46587,
      "e": 46587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46589,
      "e": 46589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46635,
      "e": 46590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46754,
      "e": 46709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46754,
      "e": 46709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46810,
      "e": 46765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 46922,
      "e": 46877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46922,
      "e": 46877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46962,
      "e": 46917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 47090,
      "e": 47045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47091,
      "e": 47046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47137,
      "e": 47092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47250,
      "e": 47205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47250,
      "e": 47205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47306,
      "e": 47261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47408,
      "e": 47363,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point correspon"
    },
    {
      "t": 47434,
      "e": 47389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 47436,
      "e": 47391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47498,
      "e": 47453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 47578,
      "e": 47533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47578,
      "e": 47533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47658,
      "e": 47613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48387,
      "e": 48342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48387,
      "e": 48342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48443,
      "e": 48398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48595,
      "e": 48550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48595,
      "e": 48550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48650,
      "e": 48605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49649,
      "e": 49604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49713,
      "e": 49668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point correspond t"
    },
    {
      "t": 49841,
      "e": 49796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49914,
      "e": 49869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point correspond "
    },
    {
      "t": 50002,
      "e": 49957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50107,
      "e": 50062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point correspond"
    },
    {
      "t": 50403,
      "e": 50358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50403,
      "e": 50358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50474,
      "e": 50429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 50618,
      "e": 50573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50618,
      "e": 50573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50682,
      "e": 50637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50807,
      "e": 50762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds "
    },
    {
      "t": 50955,
      "e": 50910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50956,
      "e": 50911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51009,
      "e": 50964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51138,
      "e": 51093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51138,
      "e": 51093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51194,
      "e": 51149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51330,
      "e": 51285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51332,
      "e": 51287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51410,
      "e": 51365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52378,
      "e": 52333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 52378,
      "e": 52333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52442,
      "e": 52397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 52602,
      "e": 52557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52603,
      "e": 52558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52674,
      "e": 52629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53547,
      "e": 53502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53547,
      "e": 53502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53610,
      "e": 53565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53755,
      "e": 53710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53755,
      "e": 53710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53801,
      "e": 53756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 53954,
      "e": 53909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53955,
      "e": 53910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54002,
      "e": 53957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54131,
      "e": 54086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54131,
      "e": 54086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54186,
      "e": 54141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54258,
      "e": 54213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54258,
      "e": 54213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54322,
      "e": 54277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54619,
      "e": 54574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54620,
      "e": 54575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54689,
      "e": 54644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 54807,
      "e": 54762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points"
    },
    {
      "t": 54858,
      "e": 54813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54859,
      "e": 54814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54929,
      "e": 54884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55419,
      "e": 55374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55419,
      "e": 55374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55474,
      "e": 55374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55562,
      "e": 55462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55562,
      "e": 55462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55626,
      "e": 55526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55675,
      "e": 55575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55675,
      "e": 55575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55738,
      "e": 55638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55826,
      "e": 55726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55827,
      "e": 55727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55890,
      "e": 55790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55954,
      "e": 55854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 55955,
      "e": 55855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56017,
      "e": 55917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 56090,
      "e": 55990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56090,
      "e": 55990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56153,
      "e": 56053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56227,
      "e": 56127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56227,
      "e": 56127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56290,
      "e": 56190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56406,
      "e": 56306,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the "
    },
    {
      "t": 57058,
      "e": 56958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57059,
      "e": 56959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57114,
      "e": 57014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57379,
      "e": 57279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 57379,
      "e": 57279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57433,
      "e": 57333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 57562,
      "e": 57462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57563,
      "e": 57463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57625,
      "e": 57525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 57835,
      "e": 57735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57835,
      "e": 57735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57898,
      "e": 57798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58008,
      "e": 57908,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the hori"
    },
    {
      "t": 58107,
      "e": 58007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 58107,
      "e": 58007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58170,
      "e": 58070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 59091,
      "e": 58991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59091,
      "e": 58991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59185,
      "e": 59085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 59306,
      "e": 59206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59307,
      "e": 59207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59354,
      "e": 59254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 59538,
      "e": 59438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59540,
      "e": 59440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59594,
      "e": 59494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59746,
      "e": 59646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59747,
      "e": 59647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59817,
      "e": 59717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59938,
      "e": 59838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59939,
      "e": 59839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59986,
      "e": 59886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 60122,
      "e": 60022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60123,
      "e": 60023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60193,
      "e": 60093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61890,
      "e": 61790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61891,
      "e": 61791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61953,
      "e": 61853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62122,
      "e": 62022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 62123,
      "e": 62023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62170,
      "e": 62070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 62266,
      "e": 62166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 62266,
      "e": 62166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62322,
      "e": 62222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 62995,
      "e": 62895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62995,
      "e": 62895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63073,
      "e": 62973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63842,
      "e": 63742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 63843,
      "e": 63743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63914,
      "e": 63814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 64026,
      "e": 63926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64026,
      "e": 63926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64098,
      "e": 63998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64207,
      "e": 64107,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, "
    },
    {
      "t": 64275,
      "e": 64175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64275,
      "e": 64175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64330,
      "e": 64230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 64409,
      "e": 64309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 64410,
      "e": 64310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64474,
      "e": 64374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 64608,
      "e": 64508,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, in"
    },
    {
      "t": 64667,
      "e": 64509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 64669,
      "e": 64511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64721,
      "e": 64563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 64801,
      "e": 64643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64801,
      "e": 64643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64865,
      "e": 64707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 64945,
      "e": 64787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 64945,
      "e": 64787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64993,
      "e": 64835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 65162,
      "e": 65004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65163,
      "e": 65005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65242,
      "e": 65084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 65394,
      "e": 65236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65394,
      "e": 65236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65449,
      "e": 65291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 65514,
      "e": 65356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65514,
      "e": 65356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65578,
      "e": 65420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 65658,
      "e": 65500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 65659,
      "e": 65501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65721,
      "e": 65563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 65786,
      "e": 65628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 65786,
      "e": 65628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65842,
      "e": 65684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 65947,
      "e": 65789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65947,
      "e": 65789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66025,
      "e": 65867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66025,
      "e": 65867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66033,
      "e": 65875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 66106,
      "e": 65948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66217,
      "e": 66059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66219,
      "e": 66061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66290,
      "e": 66132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 66345,
      "e": 66187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66345,
      "e": 66187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66434,
      "e": 66276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66530,
      "e": 66372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66531,
      "e": 66373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66585,
      "e": 66427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67907,
      "e": 67749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 67907,
      "e": 67749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67969,
      "e": 67811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 68097,
      "e": 67939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68098,
      "e": 67940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68154,
      "e": 67996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 68354,
      "e": 68196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 68355,
      "e": 68197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68409,
      "e": 68251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 68498,
      "e": 68340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68498,
      "e": 68340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68553,
      "e": 68395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 68658,
      "e": 68500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 68659,
      "e": 68501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68729,
      "e": 68571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 70005,
      "e": 69847,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 71059,
      "e": 70901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71113,
      "e": 70955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the begi"
    },
    {
      "t": 71225,
      "e": 71067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71290,
      "e": 71132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the beg"
    },
    {
      "t": 71386,
      "e": 71228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71441,
      "e": 71283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the be"
    },
    {
      "t": 71529,
      "e": 71371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71594,
      "e": 71436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the b"
    },
    {
      "t": 71922,
      "e": 71764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71938,
      "e": 71780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the "
    },
    {
      "t": 72779,
      "e": 72621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72779,
      "e": 72621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72865,
      "e": 72707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 73066,
      "e": 72908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73067,
      "e": 72909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73121,
      "e": 72963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73258,
      "e": 73100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73259,
      "e": 73101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73347,
      "e": 73189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 73442,
      "e": 73284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 73443,
      "e": 73285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73521,
      "e": 73363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 73641,
      "e": 73483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73642,
      "e": 73484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73713,
      "e": 73555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73810,
      "e": 73652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73810,
      "e": 73652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73873,
      "e": 73715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74008,
      "e": 73850,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start "
    },
    {
      "t": 74058,
      "e": 73900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74059,
      "e": 73901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74145,
      "e": 73987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74225,
      "e": 74067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 74226,
      "e": 74068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74290,
      "e": 74132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 74370,
      "e": 74212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 74371,
      "e": 74213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74434,
      "e": 74214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 74522,
      "e": 74302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74522,
      "e": 74302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74585,
      "e": 74365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74730,
      "e": 74510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74730,
      "e": 74510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74793,
      "e": 74573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74889,
      "e": 74669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 74889,
      "e": 74669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74945,
      "e": 74725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 75034,
      "e": 74814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 75034,
      "e": 74814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75089,
      "e": 74869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 75177,
      "e": 74957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75177,
      "e": 74957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75233,
      "e": 75013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75346,
      "e": 75126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 75347,
      "e": 75127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75402,
      "e": 75182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 75489,
      "e": 75269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 75490,
      "e": 75270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75553,
      "e": 75333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 75723,
      "e": 75503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 75723,
      "e": 75503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75769,
      "e": 75549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 75929,
      "e": 75709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75930,
      "e": 75710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75977,
      "e": 75757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76105,
      "e": 75885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76105,
      "e": 75885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76154,
      "e": 75934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 76258,
      "e": 76038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 76259,
      "e": 76039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76314,
      "e": 76094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 76418,
      "e": 76198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 76419,
      "e": 76199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76482,
      "e": 76262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 76570,
      "e": 76350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76570,
      "e": 76350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76633,
      "e": 76413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 77426,
      "e": 77206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 77427,
      "e": 77207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77473,
      "e": 77253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 77594,
      "e": 77374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77595,
      "e": 77375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77657,
      "e": 77437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80006,
      "e": 79786,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 81113,
      "e": 80893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81185,
      "e": 80965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time."
    },
    {
      "t": 81290,
      "e": 81070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81345,
      "e": 81125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time"
    },
    {
      "t": 81729,
      "e": 81509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81731,
      "e": 81511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81778,
      "e": 81558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81946,
      "e": 81726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 82114,
      "e": 81894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 82114,
      "e": 81894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82177,
      "e": 81957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 82217,
      "e": 81997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 82402,
      "e": 82182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 82403,
      "e": 82183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82449,
      "e": 82229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 82722,
      "e": 82502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 82723,
      "e": 82503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82786,
      "e": 82566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 82890,
      "e": 82670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 82890,
      "e": 82670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82953,
      "e": 82733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 83530,
      "e": 83310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 83530,
      "e": 83310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83593,
      "e": 83373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 84145,
      "e": 83925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84209,
      "e": 83989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (lef"
    },
    {
      "t": 84586,
      "e": 84366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 84586,
      "e": 84366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84649,
      "e": 84429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 84834,
      "e": 84614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 84834,
      "e": 84614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84897,
      "e": 84677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 85006,
      "e": 84786,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-"
    },
    {
      "t": 85506,
      "e": 85286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 85507,
      "e": 85287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85577,
      "e": 85357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 85802,
      "e": 85582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85804,
      "e": 85584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85865,
      "e": 85645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 86026,
      "e": 85806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 86026,
      "e": 85806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86089,
      "e": 85869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 86201,
      "e": 85981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 86202,
      "e": 85982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86266,
      "e": 86046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 86369,
      "e": 86149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 86370,
      "e": 86150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86441,
      "e": 86221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 86782,
      "e": 86562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 86784,
      "e": 86564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86829,
      "e": 86609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;"
    },
    {
      "t": 89302,
      "e": 89082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89303,
      "e": 89083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89357,
      "e": 89137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89453,
      "e": 89233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 89454,
      "e": 89234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89527,
      "e": 89235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 89638,
      "e": 89346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 89639,
      "e": 89347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89694,
      "e": 89402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 89766,
      "e": 89474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 89766,
      "e": 89474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89829,
      "e": 89537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 89894,
      "e": 89602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89894,
      "e": 89602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89959,
      "e": 89667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 90038,
      "e": 89746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90039,
      "e": 89747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90093,
      "e": 89801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90211,
      "e": 89919,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right"
    },
    {
      "t": 90942,
      "e": 90650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 90943,
      "e": 90651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90981,
      "e": 90689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 92174,
      "e": 91882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 92175,
      "e": 91883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92214,
      "e": 91922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 92294,
      "e": 92002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 92295,
      "e": 92003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92366,
      "e": 92074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 92469,
      "e": 92177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 92470,
      "e": 92178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92534,
      "e": 92242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 92670,
      "e": 92378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 92918,
      "e": 92626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 92919,
      "e": 92627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92990,
      "e": 92698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 93270,
      "e": 92978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94542,
      "e": 94250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 94543,
      "e": 94251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94598,
      "e": 94306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 94741,
      "e": 94449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94742,
      "e": 94450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94782,
      "e": 94490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94991,
      "e": 94699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 95310,
      "e": 95018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 95311,
      "e": 95019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95365,
      "e": 95073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 95381,
      "e": 95089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95565,
      "e": 95273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 95566,
      "e": 95274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95622,
      "e": 95330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 95718,
      "e": 95426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95719,
      "e": 95427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95789,
      "e": 95497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 98142,
      "e": 97850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 98144,
      "e": 97852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98205,
      "e": 97913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 98325,
      "e": 98033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 98326,
      "e": 98034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98349,
      "e": 98057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 98574,
      "e": 98282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 98575,
      "e": 98283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98638,
      "e": 98346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 98838,
      "e": 98546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98839,
      "e": 98547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98893,
      "e": 98601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99011,
      "e": 98719,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for "
    },
    {
      "t": 100010,
      "e": 99718,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100069,
      "e": 99777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 100069,
      "e": 99777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100141,
      "e": 99849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 100342,
      "e": 100050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 100343,
      "e": 100051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100398,
      "e": 100106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 100510,
      "e": 100218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 100510,
      "e": 100218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100590,
      "e": 100298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 100638,
      "e": 100346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 100638,
      "e": 100346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100694,
      "e": 100402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 100781,
      "e": 100489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 100781,
      "e": 100489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100838,
      "e": 100546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 101117,
      "e": 100825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 101117,
      "e": 100825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101222,
      "e": 100930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 102582,
      "e": 102290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102653,
      "e": 102361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for event"
    },
    {
      "t": 102998,
      "e": 102706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102999,
      "e": 102707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103045,
      "e": 102753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103430,
      "e": 103138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 103501,
      "e": 103209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for event"
    },
    {
      "t": 103611,
      "e": 103319,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for event"
    },
    {
      "t": 103621,
      "e": 103329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 103622,
      "e": 103330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103717,
      "e": 103425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 103805,
      "e": 103513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103805,
      "e": 103513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103869,
      "e": 103577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 104285,
      "e": 103993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 104285,
      "e": 103993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104350,
      "e": 104058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 104558,
      "e": 104266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 104559,
      "e": 104267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104613,
      "e": 104321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 104757,
      "e": 104465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 104758,
      "e": 104466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104838,
      "e": 104546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 105086,
      "e": 104794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 105087,
      "e": 104795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105149,
      "e": 104857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 105350,
      "e": 105058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 105350,
      "e": 105058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105413,
      "e": 105121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 105502,
      "e": 105210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 105502,
      "e": 105210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105549,
      "e": 105257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 105613,
      "e": 105321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 105615,
      "e": 105323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105693,
      "e": 105401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 105725,
      "e": 105433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 105725,
      "e": 105433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105790,
      "e": 105498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 105870,
      "e": 105578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105871,
      "e": 105579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105925,
      "e": 105633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 106014,
      "e": 105722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 106014,
      "e": 105722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106094,
      "e": 105723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 106212,
      "e": 105841,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting a"
    },
    {
      "t": 106261,
      "e": 105890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 106261,
      "e": 105890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106325,
      "e": 105954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 106406,
      "e": 106035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 106406,
      "e": 106035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106485,
      "e": 106114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 107158,
      "e": 106787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 107158,
      "e": 106787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107213,
      "e": 106842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 107334,
      "e": 106963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 107334,
      "e": 106963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107390,
      "e": 107019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 107790,
      "e": 107419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 107790,
      "e": 107419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107846,
      "e": 107475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 107990,
      "e": 107619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 107992,
      "e": 107621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108045,
      "e": 107674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 108767,
      "e": 108396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 108767,
      "e": 108396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108837,
      "e": 108466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 108989,
      "e": 108618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 108990,
      "e": 108619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109045,
      "e": 108674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 112902,
      "e": 112531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 113213,
      "e": 112842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 113215,
      "e": 112844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113277,
      "e": 112906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 113373,
      "e": 113002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114278,
      "e": 113907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 114279,
      "e": 113908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114357,
      "e": 113986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 114950,
      "e": 114579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 114951,
      "e": 114580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115004,
      "e": 114633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 115133,
      "e": 114762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 115134,
      "e": 114763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115182,
      "e": 114811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 115310,
      "e": 114939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 115311,
      "e": 114940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115365,
      "e": 114994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 115542,
      "e": 115171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 115543,
      "e": 115172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115589,
      "e": 115218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 115710,
      "e": 115339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 115710,
      "e": 115339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115758,
      "e": 115387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 115902,
      "e": 115531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115902,
      "e": 115531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115949,
      "e": 115578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 116445,
      "e": 116074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116447,
      "e": 116076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116501,
      "e": 116130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 116581,
      "e": 116210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116582,
      "e": 116211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116637,
      "e": 116266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116726,
      "e": 116355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 116727,
      "e": 116356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116797,
      "e": 116426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 116885,
      "e": 116514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116886,
      "e": 116515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116950,
      "e": 116579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117054,
      "e": 116683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 117055,
      "e": 116684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117124,
      "e": 116753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 117278,
      "e": 116907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 117278,
      "e": 116907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117349,
      "e": 116978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 117453,
      "e": 117082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 117454,
      "e": 117083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117518,
      "e": 117147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 117630,
      "e": 117259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 117630,
      "e": 117259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117694,
      "e": 117323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 117811,
      "e": 117440,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line"
    },
    {
      "t": 118334,
      "e": 117441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118335,
      "e": 117442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118396,
      "e": 117503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130010,
      "e": 122503,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130069,
      "e": 122503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 130069,
      "e": 122503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130133,
      "e": 122567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 130254,
      "e": 122688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 130254,
      "e": 122688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130308,
      "e": 122742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 130417,
      "e": 122851,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line go"
    },
    {
      "t": 130421,
      "e": 122855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 130421,
      "e": 122855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130476,
      "e": 122910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 130557,
      "e": 122991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 130557,
      "e": 122991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130629,
      "e": 123063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 130701,
      "e": 123135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 130702,
      "e": 123136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130773,
      "e": 123207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 130885,
      "e": 123319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130885,
      "e": 123319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130949,
      "e": 123383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 131069,
      "e": 123503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 131070,
      "e": 123504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131132,
      "e": 123566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 131230,
      "e": 123664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 131230,
      "e": 123664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131276,
      "e": 123710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 131405,
      "e": 123839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131406,
      "e": 123840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131468,
      "e": 123902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136093,
      "e": 128527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 136277,
      "e": 128711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 136278,
      "e": 128712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136333,
      "e": 128767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 136421,
      "e": 128855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 136595,
      "e": 129029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 136595,
      "e": 129029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136653,
      "e": 129087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 136789,
      "e": 129223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 136789,
      "e": 129223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136854,
      "e": 129288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 136973,
      "e": 129407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 136974,
      "e": 129408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137028,
      "e": 129462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 137060,
      "e": 129494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 137061,
      "e": 129495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137125,
      "e": 129559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 139621,
      "e": 132055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 139622,
      "e": 132056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139677,
      "e": 132111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 139811,
      "e": 132245,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-"
    },
    {
      "t": 140009,
      "e": 132443,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 143278,
      "e": 135712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 143278,
      "e": 135712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143348,
      "e": 135782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 143453,
      "e": 135887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 143453,
      "e": 135887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143517,
      "e": 135951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 143629,
      "e": 136063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 143629,
      "e": 136063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 143700,
      "e": 136134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 143811,
      "e": 136245,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-wes"
    },
    {
      "t": 144669,
      "e": 137103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 144716,
      "e": 137150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-we"
    },
    {
      "t": 144821,
      "e": 137255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 144893,
      "e": 137327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-w"
    },
    {
      "t": 145013,
      "e": 137328,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-w"
    },
    {
      "t": 145164,
      "e": 137479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 145245,
      "e": 137560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-"
    },
    {
      "t": 145669,
      "e": 137984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 145670,
      "e": 137985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145716,
      "e": 138031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 145933,
      "e": 138248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 146012,
      "e": 138327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-"
    },
    {
      "t": 146165,
      "e": 138480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 146166,
      "e": 138481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146228,
      "e": 138543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 146324,
      "e": 138639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 146325,
      "e": 138640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146422,
      "e": 138737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 146518,
      "e": 138833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 146518,
      "e": 138833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146580,
      "e": 138895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 146765,
      "e": 139080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 146766,
      "e": 139081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 146824,
      "e": 139139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 147080,
      "e": 139395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 147082,
      "e": 139397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147144,
      "e": 139459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 147312,
      "e": 139627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 147313,
      "e": 139628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147359,
      "e": 139674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 148384,
      "e": 140699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 148472,
      "e": 140700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-east "
    },
    {
      "t": 150231,
      "e": 142459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 150232,
      "e": 142460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150287,
      "e": 142515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 150408,
      "e": 142636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 150409,
      "e": 142637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150456,
      "e": 142684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 150553,
      "e": 142781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 150553,
      "e": 142781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150615,
      "e": 142843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 150712,
      "e": 142940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 150712,
      "e": 142940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150776,
      "e": 143004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 150888,
      "e": 143116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 150889,
      "e": 143117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150951,
      "e": 143179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 151527,
      "e": 143755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 151527,
      "e": 143755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151591,
      "e": 143819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 151711,
      "e": 143939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 151711,
      "e": 143939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151776,
      "e": 144004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 152095,
      "e": 144323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 152095,
      "e": 144323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152168,
      "e": 144396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 152288,
      "e": 144516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 152289,
      "e": 144517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152335,
      "e": 144563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 152792,
      "e": 145020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 152793,
      "e": 145021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152831,
      "e": 145059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 152928,
      "e": 145156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 152928,
      "e": 145156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153015,
      "e": 145243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 153096,
      "e": 145324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 153097,
      "e": 145325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153143,
      "e": 145371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 153256,
      "e": 145484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 153256,
      "e": 145484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153319,
      "e": 145547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 153400,
      "e": 145628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 153402,
      "e": 145630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153463,
      "e": 145691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 153880,
      "e": 146108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 153881,
      "e": 146109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153951,
      "e": 146179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 154024,
      "e": 146252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 154024,
      "e": 146252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154079,
      "e": 146307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 154152,
      "e": 146380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 154153,
      "e": 146381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154232,
      "e": 146460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 154360,
      "e": 146588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 154361,
      "e": 146589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 154400,
      "e": 146628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 155071,
      "e": 147299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 155071,
      "e": 147299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155127,
      "e": 147355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 158640,
      "e": 150868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 158912,
      "e": 151140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 158914,
      "e": 151142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158975,
      "e": 151203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 159128,
      "e": 151356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 159416,
      "e": 151644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 159417,
      "e": 151645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159487,
      "e": 151715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 159614,
      "e": 151715,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-east from 12pm and find M "
    },
    {
      "t": 159896,
      "e": 151997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 159897,
      "e": 151998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159951,
      "e": 152052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 160047,
      "e": 152148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 160047,
      "e": 152148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160112,
      "e": 152213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 160208,
      "e": 152309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 160210,
      "e": 152311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160263,
      "e": 152364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 160359,
      "e": 152460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 160360,
      "e": 152461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160415,
      "e": 152516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 160488,
      "e": 152589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 160680,
      "e": 152781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 160681,
      "e": 152782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 160759,
      "e": 152860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 160847,
      "e": 152948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 161613,
      "e": 153714,
      "ty": 2,
      "x": 425,
      "y": 584
    },
    {
      "t": 161627,
      "e": 153728,
      "ty": 7,
      "x": 425,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 161644,
      "e": 153745,
      "ty": 6,
      "x": 407,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 161660,
      "e": 153761,
      "ty": 7,
      "x": 376,
      "y": 702,
      "ta": "#strategyButton"
    },
    {
      "t": 161712,
      "e": 153813,
      "ty": 2,
      "x": 303,
      "y": 744
    },
    {
      "t": 161763,
      "e": 153864,
      "ty": 41,
      "x": 6621,
      "y": 39332,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 161811,
      "e": 153912,
      "ty": 2,
      "x": 65,
      "y": 753
    },
    {
      "t": 161912,
      "e": 154013,
      "ty": 2,
      "x": 289,
      "y": 664
    },
    {
      "t": 162012,
      "e": 154113,
      "ty": 2,
      "x": 326,
      "y": 637
    },
    {
      "t": 162012,
      "e": 154113,
      "ty": 41,
      "x": 3466,
      "y": 10004,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 162112,
      "e": 154213,
      "ty": 2,
      "x": 343,
      "y": 655
    },
    {
      "t": 162128,
      "e": 154229,
      "ty": 6,
      "x": 347,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 162212,
      "e": 154313,
      "ty": 2,
      "x": 397,
      "y": 665
    },
    {
      "t": 162262,
      "e": 154363,
      "ty": 41,
      "x": 31897,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 162365,
      "e": 154466,
      "ty": 3,
      "x": 397,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 162366,
      "e": 154467,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-east from 12pm and find M and L"
    },
    {
      "t": 162366,
      "e": 154467,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162367,
      "e": 154468,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 162452,
      "e": 154553,
      "ty": 4,
      "x": 31897,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 162469,
      "e": 154570,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 162471,
      "e": 154572,
      "ty": 5,
      "x": 397,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 162477,
      "e": 154578,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 162762,
      "e": 154863,
      "ty": 41,
      "x": 12259,
      "y": 54123,
      "ta": "html > body"
    },
    {
      "t": 162812,
      "e": 154913,
      "ty": 2,
      "x": 240,
      "y": 1199
    },
    {
      "t": 162912,
      "e": 155013,
      "ty": 2,
      "x": 116,
      "y": 1199
    },
    {
      "t": 163012,
      "e": 155113,
      "ty": 2,
      "x": 0,
      "y": 1199
    },
    {
      "t": 163212,
      "e": 155313,
      "ty": 2,
      "x": 309,
      "y": 781
    },
    {
      "t": 163262,
      "e": 155363,
      "ty": 41,
      "x": 11536,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 163311,
      "e": 155412,
      "ty": 2,
      "x": 364,
      "y": 672
    },
    {
      "t": 163413,
      "e": 155514,
      "ty": 2,
      "x": 406,
      "y": 593
    },
    {
      "t": 163478,
      "e": 155579,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 163512,
      "e": 155613,
      "ty": 2,
      "x": 406,
      "y": 590
    },
    {
      "t": 163512,
      "e": 155613,
      "ty": 41,
      "x": 13706,
      "y": 32241,
      "ta": "html > body"
    },
    {
      "t": 164112,
      "e": 156213,
      "ty": 2,
      "x": 443,
      "y": 576
    },
    {
      "t": 164212,
      "e": 156313,
      "ty": 2,
      "x": 978,
      "y": 528
    },
    {
      "t": 164262,
      "e": 156363,
      "ty": 41,
      "x": 43041,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 164312,
      "e": 156413,
      "ty": 2,
      "x": 1008,
      "y": 528
    },
    {
      "t": 164512,
      "e": 156613,
      "ty": 2,
      "x": 1012,
      "y": 534
    },
    {
      "t": 164512,
      "e": 156613,
      "ty": 41,
      "x": 44122,
      "y": 60853,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 164612,
      "e": 156713,
      "ty": 2,
      "x": 1015,
      "y": 552
    },
    {
      "t": 164630,
      "e": 156714,
      "ty": 6,
      "x": 1015,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164712,
      "e": 156796,
      "ty": 2,
      "x": 1015,
      "y": 555
    },
    {
      "t": 164762,
      "e": 156846,
      "ty": 41,
      "x": 44771,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164869,
      "e": 156953,
      "ty": 3,
      "x": 1015,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164870,
      "e": 156954,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164948,
      "e": 157032,
      "ty": 4,
      "x": 44771,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 164948,
      "e": 157032,
      "ty": 5,
      "x": 1015,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 165312,
      "e": 157396,
      "ty": 2,
      "x": 1016,
      "y": 558
    },
    {
      "t": 165412,
      "e": 157496,
      "ty": 2,
      "x": 1021,
      "y": 560
    },
    {
      "t": 165513,
      "e": 157597,
      "ty": 41,
      "x": 46069,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167008,
      "e": 159092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 167008,
      "e": 159092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167063,
      "e": 159147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 167175,
      "e": 159259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 167175,
      "e": 159259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167240,
      "e": 159324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 167621,
      "e": 159705,
      "ty": 7,
      "x": 1005,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 167712,
      "e": 159796,
      "ty": 2,
      "x": 967,
      "y": 612
    },
    {
      "t": 167762,
      "e": 159846,
      "ty": 41,
      "x": 33091,
      "y": 39789,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 167812,
      "e": 159896,
      "ty": 2,
      "x": 960,
      "y": 620
    },
    {
      "t": 167912,
      "e": 159996,
      "ty": 2,
      "x": 952,
      "y": 644
    },
    {
      "t": 167941,
      "e": 160025,
      "ty": 6,
      "x": 951,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168012,
      "e": 160096,
      "ty": 2,
      "x": 946,
      "y": 650
    },
    {
      "t": 168013,
      "e": 160097,
      "ty": 41,
      "x": 29847,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168112,
      "e": 160196,
      "ty": 2,
      "x": 945,
      "y": 657
    },
    {
      "t": 168212,
      "e": 160296,
      "ty": 2,
      "x": 945,
      "y": 658
    },
    {
      "t": 168260,
      "e": 160344,
      "ty": 3,
      "x": 945,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168262,
      "e": 160346,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 168262,
      "e": 160346,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 168263,
      "e": 160347,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168265,
      "e": 160349,
      "ty": 41,
      "x": 29631,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168339,
      "e": 160423,
      "ty": 4,
      "x": 29631,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168339,
      "e": 160423,
      "ty": 5,
      "x": 945,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168712,
      "e": 160796,
      "ty": 2,
      "x": 944,
      "y": 659
    },
    {
      "t": 168762,
      "e": 160846,
      "ty": 41,
      "x": 29415,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170012,
      "e": 162096,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170536,
      "e": 162620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 170672,
      "e": 162756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 170673,
      "e": 162757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170736,
      "e": 162820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 170783,
      "e": 162867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 171120,
      "e": 163204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 171120,
      "e": 163204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171240,
      "e": 163324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 171336,
      "e": 163420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 171336,
      "e": 163420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171415,
      "e": 163499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 171528,
      "e": 163612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 171528,
      "e": 163612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171584,
      "e": 163668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 171768,
      "e": 163852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 171769,
      "e": 163853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171832,
      "e": 163916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 172736,
      "e": 164820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 172783,
      "e": 164867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 172967,
      "e": 165051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 172969,
      "e": 165053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173040,
      "e": 165124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 173732,
      "e": 165816,
      "ty": 3,
      "x": 944,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173804,
      "e": 165888,
      "ty": 4,
      "x": 29415,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173805,
      "e": 165889,
      "ty": 5,
      "x": 944,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174188,
      "e": 166272,
      "ty": 7,
      "x": 998,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174213,
      "e": 166297,
      "ty": 2,
      "x": 1058,
      "y": 683
    },
    {
      "t": 174263,
      "e": 166347,
      "ty": 41,
      "x": 36400,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 174312,
      "e": 166396,
      "ty": 2,
      "x": 1065,
      "y": 684
    },
    {
      "t": 174459,
      "e": 166543,
      "ty": 3,
      "x": 1065,
      "y": 684,
      "ta": "html > body"
    },
    {
      "t": 174459,
      "e": 166543,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 174460,
      "e": 166544,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174539,
      "e": 166623,
      "ty": 4,
      "x": 36400,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 174540,
      "e": 166624,
      "ty": 5,
      "x": 1065,
      "y": 684,
      "ta": "html > body"
    },
    {
      "t": 174613,
      "e": 166697,
      "ty": 2,
      "x": 1062,
      "y": 686
    },
    {
      "t": 174713,
      "e": 166797,
      "ty": 2,
      "x": 1024,
      "y": 692
    },
    {
      "t": 174722,
      "e": 166806,
      "ty": 6,
      "x": 1021,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174762,
      "e": 166846,
      "ty": 41,
      "x": 58279,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174812,
      "e": 166896,
      "ty": 2,
      "x": 999,
      "y": 692
    },
    {
      "t": 174901,
      "e": 166985,
      "ty": 3,
      "x": 991,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174902,
      "e": 166986,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174913,
      "e": 166997,
      "ty": 2,
      "x": 991,
      "y": 695
    },
    {
      "t": 174996,
      "e": 167080,
      "ty": 4,
      "x": 49002,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174997,
      "e": 167081,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174998,
      "e": 167082,
      "ty": 5,
      "x": 991,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174999,
      "e": 167083,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 175013,
      "e": 167097,
      "ty": 41,
      "x": 33852,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 175712,
      "e": 167796,
      "ty": 2,
      "x": 990,
      "y": 695
    },
    {
      "t": 175763,
      "e": 167847,
      "ty": 41,
      "x": 33817,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 176021,
      "e": 168105,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 176513,
      "e": 168597,
      "ty": 2,
      "x": 956,
      "y": 441
    },
    {
      "t": 176513,
      "e": 168597,
      "ty": 41,
      "x": 31938,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 176612,
      "e": 168696,
      "ty": 2,
      "x": 932,
      "y": 290
    },
    {
      "t": 176713,
      "e": 168797,
      "ty": 2,
      "x": 928,
      "y": 237
    },
    {
      "t": 176762,
      "e": 168846,
      "ty": 41,
      "x": 25056,
      "y": 17835,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 176813,
      "e": 168897,
      "ty": 2,
      "x": 927,
      "y": 222
    },
    {
      "t": 176912,
      "e": 168996,
      "ty": 2,
      "x": 930,
      "y": 219
    },
    {
      "t": 177012,
      "e": 169096,
      "ty": 2,
      "x": 970,
      "y": 219
    },
    {
      "t": 177012,
      "e": 169096,
      "ty": 41,
      "x": 35261,
      "y": 16591,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 177312,
      "e": 169396,
      "ty": 2,
      "x": 970,
      "y": 225
    },
    {
      "t": 177413,
      "e": 169497,
      "ty": 2,
      "x": 948,
      "y": 233
    },
    {
      "t": 177512,
      "e": 169596,
      "ty": 2,
      "x": 928,
      "y": 240
    },
    {
      "t": 177512,
      "e": 169596,
      "ty": 41,
      "x": 25293,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 177613,
      "e": 169697,
      "ty": 2,
      "x": 903,
      "y": 255
    },
    {
      "t": 177763,
      "e": 169847,
      "ty": 41,
      "x": 18885,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 177812,
      "e": 169896,
      "ty": 2,
      "x": 893,
      "y": 259
    },
    {
      "t": 177913,
      "e": 169997,
      "ty": 2,
      "x": 888,
      "y": 265
    },
    {
      "t": 178012,
      "e": 170096,
      "ty": 2,
      "x": 883,
      "y": 273
    },
    {
      "t": 178012,
      "e": 170096,
      "ty": 41,
      "x": 46899,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 178113,
      "e": 170197,
      "ty": 2,
      "x": 879,
      "y": 285
    },
    {
      "t": 178212,
      "e": 170296,
      "ty": 2,
      "x": 878,
      "y": 287
    },
    {
      "t": 178263,
      "e": 170347,
      "ty": 41,
      "x": 17418,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 178313,
      "e": 170397,
      "ty": 2,
      "x": 878,
      "y": 294
    },
    {
      "t": 178512,
      "e": 170596,
      "ty": 41,
      "x": 17731,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 178612,
      "e": 170696,
      "ty": 2,
      "x": 878,
      "y": 297
    },
    {
      "t": 178763,
      "e": 170847,
      "ty": 41,
      "x": 17731,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 178932,
      "e": 171016,
      "ty": 3,
      "x": 878,
      "y": 297,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 179027,
      "e": 171111,
      "ty": 4,
      "x": 17731,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 179027,
      "e": 171111,
      "ty": 5,
      "x": 878,
      "y": 297,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 179027,
      "e": 171111,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 179028,
      "e": 171112,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 179613,
      "e": 171697,
      "ty": 2,
      "x": 883,
      "y": 301
    },
    {
      "t": 179712,
      "e": 171796,
      "ty": 2,
      "x": 1014,
      "y": 349
    },
    {
      "t": 179764,
      "e": 171797,
      "ty": 41,
      "x": 4534,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p > span"
    },
    {
      "t": 179812,
      "e": 171845,
      "ty": 2,
      "x": 1050,
      "y": 378
    },
    {
      "t": 180013,
      "e": 172046,
      "ty": 41,
      "x": 23259,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-1 > p > span"
    },
    {
      "t": 180112,
      "e": 172145,
      "ty": 2,
      "x": 1063,
      "y": 388
    },
    {
      "t": 180262,
      "e": 172295,
      "ty": 41,
      "x": 57332,
      "y": 8936,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 180513,
      "e": 172546,
      "ty": 2,
      "x": 994,
      "y": 409
    },
    {
      "t": 180513,
      "e": 172546,
      "ty": 41,
      "x": 40957,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 180613,
      "e": 172646,
      "ty": 2,
      "x": 982,
      "y": 413
    },
    {
      "t": 180713,
      "e": 172746,
      "ty": 2,
      "x": 979,
      "y": 413
    },
    {
      "t": 180763,
      "e": 172796,
      "ty": 41,
      "x": 37397,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 181113,
      "e": 173146,
      "ty": 2,
      "x": 836,
      "y": 399
    },
    {
      "t": 181212,
      "e": 173245,
      "ty": 2,
      "x": 773,
      "y": 397
    },
    {
      "t": 181263,
      "e": 173296,
      "ty": 41,
      "x": 26344,
      "y": 21549,
      "ta": "html > body"
    },
    {
      "t": 181413,
      "e": 173446,
      "ty": 2,
      "x": 779,
      "y": 389
    },
    {
      "t": 181513,
      "e": 173546,
      "ty": 2,
      "x": 784,
      "y": 391
    },
    {
      "t": 181513,
      "e": 173546,
      "ty": 41,
      "x": 26723,
      "y": 21217,
      "ta": "html > body"
    },
    {
      "t": 181913,
      "e": 173946,
      "ty": 2,
      "x": 783,
      "y": 397
    },
    {
      "t": 182013,
      "e": 174046,
      "ty": 2,
      "x": 743,
      "y": 422
    },
    {
      "t": 182013,
      "e": 174046,
      "ty": 41,
      "x": 25311,
      "y": 22934,
      "ta": "html > body"
    },
    {
      "t": 182112,
      "e": 174145,
      "ty": 2,
      "x": 737,
      "y": 422
    },
    {
      "t": 182213,
      "e": 174246,
      "ty": 2,
      "x": 647,
      "y": 442
    },
    {
      "t": 182262,
      "e": 174295,
      "ty": 41,
      "x": 21007,
      "y": 24208,
      "ta": "html > body"
    },
    {
      "t": 182312,
      "e": 174345,
      "ty": 2,
      "x": 618,
      "y": 442
    },
    {
      "t": 182412,
      "e": 174445,
      "ty": 2,
      "x": 748,
      "y": 424
    },
    {
      "t": 182512,
      "e": 174545,
      "ty": 2,
      "x": 820,
      "y": 422
    },
    {
      "t": 182513,
      "e": 174546,
      "ty": 41,
      "x": 27963,
      "y": 22934,
      "ta": "html > body"
    },
    {
      "t": 182612,
      "e": 174645,
      "ty": 2,
      "x": 822,
      "y": 413
    },
    {
      "t": 182667,
      "e": 174700,
      "ty": 6,
      "x": 826,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 182713,
      "e": 174746,
      "ty": 2,
      "x": 829,
      "y": 412
    },
    {
      "t": 182763,
      "e": 174796,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 182778,
      "e": 174811,
      "ty": 7,
      "x": 840,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 182813,
      "e": 174846,
      "ty": 2,
      "x": 847,
      "y": 418
    },
    {
      "t": 182913,
      "e": 174946,
      "ty": 2,
      "x": 854,
      "y": 420
    },
    {
      "t": 183012,
      "e": 175045,
      "ty": 2,
      "x": 853,
      "y": 432
    },
    {
      "t": 183013,
      "e": 175046,
      "ty": 41,
      "x": 7494,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 183113,
      "e": 175146,
      "ty": 2,
      "x": 841,
      "y": 451
    },
    {
      "t": 183161,
      "e": 175194,
      "ty": 6,
      "x": 831,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 183213,
      "e": 175246,
      "ty": 2,
      "x": 828,
      "y": 476
    },
    {
      "t": 183263,
      "e": 175296,
      "ty": 41,
      "x": 7955,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 183612,
      "e": 175645,
      "ty": 2,
      "x": 831,
      "y": 476
    },
    {
      "t": 183762,
      "e": 175795,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 183813,
      "e": 175846,
      "ty": 2,
      "x": 835,
      "y": 473
    },
    {
      "t": 183940,
      "e": 175973,
      "ty": 3,
      "x": 835,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 183942,
      "e": 175975,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 183942,
      "e": 175975,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 184013,
      "e": 176046,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 184027,
      "e": 176060,
      "ty": 4,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 184027,
      "e": 176060,
      "ty": 5,
      "x": 835,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 184027,
      "e": 176060,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 184194,
      "e": 176227,
      "ty": 7,
      "x": 840,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 184212,
      "e": 176245,
      "ty": 2,
      "x": 859,
      "y": 476
    },
    {
      "t": 184263,
      "e": 176296,
      "ty": 41,
      "x": 40482,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 184312,
      "e": 176345,
      "ty": 2,
      "x": 1079,
      "y": 502
    },
    {
      "t": 184413,
      "e": 176446,
      "ty": 2,
      "x": 1093,
      "y": 513
    },
    {
      "t": 184513,
      "e": 176546,
      "ty": 41,
      "x": 64452,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 184612,
      "e": 176645,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 184712,
      "e": 176745,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 185262,
      "e": 177295,
      "ty": 41,
      "x": 64452,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 185312,
      "e": 177345,
      "ty": 2,
      "x": 1093,
      "y": 526
    },
    {
      "t": 185612,
      "e": 177645,
      "ty": 2,
      "x": 1090,
      "y": 534
    },
    {
      "t": 185713,
      "e": 177746,
      "ty": 2,
      "x": 1082,
      "y": 550
    },
    {
      "t": 185763,
      "e": 177796,
      "ty": 41,
      "x": 61366,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 185813,
      "e": 177846,
      "ty": 2,
      "x": 1080,
      "y": 552
    },
    {
      "t": 186413,
      "e": 178446,
      "ty": 2,
      "x": 1065,
      "y": 574
    },
    {
      "t": 186513,
      "e": 178546,
      "ty": 2,
      "x": 974,
      "y": 619
    },
    {
      "t": 186513,
      "e": 178546,
      "ty": 41,
      "x": 36210,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 186612,
      "e": 178645,
      "ty": 2,
      "x": 885,
      "y": 687
    },
    {
      "t": 186713,
      "e": 178746,
      "ty": 2,
      "x": 884,
      "y": 691
    },
    {
      "t": 186763,
      "e": 178796,
      "ty": 41,
      "x": 14851,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 187311,
      "e": 179344,
      "ty": 2,
      "x": 884,
      "y": 690
    },
    {
      "t": 187412,
      "e": 179445,
      "ty": 2,
      "x": 879,
      "y": 687
    },
    {
      "t": 187512,
      "e": 179545,
      "ty": 2,
      "x": 876,
      "y": 686
    },
    {
      "t": 187512,
      "e": 179545,
      "ty": 41,
      "x": 12952,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 187612,
      "e": 179645,
      "ty": 2,
      "x": 873,
      "y": 685
    },
    {
      "t": 187762,
      "e": 179795,
      "ty": 41,
      "x": 12240,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 187912,
      "e": 179945,
      "ty": 2,
      "x": 869,
      "y": 685
    },
    {
      "t": 188012,
      "e": 180045,
      "ty": 41,
      "x": 11291,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 188113,
      "e": 180046,
      "ty": 2,
      "x": 863,
      "y": 695
    },
    {
      "t": 188212,
      "e": 180145,
      "ty": 2,
      "x": 858,
      "y": 699
    },
    {
      "t": 188262,
      "e": 180195,
      "ty": 41,
      "x": 9217,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 188312,
      "e": 180245,
      "ty": 2,
      "x": 856,
      "y": 703
    },
    {
      "t": 188412,
      "e": 180345,
      "ty": 2,
      "x": 855,
      "y": 704
    },
    {
      "t": 188512,
      "e": 180445,
      "ty": 41,
      "x": 8461,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 189112,
      "e": 181045,
      "ty": 2,
      "x": 855,
      "y": 717
    },
    {
      "t": 189262,
      "e": 181195,
      "ty": 41,
      "x": 7968,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 189312,
      "e": 181245,
      "ty": 2,
      "x": 855,
      "y": 720
    },
    {
      "t": 189412,
      "e": 181345,
      "ty": 2,
      "x": 855,
      "y": 721
    },
    {
      "t": 189512,
      "e": 181445,
      "ty": 41,
      "x": 8427,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 189612,
      "e": 181545,
      "ty": 2,
      "x": 855,
      "y": 724
    },
    {
      "t": 189763,
      "e": 181696,
      "ty": 41,
      "x": 8427,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 189812,
      "e": 181745,
      "ty": 2,
      "x": 854,
      "y": 733
    },
    {
      "t": 190012,
      "e": 181945,
      "ty": 2,
      "x": 854,
      "y": 748
    },
    {
      "t": 190012,
      "e": 181945,
      "ty": 41,
      "x": 7731,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 190112,
      "e": 182045,
      "ty": 2,
      "x": 855,
      "y": 753
    },
    {
      "t": 190211,
      "e": 182144,
      "ty": 2,
      "x": 855,
      "y": 758
    },
    {
      "t": 190262,
      "e": 182195,
      "ty": 41,
      "x": 14010,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 190312,
      "e": 182245,
      "ty": 2,
      "x": 855,
      "y": 766
    },
    {
      "t": 190512,
      "e": 182445,
      "ty": 41,
      "x": 14010,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 191212,
      "e": 183145,
      "ty": 2,
      "x": 854,
      "y": 751
    },
    {
      "t": 191262,
      "e": 183195,
      "ty": 41,
      "x": 13593,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 191312,
      "e": 183245,
      "ty": 2,
      "x": 854,
      "y": 742
    },
    {
      "t": 191412,
      "e": 183345,
      "ty": 2,
      "x": 852,
      "y": 733
    },
    {
      "t": 191513,
      "e": 183446,
      "ty": 41,
      "x": 7674,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 191912,
      "e": 183845,
      "ty": 2,
      "x": 852,
      "y": 719
    },
    {
      "t": 192012,
      "e": 183945,
      "ty": 2,
      "x": 861,
      "y": 690
    },
    {
      "t": 192012,
      "e": 183945,
      "ty": 41,
      "x": 9392,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 192412,
      "e": 184345,
      "ty": 2,
      "x": 869,
      "y": 691
    },
    {
      "t": 192513,
      "e": 184446,
      "ty": 2,
      "x": 881,
      "y": 695
    },
    {
      "t": 192513,
      "e": 184446,
      "ty": 41,
      "x": 15012,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 192612,
      "e": 184545,
      "ty": 2,
      "x": 896,
      "y": 706
    },
    {
      "t": 192713,
      "e": 184646,
      "ty": 2,
      "x": 900,
      "y": 707
    },
    {
      "t": 192762,
      "e": 184695,
      "ty": 41,
      "x": 20052,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 192812,
      "e": 184745,
      "ty": 2,
      "x": 902,
      "y": 708
    },
    {
      "t": 193013,
      "e": 184946,
      "ty": 41,
      "x": 20304,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 193112,
      "e": 185045,
      "ty": 2,
      "x": 895,
      "y": 708
    },
    {
      "t": 193212,
      "e": 185145,
      "ty": 2,
      "x": 888,
      "y": 705
    },
    {
      "t": 193262,
      "e": 185195,
      "ty": 41,
      "x": 15264,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 193312,
      "e": 185245,
      "ty": 2,
      "x": 877,
      "y": 709
    },
    {
      "t": 193412,
      "e": 185345,
      "ty": 2,
      "x": 860,
      "y": 712
    },
    {
      "t": 193512,
      "e": 185445,
      "ty": 2,
      "x": 847,
      "y": 712
    },
    {
      "t": 193513,
      "e": 185446,
      "ty": 41,
      "x": 6445,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 193612,
      "e": 185545,
      "ty": 2,
      "x": 836,
      "y": 710
    },
    {
      "t": 193685,
      "e": 185618,
      "ty": 6,
      "x": 828,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 193712,
      "e": 185645,
      "ty": 2,
      "x": 828,
      "y": 708
    },
    {
      "t": 193762,
      "e": 185695,
      "ty": 41,
      "x": 7955,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 194313,
      "e": 186246,
      "ty": 2,
      "x": 827,
      "y": 705
    },
    {
      "t": 194412,
      "e": 186345,
      "ty": 2,
      "x": 827,
      "y": 702
    },
    {
      "t": 194513,
      "e": 186446,
      "ty": 41,
      "x": 2914,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 194812,
      "e": 186745,
      "ty": 2,
      "x": 828,
      "y": 701
    },
    {
      "t": 194913,
      "e": 186846,
      "ty": 2,
      "x": 831,
      "y": 700
    },
    {
      "t": 195012,
      "e": 186945,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 195324,
      "e": 187257,
      "ty": 7,
      "x": 831,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 195412,
      "e": 187345,
      "ty": 2,
      "x": 822,
      "y": 726
    },
    {
      "t": 195512,
      "e": 187445,
      "ty": 41,
      "x": 145,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 195762,
      "e": 187695,
      "ty": 41,
      "x": 27722,
      "y": 40163,
      "ta": "html > body"
    },
    {
      "t": 195813,
      "e": 187746,
      "ty": 2,
      "x": 803,
      "y": 740
    },
    {
      "t": 196013,
      "e": 187946,
      "ty": 41,
      "x": 27377,
      "y": 40550,
      "ta": "html > body"
    },
    {
      "t": 196112,
      "e": 188045,
      "ty": 2,
      "x": 802,
      "y": 746
    },
    {
      "t": 196212,
      "e": 188145,
      "ty": 2,
      "x": 807,
      "y": 753
    },
    {
      "t": 196263,
      "e": 188196,
      "ty": 41,
      "x": 27515,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 196312,
      "e": 188245,
      "ty": 2,
      "x": 807,
      "y": 754
    },
    {
      "t": 196512,
      "e": 188445,
      "ty": 2,
      "x": 808,
      "y": 755
    },
    {
      "t": 196513,
      "e": 188446,
      "ty": 41,
      "x": 27550,
      "y": 41381,
      "ta": "html > body"
    },
    {
      "t": 196712,
      "e": 188645,
      "ty": 2,
      "x": 809,
      "y": 759
    },
    {
      "t": 196762,
      "e": 188695,
      "ty": 41,
      "x": 27584,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 196813,
      "e": 188746,
      "ty": 2,
      "x": 809,
      "y": 763
    },
    {
      "t": 197412,
      "e": 189345,
      "ty": 2,
      "x": 809,
      "y": 767
    },
    {
      "t": 197513,
      "e": 189446,
      "ty": 2,
      "x": 772,
      "y": 774
    },
    {
      "t": 197513,
      "e": 189446,
      "ty": 41,
      "x": 26310,
      "y": 42434,
      "ta": "html > body"
    },
    {
      "t": 197612,
      "e": 189545,
      "ty": 2,
      "x": 711,
      "y": 782
    },
    {
      "t": 197712,
      "e": 189645,
      "ty": 2,
      "x": 672,
      "y": 785
    },
    {
      "t": 197762,
      "e": 189695,
      "ty": 41,
      "x": 22728,
      "y": 43154,
      "ta": "html > body"
    },
    {
      "t": 197812,
      "e": 189745,
      "ty": 2,
      "x": 669,
      "y": 787
    },
    {
      "t": 197912,
      "e": 189845,
      "ty": 2,
      "x": 685,
      "y": 791
    },
    {
      "t": 198012,
      "e": 189945,
      "ty": 2,
      "x": 694,
      "y": 794
    },
    {
      "t": 198012,
      "e": 189945,
      "ty": 41,
      "x": 23624,
      "y": 43542,
      "ta": "html > body"
    },
    {
      "t": 198512,
      "e": 190445,
      "ty": 2,
      "x": 743,
      "y": 765
    },
    {
      "t": 198513,
      "e": 190446,
      "ty": 41,
      "x": 25311,
      "y": 41935,
      "ta": "html > body"
    },
    {
      "t": 198612,
      "e": 190545,
      "ty": 2,
      "x": 769,
      "y": 751
    },
    {
      "t": 198712,
      "e": 190645,
      "ty": 2,
      "x": 796,
      "y": 733
    },
    {
      "t": 198763,
      "e": 190696,
      "ty": 41,
      "x": 611,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 198813,
      "e": 190746,
      "ty": 2,
      "x": 833,
      "y": 710
    },
    {
      "t": 198913,
      "e": 190846,
      "ty": 2,
      "x": 850,
      "y": 693
    },
    {
      "t": 199012,
      "e": 190945,
      "ty": 2,
      "x": 843,
      "y": 679
    },
    {
      "t": 199013,
      "e": 190945,
      "ty": 41,
      "x": 5793,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 199040,
      "e": 190972,
      "ty": 6,
      "x": 839,
      "y": 676,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199112,
      "e": 191044,
      "ty": 2,
      "x": 836,
      "y": 674
    },
    {
      "t": 199212,
      "e": 191144,
      "ty": 2,
      "x": 834,
      "y": 674
    },
    {
      "t": 199263,
      "e": 191195,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199277,
      "e": 191209,
      "ty": 3,
      "x": 834,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199277,
      "e": 191209,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 199278,
      "e": 191210,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199362,
      "e": 191294,
      "ty": 4,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199363,
      "e": 191295,
      "ty": 5,
      "x": 834,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199363,
      "e": 191295,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 199513,
      "e": 191445,
      "ty": 2,
      "x": 833,
      "y": 679
    },
    {
      "t": 199513,
      "e": 191445,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199541,
      "e": 191473,
      "ty": 7,
      "x": 833,
      "y": 682,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199612,
      "e": 191544,
      "ty": 2,
      "x": 831,
      "y": 694
    },
    {
      "t": 199640,
      "e": 191572,
      "ty": 6,
      "x": 831,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199708,
      "e": 191640,
      "ty": 3,
      "x": 831,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199709,
      "e": 191641,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 199709,
      "e": 191641,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199712,
      "e": 191644,
      "ty": 2,
      "x": 831,
      "y": 696
    },
    {
      "t": 199763,
      "e": 191695,
      "ty": 41,
      "x": 23079,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199803,
      "e": 191735,
      "ty": 4,
      "x": 23079,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199803,
      "e": 191735,
      "ty": 5,
      "x": 831,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 199804,
      "e": 191736,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 200148,
      "e": 192080,
      "ty": 7,
      "x": 830,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 200212,
      "e": 192144,
      "ty": 2,
      "x": 831,
      "y": 686
    },
    {
      "t": 200262,
      "e": 192194,
      "ty": 41,
      "x": 2840,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 200313,
      "e": 192245,
      "ty": 2,
      "x": 832,
      "y": 683
    },
    {
      "t": 200347,
      "e": 192279,
      "ty": 6,
      "x": 832,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200413,
      "e": 192345,
      "ty": 2,
      "x": 832,
      "y": 679
    },
    {
      "t": 200435,
      "e": 192367,
      "ty": 3,
      "x": 832,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200437,
      "e": 192369,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 200437,
      "e": 192369,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200512,
      "e": 192444,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200555,
      "e": 192487,
      "ty": 4,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200555,
      "e": 192487,
      "ty": 5,
      "x": 832,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 200555,
      "e": 192487,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 201213,
      "e": 193145,
      "ty": 2,
      "x": 832,
      "y": 680
    },
    {
      "t": 201224,
      "e": 193156,
      "ty": 7,
      "x": 832,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 201262,
      "e": 193194,
      "ty": 41,
      "x": 2840,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 201312,
      "e": 193244,
      "ty": 2,
      "x": 832,
      "y": 681
    },
    {
      "t": 201592,
      "e": 193524,
      "ty": 6,
      "x": 829,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 201612,
      "e": 193544,
      "ty": 2,
      "x": 829,
      "y": 698
    },
    {
      "t": 201713,
      "e": 193645,
      "ty": 2,
      "x": 829,
      "y": 701
    },
    {
      "t": 201762,
      "e": 193694,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 202228,
      "e": 194160,
      "ty": 7,
      "x": 825,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 202262,
      "e": 194194,
      "ty": 41,
      "x": 27791,
      "y": 38667,
      "ta": "html > body"
    },
    {
      "t": 202312,
      "e": 194244,
      "ty": 2,
      "x": 798,
      "y": 705
    },
    {
      "t": 202413,
      "e": 194345,
      "ty": 2,
      "x": 796,
      "y": 704
    },
    {
      "t": 202513,
      "e": 194445,
      "ty": 41,
      "x": 27136,
      "y": 38556,
      "ta": "html > body"
    },
    {
      "t": 202532,
      "e": 194464,
      "ty": 3,
      "x": 796,
      "y": 704,
      "ta": "html > body"
    },
    {
      "t": 202532,
      "e": 194464,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 202595,
      "e": 194527,
      "ty": 4,
      "x": 27136,
      "y": 38556,
      "ta": "html > body"
    },
    {
      "t": 202596,
      "e": 194528,
      "ty": 5,
      "x": 796,
      "y": 704,
      "ta": "html > body"
    },
    {
      "t": 204263,
      "e": 196195,
      "ty": 41,
      "x": 26999,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 204313,
      "e": 196245,
      "ty": 2,
      "x": 754,
      "y": 833
    },
    {
      "t": 204412,
      "e": 196344,
      "ty": 2,
      "x": 717,
      "y": 978
    },
    {
      "t": 204513,
      "e": 196445,
      "ty": 2,
      "x": 701,
      "y": 1001
    },
    {
      "t": 204513,
      "e": 196445,
      "ty": 41,
      "x": 23865,
      "y": 55009,
      "ta": "html > body"
    },
    {
      "t": 204763,
      "e": 196695,
      "ty": 41,
      "x": 24691,
      "y": 54787,
      "ta": "html > body"
    },
    {
      "t": 204813,
      "e": 196745,
      "ty": 2,
      "x": 763,
      "y": 983
    },
    {
      "t": 204912,
      "e": 196844,
      "ty": 2,
      "x": 826,
      "y": 955
    },
    {
      "t": 205012,
      "e": 196944,
      "ty": 2,
      "x": 840,
      "y": 945
    },
    {
      "t": 205012,
      "e": 196944,
      "ty": 41,
      "x": 4409,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 205112,
      "e": 197044,
      "ty": 2,
      "x": 843,
      "y": 942
    },
    {
      "t": 205213,
      "e": 197145,
      "ty": 2,
      "x": 840,
      "y": 938
    },
    {
      "t": 205263,
      "e": 197195,
      "ty": 41,
      "x": 20291,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 205388,
      "e": 197320,
      "ty": 3,
      "x": 840,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 205450,
      "e": 197382,
      "ty": 4,
      "x": 20291,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 205451,
      "e": 197383,
      "ty": 5,
      "x": 840,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 205451,
      "e": 197383,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 205451,
      "e": 197383,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 205515,
      "e": 197447,
      "ty": 6,
      "x": 838,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 205612,
      "e": 197544,
      "ty": 2,
      "x": 838,
      "y": 937
    },
    {
      "t": 205756,
      "e": 197688,
      "ty": 7,
      "x": 838,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 205762,
      "e": 197694,
      "ty": 41,
      "x": 18107,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 205813,
      "e": 197745,
      "ty": 2,
      "x": 838,
      "y": 944
    },
    {
      "t": 206012,
      "e": 197745,
      "ty": 6,
      "x": 836,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 206013,
      "e": 197746,
      "ty": 2,
      "x": 836,
      "y": 956
    },
    {
      "t": 206013,
      "e": 197746,
      "ty": 41,
      "x": 48284,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 206112,
      "e": 197845,
      "ty": 2,
      "x": 828,
      "y": 962
    },
    {
      "t": 206146,
      "e": 197879,
      "ty": 7,
      "x": 828,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 206212,
      "e": 197945,
      "ty": 2,
      "x": 831,
      "y": 976
    },
    {
      "t": 206263,
      "e": 197996,
      "ty": 41,
      "x": 2510,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 206313,
      "e": 198046,
      "ty": 2,
      "x": 833,
      "y": 979
    },
    {
      "t": 206396,
      "e": 198129,
      "ty": 6,
      "x": 838,
      "y": 984,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 206412,
      "e": 198145,
      "ty": 2,
      "x": 838,
      "y": 984
    },
    {
      "t": 206429,
      "e": 198162,
      "ty": 7,
      "x": 840,
      "y": 984,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 206513,
      "e": 198246,
      "ty": 2,
      "x": 841,
      "y": 985
    },
    {
      "t": 206513,
      "e": 198246,
      "ty": 41,
      "x": 19435,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 206612,
      "e": 198345,
      "ty": 2,
      "x": 841,
      "y": 988
    },
    {
      "t": 206712,
      "e": 198445,
      "ty": 2,
      "x": 845,
      "y": 1002
    },
    {
      "t": 206713,
      "e": 198446,
      "ty": 6,
      "x": 847,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 206762,
      "e": 198495,
      "ty": 41,
      "x": 17305,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 206812,
      "e": 198545,
      "ty": 2,
      "x": 873,
      "y": 1017
    },
    {
      "t": 206917,
      "e": 198650,
      "ty": 2,
      "x": 904,
      "y": 1023
    },
    {
      "t": 207017,
      "e": 198750,
      "ty": 2,
      "x": 905,
      "y": 1023
    },
    {
      "t": 207017,
      "e": 198750,
      "ty": 41,
      "x": 38952,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208485,
      "e": 200218,
      "ty": 7,
      "x": 1063,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 208517,
      "e": 200250,
      "ty": 2,
      "x": 1159,
      "y": 1013
    },
    {
      "t": 208517,
      "e": 200250,
      "ty": 41,
      "x": 39637,
      "y": 55674,
      "ta": "html > body"
    },
    {
      "t": 208616,
      "e": 200349,
      "ty": 2,
      "x": 1306,
      "y": 1002
    },
    {
      "t": 208767,
      "e": 200500,
      "ty": 41,
      "x": 44700,
      "y": 55064,
      "ta": "html > body"
    },
    {
      "t": 209517,
      "e": 201250,
      "ty": 2,
      "x": 1306,
      "y": 1001
    },
    {
      "t": 209517,
      "e": 201250,
      "ty": 41,
      "x": 44700,
      "y": 55009,
      "ta": "html > body"
    },
    {
      "t": 209917,
      "e": 201650,
      "ty": 2,
      "x": 1306,
      "y": 1000
    },
    {
      "t": 210017,
      "e": 201750,
      "ty": 41,
      "x": 44700,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 220016,
      "e": 206750,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 223517,
      "e": 206750,
      "ty": 2,
      "x": 1307,
      "y": 1000
    },
    {
      "t": 223517,
      "e": 206750,
      "ty": 41,
      "x": 44734,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 224116,
      "e": 207349,
      "ty": 2,
      "x": 1130,
      "y": 647
    },
    {
      "t": 224216,
      "e": 207449,
      "ty": 2,
      "x": 859,
      "y": 618
    },
    {
      "t": 224266,
      "e": 207499,
      "ty": 41,
      "x": 8918,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 224316,
      "e": 207549,
      "ty": 2,
      "x": 857,
      "y": 619
    },
    {
      "t": 224416,
      "e": 207649,
      "ty": 2,
      "x": 867,
      "y": 693
    },
    {
      "t": 224516,
      "e": 207749,
      "ty": 2,
      "x": 862,
      "y": 693
    },
    {
      "t": 224516,
      "e": 207749,
      "ty": 41,
      "x": 10224,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 224563,
      "e": 207796,
      "ty": 6,
      "x": 831,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 224597,
      "e": 207830,
      "ty": 7,
      "x": 825,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 224617,
      "e": 207850,
      "ty": 2,
      "x": 825,
      "y": 700
    },
    {
      "t": 224716,
      "e": 207949,
      "ty": 2,
      "x": 824,
      "y": 700
    },
    {
      "t": 224744,
      "e": 207977,
      "ty": 3,
      "x": 824,
      "y": 700,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 224745,
      "e": 207978,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 224767,
      "e": 208000,
      "ty": 41,
      "x": 649,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 224822,
      "e": 208055,
      "ty": 4,
      "x": 649,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 224822,
      "e": 208055,
      "ty": 5,
      "x": 824,
      "y": 700,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 224822,
      "e": 208055,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 224822,
      "e": 208055,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 224986,
      "e": 208219,
      "ty": 6,
      "x": 827,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 224997,
      "e": 208230,
      "ty": 7,
      "x": 829,
      "y": 694,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 225015,
      "e": 208248,
      "ty": 2,
      "x": 832,
      "y": 690
    },
    {
      "t": 225015,
      "e": 208248,
      "ty": 41,
      "x": 2510,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 225116,
      "e": 208349,
      "ty": 2,
      "x": 834,
      "y": 690
    },
    {
      "t": 225217,
      "e": 208450,
      "ty": 2,
      "x": 837,
      "y": 686
    },
    {
      "t": 225266,
      "e": 208499,
      "ty": 41,
      "x": 3697,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 225317,
      "e": 208550,
      "ty": 2,
      "x": 837,
      "y": 685
    },
    {
      "t": 225415,
      "e": 208648,
      "ty": 6,
      "x": 837,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225416,
      "e": 208649,
      "ty": 2,
      "x": 837,
      "y": 680
    },
    {
      "t": 225463,
      "e": 208696,
      "ty": 3,
      "x": 836,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225464,
      "e": 208697,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 225464,
      "e": 208697,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225516,
      "e": 208749,
      "ty": 2,
      "x": 836,
      "y": 680
    },
    {
      "t": 225517,
      "e": 208750,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225542,
      "e": 208775,
      "ty": 4,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225543,
      "e": 208776,
      "ty": 5,
      "x": 836,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 225543,
      "e": 208776,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 226183,
      "e": 209416,
      "ty": 7,
      "x": 836,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 226217,
      "e": 209450,
      "ty": 2,
      "x": 836,
      "y": 693
    },
    {
      "t": 226232,
      "e": 209465,
      "ty": 6,
      "x": 835,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 226249,
      "e": 209482,
      "ty": 7,
      "x": 837,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 226266,
      "e": 209499,
      "ty": 41,
      "x": 8586,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 226316,
      "e": 209549,
      "ty": 2,
      "x": 845,
      "y": 759
    },
    {
      "t": 226416,
      "e": 209649,
      "ty": 2,
      "x": 878,
      "y": 840
    },
    {
      "t": 226516,
      "e": 209749,
      "ty": 2,
      "x": 879,
      "y": 843
    },
    {
      "t": 226517,
      "e": 209750,
      "ty": 41,
      "x": 40567,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 226616,
      "e": 209849,
      "ty": 2,
      "x": 888,
      "y": 847
    },
    {
      "t": 226716,
      "e": 209949,
      "ty": 2,
      "x": 1025,
      "y": 867
    },
    {
      "t": 226767,
      "e": 210000,
      "ty": 41,
      "x": 53535,
      "y": 52607,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 226816,
      "e": 210049,
      "ty": 2,
      "x": 1049,
      "y": 865
    },
    {
      "t": 226917,
      "e": 210150,
      "ty": 2,
      "x": 1074,
      "y": 849
    },
    {
      "t": 227016,
      "e": 210249,
      "ty": 41,
      "x": 59943,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 229006,
      "e": 212239,
      "ty": 3,
      "x": 1074,
      "y": 849,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 229007,
      "e": 212240,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 229094,
      "e": 212327,
      "ty": 4,
      "x": 59943,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 229094,
      "e": 212327,
      "ty": 5,
      "x": 1074,
      "y": 849,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 229616,
      "e": 212849,
      "ty": 2,
      "x": 1075,
      "y": 849
    },
    {
      "t": 229766,
      "e": 212999,
      "ty": 41,
      "x": 60180,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 230016,
      "e": 213249,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 231767,
      "e": 215000,
      "ty": 41,
      "x": 57332,
      "y": 52607,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 231817,
      "e": 215050,
      "ty": 2,
      "x": 1016,
      "y": 907
    },
    {
      "t": 231916,
      "e": 215149,
      "ty": 2,
      "x": 997,
      "y": 920
    },
    {
      "t": 232016,
      "e": 215249,
      "ty": 2,
      "x": 984,
      "y": 929
    },
    {
      "t": 232017,
      "e": 215250,
      "ty": 41,
      "x": 38583,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 232117,
      "e": 215350,
      "ty": 2,
      "x": 966,
      "y": 946
    },
    {
      "t": 232216,
      "e": 215449,
      "ty": 2,
      "x": 924,
      "y": 959
    },
    {
      "t": 232266,
      "e": 215499,
      "ty": 41,
      "x": 58709,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 232317,
      "e": 215550,
      "ty": 2,
      "x": 878,
      "y": 967
    },
    {
      "t": 232416,
      "e": 215649,
      "ty": 2,
      "x": 865,
      "y": 963
    },
    {
      "t": 232516,
      "e": 215749,
      "ty": 2,
      "x": 855,
      "y": 957
    },
    {
      "t": 232517,
      "e": 215750,
      "ty": 41,
      "x": 27161,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 232587,
      "e": 215820,
      "ty": 6,
      "x": 869,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 232617,
      "e": 215850,
      "ty": 2,
      "x": 871,
      "y": 1014
    },
    {
      "t": 232716,
      "e": 215949,
      "ty": 2,
      "x": 873,
      "y": 1016
    },
    {
      "t": 232767,
      "e": 216000,
      "ty": 41,
      "x": 22459,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 232817,
      "e": 216050,
      "ty": 2,
      "x": 873,
      "y": 1017
    },
    {
      "t": 233016,
      "e": 216249,
      "ty": 41,
      "x": 22459,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 233917,
      "e": 217150,
      "ty": 2,
      "x": 873,
      "y": 1018
    },
    {
      "t": 234017,
      "e": 217250,
      "ty": 41,
      "x": 22459,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234231,
      "e": 217464,
      "ty": 3,
      "x": 873,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234233,
      "e": 217466,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234311,
      "e": 217544,
      "ty": 4,
      "x": 22459,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234311,
      "e": 217544,
      "ty": 5,
      "x": 873,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234318,
      "e": 217551,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 234321,
      "e": 217554,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 234322,
      "e": 217555,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 235317,
      "e": 218550,
      "ty": 2,
      "x": 862,
      "y": 969
    },
    {
      "t": 235417,
      "e": 218650,
      "ty": 2,
      "x": 794,
      "y": 744
    },
    {
      "t": 235517,
      "e": 218750,
      "ty": 2,
      "x": 794,
      "y": 743
    },
    {
      "t": 235517,
      "e": 218750,
      "ty": 41,
      "x": 27068,
      "y": 40717,
      "ta": "html > body"
    },
    {
      "t": 235671,
      "e": 218904,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 236017,
      "e": 219250,
      "ty": 2,
      "x": 692,
      "y": 634
    },
    {
      "t": 236017,
      "e": 219250,
      "ty": 41,
      "x": 19607,
      "y": 59104,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 236117,
      "e": 219350,
      "ty": 2,
      "x": 247,
      "y": 335
    },
    {
      "t": 236216,
      "e": 219449,
      "ty": 2,
      "x": 245,
      "y": 334
    },
    {
      "t": 236267,
      "e": 219500,
      "ty": 41,
      "x": 8161,
      "y": 18059,
      "ta": "> div.masterdiv"
    },
    {
      "t": 236317,
      "e": 219550,
      "ty": 2,
      "x": 291,
      "y": 543
    },
    {
      "t": 236416,
      "e": 219649,
      "ty": 2,
      "x": 547,
      "y": 820
    },
    {
      "t": 236517,
      "e": 219750,
      "ty": 2,
      "x": 615,
      "y": 847
    },
    {
      "t": 236517,
      "e": 219750,
      "ty": 41,
      "x": 15819,
      "y": 56776,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 236616,
      "e": 219849,
      "ty": 2,
      "x": 665,
      "y": 858
    },
    {
      "t": 236717,
      "e": 219950,
      "ty": 2,
      "x": 824,
      "y": 971
    },
    {
      "t": 236767,
      "e": 220000,
      "ty": 41,
      "x": 8659,
      "y": 2943,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 236775,
      "e": 220008,
      "ty": 6,
      "x": 929,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 236808,
      "e": 220041,
      "ty": 7,
      "x": 971,
      "y": 1111,
      "ta": "#start"
    },
    {
      "t": 236817,
      "e": 220050,
      "ty": 2,
      "x": 971,
      "y": 1111
    },
    {
      "t": 236917,
      "e": 220150,
      "ty": 2,
      "x": 973,
      "y": 1111
    },
    {
      "t": 237017,
      "e": 220250,
      "ty": 41,
      "x": 39086,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 237047,
      "e": 220280,
      "ty": 6,
      "x": 975,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 237117,
      "e": 220350,
      "ty": 2,
      "x": 981,
      "y": 1084
    },
    {
      "t": 237216,
      "e": 220449,
      "ty": 2,
      "x": 983,
      "y": 1082
    },
    {
      "t": 237267,
      "e": 220500,
      "ty": 41,
      "x": 40140,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 238128,
      "e": 221361,
      "ty": 3,
      "x": 983,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 238129,
      "e": 221362,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 238206,
      "e": 221439,
      "ty": 4,
      "x": 40140,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 238207,
      "e": 221440,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 238207,
      "e": 221440,
      "ty": 5,
      "x": 983,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 238207,
      "e": 221440,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 238517,
      "e": 221750,
      "ty": 2,
      "x": 945,
      "y": 908
    },
    {
      "t": 238517,
      "e": 221750,
      "ty": 41,
      "x": 32268,
      "y": 49857,
      "ta": "html > body"
    },
    {
      "t": 238617,
      "e": 221850,
      "ty": 2,
      "x": 947,
      "y": 294
    },
    {
      "t": 238717,
      "e": 221950,
      "ty": 2,
      "x": 947,
      "y": 287
    },
    {
      "t": 238767,
      "e": 222000,
      "ty": 41,
      "x": 32337,
      "y": 15455,
      "ta": "html > body"
    },
    {
      "t": 239257,
      "e": 222490,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 240266,
      "e": 223499,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 240963,
      "e": 224196,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 210166, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 210170, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8907, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 220421, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14712, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"sierra\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 236140, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 32151, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 269383, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 29446, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 299832, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 47588, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 349036, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -Z -Z -Z -A -10 AM-12 PM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:969,y:893,t:1527631705443};\\\", \\\"{x:892,y:875,t:1527631705460};\\\", \\\"{x:772,y:837,t:1527631705476};\\\", \\\"{x:689,y:799,t:1527631705494};\\\", \\\"{x:672,y:779,t:1527631705510};\\\", \\\"{x:645,y:762,t:1527631705527};\\\", \\\"{x:589,y:739,t:1527631705543};\\\", \\\"{x:485,y:715,t:1527631705561};\\\", \\\"{x:309,y:702,t:1527631705577};\\\", \\\"{x:18,y:673,t:1527631705593};\\\", \\\"{x:0,y:641,t:1527631705610};\\\", \\\"{x:0,y:629,t:1527631705627};\\\", \\\"{x:0,y:619,t:1527631705643};\\\", \\\"{x:0,y:596,t:1527631705660};\\\", \\\"{x:0,y:579,t:1527631705676};\\\", \\\"{x:0,y:570,t:1527631705693};\\\", \\\"{x:0,y:564,t:1527631705710};\\\", \\\"{x:0,y:560,t:1527631705727};\\\", \\\"{x:0,y:556,t:1527631705746};\\\", \\\"{x:15,y:543,t:1527631705761};\\\", \\\"{x:102,y:517,t:1527631705779};\\\", \\\"{x:213,y:496,t:1527631705794};\\\", \\\"{x:360,y:475,t:1527631705809};\\\", \\\"{x:621,y:470,t:1527631705827};\\\", \\\"{x:822,y:470,t:1527631705843};\\\", \\\"{x:1029,y:470,t:1527631705859};\\\", \\\"{x:1193,y:466,t:1527631705877};\\\", \\\"{x:1312,y:466,t:1527631705894};\\\", \\\"{x:1358,y:467,t:1527631705910};\\\", \\\"{x:1365,y:468,t:1527631705927};\\\", \\\"{x:1366,y:470,t:1527631705942};\\\", \\\"{x:1367,y:475,t:1527631705959};\\\", \\\"{x:1367,y:488,t:1527631705976};\\\", \\\"{x:1367,y:497,t:1527631705992};\\\", \\\"{x:1359,y:513,t:1527631706009};\\\", \\\"{x:1356,y:547,t:1527631706026};\\\", \\\"{x:1356,y:575,t:1527631706043};\\\", \\\"{x:1351,y:601,t:1527631706059};\\\", \\\"{x:1335,y:631,t:1527631706075};\\\", \\\"{x:1315,y:655,t:1527631706093};\\\", \\\"{x:1273,y:694,t:1527631706109};\\\", \\\"{x:1205,y:746,t:1527631706125};\\\", \\\"{x:1147,y:783,t:1527631706142};\\\", \\\"{x:1113,y:806,t:1527631706159};\\\", \\\"{x:1091,y:822,t:1527631706175};\\\", \\\"{x:1089,y:822,t:1527631706192};\\\", \\\"{x:1082,y:822,t:1527631706532};\\\", \\\"{x:1075,y:822,t:1527631706542};\\\", \\\"{x:1056,y:817,t:1527631706559};\\\", \\\"{x:1045,y:813,t:1527631706575};\\\", \\\"{x:1035,y:807,t:1527631706592};\\\", \\\"{x:1023,y:796,t:1527631706609};\\\", \\\"{x:1009,y:787,t:1527631706625};\\\", \\\"{x:987,y:771,t:1527631706643};\\\", \\\"{x:957,y:754,t:1527631706658};\\\", \\\"{x:912,y:722,t:1527631706675};\\\", \\\"{x:881,y:700,t:1527631706691};\\\", \\\"{x:851,y:683,t:1527631706708};\\\", \\\"{x:826,y:667,t:1527631706725};\\\", \\\"{x:806,y:654,t:1527631706742};\\\", \\\"{x:787,y:642,t:1527631706758};\\\", \\\"{x:770,y:631,t:1527631706775};\\\", \\\"{x:757,y:622,t:1527631706791};\\\", \\\"{x:749,y:616,t:1527631706807};\\\", \\\"{x:750,y:616,t:1527631706843};\\\", \\\"{x:757,y:616,t:1527631706858};\\\", \\\"{x:784,y:632,t:1527631706875};\\\", \\\"{x:818,y:659,t:1527631706891};\\\", \\\"{x:887,y:702,t:1527631706908};\\\", \\\"{x:980,y:754,t:1527631706923};\\\", \\\"{x:1056,y:796,t:1527631706942};\\\", \\\"{x:1091,y:818,t:1527631706958};\\\", \\\"{x:1108,y:828,t:1527631706974};\\\", \\\"{x:1124,y:836,t:1527631706991};\\\", \\\"{x:1142,y:847,t:1527631707008};\\\", \\\"{x:1159,y:857,t:1527631707024};\\\", \\\"{x:1174,y:867,t:1527631707041};\\\", \\\"{x:1188,y:876,t:1527631707058};\\\", \\\"{x:1197,y:880,t:1527631707074};\\\", \\\"{x:1206,y:882,t:1527631707092};\\\", \\\"{x:1217,y:885,t:1527631707107};\\\", \\\"{x:1230,y:889,t:1527631707124};\\\", \\\"{x:1235,y:891,t:1527631707140};\\\", \\\"{x:1238,y:891,t:1527631707156};\\\", \\\"{x:1239,y:892,t:1527631707173};\\\", \\\"{x:1240,y:892,t:1527631707191};\\\", \\\"{x:1242,y:894,t:1527631707207};\\\", \\\"{x:1247,y:897,t:1527631707223};\\\", \\\"{x:1253,y:901,t:1527631707239};\\\", \\\"{x:1257,y:907,t:1527631707256};\\\", \\\"{x:1258,y:909,t:1527631707274};\\\", \\\"{x:1259,y:909,t:1527631707289};\\\", \\\"{x:1260,y:910,t:1527631707306};\\\", \\\"{x:1265,y:912,t:1527631707323};\\\", \\\"{x:1266,y:913,t:1527631707339};\\\", \\\"{x:1269,y:914,t:1527631707357};\\\", \\\"{x:1271,y:914,t:1527631707372};\\\", \\\"{x:1275,y:917,t:1527631707389};\\\", \\\"{x:1281,y:920,t:1527631707407};\\\", \\\"{x:1283,y:921,t:1527631707423};\\\", \\\"{x:1285,y:923,t:1527631707439};\\\", \\\"{x:1286,y:924,t:1527631707466};\\\", \\\"{x:1287,y:924,t:1527631707475};\\\", \\\"{x:1288,y:924,t:1527631707490};\\\", \\\"{x:1289,y:926,t:1527631707506};\\\", \\\"{x:1290,y:927,t:1527631707523};\\\", \\\"{x:1290,y:928,t:1527631707539};\\\", \\\"{x:1290,y:930,t:1527631707555};\\\", \\\"{x:1290,y:932,t:1527631707573};\\\", \\\"{x:1290,y:935,t:1527631707590};\\\", \\\"{x:1290,y:937,t:1527631707605};\\\", \\\"{x:1290,y:938,t:1527631707622};\\\", \\\"{x:1290,y:939,t:1527631707639};\\\", \\\"{x:1292,y:942,t:1527631707655};\\\", \\\"{x:1293,y:945,t:1527631707673};\\\", \\\"{x:1293,y:948,t:1527631707689};\\\", \\\"{x:1293,y:949,t:1527631707706};\\\", \\\"{x:1293,y:954,t:1527631707722};\\\", \\\"{x:1292,y:958,t:1527631707739};\\\", \\\"{x:1291,y:962,t:1527631707755};\\\", \\\"{x:1291,y:965,t:1527631707773};\\\", \\\"{x:1290,y:966,t:1527631707789};\\\", \\\"{x:1289,y:967,t:1527631707806};\\\", \\\"{x:1285,y:961,t:1527631707899};\\\", \\\"{x:1284,y:956,t:1527631707907};\\\", \\\"{x:1281,y:952,t:1527631707922};\\\", \\\"{x:1281,y:946,t:1527631707939};\\\", \\\"{x:1281,y:942,t:1527631707955};\\\", \\\"{x:1281,y:933,t:1527631707972};\\\", \\\"{x:1279,y:924,t:1527631707989};\\\", \\\"{x:1279,y:916,t:1527631708005};\\\", \\\"{x:1275,y:906,t:1527631708022};\\\", \\\"{x:1273,y:892,t:1527631708038};\\\", \\\"{x:1273,y:883,t:1527631708054};\\\", \\\"{x:1271,y:876,t:1527631708071};\\\", \\\"{x:1269,y:869,t:1527631708087};\\\", \\\"{x:1269,y:865,t:1527631708105};\\\", \\\"{x:1267,y:862,t:1527631708122};\\\", \\\"{x:1267,y:859,t:1527631708138};\\\", \\\"{x:1266,y:851,t:1527631708155};\\\", \\\"{x:1266,y:847,t:1527631708172};\\\", \\\"{x:1266,y:844,t:1527631708188};\\\", \\\"{x:1266,y:842,t:1527631708204};\\\", \\\"{x:1266,y:841,t:1527631708221};\\\", \\\"{x:1266,y:840,t:1527631708237};\\\", \\\"{x:1266,y:838,t:1527631708258};\\\", \\\"{x:1266,y:837,t:1527631708283};\\\", \\\"{x:1267,y:835,t:1527631708290};\\\", \\\"{x:1268,y:835,t:1527631708304};\\\", \\\"{x:1268,y:833,t:1527631708320};\\\", \\\"{x:1270,y:833,t:1527631708337};\\\", \\\"{x:1270,y:832,t:1527631708353};\\\", \\\"{x:1271,y:831,t:1527631708371};\\\", \\\"{x:1271,y:830,t:1527631708435};\\\", \\\"{x:1273,y:829,t:1527631708451};\\\", \\\"{x:1275,y:829,t:1527631708475};\\\", \\\"{x:1276,y:829,t:1527631708492};\\\", \\\"{x:1279,y:829,t:1527631708521};\\\", \\\"{x:1280,y:829,t:1527631708538};\\\", \\\"{x:1281,y:829,t:1527631708579};\\\", \\\"{x:1277,y:826,t:1527631713444};\\\", \\\"{x:1239,y:817,t:1527631713460};\\\", \\\"{x:1206,y:815,t:1527631713476};\\\", \\\"{x:1147,y:805,t:1527631713493};\\\", \\\"{x:1029,y:775,t:1527631713509};\\\", \\\"{x:911,y:748,t:1527631713526};\\\", \\\"{x:830,y:734,t:1527631713543};\\\", \\\"{x:749,y:721,t:1527631713559};\\\", \\\"{x:673,y:708,t:1527631713576};\\\", \\\"{x:609,y:691,t:1527631713592};\\\", \\\"{x:543,y:672,t:1527631713609};\\\", \\\"{x:486,y:652,t:1527631713626};\\\", \\\"{x:443,y:637,t:1527631713644};\\\", \\\"{x:404,y:624,t:1527631713659};\\\", \\\"{x:388,y:619,t:1527631713676};\\\", \\\"{x:377,y:615,t:1527631713694};\\\", \\\"{x:370,y:612,t:1527631713711};\\\", \\\"{x:363,y:604,t:1527631713727};\\\", \\\"{x:355,y:589,t:1527631713749};\\\", \\\"{x:347,y:578,t:1527631713766};\\\", \\\"{x:341,y:567,t:1527631713784};\\\", \\\"{x:337,y:555,t:1527631713800};\\\", \\\"{x:332,y:540,t:1527631713817};\\\", \\\"{x:329,y:533,t:1527631713834};\\\", \\\"{x:328,y:525,t:1527631713849};\\\", \\\"{x:327,y:517,t:1527631713866};\\\", \\\"{x:327,y:513,t:1527631713884};\\\", \\\"{x:326,y:507,t:1527631713899};\\\", \\\"{x:326,y:505,t:1527631713917};\\\", \\\"{x:326,y:503,t:1527631713934};\\\", \\\"{x:327,y:504,t:1527631714218};\\\", \\\"{x:330,y:507,t:1527631714234};\\\", \\\"{x:338,y:515,t:1527631714250};\\\", \\\"{x:343,y:517,t:1527631714266};\\\", \\\"{x:344,y:518,t:1527631714284};\\\", \\\"{x:348,y:519,t:1527631714300};\\\", \\\"{x:349,y:519,t:1527631714316};\\\", \\\"{x:353,y:520,t:1527631714334};\\\", \\\"{x:355,y:520,t:1527631714351};\\\", \\\"{x:359,y:522,t:1527631714366};\\\", \\\"{x:364,y:523,t:1527631714384};\\\", \\\"{x:367,y:524,t:1527631714401};\\\", \\\"{x:370,y:524,t:1527631714417};\\\", \\\"{x:372,y:524,t:1527631714433};\\\", \\\"{x:376,y:524,t:1527631714450};\\\", \\\"{x:377,y:524,t:1527631714467};\\\", \\\"{x:379,y:524,t:1527631714484};\\\", \\\"{x:381,y:524,t:1527631714500};\\\", \\\"{x:385,y:524,t:1527631714518};\\\", \\\"{x:386,y:524,t:1527631714533};\\\", \\\"{x:388,y:524,t:1527631714550};\\\", \\\"{x:390,y:525,t:1527631721882};\\\", \\\"{x:396,y:529,t:1527631721890};\\\", \\\"{x:412,y:539,t:1527631721907};\\\", \\\"{x:431,y:552,t:1527631721924};\\\", \\\"{x:455,y:560,t:1527631721940};\\\", \\\"{x:492,y:568,t:1527631721956};\\\", \\\"{x:569,y:585,t:1527631721973};\\\", \\\"{x:670,y:601,t:1527631721988};\\\", \\\"{x:807,y:616,t:1527631722007};\\\", \\\"{x:940,y:631,t:1527631722023};\\\", \\\"{x:1040,y:631,t:1527631722040};\\\", \\\"{x:1093,y:632,t:1527631722057};\\\", \\\"{x:1141,y:632,t:1527631722073};\\\", \\\"{x:1207,y:649,t:1527631722089};\\\", \\\"{x:1238,y:660,t:1527631722106};\\\", \\\"{x:1252,y:668,t:1527631722123};\\\", \\\"{x:1265,y:676,t:1527631722140};\\\", \\\"{x:1279,y:685,t:1527631722157};\\\", \\\"{x:1288,y:694,t:1527631722173};\\\", \\\"{x:1296,y:702,t:1527631722190};\\\", \\\"{x:1303,y:707,t:1527631722206};\\\", \\\"{x:1309,y:712,t:1527631722223};\\\", \\\"{x:1316,y:716,t:1527631722240};\\\", \\\"{x:1323,y:721,t:1527631722256};\\\", \\\"{x:1329,y:726,t:1527631722273};\\\", \\\"{x:1336,y:731,t:1527631722289};\\\", \\\"{x:1344,y:738,t:1527631722306};\\\", \\\"{x:1349,y:748,t:1527631722323};\\\", \\\"{x:1353,y:759,t:1527631722340};\\\", \\\"{x:1358,y:773,t:1527631722356};\\\", \\\"{x:1360,y:789,t:1527631722373};\\\", \\\"{x:1360,y:810,t:1527631722390};\\\", \\\"{x:1357,y:833,t:1527631722406};\\\", \\\"{x:1350,y:851,t:1527631722423};\\\", \\\"{x:1347,y:865,t:1527631722440};\\\", \\\"{x:1346,y:873,t:1527631722456};\\\", \\\"{x:1345,y:876,t:1527631722473};\\\", \\\"{x:1344,y:878,t:1527631722490};\\\", \\\"{x:1343,y:879,t:1527631722513};\\\", \\\"{x:1343,y:880,t:1527631722523};\\\", \\\"{x:1342,y:882,t:1527631722540};\\\", \\\"{x:1342,y:883,t:1527631722555};\\\", \\\"{x:1341,y:884,t:1527631722573};\\\", \\\"{x:1341,y:885,t:1527631722589};\\\", \\\"{x:1341,y:886,t:1527631722610};\\\", \\\"{x:1340,y:887,t:1527631722623};\\\", \\\"{x:1340,y:889,t:1527631722640};\\\", \\\"{x:1339,y:892,t:1527631722656};\\\", \\\"{x:1339,y:893,t:1527631722681};\\\", \\\"{x:1339,y:894,t:1527631722826};\\\", \\\"{x:1340,y:894,t:1527631722905};\\\", \\\"{x:1342,y:894,t:1527631722922};\\\", \\\"{x:1343,y:894,t:1527631722962};\\\", \\\"{x:1344,y:894,t:1527631722973};\\\", \\\"{x:1345,y:894,t:1527631722988};\\\", \\\"{x:1346,y:894,t:1527631723010};\\\", \\\"{x:1347,y:893,t:1527631723023};\\\", \\\"{x:1348,y:893,t:1527631723074};\\\", \\\"{x:1348,y:889,t:1527631723331};\\\", \\\"{x:1346,y:888,t:1527631723339};\\\", \\\"{x:1340,y:880,t:1527631723356};\\\", \\\"{x:1337,y:876,t:1527631723372};\\\", \\\"{x:1332,y:872,t:1527631723389};\\\", \\\"{x:1330,y:871,t:1527631723406};\\\", \\\"{x:1329,y:870,t:1527631723422};\\\", \\\"{x:1328,y:869,t:1527631723439};\\\", \\\"{x:1327,y:869,t:1527631723456};\\\", \\\"{x:1326,y:869,t:1527631723472};\\\", \\\"{x:1323,y:868,t:1527631723489};\\\", \\\"{x:1315,y:865,t:1527631723505};\\\", \\\"{x:1311,y:865,t:1527631723522};\\\", \\\"{x:1309,y:863,t:1527631723539};\\\", \\\"{x:1307,y:863,t:1527631723556};\\\", \\\"{x:1305,y:862,t:1527631723572};\\\", \\\"{x:1304,y:861,t:1527631723594};\\\", \\\"{x:1303,y:860,t:1527631723606};\\\", \\\"{x:1300,y:855,t:1527631723622};\\\", \\\"{x:1298,y:852,t:1527631723639};\\\", \\\"{x:1297,y:849,t:1527631723656};\\\", \\\"{x:1296,y:846,t:1527631723672};\\\", \\\"{x:1293,y:841,t:1527631723689};\\\", \\\"{x:1293,y:837,t:1527631723706};\\\", \\\"{x:1292,y:835,t:1527631723722};\\\", \\\"{x:1292,y:834,t:1527631723746};\\\", \\\"{x:1292,y:832,t:1527631723762};\\\", \\\"{x:1292,y:831,t:1527631724106};\\\", \\\"{x:1289,y:831,t:1527631724122};\\\", \\\"{x:1286,y:831,t:1527631724139};\\\", \\\"{x:1285,y:831,t:1527631724172};\\\", \\\"{x:1284,y:831,t:1527631724189};\\\", \\\"{x:1283,y:831,t:1527631724898};\\\", \\\"{x:1281,y:832,t:1527631724906};\\\", \\\"{x:1278,y:835,t:1527631724922};\\\", \\\"{x:1273,y:839,t:1527631724938};\\\", \\\"{x:1269,y:842,t:1527631724955};\\\", \\\"{x:1267,y:843,t:1527631724972};\\\", \\\"{x:1265,y:846,t:1527631724988};\\\", \\\"{x:1262,y:849,t:1527631725005};\\\", \\\"{x:1258,y:856,t:1527631725022};\\\", \\\"{x:1255,y:859,t:1527631725037};\\\", \\\"{x:1252,y:862,t:1527631725055};\\\", \\\"{x:1250,y:865,t:1527631725072};\\\", \\\"{x:1248,y:866,t:1527631725088};\\\", \\\"{x:1246,y:869,t:1527631725105};\\\", \\\"{x:1244,y:871,t:1527631725121};\\\", \\\"{x:1242,y:876,t:1527631725138};\\\", \\\"{x:1238,y:880,t:1527631725154};\\\", \\\"{x:1234,y:885,t:1527631725171};\\\", \\\"{x:1231,y:888,t:1527631725188};\\\", \\\"{x:1228,y:891,t:1527631725205};\\\", \\\"{x:1225,y:895,t:1527631725221};\\\", \\\"{x:1223,y:899,t:1527631725238};\\\", \\\"{x:1221,y:902,t:1527631725255};\\\", \\\"{x:1219,y:905,t:1527631725271};\\\", \\\"{x:1218,y:910,t:1527631725288};\\\", \\\"{x:1216,y:915,t:1527631725305};\\\", \\\"{x:1216,y:921,t:1527631725321};\\\", \\\"{x:1214,y:942,t:1527631725337};\\\", \\\"{x:1214,y:954,t:1527631725355};\\\", \\\"{x:1214,y:962,t:1527631725371};\\\", \\\"{x:1214,y:967,t:1527631725388};\\\", \\\"{x:1215,y:972,t:1527631725405};\\\", \\\"{x:1217,y:977,t:1527631725421};\\\", \\\"{x:1220,y:979,t:1527631725438};\\\", \\\"{x:1225,y:983,t:1527631725455};\\\", \\\"{x:1234,y:991,t:1527631725471};\\\", \\\"{x:1242,y:994,t:1527631725488};\\\", \\\"{x:1253,y:996,t:1527631725505};\\\", \\\"{x:1260,y:996,t:1527631725521};\\\", \\\"{x:1266,y:996,t:1527631725538};\\\", \\\"{x:1269,y:996,t:1527631725555};\\\", \\\"{x:1272,y:995,t:1527631725571};\\\", \\\"{x:1280,y:994,t:1527631725588};\\\", \\\"{x:1294,y:989,t:1527631725605};\\\", \\\"{x:1306,y:985,t:1527631725621};\\\", \\\"{x:1320,y:981,t:1527631725638};\\\", \\\"{x:1332,y:977,t:1527631725655};\\\", \\\"{x:1335,y:976,t:1527631725671};\\\", \\\"{x:1334,y:975,t:1527631725898};\\\", \\\"{x:1331,y:973,t:1527631725906};\\\", \\\"{x:1330,y:972,t:1527631725921};\\\", \\\"{x:1325,y:970,t:1527631725938};\\\", \\\"{x:1323,y:969,t:1527631725954};\\\", \\\"{x:1320,y:968,t:1527631725971};\\\", \\\"{x:1318,y:966,t:1527631725988};\\\", \\\"{x:1316,y:965,t:1527631726005};\\\", \\\"{x:1314,y:964,t:1527631726021};\\\", \\\"{x:1309,y:962,t:1527631726038};\\\", \\\"{x:1305,y:960,t:1527631726054};\\\", \\\"{x:1300,y:958,t:1527631726071};\\\", \\\"{x:1298,y:957,t:1527631726088};\\\", \\\"{x:1297,y:956,t:1527631726162};\\\", \\\"{x:1295,y:955,t:1527631726186};\\\", \\\"{x:1294,y:955,t:1527631726194};\\\", \\\"{x:1292,y:955,t:1527631726204};\\\", \\\"{x:1290,y:954,t:1527631726221};\\\", \\\"{x:1288,y:954,t:1527631726239};\\\", \\\"{x:1285,y:953,t:1527631726258};\\\", \\\"{x:1284,y:953,t:1527631726451};\\\", \\\"{x:1282,y:953,t:1527631726467};\\\", \\\"{x:1280,y:953,t:1527631726475};\\\", \\\"{x:1279,y:953,t:1527631726523};\\\", \\\"{x:1277,y:953,t:1527631728506};\\\", \\\"{x:1274,y:953,t:1527631728530};\\\", \\\"{x:1273,y:953,t:1527631728554};\\\", \\\"{x:1272,y:951,t:1527631728569};\\\", \\\"{x:1271,y:951,t:1527631728658};\\\", \\\"{x:1270,y:950,t:1527631728835};\\\", \\\"{x:1269,y:950,t:1527631728843};\\\", \\\"{x:1267,y:948,t:1527631728854};\\\", \\\"{x:1262,y:945,t:1527631728870};\\\", \\\"{x:1255,y:940,t:1527631728887};\\\", \\\"{x:1250,y:936,t:1527631728904};\\\", \\\"{x:1244,y:931,t:1527631728920};\\\", \\\"{x:1241,y:927,t:1527631728937};\\\", \\\"{x:1238,y:924,t:1527631728954};\\\", \\\"{x:1236,y:922,t:1527631728969};\\\", \\\"{x:1235,y:921,t:1527631728986};\\\", \\\"{x:1234,y:920,t:1527631729004};\\\", \\\"{x:1233,y:920,t:1527631729019};\\\", \\\"{x:1232,y:918,t:1527631729037};\\\", \\\"{x:1231,y:916,t:1527631729053};\\\", \\\"{x:1229,y:913,t:1527631729070};\\\", \\\"{x:1228,y:910,t:1527631729086};\\\", \\\"{x:1225,y:906,t:1527631729103};\\\", \\\"{x:1222,y:902,t:1527631729120};\\\", \\\"{x:1221,y:899,t:1527631729136};\\\", \\\"{x:1220,y:895,t:1527631729153};\\\", \\\"{x:1218,y:892,t:1527631729169};\\\", \\\"{x:1218,y:888,t:1527631729186};\\\", \\\"{x:1217,y:888,t:1527631729204};\\\", \\\"{x:1217,y:886,t:1527631729220};\\\", \\\"{x:1217,y:885,t:1527631729237};\\\", \\\"{x:1215,y:883,t:1527631729253};\\\", \\\"{x:1215,y:882,t:1527631729270};\\\", \\\"{x:1214,y:878,t:1527631729287};\\\", \\\"{x:1213,y:874,t:1527631729304};\\\", \\\"{x:1213,y:871,t:1527631729320};\\\", \\\"{x:1211,y:869,t:1527631729337};\\\", \\\"{x:1211,y:866,t:1527631729354};\\\", \\\"{x:1211,y:865,t:1527631729370};\\\", \\\"{x:1211,y:864,t:1527631729387};\\\", \\\"{x:1210,y:862,t:1527631729403};\\\", \\\"{x:1209,y:859,t:1527631729420};\\\", \\\"{x:1209,y:858,t:1527631729437};\\\", \\\"{x:1208,y:857,t:1527631729453};\\\", \\\"{x:1208,y:855,t:1527631729470};\\\", \\\"{x:1207,y:855,t:1527631729491};\\\", \\\"{x:1207,y:854,t:1527631729523};\\\", \\\"{x:1207,y:853,t:1527631729539};\\\", \\\"{x:1207,y:852,t:1527631729553};\\\", \\\"{x:1207,y:851,t:1527631729579};\\\", \\\"{x:1207,y:850,t:1527631729595};\\\", \\\"{x:1207,y:849,t:1527631729618};\\\", \\\"{x:1207,y:848,t:1527631729667};\\\", \\\"{x:1206,y:847,t:1527631729674};\\\", \\\"{x:1206,y:846,t:1527631729771};\\\", \\\"{x:1206,y:845,t:1527631729795};\\\", \\\"{x:1206,y:844,t:1527631729803};\\\", \\\"{x:1206,y:843,t:1527631729820};\\\", \\\"{x:1206,y:841,t:1527631729837};\\\", \\\"{x:1206,y:840,t:1527631729853};\\\", \\\"{x:1206,y:839,t:1527631729875};\\\", \\\"{x:1206,y:837,t:1527631729886};\\\", \\\"{x:1206,y:836,t:1527631729915};\\\", \\\"{x:1206,y:835,t:1527631729940};\\\", \\\"{x:1207,y:834,t:1527631729953};\\\", \\\"{x:1200,y:834,t:1527631730500};\\\", \\\"{x:1190,y:833,t:1527631730507};\\\", \\\"{x:1185,y:833,t:1527631730519};\\\", \\\"{x:1168,y:828,t:1527631730536};\\\", \\\"{x:1130,y:811,t:1527631730553};\\\", \\\"{x:1027,y:762,t:1527631730569};\\\", \\\"{x:890,y:708,t:1527631730586};\\\", \\\"{x:643,y:634,t:1527631730604};\\\", \\\"{x:475,y:587,t:1527631730619};\\\", \\\"{x:321,y:549,t:1527631730635};\\\", \\\"{x:144,y:500,t:1527631730663};\\\", \\\"{x:101,y:485,t:1527631730680};\\\", \\\"{x:91,y:480,t:1527631730697};\\\", \\\"{x:89,y:479,t:1527631730713};\\\", \\\"{x:89,y:478,t:1527631730729};\\\", \\\"{x:91,y:478,t:1527631730834};\\\", \\\"{x:97,y:478,t:1527631730848};\\\", \\\"{x:117,y:481,t:1527631730864};\\\", \\\"{x:142,y:488,t:1527631730880};\\\", \\\"{x:162,y:492,t:1527631730898};\\\", \\\"{x:168,y:494,t:1527631730913};\\\", \\\"{x:172,y:496,t:1527631730930};\\\", \\\"{x:172,y:498,t:1527631730948};\\\", \\\"{x:172,y:499,t:1527631730964};\\\", \\\"{x:172,y:500,t:1527631731003};\\\", \\\"{x:172,y:502,t:1527631731043};\\\", \\\"{x:170,y:504,t:1527631731059};\\\", \\\"{x:167,y:505,t:1527631731067};\\\", \\\"{x:166,y:506,t:1527631731082};\\\", \\\"{x:164,y:508,t:1527631731097};\\\", \\\"{x:161,y:509,t:1527631731115};\\\", \\\"{x:160,y:510,t:1527631731154};\\\", \\\"{x:160,y:511,t:1527631731164};\\\", \\\"{x:159,y:514,t:1527631731181};\\\", \\\"{x:159,y:515,t:1527631731197};\\\", \\\"{x:159,y:517,t:1527631731213};\\\", \\\"{x:159,y:518,t:1527631731230};\\\", \\\"{x:159,y:519,t:1527631731258};\\\", \\\"{x:159,y:520,t:1527631731273};\\\", \\\"{x:159,y:521,t:1527631731618};\\\", \\\"{x:163,y:521,t:1527631731631};\\\", \\\"{x:186,y:521,t:1527631731648};\\\", \\\"{x:219,y:521,t:1527631731665};\\\", \\\"{x:262,y:528,t:1527631731681};\\\", \\\"{x:324,y:533,t:1527631731698};\\\", \\\"{x:442,y:548,t:1527631731714};\\\", \\\"{x:540,y:564,t:1527631731732};\\\", \\\"{x:638,y:581,t:1527631731748};\\\", \\\"{x:739,y:603,t:1527631731765};\\\", \\\"{x:850,y:636,t:1527631731782};\\\", \\\"{x:931,y:664,t:1527631731797};\\\", \\\"{x:1012,y:691,t:1527631731814};\\\", \\\"{x:1070,y:714,t:1527631731831};\\\", \\\"{x:1121,y:741,t:1527631731848};\\\", \\\"{x:1163,y:769,t:1527631731864};\\\", \\\"{x:1194,y:790,t:1527631731882};\\\", \\\"{x:1225,y:810,t:1527631731898};\\\", \\\"{x:1249,y:827,t:1527631731914};\\\", \\\"{x:1256,y:833,t:1527631731932};\\\", \\\"{x:1259,y:836,t:1527631731947};\\\", \\\"{x:1264,y:844,t:1527631731965};\\\", \\\"{x:1270,y:853,t:1527631731982};\\\", \\\"{x:1272,y:857,t:1527631731997};\\\", \\\"{x:1275,y:862,t:1527631732015};\\\", \\\"{x:1276,y:863,t:1527631732032};\\\", \\\"{x:1276,y:864,t:1527631732048};\\\", \\\"{x:1276,y:865,t:1527631732064};\\\", \\\"{x:1276,y:867,t:1527631732081};\\\", \\\"{x:1277,y:874,t:1527631732098};\\\", \\\"{x:1278,y:881,t:1527631732114};\\\", \\\"{x:1278,y:892,t:1527631732131};\\\", \\\"{x:1278,y:904,t:1527631732149};\\\", \\\"{x:1278,y:917,t:1527631732165};\\\", \\\"{x:1278,y:933,t:1527631732181};\\\", \\\"{x:1279,y:949,t:1527631732199};\\\", \\\"{x:1280,y:957,t:1527631732214};\\\", \\\"{x:1280,y:960,t:1527631732232};\\\", \\\"{x:1280,y:961,t:1527631732250};\\\", \\\"{x:1280,y:962,t:1527631732264};\\\", \\\"{x:1280,y:964,t:1527631732282};\\\", \\\"{x:1280,y:967,t:1527631732298};\\\", \\\"{x:1280,y:968,t:1527631732322};\\\", \\\"{x:1280,y:970,t:1527631732347};\\\", \\\"{x:1278,y:969,t:1527631732451};\\\", \\\"{x:1275,y:964,t:1527631732466};\\\", \\\"{x:1270,y:956,t:1527631732482};\\\", \\\"{x:1264,y:942,t:1527631732499};\\\", \\\"{x:1258,y:933,t:1527631732515};\\\", \\\"{x:1251,y:922,t:1527631732532};\\\", \\\"{x:1247,y:916,t:1527631732549};\\\", \\\"{x:1242,y:911,t:1527631732566};\\\", \\\"{x:1238,y:906,t:1527631732582};\\\", \\\"{x:1235,y:902,t:1527631732599};\\\", \\\"{x:1233,y:898,t:1527631732616};\\\", \\\"{x:1231,y:893,t:1527631732633};\\\", \\\"{x:1228,y:886,t:1527631732649};\\\", \\\"{x:1227,y:883,t:1527631732666};\\\", \\\"{x:1224,y:878,t:1527631732682};\\\", \\\"{x:1222,y:874,t:1527631732699};\\\", \\\"{x:1218,y:869,t:1527631732716};\\\", \\\"{x:1216,y:863,t:1527631732732};\\\", \\\"{x:1210,y:854,t:1527631732749};\\\", \\\"{x:1205,y:843,t:1527631732766};\\\", \\\"{x:1199,y:830,t:1527631732784};\\\", \\\"{x:1189,y:817,t:1527631732799};\\\", \\\"{x:1184,y:810,t:1527631732816};\\\", \\\"{x:1180,y:804,t:1527631732832};\\\", \\\"{x:1179,y:802,t:1527631732849};\\\", \\\"{x:1177,y:799,t:1527631732866};\\\", \\\"{x:1174,y:796,t:1527631732882};\\\", \\\"{x:1173,y:793,t:1527631732899};\\\", \\\"{x:1172,y:792,t:1527631732923};\\\", \\\"{x:1171,y:792,t:1527631733042};\\\", \\\"{x:1170,y:795,t:1527631733050};\\\", \\\"{x:1170,y:798,t:1527631733066};\\\", \\\"{x:1170,y:809,t:1527631733082};\\\", \\\"{x:1170,y:824,t:1527631733099};\\\", \\\"{x:1174,y:845,t:1527631733115};\\\", \\\"{x:1182,y:864,t:1527631733133};\\\", \\\"{x:1189,y:882,t:1527631733149};\\\", \\\"{x:1196,y:893,t:1527631733165};\\\", \\\"{x:1202,y:905,t:1527631733183};\\\", \\\"{x:1209,y:916,t:1527631733198};\\\", \\\"{x:1216,y:926,t:1527631733216};\\\", \\\"{x:1224,y:934,t:1527631733234};\\\", \\\"{x:1227,y:936,t:1527631733248};\\\", \\\"{x:1230,y:939,t:1527631733265};\\\", \\\"{x:1235,y:946,t:1527631733282};\\\", \\\"{x:1240,y:952,t:1527631733298};\\\", \\\"{x:1246,y:956,t:1527631733315};\\\", \\\"{x:1249,y:959,t:1527631733333};\\\", \\\"{x:1250,y:959,t:1527631733349};\\\", \\\"{x:1251,y:959,t:1527631733365};\\\", \\\"{x:1253,y:960,t:1527631733382};\\\", \\\"{x:1253,y:962,t:1527631733398};\\\", \\\"{x:1254,y:962,t:1527631733627};\\\", \\\"{x:1255,y:962,t:1527631733634};\\\", \\\"{x:1256,y:961,t:1527631733650};\\\", \\\"{x:1264,y:959,t:1527631733666};\\\", \\\"{x:1269,y:956,t:1527631733682};\\\", \\\"{x:1273,y:952,t:1527631733700};\\\", \\\"{x:1280,y:945,t:1527631733715};\\\", \\\"{x:1284,y:939,t:1527631733733};\\\", \\\"{x:1287,y:934,t:1527631733750};\\\", \\\"{x:1288,y:931,t:1527631733766};\\\", \\\"{x:1289,y:925,t:1527631733782};\\\", \\\"{x:1290,y:912,t:1527631733800};\\\", \\\"{x:1293,y:895,t:1527631733816};\\\", \\\"{x:1296,y:880,t:1527631733833};\\\", \\\"{x:1298,y:871,t:1527631733850};\\\", \\\"{x:1299,y:867,t:1527631733866};\\\", \\\"{x:1300,y:863,t:1527631733883};\\\", \\\"{x:1300,y:860,t:1527631733900};\\\", \\\"{x:1302,y:858,t:1527631733916};\\\", \\\"{x:1303,y:855,t:1527631733933};\\\", \\\"{x:1306,y:850,t:1527631733950};\\\", \\\"{x:1310,y:844,t:1527631733966};\\\", \\\"{x:1312,y:840,t:1527631733983};\\\", \\\"{x:1317,y:834,t:1527631734000};\\\", \\\"{x:1321,y:829,t:1527631734017};\\\", \\\"{x:1324,y:824,t:1527631734033};\\\", \\\"{x:1326,y:822,t:1527631734050};\\\", \\\"{x:1330,y:817,t:1527631734066};\\\", \\\"{x:1334,y:812,t:1527631734083};\\\", \\\"{x:1334,y:811,t:1527631734100};\\\", \\\"{x:1335,y:809,t:1527631734117};\\\", \\\"{x:1335,y:808,t:1527631734707};\\\", \\\"{x:1335,y:809,t:1527631734763};\\\", \\\"{x:1334,y:813,t:1527631734771};\\\", \\\"{x:1333,y:816,t:1527631734787};\\\", \\\"{x:1332,y:817,t:1527631734801};\\\", \\\"{x:1331,y:820,t:1527631734817};\\\", \\\"{x:1328,y:824,t:1527631734834};\\\", \\\"{x:1328,y:827,t:1527631734850};\\\", \\\"{x:1324,y:839,t:1527631734867};\\\", \\\"{x:1318,y:850,t:1527631734884};\\\", \\\"{x:1313,y:862,t:1527631734901};\\\", \\\"{x:1308,y:873,t:1527631734917};\\\", \\\"{x:1304,y:882,t:1527631734934};\\\", \\\"{x:1299,y:892,t:1527631734950};\\\", \\\"{x:1295,y:897,t:1527631734966};\\\", \\\"{x:1291,y:908,t:1527631734984};\\\", \\\"{x:1290,y:922,t:1527631734999};\\\", \\\"{x:1286,y:935,t:1527631735016};\\\", \\\"{x:1284,y:947,t:1527631735033};\\\", \\\"{x:1281,y:958,t:1527631735049};\\\", \\\"{x:1280,y:969,t:1527631735066};\\\", \\\"{x:1280,y:971,t:1527631735084};\\\", \\\"{x:1280,y:972,t:1527631735100};\\\", \\\"{x:1280,y:970,t:1527631735203};\\\", \\\"{x:1283,y:965,t:1527631735217};\\\", \\\"{x:1289,y:958,t:1527631735235};\\\", \\\"{x:1296,y:947,t:1527631735251};\\\", \\\"{x:1299,y:944,t:1527631735267};\\\", \\\"{x:1302,y:940,t:1527631735284};\\\", \\\"{x:1304,y:937,t:1527631735302};\\\", \\\"{x:1304,y:936,t:1527631735317};\\\", \\\"{x:1306,y:934,t:1527631735335};\\\", \\\"{x:1306,y:933,t:1527631735351};\\\", \\\"{x:1306,y:931,t:1527631735419};\\\", \\\"{x:1306,y:929,t:1527631735434};\\\", \\\"{x:1312,y:917,t:1527631735451};\\\", \\\"{x:1316,y:909,t:1527631735467};\\\", \\\"{x:1320,y:901,t:1527631735485};\\\", \\\"{x:1324,y:895,t:1527631735501};\\\", \\\"{x:1325,y:891,t:1527631735517};\\\", \\\"{x:1327,y:888,t:1527631735534};\\\", \\\"{x:1331,y:882,t:1527631735551};\\\", \\\"{x:1332,y:878,t:1527631735567};\\\", \\\"{x:1337,y:872,t:1527631735583};\\\", \\\"{x:1340,y:867,t:1527631735600};\\\", \\\"{x:1344,y:858,t:1527631735616};\\\", \\\"{x:1347,y:851,t:1527631735633};\\\", \\\"{x:1349,y:847,t:1527631735650};\\\", \\\"{x:1351,y:843,t:1527631735667};\\\", \\\"{x:1353,y:840,t:1527631735684};\\\", \\\"{x:1355,y:836,t:1527631735701};\\\", \\\"{x:1357,y:834,t:1527631735717};\\\", \\\"{x:1359,y:830,t:1527631735734};\\\", \\\"{x:1360,y:828,t:1527631735751};\\\", \\\"{x:1363,y:823,t:1527631735768};\\\", \\\"{x:1367,y:818,t:1527631735784};\\\", \\\"{x:1371,y:814,t:1527631735800};\\\", \\\"{x:1373,y:810,t:1527631735818};\\\", \\\"{x:1375,y:808,t:1527631735834};\\\", \\\"{x:1375,y:807,t:1527631735850};\\\", \\\"{x:1376,y:806,t:1527631735868};\\\", \\\"{x:1377,y:806,t:1527631735884};\\\", \\\"{x:1378,y:805,t:1527631735900};\\\", \\\"{x:1378,y:804,t:1527631735930};\\\", \\\"{x:1380,y:800,t:1527631736427};\\\", \\\"{x:1380,y:799,t:1527631736435};\\\", \\\"{x:1381,y:793,t:1527631736452};\\\", \\\"{x:1381,y:788,t:1527631736468};\\\", \\\"{x:1382,y:784,t:1527631736486};\\\", \\\"{x:1384,y:781,t:1527631736501};\\\", \\\"{x:1384,y:780,t:1527631736531};\\\", \\\"{x:1384,y:779,t:1527631736539};\\\", \\\"{x:1384,y:778,t:1527631736555};\\\", \\\"{x:1385,y:778,t:1527631736571};\\\", \\\"{x:1385,y:777,t:1527631736586};\\\", \\\"{x:1385,y:776,t:1527631736601};\\\", \\\"{x:1385,y:775,t:1527631736618};\\\", \\\"{x:1387,y:774,t:1527631736635};\\\", \\\"{x:1387,y:773,t:1527631738404};\\\", \\\"{x:1349,y:764,t:1527631738419};\\\", \\\"{x:1281,y:753,t:1527631738436};\\\", \\\"{x:1195,y:740,t:1527631738453};\\\", \\\"{x:1092,y:724,t:1527631738469};\\\", \\\"{x:970,y:705,t:1527631738486};\\\", \\\"{x:848,y:688,t:1527631738503};\\\", \\\"{x:737,y:674,t:1527631738519};\\\", \\\"{x:629,y:658,t:1527631738536};\\\", \\\"{x:540,y:647,t:1527631738554};\\\", \\\"{x:463,y:638,t:1527631738569};\\\", \\\"{x:364,y:625,t:1527631738603};\\\", \\\"{x:359,y:624,t:1527631738619};\\\", \\\"{x:359,y:623,t:1527631738637};\\\", \\\"{x:359,y:622,t:1527631738666};\\\", \\\"{x:359,y:621,t:1527631738674};\\\", \\\"{x:359,y:620,t:1527631738686};\\\", \\\"{x:359,y:617,t:1527631738704};\\\", \\\"{x:361,y:614,t:1527631738720};\\\", \\\"{x:363,y:613,t:1527631738736};\\\", \\\"{x:366,y:611,t:1527631738754};\\\", \\\"{x:369,y:607,t:1527631738769};\\\", \\\"{x:374,y:604,t:1527631738787};\\\", \\\"{x:381,y:601,t:1527631738804};\\\", \\\"{x:383,y:600,t:1527631738820};\\\", \\\"{x:390,y:597,t:1527631738837};\\\", \\\"{x:394,y:594,t:1527631738854};\\\", \\\"{x:396,y:593,t:1527631738870};\\\", \\\"{x:397,y:592,t:1527631738887};\\\", \\\"{x:399,y:590,t:1527631738903};\\\", \\\"{x:399,y:589,t:1527631738920};\\\", \\\"{x:399,y:588,t:1527631738936};\\\", \\\"{x:399,y:587,t:1527631738954};\\\", \\\"{x:399,y:584,t:1527631738970};\\\", \\\"{x:398,y:582,t:1527631738987};\\\", \\\"{x:394,y:579,t:1527631739004};\\\", \\\"{x:390,y:575,t:1527631739020};\\\", \\\"{x:385,y:570,t:1527631739036};\\\", \\\"{x:382,y:567,t:1527631739053};\\\", \\\"{x:382,y:565,t:1527631739098};\\\", \\\"{x:383,y:565,t:1527631739614};\\\", \\\"{x:386,y:565,t:1527631739620};\\\", \\\"{x:395,y:571,t:1527631739638};\\\", \\\"{x:416,y:580,t:1527631739655};\\\", \\\"{x:429,y:585,t:1527631739671};\\\", \\\"{x:441,y:591,t:1527631739688};\\\", \\\"{x:456,y:603,t:1527631739704};\\\", \\\"{x:467,y:617,t:1527631739721};\\\", \\\"{x:476,y:639,t:1527631739737};\\\", \\\"{x:481,y:648,t:1527631739753};\\\", \\\"{x:482,y:655,t:1527631739771};\\\", \\\"{x:483,y:658,t:1527631739788};\\\", \\\"{x:484,y:662,t:1527631739804};\\\", \\\"{x:484,y:664,t:1527631739820};\\\", \\\"{x:484,y:666,t:1527631739837};\\\", \\\"{x:484,y:667,t:1527631739855};\\\", \\\"{x:484,y:669,t:1527631739871};\\\", \\\"{x:484,y:671,t:1527631739898};\\\", \\\"{x:484,y:672,t:1527631739906};\\\", \\\"{x:484,y:675,t:1527631739923};\\\", \\\"{x:484,y:677,t:1527631739937};\\\", \\\"{x:484,y:681,t:1527631739955};\\\", \\\"{x:484,y:685,t:1527631739970};\\\", \\\"{x:484,y:689,t:1527631739987};\\\", \\\"{x:484,y:693,t:1527631740004};\\\", \\\"{x:484,y:696,t:1527631740020};\\\", \\\"{x:484,y:700,t:1527631740037};\\\", \\\"{x:484,y:704,t:1527631740055};\\\", \\\"{x:484,y:708,t:1527631740072};\\\", \\\"{x:484,y:710,t:1527631740088};\\\", \\\"{x:485,y:711,t:1527631740105};\\\", \\\"{x:485,y:712,t:1527631740122};\\\", \\\"{x:485,y:713,t:1527631740137};\\\" ] }, { \\\"rt\\\": 120691, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 470977, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -Z -K -K -K -10 AM-10 AM-11 AM-K -D -01 PM-D -Z -K -A -A -A -10 AM-11 AM-12 PM-K -K -K -12 PM-E -K -12 PM-K -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:703,t:1527631752018};\\\", \\\"{x:483,y:673,t:1527631752032};\\\", \\\"{x:473,y:614,t:1527631752048};\\\", \\\"{x:462,y:544,t:1527631752064};\\\", \\\"{x:459,y:514,t:1527631752081};\\\", \\\"{x:455,y:483,t:1527631752097};\\\", \\\"{x:451,y:452,t:1527631752113};\\\", \\\"{x:447,y:436,t:1527631752130};\\\", \\\"{x:447,y:426,t:1527631752147};\\\", \\\"{x:447,y:424,t:1527631752163};\\\", \\\"{x:448,y:426,t:1527631752555};\\\", \\\"{x:451,y:430,t:1527631752564};\\\", \\\"{x:455,y:437,t:1527631752581};\\\", \\\"{x:458,y:441,t:1527631752598};\\\", \\\"{x:462,y:446,t:1527631752614};\\\", \\\"{x:466,y:452,t:1527631752632};\\\", \\\"{x:470,y:457,t:1527631752647};\\\", \\\"{x:471,y:458,t:1527631752664};\\\", \\\"{x:471,y:459,t:1527631752681};\\\", \\\"{x:471,y:460,t:1527631752699};\\\", \\\"{x:472,y:461,t:1527631752714};\\\", \\\"{x:473,y:462,t:1527631752732};\\\", \\\"{x:473,y:463,t:1527631752762};\\\", \\\"{x:473,y:464,t:1527631752770};\\\", \\\"{x:473,y:466,t:1527631752786};\\\", \\\"{x:473,y:468,t:1527631752798};\\\", \\\"{x:474,y:469,t:1527631752813};\\\", \\\"{x:474,y:471,t:1527631752831};\\\", \\\"{x:475,y:473,t:1527631752848};\\\", \\\"{x:476,y:475,t:1527631752864};\\\", \\\"{x:476,y:476,t:1527631752881};\\\", \\\"{x:477,y:476,t:1527631752922};\\\", \\\"{x:480,y:476,t:1527631753770};\\\", \\\"{x:485,y:476,t:1527631753783};\\\", \\\"{x:508,y:476,t:1527631753799};\\\", \\\"{x:549,y:476,t:1527631753816};\\\", \\\"{x:619,y:476,t:1527631753832};\\\", \\\"{x:680,y:476,t:1527631753848};\\\", \\\"{x:742,y:476,t:1527631753866};\\\", \\\"{x:867,y:476,t:1527631753882};\\\", \\\"{x:950,y:476,t:1527631753898};\\\", \\\"{x:1030,y:476,t:1527631753916};\\\", \\\"{x:1083,y:476,t:1527631753933};\\\", \\\"{x:1120,y:476,t:1527631753949};\\\", \\\"{x:1157,y:476,t:1527631753966};\\\", \\\"{x:1191,y:476,t:1527631753983};\\\", \\\"{x:1219,y:480,t:1527631753999};\\\", \\\"{x:1242,y:480,t:1527631754015};\\\", \\\"{x:1260,y:480,t:1527631754033};\\\", \\\"{x:1278,y:480,t:1527631754049};\\\", \\\"{x:1295,y:480,t:1527631754065};\\\", \\\"{x:1304,y:480,t:1527631754082};\\\", \\\"{x:1305,y:480,t:1527631754099};\\\", \\\"{x:1308,y:480,t:1527631754115};\\\", \\\"{x:1313,y:480,t:1527631754132};\\\", \\\"{x:1316,y:480,t:1527631754149};\\\", \\\"{x:1319,y:479,t:1527631754165};\\\", \\\"{x:1323,y:478,t:1527631754182};\\\", \\\"{x:1328,y:475,t:1527631754199};\\\", \\\"{x:1338,y:472,t:1527631754215};\\\", \\\"{x:1345,y:471,t:1527631754232};\\\", \\\"{x:1363,y:470,t:1527631754249};\\\", \\\"{x:1374,y:467,t:1527631754266};\\\", \\\"{x:1399,y:465,t:1527631754282};\\\", \\\"{x:1418,y:465,t:1527631754299};\\\", \\\"{x:1450,y:464,t:1527631754316};\\\", \\\"{x:1484,y:464,t:1527631754333};\\\", \\\"{x:1532,y:464,t:1527631754350};\\\", \\\"{x:1582,y:464,t:1527631754365};\\\", \\\"{x:1627,y:464,t:1527631754383};\\\", \\\"{x:1654,y:462,t:1527631754400};\\\", \\\"{x:1682,y:459,t:1527631754417};\\\", \\\"{x:1697,y:456,t:1527631754432};\\\", \\\"{x:1702,y:455,t:1527631754449};\\\", \\\"{x:1702,y:454,t:1527631754515};\\\", \\\"{x:1702,y:453,t:1527631754522};\\\", \\\"{x:1702,y:452,t:1527631754532};\\\", \\\"{x:1699,y:448,t:1527631754550};\\\", \\\"{x:1690,y:444,t:1527631754567};\\\", \\\"{x:1676,y:440,t:1527631754582};\\\", \\\"{x:1656,y:433,t:1527631754599};\\\", \\\"{x:1637,y:433,t:1527631754616};\\\", \\\"{x:1625,y:433,t:1527631754632};\\\", \\\"{x:1610,y:433,t:1527631754652};\\\", \\\"{x:1597,y:433,t:1527631754666};\\\", \\\"{x:1595,y:434,t:1527631754682};\\\", \\\"{x:1594,y:434,t:1527631754699};\\\", \\\"{x:1593,y:435,t:1527631754866};\\\", \\\"{x:1593,y:436,t:1527631754884};\\\", \\\"{x:1592,y:437,t:1527631754900};\\\", \\\"{x:1591,y:438,t:1527631754917};\\\", \\\"{x:1591,y:441,t:1527631754933};\\\", \\\"{x:1590,y:446,t:1527631754949};\\\", \\\"{x:1590,y:450,t:1527631754967};\\\", \\\"{x:1589,y:451,t:1527631754984};\\\", \\\"{x:1587,y:455,t:1527631755000};\\\", \\\"{x:1586,y:460,t:1527631755016};\\\", \\\"{x:1583,y:464,t:1527631755034};\\\", \\\"{x:1583,y:468,t:1527631755050};\\\", \\\"{x:1580,y:474,t:1527631755066};\\\", \\\"{x:1576,y:480,t:1527631755083};\\\", \\\"{x:1574,y:486,t:1527631755099};\\\", \\\"{x:1572,y:489,t:1527631755117};\\\", \\\"{x:1571,y:493,t:1527631755133};\\\", \\\"{x:1568,y:500,t:1527631755150};\\\", \\\"{x:1566,y:505,t:1527631755167};\\\", \\\"{x:1563,y:510,t:1527631755183};\\\", \\\"{x:1560,y:515,t:1527631755199};\\\", \\\"{x:1560,y:516,t:1527631755216};\\\", \\\"{x:1557,y:523,t:1527631755233};\\\", \\\"{x:1556,y:524,t:1527631755250};\\\", \\\"{x:1555,y:527,t:1527631755266};\\\", \\\"{x:1555,y:531,t:1527631755283};\\\", \\\"{x:1553,y:534,t:1527631755299};\\\", \\\"{x:1551,y:538,t:1527631755316};\\\", \\\"{x:1550,y:539,t:1527631755333};\\\", \\\"{x:1549,y:541,t:1527631755350};\\\", \\\"{x:1548,y:544,t:1527631755366};\\\", \\\"{x:1546,y:547,t:1527631755383};\\\", \\\"{x:1544,y:552,t:1527631755401};\\\", \\\"{x:1540,y:559,t:1527631755416};\\\", \\\"{x:1538,y:562,t:1527631755434};\\\", \\\"{x:1534,y:566,t:1527631755451};\\\", \\\"{x:1532,y:571,t:1527631755467};\\\", \\\"{x:1529,y:574,t:1527631755484};\\\", \\\"{x:1527,y:578,t:1527631755501};\\\", \\\"{x:1524,y:582,t:1527631755517};\\\", \\\"{x:1521,y:585,t:1527631755534};\\\", \\\"{x:1519,y:589,t:1527631755550};\\\", \\\"{x:1515,y:592,t:1527631755567};\\\", \\\"{x:1515,y:593,t:1527631755584};\\\", \\\"{x:1513,y:597,t:1527631755601};\\\", \\\"{x:1511,y:599,t:1527631755617};\\\", \\\"{x:1508,y:607,t:1527631755634};\\\", \\\"{x:1504,y:614,t:1527631755650};\\\", \\\"{x:1500,y:627,t:1527631755667};\\\", \\\"{x:1495,y:637,t:1527631755684};\\\", \\\"{x:1492,y:646,t:1527631755701};\\\", \\\"{x:1488,y:654,t:1527631755717};\\\", \\\"{x:1480,y:668,t:1527631755733};\\\", \\\"{x:1476,y:677,t:1527631755751};\\\", \\\"{x:1473,y:683,t:1527631755767};\\\", \\\"{x:1471,y:687,t:1527631755783};\\\", \\\"{x:1471,y:690,t:1527631755801};\\\", \\\"{x:1470,y:690,t:1527631755817};\\\", \\\"{x:1468,y:694,t:1527631755833};\\\", \\\"{x:1466,y:697,t:1527631755850};\\\", \\\"{x:1465,y:698,t:1527631755868};\\\", \\\"{x:1464,y:699,t:1527631755883};\\\", \\\"{x:1464,y:701,t:1527631755946};\\\", \\\"{x:1463,y:701,t:1527631755955};\\\", \\\"{x:1463,y:702,t:1527631755986};\\\", \\\"{x:1462,y:703,t:1527631756001};\\\", \\\"{x:1461,y:704,t:1527631756018};\\\", \\\"{x:1462,y:704,t:1527631756451};\\\", \\\"{x:1469,y:699,t:1527631756468};\\\", \\\"{x:1472,y:694,t:1527631756485};\\\", \\\"{x:1478,y:688,t:1527631756501};\\\", \\\"{x:1485,y:682,t:1527631756518};\\\", \\\"{x:1493,y:674,t:1527631756535};\\\", \\\"{x:1503,y:664,t:1527631756551};\\\", \\\"{x:1516,y:649,t:1527631756567};\\\", \\\"{x:1523,y:634,t:1527631756585};\\\", \\\"{x:1539,y:609,t:1527631756601};\\\", \\\"{x:1546,y:597,t:1527631756618};\\\", \\\"{x:1556,y:580,t:1527631756634};\\\", \\\"{x:1560,y:572,t:1527631756652};\\\", \\\"{x:1562,y:563,t:1527631756668};\\\", \\\"{x:1566,y:550,t:1527631756686};\\\", \\\"{x:1569,y:541,t:1527631756701};\\\", \\\"{x:1570,y:535,t:1527631756718};\\\", \\\"{x:1570,y:529,t:1527631756735};\\\", \\\"{x:1570,y:524,t:1527631756751};\\\", \\\"{x:1570,y:520,t:1527631756768};\\\", \\\"{x:1570,y:516,t:1527631756785};\\\", \\\"{x:1570,y:514,t:1527631756801};\\\", \\\"{x:1571,y:512,t:1527631756818};\\\", \\\"{x:1571,y:511,t:1527631756923};\\\", \\\"{x:1571,y:510,t:1527631756935};\\\", \\\"{x:1571,y:507,t:1527631756952};\\\", \\\"{x:1571,y:502,t:1527631756968};\\\", \\\"{x:1571,y:495,t:1527631756984};\\\", \\\"{x:1571,y:481,t:1527631757002};\\\", \\\"{x:1571,y:469,t:1527631757018};\\\", \\\"{x:1571,y:458,t:1527631757034};\\\", \\\"{x:1571,y:451,t:1527631757051};\\\", \\\"{x:1571,y:443,t:1527631757068};\\\", \\\"{x:1571,y:440,t:1527631757085};\\\", \\\"{x:1571,y:436,t:1527631757102};\\\", \\\"{x:1571,y:432,t:1527631757118};\\\", \\\"{x:1571,y:430,t:1527631757135};\\\", \\\"{x:1571,y:426,t:1527631757152};\\\", \\\"{x:1571,y:423,t:1527631757169};\\\", \\\"{x:1571,y:420,t:1527631757184};\\\", \\\"{x:1571,y:418,t:1527631757202};\\\", \\\"{x:1571,y:417,t:1527631757218};\\\", \\\"{x:1571,y:415,t:1527631757235};\\\", \\\"{x:1571,y:414,t:1527631757252};\\\", \\\"{x:1571,y:413,t:1527631757269};\\\", \\\"{x:1573,y:412,t:1527631757284};\\\", \\\"{x:1574,y:412,t:1527631757302};\\\", \\\"{x:1576,y:412,t:1527631757322};\\\", \\\"{x:1578,y:412,t:1527631757346};\\\", \\\"{x:1574,y:412,t:1527631757658};\\\", \\\"{x:1569,y:414,t:1527631757669};\\\", \\\"{x:1560,y:419,t:1527631757686};\\\", \\\"{x:1552,y:422,t:1527631757702};\\\", \\\"{x:1544,y:428,t:1527631757719};\\\", \\\"{x:1534,y:433,t:1527631757736};\\\", \\\"{x:1523,y:434,t:1527631757751};\\\", \\\"{x:1497,y:438,t:1527631757769};\\\", \\\"{x:1424,y:444,t:1527631757786};\\\", \\\"{x:1387,y:447,t:1527631757801};\\\", \\\"{x:1251,y:457,t:1527631757819};\\\", \\\"{x:1162,y:472,t:1527631757836};\\\", \\\"{x:1089,y:484,t:1527631757852};\\\", \\\"{x:1063,y:485,t:1527631757869};\\\", \\\"{x:1005,y:496,t:1527631757886};\\\", \\\"{x:978,y:497,t:1527631757902};\\\", \\\"{x:950,y:497,t:1527631757918};\\\", \\\"{x:897,y:495,t:1527631757935};\\\", \\\"{x:865,y:495,t:1527631757952};\\\", \\\"{x:838,y:494,t:1527631757969};\\\", \\\"{x:792,y:497,t:1527631757986};\\\", \\\"{x:765,y:497,t:1527631758002};\\\", \\\"{x:742,y:499,t:1527631758019};\\\", \\\"{x:723,y:501,t:1527631758035};\\\", \\\"{x:706,y:503,t:1527631758053};\\\", \\\"{x:692,y:506,t:1527631758070};\\\", \\\"{x:682,y:508,t:1527631758085};\\\", \\\"{x:671,y:513,t:1527631758102};\\\", \\\"{x:657,y:517,t:1527631758118};\\\", \\\"{x:640,y:518,t:1527631758135};\\\", \\\"{x:613,y:524,t:1527631758153};\\\", \\\"{x:575,y:530,t:1527631758170};\\\", \\\"{x:553,y:533,t:1527631758185};\\\", \\\"{x:528,y:536,t:1527631758202};\\\", \\\"{x:503,y:541,t:1527631758218};\\\", \\\"{x:476,y:544,t:1527631758235};\\\", \\\"{x:453,y:544,t:1527631758252};\\\", \\\"{x:428,y:546,t:1527631758268};\\\", \\\"{x:412,y:546,t:1527631758285};\\\", \\\"{x:401,y:546,t:1527631758302};\\\", \\\"{x:395,y:546,t:1527631758318};\\\", \\\"{x:392,y:545,t:1527631758335};\\\", \\\"{x:390,y:544,t:1527631758352};\\\", \\\"{x:389,y:544,t:1527631758368};\\\", \\\"{x:385,y:542,t:1527631758387};\\\", \\\"{x:383,y:539,t:1527631758402};\\\", \\\"{x:382,y:537,t:1527631758419};\\\", \\\"{x:381,y:536,t:1527631758437};\\\", \\\"{x:381,y:535,t:1527631758498};\\\", \\\"{x:381,y:533,t:1527631758529};\\\", \\\"{x:381,y:532,t:1527631758546};\\\", \\\"{x:380,y:531,t:1527631758553};\\\", \\\"{x:380,y:530,t:1527631758570};\\\", \\\"{x:380,y:529,t:1527631758698};\\\", \\\"{x:381,y:528,t:1527631758706};\\\", \\\"{x:385,y:525,t:1527631758720};\\\", \\\"{x:412,y:518,t:1527631758737};\\\", \\\"{x:501,y:503,t:1527631758754};\\\", \\\"{x:702,y:476,t:1527631758769};\\\", \\\"{x:868,y:454,t:1527631758785};\\\", \\\"{x:1039,y:427,t:1527631758803};\\\", \\\"{x:1192,y:401,t:1527631758819};\\\", \\\"{x:1315,y:361,t:1527631758835};\\\", \\\"{x:1399,y:328,t:1527631758853};\\\", \\\"{x:1458,y:302,t:1527631758869};\\\", \\\"{x:1490,y:285,t:1527631758885};\\\", \\\"{x:1504,y:269,t:1527631758902};\\\", \\\"{x:1514,y:249,t:1527631758920};\\\", \\\"{x:1521,y:224,t:1527631758935};\\\", \\\"{x:1523,y:200,t:1527631758952};\\\", \\\"{x:1523,y:178,t:1527631758969};\\\", \\\"{x:1523,y:169,t:1527631758985};\\\", \\\"{x:1523,y:164,t:1527631759003};\\\", \\\"{x:1523,y:160,t:1527631759020};\\\", \\\"{x:1523,y:158,t:1527631759037};\\\", \\\"{x:1523,y:157,t:1527631759052};\\\", \\\"{x:1524,y:161,t:1527631759171};\\\", \\\"{x:1525,y:175,t:1527631759186};\\\", \\\"{x:1529,y:199,t:1527631759203};\\\", \\\"{x:1537,y:229,t:1527631759219};\\\", \\\"{x:1553,y:273,t:1527631759237};\\\", \\\"{x:1573,y:317,t:1527631759253};\\\", \\\"{x:1586,y:340,t:1527631759269};\\\", \\\"{x:1597,y:360,t:1527631759286};\\\", \\\"{x:1604,y:374,t:1527631759302};\\\", \\\"{x:1610,y:383,t:1527631759319};\\\", \\\"{x:1613,y:393,t:1527631759337};\\\", \\\"{x:1618,y:402,t:1527631759353};\\\", \\\"{x:1620,y:410,t:1527631759370};\\\", \\\"{x:1621,y:416,t:1527631759386};\\\", \\\"{x:1621,y:418,t:1527631759403};\\\", \\\"{x:1621,y:421,t:1527631759420};\\\", \\\"{x:1621,y:423,t:1527631759436};\\\", \\\"{x:1621,y:429,t:1527631759453};\\\", \\\"{x:1624,y:436,t:1527631759469};\\\", \\\"{x:1626,y:447,t:1527631759486};\\\", \\\"{x:1632,y:460,t:1527631759503};\\\", \\\"{x:1635,y:469,t:1527631759520};\\\", \\\"{x:1643,y:480,t:1527631759537};\\\", \\\"{x:1649,y:491,t:1527631759553};\\\", \\\"{x:1660,y:515,t:1527631759570};\\\", \\\"{x:1667,y:533,t:1527631759587};\\\", \\\"{x:1677,y:550,t:1527631759603};\\\", \\\"{x:1688,y:573,t:1527631759620};\\\", \\\"{x:1702,y:596,t:1527631759637};\\\", \\\"{x:1716,y:610,t:1527631759654};\\\", \\\"{x:1728,y:628,t:1527631759670};\\\", \\\"{x:1738,y:645,t:1527631759687};\\\", \\\"{x:1749,y:662,t:1527631759703};\\\", \\\"{x:1760,y:678,t:1527631759719};\\\", \\\"{x:1771,y:693,t:1527631759736};\\\", \\\"{x:1780,y:704,t:1527631759753};\\\", \\\"{x:1781,y:710,t:1527631759769};\\\", \\\"{x:1785,y:715,t:1527631759786};\\\", \\\"{x:1792,y:724,t:1527631759804};\\\", \\\"{x:1798,y:733,t:1527631759819};\\\", \\\"{x:1802,y:742,t:1527631759837};\\\", \\\"{x:1804,y:751,t:1527631759854};\\\", \\\"{x:1805,y:755,t:1527631759869};\\\", \\\"{x:1806,y:756,t:1527631759886};\\\", \\\"{x:1804,y:755,t:1527631760010};\\\", \\\"{x:1796,y:748,t:1527631760020};\\\", \\\"{x:1784,y:733,t:1527631760036};\\\", \\\"{x:1772,y:714,t:1527631760054};\\\", \\\"{x:1754,y:693,t:1527631760070};\\\", \\\"{x:1739,y:674,t:1527631760087};\\\", \\\"{x:1719,y:654,t:1527631760103};\\\", \\\"{x:1704,y:630,t:1527631760120};\\\", \\\"{x:1694,y:612,t:1527631760137};\\\", \\\"{x:1684,y:579,t:1527631760153};\\\", \\\"{x:1679,y:564,t:1527631760170};\\\", \\\"{x:1679,y:553,t:1527631760187};\\\", \\\"{x:1676,y:542,t:1527631760204};\\\", \\\"{x:1676,y:536,t:1527631760220};\\\", \\\"{x:1673,y:527,t:1527631760237};\\\", \\\"{x:1672,y:519,t:1527631760257};\\\", \\\"{x:1671,y:512,t:1527631760273};\\\", \\\"{x:1669,y:506,t:1527631760289};\\\", \\\"{x:1668,y:501,t:1527631760307};\\\", \\\"{x:1667,y:499,t:1527631760324};\\\", \\\"{x:1667,y:495,t:1527631760340};\\\", \\\"{x:1659,y:484,t:1527631760357};\\\", \\\"{x:1653,y:475,t:1527631760373};\\\", \\\"{x:1650,y:470,t:1527631760390};\\\", \\\"{x:1648,y:466,t:1527631760407};\\\", \\\"{x:1646,y:464,t:1527631760425};\\\", \\\"{x:1639,y:456,t:1527631760440};\\\", \\\"{x:1633,y:449,t:1527631760457};\\\", \\\"{x:1630,y:446,t:1527631760473};\\\", \\\"{x:1629,y:443,t:1527631760489};\\\", \\\"{x:1627,y:440,t:1527631760507};\\\", \\\"{x:1624,y:437,t:1527631760524};\\\", \\\"{x:1623,y:435,t:1527631760540};\\\", \\\"{x:1623,y:434,t:1527631760557};\\\", \\\"{x:1622,y:434,t:1527631761790};\\\", \\\"{x:1619,y:436,t:1527631761808};\\\", \\\"{x:1617,y:442,t:1527631761824};\\\", \\\"{x:1615,y:444,t:1527631761841};\\\", \\\"{x:1613,y:448,t:1527631761858};\\\", \\\"{x:1612,y:450,t:1527631761874};\\\", \\\"{x:1612,y:451,t:1527631761894};\\\", \\\"{x:1612,y:452,t:1527631761909};\\\", \\\"{x:1612,y:453,t:1527631761925};\\\", \\\"{x:1611,y:454,t:1527631761941};\\\", \\\"{x:1611,y:456,t:1527631761957};\\\", \\\"{x:1610,y:457,t:1527631761975};\\\", \\\"{x:1609,y:458,t:1527631761991};\\\", \\\"{x:1609,y:459,t:1527631762008};\\\", \\\"{x:1609,y:460,t:1527631762024};\\\", \\\"{x:1608,y:462,t:1527631762041};\\\", \\\"{x:1607,y:464,t:1527631762058};\\\", \\\"{x:1606,y:465,t:1527631762075};\\\", \\\"{x:1606,y:466,t:1527631762091};\\\", \\\"{x:1605,y:467,t:1527631762108};\\\", \\\"{x:1605,y:468,t:1527631762124};\\\", \\\"{x:1604,y:470,t:1527631762141};\\\", \\\"{x:1603,y:470,t:1527631762157};\\\", \\\"{x:1603,y:472,t:1527631762176};\\\", \\\"{x:1602,y:475,t:1527631762192};\\\", \\\"{x:1601,y:477,t:1527631762208};\\\", \\\"{x:1600,y:478,t:1527631762224};\\\", \\\"{x:1600,y:479,t:1527631762241};\\\", \\\"{x:1599,y:482,t:1527631762258};\\\", \\\"{x:1598,y:483,t:1527631762277};\\\", \\\"{x:1597,y:486,t:1527631762293};\\\", \\\"{x:1596,y:488,t:1527631762309};\\\", \\\"{x:1596,y:489,t:1527631762325};\\\", \\\"{x:1595,y:491,t:1527631762341};\\\", \\\"{x:1595,y:493,t:1527631762358};\\\", \\\"{x:1593,y:495,t:1527631762376};\\\", \\\"{x:1593,y:497,t:1527631762392};\\\", \\\"{x:1591,y:500,t:1527631762409};\\\", \\\"{x:1590,y:503,t:1527631762425};\\\", \\\"{x:1589,y:504,t:1527631762441};\\\", \\\"{x:1589,y:505,t:1527631762458};\\\", \\\"{x:1589,y:509,t:1527631762474};\\\", \\\"{x:1587,y:510,t:1527631762491};\\\", \\\"{x:1585,y:513,t:1527631762508};\\\", \\\"{x:1583,y:518,t:1527631762524};\\\", \\\"{x:1581,y:523,t:1527631762541};\\\", \\\"{x:1579,y:525,t:1527631762558};\\\", \\\"{x:1579,y:528,t:1527631762574};\\\", \\\"{x:1578,y:530,t:1527631762591};\\\", \\\"{x:1577,y:531,t:1527631762608};\\\", \\\"{x:1577,y:532,t:1527631762624};\\\", \\\"{x:1577,y:534,t:1527631762641};\\\", \\\"{x:1576,y:535,t:1527631762658};\\\", \\\"{x:1575,y:537,t:1527631762675};\\\", \\\"{x:1574,y:539,t:1527631762691};\\\", \\\"{x:1572,y:543,t:1527631762708};\\\", \\\"{x:1571,y:547,t:1527631762725};\\\", \\\"{x:1568,y:551,t:1527631762741};\\\", \\\"{x:1567,y:555,t:1527631762758};\\\", \\\"{x:1565,y:559,t:1527631762775};\\\", \\\"{x:1564,y:561,t:1527631762791};\\\", \\\"{x:1563,y:562,t:1527631762808};\\\", \\\"{x:1562,y:564,t:1527631762825};\\\", \\\"{x:1561,y:566,t:1527631762842};\\\", \\\"{x:1561,y:568,t:1527631762858};\\\", \\\"{x:1559,y:570,t:1527631762875};\\\", \\\"{x:1559,y:571,t:1527631762892};\\\", \\\"{x:1557,y:574,t:1527631762908};\\\", \\\"{x:1555,y:577,t:1527631762925};\\\", \\\"{x:1551,y:581,t:1527631762941};\\\", \\\"{x:1551,y:583,t:1527631762958};\\\", \\\"{x:1549,y:585,t:1527631762975};\\\", \\\"{x:1547,y:588,t:1527631762993};\\\", \\\"{x:1543,y:594,t:1527631763009};\\\", \\\"{x:1543,y:598,t:1527631763025};\\\", \\\"{x:1541,y:600,t:1527631763042};\\\", \\\"{x:1540,y:602,t:1527631763058};\\\", \\\"{x:1538,y:605,t:1527631763075};\\\", \\\"{x:1536,y:608,t:1527631763092};\\\", \\\"{x:1536,y:610,t:1527631763108};\\\", \\\"{x:1534,y:614,t:1527631763125};\\\", \\\"{x:1533,y:615,t:1527631763141};\\\", \\\"{x:1532,y:617,t:1527631763158};\\\", \\\"{x:1531,y:618,t:1527631763175};\\\", \\\"{x:1530,y:620,t:1527631763192};\\\", \\\"{x:1530,y:621,t:1527631763214};\\\", \\\"{x:1529,y:623,t:1527631763226};\\\", \\\"{x:1527,y:625,t:1527631763262};\\\", \\\"{x:1527,y:626,t:1527631763286};\\\", \\\"{x:1525,y:628,t:1527631763301};\\\", \\\"{x:1525,y:629,t:1527631763333};\\\", \\\"{x:1525,y:630,t:1527631763358};\\\", \\\"{x:1524,y:631,t:1527631763376};\\\", \\\"{x:1524,y:632,t:1527631763393};\\\", \\\"{x:1523,y:633,t:1527631763429};\\\", \\\"{x:1522,y:635,t:1527631763470};\\\", \\\"{x:1521,y:636,t:1527631763485};\\\", \\\"{x:1520,y:637,t:1527631763493};\\\", \\\"{x:1520,y:638,t:1527631763525};\\\", \\\"{x:1519,y:639,t:1527631763590};\\\", \\\"{x:1518,y:640,t:1527631763654};\\\", \\\"{x:1518,y:641,t:1527631763669};\\\", \\\"{x:1517,y:642,t:1527631763685};\\\", \\\"{x:1517,y:643,t:1527631763718};\\\", \\\"{x:1517,y:644,t:1527631763741};\\\", \\\"{x:1517,y:645,t:1527631763766};\\\", \\\"{x:1516,y:646,t:1527631763776};\\\", \\\"{x:1515,y:648,t:1527631763846};\\\", \\\"{x:1514,y:649,t:1527631767286};\\\", \\\"{x:1514,y:651,t:1527631767295};\\\", \\\"{x:1512,y:653,t:1527631767312};\\\", \\\"{x:1511,y:654,t:1527631767328};\\\", \\\"{x:1509,y:656,t:1527631767344};\\\", \\\"{x:1508,y:657,t:1527631767361};\\\", \\\"{x:1507,y:658,t:1527631767397};\\\", \\\"{x:1507,y:659,t:1527631767462};\\\", \\\"{x:1507,y:660,t:1527631767493};\\\", \\\"{x:1506,y:660,t:1527631767511};\\\", \\\"{x:1505,y:661,t:1527631767527};\\\", \\\"{x:1504,y:663,t:1527631767566};\\\", \\\"{x:1504,y:664,t:1527631767581};\\\", \\\"{x:1502,y:665,t:1527631767613};\\\", \\\"{x:1502,y:667,t:1527631767629};\\\", \\\"{x:1501,y:668,t:1527631767654};\\\", \\\"{x:1500,y:669,t:1527631767661};\\\", \\\"{x:1500,y:670,t:1527631767709};\\\", \\\"{x:1499,y:670,t:1527631767717};\\\", \\\"{x:1499,y:671,t:1527631767958};\\\", \\\"{x:1498,y:671,t:1527631768037};\\\", \\\"{x:1497,y:673,t:1527631768045};\\\", \\\"{x:1497,y:675,t:1527631768061};\\\", \\\"{x:1495,y:675,t:1527631768079};\\\", \\\"{x:1493,y:678,t:1527631768094};\\\", \\\"{x:1491,y:680,t:1527631768111};\\\", \\\"{x:1490,y:681,t:1527631768129};\\\", \\\"{x:1488,y:683,t:1527631768144};\\\", \\\"{x:1486,y:685,t:1527631768165};\\\", \\\"{x:1486,y:686,t:1527631768181};\\\", \\\"{x:1485,y:687,t:1527631768194};\\\", \\\"{x:1484,y:688,t:1527631768214};\\\", \\\"{x:1484,y:689,t:1527631768237};\\\", \\\"{x:1483,y:690,t:1527631768245};\\\", \\\"{x:1483,y:691,t:1527631768285};\\\", \\\"{x:1482,y:692,t:1527631768294};\\\", \\\"{x:1481,y:693,t:1527631768311};\\\", \\\"{x:1481,y:694,t:1527631768328};\\\", \\\"{x:1479,y:696,t:1527631768345};\\\", \\\"{x:1478,y:699,t:1527631768362};\\\", \\\"{x:1474,y:704,t:1527631768379};\\\", \\\"{x:1472,y:708,t:1527631768394};\\\", \\\"{x:1469,y:712,t:1527631768412};\\\", \\\"{x:1466,y:715,t:1527631768428};\\\", \\\"{x:1464,y:718,t:1527631768445};\\\", \\\"{x:1460,y:725,t:1527631768461};\\\", \\\"{x:1456,y:731,t:1527631768478};\\\", \\\"{x:1453,y:736,t:1527631768494};\\\", \\\"{x:1452,y:739,t:1527631768511};\\\", \\\"{x:1451,y:741,t:1527631768528};\\\", \\\"{x:1450,y:742,t:1527631768549};\\\", \\\"{x:1450,y:743,t:1527631768562};\\\", \\\"{x:1449,y:744,t:1527631768579};\\\", \\\"{x:1448,y:746,t:1527631768594};\\\", \\\"{x:1447,y:748,t:1527631768612};\\\", \\\"{x:1446,y:750,t:1527631768629};\\\", \\\"{x:1443,y:755,t:1527631768645};\\\", \\\"{x:1441,y:760,t:1527631768661};\\\", \\\"{x:1437,y:766,t:1527631768679};\\\", \\\"{x:1433,y:772,t:1527631768695};\\\", \\\"{x:1429,y:779,t:1527631768712};\\\", \\\"{x:1426,y:785,t:1527631768729};\\\", \\\"{x:1423,y:789,t:1527631768745};\\\", \\\"{x:1419,y:796,t:1527631768761};\\\", \\\"{x:1418,y:799,t:1527631768779};\\\", \\\"{x:1417,y:802,t:1527631768795};\\\", \\\"{x:1415,y:803,t:1527631768810};\\\", \\\"{x:1415,y:805,t:1527631768827};\\\", \\\"{x:1413,y:809,t:1527631768844};\\\", \\\"{x:1408,y:814,t:1527631768860};\\\", \\\"{x:1404,y:821,t:1527631768878};\\\", \\\"{x:1398,y:830,t:1527631768895};\\\", \\\"{x:1392,y:839,t:1527631768911};\\\", \\\"{x:1389,y:846,t:1527631768928};\\\", \\\"{x:1384,y:856,t:1527631768945};\\\", \\\"{x:1379,y:863,t:1527631768961};\\\", \\\"{x:1375,y:870,t:1527631768978};\\\", \\\"{x:1371,y:877,t:1527631768995};\\\", \\\"{x:1370,y:880,t:1527631769012};\\\", \\\"{x:1368,y:883,t:1527631769028};\\\", \\\"{x:1367,y:885,t:1527631769045};\\\", \\\"{x:1365,y:885,t:1527631769125};\\\", \\\"{x:1364,y:885,t:1527631769133};\\\", \\\"{x:1364,y:886,t:1527631769157};\\\", \\\"{x:1362,y:887,t:1527631769725};\\\", \\\"{x:1361,y:887,t:1527631769798};\\\", \\\"{x:1359,y:887,t:1527631769862};\\\", \\\"{x:1358,y:887,t:1527631769893};\\\", \\\"{x:1356,y:888,t:1527631769917};\\\", \\\"{x:1355,y:889,t:1527631769933};\\\", \\\"{x:1352,y:890,t:1527631769973};\\\", \\\"{x:1352,y:891,t:1527631769981};\\\", \\\"{x:1351,y:892,t:1527631770012};\\\", \\\"{x:1351,y:893,t:1527631771741};\\\", \\\"{x:1353,y:893,t:1527631771750};\\\", \\\"{x:1360,y:889,t:1527631771763};\\\", \\\"{x:1376,y:871,t:1527631771780};\\\", \\\"{x:1393,y:853,t:1527631771796};\\\", \\\"{x:1421,y:809,t:1527631771813};\\\", \\\"{x:1441,y:776,t:1527631771834};\\\", \\\"{x:1456,y:749,t:1527631771845};\\\", \\\"{x:1472,y:715,t:1527631771863};\\\", \\\"{x:1483,y:688,t:1527631771880};\\\", \\\"{x:1493,y:670,t:1527631771896};\\\", \\\"{x:1498,y:655,t:1527631771913};\\\", \\\"{x:1503,y:646,t:1527631771930};\\\", \\\"{x:1506,y:640,t:1527631771946};\\\", \\\"{x:1507,y:636,t:1527631771963};\\\", \\\"{x:1508,y:634,t:1527631771980};\\\", \\\"{x:1509,y:633,t:1527631772005};\\\", \\\"{x:1509,y:632,t:1527631772013};\\\", \\\"{x:1510,y:627,t:1527631772030};\\\", \\\"{x:1514,y:621,t:1527631772046};\\\", \\\"{x:1516,y:616,t:1527631772063};\\\", \\\"{x:1517,y:615,t:1527631772080};\\\", \\\"{x:1517,y:618,t:1527631772317};\\\", \\\"{x:1517,y:622,t:1527631772330};\\\", \\\"{x:1516,y:630,t:1527631772347};\\\", \\\"{x:1514,y:635,t:1527631772363};\\\", \\\"{x:1512,y:640,t:1527631772381};\\\", \\\"{x:1508,y:649,t:1527631772397};\\\", \\\"{x:1502,y:660,t:1527631772413};\\\", \\\"{x:1501,y:669,t:1527631772430};\\\", \\\"{x:1496,y:678,t:1527631772447};\\\", \\\"{x:1494,y:682,t:1527631772463};\\\", \\\"{x:1490,y:690,t:1527631772480};\\\", \\\"{x:1487,y:696,t:1527631772497};\\\", \\\"{x:1482,y:702,t:1527631772514};\\\", \\\"{x:1478,y:709,t:1527631772531};\\\", \\\"{x:1473,y:716,t:1527631772547};\\\", \\\"{x:1469,y:722,t:1527631772564};\\\", \\\"{x:1467,y:725,t:1527631772580};\\\", \\\"{x:1463,y:730,t:1527631772597};\\\", \\\"{x:1459,y:737,t:1527631772613};\\\", \\\"{x:1457,y:743,t:1527631772630};\\\", \\\"{x:1452,y:750,t:1527631772647};\\\", \\\"{x:1451,y:753,t:1527631772664};\\\", \\\"{x:1447,y:760,t:1527631772681};\\\", \\\"{x:1444,y:767,t:1527631772698};\\\", \\\"{x:1441,y:774,t:1527631772714};\\\", \\\"{x:1438,y:778,t:1527631772731};\\\", \\\"{x:1435,y:783,t:1527631772748};\\\", \\\"{x:1433,y:787,t:1527631772763};\\\", \\\"{x:1432,y:789,t:1527631772780};\\\", \\\"{x:1429,y:793,t:1527631772797};\\\", \\\"{x:1428,y:796,t:1527631772813};\\\", \\\"{x:1426,y:799,t:1527631772831};\\\", \\\"{x:1424,y:803,t:1527631772847};\\\", \\\"{x:1422,y:806,t:1527631772863};\\\", \\\"{x:1420,y:809,t:1527631772880};\\\", \\\"{x:1419,y:811,t:1527631772898};\\\", \\\"{x:1417,y:814,t:1527631772913};\\\", \\\"{x:1416,y:815,t:1527631772931};\\\", \\\"{x:1416,y:816,t:1527631772947};\\\", \\\"{x:1415,y:817,t:1527631772964};\\\", \\\"{x:1415,y:818,t:1527631772980};\\\", \\\"{x:1414,y:820,t:1527631772997};\\\", \\\"{x:1413,y:821,t:1527631773029};\\\", \\\"{x:1411,y:823,t:1527631773878};\\\", \\\"{x:1411,y:824,t:1527631774597};\\\", \\\"{x:1412,y:824,t:1527631774621};\\\", \\\"{x:1412,y:825,t:1527631774653};\\\", \\\"{x:1413,y:826,t:1527631774664};\\\", \\\"{x:1414,y:827,t:1527631775037};\\\", \\\"{x:1415,y:827,t:1527631775052};\\\", \\\"{x:1415,y:828,t:1527631775069};\\\", \\\"{x:1415,y:829,t:1527631775109};\\\", \\\"{x:1415,y:830,t:1527631775174};\\\", \\\"{x:1415,y:831,t:1527631775717};\\\", \\\"{x:1415,y:833,t:1527631775742};\\\", \\\"{x:1415,y:834,t:1527631775757};\\\", \\\"{x:1415,y:835,t:1527631775766};\\\", \\\"{x:1413,y:843,t:1527631775783};\\\", \\\"{x:1411,y:852,t:1527631775798};\\\", \\\"{x:1410,y:862,t:1527631775815};\\\", \\\"{x:1406,y:871,t:1527631775832};\\\", \\\"{x:1404,y:879,t:1527631775847};\\\", \\\"{x:1399,y:888,t:1527631775865};\\\", \\\"{x:1397,y:896,t:1527631775883};\\\", \\\"{x:1393,y:906,t:1527631775898};\\\", \\\"{x:1387,y:920,t:1527631775916};\\\", \\\"{x:1379,y:939,t:1527631775933};\\\", \\\"{x:1376,y:944,t:1527631775949};\\\", \\\"{x:1372,y:950,t:1527631775965};\\\", \\\"{x:1370,y:953,t:1527631775982};\\\", \\\"{x:1370,y:954,t:1527631775998};\\\", \\\"{x:1369,y:955,t:1527631776015};\\\", \\\"{x:1368,y:956,t:1527631776109};\\\", \\\"{x:1367,y:956,t:1527631776165};\\\", \\\"{x:1367,y:957,t:1527631776189};\\\", \\\"{x:1366,y:958,t:1527631776198};\\\", \\\"{x:1366,y:959,t:1527631776221};\\\", \\\"{x:1365,y:960,t:1527631776232};\\\", \\\"{x:1365,y:961,t:1527631776250};\\\", \\\"{x:1363,y:962,t:1527631776266};\\\", \\\"{x:1362,y:964,t:1527631776282};\\\", \\\"{x:1362,y:965,t:1527631776300};\\\", \\\"{x:1362,y:966,t:1527631776333};\\\", \\\"{x:1361,y:966,t:1527631776349};\\\", \\\"{x:1360,y:966,t:1527631785397};\\\", \\\"{x:1360,y:916,t:1527631785405};\\\", \\\"{x:1353,y:867,t:1527631785421};\\\", \\\"{x:1352,y:865,t:1527631786236};\\\", \\\"{x:1347,y:862,t:1527631786244};\\\", \\\"{x:1347,y:859,t:1527631786254};\\\", \\\"{x:1344,y:852,t:1527631786270};\\\", \\\"{x:1335,y:841,t:1527631786287};\\\", \\\"{x:1316,y:831,t:1527631786304};\\\", \\\"{x:1298,y:819,t:1527631786320};\\\", \\\"{x:1290,y:812,t:1527631786337};\\\", \\\"{x:1286,y:806,t:1527631786355};\\\", \\\"{x:1284,y:803,t:1527631786370};\\\", \\\"{x:1279,y:802,t:1527631786388};\\\", \\\"{x:1270,y:802,t:1527631786404};\\\", \\\"{x:1268,y:802,t:1527631786421};\\\", \\\"{x:1266,y:802,t:1527631786485};\\\", \\\"{x:1265,y:802,t:1527631786501};\\\", \\\"{x:1264,y:803,t:1527631786765};\\\", \\\"{x:1263,y:806,t:1527631786813};\\\", \\\"{x:1260,y:809,t:1527631786822};\\\", \\\"{x:1243,y:829,t:1527631786838};\\\", \\\"{x:1209,y:850,t:1527631786855};\\\", \\\"{x:1187,y:872,t:1527631786872};\\\", \\\"{x:1177,y:892,t:1527631786888};\\\", \\\"{x:1172,y:904,t:1527631786905};\\\", \\\"{x:1172,y:916,t:1527631786922};\\\", \\\"{x:1176,y:928,t:1527631786938};\\\", \\\"{x:1180,y:944,t:1527631786955};\\\", \\\"{x:1193,y:964,t:1527631786972};\\\", \\\"{x:1202,y:978,t:1527631786988};\\\", \\\"{x:1208,y:988,t:1527631787006};\\\", \\\"{x:1208,y:989,t:1527631787021};\\\", \\\"{x:1208,y:990,t:1527631787038};\\\", \\\"{x:1208,y:991,t:1527631787054};\\\", \\\"{x:1208,y:992,t:1527631787100};\\\", \\\"{x:1209,y:992,t:1527631787108};\\\", \\\"{x:1212,y:992,t:1527631787124};\\\", \\\"{x:1214,y:991,t:1527631787139};\\\", \\\"{x:1215,y:989,t:1527631787154};\\\", \\\"{x:1222,y:984,t:1527631787171};\\\", \\\"{x:1231,y:975,t:1527631787187};\\\", \\\"{x:1238,y:964,t:1527631787205};\\\", \\\"{x:1251,y:948,t:1527631787221};\\\", \\\"{x:1278,y:913,t:1527631787239};\\\", \\\"{x:1297,y:880,t:1527631787255};\\\", \\\"{x:1312,y:852,t:1527631787271};\\\", \\\"{x:1326,y:824,t:1527631787289};\\\", \\\"{x:1337,y:803,t:1527631787305};\\\", \\\"{x:1343,y:787,t:1527631787321};\\\", \\\"{x:1348,y:777,t:1527631787339};\\\", \\\"{x:1350,y:773,t:1527631787355};\\\", \\\"{x:1351,y:772,t:1527631787372};\\\", \\\"{x:1351,y:773,t:1527631787477};\\\", \\\"{x:1350,y:775,t:1527631787489};\\\", \\\"{x:1348,y:779,t:1527631787505};\\\", \\\"{x:1344,y:784,t:1527631787522};\\\", \\\"{x:1339,y:789,t:1527631787539};\\\", \\\"{x:1336,y:793,t:1527631787555};\\\", \\\"{x:1332,y:798,t:1527631787572};\\\", \\\"{x:1327,y:805,t:1527631787589};\\\", \\\"{x:1325,y:807,t:1527631787605};\\\", \\\"{x:1323,y:809,t:1527631787622};\\\", \\\"{x:1322,y:810,t:1527631787639};\\\", \\\"{x:1321,y:810,t:1527631787677};\\\", \\\"{x:1320,y:812,t:1527631787689};\\\", \\\"{x:1319,y:813,t:1527631787705};\\\", \\\"{x:1317,y:817,t:1527631787722};\\\", \\\"{x:1314,y:820,t:1527631787739};\\\", \\\"{x:1311,y:823,t:1527631787756};\\\", \\\"{x:1309,y:824,t:1527631787772};\\\", \\\"{x:1305,y:828,t:1527631787789};\\\", \\\"{x:1304,y:829,t:1527631787806};\\\", \\\"{x:1303,y:832,t:1527631787823};\\\", \\\"{x:1301,y:837,t:1527631787839};\\\", \\\"{x:1299,y:842,t:1527631787856};\\\", \\\"{x:1297,y:849,t:1527631787872};\\\", \\\"{x:1293,y:862,t:1527631787889};\\\", \\\"{x:1292,y:874,t:1527631787906};\\\", \\\"{x:1292,y:890,t:1527631787922};\\\", \\\"{x:1292,y:905,t:1527631787939};\\\", \\\"{x:1292,y:921,t:1527631787956};\\\", \\\"{x:1293,y:933,t:1527631787972};\\\", \\\"{x:1293,y:948,t:1527631787989};\\\", \\\"{x:1293,y:955,t:1527631788007};\\\", \\\"{x:1298,y:961,t:1527631788022};\\\", \\\"{x:1300,y:968,t:1527631788039};\\\", \\\"{x:1300,y:971,t:1527631788056};\\\", \\\"{x:1300,y:972,t:1527631788566};\\\", \\\"{x:1300,y:973,t:1527631788613};\\\", \\\"{x:1300,y:974,t:1527631788987};\\\", \\\"{x:1300,y:975,t:1527631788996};\\\", \\\"{x:1301,y:976,t:1527631789020};\\\", \\\"{x:1302,y:977,t:1527631789029};\\\", \\\"{x:1303,y:977,t:1527631789052};\\\", \\\"{x:1304,y:978,t:1527631789060};\\\", \\\"{x:1306,y:978,t:1527631789092};\\\", \\\"{x:1307,y:979,t:1527631789106};\\\", \\\"{x:1308,y:979,t:1527631789573};\\\", \\\"{x:1310,y:979,t:1527631789590};\\\", \\\"{x:1311,y:979,t:1527631789620};\\\", \\\"{x:1312,y:979,t:1527631789629};\\\", \\\"{x:1313,y:979,t:1527631789644};\\\", \\\"{x:1314,y:978,t:1527631789656};\\\", \\\"{x:1323,y:971,t:1527631789673};\\\", \\\"{x:1335,y:960,t:1527631789690};\\\", \\\"{x:1343,y:950,t:1527631789707};\\\", \\\"{x:1359,y:931,t:1527631789723};\\\", \\\"{x:1386,y:897,t:1527631789740};\\\", \\\"{x:1435,y:815,t:1527631789756};\\\", \\\"{x:1468,y:746,t:1527631789772};\\\", \\\"{x:1489,y:676,t:1527631789789};\\\", \\\"{x:1503,y:628,t:1527631789806};\\\", \\\"{x:1510,y:604,t:1527631789823};\\\", \\\"{x:1513,y:588,t:1527631789839};\\\", \\\"{x:1513,y:583,t:1527631789857};\\\", \\\"{x:1513,y:580,t:1527631789872};\\\", \\\"{x:1513,y:579,t:1527631789889};\\\", \\\"{x:1513,y:578,t:1527631789908};\\\", \\\"{x:1513,y:581,t:1527631789997};\\\", \\\"{x:1513,y:591,t:1527631790007};\\\", \\\"{x:1512,y:612,t:1527631790023};\\\", \\\"{x:1512,y:640,t:1527631790040};\\\", \\\"{x:1512,y:663,t:1527631790057};\\\", \\\"{x:1514,y:684,t:1527631790073};\\\", \\\"{x:1516,y:699,t:1527631790090};\\\", \\\"{x:1518,y:711,t:1527631790107};\\\", \\\"{x:1519,y:722,t:1527631790123};\\\", \\\"{x:1520,y:746,t:1527631790140};\\\", \\\"{x:1520,y:761,t:1527631790155};\\\", \\\"{x:1521,y:773,t:1527631790173};\\\", \\\"{x:1521,y:779,t:1527631790189};\\\", \\\"{x:1523,y:787,t:1527631790207};\\\", \\\"{x:1523,y:798,t:1527631790222};\\\", \\\"{x:1523,y:810,t:1527631790240};\\\", \\\"{x:1524,y:824,t:1527631790256};\\\", \\\"{x:1527,y:835,t:1527631790274};\\\", \\\"{x:1528,y:847,t:1527631790290};\\\", \\\"{x:1529,y:852,t:1527631790306};\\\", \\\"{x:1529,y:855,t:1527631790322};\\\", \\\"{x:1529,y:863,t:1527631790340};\\\", \\\"{x:1529,y:872,t:1527631790356};\\\", \\\"{x:1529,y:884,t:1527631790374};\\\", \\\"{x:1529,y:892,t:1527631790390};\\\", \\\"{x:1529,y:897,t:1527631790407};\\\", \\\"{x:1529,y:899,t:1527631790423};\\\", \\\"{x:1529,y:900,t:1527631790439};\\\", \\\"{x:1529,y:895,t:1527631790517};\\\", \\\"{x:1530,y:881,t:1527631790525};\\\", \\\"{x:1534,y:864,t:1527631790540};\\\", \\\"{x:1542,y:774,t:1527631790557};\\\", \\\"{x:1553,y:710,t:1527631790575};\\\", \\\"{x:1566,y:647,t:1527631790590};\\\", \\\"{x:1578,y:596,t:1527631790607};\\\", \\\"{x:1587,y:542,t:1527631790624};\\\", \\\"{x:1594,y:487,t:1527631790640};\\\", \\\"{x:1599,y:459,t:1527631790657};\\\", \\\"{x:1600,y:441,t:1527631790674};\\\", \\\"{x:1603,y:425,t:1527631790690};\\\", \\\"{x:1603,y:412,t:1527631790707};\\\", \\\"{x:1603,y:401,t:1527631790724};\\\", \\\"{x:1602,y:388,t:1527631790741};\\\", \\\"{x:1599,y:367,t:1527631790757};\\\", \\\"{x:1597,y:356,t:1527631790775};\\\", \\\"{x:1592,y:342,t:1527631790790};\\\", \\\"{x:1586,y:332,t:1527631790807};\\\", \\\"{x:1575,y:322,t:1527631790823};\\\", \\\"{x:1567,y:318,t:1527631790839};\\\", \\\"{x:1561,y:314,t:1527631790856};\\\", \\\"{x:1559,y:313,t:1527631790873};\\\", \\\"{x:1557,y:312,t:1527631790889};\\\", \\\"{x:1556,y:310,t:1527631790907};\\\", \\\"{x:1555,y:311,t:1527631790973};\\\", \\\"{x:1555,y:319,t:1527631790983};\\\", \\\"{x:1553,y:324,t:1527631790990};\\\", \\\"{x:1551,y:346,t:1527631791006};\\\", \\\"{x:1550,y:361,t:1527631791023};\\\", \\\"{x:1550,y:376,t:1527631791040};\\\", \\\"{x:1548,y:389,t:1527631791056};\\\", \\\"{x:1548,y:399,t:1527631791074};\\\", \\\"{x:1548,y:404,t:1527631791091};\\\", \\\"{x:1549,y:411,t:1527631791107};\\\", \\\"{x:1549,y:415,t:1527631791124};\\\", \\\"{x:1550,y:419,t:1527631791140};\\\", \\\"{x:1550,y:422,t:1527631791157};\\\", \\\"{x:1551,y:426,t:1527631791174};\\\", \\\"{x:1551,y:430,t:1527631791191};\\\", \\\"{x:1552,y:436,t:1527631791207};\\\", \\\"{x:1552,y:440,t:1527631791224};\\\", \\\"{x:1553,y:444,t:1527631791240};\\\", \\\"{x:1553,y:448,t:1527631791257};\\\", \\\"{x:1555,y:451,t:1527631791274};\\\", \\\"{x:1555,y:452,t:1527631791291};\\\", \\\"{x:1555,y:453,t:1527631791307};\\\", \\\"{x:1555,y:454,t:1527631791324};\\\", \\\"{x:1555,y:455,t:1527631791341};\\\", \\\"{x:1555,y:456,t:1527631791357};\\\", \\\"{x:1555,y:458,t:1527631791373};\\\", \\\"{x:1555,y:464,t:1527631791391};\\\", \\\"{x:1555,y:466,t:1527631791407};\\\", \\\"{x:1555,y:468,t:1527631791424};\\\", \\\"{x:1555,y:472,t:1527631791441};\\\", \\\"{x:1555,y:474,t:1527631791456};\\\", \\\"{x:1555,y:476,t:1527631791474};\\\", \\\"{x:1555,y:477,t:1527631791490};\\\", \\\"{x:1555,y:481,t:1527631791506};\\\", \\\"{x:1556,y:483,t:1527631791524};\\\", \\\"{x:1556,y:484,t:1527631791541};\\\", \\\"{x:1556,y:485,t:1527631791557};\\\", \\\"{x:1556,y:486,t:1527631791575};\\\", \\\"{x:1556,y:487,t:1527631791591};\\\", \\\"{x:1556,y:488,t:1527631791608};\\\", \\\"{x:1557,y:490,t:1527631791624};\\\", \\\"{x:1557,y:493,t:1527631791641};\\\", \\\"{x:1557,y:496,t:1527631791659};\\\", \\\"{x:1557,y:498,t:1527631791674};\\\", \\\"{x:1558,y:500,t:1527631791691};\\\", \\\"{x:1559,y:503,t:1527631791709};\\\", \\\"{x:1559,y:505,t:1527631791724};\\\", \\\"{x:1559,y:510,t:1527631791741};\\\", \\\"{x:1560,y:514,t:1527631791758};\\\", \\\"{x:1560,y:518,t:1527631791776};\\\", \\\"{x:1560,y:520,t:1527631791791};\\\", \\\"{x:1561,y:522,t:1527631791808};\\\", \\\"{x:1561,y:523,t:1527631791824};\\\", \\\"{x:1561,y:524,t:1527631791844};\\\", \\\"{x:1561,y:525,t:1527631791868};\\\", \\\"{x:1561,y:526,t:1527631791877};\\\", \\\"{x:1562,y:527,t:1527631791893};\\\", \\\"{x:1562,y:528,t:1527631791973};\\\", \\\"{x:1562,y:529,t:1527631791991};\\\", \\\"{x:1562,y:532,t:1527631792008};\\\", \\\"{x:1562,y:533,t:1527631792025};\\\", \\\"{x:1562,y:535,t:1527631792041};\\\", \\\"{x:1562,y:537,t:1527631792058};\\\", \\\"{x:1564,y:543,t:1527631792074};\\\", \\\"{x:1566,y:551,t:1527631792091};\\\", \\\"{x:1569,y:561,t:1527631792109};\\\", \\\"{x:1569,y:563,t:1527631792125};\\\", \\\"{x:1571,y:568,t:1527631792141};\\\", \\\"{x:1572,y:571,t:1527631792158};\\\", \\\"{x:1572,y:573,t:1527631792175};\\\", \\\"{x:1573,y:575,t:1527631792191};\\\", \\\"{x:1573,y:576,t:1527631792212};\\\", \\\"{x:1573,y:577,t:1527631792224};\\\", \\\"{x:1573,y:578,t:1527631792253};\\\", \\\"{x:1573,y:579,t:1527631792261};\\\", \\\"{x:1573,y:580,t:1527631792275};\\\", \\\"{x:1573,y:581,t:1527631792291};\\\", \\\"{x:1574,y:583,t:1527631792308};\\\", \\\"{x:1574,y:585,t:1527631792325};\\\", \\\"{x:1574,y:588,t:1527631792341};\\\", \\\"{x:1575,y:590,t:1527631792358};\\\", \\\"{x:1576,y:594,t:1527631792375};\\\", \\\"{x:1577,y:596,t:1527631792391};\\\", \\\"{x:1578,y:599,t:1527631792409};\\\", \\\"{x:1578,y:601,t:1527631792429};\\\", \\\"{x:1579,y:601,t:1527631792493};\\\", \\\"{x:1580,y:602,t:1527631792517};\\\", \\\"{x:1581,y:593,t:1527631792862};\\\", \\\"{x:1582,y:581,t:1527631792875};\\\", \\\"{x:1587,y:560,t:1527631792892};\\\", \\\"{x:1590,y:534,t:1527631792909};\\\", \\\"{x:1592,y:518,t:1527631792925};\\\", \\\"{x:1595,y:504,t:1527631792943};\\\", \\\"{x:1596,y:494,t:1527631792958};\\\", \\\"{x:1598,y:487,t:1527631792975};\\\", \\\"{x:1599,y:480,t:1527631792992};\\\", \\\"{x:1599,y:478,t:1527631793008};\\\", \\\"{x:1600,y:476,t:1527631793025};\\\", \\\"{x:1600,y:475,t:1527631793043};\\\", \\\"{x:1601,y:473,t:1527631793058};\\\", \\\"{x:1601,y:470,t:1527631793076};\\\", \\\"{x:1603,y:463,t:1527631793092};\\\", \\\"{x:1604,y:460,t:1527631793109};\\\", \\\"{x:1604,y:455,t:1527631793125};\\\", \\\"{x:1604,y:453,t:1527631793142};\\\", \\\"{x:1605,y:452,t:1527631793158};\\\", \\\"{x:1605,y:451,t:1527631793176};\\\", \\\"{x:1607,y:452,t:1527631793429};\\\", \\\"{x:1607,y:455,t:1527631793442};\\\", \\\"{x:1607,y:460,t:1527631793458};\\\", \\\"{x:1608,y:466,t:1527631793475};\\\", \\\"{x:1609,y:471,t:1527631793492};\\\", \\\"{x:1609,y:472,t:1527631793508};\\\", \\\"{x:1610,y:474,t:1527631793525};\\\", \\\"{x:1610,y:476,t:1527631793543};\\\", \\\"{x:1610,y:478,t:1527631793560};\\\", \\\"{x:1610,y:479,t:1527631793576};\\\", \\\"{x:1610,y:480,t:1527631793592};\\\", \\\"{x:1610,y:481,t:1527631793612};\\\", \\\"{x:1610,y:483,t:1527631793625};\\\", \\\"{x:1610,y:484,t:1527631793685};\\\", \\\"{x:1610,y:485,t:1527631793693};\\\", \\\"{x:1610,y:487,t:1527631793708};\\\", \\\"{x:1610,y:490,t:1527631793725};\\\", \\\"{x:1610,y:492,t:1527631793742};\\\", \\\"{x:1610,y:495,t:1527631793760};\\\", \\\"{x:1610,y:496,t:1527631793776};\\\", \\\"{x:1610,y:497,t:1527631793792};\\\", \\\"{x:1610,y:498,t:1527631793809};\\\", \\\"{x:1610,y:499,t:1527631793825};\\\", \\\"{x:1610,y:500,t:1527631793842};\\\", \\\"{x:1610,y:501,t:1527631793859};\\\", \\\"{x:1609,y:501,t:1527631793916};\\\", \\\"{x:1609,y:493,t:1527631794093};\\\", \\\"{x:1609,y:471,t:1527631794109};\\\", \\\"{x:1609,y:450,t:1527631794126};\\\", \\\"{x:1609,y:435,t:1527631794142};\\\", \\\"{x:1609,y:427,t:1527631794160};\\\", \\\"{x:1609,y:424,t:1527631794177};\\\", \\\"{x:1609,y:423,t:1527631794192};\\\", \\\"{x:1609,y:422,t:1527631794209};\\\", \\\"{x:1609,y:426,t:1527631794365};\\\", \\\"{x:1606,y:432,t:1527631794377};\\\", \\\"{x:1600,y:447,t:1527631794392};\\\", \\\"{x:1596,y:456,t:1527631794409};\\\", \\\"{x:1592,y:462,t:1527631794426};\\\", \\\"{x:1591,y:467,t:1527631794442};\\\", \\\"{x:1589,y:470,t:1527631794459};\\\", \\\"{x:1587,y:476,t:1527631794475};\\\", \\\"{x:1587,y:477,t:1527631794491};\\\", \\\"{x:1587,y:480,t:1527631794508};\\\", \\\"{x:1585,y:483,t:1527631794525};\\\", \\\"{x:1584,y:486,t:1527631794541};\\\", \\\"{x:1582,y:490,t:1527631794559};\\\", \\\"{x:1581,y:494,t:1527631794576};\\\", \\\"{x:1580,y:498,t:1527631794592};\\\", \\\"{x:1579,y:502,t:1527631794609};\\\", \\\"{x:1578,y:505,t:1527631794625};\\\", \\\"{x:1576,y:510,t:1527631794642};\\\", \\\"{x:1576,y:514,t:1527631794659};\\\", \\\"{x:1574,y:518,t:1527631794676};\\\", \\\"{x:1573,y:521,t:1527631794692};\\\", \\\"{x:1571,y:525,t:1527631794709};\\\", \\\"{x:1570,y:528,t:1527631794726};\\\", \\\"{x:1569,y:531,t:1527631794742};\\\", \\\"{x:1567,y:533,t:1527631794759};\\\", \\\"{x:1566,y:534,t:1527631794776};\\\", \\\"{x:1566,y:535,t:1527631794792};\\\", \\\"{x:1566,y:537,t:1527631794813};\\\", \\\"{x:1566,y:538,t:1527631794829};\\\", \\\"{x:1565,y:540,t:1527631794843};\\\", \\\"{x:1564,y:542,t:1527631794860};\\\", \\\"{x:1561,y:549,t:1527631794877};\\\", \\\"{x:1559,y:555,t:1527631794893};\\\", \\\"{x:1557,y:558,t:1527631794910};\\\", \\\"{x:1556,y:561,t:1527631794926};\\\", \\\"{x:1555,y:563,t:1527631794943};\\\", \\\"{x:1554,y:566,t:1527631794960};\\\", \\\"{x:1552,y:570,t:1527631794976};\\\", \\\"{x:1551,y:573,t:1527631794994};\\\", \\\"{x:1548,y:579,t:1527631795009};\\\", \\\"{x:1547,y:584,t:1527631795026};\\\", \\\"{x:1545,y:587,t:1527631795043};\\\", \\\"{x:1543,y:591,t:1527631795059};\\\", \\\"{x:1541,y:595,t:1527631795076};\\\", \\\"{x:1540,y:597,t:1527631795093};\\\", \\\"{x:1540,y:601,t:1527631795109};\\\", \\\"{x:1537,y:605,t:1527631795126};\\\", \\\"{x:1534,y:611,t:1527631795144};\\\", \\\"{x:1533,y:615,t:1527631795160};\\\", \\\"{x:1530,y:618,t:1527631795177};\\\", \\\"{x:1529,y:622,t:1527631795193};\\\", \\\"{x:1527,y:626,t:1527631795208};\\\", \\\"{x:1525,y:629,t:1527631795226};\\\", \\\"{x:1523,y:635,t:1527631795243};\\\", \\\"{x:1521,y:639,t:1527631795259};\\\", \\\"{x:1517,y:646,t:1527631795275};\\\", \\\"{x:1514,y:651,t:1527631795293};\\\", \\\"{x:1511,y:655,t:1527631795309};\\\", \\\"{x:1508,y:660,t:1527631795326};\\\", \\\"{x:1504,y:665,t:1527631795343};\\\", \\\"{x:1499,y:669,t:1527631795359};\\\", \\\"{x:1494,y:674,t:1527631795376};\\\", \\\"{x:1490,y:679,t:1527631795393};\\\", \\\"{x:1482,y:686,t:1527631795409};\\\", \\\"{x:1478,y:691,t:1527631795426};\\\", \\\"{x:1473,y:695,t:1527631795443};\\\", \\\"{x:1469,y:699,t:1527631795459};\\\", \\\"{x:1462,y:707,t:1527631795476};\\\", \\\"{x:1459,y:711,t:1527631795493};\\\", \\\"{x:1458,y:712,t:1527631795510};\\\", \\\"{x:1457,y:713,t:1527631795526};\\\", \\\"{x:1456,y:715,t:1527631795544};\\\", \\\"{x:1454,y:716,t:1527631795561};\\\", \\\"{x:1452,y:718,t:1527631795576};\\\", \\\"{x:1449,y:722,t:1527631795594};\\\", \\\"{x:1446,y:727,t:1527631795610};\\\", \\\"{x:1442,y:734,t:1527631795626};\\\", \\\"{x:1435,y:742,t:1527631795643};\\\", \\\"{x:1428,y:755,t:1527631795660};\\\", \\\"{x:1421,y:765,t:1527631795677};\\\", \\\"{x:1415,y:778,t:1527631795694};\\\", \\\"{x:1405,y:796,t:1527631795710};\\\", \\\"{x:1398,y:807,t:1527631795726};\\\", \\\"{x:1389,y:824,t:1527631795743};\\\", \\\"{x:1382,y:840,t:1527631795761};\\\", \\\"{x:1377,y:850,t:1527631795776};\\\", \\\"{x:1373,y:857,t:1527631795793};\\\", \\\"{x:1368,y:862,t:1527631795810};\\\", \\\"{x:1367,y:866,t:1527631795826};\\\", \\\"{x:1365,y:869,t:1527631795843};\\\", \\\"{x:1362,y:876,t:1527631795861};\\\", \\\"{x:1358,y:884,t:1527631795876};\\\", \\\"{x:1355,y:893,t:1527631795893};\\\", \\\"{x:1352,y:904,t:1527631795910};\\\", \\\"{x:1348,y:914,t:1527631795926};\\\", \\\"{x:1343,y:925,t:1527631795943};\\\", \\\"{x:1338,y:933,t:1527631795960};\\\", \\\"{x:1338,y:937,t:1527631795976};\\\", \\\"{x:1335,y:941,t:1527631795994};\\\", \\\"{x:1334,y:944,t:1527631796010};\\\", \\\"{x:1333,y:949,t:1527631796026};\\\", \\\"{x:1331,y:953,t:1527631796043};\\\", \\\"{x:1330,y:962,t:1527631796061};\\\", \\\"{x:1327,y:967,t:1527631796077};\\\", \\\"{x:1326,y:971,t:1527631796094};\\\", \\\"{x:1325,y:972,t:1527631796110};\\\", \\\"{x:1324,y:972,t:1527631796308};\\\", \\\"{x:1324,y:966,t:1527631796315};\\\", \\\"{x:1322,y:959,t:1527631796327};\\\", \\\"{x:1318,y:945,t:1527631796343};\\\", \\\"{x:1316,y:930,t:1527631796360};\\\", \\\"{x:1313,y:917,t:1527631796377};\\\", \\\"{x:1312,y:910,t:1527631796392};\\\", \\\"{x:1311,y:898,t:1527631796410};\\\", \\\"{x:1311,y:891,t:1527631796427};\\\", \\\"{x:1306,y:879,t:1527631796443};\\\", \\\"{x:1301,y:854,t:1527631796460};\\\", \\\"{x:1298,y:844,t:1527631796476};\\\", \\\"{x:1297,y:837,t:1527631796492};\\\", \\\"{x:1294,y:829,t:1527631796510};\\\", \\\"{x:1289,y:818,t:1527631796527};\\\", \\\"{x:1285,y:808,t:1527631796543};\\\", \\\"{x:1283,y:801,t:1527631796560};\\\", \\\"{x:1278,y:788,t:1527631796577};\\\", \\\"{x:1271,y:768,t:1527631796593};\\\", \\\"{x:1265,y:752,t:1527631796610};\\\", \\\"{x:1262,y:739,t:1527631796627};\\\", \\\"{x:1258,y:727,t:1527631796643};\\\", \\\"{x:1253,y:706,t:1527631796660};\\\", \\\"{x:1249,y:691,t:1527631796677};\\\", \\\"{x:1247,y:680,t:1527631796693};\\\", \\\"{x:1245,y:667,t:1527631796711};\\\", \\\"{x:1243,y:657,t:1527631796727};\\\", \\\"{x:1243,y:648,t:1527631796744};\\\", \\\"{x:1242,y:639,t:1527631796760};\\\", \\\"{x:1240,y:635,t:1527631796777};\\\", \\\"{x:1239,y:632,t:1527631796795};\\\", \\\"{x:1239,y:630,t:1527631796810};\\\", \\\"{x:1239,y:629,t:1527631796829};\\\", \\\"{x:1239,y:628,t:1527631797237};\\\", \\\"{x:1239,y:634,t:1527631797453};\\\", \\\"{x:1239,y:639,t:1527631797460};\\\", \\\"{x:1239,y:648,t:1527631797478};\\\", \\\"{x:1239,y:656,t:1527631797494};\\\", \\\"{x:1239,y:663,t:1527631797511};\\\", \\\"{x:1239,y:667,t:1527631797527};\\\", \\\"{x:1239,y:670,t:1527631797544};\\\", \\\"{x:1239,y:673,t:1527631797562};\\\", \\\"{x:1239,y:674,t:1527631797578};\\\", \\\"{x:1239,y:678,t:1527631797595};\\\", \\\"{x:1240,y:684,t:1527631797611};\\\", \\\"{x:1241,y:689,t:1527631797628};\\\", \\\"{x:1243,y:694,t:1527631797644};\\\", \\\"{x:1243,y:695,t:1527631797662};\\\", \\\"{x:1243,y:696,t:1527631797678};\\\", \\\"{x:1244,y:698,t:1527631797695};\\\", \\\"{x:1245,y:701,t:1527631797711};\\\", \\\"{x:1246,y:703,t:1527631797727};\\\", \\\"{x:1248,y:707,t:1527631797744};\\\", \\\"{x:1251,y:712,t:1527631797761};\\\", \\\"{x:1255,y:718,t:1527631797778};\\\", \\\"{x:1259,y:726,t:1527631797795};\\\", \\\"{x:1264,y:736,t:1527631797812};\\\", \\\"{x:1272,y:748,t:1527631797827};\\\", \\\"{x:1306,y:795,t:1527631797845};\\\", \\\"{x:1333,y:839,t:1527631797861};\\\", \\\"{x:1353,y:864,t:1527631797876};\\\", \\\"{x:1362,y:879,t:1527631797893};\\\", \\\"{x:1368,y:891,t:1527631797910};\\\", \\\"{x:1375,y:906,t:1527631797927};\\\", \\\"{x:1381,y:923,t:1527631797944};\\\", \\\"{x:1395,y:948,t:1527631797961};\\\", \\\"{x:1401,y:960,t:1527631797978};\\\", \\\"{x:1407,y:968,t:1527631797994};\\\", \\\"{x:1407,y:970,t:1527631798011};\\\", \\\"{x:1408,y:970,t:1527631798028};\\\", \\\"{x:1409,y:970,t:1527631798188};\\\", \\\"{x:1412,y:970,t:1527631798196};\\\", \\\"{x:1417,y:969,t:1527631798211};\\\", \\\"{x:1438,y:963,t:1527631798229};\\\", \\\"{x:1447,y:960,t:1527631798244};\\\", \\\"{x:1452,y:958,t:1527631798261};\\\", \\\"{x:1454,y:958,t:1527631798279};\\\", \\\"{x:1455,y:957,t:1527631798429};\\\", \\\"{x:1457,y:953,t:1527631798444};\\\", \\\"{x:1460,y:949,t:1527631798461};\\\", \\\"{x:1463,y:944,t:1527631798478};\\\", \\\"{x:1464,y:941,t:1527631798494};\\\", \\\"{x:1465,y:940,t:1527631798510};\\\", \\\"{x:1467,y:940,t:1527631798612};\\\", \\\"{x:1468,y:940,t:1527631798628};\\\", \\\"{x:1469,y:940,t:1527631798669};\\\", \\\"{x:1471,y:939,t:1527631798678};\\\", \\\"{x:1473,y:937,t:1527631798695};\\\", \\\"{x:1476,y:934,t:1527631798711};\\\", \\\"{x:1479,y:931,t:1527631798728};\\\", \\\"{x:1483,y:928,t:1527631798745};\\\", \\\"{x:1487,y:922,t:1527631798761};\\\", \\\"{x:1491,y:914,t:1527631798778};\\\", \\\"{x:1496,y:902,t:1527631798795};\\\", \\\"{x:1501,y:888,t:1527631798811};\\\", \\\"{x:1512,y:864,t:1527631798829};\\\", \\\"{x:1522,y:850,t:1527631798844};\\\", \\\"{x:1529,y:837,t:1527631798862};\\\", \\\"{x:1537,y:832,t:1527631798878};\\\", \\\"{x:1543,y:821,t:1527631798895};\\\", \\\"{x:1555,y:806,t:1527631798912};\\\", \\\"{x:1567,y:792,t:1527631798929};\\\", \\\"{x:1578,y:772,t:1527631798946};\\\", \\\"{x:1589,y:753,t:1527631798961};\\\", \\\"{x:1605,y:734,t:1527631798979};\\\", \\\"{x:1619,y:718,t:1527631798996};\\\", \\\"{x:1627,y:701,t:1527631799012};\\\", \\\"{x:1642,y:673,t:1527631799029};\\\", \\\"{x:1652,y:650,t:1527631799045};\\\", \\\"{x:1661,y:627,t:1527631799062};\\\", \\\"{x:1666,y:613,t:1527631799078};\\\", \\\"{x:1674,y:603,t:1527631799095};\\\", \\\"{x:1679,y:591,t:1527631799111};\\\", \\\"{x:1680,y:577,t:1527631799128};\\\", \\\"{x:1680,y:558,t:1527631799146};\\\", \\\"{x:1680,y:546,t:1527631799161};\\\", \\\"{x:1680,y:535,t:1527631799179};\\\", \\\"{x:1680,y:528,t:1527631799195};\\\", \\\"{x:1680,y:516,t:1527631799211};\\\", \\\"{x:1671,y:501,t:1527631799227};\\\", \\\"{x:1666,y:495,t:1527631799245};\\\", \\\"{x:1663,y:489,t:1527631799261};\\\", \\\"{x:1662,y:487,t:1527631799278};\\\", \\\"{x:1659,y:481,t:1527631799295};\\\", \\\"{x:1652,y:474,t:1527631799312};\\\", \\\"{x:1648,y:473,t:1527631799328};\\\", \\\"{x:1642,y:467,t:1527631799345};\\\", \\\"{x:1639,y:463,t:1527631799362};\\\", \\\"{x:1636,y:461,t:1527631799378};\\\", \\\"{x:1633,y:457,t:1527631799395};\\\", \\\"{x:1631,y:455,t:1527631799412};\\\", \\\"{x:1631,y:454,t:1527631799428};\\\", \\\"{x:1631,y:452,t:1527631799446};\\\", \\\"{x:1629,y:449,t:1527631799462};\\\", \\\"{x:1629,y:447,t:1527631799478};\\\", \\\"{x:1627,y:445,t:1527631799496};\\\", \\\"{x:1626,y:444,t:1527631799512};\\\", \\\"{x:1626,y:443,t:1527631799528};\\\", \\\"{x:1625,y:442,t:1527631799545};\\\", \\\"{x:1625,y:441,t:1527631799563};\\\", \\\"{x:1624,y:440,t:1527631799578};\\\", \\\"{x:1624,y:439,t:1527631799613};\\\", \\\"{x:1623,y:439,t:1527631799629};\\\", \\\"{x:1622,y:436,t:1527631799645};\\\", \\\"{x:1619,y:434,t:1527631799662};\\\", \\\"{x:1619,y:433,t:1527631799679};\\\", \\\"{x:1618,y:433,t:1527631799765};\\\", \\\"{x:1617,y:435,t:1527631799780};\\\", \\\"{x:1616,y:436,t:1527631799797};\\\", \\\"{x:1612,y:442,t:1527631799813};\\\", \\\"{x:1608,y:452,t:1527631799829};\\\", \\\"{x:1602,y:465,t:1527631799846};\\\", \\\"{x:1592,y:485,t:1527631799862};\\\", \\\"{x:1582,y:506,t:1527631799879};\\\", \\\"{x:1573,y:521,t:1527631799895};\\\", \\\"{x:1566,y:534,t:1527631799912};\\\", \\\"{x:1562,y:541,t:1527631799929};\\\", \\\"{x:1559,y:548,t:1527631799946};\\\", \\\"{x:1556,y:556,t:1527631799962};\\\", \\\"{x:1552,y:564,t:1527631799980};\\\", \\\"{x:1549,y:570,t:1527631799995};\\\", \\\"{x:1544,y:584,t:1527631800011};\\\", \\\"{x:1543,y:590,t:1527631800029};\\\", \\\"{x:1539,y:596,t:1527631800045};\\\", \\\"{x:1538,y:599,t:1527631800062};\\\", \\\"{x:1536,y:601,t:1527631800079};\\\", \\\"{x:1536,y:602,t:1527631800094};\\\", \\\"{x:1535,y:605,t:1527631800112};\\\", \\\"{x:1532,y:610,t:1527631800129};\\\", \\\"{x:1530,y:615,t:1527631800145};\\\", \\\"{x:1527,y:620,t:1527631800163};\\\", \\\"{x:1524,y:625,t:1527631800179};\\\", \\\"{x:1520,y:632,t:1527631800195};\\\", \\\"{x:1514,y:642,t:1527631800213};\\\", \\\"{x:1511,y:648,t:1527631800229};\\\", \\\"{x:1510,y:650,t:1527631800245};\\\", \\\"{x:1508,y:654,t:1527631800262};\\\", \\\"{x:1506,y:656,t:1527631800279};\\\", \\\"{x:1505,y:659,t:1527631800295};\\\", \\\"{x:1504,y:661,t:1527631800312};\\\", \\\"{x:1501,y:664,t:1527631800330};\\\", \\\"{x:1500,y:667,t:1527631800346};\\\", \\\"{x:1499,y:670,t:1527631800363};\\\", \\\"{x:1496,y:675,t:1527631800379};\\\", \\\"{x:1496,y:678,t:1527631800396};\\\", \\\"{x:1492,y:684,t:1527631800412};\\\", \\\"{x:1490,y:687,t:1527631800429};\\\", \\\"{x:1489,y:690,t:1527631800445};\\\", \\\"{x:1487,y:694,t:1527631800462};\\\", \\\"{x:1485,y:698,t:1527631800478};\\\", \\\"{x:1483,y:703,t:1527631800495};\\\", \\\"{x:1482,y:706,t:1527631800512};\\\", \\\"{x:1478,y:711,t:1527631800529};\\\", \\\"{x:1475,y:716,t:1527631800546};\\\", \\\"{x:1473,y:722,t:1527631800561};\\\", \\\"{x:1470,y:726,t:1527631800579};\\\", \\\"{x:1466,y:734,t:1527631800595};\\\", \\\"{x:1461,y:740,t:1527631800611};\\\", \\\"{x:1458,y:746,t:1527631800629};\\\", \\\"{x:1455,y:753,t:1527631800646};\\\", \\\"{x:1450,y:761,t:1527631800662};\\\", \\\"{x:1446,y:766,t:1527631800679};\\\", \\\"{x:1445,y:768,t:1527631800696};\\\", \\\"{x:1443,y:773,t:1527631800712};\\\", \\\"{x:1441,y:776,t:1527631800729};\\\", \\\"{x:1438,y:779,t:1527631800746};\\\", \\\"{x:1435,y:783,t:1527631800762};\\\", \\\"{x:1433,y:787,t:1527631800779};\\\", \\\"{x:1428,y:796,t:1527631800796};\\\", \\\"{x:1425,y:800,t:1527631800812};\\\", \\\"{x:1423,y:805,t:1527631800830};\\\", \\\"{x:1422,y:808,t:1527631800847};\\\", \\\"{x:1419,y:812,t:1527631800862};\\\", \\\"{x:1415,y:817,t:1527631800880};\\\", \\\"{x:1410,y:822,t:1527631800897};\\\", \\\"{x:1407,y:827,t:1527631800913};\\\", \\\"{x:1406,y:830,t:1527631800929};\\\", \\\"{x:1403,y:833,t:1527631800947};\\\", \\\"{x:1400,y:838,t:1527631800962};\\\", \\\"{x:1399,y:840,t:1527631800980};\\\", \\\"{x:1396,y:845,t:1527631800997};\\\", \\\"{x:1395,y:848,t:1527631801012};\\\", \\\"{x:1393,y:851,t:1527631801030};\\\", \\\"{x:1392,y:854,t:1527631801046};\\\", \\\"{x:1390,y:857,t:1527631801062};\\\", \\\"{x:1389,y:860,t:1527631801079};\\\", \\\"{x:1387,y:862,t:1527631801095};\\\", \\\"{x:1386,y:864,t:1527631801112};\\\", \\\"{x:1385,y:865,t:1527631801129};\\\", \\\"{x:1383,y:867,t:1527631801146};\\\", \\\"{x:1383,y:868,t:1527631801162};\\\", \\\"{x:1383,y:871,t:1527631801179};\\\", \\\"{x:1381,y:874,t:1527631801196};\\\", \\\"{x:1380,y:876,t:1527631801213};\\\", \\\"{x:1379,y:879,t:1527631801229};\\\", \\\"{x:1376,y:884,t:1527631801246};\\\", \\\"{x:1375,y:887,t:1527631801263};\\\", \\\"{x:1373,y:890,t:1527631801279};\\\", \\\"{x:1372,y:893,t:1527631801296};\\\", \\\"{x:1370,y:896,t:1527631801313};\\\", \\\"{x:1369,y:899,t:1527631801330};\\\", \\\"{x:1368,y:900,t:1527631801346};\\\", \\\"{x:1368,y:901,t:1527631801363};\\\", \\\"{x:1366,y:903,t:1527631801379};\\\", \\\"{x:1366,y:904,t:1527631801396};\\\", \\\"{x:1365,y:905,t:1527631801413};\\\", \\\"{x:1363,y:907,t:1527631801435};\\\", \\\"{x:1362,y:910,t:1527631801460};\\\", \\\"{x:1362,y:911,t:1527631801476};\\\", \\\"{x:1362,y:912,t:1527631801492};\\\", \\\"{x:1361,y:914,t:1527631801508};\\\", \\\"{x:1360,y:916,t:1527631801533};\\\", \\\"{x:1359,y:918,t:1527631801549};\\\", \\\"{x:1358,y:919,t:1527631801565};\\\", \\\"{x:1358,y:920,t:1527631801581};\\\", \\\"{x:1358,y:922,t:1527631801597};\\\", \\\"{x:1356,y:924,t:1527631801614};\\\", \\\"{x:1356,y:925,t:1527631801630};\\\", \\\"{x:1355,y:927,t:1527631801653};\\\", \\\"{x:1355,y:928,t:1527631801677};\\\", \\\"{x:1354,y:928,t:1527631801685};\\\", \\\"{x:1354,y:930,t:1527631801696};\\\", \\\"{x:1353,y:931,t:1527631801717};\\\", \\\"{x:1353,y:933,t:1527631801733};\\\", \\\"{x:1352,y:935,t:1527631801757};\\\", \\\"{x:1352,y:936,t:1527631801764};\\\", \\\"{x:1352,y:937,t:1527631801780};\\\", \\\"{x:1351,y:941,t:1527631801797};\\\", \\\"{x:1350,y:943,t:1527631801814};\\\", \\\"{x:1349,y:944,t:1527631801830};\\\", \\\"{x:1349,y:946,t:1527631801846};\\\", \\\"{x:1348,y:948,t:1527631801863};\\\", \\\"{x:1348,y:949,t:1527631801893};\\\", \\\"{x:1347,y:951,t:1527631801901};\\\", \\\"{x:1347,y:952,t:1527631802125};\\\", \\\"{x:1346,y:953,t:1527631802133};\\\", \\\"{x:1346,y:954,t:1527631802157};\\\", \\\"{x:1346,y:955,t:1527631802173};\\\", \\\"{x:1346,y:956,t:1527631802188};\\\", \\\"{x:1346,y:957,t:1527631802197};\\\", \\\"{x:1345,y:957,t:1527631802214};\\\", \\\"{x:1345,y:958,t:1527631802230};\\\", \\\"{x:1344,y:959,t:1527631802247};\\\", \\\"{x:1344,y:960,t:1527631802263};\\\", \\\"{x:1343,y:961,t:1527631802285};\\\", \\\"{x:1343,y:962,t:1527631802453};\\\", \\\"{x:1343,y:963,t:1527631802464};\\\", \\\"{x:1343,y:964,t:1527631802500};\\\", \\\"{x:1343,y:965,t:1527631802517};\\\", \\\"{x:1343,y:966,t:1527631802533};\\\", \\\"{x:1342,y:967,t:1527631802556};\\\", \\\"{x:1341,y:968,t:1527631802661};\\\", \\\"{x:1341,y:965,t:1527631802909};\\\", \\\"{x:1340,y:964,t:1527631802917};\\\", \\\"{x:1339,y:962,t:1527631802931};\\\", \\\"{x:1339,y:958,t:1527631802948};\\\", \\\"{x:1337,y:957,t:1527631802963};\\\", \\\"{x:1336,y:954,t:1527631802981};\\\", \\\"{x:1335,y:951,t:1527631802997};\\\", \\\"{x:1335,y:950,t:1527631803013};\\\", \\\"{x:1334,y:948,t:1527631803030};\\\", \\\"{x:1333,y:946,t:1527631803047};\\\", \\\"{x:1333,y:944,t:1527631803064};\\\", \\\"{x:1331,y:942,t:1527631803080};\\\", \\\"{x:1330,y:941,t:1527631803097};\\\", \\\"{x:1329,y:940,t:1527631803114};\\\", \\\"{x:1329,y:939,t:1527631803130};\\\", \\\"{x:1329,y:938,t:1527631803147};\\\", \\\"{x:1327,y:936,t:1527631803164};\\\", \\\"{x:1326,y:935,t:1527631803180};\\\", \\\"{x:1324,y:932,t:1527631803198};\\\", \\\"{x:1324,y:931,t:1527631803215};\\\", \\\"{x:1324,y:930,t:1527631803231};\\\", \\\"{x:1323,y:929,t:1527631803260};\\\", \\\"{x:1323,y:928,t:1527631803341};\\\", \\\"{x:1322,y:926,t:1527631803364};\\\", \\\"{x:1321,y:926,t:1527631803380};\\\", \\\"{x:1321,y:925,t:1527631803413};\\\", \\\"{x:1320,y:925,t:1527631803428};\\\", \\\"{x:1320,y:923,t:1527631803461};\\\", \\\"{x:1319,y:922,t:1527631803493};\\\", \\\"{x:1318,y:922,t:1527631803501};\\\", \\\"{x:1318,y:921,t:1527631803573};\\\", \\\"{x:1317,y:920,t:1527631803628};\\\", \\\"{x:1317,y:919,t:1527631803644};\\\", \\\"{x:1317,y:918,t:1527631803668};\\\", \\\"{x:1316,y:917,t:1527631803701};\\\", \\\"{x:1315,y:917,t:1527631803757};\\\", \\\"{x:1313,y:915,t:1527631804221};\\\", \\\"{x:1313,y:913,t:1527631804232};\\\", \\\"{x:1311,y:911,t:1527631804247};\\\", \\\"{x:1310,y:909,t:1527631804264};\\\", \\\"{x:1309,y:907,t:1527631804282};\\\", \\\"{x:1308,y:906,t:1527631804298};\\\", \\\"{x:1308,y:905,t:1527631804315};\\\", \\\"{x:1307,y:904,t:1527631804332};\\\", \\\"{x:1307,y:902,t:1527631804348};\\\", \\\"{x:1305,y:900,t:1527631804365};\\\", \\\"{x:1305,y:899,t:1527631804388};\\\", \\\"{x:1305,y:898,t:1527631804399};\\\", \\\"{x:1304,y:896,t:1527631804415};\\\", \\\"{x:1302,y:893,t:1527631804432};\\\", \\\"{x:1302,y:891,t:1527631804448};\\\", \\\"{x:1301,y:888,t:1527631804464};\\\", \\\"{x:1300,y:886,t:1527631804482};\\\", \\\"{x:1300,y:883,t:1527631804499};\\\", \\\"{x:1299,y:881,t:1527631804515};\\\", \\\"{x:1298,y:879,t:1527631804532};\\\", \\\"{x:1298,y:877,t:1527631804549};\\\", \\\"{x:1297,y:875,t:1527631804565};\\\", \\\"{x:1296,y:874,t:1527631804597};\\\", \\\"{x:1296,y:873,t:1527631804604};\\\", \\\"{x:1296,y:872,t:1527631804615};\\\", \\\"{x:1295,y:871,t:1527631804632};\\\", \\\"{x:1294,y:868,t:1527631804648};\\\", \\\"{x:1294,y:866,t:1527631804665};\\\", \\\"{x:1294,y:864,t:1527631804682};\\\", \\\"{x:1292,y:861,t:1527631804699};\\\", \\\"{x:1292,y:857,t:1527631804715};\\\", \\\"{x:1291,y:856,t:1527631804732};\\\", \\\"{x:1290,y:851,t:1527631804749};\\\", \\\"{x:1290,y:850,t:1527631804764};\\\", \\\"{x:1290,y:849,t:1527631804781};\\\", \\\"{x:1290,y:848,t:1527631804812};\\\", \\\"{x:1290,y:845,t:1527631807974};\\\", \\\"{x:1296,y:838,t:1527631807984};\\\", \\\"{x:1309,y:829,t:1527631808000};\\\", \\\"{x:1325,y:818,t:1527631808017};\\\", \\\"{x:1341,y:811,t:1527631808033};\\\", \\\"{x:1349,y:803,t:1527631808050};\\\", \\\"{x:1353,y:802,t:1527631808067};\\\", \\\"{x:1355,y:799,t:1527631808084};\\\", \\\"{x:1356,y:796,t:1527631808100};\\\", \\\"{x:1359,y:792,t:1527631808117};\\\", \\\"{x:1361,y:787,t:1527631808134};\\\", \\\"{x:1362,y:784,t:1527631808150};\\\", \\\"{x:1362,y:782,t:1527631808167};\\\", \\\"{x:1363,y:781,t:1527631808184};\\\", \\\"{x:1364,y:780,t:1527631808200};\\\", \\\"{x:1364,y:779,t:1527631808228};\\\", \\\"{x:1365,y:778,t:1527631808244};\\\", \\\"{x:1367,y:775,t:1527631808252};\\\", \\\"{x:1369,y:772,t:1527631808268};\\\", \\\"{x:1371,y:769,t:1527631808284};\\\", \\\"{x:1384,y:757,t:1527631808301};\\\", \\\"{x:1387,y:754,t:1527631808317};\\\", \\\"{x:1387,y:753,t:1527631808334};\\\", \\\"{x:1389,y:752,t:1527631808351};\\\", \\\"{x:1390,y:751,t:1527631808367};\\\", \\\"{x:1391,y:750,t:1527631808388};\\\", \\\"{x:1391,y:753,t:1527631808613};\\\", \\\"{x:1391,y:756,t:1527631808620};\\\", \\\"{x:1391,y:758,t:1527631808634};\\\", \\\"{x:1387,y:766,t:1527631808651};\\\", \\\"{x:1384,y:773,t:1527631808667};\\\", \\\"{x:1380,y:780,t:1527631808684};\\\", \\\"{x:1378,y:785,t:1527631808700};\\\", \\\"{x:1376,y:790,t:1527631808717};\\\", \\\"{x:1375,y:794,t:1527631808734};\\\", \\\"{x:1374,y:800,t:1527631808751};\\\", \\\"{x:1371,y:804,t:1527631808767};\\\", \\\"{x:1367,y:811,t:1527631808784};\\\", \\\"{x:1365,y:816,t:1527631808801};\\\", \\\"{x:1362,y:822,t:1527631808817};\\\", \\\"{x:1359,y:830,t:1527631808834};\\\", \\\"{x:1357,y:836,t:1527631808851};\\\", \\\"{x:1352,y:845,t:1527631808867};\\\", \\\"{x:1346,y:867,t:1527631808884};\\\", \\\"{x:1343,y:878,t:1527631808901};\\\", \\\"{x:1340,y:892,t:1527631808918};\\\", \\\"{x:1337,y:905,t:1527631808934};\\\", \\\"{x:1332,y:915,t:1527631808951};\\\", \\\"{x:1329,y:923,t:1527631808968};\\\", \\\"{x:1328,y:927,t:1527631808984};\\\", \\\"{x:1326,y:931,t:1527631809001};\\\", \\\"{x:1326,y:933,t:1527631809018};\\\", \\\"{x:1326,y:934,t:1527631809033};\\\", \\\"{x:1326,y:932,t:1527631809156};\\\", \\\"{x:1326,y:929,t:1527631809167};\\\", \\\"{x:1330,y:915,t:1527631809184};\\\", \\\"{x:1333,y:904,t:1527631809201};\\\", \\\"{x:1336,y:890,t:1527631809218};\\\", \\\"{x:1337,y:879,t:1527631809233};\\\", \\\"{x:1341,y:858,t:1527631809251};\\\", \\\"{x:1342,y:839,t:1527631809268};\\\", \\\"{x:1344,y:818,t:1527631809284};\\\", \\\"{x:1346,y:802,t:1527631809301};\\\", \\\"{x:1347,y:787,t:1527631809318};\\\", \\\"{x:1348,y:777,t:1527631809334};\\\", \\\"{x:1350,y:767,t:1527631809350};\\\", \\\"{x:1350,y:753,t:1527631809368};\\\", \\\"{x:1350,y:738,t:1527631809384};\\\", \\\"{x:1350,y:729,t:1527631809401};\\\", \\\"{x:1350,y:726,t:1527631809418};\\\", \\\"{x:1350,y:722,t:1527631809434};\\\", \\\"{x:1350,y:720,t:1527631809450};\\\", \\\"{x:1352,y:720,t:1527631809572};\\\", \\\"{x:1353,y:728,t:1527631809584};\\\", \\\"{x:1361,y:743,t:1527631809600};\\\", \\\"{x:1372,y:767,t:1527631809617};\\\", \\\"{x:1377,y:790,t:1527631809634};\\\", \\\"{x:1390,y:814,t:1527631809650};\\\", \\\"{x:1407,y:855,t:1527631809667};\\\", \\\"{x:1417,y:872,t:1527631809684};\\\", \\\"{x:1424,y:887,t:1527631809701};\\\", \\\"{x:1429,y:900,t:1527631809718};\\\", \\\"{x:1436,y:913,t:1527631809735};\\\", \\\"{x:1440,y:925,t:1527631809751};\\\", \\\"{x:1445,y:936,t:1527631809767};\\\", \\\"{x:1449,y:950,t:1527631809785};\\\", \\\"{x:1450,y:956,t:1527631809801};\\\", \\\"{x:1450,y:957,t:1527631809818};\\\", \\\"{x:1452,y:963,t:1527631809834};\\\", \\\"{x:1453,y:966,t:1527631809851};\\\", \\\"{x:1453,y:972,t:1527631809867};\\\", \\\"{x:1453,y:973,t:1527631809884};\\\", \\\"{x:1453,y:974,t:1527631809900};\\\", \\\"{x:1453,y:975,t:1527631809917};\\\", \\\"{x:1453,y:976,t:1527631809935};\\\", \\\"{x:1447,y:976,t:1527631810493};\\\", \\\"{x:1434,y:968,t:1527631810502};\\\", \\\"{x:1398,y:948,t:1527631810518};\\\", \\\"{x:1343,y:924,t:1527631810535};\\\", \\\"{x:1291,y:894,t:1527631810552};\\\", \\\"{x:1220,y:853,t:1527631810568};\\\", \\\"{x:1145,y:816,t:1527631810585};\\\", \\\"{x:1065,y:769,t:1527631810602};\\\", \\\"{x:989,y:727,t:1527631810618};\\\", \\\"{x:927,y:694,t:1527631810635};\\\", \\\"{x:841,y:662,t:1527631810652};\\\", \\\"{x:798,y:645,t:1527631810668};\\\", \\\"{x:758,y:633,t:1527631810684};\\\", \\\"{x:721,y:622,t:1527631810703};\\\", \\\"{x:687,y:610,t:1527631810720};\\\", \\\"{x:667,y:606,t:1527631810734};\\\", \\\"{x:660,y:605,t:1527631810759};\\\", \\\"{x:659,y:605,t:1527631810774};\\\", \\\"{x:657,y:604,t:1527631810791};\\\", \\\"{x:655,y:603,t:1527631810808};\\\", \\\"{x:653,y:602,t:1527631810825};\\\", \\\"{x:652,y:602,t:1527631810841};\\\", \\\"{x:648,y:599,t:1527631810859};\\\", \\\"{x:644,y:595,t:1527631810875};\\\", \\\"{x:632,y:591,t:1527631810892};\\\", \\\"{x:628,y:587,t:1527631810908};\\\", \\\"{x:621,y:583,t:1527631810931};\\\", \\\"{x:614,y:580,t:1527631810948};\\\", \\\"{x:608,y:577,t:1527631810964};\\\", \\\"{x:602,y:573,t:1527631810981};\\\", \\\"{x:592,y:565,t:1527631810998};\\\", \\\"{x:590,y:565,t:1527631811013};\\\", \\\"{x:597,y:565,t:1527631811557};\\\", \\\"{x:605,y:563,t:1527631811567};\\\", \\\"{x:615,y:556,t:1527631811583};\\\", \\\"{x:650,y:547,t:1527631811597};\\\", \\\"{x:736,y:532,t:1527631811616};\\\", \\\"{x:837,y:512,t:1527631811631};\\\", \\\"{x:956,y:500,t:1527631811648};\\\", \\\"{x:1065,y:478,t:1527631811665};\\\", \\\"{x:1132,y:460,t:1527631811681};\\\", \\\"{x:1172,y:457,t:1527631811697};\\\", \\\"{x:1185,y:457,t:1527631811715};\\\", \\\"{x:1197,y:457,t:1527631811731};\\\", \\\"{x:1199,y:459,t:1527631812069};\\\", \\\"{x:1202,y:460,t:1527631812082};\\\", \\\"{x:1217,y:461,t:1527631812099};\\\", \\\"{x:1243,y:462,t:1527631812115};\\\", \\\"{x:1261,y:462,t:1527631812131};\\\", \\\"{x:1282,y:464,t:1527631812149};\\\", \\\"{x:1303,y:464,t:1527631812165};\\\", \\\"{x:1324,y:467,t:1527631812181};\\\", \\\"{x:1336,y:470,t:1527631812199};\\\", \\\"{x:1350,y:474,t:1527631812216};\\\", \\\"{x:1360,y:479,t:1527631812232};\\\", \\\"{x:1369,y:484,t:1527631812248};\\\", \\\"{x:1377,y:489,t:1527631812266};\\\", \\\"{x:1384,y:493,t:1527631812282};\\\", \\\"{x:1389,y:494,t:1527631812299};\\\", \\\"{x:1394,y:497,t:1527631812316};\\\", \\\"{x:1398,y:499,t:1527631812333};\\\", \\\"{x:1401,y:502,t:1527631812349};\\\", \\\"{x:1407,y:505,t:1527631812366};\\\", \\\"{x:1413,y:506,t:1527631812383};\\\", \\\"{x:1418,y:508,t:1527631812399};\\\", \\\"{x:1421,y:508,t:1527631812416};\\\", \\\"{x:1423,y:509,t:1527631812433};\\\", \\\"{x:1426,y:509,t:1527631812449};\\\", \\\"{x:1427,y:509,t:1527631812469};\\\", \\\"{x:1429,y:509,t:1527631812483};\\\", \\\"{x:1437,y:507,t:1527631812499};\\\", \\\"{x:1454,y:501,t:1527631812516};\\\", \\\"{x:1470,y:494,t:1527631812532};\\\", \\\"{x:1484,y:491,t:1527631812550};\\\", \\\"{x:1500,y:488,t:1527631812566};\\\", \\\"{x:1516,y:482,t:1527631812583};\\\", \\\"{x:1528,y:477,t:1527631812600};\\\", \\\"{x:1542,y:474,t:1527631812616};\\\", \\\"{x:1552,y:470,t:1527631812633};\\\", \\\"{x:1558,y:469,t:1527631812650};\\\", \\\"{x:1559,y:468,t:1527631812666};\\\", \\\"{x:1559,y:469,t:1527631813221};\\\", \\\"{x:1555,y:472,t:1527631813234};\\\", \\\"{x:1537,y:481,t:1527631813251};\\\", \\\"{x:1509,y:489,t:1527631813267};\\\", \\\"{x:1455,y:497,t:1527631813285};\\\", \\\"{x:1374,y:501,t:1527631813300};\\\", \\\"{x:1274,y:501,t:1527631813317};\\\", \\\"{x:1143,y:505,t:1527631813334};\\\", \\\"{x:1004,y:507,t:1527631813351};\\\", \\\"{x:866,y:509,t:1527631813367};\\\", \\\"{x:725,y:509,t:1527631813383};\\\", \\\"{x:600,y:509,t:1527631813401};\\\", \\\"{x:547,y:509,t:1527631813410};\\\", \\\"{x:398,y:509,t:1527631813428};\\\", \\\"{x:341,y:511,t:1527631813444};\\\", \\\"{x:320,y:515,t:1527631813465};\\\", \\\"{x:316,y:515,t:1527631813482};\\\", \\\"{x:315,y:516,t:1527631814301};\\\", \\\"{x:322,y:516,t:1527631814315};\\\", \\\"{x:434,y:484,t:1527631814333};\\\", \\\"{x:586,y:444,t:1527631814350};\\\", \\\"{x:726,y:412,t:1527631814368};\\\", \\\"{x:865,y:388,t:1527631814384};\\\", \\\"{x:991,y:357,t:1527631814400};\\\", \\\"{x:1101,y:337,t:1527631814417};\\\", \\\"{x:1109,y:337,t:1527631814434};\\\", \\\"{x:1114,y:338,t:1527631814450};\\\", \\\"{x:1118,y:335,t:1527631814467};\\\", \\\"{x:1116,y:335,t:1527631814581};\\\", \\\"{x:1114,y:337,t:1527631814588};\\\", \\\"{x:1114,y:340,t:1527631814600};\\\", \\\"{x:1109,y:352,t:1527631814617};\\\", \\\"{x:1108,y:366,t:1527631814634};\\\", \\\"{x:1108,y:380,t:1527631814650};\\\", \\\"{x:1111,y:388,t:1527631814667};\\\", \\\"{x:1115,y:392,t:1527631814684};\\\", \\\"{x:1118,y:393,t:1527631814700};\\\", \\\"{x:1120,y:394,t:1527631814717};\\\", \\\"{x:1121,y:394,t:1527631814773};\\\", \\\"{x:1121,y:395,t:1527631814784};\\\", \\\"{x:1121,y:397,t:1527631814801};\\\", \\\"{x:1119,y:401,t:1527631814816};\\\", \\\"{x:1116,y:404,t:1527631814833};\\\", \\\"{x:1114,y:406,t:1527631814850};\\\", \\\"{x:1113,y:407,t:1527631814867};\\\", \\\"{x:1112,y:408,t:1527631814891};\\\", \\\"{x:1111,y:409,t:1527631814931};\\\", \\\"{x:1110,y:411,t:1527631814939};\\\", \\\"{x:1107,y:413,t:1527631814955};\\\", \\\"{x:1107,y:414,t:1527631814966};\\\", \\\"{x:1106,y:415,t:1527631814984};\\\", \\\"{x:1105,y:416,t:1527631815020};\\\", \\\"{x:1104,y:417,t:1527631815034};\\\", \\\"{x:1103,y:418,t:1527631815068};\\\", \\\"{x:1103,y:419,t:1527631815084};\\\", \\\"{x:1103,y:422,t:1527631815101};\\\", \\\"{x:1102,y:426,t:1527631815117};\\\", \\\"{x:1101,y:432,t:1527631815134};\\\", \\\"{x:1100,y:439,t:1527631815151};\\\", \\\"{x:1099,y:446,t:1527631815169};\\\", \\\"{x:1098,y:453,t:1527631815184};\\\", \\\"{x:1096,y:465,t:1527631815201};\\\", \\\"{x:1094,y:482,t:1527631815217};\\\", \\\"{x:1090,y:498,t:1527631815233};\\\", \\\"{x:1088,y:512,t:1527631815251};\\\", \\\"{x:1084,y:526,t:1527631815267};\\\", \\\"{x:1081,y:532,t:1527631815284};\\\", \\\"{x:1078,y:540,t:1527631815301};\\\", \\\"{x:1076,y:549,t:1527631815317};\\\", \\\"{x:1073,y:559,t:1527631815334};\\\", \\\"{x:1071,y:566,t:1527631815350};\\\", \\\"{x:1068,y:571,t:1527631815368};\\\", \\\"{x:1067,y:578,t:1527631815384};\\\", \\\"{x:1065,y:582,t:1527631815400};\\\", \\\"{x:1063,y:585,t:1527631815418};\\\", \\\"{x:1062,y:591,t:1527631815434};\\\", \\\"{x:1062,y:592,t:1527631815451};\\\", \\\"{x:1061,y:596,t:1527631815467};\\\", \\\"{x:1061,y:598,t:1527631815483};\\\", \\\"{x:1060,y:601,t:1527631815501};\\\", \\\"{x:1060,y:602,t:1527631815525};\\\", \\\"{x:1060,y:603,t:1527631815556};\\\", \\\"{x:1068,y:605,t:1527631815861};\\\", \\\"{x:1073,y:608,t:1527631815868};\\\", \\\"{x:1075,y:609,t:1527631815885};\\\", \\\"{x:1086,y:608,t:1527631817139};\\\", \\\"{x:1105,y:600,t:1527631817152};\\\", \\\"{x:1169,y:579,t:1527631817168};\\\", \\\"{x:1268,y:555,t:1527631817185};\\\", \\\"{x:1389,y:528,t:1527631817201};\\\", \\\"{x:1495,y:506,t:1527631817218};\\\", \\\"{x:1655,y:463,t:1527631817236};\\\", \\\"{x:1739,y:437,t:1527631817252};\\\", \\\"{x:1800,y:422,t:1527631817268};\\\", \\\"{x:1844,y:410,t:1527631817286};\\\", \\\"{x:1876,y:398,t:1527631817302};\\\", \\\"{x:1890,y:393,t:1527631817318};\\\", \\\"{x:1899,y:389,t:1527631817336};\\\", \\\"{x:1901,y:388,t:1527631817353};\\\", \\\"{x:1897,y:389,t:1527631817476};\\\", \\\"{x:1895,y:389,t:1527631817486};\\\", \\\"{x:1887,y:394,t:1527631817503};\\\", \\\"{x:1879,y:398,t:1527631817520};\\\", \\\"{x:1867,y:405,t:1527631817536};\\\", \\\"{x:1853,y:409,t:1527631817553};\\\", \\\"{x:1835,y:415,t:1527631817569};\\\", \\\"{x:1813,y:422,t:1527631817585};\\\", \\\"{x:1794,y:425,t:1527631817602};\\\", \\\"{x:1782,y:427,t:1527631817619};\\\", \\\"{x:1772,y:429,t:1527631817635};\\\", \\\"{x:1770,y:429,t:1527631817653};\\\", \\\"{x:1769,y:429,t:1527631817669};\\\", \\\"{x:1766,y:429,t:1527631817685};\\\", \\\"{x:1759,y:427,t:1527631817702};\\\", \\\"{x:1747,y:418,t:1527631817719};\\\", \\\"{x:1739,y:412,t:1527631817736};\\\", \\\"{x:1731,y:406,t:1527631817753};\\\", \\\"{x:1725,y:402,t:1527631817770};\\\", \\\"{x:1722,y:401,t:1527631817786};\\\", \\\"{x:1719,y:400,t:1527631817803};\\\", \\\"{x:1711,y:400,t:1527631817820};\\\", \\\"{x:1703,y:400,t:1527631817836};\\\", \\\"{x:1695,y:400,t:1527631817853};\\\", \\\"{x:1684,y:401,t:1527631817870};\\\", \\\"{x:1674,y:403,t:1527631817886};\\\", \\\"{x:1662,y:407,t:1527631817903};\\\", \\\"{x:1654,y:408,t:1527631817919};\\\", \\\"{x:1649,y:411,t:1527631817936};\\\", \\\"{x:1643,y:411,t:1527631817953};\\\", \\\"{x:1642,y:412,t:1527631817971};\\\", \\\"{x:1640,y:413,t:1527631817986};\\\", \\\"{x:1637,y:414,t:1527631818003};\\\", \\\"{x:1634,y:418,t:1527631818019};\\\", \\\"{x:1631,y:420,t:1527631818036};\\\", \\\"{x:1628,y:425,t:1527631818053};\\\", \\\"{x:1625,y:429,t:1527631818069};\\\", \\\"{x:1624,y:434,t:1527631818086};\\\", \\\"{x:1623,y:436,t:1527631818102};\\\", \\\"{x:1623,y:437,t:1527631818119};\\\", \\\"{x:1621,y:440,t:1527631818136};\\\", \\\"{x:1620,y:443,t:1527631818153};\\\", \\\"{x:1618,y:447,t:1527631818170};\\\", \\\"{x:1617,y:449,t:1527631818187};\\\", \\\"{x:1616,y:453,t:1527631818202};\\\", \\\"{x:1612,y:459,t:1527631818219};\\\", \\\"{x:1609,y:462,t:1527631818237};\\\", \\\"{x:1607,y:466,t:1527631818253};\\\", \\\"{x:1606,y:468,t:1527631818270};\\\", \\\"{x:1605,y:469,t:1527631818287};\\\", \\\"{x:1605,y:470,t:1527631818303};\\\", \\\"{x:1603,y:472,t:1527631818320};\\\", \\\"{x:1602,y:474,t:1527631818337};\\\", \\\"{x:1601,y:475,t:1527631818353};\\\", \\\"{x:1601,y:476,t:1527631818370};\\\", \\\"{x:1600,y:477,t:1527631818387};\\\", \\\"{x:1598,y:480,t:1527631818403};\\\", \\\"{x:1598,y:483,t:1527631818420};\\\", \\\"{x:1597,y:485,t:1527631818437};\\\", \\\"{x:1595,y:489,t:1527631818453};\\\", \\\"{x:1595,y:491,t:1527631818470};\\\", \\\"{x:1593,y:493,t:1527631818487};\\\", \\\"{x:1593,y:495,t:1527631818502};\\\", \\\"{x:1592,y:499,t:1527631818520};\\\", \\\"{x:1590,y:503,t:1527631818537};\\\", \\\"{x:1588,y:506,t:1527631818553};\\\", \\\"{x:1586,y:508,t:1527631818570};\\\", \\\"{x:1586,y:513,t:1527631818588};\\\", \\\"{x:1584,y:517,t:1527631818604};\\\", \\\"{x:1583,y:520,t:1527631818620};\\\", \\\"{x:1582,y:522,t:1527631818637};\\\", \\\"{x:1582,y:523,t:1527631818653};\\\", \\\"{x:1581,y:525,t:1527631818670};\\\", \\\"{x:1580,y:526,t:1527631818687};\\\", \\\"{x:1579,y:528,t:1527631818704};\\\", \\\"{x:1578,y:530,t:1527631818720};\\\", \\\"{x:1576,y:533,t:1527631818737};\\\", \\\"{x:1574,y:536,t:1527631818754};\\\", \\\"{x:1572,y:544,t:1527631818770};\\\", \\\"{x:1567,y:553,t:1527631818787};\\\", \\\"{x:1562,y:564,t:1527631818804};\\\", \\\"{x:1559,y:568,t:1527631818820};\\\", \\\"{x:1559,y:570,t:1527631818837};\\\", \\\"{x:1558,y:573,t:1527631818854};\\\", \\\"{x:1558,y:574,t:1527631818876};\\\", \\\"{x:1556,y:576,t:1527631818887};\\\", \\\"{x:1556,y:577,t:1527631818904};\\\", \\\"{x:1555,y:579,t:1527631818920};\\\", \\\"{x:1555,y:582,t:1527631818938};\\\", \\\"{x:1554,y:583,t:1527631818955};\\\", \\\"{x:1553,y:585,t:1527631818970};\\\", \\\"{x:1552,y:586,t:1527631818988};\\\", \\\"{x:1552,y:588,t:1527631819004};\\\", \\\"{x:1552,y:589,t:1527631819021};\\\", \\\"{x:1550,y:591,t:1527631819037};\\\", \\\"{x:1549,y:592,t:1527631819076};\\\", \\\"{x:1549,y:593,t:1527631819100};\\\", \\\"{x:1548,y:595,t:1527631819132};\\\", \\\"{x:1548,y:596,t:1527631819141};\\\", \\\"{x:1547,y:596,t:1527631819156};\\\", \\\"{x:1547,y:598,t:1527631819180};\\\", \\\"{x:1545,y:600,t:1527631819197};\\\", \\\"{x:1544,y:601,t:1527631819212};\\\", \\\"{x:1544,y:602,t:1527631819220};\\\", \\\"{x:1542,y:603,t:1527631819237};\\\", \\\"{x:1542,y:604,t:1527631819254};\\\", \\\"{x:1541,y:604,t:1527631819271};\\\", \\\"{x:1541,y:606,t:1527631819287};\\\", \\\"{x:1540,y:606,t:1527631819304};\\\", \\\"{x:1539,y:607,t:1527631819322};\\\", \\\"{x:1538,y:609,t:1527631819337};\\\", \\\"{x:1536,y:611,t:1527631819354};\\\", \\\"{x:1536,y:612,t:1527631819372};\\\", \\\"{x:1535,y:614,t:1527631819387};\\\", \\\"{x:1534,y:616,t:1527631819404};\\\", \\\"{x:1533,y:616,t:1527631819421};\\\", \\\"{x:1533,y:617,t:1527631819437};\\\", \\\"{x:1533,y:618,t:1527631819460};\\\", \\\"{x:1532,y:619,t:1527631819476};\\\", \\\"{x:1531,y:620,t:1527631819489};\\\", \\\"{x:1530,y:622,t:1527631819504};\\\", \\\"{x:1529,y:623,t:1527631819521};\\\", \\\"{x:1527,y:625,t:1527631819537};\\\", \\\"{x:1526,y:626,t:1527631819565};\\\", \\\"{x:1526,y:627,t:1527631819580};\\\", \\\"{x:1525,y:628,t:1527631819628};\\\", \\\"{x:1524,y:628,t:1527631819644};\\\", \\\"{x:1521,y:629,t:1527631820737};\\\", \\\"{x:1520,y:630,t:1527631820744};\\\", \\\"{x:1520,y:631,t:1527631820775};\\\", \\\"{x:1519,y:632,t:1527631820793};\\\", \\\"{x:1518,y:633,t:1527631820840};\\\", \\\"{x:1517,y:633,t:1527631820879};\\\", \\\"{x:1517,y:634,t:1527631820976};\\\", \\\"{x:1516,y:634,t:1527631821063};\\\", \\\"{x:1514,y:635,t:1527631821127};\\\", \\\"{x:1514,y:636,t:1527631821143};\\\", \\\"{x:1513,y:637,t:1527631821158};\\\", \\\"{x:1512,y:638,t:1527631821175};\\\", \\\"{x:1511,y:640,t:1527631821193};\\\", \\\"{x:1510,y:642,t:1527631821209};\\\", \\\"{x:1510,y:643,t:1527631821239};\\\", \\\"{x:1509,y:643,t:1527631821248};\\\", \\\"{x:1509,y:644,t:1527631821259};\\\", \\\"{x:1508,y:645,t:1527631821275};\\\", \\\"{x:1508,y:646,t:1527631821293};\\\", \\\"{x:1507,y:647,t:1527631821310};\\\", \\\"{x:1505,y:650,t:1527631821325};\\\", \\\"{x:1505,y:652,t:1527631821342};\\\", \\\"{x:1502,y:659,t:1527631821359};\\\", \\\"{x:1500,y:665,t:1527631821375};\\\", \\\"{x:1497,y:669,t:1527631821392};\\\", \\\"{x:1496,y:673,t:1527631821409};\\\", \\\"{x:1494,y:676,t:1527631821425};\\\", \\\"{x:1493,y:680,t:1527631821443};\\\", \\\"{x:1492,y:683,t:1527631821459};\\\", \\\"{x:1490,y:685,t:1527631821476};\\\", \\\"{x:1490,y:688,t:1527631821492};\\\", \\\"{x:1489,y:690,t:1527631821510};\\\", \\\"{x:1486,y:695,t:1527631821526};\\\", \\\"{x:1484,y:700,t:1527631821542};\\\", \\\"{x:1482,y:703,t:1527631821559};\\\", \\\"{x:1482,y:705,t:1527631821576};\\\", \\\"{x:1480,y:708,t:1527631821592};\\\", \\\"{x:1480,y:711,t:1527631821610};\\\", \\\"{x:1479,y:714,t:1527631821626};\\\", \\\"{x:1477,y:718,t:1527631821643};\\\", \\\"{x:1475,y:722,t:1527631821659};\\\", \\\"{x:1474,y:726,t:1527631821677};\\\", \\\"{x:1472,y:729,t:1527631821692};\\\", \\\"{x:1471,y:730,t:1527631821709};\\\", \\\"{x:1471,y:732,t:1527631821726};\\\", \\\"{x:1471,y:734,t:1527631821743};\\\", \\\"{x:1469,y:736,t:1527631821759};\\\", \\\"{x:1469,y:739,t:1527631821776};\\\", \\\"{x:1466,y:743,t:1527631821792};\\\", \\\"{x:1464,y:747,t:1527631821810};\\\", \\\"{x:1461,y:751,t:1527631821827};\\\", \\\"{x:1458,y:755,t:1527631821843};\\\", \\\"{x:1454,y:760,t:1527631821859};\\\", \\\"{x:1449,y:765,t:1527631821876};\\\", \\\"{x:1446,y:770,t:1527631821893};\\\", \\\"{x:1444,y:773,t:1527631821910};\\\", \\\"{x:1440,y:778,t:1527631821927};\\\", \\\"{x:1439,y:779,t:1527631821944};\\\", \\\"{x:1438,y:781,t:1527631821983};\\\", \\\"{x:1438,y:782,t:1527631828689};\\\", \\\"{x:1435,y:783,t:1527631828833};\\\", \\\"{x:1430,y:785,t:1527631828849};\\\", \\\"{x:1422,y:788,t:1527631828865};\\\", \\\"{x:1411,y:794,t:1527631828883};\\\", \\\"{x:1398,y:804,t:1527631828899};\\\", \\\"{x:1386,y:810,t:1527631828916};\\\", \\\"{x:1371,y:818,t:1527631828932};\\\", \\\"{x:1360,y:823,t:1527631828949};\\\", \\\"{x:1352,y:826,t:1527631828965};\\\", \\\"{x:1343,y:831,t:1527631828983};\\\", \\\"{x:1336,y:834,t:1527631828999};\\\", \\\"{x:1335,y:836,t:1527631829015};\\\", \\\"{x:1333,y:836,t:1527631829032};\\\", \\\"{x:1331,y:837,t:1527631829056};\\\", \\\"{x:1329,y:838,t:1527631829088};\\\", \\\"{x:1328,y:839,t:1527631829104};\\\", \\\"{x:1327,y:839,t:1527631829115};\\\", \\\"{x:1325,y:839,t:1527631829133};\\\", \\\"{x:1322,y:839,t:1527631829149};\\\", \\\"{x:1320,y:839,t:1527631829166};\\\", \\\"{x:1319,y:839,t:1527631829181};\\\", \\\"{x:1317,y:839,t:1527631829198};\\\", \\\"{x:1314,y:838,t:1527631829215};\\\", \\\"{x:1312,y:837,t:1527631829232};\\\", \\\"{x:1311,y:837,t:1527631829287};\\\", \\\"{x:1310,y:837,t:1527631829319};\\\", \\\"{x:1309,y:836,t:1527631829343};\\\", \\\"{x:1308,y:836,t:1527631829368};\\\", \\\"{x:1307,y:836,t:1527631829383};\\\", \\\"{x:1306,y:836,t:1527631830904};\\\", \\\"{x:1304,y:836,t:1527631830917};\\\", \\\"{x:1298,y:832,t:1527631830933};\\\", \\\"{x:1294,y:830,t:1527631830951};\\\", \\\"{x:1288,y:827,t:1527631830968};\\\", \\\"{x:1285,y:827,t:1527631830984};\\\", \\\"{x:1282,y:825,t:1527631831000};\\\", \\\"{x:1281,y:825,t:1527631831039};\\\", \\\"{x:1280,y:825,t:1527631831391};\\\", \\\"{x:1278,y:825,t:1527631831401};\\\", \\\"{x:1272,y:825,t:1527631831419};\\\", \\\"{x:1267,y:825,t:1527631831435};\\\", \\\"{x:1263,y:825,t:1527631831451};\\\", \\\"{x:1262,y:825,t:1527631831467};\\\", \\\"{x:1263,y:825,t:1527631831871};\\\", \\\"{x:1264,y:826,t:1527631831887};\\\", \\\"{x:1265,y:826,t:1527631831903};\\\", \\\"{x:1266,y:826,t:1527631831944};\\\", \\\"{x:1267,y:827,t:1527631831951};\\\", \\\"{x:1268,y:827,t:1527631832008};\\\", \\\"{x:1268,y:828,t:1527631832018};\\\", \\\"{x:1269,y:828,t:1527631832047};\\\", \\\"{x:1270,y:828,t:1527631832063};\\\", \\\"{x:1271,y:828,t:1527631833672};\\\", \\\"{x:1272,y:828,t:1527631833686};\\\", \\\"{x:1278,y:829,t:1527631833702};\\\", \\\"{x:1281,y:830,t:1527631833720};\\\", \\\"{x:1282,y:831,t:1527631833752};\\\", \\\"{x:1283,y:831,t:1527631833943};\\\", \\\"{x:1283,y:832,t:1527631836136};\\\", \\\"{x:1283,y:834,t:1527631836144};\\\", \\\"{x:1281,y:837,t:1527631836155};\\\", \\\"{x:1276,y:845,t:1527631836171};\\\", \\\"{x:1272,y:852,t:1527631836189};\\\", \\\"{x:1269,y:860,t:1527631836205};\\\", \\\"{x:1267,y:865,t:1527631836222};\\\", \\\"{x:1265,y:870,t:1527631836239};\\\", \\\"{x:1264,y:873,t:1527631836254};\\\", \\\"{x:1261,y:884,t:1527631836271};\\\", \\\"{x:1260,y:891,t:1527631836288};\\\", \\\"{x:1259,y:897,t:1527631836304};\\\", \\\"{x:1258,y:901,t:1527631836321};\\\", \\\"{x:1257,y:905,t:1527631836338};\\\", \\\"{x:1253,y:913,t:1527631836355};\\\", \\\"{x:1251,y:921,t:1527631836371};\\\", \\\"{x:1248,y:928,t:1527631836389};\\\", \\\"{x:1247,y:934,t:1527631836404};\\\", \\\"{x:1243,y:938,t:1527631836422};\\\", \\\"{x:1243,y:941,t:1527631836439};\\\", \\\"{x:1242,y:942,t:1527631836464};\\\", \\\"{x:1241,y:942,t:1527631836479};\\\", \\\"{x:1240,y:944,t:1527631836487};\\\", \\\"{x:1239,y:946,t:1527631836519};\\\", \\\"{x:1238,y:946,t:1527631836528};\\\", \\\"{x:1237,y:948,t:1527631836544};\\\", \\\"{x:1236,y:948,t:1527631836556};\\\", \\\"{x:1234,y:951,t:1527631836571};\\\", \\\"{x:1232,y:953,t:1527631836589};\\\", \\\"{x:1228,y:956,t:1527631836606};\\\", \\\"{x:1225,y:959,t:1527631836621};\\\", \\\"{x:1223,y:961,t:1527631836639};\\\", \\\"{x:1222,y:961,t:1527631836655};\\\", \\\"{x:1221,y:962,t:1527631836680};\\\", \\\"{x:1221,y:963,t:1527631836689};\\\", \\\"{x:1219,y:964,t:1527631836705};\\\", \\\"{x:1219,y:965,t:1527631836722};\\\", \\\"{x:1218,y:965,t:1527631836744};\\\", \\\"{x:1218,y:966,t:1527631836792};\\\", \\\"{x:1220,y:966,t:1527631837160};\\\", \\\"{x:1221,y:966,t:1527631837176};\\\", \\\"{x:1223,y:966,t:1527631837188};\\\", \\\"{x:1226,y:964,t:1527631837205};\\\", \\\"{x:1230,y:962,t:1527631837222};\\\", \\\"{x:1235,y:960,t:1527631837238};\\\", \\\"{x:1248,y:955,t:1527631837255};\\\", \\\"{x:1255,y:951,t:1527631837272};\\\", \\\"{x:1261,y:949,t:1527631837288};\\\", \\\"{x:1269,y:945,t:1527631837305};\\\", \\\"{x:1280,y:938,t:1527631837322};\\\", \\\"{x:1283,y:937,t:1527631837338};\\\", \\\"{x:1284,y:936,t:1527631837355};\\\", \\\"{x:1285,y:935,t:1527631837372};\\\", \\\"{x:1286,y:934,t:1527631837388};\\\", \\\"{x:1288,y:931,t:1527631837405};\\\", \\\"{x:1290,y:925,t:1527631837422};\\\", \\\"{x:1294,y:913,t:1527631837439};\\\", \\\"{x:1296,y:895,t:1527631837455};\\\", \\\"{x:1296,y:878,t:1527631837472};\\\", \\\"{x:1296,y:871,t:1527631837489};\\\", \\\"{x:1296,y:861,t:1527631837505};\\\", \\\"{x:1296,y:855,t:1527631837522};\\\", \\\"{x:1296,y:854,t:1527631837539};\\\", \\\"{x:1296,y:853,t:1527631837555};\\\", \\\"{x:1296,y:852,t:1527631837760};\\\", \\\"{x:1295,y:851,t:1527631837772};\\\", \\\"{x:1293,y:846,t:1527631837790};\\\", \\\"{x:1292,y:839,t:1527631837805};\\\", \\\"{x:1290,y:835,t:1527631837823};\\\", \\\"{x:1287,y:830,t:1527631837839};\\\", \\\"{x:1287,y:829,t:1527631837903};\\\", \\\"{x:1287,y:828,t:1527631838088};\\\", \\\"{x:1286,y:828,t:1527631839137};\\\", \\\"{x:1284,y:828,t:1527631839156};\\\", \\\"{x:1281,y:829,t:1527631839173};\\\", \\\"{x:1280,y:829,t:1527631839190};\\\", \\\"{x:1278,y:830,t:1527631839207};\\\", \\\"{x:1277,y:832,t:1527631839231};\\\", \\\"{x:1276,y:832,t:1527631839241};\\\", \\\"{x:1275,y:833,t:1527631839258};\\\", \\\"{x:1273,y:834,t:1527631839304};\\\", \\\"{x:1272,y:836,t:1527631839319};\\\", \\\"{x:1271,y:836,t:1527631839327};\\\", \\\"{x:1271,y:837,t:1527631839340};\\\", \\\"{x:1268,y:841,t:1527631839357};\\\", \\\"{x:1268,y:843,t:1527631839374};\\\", \\\"{x:1267,y:844,t:1527631839391};\\\", \\\"{x:1267,y:845,t:1527631839680};\\\", \\\"{x:1267,y:846,t:1527631839806};\\\", \\\"{x:1267,y:847,t:1527631839839};\\\", \\\"{x:1267,y:848,t:1527631840864};\\\", \\\"{x:1268,y:852,t:1527631840874};\\\", \\\"{x:1268,y:848,t:1527631841528};\\\", \\\"{x:1268,y:844,t:1527631841543};\\\", \\\"{x:1268,y:828,t:1527631841559};\\\", \\\"{x:1268,y:819,t:1527631841575};\\\", \\\"{x:1267,y:814,t:1527631841593};\\\", \\\"{x:1267,y:807,t:1527631841608};\\\", \\\"{x:1267,y:803,t:1527631841626};\\\", \\\"{x:1267,y:802,t:1527631841643};\\\", \\\"{x:1267,y:801,t:1527631841658};\\\", \\\"{x:1266,y:800,t:1527631841680};\\\", \\\"{x:1265,y:800,t:1527631841824};\\\", \\\"{x:1263,y:805,t:1527631841832};\\\", \\\"{x:1259,y:813,t:1527631841842};\\\", \\\"{x:1254,y:825,t:1527631841860};\\\", \\\"{x:1245,y:843,t:1527631841876};\\\", \\\"{x:1238,y:856,t:1527631841893};\\\", \\\"{x:1232,y:867,t:1527631841910};\\\", \\\"{x:1228,y:874,t:1527631841925};\\\", \\\"{x:1227,y:879,t:1527631841943};\\\", \\\"{x:1225,y:883,t:1527631841960};\\\", \\\"{x:1223,y:887,t:1527631841975};\\\", \\\"{x:1221,y:894,t:1527631841992};\\\", \\\"{x:1220,y:898,t:1527631842010};\\\", \\\"{x:1218,y:904,t:1527631842026};\\\", \\\"{x:1217,y:909,t:1527631842042};\\\", \\\"{x:1215,y:914,t:1527631842060};\\\", \\\"{x:1212,y:921,t:1527631842076};\\\", \\\"{x:1207,y:930,t:1527631842093};\\\", \\\"{x:1206,y:935,t:1527631842109};\\\", \\\"{x:1203,y:941,t:1527631842126};\\\", \\\"{x:1203,y:948,t:1527631842143};\\\", \\\"{x:1201,y:957,t:1527631842159};\\\", \\\"{x:1200,y:962,t:1527631842175};\\\", \\\"{x:1200,y:964,t:1527631842194};\\\", \\\"{x:1200,y:965,t:1527631842210};\\\", \\\"{x:1200,y:966,t:1527631842226};\\\", \\\"{x:1200,y:967,t:1527631842271};\\\", \\\"{x:1200,y:968,t:1527631842296};\\\", \\\"{x:1200,y:969,t:1527631842319};\\\", \\\"{x:1200,y:970,t:1527631842344};\\\", \\\"{x:1201,y:972,t:1527631842368};\\\", \\\"{x:1202,y:975,t:1527631842376};\\\", \\\"{x:1206,y:978,t:1527631842393};\\\", \\\"{x:1206,y:980,t:1527631842410};\\\", \\\"{x:1207,y:981,t:1527631842560};\\\", \\\"{x:1211,y:987,t:1527631842577};\\\", \\\"{x:1213,y:989,t:1527631842592};\\\", \\\"{x:1214,y:990,t:1527631842759};\\\", \\\"{x:1215,y:990,t:1527631842816};\\\", \\\"{x:1216,y:990,t:1527631842827};\\\", \\\"{x:1220,y:990,t:1527631842843};\\\", \\\"{x:1224,y:990,t:1527631842860};\\\", \\\"{x:1230,y:990,t:1527631842876};\\\", \\\"{x:1236,y:990,t:1527631842894};\\\", \\\"{x:1241,y:990,t:1527631842909};\\\", \\\"{x:1250,y:989,t:1527631842926};\\\", \\\"{x:1256,y:987,t:1527631842943};\\\", \\\"{x:1258,y:987,t:1527631842960};\\\", \\\"{x:1265,y:985,t:1527631842977};\\\", \\\"{x:1268,y:984,t:1527631842994};\\\", \\\"{x:1276,y:980,t:1527631843010};\\\", \\\"{x:1285,y:977,t:1527631843027};\\\", \\\"{x:1291,y:976,t:1527631843044};\\\", \\\"{x:1298,y:973,t:1527631843060};\\\", \\\"{x:1299,y:973,t:1527631843080};\\\", \\\"{x:1301,y:973,t:1527631843104};\\\", \\\"{x:1302,y:973,t:1527631843112};\\\", \\\"{x:1306,y:973,t:1527631843126};\\\", \\\"{x:1316,y:973,t:1527631843143};\\\", \\\"{x:1326,y:975,t:1527631843161};\\\", \\\"{x:1335,y:975,t:1527631843177};\\\", \\\"{x:1340,y:975,t:1527631843193};\\\", \\\"{x:1342,y:973,t:1527631844248};\\\", \\\"{x:1343,y:971,t:1527631844261};\\\", \\\"{x:1348,y:966,t:1527631844278};\\\", \\\"{x:1364,y:955,t:1527631844295};\\\", \\\"{x:1395,y:932,t:1527631844311};\\\", \\\"{x:1475,y:868,t:1527631844327};\\\", \\\"{x:1528,y:820,t:1527631844345};\\\", \\\"{x:1571,y:778,t:1527631844361};\\\", \\\"{x:1608,y:742,t:1527631844380};\\\", \\\"{x:1635,y:714,t:1527631844395};\\\", \\\"{x:1656,y:678,t:1527631844411};\\\", \\\"{x:1672,y:644,t:1527631844428};\\\", \\\"{x:1682,y:619,t:1527631844445};\\\", \\\"{x:1688,y:595,t:1527631844462};\\\", \\\"{x:1694,y:575,t:1527631844478};\\\", \\\"{x:1698,y:558,t:1527631844495};\\\", \\\"{x:1699,y:549,t:1527631844511};\\\", \\\"{x:1702,y:539,t:1527631844528};\\\", \\\"{x:1702,y:524,t:1527631844545};\\\", \\\"{x:1702,y:502,t:1527631844561};\\\", \\\"{x:1698,y:493,t:1527631844580};\\\", \\\"{x:1696,y:486,t:1527631844595};\\\", \\\"{x:1694,y:480,t:1527631844612};\\\", \\\"{x:1689,y:468,t:1527631844628};\\\", \\\"{x:1678,y:454,t:1527631844645};\\\", \\\"{x:1671,y:446,t:1527631844662};\\\", \\\"{x:1665,y:441,t:1527631844678};\\\", \\\"{x:1660,y:438,t:1527631844694};\\\", \\\"{x:1655,y:435,t:1527631844712};\\\", \\\"{x:1654,y:435,t:1527631844728};\\\", \\\"{x:1650,y:435,t:1527631845024};\\\", \\\"{x:1644,y:439,t:1527631845032};\\\", \\\"{x:1639,y:445,t:1527631845045};\\\", \\\"{x:1629,y:456,t:1527631845062};\\\", \\\"{x:1614,y:468,t:1527631845079};\\\", \\\"{x:1603,y:474,t:1527631845096};\\\", \\\"{x:1593,y:481,t:1527631845111};\\\", \\\"{x:1586,y:485,t:1527631845129};\\\", \\\"{x:1583,y:486,t:1527631845145};\\\", \\\"{x:1581,y:488,t:1527631845162};\\\", \\\"{x:1579,y:488,t:1527631845179};\\\", \\\"{x:1578,y:488,t:1527631845195};\\\", \\\"{x:1577,y:488,t:1527631845212};\\\", \\\"{x:1575,y:489,t:1527631845229};\\\", \\\"{x:1575,y:491,t:1527631845391};\\\", \\\"{x:1574,y:495,t:1527631845399};\\\", \\\"{x:1570,y:502,t:1527631845412};\\\", \\\"{x:1563,y:518,t:1527631845429};\\\", \\\"{x:1556,y:529,t:1527631845446};\\\", \\\"{x:1550,y:544,t:1527631845462};\\\", \\\"{x:1546,y:557,t:1527631845480};\\\", \\\"{x:1544,y:565,t:1527631845495};\\\", \\\"{x:1540,y:572,t:1527631845512};\\\", \\\"{x:1538,y:576,t:1527631845529};\\\", \\\"{x:1537,y:580,t:1527631845546};\\\", \\\"{x:1537,y:581,t:1527631845562};\\\", \\\"{x:1535,y:584,t:1527631845580};\\\", \\\"{x:1534,y:585,t:1527631845607};\\\", \\\"{x:1533,y:587,t:1527631845728};\\\", \\\"{x:1532,y:589,t:1527631845746};\\\", \\\"{x:1529,y:594,t:1527631845762};\\\", \\\"{x:1528,y:597,t:1527631845780};\\\", \\\"{x:1527,y:600,t:1527631845796};\\\", \\\"{x:1526,y:603,t:1527631845813};\\\", \\\"{x:1524,y:606,t:1527631845828};\\\", \\\"{x:1521,y:611,t:1527631845846};\\\", \\\"{x:1519,y:616,t:1527631845863};\\\", \\\"{x:1517,y:621,t:1527631845880};\\\", \\\"{x:1515,y:623,t:1527631845896};\\\", \\\"{x:1513,y:626,t:1527631845913};\\\", \\\"{x:1512,y:630,t:1527631845929};\\\", \\\"{x:1509,y:635,t:1527631845947};\\\", \\\"{x:1507,y:638,t:1527631845963};\\\", \\\"{x:1505,y:640,t:1527631845979};\\\", \\\"{x:1504,y:641,t:1527631845996};\\\", \\\"{x:1504,y:643,t:1527631846013};\\\", \\\"{x:1502,y:644,t:1527631846029};\\\", \\\"{x:1502,y:646,t:1527631846064};\\\", \\\"{x:1501,y:647,t:1527631846079};\\\", \\\"{x:1500,y:649,t:1527631846096};\\\", \\\"{x:1499,y:650,t:1527631846113};\\\", \\\"{x:1499,y:651,t:1527631846135};\\\", \\\"{x:1499,y:653,t:1527631846146};\\\", \\\"{x:1498,y:659,t:1527631846163};\\\", \\\"{x:1496,y:671,t:1527631846179};\\\", \\\"{x:1494,y:688,t:1527631846196};\\\", \\\"{x:1491,y:699,t:1527631846213};\\\", \\\"{x:1484,y:714,t:1527631846229};\\\", \\\"{x:1483,y:715,t:1527631847615};\\\", \\\"{x:1482,y:716,t:1527631847630};\\\", \\\"{x:1482,y:717,t:1527631847663};\\\", \\\"{x:1481,y:717,t:1527631847871};\\\", \\\"{x:1480,y:716,t:1527631847881};\\\", \\\"{x:1483,y:702,t:1527631847897};\\\", \\\"{x:1493,y:691,t:1527631847914};\\\", \\\"{x:1504,y:666,t:1527631847931};\\\", \\\"{x:1519,y:633,t:1527631847948};\\\", \\\"{x:1530,y:607,t:1527631847965};\\\", \\\"{x:1540,y:583,t:1527631847981};\\\", \\\"{x:1548,y:558,t:1527631847998};\\\", \\\"{x:1559,y:536,t:1527631848014};\\\", \\\"{x:1574,y:510,t:1527631848031};\\\", \\\"{x:1581,y:493,t:1527631848047};\\\", \\\"{x:1591,y:478,t:1527631848064};\\\", \\\"{x:1595,y:472,t:1527631848081};\\\", \\\"{x:1597,y:469,t:1527631848098};\\\", \\\"{x:1597,y:468,t:1527631848135};\\\", \\\"{x:1597,y:465,t:1527631848148};\\\", \\\"{x:1597,y:451,t:1527631848164};\\\", \\\"{x:1597,y:442,t:1527631848181};\\\", \\\"{x:1597,y:438,t:1527631848198};\\\", \\\"{x:1597,y:435,t:1527631848214};\\\", \\\"{x:1597,y:433,t:1527631848231};\\\", \\\"{x:1597,y:435,t:1527631848359};\\\", \\\"{x:1595,y:446,t:1527631848367};\\\", \\\"{x:1592,y:456,t:1527631848381};\\\", \\\"{x:1582,y:490,t:1527631848398};\\\", \\\"{x:1560,y:548,t:1527631848416};\\\", \\\"{x:1544,y:584,t:1527631848431};\\\", \\\"{x:1535,y:605,t:1527631848447};\\\", \\\"{x:1527,y:624,t:1527631848465};\\\", \\\"{x:1522,y:637,t:1527631848481};\\\", \\\"{x:1511,y:657,t:1527631848498};\\\", \\\"{x:1497,y:682,t:1527631848514};\\\", \\\"{x:1481,y:706,t:1527631848531};\\\", \\\"{x:1470,y:729,t:1527631848548};\\\", \\\"{x:1466,y:741,t:1527631848564};\\\", \\\"{x:1462,y:751,t:1527631848581};\\\", \\\"{x:1457,y:764,t:1527631848598};\\\", \\\"{x:1446,y:788,t:1527631848616};\\\", \\\"{x:1435,y:812,t:1527631848632};\\\", \\\"{x:1427,y:836,t:1527631848647};\\\", \\\"{x:1418,y:852,t:1527631848666};\\\", \\\"{x:1412,y:863,t:1527631848681};\\\", \\\"{x:1406,y:875,t:1527631848698};\\\", \\\"{x:1402,y:882,t:1527631848715};\\\", \\\"{x:1398,y:891,t:1527631848731};\\\", \\\"{x:1397,y:895,t:1527631848748};\\\", \\\"{x:1394,y:899,t:1527631848765};\\\", \\\"{x:1393,y:901,t:1527631848781};\\\", \\\"{x:1391,y:904,t:1527631848798};\\\", \\\"{x:1390,y:905,t:1527631848815};\\\", \\\"{x:1387,y:909,t:1527631848831};\\\", \\\"{x:1386,y:910,t:1527631848855};\\\", \\\"{x:1383,y:912,t:1527631848865};\\\", \\\"{x:1380,y:915,t:1527631848881};\\\", \\\"{x:1377,y:919,t:1527631848898};\\\", \\\"{x:1375,y:921,t:1527631848916};\\\", \\\"{x:1373,y:924,t:1527631848932};\\\", \\\"{x:1369,y:927,t:1527631848948};\\\", \\\"{x:1364,y:932,t:1527631848965};\\\", \\\"{x:1356,y:936,t:1527631848982};\\\", \\\"{x:1348,y:940,t:1527631848998};\\\", \\\"{x:1339,y:945,t:1527631849015};\\\", \\\"{x:1337,y:947,t:1527631849031};\\\", \\\"{x:1336,y:949,t:1527631849056};\\\", \\\"{x:1335,y:951,t:1527631849065};\\\", \\\"{x:1333,y:953,t:1527631849087};\\\", \\\"{x:1333,y:954,t:1527631849098};\\\", \\\"{x:1332,y:954,t:1527631849115};\\\", \\\"{x:1332,y:956,t:1527631849132};\\\", \\\"{x:1331,y:958,t:1527631849148};\\\", \\\"{x:1330,y:958,t:1527631849165};\\\", \\\"{x:1329,y:959,t:1527631849256};\\\", \\\"{x:1329,y:960,t:1527631850096};\\\", \\\"{x:1331,y:961,t:1527631850167};\\\", \\\"{x:1332,y:961,t:1527631850216};\\\", \\\"{x:1333,y:961,t:1527631850272};\\\", \\\"{x:1334,y:961,t:1527631850447};\\\", \\\"{x:1335,y:961,t:1527631850455};\\\", \\\"{x:1336,y:961,t:1527631850471};\\\", \\\"{x:1337,y:962,t:1527631850483};\\\", \\\"{x:1339,y:963,t:1527631850499};\\\", \\\"{x:1339,y:964,t:1527631850519};\\\", \\\"{x:1343,y:965,t:1527631850535};\\\", \\\"{x:1344,y:966,t:1527631850549};\\\", \\\"{x:1347,y:967,t:1527631850566};\\\", \\\"{x:1349,y:967,t:1527631850583};\\\", \\\"{x:1353,y:970,t:1527631850631};\\\", \\\"{x:1354,y:971,t:1527631850650};\\\", \\\"{x:1356,y:971,t:1527631850695};\\\", \\\"{x:1357,y:971,t:1527631850704};\\\", \\\"{x:1361,y:972,t:1527631850716};\\\", \\\"{x:1362,y:972,t:1527631850733};\\\", \\\"{x:1361,y:972,t:1527631852711};\\\", \\\"{x:1360,y:972,t:1527631852735};\\\", \\\"{x:1359,y:972,t:1527631852759};\\\", \\\"{x:1358,y:972,t:1527631853183};\\\", \\\"{x:1357,y:972,t:1527631853191};\\\", \\\"{x:1357,y:970,t:1527631853202};\\\", \\\"{x:1357,y:961,t:1527631853219};\\\", \\\"{x:1364,y:946,t:1527631853235};\\\", \\\"{x:1376,y:930,t:1527631853252};\\\", \\\"{x:1389,y:911,t:1527631853269};\\\", \\\"{x:1414,y:878,t:1527631853285};\\\", \\\"{x:1448,y:815,t:1527631853303};\\\", \\\"{x:1508,y:727,t:1527631853318};\\\", \\\"{x:1569,y:631,t:1527631853335};\\\", \\\"{x:1598,y:581,t:1527631853351};\\\", \\\"{x:1612,y:554,t:1527631853369};\\\", \\\"{x:1618,y:533,t:1527631853386};\\\", \\\"{x:1627,y:508,t:1527631853402};\\\", \\\"{x:1632,y:483,t:1527631853419};\\\", \\\"{x:1634,y:466,t:1527631853435};\\\", \\\"{x:1637,y:449,t:1527631853452};\\\", \\\"{x:1641,y:430,t:1527631853468};\\\", \\\"{x:1644,y:405,t:1527631853486};\\\", \\\"{x:1646,y:382,t:1527631853502};\\\", \\\"{x:1646,y:367,t:1527631853518};\\\", \\\"{x:1648,y:360,t:1527631853535};\\\", \\\"{x:1648,y:364,t:1527631853671};\\\", \\\"{x:1646,y:371,t:1527631853685};\\\", \\\"{x:1642,y:389,t:1527631853703};\\\", \\\"{x:1632,y:411,t:1527631853719};\\\", \\\"{x:1627,y:423,t:1527631853735};\\\", \\\"{x:1621,y:438,t:1527631853752};\\\", \\\"{x:1616,y:448,t:1527631853769};\\\", \\\"{x:1614,y:455,t:1527631853785};\\\", \\\"{x:1612,y:458,t:1527631853802};\\\", \\\"{x:1609,y:463,t:1527631853819};\\\", \\\"{x:1609,y:464,t:1527631853835};\\\", \\\"{x:1608,y:466,t:1527631853853};\\\", \\\"{x:1607,y:468,t:1527631853871};\\\", \\\"{x:1606,y:468,t:1527631853885};\\\", \\\"{x:1605,y:473,t:1527631853903};\\\", \\\"{x:1602,y:478,t:1527631853919};\\\", \\\"{x:1601,y:481,t:1527631853936};\\\", \\\"{x:1600,y:482,t:1527631853952};\\\", \\\"{x:1599,y:483,t:1527631853976};\\\", \\\"{x:1598,y:485,t:1527631853985};\\\", \\\"{x:1596,y:488,t:1527631854001};\\\", \\\"{x:1590,y:496,t:1527631854018};\\\", \\\"{x:1583,y:509,t:1527631854036};\\\", \\\"{x:1576,y:521,t:1527631854051};\\\", \\\"{x:1572,y:527,t:1527631854069};\\\", \\\"{x:1571,y:529,t:1527631854085};\\\", \\\"{x:1569,y:532,t:1527631854102};\\\", \\\"{x:1566,y:537,t:1527631854118};\\\", \\\"{x:1564,y:539,t:1527631854135};\\\", \\\"{x:1564,y:542,t:1527631854152};\\\", \\\"{x:1563,y:542,t:1527631854169};\\\", \\\"{x:1563,y:544,t:1527631854186};\\\", \\\"{x:1561,y:549,t:1527631854202};\\\", \\\"{x:1556,y:554,t:1527631854219};\\\", \\\"{x:1551,y:561,t:1527631854236};\\\", \\\"{x:1547,y:567,t:1527631854252};\\\", \\\"{x:1542,y:576,t:1527631854269};\\\", \\\"{x:1538,y:585,t:1527631854286};\\\", \\\"{x:1535,y:591,t:1527631854302};\\\", \\\"{x:1533,y:597,t:1527631854319};\\\", \\\"{x:1530,y:601,t:1527631854336};\\\", \\\"{x:1526,y:609,t:1527631854352};\\\", \\\"{x:1519,y:627,t:1527631854369};\\\", \\\"{x:1510,y:650,t:1527631854387};\\\", \\\"{x:1498,y:672,t:1527631854402};\\\", \\\"{x:1491,y:684,t:1527631854419};\\\", \\\"{x:1487,y:692,t:1527631854436};\\\", \\\"{x:1485,y:696,t:1527631854453};\\\", \\\"{x:1484,y:700,t:1527631854469};\\\", \\\"{x:1484,y:702,t:1527631854486};\\\", \\\"{x:1484,y:703,t:1527631854502};\\\", \\\"{x:1481,y:708,t:1527631854519};\\\", \\\"{x:1480,y:711,t:1527631854536};\\\", \\\"{x:1478,y:714,t:1527631854553};\\\", \\\"{x:1477,y:714,t:1527631854574};\\\", \\\"{x:1477,y:715,t:1527631854585};\\\", \\\"{x:1476,y:716,t:1527631854603};\\\", \\\"{x:1476,y:718,t:1527631854618};\\\", \\\"{x:1475,y:719,t:1527631854636};\\\", \\\"{x:1474,y:721,t:1527631854652};\\\", \\\"{x:1473,y:723,t:1527631854669};\\\", \\\"{x:1473,y:725,t:1527631854686};\\\", \\\"{x:1472,y:726,t:1527631854710};\\\", \\\"{x:1470,y:729,t:1527631854726};\\\", \\\"{x:1470,y:730,t:1527631854750};\\\", \\\"{x:1469,y:733,t:1527631854758};\\\", \\\"{x:1468,y:733,t:1527631854769};\\\", \\\"{x:1463,y:738,t:1527631854786};\\\", \\\"{x:1458,y:749,t:1527631854803};\\\", \\\"{x:1448,y:760,t:1527631854819};\\\", \\\"{x:1441,y:768,t:1527631854836};\\\", \\\"{x:1432,y:773,t:1527631854853};\\\", \\\"{x:1427,y:778,t:1527631854869};\\\", \\\"{x:1426,y:780,t:1527631854886};\\\", \\\"{x:1423,y:783,t:1527631854903};\\\", \\\"{x:1419,y:787,t:1527631854919};\\\", \\\"{x:1415,y:790,t:1527631854935};\\\", \\\"{x:1411,y:796,t:1527631854953};\\\", \\\"{x:1407,y:800,t:1527631854969};\\\", \\\"{x:1405,y:803,t:1527631854986};\\\", \\\"{x:1403,y:805,t:1527631855003};\\\", \\\"{x:1401,y:808,t:1527631855020};\\\", \\\"{x:1394,y:818,t:1527631855036};\\\", \\\"{x:1389,y:822,t:1527631855053};\\\", \\\"{x:1388,y:823,t:1527631855527};\\\", \\\"{x:1388,y:824,t:1527631855543};\\\", \\\"{x:1388,y:825,t:1527631855554};\\\", \\\"{x:1388,y:827,t:1527631855570};\\\", \\\"{x:1388,y:831,t:1527631855588};\\\", \\\"{x:1387,y:837,t:1527631855604};\\\", \\\"{x:1387,y:841,t:1527631855620};\\\", \\\"{x:1387,y:847,t:1527631855638};\\\", \\\"{x:1387,y:855,t:1527631855653};\\\", \\\"{x:1386,y:867,t:1527631855671};\\\", \\\"{x:1383,y:880,t:1527631855687};\\\", \\\"{x:1383,y:885,t:1527631855704};\\\", \\\"{x:1380,y:894,t:1527631855721};\\\", \\\"{x:1377,y:903,t:1527631855738};\\\", \\\"{x:1375,y:911,t:1527631855753};\\\", \\\"{x:1375,y:919,t:1527631855771};\\\", \\\"{x:1373,y:924,t:1527631855787};\\\", \\\"{x:1371,y:928,t:1527631855804};\\\", \\\"{x:1371,y:932,t:1527631855820};\\\", \\\"{x:1369,y:935,t:1527631855837};\\\", \\\"{x:1367,y:936,t:1527631855854};\\\", \\\"{x:1367,y:938,t:1527631855871};\\\", \\\"{x:1364,y:941,t:1527631855887};\\\", \\\"{x:1364,y:942,t:1527631855904};\\\", \\\"{x:1361,y:945,t:1527631855921};\\\", \\\"{x:1360,y:947,t:1527631855937};\\\", \\\"{x:1358,y:950,t:1527631855954};\\\", \\\"{x:1356,y:952,t:1527631855970};\\\", \\\"{x:1355,y:953,t:1527631855988};\\\", \\\"{x:1354,y:953,t:1527631856003};\\\", \\\"{x:1353,y:955,t:1527631856020};\\\", \\\"{x:1352,y:956,t:1527631856128};\\\", \\\"{x:1351,y:957,t:1527631856207};\\\", \\\"{x:1351,y:958,t:1527631856231};\\\", \\\"{x:1351,y:960,t:1527631856272};\\\", \\\"{x:1350,y:960,t:1527631856288};\\\", \\\"{x:1350,y:961,t:1527631856335};\\\", \\\"{x:1349,y:961,t:1527631856431};\\\", \\\"{x:1348,y:961,t:1527631856447};\\\", \\\"{x:1348,y:962,t:1527631856488};\\\", \\\"{x:1347,y:963,t:1527631856505};\\\", \\\"{x:1347,y:964,t:1527631856521};\\\", \\\"{x:1345,y:965,t:1527631856537};\\\", \\\"{x:1345,y:966,t:1527631856555};\\\", \\\"{x:1345,y:967,t:1527631856575};\\\", \\\"{x:1345,y:968,t:1527631856639};\\\", \\\"{x:1345,y:969,t:1527631856663};\\\", \\\"{x:1345,y:968,t:1527631857415};\\\", \\\"{x:1345,y:967,t:1527631857423};\\\", \\\"{x:1346,y:966,t:1527631857439};\\\", \\\"{x:1347,y:964,t:1527631857519};\\\", \\\"{x:1348,y:963,t:1527631857527};\\\", \\\"{x:1348,y:961,t:1527631857574};\\\", \\\"{x:1349,y:961,t:1527631857588};\\\", \\\"{x:1349,y:960,t:1527631857622};\\\", \\\"{x:1350,y:960,t:1527631857648};\\\", \\\"{x:1350,y:959,t:1527631857655};\\\", \\\"{x:1351,y:958,t:1527631857673};\\\", \\\"{x:1352,y:957,t:1527631857719};\\\", \\\"{x:1353,y:957,t:1527631857807};\\\", \\\"{x:1354,y:957,t:1527631857831};\\\", \\\"{x:1355,y:957,t:1527631857855};\\\", \\\"{x:1356,y:957,t:1527631857880};\\\", \\\"{x:1357,y:957,t:1527631857888};\\\", \\\"{x:1357,y:958,t:1527631857905};\\\", \\\"{x:1357,y:960,t:1527631857922};\\\", \\\"{x:1357,y:961,t:1527631857943};\\\", \\\"{x:1357,y:962,t:1527631857960};\\\", \\\"{x:1356,y:964,t:1527631857973};\\\", \\\"{x:1355,y:965,t:1527631858102};\\\", \\\"{x:1354,y:965,t:1527631858117};\\\", \\\"{x:1354,y:964,t:1527631858126};\\\", \\\"{x:1354,y:963,t:1527631858139};\\\", \\\"{x:1360,y:955,t:1527631858155};\\\", \\\"{x:1374,y:941,t:1527631858172};\\\", \\\"{x:1383,y:933,t:1527631858189};\\\", \\\"{x:1391,y:924,t:1527631858205};\\\", \\\"{x:1411,y:907,t:1527631858222};\\\", \\\"{x:1434,y:879,t:1527631858239};\\\", \\\"{x:1445,y:855,t:1527631858254};\\\", \\\"{x:1454,y:828,t:1527631858272};\\\", \\\"{x:1466,y:802,t:1527631858289};\\\", \\\"{x:1470,y:784,t:1527631858305};\\\", \\\"{x:1474,y:773,t:1527631858322};\\\", \\\"{x:1475,y:763,t:1527631858340};\\\", \\\"{x:1475,y:759,t:1527631858355};\\\", \\\"{x:1476,y:756,t:1527631858372};\\\", \\\"{x:1476,y:754,t:1527631858388};\\\", \\\"{x:1476,y:752,t:1527631858405};\\\", \\\"{x:1476,y:751,t:1527631858422};\\\", \\\"{x:1476,y:749,t:1527631858438};\\\", \\\"{x:1469,y:746,t:1527631858455};\\\", \\\"{x:1446,y:744,t:1527631858472};\\\", \\\"{x:1412,y:744,t:1527631858489};\\\", \\\"{x:1354,y:751,t:1527631858506};\\\", \\\"{x:1246,y:761,t:1527631858522};\\\", \\\"{x:1122,y:761,t:1527631858539};\\\", \\\"{x:997,y:761,t:1527631858556};\\\", \\\"{x:875,y:761,t:1527631858573};\\\", \\\"{x:777,y:758,t:1527631858589};\\\", \\\"{x:704,y:746,t:1527631858606};\\\", \\\"{x:665,y:735,t:1527631858622};\\\", \\\"{x:645,y:727,t:1527631858639};\\\", \\\"{x:634,y:721,t:1527631858656};\\\", \\\"{x:621,y:712,t:1527631858672};\\\", \\\"{x:602,y:698,t:1527631858689};\\\", \\\"{x:582,y:686,t:1527631858706};\\\", \\\"{x:563,y:673,t:1527631858723};\\\", \\\"{x:538,y:667,t:1527631858740};\\\", \\\"{x:518,y:658,t:1527631858756};\\\", \\\"{x:502,y:646,t:1527631858773};\\\", \\\"{x:488,y:634,t:1527631858789};\\\", \\\"{x:475,y:624,t:1527631858806};\\\", \\\"{x:467,y:612,t:1527631858822};\\\", \\\"{x:456,y:597,t:1527631858839};\\\", \\\"{x:450,y:589,t:1527631858855};\\\", \\\"{x:442,y:581,t:1527631858872};\\\", \\\"{x:434,y:571,t:1527631858890};\\\", \\\"{x:424,y:560,t:1527631858906};\\\", \\\"{x:416,y:552,t:1527631858922};\\\", \\\"{x:411,y:549,t:1527631858938};\\\", \\\"{x:407,y:549,t:1527631859047};\\\", \\\"{x:401,y:550,t:1527631859056};\\\", \\\"{x:382,y:555,t:1527631859074};\\\", \\\"{x:367,y:556,t:1527631859090};\\\", \\\"{x:342,y:561,t:1527631859106};\\\", \\\"{x:323,y:564,t:1527631859122};\\\", \\\"{x:310,y:567,t:1527631859139};\\\", \\\"{x:304,y:571,t:1527631859156};\\\", \\\"{x:300,y:574,t:1527631859172};\\\", \\\"{x:299,y:579,t:1527631859189};\\\", \\\"{x:298,y:583,t:1527631859206};\\\", \\\"{x:298,y:591,t:1527631859222};\\\", \\\"{x:301,y:596,t:1527631859238};\\\", \\\"{x:305,y:600,t:1527631859256};\\\", \\\"{x:310,y:603,t:1527631859272};\\\", \\\"{x:313,y:604,t:1527631859289};\\\", \\\"{x:315,y:605,t:1527631859305};\\\", \\\"{x:320,y:607,t:1527631859323};\\\", \\\"{x:327,y:607,t:1527631859339};\\\", \\\"{x:336,y:607,t:1527631859356};\\\", \\\"{x:340,y:608,t:1527631859373};\\\", \\\"{x:345,y:609,t:1527631859389};\\\", \\\"{x:347,y:609,t:1527631859407};\\\", \\\"{x:351,y:608,t:1527631859422};\\\", \\\"{x:353,y:608,t:1527631859446};\\\", \\\"{x:354,y:608,t:1527631859463};\\\", \\\"{x:357,y:607,t:1527631859473};\\\", \\\"{x:358,y:606,t:1527631859489};\\\", \\\"{x:359,y:606,t:1527631859506};\\\", \\\"{x:365,y:604,t:1527631859523};\\\", \\\"{x:372,y:602,t:1527631859540};\\\", \\\"{x:376,y:601,t:1527631859556};\\\", \\\"{x:381,y:600,t:1527631859573};\\\", \\\"{x:384,y:599,t:1527631859590};\\\", \\\"{x:387,y:599,t:1527631859606};\\\", \\\"{x:388,y:599,t:1527631859646};\\\", \\\"{x:390,y:597,t:1527631859656};\\\", \\\"{x:395,y:597,t:1527631860056};\\\", \\\"{x:399,y:597,t:1527631860063};\\\", \\\"{x:411,y:600,t:1527631860073};\\\", \\\"{x:440,y:611,t:1527631860090};\\\", \\\"{x:474,y:615,t:1527631860108};\\\", \\\"{x:517,y:615,t:1527631860123};\\\", \\\"{x:598,y:617,t:1527631860140};\\\", \\\"{x:693,y:617,t:1527631860156};\\\", \\\"{x:804,y:617,t:1527631860173};\\\", \\\"{x:912,y:617,t:1527631860190};\\\", \\\"{x:1031,y:617,t:1527631860207};\\\", \\\"{x:1175,y:617,t:1527631860222};\\\", \\\"{x:1256,y:617,t:1527631860240};\\\", \\\"{x:1298,y:617,t:1527631860256};\\\", \\\"{x:1327,y:617,t:1527631860273};\\\", \\\"{x:1338,y:617,t:1527631860291};\\\", \\\"{x:1339,y:617,t:1527631860306};\\\", \\\"{x:1347,y:617,t:1527631860607};\\\", \\\"{x:1399,y:617,t:1527631860624};\\\", \\\"{x:1452,y:617,t:1527631860640};\\\", \\\"{x:1512,y:616,t:1527631860657};\\\", \\\"{x:1560,y:609,t:1527631860674};\\\", \\\"{x:1588,y:602,t:1527631860691};\\\", \\\"{x:1600,y:591,t:1527631860707};\\\", \\\"{x:1607,y:581,t:1527631860724};\\\", \\\"{x:1612,y:566,t:1527631860741};\\\", \\\"{x:1615,y:554,t:1527631860757};\\\", \\\"{x:1615,y:548,t:1527631860774};\\\", \\\"{x:1615,y:543,t:1527631860791};\\\", \\\"{x:1615,y:533,t:1527631860807};\\\", \\\"{x:1615,y:523,t:1527631860823};\\\", \\\"{x:1615,y:516,t:1527631860840};\\\", \\\"{x:1615,y:511,t:1527631860857};\\\", \\\"{x:1615,y:509,t:1527631860874};\\\", \\\"{x:1615,y:508,t:1527631860895};\\\", \\\"{x:1609,y:515,t:1527631861000};\\\", \\\"{x:1601,y:532,t:1527631861007};\\\", \\\"{x:1579,y:570,t:1527631861023};\\\", \\\"{x:1555,y:600,t:1527631861041};\\\", \\\"{x:1536,y:622,t:1527631861058};\\\", \\\"{x:1518,y:637,t:1527631861074};\\\", \\\"{x:1504,y:649,t:1527631861091};\\\", \\\"{x:1499,y:653,t:1527631861108};\\\", \\\"{x:1494,y:659,t:1527631861124};\\\", \\\"{x:1490,y:664,t:1527631861140};\\\", \\\"{x:1486,y:668,t:1527631861158};\\\", \\\"{x:1482,y:673,t:1527631861174};\\\", \\\"{x:1478,y:678,t:1527631861189};\\\", \\\"{x:1474,y:683,t:1527631861207};\\\", \\\"{x:1471,y:688,t:1527631861223};\\\", \\\"{x:1469,y:692,t:1527631861240};\\\", \\\"{x:1464,y:699,t:1527631861257};\\\", \\\"{x:1459,y:705,t:1527631861273};\\\", \\\"{x:1453,y:719,t:1527631861290};\\\", \\\"{x:1448,y:731,t:1527631861307};\\\", \\\"{x:1443,y:744,t:1527631861323};\\\", \\\"{x:1437,y:756,t:1527631861340};\\\", \\\"{x:1431,y:773,t:1527631861357};\\\", \\\"{x:1423,y:788,t:1527631861373};\\\", \\\"{x:1417,y:802,t:1527631861390};\\\", \\\"{x:1403,y:827,t:1527631861406};\\\", \\\"{x:1397,y:841,t:1527631861424};\\\", \\\"{x:1387,y:856,t:1527631861440};\\\", \\\"{x:1382,y:864,t:1527631861458};\\\", \\\"{x:1380,y:869,t:1527631861473};\\\", \\\"{x:1378,y:871,t:1527631861490};\\\", \\\"{x:1376,y:874,t:1527631861507};\\\", \\\"{x:1374,y:880,t:1527631861523};\\\", \\\"{x:1371,y:886,t:1527631861541};\\\", \\\"{x:1369,y:890,t:1527631861558};\\\", \\\"{x:1369,y:892,t:1527631861574};\\\", \\\"{x:1367,y:894,t:1527631861591};\\\", \\\"{x:1363,y:899,t:1527631861607};\\\", \\\"{x:1361,y:904,t:1527631861624};\\\", \\\"{x:1359,y:907,t:1527631861641};\\\", \\\"{x:1358,y:909,t:1527631861657};\\\", \\\"{x:1357,y:910,t:1527631861679};\\\", \\\"{x:1357,y:911,t:1527631861691};\\\", \\\"{x:1356,y:914,t:1527631861708};\\\", \\\"{x:1355,y:916,t:1527631861724};\\\", \\\"{x:1354,y:919,t:1527631861740};\\\", \\\"{x:1353,y:920,t:1527631861758};\\\", \\\"{x:1353,y:921,t:1527631861773};\\\", \\\"{x:1352,y:923,t:1527631861790};\\\", \\\"{x:1349,y:929,t:1527631861806};\\\", \\\"{x:1349,y:930,t:1527631861823};\\\", \\\"{x:1347,y:934,t:1527631861840};\\\", \\\"{x:1347,y:935,t:1527631861857};\\\", \\\"{x:1346,y:937,t:1527631861878};\\\", \\\"{x:1346,y:939,t:1527631861903};\\\", \\\"{x:1345,y:940,t:1527631861910};\\\", \\\"{x:1345,y:941,t:1527631861923};\\\", \\\"{x:1345,y:943,t:1527631861940};\\\", \\\"{x:1343,y:946,t:1527631861957};\\\", \\\"{x:1343,y:948,t:1527631861973};\\\", \\\"{x:1343,y:949,t:1527631861990};\\\", \\\"{x:1342,y:950,t:1527631862023};\\\", \\\"{x:1343,y:949,t:1527631862487};\\\", \\\"{x:1346,y:946,t:1527631862519};\\\", \\\"{x:1347,y:945,t:1527631862535};\\\", \\\"{x:1349,y:943,t:1527631862552};\\\", \\\"{x:1352,y:942,t:1527631862567};\\\", \\\"{x:1353,y:941,t:1527631862575};\\\", \\\"{x:1360,y:935,t:1527631862591};\\\", \\\"{x:1366,y:929,t:1527631862607};\\\", \\\"{x:1378,y:917,t:1527631862624};\\\", \\\"{x:1395,y:899,t:1527631862641};\\\", \\\"{x:1406,y:886,t:1527631862657};\\\", \\\"{x:1421,y:872,t:1527631862674};\\\", \\\"{x:1431,y:859,t:1527631862691};\\\", \\\"{x:1440,y:848,t:1527631862708};\\\", \\\"{x:1451,y:829,t:1527631862723};\\\", \\\"{x:1457,y:819,t:1527631862741};\\\", \\\"{x:1465,y:809,t:1527631862758};\\\", \\\"{x:1472,y:799,t:1527631862774};\\\", \\\"{x:1478,y:784,t:1527631862791};\\\", \\\"{x:1485,y:770,t:1527631862807};\\\", \\\"{x:1489,y:761,t:1527631862823};\\\", \\\"{x:1495,y:740,t:1527631862841};\\\", \\\"{x:1500,y:726,t:1527631862858};\\\", \\\"{x:1500,y:719,t:1527631862874};\\\", \\\"{x:1500,y:713,t:1527631862891};\\\", \\\"{x:1500,y:705,t:1527631862908};\\\", \\\"{x:1501,y:702,t:1527631862923};\\\", \\\"{x:1501,y:701,t:1527631862941};\\\", \\\"{x:1502,y:699,t:1527631862958};\\\", \\\"{x:1503,y:697,t:1527631862973};\\\", \\\"{x:1505,y:690,t:1527631862991};\\\", \\\"{x:1507,y:672,t:1527631863007};\\\", \\\"{x:1511,y:657,t:1527631863024};\\\", \\\"{x:1515,y:648,t:1527631863041};\\\", \\\"{x:1515,y:646,t:1527631863057};\\\", \\\"{x:1515,y:645,t:1527631863078};\\\", \\\"{x:1515,y:644,t:1527631863090};\\\", \\\"{x:1516,y:643,t:1527631863107};\\\", \\\"{x:1517,y:643,t:1527631863126};\\\", \\\"{x:1517,y:642,t:1527631863140};\\\", \\\"{x:1517,y:641,t:1527631863157};\\\", \\\"{x:1517,y:640,t:1527631863174};\\\", \\\"{x:1518,y:640,t:1527631864424};\\\", \\\"{x:1523,y:638,t:1527631864441};\\\", \\\"{x:1530,y:632,t:1527631864458};\\\", \\\"{x:1538,y:624,t:1527631864475};\\\", \\\"{x:1547,y:618,t:1527631864491};\\\", \\\"{x:1551,y:613,t:1527631864508};\\\", \\\"{x:1555,y:610,t:1527631864525};\\\", \\\"{x:1557,y:609,t:1527631864541};\\\", \\\"{x:1558,y:608,t:1527631864557};\\\", \\\"{x:1560,y:606,t:1527631864575};\\\", \\\"{x:1560,y:605,t:1527631864590};\\\", \\\"{x:1561,y:604,t:1527631864623};\\\", \\\"{x:1558,y:604,t:1527631864904};\\\", \\\"{x:1557,y:604,t:1527631864911};\\\", \\\"{x:1556,y:604,t:1527631864928};\\\", \\\"{x:1556,y:605,t:1527631864940};\\\", \\\"{x:1555,y:605,t:1527631864983};\\\", \\\"{x:1554,y:606,t:1527631864991};\\\", \\\"{x:1554,y:607,t:1527631865007};\\\", \\\"{x:1553,y:608,t:1527631865024};\\\", \\\"{x:1552,y:609,t:1527631865040};\\\", \\\"{x:1551,y:610,t:1527631865057};\\\", \\\"{x:1551,y:612,t:1527631865078};\\\", \\\"{x:1550,y:613,t:1527631865126};\\\", \\\"{x:1549,y:613,t:1527631865140};\\\", \\\"{x:1548,y:616,t:1527631865159};\\\", \\\"{x:1547,y:617,t:1527631865175};\\\", \\\"{x:1546,y:617,t:1527631865190};\\\", \\\"{x:1546,y:619,t:1527631865208};\\\", \\\"{x:1545,y:619,t:1527631865224};\\\", \\\"{x:1545,y:620,t:1527631865241};\\\", \\\"{x:1545,y:622,t:1527631865258};\\\", \\\"{x:1543,y:624,t:1527631865275};\\\", \\\"{x:1542,y:625,t:1527631865292};\\\", \\\"{x:1541,y:627,t:1527631865307};\\\", \\\"{x:1539,y:629,t:1527631865324};\\\", \\\"{x:1539,y:631,t:1527631865341};\\\", \\\"{x:1538,y:633,t:1527631865358};\\\", \\\"{x:1534,y:639,t:1527631865375};\\\", \\\"{x:1530,y:644,t:1527631865391};\\\", \\\"{x:1528,y:651,t:1527631865407};\\\", \\\"{x:1525,y:656,t:1527631865424};\\\", \\\"{x:1523,y:660,t:1527631865441};\\\", \\\"{x:1522,y:662,t:1527631865457};\\\", \\\"{x:1519,y:670,t:1527631865475};\\\", \\\"{x:1515,y:679,t:1527631865491};\\\", \\\"{x:1514,y:689,t:1527631865508};\\\", \\\"{x:1511,y:698,t:1527631865525};\\\", \\\"{x:1509,y:703,t:1527631865541};\\\", \\\"{x:1507,y:708,t:1527631865558};\\\", \\\"{x:1505,y:712,t:1527631865575};\\\", \\\"{x:1504,y:716,t:1527631865591};\\\", \\\"{x:1502,y:722,t:1527631865607};\\\", \\\"{x:1498,y:731,t:1527631865625};\\\", \\\"{x:1495,y:740,t:1527631865642};\\\", \\\"{x:1488,y:755,t:1527631865658};\\\", \\\"{x:1484,y:766,t:1527631865675};\\\", \\\"{x:1482,y:770,t:1527631865692};\\\", \\\"{x:1480,y:774,t:1527631865708};\\\", \\\"{x:1478,y:778,t:1527631865725};\\\", \\\"{x:1477,y:782,t:1527631865742};\\\", \\\"{x:1475,y:785,t:1527631865757};\\\", \\\"{x:1472,y:791,t:1527631865775};\\\", \\\"{x:1471,y:793,t:1527631865791};\\\", \\\"{x:1469,y:797,t:1527631865807};\\\", \\\"{x:1468,y:798,t:1527631865825};\\\", \\\"{x:1467,y:800,t:1527631865842};\\\", \\\"{x:1466,y:800,t:1527631865871};\\\", \\\"{x:1466,y:801,t:1527631865880};\\\", \\\"{x:1465,y:802,t:1527631865919};\\\", \\\"{x:1465,y:803,t:1527631865927};\\\", \\\"{x:1463,y:804,t:1527631865959};\\\", \\\"{x:1463,y:805,t:1527631865975};\\\", \\\"{x:1451,y:806,t:1527631865991};\\\", \\\"{x:1433,y:808,t:1527631866007};\\\", \\\"{x:1401,y:808,t:1527631866024};\\\", \\\"{x:1358,y:808,t:1527631866041};\\\", \\\"{x:1292,y:806,t:1527631866058};\\\", \\\"{x:1209,y:795,t:1527631866074};\\\", \\\"{x:1106,y:779,t:1527631866091};\\\", \\\"{x:1002,y:769,t:1527631866108};\\\", \\\"{x:899,y:767,t:1527631866125};\\\", \\\"{x:804,y:766,t:1527631866142};\\\", \\\"{x:710,y:766,t:1527631866157};\\\", \\\"{x:629,y:769,t:1527631866175};\\\", \\\"{x:606,y:775,t:1527631866190};\\\", \\\"{x:590,y:780,t:1527631866208};\\\", \\\"{x:580,y:784,t:1527631866225};\\\", \\\"{x:572,y:786,t:1527631866241};\\\", \\\"{x:564,y:787,t:1527631866258};\\\", \\\"{x:561,y:787,t:1527631866274};\\\", \\\"{x:553,y:787,t:1527631866292};\\\", \\\"{x:542,y:787,t:1527631866307};\\\", \\\"{x:530,y:787,t:1527631866325};\\\", \\\"{x:513,y:787,t:1527631866342};\\\", \\\"{x:499,y:784,t:1527631866358};\\\", \\\"{x:497,y:783,t:1527631866374};\\\", \\\"{x:497,y:777,t:1527631866391};\\\", \\\"{x:505,y:765,t:1527631866407};\\\", \\\"{x:510,y:757,t:1527631866424};\\\", \\\"{x:514,y:753,t:1527631866441};\\\", \\\"{x:514,y:751,t:1527631866457};\\\", \\\"{x:514,y:750,t:1527631866528};\\\", \\\"{x:515,y:750,t:1527631866541};\\\", \\\"{x:516,y:746,t:1527631866558};\\\", \\\"{x:517,y:743,t:1527631866575};\\\", \\\"{x:517,y:740,t:1527631866591};\\\", \\\"{x:518,y:737,t:1527631866608};\\\", \\\"{x:521,y:729,t:1527631866626};\\\", \\\"{x:521,y:728,t:1527631866641};\\\", \\\"{x:522,y:726,t:1527631866657};\\\", \\\"{x:522,y:725,t:1527631866678};\\\", \\\"{x:521,y:725,t:1527631872934};\\\", \\\"{x:518,y:725,t:1527631872950};\\\" ] }, { \\\"rt\\\": 16939, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 489460, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-F -11 AM-12 PM-02 PM-F -11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:460,y:672,t:1527631873591};\\\", \\\"{x:450,y:666,t:1527631873601};\\\", \\\"{x:413,y:651,t:1527631873617};\\\", \\\"{x:373,y:632,t:1527631873636};\\\", \\\"{x:330,y:615,t:1527631873650};\\\", \\\"{x:232,y:579,t:1527631873679};\\\", \\\"{x:178,y:546,t:1527631873763};\\\", \\\"{x:178,y:545,t:1527631873781};\\\", \\\"{x:184,y:542,t:1527631874111};\\\", \\\"{x:196,y:534,t:1527631874119};\\\", \\\"{x:242,y:511,t:1527631874134};\\\", \\\"{x:317,y:474,t:1527631874151};\\\", \\\"{x:403,y:437,t:1527631874168};\\\", \\\"{x:519,y:386,t:1527631874185};\\\", \\\"{x:630,y:332,t:1527631874201};\\\", \\\"{x:729,y:289,t:1527631874217};\\\", \\\"{x:791,y:266,t:1527631874234};\\\", \\\"{x:820,y:257,t:1527631874252};\\\", \\\"{x:825,y:254,t:1527631874268};\\\", \\\"{x:826,y:253,t:1527631874285};\\\", \\\"{x:825,y:254,t:1527631874391};\\\", \\\"{x:820,y:256,t:1527631874402};\\\", \\\"{x:815,y:259,t:1527631874419};\\\", \\\"{x:811,y:262,t:1527631874434};\\\", \\\"{x:810,y:262,t:1527631874452};\\\", \\\"{x:807,y:263,t:1527631874469};\\\", \\\"{x:804,y:266,t:1527631874486};\\\", \\\"{x:797,y:270,t:1527631874503};\\\", \\\"{x:794,y:271,t:1527631874519};\\\", \\\"{x:789,y:273,t:1527631874535};\\\", \\\"{x:788,y:273,t:1527631874552};\\\", \\\"{x:786,y:275,t:1527631874569};\\\", \\\"{x:785,y:275,t:1527631874591};\\\", \\\"{x:784,y:275,t:1527631874615};\\\", \\\"{x:784,y:276,t:1527631874655};\\\", \\\"{x:788,y:278,t:1527631874919};\\\", \\\"{x:797,y:282,t:1527631874935};\\\", \\\"{x:803,y:284,t:1527631874953};\\\", \\\"{x:806,y:286,t:1527631874970};\\\", \\\"{x:809,y:286,t:1527631874987};\\\", \\\"{x:811,y:286,t:1527631875003};\\\", \\\"{x:811,y:284,t:1527631875019};\\\", \\\"{x:811,y:285,t:1527631875344};\\\", \\\"{x:814,y:288,t:1527631875354};\\\", \\\"{x:832,y:303,t:1527631875371};\\\", \\\"{x:861,y:330,t:1527631875386};\\\", \\\"{x:907,y:357,t:1527631875404};\\\", \\\"{x:968,y:396,t:1527631875421};\\\", \\\"{x:1038,y:433,t:1527631875437};\\\", \\\"{x:1121,y:482,t:1527631875454};\\\", \\\"{x:1259,y:571,t:1527631875471};\\\", \\\"{x:1343,y:655,t:1527631875488};\\\", \\\"{x:1375,y:707,t:1527631875504};\\\", \\\"{x:1395,y:752,t:1527631875521};\\\", \\\"{x:1405,y:793,t:1527631875538};\\\", \\\"{x:1407,y:825,t:1527631875554};\\\", \\\"{x:1407,y:854,t:1527631875571};\\\", \\\"{x:1403,y:881,t:1527631875589};\\\", \\\"{x:1398,y:905,t:1527631875605};\\\", \\\"{x:1398,y:924,t:1527631875621};\\\", \\\"{x:1398,y:935,t:1527631875638};\\\", \\\"{x:1398,y:941,t:1527631875654};\\\", \\\"{x:1398,y:944,t:1527631875671};\\\", \\\"{x:1398,y:948,t:1527631875688};\\\", \\\"{x:1397,y:952,t:1527631875705};\\\", \\\"{x:1390,y:956,t:1527631875721};\\\", \\\"{x:1388,y:956,t:1527631875738};\\\", \\\"{x:1387,y:956,t:1527631875998};\\\", \\\"{x:1391,y:951,t:1527631876062};\\\", \\\"{x:1393,y:945,t:1527631876072};\\\", \\\"{x:1394,y:945,t:1527631876089};\\\", \\\"{x:1402,y:930,t:1527631876106};\\\", \\\"{x:1421,y:902,t:1527631876121};\\\", \\\"{x:1438,y:879,t:1527631876139};\\\", \\\"{x:1448,y:860,t:1527631876156};\\\", \\\"{x:1456,y:840,t:1527631876172};\\\", \\\"{x:1460,y:826,t:1527631876189};\\\", \\\"{x:1461,y:814,t:1527631876206};\\\", \\\"{x:1462,y:798,t:1527631876222};\\\", \\\"{x:1459,y:778,t:1527631876239};\\\", \\\"{x:1454,y:769,t:1527631876256};\\\", \\\"{x:1445,y:762,t:1527631876273};\\\", \\\"{x:1443,y:759,t:1527631876291};\\\", \\\"{x:1442,y:758,t:1527631876306};\\\", \\\"{x:1441,y:757,t:1527631876323};\\\", \\\"{x:1441,y:755,t:1527631876415};\\\", \\\"{x:1451,y:755,t:1527631876942};\\\", \\\"{x:1464,y:756,t:1527631876957};\\\", \\\"{x:1488,y:760,t:1527631876974};\\\", \\\"{x:1521,y:767,t:1527631876990};\\\", \\\"{x:1537,y:773,t:1527631877006};\\\", \\\"{x:1543,y:775,t:1527631877023};\\\", \\\"{x:1544,y:776,t:1527631877040};\\\", \\\"{x:1546,y:776,t:1527631877110};\\\", \\\"{x:1548,y:776,t:1527631877123};\\\", \\\"{x:1550,y:776,t:1527631877140};\\\", \\\"{x:1551,y:776,t:1527631877230};\\\", \\\"{x:1553,y:776,t:1527631877326};\\\", \\\"{x:1554,y:776,t:1527631877414};\\\", \\\"{x:1554,y:777,t:1527631877424};\\\", \\\"{x:1554,y:778,t:1527631877442};\\\", \\\"{x:1554,y:779,t:1527631877458};\\\", \\\"{x:1554,y:780,t:1527631877486};\\\", \\\"{x:1553,y:780,t:1527631877502};\\\", \\\"{x:1552,y:782,t:1527631877510};\\\", \\\"{x:1550,y:782,t:1527631877526};\\\", \\\"{x:1548,y:783,t:1527631877550};\\\", \\\"{x:1546,y:785,t:1527631877566};\\\", \\\"{x:1544,y:785,t:1527631877575};\\\", \\\"{x:1540,y:786,t:1527631877592};\\\", \\\"{x:1535,y:786,t:1527631877608};\\\", \\\"{x:1525,y:789,t:1527631877625};\\\", \\\"{x:1514,y:789,t:1527631877642};\\\", \\\"{x:1496,y:790,t:1527631877659};\\\", \\\"{x:1481,y:790,t:1527631877675};\\\", \\\"{x:1465,y:790,t:1527631877692};\\\", \\\"{x:1457,y:790,t:1527631877709};\\\", \\\"{x:1445,y:790,t:1527631877726};\\\", \\\"{x:1436,y:790,t:1527631877741};\\\", \\\"{x:1424,y:790,t:1527631877758};\\\", \\\"{x:1411,y:790,t:1527631877776};\\\", \\\"{x:1404,y:791,t:1527631877792};\\\", \\\"{x:1396,y:792,t:1527631877809};\\\", \\\"{x:1392,y:794,t:1527631877826};\\\", \\\"{x:1386,y:795,t:1527631877842};\\\", \\\"{x:1381,y:795,t:1527631877858};\\\", \\\"{x:1377,y:798,t:1527631877876};\\\", \\\"{x:1370,y:799,t:1527631877893};\\\", \\\"{x:1365,y:803,t:1527631877908};\\\", \\\"{x:1357,y:806,t:1527631877926};\\\", \\\"{x:1352,y:808,t:1527631877943};\\\", \\\"{x:1350,y:810,t:1527631877959};\\\", \\\"{x:1347,y:811,t:1527631877976};\\\", \\\"{x:1343,y:815,t:1527631877993};\\\", \\\"{x:1338,y:819,t:1527631878009};\\\", \\\"{x:1331,y:822,t:1527631878026};\\\", \\\"{x:1323,y:828,t:1527631878042};\\\", \\\"{x:1312,y:833,t:1527631878060};\\\", \\\"{x:1302,y:837,t:1527631878076};\\\", \\\"{x:1291,y:839,t:1527631878093};\\\", \\\"{x:1277,y:841,t:1527631878109};\\\", \\\"{x:1273,y:841,t:1527631878126};\\\", \\\"{x:1262,y:844,t:1527631878143};\\\", \\\"{x:1254,y:845,t:1527631878160};\\\", \\\"{x:1248,y:848,t:1527631878176};\\\", \\\"{x:1236,y:849,t:1527631878193};\\\", \\\"{x:1225,y:850,t:1527631878210};\\\", \\\"{x:1216,y:851,t:1527631878227};\\\", \\\"{x:1209,y:853,t:1527631878243};\\\", \\\"{x:1208,y:853,t:1527631878260};\\\", \\\"{x:1207,y:854,t:1527631878278};\\\", \\\"{x:1207,y:853,t:1527631878511};\\\", \\\"{x:1207,y:851,t:1527631878527};\\\", \\\"{x:1207,y:850,t:1527631878550};\\\", \\\"{x:1207,y:848,t:1527631878575};\\\", \\\"{x:1207,y:847,t:1527631878590};\\\", \\\"{x:1208,y:844,t:1527631878598};\\\", \\\"{x:1208,y:843,t:1527631878611};\\\", \\\"{x:1208,y:841,t:1527631878627};\\\", \\\"{x:1209,y:840,t:1527631878644};\\\", \\\"{x:1209,y:839,t:1527631878687};\\\", \\\"{x:1209,y:838,t:1527631878926};\\\", \\\"{x:1209,y:841,t:1527631879655};\\\", \\\"{x:1208,y:842,t:1527631879662};\\\", \\\"{x:1207,y:847,t:1527631879680};\\\", \\\"{x:1204,y:852,t:1527631879696};\\\", \\\"{x:1201,y:859,t:1527631879713};\\\", \\\"{x:1201,y:864,t:1527631879729};\\\", \\\"{x:1200,y:867,t:1527631879746};\\\", \\\"{x:1198,y:870,t:1527631879762};\\\", \\\"{x:1197,y:873,t:1527631879779};\\\", \\\"{x:1196,y:879,t:1527631879797};\\\", \\\"{x:1191,y:887,t:1527631879813};\\\", \\\"{x:1184,y:897,t:1527631879829};\\\", \\\"{x:1179,y:904,t:1527631879846};\\\", \\\"{x:1177,y:909,t:1527631879862};\\\", \\\"{x:1174,y:917,t:1527631879879};\\\", \\\"{x:1171,y:923,t:1527631879897};\\\", \\\"{x:1170,y:926,t:1527631879913};\\\", \\\"{x:1167,y:931,t:1527631879930};\\\", \\\"{x:1164,y:935,t:1527631879947};\\\", \\\"{x:1160,y:941,t:1527631879964};\\\", \\\"{x:1158,y:944,t:1527631879980};\\\", \\\"{x:1153,y:950,t:1527631879997};\\\", \\\"{x:1150,y:954,t:1527631880014};\\\", \\\"{x:1148,y:958,t:1527631880030};\\\", \\\"{x:1147,y:959,t:1527631880047};\\\", \\\"{x:1148,y:959,t:1527631880135};\\\", \\\"{x:1153,y:959,t:1527631880147};\\\", \\\"{x:1160,y:959,t:1527631880164};\\\", \\\"{x:1168,y:959,t:1527631880181};\\\", \\\"{x:1174,y:959,t:1527631880197};\\\", \\\"{x:1179,y:959,t:1527631880214};\\\", \\\"{x:1181,y:959,t:1527631880238};\\\", \\\"{x:1183,y:959,t:1527631880249};\\\", \\\"{x:1187,y:960,t:1527631880264};\\\", \\\"{x:1193,y:960,t:1527631880281};\\\", \\\"{x:1204,y:961,t:1527631880298};\\\", \\\"{x:1213,y:962,t:1527631880314};\\\", \\\"{x:1221,y:963,t:1527631880332};\\\", \\\"{x:1229,y:964,t:1527631880348};\\\", \\\"{x:1234,y:965,t:1527631880365};\\\", \\\"{x:1238,y:965,t:1527631880384};\\\", \\\"{x:1241,y:967,t:1527631880402};\\\", \\\"{x:1246,y:967,t:1527631880418};\\\", \\\"{x:1250,y:969,t:1527631880435};\\\", \\\"{x:1255,y:969,t:1527631880452};\\\", \\\"{x:1263,y:971,t:1527631880469};\\\", \\\"{x:1266,y:972,t:1527631880485};\\\", \\\"{x:1267,y:973,t:1527631880501};\\\", \\\"{x:1269,y:973,t:1527631880519};\\\", \\\"{x:1270,y:973,t:1527631880587};\\\", \\\"{x:1271,y:974,t:1527631880626};\\\", \\\"{x:1272,y:974,t:1527631880667};\\\", \\\"{x:1273,y:975,t:1527631880674};\\\", \\\"{x:1276,y:977,t:1527631880685};\\\", \\\"{x:1281,y:979,t:1527631880702};\\\", \\\"{x:1286,y:981,t:1527631880719};\\\", \\\"{x:1289,y:982,t:1527631880735};\\\", \\\"{x:1291,y:983,t:1527631880752};\\\", \\\"{x:1291,y:981,t:1527631880987};\\\", \\\"{x:1286,y:972,t:1527631881003};\\\", \\\"{x:1283,y:966,t:1527631881021};\\\", \\\"{x:1282,y:966,t:1527631881050};\\\", \\\"{x:1282,y:965,t:1527631881074};\\\", \\\"{x:1284,y:964,t:1527631881683};\\\", \\\"{x:1286,y:961,t:1527631881690};\\\", \\\"{x:1287,y:960,t:1527631881704};\\\", \\\"{x:1289,y:957,t:1527631881721};\\\", \\\"{x:1292,y:953,t:1527631881738};\\\", \\\"{x:1294,y:950,t:1527631881754};\\\", \\\"{x:1295,y:950,t:1527631881811};\\\", \\\"{x:1295,y:949,t:1527631881939};\\\", \\\"{x:1295,y:947,t:1527631881955};\\\", \\\"{x:1295,y:946,t:1527631881972};\\\", \\\"{x:1297,y:945,t:1527631881988};\\\", \\\"{x:1297,y:944,t:1527631882018};\\\", \\\"{x:1297,y:943,t:1527631882059};\\\", \\\"{x:1297,y:942,t:1527631882074};\\\", \\\"{x:1298,y:942,t:1527631882090};\\\", \\\"{x:1298,y:941,t:1527631882115};\\\", \\\"{x:1298,y:940,t:1527631882122};\\\", \\\"{x:1298,y:938,t:1527631882138};\\\", \\\"{x:1299,y:938,t:1527631882155};\\\", \\\"{x:1300,y:937,t:1527631882171};\\\", \\\"{x:1300,y:935,t:1527631882188};\\\", \\\"{x:1301,y:935,t:1527631882205};\\\", \\\"{x:1301,y:932,t:1527631882221};\\\", \\\"{x:1304,y:931,t:1527631882507};\\\", \\\"{x:1304,y:928,t:1527631882522};\\\", \\\"{x:1305,y:925,t:1527631882540};\\\", \\\"{x:1307,y:923,t:1527631882555};\\\", \\\"{x:1308,y:922,t:1527631882573};\\\", \\\"{x:1308,y:921,t:1527631882867};\\\", \\\"{x:1310,y:921,t:1527631882874};\\\", \\\"{x:1310,y:919,t:1527631882891};\\\", \\\"{x:1311,y:917,t:1527631882906};\\\", \\\"{x:1312,y:913,t:1527631882924};\\\", \\\"{x:1315,y:908,t:1527631882940};\\\", \\\"{x:1317,y:904,t:1527631882957};\\\", \\\"{x:1321,y:896,t:1527631882974};\\\", \\\"{x:1325,y:888,t:1527631882990};\\\", \\\"{x:1329,y:881,t:1527631883007};\\\", \\\"{x:1334,y:875,t:1527631883024};\\\", \\\"{x:1340,y:866,t:1527631883041};\\\", \\\"{x:1345,y:858,t:1527631883057};\\\", \\\"{x:1356,y:843,t:1527631883075};\\\", \\\"{x:1361,y:835,t:1527631883090};\\\", \\\"{x:1366,y:824,t:1527631883107};\\\", \\\"{x:1374,y:816,t:1527631883123};\\\", \\\"{x:1380,y:806,t:1527631883141};\\\", \\\"{x:1383,y:801,t:1527631883157};\\\", \\\"{x:1384,y:795,t:1527631883173};\\\", \\\"{x:1387,y:789,t:1527631883191};\\\", \\\"{x:1389,y:786,t:1527631883207};\\\", \\\"{x:1390,y:784,t:1527631883223};\\\", \\\"{x:1390,y:783,t:1527631883241};\\\", \\\"{x:1391,y:782,t:1527631883257};\\\", \\\"{x:1391,y:780,t:1527631883273};\\\", \\\"{x:1391,y:776,t:1527631883291};\\\", \\\"{x:1393,y:768,t:1527631883308};\\\", \\\"{x:1394,y:767,t:1527631883323};\\\", \\\"{x:1394,y:765,t:1527631883341};\\\", \\\"{x:1394,y:764,t:1527631883459};\\\", \\\"{x:1393,y:763,t:1527631883482};\\\", \\\"{x:1393,y:762,t:1527631883506};\\\", \\\"{x:1392,y:762,t:1527631883555};\\\", \\\"{x:1389,y:762,t:1527631883610};\\\", \\\"{x:1385,y:764,t:1527631883626};\\\", \\\"{x:1376,y:776,t:1527631883643};\\\", \\\"{x:1367,y:785,t:1527631883658};\\\", \\\"{x:1362,y:791,t:1527631883674};\\\", \\\"{x:1359,y:794,t:1527631883692};\\\", \\\"{x:1358,y:798,t:1527631883709};\\\", \\\"{x:1357,y:799,t:1527631883730};\\\", \\\"{x:1357,y:800,t:1527631883741};\\\", \\\"{x:1356,y:801,t:1527631883758};\\\", \\\"{x:1354,y:807,t:1527631883775};\\\", \\\"{x:1348,y:815,t:1527631883791};\\\", \\\"{x:1346,y:824,t:1527631883809};\\\", \\\"{x:1342,y:832,t:1527631883826};\\\", \\\"{x:1339,y:836,t:1527631883842};\\\", \\\"{x:1339,y:841,t:1527631883858};\\\", \\\"{x:1336,y:845,t:1527631883876};\\\", \\\"{x:1335,y:848,t:1527631883892};\\\", \\\"{x:1332,y:852,t:1527631883909};\\\", \\\"{x:1329,y:857,t:1527631883926};\\\", \\\"{x:1327,y:861,t:1527631883942};\\\", \\\"{x:1324,y:864,t:1527631883959};\\\", \\\"{x:1323,y:867,t:1527631883976};\\\", \\\"{x:1320,y:871,t:1527631883993};\\\", \\\"{x:1319,y:874,t:1527631884009};\\\", \\\"{x:1316,y:880,t:1527631884026};\\\", \\\"{x:1311,y:887,t:1527631884043};\\\", \\\"{x:1308,y:892,t:1527631884059};\\\", \\\"{x:1306,y:896,t:1527631884077};\\\", \\\"{x:1305,y:898,t:1527631884094};\\\", \\\"{x:1302,y:904,t:1527631884109};\\\", \\\"{x:1301,y:907,t:1527631884126};\\\", \\\"{x:1298,y:913,t:1527631884143};\\\", \\\"{x:1297,y:919,t:1527631884159};\\\", \\\"{x:1292,y:930,t:1527631884176};\\\", \\\"{x:1286,y:940,t:1527631884193};\\\", \\\"{x:1277,y:951,t:1527631884209};\\\", \\\"{x:1274,y:953,t:1527631884226};\\\", \\\"{x:1272,y:955,t:1527631884243};\\\", \\\"{x:1270,y:958,t:1527631884260};\\\", \\\"{x:1269,y:960,t:1527631884277};\\\", \\\"{x:1268,y:960,t:1527631884299};\\\", \\\"{x:1268,y:961,t:1527631884310};\\\", \\\"{x:1268,y:963,t:1527631884327};\\\", \\\"{x:1266,y:965,t:1527631884343};\\\", \\\"{x:1265,y:967,t:1527631884360};\\\", \\\"{x:1264,y:967,t:1527631884378};\\\", \\\"{x:1265,y:968,t:1527631884698};\\\", \\\"{x:1269,y:968,t:1527631884711};\\\", \\\"{x:1277,y:968,t:1527631884727};\\\", \\\"{x:1284,y:968,t:1527631884744};\\\", \\\"{x:1286,y:968,t:1527631884761};\\\", \\\"{x:1287,y:969,t:1527631884803};\\\", \\\"{x:1289,y:969,t:1527631884818};\\\", \\\"{x:1292,y:971,t:1527631884828};\\\", \\\"{x:1297,y:973,t:1527631884843};\\\", \\\"{x:1305,y:974,t:1527631884861};\\\", \\\"{x:1314,y:977,t:1527631884877};\\\", \\\"{x:1328,y:980,t:1527631884893};\\\", \\\"{x:1346,y:983,t:1527631884910};\\\", \\\"{x:1364,y:985,t:1527631884927};\\\", \\\"{x:1377,y:985,t:1527631884945};\\\", \\\"{x:1390,y:985,t:1527631884960};\\\", \\\"{x:1407,y:985,t:1527631884977};\\\", \\\"{x:1418,y:986,t:1527631884995};\\\", \\\"{x:1426,y:986,t:1527631885011};\\\", \\\"{x:1431,y:986,t:1527631885027};\\\", \\\"{x:1435,y:986,t:1527631885045};\\\", \\\"{x:1437,y:986,t:1527631885275};\\\", \\\"{x:1443,y:986,t:1527631885282};\\\", \\\"{x:1449,y:986,t:1527631885295};\\\", \\\"{x:1462,y:986,t:1527631885311};\\\", \\\"{x:1470,y:986,t:1527631885328};\\\", \\\"{x:1474,y:986,t:1527631885344};\\\", \\\"{x:1481,y:987,t:1527631885362};\\\", \\\"{x:1484,y:987,t:1527631885378};\\\", \\\"{x:1485,y:987,t:1527631885395};\\\", \\\"{x:1484,y:984,t:1527631885498};\\\", \\\"{x:1478,y:979,t:1527631885512};\\\", \\\"{x:1461,y:966,t:1527631885529};\\\", \\\"{x:1432,y:941,t:1527631885546};\\\", \\\"{x:1419,y:928,t:1527631885562};\\\", \\\"{x:1408,y:911,t:1527631885579};\\\", \\\"{x:1402,y:892,t:1527631885596};\\\", \\\"{x:1399,y:875,t:1527631885613};\\\", \\\"{x:1399,y:860,t:1527631885629};\\\", \\\"{x:1399,y:845,t:1527631885647};\\\", \\\"{x:1399,y:835,t:1527631885663};\\\", \\\"{x:1399,y:829,t:1527631885678};\\\", \\\"{x:1397,y:824,t:1527631885696};\\\", \\\"{x:1396,y:818,t:1527631885713};\\\", \\\"{x:1395,y:805,t:1527631885730};\\\", \\\"{x:1391,y:795,t:1527631885746};\\\", \\\"{x:1390,y:785,t:1527631885763};\\\", \\\"{x:1387,y:778,t:1527631885780};\\\", \\\"{x:1386,y:774,t:1527631885797};\\\", \\\"{x:1386,y:773,t:1527631885813};\\\", \\\"{x:1384,y:772,t:1527631885830};\\\", \\\"{x:1384,y:771,t:1527631885846};\\\", \\\"{x:1384,y:770,t:1527631885875};\\\", \\\"{x:1383,y:769,t:1527631885882};\\\", \\\"{x:1383,y:768,t:1527631885897};\\\", \\\"{x:1382,y:768,t:1527631885913};\\\", \\\"{x:1380,y:768,t:1527631886003};\\\", \\\"{x:1380,y:771,t:1527631886015};\\\", \\\"{x:1376,y:782,t:1527631886030};\\\", \\\"{x:1371,y:792,t:1527631886047};\\\", \\\"{x:1369,y:801,t:1527631886064};\\\", \\\"{x:1363,y:810,t:1527631886080};\\\", \\\"{x:1357,y:822,t:1527631886097};\\\", \\\"{x:1352,y:831,t:1527631886114};\\\", \\\"{x:1349,y:835,t:1527631886130};\\\", \\\"{x:1347,y:840,t:1527631886147};\\\", \\\"{x:1344,y:847,t:1527631886164};\\\", \\\"{x:1340,y:854,t:1527631886180};\\\", \\\"{x:1337,y:860,t:1527631886197};\\\", \\\"{x:1331,y:868,t:1527631886214};\\\", \\\"{x:1328,y:876,t:1527631886231};\\\", \\\"{x:1326,y:878,t:1527631886247};\\\", \\\"{x:1323,y:884,t:1527631886264};\\\", \\\"{x:1321,y:889,t:1527631886280};\\\", \\\"{x:1318,y:898,t:1527631886297};\\\", \\\"{x:1313,y:913,t:1527631886314};\\\", \\\"{x:1309,y:921,t:1527631886330};\\\", \\\"{x:1305,y:928,t:1527631886347};\\\", \\\"{x:1304,y:930,t:1527631886364};\\\", \\\"{x:1302,y:933,t:1527631886381};\\\", \\\"{x:1301,y:935,t:1527631886398};\\\", \\\"{x:1300,y:939,t:1527631886414};\\\", \\\"{x:1298,y:943,t:1527631886431};\\\", \\\"{x:1296,y:946,t:1527631886447};\\\", \\\"{x:1293,y:948,t:1527631886463};\\\", \\\"{x:1292,y:950,t:1527631886481};\\\", \\\"{x:1291,y:952,t:1527631886497};\\\", \\\"{x:1290,y:957,t:1527631886514};\\\", \\\"{x:1288,y:958,t:1527631886530};\\\", \\\"{x:1288,y:960,t:1527631886547};\\\", \\\"{x:1287,y:961,t:1527631886564};\\\", \\\"{x:1286,y:963,t:1527631886581};\\\", \\\"{x:1285,y:964,t:1527631886597};\\\", \\\"{x:1285,y:965,t:1527631886614};\\\", \\\"{x:1284,y:966,t:1527631886631};\\\", \\\"{x:1284,y:967,t:1527631886658};\\\", \\\"{x:1283,y:968,t:1527631886834};\\\", \\\"{x:1283,y:969,t:1527631886866};\\\", \\\"{x:1282,y:970,t:1527631886882};\\\", \\\"{x:1283,y:971,t:1527631887195};\\\", \\\"{x:1285,y:971,t:1527631887203};\\\", \\\"{x:1290,y:971,t:1527631887216};\\\", \\\"{x:1305,y:971,t:1527631887233};\\\", \\\"{x:1322,y:971,t:1527631887249};\\\", \\\"{x:1360,y:971,t:1527631887267};\\\", \\\"{x:1386,y:967,t:1527631887283};\\\", \\\"{x:1428,y:967,t:1527631887299};\\\", \\\"{x:1467,y:967,t:1527631887316};\\\", \\\"{x:1494,y:967,t:1527631887333};\\\", \\\"{x:1517,y:967,t:1527631887350};\\\", \\\"{x:1532,y:967,t:1527631887367};\\\", \\\"{x:1536,y:967,t:1527631887383};\\\", \\\"{x:1537,y:967,t:1527631887400};\\\", \\\"{x:1537,y:960,t:1527631887507};\\\", \\\"{x:1531,y:949,t:1527631887518};\\\", \\\"{x:1505,y:902,t:1527631887534};\\\", \\\"{x:1467,y:849,t:1527631887550};\\\", \\\"{x:1430,y:801,t:1527631887567};\\\", \\\"{x:1403,y:764,t:1527631887583};\\\", \\\"{x:1390,y:743,t:1527631887600};\\\", \\\"{x:1383,y:730,t:1527631887617};\\\", \\\"{x:1381,y:722,t:1527631887633};\\\", \\\"{x:1380,y:711,t:1527631887650};\\\", \\\"{x:1380,y:709,t:1527631887667};\\\", \\\"{x:1380,y:706,t:1527631887684};\\\", \\\"{x:1380,y:704,t:1527631887739};\\\", \\\"{x:1380,y:703,t:1527631887755};\\\", \\\"{x:1380,y:702,t:1527631887770};\\\", \\\"{x:1381,y:701,t:1527631887784};\\\", \\\"{x:1384,y:700,t:1527631887801};\\\", \\\"{x:1389,y:695,t:1527631887817};\\\", \\\"{x:1408,y:674,t:1527631887834};\\\", \\\"{x:1434,y:646,t:1527631887851};\\\", \\\"{x:1457,y:617,t:1527631887867};\\\", \\\"{x:1474,y:599,t:1527631887884};\\\", \\\"{x:1478,y:592,t:1527631887901};\\\", \\\"{x:1482,y:587,t:1527631887917};\\\", \\\"{x:1487,y:571,t:1527631887934};\\\", \\\"{x:1489,y:554,t:1527631887951};\\\", \\\"{x:1491,y:541,t:1527631887968};\\\", \\\"{x:1492,y:540,t:1527631887984};\\\", \\\"{x:1492,y:539,t:1527631888059};\\\", \\\"{x:1495,y:538,t:1527631888162};\\\", \\\"{x:1496,y:537,t:1527631888170};\\\", \\\"{x:1496,y:536,t:1527631888194};\\\", \\\"{x:1499,y:530,t:1527631888202};\\\", \\\"{x:1500,y:530,t:1527631888291};\\\", \\\"{x:1500,y:528,t:1527631888302};\\\", \\\"{x:1500,y:525,t:1527631888318};\\\", \\\"{x:1499,y:522,t:1527631888336};\\\", \\\"{x:1492,y:521,t:1527631888352};\\\", \\\"{x:1473,y:521,t:1527631888368};\\\", \\\"{x:1438,y:531,t:1527631888385};\\\", \\\"{x:1357,y:564,t:1527631888402};\\\", \\\"{x:1254,y:582,t:1527631888418};\\\", \\\"{x:1145,y:586,t:1527631888436};\\\", \\\"{x:1015,y:586,t:1527631888452};\\\", \\\"{x:867,y:581,t:1527631888469};\\\", \\\"{x:730,y:566,t:1527631888487};\\\", \\\"{x:612,y:562,t:1527631888502};\\\", \\\"{x:571,y:563,t:1527631888533};\\\", \\\"{x:572,y:555,t:1527631888674};\\\", \\\"{x:577,y:548,t:1527631888683};\\\", \\\"{x:582,y:539,t:1527631888700};\\\", \\\"{x:583,y:536,t:1527631888717};\\\", \\\"{x:585,y:534,t:1527631888733};\\\", \\\"{x:585,y:533,t:1527631888750};\\\", \\\"{x:580,y:534,t:1527631888785};\\\", \\\"{x:569,y:535,t:1527631888800};\\\", \\\"{x:545,y:535,t:1527631888817};\\\", \\\"{x:523,y:535,t:1527631888833};\\\", \\\"{x:490,y:535,t:1527631888852};\\\", \\\"{x:482,y:535,t:1527631888866};\\\", \\\"{x:481,y:535,t:1527631888883};\\\", \\\"{x:478,y:535,t:1527631888953};\\\", \\\"{x:474,y:535,t:1527631888966};\\\", \\\"{x:464,y:535,t:1527631888982};\\\", \\\"{x:447,y:549,t:1527631889000};\\\", \\\"{x:432,y:562,t:1527631889016};\\\", \\\"{x:420,y:571,t:1527631889033};\\\", \\\"{x:410,y:576,t:1527631889050};\\\", \\\"{x:408,y:576,t:1527631889066};\\\", \\\"{x:407,y:576,t:1527631889083};\\\", \\\"{x:404,y:576,t:1527631889099};\\\", \\\"{x:398,y:574,t:1527631889116};\\\", \\\"{x:389,y:571,t:1527631889134};\\\", \\\"{x:381,y:567,t:1527631889150};\\\", \\\"{x:380,y:566,t:1527631889167};\\\", \\\"{x:379,y:566,t:1527631889183};\\\", \\\"{x:376,y:565,t:1527631889199};\\\", \\\"{x:380,y:571,t:1527631889650};\\\", \\\"{x:391,y:589,t:1527631889667};\\\", \\\"{x:402,y:609,t:1527631889684};\\\", \\\"{x:413,y:627,t:1527631889702};\\\", \\\"{x:427,y:643,t:1527631889717};\\\", \\\"{x:439,y:656,t:1527631889734};\\\", \\\"{x:450,y:669,t:1527631889750};\\\", \\\"{x:461,y:685,t:1527631889767};\\\", \\\"{x:470,y:701,t:1527631889784};\\\", \\\"{x:474,y:710,t:1527631889801};\\\", \\\"{x:476,y:715,t:1527631889816};\\\", \\\"{x:479,y:719,t:1527631889833};\\\", \\\"{x:479,y:720,t:1527631889979};\\\", \\\"{x:479,y:709,t:1527631891074};\\\", \\\"{x:479,y:690,t:1527631891085};\\\", \\\"{x:486,y:630,t:1527631891101};\\\", \\\"{x:501,y:569,t:1527631891118};\\\", \\\"{x:511,y:541,t:1527631891135};\\\", \\\"{x:518,y:525,t:1527631891152};\\\", \\\"{x:519,y:515,t:1527631891168};\\\", \\\"{x:519,y:512,t:1527631891185};\\\", \\\"{x:520,y:511,t:1527631891202};\\\", \\\"{x:520,y:510,t:1527631891266};\\\" ] }, { \\\"rt\\\": 11835, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 502539, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:496,t:1527631892371};\\\", \\\"{x:499,y:457,t:1527631892388};\\\", \\\"{x:484,y:430,t:1527631892402};\\\", \\\"{x:477,y:418,t:1527631892419};\\\", \\\"{x:476,y:414,t:1527631892436};\\\", \\\"{x:476,y:412,t:1527631892453};\\\", \\\"{x:477,y:410,t:1527631892468};\\\", \\\"{x:480,y:410,t:1527631892865};\\\", \\\"{x:483,y:410,t:1527631892874};\\\", \\\"{x:487,y:410,t:1527631892885};\\\", \\\"{x:500,y:410,t:1527631892903};\\\", \\\"{x:507,y:410,t:1527631892920};\\\", \\\"{x:521,y:410,t:1527631892936};\\\", \\\"{x:532,y:410,t:1527631892952};\\\", \\\"{x:552,y:413,t:1527631892969};\\\", \\\"{x:565,y:415,t:1527631892986};\\\", \\\"{x:583,y:420,t:1527631893003};\\\", \\\"{x:604,y:423,t:1527631893020};\\\", \\\"{x:626,y:426,t:1527631893036};\\\", \\\"{x:654,y:430,t:1527631893053};\\\", \\\"{x:677,y:436,t:1527631893071};\\\", \\\"{x:705,y:440,t:1527631893086};\\\", \\\"{x:744,y:448,t:1527631893103};\\\", \\\"{x:796,y:458,t:1527631893120};\\\", \\\"{x:841,y:465,t:1527631893136};\\\", \\\"{x:872,y:470,t:1527631893153};\\\", \\\"{x:899,y:474,t:1527631893170};\\\", \\\"{x:907,y:475,t:1527631893185};\\\", \\\"{x:912,y:476,t:1527631893203};\\\", \\\"{x:923,y:479,t:1527631893220};\\\", \\\"{x:933,y:489,t:1527631893236};\\\", \\\"{x:954,y:504,t:1527631893253};\\\", \\\"{x:975,y:518,t:1527631893269};\\\", \\\"{x:993,y:532,t:1527631893287};\\\", \\\"{x:1018,y:548,t:1527631893303};\\\", \\\"{x:1041,y:568,t:1527631893320};\\\", \\\"{x:1066,y:598,t:1527631893337};\\\", \\\"{x:1099,y:638,t:1527631893353};\\\", \\\"{x:1141,y:698,t:1527631893370};\\\", \\\"{x:1169,y:740,t:1527631893387};\\\", \\\"{x:1191,y:778,t:1527631893402};\\\", \\\"{x:1204,y:800,t:1527631893419};\\\", \\\"{x:1216,y:827,t:1527631893438};\\\", \\\"{x:1226,y:851,t:1527631893454};\\\", \\\"{x:1235,y:873,t:1527631893470};\\\", \\\"{x:1248,y:884,t:1527631893487};\\\", \\\"{x:1257,y:895,t:1527631893503};\\\", \\\"{x:1273,y:906,t:1527631893520};\\\", \\\"{x:1292,y:916,t:1527631893537};\\\", \\\"{x:1313,y:922,t:1527631893553};\\\", \\\"{x:1357,y:926,t:1527631893571};\\\", \\\"{x:1383,y:929,t:1527631893587};\\\", \\\"{x:1428,y:934,t:1527631893603};\\\", \\\"{x:1481,y:942,t:1527631893620};\\\", \\\"{x:1512,y:943,t:1527631893638};\\\", \\\"{x:1522,y:945,t:1527631893654};\\\", \\\"{x:1524,y:945,t:1527631893670};\\\", \\\"{x:1525,y:945,t:1527631893827};\\\", \\\"{x:1528,y:948,t:1527631893837};\\\", \\\"{x:1538,y:958,t:1527631893854};\\\", \\\"{x:1557,y:972,t:1527631893870};\\\", \\\"{x:1581,y:983,t:1527631893888};\\\", \\\"{x:1599,y:991,t:1527631893905};\\\", \\\"{x:1610,y:996,t:1527631893920};\\\", \\\"{x:1616,y:999,t:1527631893937};\\\", \\\"{x:1617,y:999,t:1527631893954};\\\", \\\"{x:1621,y:999,t:1527631893970};\\\", \\\"{x:1622,y:1000,t:1527631893987};\\\", \\\"{x:1623,y:1001,t:1527631894018};\\\", \\\"{x:1623,y:1000,t:1527631894243};\\\", \\\"{x:1623,y:998,t:1527631894254};\\\", \\\"{x:1623,y:996,t:1527631894271};\\\", \\\"{x:1623,y:995,t:1527631894362};\\\", \\\"{x:1621,y:990,t:1527631894563};\\\", \\\"{x:1619,y:987,t:1527631894572};\\\", \\\"{x:1615,y:982,t:1527631894586};\\\", \\\"{x:1611,y:976,t:1527631894604};\\\", \\\"{x:1608,y:973,t:1527631894620};\\\", \\\"{x:1608,y:971,t:1527631894636};\\\", \\\"{x:1606,y:970,t:1527631894729};\\\", \\\"{x:1606,y:967,t:1527631894746};\\\", \\\"{x:1605,y:965,t:1527631894754};\\\", \\\"{x:1600,y:955,t:1527631894771};\\\", \\\"{x:1594,y:941,t:1527631894787};\\\", \\\"{x:1583,y:923,t:1527631894805};\\\", \\\"{x:1578,y:913,t:1527631894821};\\\", \\\"{x:1575,y:909,t:1527631894839};\\\", \\\"{x:1572,y:905,t:1527631894854};\\\", \\\"{x:1571,y:903,t:1527631894871};\\\", \\\"{x:1569,y:901,t:1527631894978};\\\", \\\"{x:1567,y:894,t:1527631894989};\\\", \\\"{x:1557,y:874,t:1527631895004};\\\", \\\"{x:1550,y:853,t:1527631895021};\\\", \\\"{x:1544,y:838,t:1527631895038};\\\", \\\"{x:1538,y:830,t:1527631895055};\\\", \\\"{x:1536,y:826,t:1527631895072};\\\", \\\"{x:1533,y:816,t:1527631895089};\\\", \\\"{x:1527,y:804,t:1527631895105};\\\", \\\"{x:1524,y:795,t:1527631895121};\\\", \\\"{x:1519,y:783,t:1527631895139};\\\", \\\"{x:1515,y:776,t:1527631895155};\\\", \\\"{x:1512,y:768,t:1527631895172};\\\", \\\"{x:1508,y:758,t:1527631895189};\\\", \\\"{x:1503,y:749,t:1527631895205};\\\", \\\"{x:1495,y:740,t:1527631895222};\\\", \\\"{x:1488,y:731,t:1527631895239};\\\", \\\"{x:1482,y:721,t:1527631895254};\\\", \\\"{x:1477,y:713,t:1527631895271};\\\", \\\"{x:1473,y:702,t:1527631895289};\\\", \\\"{x:1467,y:688,t:1527631895305};\\\", \\\"{x:1461,y:675,t:1527631895322};\\\", \\\"{x:1455,y:663,t:1527631895338};\\\", \\\"{x:1453,y:657,t:1527631895356};\\\", \\\"{x:1451,y:648,t:1527631895372};\\\", \\\"{x:1450,y:637,t:1527631895388};\\\", \\\"{x:1447,y:622,t:1527631895405};\\\", \\\"{x:1446,y:608,t:1527631895422};\\\", \\\"{x:1446,y:602,t:1527631895438};\\\", \\\"{x:1445,y:598,t:1527631895455};\\\", \\\"{x:1444,y:594,t:1527631895471};\\\", \\\"{x:1443,y:589,t:1527631895488};\\\", \\\"{x:1443,y:584,t:1527631895505};\\\", \\\"{x:1443,y:579,t:1527631895521};\\\", \\\"{x:1443,y:576,t:1527631895538};\\\", \\\"{x:1443,y:573,t:1527631895556};\\\", \\\"{x:1442,y:570,t:1527631895573};\\\", \\\"{x:1441,y:568,t:1527631895588};\\\", \\\"{x:1440,y:567,t:1527631895610};\\\", \\\"{x:1440,y:566,t:1527631895714};\\\", \\\"{x:1439,y:566,t:1527631895722};\\\", \\\"{x:1438,y:566,t:1527631895739};\\\", \\\"{x:1432,y:566,t:1527631895755};\\\", \\\"{x:1426,y:566,t:1527631895773};\\\", \\\"{x:1425,y:566,t:1527631895788};\\\", \\\"{x:1423,y:566,t:1527631895805};\\\", \\\"{x:1423,y:567,t:1527631895822};\\\", \\\"{x:1404,y:567,t:1527631896947};\\\", \\\"{x:1356,y:564,t:1527631896957};\\\", \\\"{x:1236,y:560,t:1527631896973};\\\", \\\"{x:1086,y:553,t:1527631896989};\\\", \\\"{x:938,y:559,t:1527631897006};\\\", \\\"{x:823,y:565,t:1527631897022};\\\", \\\"{x:732,y:578,t:1527631897039};\\\", \\\"{x:695,y:587,t:1527631897056};\\\", \\\"{x:674,y:590,t:1527631897072};\\\", \\\"{x:660,y:594,t:1527631897089};\\\", \\\"{x:653,y:594,t:1527631897106};\\\", \\\"{x:652,y:595,t:1527631897123};\\\", \\\"{x:651,y:595,t:1527631897140};\\\", \\\"{x:650,y:595,t:1527631897233};\\\", \\\"{x:649,y:592,t:1527631897241};\\\", \\\"{x:648,y:589,t:1527631897256};\\\", \\\"{x:644,y:583,t:1527631897274};\\\", \\\"{x:638,y:576,t:1527631897290};\\\", \\\"{x:633,y:572,t:1527631897306};\\\", \\\"{x:630,y:567,t:1527631897323};\\\", \\\"{x:626,y:563,t:1527631897340};\\\", \\\"{x:621,y:560,t:1527631897357};\\\", \\\"{x:619,y:559,t:1527631897373};\\\", \\\"{x:617,y:557,t:1527631897390};\\\", \\\"{x:614,y:557,t:1527631897406};\\\", \\\"{x:612,y:556,t:1527631897423};\\\", \\\"{x:611,y:556,t:1527631897440};\\\", \\\"{x:608,y:555,t:1527631897457};\\\", \\\"{x:608,y:559,t:1527631898178};\\\", \\\"{x:609,y:563,t:1527631898191};\\\", \\\"{x:626,y:574,t:1527631898208};\\\", \\\"{x:646,y:585,t:1527631898225};\\\", \\\"{x:692,y:604,t:1527631898241};\\\", \\\"{x:753,y:618,t:1527631898257};\\\", \\\"{x:829,y:633,t:1527631898274};\\\", \\\"{x:906,y:642,t:1527631898290};\\\", \\\"{x:963,y:645,t:1527631898307};\\\", \\\"{x:1003,y:645,t:1527631898324};\\\", \\\"{x:1056,y:645,t:1527631898340};\\\", \\\"{x:1120,y:645,t:1527631898357};\\\", \\\"{x:1184,y:645,t:1527631898374};\\\", \\\"{x:1235,y:644,t:1527631898390};\\\", \\\"{x:1260,y:640,t:1527631898407};\\\", \\\"{x:1268,y:640,t:1527631898424};\\\", \\\"{x:1270,y:640,t:1527631898515};\\\", \\\"{x:1271,y:641,t:1527631898524};\\\", \\\"{x:1276,y:646,t:1527631898540};\\\", \\\"{x:1284,y:652,t:1527631898557};\\\", \\\"{x:1289,y:656,t:1527631898574};\\\", \\\"{x:1290,y:657,t:1527631898590};\\\", \\\"{x:1290,y:659,t:1527631898642};\\\", \\\"{x:1284,y:660,t:1527631898658};\\\", \\\"{x:1275,y:660,t:1527631898673};\\\", \\\"{x:1265,y:662,t:1527631898690};\\\", \\\"{x:1257,y:664,t:1527631898707};\\\", \\\"{x:1255,y:664,t:1527631898723};\\\", \\\"{x:1255,y:663,t:1527631898866};\\\", \\\"{x:1256,y:663,t:1527631898874};\\\", \\\"{x:1259,y:662,t:1527631898891};\\\", \\\"{x:1260,y:662,t:1527631898907};\\\", \\\"{x:1261,y:661,t:1527631898923};\\\", \\\"{x:1262,y:660,t:1527631898941};\\\", \\\"{x:1264,y:658,t:1527631898978};\\\", \\\"{x:1265,y:655,t:1527631898990};\\\", \\\"{x:1266,y:645,t:1527631899008};\\\", \\\"{x:1266,y:639,t:1527631899023};\\\", \\\"{x:1266,y:626,t:1527631899041};\\\", \\\"{x:1266,y:593,t:1527631899058};\\\", \\\"{x:1260,y:565,t:1527631899075};\\\", \\\"{x:1257,y:544,t:1527631899091};\\\", \\\"{x:1257,y:512,t:1527631899108};\\\", \\\"{x:1258,y:488,t:1527631899124};\\\", \\\"{x:1258,y:476,t:1527631899140};\\\", \\\"{x:1259,y:472,t:1527631899158};\\\", \\\"{x:1260,y:469,t:1527631899173};\\\", \\\"{x:1260,y:468,t:1527631899190};\\\", \\\"{x:1261,y:468,t:1527631899207};\\\", \\\"{x:1262,y:467,t:1527631899234};\\\", \\\"{x:1263,y:466,t:1527631899243};\\\", \\\"{x:1265,y:466,t:1527631899258};\\\", \\\"{x:1267,y:465,t:1527631899273};\\\", \\\"{x:1270,y:465,t:1527631899290};\\\", \\\"{x:1273,y:465,t:1527631899307};\\\", \\\"{x:1275,y:465,t:1527631899324};\\\", \\\"{x:1276,y:465,t:1527631899340};\\\", \\\"{x:1277,y:466,t:1527631899402};\\\", \\\"{x:1278,y:466,t:1527631899426};\\\", \\\"{x:1279,y:466,t:1527631899450};\\\", \\\"{x:1281,y:466,t:1527631899458};\\\", \\\"{x:1283,y:466,t:1527631899473};\\\", \\\"{x:1288,y:461,t:1527631899490};\\\", \\\"{x:1290,y:455,t:1527631899506};\\\", \\\"{x:1295,y:444,t:1527631899524};\\\", \\\"{x:1299,y:432,t:1527631899540};\\\", \\\"{x:1300,y:419,t:1527631899556};\\\", \\\"{x:1300,y:415,t:1527631899573};\\\", \\\"{x:1300,y:411,t:1527631899591};\\\", \\\"{x:1300,y:408,t:1527631899606};\\\", \\\"{x:1300,y:407,t:1527631899624};\\\", \\\"{x:1297,y:409,t:1527631899762};\\\", \\\"{x:1295,y:410,t:1527631899773};\\\", \\\"{x:1292,y:413,t:1527631899790};\\\", \\\"{x:1290,y:417,t:1527631899807};\\\", \\\"{x:1287,y:423,t:1527631899824};\\\", \\\"{x:1287,y:424,t:1527631899839};\\\", \\\"{x:1286,y:426,t:1527631899856};\\\", \\\"{x:1285,y:427,t:1527631899873};\\\", \\\"{x:1284,y:428,t:1527631899889};\\\", \\\"{x:1282,y:431,t:1527631899913};\\\", \\\"{x:1282,y:432,t:1527631899923};\\\", \\\"{x:1280,y:434,t:1527631899939};\\\", \\\"{x:1280,y:435,t:1527631899961};\\\", \\\"{x:1278,y:438,t:1527631899973};\\\", \\\"{x:1277,y:439,t:1527631899989};\\\", \\\"{x:1276,y:441,t:1527631900006};\\\", \\\"{x:1274,y:445,t:1527631900024};\\\", \\\"{x:1273,y:447,t:1527631900039};\\\", \\\"{x:1270,y:451,t:1527631900056};\\\", \\\"{x:1269,y:452,t:1527631900074};\\\", \\\"{x:1269,y:454,t:1527631900097};\\\", \\\"{x:1268,y:454,t:1527631900162};\\\", \\\"{x:1256,y:462,t:1527631901818};\\\", \\\"{x:1231,y:477,t:1527631901826};\\\", \\\"{x:1201,y:494,t:1527631901839};\\\", \\\"{x:1116,y:529,t:1527631901855};\\\", \\\"{x:1033,y:552,t:1527631901872};\\\", \\\"{x:947,y:579,t:1527631901888};\\\", \\\"{x:840,y:615,t:1527631901906};\\\", \\\"{x:788,y:636,t:1527631901921};\\\", \\\"{x:756,y:652,t:1527631901939};\\\", \\\"{x:736,y:662,t:1527631901956};\\\", \\\"{x:723,y:669,t:1527631901972};\\\", \\\"{x:718,y:674,t:1527631901989};\\\", \\\"{x:705,y:681,t:1527631902005};\\\", \\\"{x:675,y:691,t:1527631902021};\\\", \\\"{x:635,y:704,t:1527631902038};\\\", \\\"{x:566,y:722,t:1527631902056};\\\", \\\"{x:521,y:729,t:1527631902073};\\\", \\\"{x:484,y:736,t:1527631902088};\\\", \\\"{x:462,y:740,t:1527631902105};\\\", \\\"{x:466,y:740,t:1527631902298};\\\", \\\"{x:469,y:740,t:1527631902310};\\\", \\\"{x:473,y:741,t:1527631902327};\\\", \\\"{x:481,y:741,t:1527631902345};\\\", \\\"{x:487,y:741,t:1527631902360};\\\", \\\"{x:488,y:741,t:1527631902377};\\\", \\\"{x:489,y:741,t:1527631902611};\\\", \\\"{x:491,y:738,t:1527631902627};\\\", \\\"{x:491,y:737,t:1527631902650};\\\", \\\"{x:492,y:735,t:1527631902667};\\\", \\\"{x:494,y:733,t:1527631902681};\\\", \\\"{x:497,y:732,t:1527631902694};\\\", \\\"{x:499,y:731,t:1527631902710};\\\", \\\"{x:500,y:731,t:1527631902729};\\\", \\\"{x:500,y:730,t:1527631902744};\\\" ] }, { \\\"rt\\\": 72089, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 575838, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-11 AM-09 AM-10 AM-11 AM-12 PM-12 PM-12 PM-Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:730,t:1527631904921};\\\", \\\"{x:497,y:731,t:1527631904929};\\\", \\\"{x:494,y:733,t:1527631904958};\\\", \\\"{x:493,y:733,t:1527631904962};\\\", \\\"{x:491,y:734,t:1527631904979};\\\", \\\"{x:490,y:734,t:1527631904996};\\\", \\\"{x:489,y:734,t:1527631905129};\\\", \\\"{x:483,y:735,t:1527631905147};\\\", \\\"{x:473,y:740,t:1527631905164};\\\", \\\"{x:461,y:747,t:1527631905179};\\\", \\\"{x:452,y:751,t:1527631905197};\\\", \\\"{x:446,y:756,t:1527631905213};\\\", \\\"{x:441,y:760,t:1527631905300};\\\", \\\"{x:440,y:760,t:1527631905321};\\\", \\\"{x:436,y:758,t:1527631905328};\\\", \\\"{x:430,y:743,t:1527631905346};\\\", \\\"{x:423,y:734,t:1527631905363};\\\", \\\"{x:421,y:730,t:1527631905379};\\\", \\\"{x:437,y:679,t:1527631905396};\\\", \\\"{x:451,y:592,t:1527631905413};\\\", \\\"{x:452,y:528,t:1527631905430};\\\", \\\"{x:455,y:487,t:1527631905447};\\\", \\\"{x:457,y:460,t:1527631905463};\\\", \\\"{x:463,y:443,t:1527631905479};\\\", \\\"{x:465,y:436,t:1527631905496};\\\", \\\"{x:465,y:435,t:1527631905513};\\\", \\\"{x:466,y:435,t:1527631905529};\\\", \\\"{x:466,y:432,t:1527631905553};\\\", \\\"{x:466,y:429,t:1527631905564};\\\", \\\"{x:470,y:417,t:1527631905579};\\\", \\\"{x:470,y:415,t:1527631905597};\\\", \\\"{x:471,y:413,t:1527631905613};\\\", \\\"{x:474,y:410,t:1527631905834};\\\", \\\"{x:484,y:407,t:1527631905846};\\\", \\\"{x:492,y:402,t:1527631905864};\\\", \\\"{x:497,y:397,t:1527631905880};\\\", \\\"{x:498,y:395,t:1527631905897};\\\", \\\"{x:505,y:388,t:1527631905914};\\\", \\\"{x:510,y:386,t:1527631905930};\\\", \\\"{x:514,y:383,t:1527631905946};\\\", \\\"{x:516,y:383,t:1527631906449};\\\", \\\"{x:519,y:382,t:1527631908707};\\\", \\\"{x:534,y:381,t:1527631908716};\\\", \\\"{x:583,y:376,t:1527631908732};\\\", \\\"{x:645,y:373,t:1527631908749};\\\", \\\"{x:786,y:373,t:1527631908766};\\\", \\\"{x:927,y:373,t:1527631908782};\\\", \\\"{x:1074,y:371,t:1527631908799};\\\", \\\"{x:1221,y:366,t:1527631908815};\\\", \\\"{x:1360,y:362,t:1527631908833};\\\", \\\"{x:1488,y:362,t:1527631908849};\\\", \\\"{x:1505,y:364,t:1527631908865};\\\", \\\"{x:1508,y:365,t:1527631908883};\\\", \\\"{x:1508,y:366,t:1527631908922};\\\", \\\"{x:1508,y:367,t:1527631908938};\\\", \\\"{x:1508,y:369,t:1527631908950};\\\", \\\"{x:1508,y:373,t:1527631908966};\\\", \\\"{x:1508,y:374,t:1527631908983};\\\", \\\"{x:1508,y:376,t:1527631909000};\\\", \\\"{x:1508,y:380,t:1527631909016};\\\", \\\"{x:1508,y:384,t:1527631909033};\\\", \\\"{x:1508,y:391,t:1527631909049};\\\", \\\"{x:1507,y:398,t:1527631909065};\\\", \\\"{x:1506,y:405,t:1527631909083};\\\", \\\"{x:1501,y:417,t:1527631909100};\\\", \\\"{x:1497,y:428,t:1527631909116};\\\", \\\"{x:1491,y:438,t:1527631909133};\\\", \\\"{x:1482,y:452,t:1527631909150};\\\", \\\"{x:1477,y:464,t:1527631909166};\\\", \\\"{x:1473,y:471,t:1527631909183};\\\", \\\"{x:1469,y:479,t:1527631909200};\\\", \\\"{x:1463,y:488,t:1527631909216};\\\", \\\"{x:1457,y:496,t:1527631909233};\\\", \\\"{x:1450,y:506,t:1527631909250};\\\", \\\"{x:1449,y:509,t:1527631909266};\\\", \\\"{x:1448,y:510,t:1527631909283};\\\", \\\"{x:1447,y:510,t:1527631909763};\\\", \\\"{x:1444,y:513,t:1527631909769};\\\", \\\"{x:1442,y:516,t:1527631909783};\\\", \\\"{x:1441,y:516,t:1527631909800};\\\", \\\"{x:1440,y:517,t:1527631909865};\\\", \\\"{x:1440,y:518,t:1527631909921};\\\", \\\"{x:1440,y:519,t:1527631909944};\\\", \\\"{x:1440,y:521,t:1527631909977};\\\", \\\"{x:1439,y:522,t:1527631913978};\\\", \\\"{x:1436,y:523,t:1527631913988};\\\", \\\"{x:1428,y:523,t:1527631914003};\\\", \\\"{x:1418,y:523,t:1527631914020};\\\", \\\"{x:1408,y:520,t:1527631914037};\\\", \\\"{x:1403,y:519,t:1527631914054};\\\", \\\"{x:1402,y:519,t:1527631914082};\\\", \\\"{x:1400,y:519,t:1527631914089};\\\", \\\"{x:1398,y:518,t:1527631914128};\\\", \\\"{x:1397,y:518,t:1527631914153};\\\", \\\"{x:1396,y:518,t:1527631914170};\\\", \\\"{x:1394,y:518,t:1527631914193};\\\", \\\"{x:1393,y:518,t:1527631914217};\\\", \\\"{x:1391,y:518,t:1527631914241};\\\", \\\"{x:1390,y:518,t:1527631914254};\\\", \\\"{x:1386,y:518,t:1527631914270};\\\", \\\"{x:1378,y:518,t:1527631914286};\\\", \\\"{x:1369,y:519,t:1527631914303};\\\", \\\"{x:1360,y:521,t:1527631914320};\\\", \\\"{x:1350,y:522,t:1527631914337};\\\", \\\"{x:1339,y:522,t:1527631914354};\\\", \\\"{x:1337,y:522,t:1527631914369};\\\", \\\"{x:1336,y:522,t:1527631914386};\\\", \\\"{x:1335,y:522,t:1527631914610};\\\", \\\"{x:1334,y:522,t:1527631914626};\\\", \\\"{x:1334,y:523,t:1527631914641};\\\", \\\"{x:1332,y:524,t:1527631914654};\\\", \\\"{x:1331,y:525,t:1527631914670};\\\", \\\"{x:1330,y:526,t:1527631914686};\\\", \\\"{x:1327,y:526,t:1527631914703};\\\", \\\"{x:1324,y:528,t:1527631914720};\\\", \\\"{x:1323,y:529,t:1527631915154};\\\", \\\"{x:1319,y:528,t:1527631917170};\\\", \\\"{x:1315,y:521,t:1527631917178};\\\", \\\"{x:1314,y:520,t:1527631917189};\\\", \\\"{x:1312,y:516,t:1527631917206};\\\", \\\"{x:1309,y:512,t:1527631917222};\\\", \\\"{x:1306,y:506,t:1527631917239};\\\", \\\"{x:1305,y:502,t:1527631917257};\\\", \\\"{x:1303,y:499,t:1527631917273};\\\", \\\"{x:1303,y:498,t:1527631917290};\\\", \\\"{x:1303,y:497,t:1527631917306};\\\", \\\"{x:1303,y:496,t:1527631917339};\\\", \\\"{x:1302,y:496,t:1527631917356};\\\", \\\"{x:1302,y:495,t:1527631917674};\\\", \\\"{x:1301,y:500,t:1527631917689};\\\", \\\"{x:1299,y:509,t:1527631917706};\\\", \\\"{x:1299,y:517,t:1527631917723};\\\", \\\"{x:1298,y:527,t:1527631917740};\\\", \\\"{x:1296,y:541,t:1527631917756};\\\", \\\"{x:1295,y:551,t:1527631917773};\\\", \\\"{x:1293,y:559,t:1527631917789};\\\", \\\"{x:1292,y:564,t:1527631917806};\\\", \\\"{x:1291,y:571,t:1527631917823};\\\", \\\"{x:1289,y:578,t:1527631917841};\\\", \\\"{x:1288,y:585,t:1527631917857};\\\", \\\"{x:1285,y:599,t:1527631917874};\\\", \\\"{x:1280,y:613,t:1527631917890};\\\", \\\"{x:1276,y:627,t:1527631917906};\\\", \\\"{x:1272,y:638,t:1527631917924};\\\", \\\"{x:1269,y:649,t:1527631917940};\\\", \\\"{x:1265,y:659,t:1527631917957};\\\", \\\"{x:1260,y:667,t:1527631917973};\\\", \\\"{x:1256,y:678,t:1527631917990};\\\", \\\"{x:1248,y:690,t:1527631918006};\\\", \\\"{x:1245,y:696,t:1527631918024};\\\", \\\"{x:1244,y:698,t:1527631918040};\\\", \\\"{x:1241,y:704,t:1527631918057};\\\", \\\"{x:1239,y:709,t:1527631918073};\\\", \\\"{x:1234,y:718,t:1527631918090};\\\", \\\"{x:1230,y:726,t:1527631918106};\\\", \\\"{x:1227,y:733,t:1527631918122};\\\", \\\"{x:1223,y:739,t:1527631918140};\\\", \\\"{x:1221,y:743,t:1527631918157};\\\", \\\"{x:1219,y:747,t:1527631918173};\\\", \\\"{x:1217,y:750,t:1527631918189};\\\", \\\"{x:1214,y:755,t:1527631918206};\\\", \\\"{x:1209,y:764,t:1527631918222};\\\", \\\"{x:1204,y:774,t:1527631918239};\\\", \\\"{x:1195,y:786,t:1527631918256};\\\", \\\"{x:1184,y:797,t:1527631918272};\\\", \\\"{x:1174,y:807,t:1527631918290};\\\", \\\"{x:1163,y:816,t:1527631918306};\\\", \\\"{x:1156,y:824,t:1527631918323};\\\", \\\"{x:1150,y:830,t:1527631918339};\\\", \\\"{x:1144,y:834,t:1527631918356};\\\", \\\"{x:1138,y:840,t:1527631918373};\\\", \\\"{x:1134,y:846,t:1527631918389};\\\", \\\"{x:1129,y:851,t:1527631918407};\\\", \\\"{x:1126,y:855,t:1527631918423};\\\", \\\"{x:1122,y:857,t:1527631918440};\\\", \\\"{x:1119,y:861,t:1527631918457};\\\", \\\"{x:1115,y:864,t:1527631918473};\\\", \\\"{x:1113,y:865,t:1527631918490};\\\", \\\"{x:1112,y:866,t:1527631918507};\\\", \\\"{x:1111,y:867,t:1527631918523};\\\", \\\"{x:1110,y:868,t:1527631918540};\\\", \\\"{x:1109,y:868,t:1527631919258};\\\", \\\"{x:1104,y:871,t:1527631919274};\\\", \\\"{x:1101,y:872,t:1527631919292};\\\", \\\"{x:1096,y:874,t:1527631919308};\\\", \\\"{x:1094,y:876,t:1527631919324};\\\", \\\"{x:1086,y:884,t:1527631919341};\\\", \\\"{x:1081,y:891,t:1527631919358};\\\", \\\"{x:1077,y:898,t:1527631919375};\\\", \\\"{x:1074,y:902,t:1527631919391};\\\", \\\"{x:1072,y:904,t:1527631919407};\\\", \\\"{x:1072,y:906,t:1527631919424};\\\", \\\"{x:1071,y:908,t:1527631919441};\\\", \\\"{x:1070,y:910,t:1527631919457};\\\", \\\"{x:1069,y:912,t:1527631919474};\\\", \\\"{x:1069,y:913,t:1527631919491};\\\", \\\"{x:1067,y:917,t:1527631919509};\\\", \\\"{x:1067,y:919,t:1527631919525};\\\", \\\"{x:1066,y:920,t:1527631919542};\\\", \\\"{x:1065,y:921,t:1527631919570};\\\", \\\"{x:1065,y:922,t:1527631919577};\\\", \\\"{x:1065,y:923,t:1527631919594};\\\", \\\"{x:1065,y:924,t:1527631919609};\\\", \\\"{x:1064,y:924,t:1527631919624};\\\", \\\"{x:1063,y:926,t:1527631919642};\\\", \\\"{x:1063,y:927,t:1527631919657};\\\", \\\"{x:1062,y:929,t:1527631919674};\\\", \\\"{x:1060,y:930,t:1527631919691};\\\", \\\"{x:1059,y:932,t:1527631919714};\\\", \\\"{x:1058,y:934,t:1527631919737};\\\", \\\"{x:1057,y:935,t:1527631919753};\\\", \\\"{x:1057,y:936,t:1527631919778};\\\", \\\"{x:1057,y:937,t:1527631919791};\\\", \\\"{x:1057,y:938,t:1527631919810};\\\", \\\"{x:1056,y:940,t:1527631919858};\\\", \\\"{x:1055,y:941,t:1527631919914};\\\", \\\"{x:1054,y:942,t:1527631919994};\\\", \\\"{x:1054,y:943,t:1527631920017};\\\", \\\"{x:1053,y:944,t:1527631920065};\\\", \\\"{x:1052,y:945,t:1527631920075};\\\", \\\"{x:1052,y:946,t:1527631920092};\\\", \\\"{x:1051,y:947,t:1527631920108};\\\", \\\"{x:1050,y:947,t:1527631920125};\\\", \\\"{x:1050,y:948,t:1527631920146};\\\", \\\"{x:1049,y:948,t:1527631920162};\\\", \\\"{x:1048,y:949,t:1527631920738};\\\", \\\"{x:1048,y:947,t:1527631921354};\\\", \\\"{x:1054,y:934,t:1527631921361};\\\", \\\"{x:1065,y:913,t:1527631921377};\\\", \\\"{x:1082,y:881,t:1527631921393};\\\", \\\"{x:1130,y:781,t:1527631921410};\\\", \\\"{x:1155,y:719,t:1527631921426};\\\", \\\"{x:1173,y:688,t:1527631921443};\\\", \\\"{x:1181,y:669,t:1527631921460};\\\", \\\"{x:1191,y:650,t:1527631921477};\\\", \\\"{x:1197,y:634,t:1527631921492};\\\", \\\"{x:1206,y:622,t:1527631921510};\\\", \\\"{x:1210,y:615,t:1527631921527};\\\", \\\"{x:1212,y:612,t:1527631921543};\\\", \\\"{x:1213,y:610,t:1527631921559};\\\", \\\"{x:1214,y:608,t:1527631921577};\\\", \\\"{x:1215,y:608,t:1527631921594};\\\", \\\"{x:1215,y:607,t:1527631921618};\\\", \\\"{x:1217,y:607,t:1527631921642};\\\", \\\"{x:1221,y:602,t:1527631921660};\\\", \\\"{x:1235,y:592,t:1527631921677};\\\", \\\"{x:1245,y:586,t:1527631921694};\\\", \\\"{x:1252,y:582,t:1527631921710};\\\", \\\"{x:1259,y:579,t:1527631921727};\\\", \\\"{x:1263,y:579,t:1527631921744};\\\", \\\"{x:1266,y:583,t:1527631921759};\\\", \\\"{x:1268,y:600,t:1527631921777};\\\", \\\"{x:1269,y:631,t:1527631921794};\\\", \\\"{x:1269,y:652,t:1527631921809};\\\", \\\"{x:1260,y:672,t:1527631921827};\\\", \\\"{x:1240,y:710,t:1527631921843};\\\", \\\"{x:1225,y:751,t:1527631921860};\\\", \\\"{x:1208,y:792,t:1527631921876};\\\", \\\"{x:1194,y:825,t:1527631921894};\\\", \\\"{x:1180,y:856,t:1527631921909};\\\", \\\"{x:1175,y:873,t:1527631921926};\\\", \\\"{x:1171,y:884,t:1527631921944};\\\", \\\"{x:1169,y:890,t:1527631921960};\\\", \\\"{x:1164,y:898,t:1527631921976};\\\", \\\"{x:1159,y:908,t:1527631921994};\\\", \\\"{x:1154,y:917,t:1527631922009};\\\", \\\"{x:1149,y:925,t:1527631922026};\\\", \\\"{x:1145,y:933,t:1527631922043};\\\", \\\"{x:1144,y:939,t:1527631922060};\\\", \\\"{x:1142,y:942,t:1527631922076};\\\", \\\"{x:1142,y:943,t:1527631922094};\\\", \\\"{x:1141,y:946,t:1527631922110};\\\", \\\"{x:1140,y:947,t:1527631922127};\\\", \\\"{x:1138,y:951,t:1527631922144};\\\", \\\"{x:1137,y:955,t:1527631922160};\\\", \\\"{x:1135,y:957,t:1527631922176};\\\", \\\"{x:1133,y:959,t:1527631922194};\\\", \\\"{x:1132,y:960,t:1527631922210};\\\", \\\"{x:1126,y:963,t:1527631922227};\\\", \\\"{x:1118,y:969,t:1527631922243};\\\", \\\"{x:1113,y:972,t:1527631922260};\\\", \\\"{x:1108,y:974,t:1527631922276};\\\", \\\"{x:1107,y:974,t:1527631922293};\\\", \\\"{x:1107,y:975,t:1527631922394};\\\", \\\"{x:1107,y:976,t:1527631922442};\\\", \\\"{x:1110,y:976,t:1527631922449};\\\", \\\"{x:1115,y:976,t:1527631922461};\\\", \\\"{x:1132,y:976,t:1527631922477};\\\", \\\"{x:1148,y:976,t:1527631922494};\\\", \\\"{x:1163,y:976,t:1527631922510};\\\", \\\"{x:1171,y:978,t:1527631922528};\\\", \\\"{x:1174,y:978,t:1527631922543};\\\", \\\"{x:1175,y:978,t:1527631922617};\\\", \\\"{x:1176,y:978,t:1527631922627};\\\", \\\"{x:1181,y:978,t:1527631922643};\\\", \\\"{x:1189,y:978,t:1527631922660};\\\", \\\"{x:1201,y:978,t:1527631922677};\\\", \\\"{x:1218,y:978,t:1527631922694};\\\", \\\"{x:1237,y:978,t:1527631922711};\\\", \\\"{x:1251,y:978,t:1527631922727};\\\", \\\"{x:1260,y:976,t:1527631922744};\\\", \\\"{x:1274,y:976,t:1527631922761};\\\", \\\"{x:1288,y:975,t:1527631922777};\\\", \\\"{x:1291,y:975,t:1527631922794};\\\", \\\"{x:1293,y:975,t:1527631922810};\\\", \\\"{x:1294,y:975,t:1527631922827};\\\", \\\"{x:1295,y:975,t:1527631922844};\\\", \\\"{x:1297,y:975,t:1527631922860};\\\", \\\"{x:1298,y:975,t:1527631922877};\\\", \\\"{x:1301,y:975,t:1527631922895};\\\", \\\"{x:1305,y:975,t:1527631922911};\\\", \\\"{x:1312,y:975,t:1527631922928};\\\", \\\"{x:1319,y:974,t:1527631922944};\\\", \\\"{x:1330,y:974,t:1527631922960};\\\", \\\"{x:1350,y:974,t:1527631922978};\\\", \\\"{x:1364,y:974,t:1527631922993};\\\", \\\"{x:1376,y:973,t:1527631923010};\\\", \\\"{x:1382,y:973,t:1527631923028};\\\", \\\"{x:1389,y:973,t:1527631923044};\\\", \\\"{x:1392,y:973,t:1527631923060};\\\", \\\"{x:1395,y:973,t:1527631923078};\\\", \\\"{x:1396,y:973,t:1527631923094};\\\", \\\"{x:1397,y:973,t:1527631923110};\\\", \\\"{x:1400,y:973,t:1527631923128};\\\", \\\"{x:1404,y:973,t:1527631923145};\\\", \\\"{x:1410,y:973,t:1527631923160};\\\", \\\"{x:1422,y:975,t:1527631923178};\\\", \\\"{x:1433,y:975,t:1527631923194};\\\", \\\"{x:1441,y:975,t:1527631923211};\\\", \\\"{x:1448,y:975,t:1527631923227};\\\", \\\"{x:1452,y:975,t:1527631923245};\\\", \\\"{x:1456,y:975,t:1527631923260};\\\", \\\"{x:1462,y:975,t:1527631923278};\\\", \\\"{x:1467,y:975,t:1527631923294};\\\", \\\"{x:1471,y:975,t:1527631923311};\\\", \\\"{x:1476,y:975,t:1527631923328};\\\", \\\"{x:1483,y:975,t:1527631923344};\\\", \\\"{x:1490,y:975,t:1527631923360};\\\", \\\"{x:1497,y:975,t:1527631923378};\\\", \\\"{x:1502,y:975,t:1527631923395};\\\", \\\"{x:1505,y:975,t:1527631923411};\\\", \\\"{x:1508,y:975,t:1527631923427};\\\", \\\"{x:1509,y:975,t:1527631923466};\\\", \\\"{x:1510,y:975,t:1527631923477};\\\", \\\"{x:1511,y:976,t:1527631923506};\\\", \\\"{x:1512,y:976,t:1527631923522};\\\", \\\"{x:1513,y:977,t:1527631923538};\\\", \\\"{x:1512,y:977,t:1527631923986};\\\", \\\"{x:1511,y:977,t:1527631924001};\\\", \\\"{x:1509,y:977,t:1527631924018};\\\", \\\"{x:1507,y:975,t:1527631924033};\\\", \\\"{x:1506,y:975,t:1527631924065};\\\", \\\"{x:1504,y:975,t:1527631924585};\\\", \\\"{x:1504,y:974,t:1527631927210};\\\", \\\"{x:1489,y:968,t:1527631927217};\\\", \\\"{x:1474,y:965,t:1527631927231};\\\", \\\"{x:1448,y:951,t:1527631927249};\\\", \\\"{x:1426,y:932,t:1527631927264};\\\", \\\"{x:1417,y:930,t:1527631927281};\\\", \\\"{x:1414,y:926,t:1527631927297};\\\", \\\"{x:1401,y:922,t:1527631927314};\\\", \\\"{x:1390,y:910,t:1527631927331};\\\", \\\"{x:1385,y:897,t:1527631927348};\\\", \\\"{x:1382,y:874,t:1527631927365};\\\", \\\"{x:1374,y:848,t:1527631927381};\\\", \\\"{x:1368,y:827,t:1527631927397};\\\", \\\"{x:1367,y:817,t:1527631927415};\\\", \\\"{x:1363,y:809,t:1527631927430};\\\", \\\"{x:1356,y:793,t:1527631927449};\\\", \\\"{x:1354,y:789,t:1527631927464};\\\", \\\"{x:1348,y:777,t:1527631927480};\\\", \\\"{x:1336,y:755,t:1527631927498};\\\", \\\"{x:1327,y:742,t:1527631927515};\\\", \\\"{x:1317,y:729,t:1527631927530};\\\", \\\"{x:1299,y:714,t:1527631927547};\\\", \\\"{x:1283,y:706,t:1527631927565};\\\", \\\"{x:1267,y:699,t:1527631927580};\\\", \\\"{x:1251,y:692,t:1527631927598};\\\", \\\"{x:1238,y:688,t:1527631927615};\\\", \\\"{x:1228,y:685,t:1527631927630};\\\", \\\"{x:1217,y:681,t:1527631927647};\\\", \\\"{x:1211,y:680,t:1527631927665};\\\", \\\"{x:1203,y:676,t:1527631927681};\\\", \\\"{x:1190,y:674,t:1527631927698};\\\", \\\"{x:1184,y:674,t:1527631927715};\\\", \\\"{x:1179,y:670,t:1527631927731};\\\", \\\"{x:1176,y:670,t:1527631927748};\\\", \\\"{x:1175,y:670,t:1527631927818};\\\", \\\"{x:1173,y:670,t:1527631927857};\\\", \\\"{x:1171,y:670,t:1527631927873};\\\", \\\"{x:1168,y:670,t:1527631927889};\\\", \\\"{x:1166,y:670,t:1527631927897};\\\", \\\"{x:1162,y:670,t:1527631927915};\\\", \\\"{x:1155,y:670,t:1527631927931};\\\", \\\"{x:1142,y:670,t:1527631927947};\\\", \\\"{x:1130,y:670,t:1527631927965};\\\", \\\"{x:1123,y:670,t:1527631927982};\\\", \\\"{x:1116,y:670,t:1527631927998};\\\", \\\"{x:1115,y:670,t:1527631928017};\\\", \\\"{x:1114,y:670,t:1527631928050};\\\", \\\"{x:1113,y:670,t:1527631928065};\\\", \\\"{x:1112,y:669,t:1527631928089};\\\", \\\"{x:1111,y:668,t:1527631928114};\\\", \\\"{x:1135,y:671,t:1527631934434};\\\", \\\"{x:1170,y:676,t:1527631934441};\\\", \\\"{x:1199,y:681,t:1527631934452};\\\", \\\"{x:1259,y:686,t:1527631934469};\\\", \\\"{x:1299,y:686,t:1527631934486};\\\", \\\"{x:1318,y:686,t:1527631934502};\\\", \\\"{x:1326,y:691,t:1527631934519};\\\", \\\"{x:1334,y:705,t:1527631934536};\\\", \\\"{x:1339,y:719,t:1527631934553};\\\", \\\"{x:1339,y:729,t:1527631934569};\\\", \\\"{x:1342,y:744,t:1527631934586};\\\", \\\"{x:1346,y:768,t:1527631934603};\\\", \\\"{x:1358,y:829,t:1527631934620};\\\", \\\"{x:1359,y:874,t:1527631934637};\\\", \\\"{x:1359,y:907,t:1527631934652};\\\", \\\"{x:1359,y:920,t:1527631934669};\\\", \\\"{x:1357,y:931,t:1527631934686};\\\", \\\"{x:1356,y:935,t:1527631934703};\\\", \\\"{x:1354,y:937,t:1527631934719};\\\", \\\"{x:1353,y:938,t:1527631934873};\\\", \\\"{x:1351,y:940,t:1527631934886};\\\", \\\"{x:1346,y:943,t:1527631934904};\\\", \\\"{x:1341,y:945,t:1527631934919};\\\", \\\"{x:1330,y:949,t:1527631934936};\\\", \\\"{x:1328,y:951,t:1527631934952};\\\", \\\"{x:1326,y:952,t:1527631934969};\\\", \\\"{x:1324,y:953,t:1527631934987};\\\", \\\"{x:1322,y:955,t:1527631935003};\\\", \\\"{x:1318,y:955,t:1527631935019};\\\", \\\"{x:1310,y:960,t:1527631935037};\\\", \\\"{x:1301,y:962,t:1527631935054};\\\", \\\"{x:1284,y:970,t:1527631935070};\\\", \\\"{x:1264,y:977,t:1527631935087};\\\", \\\"{x:1250,y:985,t:1527631935104};\\\", \\\"{x:1236,y:987,t:1527631935119};\\\", \\\"{x:1217,y:995,t:1527631935137};\\\", \\\"{x:1206,y:999,t:1527631935153};\\\", \\\"{x:1195,y:1001,t:1527631935170};\\\", \\\"{x:1182,y:1002,t:1527631935186};\\\", \\\"{x:1168,y:1003,t:1527631935204};\\\", \\\"{x:1149,y:1003,t:1527631935220};\\\", \\\"{x:1138,y:1003,t:1527631935237};\\\", \\\"{x:1132,y:1003,t:1527631935254};\\\", \\\"{x:1131,y:1003,t:1527631935271};\\\", \\\"{x:1130,y:1003,t:1527631935287};\\\", \\\"{x:1129,y:1003,t:1527631935329};\\\", \\\"{x:1126,y:1001,t:1527631935394};\\\", \\\"{x:1126,y:1000,t:1527631935404};\\\", \\\"{x:1124,y:999,t:1527631935420};\\\", \\\"{x:1120,y:994,t:1527631935437};\\\", \\\"{x:1119,y:990,t:1527631935454};\\\", \\\"{x:1119,y:981,t:1527631935471};\\\", \\\"{x:1119,y:978,t:1527631935487};\\\", \\\"{x:1120,y:974,t:1527631935504};\\\", \\\"{x:1122,y:973,t:1527631935521};\\\", \\\"{x:1123,y:972,t:1527631935537};\\\", \\\"{x:1125,y:972,t:1527631935553};\\\", \\\"{x:1134,y:972,t:1527631935571};\\\", \\\"{x:1138,y:972,t:1527631935587};\\\", \\\"{x:1139,y:972,t:1527631935604};\\\", \\\"{x:1141,y:972,t:1527631935621};\\\", \\\"{x:1142,y:973,t:1527631935638};\\\", \\\"{x:1143,y:973,t:1527631935770};\\\", \\\"{x:1144,y:973,t:1527631935788};\\\", \\\"{x:1145,y:973,t:1527631935804};\\\", \\\"{x:1150,y:971,t:1527631935821};\\\", \\\"{x:1158,y:971,t:1527631935838};\\\", \\\"{x:1170,y:971,t:1527631935854};\\\", \\\"{x:1181,y:972,t:1527631935871};\\\", \\\"{x:1198,y:974,t:1527631935888};\\\", \\\"{x:1212,y:977,t:1527631935904};\\\", \\\"{x:1214,y:977,t:1527631935921};\\\", \\\"{x:1215,y:977,t:1527631935985};\\\", \\\"{x:1216,y:977,t:1527631936122};\\\", \\\"{x:1224,y:977,t:1527631936137};\\\", \\\"{x:1230,y:977,t:1527631936154};\\\", \\\"{x:1242,y:977,t:1527631936171};\\\", \\\"{x:1256,y:977,t:1527631936188};\\\", \\\"{x:1270,y:977,t:1527631936205};\\\", \\\"{x:1285,y:980,t:1527631936221};\\\", \\\"{x:1292,y:981,t:1527631936238};\\\", \\\"{x:1293,y:981,t:1527631936384};\\\", \\\"{x:1294,y:981,t:1527631936393};\\\", \\\"{x:1295,y:981,t:1527631936404};\\\", \\\"{x:1301,y:981,t:1527631936421};\\\", \\\"{x:1308,y:981,t:1527631936438};\\\", \\\"{x:1316,y:981,t:1527631936455};\\\", \\\"{x:1318,y:981,t:1527631936472};\\\", \\\"{x:1319,y:981,t:1527631936489};\\\", \\\"{x:1320,y:981,t:1527631936513};\\\", \\\"{x:1321,y:981,t:1527631936538};\\\", \\\"{x:1322,y:981,t:1527631936562};\\\", \\\"{x:1323,y:981,t:1527631936610};\\\", \\\"{x:1324,y:981,t:1527631936621};\\\", \\\"{x:1326,y:980,t:1527631936638};\\\", \\\"{x:1328,y:980,t:1527631936655};\\\", \\\"{x:1329,y:978,t:1527631936672};\\\", \\\"{x:1331,y:978,t:1527631936690};\\\", \\\"{x:1331,y:977,t:1527631936705};\\\", \\\"{x:1333,y:975,t:1527631936721};\\\", \\\"{x:1334,y:975,t:1527631936738};\\\", \\\"{x:1335,y:975,t:1527631936755};\\\", \\\"{x:1335,y:974,t:1527631936777};\\\", \\\"{x:1337,y:974,t:1527631936793};\\\", \\\"{x:1338,y:972,t:1527631936809};\\\", \\\"{x:1340,y:971,t:1527631937177};\\\", \\\"{x:1342,y:969,t:1527631937194};\\\", \\\"{x:1342,y:968,t:1527631937210};\\\", \\\"{x:1342,y:966,t:1527631937257};\\\", \\\"{x:1342,y:965,t:1527631937297};\\\", \\\"{x:1343,y:965,t:1527631937314};\\\", \\\"{x:1344,y:964,t:1527631937345};\\\", \\\"{x:1344,y:963,t:1527631937377};\\\", \\\"{x:1344,y:962,t:1527631937409};\\\", \\\"{x:1345,y:962,t:1527631937422};\\\", \\\"{x:1341,y:962,t:1527631938610};\\\", \\\"{x:1331,y:962,t:1527631938623};\\\", \\\"{x:1305,y:962,t:1527631938640};\\\", \\\"{x:1279,y:962,t:1527631938656};\\\", \\\"{x:1264,y:962,t:1527631938673};\\\", \\\"{x:1262,y:962,t:1527631938690};\\\", \\\"{x:1264,y:962,t:1527631938993};\\\", \\\"{x:1268,y:963,t:1527631939006};\\\", \\\"{x:1274,y:964,t:1527631939023};\\\", \\\"{x:1291,y:967,t:1527631939040};\\\", \\\"{x:1303,y:967,t:1527631939056};\\\", \\\"{x:1310,y:967,t:1527631939073};\\\", \\\"{x:1311,y:967,t:1527631939089};\\\", \\\"{x:1312,y:967,t:1527631939153};\\\", \\\"{x:1313,y:967,t:1527631939160};\\\", \\\"{x:1314,y:967,t:1527631939177};\\\", \\\"{x:1315,y:967,t:1527631939189};\\\", \\\"{x:1317,y:967,t:1527631939207};\\\", \\\"{x:1325,y:967,t:1527631939224};\\\", \\\"{x:1329,y:966,t:1527631939239};\\\", \\\"{x:1331,y:966,t:1527631939257};\\\", \\\"{x:1334,y:966,t:1527631939273};\\\", \\\"{x:1336,y:964,t:1527631939290};\\\", \\\"{x:1338,y:964,t:1527631939307};\\\", \\\"{x:1339,y:964,t:1527631939440};\\\", \\\"{x:1339,y:963,t:1527631939456};\\\", \\\"{x:1336,y:961,t:1527631939473};\\\", \\\"{x:1332,y:960,t:1527631939490};\\\", \\\"{x:1325,y:960,t:1527631939506};\\\", \\\"{x:1316,y:960,t:1527631939523};\\\", \\\"{x:1308,y:960,t:1527631939540};\\\", \\\"{x:1299,y:960,t:1527631939556};\\\", \\\"{x:1294,y:960,t:1527631939574};\\\", \\\"{x:1292,y:960,t:1527631939589};\\\", \\\"{x:1291,y:956,t:1527631939761};\\\", \\\"{x:1291,y:953,t:1527631939774};\\\", \\\"{x:1291,y:946,t:1527631939791};\\\", \\\"{x:1292,y:943,t:1527631939807};\\\", \\\"{x:1294,y:942,t:1527631939823};\\\", \\\"{x:1296,y:937,t:1527631939841};\\\", \\\"{x:1297,y:934,t:1527631939857};\\\", \\\"{x:1298,y:931,t:1527631939874};\\\", \\\"{x:1300,y:926,t:1527631939891};\\\", \\\"{x:1301,y:923,t:1527631939906};\\\", \\\"{x:1302,y:921,t:1527631939924};\\\", \\\"{x:1303,y:917,t:1527631939941};\\\", \\\"{x:1303,y:916,t:1527631939958};\\\", \\\"{x:1304,y:914,t:1527631939974};\\\", \\\"{x:1304,y:905,t:1527631939991};\\\", \\\"{x:1304,y:903,t:1527631940008};\\\", \\\"{x:1304,y:900,t:1527631940024};\\\", \\\"{x:1303,y:897,t:1527631940042};\\\", \\\"{x:1307,y:900,t:1527631940218};\\\", \\\"{x:1311,y:905,t:1527631940225};\\\", \\\"{x:1320,y:919,t:1527631940241};\\\", \\\"{x:1330,y:933,t:1527631940257};\\\", \\\"{x:1336,y:942,t:1527631940275};\\\", \\\"{x:1338,y:948,t:1527631940291};\\\", \\\"{x:1340,y:951,t:1527631940308};\\\", \\\"{x:1341,y:955,t:1527631940324};\\\", \\\"{x:1343,y:960,t:1527631940341};\\\", \\\"{x:1343,y:967,t:1527631940358};\\\", \\\"{x:1344,y:973,t:1527631940375};\\\", \\\"{x:1345,y:976,t:1527631940395};\\\", \\\"{x:1345,y:977,t:1527631940412};\\\", \\\"{x:1346,y:978,t:1527631940430};\\\", \\\"{x:1347,y:979,t:1527631940446};\\\", \\\"{x:1347,y:980,t:1527631940462};\\\", \\\"{x:1348,y:981,t:1527631940486};\\\", \\\"{x:1348,y:975,t:1527631940926};\\\", \\\"{x:1348,y:971,t:1527631940934};\\\", \\\"{x:1348,y:968,t:1527631940947};\\\", \\\"{x:1348,y:965,t:1527631940963};\\\", \\\"{x:1348,y:961,t:1527631940980};\\\", \\\"{x:1349,y:956,t:1527631940997};\\\", \\\"{x:1349,y:954,t:1527631941013};\\\", \\\"{x:1349,y:953,t:1527631941029};\\\", \\\"{x:1350,y:950,t:1527631941046};\\\", \\\"{x:1351,y:948,t:1527631941078};\\\", \\\"{x:1351,y:947,t:1527631941119};\\\", \\\"{x:1351,y:948,t:1527631941294};\\\", \\\"{x:1351,y:949,t:1527631941302};\\\", \\\"{x:1351,y:951,t:1527631941314};\\\", \\\"{x:1351,y:958,t:1527631941330};\\\", \\\"{x:1352,y:966,t:1527631941347};\\\", \\\"{x:1355,y:972,t:1527631941363};\\\", \\\"{x:1355,y:974,t:1527631941380};\\\", \\\"{x:1355,y:975,t:1527631941397};\\\", \\\"{x:1356,y:976,t:1527631941413};\\\", \\\"{x:1354,y:976,t:1527631941742};\\\", \\\"{x:1352,y:973,t:1527631941750};\\\", \\\"{x:1351,y:970,t:1527631941764};\\\", \\\"{x:1349,y:967,t:1527631941781};\\\", \\\"{x:1342,y:957,t:1527631941797};\\\", \\\"{x:1336,y:946,t:1527631941814};\\\", \\\"{x:1333,y:940,t:1527631941830};\\\", \\\"{x:1332,y:937,t:1527631941847};\\\", \\\"{x:1329,y:933,t:1527631941864};\\\", \\\"{x:1328,y:932,t:1527631941881};\\\", \\\"{x:1326,y:929,t:1527631941897};\\\", \\\"{x:1324,y:926,t:1527631941914};\\\", \\\"{x:1321,y:920,t:1527631941931};\\\", \\\"{x:1320,y:918,t:1527631941947};\\\", \\\"{x:1320,y:917,t:1527631941964};\\\", \\\"{x:1318,y:916,t:1527631941981};\\\", \\\"{x:1318,y:915,t:1527631942006};\\\", \\\"{x:1317,y:914,t:1527631942030};\\\", \\\"{x:1317,y:912,t:1527631942134};\\\", \\\"{x:1317,y:909,t:1527631942147};\\\", \\\"{x:1317,y:908,t:1527631942164};\\\", \\\"{x:1317,y:907,t:1527631942182};\\\", \\\"{x:1317,y:906,t:1527631942198};\\\", \\\"{x:1311,y:900,t:1527631945183};\\\", \\\"{x:1296,y:882,t:1527631945200};\\\", \\\"{x:1289,y:876,t:1527631945216};\\\", \\\"{x:1286,y:873,t:1527631945233};\\\", \\\"{x:1285,y:872,t:1527631945249};\\\", \\\"{x:1285,y:871,t:1527631945310};\\\", \\\"{x:1282,y:869,t:1527631945317};\\\", \\\"{x:1282,y:868,t:1527631945334};\\\", \\\"{x:1282,y:867,t:1527631945350};\\\", \\\"{x:1281,y:865,t:1527631945366};\\\", \\\"{x:1280,y:862,t:1527631945383};\\\", \\\"{x:1279,y:859,t:1527631945400};\\\", \\\"{x:1278,y:857,t:1527631945417};\\\", \\\"{x:1278,y:855,t:1527631945433};\\\", \\\"{x:1277,y:850,t:1527631945450};\\\", \\\"{x:1274,y:845,t:1527631945467};\\\", \\\"{x:1273,y:842,t:1527631945483};\\\", \\\"{x:1271,y:839,t:1527631945500};\\\", \\\"{x:1271,y:838,t:1527631945517};\\\", \\\"{x:1270,y:836,t:1527631945533};\\\", \\\"{x:1269,y:835,t:1527631946390};\\\", \\\"{x:1268,y:835,t:1527631946401};\\\", \\\"{x:1266,y:835,t:1527631946417};\\\", \\\"{x:1265,y:836,t:1527631946434};\\\", \\\"{x:1264,y:836,t:1527631946451};\\\", \\\"{x:1264,y:837,t:1527631946470};\\\", \\\"{x:1264,y:838,t:1527631946484};\\\", \\\"{x:1263,y:838,t:1527631946822};\\\", \\\"{x:1263,y:822,t:1527631950078};\\\", \\\"{x:1263,y:807,t:1527631950088};\\\", \\\"{x:1266,y:778,t:1527631950104};\\\", \\\"{x:1269,y:752,t:1527631950121};\\\", \\\"{x:1272,y:732,t:1527631950137};\\\", \\\"{x:1272,y:715,t:1527631950154};\\\", \\\"{x:1272,y:693,t:1527631950170};\\\", \\\"{x:1274,y:671,t:1527631950187};\\\", \\\"{x:1280,y:649,t:1527631950204};\\\", \\\"{x:1283,y:633,t:1527631950221};\\\", \\\"{x:1285,y:625,t:1527631950237};\\\", \\\"{x:1286,y:623,t:1527631950254};\\\", \\\"{x:1286,y:622,t:1527631950277};\\\", \\\"{x:1289,y:619,t:1527631950327};\\\", \\\"{x:1293,y:610,t:1527631950337};\\\", \\\"{x:1299,y:594,t:1527631950354};\\\", \\\"{x:1304,y:585,t:1527631950370};\\\", \\\"{x:1307,y:574,t:1527631950387};\\\", \\\"{x:1308,y:573,t:1527631950404};\\\", \\\"{x:1308,y:569,t:1527631950420};\\\", \\\"{x:1308,y:568,t:1527631950437};\\\", \\\"{x:1308,y:567,t:1527631950934};\\\", \\\"{x:1308,y:549,t:1527631950941};\\\", \\\"{x:1308,y:526,t:1527631950954};\\\", \\\"{x:1308,y:502,t:1527631950971};\\\", \\\"{x:1306,y:485,t:1527631950988};\\\", \\\"{x:1305,y:475,t:1527631951005};\\\", \\\"{x:1304,y:464,t:1527631951021};\\\", \\\"{x:1304,y:463,t:1527631951037};\\\", \\\"{x:1304,y:461,t:1527631951054};\\\", \\\"{x:1302,y:461,t:1527631951150};\\\", \\\"{x:1301,y:465,t:1527631951157};\\\", \\\"{x:1299,y:474,t:1527631951172};\\\", \\\"{x:1289,y:492,t:1527631951188};\\\", \\\"{x:1277,y:510,t:1527631951204};\\\", \\\"{x:1255,y:532,t:1527631951221};\\\", \\\"{x:1230,y:551,t:1527631951238};\\\", \\\"{x:1202,y:570,t:1527631951254};\\\", \\\"{x:1176,y:593,t:1527631951271};\\\", \\\"{x:1143,y:616,t:1527631951288};\\\", \\\"{x:1097,y:641,t:1527631951304};\\\", \\\"{x:1059,y:663,t:1527631951321};\\\", \\\"{x:1043,y:671,t:1527631951338};\\\", \\\"{x:1038,y:671,t:1527631951354};\\\", \\\"{x:1035,y:671,t:1527631951371};\\\", \\\"{x:1033,y:666,t:1527631951388};\\\", \\\"{x:1031,y:647,t:1527631951406};\\\", \\\"{x:1028,y:627,t:1527631951422};\\\", \\\"{x:1026,y:605,t:1527631951437};\\\", \\\"{x:1024,y:590,t:1527631951456};\\\", \\\"{x:1021,y:575,t:1527631951471};\\\", \\\"{x:1020,y:565,t:1527631951488};\\\", \\\"{x:1020,y:557,t:1527631951505};\\\", \\\"{x:1020,y:555,t:1527631951521};\\\", \\\"{x:1020,y:553,t:1527631951538};\\\", \\\"{x:1030,y:553,t:1527631951555};\\\", \\\"{x:1038,y:555,t:1527631951571};\\\", \\\"{x:1044,y:563,t:1527631951588};\\\", \\\"{x:1048,y:567,t:1527631951605};\\\", \\\"{x:1049,y:568,t:1527631951621};\\\", \\\"{x:1050,y:568,t:1527631951638};\\\", \\\"{x:1051,y:570,t:1527631951670};\\\", \\\"{x:1053,y:572,t:1527631951678};\\\", \\\"{x:1054,y:573,t:1527631951688};\\\", \\\"{x:1055,y:574,t:1527631951705};\\\", \\\"{x:1056,y:574,t:1527631951862};\\\", \\\"{x:1056,y:578,t:1527631951886};\\\", \\\"{x:1058,y:581,t:1527631951894};\\\", \\\"{x:1062,y:589,t:1527631951905};\\\", \\\"{x:1067,y:598,t:1527631951923};\\\", \\\"{x:1070,y:604,t:1527631951938};\\\", \\\"{x:1071,y:608,t:1527631951955};\\\", \\\"{x:1071,y:613,t:1527631951972};\\\", \\\"{x:1072,y:616,t:1527631951988};\\\", \\\"{x:1074,y:624,t:1527631952006};\\\", \\\"{x:1075,y:630,t:1527631952022};\\\", \\\"{x:1076,y:635,t:1527631952038};\\\", \\\"{x:1076,y:637,t:1527631952055};\\\", \\\"{x:1077,y:639,t:1527631952072};\\\", \\\"{x:1077,y:640,t:1527631952088};\\\", \\\"{x:1077,y:641,t:1527631952238};\\\", \\\"{x:1077,y:643,t:1527631952255};\\\", \\\"{x:1079,y:652,t:1527631952272};\\\", \\\"{x:1083,y:665,t:1527631952289};\\\", \\\"{x:1087,y:679,t:1527631952306};\\\", \\\"{x:1089,y:692,t:1527631952322};\\\", \\\"{x:1092,y:698,t:1527631952339};\\\", \\\"{x:1093,y:703,t:1527631952356};\\\", \\\"{x:1094,y:705,t:1527631952372};\\\", \\\"{x:1094,y:706,t:1527631952390};\\\", \\\"{x:1094,y:709,t:1527631952574};\\\", \\\"{x:1093,y:709,t:1527631952598};\\\", \\\"{x:1093,y:710,t:1527631952622};\\\", \\\"{x:1093,y:709,t:1527631952694};\\\", \\\"{x:1093,y:711,t:1527631952789};\\\", \\\"{x:1092,y:718,t:1527631952805};\\\", \\\"{x:1091,y:722,t:1527631952823};\\\", \\\"{x:1090,y:726,t:1527631952839};\\\", \\\"{x:1090,y:727,t:1527631952856};\\\", \\\"{x:1090,y:726,t:1527631952925};\\\", \\\"{x:1090,y:724,t:1527631952940};\\\", \\\"{x:1090,y:717,t:1527631952956};\\\", \\\"{x:1089,y:712,t:1527631952972};\\\", \\\"{x:1087,y:707,t:1527631952989};\\\", \\\"{x:1086,y:703,t:1527631953006};\\\", \\\"{x:1091,y:703,t:1527631957966};\\\", \\\"{x:1106,y:703,t:1527631957976};\\\", \\\"{x:1134,y:703,t:1527631957994};\\\", \\\"{x:1158,y:703,t:1527631958010};\\\", \\\"{x:1167,y:703,t:1527631958027};\\\", \\\"{x:1171,y:703,t:1527631958043};\\\", \\\"{x:1173,y:703,t:1527631958070};\\\", \\\"{x:1175,y:703,t:1527631958085};\\\", \\\"{x:1177,y:703,t:1527631958093};\\\", \\\"{x:1189,y:703,t:1527631958109};\\\", \\\"{x:1206,y:703,t:1527631958126};\\\", \\\"{x:1229,y:703,t:1527631958144};\\\", \\\"{x:1252,y:703,t:1527631958160};\\\", \\\"{x:1268,y:703,t:1527631958177};\\\", \\\"{x:1281,y:703,t:1527631958193};\\\", \\\"{x:1288,y:703,t:1527631958210};\\\", \\\"{x:1293,y:703,t:1527631958226};\\\", \\\"{x:1300,y:703,t:1527631958243};\\\", \\\"{x:1307,y:705,t:1527631958260};\\\", \\\"{x:1312,y:705,t:1527631958276};\\\", \\\"{x:1320,y:705,t:1527631958293};\\\", \\\"{x:1323,y:705,t:1527631958309};\\\", \\\"{x:1326,y:705,t:1527631958326};\\\", \\\"{x:1328,y:706,t:1527631958343};\\\", \\\"{x:1330,y:706,t:1527631958360};\\\", \\\"{x:1331,y:706,t:1527631958377};\\\", \\\"{x:1334,y:706,t:1527631958393};\\\", \\\"{x:1337,y:706,t:1527631958410};\\\", \\\"{x:1341,y:706,t:1527631958427};\\\", \\\"{x:1350,y:708,t:1527631958443};\\\", \\\"{x:1361,y:708,t:1527631958460};\\\", \\\"{x:1369,y:708,t:1527631958477};\\\", \\\"{x:1363,y:708,t:1527631959302};\\\", \\\"{x:1361,y:708,t:1527631959312};\\\", \\\"{x:1352,y:707,t:1527631959328};\\\", \\\"{x:1350,y:705,t:1527631959344};\\\", \\\"{x:1349,y:705,t:1527631959361};\\\", \\\"{x:1347,y:705,t:1527631960422};\\\", \\\"{x:1346,y:707,t:1527631960654};\\\", \\\"{x:1346,y:708,t:1527631960670};\\\", \\\"{x:1346,y:710,t:1527631960686};\\\", \\\"{x:1346,y:711,t:1527631960709};\\\", \\\"{x:1345,y:713,t:1527631960741};\\\", \\\"{x:1345,y:714,t:1527631960766};\\\", \\\"{x:1345,y:715,t:1527631960782};\\\", \\\"{x:1345,y:716,t:1527631960795};\\\", \\\"{x:1345,y:717,t:1527631960814};\\\", \\\"{x:1344,y:718,t:1527631960829};\\\", \\\"{x:1343,y:722,t:1527631960846};\\\", \\\"{x:1341,y:727,t:1527631960863};\\\", \\\"{x:1339,y:728,t:1527631960878};\\\", \\\"{x:1338,y:731,t:1527631960895};\\\", \\\"{x:1337,y:733,t:1527631960912};\\\", \\\"{x:1335,y:734,t:1527631960928};\\\", \\\"{x:1334,y:735,t:1527631960946};\\\", \\\"{x:1334,y:737,t:1527631960962};\\\", \\\"{x:1333,y:739,t:1527631960979};\\\", \\\"{x:1332,y:744,t:1527631960996};\\\", \\\"{x:1329,y:748,t:1527631961012};\\\", \\\"{x:1327,y:753,t:1527631961029};\\\", \\\"{x:1327,y:755,t:1527631961044};\\\", \\\"{x:1326,y:756,t:1527631961062};\\\", \\\"{x:1325,y:757,t:1527631961101};\\\", \\\"{x:1325,y:759,t:1527631961132};\\\", \\\"{x:1324,y:760,t:1527631961189};\\\", \\\"{x:1324,y:761,t:1527631961205};\\\", \\\"{x:1322,y:763,t:1527631961221};\\\", \\\"{x:1322,y:764,t:1527631961237};\\\", \\\"{x:1321,y:765,t:1527631961246};\\\", \\\"{x:1321,y:766,t:1527631961263};\\\", \\\"{x:1320,y:766,t:1527631961285};\\\", \\\"{x:1319,y:766,t:1527631961301};\\\", \\\"{x:1318,y:767,t:1527631961341};\\\", \\\"{x:1317,y:767,t:1527631961350};\\\", \\\"{x:1316,y:767,t:1527631961366};\\\", \\\"{x:1316,y:768,t:1527631961406};\\\", \\\"{x:1315,y:768,t:1527631961430};\\\", \\\"{x:1315,y:771,t:1527631962438};\\\", \\\"{x:1315,y:772,t:1527631962446};\\\", \\\"{x:1314,y:773,t:1527631962464};\\\", \\\"{x:1313,y:773,t:1527631962480};\\\", \\\"{x:1312,y:774,t:1527631962518};\\\", \\\"{x:1312,y:775,t:1527631963254};\\\", \\\"{x:1312,y:777,t:1527631963265};\\\", \\\"{x:1312,y:782,t:1527631963281};\\\", \\\"{x:1312,y:787,t:1527631963298};\\\", \\\"{x:1312,y:793,t:1527631963315};\\\", \\\"{x:1312,y:806,t:1527631963331};\\\", \\\"{x:1314,y:822,t:1527631963348};\\\", \\\"{x:1316,y:834,t:1527631963365};\\\", \\\"{x:1320,y:848,t:1527631963380};\\\", \\\"{x:1331,y:870,t:1527631963397};\\\", \\\"{x:1335,y:879,t:1527631963415};\\\", \\\"{x:1337,y:883,t:1527631963431};\\\", \\\"{x:1338,y:885,t:1527631963447};\\\", \\\"{x:1339,y:886,t:1527631963465};\\\", \\\"{x:1339,y:887,t:1527631963481};\\\", \\\"{x:1339,y:889,t:1527631963497};\\\", \\\"{x:1341,y:892,t:1527631963515};\\\", \\\"{x:1342,y:895,t:1527631963533};\\\", \\\"{x:1343,y:896,t:1527631963548};\\\", \\\"{x:1344,y:899,t:1527631963564};\\\", \\\"{x:1345,y:901,t:1527631963580};\\\", \\\"{x:1346,y:902,t:1527631963597};\\\", \\\"{x:1348,y:902,t:1527631963615};\\\", \\\"{x:1351,y:902,t:1527631963631};\\\", \\\"{x:1354,y:902,t:1527631963648};\\\", \\\"{x:1357,y:902,t:1527631963664};\\\", \\\"{x:1358,y:902,t:1527631963681};\\\", \\\"{x:1359,y:902,t:1527631963733};\\\", \\\"{x:1358,y:902,t:1527631963884};\\\", \\\"{x:1358,y:901,t:1527631963897};\\\", \\\"{x:1357,y:901,t:1527631963915};\\\", \\\"{x:1355,y:901,t:1527631963933};\\\", \\\"{x:1354,y:901,t:1527631964133};\\\", \\\"{x:1353,y:901,t:1527631964366};\\\", \\\"{x:1352,y:901,t:1527631964381};\\\", \\\"{x:1351,y:901,t:1527631964439};\\\", \\\"{x:1350,y:901,t:1527631964465};\\\", \\\"{x:1349,y:901,t:1527631964482};\\\", \\\"{x:1348,y:901,t:1527631964509};\\\", \\\"{x:1347,y:901,t:1527631964525};\\\", \\\"{x:1345,y:901,t:1527631964541};\\\", \\\"{x:1345,y:902,t:1527631964566};\\\", \\\"{x:1344,y:902,t:1527631964598};\\\", \\\"{x:1344,y:903,t:1527631964629};\\\", \\\"{x:1343,y:903,t:1527631964701};\\\", \\\"{x:1342,y:903,t:1527631964788};\\\", \\\"{x:1341,y:904,t:1527631964925};\\\", \\\"{x:1341,y:905,t:1527631964948};\\\", \\\"{x:1339,y:905,t:1527631964964};\\\", \\\"{x:1338,y:906,t:1527631964982};\\\", \\\"{x:1335,y:908,t:1527631964998};\\\", \\\"{x:1332,y:910,t:1527631965015};\\\", \\\"{x:1329,y:911,t:1527631965032};\\\", \\\"{x:1327,y:913,t:1527631965049};\\\", \\\"{x:1318,y:921,t:1527631965066};\\\", \\\"{x:1311,y:926,t:1527631965083};\\\", \\\"{x:1308,y:928,t:1527631965098};\\\", \\\"{x:1308,y:929,t:1527631965141};\\\", \\\"{x:1308,y:930,t:1527631965214};\\\", \\\"{x:1307,y:931,t:1527631965237};\\\", \\\"{x:1307,y:932,t:1527631965318};\\\", \\\"{x:1306,y:933,t:1527631965390};\\\", \\\"{x:1306,y:961,t:1527631971957};\\\", \\\"{x:1309,y:1033,t:1527631971971};\\\", \\\"{x:1319,y:1162,t:1527631971988};\\\", \\\"{x:1348,y:1199,t:1527631972006};\\\", \\\"{x:1365,y:1199,t:1527631972021};\\\", \\\"{x:1381,y:1199,t:1527631972038};\\\", \\\"{x:1377,y:1199,t:1527631972055};\\\", \\\"{x:1356,y:1199,t:1527631972070};\\\", \\\"{x:1321,y:1199,t:1527631972088};\\\", \\\"{x:1274,y:1199,t:1527631972105};\\\", \\\"{x:1233,y:1199,t:1527631972121};\\\", \\\"{x:1184,y:1199,t:1527631972138};\\\", \\\"{x:1135,y:1199,t:1527631972155};\\\", \\\"{x:1076,y:1199,t:1527631972172};\\\", \\\"{x:1021,y:1199,t:1527631972187};\\\", \\\"{x:975,y:1199,t:1527631972205};\\\", \\\"{x:960,y:1199,t:1527631972221};\\\", \\\"{x:944,y:1199,t:1527631972238};\\\", \\\"{x:949,y:1199,t:1527631972254};\\\", \\\"{x:906,y:1199,t:1527631972272};\\\", \\\"{x:819,y:1199,t:1527631972288};\\\", \\\"{x:718,y:1199,t:1527631972305};\\\", \\\"{x:643,y:1199,t:1527631972321};\\\", \\\"{x:613,y:1199,t:1527631972339};\\\", \\\"{x:622,y:1199,t:1527631972355};\\\", \\\"{x:635,y:1199,t:1527631972372};\\\", \\\"{x:659,y:1199,t:1527631972389};\\\", \\\"{x:677,y:1199,t:1527631972405};\\\", \\\"{x:695,y:1199,t:1527631972422};\\\", \\\"{x:699,y:1199,t:1527631972439};\\\", \\\"{x:705,y:1199,t:1527631972456};\\\", \\\"{x:709,y:1199,t:1527631972471};\\\", \\\"{x:716,y:1199,t:1527631972489};\\\", \\\"{x:726,y:1199,t:1527631972505};\\\", \\\"{x:745,y:1199,t:1527631972522};\\\", \\\"{x:769,y:1199,t:1527631972539};\\\", \\\"{x:801,y:1199,t:1527631972556};\\\", \\\"{x:837,y:1199,t:1527631972572};\\\", \\\"{x:882,y:1199,t:1527631972589};\\\", \\\"{x:914,y:1199,t:1527631972605};\\\", \\\"{x:933,y:1197,t:1527631972623};\\\", \\\"{x:944,y:1192,t:1527631972639};\\\", \\\"{x:960,y:1182,t:1527631972656};\\\", \\\"{x:973,y:1169,t:1527631972673};\\\", \\\"{x:982,y:1149,t:1527631972688};\\\", \\\"{x:983,y:1133,t:1527631972705};\\\", \\\"{x:983,y:1130,t:1527631972720};\\\", \\\"{x:991,y:1117,t:1527631972790};\\\", \\\"{x:1055,y:1014,t:1527631972805};\\\", \\\"{x:1090,y:898,t:1527631972821};\\\", \\\"{x:1090,y:795,t:1527631972838};\\\", \\\"{x:1087,y:670,t:1527631972855};\\\", \\\"{x:1101,y:538,t:1527631972872};\\\", \\\"{x:1106,y:529,t:1527631972888};\\\", \\\"{x:1105,y:528,t:1527631972905};\\\", \\\"{x:1123,y:477,t:1527631972922};\\\", \\\"{x:1132,y:444,t:1527631972938};\\\", \\\"{x:1136,y:415,t:1527631972955};\\\", \\\"{x:1133,y:379,t:1527631972972};\\\", \\\"{x:1128,y:357,t:1527631972988};\\\", \\\"{x:1125,y:324,t:1527631973005};\\\", \\\"{x:1123,y:308,t:1527631973021};\\\", \\\"{x:1123,y:286,t:1527631973037};\\\", \\\"{x:1123,y:271,t:1527631973055};\\\", \\\"{x:1123,y:255,t:1527631973072};\\\", \\\"{x:1123,y:252,t:1527631973088};\\\", \\\"{x:1123,y:251,t:1527631973104};\\\", \\\"{x:1123,y:249,t:1527631973142};\\\", \\\"{x:1124,y:242,t:1527631973155};\\\", \\\"{x:1142,y:222,t:1527631973172};\\\", \\\"{x:1144,y:217,t:1527631973187};\\\", \\\"{x:1145,y:217,t:1527631973678};\\\", \\\"{x:1145,y:219,t:1527631973689};\\\", \\\"{x:1136,y:222,t:1527631973706};\\\", \\\"{x:1131,y:224,t:1527631973722};\\\", \\\"{x:1129,y:224,t:1527631973739};\\\", \\\"{x:1125,y:225,t:1527631973821};\\\", \\\"{x:1121,y:260,t:1527631973839};\\\", \\\"{x:1106,y:321,t:1527631973855};\\\", \\\"{x:1077,y:395,t:1527631973872};\\\", \\\"{x:1049,y:409,t:1527631973889};\\\", \\\"{x:1033,y:418,t:1527631973906};\\\", \\\"{x:1030,y:418,t:1527631973922};\\\", \\\"{x:1031,y:419,t:1527631974358};\\\", \\\"{x:1028,y:427,t:1527631974373};\\\", \\\"{x:1013,y:440,t:1527631974389};\\\", \\\"{x:981,y:462,t:1527631974406};\\\", \\\"{x:957,y:490,t:1527631974423};\\\", \\\"{x:928,y:526,t:1527631974440};\\\", \\\"{x:901,y:553,t:1527631974456};\\\", \\\"{x:887,y:566,t:1527631974472};\\\", \\\"{x:876,y:582,t:1527631974505};\\\", \\\"{x:873,y:596,t:1527631974523};\\\", \\\"{x:872,y:615,t:1527631974539};\\\", \\\"{x:864,y:625,t:1527631974555};\\\", \\\"{x:829,y:633,t:1527631974572};\\\", \\\"{x:811,y:637,t:1527631974590};\\\", \\\"{x:795,y:641,t:1527631974605};\\\", \\\"{x:786,y:641,t:1527631974623};\\\", \\\"{x:783,y:641,t:1527631974640};\\\", \\\"{x:782,y:640,t:1527631974656};\\\", \\\"{x:775,y:632,t:1527631974672};\\\", \\\"{x:765,y:627,t:1527631974689};\\\", \\\"{x:754,y:625,t:1527631974706};\\\", \\\"{x:742,y:620,t:1527631974722};\\\", \\\"{x:733,y:616,t:1527631974740};\\\", \\\"{x:728,y:612,t:1527631974755};\\\", \\\"{x:725,y:603,t:1527631974772};\\\", \\\"{x:725,y:592,t:1527631974790};\\\", \\\"{x:725,y:579,t:1527631974807};\\\", \\\"{x:731,y:565,t:1527631974822};\\\", \\\"{x:737,y:558,t:1527631974839};\\\", \\\"{x:744,y:554,t:1527631974856};\\\", \\\"{x:749,y:553,t:1527631974872};\\\", \\\"{x:760,y:549,t:1527631974890};\\\", \\\"{x:774,y:548,t:1527631974906};\\\", \\\"{x:783,y:545,t:1527631974923};\\\", \\\"{x:793,y:540,t:1527631974939};\\\", \\\"{x:797,y:539,t:1527631974956};\\\", \\\"{x:799,y:539,t:1527631974981};\\\", \\\"{x:800,y:539,t:1527631974996};\\\", \\\"{x:803,y:539,t:1527631975006};\\\", \\\"{x:806,y:539,t:1527631975023};\\\", \\\"{x:809,y:539,t:1527631975040};\\\", \\\"{x:813,y:539,t:1527631975057};\\\", \\\"{x:816,y:539,t:1527631975072};\\\", \\\"{x:825,y:535,t:1527631975090};\\\", \\\"{x:826,y:534,t:1527631975106};\\\", \\\"{x:827,y:534,t:1527631975122};\\\", \\\"{x:824,y:537,t:1527631975381};\\\", \\\"{x:815,y:544,t:1527631975390};\\\", \\\"{x:790,y:566,t:1527631975407};\\\", \\\"{x:768,y:587,t:1527631975423};\\\", \\\"{x:733,y:612,t:1527631975440};\\\", \\\"{x:710,y:632,t:1527631975457};\\\", \\\"{x:692,y:646,t:1527631975474};\\\", \\\"{x:677,y:655,t:1527631975490};\\\", \\\"{x:668,y:658,t:1527631975507};\\\", \\\"{x:661,y:663,t:1527631975524};\\\", \\\"{x:655,y:666,t:1527631975540};\\\", \\\"{x:640,y:673,t:1527631975557};\\\", \\\"{x:630,y:676,t:1527631975574};\\\", \\\"{x:624,y:679,t:1527631975590};\\\", \\\"{x:617,y:680,t:1527631975606};\\\", \\\"{x:607,y:681,t:1527631975623};\\\", \\\"{x:600,y:683,t:1527631975640};\\\", \\\"{x:590,y:684,t:1527631975657};\\\", \\\"{x:578,y:686,t:1527631975673};\\\", \\\"{x:567,y:690,t:1527631975689};\\\", \\\"{x:559,y:694,t:1527631975707};\\\", \\\"{x:554,y:697,t:1527631975724};\\\", \\\"{x:548,y:700,t:1527631975740};\\\", \\\"{x:539,y:706,t:1527631975756};\\\", \\\"{x:532,y:709,t:1527631975773};\\\", \\\"{x:528,y:711,t:1527631975790};\\\", \\\"{x:524,y:715,t:1527631975807};\\\", \\\"{x:522,y:716,t:1527631975824};\\\", \\\"{x:520,y:719,t:1527631975840};\\\", \\\"{x:517,y:723,t:1527631975857};\\\", \\\"{x:517,y:724,t:1527631975874};\\\", \\\"{x:517,y:725,t:1527631977718};\\\", \\\"{x:532,y:718,t:1527631977725};\\\", \\\"{x:555,y:703,t:1527631977742};\\\", \\\"{x:566,y:684,t:1527631977759};\\\", \\\"{x:576,y:649,t:1527631977774};\\\", \\\"{x:586,y:613,t:1527631977792};\\\", \\\"{x:602,y:582,t:1527631977809};\\\", \\\"{x:605,y:549,t:1527631977825};\\\", \\\"{x:606,y:518,t:1527631977841};\\\", \\\"{x:606,y:488,t:1527631977859};\\\", \\\"{x:609,y:454,t:1527631977874};\\\", \\\"{x:615,y:425,t:1527631977891};\\\", \\\"{x:618,y:389,t:1527631977908};\\\", \\\"{x:618,y:329,t:1527631977973};\\\", \\\"{x:620,y:320,t:1527631977995};\\\", \\\"{x:621,y:312,t:1527631978008};\\\", \\\"{x:623,y:300,t:1527631978025};\\\", \\\"{x:623,y:294,t:1527631978041};\\\", \\\"{x:623,y:290,t:1527631978059};\\\", \\\"{x:623,y:284,t:1527631978076};\\\", \\\"{x:624,y:281,t:1527631978092};\\\", \\\"{x:624,y:279,t:1527631978109};\\\", \\\"{x:624,y:278,t:1527631978124};\\\" ] }, { \\\"rt\\\": 21761, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 599145, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-08 AM-09 AM-10 AM-12 PM-01 PM-02 PM-02 PM-10 AM-12 PM-01 PM-02 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:629,y:278,t:1527631980348};\\\", \\\"{x:639,y:279,t:1527631980360};\\\", \\\"{x:686,y:292,t:1527631980377};\\\", \\\"{x:796,y:314,t:1527631980394};\\\", \\\"{x:926,y:329,t:1527631980411};\\\", \\\"{x:1065,y:335,t:1527631980427};\\\", \\\"{x:1196,y:340,t:1527631980444};\\\", \\\"{x:1367,y:340,t:1527631980461};\\\", \\\"{x:1478,y:340,t:1527631980477};\\\", \\\"{x:1594,y:350,t:1527631980493};\\\", \\\"{x:1680,y:354,t:1527631980511};\\\", \\\"{x:1737,y:363,t:1527631980526};\\\", \\\"{x:1768,y:368,t:1527631980544};\\\", \\\"{x:1783,y:373,t:1527631980560};\\\", \\\"{x:1786,y:375,t:1527631980577};\\\", \\\"{x:1786,y:376,t:1527631980594};\\\", \\\"{x:1791,y:386,t:1527631980611};\\\", \\\"{x:1799,y:436,t:1527631980626};\\\", \\\"{x:1799,y:544,t:1527631980644};\\\", \\\"{x:1762,y:706,t:1527631980660};\\\", \\\"{x:1722,y:779,t:1527631980677};\\\", \\\"{x:1679,y:841,t:1527631980694};\\\", \\\"{x:1621,y:915,t:1527631980711};\\\", \\\"{x:1572,y:984,t:1527631980727};\\\", \\\"{x:1533,y:1053,t:1527631980744};\\\", \\\"{x:1512,y:1081,t:1527631980761};\\\", \\\"{x:1501,y:1090,t:1527631980777};\\\", \\\"{x:1496,y:1095,t:1527631980794};\\\", \\\"{x:1496,y:1097,t:1527631980812};\\\", \\\"{x:1496,y:1098,t:1527631980827};\\\", \\\"{x:1496,y:1104,t:1527631980844};\\\", \\\"{x:1496,y:1107,t:1527631980861};\\\", \\\"{x:1492,y:1107,t:1527631980934};\\\", \\\"{x:1487,y:1103,t:1527631980944};\\\", \\\"{x:1478,y:1097,t:1527631980961};\\\", \\\"{x:1460,y:1086,t:1527631980978};\\\", \\\"{x:1447,y:1073,t:1527631980994};\\\", \\\"{x:1433,y:1055,t:1527631981011};\\\", \\\"{x:1420,y:1038,t:1527631981029};\\\", \\\"{x:1411,y:1026,t:1527631981044};\\\", \\\"{x:1409,y:1022,t:1527631981061};\\\", \\\"{x:1409,y:1021,t:1527631981132};\\\", \\\"{x:1408,y:1021,t:1527631981197};\\\", \\\"{x:1406,y:1020,t:1527631981210};\\\", \\\"{x:1389,y:1016,t:1527631981228};\\\", \\\"{x:1367,y:1013,t:1527631981244};\\\", \\\"{x:1340,y:1008,t:1527631981261};\\\", \\\"{x:1316,y:1004,t:1527631981278};\\\", \\\"{x:1292,y:1000,t:1527631981295};\\\", \\\"{x:1268,y:997,t:1527631981311};\\\", \\\"{x:1238,y:992,t:1527631981328};\\\", \\\"{x:1211,y:987,t:1527631981345};\\\", \\\"{x:1175,y:981,t:1527631981361};\\\", \\\"{x:1144,y:980,t:1527631981378};\\\", \\\"{x:1127,y:979,t:1527631981396};\\\", \\\"{x:1123,y:979,t:1527631981411};\\\", \\\"{x:1118,y:977,t:1527631981428};\\\", \\\"{x:1115,y:977,t:1527631981445};\\\", \\\"{x:1114,y:976,t:1527631981461};\\\", \\\"{x:1112,y:975,t:1527631981479};\\\", \\\"{x:1111,y:975,t:1527631981495};\\\", \\\"{x:1109,y:975,t:1527631981822};\\\", \\\"{x:1106,y:974,t:1527631981829};\\\", \\\"{x:1102,y:972,t:1527631981845};\\\", \\\"{x:1098,y:972,t:1527631981863};\\\", \\\"{x:1096,y:972,t:1527631981902};\\\", \\\"{x:1095,y:971,t:1527631981913};\\\", \\\"{x:1095,y:970,t:1527631981929};\\\", \\\"{x:1101,y:970,t:1527631982301};\\\", \\\"{x:1108,y:970,t:1527631982312};\\\", \\\"{x:1124,y:970,t:1527631982328};\\\", \\\"{x:1142,y:970,t:1527631982345};\\\", \\\"{x:1155,y:970,t:1527631982362};\\\", \\\"{x:1159,y:971,t:1527631982379};\\\", \\\"{x:1160,y:971,t:1527631982421};\\\", \\\"{x:1160,y:972,t:1527631982886};\\\", \\\"{x:1161,y:972,t:1527631983294};\\\", \\\"{x:1162,y:972,t:1527631983301};\\\", \\\"{x:1163,y:972,t:1527631983317};\\\", \\\"{x:1165,y:972,t:1527631983329};\\\", \\\"{x:1167,y:972,t:1527631983347};\\\", \\\"{x:1172,y:973,t:1527631983364};\\\", \\\"{x:1175,y:973,t:1527631983380};\\\", \\\"{x:1180,y:973,t:1527631983396};\\\", \\\"{x:1191,y:973,t:1527631983413};\\\", \\\"{x:1199,y:973,t:1527631983430};\\\", \\\"{x:1207,y:973,t:1527631983446};\\\", \\\"{x:1219,y:973,t:1527631983464};\\\", \\\"{x:1225,y:973,t:1527631983479};\\\", \\\"{x:1237,y:972,t:1527631983496};\\\", \\\"{x:1251,y:969,t:1527631983514};\\\", \\\"{x:1265,y:967,t:1527631983530};\\\", \\\"{x:1275,y:966,t:1527631983547};\\\", \\\"{x:1279,y:963,t:1527631983564};\\\", \\\"{x:1288,y:958,t:1527631983580};\\\", \\\"{x:1290,y:955,t:1527631983596};\\\", \\\"{x:1297,y:941,t:1527631983613};\\\", \\\"{x:1304,y:916,t:1527631983629};\\\", \\\"{x:1308,y:890,t:1527631983647};\\\", \\\"{x:1308,y:864,t:1527631983663};\\\", \\\"{x:1305,y:841,t:1527631983679};\\\", \\\"{x:1298,y:817,t:1527631983696};\\\", \\\"{x:1289,y:790,t:1527631983713};\\\", \\\"{x:1280,y:759,t:1527631983730};\\\", \\\"{x:1276,y:737,t:1527631983746};\\\", \\\"{x:1274,y:716,t:1527631983764};\\\", \\\"{x:1274,y:694,t:1527631983780};\\\", \\\"{x:1272,y:670,t:1527631983797};\\\", \\\"{x:1270,y:642,t:1527631983813};\\\", \\\"{x:1266,y:630,t:1527631983831};\\\", \\\"{x:1266,y:622,t:1527631983847};\\\", \\\"{x:1266,y:620,t:1527631983864};\\\", \\\"{x:1266,y:619,t:1527631983942};\\\", \\\"{x:1266,y:617,t:1527631983949};\\\", \\\"{x:1266,y:615,t:1527631983964};\\\", \\\"{x:1266,y:613,t:1527631983980};\\\", \\\"{x:1266,y:612,t:1527631983996};\\\", \\\"{x:1260,y:621,t:1527631984101};\\\", \\\"{x:1253,y:636,t:1527631984114};\\\", \\\"{x:1239,y:660,t:1527631984130};\\\", \\\"{x:1233,y:682,t:1527631984146};\\\", \\\"{x:1225,y:709,t:1527631984163};\\\", \\\"{x:1218,y:736,t:1527631984180};\\\", \\\"{x:1191,y:792,t:1527631984197};\\\", \\\"{x:1172,y:828,t:1527631984214};\\\", \\\"{x:1155,y:858,t:1527631984230};\\\", \\\"{x:1140,y:887,t:1527631984247};\\\", \\\"{x:1132,y:906,t:1527631984263};\\\", \\\"{x:1124,y:922,t:1527631984280};\\\", \\\"{x:1118,y:939,t:1527631984298};\\\", \\\"{x:1113,y:955,t:1527631984313};\\\", \\\"{x:1112,y:961,t:1527631984330};\\\", \\\"{x:1111,y:968,t:1527631984347};\\\", \\\"{x:1109,y:972,t:1527631984364};\\\", \\\"{x:1109,y:974,t:1527631984380};\\\", \\\"{x:1107,y:980,t:1527631984397};\\\", \\\"{x:1107,y:982,t:1527631984413};\\\", \\\"{x:1107,y:985,t:1527631984430};\\\", \\\"{x:1107,y:986,t:1527631984447};\\\", \\\"{x:1109,y:987,t:1527631984541};\\\", \\\"{x:1112,y:987,t:1527631984549};\\\", \\\"{x:1116,y:989,t:1527631984563};\\\", \\\"{x:1126,y:990,t:1527631984580};\\\", \\\"{x:1148,y:990,t:1527631984597};\\\", \\\"{x:1167,y:990,t:1527631984614};\\\", \\\"{x:1181,y:990,t:1527631984631};\\\", \\\"{x:1199,y:990,t:1527631984647};\\\", \\\"{x:1224,y:990,t:1527631984664};\\\", \\\"{x:1248,y:990,t:1527631984681};\\\", \\\"{x:1273,y:990,t:1527631984697};\\\", \\\"{x:1296,y:986,t:1527631984714};\\\", \\\"{x:1311,y:983,t:1527631984730};\\\", \\\"{x:1324,y:981,t:1527631984747};\\\", \\\"{x:1339,y:981,t:1527631984765};\\\", \\\"{x:1357,y:979,t:1527631984780};\\\", \\\"{x:1383,y:979,t:1527631984798};\\\", \\\"{x:1394,y:977,t:1527631984814};\\\", \\\"{x:1403,y:976,t:1527631984830};\\\", \\\"{x:1411,y:976,t:1527631984847};\\\", \\\"{x:1419,y:976,t:1527631984864};\\\", \\\"{x:1422,y:974,t:1527631984880};\\\", \\\"{x:1427,y:974,t:1527631984897};\\\", \\\"{x:1429,y:974,t:1527631984914};\\\", \\\"{x:1430,y:973,t:1527631984930};\\\", \\\"{x:1431,y:973,t:1527631984956};\\\", \\\"{x:1433,y:973,t:1527631984964};\\\", \\\"{x:1436,y:973,t:1527631984980};\\\", \\\"{x:1446,y:975,t:1527631984997};\\\", \\\"{x:1451,y:975,t:1527631985014};\\\", \\\"{x:1459,y:976,t:1527631985031};\\\", \\\"{x:1471,y:977,t:1527631985048};\\\", \\\"{x:1480,y:980,t:1527631985064};\\\", \\\"{x:1489,y:980,t:1527631985080};\\\", \\\"{x:1497,y:980,t:1527631985097};\\\", \\\"{x:1501,y:980,t:1527631985114};\\\", \\\"{x:1503,y:981,t:1527631985130};\\\", \\\"{x:1503,y:982,t:1527631985469};\\\", \\\"{x:1501,y:982,t:1527631985550};\\\", \\\"{x:1500,y:978,t:1527631985564};\\\", \\\"{x:1482,y:960,t:1527631985581};\\\", \\\"{x:1467,y:939,t:1527631985599};\\\", \\\"{x:1456,y:918,t:1527631985615};\\\", \\\"{x:1444,y:894,t:1527631985631};\\\", \\\"{x:1442,y:874,t:1527631985649};\\\", \\\"{x:1440,y:849,t:1527631985665};\\\", \\\"{x:1441,y:830,t:1527631985681};\\\", \\\"{x:1441,y:813,t:1527631985699};\\\", \\\"{x:1441,y:803,t:1527631985714};\\\", \\\"{x:1441,y:797,t:1527631985731};\\\", \\\"{x:1442,y:783,t:1527631985749};\\\", \\\"{x:1445,y:768,t:1527631985765};\\\", \\\"{x:1447,y:756,t:1527631985782};\\\", \\\"{x:1447,y:744,t:1527631985799};\\\", \\\"{x:1447,y:737,t:1527631985814};\\\", \\\"{x:1447,y:725,t:1527631985832};\\\", \\\"{x:1442,y:704,t:1527631985848};\\\", \\\"{x:1438,y:688,t:1527631985865};\\\", \\\"{x:1432,y:673,t:1527631985881};\\\", \\\"{x:1427,y:658,t:1527631985898};\\\", \\\"{x:1423,y:649,t:1527631985914};\\\", \\\"{x:1422,y:643,t:1527631985932};\\\", \\\"{x:1419,y:633,t:1527631985949};\\\", \\\"{x:1417,y:630,t:1527631985965};\\\", \\\"{x:1415,y:625,t:1527631985982};\\\", \\\"{x:1415,y:626,t:1527631986045};\\\", \\\"{x:1413,y:634,t:1527631986053};\\\", \\\"{x:1408,y:647,t:1527631986066};\\\", \\\"{x:1395,y:679,t:1527631986082};\\\", \\\"{x:1376,y:721,t:1527631986098};\\\", \\\"{x:1362,y:754,t:1527631986116};\\\", \\\"{x:1351,y:779,t:1527631986132};\\\", \\\"{x:1343,y:796,t:1527631986148};\\\", \\\"{x:1340,y:808,t:1527631986165};\\\", \\\"{x:1338,y:816,t:1527631986182};\\\", \\\"{x:1335,y:826,t:1527631986199};\\\", \\\"{x:1330,y:842,t:1527631986216};\\\", \\\"{x:1326,y:856,t:1527631986232};\\\", \\\"{x:1323,y:868,t:1527631986249};\\\", \\\"{x:1314,y:881,t:1527631986265};\\\", \\\"{x:1308,y:892,t:1527631986282};\\\", \\\"{x:1302,y:907,t:1527631986299};\\\", \\\"{x:1297,y:919,t:1527631986316};\\\", \\\"{x:1292,y:931,t:1527631986332};\\\", \\\"{x:1284,y:943,t:1527631986349};\\\", \\\"{x:1267,y:960,t:1527631986365};\\\", \\\"{x:1256,y:972,t:1527631986381};\\\", \\\"{x:1244,y:980,t:1527631986399};\\\", \\\"{x:1239,y:986,t:1527631986416};\\\", \\\"{x:1232,y:992,t:1527631986431};\\\", \\\"{x:1229,y:994,t:1527631986449};\\\", \\\"{x:1227,y:996,t:1527631986465};\\\", \\\"{x:1224,y:999,t:1527631986481};\\\", \\\"{x:1222,y:1000,t:1527631986499};\\\", \\\"{x:1221,y:1002,t:1527631986516};\\\", \\\"{x:1220,y:1003,t:1527631986558};\\\", \\\"{x:1220,y:1002,t:1527631986982};\\\", \\\"{x:1220,y:999,t:1527631986998};\\\", \\\"{x:1220,y:995,t:1527631987015};\\\", \\\"{x:1221,y:992,t:1527631987033};\\\", \\\"{x:1222,y:990,t:1527631987050};\\\", \\\"{x:1223,y:988,t:1527631987065};\\\", \\\"{x:1223,y:986,t:1527631987092};\\\", \\\"{x:1223,y:985,t:1527631987181};\\\", \\\"{x:1223,y:982,t:1527631987200};\\\", \\\"{x:1223,y:980,t:1527631987216};\\\", \\\"{x:1223,y:978,t:1527631987233};\\\", \\\"{x:1225,y:975,t:1527631987249};\\\", \\\"{x:1229,y:972,t:1527631987265};\\\", \\\"{x:1234,y:970,t:1527631987283};\\\", \\\"{x:1243,y:968,t:1527631987300};\\\", \\\"{x:1251,y:967,t:1527631987316};\\\", \\\"{x:1257,y:967,t:1527631987333};\\\", \\\"{x:1262,y:967,t:1527631987349};\\\", \\\"{x:1264,y:967,t:1527631987366};\\\", \\\"{x:1267,y:967,t:1527631987383};\\\", \\\"{x:1268,y:967,t:1527631987400};\\\", \\\"{x:1270,y:967,t:1527631987565};\\\", \\\"{x:1272,y:967,t:1527631987583};\\\", \\\"{x:1276,y:967,t:1527631987600};\\\", \\\"{x:1279,y:967,t:1527631987616};\\\", \\\"{x:1286,y:967,t:1527631987633};\\\", \\\"{x:1293,y:967,t:1527631987650};\\\", \\\"{x:1296,y:968,t:1527631987666};\\\", \\\"{x:1302,y:969,t:1527631987683};\\\", \\\"{x:1304,y:969,t:1527631987700};\\\", \\\"{x:1305,y:969,t:1527631987716};\\\", \\\"{x:1306,y:970,t:1527631987757};\\\", \\\"{x:1307,y:971,t:1527631987766};\\\", \\\"{x:1310,y:972,t:1527631987782};\\\", \\\"{x:1314,y:974,t:1527631987798};\\\", \\\"{x:1317,y:975,t:1527631987816};\\\", \\\"{x:1323,y:975,t:1527631987832};\\\", \\\"{x:1328,y:976,t:1527631987849};\\\", \\\"{x:1334,y:976,t:1527631987865};\\\", \\\"{x:1338,y:976,t:1527631987882};\\\", \\\"{x:1339,y:976,t:1527631987908};\\\", \\\"{x:1340,y:976,t:1527631987957};\\\", \\\"{x:1341,y:975,t:1527631987966};\\\", \\\"{x:1349,y:973,t:1527631987983};\\\", \\\"{x:1354,y:972,t:1527631987999};\\\", \\\"{x:1357,y:971,t:1527631988016};\\\", \\\"{x:1358,y:971,t:1527631988033};\\\", \\\"{x:1359,y:971,t:1527631988173};\\\", \\\"{x:1360,y:971,t:1527631988183};\\\", \\\"{x:1364,y:971,t:1527631988199};\\\", \\\"{x:1368,y:971,t:1527631988216};\\\", \\\"{x:1372,y:971,t:1527631988233};\\\", \\\"{x:1379,y:971,t:1527631988249};\\\", \\\"{x:1385,y:971,t:1527631988266};\\\", \\\"{x:1393,y:971,t:1527631988283};\\\", \\\"{x:1404,y:971,t:1527631988299};\\\", \\\"{x:1418,y:971,t:1527631988316};\\\", \\\"{x:1425,y:971,t:1527631988332};\\\", \\\"{x:1429,y:971,t:1527631988349};\\\", \\\"{x:1430,y:971,t:1527631988366};\\\", \\\"{x:1431,y:971,t:1527631988383};\\\", \\\"{x:1432,y:972,t:1527631988646};\\\", \\\"{x:1433,y:972,t:1527631988653};\\\", \\\"{x:1434,y:973,t:1527631988666};\\\", \\\"{x:1434,y:974,t:1527631988683};\\\", \\\"{x:1437,y:975,t:1527631988701};\\\", \\\"{x:1440,y:975,t:1527631988717};\\\", \\\"{x:1444,y:975,t:1527631988733};\\\", \\\"{x:1449,y:975,t:1527631988750};\\\", \\\"{x:1457,y:975,t:1527631988766};\\\", \\\"{x:1467,y:975,t:1527631988784};\\\", \\\"{x:1478,y:975,t:1527631988800};\\\", \\\"{x:1487,y:975,t:1527631988816};\\\", \\\"{x:1493,y:975,t:1527631988834};\\\", \\\"{x:1497,y:975,t:1527631988850};\\\", \\\"{x:1500,y:975,t:1527631989213};\\\", \\\"{x:1503,y:975,t:1527631989222};\\\", \\\"{x:1505,y:975,t:1527631989234};\\\", \\\"{x:1513,y:975,t:1527631989251};\\\", \\\"{x:1519,y:975,t:1527631989267};\\\", \\\"{x:1525,y:975,t:1527631989284};\\\", \\\"{x:1530,y:975,t:1527631989301};\\\", \\\"{x:1534,y:975,t:1527631989317};\\\", \\\"{x:1535,y:975,t:1527631989334};\\\", \\\"{x:1536,y:975,t:1527631989725};\\\", \\\"{x:1537,y:975,t:1527631989782};\\\", \\\"{x:1538,y:975,t:1527631989886};\\\", \\\"{x:1539,y:975,t:1527631989975};\\\", \\\"{x:1541,y:976,t:1527631990029};\\\", \\\"{x:1541,y:977,t:1527631990061};\\\", \\\"{x:1542,y:977,t:1527631990077};\\\", \\\"{x:1543,y:977,t:1527631990093};\\\", \\\"{x:1544,y:978,t:1527631990101};\\\", \\\"{x:1546,y:979,t:1527631990118};\\\", \\\"{x:1549,y:979,t:1527631990135};\\\", \\\"{x:1551,y:980,t:1527631990152};\\\", \\\"{x:1554,y:981,t:1527631990168};\\\", \\\"{x:1557,y:981,t:1527631990185};\\\", \\\"{x:1561,y:983,t:1527631990201};\\\", \\\"{x:1564,y:983,t:1527631990217};\\\", \\\"{x:1566,y:984,t:1527631990235};\\\", \\\"{x:1568,y:985,t:1527631990253};\\\", \\\"{x:1570,y:987,t:1527631990268};\\\", \\\"{x:1571,y:987,t:1527631990285};\\\", \\\"{x:1573,y:987,t:1527631990301};\\\", \\\"{x:1574,y:987,t:1527631990317};\\\", \\\"{x:1578,y:987,t:1527631990334};\\\", \\\"{x:1580,y:987,t:1527631990352};\\\", \\\"{x:1584,y:987,t:1527631990369};\\\", \\\"{x:1585,y:987,t:1527631990385};\\\", \\\"{x:1590,y:987,t:1527631990402};\\\", \\\"{x:1593,y:987,t:1527631990418};\\\", \\\"{x:1598,y:987,t:1527631990434};\\\", \\\"{x:1603,y:987,t:1527631990452};\\\", \\\"{x:1609,y:987,t:1527631990469};\\\", \\\"{x:1610,y:987,t:1527631990485};\\\", \\\"{x:1612,y:987,t:1527631990501};\\\", \\\"{x:1613,y:987,t:1527631990525};\\\", \\\"{x:1614,y:987,t:1527631991158};\\\", \\\"{x:1614,y:984,t:1527631992077};\\\", \\\"{x:1606,y:975,t:1527631992085};\\\", \\\"{x:1585,y:944,t:1527631992103};\\\", \\\"{x:1554,y:897,t:1527631992120};\\\", \\\"{x:1514,y:841,t:1527631992136};\\\", \\\"{x:1477,y:770,t:1527631992153};\\\", \\\"{x:1419,y:690,t:1527631992170};\\\", \\\"{x:1369,y:615,t:1527631992185};\\\", \\\"{x:1335,y:538,t:1527631992203};\\\", \\\"{x:1315,y:478,t:1527631992220};\\\", \\\"{x:1310,y:448,t:1527631992236};\\\", \\\"{x:1309,y:417,t:1527631992253};\\\", \\\"{x:1313,y:387,t:1527631992269};\\\", \\\"{x:1314,y:369,t:1527631992287};\\\", \\\"{x:1314,y:362,t:1527631992303};\\\", \\\"{x:1314,y:358,t:1527631992320};\\\", \\\"{x:1315,y:357,t:1527631992337};\\\", \\\"{x:1317,y:357,t:1527631992421};\\\", \\\"{x:1333,y:376,t:1527631992437};\\\", \\\"{x:1352,y:397,t:1527631992453};\\\", \\\"{x:1368,y:419,t:1527631992470};\\\", \\\"{x:1376,y:431,t:1527631992487};\\\", \\\"{x:1382,y:441,t:1527631992503};\\\", \\\"{x:1386,y:450,t:1527631992520};\\\", \\\"{x:1392,y:462,t:1527631992537};\\\", \\\"{x:1396,y:474,t:1527631992553};\\\", \\\"{x:1396,y:482,t:1527631992570};\\\", \\\"{x:1397,y:491,t:1527631992586};\\\", \\\"{x:1398,y:500,t:1527631992603};\\\", \\\"{x:1398,y:506,t:1527631992620};\\\", \\\"{x:1398,y:514,t:1527631992637};\\\", \\\"{x:1387,y:521,t:1527631992653};\\\", \\\"{x:1355,y:527,t:1527631992670};\\\", \\\"{x:1299,y:536,t:1527631992687};\\\", \\\"{x:1224,y:546,t:1527631992703};\\\", \\\"{x:1130,y:554,t:1527631992720};\\\", \\\"{x:1031,y:554,t:1527631992737};\\\", \\\"{x:925,y:554,t:1527631992756};\\\", \\\"{x:840,y:561,t:1527631992769};\\\", \\\"{x:794,y:561,t:1527631992803};\\\", \\\"{x:789,y:561,t:1527631992816};\\\", \\\"{x:788,y:561,t:1527631992831};\\\", \\\"{x:786,y:561,t:1527631992908};\\\", \\\"{x:785,y:561,t:1527631992924};\\\", \\\"{x:787,y:562,t:1527631993422};\\\", \\\"{x:793,y:564,t:1527631993434};\\\", \\\"{x:798,y:565,t:1527631993448};\\\", \\\"{x:799,y:567,t:1527631993733};\\\", \\\"{x:800,y:567,t:1527631993741};\\\", \\\"{x:802,y:567,t:1527631993755};\\\", \\\"{x:810,y:570,t:1527631993772};\\\", \\\"{x:820,y:573,t:1527631993790};\\\", \\\"{x:831,y:574,t:1527631993805};\\\", \\\"{x:846,y:577,t:1527631993823};\\\", \\\"{x:879,y:578,t:1527631993838};\\\", \\\"{x:918,y:578,t:1527631993854};\\\", \\\"{x:953,y:578,t:1527631993871};\\\", \\\"{x:973,y:578,t:1527631993888};\\\", \\\"{x:987,y:578,t:1527631993904};\\\", \\\"{x:1001,y:578,t:1527631993921};\\\", \\\"{x:1012,y:578,t:1527631993939};\\\", \\\"{x:1019,y:578,t:1527631993954};\\\", \\\"{x:1022,y:578,t:1527631993971};\\\", \\\"{x:1022,y:577,t:1527631993988};\\\", \\\"{x:1023,y:575,t:1527631994028};\\\", \\\"{x:1027,y:574,t:1527631994053};\\\", \\\"{x:1029,y:574,t:1527631994061};\\\", \\\"{x:1032,y:574,t:1527631994072};\\\", \\\"{x:1038,y:573,t:1527631994089};\\\", \\\"{x:1044,y:573,t:1527631994105};\\\", \\\"{x:1048,y:573,t:1527631994122};\\\", \\\"{x:1053,y:573,t:1527631994139};\\\", \\\"{x:1055,y:573,t:1527631994156};\\\", \\\"{x:1056,y:573,t:1527631994181};\\\", \\\"{x:1057,y:573,t:1527631994197};\\\", \\\"{x:1058,y:573,t:1527631994206};\\\", \\\"{x:1059,y:573,t:1527631994222};\\\", \\\"{x:1060,y:573,t:1527631994239};\\\", \\\"{x:1061,y:574,t:1527631994256};\\\", \\\"{x:1062,y:574,t:1527631994277};\\\", \\\"{x:1063,y:574,t:1527631994422};\\\", \\\"{x:1063,y:575,t:1527631994429};\\\", \\\"{x:1066,y:577,t:1527631994439};\\\", \\\"{x:1082,y:583,t:1527631994456};\\\", \\\"{x:1098,y:589,t:1527631994474};\\\", \\\"{x:1115,y:595,t:1527631994490};\\\", \\\"{x:1133,y:599,t:1527631994505};\\\", \\\"{x:1151,y:602,t:1527631994523};\\\", \\\"{x:1171,y:606,t:1527631994540};\\\", \\\"{x:1192,y:609,t:1527631994556};\\\", \\\"{x:1215,y:611,t:1527631994572};\\\", \\\"{x:1223,y:611,t:1527631994590};\\\", \\\"{x:1225,y:611,t:1527631994606};\\\", \\\"{x:1226,y:611,t:1527631994709};\\\", \\\"{x:1228,y:611,t:1527631994723};\\\", \\\"{x:1230,y:611,t:1527631994739};\\\", \\\"{x:1238,y:602,t:1527631994757};\\\", \\\"{x:1245,y:589,t:1527631994772};\\\", \\\"{x:1250,y:579,t:1527631994789};\\\", \\\"{x:1251,y:576,t:1527631994807};\\\", \\\"{x:1252,y:576,t:1527631994917};\\\", \\\"{x:1248,y:576,t:1527631995037};\\\", \\\"{x:1241,y:576,t:1527631995044};\\\", \\\"{x:1225,y:581,t:1527631995057};\\\", \\\"{x:1178,y:587,t:1527631995074};\\\", \\\"{x:1094,y:600,t:1527631995091};\\\", \\\"{x:986,y:614,t:1527631995107};\\\", \\\"{x:846,y:626,t:1527631995125};\\\", \\\"{x:638,y:628,t:1527631995140};\\\", \\\"{x:586,y:628,t:1527631995155};\\\", \\\"{x:419,y:630,t:1527631995173};\\\", \\\"{x:338,y:630,t:1527631995189};\\\", \\\"{x:274,y:630,t:1527631995205};\\\", \\\"{x:251,y:630,t:1527631995223};\\\", \\\"{x:244,y:630,t:1527631995238};\\\", \\\"{x:243,y:630,t:1527631995255};\\\", \\\"{x:242,y:629,t:1527631995284};\\\", \\\"{x:241,y:629,t:1527631995299};\\\", \\\"{x:239,y:629,t:1527631995316};\\\", \\\"{x:237,y:629,t:1527631995324};\\\", \\\"{x:232,y:628,t:1527631995339};\\\", \\\"{x:224,y:621,t:1527631995356};\\\", \\\"{x:222,y:618,t:1527631995372};\\\", \\\"{x:220,y:612,t:1527631995389};\\\", \\\"{x:218,y:600,t:1527631995407};\\\", \\\"{x:216,y:585,t:1527631995423};\\\", \\\"{x:212,y:569,t:1527631995439};\\\", \\\"{x:210,y:558,t:1527631995456};\\\", \\\"{x:205,y:548,t:1527631995474};\\\", \\\"{x:202,y:543,t:1527631995489};\\\", \\\"{x:201,y:542,t:1527631995505};\\\", \\\"{x:200,y:541,t:1527631995589};\\\", \\\"{x:198,y:541,t:1527631995606};\\\", \\\"{x:192,y:541,t:1527631995622};\\\", \\\"{x:181,y:548,t:1527631995640};\\\", \\\"{x:175,y:553,t:1527631995656};\\\", \\\"{x:169,y:557,t:1527631995672};\\\", \\\"{x:167,y:558,t:1527631995689};\\\", \\\"{x:167,y:559,t:1527631995707};\\\", \\\"{x:171,y:559,t:1527631995732};\\\", \\\"{x:181,y:559,t:1527631995740};\\\", \\\"{x:209,y:559,t:1527631995756};\\\", \\\"{x:261,y:554,t:1527631995773};\\\", \\\"{x:353,y:536,t:1527631995790};\\\", \\\"{x:444,y:527,t:1527631995805};\\\", \\\"{x:527,y:518,t:1527631995823};\\\", \\\"{x:561,y:511,t:1527631995839};\\\", \\\"{x:589,y:508,t:1527631995856};\\\", \\\"{x:612,y:507,t:1527631995874};\\\", \\\"{x:620,y:506,t:1527631995889};\\\", \\\"{x:622,y:506,t:1527631995908};\\\", \\\"{x:623,y:505,t:1527631995922};\\\", \\\"{x:626,y:504,t:1527631995939};\\\", \\\"{x:627,y:503,t:1527631995957};\\\", \\\"{x:626,y:503,t:1527631996053};\\\", \\\"{x:623,y:503,t:1527631996061};\\\", \\\"{x:621,y:503,t:1527631996076};\\\", \\\"{x:620,y:503,t:1527631996093};\\\", \\\"{x:619,y:503,t:1527631996106};\\\", \\\"{x:618,y:503,t:1527631996124};\\\", \\\"{x:616,y:503,t:1527631996140};\\\", \\\"{x:613,y:503,t:1527631996157};\\\", \\\"{x:610,y:504,t:1527631996541};\\\", \\\"{x:628,y:513,t:1527631996557};\\\", \\\"{x:654,y:516,t:1527631996573};\\\", \\\"{x:674,y:516,t:1527631996590};\\\", \\\"{x:695,y:516,t:1527631996606};\\\", \\\"{x:710,y:516,t:1527631996623};\\\", \\\"{x:719,y:516,t:1527631996640};\\\", \\\"{x:725,y:516,t:1527631996657};\\\", \\\"{x:729,y:516,t:1527631996674};\\\", \\\"{x:735,y:516,t:1527631996690};\\\", \\\"{x:740,y:518,t:1527631996707};\\\", \\\"{x:747,y:518,t:1527631996723};\\\", \\\"{x:756,y:519,t:1527631996740};\\\", \\\"{x:760,y:519,t:1527631996757};\\\", \\\"{x:764,y:519,t:1527631996775};\\\", \\\"{x:767,y:519,t:1527631996790};\\\", \\\"{x:771,y:520,t:1527631996807};\\\", \\\"{x:776,y:523,t:1527631996824};\\\", \\\"{x:779,y:525,t:1527631996841};\\\", \\\"{x:783,y:528,t:1527631996858};\\\", \\\"{x:790,y:531,t:1527631996874};\\\", \\\"{x:797,y:534,t:1527631996890};\\\", \\\"{x:802,y:535,t:1527631996907};\\\", \\\"{x:810,y:536,t:1527631996923};\\\", \\\"{x:819,y:538,t:1527631996940};\\\", \\\"{x:826,y:538,t:1527631996958};\\\", \\\"{x:828,y:538,t:1527631996974};\\\", \\\"{x:829,y:538,t:1527631997524};\\\", \\\"{x:829,y:541,t:1527631997540};\\\", \\\"{x:829,y:543,t:1527631997557};\\\", \\\"{x:829,y:545,t:1527631997575};\\\", \\\"{x:826,y:547,t:1527631997591};\\\", \\\"{x:822,y:550,t:1527631997608};\\\", \\\"{x:819,y:553,t:1527631997624};\\\", \\\"{x:808,y:559,t:1527631997640};\\\", \\\"{x:792,y:567,t:1527631997657};\\\", \\\"{x:769,y:573,t:1527631997675};\\\", \\\"{x:726,y:586,t:1527631997690};\\\", \\\"{x:669,y:598,t:1527631997708};\\\", \\\"{x:518,y:616,t:1527631997725};\\\", \\\"{x:410,y:616,t:1527631997741};\\\", \\\"{x:302,y:620,t:1527631997758};\\\", \\\"{x:198,y:626,t:1527631997775};\\\", \\\"{x:70,y:630,t:1527631997791};\\\", \\\"{x:0,y:630,t:1527631997808};\\\", \\\"{x:0,y:636,t:1527631997836};\\\", \\\"{x:0,y:640,t:1527631997844};\\\", \\\"{x:0,y:647,t:1527631997868};\\\", \\\"{x:0,y:655,t:1527631997876};\\\", \\\"{x:0,y:658,t:1527631997891};\\\", \\\"{x:0,y:660,t:1527631997907};\\\", \\\"{x:0,y:665,t:1527631997957};\\\", \\\"{x:0,y:675,t:1527631997974};\\\", \\\"{x:0,y:674,t:1527631998044};\\\", \\\"{x:3,y:676,t:1527631998180};\\\", \\\"{x:13,y:677,t:1527631998191};\\\", \\\"{x:39,y:682,t:1527631998208};\\\", \\\"{x:82,y:695,t:1527631998226};\\\", \\\"{x:167,y:714,t:1527631998241};\\\", \\\"{x:267,y:730,t:1527631998258};\\\", \\\"{x:362,y:732,t:1527631998275};\\\", \\\"{x:429,y:732,t:1527631998292};\\\", \\\"{x:536,y:735,t:1527631998309};\\\", \\\"{x:558,y:733,t:1527631998325};\\\", \\\"{x:564,y:734,t:1527631998340};\\\", \\\"{x:568,y:736,t:1527631998358};\\\", \\\"{x:569,y:736,t:1527631998374};\\\", \\\"{x:570,y:736,t:1527631998420};\\\", \\\"{x:571,y:736,t:1527631998427};\\\", \\\"{x:573,y:736,t:1527631998460};\\\", \\\"{x:576,y:736,t:1527631998474};\\\", \\\"{x:578,y:735,t:1527631998492};\\\", \\\"{x:577,y:735,t:1527631998597};\\\", \\\"{x:574,y:735,t:1527631998608};\\\", \\\"{x:567,y:735,t:1527631998625};\\\", \\\"{x:554,y:735,t:1527631998642};\\\", \\\"{x:545,y:736,t:1527631998658};\\\", \\\"{x:539,y:737,t:1527631998676};\\\", \\\"{x:536,y:737,t:1527631998691};\\\", \\\"{x:535,y:737,t:1527631998708};\\\", \\\"{x:534,y:738,t:1527632001144};\\\", \\\"{x:534,y:726,t:1527632001152};\\\", \\\"{x:534,y:693,t:1527632001165};\\\", \\\"{x:534,y:645,t:1527632001180};\\\", \\\"{x:534,y:620,t:1527632001197};\\\", \\\"{x:534,y:597,t:1527632001214};\\\", \\\"{x:534,y:579,t:1527632001230};\\\", \\\"{x:542,y:544,t:1527632001263};\\\", \\\"{x:544,y:535,t:1527632001280};\\\", \\\"{x:546,y:530,t:1527632001297};\\\", \\\"{x:547,y:524,t:1527632001314};\\\", \\\"{x:549,y:522,t:1527632001329};\\\", \\\"{x:549,y:520,t:1527632001346};\\\", \\\"{x:550,y:519,t:1527632001375};\\\" ] }, { \\\"rt\\\": 19428, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 619907, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -F -I -I -I -B -B -F -F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:514,t:1527632002040};\\\", \\\"{x:540,y:501,t:1527632002048};\\\", \\\"{x:518,y:477,t:1527632002065};\\\", \\\"{x:501,y:451,t:1527632002081};\\\", \\\"{x:489,y:432,t:1527632002098};\\\", \\\"{x:479,y:418,t:1527632002113};\\\", \\\"{x:473,y:408,t:1527632002131};\\\", \\\"{x:473,y:400,t:1527632002148};\\\", \\\"{x:474,y:395,t:1527632002164};\\\", \\\"{x:475,y:394,t:1527632002181};\\\", \\\"{x:478,y:393,t:1527632002207};\\\", \\\"{x:485,y:393,t:1527632002215};\\\", \\\"{x:489,y:396,t:1527632002231};\\\", \\\"{x:489,y:397,t:1527632002248};\\\", \\\"{x:489,y:398,t:1527632002737};\\\", \\\"{x:489,y:399,t:1527632002752};\\\", \\\"{x:489,y:400,t:1527632003449};\\\", \\\"{x:491,y:403,t:1527632003466};\\\", \\\"{x:494,y:404,t:1527632003482};\\\", \\\"{x:499,y:407,t:1527632003500};\\\", \\\"{x:500,y:407,t:1527632003516};\\\", \\\"{x:503,y:408,t:1527632003533};\\\", \\\"{x:504,y:408,t:1527632003552};\\\", \\\"{x:506,y:408,t:1527632003566};\\\", \\\"{x:515,y:410,t:1527632003583};\\\", \\\"{x:522,y:411,t:1527632003599};\\\", \\\"{x:531,y:412,t:1527632003616};\\\", \\\"{x:532,y:412,t:1527632003640};\\\", \\\"{x:533,y:412,t:1527632003649};\\\", \\\"{x:533,y:413,t:1527632003753};\\\", \\\"{x:534,y:415,t:1527632003768};\\\", \\\"{x:536,y:415,t:1527632003783};\\\", \\\"{x:544,y:419,t:1527632003800};\\\", \\\"{x:553,y:422,t:1527632003816};\\\", \\\"{x:564,y:424,t:1527632003832};\\\", \\\"{x:578,y:427,t:1527632003849};\\\", \\\"{x:583,y:428,t:1527632003866};\\\", \\\"{x:588,y:430,t:1527632003882};\\\", \\\"{x:589,y:430,t:1527632004944};\\\", \\\"{x:593,y:430,t:1527632004951};\\\", \\\"{x:598,y:430,t:1527632004966};\\\", \\\"{x:619,y:430,t:1527632004983};\\\", \\\"{x:632,y:428,t:1527632005000};\\\", \\\"{x:636,y:426,t:1527632005016};\\\", \\\"{x:637,y:426,t:1527632005088};\\\", \\\"{x:637,y:425,t:1527632005100};\\\", \\\"{x:638,y:425,t:1527632005184};\\\", \\\"{x:639,y:425,t:1527632005305};\\\", \\\"{x:640,y:425,t:1527632005393};\\\", \\\"{x:640,y:427,t:1527632005408};\\\", \\\"{x:640,y:428,t:1527632005424};\\\", \\\"{x:640,y:429,t:1527632005434};\\\", \\\"{x:642,y:430,t:1527632005450};\\\", \\\"{x:642,y:432,t:1527632005467};\\\", \\\"{x:642,y:435,t:1527632005484};\\\", \\\"{x:643,y:436,t:1527632005501};\\\", \\\"{x:643,y:439,t:1527632005517};\\\", \\\"{x:645,y:445,t:1527632005534};\\\", \\\"{x:646,y:451,t:1527632005551};\\\", \\\"{x:646,y:459,t:1527632005568};\\\", \\\"{x:644,y:466,t:1527632005584};\\\", \\\"{x:644,y:471,t:1527632005601};\\\", \\\"{x:644,y:473,t:1527632005618};\\\", \\\"{x:643,y:474,t:1527632005634};\\\", \\\"{x:643,y:476,t:1527632005728};\\\", \\\"{x:644,y:476,t:1527632005744};\\\", \\\"{x:646,y:477,t:1527632005752};\\\", \\\"{x:653,y:480,t:1527632005768};\\\", \\\"{x:673,y:482,t:1527632005784};\\\", \\\"{x:709,y:486,t:1527632005801};\\\", \\\"{x:779,y:486,t:1527632005818};\\\", \\\"{x:865,y:486,t:1527632005835};\\\", \\\"{x:948,y:476,t:1527632005851};\\\", \\\"{x:1036,y:468,t:1527632005868};\\\", \\\"{x:1114,y:468,t:1527632005885};\\\", \\\"{x:1200,y:468,t:1527632005901};\\\", \\\"{x:1273,y:468,t:1527632005918};\\\", \\\"{x:1295,y:479,t:1527632005935};\\\", \\\"{x:1307,y:485,t:1527632005951};\\\", \\\"{x:1311,y:487,t:1527632005969};\\\", \\\"{x:1313,y:488,t:1527632005984};\\\", \\\"{x:1322,y:494,t:1527632006001};\\\", \\\"{x:1333,y:501,t:1527632006018};\\\", \\\"{x:1346,y:504,t:1527632006035};\\\", \\\"{x:1357,y:507,t:1527632006052};\\\", \\\"{x:1361,y:507,t:1527632006068};\\\", \\\"{x:1364,y:507,t:1527632006085};\\\", \\\"{x:1364,y:510,t:1527632006145};\\\", \\\"{x:1364,y:513,t:1527632006152};\\\", \\\"{x:1359,y:522,t:1527632006168};\\\", \\\"{x:1350,y:534,t:1527632006184};\\\", \\\"{x:1341,y:545,t:1527632006202};\\\", \\\"{x:1330,y:559,t:1527632006218};\\\", \\\"{x:1319,y:567,t:1527632006235};\\\", \\\"{x:1312,y:573,t:1527632006252};\\\", \\\"{x:1308,y:578,t:1527632006268};\\\", \\\"{x:1303,y:582,t:1527632006285};\\\", \\\"{x:1298,y:583,t:1527632006302};\\\", \\\"{x:1290,y:585,t:1527632006318};\\\", \\\"{x:1276,y:587,t:1527632006335};\\\", \\\"{x:1262,y:587,t:1527632006352};\\\", \\\"{x:1257,y:587,t:1527632006368};\\\", \\\"{x:1245,y:587,t:1527632006385};\\\", \\\"{x:1230,y:587,t:1527632006402};\\\", \\\"{x:1214,y:590,t:1527632006418};\\\", \\\"{x:1205,y:593,t:1527632006435};\\\", \\\"{x:1198,y:596,t:1527632006452};\\\", \\\"{x:1190,y:601,t:1527632006468};\\\", \\\"{x:1184,y:608,t:1527632006485};\\\", \\\"{x:1178,y:612,t:1527632006502};\\\", \\\"{x:1171,y:620,t:1527632006518};\\\", \\\"{x:1164,y:627,t:1527632006534};\\\", \\\"{x:1156,y:640,t:1527632006552};\\\", \\\"{x:1154,y:641,t:1527632006569};\\\", \\\"{x:1153,y:644,t:1527632006585};\\\", \\\"{x:1152,y:646,t:1527632006602};\\\", \\\"{x:1150,y:647,t:1527632006619};\\\", \\\"{x:1151,y:647,t:1527632006785};\\\", \\\"{x:1157,y:645,t:1527632006802};\\\", \\\"{x:1169,y:641,t:1527632006819};\\\", \\\"{x:1180,y:637,t:1527632006835};\\\", \\\"{x:1196,y:636,t:1527632006852};\\\", \\\"{x:1209,y:636,t:1527632006869};\\\", \\\"{x:1220,y:636,t:1527632006886};\\\", \\\"{x:1233,y:636,t:1527632006902};\\\", \\\"{x:1250,y:636,t:1527632006919};\\\", \\\"{x:1274,y:636,t:1527632006935};\\\", \\\"{x:1312,y:636,t:1527632006952};\\\", \\\"{x:1338,y:636,t:1527632006968};\\\", \\\"{x:1368,y:636,t:1527632006985};\\\", \\\"{x:1397,y:636,t:1527632007002};\\\", \\\"{x:1426,y:636,t:1527632007019};\\\", \\\"{x:1461,y:633,t:1527632007036};\\\", \\\"{x:1495,y:633,t:1527632007052};\\\", \\\"{x:1525,y:631,t:1527632007069};\\\", \\\"{x:1542,y:631,t:1527632007086};\\\", \\\"{x:1563,y:631,t:1527632007102};\\\", \\\"{x:1583,y:631,t:1527632007122};\\\", \\\"{x:1621,y:631,t:1527632007136};\\\", \\\"{x:1644,y:631,t:1527632007151};\\\", \\\"{x:1665,y:631,t:1527632007168};\\\", \\\"{x:1683,y:631,t:1527632007185};\\\", \\\"{x:1702,y:633,t:1527632007202};\\\", \\\"{x:1714,y:635,t:1527632007218};\\\", \\\"{x:1721,y:635,t:1527632007235};\\\", \\\"{x:1724,y:635,t:1527632007251};\\\", \\\"{x:1723,y:637,t:1527632007761};\\\", \\\"{x:1722,y:637,t:1527632007776};\\\", \\\"{x:1721,y:638,t:1527632007793};\\\", \\\"{x:1717,y:640,t:1527632008728};\\\", \\\"{x:1712,y:640,t:1527632008737};\\\", \\\"{x:1693,y:642,t:1527632008753};\\\", \\\"{x:1670,y:646,t:1527632008770};\\\", \\\"{x:1639,y:647,t:1527632008787};\\\", \\\"{x:1600,y:648,t:1527632008803};\\\", \\\"{x:1561,y:648,t:1527632008820};\\\", \\\"{x:1533,y:650,t:1527632008837};\\\", \\\"{x:1505,y:650,t:1527632008853};\\\", \\\"{x:1486,y:650,t:1527632008870};\\\", \\\"{x:1477,y:653,t:1527632008887};\\\", \\\"{x:1475,y:653,t:1527632008903};\\\", \\\"{x:1474,y:653,t:1527632008921};\\\", \\\"{x:1472,y:653,t:1527632008952};\\\", \\\"{x:1470,y:653,t:1527632008977};\\\", \\\"{x:1466,y:655,t:1527632008993};\\\", \\\"{x:1463,y:655,t:1527632009004};\\\", \\\"{x:1457,y:656,t:1527632009020};\\\", \\\"{x:1447,y:657,t:1527632009037};\\\", \\\"{x:1440,y:659,t:1527632009054};\\\", \\\"{x:1429,y:661,t:1527632009070};\\\", \\\"{x:1423,y:661,t:1527632009087};\\\", \\\"{x:1416,y:665,t:1527632009104};\\\", \\\"{x:1414,y:665,t:1527632009121};\\\", \\\"{x:1413,y:665,t:1527632009137};\\\", \\\"{x:1412,y:666,t:1527632009154};\\\", \\\"{x:1410,y:667,t:1527632009176};\\\", \\\"{x:1408,y:668,t:1527632009187};\\\", \\\"{x:1406,y:668,t:1527632009204};\\\", \\\"{x:1402,y:671,t:1527632009220};\\\", \\\"{x:1401,y:671,t:1527632009238};\\\", \\\"{x:1398,y:671,t:1527632009254};\\\", \\\"{x:1395,y:672,t:1527632009270};\\\", \\\"{x:1388,y:674,t:1527632009286};\\\", \\\"{x:1375,y:676,t:1527632009303};\\\", \\\"{x:1371,y:676,t:1527632009320};\\\", \\\"{x:1363,y:679,t:1527632009337};\\\", \\\"{x:1358,y:680,t:1527632009354};\\\", \\\"{x:1353,y:682,t:1527632009370};\\\", \\\"{x:1351,y:683,t:1527632009387};\\\", \\\"{x:1350,y:683,t:1527632009456};\\\", \\\"{x:1348,y:683,t:1527632009496};\\\", \\\"{x:1347,y:683,t:1527632009545};\\\", \\\"{x:1345,y:684,t:1527632009568};\\\", \\\"{x:1343,y:684,t:1527632009609};\\\", \\\"{x:1341,y:686,t:1527632009633};\\\", \\\"{x:1339,y:687,t:1527632009649};\\\", \\\"{x:1337,y:687,t:1527632009656};\\\", \\\"{x:1336,y:687,t:1527632009689};\\\", \\\"{x:1334,y:688,t:1527632009704};\\\", \\\"{x:1331,y:689,t:1527632009720};\\\", \\\"{x:1328,y:690,t:1527632009737};\\\", \\\"{x:1322,y:691,t:1527632009754};\\\", \\\"{x:1311,y:695,t:1527632009771};\\\", \\\"{x:1305,y:696,t:1527632009787};\\\", \\\"{x:1301,y:699,t:1527632009804};\\\", \\\"{x:1291,y:702,t:1527632009821};\\\", \\\"{x:1279,y:705,t:1527632009838};\\\", \\\"{x:1269,y:708,t:1527632009855};\\\", \\\"{x:1260,y:712,t:1527632009871};\\\", \\\"{x:1246,y:715,t:1527632009888};\\\", \\\"{x:1242,y:717,t:1527632009905};\\\", \\\"{x:1240,y:718,t:1527632009921};\\\", \\\"{x:1237,y:719,t:1527632009938};\\\", \\\"{x:1236,y:720,t:1527632009954};\\\", \\\"{x:1235,y:720,t:1527632009971};\\\", \\\"{x:1233,y:721,t:1527632009992};\\\", \\\"{x:1232,y:721,t:1527632010009};\\\", \\\"{x:1232,y:722,t:1527632010021};\\\", \\\"{x:1230,y:723,t:1527632010037};\\\", \\\"{x:1229,y:723,t:1527632010054};\\\", \\\"{x:1228,y:724,t:1527632010070};\\\", \\\"{x:1226,y:725,t:1527632010088};\\\", \\\"{x:1223,y:727,t:1527632010103};\\\", \\\"{x:1221,y:728,t:1527632010121};\\\", \\\"{x:1216,y:731,t:1527632010137};\\\", \\\"{x:1211,y:734,t:1527632010153};\\\", \\\"{x:1205,y:737,t:1527632010170};\\\", \\\"{x:1201,y:739,t:1527632010187};\\\", \\\"{x:1196,y:741,t:1527632010203};\\\", \\\"{x:1193,y:743,t:1527632010221};\\\", \\\"{x:1191,y:743,t:1527632010238};\\\", \\\"{x:1186,y:745,t:1527632010253};\\\", \\\"{x:1186,y:746,t:1527632010271};\\\", \\\"{x:1182,y:749,t:1527632010287};\\\", \\\"{x:1180,y:750,t:1527632010303};\\\", \\\"{x:1178,y:752,t:1527632010321};\\\", \\\"{x:1176,y:753,t:1527632010337};\\\", \\\"{x:1175,y:753,t:1527632010368};\\\", \\\"{x:1174,y:753,t:1527632010423};\\\", \\\"{x:1174,y:755,t:1527632011616};\\\", \\\"{x:1174,y:756,t:1527632011680};\\\", \\\"{x:1175,y:756,t:1527632012432};\\\", \\\"{x:1176,y:757,t:1527632012440};\\\", \\\"{x:1176,y:758,t:1527632012457};\\\", \\\"{x:1179,y:758,t:1527632012817};\\\", \\\"{x:1182,y:758,t:1527632012839};\\\", \\\"{x:1187,y:759,t:1527632012857};\\\", \\\"{x:1188,y:759,t:1527632012873};\\\", \\\"{x:1189,y:759,t:1527632012890};\\\", \\\"{x:1191,y:760,t:1527632012906};\\\", \\\"{x:1193,y:761,t:1527632012922};\\\", \\\"{x:1195,y:762,t:1527632012960};\\\", \\\"{x:1196,y:762,t:1527632012972};\\\", \\\"{x:1197,y:762,t:1527632012989};\\\", \\\"{x:1198,y:762,t:1527632013005};\\\", \\\"{x:1205,y:763,t:1527632013022};\\\", \\\"{x:1210,y:766,t:1527632013040};\\\", \\\"{x:1212,y:767,t:1527632013096};\\\", \\\"{x:1216,y:770,t:1527632013105};\\\", \\\"{x:1217,y:772,t:1527632013123};\\\", \\\"{x:1222,y:776,t:1527632013140};\\\", \\\"{x:1223,y:777,t:1527632013156};\\\", \\\"{x:1224,y:777,t:1527632013657};\\\", \\\"{x:1227,y:777,t:1527632013675};\\\", \\\"{x:1237,y:778,t:1527632013690};\\\", \\\"{x:1247,y:781,t:1527632013708};\\\", \\\"{x:1255,y:782,t:1527632013724};\\\", \\\"{x:1272,y:783,t:1527632013740};\\\", \\\"{x:1290,y:783,t:1527632013757};\\\", \\\"{x:1307,y:783,t:1527632013774};\\\", \\\"{x:1320,y:783,t:1527632013790};\\\", \\\"{x:1332,y:785,t:1527632013808};\\\", \\\"{x:1350,y:785,t:1527632013824};\\\", \\\"{x:1360,y:785,t:1527632013840};\\\", \\\"{x:1372,y:786,t:1527632013856};\\\", \\\"{x:1382,y:786,t:1527632013873};\\\", \\\"{x:1391,y:786,t:1527632013890};\\\", \\\"{x:1400,y:786,t:1527632013906};\\\", \\\"{x:1408,y:786,t:1527632013924};\\\", \\\"{x:1410,y:786,t:1527632013940};\\\", \\\"{x:1408,y:786,t:1527632014066};\\\", \\\"{x:1407,y:786,t:1527632014074};\\\", \\\"{x:1403,y:786,t:1527632014091};\\\", \\\"{x:1401,y:786,t:1527632014107};\\\", \\\"{x:1399,y:786,t:1527632014124};\\\", \\\"{x:1398,y:786,t:1527632014141};\\\", \\\"{x:1397,y:786,t:1527632014201};\\\", \\\"{x:1396,y:786,t:1527632014208};\\\", \\\"{x:1395,y:786,t:1527632014225};\\\", \\\"{x:1394,y:786,t:1527632014241};\\\", \\\"{x:1393,y:787,t:1527632014257};\\\", \\\"{x:1391,y:788,t:1527632014275};\\\", \\\"{x:1389,y:789,t:1527632014296};\\\", \\\"{x:1388,y:790,t:1527632014336};\\\", \\\"{x:1386,y:790,t:1527632014368};\\\", \\\"{x:1385,y:791,t:1527632014424};\\\", \\\"{x:1384,y:791,t:1527632014472};\\\", \\\"{x:1383,y:791,t:1527632014504};\\\", \\\"{x:1381,y:792,t:1527632014528};\\\", \\\"{x:1380,y:792,t:1527632014561};\\\", \\\"{x:1379,y:793,t:1527632014574};\\\", \\\"{x:1378,y:793,t:1527632014728};\\\", \\\"{x:1376,y:793,t:1527632014741};\\\", \\\"{x:1372,y:790,t:1527632014759};\\\", \\\"{x:1369,y:787,t:1527632014775};\\\", \\\"{x:1365,y:784,t:1527632014792};\\\", \\\"{x:1358,y:776,t:1527632014808};\\\", \\\"{x:1353,y:771,t:1527632014824};\\\", \\\"{x:1351,y:767,t:1527632014842};\\\", \\\"{x:1347,y:762,t:1527632014858};\\\", \\\"{x:1347,y:760,t:1527632014874};\\\", \\\"{x:1347,y:758,t:1527632014891};\\\", \\\"{x:1345,y:757,t:1527632014909};\\\", \\\"{x:1345,y:756,t:1527632014924};\\\", \\\"{x:1345,y:754,t:1527632015617};\\\", \\\"{x:1345,y:753,t:1527632015632};\\\", \\\"{x:1345,y:752,t:1527632015642};\\\", \\\"{x:1345,y:751,t:1527632015658};\\\", \\\"{x:1345,y:750,t:1527632015679};\\\", \\\"{x:1345,y:748,t:1527632015928};\\\", \\\"{x:1345,y:740,t:1527632015943};\\\", \\\"{x:1344,y:726,t:1527632015958};\\\", \\\"{x:1343,y:713,t:1527632015975};\\\", \\\"{x:1342,y:703,t:1527632015992};\\\", \\\"{x:1342,y:698,t:1527632016009};\\\", \\\"{x:1342,y:696,t:1527632016025};\\\", \\\"{x:1342,y:695,t:1527632016042};\\\", \\\"{x:1342,y:694,t:1527632016137};\\\", \\\"{x:1342,y:693,t:1527632016152};\\\", \\\"{x:1342,y:694,t:1527632017080};\\\", \\\"{x:1342,y:697,t:1527632017094};\\\", \\\"{x:1342,y:702,t:1527632017110};\\\", \\\"{x:1342,y:707,t:1527632017127};\\\", \\\"{x:1344,y:710,t:1527632017143};\\\", \\\"{x:1344,y:712,t:1527632017159};\\\", \\\"{x:1344,y:714,t:1527632017175};\\\", \\\"{x:1344,y:716,t:1527632017193};\\\", \\\"{x:1345,y:717,t:1527632017209};\\\", \\\"{x:1345,y:719,t:1527632017226};\\\", \\\"{x:1345,y:721,t:1527632017243};\\\", \\\"{x:1346,y:723,t:1527632017260};\\\", \\\"{x:1346,y:724,t:1527632017279};\\\", \\\"{x:1346,y:726,t:1527632017295};\\\", \\\"{x:1346,y:728,t:1527632017311};\\\", \\\"{x:1346,y:730,t:1527632017326};\\\", \\\"{x:1346,y:737,t:1527632017343};\\\", \\\"{x:1346,y:743,t:1527632017358};\\\", \\\"{x:1346,y:748,t:1527632017376};\\\", \\\"{x:1346,y:749,t:1527632017392};\\\", \\\"{x:1346,y:751,t:1527632017409};\\\", \\\"{x:1346,y:753,t:1527632017426};\\\", \\\"{x:1345,y:755,t:1527632017448};\\\", \\\"{x:1345,y:756,t:1527632017624};\\\", \\\"{x:1345,y:757,t:1527632017648};\\\", \\\"{x:1344,y:758,t:1527632017661};\\\", \\\"{x:1344,y:759,t:1527632017676};\\\", \\\"{x:1343,y:759,t:1527632017693};\\\", \\\"{x:1343,y:761,t:1527632017710};\\\", \\\"{x:1341,y:764,t:1527632017726};\\\", \\\"{x:1341,y:766,t:1527632017743};\\\", \\\"{x:1337,y:768,t:1527632017759};\\\", \\\"{x:1333,y:770,t:1527632017776};\\\", \\\"{x:1327,y:771,t:1527632017793};\\\", \\\"{x:1315,y:774,t:1527632017810};\\\", \\\"{x:1293,y:775,t:1527632017825};\\\", \\\"{x:1260,y:775,t:1527632017843};\\\", \\\"{x:1179,y:775,t:1527632017860};\\\", \\\"{x:1079,y:775,t:1527632017876};\\\", \\\"{x:981,y:768,t:1527632017893};\\\", \\\"{x:893,y:761,t:1527632017910};\\\", \\\"{x:790,y:745,t:1527632017926};\\\", \\\"{x:676,y:729,t:1527632017942};\\\", \\\"{x:565,y:707,t:1527632017959};\\\", \\\"{x:485,y:689,t:1527632017977};\\\", \\\"{x:421,y:670,t:1527632017993};\\\", \\\"{x:370,y:652,t:1527632018011};\\\", \\\"{x:337,y:639,t:1527632018026};\\\", \\\"{x:316,y:627,t:1527632018043};\\\", \\\"{x:295,y:610,t:1527632018061};\\\", \\\"{x:277,y:594,t:1527632018078};\\\", \\\"{x:264,y:584,t:1527632018094};\\\", \\\"{x:257,y:579,t:1527632018110};\\\", \\\"{x:255,y:575,t:1527632018126};\\\", \\\"{x:254,y:573,t:1527632018143};\\\", \\\"{x:253,y:573,t:1527632018183};\\\", \\\"{x:253,y:572,t:1527632018224};\\\", \\\"{x:253,y:570,t:1527632018231};\\\", \\\"{x:256,y:568,t:1527632018244};\\\", \\\"{x:264,y:565,t:1527632018260};\\\", \\\"{x:276,y:563,t:1527632018277};\\\", \\\"{x:292,y:558,t:1527632018294};\\\", \\\"{x:314,y:554,t:1527632018311};\\\", \\\"{x:341,y:553,t:1527632018326};\\\", \\\"{x:374,y:552,t:1527632018343};\\\", \\\"{x:399,y:552,t:1527632018360};\\\", \\\"{x:420,y:552,t:1527632018377};\\\", \\\"{x:443,y:555,t:1527632018394};\\\", \\\"{x:457,y:555,t:1527632018411};\\\", \\\"{x:466,y:556,t:1527632018428};\\\", \\\"{x:471,y:557,t:1527632018444};\\\", \\\"{x:475,y:557,t:1527632018461};\\\", \\\"{x:483,y:557,t:1527632018477};\\\", \\\"{x:489,y:557,t:1527632018495};\\\", \\\"{x:505,y:557,t:1527632018511};\\\", \\\"{x:510,y:557,t:1527632018528};\\\", \\\"{x:513,y:557,t:1527632018545};\\\", \\\"{x:514,y:557,t:1527632018672};\\\", \\\"{x:522,y:557,t:1527632018680};\\\", \\\"{x:533,y:557,t:1527632018695};\\\", \\\"{x:572,y:554,t:1527632018713};\\\", \\\"{x:635,y:551,t:1527632018728};\\\", \\\"{x:723,y:541,t:1527632018745};\\\", \\\"{x:814,y:532,t:1527632018761};\\\", \\\"{x:873,y:524,t:1527632018778};\\\", \\\"{x:895,y:517,t:1527632018795};\\\", \\\"{x:901,y:516,t:1527632018812};\\\", \\\"{x:903,y:515,t:1527632018887};\\\", \\\"{x:904,y:515,t:1527632018895};\\\", \\\"{x:906,y:515,t:1527632018910};\\\", \\\"{x:907,y:513,t:1527632018927};\\\", \\\"{x:907,y:512,t:1527632018944};\\\", \\\"{x:907,y:511,t:1527632018960};\\\", \\\"{x:907,y:510,t:1527632018983};\\\", \\\"{x:903,y:509,t:1527632018994};\\\", \\\"{x:899,y:507,t:1527632019011};\\\", \\\"{x:884,y:507,t:1527632019027};\\\", \\\"{x:869,y:505,t:1527632019045};\\\", \\\"{x:864,y:505,t:1527632019061};\\\", \\\"{x:857,y:505,t:1527632019077};\\\", \\\"{x:855,y:505,t:1527632019094};\\\", \\\"{x:854,y:505,t:1527632019118};\\\", \\\"{x:852,y:505,t:1527632019134};\\\", \\\"{x:851,y:505,t:1527632019144};\\\", \\\"{x:844,y:505,t:1527632019162};\\\", \\\"{x:843,y:505,t:1527632019190};\\\", \\\"{x:842,y:505,t:1527632019207};\\\", \\\"{x:841,y:505,t:1527632019303};\\\", \\\"{x:840,y:504,t:1527632019311};\\\", \\\"{x:839,y:504,t:1527632019328};\\\", \\\"{x:838,y:504,t:1527632019344};\\\", \\\"{x:834,y:504,t:1527632019543};\\\", \\\"{x:824,y:504,t:1527632019551};\\\", \\\"{x:807,y:504,t:1527632019561};\\\", \\\"{x:724,y:504,t:1527632019579};\\\", \\\"{x:616,y:504,t:1527632019595};\\\", \\\"{x:522,y:504,t:1527632019612};\\\", \\\"{x:442,y:510,t:1527632019629};\\\", \\\"{x:405,y:514,t:1527632019644};\\\", \\\"{x:381,y:516,t:1527632019661};\\\", \\\"{x:353,y:517,t:1527632019678};\\\", \\\"{x:340,y:520,t:1527632019695};\\\", \\\"{x:329,y:521,t:1527632019712};\\\", \\\"{x:321,y:524,t:1527632019728};\\\", \\\"{x:309,y:526,t:1527632019746};\\\", \\\"{x:290,y:531,t:1527632019761};\\\", \\\"{x:271,y:535,t:1527632019780};\\\", \\\"{x:250,y:537,t:1527632019796};\\\", \\\"{x:231,y:540,t:1527632019811};\\\", \\\"{x:214,y:541,t:1527632019829};\\\", \\\"{x:196,y:541,t:1527632019846};\\\", \\\"{x:186,y:541,t:1527632019862};\\\", \\\"{x:176,y:541,t:1527632019879};\\\", \\\"{x:169,y:541,t:1527632019895};\\\", \\\"{x:166,y:541,t:1527632019912};\\\", \\\"{x:165,y:541,t:1527632019929};\\\", \\\"{x:164,y:541,t:1527632019951};\\\", \\\"{x:163,y:541,t:1527632019961};\\\", \\\"{x:162,y:541,t:1527632019978};\\\", \\\"{x:159,y:540,t:1527632019996};\\\", \\\"{x:166,y:545,t:1527632020407};\\\", \\\"{x:186,y:559,t:1527632020415};\\\", \\\"{x:207,y:569,t:1527632020429};\\\", \\\"{x:244,y:588,t:1527632020446};\\\", \\\"{x:299,y:613,t:1527632020463};\\\", \\\"{x:323,y:628,t:1527632020479};\\\", \\\"{x:359,y:652,t:1527632020497};\\\", \\\"{x:380,y:670,t:1527632020513};\\\", \\\"{x:390,y:685,t:1527632020529};\\\", \\\"{x:401,y:699,t:1527632020545};\\\", \\\"{x:407,y:707,t:1527632020563};\\\", \\\"{x:409,y:710,t:1527632020579};\\\", \\\"{x:411,y:711,t:1527632020596};\\\", \\\"{x:411,y:712,t:1527632020613};\\\", \\\"{x:417,y:716,t:1527632020629};\\\", \\\"{x:423,y:719,t:1527632020646};\\\", \\\"{x:429,y:723,t:1527632020665};\\\", \\\"{x:432,y:725,t:1527632020679};\\\", \\\"{x:437,y:730,t:1527632020695};\\\", \\\"{x:441,y:733,t:1527632020713};\\\", \\\"{x:442,y:735,t:1527632020729};\\\", \\\"{x:446,y:737,t:1527632020746};\\\", \\\"{x:448,y:739,t:1527632020763};\\\", \\\"{x:452,y:740,t:1527632020779};\\\", \\\"{x:457,y:741,t:1527632020796};\\\", \\\"{x:459,y:741,t:1527632020813};\\\", \\\"{x:460,y:741,t:1527632020830};\\\", \\\"{x:460,y:745,t:1527632021319};\\\", \\\"{x:458,y:745,t:1527632021329};\\\", \\\"{x:439,y:741,t:1527632021347};\\\", \\\"{x:413,y:729,t:1527632021363};\\\", \\\"{x:363,y:714,t:1527632021380};\\\", \\\"{x:292,y:695,t:1527632021396};\\\", \\\"{x:178,y:658,t:1527632021413};\\\", \\\"{x:52,y:631,t:1527632021430};\\\", \\\"{x:0,y:605,t:1527632021447};\\\", \\\"{x:0,y:573,t:1527632021463};\\\", \\\"{x:0,y:552,t:1527632021480};\\\", \\\"{x:0,y:535,t:1527632021497};\\\", \\\"{x:0,y:517,t:1527632021514};\\\", \\\"{x:0,y:512,t:1527632021530};\\\", \\\"{x:0,y:508,t:1527632021547};\\\", \\\"{x:0,y:507,t:1527632021564};\\\", \\\"{x:0,y:508,t:1527632021608};\\\", \\\"{x:0,y:509,t:1527632021632};\\\", \\\"{x:0,y:510,t:1527632021647};\\\", \\\"{x:0,y:511,t:1527632021671};\\\", \\\"{x:0,y:512,t:1527632021695};\\\" ] }, { \\\"rt\\\": 62233, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 683390, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -X -X -X -F -G -C -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:9,y:510,t:1527632022245};\\\", \\\"{x:21,y:509,t:1527632022253};\\\", \\\"{x:60,y:502,t:1527632022264};\\\", \\\"{x:121,y:493,t:1527632022281};\\\", \\\"{x:206,y:476,t:1527632022297};\\\", \\\"{x:349,y:454,t:1527632022323};\\\", \\\"{x:394,y:451,t:1527632022330};\\\", \\\"{x:475,y:440,t:1527632022347};\\\", \\\"{x:520,y:432,t:1527632022364};\\\", \\\"{x:534,y:431,t:1527632022381};\\\", \\\"{x:534,y:430,t:1527632022735};\\\", \\\"{x:533,y:428,t:1527632022748};\\\", \\\"{x:527,y:423,t:1527632022763};\\\", \\\"{x:525,y:413,t:1527632022780};\\\", \\\"{x:519,y:393,t:1527632022798};\\\", \\\"{x:511,y:372,t:1527632022814};\\\", \\\"{x:501,y:350,t:1527632022831};\\\", \\\"{x:500,y:348,t:1527632022848};\\\", \\\"{x:495,y:349,t:1527632029992};\\\", \\\"{x:488,y:352,t:1527632030005};\\\", \\\"{x:473,y:358,t:1527632030021};\\\", \\\"{x:452,y:367,t:1527632030039};\\\", \\\"{x:444,y:373,t:1527632030054};\\\", \\\"{x:438,y:374,t:1527632030071};\\\", \\\"{x:438,y:375,t:1527632030089};\\\", \\\"{x:438,y:376,t:1527632030105};\\\", \\\"{x:437,y:377,t:1527632030127};\\\", \\\"{x:436,y:380,t:1527632030139};\\\", \\\"{x:434,y:382,t:1527632030155};\\\", \\\"{x:432,y:387,t:1527632030172};\\\", \\\"{x:427,y:396,t:1527632030188};\\\", \\\"{x:421,y:408,t:1527632030205};\\\", \\\"{x:415,y:416,t:1527632030222};\\\", \\\"{x:407,y:431,t:1527632030238};\\\", \\\"{x:399,y:445,t:1527632030255};\\\", \\\"{x:397,y:454,t:1527632030271};\\\", \\\"{x:396,y:463,t:1527632030288};\\\", \\\"{x:393,y:470,t:1527632030306};\\\", \\\"{x:392,y:472,t:1527632030321};\\\", \\\"{x:389,y:476,t:1527632030338};\\\", \\\"{x:382,y:484,t:1527632030356};\\\", \\\"{x:379,y:488,t:1527632030373};\\\", \\\"{x:377,y:491,t:1527632030389};\\\", \\\"{x:376,y:492,t:1527632030405};\\\", \\\"{x:376,y:490,t:1527632030855};\\\", \\\"{x:373,y:487,t:1527632030871};\\\", \\\"{x:369,y:484,t:1527632030887};\\\", \\\"{x:358,y:479,t:1527632030904};\\\", \\\"{x:347,y:474,t:1527632030921};\\\", \\\"{x:331,y:472,t:1527632030937};\\\", \\\"{x:310,y:468,t:1527632030954};\\\", \\\"{x:282,y:464,t:1527632030971};\\\", \\\"{x:262,y:463,t:1527632030987};\\\", \\\"{x:249,y:462,t:1527632031004};\\\", \\\"{x:240,y:461,t:1527632031021};\\\", \\\"{x:238,y:461,t:1527632031037};\\\", \\\"{x:238,y:462,t:1527632033360};\\\", \\\"{x:239,y:463,t:1527632033372};\\\", \\\"{x:242,y:465,t:1527632033389};\\\", \\\"{x:246,y:466,t:1527632033407};\\\", \\\"{x:254,y:472,t:1527632033424};\\\", \\\"{x:261,y:475,t:1527632033439};\\\", \\\"{x:270,y:479,t:1527632033456};\\\", \\\"{x:279,y:481,t:1527632033473};\\\", \\\"{x:288,y:483,t:1527632033490};\\\", \\\"{x:297,y:486,t:1527632033506};\\\", \\\"{x:315,y:490,t:1527632033525};\\\", \\\"{x:343,y:497,t:1527632033539};\\\", \\\"{x:392,y:507,t:1527632033554};\\\", \\\"{x:458,y:512,t:1527632033570};\\\", \\\"{x:511,y:520,t:1527632033585};\\\", \\\"{x:560,y:531,t:1527632033607};\\\", \\\"{x:665,y:557,t:1527632033623};\\\", \\\"{x:771,y:573,t:1527632033640};\\\", \\\"{x:859,y:582,t:1527632033657};\\\", \\\"{x:940,y:582,t:1527632033673};\\\", \\\"{x:964,y:585,t:1527632033689};\\\", \\\"{x:964,y:584,t:1527632033706};\\\", \\\"{x:965,y:582,t:1527632033723};\\\", \\\"{x:975,y:584,t:1527632034023};\\\", \\\"{x:1013,y:589,t:1527632034042};\\\", \\\"{x:1070,y:602,t:1527632034057};\\\", \\\"{x:1134,y:620,t:1527632034074};\\\", \\\"{x:1176,y:631,t:1527632034091};\\\", \\\"{x:1200,y:642,t:1527632034107};\\\", \\\"{x:1216,y:648,t:1527632034124};\\\", \\\"{x:1234,y:658,t:1527632034142};\\\", \\\"{x:1250,y:668,t:1527632034157};\\\", \\\"{x:1264,y:678,t:1527632034174};\\\", \\\"{x:1270,y:683,t:1527632034191};\\\", \\\"{x:1275,y:687,t:1527632034207};\\\", \\\"{x:1282,y:690,t:1527632034223};\\\", \\\"{x:1285,y:693,t:1527632034241};\\\", \\\"{x:1288,y:695,t:1527632034257};\\\", \\\"{x:1291,y:697,t:1527632034273};\\\", \\\"{x:1292,y:698,t:1527632034290};\\\", \\\"{x:1295,y:700,t:1527632034307};\\\", \\\"{x:1299,y:705,t:1527632034324};\\\", \\\"{x:1303,y:712,t:1527632034341};\\\", \\\"{x:1305,y:719,t:1527632034358};\\\", \\\"{x:1309,y:726,t:1527632034374};\\\", \\\"{x:1312,y:730,t:1527632034391};\\\", \\\"{x:1315,y:736,t:1527632034407};\\\", \\\"{x:1322,y:747,t:1527632034424};\\\", \\\"{x:1331,y:758,t:1527632034441};\\\", \\\"{x:1336,y:765,t:1527632034458};\\\", \\\"{x:1337,y:766,t:1527632034473};\\\", \\\"{x:1340,y:767,t:1527632034544};\\\", \\\"{x:1343,y:768,t:1527632034558};\\\", \\\"{x:1345,y:769,t:1527632034574};\\\", \\\"{x:1349,y:770,t:1527632034591};\\\", \\\"{x:1351,y:772,t:1527632034608};\\\", \\\"{x:1352,y:772,t:1527632034872};\\\", \\\"{x:1352,y:770,t:1527632034896};\\\", \\\"{x:1352,y:769,t:1527632034983};\\\", \\\"{x:1351,y:769,t:1527632035168};\\\", \\\"{x:1349,y:769,t:1527632035225};\\\", \\\"{x:1348,y:769,t:1527632035256};\\\", \\\"{x:1347,y:768,t:1527632035266};\\\", \\\"{x:1346,y:769,t:1527632035551};\\\", \\\"{x:1345,y:771,t:1527632035566};\\\", \\\"{x:1344,y:773,t:1527632035591};\\\", \\\"{x:1344,y:774,t:1527632035609};\\\", \\\"{x:1342,y:776,t:1527632035631};\\\", \\\"{x:1341,y:778,t:1527632035663};\\\", \\\"{x:1339,y:780,t:1527632035675};\\\", \\\"{x:1339,y:781,t:1527632035695};\\\", \\\"{x:1338,y:782,t:1527632035708};\\\", \\\"{x:1338,y:783,t:1527632035724};\\\", \\\"{x:1336,y:786,t:1527632035741};\\\", \\\"{x:1334,y:789,t:1527632035758};\\\", \\\"{x:1333,y:791,t:1527632035774};\\\", \\\"{x:1331,y:793,t:1527632035792};\\\", \\\"{x:1330,y:796,t:1527632035808};\\\", \\\"{x:1329,y:797,t:1527632035824};\\\", \\\"{x:1327,y:800,t:1527632035842};\\\", \\\"{x:1325,y:802,t:1527632035858};\\\", \\\"{x:1321,y:808,t:1527632035874};\\\", \\\"{x:1314,y:819,t:1527632035892};\\\", \\\"{x:1306,y:831,t:1527632035908};\\\", \\\"{x:1296,y:843,t:1527632035925};\\\", \\\"{x:1287,y:851,t:1527632035942};\\\", \\\"{x:1282,y:857,t:1527632035959};\\\", \\\"{x:1279,y:861,t:1527632035976};\\\", \\\"{x:1276,y:865,t:1527632035992};\\\", \\\"{x:1276,y:867,t:1527632036009};\\\", \\\"{x:1275,y:871,t:1527632036025};\\\", \\\"{x:1272,y:878,t:1527632036041};\\\", \\\"{x:1272,y:883,t:1527632036058};\\\", \\\"{x:1271,y:887,t:1527632036075};\\\", \\\"{x:1268,y:894,t:1527632036092};\\\", \\\"{x:1266,y:898,t:1527632036109};\\\", \\\"{x:1266,y:900,t:1527632036126};\\\", \\\"{x:1265,y:903,t:1527632036142};\\\", \\\"{x:1265,y:908,t:1527632036159};\\\", \\\"{x:1265,y:912,t:1527632036175};\\\", \\\"{x:1265,y:915,t:1527632036192};\\\", \\\"{x:1264,y:919,t:1527632036209};\\\", \\\"{x:1263,y:921,t:1527632036226};\\\", \\\"{x:1263,y:923,t:1527632036241};\\\", \\\"{x:1263,y:925,t:1527632036259};\\\", \\\"{x:1261,y:929,t:1527632036276};\\\", \\\"{x:1261,y:931,t:1527632036292};\\\", \\\"{x:1261,y:933,t:1527632036309};\\\", \\\"{x:1261,y:934,t:1527632036326};\\\", \\\"{x:1261,y:936,t:1527632036342};\\\", \\\"{x:1261,y:938,t:1527632036359};\\\", \\\"{x:1261,y:941,t:1527632036375};\\\", \\\"{x:1260,y:943,t:1527632036392};\\\", \\\"{x:1259,y:947,t:1527632036409};\\\", \\\"{x:1257,y:950,t:1527632036426};\\\", \\\"{x:1256,y:956,t:1527632036442};\\\", \\\"{x:1253,y:958,t:1527632036459};\\\", \\\"{x:1252,y:962,t:1527632036476};\\\", \\\"{x:1251,y:964,t:1527632036492};\\\", \\\"{x:1251,y:965,t:1527632036509};\\\", \\\"{x:1251,y:967,t:1527632036526};\\\", \\\"{x:1250,y:968,t:1527632036543};\\\", \\\"{x:1250,y:969,t:1527632036600};\\\", \\\"{x:1250,y:970,t:1527632036609};\\\", \\\"{x:1250,y:971,t:1527632036655};\\\", \\\"{x:1251,y:971,t:1527632037800};\\\", \\\"{x:1249,y:971,t:1527632038272};\\\", \\\"{x:1248,y:971,t:1527632038288};\\\", \\\"{x:1247,y:971,t:1527632038304};\\\", \\\"{x:1246,y:970,t:1527632038327};\\\", \\\"{x:1244,y:970,t:1527632038343};\\\", \\\"{x:1242,y:969,t:1527632038361};\\\", \\\"{x:1241,y:969,t:1527632038591};\\\", \\\"{x:1240,y:968,t:1527632038614};\\\", \\\"{x:1239,y:968,t:1527632038631};\\\", \\\"{x:1237,y:968,t:1527632038646};\\\", \\\"{x:1235,y:968,t:1527632038670};\\\", \\\"{x:1234,y:967,t:1527632038687};\\\", \\\"{x:1232,y:967,t:1527632038702};\\\", \\\"{x:1232,y:966,t:1527632038719};\\\", \\\"{x:1231,y:966,t:1527632038727};\\\", \\\"{x:1229,y:966,t:1527632038848};\\\", \\\"{x:1228,y:965,t:1527632038863};\\\", \\\"{x:1227,y:963,t:1527632044432};\\\", \\\"{x:1229,y:957,t:1527632044450};\\\", \\\"{x:1235,y:949,t:1527632044465};\\\", \\\"{x:1238,y:943,t:1527632044482};\\\", \\\"{x:1240,y:938,t:1527632044498};\\\", \\\"{x:1242,y:933,t:1527632044516};\\\", \\\"{x:1246,y:924,t:1527632044532};\\\", \\\"{x:1250,y:915,t:1527632044549};\\\", \\\"{x:1253,y:903,t:1527632044565};\\\", \\\"{x:1260,y:888,t:1527632044582};\\\", \\\"{x:1273,y:875,t:1527632044600};\\\", \\\"{x:1283,y:863,t:1527632044615};\\\", \\\"{x:1294,y:851,t:1527632044633};\\\", \\\"{x:1304,y:838,t:1527632044649};\\\", \\\"{x:1313,y:827,t:1527632044665};\\\", \\\"{x:1324,y:813,t:1527632044682};\\\", \\\"{x:1330,y:804,t:1527632044700};\\\", \\\"{x:1333,y:797,t:1527632044715};\\\", \\\"{x:1336,y:791,t:1527632044733};\\\", \\\"{x:1337,y:786,t:1527632044750};\\\", \\\"{x:1340,y:777,t:1527632044766};\\\", \\\"{x:1342,y:770,t:1527632044782};\\\", \\\"{x:1344,y:759,t:1527632044800};\\\", \\\"{x:1346,y:753,t:1527632044817};\\\", \\\"{x:1346,y:750,t:1527632044832};\\\", \\\"{x:1347,y:747,t:1527632044849};\\\", \\\"{x:1348,y:745,t:1527632044866};\\\", \\\"{x:1349,y:738,t:1527632044882};\\\", \\\"{x:1351,y:733,t:1527632044899};\\\", \\\"{x:1354,y:725,t:1527632044915};\\\", \\\"{x:1356,y:720,t:1527632044932};\\\", \\\"{x:1359,y:714,t:1527632044949};\\\", \\\"{x:1361,y:709,t:1527632044966};\\\", \\\"{x:1362,y:707,t:1527632044981};\\\", \\\"{x:1363,y:704,t:1527632044998};\\\", \\\"{x:1363,y:703,t:1527632047656};\\\", \\\"{x:1362,y:703,t:1527632047680};\\\", \\\"{x:1360,y:702,t:1527632047695};\\\", \\\"{x:1357,y:701,t:1527632047711};\\\", \\\"{x:1355,y:701,t:1527632047719};\\\", \\\"{x:1356,y:704,t:1527632048088};\\\", \\\"{x:1360,y:709,t:1527632048101};\\\", \\\"{x:1363,y:716,t:1527632048119};\\\", \\\"{x:1367,y:724,t:1527632048136};\\\", \\\"{x:1371,y:729,t:1527632048151};\\\", \\\"{x:1378,y:738,t:1527632048168};\\\", \\\"{x:1387,y:749,t:1527632048185};\\\", \\\"{x:1394,y:760,t:1527632048201};\\\", \\\"{x:1405,y:773,t:1527632048219};\\\", \\\"{x:1413,y:787,t:1527632048236};\\\", \\\"{x:1421,y:801,t:1527632048252};\\\", \\\"{x:1431,y:816,t:1527632048269};\\\", \\\"{x:1438,y:824,t:1527632048285};\\\", \\\"{x:1442,y:828,t:1527632048302};\\\", \\\"{x:1443,y:829,t:1527632048319};\\\", \\\"{x:1444,y:830,t:1527632048359};\\\", \\\"{x:1445,y:831,t:1527632048416};\\\", \\\"{x:1447,y:831,t:1527632048440};\\\", \\\"{x:1447,y:832,t:1527632048456};\\\", \\\"{x:1448,y:832,t:1527632048468};\\\", \\\"{x:1450,y:833,t:1527632048486};\\\", \\\"{x:1451,y:833,t:1527632048503};\\\", \\\"{x:1454,y:833,t:1527632048518};\\\", \\\"{x:1466,y:833,t:1527632048535};\\\", \\\"{x:1482,y:830,t:1527632048552};\\\", \\\"{x:1487,y:829,t:1527632048570};\\\", \\\"{x:1491,y:827,t:1527632048585};\\\", \\\"{x:1489,y:827,t:1527632048695};\\\", \\\"{x:1485,y:827,t:1527632048704};\\\", \\\"{x:1482,y:828,t:1527632048719};\\\", \\\"{x:1475,y:830,t:1527632048736};\\\", \\\"{x:1474,y:831,t:1527632048753};\\\", \\\"{x:1472,y:831,t:1527632048769};\\\", \\\"{x:1473,y:831,t:1527632049032};\\\", \\\"{x:1474,y:831,t:1527632049039};\\\", \\\"{x:1476,y:830,t:1527632049053};\\\", \\\"{x:1477,y:830,t:1527632049070};\\\", \\\"{x:1478,y:830,t:1527632049085};\\\", \\\"{x:1479,y:830,t:1527632049102};\\\", \\\"{x:1479,y:829,t:1527632049119};\\\", \\\"{x:1479,y:830,t:1527632053127};\\\", \\\"{x:1480,y:831,t:1527632053151};\\\", \\\"{x:1480,y:832,t:1527632053167};\\\", \\\"{x:1481,y:833,t:1527632053191};\\\", \\\"{x:1482,y:835,t:1527632053207};\\\", \\\"{x:1482,y:837,t:1527632053223};\\\", \\\"{x:1486,y:845,t:1527632053239};\\\", \\\"{x:1490,y:853,t:1527632053256};\\\", \\\"{x:1496,y:865,t:1527632053273};\\\", \\\"{x:1503,y:878,t:1527632053289};\\\", \\\"{x:1509,y:889,t:1527632053306};\\\", \\\"{x:1515,y:899,t:1527632053323};\\\", \\\"{x:1519,y:907,t:1527632053340};\\\", \\\"{x:1523,y:916,t:1527632053355};\\\", \\\"{x:1529,y:927,t:1527632053373};\\\", \\\"{x:1533,y:935,t:1527632053390};\\\", \\\"{x:1536,y:939,t:1527632053406};\\\", \\\"{x:1536,y:940,t:1527632053422};\\\", \\\"{x:1537,y:941,t:1527632053439};\\\", \\\"{x:1537,y:943,t:1527632053456};\\\", \\\"{x:1539,y:945,t:1527632053473};\\\", \\\"{x:1539,y:946,t:1527632053489};\\\", \\\"{x:1539,y:949,t:1527632053506};\\\", \\\"{x:1540,y:953,t:1527632053522};\\\", \\\"{x:1540,y:954,t:1527632053543};\\\", \\\"{x:1541,y:955,t:1527632053560};\\\", \\\"{x:1541,y:956,t:1527632053572};\\\", \\\"{x:1541,y:957,t:1527632053590};\\\", \\\"{x:1541,y:959,t:1527632053607};\\\", \\\"{x:1542,y:960,t:1527632053632};\\\", \\\"{x:1543,y:960,t:1527632053647};\\\", \\\"{x:1543,y:961,t:1527632053657};\\\", \\\"{x:1543,y:962,t:1527632053673};\\\", \\\"{x:1544,y:964,t:1527632053690};\\\", \\\"{x:1545,y:965,t:1527632053744};\\\", \\\"{x:1546,y:965,t:1527632053760};\\\", \\\"{x:1548,y:965,t:1527632053784};\\\", \\\"{x:1549,y:965,t:1527632053791};\\\", \\\"{x:1550,y:965,t:1527632053807};\\\", \\\"{x:1553,y:964,t:1527632053823};\\\", \\\"{x:1557,y:962,t:1527632053840};\\\", \\\"{x:1562,y:961,t:1527632053856};\\\", \\\"{x:1567,y:960,t:1527632053873};\\\", \\\"{x:1575,y:958,t:1527632053890};\\\", \\\"{x:1585,y:957,t:1527632053907};\\\", \\\"{x:1593,y:956,t:1527632053923};\\\", \\\"{x:1601,y:954,t:1527632053940};\\\", \\\"{x:1605,y:954,t:1527632053957};\\\", \\\"{x:1607,y:954,t:1527632053973};\\\", \\\"{x:1608,y:953,t:1527632053990};\\\", \\\"{x:1609,y:953,t:1527632054120};\\\", \\\"{x:1611,y:953,t:1527632056001};\\\", \\\"{x:1612,y:953,t:1527632056046};\\\", \\\"{x:1613,y:954,t:1527632056070};\\\", \\\"{x:1614,y:954,t:1527632056143};\\\", \\\"{x:1615,y:954,t:1527632056191};\\\", \\\"{x:1616,y:954,t:1527632056215};\\\", \\\"{x:1617,y:954,t:1527632056239};\\\", \\\"{x:1617,y:955,t:1527632056248};\\\", \\\"{x:1618,y:955,t:1527632056424};\\\", \\\"{x:1614,y:955,t:1527632057824};\\\", \\\"{x:1608,y:955,t:1527632057831};\\\", \\\"{x:1599,y:955,t:1527632057843};\\\", \\\"{x:1582,y:952,t:1527632057860};\\\", \\\"{x:1562,y:950,t:1527632057876};\\\", \\\"{x:1549,y:947,t:1527632057893};\\\", \\\"{x:1537,y:945,t:1527632057910};\\\", \\\"{x:1514,y:939,t:1527632057927};\\\", \\\"{x:1502,y:935,t:1527632057943};\\\", \\\"{x:1489,y:931,t:1527632057959};\\\", \\\"{x:1473,y:924,t:1527632057976};\\\", \\\"{x:1440,y:906,t:1527632057992};\\\", \\\"{x:1405,y:888,t:1527632058009};\\\", \\\"{x:1370,y:867,t:1527632058026};\\\", \\\"{x:1347,y:856,t:1527632058042};\\\", \\\"{x:1323,y:843,t:1527632058059};\\\", \\\"{x:1308,y:835,t:1527632058076};\\\", \\\"{x:1299,y:822,t:1527632058092};\\\", \\\"{x:1291,y:806,t:1527632058109};\\\", \\\"{x:1283,y:786,t:1527632058126};\\\", \\\"{x:1281,y:777,t:1527632058142};\\\", \\\"{x:1279,y:767,t:1527632058159};\\\", \\\"{x:1277,y:762,t:1527632058176};\\\", \\\"{x:1277,y:757,t:1527632058192};\\\", \\\"{x:1279,y:750,t:1527632058210};\\\", \\\"{x:1281,y:745,t:1527632058226};\\\", \\\"{x:1283,y:743,t:1527632058242};\\\", \\\"{x:1284,y:738,t:1527632058260};\\\", \\\"{x:1286,y:736,t:1527632058276};\\\", \\\"{x:1287,y:734,t:1527632058293};\\\", \\\"{x:1289,y:732,t:1527632058310};\\\", \\\"{x:1293,y:728,t:1527632058327};\\\", \\\"{x:1297,y:726,t:1527632058343};\\\", \\\"{x:1298,y:726,t:1527632058368};\\\", \\\"{x:1300,y:725,t:1527632058377};\\\", \\\"{x:1305,y:725,t:1527632058394};\\\", \\\"{x:1308,y:723,t:1527632058410};\\\", \\\"{x:1312,y:721,t:1527632058426};\\\", \\\"{x:1314,y:720,t:1527632058444};\\\", \\\"{x:1318,y:718,t:1527632058459};\\\", \\\"{x:1324,y:716,t:1527632058476};\\\", \\\"{x:1328,y:712,t:1527632058493};\\\", \\\"{x:1335,y:711,t:1527632058510};\\\", \\\"{x:1344,y:706,t:1527632058526};\\\", \\\"{x:1346,y:706,t:1527632058543};\\\", \\\"{x:1347,y:705,t:1527632058655};\\\", \\\"{x:1348,y:704,t:1527632058791};\\\", \\\"{x:1349,y:703,t:1527632058800};\\\", \\\"{x:1349,y:701,t:1527632058810};\\\", \\\"{x:1351,y:698,t:1527632058826};\\\", \\\"{x:1353,y:696,t:1527632058843};\\\", \\\"{x:1353,y:695,t:1527632058860};\\\", \\\"{x:1353,y:694,t:1527632058902};\\\", \\\"{x:1354,y:694,t:1527632058911};\\\", \\\"{x:1354,y:691,t:1527632060635};\\\", \\\"{x:1354,y:688,t:1527632060648};\\\", \\\"{x:1354,y:682,t:1527632060665};\\\", \\\"{x:1354,y:673,t:1527632060681};\\\", \\\"{x:1354,y:667,t:1527632060698};\\\", \\\"{x:1354,y:666,t:1527632060715};\\\", \\\"{x:1354,y:664,t:1527632060732};\\\", \\\"{x:1354,y:663,t:1527632060748};\\\", \\\"{x:1354,y:662,t:1527632060765};\\\", \\\"{x:1354,y:661,t:1527632060783};\\\", \\\"{x:1354,y:658,t:1527632060798};\\\", \\\"{x:1354,y:655,t:1527632060816};\\\", \\\"{x:1354,y:650,t:1527632060832};\\\", \\\"{x:1354,y:644,t:1527632060848};\\\", \\\"{x:1354,y:640,t:1527632060865};\\\", \\\"{x:1351,y:633,t:1527632060882};\\\", \\\"{x:1351,y:629,t:1527632060898};\\\", \\\"{x:1351,y:626,t:1527632060915};\\\", \\\"{x:1351,y:621,t:1527632060932};\\\", \\\"{x:1350,y:619,t:1527632060948};\\\", \\\"{x:1349,y:616,t:1527632060965};\\\", \\\"{x:1349,y:613,t:1527632060982};\\\", \\\"{x:1349,y:611,t:1527632060998};\\\", \\\"{x:1348,y:609,t:1527632061016};\\\", \\\"{x:1348,y:608,t:1527632061032};\\\", \\\"{x:1347,y:607,t:1527632061049};\\\", \\\"{x:1347,y:605,t:1527632061064};\\\", \\\"{x:1347,y:603,t:1527632061081};\\\", \\\"{x:1347,y:601,t:1527632061099};\\\", \\\"{x:1347,y:599,t:1527632061115};\\\", \\\"{x:1347,y:598,t:1527632061131};\\\", \\\"{x:1345,y:595,t:1527632061149};\\\", \\\"{x:1345,y:593,t:1527632061164};\\\", \\\"{x:1345,y:592,t:1527632061182};\\\", \\\"{x:1345,y:590,t:1527632061199};\\\", \\\"{x:1345,y:589,t:1527632061214};\\\", \\\"{x:1345,y:587,t:1527632061258};\\\", \\\"{x:1344,y:587,t:1527632061811};\\\", \\\"{x:1341,y:587,t:1527632061834};\\\", \\\"{x:1340,y:587,t:1527632061859};\\\", \\\"{x:1339,y:587,t:1527632061866};\\\", \\\"{x:1336,y:587,t:1527632061883};\\\", \\\"{x:1332,y:587,t:1527632061900};\\\", \\\"{x:1329,y:587,t:1527632061916};\\\", \\\"{x:1325,y:587,t:1527632061933};\\\", \\\"{x:1322,y:587,t:1527632061949};\\\", \\\"{x:1313,y:585,t:1527632061967};\\\", \\\"{x:1307,y:584,t:1527632061983};\\\", \\\"{x:1299,y:581,t:1527632062000};\\\", \\\"{x:1292,y:580,t:1527632062017};\\\", \\\"{x:1288,y:578,t:1527632062033};\\\", \\\"{x:1287,y:578,t:1527632062049};\\\", \\\"{x:1283,y:576,t:1527632062065};\\\", \\\"{x:1281,y:576,t:1527632062082};\\\", \\\"{x:1279,y:573,t:1527632062099};\\\", \\\"{x:1276,y:571,t:1527632062115};\\\", \\\"{x:1275,y:570,t:1527632062133};\\\", \\\"{x:1274,y:569,t:1527632062148};\\\", \\\"{x:1273,y:568,t:1527632062169};\\\", \\\"{x:1273,y:567,t:1527632062209};\\\", \\\"{x:1287,y:579,t:1527632065891};\\\", \\\"{x:1307,y:594,t:1527632065903};\\\", \\\"{x:1349,y:622,t:1527632065920};\\\", \\\"{x:1409,y:644,t:1527632065936};\\\", \\\"{x:1457,y:660,t:1527632065952};\\\", \\\"{x:1509,y:672,t:1527632065969};\\\", \\\"{x:1598,y:705,t:1527632065986};\\\", \\\"{x:1651,y:723,t:1527632066002};\\\", \\\"{x:1679,y:731,t:1527632066019};\\\", \\\"{x:1696,y:736,t:1527632066036};\\\", \\\"{x:1700,y:739,t:1527632066052};\\\", \\\"{x:1701,y:740,t:1527632066069};\\\", \\\"{x:1701,y:741,t:1527632066091};\\\", \\\"{x:1701,y:742,t:1527632066139};\\\", \\\"{x:1700,y:743,t:1527632066154};\\\", \\\"{x:1697,y:745,t:1527632066170};\\\", \\\"{x:1692,y:749,t:1527632066187};\\\", \\\"{x:1683,y:753,t:1527632066202};\\\", \\\"{x:1670,y:756,t:1527632066219};\\\", \\\"{x:1653,y:759,t:1527632066236};\\\", \\\"{x:1637,y:760,t:1527632066254};\\\", \\\"{x:1626,y:760,t:1527632066269};\\\", \\\"{x:1614,y:760,t:1527632066286};\\\", \\\"{x:1605,y:757,t:1527632066303};\\\", \\\"{x:1596,y:753,t:1527632066320};\\\", \\\"{x:1585,y:748,t:1527632066336};\\\", \\\"{x:1578,y:744,t:1527632066353};\\\", \\\"{x:1571,y:736,t:1527632066369};\\\", \\\"{x:1563,y:722,t:1527632066387};\\\", \\\"{x:1556,y:712,t:1527632066403};\\\", \\\"{x:1548,y:702,t:1527632066420};\\\", \\\"{x:1539,y:690,t:1527632066436};\\\", \\\"{x:1526,y:676,t:1527632066453};\\\", \\\"{x:1512,y:663,t:1527632066469};\\\", \\\"{x:1501,y:652,t:1527632066486};\\\", \\\"{x:1491,y:643,t:1527632066503};\\\", \\\"{x:1486,y:636,t:1527632066520};\\\", \\\"{x:1481,y:630,t:1527632066536};\\\", \\\"{x:1479,y:626,t:1527632066554};\\\", \\\"{x:1477,y:621,t:1527632066570};\\\", \\\"{x:1472,y:613,t:1527632066586};\\\", \\\"{x:1470,y:609,t:1527632066603};\\\", \\\"{x:1468,y:607,t:1527632066619};\\\", \\\"{x:1466,y:604,t:1527632066636};\\\", \\\"{x:1464,y:601,t:1527632066654};\\\", \\\"{x:1460,y:595,t:1527632066670};\\\", \\\"{x:1457,y:590,t:1527632066686};\\\", \\\"{x:1454,y:585,t:1527632066703};\\\", \\\"{x:1451,y:580,t:1527632066721};\\\", \\\"{x:1448,y:576,t:1527632066736};\\\", \\\"{x:1447,y:574,t:1527632066754};\\\", \\\"{x:1445,y:572,t:1527632066770};\\\", \\\"{x:1444,y:571,t:1527632066787};\\\", \\\"{x:1442,y:570,t:1527632066803};\\\", \\\"{x:1442,y:569,t:1527632066821};\\\", \\\"{x:1441,y:569,t:1527632066837};\\\", \\\"{x:1439,y:568,t:1527632066859};\\\", \\\"{x:1438,y:568,t:1527632066875};\\\", \\\"{x:1436,y:568,t:1527632066886};\\\", \\\"{x:1433,y:568,t:1527632066903};\\\", \\\"{x:1430,y:568,t:1527632066920};\\\", \\\"{x:1429,y:568,t:1527632066937};\\\", \\\"{x:1427,y:568,t:1527632066954};\\\", \\\"{x:1425,y:568,t:1527632066970};\\\", \\\"{x:1423,y:568,t:1527632066987};\\\", \\\"{x:1422,y:568,t:1527632067010};\\\", \\\"{x:1420,y:568,t:1527632067346};\\\", \\\"{x:1419,y:568,t:1527632067354};\\\", \\\"{x:1415,y:570,t:1527632067370};\\\", \\\"{x:1414,y:572,t:1527632067387};\\\", \\\"{x:1411,y:575,t:1527632067403};\\\", \\\"{x:1411,y:576,t:1527632067421};\\\", \\\"{x:1409,y:577,t:1527632067438};\\\", \\\"{x:1409,y:578,t:1527632067963};\\\", \\\"{x:1408,y:578,t:1527632067978};\\\", \\\"{x:1409,y:575,t:1527632070811};\\\", \\\"{x:1410,y:573,t:1527632070823};\\\", \\\"{x:1412,y:569,t:1527632070838};\\\", \\\"{x:1413,y:569,t:1527632070856};\\\", \\\"{x:1414,y:569,t:1527632070873};\\\", \\\"{x:1414,y:568,t:1527632070889};\\\", \\\"{x:1415,y:568,t:1527632070906};\\\", \\\"{x:1416,y:568,t:1527632074338};\\\", \\\"{x:1417,y:570,t:1527632074347};\\\", \\\"{x:1417,y:572,t:1527632074360};\\\", \\\"{x:1419,y:575,t:1527632074375};\\\", \\\"{x:1420,y:577,t:1527632074393};\\\", \\\"{x:1422,y:580,t:1527632074410};\\\", \\\"{x:1423,y:580,t:1527632074426};\\\", \\\"{x:1423,y:581,t:1527632074443};\\\", \\\"{x:1424,y:584,t:1527632074460};\\\", \\\"{x:1427,y:591,t:1527632074475};\\\", \\\"{x:1430,y:597,t:1527632074492};\\\", \\\"{x:1431,y:600,t:1527632074509};\\\", \\\"{x:1432,y:602,t:1527632074526};\\\", \\\"{x:1434,y:605,t:1527632074543};\\\", \\\"{x:1436,y:608,t:1527632074559};\\\", \\\"{x:1438,y:610,t:1527632074577};\\\", \\\"{x:1440,y:613,t:1527632074593};\\\", \\\"{x:1442,y:615,t:1527632074610};\\\", \\\"{x:1443,y:617,t:1527632074626};\\\", \\\"{x:1445,y:619,t:1527632074642};\\\", \\\"{x:1446,y:621,t:1527632074682};\\\", \\\"{x:1447,y:621,t:1527632074692};\\\", \\\"{x:1448,y:622,t:1527632074738};\\\", \\\"{x:1448,y:623,t:1527632074762};\\\", \\\"{x:1448,y:624,t:1527632074811};\\\", \\\"{x:1448,y:625,t:1527632076292};\\\", \\\"{x:1448,y:626,t:1527632076311};\\\", \\\"{x:1450,y:627,t:1527632076328};\\\", \\\"{x:1451,y:628,t:1527632076362};\\\", \\\"{x:1451,y:629,t:1527632076386};\\\", \\\"{x:1452,y:632,t:1527632076411};\\\", \\\"{x:1454,y:633,t:1527632076429};\\\", \\\"{x:1455,y:636,t:1527632076444};\\\", \\\"{x:1456,y:636,t:1527632076461};\\\", \\\"{x:1456,y:637,t:1527632076478};\\\", \\\"{x:1458,y:639,t:1527632076495};\\\", \\\"{x:1459,y:639,t:1527632076563};\\\", \\\"{x:1454,y:639,t:1527632077586};\\\", \\\"{x:1444,y:639,t:1527632077595};\\\", \\\"{x:1402,y:641,t:1527632077612};\\\", \\\"{x:1368,y:636,t:1527632077629};\\\", \\\"{x:1358,y:631,t:1527632077646};\\\", \\\"{x:1358,y:629,t:1527632077905};\\\", \\\"{x:1358,y:628,t:1527632077921};\\\", \\\"{x:1357,y:627,t:1527632077929};\\\", \\\"{x:1353,y:624,t:1527632077946};\\\", \\\"{x:1341,y:620,t:1527632077961};\\\", \\\"{x:1297,y:615,t:1527632077979};\\\", \\\"{x:1213,y:613,t:1527632077995};\\\", \\\"{x:1120,y:609,t:1527632078011};\\\", \\\"{x:1024,y:602,t:1527632078028};\\\", \\\"{x:939,y:592,t:1527632078046};\\\", \\\"{x:903,y:590,t:1527632078062};\\\", \\\"{x:808,y:590,t:1527632078078};\\\", \\\"{x:716,y:588,t:1527632078092};\\\", \\\"{x:627,y:584,t:1527632078109};\\\", \\\"{x:582,y:584,t:1527632078128};\\\", \\\"{x:549,y:584,t:1527632078144};\\\", \\\"{x:538,y:584,t:1527632078161};\\\", \\\"{x:523,y:584,t:1527632078178};\\\", \\\"{x:509,y:584,t:1527632078194};\\\", \\\"{x:489,y:584,t:1527632078213};\\\", \\\"{x:458,y:584,t:1527632078228};\\\", \\\"{x:413,y:584,t:1527632078245};\\\", \\\"{x:363,y:584,t:1527632078263};\\\", \\\"{x:312,y:583,t:1527632078278};\\\", \\\"{x:278,y:580,t:1527632078295};\\\", \\\"{x:250,y:580,t:1527632078313};\\\", \\\"{x:229,y:579,t:1527632078328};\\\", \\\"{x:193,y:579,t:1527632078345};\\\", \\\"{x:169,y:579,t:1527632078362};\\\", \\\"{x:144,y:579,t:1527632078378};\\\", \\\"{x:132,y:579,t:1527632078395};\\\", \\\"{x:128,y:579,t:1527632078412};\\\", \\\"{x:126,y:579,t:1527632078449};\\\", \\\"{x:124,y:579,t:1527632078506};\\\", \\\"{x:123,y:579,t:1527632078521};\\\", \\\"{x:127,y:579,t:1527632078643};\\\", \\\"{x:134,y:579,t:1527632078650};\\\", \\\"{x:141,y:579,t:1527632078663};\\\", \\\"{x:169,y:579,t:1527632078681};\\\", \\\"{x:211,y:579,t:1527632078695};\\\", \\\"{x:256,y:579,t:1527632078711};\\\", \\\"{x:304,y:579,t:1527632078727};\\\", \\\"{x:354,y:579,t:1527632078744};\\\", \\\"{x:387,y:579,t:1527632078762};\\\", \\\"{x:406,y:579,t:1527632078778};\\\", \\\"{x:422,y:579,t:1527632078795};\\\", \\\"{x:443,y:579,t:1527632078812};\\\", \\\"{x:467,y:579,t:1527632078828};\\\", \\\"{x:501,y:579,t:1527632078846};\\\", \\\"{x:530,y:579,t:1527632078862};\\\", \\\"{x:559,y:579,t:1527632078879};\\\", \\\"{x:574,y:578,t:1527632078895};\\\", \\\"{x:585,y:577,t:1527632078912};\\\", \\\"{x:614,y:571,t:1527632078929};\\\", \\\"{x:639,y:566,t:1527632078945};\\\", \\\"{x:661,y:561,t:1527632078963};\\\", \\\"{x:665,y:560,t:1527632078979};\\\", \\\"{x:665,y:559,t:1527632078995};\\\", \\\"{x:672,y:558,t:1527632079012};\\\", \\\"{x:682,y:557,t:1527632079029};\\\", \\\"{x:689,y:554,t:1527632079046};\\\", \\\"{x:693,y:554,t:1527632079062};\\\", \\\"{x:709,y:550,t:1527632079079};\\\", \\\"{x:732,y:547,t:1527632079096};\\\", \\\"{x:745,y:543,t:1527632079112};\\\", \\\"{x:761,y:538,t:1527632079129};\\\", \\\"{x:769,y:536,t:1527632079145};\\\", \\\"{x:774,y:534,t:1527632079162};\\\", \\\"{x:776,y:534,t:1527632079179};\\\", \\\"{x:780,y:533,t:1527632079196};\\\", \\\"{x:787,y:532,t:1527632079212};\\\", \\\"{x:797,y:531,t:1527632079229};\\\", \\\"{x:807,y:530,t:1527632079246};\\\", \\\"{x:810,y:529,t:1527632079262};\\\", \\\"{x:811,y:529,t:1527632079280};\\\", \\\"{x:813,y:529,t:1527632079296};\\\", \\\"{x:815,y:529,t:1527632079313};\\\", \\\"{x:817,y:529,t:1527632079329};\\\", \\\"{x:821,y:529,t:1527632079346};\\\", \\\"{x:823,y:529,t:1527632079363};\\\", \\\"{x:824,y:529,t:1527632079380};\\\", \\\"{x:825,y:529,t:1527632079397};\\\", \\\"{x:826,y:529,t:1527632079413};\\\", \\\"{x:827,y:530,t:1527632079429};\\\", \\\"{x:829,y:531,t:1527632079447};\\\", \\\"{x:830,y:532,t:1527632079466};\\\", \\\"{x:832,y:533,t:1527632079523};\\\", \\\"{x:833,y:533,t:1527632079594};\\\", \\\"{x:833,y:534,t:1527632080162};\\\", \\\"{x:832,y:534,t:1527632080178};\\\", \\\"{x:829,y:534,t:1527632080186};\\\", \\\"{x:827,y:534,t:1527632080197};\\\", \\\"{x:822,y:534,t:1527632080216};\\\", \\\"{x:818,y:534,t:1527632080230};\\\", \\\"{x:812,y:534,t:1527632080246};\\\", \\\"{x:808,y:534,t:1527632080263};\\\", \\\"{x:802,y:531,t:1527632080280};\\\", \\\"{x:791,y:525,t:1527632080296};\\\", \\\"{x:778,y:518,t:1527632080314};\\\", \\\"{x:765,y:509,t:1527632080331};\\\", \\\"{x:753,y:500,t:1527632080346};\\\", \\\"{x:742,y:492,t:1527632080363};\\\", \\\"{x:731,y:484,t:1527632080381};\\\", \\\"{x:721,y:476,t:1527632080396};\\\", \\\"{x:711,y:469,t:1527632080414};\\\", \\\"{x:704,y:465,t:1527632080430};\\\", \\\"{x:698,y:461,t:1527632080447};\\\", \\\"{x:690,y:456,t:1527632080463};\\\", \\\"{x:688,y:456,t:1527632080481};\\\", \\\"{x:688,y:455,t:1527632080497};\\\", \\\"{x:687,y:455,t:1527632080522};\\\", \\\"{x:685,y:455,t:1527632080530};\\\", \\\"{x:684,y:455,t:1527632080562};\\\", \\\"{x:683,y:455,t:1527632080586};\\\", \\\"{x:682,y:455,t:1527632080891};\\\", \\\"{x:698,y:458,t:1527632080898};\\\", \\\"{x:789,y:468,t:1527632080914};\\\", \\\"{x:878,y:468,t:1527632080931};\\\", \\\"{x:973,y:470,t:1527632080948};\\\", \\\"{x:1044,y:477,t:1527632080965};\\\", \\\"{x:1139,y:492,t:1527632080981};\\\", \\\"{x:1185,y:499,t:1527632080998};\\\", \\\"{x:1263,y:512,t:1527632081015};\\\", \\\"{x:1322,y:522,t:1527632081030};\\\", \\\"{x:1353,y:529,t:1527632081047};\\\", \\\"{x:1367,y:533,t:1527632081064};\\\", \\\"{x:1371,y:535,t:1527632081080};\\\", \\\"{x:1374,y:537,t:1527632081097};\\\", \\\"{x:1375,y:543,t:1527632081114};\\\", \\\"{x:1379,y:552,t:1527632081131};\\\", \\\"{x:1385,y:567,t:1527632081148};\\\", \\\"{x:1391,y:581,t:1527632081164};\\\", \\\"{x:1397,y:595,t:1527632081180};\\\", \\\"{x:1405,y:607,t:1527632081197};\\\", \\\"{x:1409,y:615,t:1527632081214};\\\", \\\"{x:1411,y:617,t:1527632081230};\\\", \\\"{x:1412,y:621,t:1527632081247};\\\", \\\"{x:1413,y:624,t:1527632081265};\\\", \\\"{x:1414,y:630,t:1527632081280};\\\", \\\"{x:1414,y:639,t:1527632081298};\\\", \\\"{x:1416,y:643,t:1527632081314};\\\", \\\"{x:1417,y:648,t:1527632081331};\\\", \\\"{x:1417,y:651,t:1527632081348};\\\", \\\"{x:1417,y:654,t:1527632081365};\\\", \\\"{x:1416,y:660,t:1527632081382};\\\", \\\"{x:1411,y:672,t:1527632081398};\\\", \\\"{x:1406,y:683,t:1527632081416};\\\", \\\"{x:1404,y:691,t:1527632081431};\\\", \\\"{x:1402,y:696,t:1527632081448};\\\", \\\"{x:1402,y:698,t:1527632081465};\\\", \\\"{x:1401,y:701,t:1527632081481};\\\", \\\"{x:1400,y:703,t:1527632081498};\\\", \\\"{x:1400,y:704,t:1527632081515};\\\", \\\"{x:1399,y:708,t:1527632081531};\\\", \\\"{x:1399,y:710,t:1527632081547};\\\", \\\"{x:1398,y:715,t:1527632081565};\\\", \\\"{x:1395,y:721,t:1527632081581};\\\", \\\"{x:1395,y:728,t:1527632081597};\\\", \\\"{x:1393,y:731,t:1527632081615};\\\", \\\"{x:1390,y:739,t:1527632081632};\\\", \\\"{x:1387,y:743,t:1527632081648};\\\", \\\"{x:1385,y:746,t:1527632081666};\\\", \\\"{x:1382,y:750,t:1527632081681};\\\", \\\"{x:1382,y:749,t:1527632081851};\\\", \\\"{x:1382,y:746,t:1527632081865};\\\", \\\"{x:1388,y:738,t:1527632081882};\\\", \\\"{x:1392,y:731,t:1527632081898};\\\", \\\"{x:1396,y:724,t:1527632081915};\\\", \\\"{x:1402,y:716,t:1527632081932};\\\", \\\"{x:1404,y:712,t:1527632081949};\\\", \\\"{x:1406,y:709,t:1527632081965};\\\", \\\"{x:1408,y:707,t:1527632081982};\\\", \\\"{x:1408,y:706,t:1527632081999};\\\", \\\"{x:1409,y:705,t:1527632082025};\\\", \\\"{x:1409,y:706,t:1527632082113};\\\", \\\"{x:1409,y:708,t:1527632082121};\\\", \\\"{x:1407,y:712,t:1527632082131};\\\", \\\"{x:1404,y:718,t:1527632082148};\\\", \\\"{x:1402,y:724,t:1527632082164};\\\", \\\"{x:1399,y:730,t:1527632082182};\\\", \\\"{x:1398,y:734,t:1527632082198};\\\", \\\"{x:1395,y:740,t:1527632082214};\\\", \\\"{x:1393,y:743,t:1527632082231};\\\", \\\"{x:1392,y:745,t:1527632082248};\\\", \\\"{x:1391,y:747,t:1527632082266};\\\", \\\"{x:1389,y:748,t:1527632082282};\\\", \\\"{x:1388,y:750,t:1527632082298};\\\", \\\"{x:1387,y:752,t:1527632082316};\\\", \\\"{x:1386,y:754,t:1527632082331};\\\", \\\"{x:1385,y:755,t:1527632082348};\\\", \\\"{x:1384,y:757,t:1527632082366};\\\", \\\"{x:1384,y:759,t:1527632082382};\\\", \\\"{x:1383,y:761,t:1527632082399};\\\", \\\"{x:1382,y:763,t:1527632082416};\\\", \\\"{x:1382,y:764,t:1527632082432};\\\", \\\"{x:1382,y:766,t:1527632082449};\\\", \\\"{x:1382,y:769,t:1527632082465};\\\", \\\"{x:1382,y:770,t:1527632082482};\\\", \\\"{x:1382,y:773,t:1527632082498};\\\", \\\"{x:1382,y:774,t:1527632082515};\\\", \\\"{x:1382,y:775,t:1527632082531};\\\", \\\"{x:1381,y:777,t:1527632082548};\\\", \\\"{x:1381,y:779,t:1527632082810};\\\", \\\"{x:1380,y:781,t:1527632082826};\\\", \\\"{x:1379,y:783,t:1527632082842};\\\", \\\"{x:1379,y:784,t:1527632082858};\\\", \\\"{x:1378,y:786,t:1527632082874};\\\", \\\"{x:1378,y:787,t:1527632082914};\\\", \\\"{x:1378,y:789,t:1527632083059};\\\", \\\"{x:1376,y:791,t:1527632083074};\\\", \\\"{x:1372,y:791,t:1527632083082};\\\", \\\"{x:1369,y:791,t:1527632083099};\\\", \\\"{x:1355,y:791,t:1527632083116};\\\", \\\"{x:1338,y:791,t:1527632083133};\\\", \\\"{x:1310,y:791,t:1527632083150};\\\", \\\"{x:1275,y:791,t:1527632083166};\\\", \\\"{x:1217,y:791,t:1527632083183};\\\", \\\"{x:1172,y:791,t:1527632083200};\\\", \\\"{x:1109,y:787,t:1527632083216};\\\", \\\"{x:1052,y:784,t:1527632083232};\\\", \\\"{x:961,y:779,t:1527632083250};\\\", \\\"{x:910,y:778,t:1527632083266};\\\", \\\"{x:852,y:778,t:1527632083283};\\\", \\\"{x:782,y:778,t:1527632083300};\\\", \\\"{x:726,y:778,t:1527632083316};\\\", \\\"{x:684,y:778,t:1527632083332};\\\", \\\"{x:628,y:778,t:1527632083350};\\\", \\\"{x:575,y:778,t:1527632083366};\\\", \\\"{x:538,y:778,t:1527632083382};\\\", \\\"{x:513,y:779,t:1527632083400};\\\", \\\"{x:492,y:781,t:1527632083416};\\\", \\\"{x:478,y:785,t:1527632083432};\\\", \\\"{x:461,y:785,t:1527632083449};\\\", \\\"{x:448,y:787,t:1527632083466};\\\", \\\"{x:437,y:789,t:1527632083483};\\\", \\\"{x:422,y:793,t:1527632083500};\\\", \\\"{x:416,y:795,t:1527632083516};\\\", \\\"{x:415,y:796,t:1527632083532};\\\", \\\"{x:415,y:791,t:1527632083610};\\\", \\\"{x:417,y:783,t:1527632083617};\\\", \\\"{x:420,y:778,t:1527632083633};\\\", \\\"{x:434,y:754,t:1527632083650};\\\", \\\"{x:444,y:746,t:1527632083666};\\\", \\\"{x:455,y:738,t:1527632083684};\\\", \\\"{x:460,y:734,t:1527632083699};\\\", \\\"{x:462,y:732,t:1527632083716};\\\", \\\"{x:464,y:732,t:1527632083732};\\\", \\\"{x:465,y:732,t:1527632083801};\\\", \\\"{x:466,y:732,t:1527632084211};\\\", \\\"{x:467,y:732,t:1527632084217};\\\", \\\"{x:468,y:731,t:1527632084994};\\\", \\\"{x:466,y:724,t:1527632085001};\\\", \\\"{x:454,y:711,t:1527632085018};\\\", \\\"{x:449,y:701,t:1527632085034};\\\", \\\"{x:442,y:677,t:1527632085050};\\\", \\\"{x:433,y:647,t:1527632085067};\\\", \\\"{x:429,y:607,t:1527632085083};\\\", \\\"{x:427,y:575,t:1527632085101};\\\", \\\"{x:427,y:544,t:1527632085117};\\\", \\\"{x:428,y:515,t:1527632085134};\\\", \\\"{x:430,y:482,t:1527632085151};\\\", \\\"{x:435,y:444,t:1527632085167};\\\", \\\"{x:438,y:414,t:1527632085183};\\\" ] }, { \\\"rt\\\": 38982, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 723958, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -J -I -11 AM-11 AM-B -11 AM-11 AM-M -10 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:438,y:413,t:1527632089075};\\\", \\\"{x:436,y:413,t:1527632089105};\\\", \\\"{x:432,y:413,t:1527632089120};\\\", \\\"{x:422,y:407,t:1527632089138};\\\", \\\"{x:421,y:401,t:1527632089153};\\\", \\\"{x:421,y:396,t:1527632089171};\\\", \\\"{x:435,y:387,t:1527632089187};\\\", \\\"{x:453,y:382,t:1527632089204};\\\", \\\"{x:464,y:382,t:1527632089221};\\\", \\\"{x:467,y:382,t:1527632089237};\\\", \\\"{x:467,y:390,t:1527632089254};\\\", \\\"{x:461,y:396,t:1527632089271};\\\", \\\"{x:455,y:402,t:1527632089287};\\\", \\\"{x:449,y:407,t:1527632089304};\\\", \\\"{x:448,y:407,t:1527632089321};\\\", \\\"{x:446,y:406,t:1527632089386};\\\", \\\"{x:438,y:399,t:1527632089404};\\\", \\\"{x:431,y:393,t:1527632089421};\\\", \\\"{x:423,y:387,t:1527632089437};\\\", \\\"{x:416,y:383,t:1527632089454};\\\", \\\"{x:414,y:381,t:1527632089471};\\\", \\\"{x:413,y:381,t:1527632089513};\\\", \\\"{x:413,y:378,t:1527632089522};\\\", \\\"{x:412,y:375,t:1527632089537};\\\", \\\"{x:407,y:361,t:1527632089554};\\\", \\\"{x:406,y:357,t:1527632089571};\\\", \\\"{x:405,y:355,t:1527632089587};\\\", \\\"{x:405,y:354,t:1527632089722};\\\", \\\"{x:407,y:366,t:1527632089737};\\\", \\\"{x:415,y:394,t:1527632089754};\\\", \\\"{x:418,y:411,t:1527632089771};\\\", \\\"{x:424,y:430,t:1527632089788};\\\", \\\"{x:432,y:451,t:1527632089804};\\\", \\\"{x:444,y:474,t:1527632089821};\\\", \\\"{x:453,y:504,t:1527632089840};\\\", \\\"{x:472,y:537,t:1527632089854};\\\", \\\"{x:489,y:564,t:1527632089871};\\\", \\\"{x:505,y:580,t:1527632089888};\\\", \\\"{x:530,y:597,t:1527632089905};\\\", \\\"{x:537,y:599,t:1527632089920};\\\", \\\"{x:541,y:599,t:1527632089938};\\\", \\\"{x:542,y:597,t:1527632090009};\\\", \\\"{x:542,y:591,t:1527632090021};\\\", \\\"{x:547,y:569,t:1527632090037};\\\", \\\"{x:558,y:540,t:1527632090055};\\\", \\\"{x:579,y:502,t:1527632090071};\\\", \\\"{x:604,y:461,t:1527632090088};\\\", \\\"{x:614,y:437,t:1527632090105};\\\", \\\"{x:615,y:429,t:1527632090121};\\\", \\\"{x:614,y:429,t:1527632090490};\\\", \\\"{x:613,y:429,t:1527632090506};\\\", \\\"{x:612,y:429,t:1527632091938};\\\", \\\"{x:610,y:429,t:1527632092082};\\\", \\\"{x:608,y:429,t:1527632092092};\\\", \\\"{x:607,y:429,t:1527632092109};\\\", \\\"{x:606,y:429,t:1527632092634};\\\", \\\"{x:605,y:428,t:1527632092650};\\\", \\\"{x:607,y:426,t:1527632096914};\\\", \\\"{x:649,y:418,t:1527632096921};\\\", \\\"{x:699,y:404,t:1527632096936};\\\", \\\"{x:783,y:386,t:1527632096952};\\\", \\\"{x:855,y:367,t:1527632096969};\\\", \\\"{x:890,y:361,t:1527632096985};\\\", \\\"{x:900,y:360,t:1527632097002};\\\", \\\"{x:900,y:359,t:1527632097019};\\\", \\\"{x:901,y:359,t:1527632097121};\\\", \\\"{x:902,y:359,t:1527632097274};\\\", \\\"{x:904,y:359,t:1527632097287};\\\", \\\"{x:906,y:359,t:1527632097304};\\\", \\\"{x:906,y:362,t:1527632097319};\\\", \\\"{x:915,y:369,t:1527632097337};\\\", \\\"{x:928,y:381,t:1527632097353};\\\", \\\"{x:937,y:388,t:1527632097369};\\\", \\\"{x:943,y:393,t:1527632097386};\\\", \\\"{x:949,y:397,t:1527632097404};\\\", \\\"{x:956,y:401,t:1527632097420};\\\", \\\"{x:965,y:407,t:1527632097436};\\\", \\\"{x:973,y:413,t:1527632097454};\\\", \\\"{x:976,y:417,t:1527632097471};\\\", \\\"{x:981,y:424,t:1527632097487};\\\", \\\"{x:988,y:430,t:1527632097504};\\\", \\\"{x:999,y:438,t:1527632097520};\\\", \\\"{x:1012,y:446,t:1527632097536};\\\", \\\"{x:1048,y:471,t:1527632097553};\\\", \\\"{x:1069,y:484,t:1527632097570};\\\", \\\"{x:1086,y:493,t:1527632097587};\\\", \\\"{x:1108,y:506,t:1527632097603};\\\", \\\"{x:1126,y:513,t:1527632097620};\\\", \\\"{x:1145,y:521,t:1527632097637};\\\", \\\"{x:1161,y:529,t:1527632097653};\\\", \\\"{x:1173,y:534,t:1527632097670};\\\", \\\"{x:1188,y:542,t:1527632097687};\\\", \\\"{x:1202,y:550,t:1527632097703};\\\", \\\"{x:1218,y:557,t:1527632097720};\\\", \\\"{x:1231,y:561,t:1527632097737};\\\", \\\"{x:1238,y:563,t:1527632097753};\\\", \\\"{x:1243,y:565,t:1527632097770};\\\", \\\"{x:1247,y:566,t:1527632097787};\\\", \\\"{x:1255,y:568,t:1527632097804};\\\", \\\"{x:1260,y:569,t:1527632097820};\\\", \\\"{x:1261,y:569,t:1527632097837};\\\", \\\"{x:1262,y:569,t:1527632097874};\\\", \\\"{x:1264,y:569,t:1527632097888};\\\", \\\"{x:1276,y:568,t:1527632097905};\\\", \\\"{x:1289,y:563,t:1527632097922};\\\", \\\"{x:1297,y:560,t:1527632097938};\\\", \\\"{x:1300,y:559,t:1527632097955};\\\", \\\"{x:1303,y:559,t:1527632097971};\\\", \\\"{x:1304,y:559,t:1527632097987};\\\", \\\"{x:1305,y:559,t:1527632098005};\\\", \\\"{x:1308,y:563,t:1527632098021};\\\", \\\"{x:1312,y:576,t:1527632098038};\\\", \\\"{x:1316,y:596,t:1527632098055};\\\", \\\"{x:1320,y:608,t:1527632098071};\\\", \\\"{x:1327,y:625,t:1527632098088};\\\", \\\"{x:1334,y:645,t:1527632098104};\\\", \\\"{x:1344,y:676,t:1527632098122};\\\", \\\"{x:1348,y:688,t:1527632098138};\\\", \\\"{x:1351,y:701,t:1527632098158};\\\", \\\"{x:1353,y:707,t:1527632098172};\\\", \\\"{x:1353,y:714,t:1527632098188};\\\", \\\"{x:1353,y:716,t:1527632098204};\\\", \\\"{x:1353,y:717,t:1527632098221};\\\", \\\"{x:1348,y:719,t:1527632098465};\\\", \\\"{x:1333,y:719,t:1527632098473};\\\", \\\"{x:1314,y:719,t:1527632098488};\\\", \\\"{x:1273,y:727,t:1527632098504};\\\", \\\"{x:1252,y:731,t:1527632098521};\\\", \\\"{x:1236,y:736,t:1527632098538};\\\", \\\"{x:1228,y:741,t:1527632098555};\\\", \\\"{x:1227,y:742,t:1527632098572};\\\", \\\"{x:1226,y:742,t:1527632098589};\\\", \\\"{x:1223,y:745,t:1527632098648};\\\", \\\"{x:1223,y:748,t:1527632098656};\\\", \\\"{x:1222,y:753,t:1527632098672};\\\", \\\"{x:1218,y:762,t:1527632098688};\\\", \\\"{x:1218,y:768,t:1527632098706};\\\", \\\"{x:1218,y:772,t:1527632098722};\\\", \\\"{x:1218,y:777,t:1527632098739};\\\", \\\"{x:1218,y:780,t:1527632098756};\\\", \\\"{x:1218,y:785,t:1527632098772};\\\", \\\"{x:1220,y:788,t:1527632098789};\\\", \\\"{x:1220,y:790,t:1527632098806};\\\", \\\"{x:1222,y:792,t:1527632098822};\\\", \\\"{x:1222,y:793,t:1527632098839};\\\", \\\"{x:1222,y:796,t:1527632098856};\\\", \\\"{x:1222,y:797,t:1527632098873};\\\", \\\"{x:1223,y:800,t:1527632098889};\\\", \\\"{x:1223,y:802,t:1527632098906};\\\", \\\"{x:1223,y:807,t:1527632098923};\\\", \\\"{x:1223,y:811,t:1527632098939};\\\", \\\"{x:1222,y:816,t:1527632098956};\\\", \\\"{x:1220,y:821,t:1527632098973};\\\", \\\"{x:1218,y:824,t:1527632098989};\\\", \\\"{x:1214,y:827,t:1527632099007};\\\", \\\"{x:1212,y:831,t:1527632099024};\\\", \\\"{x:1210,y:834,t:1527632099040};\\\", \\\"{x:1209,y:836,t:1527632099057};\\\", \\\"{x:1208,y:837,t:1527632099073};\\\", \\\"{x:1204,y:837,t:1527632099626};\\\", \\\"{x:1190,y:837,t:1527632099642};\\\", \\\"{x:1173,y:839,t:1527632099658};\\\", \\\"{x:1158,y:842,t:1527632099675};\\\", \\\"{x:1148,y:843,t:1527632099691};\\\", \\\"{x:1145,y:844,t:1527632099708};\\\", \\\"{x:1144,y:844,t:1527632099724};\\\", \\\"{x:1144,y:842,t:1527632101978};\\\", \\\"{x:1144,y:841,t:1527632102009};\\\", \\\"{x:1145,y:840,t:1527632102090};\\\", \\\"{x:1146,y:839,t:1527632102097};\\\", \\\"{x:1148,y:838,t:1527632102121};\\\", \\\"{x:1148,y:837,t:1527632102129};\\\", \\\"{x:1151,y:834,t:1527632102147};\\\", \\\"{x:1153,y:830,t:1527632102163};\\\", \\\"{x:1155,y:828,t:1527632102180};\\\", \\\"{x:1155,y:827,t:1527632102210};\\\", \\\"{x:1156,y:827,t:1527632102233};\\\", \\\"{x:1156,y:826,t:1527632102246};\\\", \\\"{x:1156,y:824,t:1527632102263};\\\", \\\"{x:1159,y:820,t:1527632102279};\\\", \\\"{x:1164,y:814,t:1527632102295};\\\", \\\"{x:1167,y:807,t:1527632102313};\\\", \\\"{x:1171,y:799,t:1527632102329};\\\", \\\"{x:1179,y:784,t:1527632102346};\\\", \\\"{x:1188,y:769,t:1527632102364};\\\", \\\"{x:1193,y:756,t:1527632102380};\\\", \\\"{x:1200,y:740,t:1527632102396};\\\", \\\"{x:1208,y:725,t:1527632102414};\\\", \\\"{x:1217,y:709,t:1527632102430};\\\", \\\"{x:1224,y:697,t:1527632102447};\\\", \\\"{x:1229,y:685,t:1527632102464};\\\", \\\"{x:1233,y:676,t:1527632102480};\\\", \\\"{x:1236,y:665,t:1527632102496};\\\", \\\"{x:1243,y:647,t:1527632102514};\\\", \\\"{x:1247,y:639,t:1527632102531};\\\", \\\"{x:1250,y:630,t:1527632102548};\\\", \\\"{x:1252,y:624,t:1527632102564};\\\", \\\"{x:1253,y:619,t:1527632102582};\\\", \\\"{x:1254,y:616,t:1527632102597};\\\", \\\"{x:1255,y:612,t:1527632102614};\\\", \\\"{x:1256,y:610,t:1527632102631};\\\", \\\"{x:1257,y:608,t:1527632102648};\\\", \\\"{x:1257,y:605,t:1527632102663};\\\", \\\"{x:1258,y:602,t:1527632102681};\\\", \\\"{x:1259,y:602,t:1527632102697};\\\", \\\"{x:1259,y:600,t:1527632102714};\\\", \\\"{x:1259,y:598,t:1527632102731};\\\", \\\"{x:1260,y:592,t:1527632102747};\\\", \\\"{x:1261,y:590,t:1527632102764};\\\", \\\"{x:1262,y:588,t:1527632102781};\\\", \\\"{x:1263,y:585,t:1527632102798};\\\", \\\"{x:1263,y:583,t:1527632102815};\\\", \\\"{x:1263,y:581,t:1527632102830};\\\", \\\"{x:1265,y:579,t:1527632103611};\\\", \\\"{x:1268,y:577,t:1527632103617};\\\", \\\"{x:1273,y:573,t:1527632103633};\\\", \\\"{x:1276,y:570,t:1527632103650};\\\", \\\"{x:1277,y:569,t:1527632103673};\\\", \\\"{x:1279,y:569,t:1527632105338};\\\", \\\"{x:1280,y:572,t:1527632105352};\\\", \\\"{x:1264,y:613,t:1527632105370};\\\", \\\"{x:1254,y:632,t:1527632105387};\\\", \\\"{x:1242,y:651,t:1527632105403};\\\", \\\"{x:1230,y:669,t:1527632105420};\\\", \\\"{x:1220,y:683,t:1527632105436};\\\", \\\"{x:1214,y:701,t:1527632105453};\\\", \\\"{x:1205,y:721,t:1527632105470};\\\", \\\"{x:1200,y:733,t:1527632105487};\\\", \\\"{x:1197,y:739,t:1527632105503};\\\", \\\"{x:1196,y:742,t:1527632105519};\\\", \\\"{x:1194,y:744,t:1527632105537};\\\", \\\"{x:1191,y:747,t:1527632105986};\\\", \\\"{x:1189,y:749,t:1527632105994};\\\", \\\"{x:1185,y:755,t:1527632106004};\\\", \\\"{x:1179,y:763,t:1527632106021};\\\", \\\"{x:1174,y:767,t:1527632106039};\\\", \\\"{x:1173,y:768,t:1527632106054};\\\", \\\"{x:1173,y:769,t:1527632106482};\\\", \\\"{x:1173,y:770,t:1527632106513};\\\", \\\"{x:1173,y:771,t:1527632106537};\\\", \\\"{x:1173,y:772,t:1527632106556};\\\", \\\"{x:1173,y:774,t:1527632106585};\\\", \\\"{x:1173,y:775,t:1527632106594};\\\", \\\"{x:1173,y:776,t:1527632106610};\\\", \\\"{x:1173,y:777,t:1527632106621};\\\", \\\"{x:1173,y:780,t:1527632106639};\\\", \\\"{x:1173,y:781,t:1527632106656};\\\", \\\"{x:1174,y:782,t:1527632106673};\\\", \\\"{x:1174,y:785,t:1527632106689};\\\", \\\"{x:1177,y:788,t:1527632106705};\\\", \\\"{x:1178,y:790,t:1527632106723};\\\", \\\"{x:1179,y:792,t:1527632106739};\\\", \\\"{x:1180,y:793,t:1527632106756};\\\", \\\"{x:1181,y:795,t:1527632106772};\\\", \\\"{x:1182,y:797,t:1527632106789};\\\", \\\"{x:1185,y:802,t:1527632106805};\\\", \\\"{x:1189,y:809,t:1527632106823};\\\", \\\"{x:1194,y:816,t:1527632106840};\\\", \\\"{x:1197,y:820,t:1527632106856};\\\", \\\"{x:1202,y:827,t:1527632106872};\\\", \\\"{x:1208,y:839,t:1527632106890};\\\", \\\"{x:1211,y:842,t:1527632106906};\\\", \\\"{x:1214,y:848,t:1527632106923};\\\", \\\"{x:1217,y:855,t:1527632106940};\\\", \\\"{x:1219,y:860,t:1527632106956};\\\", \\\"{x:1220,y:864,t:1527632106973};\\\", \\\"{x:1220,y:867,t:1527632106990};\\\", \\\"{x:1222,y:871,t:1527632107007};\\\", \\\"{x:1222,y:875,t:1527632107023};\\\", \\\"{x:1225,y:880,t:1527632107041};\\\", \\\"{x:1225,y:883,t:1527632107057};\\\", \\\"{x:1226,y:885,t:1527632107073};\\\", \\\"{x:1233,y:898,t:1527632107089};\\\", \\\"{x:1240,y:914,t:1527632107107};\\\", \\\"{x:1247,y:934,t:1527632107123};\\\", \\\"{x:1251,y:943,t:1527632107140};\\\", \\\"{x:1256,y:954,t:1527632107157};\\\", \\\"{x:1265,y:969,t:1527632107174};\\\", \\\"{x:1272,y:981,t:1527632107190};\\\", \\\"{x:1280,y:991,t:1527632107208};\\\", \\\"{x:1285,y:997,t:1527632107224};\\\", \\\"{x:1288,y:1000,t:1527632107240};\\\", \\\"{x:1287,y:1000,t:1527632107322};\\\", \\\"{x:1285,y:997,t:1527632107329};\\\", \\\"{x:1282,y:994,t:1527632107341};\\\", \\\"{x:1279,y:986,t:1527632107357};\\\", \\\"{x:1278,y:982,t:1527632107374};\\\", \\\"{x:1276,y:977,t:1527632107391};\\\", \\\"{x:1275,y:973,t:1527632107407};\\\", \\\"{x:1275,y:968,t:1527632107424};\\\", \\\"{x:1274,y:966,t:1527632107440};\\\", \\\"{x:1274,y:960,t:1527632107457};\\\", \\\"{x:1272,y:940,t:1527632107473};\\\", \\\"{x:1272,y:922,t:1527632107491};\\\", \\\"{x:1272,y:899,t:1527632107508};\\\", \\\"{x:1272,y:883,t:1527632107524};\\\", \\\"{x:1272,y:861,t:1527632107540};\\\", \\\"{x:1272,y:840,t:1527632107557};\\\", \\\"{x:1272,y:824,t:1527632107573};\\\", \\\"{x:1272,y:798,t:1527632107590};\\\", \\\"{x:1270,y:779,t:1527632107608};\\\", \\\"{x:1267,y:763,t:1527632107624};\\\", \\\"{x:1267,y:748,t:1527632107640};\\\", \\\"{x:1266,y:725,t:1527632107657};\\\", \\\"{x:1264,y:713,t:1527632107675};\\\", \\\"{x:1261,y:700,t:1527632107690};\\\", \\\"{x:1260,y:689,t:1527632107707};\\\", \\\"{x:1259,y:680,t:1527632107725};\\\", \\\"{x:1259,y:669,t:1527632107740};\\\", \\\"{x:1259,y:658,t:1527632107757};\\\", \\\"{x:1261,y:649,t:1527632107774};\\\", \\\"{x:1261,y:646,t:1527632107791};\\\", \\\"{x:1262,y:642,t:1527632107807};\\\", \\\"{x:1262,y:640,t:1527632107825};\\\", \\\"{x:1263,y:639,t:1527632107841};\\\", \\\"{x:1265,y:638,t:1527632107922};\\\", \\\"{x:1269,y:640,t:1527632107930};\\\", \\\"{x:1271,y:646,t:1527632107942};\\\", \\\"{x:1278,y:658,t:1527632107958};\\\", \\\"{x:1286,y:670,t:1527632107975};\\\", \\\"{x:1297,y:681,t:1527632107992};\\\", \\\"{x:1311,y:696,t:1527632108009};\\\", \\\"{x:1318,y:708,t:1527632108026};\\\", \\\"{x:1333,y:730,t:1527632108041};\\\", \\\"{x:1342,y:745,t:1527632108059};\\\", \\\"{x:1350,y:759,t:1527632108076};\\\", \\\"{x:1354,y:768,t:1527632108093};\\\", \\\"{x:1357,y:773,t:1527632108109};\\\", \\\"{x:1358,y:777,t:1527632108125};\\\", \\\"{x:1360,y:780,t:1527632108141};\\\", \\\"{x:1360,y:784,t:1527632108158};\\\", \\\"{x:1362,y:787,t:1527632108175};\\\", \\\"{x:1362,y:790,t:1527632108191};\\\", \\\"{x:1363,y:794,t:1527632108208};\\\", \\\"{x:1366,y:801,t:1527632108225};\\\", \\\"{x:1368,y:806,t:1527632108242};\\\", \\\"{x:1369,y:808,t:1527632108258};\\\", \\\"{x:1369,y:809,t:1527632108276};\\\", \\\"{x:1371,y:813,t:1527632108291};\\\", \\\"{x:1371,y:816,t:1527632108309};\\\", \\\"{x:1373,y:819,t:1527632108325};\\\", \\\"{x:1374,y:822,t:1527632108342};\\\", \\\"{x:1376,y:825,t:1527632108359};\\\", \\\"{x:1379,y:828,t:1527632108376};\\\", \\\"{x:1384,y:834,t:1527632108393};\\\", \\\"{x:1388,y:840,t:1527632108409};\\\", \\\"{x:1393,y:850,t:1527632108426};\\\", \\\"{x:1396,y:854,t:1527632108443};\\\", \\\"{x:1398,y:857,t:1527632108458};\\\", \\\"{x:1399,y:858,t:1527632108490};\\\", \\\"{x:1399,y:859,t:1527632108498};\\\", \\\"{x:1399,y:858,t:1527632108737};\\\", \\\"{x:1399,y:854,t:1527632108746};\\\", \\\"{x:1398,y:852,t:1527632108761};\\\", \\\"{x:1392,y:840,t:1527632108778};\\\", \\\"{x:1388,y:832,t:1527632108793};\\\", \\\"{x:1378,y:816,t:1527632108810};\\\", \\\"{x:1373,y:808,t:1527632108826};\\\", \\\"{x:1369,y:803,t:1527632108844};\\\", \\\"{x:1367,y:798,t:1527632108860};\\\", \\\"{x:1365,y:795,t:1527632108877};\\\", \\\"{x:1363,y:792,t:1527632108894};\\\", \\\"{x:1362,y:789,t:1527632108910};\\\", \\\"{x:1362,y:788,t:1527632108929};\\\", \\\"{x:1361,y:788,t:1527632108946};\\\", \\\"{x:1361,y:786,t:1527632108994};\\\", \\\"{x:1361,y:785,t:1527632109018};\\\", \\\"{x:1361,y:783,t:1527632109034};\\\", \\\"{x:1360,y:782,t:1527632109065};\\\", \\\"{x:1360,y:779,t:1527632109170};\\\", \\\"{x:1359,y:779,t:1527632109177};\\\", \\\"{x:1359,y:777,t:1527632109194};\\\", \\\"{x:1358,y:776,t:1527632109211};\\\", \\\"{x:1357,y:774,t:1527632109228};\\\", \\\"{x:1355,y:772,t:1527632109244};\\\", \\\"{x:1355,y:771,t:1527632109261};\\\", \\\"{x:1354,y:769,t:1527632109278};\\\", \\\"{x:1352,y:769,t:1527632109295};\\\", \\\"{x:1352,y:768,t:1527632109311};\\\", \\\"{x:1351,y:768,t:1527632109328};\\\", \\\"{x:1349,y:769,t:1527632109594};\\\", \\\"{x:1344,y:781,t:1527632109612};\\\", \\\"{x:1336,y:794,t:1527632109629};\\\", \\\"{x:1329,y:805,t:1527632109645};\\\", \\\"{x:1322,y:814,t:1527632109662};\\\", \\\"{x:1317,y:826,t:1527632109679};\\\", \\\"{x:1314,y:831,t:1527632109695};\\\", \\\"{x:1311,y:838,t:1527632109712};\\\", \\\"{x:1305,y:853,t:1527632109729};\\\", \\\"{x:1304,y:857,t:1527632109745};\\\", \\\"{x:1298,y:869,t:1527632109762};\\\", \\\"{x:1297,y:874,t:1527632109779};\\\", \\\"{x:1295,y:888,t:1527632109795};\\\", \\\"{x:1289,y:908,t:1527632109812};\\\", \\\"{x:1289,y:931,t:1527632109829};\\\", \\\"{x:1289,y:947,t:1527632109846};\\\", \\\"{x:1286,y:960,t:1527632109863};\\\", \\\"{x:1285,y:966,t:1527632109879};\\\", \\\"{x:1283,y:974,t:1527632109896};\\\", \\\"{x:1282,y:978,t:1527632109912};\\\", \\\"{x:1280,y:983,t:1527632109930};\\\", \\\"{x:1280,y:984,t:1527632109945};\\\", \\\"{x:1280,y:985,t:1527632109964};\\\", \\\"{x:1280,y:981,t:1527632110042};\\\", \\\"{x:1280,y:976,t:1527632110049};\\\", \\\"{x:1282,y:969,t:1527632110062};\\\", \\\"{x:1291,y:952,t:1527632110078};\\\", \\\"{x:1304,y:926,t:1527632110095};\\\", \\\"{x:1324,y:888,t:1527632110112};\\\", \\\"{x:1340,y:857,t:1527632110128};\\\", \\\"{x:1349,y:833,t:1527632110145};\\\", \\\"{x:1357,y:818,t:1527632110162};\\\", \\\"{x:1362,y:803,t:1527632110179};\\\", \\\"{x:1362,y:798,t:1527632110196};\\\", \\\"{x:1362,y:793,t:1527632110213};\\\", \\\"{x:1362,y:786,t:1527632110229};\\\", \\\"{x:1361,y:778,t:1527632110246};\\\", \\\"{x:1360,y:772,t:1527632110263};\\\", \\\"{x:1360,y:769,t:1527632110280};\\\", \\\"{x:1360,y:768,t:1527632110296};\\\", \\\"{x:1360,y:767,t:1527632110321};\\\", \\\"{x:1360,y:771,t:1527632110578};\\\", \\\"{x:1363,y:777,t:1527632110586};\\\", \\\"{x:1363,y:781,t:1527632110597};\\\", \\\"{x:1363,y:786,t:1527632110614};\\\", \\\"{x:1364,y:792,t:1527632110631};\\\", \\\"{x:1364,y:794,t:1527632110647};\\\", \\\"{x:1364,y:797,t:1527632110664};\\\", \\\"{x:1367,y:806,t:1527632110682};\\\", \\\"{x:1367,y:810,t:1527632110697};\\\", \\\"{x:1369,y:815,t:1527632110714};\\\", \\\"{x:1371,y:819,t:1527632110731};\\\", \\\"{x:1371,y:822,t:1527632110747};\\\", \\\"{x:1372,y:825,t:1527632110764};\\\", \\\"{x:1373,y:827,t:1527632110781};\\\", \\\"{x:1374,y:832,t:1527632110798};\\\", \\\"{x:1375,y:835,t:1527632110814};\\\", \\\"{x:1376,y:840,t:1527632110831};\\\", \\\"{x:1376,y:842,t:1527632110848};\\\", \\\"{x:1376,y:846,t:1527632110864};\\\", \\\"{x:1376,y:851,t:1527632110881};\\\", \\\"{x:1376,y:853,t:1527632110898};\\\", \\\"{x:1376,y:856,t:1527632110914};\\\", \\\"{x:1376,y:857,t:1527632110930};\\\", \\\"{x:1376,y:858,t:1527632110948};\\\", \\\"{x:1377,y:860,t:1527632110965};\\\", \\\"{x:1377,y:862,t:1527632110981};\\\", \\\"{x:1378,y:866,t:1527632110998};\\\", \\\"{x:1379,y:869,t:1527632111015};\\\", \\\"{x:1380,y:872,t:1527632111030};\\\", \\\"{x:1382,y:875,t:1527632111048};\\\", \\\"{x:1382,y:878,t:1527632111064};\\\", \\\"{x:1386,y:888,t:1527632111080};\\\", \\\"{x:1387,y:894,t:1527632111097};\\\", \\\"{x:1389,y:899,t:1527632111114};\\\", \\\"{x:1389,y:902,t:1527632111132};\\\", \\\"{x:1390,y:902,t:1527632111147};\\\", \\\"{x:1391,y:904,t:1527632111164};\\\", \\\"{x:1391,y:906,t:1527632111182};\\\", \\\"{x:1394,y:910,t:1527632111197};\\\", \\\"{x:1394,y:912,t:1527632111215};\\\", \\\"{x:1395,y:915,t:1527632111231};\\\", \\\"{x:1396,y:918,t:1527632111248};\\\", \\\"{x:1398,y:921,t:1527632111265};\\\", \\\"{x:1399,y:923,t:1527632111281};\\\", \\\"{x:1399,y:924,t:1527632111298};\\\", \\\"{x:1400,y:925,t:1527632111315};\\\", \\\"{x:1401,y:926,t:1527632111332};\\\", \\\"{x:1401,y:927,t:1527632111349};\\\", \\\"{x:1402,y:928,t:1527632111365};\\\", \\\"{x:1402,y:929,t:1527632111382};\\\", \\\"{x:1403,y:931,t:1527632111401};\\\", \\\"{x:1403,y:932,t:1527632111456};\\\", \\\"{x:1402,y:932,t:1527632113609};\\\", \\\"{x:1398,y:932,t:1527632113620};\\\", \\\"{x:1394,y:929,t:1527632113636};\\\", \\\"{x:1380,y:925,t:1527632113652};\\\", \\\"{x:1350,y:919,t:1527632113670};\\\", \\\"{x:1329,y:913,t:1527632113686};\\\", \\\"{x:1314,y:908,t:1527632113703};\\\", \\\"{x:1286,y:900,t:1527632113719};\\\", \\\"{x:1274,y:897,t:1527632113736};\\\", \\\"{x:1273,y:896,t:1527632113825};\\\", \\\"{x:1272,y:895,t:1527632113837};\\\", \\\"{x:1270,y:886,t:1527632113854};\\\", \\\"{x:1265,y:878,t:1527632113869};\\\", \\\"{x:1263,y:873,t:1527632113886};\\\", \\\"{x:1263,y:871,t:1527632113904};\\\", \\\"{x:1262,y:871,t:1527632113920};\\\", \\\"{x:1261,y:870,t:1527632113984};\\\", \\\"{x:1261,y:868,t:1527632114001};\\\", \\\"{x:1259,y:866,t:1527632114016};\\\", \\\"{x:1259,y:864,t:1527632114024};\\\", \\\"{x:1258,y:863,t:1527632114037};\\\", \\\"{x:1256,y:859,t:1527632114054};\\\", \\\"{x:1254,y:856,t:1527632114071};\\\", \\\"{x:1253,y:855,t:1527632114087};\\\", \\\"{x:1250,y:854,t:1527632114104};\\\", \\\"{x:1246,y:852,t:1527632114120};\\\", \\\"{x:1244,y:851,t:1527632114136};\\\", \\\"{x:1244,y:850,t:1527632114160};\\\", \\\"{x:1243,y:850,t:1527632114192};\\\", \\\"{x:1242,y:849,t:1527632114209};\\\", \\\"{x:1240,y:849,t:1527632114224};\\\", \\\"{x:1238,y:848,t:1527632114238};\\\", \\\"{x:1236,y:847,t:1527632114253};\\\", \\\"{x:1235,y:847,t:1527632114289};\\\", \\\"{x:1234,y:846,t:1527632114321};\\\", \\\"{x:1233,y:846,t:1527632114345};\\\", \\\"{x:1232,y:833,t:1527632116745};\\\", \\\"{x:1232,y:791,t:1527632116759};\\\", \\\"{x:1234,y:742,t:1527632116775};\\\", \\\"{x:1239,y:698,t:1527632116792};\\\", \\\"{x:1241,y:675,t:1527632116809};\\\", \\\"{x:1243,y:655,t:1527632116825};\\\", \\\"{x:1244,y:642,t:1527632116843};\\\", \\\"{x:1244,y:628,t:1527632116859};\\\", \\\"{x:1244,y:614,t:1527632116877};\\\", \\\"{x:1244,y:599,t:1527632116892};\\\", \\\"{x:1244,y:590,t:1527632116909};\\\", \\\"{x:1244,y:579,t:1527632116927};\\\", \\\"{x:1244,y:573,t:1527632116942};\\\", \\\"{x:1244,y:569,t:1527632116959};\\\", \\\"{x:1244,y:567,t:1527632116976};\\\", \\\"{x:1245,y:569,t:1527632117264};\\\", \\\"{x:1245,y:571,t:1527632117277};\\\", \\\"{x:1246,y:575,t:1527632117294};\\\", \\\"{x:1246,y:577,t:1527632117310};\\\", \\\"{x:1246,y:578,t:1527632117328};\\\", \\\"{x:1247,y:578,t:1527632117344};\\\", \\\"{x:1247,y:579,t:1527632117376};\\\", \\\"{x:1247,y:580,t:1527632117384};\\\", \\\"{x:1249,y:585,t:1527632117393};\\\", \\\"{x:1249,y:588,t:1527632117411};\\\", \\\"{x:1251,y:597,t:1527632117428};\\\", \\\"{x:1252,y:611,t:1527632117443};\\\", \\\"{x:1253,y:631,t:1527632117461};\\\", \\\"{x:1253,y:650,t:1527632117478};\\\", \\\"{x:1253,y:666,t:1527632117493};\\\", \\\"{x:1253,y:681,t:1527632117510};\\\", \\\"{x:1253,y:690,t:1527632117527};\\\", \\\"{x:1253,y:695,t:1527632117544};\\\", \\\"{x:1253,y:703,t:1527632117560};\\\", \\\"{x:1253,y:706,t:1527632117578};\\\", \\\"{x:1253,y:707,t:1527632117785};\\\", \\\"{x:1253,y:710,t:1527632117794};\\\", \\\"{x:1253,y:716,t:1527632117811};\\\", \\\"{x:1253,y:720,t:1527632117828};\\\", \\\"{x:1253,y:722,t:1527632117844};\\\", \\\"{x:1253,y:726,t:1527632117861};\\\", \\\"{x:1252,y:729,t:1527632117878};\\\", \\\"{x:1252,y:730,t:1527632117928};\\\", \\\"{x:1252,y:731,t:1527632117944};\\\", \\\"{x:1251,y:732,t:1527632118048};\\\", \\\"{x:1251,y:733,t:1527632118061};\\\", \\\"{x:1249,y:736,t:1527632118078};\\\", \\\"{x:1248,y:742,t:1527632118096};\\\", \\\"{x:1245,y:755,t:1527632118111};\\\", \\\"{x:1241,y:773,t:1527632118129};\\\", \\\"{x:1239,y:786,t:1527632118145};\\\", \\\"{x:1238,y:793,t:1527632118162};\\\", \\\"{x:1236,y:799,t:1527632118179};\\\", \\\"{x:1233,y:807,t:1527632118195};\\\", \\\"{x:1232,y:809,t:1527632118213};\\\", \\\"{x:1231,y:811,t:1527632118228};\\\", \\\"{x:1230,y:815,t:1527632118245};\\\", \\\"{x:1228,y:817,t:1527632118263};\\\", \\\"{x:1228,y:818,t:1527632118279};\\\", \\\"{x:1228,y:820,t:1527632118295};\\\", \\\"{x:1227,y:824,t:1527632118313};\\\", \\\"{x:1225,y:830,t:1527632118329};\\\", \\\"{x:1223,y:836,t:1527632118345};\\\", \\\"{x:1221,y:842,t:1527632118362};\\\", \\\"{x:1219,y:847,t:1527632118380};\\\", \\\"{x:1217,y:854,t:1527632118395};\\\", \\\"{x:1216,y:861,t:1527632118413};\\\", \\\"{x:1215,y:867,t:1527632118429};\\\", \\\"{x:1213,y:872,t:1527632118445};\\\", \\\"{x:1213,y:875,t:1527632118463};\\\", \\\"{x:1212,y:878,t:1527632118479};\\\", \\\"{x:1211,y:880,t:1527632118495};\\\", \\\"{x:1211,y:881,t:1527632118512};\\\", \\\"{x:1210,y:883,t:1527632118680};\\\", \\\"{x:1210,y:889,t:1527632118696};\\\", \\\"{x:1210,y:896,t:1527632118713};\\\", \\\"{x:1209,y:902,t:1527632118730};\\\", \\\"{x:1208,y:909,t:1527632118746};\\\", \\\"{x:1208,y:913,t:1527632118764};\\\", \\\"{x:1208,y:920,t:1527632118780};\\\", \\\"{x:1208,y:926,t:1527632118796};\\\", \\\"{x:1208,y:933,t:1527632118814};\\\", \\\"{x:1207,y:941,t:1527632118829};\\\", \\\"{x:1207,y:943,t:1527632118846};\\\", \\\"{x:1206,y:945,t:1527632118863};\\\", \\\"{x:1206,y:948,t:1527632118880};\\\", \\\"{x:1206,y:950,t:1527632118897};\\\", \\\"{x:1206,y:954,t:1527632118914};\\\", \\\"{x:1206,y:957,t:1527632118931};\\\", \\\"{x:1206,y:962,t:1527632118946};\\\", \\\"{x:1206,y:964,t:1527632118964};\\\", \\\"{x:1206,y:965,t:1527632118980};\\\", \\\"{x:1206,y:968,t:1527632118997};\\\", \\\"{x:1206,y:970,t:1527632119014};\\\", \\\"{x:1206,y:972,t:1527632119031};\\\", \\\"{x:1206,y:973,t:1527632119047};\\\", \\\"{x:1206,y:974,t:1527632119096};\\\", \\\"{x:1206,y:975,t:1527632119103};\\\", \\\"{x:1206,y:976,t:1527632119113};\\\", \\\"{x:1206,y:977,t:1527632119130};\\\", \\\"{x:1206,y:978,t:1527632119147};\\\", \\\"{x:1206,y:980,t:1527632119164};\\\", \\\"{x:1206,y:981,t:1527632119180};\\\", \\\"{x:1206,y:983,t:1527632119197};\\\", \\\"{x:1206,y:984,t:1527632119216};\\\", \\\"{x:1207,y:985,t:1527632119231};\\\", \\\"{x:1207,y:987,t:1527632119248};\\\", \\\"{x:1207,y:989,t:1527632119265};\\\", \\\"{x:1208,y:989,t:1527632119425};\\\", \\\"{x:1210,y:981,t:1527632119432};\\\", \\\"{x:1211,y:970,t:1527632119448};\\\", \\\"{x:1222,y:924,t:1527632119465};\\\", \\\"{x:1235,y:870,t:1527632119482};\\\", \\\"{x:1237,y:811,t:1527632119498};\\\", \\\"{x:1237,y:771,t:1527632119514};\\\", \\\"{x:1238,y:726,t:1527632119531};\\\", \\\"{x:1240,y:701,t:1527632119548};\\\", \\\"{x:1245,y:684,t:1527632119564};\\\", \\\"{x:1251,y:662,t:1527632119582};\\\", \\\"{x:1258,y:639,t:1527632119598};\\\", \\\"{x:1260,y:619,t:1527632119614};\\\", \\\"{x:1260,y:610,t:1527632119632};\\\", \\\"{x:1261,y:602,t:1527632119648};\\\", \\\"{x:1261,y:600,t:1527632119665};\\\", \\\"{x:1261,y:608,t:1527632119864};\\\", \\\"{x:1261,y:618,t:1527632119872};\\\", \\\"{x:1259,y:629,t:1527632119883};\\\", \\\"{x:1257,y:646,t:1527632119899};\\\", \\\"{x:1256,y:661,t:1527632119915};\\\", \\\"{x:1254,y:674,t:1527632119932};\\\", \\\"{x:1254,y:680,t:1527632119949};\\\", \\\"{x:1254,y:691,t:1527632119965};\\\", \\\"{x:1254,y:700,t:1527632119982};\\\", \\\"{x:1253,y:705,t:1527632120000};\\\", \\\"{x:1251,y:711,t:1527632120016};\\\", \\\"{x:1249,y:719,t:1527632120032};\\\", \\\"{x:1248,y:723,t:1527632120050};\\\", \\\"{x:1247,y:728,t:1527632120066};\\\", \\\"{x:1244,y:734,t:1527632120083};\\\", \\\"{x:1241,y:739,t:1527632120100};\\\", \\\"{x:1238,y:745,t:1527632120115};\\\", \\\"{x:1236,y:748,t:1527632120132};\\\", \\\"{x:1231,y:754,t:1527632120150};\\\", \\\"{x:1225,y:760,t:1527632120166};\\\", \\\"{x:1221,y:765,t:1527632120183};\\\", \\\"{x:1218,y:768,t:1527632120200};\\\", \\\"{x:1212,y:774,t:1527632120216};\\\", \\\"{x:1206,y:780,t:1527632120233};\\\", \\\"{x:1201,y:784,t:1527632120250};\\\", \\\"{x:1196,y:788,t:1527632120267};\\\", \\\"{x:1192,y:790,t:1527632120282};\\\", \\\"{x:1186,y:793,t:1527632120299};\\\", \\\"{x:1183,y:795,t:1527632120316};\\\", \\\"{x:1181,y:797,t:1527632120334};\\\", \\\"{x:1179,y:797,t:1527632120350};\\\", \\\"{x:1178,y:797,t:1527632120367};\\\", \\\"{x:1178,y:796,t:1527632120584};\\\", \\\"{x:1178,y:791,t:1527632120600};\\\", \\\"{x:1179,y:788,t:1527632120620};\\\", \\\"{x:1180,y:786,t:1527632120637};\\\", \\\"{x:1180,y:783,t:1527632120655};\\\", \\\"{x:1181,y:781,t:1527632120671};\\\", \\\"{x:1181,y:780,t:1527632120701};\\\", \\\"{x:1181,y:779,t:1527632121172};\\\", \\\"{x:1157,y:773,t:1527632122365};\\\", \\\"{x:1117,y:769,t:1527632122376};\\\", \\\"{x:1011,y:751,t:1527632122393};\\\", \\\"{x:897,y:735,t:1527632122409};\\\", \\\"{x:775,y:714,t:1527632122425};\\\", \\\"{x:649,y:689,t:1527632122442};\\\", \\\"{x:554,y:659,t:1527632122458};\\\", \\\"{x:483,y:632,t:1527632122475};\\\", \\\"{x:419,y:604,t:1527632122492};\\\", \\\"{x:392,y:581,t:1527632122509};\\\", \\\"{x:388,y:572,t:1527632122525};\\\", \\\"{x:384,y:565,t:1527632122545};\\\", \\\"{x:382,y:557,t:1527632122561};\\\", \\\"{x:379,y:555,t:1527632122584};\\\", \\\"{x:378,y:555,t:1527632122600};\\\", \\\"{x:375,y:554,t:1527632122618};\\\", \\\"{x:368,y:549,t:1527632122634};\\\", \\\"{x:363,y:540,t:1527632122651};\\\", \\\"{x:360,y:530,t:1527632122667};\\\", \\\"{x:360,y:522,t:1527632122685};\\\", \\\"{x:359,y:522,t:1527632122700};\\\", \\\"{x:359,y:520,t:1527632122772};\\\", \\\"{x:359,y:519,t:1527632122784};\\\", \\\"{x:359,y:514,t:1527632122801};\\\", \\\"{x:348,y:509,t:1527632122818};\\\", \\\"{x:335,y:502,t:1527632122835};\\\", \\\"{x:322,y:499,t:1527632122851};\\\", \\\"{x:316,y:498,t:1527632122868};\\\", \\\"{x:305,y:496,t:1527632122884};\\\", \\\"{x:292,y:496,t:1527632122901};\\\", \\\"{x:273,y:496,t:1527632122918};\\\", \\\"{x:261,y:496,t:1527632122935};\\\", \\\"{x:253,y:495,t:1527632122951};\\\", \\\"{x:249,y:495,t:1527632122968};\\\", \\\"{x:248,y:495,t:1527632122985};\\\", \\\"{x:245,y:494,t:1527632123001};\\\", \\\"{x:242,y:493,t:1527632123018};\\\", \\\"{x:238,y:492,t:1527632123035};\\\", \\\"{x:231,y:490,t:1527632123050};\\\", \\\"{x:227,y:488,t:1527632123067};\\\", \\\"{x:223,y:487,t:1527632123084};\\\", \\\"{x:222,y:486,t:1527632123101};\\\", \\\"{x:221,y:486,t:1527632123132};\\\", \\\"{x:220,y:486,t:1527632123139};\\\", \\\"{x:219,y:486,t:1527632123156};\\\", \\\"{x:217,y:485,t:1527632123167};\\\", \\\"{x:215,y:484,t:1527632123184};\\\", \\\"{x:213,y:484,t:1527632123202};\\\", \\\"{x:209,y:483,t:1527632123217};\\\", \\\"{x:209,y:482,t:1527632123236};\\\", \\\"{x:208,y:482,t:1527632123252};\\\", \\\"{x:207,y:482,t:1527632123267};\\\", \\\"{x:206,y:482,t:1527632123372};\\\", \\\"{x:206,y:483,t:1527632123445};\\\", \\\"{x:206,y:484,t:1527632123500};\\\", \\\"{x:206,y:485,t:1527632123549};\\\", \\\"{x:206,y:486,t:1527632123556};\\\", \\\"{x:203,y:486,t:1527632123884};\\\", \\\"{x:200,y:486,t:1527632123892};\\\", \\\"{x:190,y:487,t:1527632123902};\\\", \\\"{x:181,y:490,t:1527632123919};\\\", \\\"{x:179,y:490,t:1527632123935};\\\", \\\"{x:179,y:491,t:1527632123997};\\\", \\\"{x:177,y:492,t:1527632124004};\\\", \\\"{x:174,y:493,t:1527632124019};\\\", \\\"{x:169,y:495,t:1527632124035};\\\", \\\"{x:168,y:495,t:1527632124052};\\\", \\\"{x:168,y:496,t:1527632124076};\\\", \\\"{x:169,y:497,t:1527632124388};\\\", \\\"{x:175,y:500,t:1527632124401};\\\", \\\"{x:194,y:519,t:1527632124419};\\\", \\\"{x:218,y:537,t:1527632124437};\\\", \\\"{x:237,y:552,t:1527632124451};\\\", \\\"{x:273,y:580,t:1527632124469};\\\", \\\"{x:294,y:601,t:1527632124486};\\\", \\\"{x:314,y:624,t:1527632124502};\\\", \\\"{x:335,y:648,t:1527632124519};\\\", \\\"{x:351,y:666,t:1527632124536};\\\", \\\"{x:369,y:682,t:1527632124554};\\\", \\\"{x:387,y:698,t:1527632124569};\\\", \\\"{x:392,y:705,t:1527632124585};\\\", \\\"{x:395,y:709,t:1527632124603};\\\", \\\"{x:397,y:711,t:1527632124619};\\\", \\\"{x:399,y:714,t:1527632124636};\\\", \\\"{x:403,y:715,t:1527632124652};\\\", \\\"{x:405,y:715,t:1527632124669};\\\", \\\"{x:413,y:715,t:1527632124685};\\\", \\\"{x:423,y:718,t:1527632124702};\\\", \\\"{x:432,y:721,t:1527632124719};\\\", \\\"{x:441,y:723,t:1527632124736};\\\", \\\"{x:451,y:728,t:1527632124754};\\\", \\\"{x:460,y:732,t:1527632124770};\\\", \\\"{x:467,y:736,t:1527632124785};\\\", \\\"{x:481,y:740,t:1527632124803};\\\", \\\"{x:499,y:746,t:1527632124819};\\\", \\\"{x:512,y:747,t:1527632124836};\\\", \\\"{x:522,y:750,t:1527632124853};\\\", \\\"{x:524,y:750,t:1527632124869};\\\", \\\"{x:525,y:750,t:1527632124886};\\\", \\\"{x:526,y:745,t:1527632126108};\\\", \\\"{x:527,y:739,t:1527632126120};\\\", \\\"{x:529,y:732,t:1527632126137};\\\", \\\"{x:529,y:724,t:1527632126154};\\\" ] }, { \\\"rt\\\": 12353, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 737591, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:598,t:1527632126308};\\\", \\\"{x:533,y:597,t:1527632126320};\\\", \\\"{x:533,y:594,t:1527632126336};\\\", \\\"{x:533,y:593,t:1527632126354};\\\", \\\"{x:533,y:591,t:1527632126370};\\\", \\\"{x:533,y:586,t:1527632126425};\\\", \\\"{x:535,y:576,t:1527632126437};\\\", \\\"{x:537,y:562,t:1527632126454};\\\", \\\"{x:537,y:555,t:1527632126471};\\\", \\\"{x:537,y:546,t:1527632126487};\\\", \\\"{x:537,y:529,t:1527632126504};\\\", \\\"{x:533,y:501,t:1527632126521};\\\", \\\"{x:533,y:486,t:1527632126538};\\\", \\\"{x:533,y:483,t:1527632126553};\\\", \\\"{x:532,y:483,t:1527632126571};\\\", \\\"{x:553,y:472,t:1527632126686};\\\", \\\"{x:559,y:469,t:1527632126695};\\\", \\\"{x:564,y:467,t:1527632126704};\\\", \\\"{x:569,y:464,t:1527632126721};\\\", \\\"{x:571,y:464,t:1527632126772};\\\", \\\"{x:572,y:464,t:1527632126844};\\\", \\\"{x:581,y:459,t:1527632126854};\\\", \\\"{x:643,y:423,t:1527632126871};\\\", \\\"{x:710,y:390,t:1527632126888};\\\", \\\"{x:734,y:378,t:1527632126903};\\\", \\\"{x:743,y:372,t:1527632126921};\\\", \\\"{x:745,y:371,t:1527632126938};\\\", \\\"{x:747,y:370,t:1527632126954};\\\", \\\"{x:751,y:368,t:1527632126971};\\\", \\\"{x:756,y:367,t:1527632126988};\\\", \\\"{x:756,y:366,t:1527632127004};\\\", \\\"{x:756,y:365,t:1527632131204};\\\", \\\"{x:784,y:345,t:1527632131212};\\\", \\\"{x:817,y:327,t:1527632131224};\\\", \\\"{x:846,y:302,t:1527632131239};\\\", \\\"{x:856,y:289,t:1527632131256};\\\", \\\"{x:863,y:277,t:1527632131273};\\\", \\\"{x:867,y:250,t:1527632131289};\\\", \\\"{x:867,y:203,t:1527632131306};\\\", \\\"{x:864,y:135,t:1527632131323};\\\", \\\"{x:867,y:39,t:1527632131340};\\\", \\\"{x:903,y:0,t:1527632131356};\\\", \\\"{x:950,y:0,t:1527632131373};\\\", \\\"{x:984,y:0,t:1527632131389};\\\", \\\"{x:990,y:0,t:1527632131406};\\\", \\\"{x:985,y:0,t:1527632131424};\\\", \\\"{x:957,y:0,t:1527632131441};\\\", \\\"{x:920,y:0,t:1527632131456};\\\", \\\"{x:860,y:0,t:1527632131473};\\\", \\\"{x:769,y:0,t:1527632131490};\\\", \\\"{x:639,y:0,t:1527632131506};\\\", \\\"{x:532,y:0,t:1527632131523};\\\", \\\"{x:452,y:0,t:1527632131540};\\\", \\\"{x:438,y:0,t:1527632131556};\\\", \\\"{x:410,y:0,t:1527632131573};\\\", \\\"{x:299,y:0,t:1527632131590};\\\", \\\"{x:164,y:0,t:1527632131606};\\\", \\\"{x:45,y:28,t:1527632131623};\\\", \\\"{x:0,y:66,t:1527632131640};\\\", \\\"{x:0,y:102,t:1527632131656};\\\", \\\"{x:0,y:133,t:1527632131673};\\\", \\\"{x:0,y:146,t:1527632131690};\\\", \\\"{x:0,y:156,t:1527632131706};\\\", \\\"{x:18,y:176,t:1527632131724};\\\", \\\"{x:189,y:233,t:1527632131740};\\\", \\\"{x:347,y:264,t:1527632131757};\\\", \\\"{x:497,y:283,t:1527632131773};\\\", \\\"{x:617,y:290,t:1527632131790};\\\", \\\"{x:776,y:305,t:1527632131806};\\\", \\\"{x:988,y:321,t:1527632131823};\\\", \\\"{x:1158,y:334,t:1527632131841};\\\", \\\"{x:1306,y:362,t:1527632131856};\\\", \\\"{x:1344,y:379,t:1527632131873};\\\", \\\"{x:1353,y:385,t:1527632131890};\\\", \\\"{x:1363,y:394,t:1527632131907};\\\", \\\"{x:1370,y:403,t:1527632131924};\\\", \\\"{x:1371,y:420,t:1527632131941};\\\", \\\"{x:1371,y:430,t:1527632131957};\\\", \\\"{x:1368,y:444,t:1527632131973};\\\", \\\"{x:1364,y:457,t:1527632131990};\\\", \\\"{x:1361,y:465,t:1527632132007};\\\", \\\"{x:1356,y:477,t:1527632132023};\\\", \\\"{x:1344,y:492,t:1527632132040};\\\", \\\"{x:1330,y:509,t:1527632132057};\\\", \\\"{x:1325,y:529,t:1527632132073};\\\", \\\"{x:1325,y:554,t:1527632132090};\\\", \\\"{x:1342,y:596,t:1527632132107};\\\", \\\"{x:1372,y:647,t:1527632132124};\\\", \\\"{x:1396,y:701,t:1527632132140};\\\", \\\"{x:1397,y:716,t:1527632132157};\\\", \\\"{x:1397,y:728,t:1527632132173};\\\", \\\"{x:1397,y:742,t:1527632132190};\\\", \\\"{x:1398,y:755,t:1527632132207};\\\", \\\"{x:1398,y:766,t:1527632132223};\\\", \\\"{x:1398,y:769,t:1527632132240};\\\", \\\"{x:1397,y:770,t:1527632132381};\\\", \\\"{x:1396,y:770,t:1527632132390};\\\", \\\"{x:1391,y:769,t:1527632132407};\\\", \\\"{x:1386,y:764,t:1527632132423};\\\", \\\"{x:1378,y:755,t:1527632132441};\\\", \\\"{x:1372,y:746,t:1527632132457};\\\", \\\"{x:1367,y:738,t:1527632132473};\\\", \\\"{x:1365,y:735,t:1527632132490};\\\", \\\"{x:1364,y:735,t:1527632132507};\\\", \\\"{x:1363,y:733,t:1527632132523};\\\", \\\"{x:1362,y:732,t:1527632132580};\\\", \\\"{x:1360,y:730,t:1527632132660};\\\", \\\"{x:1358,y:730,t:1527632132673};\\\", \\\"{x:1355,y:726,t:1527632132690};\\\", \\\"{x:1352,y:723,t:1527632132707};\\\", \\\"{x:1350,y:721,t:1527632132723};\\\", \\\"{x:1350,y:720,t:1527632132740};\\\", \\\"{x:1348,y:719,t:1527632132758};\\\", \\\"{x:1348,y:718,t:1527632132804};\\\", \\\"{x:1348,y:717,t:1527632132836};\\\", \\\"{x:1347,y:716,t:1527632132852};\\\", \\\"{x:1347,y:715,t:1527632132876};\\\", \\\"{x:1346,y:714,t:1527632132996};\\\", \\\"{x:1351,y:720,t:1527632133076};\\\", \\\"{x:1368,y:750,t:1527632133090};\\\", \\\"{x:1403,y:817,t:1527632133107};\\\", \\\"{x:1450,y:906,t:1527632133124};\\\", \\\"{x:1479,y:946,t:1527632133140};\\\", \\\"{x:1494,y:964,t:1527632133157};\\\", \\\"{x:1504,y:970,t:1527632133174};\\\", \\\"{x:1505,y:972,t:1527632133190};\\\", \\\"{x:1501,y:964,t:1527632133597};\\\", \\\"{x:1495,y:951,t:1527632133607};\\\", \\\"{x:1471,y:910,t:1527632133624};\\\", \\\"{x:1419,y:829,t:1527632133641};\\\", \\\"{x:1333,y:723,t:1527632133657};\\\", \\\"{x:1272,y:631,t:1527632133674};\\\", \\\"{x:1248,y:571,t:1527632133691};\\\", \\\"{x:1229,y:522,t:1527632133707};\\\", \\\"{x:1213,y:468,t:1527632133723};\\\", \\\"{x:1210,y:450,t:1527632133741};\\\", \\\"{x:1205,y:443,t:1527632133757};\\\", \\\"{x:1202,y:440,t:1527632133774};\\\", \\\"{x:1193,y:440,t:1527632133949};\\\", \\\"{x:1171,y:440,t:1527632133957};\\\", \\\"{x:1079,y:438,t:1527632133975};\\\", \\\"{x:952,y:425,t:1527632133992};\\\", \\\"{x:825,y:406,t:1527632134007};\\\", \\\"{x:695,y:390,t:1527632134024};\\\", \\\"{x:592,y:376,t:1527632134041};\\\", \\\"{x:530,y:374,t:1527632134057};\\\", \\\"{x:485,y:374,t:1527632134075};\\\", \\\"{x:448,y:374,t:1527632134091};\\\", \\\"{x:437,y:374,t:1527632134107};\\\", \\\"{x:426,y:374,t:1527632134124};\\\", \\\"{x:419,y:375,t:1527632134141};\\\", \\\"{x:412,y:381,t:1527632134158};\\\", \\\"{x:402,y:391,t:1527632134174};\\\", \\\"{x:392,y:407,t:1527632134191};\\\", \\\"{x:388,y:420,t:1527632134207};\\\", \\\"{x:387,y:432,t:1527632134224};\\\", \\\"{x:387,y:444,t:1527632134242};\\\", \\\"{x:389,y:456,t:1527632134257};\\\", \\\"{x:391,y:461,t:1527632134274};\\\", \\\"{x:393,y:464,t:1527632134292};\\\", \\\"{x:394,y:466,t:1527632134308};\\\", \\\"{x:395,y:467,t:1527632134324};\\\", \\\"{x:407,y:470,t:1527632134341};\\\", \\\"{x:437,y:478,t:1527632134358};\\\", \\\"{x:473,y:479,t:1527632134374};\\\", \\\"{x:518,y:479,t:1527632134392};\\\", \\\"{x:572,y:481,t:1527632134408};\\\", \\\"{x:600,y:481,t:1527632134424};\\\", \\\"{x:606,y:483,t:1527632134442};\\\", \\\"{x:609,y:483,t:1527632134458};\\\", \\\"{x:610,y:483,t:1527632134474};\\\", \\\"{x:610,y:484,t:1527632134491};\\\", \\\"{x:611,y:484,t:1527632134508};\\\", \\\"{x:613,y:484,t:1527632134524};\\\", \\\"{x:614,y:484,t:1527632134548};\\\", \\\"{x:616,y:485,t:1527632134558};\\\", \\\"{x:619,y:486,t:1527632134574};\\\", \\\"{x:620,y:486,t:1527632134591};\\\", \\\"{x:621,y:487,t:1527632134609};\\\", \\\"{x:621,y:489,t:1527632134661};\\\", \\\"{x:621,y:492,t:1527632134676};\\\", \\\"{x:621,y:494,t:1527632134689};\\\", \\\"{x:618,y:499,t:1527632134710};\\\", \\\"{x:616,y:501,t:1527632134727};\\\", \\\"{x:615,y:501,t:1527632134748};\\\", \\\"{x:621,y:505,t:1527632135229};\\\", \\\"{x:676,y:535,t:1527632135245};\\\", \\\"{x:756,y:558,t:1527632135261};\\\", \\\"{x:840,y:571,t:1527632135277};\\\", \\\"{x:918,y:580,t:1527632135295};\\\", \\\"{x:957,y:583,t:1527632135312};\\\", \\\"{x:962,y:586,t:1527632135327};\\\", \\\"{x:963,y:586,t:1527632135344};\\\", \\\"{x:964,y:586,t:1527632135361};\\\", \\\"{x:964,y:585,t:1527632135377};\\\", \\\"{x:970,y:585,t:1527632135394};\\\", \\\"{x:973,y:585,t:1527632135412};\\\", \\\"{x:974,y:585,t:1527632135427};\\\", \\\"{x:975,y:585,t:1527632135468};\\\", \\\"{x:978,y:585,t:1527632135500};\\\", \\\"{x:982,y:583,t:1527632135511};\\\", \\\"{x:1005,y:576,t:1527632135527};\\\", \\\"{x:1021,y:570,t:1527632135544};\\\", \\\"{x:1036,y:568,t:1527632135562};\\\", \\\"{x:1065,y:568,t:1527632135578};\\\", \\\"{x:1103,y:565,t:1527632135594};\\\", \\\"{x:1179,y:561,t:1527632135612};\\\", \\\"{x:1246,y:560,t:1527632135628};\\\", \\\"{x:1356,y:556,t:1527632135644};\\\", \\\"{x:1406,y:556,t:1527632135661};\\\", \\\"{x:1427,y:557,t:1527632135678};\\\", \\\"{x:1440,y:563,t:1527632135695};\\\", \\\"{x:1443,y:571,t:1527632135711};\\\", \\\"{x:1451,y:584,t:1527632135727};\\\", \\\"{x:1452,y:591,t:1527632135745};\\\", \\\"{x:1452,y:596,t:1527632135761};\\\", \\\"{x:1453,y:602,t:1527632135777};\\\", \\\"{x:1456,y:614,t:1527632135794};\\\", \\\"{x:1460,y:623,t:1527632135812};\\\", \\\"{x:1460,y:630,t:1527632135828};\\\", \\\"{x:1460,y:648,t:1527632135844};\\\", \\\"{x:1460,y:661,t:1527632135861};\\\", \\\"{x:1460,y:679,t:1527632135877};\\\", \\\"{x:1457,y:693,t:1527632135894};\\\", \\\"{x:1453,y:704,t:1527632135911};\\\", \\\"{x:1453,y:711,t:1527632135928};\\\", \\\"{x:1451,y:718,t:1527632135945};\\\", \\\"{x:1450,y:721,t:1527632135962};\\\", \\\"{x:1449,y:728,t:1527632135977};\\\", \\\"{x:1449,y:730,t:1527632135994};\\\", \\\"{x:1447,y:733,t:1527632136012};\\\", \\\"{x:1447,y:734,t:1527632136027};\\\", \\\"{x:1447,y:737,t:1527632136053};\\\", \\\"{x:1447,y:739,t:1527632136068};\\\", \\\"{x:1447,y:743,t:1527632136077};\\\", \\\"{x:1449,y:749,t:1527632136094};\\\", \\\"{x:1449,y:754,t:1527632136111};\\\", \\\"{x:1451,y:757,t:1527632136127};\\\", \\\"{x:1454,y:764,t:1527632136144};\\\", \\\"{x:1456,y:771,t:1527632136162};\\\", \\\"{x:1458,y:776,t:1527632136177};\\\", \\\"{x:1459,y:780,t:1527632136194};\\\", \\\"{x:1459,y:781,t:1527632136212};\\\", \\\"{x:1459,y:783,t:1527632136228};\\\", \\\"{x:1458,y:782,t:1527632136332};\\\", \\\"{x:1455,y:778,t:1527632136344};\\\", \\\"{x:1450,y:770,t:1527632136362};\\\", \\\"{x:1440,y:761,t:1527632136377};\\\", \\\"{x:1429,y:751,t:1527632136395};\\\", \\\"{x:1418,y:738,t:1527632136412};\\\", \\\"{x:1405,y:723,t:1527632136428};\\\", \\\"{x:1394,y:707,t:1527632136444};\\\", \\\"{x:1390,y:701,t:1527632136461};\\\", \\\"{x:1386,y:693,t:1527632136477};\\\", \\\"{x:1382,y:681,t:1527632136494};\\\", \\\"{x:1378,y:674,t:1527632136511};\\\", \\\"{x:1377,y:671,t:1527632136528};\\\", \\\"{x:1376,y:674,t:1527632136637};\\\", \\\"{x:1379,y:686,t:1527632136644};\\\", \\\"{x:1385,y:699,t:1527632136661};\\\", \\\"{x:1392,y:709,t:1527632136677};\\\", \\\"{x:1394,y:719,t:1527632136695};\\\", \\\"{x:1398,y:739,t:1527632136711};\\\", \\\"{x:1401,y:755,t:1527632136728};\\\", \\\"{x:1405,y:777,t:1527632136745};\\\", \\\"{x:1408,y:799,t:1527632136762};\\\", \\\"{x:1412,y:820,t:1527632136777};\\\", \\\"{x:1414,y:835,t:1527632136794};\\\", \\\"{x:1419,y:851,t:1527632136812};\\\", \\\"{x:1420,y:860,t:1527632136828};\\\", \\\"{x:1424,y:867,t:1527632136844};\\\", \\\"{x:1424,y:872,t:1527632136862};\\\", \\\"{x:1424,y:875,t:1527632136877};\\\", \\\"{x:1425,y:883,t:1527632136894};\\\", \\\"{x:1426,y:886,t:1527632136912};\\\", \\\"{x:1426,y:887,t:1527632136927};\\\", \\\"{x:1426,y:890,t:1527632136945};\\\", \\\"{x:1428,y:893,t:1527632136961};\\\", \\\"{x:1428,y:896,t:1527632136978};\\\", \\\"{x:1429,y:899,t:1527632136995};\\\", \\\"{x:1429,y:903,t:1527632137012};\\\", \\\"{x:1429,y:905,t:1527632137027};\\\", \\\"{x:1429,y:906,t:1527632137044};\\\", \\\"{x:1430,y:907,t:1527632137062};\\\", \\\"{x:1425,y:907,t:1527632137244};\\\", \\\"{x:1421,y:904,t:1527632137261};\\\", \\\"{x:1415,y:900,t:1527632137278};\\\", \\\"{x:1408,y:896,t:1527632137295};\\\", \\\"{x:1400,y:889,t:1527632137312};\\\", \\\"{x:1393,y:879,t:1527632137328};\\\", \\\"{x:1386,y:871,t:1527632137345};\\\", \\\"{x:1382,y:865,t:1527632137361};\\\", \\\"{x:1377,y:858,t:1527632137378};\\\", \\\"{x:1369,y:847,t:1527632137394};\\\", \\\"{x:1362,y:843,t:1527632137411};\\\", \\\"{x:1360,y:841,t:1527632137428};\\\", \\\"{x:1357,y:837,t:1527632137444};\\\", \\\"{x:1354,y:831,t:1527632137462};\\\", \\\"{x:1347,y:823,t:1527632137477};\\\", \\\"{x:1330,y:809,t:1527632137494};\\\", \\\"{x:1295,y:795,t:1527632137511};\\\", \\\"{x:1245,y:772,t:1527632137527};\\\", \\\"{x:1164,y:748,t:1527632137545};\\\", \\\"{x:1063,y:726,t:1527632137561};\\\", \\\"{x:944,y:707,t:1527632137577};\\\", \\\"{x:827,y:691,t:1527632137595};\\\", \\\"{x:705,y:672,t:1527632137612};\\\", \\\"{x:607,y:653,t:1527632137628};\\\", \\\"{x:536,y:631,t:1527632137645};\\\", \\\"{x:527,y:629,t:1527632137661};\\\", \\\"{x:526,y:628,t:1527632137678};\\\", \\\"{x:524,y:628,t:1527632137716};\\\", \\\"{x:519,y:628,t:1527632137730};\\\", \\\"{x:508,y:628,t:1527632137747};\\\", \\\"{x:507,y:628,t:1527632137763};\\\", \\\"{x:506,y:630,t:1527632137779};\\\", \\\"{x:502,y:640,t:1527632137797};\\\", \\\"{x:498,y:648,t:1527632137814};\\\", \\\"{x:495,y:654,t:1527632137829};\\\", \\\"{x:494,y:658,t:1527632137846};\\\", \\\"{x:494,y:664,t:1527632137864};\\\", \\\"{x:495,y:669,t:1527632137880};\\\", \\\"{x:502,y:679,t:1527632137896};\\\", \\\"{x:518,y:687,t:1527632137913};\\\", \\\"{x:539,y:693,t:1527632137929};\\\", \\\"{x:558,y:699,t:1527632137946};\\\", \\\"{x:574,y:705,t:1527632137964};\\\", \\\"{x:577,y:705,t:1527632137979};\\\", \\\"{x:577,y:707,t:1527632137997};\\\", \\\"{x:577,y:708,t:1527632138014};\\\", \\\"{x:577,y:711,t:1527632138030};\\\", \\\"{x:576,y:714,t:1527632138047};\\\", \\\"{x:571,y:720,t:1527632138064};\\\", \\\"{x:563,y:730,t:1527632138081};\\\", \\\"{x:554,y:735,t:1527632138097};\\\", \\\"{x:546,y:739,t:1527632138113};\\\", \\\"{x:536,y:742,t:1527632138130};\\\", \\\"{x:526,y:746,t:1527632138146};\\\", \\\"{x:521,y:747,t:1527632138164};\\\", \\\"{x:520,y:747,t:1527632138180};\\\", \\\"{x:519,y:747,t:1527632138196};\\\" ] }, { \\\"rt\\\": 10589, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 749391, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:747,t:1527632139988};\\\", \\\"{x:506,y:741,t:1527632139998};\\\", \\\"{x:476,y:716,t:1527632140015};\\\", \\\"{x:403,y:677,t:1527632140031};\\\", \\\"{x:257,y:617,t:1527632140049};\\\", \\\"{x:114,y:555,t:1527632140064};\\\", \\\"{x:0,y:509,t:1527632140082};\\\", \\\"{x:0,y:469,t:1527632140099};\\\", \\\"{x:0,y:444,t:1527632140115};\\\", \\\"{x:0,y:421,t:1527632140132};\\\", \\\"{x:0,y:396,t:1527632140148};\\\", \\\"{x:0,y:379,t:1527632140164};\\\", \\\"{x:0,y:371,t:1527632140181};\\\", \\\"{x:0,y:365,t:1527632140199};\\\", \\\"{x:0,y:353,t:1527632140214};\\\", \\\"{x:0,y:346,t:1527632140232};\\\", \\\"{x:0,y:340,t:1527632140248};\\\", \\\"{x:29,y:311,t:1527632140333};\\\", \\\"{x:50,y:300,t:1527632140348};\\\", \\\"{x:84,y:284,t:1527632140379};\\\", \\\"{x:104,y:278,t:1527632140382};\\\", \\\"{x:134,y:271,t:1527632140398};\\\", \\\"{x:198,y:270,t:1527632140414};\\\", \\\"{x:279,y:270,t:1527632140431};\\\", \\\"{x:332,y:270,t:1527632140449};\\\", \\\"{x:367,y:276,t:1527632140464};\\\", \\\"{x:430,y:286,t:1527632140481};\\\", \\\"{x:476,y:294,t:1527632140499};\\\", \\\"{x:496,y:299,t:1527632140515};\\\", \\\"{x:497,y:299,t:1527632140532};\\\", \\\"{x:499,y:300,t:1527632140549};\\\", \\\"{x:499,y:301,t:1527632140572};\\\", \\\"{x:499,y:302,t:1527632141188};\\\", \\\"{x:508,y:314,t:1527632141198};\\\", \\\"{x:560,y:358,t:1527632141215};\\\", \\\"{x:642,y:404,t:1527632141231};\\\", \\\"{x:724,y:451,t:1527632141247};\\\", \\\"{x:810,y:490,t:1527632141265};\\\", \\\"{x:917,y:538,t:1527632141282};\\\", \\\"{x:1030,y:586,t:1527632141300};\\\", \\\"{x:1126,y:624,t:1527632141315};\\\", \\\"{x:1221,y:673,t:1527632141333};\\\", \\\"{x:1271,y:706,t:1527632141349};\\\", \\\"{x:1318,y:736,t:1527632141366};\\\", \\\"{x:1364,y:754,t:1527632141383};\\\", \\\"{x:1408,y:772,t:1527632141399};\\\", \\\"{x:1447,y:784,t:1527632141415};\\\", \\\"{x:1486,y:793,t:1527632141432};\\\", \\\"{x:1511,y:812,t:1527632141450};\\\", \\\"{x:1534,y:830,t:1527632141465};\\\", \\\"{x:1551,y:854,t:1527632141483};\\\", \\\"{x:1558,y:876,t:1527632141500};\\\", \\\"{x:1558,y:893,t:1527632141515};\\\", \\\"{x:1558,y:903,t:1527632141533};\\\", \\\"{x:1556,y:908,t:1527632141549};\\\", \\\"{x:1555,y:911,t:1527632141565};\\\", \\\"{x:1555,y:916,t:1527632141583};\\\", \\\"{x:1555,y:924,t:1527632141600};\\\", \\\"{x:1555,y:933,t:1527632141616};\\\", \\\"{x:1551,y:939,t:1527632141632};\\\", \\\"{x:1547,y:946,t:1527632141649};\\\", \\\"{x:1541,y:954,t:1527632141666};\\\", \\\"{x:1536,y:960,t:1527632141682};\\\", \\\"{x:1532,y:966,t:1527632141700};\\\", \\\"{x:1529,y:970,t:1527632141716};\\\", \\\"{x:1528,y:973,t:1527632141732};\\\", \\\"{x:1527,y:973,t:1527632141757};\\\", \\\"{x:1527,y:974,t:1527632141772};\\\", \\\"{x:1526,y:975,t:1527632141788};\\\", \\\"{x:1526,y:977,t:1527632141940};\\\", \\\"{x:1525,y:978,t:1527632141950};\\\", \\\"{x:1523,y:980,t:1527632141967};\\\", \\\"{x:1520,y:982,t:1527632141983};\\\", \\\"{x:1513,y:985,t:1527632142000};\\\", \\\"{x:1512,y:985,t:1527632142017};\\\", \\\"{x:1509,y:986,t:1527632142032};\\\", \\\"{x:1507,y:986,t:1527632142060};\\\", \\\"{x:1506,y:986,t:1527632142068};\\\", \\\"{x:1504,y:985,t:1527632142084};\\\", \\\"{x:1500,y:984,t:1527632142100};\\\", \\\"{x:1494,y:983,t:1527632142117};\\\", \\\"{x:1489,y:983,t:1527632142133};\\\", \\\"{x:1488,y:983,t:1527632142150};\\\", \\\"{x:1482,y:983,t:1527632142167};\\\", \\\"{x:1472,y:986,t:1527632142184};\\\", \\\"{x:1464,y:990,t:1527632142200};\\\", \\\"{x:1460,y:993,t:1527632142217};\\\", \\\"{x:1456,y:996,t:1527632142234};\\\", \\\"{x:1455,y:998,t:1527632142250};\\\", \\\"{x:1445,y:1002,t:1527632142266};\\\", \\\"{x:1434,y:1005,t:1527632142284};\\\", \\\"{x:1423,y:1005,t:1527632142299};\\\", \\\"{x:1409,y:1006,t:1527632142316};\\\", \\\"{x:1401,y:1006,t:1527632142333};\\\", \\\"{x:1395,y:1006,t:1527632142350};\\\", \\\"{x:1391,y:1006,t:1527632142367};\\\", \\\"{x:1387,y:1005,t:1527632142383};\\\", \\\"{x:1386,y:1005,t:1527632142399};\\\", \\\"{x:1382,y:1003,t:1527632142416};\\\", \\\"{x:1380,y:1001,t:1527632142433};\\\", \\\"{x:1379,y:999,t:1527632142449};\\\", \\\"{x:1378,y:998,t:1527632142467};\\\", \\\"{x:1378,y:996,t:1527632142483};\\\", \\\"{x:1377,y:993,t:1527632142500};\\\", \\\"{x:1377,y:992,t:1527632142517};\\\", \\\"{x:1376,y:986,t:1527632142534};\\\", \\\"{x:1376,y:982,t:1527632142550};\\\", \\\"{x:1375,y:976,t:1527632142567};\\\", \\\"{x:1372,y:972,t:1527632142583};\\\", \\\"{x:1371,y:970,t:1527632142600};\\\", \\\"{x:1370,y:968,t:1527632142616};\\\", \\\"{x:1369,y:966,t:1527632142668};\\\", \\\"{x:1368,y:965,t:1527632142684};\\\", \\\"{x:1366,y:963,t:1527632142701};\\\", \\\"{x:1366,y:961,t:1527632142716};\\\", \\\"{x:1365,y:959,t:1527632142764};\\\", \\\"{x:1365,y:958,t:1527632142829};\\\", \\\"{x:1364,y:958,t:1527632142836};\\\", \\\"{x:1364,y:957,t:1527632142852};\\\", \\\"{x:1364,y:956,t:1527632142867};\\\", \\\"{x:1364,y:955,t:1527632142883};\\\", \\\"{x:1364,y:951,t:1527632142900};\\\", \\\"{x:1364,y:948,t:1527632142917};\\\", \\\"{x:1364,y:947,t:1527632142933};\\\", \\\"{x:1364,y:945,t:1527632142951};\\\", \\\"{x:1364,y:944,t:1527632142967};\\\", \\\"{x:1364,y:943,t:1527632142984};\\\", \\\"{x:1365,y:941,t:1527632143000};\\\", \\\"{x:1366,y:940,t:1527632143084};\\\", \\\"{x:1366,y:939,t:1527632143100};\\\", \\\"{x:1367,y:936,t:1527632143117};\\\", \\\"{x:1369,y:934,t:1527632143133};\\\", \\\"{x:1370,y:932,t:1527632143150};\\\", \\\"{x:1372,y:930,t:1527632143168};\\\", \\\"{x:1373,y:928,t:1527632143184};\\\", \\\"{x:1374,y:926,t:1527632143200};\\\", \\\"{x:1376,y:924,t:1527632143218};\\\", \\\"{x:1377,y:921,t:1527632143234};\\\", \\\"{x:1379,y:919,t:1527632143251};\\\", \\\"{x:1380,y:919,t:1527632143268};\\\", \\\"{x:1380,y:918,t:1527632143291};\\\", \\\"{x:1382,y:916,t:1527632145084};\\\", \\\"{x:1384,y:911,t:1527632145092};\\\", \\\"{x:1387,y:908,t:1527632145102};\\\", \\\"{x:1390,y:903,t:1527632145119};\\\", \\\"{x:1394,y:897,t:1527632145136};\\\", \\\"{x:1396,y:895,t:1527632145153};\\\", \\\"{x:1398,y:892,t:1527632145169};\\\", \\\"{x:1398,y:891,t:1527632145188};\\\", \\\"{x:1398,y:890,t:1527632145202};\\\", \\\"{x:1398,y:889,t:1527632145219};\\\", \\\"{x:1399,y:888,t:1527632145252};\\\", \\\"{x:1400,y:886,t:1527632145269};\\\", \\\"{x:1401,y:885,t:1527632145286};\\\", \\\"{x:1402,y:882,t:1527632145303};\\\", \\\"{x:1403,y:879,t:1527632145319};\\\", \\\"{x:1404,y:877,t:1527632145336};\\\", \\\"{x:1405,y:875,t:1527632145353};\\\", \\\"{x:1408,y:869,t:1527632145369};\\\", \\\"{x:1408,y:867,t:1527632145386};\\\", \\\"{x:1409,y:865,t:1527632145402};\\\", \\\"{x:1410,y:862,t:1527632145418};\\\", \\\"{x:1416,y:851,t:1527632145435};\\\", \\\"{x:1425,y:837,t:1527632145452};\\\", \\\"{x:1430,y:827,t:1527632145469};\\\", \\\"{x:1434,y:819,t:1527632145486};\\\", \\\"{x:1437,y:815,t:1527632145502};\\\", \\\"{x:1439,y:810,t:1527632145519};\\\", \\\"{x:1441,y:807,t:1527632145536};\\\", \\\"{x:1442,y:800,t:1527632145553};\\\", \\\"{x:1448,y:788,t:1527632145570};\\\", \\\"{x:1452,y:779,t:1527632145586};\\\", \\\"{x:1455,y:764,t:1527632145602};\\\", \\\"{x:1457,y:754,t:1527632145619};\\\", \\\"{x:1460,y:726,t:1527632145636};\\\", \\\"{x:1462,y:707,t:1527632145653};\\\", \\\"{x:1467,y:691,t:1527632145670};\\\", \\\"{x:1476,y:675,t:1527632145686};\\\", \\\"{x:1482,y:663,t:1527632145703};\\\", \\\"{x:1487,y:652,t:1527632145720};\\\", \\\"{x:1487,y:646,t:1527632145736};\\\", \\\"{x:1492,y:638,t:1527632145752};\\\", \\\"{x:1497,y:631,t:1527632145770};\\\", \\\"{x:1502,y:624,t:1527632145786};\\\", \\\"{x:1506,y:619,t:1527632145802};\\\", \\\"{x:1511,y:612,t:1527632145820};\\\", \\\"{x:1515,y:605,t:1527632145836};\\\", \\\"{x:1520,y:592,t:1527632145852};\\\", \\\"{x:1526,y:583,t:1527632145869};\\\", \\\"{x:1532,y:572,t:1527632145886};\\\", \\\"{x:1535,y:570,t:1527632145903};\\\", \\\"{x:1535,y:569,t:1527632146012};\\\", \\\"{x:1535,y:568,t:1527632146020};\\\", \\\"{x:1535,y:567,t:1527632146372};\\\", \\\"{x:1543,y:560,t:1527632146387};\\\", \\\"{x:1557,y:550,t:1527632146403};\\\", \\\"{x:1571,y:538,t:1527632146420};\\\", \\\"{x:1577,y:535,t:1527632146437};\\\", \\\"{x:1581,y:529,t:1527632146453};\\\", \\\"{x:1583,y:526,t:1527632146470};\\\", \\\"{x:1584,y:526,t:1527632146487};\\\", \\\"{x:1584,y:525,t:1527632146516};\\\", \\\"{x:1584,y:523,t:1527632146532};\\\", \\\"{x:1584,y:522,t:1527632146548};\\\", \\\"{x:1584,y:520,t:1527632146571};\\\", \\\"{x:1585,y:520,t:1527632146587};\\\", \\\"{x:1585,y:519,t:1527632146604};\\\", \\\"{x:1586,y:517,t:1527632146620};\\\", \\\"{x:1589,y:512,t:1527632146636};\\\", \\\"{x:1590,y:507,t:1527632146653};\\\", \\\"{x:1590,y:505,t:1527632146669};\\\", \\\"{x:1590,y:504,t:1527632146692};\\\", \\\"{x:1586,y:504,t:1527632146804};\\\", \\\"{x:1571,y:504,t:1527632146820};\\\", \\\"{x:1534,y:510,t:1527632146837};\\\", \\\"{x:1441,y:514,t:1527632146854};\\\", \\\"{x:1304,y:525,t:1527632146870};\\\", \\\"{x:1147,y:542,t:1527632146887};\\\", \\\"{x:982,y:553,t:1527632146904};\\\", \\\"{x:813,y:582,t:1527632146921};\\\", \\\"{x:669,y:601,t:1527632146937};\\\", \\\"{x:575,y:603,t:1527632146954};\\\", \\\"{x:513,y:603,t:1527632146971};\\\", \\\"{x:483,y:603,t:1527632146987};\\\", \\\"{x:468,y:603,t:1527632147003};\\\", \\\"{x:466,y:603,t:1527632147021};\\\", \\\"{x:466,y:602,t:1527632147036};\\\", \\\"{x:466,y:600,t:1527632147116};\\\", \\\"{x:466,y:596,t:1527632147124};\\\", \\\"{x:464,y:590,t:1527632147137};\\\", \\\"{x:464,y:583,t:1527632147154};\\\", \\\"{x:461,y:571,t:1527632147171};\\\", \\\"{x:459,y:557,t:1527632147187};\\\", \\\"{x:454,y:548,t:1527632147204};\\\", \\\"{x:452,y:547,t:1527632147221};\\\", \\\"{x:448,y:546,t:1527632147236};\\\", \\\"{x:444,y:543,t:1527632147254};\\\", \\\"{x:433,y:540,t:1527632147271};\\\", \\\"{x:424,y:536,t:1527632147288};\\\", \\\"{x:421,y:536,t:1527632147303};\\\", \\\"{x:419,y:536,t:1527632147372};\\\", \\\"{x:417,y:535,t:1527632147387};\\\", \\\"{x:415,y:534,t:1527632147404};\\\", \\\"{x:414,y:532,t:1527632147421};\\\", \\\"{x:414,y:531,t:1527632147451};\\\", \\\"{x:412,y:530,t:1527632147484};\\\", \\\"{x:411,y:530,t:1527632147492};\\\", \\\"{x:405,y:530,t:1527632147504};\\\", \\\"{x:396,y:532,t:1527632147522};\\\", \\\"{x:386,y:536,t:1527632147538};\\\", \\\"{x:385,y:536,t:1527632147852};\\\", \\\"{x:375,y:535,t:1527632147860};\\\", \\\"{x:366,y:534,t:1527632147872};\\\", \\\"{x:342,y:532,t:1527632147888};\\\", \\\"{x:287,y:523,t:1527632147905};\\\", \\\"{x:260,y:521,t:1527632147921};\\\", \\\"{x:251,y:518,t:1527632147938};\\\", \\\"{x:247,y:518,t:1527632147954};\\\", \\\"{x:245,y:518,t:1527632147971};\\\", \\\"{x:243,y:518,t:1527632148052};\\\", \\\"{x:241,y:518,t:1527632148060};\\\", \\\"{x:236,y:518,t:1527632148070};\\\", \\\"{x:228,y:523,t:1527632148088};\\\", \\\"{x:222,y:528,t:1527632148106};\\\", \\\"{x:217,y:535,t:1527632148121};\\\", \\\"{x:213,y:541,t:1527632148138};\\\", \\\"{x:211,y:544,t:1527632148154};\\\", \\\"{x:211,y:548,t:1527632148170};\\\", \\\"{x:219,y:557,t:1527632148189};\\\", \\\"{x:237,y:561,t:1527632148205};\\\", \\\"{x:259,y:564,t:1527632148221};\\\", \\\"{x:278,y:565,t:1527632148238};\\\", \\\"{x:303,y:565,t:1527632148255};\\\", \\\"{x:342,y:569,t:1527632148271};\\\", \\\"{x:373,y:569,t:1527632148288};\\\", \\\"{x:398,y:569,t:1527632148305};\\\", \\\"{x:426,y:569,t:1527632148321};\\\", \\\"{x:449,y:569,t:1527632148338};\\\", \\\"{x:472,y:569,t:1527632148355};\\\", \\\"{x:496,y:569,t:1527632148372};\\\", \\\"{x:520,y:571,t:1527632148388};\\\", \\\"{x:551,y:572,t:1527632148404};\\\", \\\"{x:579,y:572,t:1527632148422};\\\", \\\"{x:603,y:572,t:1527632148438};\\\", \\\"{x:625,y:574,t:1527632148455};\\\", \\\"{x:634,y:575,t:1527632148471};\\\", \\\"{x:639,y:575,t:1527632148488};\\\", \\\"{x:642,y:575,t:1527632148505};\\\", \\\"{x:651,y:575,t:1527632148522};\\\", \\\"{x:665,y:575,t:1527632148538};\\\", \\\"{x:679,y:574,t:1527632148555};\\\", \\\"{x:695,y:570,t:1527632148572};\\\", \\\"{x:714,y:569,t:1527632148587};\\\", \\\"{x:726,y:569,t:1527632148605};\\\", \\\"{x:728,y:569,t:1527632148622};\\\", \\\"{x:730,y:569,t:1527632148637};\\\", \\\"{x:730,y:570,t:1527632148654};\\\", \\\"{x:727,y:572,t:1527632148672};\\\", \\\"{x:721,y:576,t:1527632148688};\\\", \\\"{x:720,y:577,t:1527632148705};\\\", \\\"{x:714,y:580,t:1527632148722};\\\", \\\"{x:708,y:582,t:1527632148739};\\\", \\\"{x:692,y:584,t:1527632148755};\\\", \\\"{x:669,y:590,t:1527632148771};\\\", \\\"{x:659,y:591,t:1527632148789};\\\", \\\"{x:657,y:591,t:1527632148805};\\\", \\\"{x:655,y:591,t:1527632148822};\\\", \\\"{x:653,y:591,t:1527632148891};\\\", \\\"{x:650,y:590,t:1527632148905};\\\", \\\"{x:640,y:589,t:1527632148922};\\\", \\\"{x:626,y:586,t:1527632148939};\\\", \\\"{x:598,y:586,t:1527632148956};\\\", \\\"{x:571,y:586,t:1527632148971};\\\", \\\"{x:547,y:586,t:1527632148988};\\\", \\\"{x:520,y:586,t:1527632149004};\\\", \\\"{x:491,y:586,t:1527632149022};\\\", \\\"{x:471,y:586,t:1527632149038};\\\", \\\"{x:457,y:586,t:1527632149055};\\\", \\\"{x:453,y:586,t:1527632149072};\\\", \\\"{x:450,y:586,t:1527632149089};\\\", \\\"{x:449,y:586,t:1527632149148};\\\", \\\"{x:448,y:586,t:1527632149155};\\\", \\\"{x:443,y:580,t:1527632149172};\\\", \\\"{x:435,y:572,t:1527632149189};\\\", \\\"{x:431,y:564,t:1527632149205};\\\", \\\"{x:427,y:551,t:1527632149223};\\\", \\\"{x:425,y:541,t:1527632149239};\\\", \\\"{x:421,y:532,t:1527632149254};\\\", \\\"{x:418,y:527,t:1527632149272};\\\", \\\"{x:415,y:525,t:1527632149289};\\\", \\\"{x:414,y:525,t:1527632149364};\\\", \\\"{x:411,y:529,t:1527632149372};\\\", \\\"{x:404,y:542,t:1527632149388};\\\", \\\"{x:395,y:556,t:1527632149407};\\\", \\\"{x:388,y:569,t:1527632149422};\\\", \\\"{x:382,y:578,t:1527632149438};\\\", \\\"{x:379,y:586,t:1527632149456};\\\", \\\"{x:377,y:589,t:1527632149471};\\\", \\\"{x:376,y:592,t:1527632149489};\\\", \\\"{x:375,y:594,t:1527632149506};\\\", \\\"{x:374,y:597,t:1527632149522};\\\", \\\"{x:373,y:599,t:1527632149539};\\\", \\\"{x:373,y:601,t:1527632149588};\\\", \\\"{x:373,y:603,t:1527632149606};\\\", \\\"{x:373,y:604,t:1527632149622};\\\", \\\"{x:373,y:605,t:1527632149639};\\\", \\\"{x:373,y:607,t:1527632149656};\\\", \\\"{x:373,y:612,t:1527632149673};\\\", \\\"{x:374,y:614,t:1527632149689};\\\", \\\"{x:374,y:616,t:1527632149706};\\\", \\\"{x:374,y:617,t:1527632149748};\\\", \\\"{x:375,y:618,t:1527632149780};\\\", \\\"{x:381,y:622,t:1527632150052};\\\", \\\"{x:392,y:636,t:1527632150060};\\\", \\\"{x:408,y:651,t:1527632150073};\\\", \\\"{x:430,y:677,t:1527632150089};\\\", \\\"{x:453,y:694,t:1527632150105};\\\", \\\"{x:473,y:709,t:1527632150122};\\\", \\\"{x:505,y:727,t:1527632150140};\\\", \\\"{x:518,y:736,t:1527632150156};\\\", \\\"{x:525,y:742,t:1527632150173};\\\", \\\"{x:526,y:743,t:1527632150190};\\\", \\\"{x:526,y:744,t:1527632150932};\\\", \\\"{x:520,y:744,t:1527632150939};\\\", \\\"{x:504,y:743,t:1527632150957};\\\", \\\"{x:477,y:743,t:1527632150973};\\\", \\\"{x:438,y:743,t:1527632150990};\\\", \\\"{x:399,y:739,t:1527632151006};\\\", \\\"{x:376,y:733,t:1527632151024};\\\", \\\"{x:357,y:726,t:1527632151039};\\\", \\\"{x:342,y:716,t:1527632151057};\\\", \\\"{x:332,y:707,t:1527632151073};\\\", \\\"{x:322,y:692,t:1527632151090};\\\", \\\"{x:320,y:669,t:1527632151107};\\\", \\\"{x:320,y:648,t:1527632151123};\\\", \\\"{x:326,y:627,t:1527632151139};\\\", \\\"{x:329,y:606,t:1527632151157};\\\", \\\"{x:330,y:583,t:1527632151174};\\\", \\\"{x:331,y:550,t:1527632151190};\\\", \\\"{x:335,y:521,t:1527632151207};\\\", \\\"{x:340,y:499,t:1527632151224};\\\", \\\"{x:348,y:478,t:1527632151240};\\\", \\\"{x:362,y:457,t:1527632151257};\\\", \\\"{x:374,y:442,t:1527632151274};\\\", \\\"{x:393,y:426,t:1527632151290};\\\", \\\"{x:407,y:420,t:1527632151307};\\\", \\\"{x:430,y:414,t:1527632151323};\\\", \\\"{x:442,y:410,t:1527632151340};\\\", \\\"{x:449,y:410,t:1527632151357};\\\", \\\"{x:454,y:410,t:1527632151374};\\\", \\\"{x:465,y:410,t:1527632151390};\\\", \\\"{x:480,y:410,t:1527632151407};\\\", \\\"{x:493,y:410,t:1527632151423};\\\", \\\"{x:506,y:412,t:1527632151440};\\\", \\\"{x:521,y:413,t:1527632151457};\\\", \\\"{x:529,y:414,t:1527632151482};\\\", \\\"{x:529,y:415,t:1527632151491};\\\" ] }, { \\\"rt\\\": 12300, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 762925, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:415,t:1527632152252};\\\", \\\"{x:530,y:413,t:1527632153124};\\\", \\\"{x:532,y:412,t:1527632153148};\\\", \\\"{x:533,y:411,t:1527632153158};\\\", \\\"{x:536,y:411,t:1527632153852};\\\", \\\"{x:545,y:411,t:1527632153859};\\\", \\\"{x:602,y:411,t:1527632153876};\\\", \\\"{x:696,y:411,t:1527632153892};\\\", \\\"{x:793,y:411,t:1527632153909};\\\", \\\"{x:893,y:411,t:1527632153926};\\\", \\\"{x:987,y:411,t:1527632153942};\\\", \\\"{x:1068,y:411,t:1527632153959};\\\", \\\"{x:1103,y:413,t:1527632153976};\\\", \\\"{x:1119,y:413,t:1527632153992};\\\", \\\"{x:1122,y:414,t:1527632154009};\\\", \\\"{x:1123,y:414,t:1527632154026};\\\", \\\"{x:1127,y:414,t:1527632154404};\\\", \\\"{x:1131,y:414,t:1527632154412};\\\", \\\"{x:1141,y:416,t:1527632154426};\\\", \\\"{x:1166,y:419,t:1527632154443};\\\", \\\"{x:1195,y:419,t:1527632154459};\\\", \\\"{x:1284,y:419,t:1527632154476};\\\", \\\"{x:1340,y:419,t:1527632154493};\\\", \\\"{x:1398,y:419,t:1527632154510};\\\", \\\"{x:1441,y:418,t:1527632154526};\\\", \\\"{x:1473,y:412,t:1527632154543};\\\", \\\"{x:1497,y:406,t:1527632154559};\\\", \\\"{x:1505,y:402,t:1527632154576};\\\", \\\"{x:1508,y:400,t:1527632154593};\\\", \\\"{x:1510,y:398,t:1527632154609};\\\", \\\"{x:1512,y:396,t:1527632154626};\\\", \\\"{x:1512,y:395,t:1527632154643};\\\", \\\"{x:1514,y:391,t:1527632154659};\\\", \\\"{x:1514,y:390,t:1527632154676};\\\", \\\"{x:1515,y:388,t:1527632154693};\\\", \\\"{x:1516,y:387,t:1527632154710};\\\", \\\"{x:1516,y:386,t:1527632154732};\\\", \\\"{x:1516,y:385,t:1527632154743};\\\", \\\"{x:1516,y:384,t:1527632154760};\\\", \\\"{x:1517,y:383,t:1527632154776};\\\", \\\"{x:1518,y:381,t:1527632154793};\\\", \\\"{x:1518,y:380,t:1527632154809};\\\", \\\"{x:1518,y:378,t:1527632154825};\\\", \\\"{x:1518,y:376,t:1527632154843};\\\", \\\"{x:1518,y:375,t:1527632154860};\\\", \\\"{x:1518,y:372,t:1527632154876};\\\", \\\"{x:1518,y:371,t:1527632154893};\\\", \\\"{x:1518,y:369,t:1527632154910};\\\", \\\"{x:1518,y:366,t:1527632154926};\\\", \\\"{x:1518,y:365,t:1527632154943};\\\", \\\"{x:1518,y:362,t:1527632154960};\\\", \\\"{x:1518,y:361,t:1527632154976};\\\", \\\"{x:1518,y:359,t:1527632154993};\\\", \\\"{x:1519,y:356,t:1527632155035};\\\", \\\"{x:1519,y:355,t:1527632155068};\\\", \\\"{x:1521,y:355,t:1527632155076};\\\", \\\"{x:1521,y:354,t:1527632155093};\\\", \\\"{x:1522,y:353,t:1527632155110};\\\", \\\"{x:1526,y:353,t:1527632155292};\\\", \\\"{x:1530,y:358,t:1527632155300};\\\", \\\"{x:1533,y:363,t:1527632155310};\\\", \\\"{x:1538,y:370,t:1527632155327};\\\", \\\"{x:1541,y:376,t:1527632155343};\\\", \\\"{x:1547,y:385,t:1527632155360};\\\", \\\"{x:1554,y:401,t:1527632155377};\\\", \\\"{x:1564,y:422,t:1527632155393};\\\", \\\"{x:1576,y:441,t:1527632155410};\\\", \\\"{x:1587,y:463,t:1527632155427};\\\", \\\"{x:1593,y:479,t:1527632155443};\\\", \\\"{x:1603,y:503,t:1527632155460};\\\", \\\"{x:1611,y:519,t:1527632155477};\\\", \\\"{x:1616,y:530,t:1527632155493};\\\", \\\"{x:1618,y:536,t:1527632155510};\\\", \\\"{x:1618,y:542,t:1527632155527};\\\", \\\"{x:1620,y:549,t:1527632155543};\\\", \\\"{x:1621,y:558,t:1527632155560};\\\", \\\"{x:1621,y:569,t:1527632155577};\\\", \\\"{x:1622,y:588,t:1527632155593};\\\", \\\"{x:1622,y:612,t:1527632155610};\\\", \\\"{x:1621,y:645,t:1527632155627};\\\", \\\"{x:1606,y:686,t:1527632155643};\\\", \\\"{x:1602,y:699,t:1527632155660};\\\", \\\"{x:1598,y:707,t:1527632155677};\\\", \\\"{x:1594,y:714,t:1527632155694};\\\", \\\"{x:1588,y:722,t:1527632155710};\\\", \\\"{x:1579,y:732,t:1527632155727};\\\", \\\"{x:1565,y:744,t:1527632155744};\\\", \\\"{x:1539,y:759,t:1527632155760};\\\", \\\"{x:1516,y:773,t:1527632155777};\\\", \\\"{x:1503,y:782,t:1527632155794};\\\", \\\"{x:1490,y:792,t:1527632155810};\\\", \\\"{x:1471,y:803,t:1527632155827};\\\", \\\"{x:1450,y:813,t:1527632155843};\\\", \\\"{x:1437,y:818,t:1527632155860};\\\", \\\"{x:1425,y:823,t:1527632155877};\\\", \\\"{x:1410,y:828,t:1527632155894};\\\", \\\"{x:1389,y:831,t:1527632155910};\\\", \\\"{x:1372,y:836,t:1527632155927};\\\", \\\"{x:1358,y:844,t:1527632155944};\\\", \\\"{x:1353,y:846,t:1527632155960};\\\", \\\"{x:1345,y:849,t:1527632155977};\\\", \\\"{x:1341,y:849,t:1527632155994};\\\", \\\"{x:1333,y:849,t:1527632156010};\\\", \\\"{x:1320,y:847,t:1527632156027};\\\", \\\"{x:1299,y:843,t:1527632156043};\\\", \\\"{x:1291,y:843,t:1527632156060};\\\", \\\"{x:1288,y:843,t:1527632156077};\\\", \\\"{x:1284,y:843,t:1527632156094};\\\", \\\"{x:1275,y:842,t:1527632156112};\\\", \\\"{x:1272,y:841,t:1527632156127};\\\", \\\"{x:1269,y:840,t:1527632156144};\\\", \\\"{x:1268,y:840,t:1527632156161};\\\", \\\"{x:1267,y:840,t:1527632156177};\\\", \\\"{x:1266,y:840,t:1527632156212};\\\", \\\"{x:1266,y:843,t:1527632156227};\\\", \\\"{x:1266,y:854,t:1527632156244};\\\", \\\"{x:1266,y:861,t:1527632156261};\\\", \\\"{x:1273,y:871,t:1527632156277};\\\", \\\"{x:1279,y:881,t:1527632156294};\\\", \\\"{x:1285,y:889,t:1527632156311};\\\", \\\"{x:1294,y:894,t:1527632156327};\\\", \\\"{x:1318,y:897,t:1527632156344};\\\", \\\"{x:1351,y:901,t:1527632156361};\\\", \\\"{x:1382,y:909,t:1527632156377};\\\", \\\"{x:1443,y:914,t:1527632156394};\\\", \\\"{x:1496,y:914,t:1527632156411};\\\", \\\"{x:1544,y:914,t:1527632156427};\\\", \\\"{x:1548,y:911,t:1527632156444};\\\", \\\"{x:1548,y:910,t:1527632156612};\\\", \\\"{x:1546,y:909,t:1527632156627};\\\", \\\"{x:1542,y:907,t:1527632156644};\\\", \\\"{x:1540,y:905,t:1527632156661};\\\", \\\"{x:1533,y:905,t:1527632156678};\\\", \\\"{x:1518,y:905,t:1527632156694};\\\", \\\"{x:1508,y:905,t:1527632156711};\\\", \\\"{x:1495,y:905,t:1527632156728};\\\", \\\"{x:1481,y:905,t:1527632156744};\\\", \\\"{x:1470,y:905,t:1527632156761};\\\", \\\"{x:1463,y:905,t:1527632156779};\\\", \\\"{x:1458,y:905,t:1527632156794};\\\", \\\"{x:1451,y:905,t:1527632156811};\\\", \\\"{x:1448,y:905,t:1527632156828};\\\", \\\"{x:1446,y:905,t:1527632156845};\\\", \\\"{x:1441,y:905,t:1527632156861};\\\", \\\"{x:1440,y:905,t:1527632156883};\\\", \\\"{x:1439,y:905,t:1527632156894};\\\", \\\"{x:1438,y:905,t:1527632156911};\\\", \\\"{x:1437,y:905,t:1527632156928};\\\", \\\"{x:1433,y:905,t:1527632156996};\\\", \\\"{x:1431,y:903,t:1527632157011};\\\", \\\"{x:1420,y:897,t:1527632157027};\\\", \\\"{x:1412,y:889,t:1527632157044};\\\", \\\"{x:1403,y:881,t:1527632157061};\\\", \\\"{x:1391,y:876,t:1527632157078};\\\", \\\"{x:1380,y:872,t:1527632157095};\\\", \\\"{x:1369,y:870,t:1527632157112};\\\", \\\"{x:1363,y:870,t:1527632157128};\\\", \\\"{x:1352,y:872,t:1527632157145};\\\", \\\"{x:1347,y:872,t:1527632157161};\\\", \\\"{x:1344,y:873,t:1527632157178};\\\", \\\"{x:1343,y:871,t:1527632157316};\\\", \\\"{x:1343,y:862,t:1527632157328};\\\", \\\"{x:1343,y:842,t:1527632157345};\\\", \\\"{x:1350,y:821,t:1527632157361};\\\", \\\"{x:1355,y:804,t:1527632157378};\\\", \\\"{x:1362,y:783,t:1527632157396};\\\", \\\"{x:1369,y:770,t:1527632157411};\\\", \\\"{x:1376,y:752,t:1527632157428};\\\", \\\"{x:1376,y:751,t:1527632157445};\\\", \\\"{x:1377,y:748,t:1527632157469};\\\", \\\"{x:1377,y:747,t:1527632157492};\\\", \\\"{x:1377,y:745,t:1527632157524};\\\", \\\"{x:1377,y:744,t:1527632157540};\\\", \\\"{x:1377,y:741,t:1527632157555};\\\", \\\"{x:1377,y:739,t:1527632157563};\\\", \\\"{x:1376,y:738,t:1527632157578};\\\", \\\"{x:1371,y:733,t:1527632157595};\\\", \\\"{x:1366,y:729,t:1527632157611};\\\", \\\"{x:1355,y:725,t:1527632157628};\\\", \\\"{x:1351,y:723,t:1527632157646};\\\", \\\"{x:1350,y:723,t:1527632157693};\\\", \\\"{x:1348,y:721,t:1527632157757};\\\", \\\"{x:1346,y:721,t:1527632157772};\\\", \\\"{x:1345,y:719,t:1527632157829};\\\", \\\"{x:1345,y:718,t:1527632157846};\\\", \\\"{x:1345,y:715,t:1527632157862};\\\", \\\"{x:1345,y:714,t:1527632157879};\\\", \\\"{x:1344,y:712,t:1527632157895};\\\", \\\"{x:1344,y:711,t:1527632157916};\\\", \\\"{x:1344,y:710,t:1527632157940};\\\", \\\"{x:1344,y:708,t:1527632158165};\\\", \\\"{x:1344,y:705,t:1527632158180};\\\", \\\"{x:1344,y:704,t:1527632158197};\\\", \\\"{x:1344,y:701,t:1527632158215};\\\", \\\"{x:1344,y:699,t:1527632158229};\\\", \\\"{x:1344,y:698,t:1527632158245};\\\", \\\"{x:1344,y:697,t:1527632158262};\\\", \\\"{x:1345,y:695,t:1527632160213};\\\", \\\"{x:1376,y:652,t:1527632160232};\\\", \\\"{x:1397,y:627,t:1527632160248};\\\", \\\"{x:1418,y:598,t:1527632160264};\\\", \\\"{x:1435,y:578,t:1527632160281};\\\", \\\"{x:1448,y:562,t:1527632160298};\\\", \\\"{x:1452,y:556,t:1527632160314};\\\", \\\"{x:1453,y:554,t:1527632160331};\\\", \\\"{x:1452,y:552,t:1527632160421};\\\", \\\"{x:1445,y:552,t:1527632160432};\\\", \\\"{x:1432,y:552,t:1527632160448};\\\", \\\"{x:1422,y:552,t:1527632160465};\\\", \\\"{x:1415,y:556,t:1527632160481};\\\", \\\"{x:1413,y:556,t:1527632160498};\\\", \\\"{x:1412,y:556,t:1527632160514};\\\", \\\"{x:1411,y:558,t:1527632160532};\\\", \\\"{x:1411,y:559,t:1527632160638};\\\", \\\"{x:1406,y:560,t:1527632161548};\\\", \\\"{x:1359,y:564,t:1527632161565};\\\", \\\"{x:1263,y:571,t:1527632161581};\\\", \\\"{x:1166,y:571,t:1527632161599};\\\", \\\"{x:1069,y:573,t:1527632161614};\\\", \\\"{x:959,y:584,t:1527632161632};\\\", \\\"{x:842,y:584,t:1527632161649};\\\", \\\"{x:734,y:585,t:1527632161665};\\\", \\\"{x:611,y:582,t:1527632161681};\\\", \\\"{x:441,y:579,t:1527632161716};\\\", \\\"{x:410,y:577,t:1527632161732};\\\", \\\"{x:399,y:577,t:1527632161748};\\\", \\\"{x:393,y:577,t:1527632161765};\\\", \\\"{x:390,y:577,t:1527632161782};\\\", \\\"{x:388,y:577,t:1527632161981};\\\", \\\"{x:375,y:573,t:1527632161998};\\\", \\\"{x:354,y:568,t:1527632162016};\\\", \\\"{x:328,y:564,t:1527632162032};\\\", \\\"{x:305,y:561,t:1527632162049};\\\", \\\"{x:282,y:559,t:1527632162065};\\\", \\\"{x:260,y:557,t:1527632162082};\\\", \\\"{x:245,y:554,t:1527632162100};\\\", \\\"{x:224,y:552,t:1527632162115};\\\", \\\"{x:212,y:551,t:1527632162132};\\\", \\\"{x:207,y:550,t:1527632162149};\\\", \\\"{x:207,y:549,t:1527632162165};\\\", \\\"{x:206,y:549,t:1527632162244};\\\", \\\"{x:203,y:549,t:1527632162267};\\\", \\\"{x:203,y:552,t:1527632162282};\\\", \\\"{x:200,y:558,t:1527632162300};\\\", \\\"{x:199,y:566,t:1527632162316};\\\", \\\"{x:199,y:580,t:1527632162332};\\\", \\\"{x:210,y:591,t:1527632162350};\\\", \\\"{x:231,y:599,t:1527632162367};\\\", \\\"{x:256,y:604,t:1527632162383};\\\", \\\"{x:286,y:608,t:1527632162400};\\\", \\\"{x:330,y:613,t:1527632162416};\\\", \\\"{x:370,y:613,t:1527632162432};\\\", \\\"{x:397,y:613,t:1527632162449};\\\", \\\"{x:419,y:613,t:1527632162467};\\\", \\\"{x:436,y:611,t:1527632162483};\\\", \\\"{x:457,y:609,t:1527632162499};\\\", \\\"{x:496,y:601,t:1527632162515};\\\", \\\"{x:510,y:596,t:1527632162534};\\\", \\\"{x:530,y:590,t:1527632162550};\\\", \\\"{x:544,y:587,t:1527632162566};\\\", \\\"{x:553,y:585,t:1527632162583};\\\", \\\"{x:563,y:584,t:1527632162600};\\\", \\\"{x:577,y:582,t:1527632162616};\\\", \\\"{x:593,y:580,t:1527632162634};\\\", \\\"{x:607,y:577,t:1527632162650};\\\", \\\"{x:615,y:575,t:1527632162666};\\\", \\\"{x:623,y:573,t:1527632162684};\\\", \\\"{x:631,y:571,t:1527632162699};\\\", \\\"{x:644,y:571,t:1527632162718};\\\", \\\"{x:663,y:571,t:1527632162733};\\\", \\\"{x:685,y:574,t:1527632162750};\\\", \\\"{x:715,y:578,t:1527632162767};\\\", \\\"{x:741,y:582,t:1527632162784};\\\", \\\"{x:779,y:583,t:1527632162800};\\\", \\\"{x:817,y:586,t:1527632162817};\\\", \\\"{x:851,y:586,t:1527632162834};\\\", \\\"{x:872,y:583,t:1527632162850};\\\", \\\"{x:876,y:583,t:1527632162867};\\\", \\\"{x:878,y:582,t:1527632162883};\\\", \\\"{x:878,y:581,t:1527632162949};\\\", \\\"{x:875,y:576,t:1527632162967};\\\", \\\"{x:872,y:573,t:1527632162984};\\\", \\\"{x:864,y:566,t:1527632163000};\\\", \\\"{x:859,y:565,t:1527632163017};\\\", \\\"{x:858,y:563,t:1527632163032};\\\", \\\"{x:855,y:560,t:1527632163050};\\\", \\\"{x:853,y:560,t:1527632163065};\\\", \\\"{x:846,y:551,t:1527632163084};\\\", \\\"{x:838,y:542,t:1527632163099};\\\", \\\"{x:836,y:540,t:1527632163116};\\\", \\\"{x:836,y:539,t:1527632163133};\\\", \\\"{x:832,y:541,t:1527632163428};\\\", \\\"{x:827,y:542,t:1527632163436};\\\", \\\"{x:822,y:547,t:1527632163451};\\\", \\\"{x:807,y:557,t:1527632163466};\\\", \\\"{x:775,y:576,t:1527632163484};\\\", \\\"{x:746,y:595,t:1527632163501};\\\", \\\"{x:691,y:629,t:1527632163517};\\\", \\\"{x:662,y:652,t:1527632163534};\\\", \\\"{x:637,y:666,t:1527632163551};\\\", \\\"{x:616,y:676,t:1527632163567};\\\", \\\"{x:600,y:682,t:1527632163584};\\\", \\\"{x:594,y:687,t:1527632163600};\\\", \\\"{x:590,y:690,t:1527632163617};\\\", \\\"{x:585,y:693,t:1527632163634};\\\", \\\"{x:576,y:697,t:1527632163650};\\\", \\\"{x:568,y:701,t:1527632163667};\\\", \\\"{x:555,y:706,t:1527632163684};\\\", \\\"{x:544,y:711,t:1527632163701};\\\", \\\"{x:539,y:713,t:1527632163717};\\\", \\\"{x:533,y:717,t:1527632163734};\\\", \\\"{x:525,y:718,t:1527632163751};\\\", \\\"{x:519,y:720,t:1527632163769};\\\", \\\"{x:516,y:722,t:1527632163783};\\\", \\\"{x:513,y:724,t:1527632163801};\\\", \\\"{x:509,y:727,t:1527632163818};\\\", \\\"{x:508,y:728,t:1527632163834};\\\", \\\"{x:507,y:722,t:1527632164204};\\\", \\\"{x:507,y:713,t:1527632164218};\\\", \\\"{x:507,y:696,t:1527632164235};\\\", \\\"{x:501,y:668,t:1527632164250};\\\", \\\"{x:489,y:624,t:1527632164268};\\\", \\\"{x:482,y:598,t:1527632164284};\\\", \\\"{x:476,y:574,t:1527632164301};\\\", \\\"{x:472,y:549,t:1527632164317};\\\", \\\"{x:470,y:529,t:1527632164335};\\\", \\\"{x:470,y:511,t:1527632164351};\\\", \\\"{x:470,y:501,t:1527632164368};\\\", \\\"{x:470,y:498,t:1527632164384};\\\", \\\"{x:470,y:497,t:1527632164836};\\\", \\\"{x:474,y:496,t:1527632164852};\\\" ] }, { \\\"rt\\\": 9667, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 773807, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:494,t:1527632165779};\\\", \\\"{x:474,y:482,t:1527632165788};\\\", \\\"{x:474,y:467,t:1527632165802};\\\", \\\"{x:474,y:447,t:1527632165818};\\\", \\\"{x:474,y:413,t:1527632165836};\\\", \\\"{x:475,y:392,t:1527632165852};\\\", \\\"{x:477,y:378,t:1527632165869};\\\", \\\"{x:478,y:372,t:1527632165886};\\\", \\\"{x:479,y:370,t:1527632165903};\\\", \\\"{x:480,y:369,t:1527632168005};\\\", \\\"{x:495,y:369,t:1527632168022};\\\", \\\"{x:509,y:370,t:1527632168039};\\\", \\\"{x:525,y:372,t:1527632168055};\\\", \\\"{x:550,y:380,t:1527632168072};\\\", \\\"{x:619,y:399,t:1527632168089};\\\", \\\"{x:713,y:410,t:1527632168104};\\\", \\\"{x:834,y:420,t:1527632168122};\\\", \\\"{x:952,y:431,t:1527632168139};\\\", \\\"{x:1074,y:435,t:1527632168156};\\\", \\\"{x:1271,y:449,t:1527632168172};\\\", \\\"{x:1391,y:460,t:1527632168189};\\\", \\\"{x:1499,y:470,t:1527632168205};\\\", \\\"{x:1584,y:479,t:1527632168223};\\\", \\\"{x:1659,y:488,t:1527632168239};\\\", \\\"{x:1696,y:492,t:1527632168256};\\\", \\\"{x:1718,y:496,t:1527632168272};\\\", \\\"{x:1732,y:497,t:1527632168290};\\\", \\\"{x:1737,y:499,t:1527632168306};\\\", \\\"{x:1740,y:499,t:1527632168322};\\\", \\\"{x:1741,y:502,t:1527632169045};\\\", \\\"{x:1740,y:507,t:1527632169056};\\\", \\\"{x:1735,y:517,t:1527632169073};\\\", \\\"{x:1732,y:525,t:1527632169090};\\\", \\\"{x:1729,y:530,t:1527632169107};\\\", \\\"{x:1726,y:534,t:1527632169123};\\\", \\\"{x:1722,y:539,t:1527632169140};\\\", \\\"{x:1719,y:542,t:1527632169156};\\\", \\\"{x:1713,y:547,t:1527632169173};\\\", \\\"{x:1705,y:555,t:1527632169190};\\\", \\\"{x:1697,y:565,t:1527632169207};\\\", \\\"{x:1690,y:574,t:1527632169223};\\\", \\\"{x:1680,y:582,t:1527632169240};\\\", \\\"{x:1671,y:591,t:1527632169257};\\\", \\\"{x:1663,y:600,t:1527632169273};\\\", \\\"{x:1651,y:609,t:1527632169291};\\\", \\\"{x:1643,y:619,t:1527632169307};\\\", \\\"{x:1636,y:628,t:1527632169323};\\\", \\\"{x:1626,y:643,t:1527632169340};\\\", \\\"{x:1621,y:649,t:1527632169357};\\\", \\\"{x:1618,y:651,t:1527632169374};\\\", \\\"{x:1615,y:654,t:1527632169390};\\\", \\\"{x:1615,y:655,t:1527632169407};\\\", \\\"{x:1615,y:656,t:1527632169424};\\\", \\\"{x:1615,y:657,t:1527632169440};\\\", \\\"{x:1614,y:660,t:1527632169469};\\\", \\\"{x:1613,y:662,t:1527632169501};\\\", \\\"{x:1613,y:663,t:1527632169508};\\\", \\\"{x:1613,y:666,t:1527632169525};\\\", \\\"{x:1611,y:670,t:1527632169541};\\\", \\\"{x:1608,y:680,t:1527632169558};\\\", \\\"{x:1605,y:692,t:1527632169575};\\\", \\\"{x:1600,y:706,t:1527632169591};\\\", \\\"{x:1594,y:720,t:1527632169607};\\\", \\\"{x:1591,y:730,t:1527632169625};\\\", \\\"{x:1586,y:742,t:1527632169641};\\\", \\\"{x:1581,y:754,t:1527632169658};\\\", \\\"{x:1574,y:765,t:1527632169674};\\\", \\\"{x:1568,y:776,t:1527632169692};\\\", \\\"{x:1562,y:789,t:1527632169708};\\\", \\\"{x:1550,y:808,t:1527632169724};\\\", \\\"{x:1540,y:820,t:1527632169741};\\\", \\\"{x:1530,y:830,t:1527632169757};\\\", \\\"{x:1520,y:843,t:1527632169775};\\\", \\\"{x:1511,y:858,t:1527632169791};\\\", \\\"{x:1505,y:867,t:1527632169807};\\\", \\\"{x:1499,y:882,t:1527632169825};\\\", \\\"{x:1491,y:895,t:1527632169841};\\\", \\\"{x:1487,y:903,t:1527632169858};\\\", \\\"{x:1482,y:912,t:1527632169874};\\\", \\\"{x:1479,y:917,t:1527632169891};\\\", \\\"{x:1476,y:922,t:1527632169909};\\\", \\\"{x:1475,y:925,t:1527632169925};\\\", \\\"{x:1475,y:927,t:1527632169942};\\\", \\\"{x:1474,y:930,t:1527632169959};\\\", \\\"{x:1473,y:934,t:1527632169975};\\\", \\\"{x:1473,y:937,t:1527632169991};\\\", \\\"{x:1471,y:943,t:1527632170009};\\\", \\\"{x:1471,y:945,t:1527632170024};\\\", \\\"{x:1471,y:946,t:1527632170040};\\\", \\\"{x:1471,y:947,t:1527632170057};\\\", \\\"{x:1471,y:948,t:1527632170074};\\\", \\\"{x:1471,y:949,t:1527632170091};\\\", \\\"{x:1471,y:950,t:1527632170221};\\\", \\\"{x:1469,y:950,t:1527632170381};\\\", \\\"{x:1469,y:948,t:1527632170393};\\\", \\\"{x:1468,y:948,t:1527632170428};\\\", \\\"{x:1467,y:947,t:1527632170533};\\\", \\\"{x:1467,y:946,t:1527632170549};\\\", \\\"{x:1467,y:944,t:1527632170565};\\\", \\\"{x:1466,y:943,t:1527632170576};\\\", \\\"{x:1464,y:939,t:1527632170593};\\\", \\\"{x:1463,y:933,t:1527632170609};\\\", \\\"{x:1462,y:928,t:1527632170626};\\\", \\\"{x:1459,y:923,t:1527632170643};\\\", \\\"{x:1456,y:916,t:1527632170660};\\\", \\\"{x:1453,y:911,t:1527632170676};\\\", \\\"{x:1443,y:896,t:1527632170693};\\\", \\\"{x:1438,y:893,t:1527632170710};\\\", \\\"{x:1433,y:888,t:1527632170725};\\\", \\\"{x:1429,y:884,t:1527632170743};\\\", \\\"{x:1426,y:880,t:1527632170759};\\\", \\\"{x:1424,y:876,t:1527632170776};\\\", \\\"{x:1422,y:874,t:1527632170793};\\\", \\\"{x:1420,y:870,t:1527632170810};\\\", \\\"{x:1419,y:867,t:1527632170825};\\\", \\\"{x:1417,y:865,t:1527632170842};\\\", \\\"{x:1412,y:859,t:1527632170860};\\\", \\\"{x:1411,y:852,t:1527632170875};\\\", \\\"{x:1406,y:836,t:1527632170893};\\\", \\\"{x:1402,y:824,t:1527632170909};\\\", \\\"{x:1400,y:813,t:1527632170927};\\\", \\\"{x:1397,y:808,t:1527632170942};\\\", \\\"{x:1396,y:805,t:1527632170959};\\\", \\\"{x:1393,y:801,t:1527632170976};\\\", \\\"{x:1393,y:800,t:1527632170993};\\\", \\\"{x:1392,y:798,t:1527632171009};\\\", \\\"{x:1391,y:798,t:1527632171027};\\\", \\\"{x:1391,y:796,t:1527632171045};\\\", \\\"{x:1390,y:795,t:1527632171059};\\\", \\\"{x:1387,y:788,t:1527632171076};\\\", \\\"{x:1381,y:777,t:1527632171091};\\\", \\\"{x:1375,y:768,t:1527632171109};\\\", \\\"{x:1365,y:753,t:1527632171125};\\\", \\\"{x:1353,y:736,t:1527632171142};\\\", \\\"{x:1336,y:709,t:1527632171159};\\\", \\\"{x:1307,y:675,t:1527632171176};\\\", \\\"{x:1269,y:647,t:1527632171193};\\\", \\\"{x:1231,y:625,t:1527632171209};\\\", \\\"{x:1178,y:609,t:1527632171227};\\\", \\\"{x:1085,y:592,t:1527632171244};\\\", \\\"{x:999,y:581,t:1527632171259};\\\", \\\"{x:866,y:567,t:1527632171277};\\\", \\\"{x:787,y:555,t:1527632171294};\\\", \\\"{x:723,y:555,t:1527632171309};\\\", \\\"{x:665,y:552,t:1527632171339};\\\", \\\"{x:646,y:548,t:1527632171357};\\\", \\\"{x:629,y:544,t:1527632171373};\\\", \\\"{x:614,y:539,t:1527632171390};\\\", \\\"{x:599,y:534,t:1527632171407};\\\", \\\"{x:583,y:531,t:1527632171422};\\\", \\\"{x:572,y:531,t:1527632171440};\\\", \\\"{x:569,y:531,t:1527632171457};\\\", \\\"{x:568,y:531,t:1527632171472};\\\", \\\"{x:567,y:531,t:1527632171499};\\\", \\\"{x:567,y:529,t:1527632171516};\\\", \\\"{x:565,y:525,t:1527632171524};\\\", \\\"{x:563,y:520,t:1527632171540};\\\", \\\"{x:562,y:518,t:1527632171557};\\\", \\\"{x:562,y:517,t:1527632171574};\\\", \\\"{x:562,y:515,t:1527632171590};\\\", \\\"{x:563,y:512,t:1527632171607};\\\", \\\"{x:568,y:506,t:1527632171623};\\\", \\\"{x:570,y:504,t:1527632171639};\\\", \\\"{x:571,y:501,t:1527632171657};\\\", \\\"{x:574,y:499,t:1527632171674};\\\", \\\"{x:575,y:499,t:1527632171690};\\\", \\\"{x:576,y:498,t:1527632171707};\\\", \\\"{x:577,y:498,t:1527632171756};\\\", \\\"{x:579,y:498,t:1527632171774};\\\", \\\"{x:584,y:498,t:1527632171790};\\\", \\\"{x:586,y:498,t:1527632171807};\\\", \\\"{x:587,y:498,t:1527632171828};\\\", \\\"{x:590,y:499,t:1527632171925};\\\", \\\"{x:593,y:501,t:1527632171940};\\\", \\\"{x:594,y:501,t:1527632171957};\\\", \\\"{x:595,y:502,t:1527632172101};\\\", \\\"{x:597,y:502,t:1527632172269};\\\", \\\"{x:601,y:503,t:1527632172277};\\\", \\\"{x:606,y:504,t:1527632172291};\\\", \\\"{x:610,y:504,t:1527632172306};\\\", \\\"{x:617,y:504,t:1527632172324};\\\", \\\"{x:619,y:504,t:1527632172339};\\\", \\\"{x:628,y:504,t:1527632172357};\\\", \\\"{x:639,y:504,t:1527632172374};\\\", \\\"{x:659,y:504,t:1527632172390};\\\", \\\"{x:680,y:505,t:1527632172407};\\\", \\\"{x:692,y:505,t:1527632172424};\\\", \\\"{x:703,y:505,t:1527632172441};\\\", \\\"{x:713,y:505,t:1527632172457};\\\", \\\"{x:723,y:505,t:1527632172474};\\\", \\\"{x:731,y:505,t:1527632172492};\\\", \\\"{x:755,y:503,t:1527632172507};\\\", \\\"{x:767,y:503,t:1527632172524};\\\", \\\"{x:772,y:503,t:1527632172541};\\\", \\\"{x:773,y:503,t:1527632172588};\\\", \\\"{x:775,y:503,t:1527632172603};\\\", \\\"{x:777,y:503,t:1527632172612};\\\", \\\"{x:780,y:503,t:1527632172624};\\\", \\\"{x:783,y:504,t:1527632172641};\\\", \\\"{x:786,y:505,t:1527632172658};\\\", \\\"{x:792,y:506,t:1527632172674};\\\", \\\"{x:796,y:508,t:1527632172691};\\\", \\\"{x:799,y:509,t:1527632172708};\\\", \\\"{x:800,y:509,t:1527632172724};\\\", \\\"{x:803,y:509,t:1527632172741};\\\", \\\"{x:806,y:509,t:1527632172758};\\\", \\\"{x:809,y:509,t:1527632172780};\\\", \\\"{x:810,y:509,t:1527632172792};\\\", \\\"{x:813,y:509,t:1527632172808};\\\", \\\"{x:815,y:509,t:1527632172824};\\\", \\\"{x:818,y:509,t:1527632172841};\\\", \\\"{x:819,y:509,t:1527632172858};\\\", \\\"{x:824,y:507,t:1527632172874};\\\", \\\"{x:826,y:506,t:1527632172893};\\\", \\\"{x:828,y:505,t:1527632172908};\\\", \\\"{x:829,y:505,t:1527632172924};\\\", \\\"{x:830,y:505,t:1527632172980};\\\", \\\"{x:824,y:505,t:1527632173156};\\\", \\\"{x:790,y:508,t:1527632173175};\\\", \\\"{x:768,y:509,t:1527632173191};\\\", \\\"{x:743,y:510,t:1527632173208};\\\", \\\"{x:725,y:513,t:1527632173224};\\\", \\\"{x:712,y:515,t:1527632173241};\\\", \\\"{x:700,y:517,t:1527632173258};\\\", \\\"{x:683,y:517,t:1527632173274};\\\", \\\"{x:676,y:517,t:1527632173291};\\\", \\\"{x:667,y:517,t:1527632173308};\\\", \\\"{x:660,y:517,t:1527632173325};\\\", \\\"{x:655,y:517,t:1527632173340};\\\", \\\"{x:649,y:517,t:1527632173358};\\\", \\\"{x:644,y:517,t:1527632173375};\\\", \\\"{x:637,y:516,t:1527632173392};\\\", \\\"{x:632,y:514,t:1527632173409};\\\", \\\"{x:628,y:513,t:1527632173425};\\\", \\\"{x:622,y:513,t:1527632173442};\\\", \\\"{x:621,y:512,t:1527632173458};\\\", \\\"{x:620,y:512,t:1527632173476};\\\", \\\"{x:619,y:512,t:1527632173492};\\\", \\\"{x:618,y:511,t:1527632173508};\\\", \\\"{x:616,y:510,t:1527632173526};\\\", \\\"{x:612,y:509,t:1527632173542};\\\", \\\"{x:608,y:507,t:1527632173558};\\\", \\\"{x:606,y:506,t:1527632173575};\\\", \\\"{x:604,y:508,t:1527632173804};\\\", \\\"{x:603,y:517,t:1527632173812};\\\", \\\"{x:598,y:530,t:1527632173825};\\\", \\\"{x:581,y:575,t:1527632173842};\\\", \\\"{x:556,y:630,t:1527632173859};\\\", \\\"{x:533,y:678,t:1527632173875};\\\", \\\"{x:516,y:712,t:1527632173891};\\\", \\\"{x:511,y:722,t:1527632173909};\\\", \\\"{x:509,y:727,t:1527632173924};\\\", \\\"{x:507,y:731,t:1527632173942};\\\", \\\"{x:505,y:737,t:1527632173959};\\\", \\\"{x:503,y:740,t:1527632173974};\\\", \\\"{x:499,y:748,t:1527632173992};\\\", \\\"{x:498,y:755,t:1527632174009};\\\", \\\"{x:496,y:758,t:1527632174026};\\\", \\\"{x:494,y:763,t:1527632174042};\\\", \\\"{x:493,y:766,t:1527632174059};\\\", \\\"{x:492,y:768,t:1527632174076};\\\", \\\"{x:493,y:766,t:1527632174548};\\\", \\\"{x:494,y:764,t:1527632174559};\\\", \\\"{x:500,y:757,t:1527632174576};\\\", \\\"{x:503,y:754,t:1527632174593};\\\", \\\"{x:504,y:753,t:1527632174609};\\\", \\\"{x:504,y:752,t:1527632174627};\\\", \\\"{x:504,y:751,t:1527632174660};\\\", \\\"{x:506,y:747,t:1527632174676};\\\", \\\"{x:508,y:745,t:1527632174693};\\\", \\\"{x:508,y:744,t:1527632174709};\\\", \\\"{x:508,y:742,t:1527632174727};\\\", \\\"{x:508,y:741,t:1527632174781};\\\", \\\"{x:515,y:737,t:1527632175452};\\\", \\\"{x:522,y:732,t:1527632175460};\\\", \\\"{x:538,y:716,t:1527632175476};\\\", \\\"{x:552,y:701,t:1527632175493};\\\", \\\"{x:562,y:684,t:1527632175510};\\\", \\\"{x:569,y:671,t:1527632175527};\\\", \\\"{x:575,y:655,t:1527632175543};\\\", \\\"{x:592,y:632,t:1527632175560};\\\", \\\"{x:610,y:612,t:1527632175577};\\\", \\\"{x:618,y:599,t:1527632175593};\\\", \\\"{x:624,y:594,t:1527632175610};\\\", \\\"{x:626,y:593,t:1527632175628};\\\" ] }, { \\\"rt\\\": 9029, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 784057, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:623,y:583,t:1527632176604};\\\", \\\"{x:615,y:569,t:1527632176612};\\\", \\\"{x:608,y:553,t:1527632176627};\\\", \\\"{x:590,y:509,t:1527632176644};\\\", \\\"{x:584,y:484,t:1527632176661};\\\", \\\"{x:583,y:462,t:1527632176677};\\\", \\\"{x:583,y:447,t:1527632176693};\\\", \\\"{x:583,y:439,t:1527632176711};\\\", \\\"{x:583,y:437,t:1527632176727};\\\", \\\"{x:583,y:436,t:1527632176744};\\\", \\\"{x:585,y:435,t:1527632177029};\\\", \\\"{x:590,y:435,t:1527632177043};\\\", \\\"{x:591,y:435,t:1527632177460};\\\", \\\"{x:635,y:435,t:1527632177478};\\\", \\\"{x:716,y:438,t:1527632177494};\\\", \\\"{x:863,y:419,t:1527632177512};\\\", \\\"{x:962,y:419,t:1527632177528};\\\", \\\"{x:1113,y:411,t:1527632177545};\\\", \\\"{x:1271,y:408,t:1527632177562};\\\", \\\"{x:1407,y:406,t:1527632177577};\\\", \\\"{x:1507,y:406,t:1527632177595};\\\", \\\"{x:1562,y:406,t:1527632177612};\\\", \\\"{x:1584,y:406,t:1527632177628};\\\", \\\"{x:1587,y:406,t:1527632177645};\\\", \\\"{x:1582,y:404,t:1527632177869};\\\", \\\"{x:1572,y:398,t:1527632177878};\\\", \\\"{x:1542,y:387,t:1527632177894};\\\", \\\"{x:1519,y:385,t:1527632177912};\\\", \\\"{x:1505,y:376,t:1527632177928};\\\", \\\"{x:1467,y:373,t:1527632177944};\\\", \\\"{x:1464,y:371,t:1527632177962};\\\", \\\"{x:1462,y:373,t:1527632177981};\\\", \\\"{x:1462,y:374,t:1527632178037};\\\", \\\"{x:1462,y:378,t:1527632178141};\\\", \\\"{x:1462,y:381,t:1527632178148};\\\", \\\"{x:1462,y:386,t:1527632178162};\\\", \\\"{x:1462,y:403,t:1527632178178};\\\", \\\"{x:1471,y:425,t:1527632178195};\\\", \\\"{x:1491,y:468,t:1527632178212};\\\", \\\"{x:1500,y:485,t:1527632178228};\\\", \\\"{x:1533,y:533,t:1527632178245};\\\", \\\"{x:1558,y:576,t:1527632178262};\\\", \\\"{x:1594,y:644,t:1527632178278};\\\", \\\"{x:1642,y:706,t:1527632178295};\\\", \\\"{x:1654,y:721,t:1527632178311};\\\", \\\"{x:1682,y:758,t:1527632178328};\\\", \\\"{x:1715,y:779,t:1527632178345};\\\", \\\"{x:1743,y:796,t:1527632178362};\\\", \\\"{x:1767,y:813,t:1527632178378};\\\", \\\"{x:1783,y:820,t:1527632178395};\\\", \\\"{x:1793,y:829,t:1527632178411};\\\", \\\"{x:1797,y:835,t:1527632178427};\\\", \\\"{x:1803,y:840,t:1527632178445};\\\", \\\"{x:1804,y:841,t:1527632178532};\\\", \\\"{x:1804,y:842,t:1527632178544};\\\", \\\"{x:1799,y:853,t:1527632178562};\\\", \\\"{x:1787,y:867,t:1527632178578};\\\", \\\"{x:1777,y:879,t:1527632178595};\\\", \\\"{x:1758,y:891,t:1527632178612};\\\", \\\"{x:1742,y:900,t:1527632178627};\\\", \\\"{x:1717,y:914,t:1527632178644};\\\", \\\"{x:1706,y:920,t:1527632178662};\\\", \\\"{x:1692,y:924,t:1527632178678};\\\", \\\"{x:1677,y:930,t:1527632178695};\\\", \\\"{x:1668,y:934,t:1527632178712};\\\", \\\"{x:1660,y:939,t:1527632178728};\\\", \\\"{x:1649,y:942,t:1527632178744};\\\", \\\"{x:1646,y:944,t:1527632178762};\\\", \\\"{x:1642,y:945,t:1527632178777};\\\", \\\"{x:1638,y:946,t:1527632178795};\\\", \\\"{x:1637,y:947,t:1527632178812};\\\", \\\"{x:1634,y:949,t:1527632178828};\\\", \\\"{x:1626,y:955,t:1527632178845};\\\", \\\"{x:1620,y:959,t:1527632178862};\\\", \\\"{x:1613,y:963,t:1527632178878};\\\", \\\"{x:1602,y:966,t:1527632178895};\\\", \\\"{x:1595,y:968,t:1527632178912};\\\", \\\"{x:1587,y:972,t:1527632178928};\\\", \\\"{x:1584,y:972,t:1527632178945};\\\", \\\"{x:1581,y:973,t:1527632178961};\\\", \\\"{x:1578,y:974,t:1527632178978};\\\", \\\"{x:1577,y:974,t:1527632178995};\\\", \\\"{x:1575,y:975,t:1527632179012};\\\", \\\"{x:1573,y:976,t:1527632179028};\\\", \\\"{x:1570,y:976,t:1527632179044};\\\", \\\"{x:1567,y:977,t:1527632179062};\\\", \\\"{x:1566,y:977,t:1527632179077};\\\", \\\"{x:1564,y:977,t:1527632179094};\\\", \\\"{x:1563,y:977,t:1527632179112};\\\", \\\"{x:1562,y:977,t:1527632179128};\\\", \\\"{x:1560,y:977,t:1527632179144};\\\", \\\"{x:1559,y:977,t:1527632179162};\\\", \\\"{x:1557,y:977,t:1527632179178};\\\", \\\"{x:1556,y:977,t:1527632179213};\\\", \\\"{x:1555,y:976,t:1527632179228};\\\", \\\"{x:1554,y:975,t:1527632179252};\\\", \\\"{x:1554,y:974,t:1527632179269};\\\", \\\"{x:1553,y:973,t:1527632179357};\\\", \\\"{x:1552,y:971,t:1527632179365};\\\", \\\"{x:1552,y:970,t:1527632179389};\\\", \\\"{x:1551,y:968,t:1527632179405};\\\", \\\"{x:1550,y:964,t:1527632179429};\\\", \\\"{x:1547,y:959,t:1527632179445};\\\", \\\"{x:1545,y:954,t:1527632179462};\\\", \\\"{x:1540,y:949,t:1527632179477};\\\", \\\"{x:1536,y:945,t:1527632179494};\\\", \\\"{x:1531,y:941,t:1527632179511};\\\", \\\"{x:1530,y:939,t:1527632179527};\\\", \\\"{x:1528,y:938,t:1527632179544};\\\", \\\"{x:1528,y:936,t:1527632179562};\\\", \\\"{x:1527,y:932,t:1527632179577};\\\", \\\"{x:1525,y:926,t:1527632179594};\\\", \\\"{x:1522,y:921,t:1527632179611};\\\", \\\"{x:1520,y:916,t:1527632179627};\\\", \\\"{x:1516,y:909,t:1527632179644};\\\", \\\"{x:1512,y:904,t:1527632179661};\\\", \\\"{x:1507,y:897,t:1527632179678};\\\", \\\"{x:1503,y:891,t:1527632179695};\\\", \\\"{x:1498,y:883,t:1527632179711};\\\", \\\"{x:1496,y:880,t:1527632179728};\\\", \\\"{x:1495,y:877,t:1527632179744};\\\", \\\"{x:1493,y:874,t:1527632179762};\\\", \\\"{x:1493,y:873,t:1527632179781};\\\", \\\"{x:1492,y:872,t:1527632179794};\\\", \\\"{x:1492,y:871,t:1527632179812};\\\", \\\"{x:1492,y:870,t:1527632179828};\\\", \\\"{x:1492,y:869,t:1527632179957};\\\", \\\"{x:1492,y:867,t:1527632179981};\\\", \\\"{x:1492,y:866,t:1527632179995};\\\", \\\"{x:1491,y:861,t:1527632180012};\\\", \\\"{x:1489,y:857,t:1527632180027};\\\", \\\"{x:1488,y:851,t:1527632180045};\\\", \\\"{x:1485,y:845,t:1527632180061};\\\", \\\"{x:1485,y:841,t:1527632180077};\\\", \\\"{x:1484,y:837,t:1527632180094};\\\", \\\"{x:1484,y:836,t:1527632180111};\\\", \\\"{x:1484,y:835,t:1527632180127};\\\", \\\"{x:1484,y:834,t:1527632180738};\\\", \\\"{x:1481,y:834,t:1527632180748};\\\", \\\"{x:1462,y:834,t:1527632180765};\\\", \\\"{x:1445,y:837,t:1527632180780};\\\", \\\"{x:1435,y:840,t:1527632180797};\\\", \\\"{x:1435,y:839,t:1527632180815};\\\", \\\"{x:1433,y:839,t:1527632181768};\\\", \\\"{x:1430,y:839,t:1527632181781};\\\", \\\"{x:1422,y:838,t:1527632181799};\\\", \\\"{x:1412,y:836,t:1527632181816};\\\", \\\"{x:1405,y:836,t:1527632181831};\\\", \\\"{x:1397,y:836,t:1527632181848};\\\", \\\"{x:1396,y:836,t:1527632181865};\\\", \\\"{x:1394,y:836,t:1527632181882};\\\", \\\"{x:1393,y:836,t:1527632181898};\\\", \\\"{x:1391,y:836,t:1527632181920};\\\", \\\"{x:1390,y:836,t:1527632181984};\\\", \\\"{x:1388,y:836,t:1527632181999};\\\", \\\"{x:1385,y:837,t:1527632182016};\\\", \\\"{x:1381,y:839,t:1527632182032};\\\", \\\"{x:1379,y:839,t:1527632182048};\\\", \\\"{x:1376,y:839,t:1527632182065};\\\", \\\"{x:1371,y:839,t:1527632182081};\\\", \\\"{x:1368,y:839,t:1527632182099};\\\", \\\"{x:1364,y:839,t:1527632182115};\\\", \\\"{x:1361,y:839,t:1527632182131};\\\", \\\"{x:1360,y:839,t:1527632182168};\\\", \\\"{x:1360,y:838,t:1527632182182};\\\", \\\"{x:1359,y:838,t:1527632182224};\\\", \\\"{x:1357,y:837,t:1527632182272};\\\", \\\"{x:1356,y:836,t:1527632182288};\\\", \\\"{x:1356,y:835,t:1527632182360};\\\", \\\"{x:1355,y:835,t:1527632182368};\\\", \\\"{x:1355,y:834,t:1527632182392};\\\", \\\"{x:1355,y:833,t:1527632182456};\\\", \\\"{x:1355,y:832,t:1527632182488};\\\", \\\"{x:1355,y:831,t:1527632182519};\\\", \\\"{x:1355,y:830,t:1527632182536};\\\", \\\"{x:1355,y:829,t:1527632182549};\\\", \\\"{x:1355,y:828,t:1527632182565};\\\", \\\"{x:1355,y:827,t:1527632182581};\\\", \\\"{x:1355,y:826,t:1527632182599};\\\", \\\"{x:1355,y:825,t:1527632182615};\\\", \\\"{x:1355,y:824,t:1527632182632};\\\", \\\"{x:1354,y:824,t:1527632182647};\\\", \\\"{x:1353,y:824,t:1527632182665};\\\", \\\"{x:1349,y:822,t:1527632182681};\\\", \\\"{x:1341,y:817,t:1527632182698};\\\", \\\"{x:1329,y:812,t:1527632182716};\\\", \\\"{x:1314,y:804,t:1527632182731};\\\", \\\"{x:1288,y:794,t:1527632182748};\\\", \\\"{x:1252,y:777,t:1527632182765};\\\", \\\"{x:1224,y:757,t:1527632182782};\\\", \\\"{x:1194,y:731,t:1527632182799};\\\", \\\"{x:1188,y:724,t:1527632182815};\\\", \\\"{x:1188,y:723,t:1527632182832};\\\", \\\"{x:1186,y:723,t:1527632182848};\\\", \\\"{x:1180,y:722,t:1527632182865};\\\", \\\"{x:1159,y:724,t:1527632182881};\\\", \\\"{x:1147,y:725,t:1527632182898};\\\", \\\"{x:1135,y:725,t:1527632182916};\\\", \\\"{x:1133,y:725,t:1527632183008};\\\", \\\"{x:1130,y:725,t:1527632183015};\\\", \\\"{x:1116,y:719,t:1527632183031};\\\", \\\"{x:1093,y:712,t:1527632183047};\\\", \\\"{x:1052,y:698,t:1527632183065};\\\", \\\"{x:966,y:671,t:1527632183082};\\\", \\\"{x:834,y:642,t:1527632183098};\\\", \\\"{x:690,y:618,t:1527632183116};\\\", \\\"{x:548,y:594,t:1527632183132};\\\", \\\"{x:396,y:552,t:1527632183164};\\\", \\\"{x:387,y:544,t:1527632183186};\\\", \\\"{x:381,y:540,t:1527632183203};\\\", \\\"{x:377,y:540,t:1527632183219};\\\", \\\"{x:376,y:540,t:1527632183359};\\\", \\\"{x:375,y:544,t:1527632183370};\\\", \\\"{x:375,y:545,t:1527632183386};\\\", \\\"{x:375,y:547,t:1527632183712};\\\", \\\"{x:378,y:549,t:1527632183727};\\\", \\\"{x:389,y:549,t:1527632183737};\\\", \\\"{x:390,y:549,t:1527632183753};\\\", \\\"{x:405,y:552,t:1527632183770};\\\", \\\"{x:412,y:554,t:1527632183786};\\\", \\\"{x:414,y:554,t:1527632183803};\\\", \\\"{x:415,y:554,t:1527632183819};\\\", \\\"{x:416,y:554,t:1527632183846};\\\", \\\"{x:417,y:554,t:1527632183855};\\\", \\\"{x:422,y:554,t:1527632183870};\\\", \\\"{x:431,y:559,t:1527632183887};\\\", \\\"{x:441,y:564,t:1527632183904};\\\", \\\"{x:458,y:574,t:1527632183919};\\\", \\\"{x:476,y:579,t:1527632183936};\\\", \\\"{x:490,y:582,t:1527632183953};\\\", \\\"{x:504,y:584,t:1527632183971};\\\", \\\"{x:522,y:587,t:1527632183986};\\\", \\\"{x:540,y:590,t:1527632184004};\\\", \\\"{x:557,y:592,t:1527632184020};\\\", \\\"{x:572,y:595,t:1527632184037};\\\", \\\"{x:590,y:596,t:1527632184054};\\\", \\\"{x:604,y:598,t:1527632184070};\\\", \\\"{x:612,y:598,t:1527632184087};\\\", \\\"{x:613,y:598,t:1527632184111};\\\", \\\"{x:614,y:598,t:1527632184192};\\\", \\\"{x:615,y:598,t:1527632184207};\\\", \\\"{x:616,y:597,t:1527632184220};\\\", \\\"{x:618,y:595,t:1527632184237};\\\", \\\"{x:618,y:592,t:1527632184255};\\\", \\\"{x:618,y:591,t:1527632184270};\\\", \\\"{x:618,y:590,t:1527632184286};\\\", \\\"{x:618,y:589,t:1527632184303};\\\", \\\"{x:617,y:587,t:1527632184321};\\\", \\\"{x:616,y:586,t:1527632184337};\\\", \\\"{x:615,y:586,t:1527632184354};\\\", \\\"{x:613,y:586,t:1527632184369};\\\", \\\"{x:613,y:585,t:1527632184387};\\\", \\\"{x:612,y:585,t:1527632184407};\\\", \\\"{x:610,y:585,t:1527632184672};\\\", \\\"{x:576,y:643,t:1527632184723};\\\", \\\"{x:559,y:665,t:1527632184738};\\\", \\\"{x:546,y:688,t:1527632184754};\\\", \\\"{x:531,y:708,t:1527632184770};\\\", \\\"{x:519,y:723,t:1527632184787};\\\", \\\"{x:514,y:730,t:1527632184803};\\\", \\\"{x:511,y:734,t:1527632184820};\\\", \\\"{x:509,y:735,t:1527632184837};\\\", \\\"{x:508,y:735,t:1527632184853};\\\", \\\"{x:507,y:736,t:1527632184871};\\\", \\\"{x:506,y:736,t:1527632184935};\\\", \\\"{x:505,y:736,t:1527632184943};\\\" ] }, { \\\"rt\\\": 26705, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 812008, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -02 PM-X -02 PM-X -X -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:445,y:649,t:1527632186873};\\\", \\\"{x:431,y:631,t:1527632186889};\\\", \\\"{x:427,y:628,t:1527632186906};\\\", \\\"{x:426,y:627,t:1527632186922};\\\", \\\"{x:411,y:595,t:1527632186939};\\\", \\\"{x:411,y:575,t:1527632186956};\\\", \\\"{x:409,y:556,t:1527632186973};\\\", \\\"{x:409,y:550,t:1527632186988};\\\", \\\"{x:409,y:549,t:1527632187006};\\\", \\\"{x:406,y:544,t:1527632187119};\\\", \\\"{x:403,y:539,t:1527632187127};\\\", \\\"{x:401,y:532,t:1527632187139};\\\", \\\"{x:389,y:515,t:1527632187156};\\\", \\\"{x:374,y:488,t:1527632187172};\\\", \\\"{x:345,y:455,t:1527632187189};\\\", \\\"{x:316,y:425,t:1527632187206};\\\", \\\"{x:298,y:409,t:1527632187221};\\\", \\\"{x:283,y:396,t:1527632187238};\\\", \\\"{x:273,y:390,t:1527632187256};\\\", \\\"{x:269,y:387,t:1527632187272};\\\", \\\"{x:269,y:388,t:1527632187727};\\\", \\\"{x:269,y:391,t:1527632187738};\\\", \\\"{x:269,y:399,t:1527632187756};\\\", \\\"{x:274,y:405,t:1527632187771};\\\", \\\"{x:286,y:417,t:1527632187788};\\\", \\\"{x:306,y:427,t:1527632187806};\\\", \\\"{x:328,y:433,t:1527632187821};\\\", \\\"{x:350,y:436,t:1527632187839};\\\", \\\"{x:367,y:436,t:1527632187855};\\\", \\\"{x:379,y:437,t:1527632187872};\\\", \\\"{x:385,y:438,t:1527632187888};\\\", \\\"{x:391,y:438,t:1527632187905};\\\", \\\"{x:399,y:438,t:1527632187922};\\\", \\\"{x:404,y:438,t:1527632187939};\\\", \\\"{x:410,y:438,t:1527632187955};\\\", \\\"{x:415,y:438,t:1527632187971};\\\", \\\"{x:422,y:438,t:1527632187988};\\\", \\\"{x:431,y:438,t:1527632188004};\\\", \\\"{x:445,y:438,t:1527632188021};\\\", \\\"{x:461,y:438,t:1527632188039};\\\", \\\"{x:475,y:438,t:1527632188054};\\\", \\\"{x:495,y:438,t:1527632188071};\\\", \\\"{x:511,y:441,t:1527632188088};\\\", \\\"{x:523,y:441,t:1527632188104};\\\", \\\"{x:530,y:441,t:1527632188121};\\\", \\\"{x:537,y:441,t:1527632188137};\\\", \\\"{x:544,y:441,t:1527632188154};\\\", \\\"{x:548,y:441,t:1527632188171};\\\", \\\"{x:549,y:441,t:1527632188187};\\\", \\\"{x:551,y:441,t:1527632188205};\\\", \\\"{x:555,y:441,t:1527632188221};\\\", \\\"{x:559,y:441,t:1527632188237};\\\", \\\"{x:564,y:441,t:1527632188254};\\\", \\\"{x:569,y:441,t:1527632188271};\\\", \\\"{x:570,y:441,t:1527632188287};\\\", \\\"{x:569,y:441,t:1527632189328};\\\", \\\"{x:562,y:443,t:1527632189335};\\\", \\\"{x:535,y:448,t:1527632189352};\\\", \\\"{x:506,y:452,t:1527632189369};\\\", \\\"{x:478,y:454,t:1527632189386};\\\", \\\"{x:448,y:457,t:1527632189402};\\\", \\\"{x:420,y:459,t:1527632189418};\\\", \\\"{x:395,y:461,t:1527632189435};\\\", \\\"{x:380,y:461,t:1527632189451};\\\", \\\"{x:372,y:461,t:1527632189468};\\\", \\\"{x:370,y:461,t:1527632189485};\\\", \\\"{x:368,y:461,t:1527632189528};\\\", \\\"{x:368,y:463,t:1527632191408};\\\", \\\"{x:368,y:465,t:1527632191423};\\\", \\\"{x:368,y:466,t:1527632191439};\\\", \\\"{x:369,y:467,t:1527632191463};\\\", \\\"{x:369,y:468,t:1527632191478};\\\", \\\"{x:369,y:469,t:1527632191487};\\\", \\\"{x:370,y:469,t:1527632191518};\\\", \\\"{x:371,y:469,t:1527632191535};\\\", \\\"{x:372,y:470,t:1527632191551};\\\", \\\"{x:373,y:470,t:1527632191565};\\\", \\\"{x:374,y:470,t:1527632191607};\\\", \\\"{x:375,y:470,t:1527632191615};\\\", \\\"{x:376,y:470,t:1527632191631};\\\", \\\"{x:379,y:470,t:1527632191648};\\\", \\\"{x:383,y:470,t:1527632191664};\\\", \\\"{x:388,y:469,t:1527632191681};\\\", \\\"{x:399,y:468,t:1527632191698};\\\", \\\"{x:407,y:467,t:1527632191714};\\\", \\\"{x:418,y:466,t:1527632191731};\\\", \\\"{x:435,y:466,t:1527632191748};\\\", \\\"{x:455,y:466,t:1527632191765};\\\", \\\"{x:476,y:466,t:1527632191781};\\\", \\\"{x:503,y:466,t:1527632191797};\\\", \\\"{x:536,y:466,t:1527632191815};\\\", \\\"{x:609,y:466,t:1527632191831};\\\", \\\"{x:668,y:463,t:1527632191847};\\\", \\\"{x:727,y:463,t:1527632191864};\\\", \\\"{x:792,y:461,t:1527632191881};\\\", \\\"{x:845,y:453,t:1527632191898};\\\", \\\"{x:907,y:450,t:1527632191915};\\\", \\\"{x:958,y:450,t:1527632191932};\\\", \\\"{x:1000,y:450,t:1527632191948};\\\", \\\"{x:1047,y:450,t:1527632191964};\\\", \\\"{x:1089,y:450,t:1527632191980};\\\", \\\"{x:1140,y:450,t:1527632191998};\\\", \\\"{x:1190,y:457,t:1527632192014};\\\", \\\"{x:1212,y:467,t:1527632192030};\\\", \\\"{x:1228,y:484,t:1527632192047};\\\", \\\"{x:1230,y:484,t:1527632192064};\\\", \\\"{x:1232,y:484,t:1527632192111};\\\", \\\"{x:1232,y:487,t:1527632192119};\\\", \\\"{x:1236,y:488,t:1527632192131};\\\", \\\"{x:1241,y:491,t:1527632192148};\\\", \\\"{x:1247,y:492,t:1527632192164};\\\", \\\"{x:1255,y:492,t:1527632192181};\\\", \\\"{x:1257,y:492,t:1527632192198};\\\", \\\"{x:1260,y:492,t:1527632192376};\\\", \\\"{x:1264,y:499,t:1527632192384};\\\", \\\"{x:1271,y:512,t:1527632192397};\\\", \\\"{x:1295,y:553,t:1527632192413};\\\", \\\"{x:1321,y:608,t:1527632192430};\\\", \\\"{x:1329,y:652,t:1527632192446};\\\", \\\"{x:1337,y:702,t:1527632192463};\\\", \\\"{x:1342,y:739,t:1527632192479};\\\", \\\"{x:1345,y:774,t:1527632192497};\\\", \\\"{x:1348,y:810,t:1527632192514};\\\", \\\"{x:1351,y:831,t:1527632192530};\\\", \\\"{x:1351,y:842,t:1527632192547};\\\", \\\"{x:1352,y:850,t:1527632192563};\\\", \\\"{x:1352,y:854,t:1527632192579};\\\", \\\"{x:1352,y:855,t:1527632192607};\\\", \\\"{x:1354,y:855,t:1527632192992};\\\", \\\"{x:1354,y:854,t:1527632192999};\\\", \\\"{x:1356,y:854,t:1527632193013};\\\", \\\"{x:1357,y:856,t:1527632193031};\\\", \\\"{x:1360,y:860,t:1527632193046};\\\", \\\"{x:1364,y:867,t:1527632193063};\\\", \\\"{x:1370,y:877,t:1527632193079};\\\", \\\"{x:1376,y:887,t:1527632193095};\\\", \\\"{x:1380,y:894,t:1527632193116};\\\", \\\"{x:1387,y:904,t:1527632193128};\\\", \\\"{x:1395,y:913,t:1527632193145};\\\", \\\"{x:1404,y:923,t:1527632193162};\\\", \\\"{x:1412,y:929,t:1527632193177};\\\", \\\"{x:1422,y:938,t:1527632193195};\\\", \\\"{x:1432,y:943,t:1527632193212};\\\", \\\"{x:1442,y:948,t:1527632193228};\\\", \\\"{x:1449,y:951,t:1527632193245};\\\", \\\"{x:1454,y:953,t:1527632193261};\\\", \\\"{x:1459,y:956,t:1527632193279};\\\", \\\"{x:1467,y:960,t:1527632193295};\\\", \\\"{x:1473,y:963,t:1527632193311};\\\", \\\"{x:1478,y:965,t:1527632193328};\\\", \\\"{x:1480,y:966,t:1527632193346};\\\", \\\"{x:1481,y:967,t:1527632193368};\\\", \\\"{x:1483,y:968,t:1527632193379};\\\", \\\"{x:1487,y:970,t:1527632193396};\\\", \\\"{x:1488,y:970,t:1527632193416};\\\", \\\"{x:1487,y:970,t:1527632193551};\\\", \\\"{x:1485,y:970,t:1527632193561};\\\", \\\"{x:1485,y:969,t:1527632193688};\\\", \\\"{x:1485,y:968,t:1527632193737};\\\", \\\"{x:1485,y:967,t:1527632193751};\\\", \\\"{x:1485,y:965,t:1527632193784};\\\", \\\"{x:1485,y:964,t:1527632193794};\\\", \\\"{x:1485,y:960,t:1527632193810};\\\", \\\"{x:1485,y:954,t:1527632193827};\\\", \\\"{x:1485,y:948,t:1527632193844};\\\", \\\"{x:1485,y:941,t:1527632193860};\\\", \\\"{x:1485,y:934,t:1527632193877};\\\", \\\"{x:1485,y:927,t:1527632193894};\\\", \\\"{x:1486,y:921,t:1527632193911};\\\", \\\"{x:1488,y:912,t:1527632193926};\\\", \\\"{x:1489,y:907,t:1527632193944};\\\", \\\"{x:1489,y:902,t:1527632193960};\\\", \\\"{x:1490,y:896,t:1527632193978};\\\", \\\"{x:1492,y:890,t:1527632193993};\\\", \\\"{x:1494,y:882,t:1527632194010};\\\", \\\"{x:1494,y:878,t:1527632194028};\\\", \\\"{x:1496,y:873,t:1527632194043};\\\", \\\"{x:1496,y:871,t:1527632194060};\\\", \\\"{x:1496,y:869,t:1527632194077};\\\", \\\"{x:1497,y:867,t:1527632194093};\\\", \\\"{x:1497,y:865,t:1527632194119};\\\", \\\"{x:1497,y:864,t:1527632194127};\\\", \\\"{x:1497,y:863,t:1527632194152};\\\", \\\"{x:1497,y:862,t:1527632194160};\\\", \\\"{x:1496,y:860,t:1527632194177};\\\", \\\"{x:1496,y:857,t:1527632194194};\\\", \\\"{x:1496,y:853,t:1527632194210};\\\", \\\"{x:1495,y:849,t:1527632194226};\\\", \\\"{x:1495,y:848,t:1527632194243};\\\", \\\"{x:1493,y:844,t:1527632194423};\\\", \\\"{x:1488,y:836,t:1527632194432};\\\", \\\"{x:1487,y:832,t:1527632194444};\\\", \\\"{x:1477,y:818,t:1527632194459};\\\", \\\"{x:1472,y:809,t:1527632194476};\\\", \\\"{x:1472,y:801,t:1527632194493};\\\", \\\"{x:1471,y:796,t:1527632194509};\\\", \\\"{x:1471,y:791,t:1527632194526};\\\", \\\"{x:1471,y:789,t:1527632194542};\\\", \\\"{x:1471,y:794,t:1527632194872};\\\", \\\"{x:1471,y:801,t:1527632194880};\\\", \\\"{x:1471,y:803,t:1527632194893};\\\", \\\"{x:1472,y:809,t:1527632194909};\\\", \\\"{x:1472,y:813,t:1527632194925};\\\", \\\"{x:1472,y:818,t:1527632194942};\\\", \\\"{x:1472,y:820,t:1527632194958};\\\", \\\"{x:1473,y:821,t:1527632194975};\\\", \\\"{x:1473,y:817,t:1527632195288};\\\", \\\"{x:1475,y:810,t:1527632195295};\\\", \\\"{x:1475,y:803,t:1527632195309};\\\", \\\"{x:1478,y:791,t:1527632195324};\\\", \\\"{x:1478,y:788,t:1527632195341};\\\", \\\"{x:1479,y:786,t:1527632195359};\\\", \\\"{x:1481,y:789,t:1527632195520};\\\", \\\"{x:1482,y:797,t:1527632195527};\\\", \\\"{x:1484,y:805,t:1527632195542};\\\", \\\"{x:1490,y:822,t:1527632195558};\\\", \\\"{x:1493,y:836,t:1527632195574};\\\", \\\"{x:1497,y:851,t:1527632195591};\\\", \\\"{x:1498,y:860,t:1527632195608};\\\", \\\"{x:1499,y:868,t:1527632195625};\\\", \\\"{x:1501,y:880,t:1527632195641};\\\", \\\"{x:1504,y:889,t:1527632195658};\\\", \\\"{x:1504,y:898,t:1527632195675};\\\", \\\"{x:1506,y:909,t:1527632195691};\\\", \\\"{x:1507,y:916,t:1527632195708};\\\", \\\"{x:1507,y:922,t:1527632195725};\\\", \\\"{x:1507,y:927,t:1527632195741};\\\", \\\"{x:1507,y:932,t:1527632195758};\\\", \\\"{x:1507,y:938,t:1527632195775};\\\", \\\"{x:1507,y:942,t:1527632195791};\\\", \\\"{x:1506,y:946,t:1527632195807};\\\", \\\"{x:1505,y:949,t:1527632195825};\\\", \\\"{x:1503,y:956,t:1527632195841};\\\", \\\"{x:1502,y:960,t:1527632195858};\\\", \\\"{x:1501,y:963,t:1527632195874};\\\", \\\"{x:1501,y:965,t:1527632195891};\\\", \\\"{x:1500,y:966,t:1527632195907};\\\", \\\"{x:1500,y:967,t:1527632195923};\\\", \\\"{x:1500,y:968,t:1527632195941};\\\", \\\"{x:1499,y:968,t:1527632195958};\\\", \\\"{x:1499,y:969,t:1527632195974};\\\", \\\"{x:1499,y:970,t:1527632196128};\\\", \\\"{x:1497,y:970,t:1527632196144};\\\", \\\"{x:1494,y:970,t:1527632196167};\\\", \\\"{x:1492,y:970,t:1527632196183};\\\", \\\"{x:1492,y:969,t:1527632196222};\\\", \\\"{x:1491,y:969,t:1527632196246};\\\", \\\"{x:1489,y:969,t:1527632196408};\\\", \\\"{x:1486,y:968,t:1527632196423};\\\", \\\"{x:1478,y:964,t:1527632196439};\\\", \\\"{x:1473,y:963,t:1527632196457};\\\", \\\"{x:1471,y:963,t:1527632196487};\\\", \\\"{x:1470,y:962,t:1527632196495};\\\", \\\"{x:1471,y:960,t:1527632196824};\\\", \\\"{x:1472,y:957,t:1527632196847};\\\", \\\"{x:1472,y:956,t:1527632196871};\\\", \\\"{x:1473,y:954,t:1527632196889};\\\", \\\"{x:1473,y:947,t:1527632197096};\\\", \\\"{x:1473,y:938,t:1527632197105};\\\", \\\"{x:1473,y:917,t:1527632197121};\\\", \\\"{x:1473,y:889,t:1527632197139};\\\", \\\"{x:1473,y:865,t:1527632197155};\\\", \\\"{x:1473,y:845,t:1527632197172};\\\", \\\"{x:1473,y:839,t:1527632197189};\\\", \\\"{x:1473,y:838,t:1527632197204};\\\", \\\"{x:1473,y:835,t:1527632197495};\\\", \\\"{x:1473,y:834,t:1527632197505};\\\", \\\"{x:1473,y:832,t:1527632197521};\\\", \\\"{x:1474,y:831,t:1527632197538};\\\", \\\"{x:1474,y:832,t:1527632198000};\\\", \\\"{x:1474,y:833,t:1527632198007};\\\", \\\"{x:1474,y:834,t:1527632198040};\\\", \\\"{x:1474,y:835,t:1527632198112};\\\", \\\"{x:1475,y:836,t:1527632199312};\\\", \\\"{x:1478,y:836,t:1527632199320};\\\", \\\"{x:1480,y:836,t:1527632199335};\\\", \\\"{x:1483,y:837,t:1527632199351};\\\", \\\"{x:1492,y:840,t:1527632199368};\\\", \\\"{x:1495,y:841,t:1527632199385};\\\", \\\"{x:1490,y:839,t:1527632199616};\\\", \\\"{x:1485,y:837,t:1527632199624};\\\", \\\"{x:1482,y:837,t:1527632199640};\\\", \\\"{x:1481,y:836,t:1527632199651};\\\", \\\"{x:1481,y:835,t:1527632199672};\\\", \\\"{x:1477,y:831,t:1527632201151};\\\", \\\"{x:1448,y:822,t:1527632201166};\\\", \\\"{x:1362,y:778,t:1527632201181};\\\", \\\"{x:1214,y:721,t:1527632201198};\\\", \\\"{x:1057,y:668,t:1527632201215};\\\", \\\"{x:998,y:646,t:1527632201231};\\\", \\\"{x:982,y:641,t:1527632201247};\\\", \\\"{x:957,y:632,t:1527632201264};\\\", \\\"{x:940,y:622,t:1527632201283};\\\", \\\"{x:921,y:615,t:1527632201297};\\\", \\\"{x:907,y:607,t:1527632201315};\\\", \\\"{x:886,y:601,t:1527632201334};\\\", \\\"{x:843,y:595,t:1527632201351};\\\", \\\"{x:816,y:594,t:1527632201367};\\\", \\\"{x:788,y:594,t:1527632201383};\\\", \\\"{x:745,y:594,t:1527632201400};\\\", \\\"{x:699,y:596,t:1527632201418};\\\", \\\"{x:649,y:596,t:1527632201433};\\\", \\\"{x:617,y:596,t:1527632201450};\\\", \\\"{x:587,y:595,t:1527632201468};\\\", \\\"{x:567,y:595,t:1527632201483};\\\", \\\"{x:558,y:595,t:1527632201501};\\\", \\\"{x:551,y:595,t:1527632201517};\\\", \\\"{x:541,y:595,t:1527632201533};\\\", \\\"{x:529,y:595,t:1527632201551};\\\", \\\"{x:521,y:595,t:1527632201567};\\\", \\\"{x:513,y:595,t:1527632201583};\\\", \\\"{x:507,y:595,t:1527632201600};\\\", \\\"{x:497,y:592,t:1527632201618};\\\", \\\"{x:488,y:587,t:1527632201633};\\\", \\\"{x:474,y:584,t:1527632201650};\\\", \\\"{x:459,y:580,t:1527632201668};\\\", \\\"{x:453,y:580,t:1527632201685};\\\", \\\"{x:444,y:580,t:1527632201701};\\\", \\\"{x:443,y:580,t:1527632201717};\\\", \\\"{x:436,y:580,t:1527632201735};\\\", \\\"{x:432,y:580,t:1527632201751};\\\", \\\"{x:429,y:579,t:1527632201767};\\\", \\\"{x:427,y:579,t:1527632201785};\\\", \\\"{x:424,y:579,t:1527632201800};\\\", \\\"{x:414,y:579,t:1527632201817};\\\", \\\"{x:400,y:581,t:1527632201835};\\\", \\\"{x:382,y:584,t:1527632201850};\\\", \\\"{x:366,y:584,t:1527632201867};\\\", \\\"{x:339,y:587,t:1527632201884};\\\", \\\"{x:316,y:587,t:1527632201901};\\\", \\\"{x:274,y:587,t:1527632201917};\\\", \\\"{x:230,y:587,t:1527632201935};\\\", \\\"{x:214,y:589,t:1527632201950};\\\", \\\"{x:207,y:589,t:1527632201967};\\\", \\\"{x:206,y:589,t:1527632201985};\\\", \\\"{x:204,y:589,t:1527632202006};\\\", \\\"{x:203,y:590,t:1527632202018};\\\", \\\"{x:202,y:592,t:1527632202035};\\\", \\\"{x:202,y:594,t:1527632202051};\\\", \\\"{x:202,y:596,t:1527632202067};\\\", \\\"{x:202,y:599,t:1527632202085};\\\", \\\"{x:209,y:603,t:1527632202101};\\\", \\\"{x:223,y:611,t:1527632202118};\\\", \\\"{x:286,y:634,t:1527632202134};\\\", \\\"{x:395,y:652,t:1527632202152};\\\", \\\"{x:512,y:656,t:1527632202167};\\\", \\\"{x:612,y:656,t:1527632202186};\\\", \\\"{x:692,y:639,t:1527632202202};\\\", \\\"{x:722,y:624,t:1527632202217};\\\", \\\"{x:775,y:612,t:1527632202234};\\\", \\\"{x:806,y:602,t:1527632202251};\\\", \\\"{x:826,y:595,t:1527632202267};\\\", \\\"{x:842,y:590,t:1527632202284};\\\", \\\"{x:856,y:586,t:1527632202301};\\\", \\\"{x:869,y:584,t:1527632202317};\\\", \\\"{x:881,y:581,t:1527632202335};\\\", \\\"{x:884,y:581,t:1527632202351};\\\", \\\"{x:882,y:581,t:1527632202520};\\\", \\\"{x:877,y:581,t:1527632202535};\\\", \\\"{x:863,y:587,t:1527632202553};\\\", \\\"{x:841,y:594,t:1527632202569};\\\", \\\"{x:817,y:599,t:1527632202586};\\\", \\\"{x:788,y:604,t:1527632202601};\\\", \\\"{x:762,y:606,t:1527632202619};\\\", \\\"{x:740,y:606,t:1527632202634};\\\", \\\"{x:721,y:606,t:1527632202653};\\\", \\\"{x:711,y:609,t:1527632202670};\\\", \\\"{x:708,y:609,t:1527632202685};\\\", \\\"{x:702,y:610,t:1527632202702};\\\", \\\"{x:697,y:612,t:1527632202719};\\\", \\\"{x:694,y:613,t:1527632202734};\\\", \\\"{x:690,y:616,t:1527632202752};\\\", \\\"{x:687,y:617,t:1527632202768};\\\", \\\"{x:680,y:617,t:1527632202785};\\\", \\\"{x:670,y:618,t:1527632202801};\\\", \\\"{x:657,y:618,t:1527632202818};\\\", \\\"{x:641,y:618,t:1527632202836};\\\", \\\"{x:619,y:618,t:1527632202851};\\\", \\\"{x:593,y:618,t:1527632202869};\\\", \\\"{x:566,y:618,t:1527632202885};\\\", \\\"{x:543,y:623,t:1527632202901};\\\", \\\"{x:497,y:629,t:1527632202920};\\\", \\\"{x:491,y:630,t:1527632202935};\\\", \\\"{x:493,y:630,t:1527632202999};\\\", \\\"{x:498,y:630,t:1527632203007};\\\", \\\"{x:504,y:626,t:1527632203020};\\\", \\\"{x:521,y:618,t:1527632203036};\\\", \\\"{x:541,y:612,t:1527632203052};\\\", \\\"{x:558,y:610,t:1527632203068};\\\", \\\"{x:568,y:607,t:1527632203086};\\\", \\\"{x:572,y:606,t:1527632203101};\\\", \\\"{x:573,y:606,t:1527632203119};\\\", \\\"{x:577,y:603,t:1527632203135};\\\", \\\"{x:584,y:601,t:1527632203151};\\\", \\\"{x:586,y:600,t:1527632203169};\\\", \\\"{x:587,y:598,t:1527632203185};\\\", \\\"{x:588,y:597,t:1527632203201};\\\", \\\"{x:589,y:596,t:1527632203218};\\\", \\\"{x:589,y:595,t:1527632203247};\\\", \\\"{x:590,y:595,t:1527632203351};\\\", \\\"{x:593,y:593,t:1527632203369};\\\", \\\"{x:594,y:593,t:1527632203386};\\\", \\\"{x:596,y:593,t:1527632203402};\\\", \\\"{x:597,y:593,t:1527632203423};\\\", \\\"{x:598,y:593,t:1527632203436};\\\", \\\"{x:599,y:593,t:1527632203452};\\\", \\\"{x:600,y:593,t:1527632203480};\\\", \\\"{x:601,y:593,t:1527632203502};\\\", \\\"{x:603,y:592,t:1527632203520};\\\", \\\"{x:607,y:592,t:1527632203535};\\\", \\\"{x:610,y:592,t:1527632203552};\\\", \\\"{x:611,y:592,t:1527632203599};\\\", \\\"{x:612,y:592,t:1527632204360};\\\", \\\"{x:613,y:592,t:1527632204370};\\\", \\\"{x:614,y:592,t:1527632204399};\\\", \\\"{x:615,y:592,t:1527632204647};\\\", \\\"{x:622,y:592,t:1527632204655};\\\", \\\"{x:632,y:592,t:1527632204670};\\\", \\\"{x:663,y:592,t:1527632204687};\\\", \\\"{x:685,y:591,t:1527632204703};\\\", \\\"{x:705,y:591,t:1527632204719};\\\", \\\"{x:727,y:591,t:1527632204736};\\\", \\\"{x:744,y:591,t:1527632204752};\\\", \\\"{x:756,y:594,t:1527632204769};\\\", \\\"{x:778,y:601,t:1527632204787};\\\", \\\"{x:823,y:605,t:1527632204803};\\\", \\\"{x:871,y:605,t:1527632204819};\\\", \\\"{x:938,y:605,t:1527632204836};\\\", \\\"{x:1015,y:605,t:1527632204854};\\\", \\\"{x:1099,y:605,t:1527632204869};\\\", \\\"{x:1221,y:605,t:1527632204887};\\\", \\\"{x:1307,y:605,t:1527632204904};\\\", \\\"{x:1385,y:605,t:1527632204919};\\\", \\\"{x:1438,y:605,t:1527632204937};\\\", \\\"{x:1465,y:605,t:1527632204953};\\\", \\\"{x:1482,y:607,t:1527632204970};\\\", \\\"{x:1485,y:608,t:1527632204987};\\\", \\\"{x:1486,y:608,t:1527632205007};\\\", \\\"{x:1486,y:609,t:1527632205056};\\\", \\\"{x:1486,y:612,t:1527632205070};\\\", \\\"{x:1486,y:625,t:1527632205088};\\\", \\\"{x:1483,y:641,t:1527632205104};\\\", \\\"{x:1481,y:657,t:1527632205119};\\\", \\\"{x:1479,y:672,t:1527632205137};\\\", \\\"{x:1474,y:686,t:1527632205154};\\\", \\\"{x:1471,y:695,t:1527632205169};\\\", \\\"{x:1466,y:702,t:1527632205187};\\\", \\\"{x:1458,y:709,t:1527632205204};\\\", \\\"{x:1455,y:711,t:1527632205220};\\\", \\\"{x:1452,y:714,t:1527632205237};\\\", \\\"{x:1452,y:716,t:1527632205312};\\\", \\\"{x:1452,y:720,t:1527632205320};\\\", \\\"{x:1452,y:729,t:1527632205337};\\\", \\\"{x:1452,y:734,t:1527632205354};\\\", \\\"{x:1452,y:745,t:1527632205370};\\\", \\\"{x:1452,y:750,t:1527632205387};\\\", \\\"{x:1452,y:754,t:1527632205404};\\\", \\\"{x:1452,y:757,t:1527632205420};\\\", \\\"{x:1452,y:758,t:1527632205439};\\\", \\\"{x:1456,y:761,t:1527632205703};\\\", \\\"{x:1461,y:764,t:1527632205720};\\\", \\\"{x:1462,y:766,t:1527632205737};\\\", \\\"{x:1465,y:769,t:1527632205754};\\\", \\\"{x:1466,y:772,t:1527632205771};\\\", \\\"{x:1466,y:773,t:1527632205787};\\\", \\\"{x:1467,y:774,t:1527632205807};\\\", \\\"{x:1467,y:775,t:1527632206007};\\\", \\\"{x:1467,y:777,t:1527632206487};\\\", \\\"{x:1467,y:778,t:1527632206504};\\\", \\\"{x:1467,y:782,t:1527632206521};\\\", \\\"{x:1467,y:783,t:1527632206537};\\\", \\\"{x:1467,y:785,t:1527632206554};\\\", \\\"{x:1467,y:787,t:1527632206571};\\\", \\\"{x:1466,y:790,t:1527632206587};\\\", \\\"{x:1466,y:792,t:1527632206604};\\\", \\\"{x:1464,y:793,t:1527632206622};\\\", \\\"{x:1464,y:795,t:1527632206637};\\\", \\\"{x:1463,y:797,t:1527632206655};\\\", \\\"{x:1463,y:798,t:1527632206695};\\\", \\\"{x:1462,y:798,t:1527632206711};\\\", \\\"{x:1461,y:799,t:1527632206735};\\\", \\\"{x:1458,y:799,t:1527632207720};\\\", \\\"{x:1457,y:799,t:1527632207738};\\\", \\\"{x:1456,y:799,t:1527632207968};\\\", \\\"{x:1459,y:803,t:1527632207975};\\\", \\\"{x:1467,y:810,t:1527632207989};\\\", \\\"{x:1471,y:818,t:1527632208004};\\\", \\\"{x:1479,y:829,t:1527632208022};\\\", \\\"{x:1485,y:841,t:1527632208039};\\\", \\\"{x:1490,y:854,t:1527632208054};\\\", \\\"{x:1496,y:871,t:1527632208071};\\\", \\\"{x:1498,y:879,t:1527632208087};\\\", \\\"{x:1499,y:881,t:1527632208105};\\\", \\\"{x:1499,y:882,t:1527632208121};\\\", \\\"{x:1499,y:884,t:1527632208139};\\\", \\\"{x:1499,y:885,t:1527632208154};\\\", \\\"{x:1499,y:888,t:1527632208171};\\\", \\\"{x:1499,y:893,t:1527632208188};\\\", \\\"{x:1499,y:906,t:1527632208204};\\\", \\\"{x:1499,y:922,t:1527632208220};\\\", \\\"{x:1499,y:933,t:1527632208237};\\\", \\\"{x:1499,y:938,t:1527632208253};\\\", \\\"{x:1500,y:945,t:1527632208270};\\\", \\\"{x:1500,y:947,t:1527632208287};\\\", \\\"{x:1500,y:949,t:1527632208304};\\\", \\\"{x:1500,y:955,t:1527632208321};\\\", \\\"{x:1500,y:959,t:1527632208337};\\\", \\\"{x:1500,y:962,t:1527632208354};\\\", \\\"{x:1499,y:965,t:1527632208371};\\\", \\\"{x:1498,y:966,t:1527632208388};\\\", \\\"{x:1498,y:967,t:1527632208404};\\\", \\\"{x:1497,y:968,t:1527632208421};\\\", \\\"{x:1497,y:969,t:1527632208455};\\\", \\\"{x:1495,y:970,t:1527632208583};\\\", \\\"{x:1490,y:967,t:1527632208591};\\\", \\\"{x:1483,y:960,t:1527632208604};\\\", \\\"{x:1472,y:946,t:1527632208621};\\\", \\\"{x:1464,y:934,t:1527632208637};\\\", \\\"{x:1461,y:926,t:1527632208653};\\\", \\\"{x:1457,y:910,t:1527632208670};\\\", \\\"{x:1456,y:901,t:1527632208688};\\\", \\\"{x:1455,y:896,t:1527632208704};\\\", \\\"{x:1454,y:890,t:1527632208721};\\\", \\\"{x:1454,y:888,t:1527632208737};\\\", \\\"{x:1454,y:886,t:1527632208754};\\\", \\\"{x:1454,y:883,t:1527632208771};\\\", \\\"{x:1454,y:881,t:1527632208788};\\\", \\\"{x:1454,y:875,t:1527632208804};\\\", \\\"{x:1454,y:870,t:1527632208821};\\\", \\\"{x:1454,y:864,t:1527632208838};\\\", \\\"{x:1455,y:856,t:1527632208855};\\\", \\\"{x:1456,y:850,t:1527632208871};\\\", \\\"{x:1456,y:842,t:1527632208889};\\\", \\\"{x:1459,y:831,t:1527632208905};\\\", \\\"{x:1461,y:822,t:1527632208922};\\\", \\\"{x:1462,y:809,t:1527632208939};\\\", \\\"{x:1465,y:800,t:1527632208954};\\\", \\\"{x:1465,y:794,t:1527632208971};\\\", \\\"{x:1468,y:786,t:1527632208988};\\\", \\\"{x:1468,y:784,t:1527632209005};\\\", \\\"{x:1469,y:781,t:1527632209021};\\\", \\\"{x:1470,y:779,t:1527632209038};\\\", \\\"{x:1476,y:771,t:1527632209054};\\\", \\\"{x:1477,y:766,t:1527632209071};\\\", \\\"{x:1477,y:764,t:1527632209088};\\\", \\\"{x:1478,y:758,t:1527632209105};\\\", \\\"{x:1480,y:753,t:1527632209121};\\\", \\\"{x:1481,y:746,t:1527632209138};\\\", \\\"{x:1482,y:740,t:1527632209156};\\\", \\\"{x:1484,y:734,t:1527632209172};\\\", \\\"{x:1484,y:729,t:1527632209188};\\\", \\\"{x:1484,y:725,t:1527632209204};\\\", \\\"{x:1484,y:719,t:1527632209221};\\\", \\\"{x:1488,y:712,t:1527632209238};\\\", \\\"{x:1488,y:708,t:1527632209255};\\\", \\\"{x:1488,y:707,t:1527632209271};\\\", \\\"{x:1488,y:702,t:1527632209288};\\\", \\\"{x:1488,y:697,t:1527632209306};\\\", \\\"{x:1488,y:695,t:1527632209322};\\\", \\\"{x:1488,y:693,t:1527632209338};\\\", \\\"{x:1488,y:692,t:1527632209355};\\\", \\\"{x:1488,y:690,t:1527632209371};\\\", \\\"{x:1488,y:681,t:1527632209783};\\\", \\\"{x:1488,y:672,t:1527632209791};\\\", \\\"{x:1488,y:668,t:1527632209805};\\\", \\\"{x:1488,y:655,t:1527632209821};\\\", \\\"{x:1488,y:643,t:1527632209838};\\\", \\\"{x:1488,y:630,t:1527632209855};\\\", \\\"{x:1488,y:622,t:1527632209871};\\\", \\\"{x:1488,y:609,t:1527632209888};\\\", \\\"{x:1488,y:599,t:1527632209905};\\\", \\\"{x:1488,y:591,t:1527632209921};\\\", \\\"{x:1488,y:584,t:1527632209938};\\\", \\\"{x:1489,y:575,t:1527632209955};\\\", \\\"{x:1490,y:557,t:1527632209971};\\\", \\\"{x:1490,y:538,t:1527632209988};\\\", \\\"{x:1490,y:520,t:1527632210005};\\\", \\\"{x:1490,y:502,t:1527632210022};\\\", \\\"{x:1490,y:485,t:1527632210038};\\\", \\\"{x:1490,y:460,t:1527632210055};\\\", \\\"{x:1490,y:445,t:1527632210071};\\\", \\\"{x:1490,y:428,t:1527632210088};\\\", \\\"{x:1490,y:416,t:1527632210105};\\\", \\\"{x:1488,y:405,t:1527632210120};\\\", \\\"{x:1488,y:394,t:1527632210138};\\\", \\\"{x:1488,y:388,t:1527632210154};\\\", \\\"{x:1486,y:379,t:1527632210170};\\\", \\\"{x:1484,y:375,t:1527632210187};\\\", \\\"{x:1484,y:372,t:1527632210204};\\\", \\\"{x:1483,y:370,t:1527632210221};\\\", \\\"{x:1483,y:369,t:1527632210238};\\\", \\\"{x:1483,y:368,t:1527632210255};\\\", \\\"{x:1483,y:364,t:1527632210271};\\\", \\\"{x:1483,y:359,t:1527632210288};\\\", \\\"{x:1483,y:353,t:1527632210305};\\\", \\\"{x:1483,y:350,t:1527632210320};\\\", \\\"{x:1483,y:343,t:1527632210337};\\\", \\\"{x:1483,y:339,t:1527632210355};\\\", \\\"{x:1484,y:333,t:1527632210371};\\\", \\\"{x:1485,y:328,t:1527632210388};\\\", \\\"{x:1485,y:326,t:1527632210405};\\\", \\\"{x:1485,y:323,t:1527632210421};\\\", \\\"{x:1487,y:316,t:1527632210438};\\\", \\\"{x:1489,y:312,t:1527632210454};\\\", \\\"{x:1489,y:310,t:1527632210471};\\\", \\\"{x:1489,y:309,t:1527632210560};\\\", \\\"{x:1488,y:309,t:1527632211200};\\\", \\\"{x:1483,y:308,t:1527632211207};\\\", \\\"{x:1475,y:308,t:1527632211223};\\\", \\\"{x:1440,y:308,t:1527632211239};\\\", \\\"{x:1317,y:311,t:1527632211256};\\\", \\\"{x:1213,y:333,t:1527632211273};\\\", \\\"{x:1091,y:364,t:1527632211288};\\\", \\\"{x:964,y:400,t:1527632211305};\\\", \\\"{x:860,y:439,t:1527632211322};\\\", \\\"{x:773,y:474,t:1527632211338};\\\", \\\"{x:722,y:507,t:1527632211357};\\\", \\\"{x:697,y:535,t:1527632211373};\\\", \\\"{x:655,y:588,t:1527632211405};\\\", \\\"{x:643,y:608,t:1527632211425};\\\", \\\"{x:642,y:611,t:1527632211440};\\\", \\\"{x:641,y:614,t:1527632211458};\\\", \\\"{x:641,y:618,t:1527632211475};\\\", \\\"{x:644,y:624,t:1527632211490};\\\", \\\"{x:647,y:627,t:1527632211508};\\\", \\\"{x:658,y:630,t:1527632211524};\\\", \\\"{x:675,y:630,t:1527632211542};\\\", \\\"{x:693,y:630,t:1527632211558};\\\", \\\"{x:728,y:628,t:1527632211575};\\\", \\\"{x:744,y:624,t:1527632211592};\\\", \\\"{x:753,y:623,t:1527632211608};\\\", \\\"{x:758,y:622,t:1527632211626};\\\", \\\"{x:760,y:621,t:1527632211642};\\\", \\\"{x:761,y:620,t:1527632211662};\\\", \\\"{x:761,y:619,t:1527632211678};\\\", \\\"{x:760,y:617,t:1527632211693};\\\", \\\"{x:756,y:616,t:1527632211709};\\\", \\\"{x:748,y:614,t:1527632211727};\\\", \\\"{x:726,y:612,t:1527632211742};\\\", \\\"{x:684,y:612,t:1527632211759};\\\", \\\"{x:593,y:612,t:1527632211776};\\\", \\\"{x:501,y:612,t:1527632211792};\\\", \\\"{x:418,y:612,t:1527632211809};\\\", \\\"{x:374,y:612,t:1527632211825};\\\", \\\"{x:357,y:613,t:1527632211841};\\\", \\\"{x:352,y:613,t:1527632211858};\\\", \\\"{x:348,y:612,t:1527632211876};\\\", \\\"{x:347,y:611,t:1527632211892};\\\", \\\"{x:346,y:610,t:1527632211952};\\\", \\\"{x:346,y:608,t:1527632212024};\\\", \\\"{x:346,y:606,t:1527632212032};\\\", \\\"{x:349,y:604,t:1527632212042};\\\", \\\"{x:358,y:598,t:1527632212058};\\\", \\\"{x:365,y:593,t:1527632212075};\\\", \\\"{x:372,y:588,t:1527632212091};\\\", \\\"{x:377,y:584,t:1527632212109};\\\", \\\"{x:382,y:581,t:1527632212126};\\\", \\\"{x:387,y:580,t:1527632212141};\\\", \\\"{x:391,y:577,t:1527632212159};\\\", \\\"{x:392,y:578,t:1527632212239};\\\", \\\"{x:392,y:580,t:1527632212255};\\\", \\\"{x:392,y:581,t:1527632212407};\\\", \\\"{x:392,y:583,t:1527632212432};\\\", \\\"{x:390,y:585,t:1527632212622};\\\", \\\"{x:390,y:587,t:1527632212630};\\\", \\\"{x:390,y:589,t:1527632212643};\\\", \\\"{x:390,y:597,t:1527632212660};\\\", \\\"{x:394,y:611,t:1527632212676};\\\", \\\"{x:404,y:627,t:1527632212694};\\\", \\\"{x:415,y:644,t:1527632212710};\\\", \\\"{x:431,y:663,t:1527632212726};\\\", \\\"{x:441,y:681,t:1527632212742};\\\", \\\"{x:446,y:692,t:1527632212760};\\\", \\\"{x:454,y:704,t:1527632212776};\\\", \\\"{x:465,y:718,t:1527632212793};\\\", \\\"{x:476,y:734,t:1527632212810};\\\", \\\"{x:487,y:745,t:1527632212827};\\\", \\\"{x:496,y:749,t:1527632212842};\\\", \\\"{x:500,y:751,t:1527632212860};\\\", \\\"{x:503,y:752,t:1527632212876};\\\", \\\"{x:503,y:753,t:1527632212910};\\\", \\\"{x:505,y:753,t:1527632213487};\\\", \\\"{x:506,y:753,t:1527632213495};\\\", \\\"{x:507,y:753,t:1527632213510};\\\", \\\"{x:516,y:757,t:1527632213526};\\\", \\\"{x:529,y:757,t:1527632213543};\\\", \\\"{x:536,y:757,t:1527632213560};\\\", \\\"{x:537,y:758,t:1527632213631};\\\", \\\"{x:539,y:758,t:1527632213703};\\\", \\\"{x:542,y:758,t:1527632213711};\\\", \\\"{x:544,y:757,t:1527632213727};\\\", \\\"{x:547,y:755,t:1527632213743};\\\", \\\"{x:548,y:755,t:1527632213767};\\\", \\\"{x:549,y:755,t:1527632213782};\\\", \\\"{x:550,y:754,t:1527632213806};\\\" ] }, { \\\"rt\\\": 162115, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 975497, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The vertical axis is the time duration and each point corresponds to 2 points on the horizontal axis, indicating the start and the end time (left-start; right-end). So for events starting at 12pm, I check the line going to North-east from 12pm and find M and L\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11520, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 988024, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 58294, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1047347, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2545, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1051233, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"FA2ZF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"sierra\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"FA2ZF\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 159, dom: 652, initialDom: 783",
  "javascriptErrors": []
}